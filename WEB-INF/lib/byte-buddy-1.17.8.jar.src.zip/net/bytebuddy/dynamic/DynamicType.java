/*      */ package net.bytebuddy.dynamic;
/*      */ 
/*      */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.AnnotatedElement;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Type;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.jar.Attributes;
/*      */ import java.util.jar.JarEntry;
/*      */ import java.util.jar.JarInputStream;
/*      */ import java.util.jar.JarOutputStream;
/*      */ import java.util.jar.Manifest;
/*      */ import net.bytebuddy.ClassFileVersion;
/*      */ import net.bytebuddy.asm.AsmVisitorWrapper;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling;
/*      */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*      */ import net.bytebuddy.description.annotation.AnnotationList;
/*      */ import net.bytebuddy.description.annotation.AnnotationValue;
/*      */ import net.bytebuddy.description.field.FieldDescription;
/*      */ import net.bytebuddy.description.method.MethodDescription;
/*      */ import net.bytebuddy.description.method.ParameterDescription;
/*      */ import net.bytebuddy.description.method.ParameterList;
/*      */ import net.bytebuddy.description.modifier.FieldManifestation;
/*      */ import net.bytebuddy.description.modifier.MethodManifestation;
/*      */ import net.bytebuddy.description.modifier.ModifierContributor;
/*      */ import net.bytebuddy.description.modifier.Ownership;
/*      */ import net.bytebuddy.description.modifier.Visibility;
/*      */ import net.bytebuddy.description.type.RecordComponentDescription;
/*      */ import net.bytebuddy.description.type.TypeDefinition;
/*      */ import net.bytebuddy.description.type.TypeDescription;
/*      */ import net.bytebuddy.description.type.TypeList;
/*      */ import net.bytebuddy.description.type.TypeVariableToken;
/*      */ import net.bytebuddy.dynamic.loading.ClassLoadingStrategy;
/*      */ import net.bytebuddy.dynamic.loading.InjectionClassLoader;
/*      */ import net.bytebuddy.dynamic.scaffold.FieldRegistry;
/*      */ import net.bytebuddy.dynamic.scaffold.InstrumentedType;
/*      */ import net.bytebuddy.dynamic.scaffold.MethodGraph;
/*      */ import net.bytebuddy.dynamic.scaffold.MethodRegistry;
/*      */ import net.bytebuddy.dynamic.scaffold.RecordComponentRegistry;
/*      */ import net.bytebuddy.dynamic.scaffold.TypeValidation;
/*      */ import net.bytebuddy.dynamic.scaffold.TypeWriter;
/*      */ import net.bytebuddy.implementation.EqualsMethod;
/*      */ import net.bytebuddy.implementation.FieldAccessor;
/*      */ import net.bytebuddy.implementation.HashCodeMethod;
/*      */ import net.bytebuddy.implementation.Implementation;
/*      */ import net.bytebuddy.implementation.LoadedTypeInitializer;
/*      */ import net.bytebuddy.implementation.ToStringMethod;
/*      */ import net.bytebuddy.implementation.attribute.AnnotationRetention;
/*      */ import net.bytebuddy.implementation.attribute.AnnotationValueFilter;
/*      */ import net.bytebuddy.implementation.attribute.FieldAttributeAppender;
/*      */ import net.bytebuddy.implementation.attribute.MethodAttributeAppender;
/*      */ import net.bytebuddy.implementation.attribute.RecordComponentAttributeAppender;
/*      */ import net.bytebuddy.implementation.attribute.TypeAttributeAppender;
/*      */ import net.bytebuddy.implementation.auxiliary.AuxiliaryType;
/*      */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*      */ import net.bytebuddy.jar.asm.ClassVisitor;
/*      */ import net.bytebuddy.matcher.ElementMatcher;
/*      */ import net.bytebuddy.matcher.ElementMatchers;
/*      */ import net.bytebuddy.matcher.LatentMatcher;
/*      */ import net.bytebuddy.pool.TypePool;
/*      */ import net.bytebuddy.utility.AsmClassReader;
/*      */ import net.bytebuddy.utility.AsmClassWriter;
/*      */ import net.bytebuddy.utility.CompoundList;
/*      */ import net.bytebuddy.utility.FileSystem;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ import net.bytebuddy.utility.visitor.ContextClassVisitor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface DynamicType
/*      */   extends ClassFileLocator
/*      */ {
/*      */   TypeDescription getTypeDescription();
/*      */   
/*      */   byte[] getBytes();
/*      */   
/*      */   LoadedTypeInitializer getLoadedTypeInitializer();
/*      */   
/*      */   List<? extends DynamicType> getAuxiliaries();
/*      */   
/*      */   Set<TypeDescription> getAuxiliaryTypeDescriptions();
/*      */   
/*      */   Set<TypeDescription> getAllTypeDescriptions();
/*      */   
/*      */   Map<TypeDescription, byte[]> getAuxiliaryTypes();
/*      */   
/*      */   Map<TypeDescription, byte[]> getAllTypes();
/*      */   
/*      */   Map<TypeDescription, LoadedTypeInitializer> getLoadedTypeInitializers();
/*      */   
/*      */   boolean hasAliveLoadedTypeInitializers();
/*      */   
/*      */   Map<TypeDescription, File> saveIn(File paramFile) throws IOException;
/*      */   
/*      */   File inject(File paramFile1, File paramFile2) throws IOException;
/*      */   
/*      */   File inject(File paramFile) throws IOException;
/*      */   
/*      */   File toJar(File paramFile) throws IOException;
/*      */   
/*      */   File toJar(File paramFile, Manifest paramManifest) throws IOException;
/*      */   
/*      */   void close();
/*      */   
/*      */   public static interface Builder<T>
/*      */   {
/*      */     Builder<T> visit(AsmVisitorWrapper param1AsmVisitorWrapper);
/*      */     
/*      */     Builder<T> name(String param1String);
/*      */     
/*      */     Builder<T> suffix(String param1String);
/*      */     
/*      */     Builder<T> modifiers(ModifierContributor.ForType... param1VarArgs);
/*      */     
/*      */     Builder<T> modifiers(Collection<? extends ModifierContributor.ForType> param1Collection);
/*      */     
/*      */     Builder<T> modifiers(int param1Int);
/*      */     
/*      */     Builder<T> merge(ModifierContributor.ForType... param1VarArgs);
/*      */     
/*      */     Builder<T> merge(Collection<? extends ModifierContributor.ForType> param1Collection);
/*      */     
/*      */     Builder<T> topLevelType();
/*      */     
/*      */     InnerTypeDefinition.ForType<T> innerTypeOf(Class<?> param1Class);
/*      */     
/*      */     InnerTypeDefinition.ForType<T> innerTypeOf(TypeDescription param1TypeDescription);
/*      */     
/*      */     InnerTypeDefinition<T> innerTypeOf(Method param1Method);
/*      */     
/*      */     InnerTypeDefinition<T> innerTypeOf(Constructor<?> param1Constructor);
/*      */     
/*      */     InnerTypeDefinition<T> innerTypeOf(MethodDescription.InDefinedShape param1InDefinedShape);
/*      */     
/*      */     Builder<T> declaredTypes(Class<?>... param1VarArgs);
/*      */     
/*      */     Builder<T> declaredTypes(TypeDescription... param1VarArgs);
/*      */     
/*      */     Builder<T> declaredTypes(List<? extends Class<?>> param1List);
/*      */     
/*      */     Builder<T> declaredTypes(Collection<? extends TypeDescription> param1Collection);
/*      */     
/*      */     Builder<T> noNestMate();
/*      */     
/*      */     Builder<T> nestHost(Class<?> param1Class);
/*      */     
/*      */     Builder<T> nestHost(TypeDescription param1TypeDescription);
/*      */     
/*      */     Builder<T> nestMembers(Class<?>... param1VarArgs);
/*      */     
/*      */     Builder<T> nestMembers(TypeDescription... param1VarArgs);
/*      */     
/*      */     Builder<T> nestMembers(List<? extends Class<?>> param1List);
/*      */     
/*      */     Builder<T> nestMembers(Collection<? extends TypeDescription> param1Collection);
/*      */     
/*      */     Builder<T> permittedSubclass(Class<?>... param1VarArgs);
/*      */     
/*      */     Builder<T> permittedSubclass(TypeDescription... param1VarArgs);
/*      */     
/*      */     Builder<T> permittedSubclass(List<? extends Class<?>> param1List);
/*      */     
/*      */     Builder<T> permittedSubclass(Collection<? extends TypeDescription> param1Collection);
/*      */     
/*      */     Builder<T> unsealed();
/*      */     
/*      */     Builder<T> attribute(TypeAttributeAppender param1TypeAttributeAppender);
/*      */     
/*      */     Builder<T> annotateType(Annotation... param1VarArgs);
/*      */     
/*      */     Builder<T> annotateType(List<? extends Annotation> param1List);
/*      */     
/*      */     Builder<T> annotateType(AnnotationDescription... param1VarArgs);
/*      */     
/*      */     Builder<T> annotateType(Collection<? extends AnnotationDescription> param1Collection);
/*      */     
/*      */     MethodDefinition.ImplementationDefinition.Optional<T> implement(Type... param1VarArgs);
/*      */     
/*      */     MethodDefinition.ImplementationDefinition.Optional<T> implement(List<? extends Type> param1List);
/*      */     
/*      */     MethodDefinition.ImplementationDefinition.Optional<T> implement(TypeDefinition... param1VarArgs);
/*      */     
/*      */     MethodDefinition.ImplementationDefinition.Optional<T> implement(Collection<? extends TypeDefinition> param1Collection);
/*      */     
/*      */     Builder<T> initializer(ByteCodeAppender param1ByteCodeAppender);
/*      */     
/*      */     Builder<T> initializer(LoadedTypeInitializer param1LoadedTypeInitializer);
/*      */     
/*      */     Builder<T> require(TypeDescription param1TypeDescription, byte[] param1ArrayOfbyte);
/*      */     
/*      */     Builder<T> require(TypeDescription param1TypeDescription, byte[] param1ArrayOfbyte, LoadedTypeInitializer param1LoadedTypeInitializer);
/*      */     
/*      */     Builder<T> require(DynamicType... param1VarArgs);
/*      */     
/*      */     Builder<T> require(Collection<DynamicType> param1Collection);
/*      */     
/*      */     TypeVariableDefinition<T> typeVariable(String param1String);
/*      */     
/*      */     TypeVariableDefinition<T> typeVariable(String param1String, Type... param1VarArgs);
/*      */     
/*      */     TypeVariableDefinition<T> typeVariable(String param1String, List<? extends Type> param1List);
/*      */     
/*      */     TypeVariableDefinition<T> typeVariable(String param1String, TypeDefinition... param1VarArgs);
/*      */     
/*      */     TypeVariableDefinition<T> typeVariable(String param1String, Collection<? extends TypeDefinition> param1Collection);
/*      */     
/*      */     Builder<T> transform(ElementMatcher<? super TypeDescription.Generic> param1ElementMatcher, Transformer<TypeVariableToken> param1Transformer);
/*      */     
/*      */     FieldDefinition.Optional.Valuable<T> defineField(String param1String, Type param1Type, ModifierContributor.ForField... param1VarArgs);
/*      */     
/*      */     FieldDefinition.Optional.Valuable<T> defineField(String param1String, Type param1Type, Collection<? extends ModifierContributor.ForField> param1Collection);
/*      */     
/*      */     FieldDefinition.Optional.Valuable<T> defineField(String param1String, Type param1Type, int param1Int);
/*      */     
/*      */     FieldDefinition.Optional.Valuable<T> defineField(String param1String, TypeDefinition param1TypeDefinition, ModifierContributor.ForField... param1VarArgs);
/*      */     
/*      */     FieldDefinition.Optional.Valuable<T> defineField(String param1String, TypeDefinition param1TypeDefinition, Collection<? extends ModifierContributor.ForField> param1Collection);
/*      */     
/*      */     FieldDefinition.Optional.Valuable<T> defineField(String param1String, TypeDefinition param1TypeDefinition, int param1Int);
/*      */     
/*      */     FieldDefinition.Optional.Valuable<T> define(Field param1Field);
/*      */     
/*      */     FieldDefinition.Optional.Valuable<T> define(FieldDescription param1FieldDescription);
/*      */     
/*      */     FieldDefinition.Optional<T> serialVersionUid(long param1Long);
/*      */     
/*      */     FieldDefinition.Valuable<T> field(ElementMatcher<? super FieldDescription> param1ElementMatcher);
/*      */     
/*      */     FieldDefinition.Valuable<T> field(LatentMatcher<? super FieldDescription> param1LatentMatcher);
/*      */     
/*      */     Builder<T> ignoreAlso(ElementMatcher<? super MethodDescription> param1ElementMatcher);
/*      */     
/*      */     Builder<T> ignoreAlso(LatentMatcher<? super MethodDescription> param1LatentMatcher);
/*      */     
/*      */     MethodDefinition.ParameterDefinition.Initial<T> defineMethod(String param1String, Type param1Type, ModifierContributor.ForMethod... param1VarArgs);
/*      */     
/*      */     MethodDefinition.ParameterDefinition.Initial<T> defineMethod(String param1String, Type param1Type, Collection<? extends ModifierContributor.ForMethod> param1Collection);
/*      */     
/*      */     MethodDefinition.ParameterDefinition.Initial<T> defineMethod(String param1String, Type param1Type, int param1Int);
/*      */     
/*      */     MethodDefinition.ParameterDefinition.Initial<T> defineMethod(String param1String, TypeDefinition param1TypeDefinition, ModifierContributor.ForMethod... param1VarArgs);
/*      */     
/*      */     MethodDefinition.ParameterDefinition.Initial<T> defineMethod(String param1String, TypeDefinition param1TypeDefinition, Collection<? extends ModifierContributor.ForMethod> param1Collection);
/*      */     
/*      */     MethodDefinition.ParameterDefinition.Initial<T> defineMethod(String param1String, TypeDefinition param1TypeDefinition, int param1Int);
/*      */     
/*      */     MethodDefinition.ParameterDefinition.Initial<T> defineConstructor(ModifierContributor.ForMethod... param1VarArgs);
/*      */     
/*      */     MethodDefinition.ParameterDefinition.Initial<T> defineConstructor(Collection<? extends ModifierContributor.ForMethod> param1Collection);
/*      */     
/*      */     MethodDefinition.ParameterDefinition.Initial<T> defineConstructor(int param1Int);
/*      */     
/*      */     MethodDefinition.ImplementationDefinition<T> define(Method param1Method);
/*      */     
/*      */     MethodDefinition.ImplementationDefinition<T> define(Constructor<?> param1Constructor);
/*      */     
/*      */     MethodDefinition.ImplementationDefinition<T> define(MethodDescription param1MethodDescription);
/*      */     
/*      */     FieldDefinition.Optional<T> defineProperty(String param1String, Type param1Type);
/*      */     
/*      */     FieldDefinition.Optional<T> defineProperty(String param1String, Type param1Type, boolean param1Boolean);
/*      */     
/*      */     FieldDefinition.Optional<T> defineProperty(String param1String, TypeDefinition param1TypeDefinition);
/*      */     
/*      */     FieldDefinition.Optional<T> defineProperty(String param1String, TypeDefinition param1TypeDefinition, boolean param1Boolean);
/*      */     
/*      */     MethodDefinition.ImplementationDefinition<T> method(ElementMatcher<? super MethodDescription> param1ElementMatcher);
/*      */     
/*      */     MethodDefinition.ImplementationDefinition<T> constructor(ElementMatcher<? super MethodDescription> param1ElementMatcher);
/*      */     
/*      */     MethodDefinition.ImplementationDefinition<T> invokable(ElementMatcher<? super MethodDescription> param1ElementMatcher);
/*      */     
/*      */     MethodDefinition.ImplementationDefinition<T> invokable(LatentMatcher<? super MethodDescription> param1LatentMatcher);
/*      */     
/*      */     Builder<T> withHashCodeEquals();
/*      */     
/*      */     Builder<T> withToString();
/*      */     
/*      */     RecordComponentDefinition.Optional<T> defineRecordComponent(String param1String, Type param1Type);
/*      */     
/*      */     RecordComponentDefinition.Optional<T> defineRecordComponent(String param1String, TypeDefinition param1TypeDefinition);
/*      */     
/*      */     RecordComponentDefinition.Optional<T> define(RecordComponentDescription param1RecordComponentDescription);
/*      */     
/*      */     RecordComponentDefinition<T> recordComponent(ElementMatcher<? super RecordComponentDescription> param1ElementMatcher);
/*      */     
/*      */     RecordComponentDefinition<T> recordComponent(LatentMatcher<? super RecordComponentDescription> param1LatentMatcher);
/*      */     
/*      */     ContextClassVisitor wrap(ClassVisitor param1ClassVisitor);
/*      */     
/*      */     ContextClassVisitor wrap(ClassVisitor param1ClassVisitor, int param1Int1, int param1Int2);
/*      */     
/*      */     ContextClassVisitor wrap(ClassVisitor param1ClassVisitor, TypePool param1TypePool);
/*      */     
/*      */     ContextClassVisitor wrap(ClassVisitor param1ClassVisitor, TypePool param1TypePool, int param1Int1, int param1Int2);
/*      */     
/*      */     DynamicType.Unloaded<T> make();
/*      */     
/*      */     DynamicType.Unloaded<T> make(TypeResolutionStrategy param1TypeResolutionStrategy);
/*      */     
/*      */     DynamicType.Unloaded<T> make(TypePool param1TypePool);
/*      */     
/*      */     DynamicType.Unloaded<T> make(TypeResolutionStrategy param1TypeResolutionStrategy, TypePool param1TypePool);
/*      */     
/*      */     TypeDescription toTypeDescription();
/*      */     
/*      */     public static interface TypeVariableDefinition<S>
/*      */       extends Builder<S>
/*      */     {
/*      */       TypeVariableDefinition<S> annotateTypeVariable(Annotation... param2VarArgs);
/*      */       
/*      */       TypeVariableDefinition<S> annotateTypeVariable(List<? extends Annotation> param2List);
/*      */       
/*      */       TypeVariableDefinition<S> annotateTypeVariable(AnnotationDescription... param2VarArgs);
/*      */       
/*      */       TypeVariableDefinition<S> annotateTypeVariable(Collection<? extends AnnotationDescription> param2Collection);
/*      */       
/*      */       public static abstract class AbstractBase<U>
/*      */         extends DynamicType.Builder.AbstractBase.Delegator<U>
/*      */         implements TypeVariableDefinition<U>
/*      */       {
/*      */         public DynamicType.Builder.TypeVariableDefinition<U> annotateTypeVariable(Annotation... annotation) {
/* 1640 */           return annotateTypeVariable(Arrays.asList(annotation));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.TypeVariableDefinition<U> annotateTypeVariable(List<? extends Annotation> annotations) {
/* 1647 */           return annotateTypeVariable((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.TypeVariableDefinition<U> annotateTypeVariable(AnnotationDescription... annotation) {
/* 1654 */           return annotateTypeVariable(Arrays.asList(annotation));
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static interface Valuable<V>
/*      */       extends FieldDefinition.Valuable<V>, FieldDefinition.Optional<V>
/*      */     {
/*      */       public static abstract class AbstractBase<U>
/*      */         extends DynamicType.Builder.FieldDefinition.Optional.AbstractBase<U>
/*      */         implements Valuable<U>
/*      */       {
/*      */         public DynamicType.Builder.FieldDefinition.Optional<U> value(boolean value) {
/* 1856 */           return defaultValue(Integer.valueOf(value ? 1 : 0));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.FieldDefinition.Optional<U> value(int value) {
/* 1863 */           return defaultValue(Integer.valueOf(value));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.FieldDefinition.Optional<U> value(long value) {
/* 1870 */           return defaultValue(Long.valueOf(value));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.FieldDefinition.Optional<U> value(float value) {
/* 1877 */           return defaultValue(Float.valueOf(value));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.FieldDefinition.Optional<U> value(double value) {
/* 1884 */           return defaultValue(Double.valueOf(value));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.FieldDefinition.Optional<U> value(String value) {
/* 1891 */           if (value == null) {
/* 1892 */             throw new IllegalArgumentException("Cannot define 'null' as constant value");
/*      */           }
/* 1894 */           return defaultValue(value);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected abstract DynamicType.Builder.FieldDefinition.Optional<U> defaultValue(Object param5Object);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         private static abstract class Adapter<V>
/*      */           extends AbstractBase<V>
/*      */         {
/*      */           protected final FieldAttributeAppender.Factory fieldAttributeAppenderFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected final Transformer<FieldDescription> transformer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @MaybeNull
/*      */           @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*      */           protected final Object defaultValue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected Adapter(FieldAttributeAppender.Factory fieldAttributeAppenderFactory, Transformer<FieldDescription> transformer, @MaybeNull Object defaultValue) {
/* 1941 */             this.fieldAttributeAppenderFactory = fieldAttributeAppenderFactory;
/* 1942 */             this.transformer = transformer;
/* 1943 */             this.defaultValue = defaultValue;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.FieldDefinition.Optional<V> attribute(FieldAttributeAppender.Factory fieldAttributeAppenderFactory) {
/* 1950 */             return materialize((FieldAttributeAppender.Factory)new FieldAttributeAppender.Factory.Compound(new FieldAttributeAppender.Factory[] { this.fieldAttributeAppenderFactory, fieldAttributeAppenderFactory }, ), this.transformer, this.defaultValue);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.FieldDefinition.Optional<V> transform(Transformer<FieldDescription> transformer) {
/* 1958 */             return materialize(this.fieldAttributeAppenderFactory, new Transformer.Compound<FieldDescription>((Transformer<FieldDescription>[])new Transformer[] { this.transformer, transformer }, ), this.defaultValue);
/*      */           }
/*      */           
/*      */           protected DynamicType.Builder.FieldDefinition.Optional<V> defaultValue(Object defaultValue)
/*      */           {
/* 1963 */             return materialize(this.fieldAttributeAppenderFactory, this.transformer, defaultValue); } protected abstract DynamicType.Builder.FieldDefinition.Optional<V> materialize(FieldAttributeAppender.Factory param6Factory, Transformer<FieldDescription> param6Transformer, @MaybeNull Object param6Object); public boolean equals(@MaybeNull Object param6Object) { if (this == param6Object) return true;  if (param6Object == null) return false;  if (getClass() != param6Object.getClass()) return false;  if (!this.fieldAttributeAppenderFactory.equals(((Adapter)param6Object).fieldAttributeAppenderFactory)) return false;  if (!this.transformer.equals(((Adapter)param6Object).transformer)) return false;  Object object1 = ((Adapter)param6Object).defaultValue; Object object2 = this.defaultValue; if (object1 != null) { if (object2 != null) { if (!object2.equals(object1)) return false;  } else { return false; }  } else if (object2 != null) { return false; }  return true; } public int hashCode() { Object object = this.defaultValue; if (object != null); return ((getClass().hashCode() * 31 + this.fieldAttributeAppenderFactory.hashCode()) * 31 + this.transformer.hashCode()) * 31 + object.hashCode(); } } } } public static interface FieldDefinition<S> { Optional<S> annotateField(Annotation... param2VarArgs); Optional<S> annotateField(List<? extends Annotation> param2List); Optional<S> annotateField(AnnotationDescription... param2VarArgs); Optional<S> annotateField(Collection<? extends AnnotationDescription> param2Collection); Optional<S> attribute(FieldAttributeAppender.Factory param2Factory); Optional<S> transform(Transformer<FieldDescription> param2Transformer); public static interface Optional<U> extends FieldDefinition<U>, DynamicType.Builder<U> { public static interface Valuable<V> extends DynamicType.Builder.FieldDefinition.Valuable<V>, Optional<V> { public static abstract class AbstractBase<U> extends DynamicType.Builder.FieldDefinition.Optional.AbstractBase<U> implements Valuable<U> { public DynamicType.Builder.FieldDefinition.Optional<U> value(boolean value) { return defaultValue(Integer.valueOf(value ? 1 : 0)); } public DynamicType.Builder.FieldDefinition.Optional<U> value(int value) { return defaultValue(Integer.valueOf(value)); } public DynamicType.Builder.FieldDefinition.Optional<U> value(long value) { return defaultValue(Long.valueOf(value)); } public DynamicType.Builder.FieldDefinition.Optional<U> value(float value) { return defaultValue(Float.valueOf(value)); } public DynamicType.Builder.FieldDefinition.Optional<U> value(double value) { return defaultValue(Double.valueOf(value)); } public DynamicType.Builder.FieldDefinition.Optional<U> value(String value) { if (value == null) throw new IllegalArgumentException("Cannot define 'null' as constant value");  return defaultValue(value); } protected abstract DynamicType.Builder.FieldDefinition.Optional<U> defaultValue(Object param5Object); @Enhance private static abstract class Adapter<V> extends AbstractBase<V> { protected final FieldAttributeAppender.Factory fieldAttributeAppenderFactory; protected final Transformer<FieldDescription> transformer; @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) protected final Object defaultValue; protected Adapter(FieldAttributeAppender.Factory fieldAttributeAppenderFactory, Transformer<FieldDescription> transformer, @MaybeNull Object defaultValue) { this.fieldAttributeAppenderFactory = fieldAttributeAppenderFactory; this.transformer = transformer; this.defaultValue = defaultValue; } public DynamicType.Builder.FieldDefinition.Optional<V> attribute(FieldAttributeAppender.Factory fieldAttributeAppenderFactory) { return materialize((FieldAttributeAppender.Factory)new FieldAttributeAppender.Factory.Compound(new FieldAttributeAppender.Factory[] { this.fieldAttributeAppenderFactory, fieldAttributeAppenderFactory }, ), this.transformer, this.defaultValue); } public DynamicType.Builder.FieldDefinition.Optional<V> transform(Transformer<FieldDescription> transformer) { return materialize(this.fieldAttributeAppenderFactory, new Transformer.Compound<FieldDescription>((Transformer<FieldDescription>[])new Transformer[] { this.transformer, transformer }, ), this.defaultValue); } protected DynamicType.Builder.FieldDefinition.Optional<V> defaultValue(Object defaultValue) { return materialize(this.fieldAttributeAppenderFactory, this.transformer, defaultValue); } protected abstract DynamicType.Builder.FieldDefinition.Optional<V> materialize(FieldAttributeAppender.Factory param6Factory, Transformer<FieldDescription> param6Transformer, @MaybeNull Object param6Object); public boolean equals(@MaybeNull Object param6Object) {
/*      */                 if (this == param6Object)
/*      */                   return true; 
/*      */                 if (param6Object == null)
/*      */                   return false; 
/*      */                 if (getClass() != param6Object.getClass())
/*      */                   return false; 
/*      */                 if (!this.fieldAttributeAppenderFactory.equals(((Adapter)param6Object).fieldAttributeAppenderFactory))
/*      */                   return false; 
/*      */                 if (!this.transformer.equals(((Adapter)param6Object).transformer))
/*      */                   return false; 
/*      */                 Object object1 = ((Adapter)param6Object).defaultValue;
/*      */                 Object object2 = this.defaultValue;
/*      */                 if (object1 != null) {
/*      */                   if (object2 != null) {
/*      */                     if (!object2.equals(object1))
/*      */                       return false; 
/*      */                   } else {
/*      */                     return false;
/*      */                   } 
/*      */                 } else if (object2 != null) {
/*      */                   return false;
/*      */                 } 
/*      */                 return true;
/*      */               } public int hashCode() {
/*      */                 Object object = this.defaultValue;
/*      */                 if (object != null);
/*      */                 return ((getClass().hashCode() * 31 + this.fieldAttributeAppenderFactory.hashCode()) * 31 + this.transformer.hashCode()) * 31 + object.hashCode();
/*      */               } } } } public static abstract class AbstractBase<U> extends DynamicType.Builder.AbstractBase.Delegator<U> implements Optional<U> { public DynamicType.Builder.FieldDefinition.Optional<U> annotateField(Annotation... annotation) {
/* 1992 */             return annotateField(Arrays.asList(annotation));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.FieldDefinition.Optional<U> annotateField(List<? extends Annotation> annotations) {
/* 1999 */             return annotateField((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.FieldDefinition.Optional<U> annotateField(AnnotationDescription... annotation)
/*      */           {
/* 2006 */             return annotateField(Arrays.asList(annotation)); } } } public static interface Valuable<U> extends FieldDefinition<U> { DynamicType.Builder.FieldDefinition.Optional<U> value(boolean param3Boolean); DynamicType.Builder.FieldDefinition.Optional<U> value(int param3Int); DynamicType.Builder.FieldDefinition.Optional<U> value(long param3Long); DynamicType.Builder.FieldDefinition.Optional<U> value(float param3Float); DynamicType.Builder.FieldDefinition.Optional<U> value(double param3Double); DynamicType.Builder.FieldDefinition.Optional<U> value(String param3String); } } public static interface Optional<U> extends FieldDefinition<U>, Builder<U> { public static interface Valuable<V> extends DynamicType.Builder.FieldDefinition.Valuable<V>, Optional<V> { public static abstract class AbstractBase<U> extends DynamicType.Builder.FieldDefinition.Optional.AbstractBase<U> implements Valuable<U> { public DynamicType.Builder.FieldDefinition.Optional<U> value(boolean value) { return defaultValue(Integer.valueOf(value ? 1 : 0)); } public DynamicType.Builder.FieldDefinition.Optional<U> value(int value) { return defaultValue(Integer.valueOf(value)); } public DynamicType.Builder.FieldDefinition.Optional<U> value(long value) { return defaultValue(Long.valueOf(value)); } public DynamicType.Builder.FieldDefinition.Optional<U> value(float value) { return defaultValue(Float.valueOf(value)); } public DynamicType.Builder.FieldDefinition.Optional<U> value(double value) { return defaultValue(Double.valueOf(value)); } public DynamicType.Builder.FieldDefinition.Optional<U> value(String value) { if (value == null) throw new IllegalArgumentException("Cannot define 'null' as constant value");  return defaultValue(value); } protected abstract DynamicType.Builder.FieldDefinition.Optional<U> defaultValue(Object param5Object); @Enhance private static abstract class Adapter<V> extends AbstractBase<V> { protected final FieldAttributeAppender.Factory fieldAttributeAppenderFactory; protected final Transformer<FieldDescription> transformer; @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) protected final Object defaultValue; protected Adapter(FieldAttributeAppender.Factory fieldAttributeAppenderFactory, Transformer<FieldDescription> transformer, @MaybeNull Object defaultValue) { this.fieldAttributeAppenderFactory = fieldAttributeAppenderFactory; this.transformer = transformer; this.defaultValue = defaultValue; } public DynamicType.Builder.FieldDefinition.Optional<V> attribute(FieldAttributeAppender.Factory fieldAttributeAppenderFactory) { return materialize((FieldAttributeAppender.Factory)new FieldAttributeAppender.Factory.Compound(new FieldAttributeAppender.Factory[] { this.fieldAttributeAppenderFactory, fieldAttributeAppenderFactory }, ), this.transformer, this.defaultValue); } public DynamicType.Builder.FieldDefinition.Optional<V> transform(Transformer<FieldDescription> transformer) { return materialize(this.fieldAttributeAppenderFactory, new Transformer.Compound<FieldDescription>((Transformer<FieldDescription>[])new Transformer[] { this.transformer, transformer }, ), this.defaultValue); } protected DynamicType.Builder.FieldDefinition.Optional<V> defaultValue(Object defaultValue) { return materialize(this.fieldAttributeAppenderFactory, this.transformer, defaultValue); } protected abstract DynamicType.Builder.FieldDefinition.Optional<V> materialize(FieldAttributeAppender.Factory param6Factory, Transformer<FieldDescription> param6Transformer, @MaybeNull Object param6Object); public boolean equals(@MaybeNull Object param6Object) { if (this == param6Object) return true;  if (param6Object == null) return false;  if (getClass() != param6Object.getClass()) return false;  if (!this.fieldAttributeAppenderFactory.equals(((Adapter)param6Object).fieldAttributeAppenderFactory)) return false;  if (!this.transformer.equals(((Adapter)param6Object).transformer)) return false;  Object object1 = ((Adapter)param6Object).defaultValue; Object object2 = this.defaultValue; if (object1 != null) { if (object2 != null) { if (!object2.equals(object1)) return false;  } else { return false; }  } else if (object2 != null) { return false; }  return true; } public int hashCode() { Object object = this.defaultValue; if (object != null); return ((getClass().hashCode() * 31 + this.fieldAttributeAppenderFactory.hashCode()) * 31 + this.transformer.hashCode()) * 31 + object.hashCode(); } } } } public static abstract class AbstractBase<U> extends DynamicType.Builder.AbstractBase.Delegator<U> implements Optional<U> { public DynamicType.Builder.FieldDefinition.Optional<U> annotateField(Annotation... annotation) { return annotateField(Arrays.asList(annotation)); } public DynamicType.Builder.FieldDefinition.Optional<U> annotateField(List<? extends Annotation> annotations) { return annotateField((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations)); } public DynamicType.Builder.FieldDefinition.Optional<U> annotateField(AnnotationDescription... annotation) { return annotateField(Arrays.asList(annotation)); }
/*      */          }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static interface ImplementationDefinition<U>
/*      */     {
/*      */       DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> intercept(Implementation param2Implementation);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> withoutCode();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> defaultValue(AnnotationValue<?, ?> param2AnnotationValue);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       <W> DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> defaultValue(W param2W, Class<? extends W> param2Class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static abstract class AbstractBase<V>
/*      */         implements ImplementationDefinition<V>
/*      */       {
/*      */         public <W> DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<V> defaultValue(W value, Class<? extends W> type) {
/* 2234 */           return defaultValue(AnnotationDescription.ForLoadedAnnotation.asValue(value, type));
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static interface Optional<V>
/*      */         extends ImplementationDefinition<V>, DynamicType.Builder<V> {}
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static interface Initial<V>
/*      */       extends MethodDefinition.ParameterDefinition<V>, MethodDefinition.ParameterDefinition.Simple<V>
/*      */     {
/*      */       DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> withParameters(Type... param2VarArgs);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> withParameters(List<? extends Type> param2List);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> withParameters(TypeDefinition... param2VarArgs);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> withParameters(Collection<? extends TypeDefinition> param2Collection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static abstract class AbstractBase<W>
/*      */         extends DynamicType.Builder.MethodDefinition.ParameterDefinition.AbstractBase<W>
/*      */         implements Initial<W>
/*      */       {
/*      */         public DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.Annotatable<W> withParameter(Type type) {
/* 2968 */           return withParameter((TypeDefinition)TypeDefinition.Sort.describe(type));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition.ExceptionDefinition<W> withParameters(Type... type) {
/* 2975 */           return withParameters(Arrays.asList(type));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition.ExceptionDefinition<W> withParameters(List<? extends Type> types) {
/* 2982 */           return withParameters((Collection<? extends TypeDefinition>)new TypeList.Generic.ForLoadedTypes(types));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition.ExceptionDefinition<W> withParameters(TypeDefinition... type) {
/* 2989 */           return withParameters(Arrays.asList(type));
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition.ExceptionDefinition<W> withParameters(Collection<? extends TypeDefinition> types)
/*      */         {
/* 2996 */           DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple<W> parameterDefinition = this;
/* 2997 */           for (TypeDefinition type : types) {
/* 2998 */             parameterDefinition = parameterDefinition.withParameter(type);
/*      */           }
/* 3000 */           return parameterDefinition; } } } public static interface ParameterDefinition<U> extends MethodDefinition.ExceptionDefinition<U> { Annotatable<U> withParameter(Type param2Type, String param2String, ModifierContributor.ForParameter... param2VarArgs); Annotatable<U> withParameter(Type param2Type, String param2String, Collection<? extends ModifierContributor.ForParameter> param2Collection); Annotatable<U> withParameter(Type param2Type, String param2String, int param2Int); Annotatable<U> withParameter(TypeDefinition param2TypeDefinition, String param2String, ModifierContributor.ForParameter... param2VarArgs); Annotatable<U> withParameter(TypeDefinition param2TypeDefinition, String param2String, Collection<? extends ModifierContributor.ForParameter> param2Collection); Annotatable<U> withParameter(TypeDefinition param2TypeDefinition, String param2String, int param2Int); public static interface Annotatable<V> extends ParameterDefinition<V> { Annotatable<V> annotateParameter(Annotation... param4VarArgs); Annotatable<V> annotateParameter(List<? extends Annotation> param4List); Annotatable<V> annotateParameter(AnnotationDescription... param4VarArgs); Annotatable<V> annotateParameter(Collection<? extends AnnotationDescription> param4Collection); public static abstract class AbstractBase<W> extends DynamicType.Builder.MethodDefinition.ParameterDefinition.AbstractBase<W> implements Annotatable<W> { public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<W> annotateParameter(Annotation... annotation) { return annotateParameter(Arrays.asList(annotation)); } public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<W> annotateParameter(List<? extends Annotation> annotations) { return annotateParameter((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations)); } public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<W> annotateParameter(AnnotationDescription... annotation) { return annotateParameter(Arrays.asList(annotation)); } protected static abstract class Adapter<X> extends AbstractBase<X> { public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<X> withParameter(TypeDefinition type, String name, int modifiers) { return materialize().withParameter(type, name, modifiers); } public DynamicType.Builder.MethodDefinition.ExceptionDefinition<X> throwing(Collection<? extends TypeDefinition> types) { return materialize().throwing(types); } public DynamicType.Builder.MethodDefinition.TypeVariableDefinition.Annotatable<X> typeVariable(String symbol, Collection<? extends TypeDefinition> bounds) { return materialize().typeVariable(symbol, bounds); } public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> intercept(Implementation implementation) { return materialize().intercept(implementation); } public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> withoutCode() { return materialize().withoutCode(); } public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> defaultValue(AnnotationValue<?, ?> annotationValue) { return materialize().defaultValue(annotationValue); } public <V> DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> defaultValue(V value, Class<? extends V> type) { return materialize().defaultValue(value, type); } protected abstract DynamicType.Builder.MethodDefinition.ParameterDefinition<X> materialize(); } } } public static interface Simple<V> extends DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> { Annotatable<V> withParameter(Type param4Type); Annotatable<V> withParameter(TypeDefinition param4TypeDefinition); public static interface Annotatable<V> extends Simple<V> { Annotatable<V> annotateParameter(Annotation... param5VarArgs); Annotatable<V> annotateParameter(List<? extends Annotation> param5List); Annotatable<V> annotateParameter(AnnotationDescription... param5VarArgs); Annotatable<V> annotateParameter(Collection<? extends AnnotationDescription> param5Collection); public static abstract class AbstractBase<W> extends DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.AbstractBase<W> implements Annotatable<W> { public DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.Annotatable<W> annotateParameter(Annotation... annotation) { return annotateParameter(Arrays.asList(annotation)); } public DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.Annotatable<W> annotateParameter(List<? extends Annotation> annotations) { return annotateParameter((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations)); } public DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.Annotatable<W> annotateParameter(AnnotationDescription... annotation) { return annotateParameter(Arrays.asList(annotation)); } protected static abstract class Adapter<X> extends AbstractBase<X> { public DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.Annotatable<X> withParameter(TypeDefinition type) { return materialize().withParameter(type); } public DynamicType.Builder.MethodDefinition.ExceptionDefinition<X> throwing(Collection<? extends TypeDefinition> types) { return materialize().throwing(types); } public DynamicType.Builder.MethodDefinition.TypeVariableDefinition.Annotatable<X> typeVariable(String symbol, Collection<? extends TypeDefinition> bounds) { return materialize().typeVariable(symbol, bounds); } public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> intercept(Implementation implementation) { return materialize().intercept(implementation); } public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> withoutCode() { return materialize().withoutCode(); } public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> defaultValue(AnnotationValue<?, ?> annotationValue) { return materialize().defaultValue(annotationValue); } public <V> DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> defaultValue(V value, Class<? extends V> type) { return materialize().defaultValue(value, type); } protected abstract DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple<X> materialize(); } } } public static abstract class AbstractBase<W> extends DynamicType.Builder.MethodDefinition.ExceptionDefinition.AbstractBase<W> implements Simple<W> { public DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.Annotatable<W> withParameter(Type type) { return withParameter((TypeDefinition)TypeDefinition.Sort.describe(type)); } } } public static interface Initial<V> extends ParameterDefinition<V>, Simple<V> { DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> withParameters(Type... param4VarArgs); DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> withParameters(List<? extends Type> param4List); DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> withParameters(TypeDefinition... param4VarArgs); DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> withParameters(Collection<? extends TypeDefinition> param4Collection); public static abstract class AbstractBase<W> extends DynamicType.Builder.MethodDefinition.ParameterDefinition.AbstractBase<W> implements Initial<W> { public DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.Annotatable<W> withParameter(Type type) { return withParameter((TypeDefinition)TypeDefinition.Sort.describe(type)); } public DynamicType.Builder.MethodDefinition.ExceptionDefinition<W> withParameters(Type... type) { return withParameters(Arrays.asList(type)); } public DynamicType.Builder.MethodDefinition.ExceptionDefinition<W> withParameters(List<? extends Type> types) { return withParameters((Collection<? extends TypeDefinition>)new TypeList.Generic.ForLoadedTypes(types)); } public DynamicType.Builder.MethodDefinition.ExceptionDefinition<W> withParameters(TypeDefinition... type) { return withParameters(Arrays.asList(type)); } public DynamicType.Builder.MethodDefinition.ExceptionDefinition<W> withParameters(Collection<? extends TypeDefinition> types) { DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple<W> parameterDefinition = this; for (TypeDefinition type : types) parameterDefinition = parameterDefinition.withParameter(type);  return parameterDefinition; }
/*      */            }
/*      */          }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static abstract class AbstractBase<V>
/*      */         extends DynamicType.Builder.MethodDefinition.ExceptionDefinition.AbstractBase<V>
/*      */         implements ParameterDefinition<V>
/*      */       {
/*      */         public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<V> withParameter(Type type, String name, ModifierContributor.ForParameter... modifierContributor) {
/* 3016 */           return withParameter(type, name, Arrays.asList(modifierContributor));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<V> withParameter(Type type, String name, Collection<? extends ModifierContributor.ForParameter> modifierContributors) {
/* 3023 */           return withParameter(type, name, ModifierContributor.Resolver.of(modifierContributors).resolve());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<V> withParameter(Type type, String name, int modifiers) {
/* 3030 */           return withParameter((TypeDefinition)TypeDefinition.Sort.describe(type), name, modifiers);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<V> withParameter(TypeDefinition type, String name, ModifierContributor.ForParameter... modifierContributor) {
/* 3037 */           return withParameter(type, name, Arrays.asList(modifierContributor));
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<V> withParameter(TypeDefinition type, String name, Collection<? extends ModifierContributor.ForParameter> modifierContributors)
/*      */         {
/* 3044 */           return withParameter(type, name, ModifierContributor.Resolver.of(modifierContributors).resolve()); } } } public static interface MethodDefinition<S> extends Builder<S> { MethodDefinition<S> annotateMethod(Annotation... param2VarArgs); MethodDefinition<S> annotateMethod(List<? extends Annotation> param2List); MethodDefinition<S> annotateMethod(AnnotationDescription... param2VarArgs); MethodDefinition<S> annotateMethod(Collection<? extends AnnotationDescription> param2Collection); MethodDefinition<S> annotateParameter(int param2Int, Annotation... param2VarArgs); MethodDefinition<S> annotateParameter(int param2Int, List<? extends Annotation> param2List); MethodDefinition<S> annotateParameter(int param2Int, AnnotationDescription... param2VarArgs); MethodDefinition<S> annotateParameter(int param2Int, Collection<? extends AnnotationDescription> param2Collection); MethodDefinition<S> attribute(MethodAttributeAppender.Factory param2Factory); MethodDefinition<S> transform(Transformer<MethodDescription> param2Transformer); public static interface ReceiverTypeDefinition<U> extends MethodDefinition<U> { DynamicType.Builder.MethodDefinition<U> receiverType(AnnotatedElement param3AnnotatedElement); DynamicType.Builder.MethodDefinition<U> receiverType(TypeDescription.Generic param3Generic); public static abstract class AbstractBase<V> extends DynamicType.Builder.MethodDefinition.AbstractBase<V> implements ReceiverTypeDefinition<V> { public DynamicType.Builder.MethodDefinition<V> receiverType(AnnotatedElement receiverType) { return receiverType(TypeDefinition.Sort.describeAnnotated(receiverType)); } } } public static interface ImplementationDefinition<U> { DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> intercept(Implementation param3Implementation); DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> withoutCode(); DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> defaultValue(AnnotationValue<?, ?> param3AnnotationValue); <W> DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> defaultValue(W param3W, Class<? extends W> param3Class); public static abstract class AbstractBase<V> implements ImplementationDefinition<V> { public <W> DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<V> defaultValue(W value, Class<? extends W> type) { return defaultValue(AnnotationDescription.ForLoadedAnnotation.asValue(value, type)); } } public static interface Optional<V> extends ImplementationDefinition<V>, DynamicType.Builder<V> {} } public static interface TypeVariableDefinition<U> extends ImplementationDefinition<U> { Annotatable<U> typeVariable(String param3String); Annotatable<U> typeVariable(String param3String, Type... param3VarArgs); Annotatable<U> typeVariable(String param3String, List<? extends Type> param3List); Annotatable<U> typeVariable(String param3String, TypeDefinition... param3VarArgs); Annotatable<U> typeVariable(String param3String, Collection<? extends TypeDefinition> param3Collection); public static interface Annotatable<V> extends TypeVariableDefinition<V> { Annotatable<V> annotateTypeVariable(Annotation... param4VarArgs); Annotatable<V> annotateTypeVariable(List<? extends Annotation> param4List); Annotatable<V> annotateTypeVariable(AnnotationDescription... param4VarArgs); Annotatable<V> annotateTypeVariable(Collection<? extends AnnotationDescription> param4Collection); public static abstract class AbstractBase<W> extends DynamicType.Builder.MethodDefinition.TypeVariableDefinition.AbstractBase<W> implements Annotatable<W> { public DynamicType.Builder.MethodDefinition.TypeVariableDefinition.Annotatable<W> annotateTypeVariable(Annotation... annotation) { return annotateTypeVariable(Arrays.asList(annotation)); } public DynamicType.Builder.MethodDefinition.TypeVariableDefinition.Annotatable<W> annotateTypeVariable(List<? extends Annotation> annotations) { return annotateTypeVariable((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations)); } public DynamicType.Builder.MethodDefinition.TypeVariableDefinition.Annotatable<W> annotateTypeVariable(AnnotationDescription... annotation) { return annotateTypeVariable(Arrays.asList(annotation)); } protected static abstract class Adapter<X> extends AbstractBase<X> { public DynamicType.Builder.MethodDefinition.TypeVariableDefinition.Annotatable<X> typeVariable(String symbol, Collection<? extends TypeDefinition> bounds) { return materialize().typeVariable(symbol, bounds); } public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> intercept(Implementation implementation) { return materialize().intercept(implementation); } public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> withoutCode() { return materialize().withoutCode(); } public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> defaultValue(AnnotationValue<?, ?> annotationValue) { return materialize().defaultValue(annotationValue); } public <V> DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> defaultValue(V value, Class<? extends V> type) { return materialize().defaultValue(value, type); } protected abstract DynamicType.Builder.MethodDefinition.ParameterDefinition<X> materialize(); } } } public static abstract class AbstractBase<V> extends DynamicType.Builder.MethodDefinition.ImplementationDefinition.AbstractBase<V> implements TypeVariableDefinition<V> { public DynamicType.Builder.MethodDefinition.TypeVariableDefinition.Annotatable<V> typeVariable(String symbol) { return typeVariable(symbol, Collections.singletonList(Object.class)); } public DynamicType.Builder.MethodDefinition.TypeVariableDefinition.Annotatable<V> typeVariable(String symbol, Type... bound) { return typeVariable(symbol, Arrays.asList(bound)); } public DynamicType.Builder.MethodDefinition.TypeVariableDefinition.Annotatable<V> typeVariable(String symbol, List<? extends Type> bounds) { return typeVariable(symbol, (Collection<? extends TypeDefinition>)new TypeList.Generic.ForLoadedTypes(bounds)); } public DynamicType.Builder.MethodDefinition.TypeVariableDefinition.Annotatable<V> typeVariable(String symbol, TypeDefinition... bound) { return typeVariable(symbol, Arrays.asList(bound)); } } } public static interface ExceptionDefinition<U> extends TypeVariableDefinition<U> { ExceptionDefinition<U> throwing(Type... param3VarArgs); ExceptionDefinition<U> throwing(List<? extends Type> param3List); ExceptionDefinition<U> throwing(TypeDefinition... param3VarArgs); ExceptionDefinition<U> throwing(Collection<? extends TypeDefinition> param3Collection); public static abstract class AbstractBase<V> extends DynamicType.Builder.MethodDefinition.TypeVariableDefinition.AbstractBase<V> implements ExceptionDefinition<V> { public DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> throwing(Type... type) { return throwing(Arrays.asList(type)); } public DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> throwing(List<? extends Type> types) { return throwing((Collection<? extends TypeDefinition>)new TypeList.Generic.ForLoadedTypes(types)); } public DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> throwing(TypeDefinition... type) { return throwing(Arrays.asList(type)); } } } public static interface ParameterDefinition<U> extends ExceptionDefinition<U> { Annotatable<U> withParameter(Type param3Type, String param3String, ModifierContributor.ForParameter... param3VarArgs); Annotatable<U> withParameter(Type param3Type, String param3String, Collection<? extends ModifierContributor.ForParameter> param3Collection); Annotatable<U> withParameter(Type param3Type, String param3String, int param3Int); Annotatable<U> withParameter(TypeDefinition param3TypeDefinition, String param3String, ModifierContributor.ForParameter... param3VarArgs); Annotatable<U> withParameter(TypeDefinition param3TypeDefinition, String param3String, Collection<? extends ModifierContributor.ForParameter> param3Collection); Annotatable<U> withParameter(TypeDefinition param3TypeDefinition, String param3String, int param3Int); public static interface Annotatable<V> extends ParameterDefinition<V> { Annotatable<V> annotateParameter(Annotation... param4VarArgs); Annotatable<V> annotateParameter(List<? extends Annotation> param4List); Annotatable<V> annotateParameter(AnnotationDescription... param4VarArgs); Annotatable<V> annotateParameter(Collection<? extends AnnotationDescription> param4Collection); public static abstract class AbstractBase<W> extends DynamicType.Builder.MethodDefinition.ParameterDefinition.AbstractBase<W> implements Annotatable<W> { public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<W> annotateParameter(Annotation... annotation) { return annotateParameter(Arrays.asList(annotation)); } public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<W> annotateParameter(List<? extends Annotation> annotations) { return annotateParameter((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations)); } public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<W> annotateParameter(AnnotationDescription... annotation) { return annotateParameter(Arrays.asList(annotation)); } protected static abstract class Adapter<X> extends AbstractBase<X> { public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<X> withParameter(TypeDefinition type, String name, int modifiers) { return materialize().withParameter(type, name, modifiers); } public DynamicType.Builder.MethodDefinition.ExceptionDefinition<X> throwing(Collection<? extends TypeDefinition> types) { return materialize().throwing(types); } public DynamicType.Builder.MethodDefinition.TypeVariableDefinition.Annotatable<X> typeVariable(String symbol, Collection<? extends TypeDefinition> bounds) { return materialize().typeVariable(symbol, bounds); } public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> intercept(Implementation implementation) { return materialize().intercept(implementation); } public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> withoutCode() { return materialize().withoutCode(); } public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> defaultValue(AnnotationValue<?, ?> annotationValue) { return materialize().defaultValue(annotationValue); } public <V> DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> defaultValue(V value, Class<? extends V> type) { return materialize().defaultValue(value, type); } protected abstract DynamicType.Builder.MethodDefinition.ParameterDefinition<X> materialize(); } } } public static interface Simple<V> extends DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> { Annotatable<V> withParameter(Type param4Type); Annotatable<V> withParameter(TypeDefinition param4TypeDefinition); public static interface Annotatable<V> extends Simple<V> { Annotatable<V> annotateParameter(Annotation... param5VarArgs); Annotatable<V> annotateParameter(List<? extends Annotation> param5List); Annotatable<V> annotateParameter(AnnotationDescription... param5VarArgs); Annotatable<V> annotateParameter(Collection<? extends AnnotationDescription> param5Collection); public static abstract class AbstractBase<W> extends DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.AbstractBase<W> implements Annotatable<W> { public DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.Annotatable<W> annotateParameter(Annotation... annotation) { return annotateParameter(Arrays.asList(annotation)); } public DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.Annotatable<W> annotateParameter(List<? extends Annotation> annotations) { return annotateParameter((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations)); } public DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.Annotatable<W> annotateParameter(AnnotationDescription... annotation) { return annotateParameter(Arrays.asList(annotation)); } protected static abstract class Adapter<X> extends AbstractBase<X> { public DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.Annotatable<X> withParameter(TypeDefinition type) { return materialize().withParameter(type); } public DynamicType.Builder.MethodDefinition.ExceptionDefinition<X> throwing(Collection<? extends TypeDefinition> types) { return materialize().throwing(types); } public DynamicType.Builder.MethodDefinition.TypeVariableDefinition.Annotatable<X> typeVariable(String symbol, Collection<? extends TypeDefinition> bounds) { return materialize().typeVariable(symbol, bounds); } public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> intercept(Implementation implementation) { return materialize().intercept(implementation); } public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> withoutCode() { return materialize().withoutCode(); } public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> defaultValue(AnnotationValue<?, ?> annotationValue) { return materialize().defaultValue(annotationValue); } public <V> DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<X> defaultValue(V value, Class<? extends V> type) { return materialize().defaultValue(value, type); } protected abstract DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple<X> materialize(); } } } public static abstract class AbstractBase<W> extends DynamicType.Builder.MethodDefinition.ExceptionDefinition.AbstractBase<W> implements Simple<W> { public DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.Annotatable<W> withParameter(Type type) { return withParameter((TypeDefinition)TypeDefinition.Sort.describe(type)); } } } public static interface Initial<V> extends ParameterDefinition<V>, Simple<V> { DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> withParameters(Type... param4VarArgs); DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> withParameters(List<? extends Type> param4List); DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> withParameters(TypeDefinition... param4VarArgs); DynamicType.Builder.MethodDefinition.ExceptionDefinition<V> withParameters(Collection<? extends TypeDefinition> param4Collection); public static abstract class AbstractBase<W> extends DynamicType.Builder.MethodDefinition.ParameterDefinition.AbstractBase<W> implements Initial<W> { public DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.Annotatable<W> withParameter(Type type) { return withParameter((TypeDefinition)TypeDefinition.Sort.describe(type)); } public DynamicType.Builder.MethodDefinition.ExceptionDefinition<W> withParameters(Type... type) { return withParameters(Arrays.asList(type)); } public DynamicType.Builder.MethodDefinition.ExceptionDefinition<W> withParameters(List<? extends Type> types) { return withParameters((Collection<? extends TypeDefinition>)new TypeList.Generic.ForLoadedTypes(types)); } public DynamicType.Builder.MethodDefinition.ExceptionDefinition<W> withParameters(TypeDefinition... type) { return withParameters(Arrays.asList(type)); } public DynamicType.Builder.MethodDefinition.ExceptionDefinition<W> withParameters(Collection<? extends TypeDefinition> types) { DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple<W> parameterDefinition = this; for (TypeDefinition type : types) parameterDefinition = parameterDefinition.withParameter(type);  return parameterDefinition; } } } public static abstract class AbstractBase<V> extends DynamicType.Builder.MethodDefinition.ExceptionDefinition.AbstractBase<V> implements ParameterDefinition<V> { public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<V> withParameter(TypeDefinition type, String name, Collection<? extends ModifierContributor.ForParameter> modifierContributors) { return withParameter(type, name, ModifierContributor.Resolver.of(modifierContributors).resolve()); }
/*      */           
/*      */           public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<V> withParameter(Type type, String name, ModifierContributor.ForParameter... modifierContributor) {
/*      */             return withParameter(type, name, Arrays.asList(modifierContributor));
/*      */           }
/*      */           public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<V> withParameter(Type type, String name, Collection<? extends ModifierContributor.ForParameter> modifierContributors) {
/*      */             return withParameter(type, name, ModifierContributor.Resolver.of(modifierContributors).resolve());
/*      */           }
/*      */           public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<V> withParameter(Type type, String name, int modifiers) {
/*      */             return withParameter((TypeDefinition)TypeDefinition.Sort.describe(type), name, modifiers);
/*      */           }
/*      */           public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<V> withParameter(TypeDefinition type, String name, ModifierContributor.ForParameter... modifierContributor) {
/*      */             return withParameter(type, name, Arrays.asList(modifierContributor));
/*      */           } } }
/*      */       
/*      */       public static abstract class AbstractBase<U> extends DynamicType.Builder.AbstractBase.Delegator<U> implements MethodDefinition<U> { public DynamicType.Builder.MethodDefinition<U> annotateMethod(Annotation... annotation) {
/* 3060 */           return annotateMethod(Arrays.asList(annotation));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition<U> annotateMethod(List<? extends Annotation> annotations) {
/* 3067 */           return annotateMethod((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition<U> annotateMethod(AnnotationDescription... annotation) {
/* 3074 */           return annotateMethod(Arrays.asList(annotation));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition<U> annotateParameter(int index, Annotation... annotation) {
/* 3081 */           return annotateParameter(index, Arrays.asList(annotation));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition<U> annotateParameter(int index, List<? extends Annotation> annotations) {
/* 3088 */           return annotateParameter(index, (Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition<U> annotateParameter(int index, AnnotationDescription... annotation) {
/* 3095 */           return annotateParameter(index, Arrays.asList(annotation));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         protected static abstract class Adapter<V>
/*      */           extends DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition.AbstractBase<V>
/*      */         {
/*      */           protected final MethodRegistry.Handler handler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected final MethodAttributeAppender.Factory methodAttributeAppenderFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected final Transformer<MethodDescription> transformer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected Adapter(MethodRegistry.Handler handler, MethodAttributeAppender.Factory methodAttributeAppenderFactory, Transformer<MethodDescription> transformer) {
/* 3131 */             this.handler = handler;
/* 3132 */             this.methodAttributeAppenderFactory = methodAttributeAppenderFactory;
/* 3133 */             this.transformer = transformer;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.MethodDefinition<V> attribute(MethodAttributeAppender.Factory methodAttributeAppenderFactory) {
/* 3140 */             return materialize(this.handler, (MethodAttributeAppender.Factory)new MethodAttributeAppender.Factory.Compound(new MethodAttributeAppender.Factory[] { this.methodAttributeAppenderFactory, methodAttributeAppenderFactory }, ), this.transformer);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.MethodDefinition<V> transform(Transformer<MethodDescription> transformer) {
/* 3148 */             return materialize(this.handler, this.methodAttributeAppenderFactory, new Transformer.Compound<MethodDescription>((Transformer<MethodDescription>[])new Transformer[] { this.transformer, transformer }));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected abstract DynamicType.Builder.MethodDefinition<V> materialize(MethodRegistry.Handler param4Handler, MethodAttributeAppender.Factory param4Factory, Transformer<MethodDescription> param4Transformer);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.handler.equals(((Adapter)param4Object).handler) ? false : (!this.methodAttributeAppenderFactory.equals(((Adapter)param4Object).methodAttributeAppenderFactory) ? false : (!!this.transformer.equals(((Adapter)param4Object).transformer))))));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return ((getClass().hashCode() * 31 + this.handler.hashCode()) * 31 + this.methodAttributeAppenderFactory.hashCode()) * 31 + this.transformer.hashCode();
/*      */           }
/*      */         } }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static interface RecordComponentDefinition<S>
/*      */     {
/*      */       Optional<S> annotateRecordComponent(Annotation... param2VarArgs);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Optional<S> annotateRecordComponent(List<? extends Annotation> param2List);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Optional<S> annotateRecordComponent(AnnotationDescription... param2VarArgs);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Optional<S> annotateRecordComponent(Collection<? extends AnnotationDescription> param2Collection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Optional<S> attribute(RecordComponentAttributeAppender.Factory param2Factory);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Optional<S> transform(Transformer<RecordComponentDescription> param2Transformer);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static interface Optional<U>
/*      */         extends RecordComponentDefinition<U>, DynamicType.Builder<U>
/*      */       {
/*      */         public static abstract class AbstractBase<U>
/*      */           extends DynamicType.Builder.AbstractBase.Delegator<U>
/*      */           implements Optional<U>
/*      */         {
/*      */           public DynamicType.Builder.RecordComponentDefinition.Optional<U> annotateRecordComponent(Annotation... annotation) {
/* 3241 */             return annotateRecordComponent(Arrays.asList(annotation));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.RecordComponentDefinition.Optional<U> annotateRecordComponent(List<? extends Annotation> annotations) {
/* 3248 */             return annotateRecordComponent((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.RecordComponentDefinition.Optional<U> annotateRecordComponent(AnnotationDescription... annotation)
/*      */           {
/* 3255 */             return annotateRecordComponent(Arrays.asList(annotation)); } } } } public static interface Optional<U> extends RecordComponentDefinition<U>, Builder<U> { public static abstract class AbstractBase<U> extends DynamicType.Builder.AbstractBase.Delegator<U> implements Optional<U> { public DynamicType.Builder.RecordComponentDefinition.Optional<U> annotateRecordComponent(Annotation... annotation) { return annotateRecordComponent(Arrays.asList(annotation)); } public DynamicType.Builder.RecordComponentDefinition.Optional<U> annotateRecordComponent(List<? extends Annotation> annotations) { return annotateRecordComponent((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations)); } public DynamicType.Builder.RecordComponentDefinition.Optional<U> annotateRecordComponent(AnnotationDescription... annotation) { return annotateRecordComponent(Arrays.asList(annotation)); }
/*      */          }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static abstract class AbstractBase<S>
/*      */       implements Builder<S>
/*      */     {
/*      */       public DynamicType.Builder.InnerTypeDefinition.ForType<S> innerTypeOf(Class<?> type) {
/* 3272 */         return innerTypeOf(TypeDescription.ForLoadedType.of(type));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.InnerTypeDefinition<S> innerTypeOf(Method method) {
/* 3279 */         return innerTypeOf((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.InnerTypeDefinition<S> innerTypeOf(Constructor<?> constructor) {
/* 3286 */         return innerTypeOf((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(constructor));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> declaredTypes(Class<?>... type) {
/* 3293 */         return declaredTypes(Arrays.asList(type));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> declaredTypes(TypeDescription... type) {
/* 3300 */         return declaredTypes(Arrays.asList(type));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> declaredTypes(List<? extends Class<?>> type) {
/* 3307 */         return declaredTypes((Collection<? extends TypeDescription>)new TypeList.ForLoadedTypes(type));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> noNestMate() {
/* 3314 */         return nestHost(TargetType.DESCRIPTION);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> nestHost(Class<?> type) {
/* 3321 */         return nestHost(TypeDescription.ForLoadedType.of(type));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> nestMembers(Class<?>... type) {
/* 3328 */         return nestMembers(Arrays.asList(type));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> nestMembers(TypeDescription... type) {
/* 3335 */         return nestMembers(Arrays.asList(type));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> nestMembers(List<? extends Class<?>> types) {
/* 3342 */         return nestMembers((Collection<? extends TypeDescription>)new TypeList.ForLoadedTypes(types));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> permittedSubclass(Class<?>... type) {
/* 3349 */         return permittedSubclass(Arrays.asList(type));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> permittedSubclass(TypeDescription... type) {
/* 3356 */         return permittedSubclass(Arrays.asList(type));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> permittedSubclass(List<? extends Class<?>> types) {
/* 3363 */         return permittedSubclass((Collection<? extends TypeDescription>)new TypeList.ForLoadedTypes(types));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> annotateType(Annotation... annotation) {
/* 3370 */         return annotateType(Arrays.asList(annotation));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> annotateType(List<? extends Annotation> annotations) {
/* 3377 */         return annotateType((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> annotateType(AnnotationDescription... annotation) {
/* 3384 */         return annotateType(Arrays.asList(annotation));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> modifiers(ModifierContributor.ForType... modifierContributor) {
/* 3391 */         return modifiers(Arrays.asList(modifierContributor));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> modifiers(Collection<? extends ModifierContributor.ForType> modifierContributors) {
/* 3398 */         return modifiers(ModifierContributor.Resolver.of(modifierContributors).resolve());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> merge(ModifierContributor.ForType... modifierContributor) {
/* 3405 */         return merge(Arrays.asList(modifierContributor));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.MethodDefinition.ImplementationDefinition.Optional<S> implement(Type... interfaceType) {
/* 3412 */         return implement(Arrays.asList(interfaceType));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.MethodDefinition.ImplementationDefinition.Optional<S> implement(List<? extends Type> interfaceTypes) {
/* 3419 */         return implement((Collection<? extends TypeDefinition>)new TypeList.Generic.ForLoadedTypes(interfaceTypes));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.MethodDefinition.ImplementationDefinition.Optional<S> implement(TypeDefinition... interfaceType) {
/* 3426 */         return implement(Arrays.asList(interfaceType));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.TypeVariableDefinition<S> typeVariable(String symbol) {
/* 3433 */         return typeVariable(symbol, new TypeDefinition[] { (TypeDefinition)TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class) });
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.TypeVariableDefinition<S> typeVariable(String symbol, Type... bound) {
/* 3440 */         return typeVariable(symbol, Arrays.asList(bound));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.TypeVariableDefinition<S> typeVariable(String symbol, List<? extends Type> bounds) {
/* 3447 */         return typeVariable(symbol, (Collection<? extends TypeDefinition>)new TypeList.Generic.ForLoadedTypes(bounds));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.TypeVariableDefinition<S> typeVariable(String symbol, TypeDefinition... bound) {
/* 3454 */         return typeVariable(symbol, Arrays.asList(bound));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.RecordComponentDefinition.Optional<S> defineRecordComponent(String name, Type type) {
/* 3461 */         return defineRecordComponent(name, (TypeDefinition)TypeDefinition.Sort.describe(type));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.RecordComponentDefinition.Optional<S> define(RecordComponentDescription recordComponentDescription) {
/* 3468 */         return defineRecordComponent(recordComponentDescription.getActualName(), (TypeDefinition)recordComponentDescription.getType());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.RecordComponentDefinition<S> recordComponent(ElementMatcher<? super RecordComponentDescription> matcher) {
/* 3475 */         return recordComponent((LatentMatcher<? super RecordComponentDescription>)new LatentMatcher.Resolved(matcher));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.FieldDefinition.Optional.Valuable<S> defineField(String name, Type type, ModifierContributor.ForField... modifierContributor) {
/* 3482 */         return defineField(name, type, Arrays.asList(modifierContributor));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.FieldDefinition.Optional.Valuable<S> defineField(String name, Type type, Collection<? extends ModifierContributor.ForField> modifierContributors) {
/* 3489 */         return defineField(name, type, ModifierContributor.Resolver.of(modifierContributors).resolve());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.FieldDefinition.Optional.Valuable<S> defineField(String name, Type type, int modifiers) {
/* 3496 */         return defineField(name, (TypeDefinition)TypeDefinition.Sort.describe(type), modifiers);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.FieldDefinition.Optional.Valuable<S> defineField(String name, TypeDefinition type, ModifierContributor.ForField... modifierContributor) {
/* 3503 */         return defineField(name, type, Arrays.asList(modifierContributor));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.FieldDefinition.Optional.Valuable<S> defineField(String name, TypeDefinition type, Collection<? extends ModifierContributor.ForField> modifierContributors) {
/* 3510 */         return defineField(name, type, ModifierContributor.Resolver.of(modifierContributors).resolve());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.FieldDefinition.Optional.Valuable<S> define(Field field) {
/* 3517 */         return define((FieldDescription)new FieldDescription.ForLoadedField(field));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.FieldDefinition.Optional.Valuable<S> define(FieldDescription field) {
/* 3524 */         return defineField(field.getName(), (TypeDefinition)field.getType(), field.getModifiers());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.FieldDefinition.Optional<S> serialVersionUid(long serialVersionUid) {
/* 3531 */         return defineField("serialVersionUID", long.class, new ModifierContributor.ForField[] { (ModifierContributor.ForField)Visibility.PRIVATE, (ModifierContributor.ForField)FieldManifestation.FINAL, (ModifierContributor.ForField)Ownership.STATIC }).value(serialVersionUid);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.FieldDefinition.Valuable<S> field(ElementMatcher<? super FieldDescription> matcher) {
/* 3538 */         return field((LatentMatcher<? super FieldDescription>)new LatentMatcher.Resolved(matcher));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> ignoreAlso(ElementMatcher<? super MethodDescription> ignoredMethods) {
/* 3545 */         return ignoreAlso((LatentMatcher<? super MethodDescription>)new LatentMatcher.Resolved(ignoredMethods));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial<S> defineMethod(String name, Type returnType, ModifierContributor.ForMethod... modifierContributor) {
/* 3552 */         return defineMethod(name, returnType, Arrays.asList(modifierContributor));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial<S> defineMethod(String name, Type returnType, Collection<? extends ModifierContributor.ForMethod> modifierContributors) {
/* 3559 */         return defineMethod(name, returnType, ModifierContributor.Resolver.of(modifierContributors).resolve());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial<S> defineMethod(String name, Type returnType, int modifiers) {
/* 3566 */         return defineMethod(name, (TypeDefinition)TypeDefinition.Sort.describe(returnType), modifiers);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial<S> defineMethod(String name, TypeDefinition returnType, ModifierContributor.ForMethod... modifierContributor) {
/* 3573 */         return defineMethod(name, returnType, Arrays.asList(modifierContributor));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial<S> defineMethod(String name, TypeDefinition returnType, Collection<? extends ModifierContributor.ForMethod> modifierContributors) {
/* 3580 */         return defineMethod(name, returnType, ModifierContributor.Resolver.of(modifierContributors).resolve());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial<S> defineConstructor(ModifierContributor.ForMethod... modifierContributor) {
/* 3587 */         return defineConstructor(Arrays.asList(modifierContributor));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial<S> defineConstructor(Collection<? extends ModifierContributor.ForMethod> modifierContributors) {
/* 3594 */         return defineConstructor(ModifierContributor.Resolver.of(modifierContributors).resolve());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.MethodDefinition.ImplementationDefinition<S> define(Method method) {
/* 3601 */         return define((MethodDescription)new MethodDescription.ForLoadedMethod(method));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.MethodDefinition.ImplementationDefinition<S> define(Constructor<?> constructor) {
/* 3608 */         return define((MethodDescription)new MethodDescription.ForLoadedConstructor(constructor));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.MethodDefinition.ImplementationDefinition<S> define(MethodDescription methodDescription) {
/*      */         DynamicType.Builder.MethodDefinition.ExceptionDefinition<S> exceptionDefinition;
/* 3617 */         DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial<S> initialParameterDefinition = methodDescription.isConstructor() ? defineConstructor(methodDescription.getModifiers()) : defineMethod(methodDescription.getInternalName(), (TypeDefinition)methodDescription.getReturnType(), methodDescription.getModifiers());
/* 3618 */         ParameterList<?> parameterList = methodDescription.getParameters();
/*      */         
/* 3620 */         if (parameterList.hasExplicitMetaData()) {
/* 3621 */           DynamicType.Builder.MethodDefinition.ParameterDefinition<S> parameterDefinition = initialParameterDefinition;
/* 3622 */           for (ParameterDescription parameter : parameterList) {
/* 3623 */             parameterDefinition = parameterDefinition.withParameter((TypeDefinition)parameter.getType(), parameter.getName(), parameter.getModifiers());
/*      */           }
/* 3625 */           exceptionDefinition = parameterDefinition;
/*      */         } else {
/* 3627 */           exceptionDefinition = initialParameterDefinition.withParameters((Collection<? extends TypeDefinition>)parameterList.asTypeList());
/*      */         } 
/* 3629 */         DynamicType.Builder.MethodDefinition.TypeVariableDefinition<S> typeVariableDefinition = exceptionDefinition.throwing((Collection<? extends TypeDefinition>)methodDescription.getExceptionTypes());
/* 3630 */         for (TypeDescription.Generic typeVariable : methodDescription.getTypeVariables()) {
/* 3631 */           typeVariableDefinition = typeVariableDefinition.typeVariable(typeVariable.getSymbol(), (Collection<? extends TypeDefinition>)typeVariable.getUpperBounds());
/*      */         }
/* 3633 */         return typeVariableDefinition;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.FieldDefinition.Optional<S> defineProperty(String name, Type type) {
/* 3640 */         return defineProperty(name, (TypeDefinition)TypeDefinition.Sort.describe(type));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.FieldDefinition.Optional<S> defineProperty(String name, Type type, boolean readOnly) {
/* 3647 */         return defineProperty(name, (TypeDefinition)TypeDefinition.Sort.describe(type), readOnly);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.FieldDefinition.Optional<S> defineProperty(String name, TypeDefinition type) {
/* 3654 */         return defineProperty(name, type, false);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.FieldDefinition.Optional<S> defineProperty(String name, TypeDefinition type, boolean readOnly) {
/*      */         FieldManifestation fieldManifestation;
/* 3661 */         if (name.length() == 0)
/* 3662 */           throw new IllegalArgumentException("A bean property cannot have an empty name"); 
/* 3663 */         if (type.represents(void.class)) {
/* 3664 */           throw new IllegalArgumentException("A bean property cannot have a void type");
/*      */         }
/* 3666 */         DynamicType.Builder<S> builder = this;
/*      */         
/* 3668 */         if (!readOnly) {
/*      */ 
/*      */ 
/*      */           
/* 3672 */           builder = builder.defineMethod("set" + Character.toUpperCase(name.charAt(0)) + name.substring(1), void.class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC }).withParameters(new TypeDefinition[] { type }).intercept((Implementation)FieldAccessor.ofField(name));
/* 3673 */           fieldManifestation = FieldManifestation.PLAIN;
/*      */         } else {
/* 3675 */           fieldManifestation = FieldManifestation.FINAL;
/*      */         } 
/* 3677 */         return builder
/* 3678 */           .defineMethod((type.represents(boolean.class) ? "is" : "get") + 
/*      */             
/* 3680 */             Character.toUpperCase(name.charAt(0)) + name.substring(1), type, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC
/* 3681 */             }).intercept((Implementation)FieldAccessor.ofField(name))
/* 3682 */           .defineField(name, type, new ModifierContributor.ForField[] { (ModifierContributor.ForField)Visibility.PRIVATE, (ModifierContributor.ForField)fieldManifestation });
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.MethodDefinition.ImplementationDefinition<S> method(ElementMatcher<? super MethodDescription> matcher) {
/* 3689 */         return invokable((ElementMatcher<? super MethodDescription>)ElementMatchers.isMethod().and(matcher));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.MethodDefinition.ImplementationDefinition<S> constructor(ElementMatcher<? super MethodDescription> matcher) {
/* 3696 */         return invokable((ElementMatcher<? super MethodDescription>)ElementMatchers.isConstructor().and(matcher));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder.MethodDefinition.ImplementationDefinition<S> invokable(ElementMatcher<? super MethodDescription> matcher) {
/* 3703 */         return invokable((LatentMatcher<? super MethodDescription>)new LatentMatcher.Resolved(matcher));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> withHashCodeEquals() {
/* 3710 */         return method((ElementMatcher<? super MethodDescription>)ElementMatchers.isHashCode())
/* 3711 */           .intercept((Implementation)HashCodeMethod.usingDefaultOffset().withIgnoredFields((ElementMatcher)ElementMatchers.isSynthetic()))
/* 3712 */           .method((ElementMatcher<? super MethodDescription>)ElementMatchers.isEquals())
/* 3713 */           .intercept((Implementation)EqualsMethod.isolated().withIgnoredFields((ElementMatcher)ElementMatchers.isSynthetic()));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> withToString() {
/* 3720 */         return method((ElementMatcher<? super MethodDescription>)ElementMatchers.isToString()).intercept((Implementation)ToStringMethod.prefixedBySimpleClassName());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> require(TypeDescription type, byte[] binaryRepresentation) {
/* 3727 */         return require(type, binaryRepresentation, (LoadedTypeInitializer)LoadedTypeInitializer.NoOp.INSTANCE);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> require(TypeDescription type, byte[] binaryRepresentation, LoadedTypeInitializer typeInitializer) {
/* 3734 */         return require(new DynamicType[] { new DynamicType.Default(type, binaryRepresentation, typeInitializer, Collections.emptyList()) });
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Builder<S> require(DynamicType... auxiliaryType) {
/* 3741 */         return require(Arrays.asList(auxiliaryType));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ContextClassVisitor wrap(ClassVisitor classVisitor) {
/* 3748 */         return wrap(classVisitor, 0, 0);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ContextClassVisitor wrap(ClassVisitor classVisitor, TypePool typePool) {
/* 3755 */         return wrap(classVisitor, typePool, 0, 0);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Unloaded<S> make(TypePool typePool) {
/* 3762 */         return make(TypeResolutionStrategy.Passive.INSTANCE, typePool);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Unloaded<S> make() {
/* 3769 */         return make(TypeResolutionStrategy.Passive.INSTANCE);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static abstract class Delegator<U>
/*      */         extends AbstractBase<U>
/*      */       {
/*      */         public DynamicType.Builder<U> visit(AsmVisitorWrapper asmVisitorWrapper) {
/* 3783 */           return materialize().visit(asmVisitorWrapper);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> initializer(LoadedTypeInitializer loadedTypeInitializer) {
/* 3790 */           return materialize().initializer(loadedTypeInitializer);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> annotateType(Collection<? extends AnnotationDescription> annotations) {
/* 3797 */           return materialize().annotateType(annotations);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> attribute(TypeAttributeAppender typeAttributeAppender) {
/* 3804 */           return materialize().attribute(typeAttributeAppender);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> modifiers(int modifiers) {
/* 3811 */           return materialize().modifiers(modifiers);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> merge(Collection<? extends ModifierContributor.ForType> modifierContributors) {
/* 3818 */           return materialize().merge(modifierContributors);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> suffix(String suffix) {
/* 3825 */           return materialize().suffix(suffix);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> name(String name) {
/* 3832 */           return materialize().name(name);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> topLevelType() {
/* 3839 */           return materialize().topLevelType();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.InnerTypeDefinition.ForType<U> innerTypeOf(TypeDescription type) {
/* 3846 */           return materialize().innerTypeOf(type);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.InnerTypeDefinition<U> innerTypeOf(MethodDescription.InDefinedShape methodDescription) {
/* 3853 */           return materialize().innerTypeOf(methodDescription);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> declaredTypes(Collection<? extends TypeDescription> types) {
/* 3860 */           return materialize().declaredTypes(types);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> nestHost(TypeDescription type) {
/* 3867 */           return materialize().nestHost(type);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> nestMembers(Collection<? extends TypeDescription> types) {
/* 3874 */           return materialize().nestMembers(types);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> permittedSubclass(Collection<? extends TypeDescription> types) {
/* 3881 */           return materialize().permittedSubclass(types);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> unsealed() {
/* 3888 */           return materialize().unsealed();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition.ImplementationDefinition.Optional<U> implement(Collection<? extends TypeDefinition> interfaceTypes) {
/* 3895 */           return materialize().implement(interfaceTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> initializer(ByteCodeAppender byteCodeAppender) {
/* 3902 */           return materialize().initializer(byteCodeAppender);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> ignoreAlso(ElementMatcher<? super MethodDescription> ignoredMethods) {
/* 3909 */           return materialize().ignoreAlso(ignoredMethods);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> ignoreAlso(LatentMatcher<? super MethodDescription> ignoredMethods) {
/* 3916 */           return materialize().ignoreAlso(ignoredMethods);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.TypeVariableDefinition<U> typeVariable(String symbol, Collection<? extends TypeDefinition> bounds) {
/* 3923 */           return materialize().typeVariable(symbol, bounds);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> transform(ElementMatcher<? super TypeDescription.Generic> matcher, Transformer<TypeVariableToken> transformer) {
/* 3930 */           return materialize().transform(matcher, transformer);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.FieldDefinition.Optional.Valuable<U> defineField(String name, TypeDefinition type, int modifiers) {
/* 3937 */           return materialize().defineField(name, type, modifiers);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.FieldDefinition.Valuable<U> field(LatentMatcher<? super FieldDescription> matcher) {
/* 3944 */           return materialize().field(matcher);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial<U> defineMethod(String name, TypeDefinition returnType, int modifiers) {
/* 3951 */           return materialize().defineMethod(name, returnType, modifiers);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial<U> defineConstructor(int modifiers) {
/* 3958 */           return materialize().defineConstructor(modifiers);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition.ImplementationDefinition<U> invokable(LatentMatcher<? super MethodDescription> matcher) {
/* 3965 */           return materialize().invokable(matcher);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> require(Collection<DynamicType> auxiliaryTypes) {
/* 3972 */           return materialize().require(auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.RecordComponentDefinition.Optional<U> defineRecordComponent(String name, TypeDefinition type) {
/* 3979 */           return materialize().defineRecordComponent(name, type);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.RecordComponentDefinition.Optional<U> define(RecordComponentDescription recordComponentDescription) {
/* 3986 */           return materialize().define(recordComponentDescription);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.RecordComponentDefinition<U> recordComponent(ElementMatcher<? super RecordComponentDescription> matcher) {
/* 3993 */           return materialize().recordComponent(matcher);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.RecordComponentDefinition<U> recordComponent(LatentMatcher<? super RecordComponentDescription> matcher) {
/* 4000 */           return materialize().recordComponent(matcher);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public ContextClassVisitor wrap(ClassVisitor classVisitor, int writerFlags, int readerFlags) {
/* 4007 */           return materialize().wrap(classVisitor, writerFlags, readerFlags);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public ContextClassVisitor wrap(ClassVisitor classVisitor, TypePool typePool, int writerFlags, int readerFlags) {
/* 4014 */           return materialize().wrap(classVisitor, typePool, writerFlags, readerFlags);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Unloaded<U> make() {
/* 4021 */           return materialize().make();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Unloaded<U> make(TypeResolutionStrategy typeResolutionStrategy) {
/* 4028 */           return materialize().make(typeResolutionStrategy);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Unloaded<U> make(TypePool typePool) {
/* 4035 */           return materialize().make(typePool);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Unloaded<U> make(TypeResolutionStrategy typeResolutionStrategy, TypePool typePool) {
/* 4042 */           return materialize().make(typeResolutionStrategy, typePool);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TypeDescription toTypeDescription() {
/* 4049 */           return materialize().toTypeDescription();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected abstract DynamicType.Builder<U> materialize();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static abstract class UsingTypeWriter<U>
/*      */         extends AbstractBase<U>
/*      */       {
/*      */         public ContextClassVisitor wrap(ClassVisitor classVisitor, int writerFlags, int readerFlags) {
/* 4071 */           return toTypeWriter().wrap(classVisitor, writerFlags, readerFlags);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public ContextClassVisitor wrap(ClassVisitor classVisitor, TypePool typePool, int writerFlags, int readerFlags) {
/* 4078 */           return toTypeWriter(typePool).wrap(classVisitor, writerFlags, readerFlags);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Unloaded<U> make(TypeResolutionStrategy typeResolutionStrategy) {
/* 4085 */           return toTypeWriter().make(typeResolutionStrategy.resolve());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Unloaded<U> make(TypeResolutionStrategy typeResolutionStrategy, TypePool typePool) {
/* 4092 */           return toTypeWriter(typePool).make(typeResolutionStrategy.resolve());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected abstract TypeWriter<U> toTypeWriter();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected abstract TypeWriter<U> toTypeWriter(TypePool param3TypePool);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static abstract class Adapter<U>
/*      */         extends UsingTypeWriter<U>
/*      */       {
/*      */         protected final InstrumentedType.WithFlexibleName instrumentedType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final FieldRegistry fieldRegistry;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final MethodRegistry methodRegistry;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final RecordComponentRegistry recordComponentRegistry;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final TypeAttributeAppender typeAttributeAppender;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final AsmVisitorWrapper asmVisitorWrapper;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final ClassFileVersion classFileVersion;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final AnnotationValueFilter.Factory annotationValueFilterFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final AnnotationRetention annotationRetention;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final Implementation.Context.Factory implementationContextFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final MethodGraph.Compiler methodGraphCompiler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final TypeValidation typeValidation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final VisibilityBridgeStrategy visibilityBridgeStrategy;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final AsmClassReader.Factory classReaderFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final AsmClassWriter.Factory classWriterFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final LatentMatcher<? super MethodDescription> ignoredMethods;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final List<? extends DynamicType> auxiliaryTypes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected Adapter(InstrumentedType.WithFlexibleName instrumentedType, FieldRegistry fieldRegistry, MethodRegistry methodRegistry, RecordComponentRegistry recordComponentRegistry, TypeAttributeAppender typeAttributeAppender, AsmVisitorWrapper asmVisitorWrapper, ClassFileVersion classFileVersion, AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy, AnnotationValueFilter.Factory annotationValueFilterFactory, AnnotationRetention annotationRetention, Implementation.Context.Factory implementationContextFactory, MethodGraph.Compiler methodGraphCompiler, TypeValidation typeValidation, VisibilityBridgeStrategy visibilityBridgeStrategy, AsmClassReader.Factory classReaderFactory, AsmClassWriter.Factory classWriterFactory, LatentMatcher<? super MethodDescription> ignoredMethods, List<? extends DynamicType> auxiliaryTypes) {
/* 4249 */           this.instrumentedType = instrumentedType;
/* 4250 */           this.fieldRegistry = fieldRegistry;
/* 4251 */           this.methodRegistry = methodRegistry;
/* 4252 */           this.recordComponentRegistry = recordComponentRegistry;
/* 4253 */           this.typeAttributeAppender = typeAttributeAppender;
/* 4254 */           this.asmVisitorWrapper = asmVisitorWrapper;
/* 4255 */           this.classFileVersion = classFileVersion;
/* 4256 */           this.auxiliaryTypeNamingStrategy = auxiliaryTypeNamingStrategy;
/* 4257 */           this.annotationValueFilterFactory = annotationValueFilterFactory;
/* 4258 */           this.annotationRetention = annotationRetention;
/* 4259 */           this.implementationContextFactory = implementationContextFactory;
/* 4260 */           this.methodGraphCompiler = methodGraphCompiler;
/* 4261 */           this.typeValidation = typeValidation;
/* 4262 */           this.visibilityBridgeStrategy = visibilityBridgeStrategy;
/* 4263 */           this.classReaderFactory = classReaderFactory;
/* 4264 */           this.classWriterFactory = classWriterFactory;
/* 4265 */           this.ignoredMethods = ignoredMethods;
/* 4266 */           this.auxiliaryTypes = auxiliaryTypes;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.FieldDefinition.Optional.Valuable<U> defineField(String name, TypeDefinition type, int modifiers) {
/* 4273 */           return new FieldDefinitionAdapter(new FieldDescription.Token(name, modifiers, type.asGenericType()));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.FieldDefinition.Valuable<U> field(LatentMatcher<? super FieldDescription> matcher) {
/* 4280 */           return new FieldMatchAdapter(matcher);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial<U> defineMethod(String name, TypeDefinition returnType, int modifiers) {
/* 4287 */           return new MethodDefinitionAdapter(new MethodDescription.Token(name, modifiers, returnType.asGenericType()));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial<U> defineConstructor(int modifiers) {
/* 4294 */           return new MethodDefinitionAdapter(new MethodDescription.Token(modifiers));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition.ImplementationDefinition<U> invokable(LatentMatcher<? super MethodDescription> matcher) {
/* 4301 */           return new MethodMatchAdapter(matcher);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.MethodDefinition.ImplementationDefinition.Optional<U> implement(Collection<? extends TypeDefinition> interfaceTypes) {
/* 4308 */           return new OptionalMethodMatchAdapter((TypeList.Generic)new TypeList.Generic.Explicit(new ArrayList<TypeDefinition>(interfaceTypes)));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> ignoreAlso(LatentMatcher<? super MethodDescription> ignoredMethods) {
/* 4316 */           return materialize(this.instrumentedType, this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, (LatentMatcher<? super MethodDescription>)new LatentMatcher.Disjunction(new LatentMatcher[] { this.ignoredMethods, ignoredMethods }, ), this.auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.RecordComponentDefinition.Optional<U> defineRecordComponent(String name, TypeDefinition type) {
/* 4340 */           return new RecordComponentDefinitionAdapter(new RecordComponentDescription.Token(name, type.asGenericType()));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.RecordComponentDefinition<U> recordComponent(LatentMatcher<? super RecordComponentDescription> matcher) {
/* 4347 */           return new RecordComponentMatchAdapter(matcher);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> initializer(ByteCodeAppender byteCodeAppender) {
/* 4354 */           return materialize(this.instrumentedType.withInitializer(byteCodeAppender), this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> initializer(LoadedTypeInitializer loadedTypeInitializer) {
/* 4378 */           return materialize(this.instrumentedType.withInitializer(loadedTypeInitializer), this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> name(String name) {
/* 4402 */           return materialize(this.instrumentedType.withName(name), this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> suffix(String suffix) {
/* 4426 */           return name(this.instrumentedType.getName() + "$" + suffix);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> modifiers(int modifiers) {
/* 4433 */           return materialize(this.instrumentedType.withModifiers(modifiers), this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> merge(Collection<? extends ModifierContributor.ForType> modifierContributors) {
/* 4457 */           return materialize(this.instrumentedType.withModifiers(ModifierContributor.Resolver.of(modifierContributors).resolve(this.instrumentedType.getModifiers())), this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> topLevelType() {
/* 4481 */           return materialize(this.instrumentedType
/* 4482 */               .withDeclaringType(TypeDescription.UNDEFINED)
/* 4483 */               .withEnclosingType(TypeDescription.UNDEFINED)
/* 4484 */               .withLocalClass(false), this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.InnerTypeDefinition.ForType<U> innerTypeOf(TypeDescription type) {
/* 4508 */           return new InnerTypeDefinitionForTypeAdapter(type);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.InnerTypeDefinition<U> innerTypeOf(MethodDescription.InDefinedShape methodDescription) {
/* 4515 */           return methodDescription.isTypeInitializer() ? new InnerTypeDefinitionForTypeAdapter(methodDescription
/* 4516 */               .getDeclaringType()) : new InnerTypeDefinitionForMethodAdapter(methodDescription);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> declaredTypes(Collection<? extends TypeDescription> types) {
/* 4524 */           return materialize(this.instrumentedType.withDeclaredTypes((TypeList)new TypeList.Explicit(new ArrayList<TypeDescription>(types))), this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> nestHost(TypeDescription type) {
/* 4548 */           return materialize(this.instrumentedType.withNestHost(type), this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> nestMembers(Collection<? extends TypeDescription> types) {
/* 4572 */           return materialize(this.instrumentedType.withNestMembers((TypeList)new TypeList.Explicit(new ArrayList<TypeDescription>(types))), this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> permittedSubclass(Collection<? extends TypeDescription> types) {
/* 4596 */           return materialize(this.instrumentedType.withPermittedSubclasses((TypeList)new TypeList.Explicit(new ArrayList<TypeDescription>(types))), this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> unsealed() {
/* 4620 */           return materialize(this.instrumentedType.withPermittedSubclasses(TypeList.UNDEFINED), this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder.TypeVariableDefinition<U> typeVariable(String symbol, Collection<? extends TypeDefinition> bounds) {
/* 4644 */           return new TypeVariableDefinitionAdapter(new TypeVariableToken(symbol, (List)new TypeList.Generic.Explicit(new ArrayList<TypeDefinition>(bounds))));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> transform(ElementMatcher<? super TypeDescription.Generic> matcher, Transformer<TypeVariableToken> transformer) {
/* 4651 */           return materialize(this.instrumentedType.withTypeVariables(matcher, transformer), this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> attribute(TypeAttributeAppender typeAttributeAppender) {
/* 4675 */           return materialize(this.instrumentedType, this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, (TypeAttributeAppender)new TypeAttributeAppender.Compound(new TypeAttributeAppender[] { this.typeAttributeAppender, typeAttributeAppender }, ), this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> annotateType(Collection<? extends AnnotationDescription> annotations) {
/* 4699 */           return materialize(this.instrumentedType.withAnnotations(new ArrayList<AnnotationDescription>(annotations)), this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> visit(AsmVisitorWrapper asmVisitorWrapper) {
/* 4723 */           return materialize(this.instrumentedType, this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, this.typeAttributeAppender, (AsmVisitorWrapper)new AsmVisitorWrapper.Compound(new AsmVisitorWrapper[] { this.asmVisitorWrapper, asmVisitorWrapper }, ), this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, this.auxiliaryTypes);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public DynamicType.Builder<U> require(Collection<DynamicType> auxiliaryTypes) {
/* 4747 */           return materialize(this.instrumentedType, this.fieldRegistry, this.methodRegistry, this.recordComponentRegistry, this.typeAttributeAppender, this.asmVisitorWrapper, this.classFileVersion, this.auxiliaryTypeNamingStrategy, this.annotationValueFilterFactory, this.annotationRetention, this.implementationContextFactory, this.methodGraphCompiler, this.typeValidation, this.visibilityBridgeStrategy, this.classReaderFactory, this.classWriterFactory, this.ignoredMethods, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 4764 */               CompoundList.of(this.auxiliaryTypes, new ArrayList<DynamicType>(auxiliaryTypes)));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TypeDescription toTypeDescription() {
/* 4771 */           return (TypeDescription)this.instrumentedType;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected abstract DynamicType.Builder<U> materialize(InstrumentedType.WithFlexibleName param3WithFlexibleName, FieldRegistry param3FieldRegistry, MethodRegistry param3MethodRegistry, RecordComponentRegistry param3RecordComponentRegistry, TypeAttributeAppender param3TypeAttributeAppender, AsmVisitorWrapper param3AsmVisitorWrapper, ClassFileVersion param3ClassFileVersion, AuxiliaryType.NamingStrategy param3NamingStrategy, AnnotationValueFilter.Factory param3Factory, AnnotationRetention param3AnnotationRetention, Implementation.Context.Factory param3Factory1, MethodGraph.Compiler param3Compiler, TypeValidation param3TypeValidation, VisibilityBridgeStrategy param3VisibilityBridgeStrategy, AsmClassReader.Factory param3Factory2, AsmClassWriter.Factory param3Factory3, LatentMatcher<? super MethodDescription> param3LatentMatcher, List<? extends DynamicType> param3List);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.annotationRetention.equals(((Adapter)param3Object).annotationRetention) ? false : (!this.typeValidation.equals(((Adapter)param3Object).typeValidation) ? false : (!this.instrumentedType.equals(((Adapter)param3Object).instrumentedType) ? false : (!this.fieldRegistry.equals(((Adapter)param3Object).fieldRegistry) ? false : (!this.methodRegistry.equals(((Adapter)param3Object).methodRegistry) ? false : (!this.recordComponentRegistry.equals(((Adapter)param3Object).recordComponentRegistry) ? false : (!this.typeAttributeAppender.equals(((Adapter)param3Object).typeAttributeAppender) ? false : (!this.asmVisitorWrapper.equals(((Adapter)param3Object).asmVisitorWrapper) ? false : (!this.classFileVersion.equals(((Adapter)param3Object).classFileVersion) ? false : (!this.auxiliaryTypeNamingStrategy.equals(((Adapter)param3Object).auxiliaryTypeNamingStrategy) ? false : (!this.annotationValueFilterFactory.equals(((Adapter)param3Object).annotationValueFilterFactory) ? false : (!this.implementationContextFactory.equals(((Adapter)param3Object).implementationContextFactory) ? false : (!this.methodGraphCompiler.equals(((Adapter)param3Object).methodGraphCompiler) ? false : (!this.visibilityBridgeStrategy.equals(((Adapter)param3Object).visibilityBridgeStrategy) ? false : (!this.classReaderFactory.equals(((Adapter)param3Object).classReaderFactory) ? false : (!this.classWriterFactory.equals(((Adapter)param3Object).classWriterFactory) ? false : (!this.ignoredMethods.equals(((Adapter)param3Object).ignoredMethods) ? false : (!!this.auxiliaryTypes.equals(((Adapter)param3Object).auxiliaryTypes)))))))))))))))))))));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return (((((((((((((((((getClass().hashCode() * 31 + this.instrumentedType.hashCode()) * 31 + this.fieldRegistry.hashCode()) * 31 + this.methodRegistry.hashCode()) * 31 + this.recordComponentRegistry.hashCode()) * 31 + this.typeAttributeAppender.hashCode()) * 31 + this.asmVisitorWrapper.hashCode()) * 31 + this.classFileVersion.hashCode()) * 31 + this.auxiliaryTypeNamingStrategy.hashCode()) * 31 + this.annotationValueFilterFactory.hashCode()) * 31 + this.annotationRetention.hashCode()) * 31 + this.implementationContextFactory.hashCode()) * 31 + this.methodGraphCompiler.hashCode()) * 31 + this.typeValidation.hashCode()) * 31 + this.visibilityBridgeStrategy.hashCode()) * 31 + this.classReaderFactory.hashCode()) * 31 + this.classWriterFactory.hashCode()) * 31 + this.ignoredMethods.hashCode()) * 31 + this.auxiliaryTypes.hashCode();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance(includeSyntheticFields = true)
/*      */         protected class InnerTypeDefinitionForTypeAdapter
/*      */           extends DynamicType.Builder.AbstractBase.Delegator<U>
/*      */           implements DynamicType.Builder.InnerTypeDefinition.ForType<U>
/*      */         {
/*      */           private final TypeDescription typeDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected InnerTypeDefinitionForTypeAdapter(TypeDescription typeDescription) {
/* 4833 */             this.typeDescription = typeDescription;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder<U> asAnonymousType() {
/* 4840 */             return DynamicType.Builder.AbstractBase.Adapter.this.materialize(DynamicType.Builder.AbstractBase.Adapter.this.instrumentedType
/* 4841 */                 .withDeclaringType(TypeDescription.UNDEFINED)
/* 4842 */                 .withEnclosingType(this.typeDescription)
/* 4843 */                 .withAnonymousClass(true), DynamicType.Builder.AbstractBase.Adapter.this.fieldRegistry, DynamicType.Builder.AbstractBase.Adapter.this.methodRegistry, DynamicType.Builder.AbstractBase.Adapter.this.recordComponentRegistry, DynamicType.Builder.AbstractBase.Adapter.this.typeAttributeAppender, DynamicType.Builder.AbstractBase.Adapter.this.asmVisitorWrapper, DynamicType.Builder.AbstractBase.Adapter.this.classFileVersion, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypeNamingStrategy, DynamicType.Builder.AbstractBase.Adapter.this.annotationValueFilterFactory, DynamicType.Builder.AbstractBase.Adapter.this.annotationRetention, DynamicType.Builder.AbstractBase.Adapter.this.implementationContextFactory, DynamicType.Builder.AbstractBase.Adapter.this.methodGraphCompiler, DynamicType.Builder.AbstractBase.Adapter.this.typeValidation, DynamicType.Builder.AbstractBase.Adapter.this.visibilityBridgeStrategy, DynamicType.Builder.AbstractBase.Adapter.this.classReaderFactory, DynamicType.Builder.AbstractBase.Adapter.this.classWriterFactory, DynamicType.Builder.AbstractBase.Adapter.this.ignoredMethods, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypes);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder<U> asMemberType() {
/* 4867 */             return DynamicType.Builder.AbstractBase.Adapter.this.materialize(DynamicType.Builder.AbstractBase.Adapter.this.instrumentedType
/* 4868 */                 .withDeclaringType(this.typeDescription)
/* 4869 */                 .withEnclosingType(this.typeDescription)
/* 4870 */                 .withAnonymousClass(false)
/* 4871 */                 .withLocalClass(false), DynamicType.Builder.AbstractBase.Adapter.this.fieldRegistry, DynamicType.Builder.AbstractBase.Adapter.this.methodRegistry, DynamicType.Builder.AbstractBase.Adapter.this.recordComponentRegistry, DynamicType.Builder.AbstractBase.Adapter.this.typeAttributeAppender, DynamicType.Builder.AbstractBase.Adapter.this.asmVisitorWrapper, DynamicType.Builder.AbstractBase.Adapter.this.classFileVersion, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypeNamingStrategy, DynamicType.Builder.AbstractBase.Adapter.this.annotationValueFilterFactory, DynamicType.Builder.AbstractBase.Adapter.this.annotationRetention, DynamicType.Builder.AbstractBase.Adapter.this.implementationContextFactory, DynamicType.Builder.AbstractBase.Adapter.this.methodGraphCompiler, DynamicType.Builder.AbstractBase.Adapter.this.typeValidation, DynamicType.Builder.AbstractBase.Adapter.this.visibilityBridgeStrategy, DynamicType.Builder.AbstractBase.Adapter.this.classReaderFactory, DynamicType.Builder.AbstractBase.Adapter.this.classWriterFactory, DynamicType.Builder.AbstractBase.Adapter.this.ignoredMethods, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypes);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected DynamicType.Builder<U> materialize() {
/* 4893 */             return DynamicType.Builder.AbstractBase.Adapter.this.materialize(DynamicType.Builder.AbstractBase.Adapter.this.instrumentedType
/* 4894 */                 .withDeclaringType(TypeDescription.UNDEFINED)
/* 4895 */                 .withEnclosingType(this.typeDescription)
/* 4896 */                 .withLocalClass(true), DynamicType.Builder.AbstractBase.Adapter.this.fieldRegistry, DynamicType.Builder.AbstractBase.Adapter.this.methodRegistry, DynamicType.Builder.AbstractBase.Adapter.this.recordComponentRegistry, DynamicType.Builder.AbstractBase.Adapter.this.typeAttributeAppender, DynamicType.Builder.AbstractBase.Adapter.this.asmVisitorWrapper, DynamicType.Builder.AbstractBase.Adapter.this.classFileVersion, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypeNamingStrategy, DynamicType.Builder.AbstractBase.Adapter.this.annotationValueFilterFactory, DynamicType.Builder.AbstractBase.Adapter.this.annotationRetention, DynamicType.Builder.AbstractBase.Adapter.this.implementationContextFactory, DynamicType.Builder.AbstractBase.Adapter.this.methodGraphCompiler, DynamicType.Builder.AbstractBase.Adapter.this.typeValidation, DynamicType.Builder.AbstractBase.Adapter.this.visibilityBridgeStrategy, DynamicType.Builder.AbstractBase.Adapter.this.classReaderFactory, DynamicType.Builder.AbstractBase.Adapter.this.classWriterFactory, DynamicType.Builder.AbstractBase.Adapter.this.ignoredMethods, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypes);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.typeDescription.equals(((InnerTypeDefinitionForTypeAdapter)param4Object).typeDescription) ? false : (!!DynamicType.Builder.AbstractBase.Adapter.this.equals(DynamicType.Builder.AbstractBase.Adapter.this)))));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return (getClass().hashCode() * 31 + this.typeDescription.hashCode()) * 31 + DynamicType.Builder.AbstractBase.Adapter.this.hashCode();
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance(includeSyntheticFields = true)
/*      */         protected class InnerTypeDefinitionForMethodAdapter
/*      */           extends DynamicType.Builder.AbstractBase.Delegator<U>
/*      */           implements DynamicType.Builder.InnerTypeDefinition<U>
/*      */         {
/*      */           private final MethodDescription.InDefinedShape methodDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected InnerTypeDefinitionForMethodAdapter(MethodDescription.InDefinedShape methodDescription) {
/* 4934 */             this.methodDescription = methodDescription;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder<U> asAnonymousType() {
/* 4941 */             return DynamicType.Builder.AbstractBase.Adapter.this.materialize(DynamicType.Builder.AbstractBase.Adapter.this.instrumentedType
/* 4942 */                 .withDeclaringType(TypeDescription.UNDEFINED)
/* 4943 */                 .withEnclosingMethod(this.methodDescription)
/* 4944 */                 .withAnonymousClass(true), DynamicType.Builder.AbstractBase.Adapter.this.fieldRegistry, DynamicType.Builder.AbstractBase.Adapter.this.methodRegistry, DynamicType.Builder.AbstractBase.Adapter.this.recordComponentRegistry, DynamicType.Builder.AbstractBase.Adapter.this.typeAttributeAppender, DynamicType.Builder.AbstractBase.Adapter.this.asmVisitorWrapper, DynamicType.Builder.AbstractBase.Adapter.this.classFileVersion, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypeNamingStrategy, DynamicType.Builder.AbstractBase.Adapter.this.annotationValueFilterFactory, DynamicType.Builder.AbstractBase.Adapter.this.annotationRetention, DynamicType.Builder.AbstractBase.Adapter.this.implementationContextFactory, DynamicType.Builder.AbstractBase.Adapter.this.methodGraphCompiler, DynamicType.Builder.AbstractBase.Adapter.this.typeValidation, DynamicType.Builder.AbstractBase.Adapter.this.visibilityBridgeStrategy, DynamicType.Builder.AbstractBase.Adapter.this.classReaderFactory, DynamicType.Builder.AbstractBase.Adapter.this.classWriterFactory, DynamicType.Builder.AbstractBase.Adapter.this.ignoredMethods, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypes);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected DynamicType.Builder<U> materialize() {
/* 4966 */             return DynamicType.Builder.AbstractBase.Adapter.this.materialize(DynamicType.Builder.AbstractBase.Adapter.this.instrumentedType
/* 4967 */                 .withDeclaringType(TypeDescription.UNDEFINED)
/* 4968 */                 .withEnclosingMethod(this.methodDescription)
/* 4969 */                 .withLocalClass(true), DynamicType.Builder.AbstractBase.Adapter.this.fieldRegistry, DynamicType.Builder.AbstractBase.Adapter.this.methodRegistry, DynamicType.Builder.AbstractBase.Adapter.this.recordComponentRegistry, DynamicType.Builder.AbstractBase.Adapter.this.typeAttributeAppender, DynamicType.Builder.AbstractBase.Adapter.this.asmVisitorWrapper, DynamicType.Builder.AbstractBase.Adapter.this.classFileVersion, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypeNamingStrategy, DynamicType.Builder.AbstractBase.Adapter.this.annotationValueFilterFactory, DynamicType.Builder.AbstractBase.Adapter.this.annotationRetention, DynamicType.Builder.AbstractBase.Adapter.this.implementationContextFactory, DynamicType.Builder.AbstractBase.Adapter.this.methodGraphCompiler, DynamicType.Builder.AbstractBase.Adapter.this.typeValidation, DynamicType.Builder.AbstractBase.Adapter.this.visibilityBridgeStrategy, DynamicType.Builder.AbstractBase.Adapter.this.classReaderFactory, DynamicType.Builder.AbstractBase.Adapter.this.classWriterFactory, DynamicType.Builder.AbstractBase.Adapter.this.ignoredMethods, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypes);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.methodDescription.equals(((InnerTypeDefinitionForMethodAdapter)param4Object).methodDescription) ? false : (!!DynamicType.Builder.AbstractBase.Adapter.this.equals(DynamicType.Builder.AbstractBase.Adapter.this)))));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return (getClass().hashCode() * 31 + this.methodDescription.hashCode()) * 31 + DynamicType.Builder.AbstractBase.Adapter.this.hashCode();
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance(includeSyntheticFields = true)
/*      */         protected class TypeVariableDefinitionAdapter
/*      */           extends DynamicType.Builder.TypeVariableDefinition.AbstractBase<U>
/*      */         {
/*      */           private final TypeVariableToken token;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected TypeVariableDefinitionAdapter(TypeVariableToken token) {
/* 5007 */             this.token = token;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.TypeVariableDefinition<U> annotateTypeVariable(Collection<? extends AnnotationDescription> annotations) {
/* 5014 */             return new TypeVariableDefinitionAdapter(new TypeVariableToken(this.token.getSymbol(), (List)this.token
/* 5015 */                   .getBounds(), 
/* 5016 */                   CompoundList.of((List)this.token.getAnnotations(), new ArrayList<AnnotationDescription>(annotations))));
/*      */           }
/*      */ 
/*      */           
/*      */           protected DynamicType.Builder<U> materialize() {
/* 5021 */             return DynamicType.Builder.AbstractBase.Adapter.this.materialize(DynamicType.Builder.AbstractBase.Adapter.this.instrumentedType.withTypeVariable(this.token), DynamicType.Builder.AbstractBase.Adapter.this.fieldRegistry, DynamicType.Builder.AbstractBase.Adapter.this.methodRegistry, DynamicType.Builder.AbstractBase.Adapter.this.recordComponentRegistry, DynamicType.Builder.AbstractBase.Adapter.this.typeAttributeAppender, DynamicType.Builder.AbstractBase.Adapter.this.asmVisitorWrapper, DynamicType.Builder.AbstractBase.Adapter.this.classFileVersion, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypeNamingStrategy, DynamicType.Builder.AbstractBase.Adapter.this.annotationValueFilterFactory, DynamicType.Builder.AbstractBase.Adapter.this.annotationRetention, DynamicType.Builder.AbstractBase.Adapter.this.implementationContextFactory, DynamicType.Builder.AbstractBase.Adapter.this.methodGraphCompiler, DynamicType.Builder.AbstractBase.Adapter.this.typeValidation, DynamicType.Builder.AbstractBase.Adapter.this.visibilityBridgeStrategy, DynamicType.Builder.AbstractBase.Adapter.this.classReaderFactory, DynamicType.Builder.AbstractBase.Adapter.this.classWriterFactory, DynamicType.Builder.AbstractBase.Adapter.this.ignoredMethods, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypes);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.token.equals(((TypeVariableDefinitionAdapter)param4Object).token) ? false : (!!DynamicType.Builder.AbstractBase.Adapter.this.equals(DynamicType.Builder.AbstractBase.Adapter.this)))));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return (getClass().hashCode() * 31 + this.token.hashCode()) * 31 + DynamicType.Builder.AbstractBase.Adapter.this.hashCode();
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance(includeSyntheticFields = true)
/*      */         protected class FieldDefinitionAdapter
/*      */           extends DynamicType.Builder.FieldDefinition.Optional.Valuable.AbstractBase.Adapter<U>
/*      */         {
/*      */           private final FieldDescription.Token token;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected FieldDefinitionAdapter(FieldDescription.Token token) {
/* 5059 */             this((FieldAttributeAppender.Factory)FieldAttributeAppender.ForInstrumentedField.INSTANCE, 
/* 5060 */                 Transformer.NoOp.make(), FieldDescription.NO_DEFAULT_VALUE, token);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected FieldDefinitionAdapter(FieldAttributeAppender.Factory fieldAttributeAppenderFactory, @MaybeNull Transformer<FieldDescription> transformer, Object defaultValue, FieldDescription.Token token) {
/* 5077 */             super(fieldAttributeAppenderFactory, transformer, defaultValue);
/* 5078 */             this.token = token;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.FieldDefinition.Optional<U> annotateField(Collection<? extends AnnotationDescription> annotations) {
/* 5085 */             return new FieldDefinitionAdapter(this.fieldAttributeAppenderFactory, this.transformer, this.defaultValue, new FieldDescription.Token(this.token.getName(), this.token
/* 5086 */                   .getModifiers(), this.token
/* 5087 */                   .getType(), 
/* 5088 */                   CompoundList.of((List)this.token.getAnnotations(), new ArrayList<AnnotationDescription>(annotations))));
/*      */           }
/*      */ 
/*      */           
/*      */           protected DynamicType.Builder<U> materialize() {
/* 5093 */             return DynamicType.Builder.AbstractBase.Adapter.this.materialize(DynamicType.Builder.AbstractBase.Adapter.this.instrumentedType.withField(this.token), DynamicType.Builder.AbstractBase.Adapter.this.fieldRegistry
/* 5094 */                 .prepend((LatentMatcher)new LatentMatcher.ForFieldToken(this.token), this.fieldAttributeAppenderFactory, this.defaultValue, this.transformer), DynamicType.Builder.AbstractBase.Adapter.this.methodRegistry, DynamicType.Builder.AbstractBase.Adapter.this.recordComponentRegistry, DynamicType.Builder.AbstractBase.Adapter.this.typeAttributeAppender, DynamicType.Builder.AbstractBase.Adapter.this.asmVisitorWrapper, DynamicType.Builder.AbstractBase.Adapter.this.classFileVersion, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypeNamingStrategy, DynamicType.Builder.AbstractBase.Adapter.this.annotationValueFilterFactory, DynamicType.Builder.AbstractBase.Adapter.this.annotationRetention, DynamicType.Builder.AbstractBase.Adapter.this.implementationContextFactory, DynamicType.Builder.AbstractBase.Adapter.this.methodGraphCompiler, DynamicType.Builder.AbstractBase.Adapter.this.typeValidation, DynamicType.Builder.AbstractBase.Adapter.this.visibilityBridgeStrategy, DynamicType.Builder.AbstractBase.Adapter.this.classReaderFactory, DynamicType.Builder.AbstractBase.Adapter.this.classWriterFactory, DynamicType.Builder.AbstractBase.Adapter.this.ignoredMethods, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypes);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected DynamicType.Builder.FieldDefinition.Optional<U> materialize(FieldAttributeAppender.Factory fieldAttributeAppenderFactory, Transformer<FieldDescription> transformer, @MaybeNull Object defaultValue) {
/* 5117 */             return new FieldDefinitionAdapter(fieldAttributeAppenderFactory, transformer, defaultValue, this.token);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.token.equals(((FieldDefinitionAdapter)param4Object).token) ? false : (!!DynamicType.Builder.AbstractBase.Adapter.this.equals(DynamicType.Builder.AbstractBase.Adapter.this))))));
/*      */           }
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return (super.hashCode() * 31 + this.token.hashCode()) * 31 + DynamicType.Builder.AbstractBase.Adapter.this.hashCode();
/*      */           }
/*      */         }
/*      */         
/*      */         @Enhance(includeSyntheticFields = true)
/*      */         protected class FieldMatchAdapter
/*      */           extends DynamicType.Builder.FieldDefinition.Optional.Valuable.AbstractBase.Adapter<U>
/*      */         {
/*      */           private final LatentMatcher<? super FieldDescription> matcher;
/*      */           
/*      */           protected FieldMatchAdapter(LatentMatcher<? super FieldDescription> matcher) {
/* 5138 */             this((FieldAttributeAppender.Factory)FieldAttributeAppender.NoOp.INSTANCE, 
/* 5139 */                 Transformer.NoOp.make(), FieldDescription.NO_DEFAULT_VALUE, matcher);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected FieldMatchAdapter(FieldAttributeAppender.Factory fieldAttributeAppenderFactory, @MaybeNull Transformer<FieldDescription> transformer, Object defaultValue, LatentMatcher<? super FieldDescription> matcher) {
/* 5156 */             super(fieldAttributeAppenderFactory, transformer, defaultValue);
/* 5157 */             this.matcher = matcher;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.FieldDefinition.Optional<U> annotateField(Collection<? extends AnnotationDescription> annotations) {
/* 5164 */             return attribute((FieldAttributeAppender.Factory)new FieldAttributeAppender.Explicit(new ArrayList<AnnotationDescription>(annotations)));
/*      */           }
/*      */ 
/*      */           
/*      */           protected DynamicType.Builder<U> materialize() {
/* 5169 */             return DynamicType.Builder.AbstractBase.Adapter.this.materialize(DynamicType.Builder.AbstractBase.Adapter.this.instrumentedType, DynamicType.Builder.AbstractBase.Adapter.this.fieldRegistry
/* 5170 */                 .prepend(this.matcher, this.fieldAttributeAppenderFactory, this.defaultValue, this.transformer), DynamicType.Builder.AbstractBase.Adapter.this.methodRegistry, DynamicType.Builder.AbstractBase.Adapter.this.recordComponentRegistry, DynamicType.Builder.AbstractBase.Adapter.this.typeAttributeAppender, DynamicType.Builder.AbstractBase.Adapter.this.asmVisitorWrapper, DynamicType.Builder.AbstractBase.Adapter.this.classFileVersion, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypeNamingStrategy, DynamicType.Builder.AbstractBase.Adapter.this.annotationValueFilterFactory, DynamicType.Builder.AbstractBase.Adapter.this.annotationRetention, DynamicType.Builder.AbstractBase.Adapter.this.implementationContextFactory, DynamicType.Builder.AbstractBase.Adapter.this.methodGraphCompiler, DynamicType.Builder.AbstractBase.Adapter.this.typeValidation, DynamicType.Builder.AbstractBase.Adapter.this.visibilityBridgeStrategy, DynamicType.Builder.AbstractBase.Adapter.this.classReaderFactory, DynamicType.Builder.AbstractBase.Adapter.this.classWriterFactory, DynamicType.Builder.AbstractBase.Adapter.this.ignoredMethods, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypes);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected DynamicType.Builder.FieldDefinition.Optional<U> materialize(FieldAttributeAppender.Factory fieldAttributeAppenderFactory, Transformer<FieldDescription> transformer, @MaybeNull Object defaultValue) {
/* 5193 */             return new FieldMatchAdapter(fieldAttributeAppenderFactory, transformer, defaultValue, this.matcher);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.matcher.equals(((FieldMatchAdapter)param4Object).matcher) ? false : (!!DynamicType.Builder.AbstractBase.Adapter.this.equals(DynamicType.Builder.AbstractBase.Adapter.this))))));
/*      */           }
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return (super.hashCode() * 31 + this.matcher.hashCode()) * 31 + DynamicType.Builder.AbstractBase.Adapter.this.hashCode();
/*      */           }
/*      */         }
/*      */         
/*      */         @Enhance(includeSyntheticFields = true)
/*      */         protected class MethodDefinitionAdapter
/*      */           extends DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial.AbstractBase<U>
/*      */         {
/*      */           private final MethodDescription.Token token;
/*      */           
/*      */           protected MethodDefinitionAdapter(MethodDescription.Token token) {
/* 5214 */             this.token = token;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<U> withParameter(TypeDefinition type, String name, int modifiers) {
/* 5221 */             return new ParameterAnnotationAdapter(new ParameterDescription.Token(type.asGenericType(), name, Integer.valueOf(modifiers)));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.Annotatable<U> withParameter(TypeDefinition type) {
/* 5228 */             return new SimpleParameterAnnotationAdapter(new ParameterDescription.Token(type.asGenericType()));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.MethodDefinition.ExceptionDefinition<U> throwing(Collection<? extends TypeDefinition> types) {
/* 5235 */             return new MethodDefinitionAdapter(new MethodDescription.Token(this.token.getName(), this.token
/* 5236 */                   .getModifiers(), (List)this.token
/* 5237 */                   .getTypeVariableTokens(), this.token
/* 5238 */                   .getReturnType(), (List)this.token
/* 5239 */                   .getParameterTokens(), 
/* 5240 */                   CompoundList.of((List)this.token.getExceptionTypes(), (List)new TypeList.Generic.Explicit(new ArrayList<TypeDefinition>(types))), (List)this.token
/* 5241 */                   .getAnnotations(), this.token
/* 5242 */                   .getDefaultValue(), this.token
/* 5243 */                   .getReceiverType()));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.MethodDefinition.TypeVariableDefinition.Annotatable<U> typeVariable(String symbol, Collection<? extends TypeDefinition> bounds) {
/* 5250 */             return new TypeVariableAnnotationAdapter(new TypeVariableToken(symbol, (List)new TypeList.Generic.Explicit(new ArrayList<TypeDefinition>(bounds))));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> intercept(Implementation implementation) {
/* 5257 */             return materialize((MethodRegistry.Handler)new MethodRegistry.Handler.ForImplementation(implementation));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> withoutCode() {
/* 5264 */             return (new MethodDefinitionAdapter(new MethodDescription.Token(this.token.getName(), 
/* 5265 */                   ((this.token.getModifiers() & 0x100) == 0) ? 
/* 5266 */                   ModifierContributor.Resolver.of(new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)MethodManifestation.ABSTRACT }, ).resolve(this.token.getModifiers()) : this.token
/* 5267 */                   .getModifiers(), (List)this.token
/* 5268 */                   .getTypeVariableTokens(), this.token
/* 5269 */                   .getReturnType(), (List)this.token
/* 5270 */                   .getParameterTokens(), (List)this.token
/* 5271 */                   .getExceptionTypes(), (List)this.token
/* 5272 */                   .getAnnotations(), this.token
/* 5273 */                   .getDefaultValue(), this.token
/* 5274 */                   .getReceiverType()))).materialize((MethodRegistry.Handler)MethodRegistry.Handler.ForAbstractMethod.INSTANCE);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> defaultValue(AnnotationValue<?, ?> annotationValue) {
/* 5281 */             return (new MethodDefinitionAdapter(new MethodDescription.Token(this.token.getName(), 
/* 5282 */                   ModifierContributor.Resolver.of(new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)MethodManifestation.ABSTRACT }, ).resolve(this.token.getModifiers()), (List)this.token
/* 5283 */                   .getTypeVariableTokens(), this.token
/* 5284 */                   .getReturnType(), (List)this.token
/* 5285 */                   .getParameterTokens(), (List)this.token
/* 5286 */                   .getExceptionTypes(), (List)this.token
/* 5287 */                   .getAnnotations(), annotationValue, this.token
/*      */                   
/* 5289 */                   .getReceiverType()))).materialize((MethodRegistry.Handler)new MethodRegistry.Handler.ForAnnotationValue(annotationValue));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> materialize(MethodRegistry.Handler handler) {
/* 5299 */             return new AnnotationAdapter(handler);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.token.equals(((MethodDefinitionAdapter)param4Object).token) ? false : (!!DynamicType.Builder.AbstractBase.Adapter.this.equals(DynamicType.Builder.AbstractBase.Adapter.this)))));
/*      */           }
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return (getClass().hashCode() * 31 + this.token.hashCode()) * 31 + DynamicType.Builder.AbstractBase.Adapter.this.hashCode();
/*      */           }
/*      */           
/*      */           @Enhance(includeSyntheticFields = true)
/*      */           protected class TypeVariableAnnotationAdapter
/*      */             extends DynamicType.Builder.MethodDefinition.TypeVariableDefinition.Annotatable.AbstractBase.Adapter<U>
/*      */           {
/*      */             private final TypeVariableToken token;
/*      */             
/*      */             protected TypeVariableAnnotationAdapter(TypeVariableToken token) {
/* 5319 */               this.token = token;
/*      */             }
/*      */ 
/*      */             
/*      */             protected DynamicType.Builder.MethodDefinition.ParameterDefinition<U> materialize() {
/* 5324 */               return new DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter(new MethodDescription.Token(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getName(), 
/* 5325 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getModifiers(), 
/* 5326 */                     CompoundList.of((List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getTypeVariableTokens(), this.token), 
/* 5327 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getReturnType(), 
/* 5328 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getParameterTokens(), 
/* 5329 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getExceptionTypes(), 
/* 5330 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getAnnotations(), 
/* 5331 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getDefaultValue(), 
/* 5332 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getReceiverType()));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public DynamicType.Builder.MethodDefinition.TypeVariableDefinition.Annotatable<U> annotateTypeVariable(Collection<? extends AnnotationDescription> annotations) {
/* 5339 */               return new TypeVariableAnnotationAdapter(new TypeVariableToken(this.token.getSymbol(), (List)this.token
/* 5340 */                     .getBounds(), 
/* 5341 */                     CompoundList.of((List)this.token.getAnnotations(), new ArrayList<AnnotationDescription>(annotations))));
/*      */             }
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!this.token.equals(((TypeVariableAnnotationAdapter)param5Object).token) ? false : (!!DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this.equals(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this)))));
/*      */             }
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               return (getClass().hashCode() * 31 + this.token.hashCode()) * 31 + DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this.hashCode();
/*      */             }
/*      */           }
/*      */           
/*      */           @Enhance(includeSyntheticFields = true)
/*      */           protected class ParameterAnnotationAdapter
/*      */             extends DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable.AbstractBase.Adapter<U>
/*      */           {
/*      */             private final ParameterDescription.Token token;
/*      */             
/*      */             protected ParameterAnnotationAdapter(ParameterDescription.Token token) {
/* 5362 */               this.token = token;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public DynamicType.Builder.MethodDefinition.ParameterDefinition.Annotatable<U> annotateParameter(Collection<? extends AnnotationDescription> annotations) {
/* 5369 */               return new ParameterAnnotationAdapter(new ParameterDescription.Token(this.token.getType(), 
/* 5370 */                     CompoundList.of((List)this.token.getAnnotations(), new ArrayList<AnnotationDescription>(annotations)), this.token
/* 5371 */                     .getName(), this.token
/* 5372 */                     .getModifiers()));
/*      */             }
/*      */ 
/*      */             
/*      */             protected DynamicType.Builder.MethodDefinition.ParameterDefinition<U> materialize() {
/* 5377 */               return new DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter(new MethodDescription.Token(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getName(), 
/* 5378 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getModifiers(), 
/* 5379 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getTypeVariableTokens(), 
/* 5380 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getReturnType(), 
/* 5381 */                     CompoundList.of((List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getParameterTokens(), this.token), 
/* 5382 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getExceptionTypes(), 
/* 5383 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getAnnotations(), 
/* 5384 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getDefaultValue(), 
/* 5385 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getReceiverType()));
/*      */             }
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!this.token.equals(((ParameterAnnotationAdapter)param5Object).token) ? false : (!!DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this.equals(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this)))));
/*      */             }
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               return (getClass().hashCode() * 31 + this.token.hashCode()) * 31 + DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this.hashCode();
/*      */             }
/*      */           }
/*      */           
/*      */           @Enhance(includeSyntheticFields = true)
/*      */           protected class SimpleParameterAnnotationAdapter
/*      */             extends DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.Annotatable.AbstractBase.Adapter<U>
/*      */           {
/*      */             private final ParameterDescription.Token token;
/*      */             
/*      */             protected SimpleParameterAnnotationAdapter(ParameterDescription.Token token) {
/* 5406 */               this.token = token;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple.Annotatable<U> annotateParameter(Collection<? extends AnnotationDescription> annotations) {
/* 5413 */               return new SimpleParameterAnnotationAdapter(new ParameterDescription.Token(this.token.getType(), 
/* 5414 */                     CompoundList.of((List)this.token.getAnnotations(), new ArrayList<AnnotationDescription>(annotations)), this.token
/* 5415 */                     .getName(), this.token
/* 5416 */                     .getModifiers()));
/*      */             }
/*      */ 
/*      */             
/*      */             protected DynamicType.Builder.MethodDefinition.ParameterDefinition.Simple<U> materialize() {
/* 5421 */               return new DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter(new MethodDescription.Token(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getName(), 
/* 5422 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getModifiers(), 
/* 5423 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getTypeVariableTokens(), 
/* 5424 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getReturnType(), 
/* 5425 */                     CompoundList.of((List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getParameterTokens(), this.token), 
/* 5426 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getExceptionTypes(), 
/* 5427 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getAnnotations(), 
/* 5428 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getDefaultValue(), 
/* 5429 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getReceiverType()));
/*      */             }
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!this.token.equals(((SimpleParameterAnnotationAdapter)param5Object).token) ? false : (!!DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this.equals(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this)))));
/*      */             }
/*      */             
/*      */             public int hashCode() {
/*      */               return (getClass().hashCode() * 31 + this.token.hashCode()) * 31 + DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this.hashCode();
/*      */             }
/*      */           }
/*      */           
/*      */           @Enhance(includeSyntheticFields = true)
/*      */           protected class AnnotationAdapter
/*      */             extends DynamicType.Builder.MethodDefinition.AbstractBase.Adapter<U> {
/*      */             protected AnnotationAdapter(MethodRegistry.Handler handler) {
/* 5445 */               this(handler, (MethodAttributeAppender.Factory)MethodAttributeAppender.ForInstrumentedMethod.INCLUDING_RECEIVER, 
/*      */                   
/* 5447 */                   Transformer.NoOp.make());
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected AnnotationAdapter(MethodRegistry.Handler handler, MethodAttributeAppender.Factory methodAttributeAppenderFactory, Transformer<MethodDescription> transformer) {
/* 5460 */               super(handler, methodAttributeAppenderFactory, transformer);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public DynamicType.Builder.MethodDefinition<U> receiverType(TypeDescription.Generic receiverType) {
/* 5467 */               (new DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter(new MethodDescription.Token(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getName(), 
/* 5468 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getModifiers(), 
/* 5469 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getTypeVariableTokens(), 
/* 5470 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getReturnType(), 
/* 5471 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getParameterTokens(), 
/* 5472 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getExceptionTypes(), 
/* 5473 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getAnnotations(), 
/* 5474 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getDefaultValue(), receiverType))).getClass(); return new AnnotationAdapter(this.handler, this.methodAttributeAppenderFactory, this.transformer);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public DynamicType.Builder.MethodDefinition<U> annotateMethod(Collection<? extends AnnotationDescription> annotations) {
/* 5482 */               (new DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter(new MethodDescription.Token(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getName(), 
/* 5483 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getModifiers(), 
/* 5484 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getTypeVariableTokens(), 
/* 5485 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getReturnType(), 
/* 5486 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getParameterTokens(), 
/* 5487 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getExceptionTypes(), 
/* 5488 */                     CompoundList.of((List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getAnnotations(), new ArrayList<AnnotationDescription>(annotations)), 
/* 5489 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getDefaultValue(), 
/* 5490 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getReceiverType()))).getClass(); return new AnnotationAdapter(this.handler, this.methodAttributeAppenderFactory, this.transformer);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public DynamicType.Builder.MethodDefinition<U> annotateParameter(int index, Collection<? extends AnnotationDescription> annotations) {
/* 5497 */               List<ParameterDescription.Token> parameterTokens = new ArrayList<ParameterDescription.Token>((Collection<? extends ParameterDescription.Token>)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getParameterTokens());
/* 5498 */               parameterTokens.set(index, new ParameterDescription.Token(((ParameterDescription.Token)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getParameterTokens().get(index)).getType(), 
/* 5499 */                     CompoundList.of((List)((ParameterDescription.Token)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getParameterTokens().get(index)).getAnnotations(), new ArrayList<AnnotationDescription>(annotations)), (
/* 5500 */                     (ParameterDescription.Token)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getParameterTokens().get(index)).getName(), (
/* 5501 */                     (ParameterDescription.Token)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getParameterTokens().get(index)).getModifiers()));
/* 5502 */               (new DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter(new MethodDescription.Token(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getName(), 
/* 5503 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getModifiers(), 
/* 5504 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getTypeVariableTokens(), 
/* 5505 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getReturnType(), parameterTokens, 
/*      */                     
/* 5507 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getExceptionTypes(), 
/* 5508 */                     (List)DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getAnnotations(), 
/* 5509 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getDefaultValue(), 
/* 5510 */                     DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this).getReceiverType()))).getClass(); return new AnnotationAdapter(this.handler, this.methodAttributeAppenderFactory, this.transformer);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected DynamicType.Builder.MethodDefinition<U> materialize(MethodRegistry.Handler handler, MethodAttributeAppender.Factory methodAttributeAppenderFactory, Transformer<MethodDescription> transformer) {
/* 5517 */               return new AnnotationAdapter(handler, methodAttributeAppenderFactory, transformer);
/*      */             }
/*      */ 
/*      */             
/*      */             protected DynamicType.Builder<U> materialize() {
/* 5522 */               return DynamicType.Builder.AbstractBase.Adapter.this.materialize(DynamicType.Builder.AbstractBase.Adapter.this.instrumentedType.withMethod(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this)), DynamicType.Builder.AbstractBase.Adapter.this.fieldRegistry, DynamicType.Builder.AbstractBase.Adapter.this.methodRegistry
/*      */                   
/* 5524 */                   .prepend((LatentMatcher)new LatentMatcher.ForMethodToken(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.access$000(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this)), this.handler, this.methodAttributeAppenderFactory, this.transformer), DynamicType.Builder.AbstractBase.Adapter.this.recordComponentRegistry, DynamicType.Builder.AbstractBase.Adapter.this.typeAttributeAppender, DynamicType.Builder.AbstractBase.Adapter.this.asmVisitorWrapper, DynamicType.Builder.AbstractBase.Adapter.this.classFileVersion, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypeNamingStrategy, DynamicType.Builder.AbstractBase.Adapter.this.annotationValueFilterFactory, DynamicType.Builder.AbstractBase.Adapter.this.annotationRetention, DynamicType.Builder.AbstractBase.Adapter.this.implementationContextFactory, DynamicType.Builder.AbstractBase.Adapter.this.methodGraphCompiler, DynamicType.Builder.AbstractBase.Adapter.this.typeValidation, DynamicType.Builder.AbstractBase.Adapter.this.visibilityBridgeStrategy, DynamicType.Builder.AbstractBase.Adapter.this.classReaderFactory, DynamicType.Builder.AbstractBase.Adapter.this.classWriterFactory, DynamicType.Builder.AbstractBase.Adapter.this.ignoredMethods, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypes);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return !super.equals(param5Object) ? false : ((this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this.equals(DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this)))));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               return super.hashCode() * 31 + DynamicType.Builder.AbstractBase.Adapter.MethodDefinitionAdapter.this.hashCode();
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance(includeSyntheticFields = true)
/*      */         protected class MethodMatchAdapter
/*      */           extends DynamicType.Builder.MethodDefinition.ImplementationDefinition.AbstractBase<U>
/*      */         {
/*      */           private final LatentMatcher<? super MethodDescription> matcher;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected MethodMatchAdapter(LatentMatcher<? super MethodDescription> matcher) {
/* 5564 */             this.matcher = matcher;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> intercept(Implementation implementation) {
/* 5571 */             return materialize((MethodRegistry.Handler)new MethodRegistry.Handler.ForImplementation(implementation));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> withoutCode() {
/* 5578 */             return materialize((MethodRegistry.Handler)MethodRegistry.Handler.ForAbstractMethod.INSTANCE);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> defaultValue(AnnotationValue<?, ?> annotationValue) {
/* 5585 */             return materialize((MethodRegistry.Handler)new MethodRegistry.Handler.ForAnnotationValue(annotationValue));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> materialize(MethodRegistry.Handler handler) {
/* 5595 */             return new AnnotationAdapter(handler);
/*      */           }
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.matcher.equals(((MethodMatchAdapter)param4Object).matcher) ? false : (!!DynamicType.Builder.AbstractBase.Adapter.this.equals(DynamicType.Builder.AbstractBase.Adapter.this)))));
/*      */           }
/*      */           
/*      */           public int hashCode() {
/*      */             return (getClass().hashCode() * 31 + this.matcher.hashCode()) * 31 + DynamicType.Builder.AbstractBase.Adapter.this.hashCode();
/*      */           }
/*      */           
/*      */           @Enhance(includeSyntheticFields = true)
/*      */           protected class AnnotationAdapter
/*      */             extends DynamicType.Builder.MethodDefinition.AbstractBase.Adapter<U> {
/*      */             protected AnnotationAdapter(MethodRegistry.Handler handler) {
/* 5610 */               this(handler, (MethodAttributeAppender.Factory)MethodAttributeAppender.NoOp.INSTANCE, Transformer.NoOp.make());
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected AnnotationAdapter(MethodRegistry.Handler handler, MethodAttributeAppender.Factory methodAttributeAppenderFactory, Transformer<MethodDescription> transformer) {
/* 5623 */               super(handler, methodAttributeAppenderFactory, transformer);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public DynamicType.Builder.MethodDefinition<U> receiverType(TypeDescription.Generic receiverType) {
/* 5630 */               return new AnnotationAdapter(this.handler, (MethodAttributeAppender.Factory)new MethodAttributeAppender.Factory.Compound(new MethodAttributeAppender.Factory[] { this.methodAttributeAppenderFactory, (MethodAttributeAppender.Factory)new MethodAttributeAppender.ForReceiverType(receiverType) }, ), this.transformer);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public DynamicType.Builder.MethodDefinition<U> annotateMethod(Collection<? extends AnnotationDescription> annotations) {
/* 5639 */               return new AnnotationAdapter(this.handler, (MethodAttributeAppender.Factory)new MethodAttributeAppender.Factory.Compound(new MethodAttributeAppender.Factory[] { this.methodAttributeAppenderFactory, (MethodAttributeAppender.Factory)new MethodAttributeAppender.Explicit(new ArrayList<AnnotationDescription>(annotations)) }, ), this.transformer);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public DynamicType.Builder.MethodDefinition<U> annotateParameter(int index, Collection<? extends AnnotationDescription> annotations) {
/* 5648 */               return new AnnotationAdapter(this.handler, (MethodAttributeAppender.Factory)new MethodAttributeAppender.Factory.Compound(new MethodAttributeAppender.Factory[] { this.methodAttributeAppenderFactory, (MethodAttributeAppender.Factory)new MethodAttributeAppender.Explicit(index, new ArrayList<AnnotationDescription>(annotations)) }), this.transformer);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected DynamicType.Builder.MethodDefinition<U> materialize(MethodRegistry.Handler handler, MethodAttributeAppender.Factory methodAttributeAppenderFactory, Transformer<MethodDescription> transformer) {
/* 5657 */               return new AnnotationAdapter(handler, methodAttributeAppenderFactory, transformer);
/*      */             }
/*      */ 
/*      */             
/*      */             protected DynamicType.Builder<U> materialize() {
/* 5662 */               return DynamicType.Builder.AbstractBase.Adapter.this.materialize(DynamicType.Builder.AbstractBase.Adapter.this.instrumentedType, DynamicType.Builder.AbstractBase.Adapter.this.fieldRegistry, DynamicType.Builder.AbstractBase.Adapter.this.methodRegistry
/*      */                   
/* 5664 */                   .prepend(DynamicType.Builder.AbstractBase.Adapter.MethodMatchAdapter.access$100(DynamicType.Builder.AbstractBase.Adapter.MethodMatchAdapter.this), this.handler, this.methodAttributeAppenderFactory, this.transformer), DynamicType.Builder.AbstractBase.Adapter.this.recordComponentRegistry, DynamicType.Builder.AbstractBase.Adapter.this.typeAttributeAppender, DynamicType.Builder.AbstractBase.Adapter.this.asmVisitorWrapper, DynamicType.Builder.AbstractBase.Adapter.this.classFileVersion, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypeNamingStrategy, DynamicType.Builder.AbstractBase.Adapter.this.annotationValueFilterFactory, DynamicType.Builder.AbstractBase.Adapter.this.annotationRetention, DynamicType.Builder.AbstractBase.Adapter.this.implementationContextFactory, DynamicType.Builder.AbstractBase.Adapter.this.methodGraphCompiler, DynamicType.Builder.AbstractBase.Adapter.this.typeValidation, DynamicType.Builder.AbstractBase.Adapter.this.visibilityBridgeStrategy, DynamicType.Builder.AbstractBase.Adapter.this.classReaderFactory, DynamicType.Builder.AbstractBase.Adapter.this.classWriterFactory, DynamicType.Builder.AbstractBase.Adapter.this.ignoredMethods, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypes);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return !super.equals(param5Object) ? false : ((this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!DynamicType.Builder.AbstractBase.Adapter.MethodMatchAdapter.this.equals(DynamicType.Builder.AbstractBase.Adapter.MethodMatchAdapter.this)))));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               return super.hashCode() * 31 + DynamicType.Builder.AbstractBase.Adapter.MethodMatchAdapter.this.hashCode();
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance(includeSyntheticFields = true)
/*      */         protected class OptionalMethodMatchAdapter
/*      */           extends DynamicType.Builder.AbstractBase.Delegator<U>
/*      */           implements DynamicType.Builder.MethodDefinition.ImplementationDefinition.Optional<U>
/*      */         {
/*      */           private final TypeList.Generic interfaces;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected OptionalMethodMatchAdapter(TypeList.Generic interfaces) {
/* 5701 */             this.interfaces = interfaces;
/*      */           }
/*      */ 
/*      */           
/*      */           protected DynamicType.Builder<U> materialize() {
/* 5706 */             return DynamicType.Builder.AbstractBase.Adapter.this.materialize(DynamicType.Builder.AbstractBase.Adapter.this.instrumentedType.withInterfaces(this.interfaces), DynamicType.Builder.AbstractBase.Adapter.this.fieldRegistry, DynamicType.Builder.AbstractBase.Adapter.this.methodRegistry, DynamicType.Builder.AbstractBase.Adapter.this.recordComponentRegistry, DynamicType.Builder.AbstractBase.Adapter.this.typeAttributeAppender, DynamicType.Builder.AbstractBase.Adapter.this.asmVisitorWrapper, DynamicType.Builder.AbstractBase.Adapter.this.classFileVersion, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypeNamingStrategy, DynamicType.Builder.AbstractBase.Adapter.this.annotationValueFilterFactory, DynamicType.Builder.AbstractBase.Adapter.this.annotationRetention, DynamicType.Builder.AbstractBase.Adapter.this.implementationContextFactory, DynamicType.Builder.AbstractBase.Adapter.this.methodGraphCompiler, DynamicType.Builder.AbstractBase.Adapter.this.typeValidation, DynamicType.Builder.AbstractBase.Adapter.this.visibilityBridgeStrategy, DynamicType.Builder.AbstractBase.Adapter.this.classReaderFactory, DynamicType.Builder.AbstractBase.Adapter.this.classWriterFactory, DynamicType.Builder.AbstractBase.Adapter.this.ignoredMethods, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypes);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> intercept(Implementation implementation) {
/* 5730 */             return interfaceType().intercept(implementation);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> withoutCode() {
/* 5737 */             return interfaceType().withoutCode();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> defaultValue(AnnotationValue<?, ?> annotationValue) {
/* 5744 */             return interfaceType().defaultValue(annotationValue);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public <V> DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition<U> defaultValue(V value, Class<? extends V> type) {
/* 5751 */             return interfaceType().defaultValue(value, type);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private DynamicType.Builder.MethodDefinition.ImplementationDefinition<U> interfaceType() {
/* 5760 */             ElementMatcher.Junction<TypeDescription> elementMatcher = ElementMatchers.none();
/* 5761 */             for (TypeDescription typeDescription : this.interfaces.asErasures()) {
/* 5762 */               elementMatcher = elementMatcher.or((ElementMatcher)ElementMatchers.isSuperTypeOf(typeDescription));
/*      */             }
/* 5764 */             return materialize().invokable((ElementMatcher<? super MethodDescription>)ElementMatchers.isDeclaredBy((ElementMatcher)ElementMatchers.isInterface().and((ElementMatcher)elementMatcher)));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.interfaces.equals(((OptionalMethodMatchAdapter)param4Object).interfaces) ? false : (!!DynamicType.Builder.AbstractBase.Adapter.this.equals(DynamicType.Builder.AbstractBase.Adapter.this)))));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return (getClass().hashCode() * 31 + this.interfaces.hashCode()) * 31 + DynamicType.Builder.AbstractBase.Adapter.this.hashCode();
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance(includeSyntheticFields = true)
/*      */         protected class RecordComponentDefinitionAdapter
/*      */           extends DynamicType.Builder.RecordComponentDefinition.Optional.AbstractBase<U>
/*      */         {
/*      */           private final RecordComponentAttributeAppender.Factory recordComponentAttributeAppenderFactory;
/*      */ 
/*      */           
/*      */           private final RecordComponentDescription.Token token;
/*      */           
/*      */           private final Transformer<RecordComponentDescription> transformer;
/*      */ 
/*      */           
/*      */           protected RecordComponentDefinitionAdapter(RecordComponentDescription.Token token) {
/* 5795 */             this((RecordComponentAttributeAppender.Factory)RecordComponentAttributeAppender.ForInstrumentedRecordComponent.INSTANCE, 
/* 5796 */                 Transformer.NoOp.make(), token);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected RecordComponentDefinitionAdapter(RecordComponentAttributeAppender.Factory recordComponentAttributeAppenderFactory, Transformer<RecordComponentDescription> transformer, RecordComponentDescription.Token token) {
/* 5810 */             this.recordComponentAttributeAppenderFactory = recordComponentAttributeAppenderFactory;
/* 5811 */             this.transformer = transformer;
/* 5812 */             this.token = token;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.RecordComponentDefinition.Optional<U> annotateRecordComponent(Collection<? extends AnnotationDescription> annotations) {
/* 5819 */             return new RecordComponentDefinitionAdapter(this.recordComponentAttributeAppenderFactory, this.transformer, new RecordComponentDescription.Token(this.token.getName(), this.token
/* 5820 */                   .getType(), 
/* 5821 */                   CompoundList.of((List)this.token.getAnnotations(), new ArrayList<AnnotationDescription>(annotations))));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.RecordComponentDefinition.Optional<U> attribute(RecordComponentAttributeAppender.Factory recordComponentAttributeAppenderFactory) {
/* 5828 */             return new RecordComponentDefinitionAdapter((RecordComponentAttributeAppender.Factory)new RecordComponentAttributeAppender.Factory.Compound(new RecordComponentAttributeAppender.Factory[] { this.recordComponentAttributeAppenderFactory, recordComponentAttributeAppenderFactory }, ), this.transformer, this.token);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.RecordComponentDefinition.Optional<U> transform(Transformer<RecordComponentDescription> transformer) {
/* 5837 */             return new RecordComponentDefinitionAdapter(this.recordComponentAttributeAppenderFactory, new Transformer.Compound<RecordComponentDescription>((Transformer<RecordComponentDescription>[])new Transformer[] { this.transformer, transformer }, ), this.token);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected DynamicType.Builder<U> materialize() {
/* 5844 */             return DynamicType.Builder.AbstractBase.Adapter.this.materialize(DynamicType.Builder.AbstractBase.Adapter.this.instrumentedType.withRecordComponent(this.token), DynamicType.Builder.AbstractBase.Adapter.this.fieldRegistry, DynamicType.Builder.AbstractBase.Adapter.this.methodRegistry, DynamicType.Builder.AbstractBase.Adapter.this.recordComponentRegistry
/*      */ 
/*      */                 
/* 5847 */                 .prepend((LatentMatcher)new LatentMatcher.ForRecordComponentToken(this.token), this.recordComponentAttributeAppenderFactory, this.transformer), DynamicType.Builder.AbstractBase.Adapter.this.typeAttributeAppender, DynamicType.Builder.AbstractBase.Adapter.this.asmVisitorWrapper, DynamicType.Builder.AbstractBase.Adapter.this.classFileVersion, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypeNamingStrategy, DynamicType.Builder.AbstractBase.Adapter.this.annotationValueFilterFactory, DynamicType.Builder.AbstractBase.Adapter.this.annotationRetention, DynamicType.Builder.AbstractBase.Adapter.this.implementationContextFactory, DynamicType.Builder.AbstractBase.Adapter.this.methodGraphCompiler, DynamicType.Builder.AbstractBase.Adapter.this.typeValidation, DynamicType.Builder.AbstractBase.Adapter.this.visibilityBridgeStrategy, DynamicType.Builder.AbstractBase.Adapter.this.classReaderFactory, DynamicType.Builder.AbstractBase.Adapter.this.classWriterFactory, DynamicType.Builder.AbstractBase.Adapter.this.ignoredMethods, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypes);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.recordComponentAttributeAppenderFactory.equals(((RecordComponentDefinitionAdapter)param4Object).recordComponentAttributeAppenderFactory) ? false : (!this.token.equals(((RecordComponentDefinitionAdapter)param4Object).token) ? false : (!this.transformer.equals(((RecordComponentDefinitionAdapter)param4Object).transformer) ? false : (!!DynamicType.Builder.AbstractBase.Adapter.this.equals(DynamicType.Builder.AbstractBase.Adapter.this)))))));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return (((getClass().hashCode() * 31 + this.recordComponentAttributeAppenderFactory.hashCode()) * 31 + this.token.hashCode()) * 31 + this.transformer.hashCode()) * 31 + DynamicType.Builder.AbstractBase.Adapter.this.hashCode();
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected class RecordComponentMatchAdapter
/*      */           extends DynamicType.Builder.RecordComponentDefinition.Optional.AbstractBase<U>
/*      */         {
/*      */           private final LatentMatcher<? super RecordComponentDescription> matcher;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final RecordComponentAttributeAppender.Factory recordComponentAttributeAppenderFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final Transformer<RecordComponentDescription> transformer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected RecordComponentMatchAdapter(LatentMatcher<? super RecordComponentDescription> matcher) {
/* 5893 */             this(matcher, (RecordComponentAttributeAppender.Factory)RecordComponentAttributeAppender.NoOp.INSTANCE, Transformer.NoOp.make());
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected RecordComponentMatchAdapter(LatentMatcher<? super RecordComponentDescription> matcher, RecordComponentAttributeAppender.Factory recordComponentAttributeAppenderFactory, Transformer<RecordComponentDescription> transformer) {
/* 5906 */             this.matcher = matcher;
/* 5907 */             this.recordComponentAttributeAppenderFactory = recordComponentAttributeAppenderFactory;
/* 5908 */             this.transformer = transformer;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.RecordComponentDefinition.Optional<U> annotateRecordComponent(Collection<? extends AnnotationDescription> annotations) {
/* 5915 */             return attribute((RecordComponentAttributeAppender.Factory)new RecordComponentAttributeAppender.Explicit(new ArrayList<AnnotationDescription>(annotations)));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.RecordComponentDefinition.Optional<U> attribute(RecordComponentAttributeAppender.Factory recordComponentAttributeAppenderFactory) {
/* 5922 */             return new RecordComponentMatchAdapter(this.matcher, (RecordComponentAttributeAppender.Factory)new RecordComponentAttributeAppender.Factory.Compound(new RecordComponentAttributeAppender.Factory[] { this.recordComponentAttributeAppenderFactory, recordComponentAttributeAppenderFactory }, ), this.transformer);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public DynamicType.Builder.RecordComponentDefinition.Optional<U> transform(Transformer<RecordComponentDescription> transformer) {
/* 5931 */             return new RecordComponentMatchAdapter(this.matcher, this.recordComponentAttributeAppenderFactory, new Transformer.Compound<RecordComponentDescription>((Transformer<RecordComponentDescription>[])new Transformer[] { this.transformer, transformer }));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected DynamicType.Builder<U> materialize() {
/* 5938 */             return DynamicType.Builder.AbstractBase.Adapter.this.materialize(DynamicType.Builder.AbstractBase.Adapter.this.instrumentedType, DynamicType.Builder.AbstractBase.Adapter.this.fieldRegistry, DynamicType.Builder.AbstractBase.Adapter.this.methodRegistry, DynamicType.Builder.AbstractBase.Adapter.this.recordComponentRegistry
/*      */ 
/*      */                 
/* 5941 */                 .prepend(this.matcher, this.recordComponentAttributeAppenderFactory, this.transformer), DynamicType.Builder.AbstractBase.Adapter.this.typeAttributeAppender, DynamicType.Builder.AbstractBase.Adapter.this.asmVisitorWrapper, DynamicType.Builder.AbstractBase.Adapter.this.classFileVersion, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypeNamingStrategy, DynamicType.Builder.AbstractBase.Adapter.this.annotationValueFilterFactory, DynamicType.Builder.AbstractBase.Adapter.this.annotationRetention, DynamicType.Builder.AbstractBase.Adapter.this.implementationContextFactory, DynamicType.Builder.AbstractBase.Adapter.this.methodGraphCompiler, DynamicType.Builder.AbstractBase.Adapter.this.typeValidation, DynamicType.Builder.AbstractBase.Adapter.this.visibilityBridgeStrategy, DynamicType.Builder.AbstractBase.Adapter.this.classReaderFactory, DynamicType.Builder.AbstractBase.Adapter.this.classWriterFactory, DynamicType.Builder.AbstractBase.Adapter.this.ignoredMethods, DynamicType.Builder.AbstractBase.Adapter.this.auxiliaryTypes);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static interface InnerTypeDefinition<S>
/*      */       extends Builder<S>
/*      */     {
/*      */       DynamicType.Builder<S> asAnonymousType();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static interface ForType<U>
/*      */         extends InnerTypeDefinition<U>
/*      */       {
/*      */         DynamicType.Builder<U> asMemberType();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static interface ForType<U>
/*      */       extends InnerTypeDefinition<U>
/*      */     {
/*      */       DynamicType.Builder<U> asMemberType();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static interface Optional<V>
/*      */       extends MethodDefinition.ImplementationDefinition<V>, Builder<V> {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static interface Valuable<U>
/*      */       extends FieldDefinition<U>
/*      */     {
/*      */       DynamicType.Builder.FieldDefinition.Optional<U> value(boolean param2Boolean);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       DynamicType.Builder.FieldDefinition.Optional<U> value(int param2Int);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       DynamicType.Builder.FieldDefinition.Optional<U> value(long param2Long);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       DynamicType.Builder.FieldDefinition.Optional<U> value(float param2Float);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       DynamicType.Builder.FieldDefinition.Optional<U> value(double param2Double);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       DynamicType.Builder.FieldDefinition.Optional<U> value(String param2String);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface Unloaded<T>
/*      */     extends DynamicType
/*      */   {
/*      */     DynamicType.Loaded<T> load(@MaybeNull ClassLoader param1ClassLoader);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     <S extends ClassLoader> DynamicType.Loaded<T> load(@MaybeNull S param1S, ClassLoadingStrategy<? super S> param1ClassLoadingStrategy);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Unloaded<T> include(DynamicType... param1VarArgs);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Unloaded<T> include(List<? extends DynamicType> param1List);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface Loaded<T>
/*      */     extends DynamicType
/*      */   {
/*      */     Class<? extends T> getLoaded();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Map<TypeDescription, Class<?>> getLoadedAuxiliaryTypes();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Map<TypeDescription, Class<?>> getAllLoaded();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static abstract class AbstractBase
/*      */     implements DynamicType
/*      */   {
/*      */     private static final String CLASS_FILE_EXTENSION = ".class";
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String MANIFEST_VERSION = "1.0";
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String TEMP_SUFFIX = "tmp";
/*      */ 
/*      */ 
/*      */     
/*      */     public ClassFileLocator.Resolution locate(String name) throws IOException {
/* 6078 */       if (getTypeDescription().getName().equals(name)) {
/* 6079 */         return new ClassFileLocator.Resolution.Explicit(getBytes());
/*      */       }
/* 6081 */       for (DynamicType auxiliaryType : getAuxiliaries()) {
/* 6082 */         ClassFileLocator.Resolution resolution = auxiliaryType.locate(name);
/* 6083 */         if (resolution.isResolved()) {
/* 6084 */           return resolution;
/*      */         }
/*      */       } 
/* 6087 */       return new ClassFileLocator.Resolution.Illegal(name);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Set<TypeDescription> getAuxiliaryTypeDescriptions() {
/* 6101 */       Set<TypeDescription> types = new LinkedHashSet<TypeDescription>();
/* 6102 */       for (DynamicType auxiliaryType : getAuxiliaries()) {
/* 6103 */         types.addAll(auxiliaryType.getAllTypeDescriptions());
/*      */       }
/* 6105 */       return types;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Set<TypeDescription> getAllTypeDescriptions() {
/* 6112 */       Set<TypeDescription> types = new LinkedHashSet<TypeDescription>();
/* 6113 */       types.add(getTypeDescription());
/* 6114 */       for (DynamicType auxiliaryType : getAuxiliaries()) {
/* 6115 */         types.addAll(auxiliaryType.getAllTypeDescriptions());
/*      */       }
/* 6117 */       return types;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Map<TypeDescription, byte[]> getAllTypes() {
/* 6124 */       Map<TypeDescription, byte[]> allTypes = (Map)new LinkedHashMap<TypeDescription, byte>();
/* 6125 */       allTypes.put(getTypeDescription(), getBytes());
/* 6126 */       for (DynamicType auxiliaryType : getAuxiliaries()) {
/* 6127 */         allTypes.putAll((Map)auxiliaryType.getAllTypes());
/*      */       }
/* 6129 */       return allTypes;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Map<TypeDescription, LoadedTypeInitializer> getLoadedTypeInitializers() {
/* 6136 */       Map<TypeDescription, LoadedTypeInitializer> classLoadingCallbacks = new HashMap<TypeDescription, LoadedTypeInitializer>();
/* 6137 */       for (DynamicType auxiliaryType : getAuxiliaries()) {
/* 6138 */         classLoadingCallbacks.putAll(auxiliaryType.getLoadedTypeInitializers());
/*      */       }
/* 6140 */       classLoadingCallbacks.put(getTypeDescription(), getLoadedTypeInitializer());
/* 6141 */       return classLoadingCallbacks;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasAliveLoadedTypeInitializers() {
/* 6148 */       if (getLoadedTypeInitializer().isAlive()) {
/* 6149 */         return true;
/*      */       }
/* 6151 */       for (DynamicType auxiliaryType : getAuxiliaries()) {
/* 6152 */         if (auxiliaryType.hasAliveLoadedTypeInitializers()) {
/* 6153 */           return true;
/*      */         }
/*      */       } 
/* 6156 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Map<TypeDescription, byte[]> getAuxiliaryTypes() {
/* 6163 */       Map<TypeDescription, byte[]> auxiliaryTypes = (Map)new HashMap<TypeDescription, byte>();
/* 6164 */       for (DynamicType auxiliaryType : getAuxiliaries()) {
/* 6165 */         auxiliaryTypes.put(auxiliaryType.getTypeDescription(), auxiliaryType.getBytes());
/* 6166 */         auxiliaryTypes.putAll((Map)auxiliaryType.getAuxiliaryTypes());
/*      */       } 
/* 6168 */       return auxiliaryTypes;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Map<TypeDescription, File> saveIn(File folder) throws IOException {
/* 6175 */       Map<TypeDescription, File> files = new HashMap<TypeDescription, File>();
/* 6176 */       File target = new File(folder, getTypeDescription().getName().replace('.', File.separatorChar) + ".class");
/* 6177 */       if (target.getParentFile() != null && !target.getParentFile().isDirectory() && !target.getParentFile().mkdirs()) {
/* 6178 */         throw new IllegalArgumentException("Could not create directory: " + target.getParentFile());
/*      */       }
/* 6180 */       OutputStream outputStream = new FileOutputStream(target);
/*      */       try {
/* 6182 */         outputStream.write(getBytes());
/*      */       } finally {
/* 6184 */         outputStream.close();
/*      */       } 
/* 6186 */       files.put(getTypeDescription(), target);
/* 6187 */       for (DynamicType auxiliaryType : getAuxiliaries()) {
/* 6188 */         files.putAll(auxiliaryType.saveIn(folder));
/*      */       }
/* 6190 */       return files;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public File inject(File sourceJar, File targetJar) throws IOException {
/* 6197 */       return sourceJar.equals(targetJar) ? 
/* 6198 */         inject(sourceJar) : 
/* 6199 */         doInject(sourceJar, targetJar);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public File inject(File jar) throws IOException {
/* 6206 */       FileSystem.getInstance().move(doInject(jar, File.createTempFile(jar.getName(), "tmp")), jar);
/* 6207 */       return jar;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"OS_OPEN_STREAM_EXCEPTION_PATH"}, justification = "Outer stream holds file handle and is closed")
/*      */     private File doInject(File sourceJar, File targetJar) throws IOException {
/* 6220 */       InputStream inputStream = new FileInputStream(sourceJar);
/*      */       try {
/* 6222 */         JarInputStream jarInputStream = new JarInputStream(inputStream);
/* 6223 */         if (!targetJar.isFile() && !targetJar.createNewFile()) {
/* 6224 */           throw new IllegalArgumentException("Could not create file: " + targetJar);
/*      */         }
/* 6226 */         Manifest manifest = jarInputStream.getManifest();
/* 6227 */         OutputStream outputStream = new FileOutputStream(targetJar);
/*      */         try {
/* 6229 */           JarOutputStream jarOutputStream = (manifest == null) ? new JarOutputStream(outputStream) : new JarOutputStream(outputStream, manifest);
/*      */ 
/*      */           
/* 6232 */           Map<TypeDescription, byte[]> rawAuxiliaryTypes = getAuxiliaryTypes();
/* 6233 */           Map<String, byte[]> files = (Map)new HashMap<String, byte>();
/* 6234 */           for (Map.Entry<TypeDescription, byte[]> entry : rawAuxiliaryTypes.entrySet()) {
/* 6235 */             files.put(((TypeDescription)entry.getKey()).getInternalName() + ".class", entry.getValue());
/*      */           }
/* 6237 */           files.put(getTypeDescription().getInternalName() + ".class", getBytes());
/*      */           JarEntry jarEntry;
/* 6239 */           while ((jarEntry = jarInputStream.getNextJarEntry()) != null) {
/* 6240 */             byte[] replacement = files.remove(jarEntry.getName());
/* 6241 */             if (replacement == null) {
/* 6242 */               jarOutputStream.putNextEntry(jarEntry);
/* 6243 */               byte[] buffer = new byte[1024];
/*      */               int index;
/* 6245 */               while ((index = jarInputStream.read(buffer)) != -1) {
/* 6246 */                 jarOutputStream.write(buffer, 0, index);
/*      */               }
/*      */             } else {
/* 6249 */               jarOutputStream.putNextEntry(new JarEntry(jarEntry.getName()));
/* 6250 */               jarOutputStream.write(replacement);
/*      */             } 
/* 6252 */             jarInputStream.closeEntry();
/* 6253 */             jarOutputStream.closeEntry();
/*      */           } 
/* 6255 */           for (Map.Entry<String, byte[]> entry : files.entrySet()) {
/* 6256 */             jarOutputStream.putNextEntry(new JarEntry(entry.getKey()));
/* 6257 */             jarOutputStream.write(entry.getValue());
/* 6258 */             jarOutputStream.closeEntry();
/*      */           } 
/* 6260 */           jarOutputStream.close();
/*      */         } finally {
/* 6262 */           outputStream.close();
/*      */         } 
/* 6264 */         jarInputStream.close();
/*      */       } finally {
/* 6266 */         inputStream.close();
/*      */       } 
/* 6268 */       return targetJar;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public File toJar(File file) throws IOException {
/* 6275 */       Manifest manifest = new Manifest();
/* 6276 */       manifest.getMainAttributes().put(Attributes.Name.MANIFEST_VERSION, "1.0");
/* 6277 */       return toJar(file, manifest);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"OS_OPEN_STREAM_EXCEPTION_PATH"}, justification = "Outer stream holds file handle and is closed")
/*      */     public File toJar(File file, Manifest manifest) throws IOException {
/* 6285 */       if (!file.isFile() && !file.createNewFile()) {
/* 6286 */         throw new IllegalArgumentException("Could not create file: " + file);
/*      */       }
/* 6288 */       OutputStream outputStream = new FileOutputStream(file);
/*      */       try {
/* 6290 */         JarOutputStream jarOutputStream = new JarOutputStream(outputStream, manifest);
/* 6291 */         for (Map.Entry<TypeDescription, byte[]> entry : getAuxiliaryTypes().entrySet()) {
/* 6292 */           jarOutputStream.putNextEntry(new JarEntry(((TypeDescription)entry.getKey()).getInternalName() + ".class"));
/* 6293 */           jarOutputStream.write(entry.getValue());
/* 6294 */           jarOutputStream.closeEntry();
/*      */         } 
/* 6296 */         jarOutputStream.putNextEntry(new JarEntry(getTypeDescription().getInternalName() + ".class"));
/* 6297 */         jarOutputStream.write(getBytes());
/* 6298 */         jarOutputStream.closeEntry();
/* 6299 */         jarOutputStream.close();
/*      */       } finally {
/* 6301 */         outputStream.close();
/*      */       } 
/* 6303 */       return file;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : (!(getClass() != param1Object.getClass())));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return getClass().hashCode();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static class Default
/*      */     extends AbstractBase
/*      */   {
/*      */     protected final TypeDescription typeDescription;
/*      */ 
/*      */ 
/*      */     
/*      */     protected final byte[] binaryRepresentation;
/*      */ 
/*      */ 
/*      */     
/*      */     protected final LoadedTypeInitializer loadedTypeInitializer;
/*      */ 
/*      */ 
/*      */     
/*      */     protected final List<? extends DynamicType> auxiliaryTypes;
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"EI_EXPOSE_REP2"}, justification = "The array is not modified by class contract.")
/*      */     public Default(TypeDescription typeDescription, byte[] binaryRepresentation, LoadedTypeInitializer loadedTypeInitializer, List<? extends DynamicType> auxiliaryTypes) {
/* 6346 */       this.typeDescription = typeDescription;
/* 6347 */       this.binaryRepresentation = binaryRepresentation;
/* 6348 */       this.loadedTypeInitializer = loadedTypeInitializer;
/* 6349 */       this.auxiliaryTypes = auxiliaryTypes;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription getTypeDescription() {
/* 6356 */       return this.typeDescription;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"EI_EXPOSE_REP"}, justification = "The array is not modified by class contract.")
/*      */     public byte[] getBytes() {
/* 6364 */       return this.binaryRepresentation;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LoadedTypeInitializer getLoadedTypeInitializer() {
/* 6371 */       return this.loadedTypeInitializer;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<? extends DynamicType> getAuxiliaries() {
/* 6378 */       return this.auxiliaryTypes;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return !super.equals(param1Object) ? false : ((this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.typeDescription.equals(((Default)param1Object).typeDescription) ? false : (!Arrays.equals(this.binaryRepresentation, ((Default)param1Object).binaryRepresentation) ? false : (!this.loadedTypeInitializer.equals(((Default)param1Object).loadedTypeInitializer) ? false : (!!this.auxiliaryTypes.equals(((Default)param1Object).auxiliaryTypes))))))));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return (((super.hashCode() * 31 + this.typeDescription.hashCode()) * 31 + Arrays.hashCode(this.binaryRepresentation)) * 31 + this.loadedTypeInitializer.hashCode()) * 31 + this.auxiliaryTypes.hashCode();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class Unloaded<T>
/*      */       extends Default
/*      */       implements DynamicType.Unloaded<T>
/*      */     {
/*      */       private final TypeResolutionStrategy.Resolved typeResolutionStrategy;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Unloaded(TypeDescription typeDescription, byte[] binaryRepresentation, LoadedTypeInitializer loadedTypeInitializer, List<? extends DynamicType> auxiliaryTypes, TypeResolutionStrategy.Resolved typeResolutionStrategy) {
/* 6409 */         super(typeDescription, binaryRepresentation, loadedTypeInitializer, auxiliaryTypes);
/* 6410 */         this.typeResolutionStrategy = typeResolutionStrategy;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Loaded<T> load(@MaybeNull ClassLoader classLoader) {
/* 6417 */         if (classLoader instanceof InjectionClassLoader && !((InjectionClassLoader)classLoader).isSealed()) {
/* 6418 */           return load((InjectionClassLoader)classLoader, (ClassLoadingStrategy<? super InjectionClassLoader>)InjectionClassLoader.Strategy.INSTANCE);
/*      */         }
/* 6420 */         return load(classLoader, (ClassLoadingStrategy<? super ClassLoader>)ClassLoadingStrategy.Default.WRAPPER);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public <S extends ClassLoader> DynamicType.Loaded<T> load(@MaybeNull S classLoader, ClassLoadingStrategy<? super S> classLoadingStrategy) {
/* 6428 */         return new DynamicType.Default.Loaded<T>(this.typeDescription, this.binaryRepresentation, this.loadedTypeInitializer, this.auxiliaryTypes, this.typeResolutionStrategy
/*      */ 
/*      */ 
/*      */             
/* 6432 */             .initialize(this, classLoader, classLoadingStrategy));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Unloaded<T> include(DynamicType... dynamicType) {
/* 6439 */         return include(Arrays.asList(dynamicType));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public DynamicType.Unloaded<T> include(List<? extends DynamicType> dynamicType) {
/* 6446 */         return new Unloaded(this.typeDescription, this.binaryRepresentation, this.loadedTypeInitializer, 
/*      */ 
/*      */             
/* 6449 */             CompoundList.of(this.auxiliaryTypes, dynamicType), this.typeResolutionStrategy);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return !super.equals(param2Object) ? false : ((this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.typeResolutionStrategy.equals(((Unloaded)param2Object).typeResolutionStrategy)))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return super.hashCode() * 31 + this.typeResolutionStrategy.hashCode();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     protected static class Loaded<T>
/*      */       extends Default
/*      */       implements DynamicType.Loaded<T>
/*      */     {
/*      */       private final Map<TypeDescription, Class<?>> loadedTypes;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected Loaded(TypeDescription typeDescription, byte[] typeByte, LoadedTypeInitializer loadedTypeInitializer, List<? extends DynamicType> auxiliaryTypes, Map<TypeDescription, Class<?>> loadedTypes) {
/* 6482 */         super(typeDescription, typeByte, loadedTypeInitializer, auxiliaryTypes);
/* 6483 */         this.loadedTypes = loadedTypes;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Class<? extends T> getLoaded() {
/* 6491 */         return (Class<? extends T>)this.loadedTypes.get(this.typeDescription);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Map<TypeDescription, Class<?>> getLoadedAuxiliaryTypes() {
/* 6498 */         Map<TypeDescription, Class<?>> loadedAuxiliaryTypes = new HashMap<TypeDescription, Class<?>>(this.loadedTypes);
/* 6499 */         loadedAuxiliaryTypes.remove(this.typeDescription);
/* 6500 */         return loadedAuxiliaryTypes;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Map<TypeDescription, Class<?>> getAllLoaded() {
/* 6507 */         return new HashMap<TypeDescription, Class<?>>(this.loadedTypes);
/*      */       }
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return !super.equals(param2Object) ? false : ((this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.loadedTypes.equals(((Loaded)param2Object).loadedTypes)))));
/*      */       }
/*      */       
/*      */       public int hashCode() {
/*      */         return super.hashCode() * 31 + this.loadedTypes.hashCode();
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\DynamicType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */