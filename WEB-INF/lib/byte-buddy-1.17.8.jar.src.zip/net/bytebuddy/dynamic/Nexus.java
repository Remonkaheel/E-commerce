/*     */ package net.bytebuddy.dynamic;
/*     */ 
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Nexus
/*     */   extends WeakReference<ClassLoader>
/*     */ {
/*     */   public static final String PROPERTY = "net.bytebuddy.nexus.disabled";
/*     */   @AlwaysNull
/*  57 */   private static final ReferenceQueue<ClassLoader> NO_QUEUE = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private static final ConcurrentMap<Nexus, Object> TYPE_INITIALIZERS = new ConcurrentHashMap<Nexus, Object>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int classLoaderHashCode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int identification;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Nexus(Class<?> type, int identification) {
/*  89 */     this(nonAnonymous(type.getName()), type.getClassLoader(), NO_QUEUE, identification);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Nexus(String name, @MaybeNull ClassLoader classLoader, @MaybeNull ReferenceQueue<? super ClassLoader> referenceQueue, int identification) {
/* 101 */     super(classLoader, (classLoader == null) ? null : referenceQueue);
/*     */ 
/*     */     
/* 104 */     this.name = name;
/* 105 */     this.classLoaderHashCode = System.identityHashCode(classLoader);
/* 106 */     this.identification = identification;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String nonAnonymous(String typeName) {
/* 116 */     int anonymousLoaderIndex = typeName.indexOf('/');
/* 117 */     return (anonymousLoaderIndex == -1) ? typeName : typeName
/*     */       
/* 119 */       .substring(0, anonymousLoaderIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initialize(Class<?> type, int identification) throws Exception {
/* 139 */     Object typeInitializer = TYPE_INITIALIZERS.remove(new Nexus(type, identification));
/* 140 */     if (typeInitializer != null) {
/* 141 */       Class.forName("net.bytebuddy.implementation.LoadedTypeInitializer", true, typeInitializer
/*     */           
/* 143 */           .getClass().getClassLoader()).getMethod("onLoad", new Class[] { Class.class }).invoke(typeInitializer, new Object[] { type });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void register(String name, @MaybeNull ClassLoader classLoader, @MaybeNull ReferenceQueue<? super ClassLoader> referenceQueue, int identification, Object typeInitializer) {
/* 168 */     TYPE_INITIALIZERS.put(new Nexus(name, classLoader, referenceQueue, identification), typeInitializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clean(Reference<? super ClassLoader> reference) {
/* 185 */     TYPE_INITIALIZERS.remove(reference);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 190 */     int result = this.name.hashCode();
/* 191 */     result = 31 * result + this.classLoaderHashCode;
/* 192 */     result = 31 * result + this.identification;
/* 193 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(@MaybeNull Object other) {
/* 198 */     if (this == other)
/* 199 */       return true; 
/* 200 */     if (other == null || getClass() != other.getClass()) {
/* 201 */       return false;
/*     */     }
/* 203 */     Nexus nexus = (Nexus)other;
/* 204 */     return (this.classLoaderHashCode == nexus.classLoaderHashCode && this.identification == nexus.identification && this.name
/*     */       
/* 206 */       .equals(nexus.name) && 
/* 207 */       get() == nexus.get());
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 212 */     return "Nexus{name='" + this.name + '\'' + ", classLoaderHashCode=" + this.classLoaderHashCode + ", identification=" + this.identification + ", classLoader=" + 
/*     */ 
/*     */ 
/*     */       
/* 216 */       get() + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\Nexus.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */