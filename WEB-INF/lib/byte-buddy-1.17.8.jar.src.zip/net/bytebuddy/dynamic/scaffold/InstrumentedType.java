/*      */ package net.bytebuddy.dynamic.scaffold;
/*      */ 
/*      */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*      */ import java.lang.annotation.ElementType;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import net.bytebuddy.ClassFileVersion;
/*      */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*      */ import net.bytebuddy.description.annotation.AnnotationList;
/*      */ import net.bytebuddy.description.annotation.AnnotationValue;
/*      */ import net.bytebuddy.description.field.FieldDescription;
/*      */ import net.bytebuddy.description.field.FieldList;
/*      */ import net.bytebuddy.description.method.MethodDescription;
/*      */ import net.bytebuddy.description.method.MethodList;
/*      */ import net.bytebuddy.description.method.ParameterDescription;
/*      */ import net.bytebuddy.description.modifier.ModifierContributor;
/*      */ import net.bytebuddy.description.type.PackageDescription;
/*      */ import net.bytebuddy.description.type.RecordComponentDescription;
/*      */ import net.bytebuddy.description.type.RecordComponentList;
/*      */ import net.bytebuddy.description.type.TypeDefinition;
/*      */ import net.bytebuddy.description.type.TypeDescription;
/*      */ import net.bytebuddy.description.type.TypeList;
/*      */ import net.bytebuddy.description.type.TypeVariableToken;
/*      */ import net.bytebuddy.dynamic.TargetType;
/*      */ import net.bytebuddy.dynamic.Transformer;
/*      */ import net.bytebuddy.implementation.LoadedTypeInitializer;
/*      */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*      */ import net.bytebuddy.matcher.ElementMatcher;
/*      */ import net.bytebuddy.matcher.ElementMatchers;
/*      */ import net.bytebuddy.utility.CompoundList;
/*      */ import net.bytebuddy.utility.JavaType;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface InstrumentedType
/*      */   extends TypeDescription
/*      */ {
/*      */   InstrumentedType withField(FieldDescription.Token paramToken);
/*      */   
/*      */   InstrumentedType withAuxiliaryField(FieldDescription.Token paramToken, Object paramObject);
/*      */   
/*      */   InstrumentedType withMethod(MethodDescription.Token paramToken);
/*      */   
/*      */   InstrumentedType withRecordComponent(RecordComponentDescription.Token paramToken);
/*      */   
/*      */   InstrumentedType withModifiers(int paramInt);
/*      */   
/*      */   InstrumentedType withInterfaces(TypeList.Generic paramGeneric);
/*      */   
/*      */   InstrumentedType withTypeVariable(TypeVariableToken paramTypeVariableToken);
/*      */   
/*      */   InstrumentedType withAnnotations(List<? extends AnnotationDescription> paramList);
/*      */   
/*      */   InstrumentedType withNestHost(TypeDescription paramTypeDescription);
/*      */   
/*      */   InstrumentedType withNestMembers(TypeList paramTypeList);
/*      */   
/*      */   InstrumentedType withEnclosingType(TypeDescription paramTypeDescription);
/*      */   
/*      */   InstrumentedType withEnclosingMethod(MethodDescription.InDefinedShape paramInDefinedShape);
/*      */   
/*      */   InstrumentedType withDeclaringType(@MaybeNull TypeDescription paramTypeDescription);
/*      */   
/*      */   InstrumentedType withDeclaredTypes(TypeList paramTypeList);
/*      */   
/*      */   InstrumentedType withPermittedSubclasses(@MaybeNull TypeList paramTypeList);
/*      */   
/*      */   InstrumentedType withLocalClass(boolean paramBoolean);
/*      */   
/*      */   InstrumentedType withAnonymousClass(boolean paramBoolean);
/*      */   
/*      */   InstrumentedType withRecord(boolean paramBoolean);
/*      */   
/*      */   InstrumentedType withInitializer(LoadedTypeInitializer paramLoadedTypeInitializer);
/*      */   
/*      */   InstrumentedType withInitializer(ByteCodeAppender paramByteCodeAppender);
/*      */   
/*      */   LoadedTypeInitializer getLoadedTypeInitializer();
/*      */   
/*      */   TypeInitializer getTypeInitializer();
/*      */   
/*      */   TypeDescription validated();
/*      */   
/*      */   public static interface WithFlexibleName
/*      */     extends InstrumentedType
/*      */   {
/*      */     WithFlexibleName withField(FieldDescription.Token param1Token);
/*      */     
/*      */     WithFlexibleName withAuxiliaryField(FieldDescription.Token param1Token, Object param1Object);
/*      */     
/*      */     WithFlexibleName withMethod(MethodDescription.Token param1Token);
/*      */     
/*      */     WithFlexibleName withRecordComponent(RecordComponentDescription.Token param1Token);
/*      */     
/*      */     WithFlexibleName withModifiers(int param1Int);
/*      */     
/*      */     WithFlexibleName withInterfaces(TypeList.Generic param1Generic);
/*      */     
/*      */     WithFlexibleName withNestHost(TypeDescription param1TypeDescription);
/*      */     
/*      */     WithFlexibleName withNestMembers(TypeList param1TypeList);
/*      */     
/*      */     WithFlexibleName withEnclosingType(@MaybeNull TypeDescription param1TypeDescription);
/*      */     
/*      */     WithFlexibleName withEnclosingMethod(MethodDescription.InDefinedShape param1InDefinedShape);
/*      */     
/*      */     WithFlexibleName withDeclaringType(@MaybeNull TypeDescription param1TypeDescription);
/*      */     
/*      */     WithFlexibleName withDeclaredTypes(TypeList param1TypeList);
/*      */     
/*      */     WithFlexibleName withPermittedSubclasses(@MaybeNull TypeList param1TypeList);
/*      */     
/*      */     WithFlexibleName withLocalClass(boolean param1Boolean);
/*      */     
/*      */     WithFlexibleName withAnonymousClass(boolean param1Boolean);
/*      */     
/*      */     WithFlexibleName withRecord(boolean param1Boolean);
/*      */     
/*      */     WithFlexibleName withTypeVariable(TypeVariableToken param1TypeVariableToken);
/*      */     
/*      */     WithFlexibleName withAnnotations(List<? extends AnnotationDescription> param1List);
/*      */     
/*      */     WithFlexibleName withInitializer(LoadedTypeInitializer param1LoadedTypeInitializer);
/*      */     
/*      */     WithFlexibleName withInitializer(ByteCodeAppender param1ByteCodeAppender);
/*      */     
/*      */     WithFlexibleName withName(String param1String);
/*      */     
/*      */     WithFlexibleName withTypeVariables(ElementMatcher<? super TypeDescription.Generic> param1ElementMatcher, Transformer<TypeVariableToken> param1Transformer);
/*      */   }
/*      */   
/*      */   public static interface Prepareable
/*      */   {
/*      */     InstrumentedType prepare(InstrumentedType param1InstrumentedType);
/*      */     
/*      */     public enum NoOp
/*      */       implements Prepareable
/*      */     {
/*  387 */       INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public InstrumentedType prepare(InstrumentedType instrumentedType) {
/*  393 */         return instrumentedType;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface Factory
/*      */   {
/*      */     InstrumentedType.WithFlexibleName represent(TypeDescription param1TypeDescription);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     InstrumentedType.WithFlexibleName subclass(String param1String, int param1Int, TypeDescription.Generic param1Generic);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public enum Default
/*      */       implements Factory
/*      */     {
/*  429 */       MODIFIABLE
/*      */       {
/*      */         public InstrumentedType.WithFlexibleName represent(TypeDescription typeDescription) {
/*  432 */           return new InstrumentedType.Default(typeDescription.getName(), typeDescription
/*  433 */               .getModifiers(), typeDescription
/*  434 */               .getSuperClass(), (List<? extends TypeVariableToken>)typeDescription
/*  435 */               .getTypeVariables().asTokenList((ElementMatcher)ElementMatchers.is(typeDescription)), (List<? extends TypeDescription.Generic>)typeDescription
/*  436 */               .getInterfaces().accept(TypeDescription.Generic.Visitor.Substitutor.ForDetachment.of((TypeDefinition)typeDescription)), (List<? extends FieldDescription.Token>)typeDescription
/*  437 */               .getDeclaredFields().asTokenList((ElementMatcher)ElementMatchers.is(typeDescription)), 
/*  438 */               Collections.emptyMap(), (List<? extends MethodDescription.Token>)typeDescription
/*  439 */               .getDeclaredMethods().asTokenList((ElementMatcher)ElementMatchers.is(typeDescription)), (List<? extends RecordComponentDescription.Token>)typeDescription
/*  440 */               .getRecordComponents().asTokenList((ElementMatcher)ElementMatchers.is(typeDescription)), (List<? extends AnnotationDescription>)typeDescription
/*  441 */               .getDeclaredAnnotations(), TypeInitializer.None.INSTANCE, (LoadedTypeInitializer)LoadedTypeInitializer.NoOp.INSTANCE, typeDescription
/*      */ 
/*      */               
/*  444 */               .getDeclaringType(), typeDescription
/*  445 */               .getEnclosingMethod(), typeDescription
/*  446 */               .getEnclosingType(), (List<? extends TypeDescription>)typeDescription
/*  447 */               .getDeclaredTypes(), 
/*  448 */               typeDescription.isSealed() ? (List<? extends TypeDescription>)typeDescription
/*  449 */               .getPermittedSubtypes() : (List<? extends TypeDescription>)TypeList.UNDEFINED, typeDescription
/*      */               
/*  451 */               .isAnonymousType(), typeDescription
/*  452 */               .isLocalType(), typeDescription
/*  453 */               .isRecord(), 
/*  454 */               typeDescription.isNestHost() ? TargetType.DESCRIPTION : typeDescription
/*      */               
/*  456 */               .getNestHost(), 
/*  457 */               typeDescription.isNestHost() ? (List<? extends TypeDescription>)typeDescription
/*  458 */               .getNestMembers().filter((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.is(typeDescription))) : 
/*  459 */               Collections.<TypeDescription>emptyList());
/*      */         }
/*      */       },
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  466 */       FROZEN
/*      */       {
/*      */         public InstrumentedType.WithFlexibleName represent(TypeDescription typeDescription) {
/*  469 */           return new InstrumentedType.Frozen(typeDescription, (LoadedTypeInitializer)LoadedTypeInitializer.NoOp.INSTANCE);
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public InstrumentedType.WithFlexibleName subclass(String name, int modifiers, TypeDescription.Generic superClass) {
/*  477 */         return new InstrumentedType.Default(name, modifiers, superClass, 
/*      */ 
/*      */             
/*  480 */             Collections.emptyList(), 
/*  481 */             Collections.emptyList(), 
/*  482 */             Collections.emptyList(), 
/*  483 */             Collections.emptyMap(), 
/*  484 */             Collections.emptyList(), 
/*  485 */             Collections.emptyList(), 
/*  486 */             Collections.emptyList(), TypeInitializer.None.INSTANCE, (LoadedTypeInitializer)LoadedTypeInitializer.NoOp.INSTANCE, TypeDescription.UNDEFINED, MethodDescription.UNDEFINED, TypeDescription.UNDEFINED, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  492 */             Collections.emptyList(), (List<? extends TypeDescription>)TypeList.UNDEFINED, false, false, false, TargetType.DESCRIPTION, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  498 */             Collections.emptyList());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Default
/*      */     extends TypeDescription.AbstractBase.OfSimpleType
/*      */     implements WithFlexibleName
/*      */   {
/*  511 */     private static final Set<String> KEYWORDS = new HashSet<String>(Arrays.asList(new String[] { "abstract", "continue", "for", "new", "switch", "assert", "default", "goto", "package", "synchronized", "boolean", "do", "if", "private", "this", "break", "double", "implements", "protected", "throw", "byte", "else", "import", "public", "throws", "case", "enum", "instanceof", "return", "transient", "catch", "extends", "int", "short", "try", "char", "final", "interface", "static", "void", "class", "finally", "long", "strictfp", "volatile", "const", "float", "native", "super", "while" }));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int modifiers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     private final TypeDescription.Generic superClass;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends TypeVariableToken> typeVariables;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends TypeDescription.Generic> interfaceTypes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends FieldDescription.Token> fieldTokens;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Map<String, Object> auxiliaryFields;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends MethodDescription.Token> methodTokens;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends RecordComponentDescription.Token> recordComponentTokens;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends AnnotationDescription> annotationDescriptions;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TypeInitializer typeInitializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final LoadedTypeInitializer loadedTypeInitializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     private final TypeDescription declaringType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     private final MethodDescription.InDefinedShape enclosingMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     private final TypeDescription enclosingType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends TypeDescription> declaredTypes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     private final List<? extends TypeDescription> permittedSubclasses;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean anonymousClass;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean localClass;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean record;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TypeDescription nestHost;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final List<? extends TypeDescription> nestMembers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Default(String name, int modifiers, @MaybeNull TypeDescription.Generic superClass, List<? extends TypeVariableToken> typeVariables, List<? extends TypeDescription.Generic> interfaceTypes, List<? extends FieldDescription.Token> fieldTokens, Map<String, Object> auxiliaryFieldValues, List<? extends MethodDescription.Token> methodTokens, List<? extends RecordComponentDescription.Token> recordComponentTokens, List<? extends AnnotationDescription> annotationDescriptions, TypeInitializer typeInitializer, LoadedTypeInitializer loadedTypeInitializer, @MaybeNull TypeDescription declaringType, @MaybeNull MethodDescription.InDefinedShape enclosingMethod, @MaybeNull TypeDescription enclosingType, List<? extends TypeDescription> declaredTypes, @MaybeNull List<? extends TypeDescription> permittedSubclasses, boolean anonymousClass, boolean localClass, boolean record, TypeDescription nestHost, List<? extends TypeDescription> nestMembers) {
/*  682 */       this.name = name;
/*  683 */       this.modifiers = modifiers;
/*  684 */       this.typeVariables = typeVariables;
/*  685 */       this.superClass = superClass;
/*  686 */       this.interfaceTypes = interfaceTypes;
/*  687 */       this.fieldTokens = fieldTokens;
/*  688 */       this.auxiliaryFields = auxiliaryFieldValues;
/*  689 */       this.methodTokens = methodTokens;
/*  690 */       this.recordComponentTokens = recordComponentTokens;
/*  691 */       this.annotationDescriptions = annotationDescriptions;
/*  692 */       this.typeInitializer = typeInitializer;
/*  693 */       this.loadedTypeInitializer = loadedTypeInitializer;
/*  694 */       this.declaringType = declaringType;
/*  695 */       this.enclosingMethod = enclosingMethod;
/*  696 */       this.enclosingType = enclosingType;
/*  697 */       this.declaredTypes = declaredTypes;
/*  698 */       this.permittedSubclasses = permittedSubclasses;
/*  699 */       this.anonymousClass = anonymousClass;
/*  700 */       this.localClass = localClass;
/*  701 */       this.record = record;
/*  702 */       this.nestHost = nestHost;
/*  703 */       this.nestMembers = nestMembers;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static InstrumentedType of(String name, TypeDescription.Generic superClass, ModifierContributor.ForType... modifierContributor) {
/*  715 */       return of(name, superClass, ModifierContributor.Resolver.of(modifierContributor).resolve());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static InstrumentedType of(String name, TypeDescription.Generic superClass, int modifiers) {
/*  727 */       return InstrumentedType.Factory.Default.MODIFIABLE.subclass(name, modifiers, superClass);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withModifiers(int modifiers) {
/*  734 */       return new Default(this.name, modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withField(FieldDescription.Token token) {
/*  762 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  767 */           CompoundList.of(this.fieldTokens, token.accept(TypeDescription.Generic.Visitor.Substitutor.ForDetachment.of((TypeDefinition)this))), this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withAuxiliaryField(FieldDescription.Token token, Object value) {
/*  790 */       Map<String, Object> auxiliaryFields = new HashMap<String, Object>(this.auxiliaryFields);
/*  791 */       Object previous = auxiliaryFields.put(token.getName(), value);
/*  792 */       if (previous != null) {
/*  793 */         if (previous == value) {
/*  794 */           return this;
/*      */         }
/*  796 */         throw new IllegalStateException("Field " + token.getName() + " for " + this + " already mapped to " + previous + " and not " + value);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  802 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  807 */           CompoundList.of(this.fieldTokens, token.accept(TypeDescription.Generic.Visitor.Substitutor.ForDetachment.of((TypeDefinition)this))), auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, (LoadedTypeInitializer)new LoadedTypeInitializer.Compound(new LoadedTypeInitializer[] { this.loadedTypeInitializer, (LoadedTypeInitializer)new LoadedTypeInitializer.ForStaticField(token
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*  813 */                 .getName(), value) }), this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withMethod(MethodDescription.Token token) {
/*  830 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  837 */           CompoundList.of(this.methodTokens, token.accept(TypeDescription.Generic.Visitor.Substitutor.ForDetachment.of((TypeDefinition)this))), this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withRecordComponent(RecordComponentDescription.Token token) {
/*  858 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  866 */           CompoundList.of(this.recordComponentTokens, token.accept(TypeDescription.Generic.Visitor.Substitutor.ForDetachment.of((TypeDefinition)this))), this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, true, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withInterfaces(TypeList.Generic interfaceTypes) {
/*  886 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, 
/*      */ 
/*      */ 
/*      */           
/*  890 */           CompoundList.of(this.interfaceTypes, (List)interfaceTypes.accept(TypeDescription.Generic.Visitor.Substitutor.ForDetachment.of((TypeDefinition)this))), this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withAnnotations(List<? extends AnnotationDescription> annotationDescriptions) {
/*  914 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  923 */           CompoundList.of(this.annotationDescriptions, annotationDescriptions), this.typeInitializer, this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withNestHost(TypeDescription nestHost) {
/*  942 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  962 */           nestHost.equals(this) ? TargetType.DESCRIPTION : nestHost, 
/*      */ 
/*      */           
/*  965 */           Collections.emptyList());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withNestMembers(TypeList nestMembers) {
/*  972 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, TargetType.DESCRIPTION, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  993 */           CompoundList.of(this.nestMembers, (List)nestMembers));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withEnclosingType(@MaybeNull TypeDescription enclosingType) {
/* 1000 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, MethodDescription.UNDEFINED, enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withEnclosingMethod(MethodDescription.InDefinedShape enclosingMethod) {
/* 1028 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, enclosingMethod, enclosingMethod
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1042 */           .getDeclaringType(), this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withDeclaringType(@MaybeNull TypeDescription declaringType) {
/* 1056 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withDeclaredTypes(TypeList declaredTypes) {
/* 1084 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1099 */           CompoundList.of(this.declaredTypes, (List)declaredTypes), this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withPermittedSubclasses(@MaybeNull TypeList permittedSubclasses) {
/* 1112 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, (permittedSubclasses == null || this.permittedSubclasses == null) ? (List<? extends TypeDescription>)permittedSubclasses : 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1130 */           CompoundList.of(this.permittedSubclasses, (List)permittedSubclasses), this.anonymousClass, this.localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withTypeVariable(TypeVariableToken typeVariable) {
/* 1142 */       return new Default(this.name, this.modifiers, this.superClass, 
/*      */ 
/*      */           
/* 1145 */           CompoundList.of(this.typeVariables, typeVariable.accept(TypeDescription.Generic.Visitor.Substitutor.ForDetachment.of((TypeDefinition)this))), this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withName(String name) {
/* 1170 */       return new Default(name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withTypeVariables(ElementMatcher<? super TypeDescription.Generic> matcher, Transformer<TypeVariableToken> transformer) {
/* 1198 */       List<TypeVariableToken> typeVariables = new ArrayList<TypeVariableToken>(this.typeVariables.size());
/* 1199 */       int index = 0;
/* 1200 */       for (TypeVariableToken typeVariableToken : this.typeVariables) {
/* 1201 */         typeVariables.add(matcher.matches(getTypeVariables().get(index++)) ? (TypeVariableToken)transformer
/* 1202 */             .transform(this, typeVariableToken) : typeVariableToken);
/*      */       }
/*      */       
/* 1205 */       return new Default(this.name, this.modifiers, this.superClass, typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withLocalClass(boolean localClass) {
/* 1233 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, false, localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withAnonymousClass(boolean anonymousClass) {
/* 1261 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, anonymousClass, false, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withRecord(boolean record) {
/* 1289 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, record ? this.recordComponentTokens : 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1299 */           Collections.<RecordComponentDescription.Token>emptyList(), this.annotationDescriptions, this.typeInitializer, this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withInitializer(LoadedTypeInitializer loadedTypeInitializer) {
/* 1319 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer, (LoadedTypeInitializer)new LoadedTypeInitializer.Compound(new LoadedTypeInitializer[] { this.loadedTypeInitializer, loadedTypeInitializer }, ), this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withInitializer(ByteCodeAppender byteCodeAppender) {
/* 1347 */       return new Default(this.name, this.modifiers, this.superClass, this.typeVariables, this.interfaceTypes, this.fieldTokens, this.auxiliaryFields, this.methodTokens, this.recordComponentTokens, this.annotationDescriptions, this.typeInitializer
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1357 */           .expandWith(byteCodeAppender), this.loadedTypeInitializer, this.declaringType, this.enclosingMethod, this.enclosingType, this.declaredTypes, this.permittedSubclasses, this.anonymousClass, this.localClass, this.record, this.nestHost, this.nestMembers);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LoadedTypeInitializer getLoadedTypeInitializer() {
/* 1375 */       return this.loadedTypeInitializer;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeInitializer getTypeInitializer() {
/* 1382 */       return this.typeInitializer;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public MethodDescription.InDefinedShape getEnclosingMethod() {
/* 1390 */       return this.enclosingMethod;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public TypeDescription getEnclosingType() {
/* 1398 */       return this.enclosingType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList getDeclaredTypes() {
/* 1405 */       return (TypeList)new TypeList.Explicit(this.declaredTypes);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isAnonymousType() {
/* 1412 */       return this.anonymousClass;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isLocalType() {
/* 1419 */       return this.localClass;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public PackageDescription getPackage() {
/* 1427 */       int packageIndex = this.name.lastIndexOf('.');
/* 1428 */       return (packageIndex == -1) ? PackageDescription.DEFAULT : (PackageDescription)new PackageDescription.Simple(this.name
/*      */           
/* 1430 */           .substring(0, packageIndex));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationList getDeclaredAnnotations() {
/* 1437 */       return (AnnotationList)new AnnotationList.Explicit(this.annotationDescriptions);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public TypeDescription getDeclaringType() {
/* 1445 */       return this.declaringType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public TypeDescription.Generic getSuperClass() {
/* 1453 */       return (this.superClass == null) ? TypeDescription.Generic.UNDEFINED : (TypeDescription.Generic)new TypeDescription.Generic.LazyProjection.WithResolvedErasure(this.superClass, 
/*      */           
/* 1455 */           (TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Substitutor.ForAttachment.of(this));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList.Generic getInterfaces() {
/* 1462 */       return (TypeList.Generic)new TypeList.Generic.ForDetachedTypes.WithResolvedErasure(this.interfaceTypes, (TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Substitutor.ForAttachment.of(this));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public FieldList<FieldDescription.InDefinedShape> getDeclaredFields() {
/* 1469 */       return (FieldList<FieldDescription.InDefinedShape>)new FieldList.ForTokens(this, this.fieldTokens);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodList<MethodDescription.InDefinedShape> getDeclaredMethods() {
/* 1476 */       return (MethodList<MethodDescription.InDefinedShape>)new MethodList.ForTokens(this, this.methodTokens);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList.Generic getTypeVariables() {
/* 1483 */       return TypeList.Generic.ForDetachedTypes.attachVariables(this, this.typeVariables);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getModifiers() {
/* 1490 */       return this.modifiers;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getName() {
/* 1497 */       return this.name;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription getNestHost() {
/* 1504 */       return this.nestHost.represents(TargetType.class) ? this : this.nestHost;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList getNestMembers() {
/* 1513 */       return this.nestHost.represents(TargetType.class) ? (TypeList)new TypeList.Explicit(
/* 1514 */           CompoundList.of(this, this.nestMembers)) : this.nestHost
/* 1515 */         .getNestMembers();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public RecordComponentList<RecordComponentDescription.InDefinedShape> getRecordComponents() {
/* 1522 */       return (RecordComponentList<RecordComponentDescription.InDefinedShape>)new RecordComponentList.ForTokens(this, this.recordComponentTokens);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming super class for given instance.")
/*      */     public boolean isRecord() {
/* 1530 */       return (this.record && this.superClass != null && 
/*      */         
/* 1532 */         getSuperClass().asErasure().equals(JavaType.RECORD.getTypeStub()));
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isSealed() {
/* 1537 */       return (this.permittedSubclasses != null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList getPermittedSubtypes() {
/* 1544 */       return (this.permittedSubclasses == null) ? (TypeList)new TypeList.Empty() : (TypeList)new TypeList.Explicit(this.permittedSubclasses);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription validated() {
/* 1553 */       if (!isValidIdentifier(getName().split("\\.")))
/* 1554 */         throw new IllegalStateException("Illegal type name: " + getName() + " for " + this); 
/* 1555 */       if ((getModifiers() & 0xFFFD81E0) != 0)
/* 1556 */         throw new IllegalStateException("Illegal modifiers " + getModifiers() + " for " + this); 
/* 1557 */       if (isPackageType() && getModifiers() != 5632) {
/* 1558 */         throw new IllegalStateException("Illegal modifiers " + getModifiers() + " for package " + this);
/*      */       }
/* 1560 */       TypeDescription.Generic superClass = getSuperClass();
/* 1561 */       if (superClass != null) {
/* 1562 */         if (!((Boolean)superClass.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.SUPER_CLASS)).booleanValue())
/* 1563 */           throw new IllegalStateException("Illegal super class " + superClass + " for " + this); 
/* 1564 */         if (!((Boolean)superClass.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.ForTypeAnnotations.INSTANCE)).booleanValue())
/* 1565 */           throw new IllegalStateException("Illegal type annotations on super class " + superClass + " for " + this); 
/* 1566 */         if (!superClass.asErasure().isVisibleTo(this)) {
/* 1567 */           throw new IllegalStateException("Invisible super type " + superClass + " for " + this);
/*      */         }
/*      */       } 
/* 1570 */       Set<TypeDescription> interfaceErasures = new HashSet<TypeDescription>();
/* 1571 */       for (TypeDescription.Generic interfaceType : getInterfaces()) {
/* 1572 */         if (!((Boolean)interfaceType.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.INTERFACE)).booleanValue())
/* 1573 */           throw new IllegalStateException("Illegal interface " + interfaceType + " for " + this); 
/* 1574 */         if (!((Boolean)interfaceType.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.ForTypeAnnotations.INSTANCE)).booleanValue())
/* 1575 */           throw new IllegalStateException("Illegal type annotations on interface " + interfaceType + " for " + this); 
/* 1576 */         if (!interfaceErasures.add(interfaceType.asErasure()))
/* 1577 */           throw new IllegalStateException("Already implemented interface " + interfaceType + " for " + this); 
/* 1578 */         if (!interfaceType.asErasure().isVisibleTo(this)) {
/* 1579 */           throw new IllegalStateException("Invisible interface type " + interfaceType + " for " + this);
/*      */         }
/*      */       } 
/* 1582 */       TypeList.Generic typeVariables = getTypeVariables();
/* 1583 */       if (!typeVariables.isEmpty() && isAssignableTo(Throwable.class)) {
/* 1584 */         throw new IllegalStateException("Cannot define throwable " + this + " to be generic");
/*      */       }
/* 1586 */       Set<String> typeVariableNames = new HashSet<String>();
/* 1587 */       for (TypeDescription.Generic typeVariable : typeVariables) {
/* 1588 */         String variableSymbol = typeVariable.getSymbol();
/* 1589 */         if (!typeVariableNames.add(variableSymbol))
/* 1590 */           throw new IllegalStateException("Duplicate type variable symbol '" + typeVariable + "' for " + this); 
/* 1591 */         if (!isValidIdentifier(variableSymbol))
/* 1592 */           throw new IllegalStateException("Illegal type variable name '" + typeVariable + "' for " + this); 
/* 1593 */         if (!TypeDescription.Generic.Visitor.Validator.ForTypeAnnotations.ofFormalTypeVariable(typeVariable)) {
/* 1594 */           throw new IllegalStateException("Illegal type annotation on '" + typeVariable + "' for " + this);
/*      */         }
/* 1596 */         boolean interfaceBound = false;
/* 1597 */         Set<TypeDescription.Generic> bounds = new HashSet<TypeDescription.Generic>();
/* 1598 */         for (TypeDescription.Generic bound : typeVariable.getUpperBounds()) {
/* 1599 */           if (!((Boolean)bound.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.TYPE_VARIABLE)).booleanValue())
/* 1600 */             throw new IllegalStateException("Illegal type variable bound " + bound + " of " + typeVariable + " for " + this); 
/* 1601 */           if (!((Boolean)bound.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.ForTypeAnnotations.INSTANCE)).booleanValue())
/* 1602 */             throw new IllegalStateException("Illegal type annotations on type variable " + bound + " for " + this); 
/* 1603 */           if (!bounds.add(bound))
/* 1604 */             throw new IllegalStateException("Duplicate bound " + bound + " of " + typeVariable + " for " + this); 
/* 1605 */           if (interfaceBound && (bound.getSort().isTypeVariable() || !bound.isInterface())) {
/* 1606 */             throw new IllegalStateException("Illegal interface bound " + bound + " of " + typeVariable + " for " + this);
/*      */           }
/* 1608 */           interfaceBound = true;
/*      */         } 
/* 1610 */         if (!interfaceBound) {
/* 1611 */           throw new IllegalStateException("Type variable " + typeVariable + " for " + this + " does not define at least one bound");
/*      */         }
/*      */       } 
/* 1614 */       TypeDescription enclosingType = getEnclosingType();
/* 1615 */       if (enclosingType != null && (enclosingType.isArray() || enclosingType.isPrimitive())) {
/* 1616 */         throw new IllegalStateException("Cannot define array type or primitive type " + enclosingType + " + as enclosing type for " + this);
/*      */       }
/* 1618 */       MethodDescription.InDefinedShape enclosingMethod = getEnclosingMethod();
/* 1619 */       if (enclosingMethod != null && enclosingMethod.isTypeInitializer()) {
/* 1620 */         throw new IllegalStateException("Cannot enclose type declaration in class initializer " + enclosingMethod);
/*      */       }
/* 1622 */       TypeDescription declaringType = getDeclaringType();
/* 1623 */       if (declaringType != null) {
/* 1624 */         if (declaringType.isPrimitive() || declaringType.isArray()) {
/* 1625 */           throw new IllegalStateException("Cannot define array type or primitive type " + declaringType + " as declaring type for " + this);
/*      */         }
/* 1627 */       } else if (enclosingType == null && enclosingMethod == null && (isLocalType() || isAnonymousType())) {
/* 1628 */         throw new IllegalStateException("Cannot define an anonymous or local class without a declaring type for " + this);
/*      */       } 
/* 1630 */       Set<TypeDescription> declaredTypes = new HashSet<TypeDescription>();
/* 1631 */       for (TypeDescription declaredType : getDeclaredTypes()) {
/* 1632 */         if (declaredType.isArray() || declaredType.isPrimitive())
/* 1633 */           throw new IllegalStateException("Cannot define array type or primitive type " + declaredType + " + as declared type for " + this); 
/* 1634 */         if (!declaredTypes.add(declaredType)) {
/* 1635 */           throw new IllegalStateException("Duplicate definition of declared type " + declaredType);
/*      */         }
/*      */       } 
/* 1638 */       TypeDescription nestHost = getNestHost();
/* 1639 */       if (nestHost.equals(this)) {
/* 1640 */         Set<TypeDescription> nestMembers = new HashSet<TypeDescription>();
/* 1641 */         for (TypeDescription nestMember : getNestMembers()) {
/* 1642 */           if (nestMember.isArray() || nestMember.isPrimitive())
/* 1643 */             throw new IllegalStateException("Cannot define array type or primitive type " + nestMember + " + as nest member of " + this); 
/* 1644 */           if (!nestMember.isSamePackage(this))
/* 1645 */             throw new IllegalStateException("Cannot define nest member " + nestMember + " + within different package then " + this); 
/* 1646 */           if (!nestMembers.add(nestMember))
/* 1647 */             throw new IllegalStateException("Duplicate definition of nest member " + nestMember); 
/*      */         } 
/*      */       } else {
/* 1650 */         if (nestHost.isArray() || nestHost.isPrimitive())
/* 1651 */           throw new IllegalStateException("Cannot define array type or primitive type " + nestHost + " + as nest host for " + this); 
/* 1652 */         if (!nestHost.isSamePackage(this))
/* 1653 */           throw new IllegalStateException("Cannot define nest host " + nestHost + " within different package then " + this); 
/*      */       } 
/* 1655 */       for (TypeDescription permittedSubclass : getPermittedSubtypes()) {
/* 1656 */         if (!permittedSubclass.isAssignableTo(this) || permittedSubclass.equals(this)) {
/* 1657 */           throw new IllegalStateException("Cannot assign permitted subclass " + permittedSubclass + " to " + this);
/*      */         }
/*      */       } 
/* 1660 */       Set<TypeDescription> typeAnnotationTypes = new HashSet<TypeDescription>();
/* 1661 */       for (AnnotationDescription annotationDescription : getDeclaredAnnotations()) {
/* 1662 */         if (!annotationDescription.isSupportedOn(ElementType.TYPE) && (
/* 1663 */           !isAnnotation() || !annotationDescription.isSupportedOn(ElementType.ANNOTATION_TYPE)) && (
/* 1664 */           !isPackageType() || !annotationDescription.isSupportedOn(ElementType.PACKAGE)))
/* 1665 */           throw new IllegalStateException("Cannot add " + annotationDescription + " on " + this); 
/* 1666 */         if (!typeAnnotationTypes.add(annotationDescription.getAnnotationType())) {
/* 1667 */           throw new IllegalStateException("Duplicate annotation " + annotationDescription + " for " + this);
/*      */         }
/*      */       } 
/* 1670 */       Set<FieldDescription.SignatureToken> fieldSignatureTokens = new HashSet<FieldDescription.SignatureToken>();
/* 1671 */       for (FieldDescription.InDefinedShape fieldDescription : getDeclaredFields()) {
/* 1672 */         String fieldName = fieldDescription.getName();
/* 1673 */         if (!fieldSignatureTokens.add(fieldDescription.asSignatureToken()))
/* 1674 */           throw new IllegalStateException("Duplicate field definition for " + fieldDescription); 
/* 1675 */         if (!isValidUnqualifiedNameIdentifier(fieldName))
/* 1676 */           throw new IllegalStateException("Illegal field name for " + fieldDescription); 
/* 1677 */         if ((fieldDescription.getModifiers() & 0xFFFDAF20) != 0) {
/* 1678 */           throw new IllegalStateException("Illegal field modifiers " + fieldDescription.getModifiers() + " for " + fieldDescription);
/*      */         }
/* 1680 */         TypeDescription.Generic fieldType = fieldDescription.getType();
/* 1681 */         if (!((Boolean)fieldType.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.FIELD)).booleanValue())
/* 1682 */           throw new IllegalStateException("Illegal field type " + fieldType + " for " + fieldDescription); 
/* 1683 */         if (!((Boolean)fieldType.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.ForTypeAnnotations.INSTANCE)).booleanValue())
/* 1684 */           throw new IllegalStateException("Illegal type annotations on " + fieldType + " for " + this); 
/* 1685 */         if (!fieldDescription.isSynthetic() && !fieldType.asErasure().isVisibleTo(this)) {
/* 1686 */           throw new IllegalStateException("Invisible field type " + fieldDescription.getType() + " for " + fieldDescription);
/*      */         }
/* 1688 */         Set<TypeDescription> fieldAnnotationTypes = new HashSet<TypeDescription>();
/* 1689 */         for (AnnotationDescription annotationDescription : fieldDescription.getDeclaredAnnotations()) {
/* 1690 */           if (!annotationDescription.isSupportedOn(ElementType.FIELD))
/* 1691 */             throw new IllegalStateException("Cannot add " + annotationDescription + " on " + fieldDescription); 
/* 1692 */           if (!fieldAnnotationTypes.add(annotationDescription.getAnnotationType())) {
/* 1693 */             throw new IllegalStateException("Duplicate annotation " + annotationDescription + " for " + fieldDescription);
/*      */           }
/*      */         } 
/*      */       } 
/* 1697 */       Set<MethodDescription.SignatureToken> methodSignatureTokens = new HashSet<MethodDescription.SignatureToken>();
/* 1698 */       for (MethodDescription.InDefinedShape methodDescription : getDeclaredMethods()) {
/* 1699 */         if (!methodSignatureTokens.add(methodDescription.asSignatureToken()))
/* 1700 */           throw new IllegalStateException("Duplicate method signature for " + methodDescription); 
/* 1701 */         if ((methodDescription.getModifiers() & 0xFFFFE200) != 0)
/* 1702 */           throw new IllegalStateException("Illegal modifiers " + methodDescription.getModifiers() + " for " + methodDescription); 
/* 1703 */         if (methodDescription.isAbstract() && (methodDescription.getModifiers() & 0x800) != 0)
/* 1704 */           throw new IllegalStateException("Cannot declare strict computations for " + methodDescription); 
/* 1705 */         if (isInterface() && !methodDescription.isPublic() && !methodDescription.isPrivate()) {
/* 1706 */           throw new IllegalStateException("Methods declared by an interface must be public or private " + methodDescription);
/*      */         }
/* 1708 */         Set<String> methodTypeVariableNames = new HashSet<String>();
/* 1709 */         for (TypeDescription.Generic typeVariable : methodDescription.getTypeVariables()) {
/* 1710 */           String variableSymbol = typeVariable.getSymbol();
/* 1711 */           if (!methodTypeVariableNames.add(variableSymbol))
/* 1712 */             throw new IllegalStateException("Duplicate type variable symbol '" + typeVariable + "' for " + methodDescription); 
/* 1713 */           if (!isValidIdentifier(variableSymbol))
/* 1714 */             throw new IllegalStateException("Illegal type variable name '" + typeVariable + "' for " + methodDescription); 
/* 1715 */           if (!TypeDescription.Generic.Visitor.Validator.ForTypeAnnotations.ofFormalTypeVariable(typeVariable)) {
/* 1716 */             throw new IllegalStateException("Illegal type annotation on '" + typeVariable + "' for " + methodDescription);
/*      */           }
/* 1718 */           boolean interfaceBound = false;
/* 1719 */           Set<TypeDescription.Generic> bounds = new HashSet<TypeDescription.Generic>();
/* 1720 */           for (TypeDescription.Generic bound : typeVariable.getUpperBounds()) {
/* 1721 */             if (!((Boolean)bound.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.TYPE_VARIABLE)).booleanValue())
/* 1722 */               throw new IllegalStateException("Illegal type variable bound " + bound + " of " + typeVariable + " for " + methodDescription); 
/* 1723 */             if (!((Boolean)bound.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.ForTypeAnnotations.INSTANCE)).booleanValue())
/* 1724 */               throw new IllegalStateException("Illegal type annotations on bound " + bound + " of " + typeVariable + " for " + this); 
/* 1725 */             if (!bounds.add(bound))
/* 1726 */               throw new IllegalStateException("Duplicate bound " + bound + " of " + typeVariable + " for " + methodDescription); 
/* 1727 */             if (interfaceBound && (bound.getSort().isTypeVariable() || !bound.isInterface())) {
/* 1728 */               throw new IllegalStateException("Illegal interface bound " + bound + " of " + typeVariable + " for " + methodDescription);
/*      */             }
/* 1730 */             interfaceBound = true;
/*      */           } 
/* 1732 */           if (!interfaceBound) {
/* 1733 */             throw new IllegalStateException("Type variable " + typeVariable + " for " + methodDescription + " does not define at least one bound");
/*      */           }
/*      */         } 
/* 1736 */         TypeDescription.Generic returnType = methodDescription.getReturnType();
/* 1737 */         if (methodDescription.isTypeInitializer())
/* 1738 */           throw new IllegalStateException("Illegal explicit declaration of a type initializer by " + this); 
/* 1739 */         if (methodDescription.isConstructor()) {
/* 1740 */           if (!returnType.represents(void.class))
/* 1741 */             throw new IllegalStateException("A constructor must return void " + methodDescription); 
/* 1742 */           if (!returnType.getDeclaredAnnotations().isEmpty())
/* 1743 */             throw new IllegalStateException("The void non-type must not be annotated for " + methodDescription); 
/*      */         } else {
/* 1745 */           if (!isValidMethodIdentifier(methodDescription.getInternalName()))
/* 1746 */             throw new IllegalStateException("Illegal method name " + returnType + " for " + methodDescription); 
/* 1747 */           if (!((Boolean)returnType.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.METHOD_RETURN)).booleanValue())
/* 1748 */             throw new IllegalStateException("Illegal return type " + returnType + " for " + methodDescription); 
/* 1749 */           if (!((Boolean)returnType.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.ForTypeAnnotations.INSTANCE)).booleanValue())
/* 1750 */             throw new IllegalStateException("Illegal type annotations on return type " + returnType + " for " + methodDescription); 
/* 1751 */           if (!methodDescription.isSynthetic() && !methodDescription.getReturnType().asErasure().isVisibleTo(this))
/* 1752 */             throw new IllegalStateException("Invisible return type " + methodDescription.getReturnType() + " for " + methodDescription); 
/*      */         } 
/* 1754 */         Set<String> parameterNames = new HashSet<String>();
/* 1755 */         for (ParameterDescription.InDefinedShape parameterDescription : methodDescription.getParameters()) {
/* 1756 */           TypeDescription.Generic parameterType = parameterDescription.getType();
/* 1757 */           if (!((Boolean)parameterType.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.METHOD_PARAMETER)).booleanValue())
/* 1758 */             throw new IllegalStateException("Illegal parameter type of " + parameterDescription + " for " + methodDescription); 
/* 1759 */           if (!((Boolean)parameterType.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.ForTypeAnnotations.INSTANCE)).booleanValue())
/* 1760 */             throw new IllegalStateException("Illegal type annotations on parameter " + parameterDescription + " for " + methodDescription); 
/* 1761 */           if (!methodDescription.isSynthetic() && !parameterType.asErasure().isVisibleTo(this)) {
/* 1762 */             throw new IllegalStateException("Invisible parameter type of " + parameterDescription + " for " + methodDescription);
/*      */           }
/* 1764 */           if (parameterDescription.isNamed()) {
/* 1765 */             String parameterName = parameterDescription.getName();
/* 1766 */             if (!parameterNames.add(parameterName))
/* 1767 */               throw new IllegalStateException("Duplicate parameter name of " + parameterDescription + " for " + methodDescription); 
/* 1768 */             if (!isValidUnqualifiedNameIdentifier(parameterName)) {
/* 1769 */               throw new IllegalStateException("Illegal parameter name of " + parameterDescription + " for " + methodDescription);
/*      */             }
/*      */           } 
/* 1772 */           if (parameterDescription.hasModifiers() && (parameterDescription.getModifiers() & 0xFFFF6FEF) != 0) {
/* 1773 */             throw new IllegalStateException("Illegal modifiers of " + parameterDescription + " for " + methodDescription);
/*      */           }
/* 1775 */           Set<TypeDescription> parameterAnnotationTypes = new HashSet<TypeDescription>();
/* 1776 */           for (AnnotationDescription annotationDescription : parameterDescription.getDeclaredAnnotations()) {
/* 1777 */             if (!annotationDescription.isSupportedOn(ElementType.PARAMETER))
/* 1778 */               throw new IllegalStateException("Cannot add " + annotationDescription + " on " + parameterDescription); 
/* 1779 */             if (!parameterAnnotationTypes.add(annotationDescription.getAnnotationType())) {
/* 1780 */               throw new IllegalStateException("Duplicate annotation " + annotationDescription + " of " + parameterDescription + " for " + methodDescription);
/*      */             }
/*      */           } 
/*      */         } 
/* 1784 */         for (TypeDescription.Generic exceptionType : methodDescription.getExceptionTypes()) {
/* 1785 */           if (!((Boolean)exceptionType.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.EXCEPTION)).booleanValue())
/* 1786 */             throw new IllegalStateException("Illegal exception type " + exceptionType + " for " + methodDescription); 
/* 1787 */           if (!((Boolean)exceptionType.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.ForTypeAnnotations.INSTANCE)).booleanValue())
/* 1788 */             throw new IllegalStateException("Illegal type annotations on " + exceptionType + " for " + methodDescription); 
/* 1789 */           if (!methodDescription.isSynthetic() && !exceptionType.asErasure().isVisibleTo(this)) {
/* 1790 */             throw new IllegalStateException("Invisible exception type " + exceptionType + " for " + methodDescription);
/*      */           }
/*      */         } 
/* 1793 */         Set<TypeDescription> methodAnnotationTypes = new HashSet<TypeDescription>();
/* 1794 */         for (AnnotationDescription annotationDescription : methodDescription.getDeclaredAnnotations()) {
/* 1795 */           if (!annotationDescription.isSupportedOn(methodDescription.isMethod() ? ElementType.METHOD : ElementType.CONSTRUCTOR))
/* 1796 */             throw new IllegalStateException("Cannot add " + annotationDescription + " on " + methodDescription); 
/* 1797 */           if (!methodAnnotationTypes.add(annotationDescription.getAnnotationType())) {
/* 1798 */             throw new IllegalStateException("Duplicate annotation " + annotationDescription + " for " + methodDescription);
/*      */           }
/*      */         } 
/* 1801 */         AnnotationValue<?, ?> defaultValue = methodDescription.getDefaultValue();
/* 1802 */         if (defaultValue != null && !methodDescription.isDefaultValue(defaultValue)) {
/* 1803 */           throw new IllegalStateException("Illegal default value " + defaultValue + "for " + methodDescription);
/*      */         }
/* 1805 */         TypeDescription.Generic receiverType = methodDescription.getReceiverType();
/* 1806 */         if (receiverType != null && !((Boolean)receiverType.accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Validator.RECEIVER)).booleanValue())
/* 1807 */           throw new IllegalStateException("Illegal receiver type " + receiverType + " for " + methodDescription); 
/* 1808 */         if (methodDescription.isStatic()) {
/* 1809 */           if (receiverType != null)
/* 1810 */             throw new IllegalStateException("Static method " + methodDescription + " defines a non-null receiver " + receiverType);  continue;
/*      */         } 
/* 1812 */         if (methodDescription.isConstructor()) {
/* 1813 */           if (receiverType == null || !receiverType.asErasure().equals((enclosingType == null) ? this : enclosingType))
/* 1814 */             throw new IllegalStateException("Constructor " + methodDescription + " defines an illegal receiver " + receiverType);  continue;
/*      */         } 
/* 1816 */         if (receiverType == null || !equals(receiverType.asErasure())) {
/* 1817 */           throw new IllegalStateException("Method " + methodDescription + " defines an illegal receiver " + receiverType);
/*      */         }
/*      */       } 
/* 1820 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static boolean isValidIdentifier(String[] identifier) {
/* 1830 */       if (identifier.length == 0) {
/* 1831 */         return false;
/*      */       }
/* 1833 */       for (String part : identifier) {
/* 1834 */         if (!isValidIdentifier(part)) {
/* 1835 */           return false;
/*      */         }
/*      */       } 
/* 1838 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static boolean isValidIdentifier(String identifier) {
/* 1848 */       if (KEYWORDS.contains(identifier) || identifier
/* 1849 */         .length() == 0 || (
/* 1850 */         !Character.isJavaIdentifierStart(identifier.charAt(0)) && 
/* 1851 */         !Character.isUnicodeIdentifierStart(identifier.charAt(0))))
/* 1852 */         return false; 
/* 1853 */       if (identifier.equals("package-info")) {
/* 1854 */         return true;
/*      */       }
/* 1856 */       for (int index = 1; index < identifier.length(); index++) {
/* 1857 */         if (!Character.isJavaIdentifierPart(identifier.charAt(index)) && !Character.isUnicodeIdentifierPart(identifier.charAt(index))) {
/* 1858 */           return false;
/*      */         }
/*      */       } 
/* 1861 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static boolean isValidUnqualifiedNameIdentifier(String identifier) {
/* 1872 */       if (identifier.length() == 0) {
/* 1873 */         return false;
/*      */       }
/* 1875 */       for (int index = 0; index < identifier.length(); index++) {
/* 1876 */         switch (identifier.charAt(index)) {
/*      */           case '.':
/*      */           case '/':
/*      */           case ';':
/*      */           case '[':
/* 1881 */             return false;
/*      */         } 
/*      */       } 
/* 1884 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static boolean isValidMethodIdentifier(String identifier) {
/* 1894 */       if (identifier.length() == 0) {
/* 1895 */         return false;
/*      */       }
/* 1897 */       if (identifier.equals("<clinit>") || identifier
/* 1898 */         .equals("<init>")) {
/* 1899 */         return true;
/*      */       }
/* 1901 */       for (int index = 0; index < identifier.length(); index++) {
/* 1902 */         switch (identifier.charAt(index)) {
/*      */           case '.':
/*      */           case '/':
/*      */           case ';':
/*      */           case '<':
/*      */           case '>':
/*      */           case '[':
/* 1909 */             return false;
/*      */         } 
/*      */       } 
/* 1912 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class Frozen
/*      */     extends TypeDescription.AbstractBase.OfSimpleType
/*      */     implements WithFlexibleName
/*      */   {
/*      */     private final TypeDescription typeDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final LoadedTypeInitializer loadedTypeInitializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Frozen(TypeDescription typeDescription, LoadedTypeInitializer loadedTypeInitializer) {
/* 1938 */       this.typeDescription = typeDescription;
/* 1939 */       this.loadedTypeInitializer = loadedTypeInitializer;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public AnnotationList getDeclaredAnnotations() {
/* 1946 */       return this.typeDescription.getDeclaredAnnotations();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getModifiers() {
/* 1953 */       return this.typeDescription.getModifiers();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList.Generic getTypeVariables() {
/* 1960 */       return this.typeDescription.getTypeVariables();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getName() {
/* 1967 */       return this.typeDescription.getName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public TypeDescription.Generic getSuperClass() {
/* 1975 */       return this.typeDescription.getSuperClass();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList.Generic getInterfaces() {
/* 1982 */       return this.typeDescription.getInterfaces();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public FieldList<FieldDescription.InDefinedShape> getDeclaredFields() {
/* 1989 */       return this.typeDescription.getDeclaredFields();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodList<MethodDescription.InDefinedShape> getDeclaredMethods() {
/* 1996 */       return this.typeDescription.getDeclaredMethods();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isAnonymousType() {
/* 2003 */       return this.typeDescription.isAnonymousType();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isLocalType() {
/* 2010 */       return this.typeDescription.isLocalType();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public PackageDescription getPackage() {
/* 2018 */       return this.typeDescription.getPackage();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public TypeDescription getEnclosingType() {
/* 2026 */       return this.typeDescription.getEnclosingType();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public TypeDescription getDeclaringType() {
/* 2034 */       return this.typeDescription.getDeclaringType();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList getDeclaredTypes() {
/* 2041 */       return this.typeDescription.getDeclaredTypes();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public MethodDescription.InDefinedShape getEnclosingMethod() {
/* 2049 */       return this.typeDescription.getEnclosingMethod();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public String getGenericSignature() {
/* 2058 */       return this.typeDescription.getGenericSignature();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getActualModifiers(boolean superFlag) {
/* 2066 */       return this.typeDescription.getActualModifiers(superFlag);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription getNestHost() {
/* 2073 */       return this.typeDescription.getNestHost();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList getNestMembers() {
/* 2080 */       return this.typeDescription.getNestMembers();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public RecordComponentList<RecordComponentDescription.InDefinedShape> getRecordComponents() {
/* 2087 */       return this.typeDescription.getRecordComponents();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isRecord() {
/* 2094 */       return this.typeDescription.isRecord();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean isSealed() {
/* 2099 */       return this.typeDescription.isSealed();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeList getPermittedSubtypes() {
/* 2106 */       return this.typeDescription.getPermittedSubtypes();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withField(FieldDescription.Token token) {
/* 2113 */       throw new IllegalStateException("Cannot define field for frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withAuxiliaryField(FieldDescription.Token token, Object value) {
/* 2120 */       throw new IllegalStateException("Cannot define auxiliary field for frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withMethod(MethodDescription.Token token) {
/* 2127 */       throw new IllegalStateException("Cannot define method for frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withRecordComponent(RecordComponentDescription.Token token) {
/* 2134 */       throw new IllegalStateException("Cannot define record component for frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withModifiers(int modifiers) {
/* 2141 */       throw new IllegalStateException("Cannot change modifiers for frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withInterfaces(TypeList.Generic interfaceTypes) {
/* 2148 */       throw new IllegalStateException("Cannot add interfaces for frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withTypeVariable(TypeVariableToken typeVariable) {
/* 2155 */       throw new IllegalStateException("Cannot define type variable for frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withAnnotations(List<? extends AnnotationDescription> annotationDescriptions) {
/* 2162 */       throw new IllegalStateException("Cannot add annotation to frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withNestHost(TypeDescription nestHost) {
/* 2169 */       throw new IllegalStateException("Cannot set nest host of frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withNestMembers(TypeList nestMembers) {
/* 2176 */       throw new IllegalStateException("Cannot add nest members to frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withEnclosingType(@MaybeNull TypeDescription enclosingType) {
/* 2183 */       throw new IllegalStateException("Cannot set enclosing type of frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withEnclosingMethod(MethodDescription.InDefinedShape enclosingMethod) {
/* 2190 */       throw new IllegalStateException("Cannot set enclosing method of frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withDeclaringType(@MaybeNull TypeDescription declaringType) {
/* 2197 */       throw new IllegalStateException("Cannot add declaring type to frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withDeclaredTypes(TypeList declaredTypes) {
/* 2204 */       throw new IllegalStateException("Cannot add declared types to frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withPermittedSubclasses(@MaybeNull TypeList permittedSubclasses) {
/* 2211 */       throw new IllegalStateException("Cannot add permitted subclasses to frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withLocalClass(boolean localClass) {
/* 2218 */       throw new IllegalStateException("Cannot define local class state for frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withAnonymousClass(boolean anonymousClass) {
/* 2225 */       throw new IllegalStateException("Cannot define anonymous class state for frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withRecord(boolean record) {
/* 2232 */       throw new IllegalStateException("Cannot define record state for frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withInitializer(LoadedTypeInitializer loadedTypeInitializer) {
/* 2239 */       return new Frozen(this.typeDescription, (LoadedTypeInitializer)new LoadedTypeInitializer.Compound(new LoadedTypeInitializer[] { this.loadedTypeInitializer, loadedTypeInitializer }));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withInitializer(ByteCodeAppender byteCodeAppender) {
/* 2246 */       throw new IllegalStateException("Cannot add initializer to frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withName(String name) {
/* 2253 */       throw new IllegalStateException("Cannot change name of frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public InstrumentedType.WithFlexibleName withTypeVariables(ElementMatcher<? super TypeDescription.Generic> matcher, Transformer<TypeVariableToken> transformer) {
/* 2260 */       throw new IllegalStateException("Cannot add type variables of frozen type: " + this.typeDescription);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LoadedTypeInitializer getLoadedTypeInitializer() {
/* 2267 */       return this.loadedTypeInitializer;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeInitializer getTypeInitializer() {
/* 2274 */       return TypeInitializer.None.INSTANCE;
/*      */     }
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     public ClassFileVersion getClassFileVersion() {
/* 2280 */       return this.typeDescription.getClassFileVersion();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription validated() {
/* 2287 */       return this.typeDescription;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\scaffold\InstrumentedType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */