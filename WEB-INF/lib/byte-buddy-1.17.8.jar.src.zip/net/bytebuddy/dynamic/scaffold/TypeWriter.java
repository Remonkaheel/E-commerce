/*      */ package net.bytebuddy.dynamic.scaffold;
/*      */ 
/*      */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import javax.annotation.Nonnull;
/*      */ import net.bytebuddy.ClassFileVersion;
/*      */ import net.bytebuddy.asm.AsmVisitorWrapper;
/*      */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling;
/*      */ import net.bytebuddy.description.annotation.AnnotationList;
/*      */ import net.bytebuddy.description.annotation.AnnotationValue;
/*      */ import net.bytebuddy.description.field.FieldDescription;
/*      */ import net.bytebuddy.description.field.FieldList;
/*      */ import net.bytebuddy.description.method.MethodDescription;
/*      */ import net.bytebuddy.description.method.MethodList;
/*      */ import net.bytebuddy.description.method.ParameterDescription;
/*      */ import net.bytebuddy.description.method.ParameterList;
/*      */ import net.bytebuddy.description.modifier.ModifierContributor;
/*      */ import net.bytebuddy.description.modifier.Visibility;
/*      */ import net.bytebuddy.description.type.RecordComponentDescription;
/*      */ import net.bytebuddy.description.type.RecordComponentList;
/*      */ import net.bytebuddy.description.type.TypeDefinition;
/*      */ import net.bytebuddy.description.type.TypeDescription;
/*      */ import net.bytebuddy.description.type.TypeList;
/*      */ import net.bytebuddy.dynamic.ClassFileLocator;
/*      */ import net.bytebuddy.dynamic.DynamicType;
/*      */ import net.bytebuddy.dynamic.TypeResolutionStrategy;
/*      */ import net.bytebuddy.dynamic.scaffold.inline.MethodRebaseResolver;
/*      */ import net.bytebuddy.dynamic.scaffold.inline.RebaseImplementationTarget;
/*      */ import net.bytebuddy.dynamic.scaffold.subclass.SubclassImplementationTarget;
/*      */ import net.bytebuddy.implementation.Implementation;
/*      */ import net.bytebuddy.implementation.LoadedTypeInitializer;
/*      */ import net.bytebuddy.implementation.attribute.AnnotationAppender;
/*      */ import net.bytebuddy.implementation.attribute.AnnotationRetention;
/*      */ import net.bytebuddy.implementation.attribute.AnnotationValueFilter;
/*      */ import net.bytebuddy.implementation.attribute.FieldAttributeAppender;
/*      */ import net.bytebuddy.implementation.attribute.MethodAttributeAppender;
/*      */ import net.bytebuddy.implementation.attribute.RecordComponentAttributeAppender;
/*      */ import net.bytebuddy.implementation.attribute.TypeAttributeAppender;
/*      */ import net.bytebuddy.implementation.auxiliary.AuxiliaryType;
/*      */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*      */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*      */ import net.bytebuddy.implementation.bytecode.assign.TypeCasting;
/*      */ import net.bytebuddy.implementation.bytecode.constant.DefaultValue;
/*      */ import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
/*      */ import net.bytebuddy.implementation.bytecode.member.MethodReturn;
/*      */ import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;
/*      */ import net.bytebuddy.jar.asm.AnnotationVisitor;
/*      */ import net.bytebuddy.jar.asm.ClassVisitor;
/*      */ import net.bytebuddy.jar.asm.FieldVisitor;
/*      */ import net.bytebuddy.jar.asm.Handle;
/*      */ import net.bytebuddy.jar.asm.Label;
/*      */ import net.bytebuddy.jar.asm.MethodVisitor;
/*      */ import net.bytebuddy.jar.asm.Opcodes;
/*      */ import net.bytebuddy.jar.asm.RecordComponentVisitor;
/*      */ import net.bytebuddy.jar.asm.Type;
/*      */ import net.bytebuddy.jar.asm.TypePath;
/*      */ import net.bytebuddy.jar.asm.commons.ClassRemapper;
/*      */ import net.bytebuddy.jar.asm.commons.Remapper;
/*      */ import net.bytebuddy.jar.asm.commons.SimpleRemapper;
/*      */ import net.bytebuddy.matcher.ElementMatcher;
/*      */ import net.bytebuddy.matcher.ElementMatchers;
/*      */ import net.bytebuddy.pool.TypePool;
/*      */ import net.bytebuddy.utility.AsmClassReader;
/*      */ import net.bytebuddy.utility.AsmClassWriter;
/*      */ import net.bytebuddy.utility.CompoundList;
/*      */ import net.bytebuddy.utility.OpenedClassReader;
/*      */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ import net.bytebuddy.utility.nullability.UnknownNull;
/*      */ import net.bytebuddy.utility.privilege.GetSystemPropertyAction;
/*      */ import net.bytebuddy.utility.visitor.ContextClassVisitor;
/*      */ import net.bytebuddy.utility.visitor.MetadataAwareClassVisitor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface TypeWriter<T>
/*      */ {
/*      */   public static final String DUMP_PROPERTY = "net.bytebuddy.dump";
/*      */   
/*      */   DynamicType.Unloaded<T> make(TypeResolutionStrategy.Resolved paramResolved);
/*      */   
/*      */   ContextClassVisitor wrap(ClassVisitor paramClassVisitor, int paramInt1, int paramInt2);
/*      */   
/*      */   public static interface FieldPool
/*      */   {
/*      */     Record target(FieldDescription param1FieldDescription);
/*      */     
/*      */     public static interface Record
/*      */     {
/*      */       boolean isImplicit();
/*      */       
/*      */       FieldDescription getField();
/*      */       
/*      */       FieldAttributeAppender getFieldAppender();
/*      */       
/*      */       @MaybeNull
/*      */       Object resolveDefault(@MaybeNull Object param2Object);
/*      */       
/*      */       void apply(ClassVisitor param2ClassVisitor, AnnotationValueFilter.Factory param2Factory);
/*      */       
/*      */       void apply(FieldVisitor param2FieldVisitor, AnnotationValueFilter.Factory param2Factory);
/*      */       
/*      */       @Enhance
/*      */       public static class ForImplicitField
/*      */         implements Record
/*      */       {
/*      */         private final FieldDescription fieldDescription;
/*      */         
/*      */         public ForImplicitField(FieldDescription fieldDescription) {
/*  193 */           this.fieldDescription = fieldDescription;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isImplicit() {
/*  200 */           return true;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public FieldDescription getField() {
/*  207 */           return this.fieldDescription;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public FieldAttributeAppender getFieldAppender() {
/*  214 */           throw new IllegalStateException("An implicit field record does not expose a field appender: " + this);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Object resolveDefault(@MaybeNull Object defaultValue) {
/*  221 */           throw new IllegalStateException("An implicit field record does not expose a default value: " + this);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void apply(ClassVisitor classVisitor, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/*  228 */           FieldVisitor fieldVisitor = classVisitor.visitField(this.fieldDescription.getActualModifiers(), this.fieldDescription
/*  229 */               .getInternalName(), this.fieldDescription
/*  230 */               .getDescriptor(), this.fieldDescription
/*  231 */               .getGenericSignature(), FieldDescription.NO_DEFAULT_VALUE);
/*      */           
/*  233 */           if (fieldVisitor != null) {
/*  234 */             FieldAttributeAppender.ForInstrumentedField.INSTANCE.apply(fieldVisitor, this.fieldDescription, annotationValueFilterFactory
/*      */                 
/*  236 */                 .on(this.fieldDescription));
/*  237 */             fieldVisitor.visitEnd();
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void apply(FieldVisitor fieldVisitor, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/*  245 */           throw new IllegalStateException("An implicit field record is not intended for partial application: " + this);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.fieldDescription.equals(((ForImplicitField)param3Object).fieldDescription))));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return getClass().hashCode() * 31 + this.fieldDescription.hashCode();
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static class ForExplicitField
/*      */         implements Record
/*      */       {
/*      */         private final FieldAttributeAppender attributeAppender;
/*      */ 
/*      */         
/*      */         @MaybeNull
/*      */         @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*      */         private final Object defaultValue;
/*      */ 
/*      */         
/*      */         private final FieldDescription fieldDescription;
/*      */ 
/*      */ 
/*      */         
/*      */         public ForExplicitField(FieldAttributeAppender attributeAppender, @MaybeNull Object defaultValue, FieldDescription fieldDescription) {
/*  282 */           this.attributeAppender = attributeAppender;
/*  283 */           this.defaultValue = defaultValue;
/*  284 */           this.fieldDescription = fieldDescription;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isImplicit() {
/*  291 */           return false;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public FieldDescription getField() {
/*  298 */           return this.fieldDescription;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public FieldAttributeAppender getFieldAppender() {
/*  305 */           return this.attributeAppender;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @MaybeNull
/*      */         public Object resolveDefault(@MaybeNull Object defaultValue) {
/*  313 */           return (this.defaultValue == null) ? defaultValue : this.defaultValue;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void apply(ClassVisitor classVisitor, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/*  322 */           FieldVisitor fieldVisitor = classVisitor.visitField(this.fieldDescription.getActualModifiers(), this.fieldDescription
/*  323 */               .getInternalName(), this.fieldDescription
/*  324 */               .getDescriptor(), this.fieldDescription
/*  325 */               .getGenericSignature(), 
/*  326 */               resolveDefault(FieldDescription.NO_DEFAULT_VALUE));
/*  327 */           if (fieldVisitor != null) {
/*  328 */             this.attributeAppender.apply(fieldVisitor, this.fieldDescription, annotationValueFilterFactory.on(this.fieldDescription));
/*  329 */             fieldVisitor.visitEnd();
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void apply(FieldVisitor fieldVisitor, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/*  337 */           this.attributeAppender.apply(fieldVisitor, this.fieldDescription, annotationValueFilterFactory.on(this.fieldDescription));
/*      */         } public boolean equals(@MaybeNull Object param3Object) { if (this == param3Object)
/*      */             return true;  if (param3Object == null)
/*      */             return false;  if (getClass() != param3Object.getClass())
/*      */             return false;  if (!this.attributeAppender.equals(((ForExplicitField)param3Object).attributeAppender))
/*      */             return false;  Object object1 = ((ForExplicitField)param3Object).defaultValue; Object object2 = this.defaultValue; if (object1 != null) { if (object2 != null) { if (!object2.equals(object1))
/*      */                 return false;  }
/*      */             else
/*      */             { return false; }
/*      */              }
/*      */           else if (object2 != null)
/*      */           { return false; }
/*      */            return !!this.fieldDescription.equals(((ForExplicitField)param3Object).fieldDescription); } public int hashCode() { Object object = this.defaultValue; if (object != null); return ((getClass().hashCode() * 31 + this.attributeAppender.hashCode()) * 31 + object.hashCode()) * 31 + this.fieldDescription.hashCode(); } } }
/*  350 */     public enum Disabled implements FieldPool { INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeWriter.FieldPool.Record target(FieldDescription fieldDescription) {
/*  356 */         throw new IllegalStateException("Cannot look up field from disabled pool");
/*      */       } }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface MethodPool
/*      */   {
/*      */     Record target(MethodDescription param1MethodDescription);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static interface Record
/*      */     {
/*      */       Sort getSort();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       MethodDescription getMethod();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Visibility getVisibility();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Record prepend(ByteCodeAppender param2ByteCodeAppender);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       void apply(ClassVisitor param2ClassVisitor, Implementation.Context param2Context, AnnotationValueFilter.Factory param2Factory);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       void applyHead(MethodVisitor param2MethodVisitor);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       void applyBody(MethodVisitor param2MethodVisitor, Implementation.Context param2Context, AnnotationValueFilter.Factory param2Factory);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       void applyAttributes(MethodVisitor param2MethodVisitor, AnnotationValueFilter.Factory param2Factory);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       ByteCodeAppender.Size applyCode(MethodVisitor param2MethodVisitor, Implementation.Context param2Context);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public enum Sort
/*      */       {
/*  465 */         SKIPPED(false, false),
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  470 */         DEFINED(true, false),
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  475 */         IMPLEMENTED(true, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final boolean define;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final boolean implement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         Sort(boolean define, boolean implement) {
/*  494 */           this.define = define;
/*  495 */           this.implement = implement;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isDefined() {
/*  504 */           return this.define;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isImplemented() {
/*  513 */           return this.implement;
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static class ForNonImplementedMethod
/*      */         implements Record
/*      */       {
/*      */         private final MethodDescription methodDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public ForNonImplementedMethod(MethodDescription methodDescription) {
/*  534 */           this.methodDescription = methodDescription;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void apply(ClassVisitor classVisitor, Implementation.Context implementationContext, AnnotationValueFilter.Factory annotationValueFilterFactory) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void applyBody(MethodVisitor methodVisitor, Implementation.Context implementationContext, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/*  548 */           throw new IllegalStateException("Cannot apply body for non-implemented method on " + this.methodDescription);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void applyAttributes(MethodVisitor methodVisitor, AnnotationValueFilter.Factory annotationValueFilterFactory) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public ByteCodeAppender.Size applyCode(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/*  562 */           throw new IllegalStateException("Cannot apply code for non-implemented method on " + this.methodDescription);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void applyHead(MethodVisitor methodVisitor) {
/*  569 */           throw new IllegalStateException("Cannot apply head for non-implemented method on " + this.methodDescription);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public MethodDescription getMethod() {
/*  576 */           return this.methodDescription;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Visibility getVisibility() {
/*  583 */           return this.methodDescription.getVisibility();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TypeWriter.MethodPool.Record.Sort getSort() {
/*  590 */           return TypeWriter.MethodPool.Record.Sort.SKIPPED;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TypeWriter.MethodPool.Record prepend(ByteCodeAppender byteCodeAppender) {
/*  597 */           return new TypeWriter.MethodPool.Record.ForDefinedMethod.WithBody(this.methodDescription, (ByteCodeAppender)new ByteCodeAppender.Compound(new ByteCodeAppender[] { byteCodeAppender, (ByteCodeAppender)new ByteCodeAppender.Simple(new StackManipulation[] {
/*  598 */                       DefaultValue.of((TypeDefinition)this.methodDescription.getReturnType()), MethodReturn.of((TypeDefinition)this.methodDescription.getReturnType()) }) }));
/*      */         }
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.methodDescription.equals(((ForNonImplementedMethod)param3Object).methodDescription))));
/*      */         }
/*      */         
/*      */         public int hashCode() {
/*      */           return getClass().hashCode() * 31 + this.methodDescription.hashCode();
/*      */         } }
/*      */       
/*      */       public static abstract class ForDefinedMethod implements Record {
/*      */         public void apply(ClassVisitor classVisitor, Implementation.Context implementationContext, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/*  611 */           MethodVisitor methodVisitor = classVisitor.visitMethod(getMethod().getActualModifiers(getSort().isImplemented(), getVisibility()), 
/*  612 */               getMethod().getInternalName(), 
/*  613 */               getMethod().getDescriptor(), 
/*  614 */               getMethod().getGenericSignature(), 
/*  615 */               getMethod().getExceptionTypes().asErasures().toInternalNames());
/*  616 */           if (methodVisitor != null) {
/*  617 */             ParameterList<?> parameterList = getMethod().getParameters();
/*  618 */             if (parameterList.hasExplicitMetaData()) {
/*  619 */               for (ParameterDescription parameterDescription : parameterList) {
/*  620 */                 methodVisitor.visitParameter(parameterDescription.getName(), parameterDescription.getModifiers());
/*      */               }
/*      */             }
/*  623 */             applyHead(methodVisitor);
/*  624 */             applyBody(methodVisitor, implementationContext, annotationValueFilterFactory);
/*  625 */             methodVisitor.visitEnd();
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         public static class WithBody
/*      */           extends ForDefinedMethod
/*      */         {
/*      */           private final MethodDescription methodDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final ByteCodeAppender byteCodeAppender;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final MethodAttributeAppender methodAttributeAppender;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final Visibility visibility;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public WithBody(MethodDescription methodDescription, ByteCodeAppender byteCodeAppender) {
/*  662 */             this(methodDescription, byteCodeAppender, (MethodAttributeAppender)MethodAttributeAppender.NoOp.INSTANCE, methodDescription.getVisibility());
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public WithBody(MethodDescription methodDescription, ByteCodeAppender byteCodeAppender, MethodAttributeAppender methodAttributeAppender, Visibility visibility) {
/*  677 */             this.methodDescription = methodDescription;
/*  678 */             this.byteCodeAppender = byteCodeAppender;
/*  679 */             this.methodAttributeAppender = methodAttributeAppender;
/*  680 */             this.visibility = visibility;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MethodDescription getMethod() {
/*  687 */             return this.methodDescription;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeWriter.MethodPool.Record.Sort getSort() {
/*  694 */             return TypeWriter.MethodPool.Record.Sort.IMPLEMENTED;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Visibility getVisibility() {
/*  701 */             return this.visibility;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void applyHead(MethodVisitor methodVisitor) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void applyBody(MethodVisitor methodVisitor, Implementation.Context implementationContext, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/*  715 */             applyAttributes(methodVisitor, annotationValueFilterFactory);
/*  716 */             methodVisitor.visitCode();
/*  717 */             ByteCodeAppender.Size size = applyCode(methodVisitor, implementationContext);
/*  718 */             methodVisitor.visitMaxs(size.getOperandStackSize(), size.getLocalVariableSize());
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void applyAttributes(MethodVisitor methodVisitor, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/*  725 */             this.methodAttributeAppender.apply(methodVisitor, this.methodDescription, annotationValueFilterFactory.on(this.methodDescription));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public ByteCodeAppender.Size applyCode(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/*  732 */             return this.byteCodeAppender.apply(methodVisitor, implementationContext, this.methodDescription);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeWriter.MethodPool.Record prepend(ByteCodeAppender byteCodeAppender) {
/*  739 */             return new WithBody(this.methodDescription, (ByteCodeAppender)new ByteCodeAppender.Compound(new ByteCodeAppender[] { byteCodeAppender, this.byteCodeAppender }, ), this.methodAttributeAppender, this.visibility);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.visibility.equals(((WithBody)param4Object).visibility) ? false : (!this.methodDescription.equals(((WithBody)param4Object).methodDescription) ? false : (!this.byteCodeAppender.equals(((WithBody)param4Object).byteCodeAppender) ? false : (!!this.methodAttributeAppender.equals(((WithBody)param4Object).methodAttributeAppender)))))));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return (((getClass().hashCode() * 31 + this.methodDescription.hashCode()) * 31 + this.byteCodeAppender.hashCode()) * 31 + this.methodAttributeAppender.hashCode()) * 31 + this.visibility.hashCode();
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         public static class WithoutBody
/*      */           extends ForDefinedMethod
/*      */         {
/*      */           private final MethodDescription methodDescription;
/*      */ 
/*      */           
/*      */           private final MethodAttributeAppender methodAttributeAppender;
/*      */ 
/*      */           
/*      */           private final Visibility visibility;
/*      */ 
/*      */ 
/*      */           
/*      */           public WithoutBody(MethodDescription methodDescription, MethodAttributeAppender methodAttributeAppender, Visibility visibility) {
/*  775 */             this.methodDescription = methodDescription;
/*  776 */             this.methodAttributeAppender = methodAttributeAppender;
/*  777 */             this.visibility = visibility;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MethodDescription getMethod() {
/*  784 */             return this.methodDescription;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeWriter.MethodPool.Record.Sort getSort() {
/*  791 */             return TypeWriter.MethodPool.Record.Sort.DEFINED;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Visibility getVisibility() {
/*  798 */             return this.visibility;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void applyHead(MethodVisitor methodVisitor) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void applyBody(MethodVisitor methodVisitor, Implementation.Context implementationContext, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/*  812 */             applyAttributes(methodVisitor, annotationValueFilterFactory);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void applyAttributes(MethodVisitor methodVisitor, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/*  819 */             this.methodAttributeAppender.apply(methodVisitor, this.methodDescription, annotationValueFilterFactory.on(this.methodDescription));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public ByteCodeAppender.Size applyCode(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/*  826 */             throw new IllegalStateException("Cannot apply code for abstract method on " + this.methodDescription);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeWriter.MethodPool.Record prepend(ByteCodeAppender byteCodeAppender) {
/*  833 */             throw new IllegalStateException("Cannot prepend code for abstract method on " + this.methodDescription);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.visibility.equals(((WithoutBody)param4Object).visibility) ? false : (!this.methodDescription.equals(((WithoutBody)param4Object).methodDescription) ? false : (!!this.methodAttributeAppender.equals(((WithoutBody)param4Object).methodAttributeAppender))))));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return ((getClass().hashCode() * 31 + this.methodDescription.hashCode()) * 31 + this.methodAttributeAppender.hashCode()) * 31 + this.visibility.hashCode();
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         public static class WithAnnotationDefaultValue
/*      */           extends ForDefinedMethod
/*      */         {
/*      */           private final MethodDescription methodDescription;
/*      */ 
/*      */           
/*      */           private final AnnotationValue<?, ?> annotationValue;
/*      */ 
/*      */           
/*      */           private final MethodAttributeAppender methodAttributeAppender;
/*      */ 
/*      */ 
/*      */           
/*      */           public WithAnnotationDefaultValue(MethodDescription methodDescription, AnnotationValue<?, ?> annotationValue, MethodAttributeAppender methodAttributeAppender) {
/*  868 */             this.methodDescription = methodDescription;
/*  869 */             this.annotationValue = annotationValue;
/*  870 */             this.methodAttributeAppender = methodAttributeAppender;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MethodDescription getMethod() {
/*  877 */             return this.methodDescription;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeWriter.MethodPool.Record.Sort getSort() {
/*  884 */             return TypeWriter.MethodPool.Record.Sort.DEFINED;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Visibility getVisibility() {
/*  891 */             return this.methodDescription.getVisibility();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void applyHead(MethodVisitor methodVisitor) {
/*  898 */             if (!this.methodDescription.isDefaultValue(this.annotationValue)) {
/*  899 */               throw new IllegalStateException("Cannot set " + this.annotationValue + " as default for " + this.methodDescription);
/*      */             }
/*  901 */             AnnotationVisitor annotationVisitor = methodVisitor.visitAnnotationDefault();
/*  902 */             AnnotationAppender.Default.apply(annotationVisitor, this.methodDescription
/*  903 */                 .getReturnType().asErasure(), AnnotationAppender.NO_NAME, this.annotationValue
/*      */                 
/*  905 */                 .resolve());
/*  906 */             annotationVisitor.visitEnd();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void applyBody(MethodVisitor methodVisitor, Implementation.Context implementationContext, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/*  913 */             this.methodAttributeAppender.apply(methodVisitor, this.methodDescription, annotationValueFilterFactory.on(this.methodDescription));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void applyAttributes(MethodVisitor methodVisitor, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/*  920 */             throw new IllegalStateException("Cannot apply attributes for default value on " + this.methodDescription);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public ByteCodeAppender.Size applyCode(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/*  927 */             throw new IllegalStateException("Cannot apply code for default value on " + this.methodDescription);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeWriter.MethodPool.Record prepend(ByteCodeAppender byteCodeAppender) {
/*  934 */             throw new IllegalStateException("Cannot prepend code for default value on " + this.methodDescription);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.methodDescription.equals(((WithAnnotationDefaultValue)param4Object).methodDescription) ? false : (!this.annotationValue.equals(((WithAnnotationDefaultValue)param4Object).annotationValue) ? false : (!!this.methodAttributeAppender.equals(((WithAnnotationDefaultValue)param4Object).methodAttributeAppender))))));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return ((getClass().hashCode() * 31 + this.methodDescription.hashCode()) * 31 + this.annotationValue.hashCode()) * 31 + this.methodAttributeAppender.hashCode();
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         public static class OfVisibilityBridge
/*      */           extends ForDefinedMethod
/*      */           implements ByteCodeAppender
/*      */         {
/*      */           private final MethodDescription visibilityBridge;
/*      */ 
/*      */ 
/*      */           
/*      */           private final MethodDescription bridgeTarget;
/*      */ 
/*      */ 
/*      */           
/*      */           private final TypeDescription bridgeType;
/*      */ 
/*      */           
/*      */           private final MethodAttributeAppender attributeAppender;
/*      */ 
/*      */ 
/*      */           
/*      */           protected OfVisibilityBridge(MethodDescription visibilityBridge, MethodDescription bridgeTarget, TypeDescription bridgeType, MethodAttributeAppender attributeAppender) {
/*  976 */             this.visibilityBridge = visibilityBridge;
/*  977 */             this.bridgeTarget = bridgeTarget;
/*  978 */             this.bridgeType = bridgeType;
/*  979 */             this.attributeAppender = attributeAppender;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static TypeWriter.MethodPool.Record of(TypeDescription instrumentedType, MethodDescription bridgeTarget, MethodAttributeAppender attributeAppender) {
/*      */             TypeDescription typeDescription;
/*  992 */             TypeDefinition bridgeType = null;
/*  993 */             if (bridgeTarget.isDefaultMethod()) {
/*  994 */               TypeDescription declaringType = bridgeTarget.getDeclaringType().asErasure();
/*  995 */               for (TypeDescription interfaceType : instrumentedType.getInterfaces().asErasures().filter((ElementMatcher)ElementMatchers.isSubTypeOf(declaringType))) {
/*  996 */                 if (bridgeType == null || declaringType.isAssignableTo(bridgeType.asErasure())) {
/*  997 */                   typeDescription = interfaceType;
/*      */                 }
/*      */               } 
/*      */             } 
/*      */             
/* 1002 */             if (typeDescription == null) {
/* 1003 */               TypeDescription.Generic generic = instrumentedType.getSuperClass();
/* 1004 */               if (generic == null) {
/* 1005 */                 typeDescription = TypeDescription.ForLoadedType.of(Object.class);
/*      */               }
/*      */             } 
/* 1008 */             return new OfVisibilityBridge((MethodDescription)new VisibilityBridge(instrumentedType, bridgeTarget), bridgeTarget, typeDescription
/*      */                 
/* 1010 */                 .asErasure(), attributeAppender);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MethodDescription getMethod() {
/* 1018 */             return this.visibilityBridge;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeWriter.MethodPool.Record.Sort getSort() {
/* 1025 */             return TypeWriter.MethodPool.Record.Sort.IMPLEMENTED;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Visibility getVisibility() {
/* 1032 */             return this.bridgeTarget.getVisibility();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeWriter.MethodPool.Record prepend(ByteCodeAppender byteCodeAppender) {
/* 1039 */             return new TypeWriter.MethodPool.Record.ForDefinedMethod.WithBody(this.visibilityBridge, (ByteCodeAppender)new ByteCodeAppender.Compound(new ByteCodeAppender[] { this, byteCodeAppender }, ), this.attributeAppender, this.bridgeTarget
/*      */ 
/*      */                 
/* 1042 */                 .getVisibility());
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void applyHead(MethodVisitor methodVisitor) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void applyBody(MethodVisitor methodVisitor, Implementation.Context implementationContext, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/* 1056 */             applyAttributes(methodVisitor, annotationValueFilterFactory);
/* 1057 */             methodVisitor.visitCode();
/* 1058 */             ByteCodeAppender.Size size = applyCode(methodVisitor, implementationContext);
/* 1059 */             methodVisitor.visitMaxs(size.getOperandStackSize(), size.getLocalVariableSize());
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void applyAttributes(MethodVisitor methodVisitor, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/* 1066 */             this.attributeAppender.apply(methodVisitor, this.visibilityBridge, annotationValueFilterFactory.on(this.visibilityBridge));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public ByteCodeAppender.Size applyCode(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 1073 */             return apply(methodVisitor, implementationContext, this.visibilityBridge);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/* 1080 */             return (new ByteCodeAppender.Simple(new StackManipulation[] {
/* 1081 */                   MethodVariableAccess.allArgumentsOf(instrumentedMethod).prependThisReference(), 
/* 1082 */                   MethodInvocation.invoke(this.bridgeTarget).special(this.bridgeType), 
/* 1083 */                   MethodReturn.of((TypeDefinition)instrumentedMethod.getReturnType())
/* 1084 */                 })).apply(methodVisitor, implementationContext, instrumentedMethod);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.visibilityBridge.equals(((OfVisibilityBridge)param4Object).visibilityBridge) ? false : (!this.bridgeTarget.equals(((OfVisibilityBridge)param4Object).bridgeTarget) ? false : (!this.bridgeType.equals(((OfVisibilityBridge)param4Object).bridgeType) ? false : (!!this.attributeAppender.equals(((OfVisibilityBridge)param4Object).attributeAppender)))))));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return (((getClass().hashCode() * 31 + this.visibilityBridge.hashCode()) * 31 + this.bridgeTarget.hashCode()) * 31 + this.bridgeType.hashCode()) * 31 + this.attributeAppender.hashCode();
/*      */           }
/*      */ 
/*      */           
/*      */           protected static class VisibilityBridge
/*      */             extends MethodDescription.InDefinedShape.AbstractBase
/*      */           {
/*      */             private final TypeDescription instrumentedType;
/*      */             
/*      */             private final MethodDescription bridgeTarget;
/*      */ 
/*      */             
/*      */             protected VisibilityBridge(TypeDescription instrumentedType, MethodDescription bridgeTarget) {
/* 1109 */               this.instrumentedType = instrumentedType;
/* 1110 */               this.bridgeTarget = bridgeTarget;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @Nonnull
/*      */             public TypeDescription getDeclaringType() {
/* 1118 */               return this.instrumentedType;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public ParameterList<ParameterDescription.InDefinedShape> getParameters() {
/* 1125 */               return (ParameterList<ParameterDescription.InDefinedShape>)new ParameterList.Explicit.ForTypes((MethodDescription.InDefinedShape)this, (List)this.bridgeTarget.getParameters().asTypeList().asRawTypes());
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public TypeDescription.Generic getReturnType() {
/* 1132 */               return this.bridgeTarget.getReturnType().asRawType();
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public TypeList.Generic getExceptionTypes() {
/* 1139 */               return this.bridgeTarget.getExceptionTypes().asRawTypes();
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @MaybeNull
/*      */             public AnnotationValue<?, ?> getDefaultValue() {
/* 1147 */               return AnnotationValue.UNDEFINED;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public TypeList.Generic getTypeVariables() {
/* 1154 */               return (TypeList.Generic)new TypeList.Generic.Empty();
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public AnnotationList getDeclaredAnnotations() {
/* 1161 */               return this.bridgeTarget.getDeclaredAnnotations();
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public int getModifiers() {
/* 1168 */               return (this.bridgeTarget.getModifiers() | 0x1000 | 0x40) & 0xFFFFFEFF;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public String getInternalName() {
/* 1175 */               return this.bridgeTarget.getName();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static class AccessBridgeWrapper
/*      */         implements Record
/*      */       {
/*      */         private final TypeWriter.MethodPool.Record delegate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final TypeDescription instrumentedType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final MethodDescription bridgeTarget;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final Set<MethodDescription.TypeToken> bridgeTypes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final MethodAttributeAppender attributeAppender;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected AccessBridgeWrapper(TypeWriter.MethodPool.Record delegate, TypeDescription instrumentedType, MethodDescription bridgeTarget, Set<MethodDescription.TypeToken> bridgeTypes, MethodAttributeAppender attributeAppender) {
/* 1228 */           this.delegate = delegate;
/* 1229 */           this.instrumentedType = instrumentedType;
/* 1230 */           this.bridgeTarget = bridgeTarget;
/* 1231 */           this.bridgeTypes = bridgeTypes;
/* 1232 */           this.attributeAppender = attributeAppender;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public static TypeWriter.MethodPool.Record of(TypeWriter.MethodPool.Record delegate, TypeDescription instrumentedType, MethodDescription bridgeTarget, Set<MethodDescription.TypeToken> bridgeTypes, MethodAttributeAppender attributeAppender) {
/* 1250 */           Set<MethodDescription.TypeToken> compatibleBridgeTypes = new HashSet<MethodDescription.TypeToken>();
/* 1251 */           for (MethodDescription.TypeToken bridgeType : bridgeTypes) {
/* 1252 */             if (bridgeTarget.isBridgeCompatible(bridgeType)) {
/* 1253 */               compatibleBridgeTypes.add(bridgeType);
/*      */             }
/*      */           } 
/* 1256 */           return (compatibleBridgeTypes.isEmpty() || (instrumentedType.isInterface() && !delegate.getSort().isImplemented())) ? delegate : new AccessBridgeWrapper(delegate, instrumentedType, bridgeTarget, compatibleBridgeTypes, attributeAppender);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TypeWriter.MethodPool.Record.Sort getSort() {
/* 1265 */           return this.delegate.getSort();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public MethodDescription getMethod() {
/* 1272 */           return this.bridgeTarget;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Visibility getVisibility() {
/* 1279 */           return this.delegate.getVisibility();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TypeWriter.MethodPool.Record prepend(ByteCodeAppender byteCodeAppender) {
/* 1286 */           return new AccessBridgeWrapper(this.delegate.prepend(byteCodeAppender), this.instrumentedType, this.bridgeTarget, this.bridgeTypes, this.attributeAppender);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void apply(ClassVisitor classVisitor, Implementation.Context implementationContext, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/* 1295 */           this.delegate.apply(classVisitor, implementationContext, annotationValueFilterFactory);
/* 1296 */           for (MethodDescription.TypeToken bridgeType : this.bridgeTypes) {
/* 1297 */             AccessorBridge accessorBridge = new AccessorBridge(this.bridgeTarget, bridgeType, this.instrumentedType);
/* 1298 */             BridgeTarget bridgeTarget = new BridgeTarget(this.bridgeTarget, this.instrumentedType);
/* 1299 */             MethodVisitor methodVisitor = classVisitor.visitMethod(accessorBridge.getActualModifiers(true, getVisibility()), accessorBridge
/* 1300 */                 .getInternalName(), accessorBridge
/* 1301 */                 .getDescriptor(), MethodDescription.NON_GENERIC_SIGNATURE, accessorBridge
/*      */                 
/* 1303 */                 .getExceptionTypes().asErasures().toInternalNames());
/* 1304 */             if (methodVisitor != null) {
/* 1305 */               this.attributeAppender.apply(methodVisitor, (MethodDescription)accessorBridge, annotationValueFilterFactory.on(this.instrumentedType));
/* 1306 */               methodVisitor.visitCode();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1314 */               ByteCodeAppender.Size size = (new ByteCodeAppender.Simple(new StackManipulation[] { MethodVariableAccess.allArgumentsOf((MethodDescription)accessorBridge).asBridgeOf((MethodDescription)bridgeTarget).prependThisReference(), MethodInvocation.invoke((MethodDescription.InDefinedShape)bridgeTarget).virtual(this.instrumentedType), bridgeTarget.getReturnType().asErasure().isAssignableTo(accessorBridge.getReturnType().asErasure()) ? (StackManipulation)StackManipulation.Trivial.INSTANCE : TypeCasting.to((TypeDefinition)accessorBridge.getReturnType().asErasure()), MethodReturn.of((TypeDefinition)accessorBridge.getReturnType()) })).apply(methodVisitor, implementationContext, (MethodDescription)accessorBridge);
/* 1315 */               methodVisitor.visitMaxs(size.getOperandStackSize(), size.getLocalVariableSize());
/* 1316 */               methodVisitor.visitEnd();
/*      */             } 
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void applyHead(MethodVisitor methodVisitor) {
/* 1325 */           this.delegate.applyHead(methodVisitor);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void applyBody(MethodVisitor methodVisitor, Implementation.Context implementationContext, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/* 1334 */           this.delegate.applyBody(methodVisitor, implementationContext, annotationValueFilterFactory);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void applyAttributes(MethodVisitor methodVisitor, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/* 1341 */           this.delegate.applyAttributes(methodVisitor, annotationValueFilterFactory);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public ByteCodeAppender.Size applyCode(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 1348 */           return this.delegate.applyCode(methodVisitor, implementationContext);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.delegate.equals(((AccessBridgeWrapper)param3Object).delegate) ? false : (!this.instrumentedType.equals(((AccessBridgeWrapper)param3Object).instrumentedType) ? false : (!this.bridgeTarget.equals(((AccessBridgeWrapper)param3Object).bridgeTarget) ? false : (!this.bridgeTypes.equals(((AccessBridgeWrapper)param3Object).bridgeTypes) ? false : (!!this.attributeAppender.equals(((AccessBridgeWrapper)param3Object).attributeAppender))))))));
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return ((((getClass().hashCode() * 31 + this.delegate.hashCode()) * 31 + this.instrumentedType.hashCode()) * 31 + this.bridgeTarget.hashCode()) * 31 + this.bridgeTypes.hashCode()) * 31 + this.attributeAppender.hashCode();
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         protected static class AccessorBridge
/*      */           extends MethodDescription.InDefinedShape.AbstractBase
/*      */         {
/*      */           private final MethodDescription bridgeTarget;
/*      */ 
/*      */           
/*      */           private final MethodDescription.TypeToken bridgeType;
/*      */ 
/*      */           
/*      */           private final TypeDescription instrumentedType;
/*      */ 
/*      */ 
/*      */           
/*      */           protected AccessorBridge(MethodDescription bridgeTarget, MethodDescription.TypeToken bridgeType, TypeDescription instrumentedType) {
/* 1379 */             this.bridgeTarget = bridgeTarget;
/* 1380 */             this.bridgeType = bridgeType;
/* 1381 */             this.instrumentedType = instrumentedType;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @Nonnull
/*      */           public TypeDescription getDeclaringType() {
/* 1389 */             return this.instrumentedType;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public ParameterList<ParameterDescription.InDefinedShape> getParameters() {
/* 1396 */             return (ParameterList<ParameterDescription.InDefinedShape>)new ParameterList.Explicit.ForTypes((MethodDescription.InDefinedShape)this, this.bridgeType.getParameterTypes());
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeDescription.Generic getReturnType() {
/* 1403 */             return this.bridgeType.getReturnType().asGenericType();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeList.Generic getExceptionTypes() {
/* 1410 */             return this.bridgeTarget.getExceptionTypes().accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.TypeErasing.INSTANCE);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @MaybeNull
/*      */           public AnnotationValue<?, ?> getDefaultValue() {
/* 1418 */             return AnnotationValue.UNDEFINED;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeList.Generic getTypeVariables() {
/* 1425 */             return (TypeList.Generic)new TypeList.Generic.Empty();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public AnnotationList getDeclaredAnnotations() {
/* 1432 */             return (AnnotationList)new AnnotationList.Empty();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public int getModifiers() {
/* 1439 */             return (this.bridgeTarget.getModifiers() | 0x40 | 0x1000) & 0xFFFFFAFF;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public String getInternalName() {
/* 1446 */             return this.bridgeTarget.getInternalName();
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected static class BridgeTarget
/*      */           extends MethodDescription.InDefinedShape.AbstractBase
/*      */         {
/*      */           private final MethodDescription bridgeTarget;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final TypeDescription instrumentedType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected BridgeTarget(MethodDescription bridgeTarget, TypeDescription instrumentedType) {
/* 1472 */             this.bridgeTarget = bridgeTarget;
/* 1473 */             this.instrumentedType = instrumentedType;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @Nonnull
/*      */           public TypeDescription getDeclaringType() {
/* 1481 */             return this.instrumentedType;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public ParameterList<ParameterDescription.InDefinedShape> getParameters() {
/* 1488 */             return (ParameterList<ParameterDescription.InDefinedShape>)new ParameterList.ForTokens((MethodDescription.InDefinedShape)this, (List)this.bridgeTarget.getParameters().asTokenList((ElementMatcher)ElementMatchers.is(this.instrumentedType)));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeDescription.Generic getReturnType() {
/* 1495 */             return this.bridgeTarget.getReturnType();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeList.Generic getExceptionTypes() {
/* 1502 */             return this.bridgeTarget.getExceptionTypes();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @MaybeNull
/*      */           public AnnotationValue<?, ?> getDefaultValue() {
/* 1510 */             return this.bridgeTarget.getDefaultValue();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeList.Generic getTypeVariables() {
/* 1517 */             return this.bridgeTarget.getTypeVariables();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public AnnotationList getDeclaredAnnotations() {
/* 1524 */             return this.bridgeTarget.getDeclaredAnnotations();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public int getModifiers() {
/* 1531 */             return this.bridgeTarget.getModifiers();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public String getInternalName() {
/* 1538 */             return this.bridgeTarget.getInternalName();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface RecordComponentPool
/*      */   {
/*      */     Record target(RecordComponentDescription param1RecordComponentDescription);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static interface Record
/*      */     {
/*      */       boolean isImplicit();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       RecordComponentDescription getRecordComponent();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       RecordComponentAttributeAppender getRecordComponentAppender();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       void apply(ClassVisitor param2ClassVisitor, AnnotationValueFilter.Factory param2Factory);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       void apply(RecordComponentVisitor param2RecordComponentVisitor, AnnotationValueFilter.Factory param2Factory);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static class ForImplicitRecordComponent
/*      */         implements Record
/*      */       {
/*      */         private final RecordComponentDescription recordComponentDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public ForImplicitRecordComponent(RecordComponentDescription recordComponentDescription) {
/* 1619 */           this.recordComponentDescription = recordComponentDescription;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isImplicit() {
/* 1626 */           return true;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public RecordComponentDescription getRecordComponent() {
/* 1633 */           return this.recordComponentDescription;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public RecordComponentAttributeAppender getRecordComponentAppender() {
/* 1640 */           throw new IllegalStateException("An implicit field record does not expose a field appender: " + this);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void apply(ClassVisitor classVisitor, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/* 1647 */           RecordComponentVisitor recordComponentVisitor = classVisitor.visitRecordComponent(this.recordComponentDescription.getActualName(), this.recordComponentDescription
/* 1648 */               .getDescriptor(), this.recordComponentDescription
/* 1649 */               .getGenericSignature());
/* 1650 */           if (recordComponentVisitor != null) {
/* 1651 */             RecordComponentAttributeAppender.ForInstrumentedRecordComponent.INSTANCE.apply(recordComponentVisitor, this.recordComponentDescription, annotationValueFilterFactory
/*      */                 
/* 1653 */                 .on(this.recordComponentDescription));
/* 1654 */             recordComponentVisitor.visitEnd();
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void apply(RecordComponentVisitor recordComponentVisitor, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/* 1662 */           throw new IllegalStateException("An implicit field record is not intended for partial application: " + this);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.recordComponentDescription.equals(((ForImplicitRecordComponent)param3Object).recordComponentDescription))));
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return getClass().hashCode() * 31 + this.recordComponentDescription.hashCode();
/*      */         }
/*      */       }
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static class ForExplicitRecordComponent
/*      */         implements Record
/*      */       {
/*      */         private final RecordComponentAttributeAppender attributeAppender;
/*      */         
/*      */         private final RecordComponentDescription recordComponentDescription;
/*      */ 
/*      */         
/*      */         public ForExplicitRecordComponent(RecordComponentAttributeAppender attributeAppender, RecordComponentDescription recordComponentDescription) {
/* 1689 */           this.attributeAppender = attributeAppender;
/* 1690 */           this.recordComponentDescription = recordComponentDescription;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isImplicit() {
/* 1697 */           return false;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public RecordComponentDescription getRecordComponent() {
/* 1704 */           return this.recordComponentDescription;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public RecordComponentAttributeAppender getRecordComponentAppender() {
/* 1711 */           return this.attributeAppender;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void apply(ClassVisitor classVisitor, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/* 1718 */           RecordComponentVisitor recordComponentVisitor = classVisitor.visitRecordComponent(this.recordComponentDescription.getActualName(), this.recordComponentDescription
/* 1719 */               .getDescriptor(), this.recordComponentDescription
/* 1720 */               .getGenericSignature());
/* 1721 */           if (recordComponentVisitor != null) {
/* 1722 */             this.attributeAppender.apply(recordComponentVisitor, this.recordComponentDescription, annotationValueFilterFactory.on(this.recordComponentDescription));
/* 1723 */             recordComponentVisitor.visitEnd();
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void apply(RecordComponentVisitor recordComponentVisitor, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/* 1731 */           this.attributeAppender.apply(recordComponentVisitor, this.recordComponentDescription, annotationValueFilterFactory.on(this.recordComponentDescription));
/*      */         }
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.attributeAppender.equals(((ForExplicitRecordComponent)param3Object).attributeAppender) ? false : (!!this.recordComponentDescription.equals(((ForExplicitRecordComponent)param3Object).recordComponentDescription)))));
/*      */         }
/*      */         
/*      */         public int hashCode() {
/*      */           return (getClass().hashCode() * 31 + this.attributeAppender.hashCode()) * 31 + this.recordComponentDescription.hashCode();
/*      */         } }
/*      */     }
/*      */     
/*      */     public enum Disabled implements RecordComponentPool {
/* 1744 */       INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeWriter.RecordComponentPool.Record target(RecordComponentDescription recordComponentDescription) {
/* 1750 */         throw new IllegalStateException("Cannot look up record component from disabled pool");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static abstract class Default<S>
/*      */     implements TypeWriter<S>
/*      */   {
/*      */     @AlwaysNull
/* 1767 */     private static final String NO_REFERENCE = null; @MaybeNull
/*      */     protected static final String DUMP_FOLDER; protected final TypeDescription instrumentedType; protected final ClassFileVersion classFileVersion; protected final TypeWriter.FieldPool fieldPool; protected final TypeWriter.RecordComponentPool recordComponentPool; protected final List<? extends DynamicType> auxiliaryTypes; protected final FieldList<FieldDescription.InDefinedShape> fields; protected final MethodList<?> methods; protected final MethodList<?> instrumentedMethods; protected final RecordComponentList<RecordComponentDescription.InDefinedShape> recordComponents; protected final LoadedTypeInitializer loadedTypeInitializer; protected final TypeInitializer typeInitializer; protected final TypeAttributeAppender typeAttributeAppender;
/*      */     protected final AsmVisitorWrapper asmVisitorWrapper;
/*      */     protected final AnnotationValueFilter.Factory annotationValueFilterFactory;
/*      */     protected final AnnotationRetention annotationRetention;
/*      */     protected final AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy;
/*      */     protected final Implementation.Context.Factory implementationContextFactory;
/*      */     protected final TypeValidation typeValidation;
/*      */     protected final AsmClassReader.Factory classReaderFactory;
/*      */     protected final AsmClassWriter.Factory classWriterFactory;
/*      */     protected final TypePool typePool;
/*      */     private static final boolean ACCESS_CONTROLLER;
/*      */     
/*      */     static { try {
/* 1781 */         dumpFolder = doPrivileged((PrivilegedAction<String>)new GetSystemPropertyAction("net.bytebuddy.dump"));
/* 1782 */       } catch (RuntimeException exception) {
/* 1783 */         dumpFolder = null;
/*      */       } 
/* 1785 */       DUMP_FOLDER = dumpFolder; } static { String dumpFolder; 
/* 1786 */       try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Default(TypeDescription instrumentedType, ClassFileVersion classFileVersion, TypeWriter.FieldPool fieldPool, TypeWriter.RecordComponentPool recordComponentPool, List<? extends DynamicType> auxiliaryTypes, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, MethodList<?> instrumentedMethods, RecordComponentList<RecordComponentDescription.InDefinedShape> recordComponents, LoadedTypeInitializer loadedTypeInitializer, TypeInitializer typeInitializer, TypeAttributeAppender typeAttributeAppender, AsmVisitorWrapper asmVisitorWrapper, AnnotationValueFilter.Factory annotationValueFilterFactory, AnnotationRetention annotationRetention, AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy, Implementation.Context.Factory implementationContextFactory, TypeValidation typeValidation, AsmClassReader.Factory classReaderFactory, AsmClassWriter.Factory classWriterFactory, TypePool typePool) {
/* 1939 */       this.instrumentedType = instrumentedType;
/* 1940 */       this.classFileVersion = classFileVersion;
/* 1941 */       this.fieldPool = fieldPool;
/* 1942 */       this.recordComponentPool = recordComponentPool;
/* 1943 */       this.auxiliaryTypes = auxiliaryTypes;
/* 1944 */       this.fields = fields;
/* 1945 */       this.methods = methods;
/* 1946 */       this.instrumentedMethods = instrumentedMethods;
/* 1947 */       this.recordComponents = recordComponents;
/* 1948 */       this.loadedTypeInitializer = loadedTypeInitializer;
/* 1949 */       this.typeInitializer = typeInitializer;
/* 1950 */       this.typeAttributeAppender = typeAttributeAppender;
/* 1951 */       this.asmVisitorWrapper = asmVisitorWrapper;
/* 1952 */       this.auxiliaryTypeNamingStrategy = auxiliaryTypeNamingStrategy;
/* 1953 */       this.annotationValueFilterFactory = annotationValueFilterFactory;
/* 1954 */       this.annotationRetention = annotationRetention;
/* 1955 */       this.implementationContextFactory = implementationContextFactory;
/* 1956 */       this.typeValidation = typeValidation;
/* 1957 */       this.classReaderFactory = classReaderFactory;
/* 1958 */       this.classWriterFactory = classWriterFactory;
/* 1959 */       this.typePool = typePool;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 1971 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     private static <T> T doPrivileged(PrivilegedExceptionAction<T> action) throws Exception {
/* 1984 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedExceptionAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static <U> TypeWriter<U> forCreation(MethodRegistry.Compiled methodRegistry, List<? extends DynamicType> auxiliaryTypes, TypeWriter.FieldPool fieldPool, TypeWriter.RecordComponentPool recordComponentPool, TypeAttributeAppender typeAttributeAppender, AsmVisitorWrapper asmVisitorWrapper, ClassFileVersion classFileVersion, AnnotationValueFilter.Factory annotationValueFilterFactory, AnnotationRetention annotationRetention, AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy, Implementation.Context.Factory implementationContextFactory, TypeValidation typeValidation, AsmClassReader.Factory classReaderFactory, AsmClassWriter.Factory classWriterFactory, TypePool typePool) {
/* 2023 */       return new ForCreation<U>(methodRegistry.getInstrumentedType(), classFileVersion, fieldPool, methodRegistry, recordComponentPool, auxiliaryTypes, methodRegistry
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2029 */           .getInstrumentedType().getDeclaredFields(), methodRegistry
/* 2030 */           .getMethods(), methodRegistry
/* 2031 */           .getInstrumentedMethods(), methodRegistry
/* 2032 */           .getInstrumentedType().getRecordComponents(), methodRegistry
/* 2033 */           .getLoadedTypeInitializer(), methodRegistry
/* 2034 */           .getTypeInitializer(), typeAttributeAppender, asmVisitorWrapper, annotationValueFilterFactory, annotationRetention, auxiliaryTypeNamingStrategy, implementationContextFactory, typeValidation, classReaderFactory, classWriterFactory, typePool);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static <U> TypeWriter<U> forRedefinition(MethodRegistry.Prepared methodRegistry, List<? extends DynamicType> auxiliaryTypes, TypeWriter.FieldPool fieldPool, TypeWriter.RecordComponentPool recordComponentPool, TypeAttributeAppender typeAttributeAppender, AsmVisitorWrapper asmVisitorWrapper, ClassFileVersion classFileVersion, AnnotationValueFilter.Factory annotationValueFilterFactory, AnnotationRetention annotationRetention, AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy, Implementation.Context.Factory implementationContextFactory, TypeValidation typeValidation, AsmClassReader.Factory classReaderFactory, AsmClassWriter.Factory classWriterFactory, TypePool typePool, TypeDescription originalType, ClassFileLocator classFileLocator) {
/* 2087 */       return new ForInlining.WithFullProcessing<U>(methodRegistry.getInstrumentedType(), classFileVersion, fieldPool, recordComponentPool, auxiliaryTypes, methodRegistry
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2092 */           .getInstrumentedType().getDeclaredFields(), methodRegistry
/* 2093 */           .getMethods(), methodRegistry
/* 2094 */           .getInstrumentedMethods(), methodRegistry
/* 2095 */           .getInstrumentedType().getRecordComponents(), methodRegistry
/* 2096 */           .getLoadedTypeInitializer(), methodRegistry
/* 2097 */           .getTypeInitializer(), typeAttributeAppender, asmVisitorWrapper, annotationValueFilterFactory, annotationRetention, auxiliaryTypeNamingStrategy, implementationContextFactory, typeValidation, classReaderFactory, classWriterFactory, typePool, originalType, classFileLocator, methodRegistry, (Implementation.Target.Factory)SubclassImplementationTarget.Factory.LEVEL_TYPE, (MethodRebaseResolver)MethodRebaseResolver.Disabled.INSTANCE);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static <U> TypeWriter<U> forRebasing(MethodRegistry.Prepared methodRegistry, List<? extends DynamicType> auxiliaryTypes, TypeWriter.FieldPool fieldPool, TypeWriter.RecordComponentPool recordComponentPool, TypeAttributeAppender typeAttributeAppender, AsmVisitorWrapper asmVisitorWrapper, ClassFileVersion classFileVersion, AnnotationValueFilter.Factory annotationValueFilterFactory, AnnotationRetention annotationRetention, AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy, Implementation.Context.Factory implementationContextFactory, TypeValidation typeValidation, AsmClassReader.Factory classReaderFactory, AsmClassWriter.Factory classWriterFactory, TypePool typePool, TypeDescription originalType, ClassFileLocator classFileLocator, MethodRebaseResolver methodRebaseResolver) {
/* 2157 */       return new ForInlining.WithFullProcessing<U>(methodRegistry.getInstrumentedType(), classFileVersion, fieldPool, recordComponentPool, 
/*      */ 
/*      */ 
/*      */           
/* 2161 */           CompoundList.of(auxiliaryTypes, methodRebaseResolver.getAuxiliaryTypes()), methodRegistry
/* 2162 */           .getInstrumentedType().getDeclaredFields(), methodRegistry
/* 2163 */           .getMethods(), methodRegistry
/* 2164 */           .getInstrumentedMethods(), methodRegistry
/* 2165 */           .getInstrumentedType().getRecordComponents(), methodRegistry
/* 2166 */           .getLoadedTypeInitializer(), methodRegistry
/* 2167 */           .getTypeInitializer(), typeAttributeAppender, asmVisitorWrapper, annotationValueFilterFactory, annotationRetention, auxiliaryTypeNamingStrategy, implementationContextFactory, typeValidation, classReaderFactory, classWriterFactory, typePool, originalType, classFileLocator, methodRegistry, (Implementation.Target.Factory)new RebaseImplementationTarget.Factory(methodRebaseResolver), methodRebaseResolver);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static <U> TypeWriter<U> forDecoration(TypeDescription instrumentedType, ClassFileVersion classFileVersion, List<? extends DynamicType> auxiliaryTypes, List<? extends MethodDescription> methods, TypeAttributeAppender typeAttributeAppender, AsmVisitorWrapper asmVisitorWrapper, AnnotationValueFilter.Factory annotationValueFilterFactory, AnnotationRetention annotationRetention, AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy, Implementation.Context.Factory implementationContextFactory, TypeValidation typeValidation, AsmClassReader.Factory classReaderFactory, AsmClassWriter.Factory classWriterFactory, TypePool typePool, ClassFileLocator classFileLocator) {
/* 2221 */       return new ForInlining.WithDecorationOnly<U>(instrumentedType, classFileVersion, auxiliaryTypes, (MethodList<?>)new MethodList.Explicit(methods), typeAttributeAppender, asmVisitorWrapper, annotationValueFilterFactory, annotationRetention, auxiliaryTypeNamingStrategy, implementationContextFactory, typeValidation, classReaderFactory, classWriterFactory, typePool, classFileLocator);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Setting a debugging property should never change the program outcome.")
/*      */     public DynamicType.Unloaded<S> make(TypeResolutionStrategy.Resolved typeResolutionStrategy) {
/* 2245 */       ClassDumpAction.Dispatcher dispatcher = (DUMP_FOLDER == null) ? ClassDumpAction.Dispatcher.Disabled.INSTANCE : new ClassDumpAction.Dispatcher.Enabled(DUMP_FOLDER, System.currentTimeMillis());
/* 2246 */       UnresolvedType unresolvedType = create(typeResolutionStrategy.injectedInto(this.typeInitializer), dispatcher);
/* 2247 */       dispatcher.dump(this.instrumentedType, false, unresolvedType.getBinaryRepresentation());
/* 2248 */       return unresolvedType.toDynamicType(typeResolutionStrategy);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected abstract UnresolvedType create(TypeInitializer param1TypeInitializer, ClassDumpAction.Dispatcher param1Dispatcher);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.annotationRetention.equals(((Default)param1Object).annotationRetention) ? false : (!this.typeValidation.equals(((Default)param1Object).typeValidation) ? false : (!this.instrumentedType.equals(((Default)param1Object).instrumentedType) ? false : (!this.classFileVersion.equals(((Default)param1Object).classFileVersion) ? false : (!this.fieldPool.equals(((Default)param1Object).fieldPool) ? false : (!this.recordComponentPool.equals(((Default)param1Object).recordComponentPool) ? false : (!this.auxiliaryTypes.equals(((Default)param1Object).auxiliaryTypes) ? false : (!this.fields.equals(((Default)param1Object).fields) ? false : (!this.methods.equals(((Default)param1Object).methods) ? false : (!this.instrumentedMethods.equals(((Default)param1Object).instrumentedMethods) ? false : (!this.recordComponents.equals(((Default)param1Object).recordComponents) ? false : (!this.loadedTypeInitializer.equals(((Default)param1Object).loadedTypeInitializer) ? false : (!this.typeInitializer.equals(((Default)param1Object).typeInitializer) ? false : (!this.typeAttributeAppender.equals(((Default)param1Object).typeAttributeAppender) ? false : (!this.asmVisitorWrapper.equals(((Default)param1Object).asmVisitorWrapper) ? false : (!this.annotationValueFilterFactory.equals(((Default)param1Object).annotationValueFilterFactory) ? false : (!this.auxiliaryTypeNamingStrategy.equals(((Default)param1Object).auxiliaryTypeNamingStrategy) ? false : (!this.implementationContextFactory.equals(((Default)param1Object).implementationContextFactory) ? false : (!this.classReaderFactory.equals(((Default)param1Object).classReaderFactory) ? false : (!this.classWriterFactory.equals(((Default)param1Object).classWriterFactory) ? false : (!!this.typePool.equals(((Default)param1Object).typePool))))))))))))))))))))))));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return ((((((((((((((((((((getClass().hashCode() * 31 + this.instrumentedType.hashCode()) * 31 + this.classFileVersion.hashCode()) * 31 + this.fieldPool.hashCode()) * 31 + this.recordComponentPool.hashCode()) * 31 + this.auxiliaryTypes.hashCode()) * 31 + this.fields.hashCode()) * 31 + this.methods.hashCode()) * 31 + this.instrumentedMethods.hashCode()) * 31 + this.recordComponents.hashCode()) * 31 + this.loadedTypeInitializer.hashCode()) * 31 + this.typeInitializer.hashCode()) * 31 + this.typeAttributeAppender.hashCode()) * 31 + this.asmVisitorWrapper.hashCode()) * 31 + this.annotationValueFilterFactory.hashCode()) * 31 + this.annotationRetention.hashCode()) * 31 + this.auxiliaryTypeNamingStrategy.hashCode()) * 31 + this.implementationContextFactory.hashCode()) * 31 + this.typeValidation.hashCode()) * 31 + this.classReaderFactory.hashCode()) * 31 + this.classWriterFactory.hashCode()) * 31 + this.typePool.hashCode();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance(includeSyntheticFields = true)
/*      */     protected class UnresolvedType
/*      */     {
/*      */       private final byte[] binaryRepresentation;
/*      */ 
/*      */       
/*      */       private final List<? extends DynamicType> auxiliaryTypes;
/*      */ 
/*      */ 
/*      */       
/*      */       protected UnresolvedType(byte[] binaryRepresentation, List<? extends DynamicType> auxiliaryTypes) {
/* 2283 */         this.binaryRepresentation = binaryRepresentation;
/* 2284 */         this.auxiliaryTypes = auxiliaryTypes;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected DynamicType.Unloaded<S> toDynamicType(TypeResolutionStrategy.Resolved typeResolutionStrategy) {
/* 2294 */         return (DynamicType.Unloaded<S>)new DynamicType.Default.Unloaded(TypeWriter.Default.this.instrumentedType, this.binaryRepresentation, TypeWriter.Default.this.loadedTypeInitializer, 
/*      */ 
/*      */             
/* 2297 */             CompoundList.of(TypeWriter.Default.this.auxiliaryTypes, this.auxiliaryTypes), typeResolutionStrategy);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected byte[] getBinaryRepresentation() {
/* 2307 */         return this.binaryRepresentation;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!Arrays.equals(this.binaryRepresentation, ((UnresolvedType)param2Object).binaryRepresentation) ? false : (!this.auxiliaryTypes.equals(((UnresolvedType)param2Object).auxiliaryTypes) ? false : (!!TypeWriter.Default.this.equals(TypeWriter.Default.this))))));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return ((getClass().hashCode() * 31 + Arrays.hashCode(this.binaryRepresentation)) * 31 + this.auxiliaryTypes.hashCode()) * 31 + TypeWriter.Default.this.hashCode();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected static class SignatureKey
/*      */     {
/*      */       private final String internalName;
/*      */       
/*      */       private final String descriptor;
/*      */ 
/*      */       
/*      */       public SignatureKey(String internalName, String descriptor) {
/* 2333 */         this.internalName = internalName;
/* 2334 */         this.descriptor = descriptor;
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object other) {
/* 2339 */         if (this == other) return true; 
/* 2340 */         if (other == null || getClass() != other.getClass()) return false; 
/* 2341 */         SignatureKey that = (SignatureKey)other;
/* 2342 */         return (this.internalName.equals(that.internalName) && this.descriptor.equals(that.descriptor));
/*      */       }
/*      */ 
/*      */       
/*      */       public int hashCode() {
/* 2347 */         return 17 + this.internalName.hashCode() + 31 * this.descriptor.hashCode();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected static class ValidatingClassVisitor
/*      */       extends ClassVisitor
/*      */     {
/*      */       private static final String NO_PARAMETERS = "()";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private static final String RETURNS_VOID = "V";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private static final String STRING_DESCRIPTOR = "Ljava/lang/String;";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @AlwaysNull
/* 2375 */       private static final FieldVisitor IGNORE_FIELD = null;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @AlwaysNull
/* 2381 */       private static final MethodVisitor IGNORE_METHOD = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @UnknownNull
/*      */       private Constraint constraint;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected ValidatingClassVisitor(ClassVisitor classVisitor) {
/* 2395 */         super(OpenedClassReader.ASM_API, classVisitor);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected static ClassVisitor of(ClassVisitor classVisitor, TypeValidation typeValidation) {
/* 2406 */         return typeValidation.isEnabled() ? new ValidatingClassVisitor(classVisitor) : classVisitor;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public void visit(int version, int modifiers, String name, @MaybeNull String signature, @MaybeNull String superName, @MaybeNull String[] interfaceInternalName) {
/*      */         boolean record;
/* 2413 */         ClassFileVersion classFileVersion = ClassFileVersion.ofMinorMajor(version);
/* 2414 */         List<Constraint> constraints = new ArrayList<Constraint>();
/* 2415 */         constraints.add(new Constraint.ForClassFileVersion(classFileVersion));
/* 2416 */         if (name.endsWith("/package-info")) {
/* 2417 */           constraints.add(Constraint.ForPackageType.INSTANCE);
/* 2418 */         } else if ((modifiers & 0x2000) != 0) {
/* 2419 */           if (!classFileVersion.isAtLeast(ClassFileVersion.JAVA_V5)) {
/* 2420 */             throw new IllegalStateException("Cannot define an annotation type for class file version " + classFileVersion);
/*      */           }
/* 2422 */           constraints.add(classFileVersion.isAtLeast(ClassFileVersion.JAVA_V8) ? Constraint.ForAnnotation.JAVA_8 : Constraint.ForAnnotation.CLASSIC);
/*      */         
/*      */         }
/* 2425 */         else if ((modifiers & 0x200) != 0) {
/* 2426 */           constraints.add(classFileVersion.isAtLeast(ClassFileVersion.JAVA_V8) ? Constraint.ForInterface.JAVA_8 : Constraint.ForInterface.CLASSIC);
/*      */         
/*      */         }
/* 2429 */         else if ((modifiers & 0x400) != 0) {
/* 2430 */           constraints.add(Constraint.ForClass.ABSTRACT);
/*      */         } else {
/* 2432 */           constraints.add(Constraint.ForClass.MANIFEST);
/*      */         } 
/*      */         
/* 2435 */         if ((modifiers & 0x10000) != 0) {
/* 2436 */           constraints.add(Constraint.ForRecord.INSTANCE);
/* 2437 */           record = true;
/*      */         } else {
/* 2439 */           record = false;
/*      */         } 
/* 2441 */         this.constraint = new Constraint.Compound(constraints);
/* 2442 */         this.constraint.assertType(modifiers, (interfaceInternalName != null), (signature != null));
/* 2443 */         if (record) {
/* 2444 */           this.constraint.assertRecord();
/*      */         }
/* 2446 */         super.visit(version, modifiers, name, signature, superName, interfaceInternalName);
/*      */       }
/*      */ 
/*      */       
/*      */       public void visitPermittedSubclass(String permittedSubclass) {
/* 2451 */         this.constraint.assertPermittedSubclass();
/* 2452 */         super.visitPermittedSubclass(permittedSubclass);
/*      */       }
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/* 2458 */         this.constraint.assertAnnotation();
/* 2459 */         return super.visitAnnotation(descriptor, visible);
/*      */       }
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       public AnnotationVisitor visitTypeAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) {
/* 2465 */         this.constraint.assertTypeAnnotation();
/* 2466 */         return super.visitTypeAnnotation(typeReference, typePath, descriptor, visible);
/*      */       }
/*      */ 
/*      */       
/*      */       public void visitNestHost(String nestHost) {
/* 2471 */         this.constraint.assertNestMate();
/* 2472 */         super.visitNestHost(nestHost);
/*      */       }
/*      */ 
/*      */       
/*      */       public void visitNestMember(String nestMember) {
/* 2477 */         this.constraint.assertNestMate();
/* 2478 */         super.visitNestMember(nestMember);
/*      */       }
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       public FieldVisitor visitField(int modifiers, String name, String descriptor, @MaybeNull String signature, @MaybeNull Object value) {
/* 2484 */         if (value != null) {
/*      */           Class<?> type;
/* 2486 */           switch (descriptor.charAt(0)) {
/*      */             case 'B':
/*      */             case 'C':
/*      */             case 'I':
/*      */             case 'S':
/*      */             case 'Z':
/* 2492 */               type = Integer.class;
/*      */               break;
/*      */             case 'J':
/* 2495 */               type = Long.class;
/*      */               break;
/*      */             case 'F':
/* 2498 */               type = Float.class;
/*      */               break;
/*      */             case 'D':
/* 2501 */               type = Double.class;
/*      */               break;
/*      */             default:
/* 2504 */               if (!descriptor.equals("Ljava/lang/String;")) {
/* 2505 */                 throw new IllegalStateException("Cannot define a default value for type of field " + name);
/*      */               }
/* 2507 */               type = String.class; break;
/*      */           } 
/* 2509 */           if (!type.isInstance(value))
/* 2510 */             throw new IllegalStateException("Field " + name + " defines an incompatible default value " + value + " (" + value.getClass().getName() + ")"); 
/* 2511 */           if (type == Integer.class) {
/*      */             boolean outOfRange;
/* 2513 */             switch (descriptor.charAt(0)) {
/*      */               case 'Z':
/* 2515 */                 outOfRange = (((Integer)value).intValue() < 0 || ((Integer)value).intValue() > 1);
/*      */                 break;
/*      */               case 'B':
/* 2518 */                 outOfRange = (((Integer)value).intValue() < -128 || ((Integer)value).intValue() > 127);
/*      */                 break;
/*      */               case 'S':
/* 2521 */                 outOfRange = (((Integer)value).intValue() < -32768 || ((Integer)value).intValue() > 32767);
/*      */                 break;
/*      */               case 'C':
/* 2524 */                 outOfRange = (((Integer)value).intValue() < 0 || ((Integer)value).intValue() > 65535);
/*      */                 break;
/*      */               default:
/* 2527 */                 outOfRange = false; break;
/*      */             } 
/* 2529 */             if (outOfRange) {
/* 2530 */               throw new IllegalStateException("Field " + name + " defines an incompatible default value " + value);
/*      */             }
/*      */           } 
/*      */         } 
/* 2534 */         this.constraint.assertField(name, ((modifiers & 0x1) != 0), ((modifiers & 0x8) != 0), ((modifiers & 0x10) != 0), (signature != null));
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2539 */         FieldVisitor fieldVisitor = super.visitField(modifiers, name, descriptor, signature, value);
/* 2540 */         return (fieldVisitor == null) ? IGNORE_FIELD : new ValidatingFieldVisitor(fieldVisitor);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       public MethodVisitor visitMethod(int modifiers, String name, String descriptor, @MaybeNull String signature, @MaybeNull String[] exceptionInternalName) {
/* 2548 */         this.constraint.assertMethod(name, ((modifiers & 0x400) != 0), ((modifiers & 0x1) != 0), ((modifiers & 0x2) != 0), ((modifiers & 0x8) != 0), (
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2553 */             !name.equals("<init>") && 
/* 2554 */             !name.equals("<clinit>") && (modifiers & 0xA) == 0), name
/*      */             
/* 2556 */             .equals("<init>"), (
/* 2557 */             !descriptor.startsWith("()") || descriptor.endsWith("V")), (signature != null));
/*      */         
/* 2559 */         MethodVisitor methodVisitor = super.visitMethod(modifiers, name, descriptor, signature, exceptionInternalName);
/* 2560 */         return (methodVisitor == null) ? IGNORE_METHOD : new ValidatingMethodVisitor(methodVisitor, name);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public enum ForClass
/*      */         implements Constraint
/*      */       {
/* 2688 */         MANIFEST(true),
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2693 */         ABSTRACT(false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final boolean manifestType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         ForClass(boolean manifestType) {
/* 2706 */           this.manifestType = manifestType;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertType(int modifier, boolean definesInterfaces, boolean isGeneric) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertField(String name, boolean isPublic, boolean isStatic, boolean isFinal, boolean isGeneric) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertMethod(String name, boolean isAbstract, boolean isPublic, boolean isPrivate, boolean isStatic, boolean isVirtual, boolean isConstructor, boolean isDefaultValueIncompatible, boolean isGeneric) {
/* 2735 */           if (isAbstract && this.manifestType) {
/* 2736 */             throw new IllegalStateException("Cannot define abstract method '" + name + "' for non-abstract class");
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertAnnotation() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertTypeAnnotation() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDefaultValue(String name) {
/* 2758 */           throw new IllegalStateException("Cannot define default value for '" + name + "' for non-annotation type");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDefaultMethodCall() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertTypeInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertMethodTypeInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertHandleInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertInvokeDynamic() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertSubRoutine() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDynamicValueInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertNestMate() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertRecord() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertPermittedSubclass() {}
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public enum ForPackageType
/*      */         implements Constraint
/*      */       {
/* 2840 */         INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertField(String name, boolean isPublic, boolean isStatic, boolean isFinal, boolean isGeneric) {
/* 2846 */           throw new IllegalStateException("Cannot define a field for a package description type");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertMethod(String name, boolean isAbstract, boolean isPublic, boolean isPrivate, boolean isStatic, boolean isVirtual, boolean isConstructor, boolean isNoDefaultValue, boolean isGeneric) {
/* 2861 */           throw new IllegalStateException("Cannot define a method for a package description type");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertAnnotation() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertTypeAnnotation() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDefaultValue(String name) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDefaultMethodCall() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertTypeInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertMethodTypeInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertHandleInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertInvokeDynamic() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertSubRoutine() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertType(int modifier, boolean definesInterfaces, boolean isGeneric) {
/* 2931 */           if (modifier != 5632)
/* 2932 */             throw new IllegalStateException("A package description type must define 5632 as modifier"); 
/* 2933 */           if (definesInterfaces) {
/* 2934 */             throw new IllegalStateException("Cannot implement interface for package type");
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDynamicValueInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertNestMate() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertRecord() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertPermittedSubclass() {}
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public enum ForInterface
/*      */         implements Constraint
/*      */       {
/* 2975 */         CLASSIC(true),
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2980 */         JAVA_8(false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final boolean classic;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         ForInterface(boolean classic) {
/* 2993 */           this.classic = classic;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertField(String name, boolean isPublic, boolean isStatic, boolean isFinal, boolean isGeneric) {
/* 3000 */           if (!isStatic || !isPublic || !isFinal) {
/* 3001 */             throw new IllegalStateException("Cannot only define public, static, final field '" + name + "' for interface type");
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertMethod(String name, boolean isAbstract, boolean isPublic, boolean isPrivate, boolean isStatic, boolean isVirtual, boolean isConstructor, boolean isDefaultValueIncompatible, boolean isGeneric) {
/* 3017 */           if (!name.equals("<clinit>")) {
/* 3018 */             if (isConstructor)
/* 3019 */               throw new IllegalStateException("Cannot define constructor for interface type"); 
/* 3020 */             if (this.classic && !isPublic)
/* 3021 */               throw new IllegalStateException("Cannot define non-public method '" + name + "' for interface type"); 
/* 3022 */             if (this.classic && !isVirtual)
/* 3023 */               throw new IllegalStateException("Cannot define non-virtual method '" + name + "' for a pre-Java 8 interface type"); 
/* 3024 */             if (this.classic && !isAbstract) {
/* 3025 */               throw new IllegalStateException("Cannot define default method '" + name + "' for pre-Java 8 interface type");
/*      */             }
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertAnnotation() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertTypeAnnotation() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDefaultValue(String name) {
/* 3048 */           throw new IllegalStateException("Cannot define default value for '" + name + "' for non-annotation type");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDefaultMethodCall() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertType(int modifier, boolean definesInterfaces, boolean isGeneric) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertTypeInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertMethodTypeInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertHandleInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertInvokeDynamic() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertSubRoutine() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDynamicValueInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertNestMate() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertRecord() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertPermittedSubclass() {}
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public enum ForRecord
/*      */         implements Constraint
/*      */       {
/* 3137 */         INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertField(String name, boolean isPublic, boolean isStatic, boolean isFinal, boolean isGeneric) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertMethod(String name, boolean isAbstract, boolean isPublic, boolean isPrivate, boolean isStatic, boolean isVirtual, boolean isConstructor, boolean isDefaultValueIncompatible, boolean isGeneric) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertAnnotation() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertTypeAnnotation() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDefaultValue(String name) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDefaultMethodCall() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertType(int modifier, boolean definesInterfaces, boolean isGeneric) {
/* 3193 */           if ((modifier & 0x400) != 0) {
/* 3194 */             throw new IllegalStateException("Cannot define a record class as abstract");
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertTypeInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertMethodTypeInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertHandleInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertInvokeDynamic() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertSubRoutine() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDynamicValueInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertNestMate() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertRecord() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertPermittedSubclass() {}
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public enum ForAnnotation
/*      */         implements Constraint
/*      */       {
/* 3270 */         CLASSIC(true),
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3275 */         JAVA_8(false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final boolean classic;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         ForAnnotation(boolean classic) {
/* 3288 */           this.classic = classic;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertField(String name, boolean isPublic, boolean isStatic, boolean isFinal, boolean isGeneric) {
/* 3295 */           if (!isStatic || !isPublic || !isFinal) {
/* 3296 */             throw new IllegalStateException("Cannot only define public, static, final field '" + name + "' for interface type");
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertMethod(String name, boolean isAbstract, boolean isPublic, boolean isPrivate, boolean isStatic, boolean isVirtual, boolean isConstructor, boolean isDefaultValueIncompatible, boolean isGeneric) {
/* 3312 */           if (!name.equals("<clinit>")) {
/* 3313 */             if (isConstructor)
/* 3314 */               throw new IllegalStateException("Cannot define constructor for interface type"); 
/* 3315 */             if (this.classic && !isVirtual)
/* 3316 */               throw new IllegalStateException("Cannot define non-virtual method '" + name + "' for a pre-Java 8 annotation type"); 
/* 3317 */             if (!isStatic && isDefaultValueIncompatible) {
/* 3318 */               throw new IllegalStateException("Cannot define method '" + name + "' with the given signature as an annotation type method");
/*      */             }
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertAnnotation() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertTypeAnnotation() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDefaultValue(String name) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDefaultMethodCall() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertType(int modifier, boolean definesInterfaces, boolean isGeneric) {
/* 3355 */           if ((modifier & 0x200) == 0) {
/* 3356 */             throw new IllegalStateException("Cannot define annotation type without interface modifier");
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertTypeInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertMethodTypeInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertHandleInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertInvokeDynamic() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertSubRoutine() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDynamicValueInConstantPool() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertNestMate() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertRecord() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertPermittedSubclass() {}
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static class ForClassFileVersion
/*      */         implements Constraint
/*      */       {
/*      */         private final ClassFileVersion classFileVersion;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected ForClassFileVersion(ClassFileVersion classFileVersion) {
/* 3441 */           this.classFileVersion = classFileVersion;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertType(int modifiers, boolean definesInterfaces, boolean isGeneric) {
/* 3448 */           if ((modifiers & 0x2000) != 0 && !this.classFileVersion.isAtLeast(ClassFileVersion.JAVA_V5))
/* 3449 */             throw new IllegalStateException("Cannot define annotation type for class file version " + this.classFileVersion); 
/* 3450 */           if (isGeneric && !this.classFileVersion.isAtLeast(ClassFileVersion.JAVA_V4)) {
/* 3451 */             throw new IllegalStateException("Cannot define a generic type for class file version " + this.classFileVersion);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertField(String name, boolean isPublic, boolean isStatic, boolean isFinal, boolean isGeneric) {
/* 3459 */           if (isGeneric && !this.classFileVersion.isAtLeast(ClassFileVersion.JAVA_V4)) {
/* 3460 */             throw new IllegalStateException("Cannot define generic field '" + name + "' for class file version " + this.classFileVersion);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertMethod(String name, boolean isAbstract, boolean isPublic, boolean isPrivate, boolean isStatic, boolean isVirtual, boolean isConstructor, boolean isDefaultValueIncompatible, boolean isGeneric) {
/* 3476 */           if (isGeneric && !this.classFileVersion.isAtLeast(ClassFileVersion.JAVA_V4))
/* 3477 */             throw new IllegalStateException("Cannot define generic method '" + name + "' for class file version " + this.classFileVersion); 
/* 3478 */           if (!isVirtual && isAbstract) {
/* 3479 */             throw new IllegalStateException("Cannot define static or non-virtual method '" + name + "' to be abstract");
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertAnnotation() {
/* 3487 */           if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V5)) {
/* 3488 */             throw new IllegalStateException("Cannot write annotations for class file version " + this.classFileVersion);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertTypeAnnotation() {
/* 3496 */           if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V5)) {
/* 3497 */             throw new IllegalStateException("Cannot write type annotations for class file version " + this.classFileVersion);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDefaultValue(String name) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDefaultMethodCall() {
/* 3512 */           if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V8)) {
/* 3513 */             throw new IllegalStateException("Cannot invoke default method for class file version " + this.classFileVersion);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertTypeInConstantPool() {
/* 3521 */           if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V5)) {
/* 3522 */             throw new IllegalStateException("Cannot write type to constant pool for class file version " + this.classFileVersion);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertMethodTypeInConstantPool() {
/* 3530 */           if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V7)) {
/* 3531 */             throw new IllegalStateException("Cannot write method type to constant pool for class file version " + this.classFileVersion);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertHandleInConstantPool() {
/* 3539 */           if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V7)) {
/* 3540 */             throw new IllegalStateException("Cannot write method handle to constant pool for class file version " + this.classFileVersion);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertInvokeDynamic() {
/* 3548 */           if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V7)) {
/* 3549 */             throw new IllegalStateException("Cannot write invoke dynamic instruction for class file version " + this.classFileVersion);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertSubRoutine() {
/* 3557 */           if (this.classFileVersion.isGreaterThan(ClassFileVersion.JAVA_V5)) {
/* 3558 */             throw new IllegalStateException("Cannot write subroutine for class file version " + this.classFileVersion);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertDynamicValueInConstantPool() {
/* 3566 */           if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V11)) {
/* 3567 */             throw new IllegalStateException("Cannot write dynamic constant for class file version " + this.classFileVersion);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertNestMate() {
/* 3575 */           if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V11)) {
/* 3576 */             throw new IllegalStateException("Cannot define nest mate for class file version " + this.classFileVersion);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertRecord() {
/* 3584 */           if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V14)) {
/* 3585 */             throw new IllegalStateException("Cannot define record for class file version " + this.classFileVersion);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public void assertPermittedSubclass()
/*      */         {
/* 3593 */           if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V17))
/* 3594 */             throw new IllegalStateException("Cannot define permitted subclasses for class file version " + this.classFileVersion);  } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.classFileVersion.equals(((ForClassFileVersion)param3Object).classFileVersion)))); } public int hashCode() { return getClass().hashCode() * 31 + this.classFileVersion.hashCode(); } } protected static interface Constraint { void assertType(int param3Int, boolean param3Boolean1, boolean param3Boolean2); void assertField(String param3String, boolean param3Boolean1, boolean param3Boolean2, boolean param3Boolean3, boolean param3Boolean4); void assertMethod(String param3String, boolean param3Boolean1, boolean param3Boolean2, boolean param3Boolean3, boolean param3Boolean4, boolean param3Boolean5, boolean param3Boolean6, boolean param3Boolean7, boolean param3Boolean8); void assertAnnotation(); void assertTypeAnnotation(); void assertDefaultValue(String param3String); void assertDefaultMethodCall(); void assertTypeInConstantPool(); void assertMethodTypeInConstantPool(); void assertHandleInConstantPool(); void assertInvokeDynamic(); void assertSubRoutine(); void assertDynamicValueInConstantPool(); void assertNestMate(); void assertRecord(); void assertPermittedSubclass(); public enum ForClass implements Constraint { MANIFEST(true), ABSTRACT(false); private final boolean manifestType; ForClass(boolean manifestType) { this.manifestType = manifestType; } public void assertType(int modifier, boolean definesInterfaces, boolean isGeneric) {} public void assertField(String name, boolean isPublic, boolean isStatic, boolean isFinal, boolean isGeneric) {} public void assertMethod(String name, boolean isAbstract, boolean isPublic, boolean isPrivate, boolean isStatic, boolean isVirtual, boolean isConstructor, boolean isDefaultValueIncompatible, boolean isGeneric) { if (isAbstract && this.manifestType) throw new IllegalStateException("Cannot define abstract method '" + name + "' for non-abstract class");  } public void assertAnnotation() {} public void assertTypeAnnotation() {} public void assertDefaultValue(String name) { throw new IllegalStateException("Cannot define default value for '" + name + "' for non-annotation type"); } public void assertDefaultMethodCall() {} public void assertTypeInConstantPool() {} public void assertMethodTypeInConstantPool() {} public void assertHandleInConstantPool() {} public void assertInvokeDynamic() {} public void assertSubRoutine() {} public void assertDynamicValueInConstantPool() {} public void assertNestMate() {} public void assertRecord() {} public void assertPermittedSubclass() {} } public enum ForPackageType implements Constraint { INSTANCE; public void assertField(String name, boolean isPublic, boolean isStatic, boolean isFinal, boolean isGeneric) { throw new IllegalStateException("Cannot define a field for a package description type"); } public void assertMethod(String name, boolean isAbstract, boolean isPublic, boolean isPrivate, boolean isStatic, boolean isVirtual, boolean isConstructor, boolean isNoDefaultValue, boolean isGeneric) { throw new IllegalStateException("Cannot define a method for a package description type"); } public void assertAnnotation() {} public void assertTypeAnnotation() {} public void assertDefaultValue(String name) {} public void assertDefaultMethodCall() {} public void assertTypeInConstantPool() {} public void assertMethodTypeInConstantPool() {} public void assertHandleInConstantPool() {} public void assertInvokeDynamic() {} public void assertSubRoutine() {} public void assertType(int modifier, boolean definesInterfaces, boolean isGeneric) { if (modifier != 5632) throw new IllegalStateException("A package description type must define 5632 as modifier");  if (definesInterfaces) throw new IllegalStateException("Cannot implement interface for package type");  } public void assertDynamicValueInConstantPool() {} public void assertNestMate() {} public void assertRecord() {} public void assertPermittedSubclass() {} } public enum ForInterface implements Constraint { CLASSIC(true), JAVA_8(false); private final boolean classic; ForInterface(boolean classic) { this.classic = classic; } public void assertField(String name, boolean isPublic, boolean isStatic, boolean isFinal, boolean isGeneric) { if (!isStatic || !isPublic || !isFinal) throw new IllegalStateException("Cannot only define public, static, final field '" + name + "' for interface type");  } public void assertMethod(String name, boolean isAbstract, boolean isPublic, boolean isPrivate, boolean isStatic, boolean isVirtual, boolean isConstructor, boolean isDefaultValueIncompatible, boolean isGeneric) { if (!name.equals("<clinit>")) { if (isConstructor) throw new IllegalStateException("Cannot define constructor for interface type");  if (this.classic && !isPublic) throw new IllegalStateException("Cannot define non-public method '" + name + "' for interface type");  if (this.classic && !isVirtual) throw new IllegalStateException("Cannot define non-virtual method '" + name + "' for a pre-Java 8 interface type");  if (this.classic && !isAbstract) throw new IllegalStateException("Cannot define default method '" + name + "' for pre-Java 8 interface type");  }  } public void assertAnnotation() {} public void assertTypeAnnotation() {} public void assertDefaultValue(String name) { throw new IllegalStateException("Cannot define default value for '" + name + "' for non-annotation type"); } public void assertDefaultMethodCall() {} public void assertType(int modifier, boolean definesInterfaces, boolean isGeneric) {} public void assertTypeInConstantPool() {} public void assertMethodTypeInConstantPool() {} public void assertHandleInConstantPool() {} public void assertInvokeDynamic() {} public void assertSubRoutine() {} public void assertDynamicValueInConstantPool() {} public void assertNestMate() {} public void assertRecord() {} public void assertPermittedSubclass() {} } public enum ForRecord implements Constraint { INSTANCE; public void assertField(String name, boolean isPublic, boolean isStatic, boolean isFinal, boolean isGeneric) {} public void assertMethod(String name, boolean isAbstract, boolean isPublic, boolean isPrivate, boolean isStatic, boolean isVirtual, boolean isConstructor, boolean isDefaultValueIncompatible, boolean isGeneric) {} public void assertAnnotation() {} public void assertTypeAnnotation() {} public void assertDefaultValue(String name) {} public void assertDefaultMethodCall() {} public void assertType(int modifier, boolean definesInterfaces, boolean isGeneric) { if ((modifier & 0x400) != 0) throw new IllegalStateException("Cannot define a record class as abstract");  } public void assertTypeInConstantPool() {} public void assertMethodTypeInConstantPool() {} public void assertHandleInConstantPool() {} public void assertInvokeDynamic() {} public void assertSubRoutine() {} public void assertDynamicValueInConstantPool() {} public void assertNestMate() {} public void assertRecord() {} public void assertPermittedSubclass() {} } public enum ForAnnotation implements Constraint { CLASSIC(true), JAVA_8(false); private final boolean classic; ForAnnotation(boolean classic) { this.classic = classic; } public void assertField(String name, boolean isPublic, boolean isStatic, boolean isFinal, boolean isGeneric) { if (!isStatic || !isPublic || !isFinal) throw new IllegalStateException("Cannot only define public, static, final field '" + name + "' for interface type");  } public void assertMethod(String name, boolean isAbstract, boolean isPublic, boolean isPrivate, boolean isStatic, boolean isVirtual, boolean isConstructor, boolean isDefaultValueIncompatible, boolean isGeneric) { if (!name.equals("<clinit>")) { if (isConstructor) throw new IllegalStateException("Cannot define constructor for interface type");  if (this.classic && !isVirtual) throw new IllegalStateException("Cannot define non-virtual method '" + name + "' for a pre-Java 8 annotation type");  if (!isStatic && isDefaultValueIncompatible) throw new IllegalStateException("Cannot define method '" + name + "' with the given signature as an annotation type method");  }  } public void assertAnnotation() {} public void assertTypeAnnotation() {} public void assertDefaultValue(String name) {} public void assertDefaultMethodCall() {} public void assertType(int modifier, boolean definesInterfaces, boolean isGeneric) { if ((modifier & 0x200) == 0) throw new IllegalStateException("Cannot define annotation type without interface modifier");  } public void assertTypeInConstantPool() {} public void assertMethodTypeInConstantPool() {} public void assertHandleInConstantPool() {} public void assertInvokeDynamic() {} public void assertSubRoutine() {} public void assertDynamicValueInConstantPool() {} public void assertNestMate() {} public void assertRecord() {} public void assertPermittedSubclass() {} } @Enhance public static class ForClassFileVersion implements Constraint { private final ClassFileVersion classFileVersion; protected ForClassFileVersion(ClassFileVersion classFileVersion) { this.classFileVersion = classFileVersion; } public void assertType(int modifiers, boolean definesInterfaces, boolean isGeneric) { if ((modifiers & 0x2000) != 0 && !this.classFileVersion.isAtLeast(ClassFileVersion.JAVA_V5)) throw new IllegalStateException("Cannot define annotation type for class file version " + this.classFileVersion);  if (isGeneric && !this.classFileVersion.isAtLeast(ClassFileVersion.JAVA_V4)) throw new IllegalStateException("Cannot define a generic type for class file version " + this.classFileVersion);  } public void assertField(String name, boolean isPublic, boolean isStatic, boolean isFinal, boolean isGeneric) { if (isGeneric && !this.classFileVersion.isAtLeast(ClassFileVersion.JAVA_V4)) throw new IllegalStateException("Cannot define generic field '" + name + "' for class file version " + this.classFileVersion);  } public void assertMethod(String name, boolean isAbstract, boolean isPublic, boolean isPrivate, boolean isStatic, boolean isVirtual, boolean isConstructor, boolean isDefaultValueIncompatible, boolean isGeneric) { if (isGeneric && !this.classFileVersion.isAtLeast(ClassFileVersion.JAVA_V4)) throw new IllegalStateException("Cannot define generic method '" + name + "' for class file version " + this.classFileVersion);  if (!isVirtual && isAbstract) throw new IllegalStateException("Cannot define static or non-virtual method '" + name + "' to be abstract");  } public void assertAnnotation() { if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V5)) throw new IllegalStateException("Cannot write annotations for class file version " + this.classFileVersion);  } public void assertTypeAnnotation() { if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V5)) throw new IllegalStateException("Cannot write type annotations for class file version " + this.classFileVersion);  } public void assertDefaultValue(String name) {} public void assertDefaultMethodCall() { if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V8)) throw new IllegalStateException("Cannot invoke default method for class file version " + this.classFileVersion);  } public void assertTypeInConstantPool() { if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V5)) throw new IllegalStateException("Cannot write type to constant pool for class file version " + this.classFileVersion);  } public void assertMethodTypeInConstantPool() { if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V7)) throw new IllegalStateException("Cannot write method type to constant pool for class file version " + this.classFileVersion);  } public void assertHandleInConstantPool() { if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V7)) throw new IllegalStateException("Cannot write method handle to constant pool for class file version " + this.classFileVersion);  } public void assertInvokeDynamic() { if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V7)) throw new IllegalStateException("Cannot write invoke dynamic instruction for class file version " + this.classFileVersion);  } public void assertSubRoutine() { if (this.classFileVersion.isGreaterThan(ClassFileVersion.JAVA_V5)) throw new IllegalStateException("Cannot write subroutine for class file version " + this.classFileVersion);  } public void assertDynamicValueInConstantPool() { if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V11)) throw new IllegalStateException("Cannot write dynamic constant for class file version " + this.classFileVersion);  } public void assertNestMate() { if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V11)) throw new IllegalStateException("Cannot define nest mate for class file version " + this.classFileVersion);  } public void assertRecord() { if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V14)) throw new IllegalStateException("Cannot define record for class file version " + this.classFileVersion);  } public void assertPermittedSubclass() { if (this.classFileVersion.isLessThan(ClassFileVersion.JAVA_V17)) throw new IllegalStateException("Cannot define permitted subclasses for class file version " + this.classFileVersion);
/*      */              }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.classFileVersion.equals(((ForClassFileVersion)param4Object).classFileVersion))));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return getClass().hashCode() * 31 + this.classFileVersion.hashCode();
/*      */           } }
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         public static class Compound
/*      */           implements Constraint
/*      */         {
/* 3616 */           private final List<TypeWriter.Default.ValidatingClassVisitor.Constraint> constraints = new ArrayList<TypeWriter.Default.ValidatingClassVisitor.Constraint>(); public Compound(List<? extends TypeWriter.Default.ValidatingClassVisitor.Constraint> constraints) {
/* 3617 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : constraints) {
/* 3618 */               if (constraint instanceof Compound) {
/* 3619 */                 this.constraints.addAll(((Compound)constraint).constraints); continue;
/*      */               } 
/* 3621 */               this.constraints.add(constraint);
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void assertType(int modifier, boolean definesInterfaces, boolean isGeneric) {
/* 3630 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) {
/* 3631 */               constraint.assertType(modifier, definesInterfaces, isGeneric);
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void assertField(String name, boolean isPublic, boolean isStatic, boolean isFinal, boolean isGeneric) {
/* 3639 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) {
/* 3640 */               constraint.assertField(name, isPublic, isStatic, isFinal, isGeneric);
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void assertMethod(String name, boolean isAbstract, boolean isPublic, boolean isPrivate, boolean isStatic, boolean isVirtual, boolean isConstructor, boolean isDefaultValueIncompatible, boolean isGeneric) {
/* 3656 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) {
/* 3657 */               constraint.assertMethod(name, isAbstract, isPublic, isPrivate, isStatic, isVirtual, isConstructor, isDefaultValueIncompatible, isGeneric);
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void assertDefaultValue(String name) {
/* 3673 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) {
/* 3674 */               constraint.assertDefaultValue(name);
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void assertDefaultMethodCall() {
/* 3682 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) {
/* 3683 */               constraint.assertDefaultMethodCall();
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void assertAnnotation() {
/* 3691 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) {
/* 3692 */               constraint.assertAnnotation();
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void assertTypeAnnotation() {
/* 3700 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) {
/* 3701 */               constraint.assertTypeAnnotation();
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void assertTypeInConstantPool() {
/* 3709 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) {
/* 3710 */               constraint.assertTypeInConstantPool();
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void assertMethodTypeInConstantPool() {
/* 3718 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) {
/* 3719 */               constraint.assertMethodTypeInConstantPool();
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void assertHandleInConstantPool() {
/* 3727 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) {
/* 3728 */               constraint.assertHandleInConstantPool();
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void assertInvokeDynamic() {
/* 3736 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) {
/* 3737 */               constraint.assertInvokeDynamic();
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void assertSubRoutine() {
/* 3745 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) {
/* 3746 */               constraint.assertSubRoutine();
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void assertDynamicValueInConstantPool() {
/* 3754 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) {
/* 3755 */               constraint.assertDynamicValueInConstantPool();
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void assertNestMate() {
/* 3763 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) {
/* 3764 */               constraint.assertNestMate();
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void assertRecord() {
/* 3772 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) {
/* 3773 */               constraint.assertRecord();
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public void assertPermittedSubclass()
/*      */           {
/* 3781 */             for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints)
/* 3782 */               constraint.assertPermittedSubclass();  } public boolean equals(@MaybeNull Object param4Object) { return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.constraints.equals(((Compound)param4Object).constraints)))); } public int hashCode() { return getClass().hashCode() * 31 + this.constraints.hashCode(); } } } @Enhance public static class Compound implements Constraint { private final List<TypeWriter.Default.ValidatingClassVisitor.Constraint> constraints = new ArrayList<TypeWriter.Default.ValidatingClassVisitor.Constraint>(); public Compound(List<? extends TypeWriter.Default.ValidatingClassVisitor.Constraint> constraints) { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : constraints) { if (constraint instanceof Compound) { this.constraints.addAll(((Compound)constraint).constraints); continue; }  this.constraints.add(constraint); }  } public void assertType(int modifier, boolean definesInterfaces, boolean isGeneric) { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) constraint.assertType(modifier, definesInterfaces, isGeneric);  } public void assertField(String name, boolean isPublic, boolean isStatic, boolean isFinal, boolean isGeneric) { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) constraint.assertField(name, isPublic, isStatic, isFinal, isGeneric);  } public void assertMethod(String name, boolean isAbstract, boolean isPublic, boolean isPrivate, boolean isStatic, boolean isVirtual, boolean isConstructor, boolean isDefaultValueIncompatible, boolean isGeneric) { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) constraint.assertMethod(name, isAbstract, isPublic, isPrivate, isStatic, isVirtual, isConstructor, isDefaultValueIncompatible, isGeneric);  } public void assertDefaultValue(String name) { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) constraint.assertDefaultValue(name);  } public void assertDefaultMethodCall() { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) constraint.assertDefaultMethodCall();  } public void assertAnnotation() { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) constraint.assertAnnotation();  } public void assertTypeAnnotation() { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) constraint.assertTypeAnnotation();  } public void assertTypeInConstantPool() { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) constraint.assertTypeInConstantPool();  } public void assertMethodTypeInConstantPool() { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) constraint.assertMethodTypeInConstantPool();  } public void assertHandleInConstantPool() { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) constraint.assertHandleInConstantPool();  } public void assertInvokeDynamic() { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) constraint.assertInvokeDynamic();  } public void assertSubRoutine() { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) constraint.assertSubRoutine();  } public void assertDynamicValueInConstantPool() { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) constraint.assertDynamicValueInConstantPool();  } public void assertNestMate() { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) constraint.assertNestMate();  } public void assertRecord() { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) constraint.assertRecord();  } public void assertPermittedSubclass() { for (TypeWriter.Default.ValidatingClassVisitor.Constraint constraint : this.constraints) constraint.assertPermittedSubclass();
/*      */            }
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.constraints.equals(((Compound)param3Object).constraints))));
/*      */         }
/*      */         
/*      */         public int hashCode() {
/*      */           return getClass().hashCode() * 31 + this.constraints.hashCode();
/*      */         } }
/*      */ 
/*      */       
/*      */       protected class ValidatingFieldVisitor
/*      */         extends FieldVisitor
/*      */       {
/*      */         protected ValidatingFieldVisitor(FieldVisitor fieldVisitor) {
/* 3799 */           super(OpenedClassReader.ASM_API, fieldVisitor);
/*      */         }
/*      */ 
/*      */         
/*      */         public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/* 3804 */           TypeWriter.Default.ValidatingClassVisitor.this.constraint.assertAnnotation();
/* 3805 */           return super.visitAnnotation(descriptor, visible);
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected class ValidatingMethodVisitor
/*      */         extends MethodVisitor
/*      */       {
/*      */         private final String name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected ValidatingMethodVisitor(MethodVisitor methodVisitor, String name) {
/* 3826 */           super(OpenedClassReader.ASM_API, methodVisitor);
/* 3827 */           this.name = name;
/*      */         }
/*      */ 
/*      */         
/*      */         @MaybeNull
/*      */         public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/* 3833 */           TypeWriter.Default.ValidatingClassVisitor.this.constraint.assertAnnotation();
/* 3834 */           return super.visitAnnotation(descriptor, visible);
/*      */         }
/*      */ 
/*      */         
/*      */         @MaybeNull
/*      */         public AnnotationVisitor visitAnnotationDefault() {
/* 3840 */           TypeWriter.Default.ValidatingClassVisitor.this.constraint.assertDefaultValue(this.name);
/* 3841 */           return super.visitAnnotationDefault();
/*      */         }
/*      */ 
/*      */         
/*      */         @SuppressFBWarnings(value = {"SF_SWITCH_NO_DEFAULT"}, justification = "Fall through to default case is intentional.")
/*      */         public void visitLdcInsn(Object value) {
/* 3847 */           if (value instanceof Type) {
/* 3848 */             Type type = (Type)value;
/* 3849 */             switch (type.getSort()) {
/*      */               case 9:
/*      */               case 10:
/* 3852 */                 TypeWriter.Default.ValidatingClassVisitor.this.constraint.assertTypeInConstantPool();
/*      */                 break;
/*      */               case 11:
/* 3855 */                 TypeWriter.Default.ValidatingClassVisitor.this.constraint.assertMethodTypeInConstantPool();
/*      */                 break;
/*      */             } 
/* 3858 */           } else if (value instanceof Handle) {
/* 3859 */             TypeWriter.Default.ValidatingClassVisitor.this.constraint.assertHandleInConstantPool();
/* 3860 */           } else if (value instanceof net.bytebuddy.jar.asm.ConstantDynamic) {
/* 3861 */             TypeWriter.Default.ValidatingClassVisitor.this.constraint.assertDynamicValueInConstantPool();
/*      */           } 
/* 3863 */           super.visitLdcInsn(value);
/*      */         }
/*      */ 
/*      */         
/*      */         public void visitMethodInsn(int opcode, String owner, String name, String descriptor, boolean isInterface) {
/* 3868 */           if (isInterface && opcode == 183) {
/* 3869 */             TypeWriter.Default.ValidatingClassVisitor.this.constraint.assertDefaultMethodCall();
/*      */           }
/* 3871 */           super.visitMethodInsn(opcode, owner, name, descriptor, isInterface);
/*      */         }
/*      */ 
/*      */         
/*      */         public void visitInvokeDynamicInsn(String name, String descriptor, Handle bootstrapMethod, Object... bootstrapArgument) {
/* 3876 */           TypeWriter.Default.ValidatingClassVisitor.this.constraint.assertInvokeDynamic();
/* 3877 */           for (Object constant : bootstrapArgument) {
/* 3878 */             if (constant instanceof net.bytebuddy.jar.asm.ConstantDynamic) {
/* 3879 */               TypeWriter.Default.ValidatingClassVisitor.this.constraint.assertDynamicValueInConstantPool();
/*      */             }
/*      */           } 
/* 3882 */           super.visitInvokeDynamicInsn(name, descriptor, bootstrapMethod, bootstrapArgument);
/*      */         }
/*      */ 
/*      */         
/*      */         public void visitJumpInsn(int opcode, Label label) {
/* 3887 */           if (opcode == 168) {
/* 3888 */             TypeWriter.Default.ValidatingClassVisitor.this.constraint.assertSubRoutine();
/*      */           }
/* 3890 */           super.visitJumpInsn(opcode, label);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static abstract class ForInlining<U>
/*      */       extends Default<U>
/*      */     {
/*      */       @AlwaysNull
/* 3907 */       private static final FieldVisitor IGNORE_FIELD = null;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @AlwaysNull
/* 3913 */       private static final MethodVisitor IGNORE_METHOD = null;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @AlwaysNull
/* 3919 */       private static final RecordComponentVisitor IGNORE_RECORD_COMPONENT = null;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @AlwaysNull
/* 3925 */       private static final AnnotationVisitor IGNORE_ANNOTATION = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected final TypeDescription originalType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected final ClassFileLocator classFileLocator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected ForInlining(TypeDescription instrumentedType, ClassFileVersion classFileVersion, TypeWriter.FieldPool fieldPool, TypeWriter.RecordComponentPool recordComponentPool, List<? extends DynamicType> auxiliaryTypes, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, MethodList<?> instrumentedMethods, RecordComponentList<RecordComponentDescription.InDefinedShape> recordComponents, LoadedTypeInitializer loadedTypeInitializer, TypeInitializer typeInitializer, TypeAttributeAppender typeAttributeAppender, AsmVisitorWrapper asmVisitorWrapper, AnnotationValueFilter.Factory annotationValueFilterFactory, AnnotationRetention annotationRetention, AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy, Implementation.Context.Factory implementationContextFactory, TypeValidation typeValidation, AsmClassReader.Factory classReaderFactory, AsmClassWriter.Factory classWriterFactory, TypePool typePool, TypeDescription originalType, ClassFileLocator classFileLocator) {
/* 3987 */         super(instrumentedType, classFileVersion, fieldPool, recordComponentPool, auxiliaryTypes, fields, methods, instrumentedMethods, recordComponents, loadedTypeInitializer, typeInitializer, typeAttributeAppender, asmVisitorWrapper, annotationValueFilterFactory, annotationRetention, auxiliaryTypeNamingStrategy, implementationContextFactory, typeValidation, classReaderFactory, classWriterFactory, typePool);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4008 */         this.originalType = originalType;
/* 4009 */         this.classFileLocator = classFileLocator;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ContextClassVisitor wrap(ClassVisitor classVisitor, int writerFlags, int readerFlags) {
/* 4016 */         ContextRegistry contextRegistry = new ContextRegistry();
/* 4017 */         return new RegistryContextClassVisitor(writeTo(TypeWriter.Default.ValidatingClassVisitor.of(classVisitor, this.typeValidation), this.typeInitializer, contextRegistry, this.asmVisitorWrapper
/*      */ 
/*      */               
/* 4020 */               .mergeWriter(writerFlags), this.asmVisitorWrapper
/* 4021 */               .mergeReader(readerFlags)), contextRegistry);
/*      */       }
/*      */ 
/*      */       
/*      */       protected TypeWriter.Default<U>.UnresolvedType create(TypeInitializer typeInitializer, TypeWriter.Default.ClassDumpAction.Dispatcher dispatcher) {
/*      */         try {
/* 4027 */           int writerFlags = this.asmVisitorWrapper.mergeWriter(0);
/* 4028 */           int readerFlags = this.asmVisitorWrapper.mergeReader(0);
/* 4029 */           byte[] binaryRepresentation = this.classFileLocator.locate(this.originalType.getName()).resolve();
/* 4030 */           dispatcher.dump(this.instrumentedType, true, binaryRepresentation);
/* 4031 */           AsmClassReader classReader = this.classReaderFactory.make(binaryRepresentation);
/* 4032 */           AsmClassWriter classWriter = this.classWriterFactory.make(writerFlags, classReader, this.typePool);
/* 4033 */           ContextRegistry contextRegistry = new ContextRegistry();
/* 4034 */           classReader.accept(writeTo(TypeWriter.Default.ValidatingClassVisitor.of(classWriter.getVisitor(), this.typeValidation), typeInitializer, contextRegistry, writerFlags, readerFlags), readerFlags);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4039 */           return new TypeWriter.Default.UnresolvedType(classWriter.getBinaryRepresentation(), contextRegistry.getAuxiliaryTypes());
/* 4040 */         } catch (IOException exception) {
/* 4041 */           throw new RuntimeException("The class file could not be written", exception);
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected abstract ClassVisitor writeTo(ClassVisitor param2ClassVisitor, TypeInitializer param2TypeInitializer, ContextRegistry param2ContextRegistry, int param2Int1, int param2Int2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return !super.equals(param2Object) ? false : ((this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.originalType.equals(((ForInlining)param2Object).originalType) ? false : (!!this.classFileLocator.equals(((ForInlining)param2Object).classFileLocator))))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return (super.hashCode() * 31 + this.originalType.hashCode()) * 31 + this.classFileLocator.hashCode();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected class RegistryContextClassVisitor
/*      */         extends ContextClassVisitor
/*      */       {
/*      */         private final TypeWriter.Default.ForInlining.ContextRegistry contextRegistry;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected RegistryContextClassVisitor(ClassVisitor classVisitor, TypeWriter.Default.ForInlining.ContextRegistry contextRegistry) {
/* 4078 */           super(classVisitor);
/* 4079 */           this.contextRegistry = contextRegistry;
/*      */         }
/*      */ 
/*      */         
/*      */         public List<DynamicType> getAuxiliaryTypes() {
/* 4084 */           return CompoundList.of(TypeWriter.Default.ForInlining.this.auxiliaryTypes, this.contextRegistry.getAuxiliaryTypes());
/*      */         }
/*      */ 
/*      */         
/*      */         public LoadedTypeInitializer getLoadedTypeInitializer() {
/* 4089 */           return TypeWriter.Default.ForInlining.this.loadedTypeInitializer;
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected static class ContextRegistry
/*      */       {
/*      */         @UnknownNull
/*      */         private Implementation.Context.ExtractableView implementationContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public void setImplementationContext(Implementation.Context.ExtractableView implementationContext) {
/* 4110 */           this.implementationContext = implementationContext;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @SuppressFBWarnings(value = {"UWF_FIELD_NOT_INITIALIZED_IN_CONSTRUCTOR"}, justification = "Lazy value definition is intended.")
/*      */         public List<DynamicType> getAuxiliaryTypes() {
/* 4121 */           return this.implementationContext.getAuxiliaryTypes();
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       protected static class WithFullProcessing<V>
/*      */         extends ForInlining<V>
/*      */       {
/* 4136 */         private static final Object[] EMPTY = new Object[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final MethodRegistry.Prepared methodRegistry;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final Implementation.Target.Factory implementationTargetFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final MethodRebaseResolver methodRebaseResolver;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected WithFullProcessing(TypeDescription instrumentedType, ClassFileVersion classFileVersion, TypeWriter.FieldPool fieldPool, TypeWriter.RecordComponentPool recordComponentPool, List<? extends DynamicType> auxiliaryTypes, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, MethodList<?> instrumentedMethods, RecordComponentList<RecordComponentDescription.InDefinedShape> recordComponents, LoadedTypeInitializer loadedTypeInitializer, TypeInitializer typeInitializer, TypeAttributeAppender typeAttributeAppender, AsmVisitorWrapper asmVisitorWrapper, AnnotationValueFilter.Factory annotationValueFilterFactory, AnnotationRetention annotationRetention, AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy, Implementation.Context.Factory implementationContextFactory, TypeValidation typeValidation, AsmClassReader.Factory classReaderFactory, AsmClassWriter.Factory classWriterFactory, TypePool typePool, TypeDescription originalType, ClassFileLocator classFileLocator, MethodRegistry.Prepared methodRegistry, Implementation.Target.Factory implementationTargetFactory, MethodRebaseResolver methodRebaseResolver) {
/* 4208 */           super(instrumentedType, classFileVersion, fieldPool, recordComponentPool, auxiliaryTypes, fields, methods, instrumentedMethods, recordComponents, loadedTypeInitializer, typeInitializer, typeAttributeAppender, asmVisitorWrapper, annotationValueFilterFactory, annotationRetention, auxiliaryTypeNamingStrategy, implementationContextFactory, typeValidation, classReaderFactory, classWriterFactory, typePool, originalType, classFileLocator);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4231 */           this.methodRegistry = methodRegistry;
/* 4232 */           this.implementationTargetFactory = implementationTargetFactory;
/* 4233 */           this.methodRebaseResolver = methodRebaseResolver;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected ClassVisitor writeTo(ClassVisitor classVisitor, TypeInitializer typeInitializer, TypeWriter.Default.ForInlining.ContextRegistry contextRegistry, int writerFlags, int readerFlags) {
/* 4240 */           RedefinitionClassVisitor redefinitionClassVisitor = new RedefinitionClassVisitor(classVisitor, typeInitializer, contextRegistry, writerFlags, readerFlags);
/* 4241 */           return this.originalType.getName().equals(this.instrumentedType.getName()) ? (ClassVisitor)redefinitionClassVisitor : (ClassVisitor)new OpenedClassRemapper((ClassVisitor)redefinitionClassVisitor, (Remapper)new SimpleRemapper(OpenedClassReader.ASM_API, this.originalType
/*      */                 
/* 4243 */                 .getInternalName(), this.instrumentedType.getInternalName()));
/*      */         }
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.methodRegistry.equals(((WithFullProcessing)param3Object).methodRegistry) ? false : (!this.implementationTargetFactory.equals(((WithFullProcessing)param3Object).implementationTargetFactory) ? false : (!!this.methodRebaseResolver.equals(((WithFullProcessing)param3Object).methodRebaseResolver)))))));
/*      */         }
/*      */         
/*      */         public int hashCode() {
/*      */           return ((super.hashCode() * 31 + this.methodRegistry.hashCode()) * 31 + this.implementationTargetFactory.hashCode()) * 31 + this.methodRebaseResolver.hashCode();
/*      */         }
/*      */         
/*      */         protected static class OpenedClassRemapper
/*      */           extends ClassRemapper
/*      */         {
/*      */           protected OpenedClassRemapper(ClassVisitor classVisitor, Remapper remapper) {
/* 4258 */             super(OpenedClassReader.ASM_API, classVisitor, remapper);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected static interface InitializationHandler
/*      */         {
/*      */           void complete(ClassVisitor param4ClassVisitor, Implementation.Context.ExtractableView param4ExtractableView);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static class Creating
/*      */             extends TypeInitializer.Drain.Default
/*      */             implements InitializationHandler
/*      */           {
/*      */             protected Creating(TypeDescription instrumentedType, TypeWriter.MethodPool methodPool, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/* 4290 */               super(instrumentedType, methodPool, annotationValueFilterFactory);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public void complete(ClassVisitor classVisitor, Implementation.Context.ExtractableView implementationContext) {
/* 4297 */               implementationContext.drain(this, classVisitor, this.annotationValueFilterFactory);
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static abstract class Appending
/*      */             extends MethodVisitor
/*      */             implements InitializationHandler, TypeInitializer.Drain
/*      */           {
/*      */             protected final TypeDescription instrumentedType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected final TypeWriter.MethodPool.Record record;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected final AnnotationValueFilter.Factory annotationValueFilterFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected final FrameWriter frameWriter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected int stackSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected int localVariableLength;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected Appending(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) {
/* 4352 */               super(OpenedClassReader.ASM_API, methodVisitor);
/* 4353 */               this.instrumentedType = instrumentedType;
/* 4354 */               this.record = record;
/* 4355 */               this.annotationValueFilterFactory = annotationValueFilterFactory;
/* 4356 */               if (!requireFrames) {
/* 4357 */                 this.frameWriter = FrameWriter.NoOp.INSTANCE;
/* 4358 */               } else if (expandFrames) {
/* 4359 */                 this.frameWriter = FrameWriter.Expanding.INSTANCE;
/*      */               } else {
/* 4361 */                 this.frameWriter = new FrameWriter.Active();
/*      */               } 
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected static TypeWriter.Default.ForInlining.WithFullProcessing.InitializationHandler of(boolean enabled, MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool methodPool, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) {
/* 4384 */               return enabled ? 
/* 4385 */                 withDrain(methodVisitor, instrumentedType, methodPool, annotationValueFilterFactory, requireFrames, expandFrames) : 
/* 4386 */                 withoutDrain(methodVisitor, instrumentedType, methodPool, annotationValueFilterFactory, requireFrames, expandFrames);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private static WithDrain withDrain(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool methodPool, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) {
/* 4406 */               TypeWriter.MethodPool.Record record = methodPool.target((MethodDescription)new MethodDescription.Latent.TypeInitializer(instrumentedType));
/* 4407 */               return record.getSort().isImplemented() ? new WithDrain.WithActiveRecord(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames) : new WithDrain.WithoutActiveRecord(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private static WithoutDrain withoutDrain(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool methodPool, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) {
/* 4429 */               TypeWriter.MethodPool.Record record = methodPool.target((MethodDescription)new MethodDescription.Latent.TypeInitializer(instrumentedType));
/* 4430 */               return record.getSort().isImplemented() ? new WithoutDrain.WithActiveRecord(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames) : new WithoutDrain.WithoutActiveRecord(methodVisitor, instrumentedType, record, annotationValueFilterFactory);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public void visitCode() {
/* 4437 */               this.record.applyAttributes(this.mv, this.annotationValueFilterFactory);
/* 4438 */               super.visitCode();
/* 4439 */               onStart();
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             protected abstract void onStart();
/*      */ 
/*      */ 
/*      */             
/*      */             public void visitFrame(int type, int localVariableLength, @MaybeNull Object[] localVariable, int stackSize, @MaybeNull Object[] stack) {
/* 4449 */               super.visitFrame(type, localVariableLength, localVariable, stackSize, stack);
/* 4450 */               this.frameWriter.onFrame(type, localVariableLength);
/*      */             }
/*      */ 
/*      */             
/*      */             public void visitMaxs(int stackSize, int localVariableLength) {
/* 4455 */               this.stackSize = stackSize;
/* 4456 */               this.localVariableLength = localVariableLength;
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public abstract void visitEnd();
/*      */ 
/*      */ 
/*      */             
/*      */             public void apply(ClassVisitor classVisitor, TypeInitializer typeInitializer, Implementation.Context implementationContext) {
/* 4466 */               ByteCodeAppender.Size size = typeInitializer.apply(this.mv, implementationContext, (MethodDescription)new MethodDescription.Latent.TypeInitializer(this.instrumentedType));
/* 4467 */               this.stackSize = Math.max(this.stackSize, size.getOperandStackSize());
/* 4468 */               this.localVariableLength = Math.max(this.localVariableLength, size.getLocalVariableSize());
/* 4469 */               onComplete(implementationContext);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected abstract void onComplete(Implementation.Context param5Context);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public void complete(ClassVisitor classVisitor, Implementation.Context.ExtractableView implementationContext) {
/* 4483 */               implementationContext.drain(this, classVisitor, this.annotationValueFilterFactory);
/* 4484 */               this.mv.visitMaxs(this.stackSize, this.localVariableLength);
/* 4485 */               this.mv.visitEnd();
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected static interface FrameWriter
/*      */             {
/* 4496 */               public static final Object[] EMPTY = new Object[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               void onFrame(int param6Int1, int param6Int2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               void emitFrame(MethodVisitor param6MethodVisitor);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public enum NoOp
/*      */                 implements FrameWriter
/*      */               {
/* 4521 */                 INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public void onFrame(int type, int localVariableLength) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public void emitFrame(MethodVisitor methodVisitor) {}
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public enum Expanding
/*      */                 implements FrameWriter
/*      */               {
/* 4546 */                 INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public void onFrame(int type, int localVariableLength) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public void emitFrame(MethodVisitor methodVisitor) {
/* 4559 */                   methodVisitor.visitFrame(-1, EMPTY.length, EMPTY, EMPTY.length, EMPTY);
/* 4560 */                   methodVisitor.visitInsn(0);
/*      */                 }
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public static class Active
/*      */                 implements FrameWriter
/*      */               {
/*      */                 private int currentLocalVariableLength;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public void onFrame(int type, int localVariableLength) {
/* 4578 */                   switch (type) {
/*      */                     case 3:
/*      */                     case 4:
/*      */                       return;
/*      */                     case 1:
/* 4583 */                       this.currentLocalVariableLength += localVariableLength;
/*      */                     
/*      */                     case 2:
/* 4586 */                       this.currentLocalVariableLength -= localVariableLength;
/*      */                     
/*      */                     case -1:
/*      */                     case 0:
/* 4590 */                       this.currentLocalVariableLength = localVariableLength;
/*      */                   } 
/*      */                   
/* 4593 */                   throw new IllegalStateException("Unexpected frame type: " + type);
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public void emitFrame(MethodVisitor methodVisitor)
/*      */                 {
/* 4601 */                   if (this.currentLocalVariableLength == 0) {
/* 4602 */                     methodVisitor.visitFrame(3, EMPTY.length, EMPTY, EMPTY.length, EMPTY);
/* 4603 */                   } else if (this.currentLocalVariableLength > 3) {
/* 4604 */                     methodVisitor.visitFrame(0, EMPTY.length, EMPTY, EMPTY.length, EMPTY);
/*      */                   } else {
/* 4606 */                     methodVisitor.visitFrame(2, this.currentLocalVariableLength, EMPTY, EMPTY.length, EMPTY);
/*      */                   } 
/* 4608 */                   methodVisitor.visitInsn(0);
/* 4609 */                   this.currentLocalVariableLength = 0; } } } public enum NoOp implements FrameWriter { INSTANCE; public void onFrame(int type, int localVariableLength) {} public void emitFrame(MethodVisitor methodVisitor) {} } public enum Expanding implements FrameWriter { INSTANCE; public void onFrame(int type, int localVariableLength) {} public void emitFrame(MethodVisitor methodVisitor) { methodVisitor.visitFrame(-1, EMPTY.length, EMPTY, EMPTY.length, EMPTY); methodVisitor.visitInsn(0); } } public static class Active implements FrameWriter { private int currentLocalVariableLength; public void onFrame(int type, int localVariableLength) { switch (type) { case 3: case 4: return;case 1: this.currentLocalVariableLength += localVariableLength;case 2: this.currentLocalVariableLength -= localVariableLength;case -1: case 0: this.currentLocalVariableLength = localVariableLength; }  throw new IllegalStateException("Unexpected frame type: " + type); } public void emitFrame(MethodVisitor methodVisitor) { if (this.currentLocalVariableLength == 0) { methodVisitor.visitFrame(3, EMPTY.length, EMPTY, EMPTY.length, EMPTY); } else if (this.currentLocalVariableLength > 3) { methodVisitor.visitFrame(0, EMPTY.length, EMPTY, EMPTY.length, EMPTY); } else { methodVisitor.visitFrame(2, this.currentLocalVariableLength, EMPTY, EMPTY.length, EMPTY); }  methodVisitor.visitInsn(0); this.currentLocalVariableLength = 0; }
/*      */                }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected static abstract class WithoutDrain
/*      */               extends Appending
/*      */             {
/*      */               protected WithoutDrain(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) {
/* 4636 */                 super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected void onStart() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public void visitEnd() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected static class WithoutActiveRecord
/*      */                 extends WithoutDrain
/*      */               {
/*      */                 protected WithoutActiveRecord(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/* 4667 */                   super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, false, false);
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 protected void onComplete(Implementation.Context implementationContext) {}
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected static class WithActiveRecord
/*      */                 extends WithoutDrain
/*      */               {
/*      */                 private final Label label;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 protected WithActiveRecord(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) {
/* 4703 */                   super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames);
/* 4704 */                   this.label = new Label();
/*      */                 }
/*      */ 
/*      */                 
/*      */                 public void visitInsn(int opcode) {
/* 4709 */                   if (opcode == 177) {
/* 4710 */                     this.mv.visitJumpInsn(167, this.label);
/*      */                   } else {
/* 4712 */                     super.visitInsn(opcode);
/*      */                   } 
/*      */                 }
/*      */                 
/*      */                 protected void onComplete(Implementation.Context implementationContext)
/*      */                 {
/* 4718 */                   this.mv.visitLabel(this.label);
/* 4719 */                   this.frameWriter.emitFrame(this.mv);
/* 4720 */                   ByteCodeAppender.Size size = this.record.applyCode(this.mv, implementationContext);
/* 4721 */                   this.stackSize = Math.max(this.stackSize, size.getOperandStackSize());
/* 4722 */                   this.localVariableLength = Math.max(this.localVariableLength, size.getLocalVariableSize()); } } } protected static class WithoutActiveRecord extends WithoutDrain { protected WithoutActiveRecord(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory) { super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, false, false); } protected void onComplete(Implementation.Context implementationContext) {} } protected static class WithActiveRecord extends WithoutDrain { private final Label label; protected WithActiveRecord(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) { super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames); this.label = new Label(); } public void visitInsn(int opcode) { if (opcode == 177) { this.mv.visitJumpInsn(167, this.label); } else { super.visitInsn(opcode); }  } protected void onComplete(Implementation.Context implementationContext) { this.mv.visitLabel(this.label); this.frameWriter.emitFrame(this.mv); ByteCodeAppender.Size size = this.record.applyCode(this.mv, implementationContext); this.stackSize = Math.max(this.stackSize, size.getOperandStackSize()); this.localVariableLength = Math.max(this.localVariableLength, size.getLocalVariableSize()); }
/*      */                }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected static abstract class WithDrain
/*      */               extends Appending
/*      */             {
/*      */               protected final Label appended;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected final Label original;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected WithDrain(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) {
/* 4760 */                 super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames);
/* 4761 */                 this.appended = new Label();
/* 4762 */                 this.original = new Label();
/*      */               }
/*      */ 
/*      */               
/*      */               protected void onStart() {
/* 4767 */                 this.mv.visitJumpInsn(167, this.appended);
/* 4768 */                 this.mv.visitLabel(this.original);
/* 4769 */                 this.frameWriter.emitFrame(this.mv);
/*      */               }
/*      */ 
/*      */               
/*      */               public void visitEnd() {
/* 4774 */                 this.mv.visitLabel(this.appended);
/* 4775 */                 this.frameWriter.emitFrame(this.mv);
/*      */               }
/*      */ 
/*      */               
/*      */               protected void onComplete(Implementation.Context implementationContext) {
/* 4780 */                 this.mv.visitJumpInsn(167, this.original);
/* 4781 */                 onAfterComplete(implementationContext);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected abstract void onAfterComplete(Implementation.Context param6Context);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected static class WithoutActiveRecord
/*      */                 extends WithDrain
/*      */               {
/*      */                 protected WithoutActiveRecord(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) {
/* 4812 */                   super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames);
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 protected void onAfterComplete(Implementation.Context implementationContext) {}
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected static class WithActiveRecord
/*      */                 extends WithDrain
/*      */               {
/*      */                 private final Label label;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 protected WithActiveRecord(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) {
/* 4847 */                   super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames);
/* 4848 */                   this.label = new Label();
/*      */                 }
/*      */ 
/*      */                 
/*      */                 public void visitInsn(int opcode) {
/* 4853 */                   if (opcode == 177) {
/* 4854 */                     this.mv.visitJumpInsn(167, this.label);
/*      */                   } else {
/* 4856 */                     super.visitInsn(opcode);
/*      */                   } 
/*      */                 }
/*      */                 
/*      */                 protected void onAfterComplete(Implementation.Context implementationContext)
/*      */                 {
/* 4862 */                   this.mv.visitLabel(this.label);
/* 4863 */                   this.frameWriter.emitFrame(this.mv);
/* 4864 */                   ByteCodeAppender.Size size = this.record.applyCode(this.mv, implementationContext);
/* 4865 */                   this.stackSize = Math.max(this.stackSize, size.getOperandStackSize());
/* 4866 */                   this.localVariableLength = Math.max(this.localVariableLength, size.getLocalVariableSize()); } } } protected static class WithoutActiveRecord extends WithDrain { protected WithoutActiveRecord(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) { super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames); } protected void onAfterComplete(Implementation.Context implementationContext) {} } protected static class WithActiveRecord extends WithDrain { private final Label label; protected WithActiveRecord(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) { super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames); this.label = new Label(); } public void visitInsn(int opcode) { if (opcode == 177) { this.mv.visitJumpInsn(167, this.label); } else { super.visitInsn(opcode); }  } protected void onAfterComplete(Implementation.Context implementationContext) { this.mv.visitLabel(this.label); this.frameWriter.emitFrame(this.mv); ByteCodeAppender.Size size = this.record.applyCode(this.mv, implementationContext); this.stackSize = Math.max(this.stackSize, size.getOperandStackSize()); this.localVariableLength = Math.max(this.localVariableLength, size.getLocalVariableSize()); }
/*      */                }
/*      */           
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @SuppressFBWarnings(value = {"UWF_FIELD_NOT_INITIALIZED_IN_CONSTRUCTOR"}, justification = "Field access order is implied by ASM.")
/*      */         protected class RedefinitionClassVisitor
/*      */           extends MetadataAwareClassVisitor
/*      */         {
/*      */           private final TypeInitializer typeInitializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final TypeWriter.Default.ForInlining.ContextRegistry contextRegistry;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final int writerFlags;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final int readerFlags;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final LinkedHashMap<TypeWriter.Default.SignatureKey, FieldDescription> declarableFields;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final LinkedHashMap<TypeWriter.Default.SignatureKey, MethodDescription> declarableMethods;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final LinkedHashMap<String, RecordComponentDescription> declarableRecordComponents;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final Set<String> nestMembers;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final LinkedHashMap<String, TypeDescription> declaredTypes;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @MaybeNull
/*      */           private final Set<String> permittedSubclasses;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @UnknownNull
/*      */           private TypeWriter.MethodPool methodPool;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @UnknownNull
/*      */           private TypeWriter.Default.ForInlining.WithFullProcessing.InitializationHandler initializationHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @UnknownNull
/*      */           private Implementation.Context.ExtractableView implementationContext;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private boolean retainDeprecationModifiers;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4956 */           private final Set<TypeWriter.Default.SignatureKey> fieldKeys = new HashSet<TypeWriter.Default.SignatureKey>();
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4961 */           private final Set<TypeWriter.Default.SignatureKey> methodsKeys = new HashSet<TypeWriter.Default.SignatureKey>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected RedefinitionClassVisitor(ClassVisitor classVisitor, TypeInitializer typeInitializer, TypeWriter.Default.ForInlining.ContextRegistry contextRegistry, int writerFlags, int readerFlags) {
/* 4977 */             super(OpenedClassReader.ASM_API, classVisitor);
/* 4978 */             this.typeInitializer = typeInitializer;
/* 4979 */             this.contextRegistry = contextRegistry;
/* 4980 */             this.writerFlags = writerFlags;
/* 4981 */             this.readerFlags = readerFlags;
/* 4982 */             this.declarableFields = new LinkedHashMap<TypeWriter.Default.SignatureKey, FieldDescription>((int)Math.ceil(TypeWriter.Default.ForInlining.WithFullProcessing.this.fields.size() / 0.75D));
/* 4983 */             for (FieldDescription fieldDescription : TypeWriter.Default.ForInlining.WithFullProcessing.this.fields) {
/* 4984 */               this.declarableFields.put(new TypeWriter.Default.SignatureKey(fieldDescription.getInternalName(), fieldDescription.getDescriptor()), fieldDescription);
/*      */             }
/* 4986 */             this.declarableMethods = new LinkedHashMap<TypeWriter.Default.SignatureKey, MethodDescription>((int)Math.ceil(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedMethods.size() / 0.75D));
/* 4987 */             for (MethodDescription methodDescription : TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedMethods) {
/* 4988 */               this.declarableMethods.put(new TypeWriter.Default.SignatureKey(methodDescription.getInternalName(), methodDescription.getDescriptor()), methodDescription);
/*      */             }
/* 4990 */             this.declarableRecordComponents = new LinkedHashMap<String, RecordComponentDescription>((int)Math.ceil(TypeWriter.Default.ForInlining.WithFullProcessing.this.recordComponents.size() / 0.75D));
/* 4991 */             for (RecordComponentDescription recordComponentDescription : TypeWriter.Default.ForInlining.WithFullProcessing.this.recordComponents) {
/* 4992 */               this.declarableRecordComponents.put(recordComponentDescription.getActualName(), recordComponentDescription);
/*      */             }
/* 4994 */             if (TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isNestHost()) {
/* 4995 */               this.nestMembers = new LinkedHashSet<String>((int)Math.ceil(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getNestMembers().size() / 0.75D));
/* 4996 */               for (TypeDescription typeDescription : TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getNestMembers().filter((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.is(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType)))) {
/* 4997 */                 this.nestMembers.add(typeDescription.getInternalName());
/*      */               }
/*      */             } else {
/* 5000 */               this.nestMembers = Collections.emptySet();
/*      */             } 
/* 5002 */             this.declaredTypes = new LinkedHashMap<String, TypeDescription>((int)Math.ceil(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getDeclaredTypes().size() / 0.75D));
/* 5003 */             for (TypeDescription typeDescription : TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getDeclaredTypes()) {
/* 5004 */               this.declaredTypes.put(typeDescription.getInternalName(), typeDescription);
/*      */             }
/* 5006 */             if (TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isSealed()) {
/* 5007 */               this.permittedSubclasses = new LinkedHashSet<String>((int)Math.ceil(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getPermittedSubtypes().size() / 0.75D));
/* 5008 */               for (TypeDescription typeDescription : TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getPermittedSubtypes()) {
/* 5009 */                 this.permittedSubclasses.add(typeDescription.getInternalName());
/*      */               }
/*      */             } else {
/* 5012 */               this.permittedSubclasses = null;
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Relying on correlated type properties.")
/*      */           public void visit(int classFileVersionNumber, int modifiers, String internalName, String genericSignature, String superClassInternalName, String[] interfaceTypeInternalName) {
/* 5024 */             ClassFileVersion classFileVersion = ClassFileVersion.ofMinorMajor(classFileVersionNumber);
/* 5025 */             this.methodPool = TypeWriter.Default.ForInlining.WithFullProcessing.this.methodRegistry.compile(TypeWriter.Default.ForInlining.WithFullProcessing.this.implementationTargetFactory, classFileVersion);
/* 5026 */             this.initializationHandler = new TypeWriter.Default.ForInlining.WithFullProcessing.InitializationHandler.Creating(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType, this.methodPool, TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory);
/* 5027 */             this.implementationContext = TypeWriter.Default.ForInlining.WithFullProcessing.this.implementationContextFactory.make(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType, TypeWriter.Default.ForInlining.WithFullProcessing.this.auxiliaryTypeNamingStrategy, this.typeInitializer, classFileVersion, TypeWriter.Default.ForInlining.WithFullProcessing.this.classFileVersion, ((this.writerFlags & 0x2) == 0 && classFileVersion
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 5032 */                 .isAtLeast(ClassFileVersion.JAVA_V6)) ? (((this.readerFlags & 0x8) == 0) ? Implementation.Context.FrameGeneration.GENERATE : Implementation.Context.FrameGeneration.EXPAND) : Implementation.Context.FrameGeneration.DISABLED);
/*      */ 
/*      */             
/* 5035 */             this.retainDeprecationModifiers = classFileVersion.isLessThan(ClassFileVersion.JAVA_V5);
/* 5036 */             this.contextRegistry.setImplementationContext(this.implementationContext);
/* 5037 */             this.cv = TypeWriter.Default.ForInlining.WithFullProcessing.this.asmVisitorWrapper.wrap(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType, this.cv, (Implementation.Context)this.implementationContext, TypeWriter.Default.ForInlining.WithFullProcessing.this.typePool, TypeWriter.Default.ForInlining.WithFullProcessing.this.fields, TypeWriter.Default.ForInlining.WithFullProcessing.this.methods, this.writerFlags, this.readerFlags);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 5045 */             this.cv.visit(classFileVersionNumber, TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType
/* 5046 */                 .getActualModifiers(((modifiers & 0x20) != 0 && !TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isInterface())) | 
/* 5047 */                 resolveDeprecationModifiers(modifiers) | (((modifiers & 0x10) != 0 && TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType
/*      */                 
/* 5049 */                 .isAnonymousType()) ? 16 : 0), TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType
/* 5050 */                 .getInternalName(), TypeDescription.AbstractBase.RAW_TYPES ? genericSignature : TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType
/*      */ 
/*      */                 
/* 5053 */                 .getGenericSignature(), 
/* 5054 */                 (TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getSuperClass() == null) ? (
/* 5055 */                 TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isInterface() ? TypeDescription.ForLoadedType.of(Object.class).getInternalName() : TypeWriter.Default.NO_REFERENCE) : TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType
/* 5056 */                 .getSuperClass().asErasure().getInternalName(), TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType
/* 5057 */                 .getInterfaces().asErasures().toInternalNames());
/*      */           }
/*      */ 
/*      */           
/*      */           protected void onVisitNestHost(String nestHost) {
/* 5062 */             onNestHost();
/*      */           }
/*      */ 
/*      */           
/*      */           protected void onNestHost() {
/* 5067 */             if (!TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isNestHost()) {
/* 5068 */               this.cv.visitNestHost(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getNestHost().getInternalName());
/*      */             }
/*      */           }
/*      */ 
/*      */           
/*      */           protected void onVisitPermittedSubclass(String permittedSubclass) {
/* 5074 */             if (this.permittedSubclasses != null && this.permittedSubclasses.remove(permittedSubclass)) {
/* 5075 */               this.cv.visitPermittedSubclass(permittedSubclass);
/*      */             }
/*      */           }
/*      */ 
/*      */           
/*      */           protected void onVisitOuterClass(String owner, @MaybeNull String name, @MaybeNull String descriptor) {
/*      */             try {
/* 5082 */               onOuterType();
/* 5083 */             } catch (Throwable ignored) {
/* 5084 */               this.cv.visitOuterClass(owner, name, descriptor);
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH"}, justification = "Relying on correlated type properties.")
/*      */           protected void onOuterType() {
/* 5091 */             MethodDescription.InDefinedShape enclosingMethod = TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getEnclosingMethod();
/* 5092 */             if (enclosingMethod != null) {
/* 5093 */               this.cv.visitOuterClass(enclosingMethod.getDeclaringType().getInternalName(), enclosingMethod
/* 5094 */                   .getInternalName(), enclosingMethod
/* 5095 */                   .getDescriptor());
/* 5096 */             } else if (TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isLocalType() || TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isAnonymousType()) {
/* 5097 */               this.cv.visitOuterClass(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getEnclosingType().getInternalName(), TypeWriter.Default.NO_REFERENCE, TypeWriter.Default.NO_REFERENCE);
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           protected void onAfterAttributes() {
/* 5103 */             TypeWriter.Default.ForInlining.WithFullProcessing.this.typeAttributeAppender.apply(this.cv, TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType, TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory.on(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType));
/*      */           }
/*      */ 
/*      */           
/*      */           @MaybeNull
/*      */           protected AnnotationVisitor onVisitTypeAnnotation(int typeReference, TypePath typePath, String descriptor, boolean visible) {
/* 5109 */             return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? this.cv
/* 5110 */               .visitTypeAnnotation(typeReference, typePath, descriptor, visible) : TypeWriter.Default.ForInlining
/* 5111 */               .IGNORE_ANNOTATION;
/*      */           }
/*      */ 
/*      */           
/*      */           @MaybeNull
/*      */           protected AnnotationVisitor onVisitAnnotation(String descriptor, boolean visible) {
/* 5117 */             return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? this.cv
/* 5118 */               .visitAnnotation(descriptor, visible) : TypeWriter.Default.ForInlining
/* 5119 */               .IGNORE_ANNOTATION;
/*      */           }
/*      */ 
/*      */           
/*      */           @MaybeNull
/*      */           protected RecordComponentVisitor onVisitRecordComponent(String name, String descriptor, @MaybeNull String genericSignature) {
/* 5125 */             RecordComponentDescription recordComponentDescription = this.declarableRecordComponents.remove(name);
/* 5126 */             if (recordComponentDescription != null) {
/* 5127 */               TypeWriter.RecordComponentPool.Record record = TypeWriter.Default.ForInlining.WithFullProcessing.this.recordComponentPool.target(recordComponentDescription);
/* 5128 */               if (!record.isImplicit()) {
/* 5129 */                 return redefine(record, genericSignature);
/*      */               }
/*      */             } 
/* 5132 */             return this.cv.visitRecordComponent(name, descriptor, genericSignature);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @MaybeNull
/*      */           protected RecordComponentVisitor redefine(TypeWriter.RecordComponentPool.Record record, @MaybeNull String genericSignature) {
/* 5144 */             RecordComponentDescription recordComponentDescription = record.getRecordComponent();
/* 5145 */             RecordComponentVisitor recordComponentVisitor = this.cv.visitRecordComponent(recordComponentDescription.getActualName(), recordComponentDescription
/* 5146 */                 .getDescriptor(), TypeDescription.AbstractBase.RAW_TYPES ? genericSignature : recordComponentDescription
/*      */ 
/*      */                 
/* 5149 */                 .getGenericSignature());
/* 5150 */             return (recordComponentVisitor == null) ? TypeWriter.Default.ForInlining
/* 5151 */               .IGNORE_RECORD_COMPONENT : new AttributeObtainingRecordComponentVisitor(recordComponentVisitor, record);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @MaybeNull
/*      */           protected FieldVisitor onVisitField(int modifiers, String internalName, String descriptor, @MaybeNull String genericSignature, @MaybeNull Object value) {
/* 5162 */             TypeWriter.Default.SignatureKey key = new TypeWriter.Default.SignatureKey(internalName, descriptor);
/* 5163 */             this.fieldKeys.add(key);
/* 5164 */             FieldDescription fieldDescription = this.declarableFields.remove(key);
/* 5165 */             if (fieldDescription != null) {
/* 5166 */               TypeWriter.FieldPool.Record record = TypeWriter.Default.ForInlining.WithFullProcessing.this.fieldPool.target(fieldDescription);
/* 5167 */               if (!record.isImplicit()) {
/* 5168 */                 return redefine(record, value, modifiers, genericSignature);
/*      */               }
/*      */             } 
/* 5171 */             return this.cv.visitField(modifiers, internalName, descriptor, genericSignature, value);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @MaybeNull
/*      */           protected FieldVisitor redefine(TypeWriter.FieldPool.Record record, @MaybeNull Object value, int modifiers, @MaybeNull String genericSignature) {
/* 5185 */             FieldDescription instrumentedField = record.getField();
/* 5186 */             FieldVisitor fieldVisitor = this.cv.visitField(instrumentedField.getActualModifiers() | resolveDeprecationModifiers(modifiers), instrumentedField
/* 5187 */                 .getInternalName(), instrumentedField
/* 5188 */                 .getDescriptor(), TypeDescription.AbstractBase.RAW_TYPES ? genericSignature : instrumentedField
/*      */ 
/*      */                 
/* 5191 */                 .getGenericSignature(), record
/* 5192 */                 .resolveDefault(value));
/* 5193 */             return (fieldVisitor == null) ? TypeWriter.Default.ForInlining
/* 5194 */               .IGNORE_FIELD : new AttributeObtainingFieldVisitor(fieldVisitor, record);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @MaybeNull
/*      */           protected MethodVisitor onVisitMethod(int modifiers, String internalName, String descriptor, @MaybeNull String genericSignature, @MaybeNull String[] exceptionName) {
/* 5205 */             if (internalName.equals("<clinit>")) {
/* 5206 */               MethodVisitor methodVisitor = this.cv.visitMethod(modifiers, internalName, descriptor, genericSignature, exceptionName);
/* 5207 */               return (methodVisitor == null) ? TypeWriter.Default.ForInlining
/* 5208 */                 .IGNORE_METHOD : 
/* 5209 */                 (MethodVisitor)(this.initializationHandler = TypeWriter.Default.ForInlining.WithFullProcessing.InitializationHandler.Appending.of(this.implementationContext.isEnabled(), methodVisitor, TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType, this.methodPool, TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory, ((this.writerFlags & 0x2) == 0 && this.implementationContext
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/* 5214 */                   .getClassFileVersion().isAtLeast(ClassFileVersion.JAVA_V6)), ((this.readerFlags & 0x8) != 0)));
/*      */             } 
/*      */             
/* 5217 */             TypeWriter.Default.SignatureKey key = new TypeWriter.Default.SignatureKey(internalName, descriptor);
/* 5218 */             this.methodsKeys.add(key);
/* 5219 */             MethodDescription methodDescription = this.declarableMethods.remove(key);
/* 5220 */             return (methodDescription == null) ? this.cv
/* 5221 */               .visitMethod(modifiers, internalName, descriptor, genericSignature, exceptionName) : 
/* 5222 */               redefine(methodDescription, ((modifiers & 0x400) != 0), modifiers, genericSignature);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @MaybeNull
/*      */           protected MethodVisitor redefine(MethodDescription methodDescription, boolean abstractOrigin, int modifiers, @MaybeNull String genericSignature) {
/* 5238 */             TypeWriter.MethodPool.Record record = this.methodPool.target(methodDescription);
/* 5239 */             if (!record.getSort().isDefined()) {
/* 5240 */               return this.cv.visitMethod(methodDescription.getActualModifiers() | resolveDeprecationModifiers(modifiers), methodDescription
/* 5241 */                   .getInternalName(), methodDescription
/* 5242 */                   .getDescriptor(), TypeDescription.AbstractBase.RAW_TYPES ? genericSignature : methodDescription
/*      */ 
/*      */                   
/* 5245 */                   .getGenericSignature(), methodDescription
/* 5246 */                   .getExceptionTypes().asErasures().toInternalNames());
/*      */             }
/* 5248 */             MethodDescription implementedMethod = record.getMethod();
/* 5249 */             MethodVisitor methodVisitor = this.cv.visitMethod(
/* 5250 */                 ModifierContributor.Resolver.of(Collections.singleton(record.getVisibility()))
/* 5251 */                 .resolve(implementedMethod.getActualModifiers(record.getSort().isImplemented())) | resolveDeprecationModifiers(modifiers), implementedMethod
/* 5252 */                 .getInternalName(), implementedMethod
/* 5253 */                 .getDescriptor(), TypeDescription.AbstractBase.RAW_TYPES ? genericSignature : implementedMethod
/*      */ 
/*      */                 
/* 5256 */                 .getGenericSignature(), implementedMethod
/* 5257 */                 .getExceptionTypes().asErasures().toInternalNames());
/* 5258 */             if (methodVisitor == null)
/* 5259 */               return TypeWriter.Default.ForInlining.IGNORE_METHOD; 
/* 5260 */             if (abstractOrigin)
/* 5261 */               return new AttributeObtainingMethodVisitor(methodVisitor, record); 
/* 5262 */             if (methodDescription.isNative()) {
/* 5263 */               MethodRebaseResolver.Resolution resolution = TypeWriter.Default.ForInlining.WithFullProcessing.this.methodRebaseResolver.resolve((MethodDescription.InDefinedShape)implementedMethod.asDefined());
/* 5264 */               if (resolution.isRebased()) {
/* 5265 */                 MethodVisitor rebasedMethodVisitor = visitMethod(resolution.getResolvedMethod().getActualModifiers() | 
/* 5266 */                     resolveDeprecationModifiers(modifiers), resolution
/* 5267 */                     .getResolvedMethod().getInternalName(), resolution
/* 5268 */                     .getResolvedMethod().getDescriptor(), TypeDescription.AbstractBase.RAW_TYPES ? genericSignature : implementedMethod
/*      */ 
/*      */                     
/* 5271 */                     .getGenericSignature(), resolution
/* 5272 */                     .getResolvedMethod().getExceptionTypes().asErasures().toInternalNames());
/* 5273 */                 if (rebasedMethodVisitor != null) {
/* 5274 */                   rebasedMethodVisitor.visitEnd();
/*      */                 }
/*      */               } 
/* 5277 */               return new AttributeObtainingMethodVisitor(methodVisitor, record);
/*      */             } 
/* 5279 */             return new CodePreservingMethodVisitor(methodVisitor, record, TypeWriter.Default.ForInlining.WithFullProcessing.this.methodRebaseResolver.resolve((MethodDescription.InDefinedShape)implementedMethod.asDefined()));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           protected void onVisitInnerClass(String internalName, @MaybeNull String outerName, @MaybeNull String innerName, int modifiers) {
/* 5285 */             if (!internalName.equals(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getInternalName())) {
/* 5286 */               TypeDescription declaredType = this.declaredTypes.remove(internalName);
/* 5287 */               if (declaredType == null) {
/* 5288 */                 this.cv.visitInnerClass(internalName, outerName, innerName, modifiers);
/*      */               } else {
/* 5290 */                 this.cv.visitInnerClass(internalName, (declaredType
/*      */                     
/* 5292 */                     .isMemberType() || (outerName != null && innerName == null && declaredType.isAnonymousType())) ? TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType
/* 5293 */                     .getInternalName() : TypeWriter.Default
/* 5294 */                     .NO_REFERENCE, 
/* 5295 */                     declaredType.isAnonymousType() ? TypeWriter.Default
/* 5296 */                     .NO_REFERENCE : declaredType
/* 5297 */                     .getSimpleName(), declaredType
/* 5298 */                     .getModifiers());
/*      */               } 
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/*      */           protected void onVisitNestMember(String nestMember) {
/* 5305 */             if (TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isNestHost() && this.nestMembers.remove(nestMember)) {
/* 5306 */               this.cv.visitNestMember(nestMember);
/*      */             }
/*      */           }
/*      */ 
/*      */           
/*      */           protected void onVisitEnd() {
/* 5312 */             for (String nestMember : this.nestMembers) {
/* 5313 */               this.cv.visitNestMember(nestMember);
/*      */             }
/* 5315 */             if (this.permittedSubclasses != null) {
/* 5316 */               for (String permittedSubclass : this.permittedSubclasses) {
/* 5317 */                 this.cv.visitPermittedSubclass(permittedSubclass);
/*      */               }
/*      */             }
/* 5320 */             TypeDescription declaringType = TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getDeclaringType();
/* 5321 */             if (declaringType != null) {
/* 5322 */               this.cv.visitInnerClass(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getInternalName(), declaringType
/* 5323 */                   .getInternalName(), TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType
/* 5324 */                   .getSimpleName(), TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType
/* 5325 */                   .getModifiers());
/* 5326 */             } else if (TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isLocalType()) {
/* 5327 */               this.cv.visitInnerClass(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getInternalName(), TypeWriter.Default
/* 5328 */                   .NO_REFERENCE, TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType
/* 5329 */                   .getSimpleName(), TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType
/* 5330 */                   .getModifiers());
/* 5331 */             } else if (TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isAnonymousType()) {
/* 5332 */               this.cv.visitInnerClass(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getInternalName(), TypeWriter.Default
/* 5333 */                   .NO_REFERENCE, TypeWriter.Default
/* 5334 */                   .NO_REFERENCE, TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType
/* 5335 */                   .getModifiers());
/*      */             } 
/* 5337 */             for (TypeDescription typeDescription : this.declaredTypes.values()) {
/* 5338 */               this.cv.visitInnerClass(typeDescription.getInternalName(), 
/* 5339 */                   typeDescription.isMemberType() ? TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType
/* 5340 */                   .getInternalName() : TypeWriter.Default
/* 5341 */                   .NO_REFERENCE, 
/* 5342 */                   typeDescription.isAnonymousType() ? TypeWriter.Default
/* 5343 */                   .NO_REFERENCE : typeDescription
/* 5344 */                   .getSimpleName(), typeDescription
/* 5345 */                   .getModifiers());
/*      */             }
/* 5347 */             for (RecordComponentDescription recordComponent : this.declarableRecordComponents.values()) {
/* 5348 */               TypeWriter.Default.ForInlining.WithFullProcessing.this.recordComponentPool.target(recordComponent).apply(this.cv, TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory);
/*      */             }
/* 5350 */             for (FieldDescription fieldDescription : this.declarableFields.values()) {
/* 5351 */               TypeWriter.Default.ForInlining.WithFullProcessing.this.fieldPool.target(fieldDescription).apply(new DeduplicatingClassVisitor(this.cv), TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory);
/*      */             }
/* 5353 */             for (MethodDescription methodDescription : this.declarableMethods.values()) {
/* 5354 */               this.methodPool.target(methodDescription).apply(new DeduplicatingClassVisitor(this.cv), (Implementation.Context)this.implementationContext, TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory);
/*      */             }
/*      */ 
/*      */             
/* 5358 */             this.initializationHandler.complete(this.cv, this.implementationContext);
/* 5359 */             this.cv.visitEnd();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private int resolveDeprecationModifiers(int modifiers) {
/* 5371 */             return (this.retainDeprecationModifiers && (modifiers & 0x20000) != 0) ? 131072 : 0;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected class DeduplicatingClassVisitor
/*      */             extends ClassVisitor
/*      */           {
/*      */             protected DeduplicatingClassVisitor(ClassVisitor classVisitor) {
/* 5388 */               super(OpenedClassReader.ASM_API, classVisitor);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @MaybeNull
/*      */             public FieldVisitor visitField(int access, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull Object value) {
/* 5398 */               if (TypeWriter.Default.ForInlining.WithFullProcessing.RedefinitionClassVisitor.this.fieldKeys.contains(new TypeWriter.Default.SignatureKey(internalName, descriptor))) {
/* 5399 */                 throw new IllegalStateException("Field already defined: " + internalName + descriptor);
/*      */               }
/* 5401 */               return super.visitField(access, internalName, descriptor, signature, value);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @MaybeNull
/*      */             public MethodVisitor visitMethod(int access, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull String[] exception) {
/* 5411 */               if (TypeWriter.Default.ForInlining.WithFullProcessing.RedefinitionClassVisitor.this.methodsKeys.contains(new TypeWriter.Default.SignatureKey(internalName, descriptor))) {
/* 5412 */                 if ((access & 0x40) != 0) {
/* 5413 */                   return null;
/*      */                 }
/* 5415 */                 throw new IllegalStateException("Method already defined: " + internalName + descriptor);
/*      */               } 
/*      */               
/* 5418 */               return super.visitMethod(access, internalName, descriptor, signature, exception);
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected class AttributeObtainingFieldVisitor
/*      */             extends FieldVisitor
/*      */           {
/*      */             private final TypeWriter.FieldPool.Record record;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected AttributeObtainingFieldVisitor(FieldVisitor fieldVisitor, TypeWriter.FieldPool.Record record) {
/* 5440 */               super(OpenedClassReader.ASM_API, fieldVisitor);
/* 5441 */               this.record = record;
/*      */             }
/*      */ 
/*      */             
/*      */             @MaybeNull
/*      */             public AnnotationVisitor visitTypeAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) {
/* 5447 */               return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super
/* 5448 */                 .visitTypeAnnotation(typeReference, typePath, descriptor, visible) : TypeWriter.Default.ForInlining
/* 5449 */                 .IGNORE_ANNOTATION;
/*      */             }
/*      */ 
/*      */             
/*      */             @MaybeNull
/*      */             public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/* 5455 */               return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super
/* 5456 */                 .visitAnnotation(descriptor, visible) : TypeWriter.Default.ForInlining
/* 5457 */                 .IGNORE_ANNOTATION;
/*      */             }
/*      */ 
/*      */             
/*      */             public void visitEnd() {
/* 5462 */               this.record.apply(this.fv, TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory);
/* 5463 */               super.visitEnd();
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected class AttributeObtainingRecordComponentVisitor
/*      */             extends RecordComponentVisitor
/*      */           {
/*      */             private final TypeWriter.RecordComponentPool.Record record;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected AttributeObtainingRecordComponentVisitor(RecordComponentVisitor recordComponentVisitor, TypeWriter.RecordComponentPool.Record record) {
/* 5485 */               super(OpenedClassReader.ASM_API, recordComponentVisitor);
/* 5486 */               this.record = record;
/*      */             }
/*      */ 
/*      */             
/*      */             public AnnotationVisitor visitTypeAnnotation(int typeReference, TypePath typePath, String descriptor, boolean visible) {
/* 5491 */               return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super
/* 5492 */                 .visitTypeAnnotation(typeReference, typePath, descriptor, visible) : TypeWriter.Default.ForInlining
/* 5493 */                 .IGNORE_ANNOTATION;
/*      */             }
/*      */ 
/*      */             
/*      */             public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/* 5498 */               return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super
/* 5499 */                 .visitAnnotation(descriptor, visible) : TypeWriter.Default.ForInlining
/* 5500 */                 .IGNORE_ANNOTATION;
/*      */             }
/*      */ 
/*      */             
/*      */             public void visitEnd() {
/* 5505 */               this.record.apply(getDelegate(), TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory);
/* 5506 */               super.visitEnd();
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected class CodePreservingMethodVisitor
/*      */             extends MethodVisitor
/*      */           {
/*      */             private final MethodVisitor actualMethodVisitor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final TypeWriter.MethodPool.Record record;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final MethodRebaseResolver.Resolution resolution;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected CodePreservingMethodVisitor(MethodVisitor actualMethodVisitor, TypeWriter.MethodPool.Record record, MethodRebaseResolver.Resolution resolution) {
/* 5541 */               super(OpenedClassReader.ASM_API, actualMethodVisitor);
/* 5542 */               this.actualMethodVisitor = actualMethodVisitor;
/* 5543 */               this.record = record;
/* 5544 */               this.resolution = resolution;
/* 5545 */               record.applyHead(actualMethodVisitor);
/*      */             }
/*      */ 
/*      */             
/*      */             @MaybeNull
/*      */             public AnnotationVisitor visitAnnotationDefault() {
/* 5551 */               return TypeWriter.Default.ForInlining.IGNORE_ANNOTATION;
/*      */             }
/*      */ 
/*      */             
/*      */             @MaybeNull
/*      */             public AnnotationVisitor visitTypeAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) {
/* 5557 */               return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super
/* 5558 */                 .visitTypeAnnotation(typeReference, typePath, descriptor, visible) : TypeWriter.Default.ForInlining
/* 5559 */                 .IGNORE_ANNOTATION;
/*      */             }
/*      */ 
/*      */             
/*      */             @MaybeNull
/*      */             public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/* 5565 */               return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super
/* 5566 */                 .visitAnnotation(descriptor, visible) : TypeWriter.Default.ForInlining
/* 5567 */                 .IGNORE_ANNOTATION;
/*      */             }
/*      */ 
/*      */             
/*      */             public void visitAnnotableParameterCount(int count, boolean visible) {
/* 5572 */               if (TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled()) {
/* 5573 */                 super.visitAnnotableParameterCount(count, visible);
/*      */               }
/*      */             }
/*      */ 
/*      */             
/*      */             @MaybeNull
/*      */             public AnnotationVisitor visitParameterAnnotation(int index, String descriptor, boolean visible) {
/* 5580 */               return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super
/* 5581 */                 .visitParameterAnnotation(index, descriptor, visible) : TypeWriter.Default.ForInlining
/* 5582 */                 .IGNORE_ANNOTATION;
/*      */             }
/*      */ 
/*      */             
/*      */             public void visitCode() {
/* 5587 */               this.record.applyBody(this.actualMethodVisitor, (Implementation.Context)TypeWriter.Default.ForInlining.WithFullProcessing.RedefinitionClassVisitor.this.implementationContext, TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory);
/* 5588 */               this.actualMethodVisitor.visitEnd();
/* 5589 */               if (this.resolution.isRebased()) {
/* 5590 */                 this.mv = TypeWriter.Default.ForInlining.WithFullProcessing.RedefinitionClassVisitor.this.cv.visitMethod(this.resolution.getResolvedMethod().getActualModifiers(), this.resolution
/* 5591 */                     .getResolvedMethod().getInternalName(), this.resolution
/* 5592 */                     .getResolvedMethod().getDescriptor(), this.resolution
/* 5593 */                     .getResolvedMethod().getGenericSignature(), this.resolution
/* 5594 */                     .getResolvedMethod().getExceptionTypes().asErasures().toInternalNames());
/* 5595 */                 super.visitCode();
/* 5596 */                 if (!this.resolution.getAppendedParameters().isEmpty() && TypeWriter.Default.ForInlining.WithFullProcessing.RedefinitionClassVisitor.this.implementationContext.getFrameGeneration().isActive()) {
/* 5597 */                   if (TypeWriter.Default.ForInlining.WithFullProcessing.RedefinitionClassVisitor.this.implementationContext.getFrameGeneration() == Implementation.Context.FrameGeneration.GENERATE && this.resolution.getAppendedParameters().size() < 4) {
/* 5598 */                     visitFrame(2, this.resolution.getAppendedParameters().size(), TypeWriter.Default.ForInlining.WithFullProcessing.EMPTY, TypeWriter.Default.ForInlining.WithFullProcessing.EMPTY.length, TypeWriter.Default.ForInlining.WithFullProcessing.EMPTY);
/*      */                   } else {
/*      */                     
/* 5601 */                     Object[] frame = new Object[this.resolution.getResolvedMethod().getParameters().size() - this.resolution.getAppendedParameters().size() + 1];
/*      */                     
/* 5603 */                     frame[0] = Opcodes.UNINITIALIZED_THIS;
/* 5604 */                     for (int index = 1; index < frame.length; index++) {
/*      */ 
/*      */ 
/*      */                       
/* 5608 */                       TypeDescription.Generic generic = ((ParameterDescription.InDefinedShape)this.resolution.getResolvedMethod().getParameters().get(index - 1)).getType();
/* 5609 */                       if (generic.represents(boolean.class) || generic
/* 5610 */                         .represents(byte.class) || generic
/* 5611 */                         .represents(short.class) || generic
/* 5612 */                         .represents(char.class) || generic
/* 5613 */                         .represents(int.class)) {
/* 5614 */                         frame[index] = Opcodes.INTEGER;
/* 5615 */                       } else if (generic.represents(long.class)) {
/* 5616 */                         frame[index] = Opcodes.LONG;
/* 5617 */                       } else if (generic.represents(float.class)) {
/* 5618 */                         frame[index] = Opcodes.FLOAT;
/* 5619 */                       } else if (generic.represents(double.class)) {
/* 5620 */                         frame[index] = Opcodes.DOUBLE;
/*      */                       } else {
/* 5622 */                         frame[index] = generic.asErasure().getInternalName();
/*      */                       } 
/*      */                     } 
/* 5625 */                     visitFrame(((TypeWriter.Default.ForInlining.WithFullProcessing.RedefinitionClassVisitor.this.readerFlags & 0x8) == 0) ? 0 : -1, frame.length, frame, TypeWriter.Default.ForInlining.WithFullProcessing
/*      */                         
/* 5627 */                         .EMPTY.length, TypeWriter.Default.ForInlining.WithFullProcessing.EMPTY);
/*      */                   } 
/* 5629 */                   visitInsn(0);
/*      */                 } 
/*      */               } else {
/* 5632 */                 this.mv = TypeWriter.Default.ForInlining.IGNORE_METHOD;
/* 5633 */                 super.visitCode();
/*      */               } 
/*      */             }
/*      */ 
/*      */             
/*      */             public void visitMaxs(int stackSize, int localVariableLength) {
/* 5639 */               super.visitMaxs(stackSize, Math.max(localVariableLength, this.resolution.getResolvedMethod().getStackSize()));
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected class AttributeObtainingMethodVisitor
/*      */             extends MethodVisitor
/*      */           {
/*      */             private final MethodVisitor actualMethodVisitor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final TypeWriter.MethodPool.Record record;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected AttributeObtainingMethodVisitor(MethodVisitor actualMethodVisitor, TypeWriter.MethodPool.Record record) {
/* 5666 */               super(OpenedClassReader.ASM_API, actualMethodVisitor);
/* 5667 */               this.actualMethodVisitor = actualMethodVisitor;
/* 5668 */               this.record = record;
/* 5669 */               record.applyHead(actualMethodVisitor);
/*      */             }
/*      */ 
/*      */             
/*      */             @MaybeNull
/*      */             public AnnotationVisitor visitAnnotationDefault() {
/* 5675 */               return TypeWriter.Default.ForInlining.IGNORE_ANNOTATION;
/*      */             }
/*      */ 
/*      */             
/*      */             @MaybeNull
/*      */             public AnnotationVisitor visitTypeAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) {
/* 5681 */               return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super
/* 5682 */                 .visitTypeAnnotation(typeReference, typePath, descriptor, visible) : TypeWriter.Default.ForInlining
/* 5683 */                 .IGNORE_ANNOTATION;
/*      */             }
/*      */ 
/*      */             
/*      */             @MaybeNull
/*      */             public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/* 5689 */               return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super
/* 5690 */                 .visitAnnotation(descriptor, visible) : TypeWriter.Default.ForInlining
/* 5691 */                 .IGNORE_ANNOTATION;
/*      */             }
/*      */ 
/*      */             
/*      */             public void visitAnnotableParameterCount(int count, boolean visible) {
/* 5696 */               if (TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled()) {
/* 5697 */                 super.visitAnnotableParameterCount(count, visible);
/*      */               }
/*      */             }
/*      */ 
/*      */             
/*      */             @MaybeNull
/*      */             public AnnotationVisitor visitParameterAnnotation(int index, String descriptor, boolean visible) {
/* 5704 */               return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super
/* 5705 */                 .visitParameterAnnotation(index, descriptor, visible) : TypeWriter.Default.ForInlining
/* 5706 */                 .IGNORE_ANNOTATION;
/*      */             }
/*      */ 
/*      */             
/*      */             public void visitCode() {
/* 5711 */               this.mv = TypeWriter.Default.ForInlining.IGNORE_METHOD;
/*      */             }
/*      */ 
/*      */             
/*      */             public void visitEnd() {
/* 5716 */               this.record.applyBody(this.actualMethodVisitor, (Implementation.Context)TypeWriter.Default.ForInlining.WithFullProcessing.RedefinitionClassVisitor.this.implementationContext, TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory);
/* 5717 */               this.actualMethodVisitor.visitEnd();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected static class WithDecorationOnly<V>
/*      */         extends ForInlining<V>
/*      */       {
/*      */         protected WithDecorationOnly(TypeDescription instrumentedType, ClassFileVersion classFileVersion, List<? extends DynamicType> auxiliaryTypes, MethodList<?> methods, TypeAttributeAppender typeAttributeAppender, AsmVisitorWrapper asmVisitorWrapper, AnnotationValueFilter.Factory annotationValueFilterFactory, AnnotationRetention annotationRetention, AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy, Implementation.Context.Factory implementationContextFactory, TypeValidation typeValidation, AsmClassReader.Factory classReaderFactory, AsmClassWriter.Factory classWriterFactory, TypePool typePool, ClassFileLocator classFileLocator) {
/* 5764 */           super(instrumentedType, classFileVersion, TypeWriter.FieldPool.Disabled.INSTANCE, TypeWriter.RecordComponentPool.Disabled.INSTANCE, auxiliaryTypes, (FieldList<FieldDescription.InDefinedShape>)new LazyFieldList(instrumentedType), methods, (MethodList<?>)new MethodList.Empty(), (RecordComponentList<RecordComponentDescription.InDefinedShape>)new RecordComponentList.Empty(), (LoadedTypeInitializer)LoadedTypeInitializer.NoOp.INSTANCE, TypeInitializer.None.INSTANCE, typeAttributeAppender, asmVisitorWrapper, annotationValueFilterFactory, annotationRetention, auxiliaryTypeNamingStrategy, implementationContextFactory, typeValidation, classReaderFactory, classWriterFactory, typePool, instrumentedType, classFileLocator);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected ClassVisitor writeTo(ClassVisitor classVisitor, TypeInitializer typeInitializer, TypeWriter.Default.ForInlining.ContextRegistry contextRegistry, int writerFlags, int readerFlags) {
/* 5797 */           if (typeInitializer.isDefined()) {
/* 5798 */             throw new UnsupportedOperationException("Cannot apply a type initializer for a decoration");
/*      */           }
/* 5800 */           return (ClassVisitor)new DecorationClassVisitor(classVisitor, contextRegistry, writerFlags, readerFlags);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected static class LazyFieldList
/*      */           extends FieldList.AbstractBase<FieldDescription.InDefinedShape>
/*      */         {
/*      */           private final TypeDescription instrumentedType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected LazyFieldList(TypeDescription instrumentedType) {
/* 5819 */             this.instrumentedType = instrumentedType;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public FieldDescription.InDefinedShape get(int index) {
/* 5826 */             return (FieldDescription.InDefinedShape)this.instrumentedType.getDeclaredFields().get(index);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public int size() {
/* 5833 */             return this.instrumentedType.getDeclaredFields().size();
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @SuppressFBWarnings(value = {"UWF_FIELD_NOT_INITIALIZED_IN_CONSTRUCTOR"}, justification = "Field access order is implied by ASM.")
/*      */         protected class DecorationClassVisitor
/*      */           extends MetadataAwareClassVisitor
/*      */           implements TypeInitializer.Drain
/*      */         {
/*      */           private final TypeWriter.Default.ForInlining.ContextRegistry contextRegistry;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final int writerFlags;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final int readerFlags;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @UnknownNull
/*      */           private Implementation.Context.ExtractableView implementationContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected DecorationClassVisitor(ClassVisitor classVisitor, TypeWriter.Default.ForInlining.ContextRegistry contextRegistry, int writerFlags, int readerFlags) {
/* 5873 */             super(OpenedClassReader.ASM_API, classVisitor);
/* 5874 */             this.contextRegistry = contextRegistry;
/* 5875 */             this.writerFlags = writerFlags;
/* 5876 */             this.readerFlags = readerFlags;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void visit(int classFileVersionNumber, int modifiers, String internalName, String genericSignature, String superClassInternalName, String[] interfaceTypeInternalName) {
/* 5886 */             ClassFileVersion classFileVersion = ClassFileVersion.ofMinorMajor(classFileVersionNumber);
/* 5887 */             this.implementationContext = TypeWriter.Default.ForInlining.WithDecorationOnly.this.implementationContextFactory.make(TypeWriter.Default.ForInlining.WithDecorationOnly.this.instrumentedType, TypeWriter.Default.ForInlining.WithDecorationOnly.this.auxiliaryTypeNamingStrategy, TypeWriter.Default.ForInlining.WithDecorationOnly.this.typeInitializer, classFileVersion, TypeWriter.Default.ForInlining.WithDecorationOnly.this.classFileVersion, ((this.writerFlags & 0x2) == 0 && classFileVersion
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 5892 */                 .isAtLeast(ClassFileVersion.JAVA_V6)) ? (((this.readerFlags & 0x8) == 0) ? Implementation.Context.FrameGeneration.GENERATE : Implementation.Context.FrameGeneration.EXPAND) : Implementation.Context.FrameGeneration.DISABLED);
/*      */ 
/*      */             
/* 5895 */             this.contextRegistry.setImplementationContext(this.implementationContext);
/* 5896 */             this.cv = TypeWriter.Default.ForInlining.WithDecorationOnly.this.asmVisitorWrapper.wrap(TypeWriter.Default.ForInlining.WithDecorationOnly.this.instrumentedType, this.cv, (Implementation.Context)this.implementationContext, TypeWriter.Default.ForInlining.WithDecorationOnly.this.typePool, TypeWriter.Default.ForInlining.WithDecorationOnly.this.fields, TypeWriter.Default.ForInlining.WithDecorationOnly.this.methods, this.writerFlags, this.readerFlags);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 5904 */             this.cv.visit(classFileVersionNumber, modifiers, internalName, genericSignature, superClassInternalName, interfaceTypeInternalName);
/*      */           }
/*      */ 
/*      */           
/*      */           @MaybeNull
/*      */           protected AnnotationVisitor onVisitTypeAnnotation(int typeReference, TypePath typePath, String descriptor, boolean visible) {
/* 5910 */             return TypeWriter.Default.ForInlining.WithDecorationOnly.this.annotationRetention.isEnabled() ? this.cv
/* 5911 */               .visitTypeAnnotation(typeReference, typePath, descriptor, visible) : TypeWriter.Default.ForInlining
/* 5912 */               .IGNORE_ANNOTATION;
/*      */           }
/*      */ 
/*      */           
/*      */           @MaybeNull
/*      */           protected AnnotationVisitor onVisitAnnotation(String descriptor, boolean visible) {
/* 5918 */             return TypeWriter.Default.ForInlining.WithDecorationOnly.this.annotationRetention.isEnabled() ? this.cv
/* 5919 */               .visitAnnotation(descriptor, visible) : TypeWriter.Default.ForInlining
/* 5920 */               .IGNORE_ANNOTATION;
/*      */           }
/*      */ 
/*      */           
/*      */           protected void onAfterAttributes() {
/* 5925 */             TypeWriter.Default.ForInlining.WithDecorationOnly.this.typeAttributeAppender.apply(this.cv, TypeWriter.Default.ForInlining.WithDecorationOnly.this.instrumentedType, TypeWriter.Default.ForInlining.WithDecorationOnly.this.annotationValueFilterFactory.on(TypeWriter.Default.ForInlining.WithDecorationOnly.this.instrumentedType));
/*      */           }
/*      */           
/*      */           public void apply(ClassVisitor classVisitor, TypeInitializer typeInitializer, Implementation.Context implementationContext) {}
/*      */           
/* 5930 */           protected void onVisitEnd() { this.implementationContext.drain(this, this.cv, TypeWriter.Default.ForInlining.WithDecorationOnly.this.annotationValueFilterFactory);
/* 5931 */             this.cv.visitEnd(); } } } } @Enhance protected static class WithFullProcessing<V> extends ForInlining<V> { private static final Object[] EMPTY = new Object[0]; private final MethodRegistry.Prepared methodRegistry; private final Implementation.Target.Factory implementationTargetFactory; private final MethodRebaseResolver methodRebaseResolver; protected WithFullProcessing(TypeDescription instrumentedType, ClassFileVersion classFileVersion, TypeWriter.FieldPool fieldPool, TypeWriter.RecordComponentPool recordComponentPool, List<? extends DynamicType> auxiliaryTypes, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, MethodList<?> instrumentedMethods, RecordComponentList<RecordComponentDescription.InDefinedShape> recordComponents, LoadedTypeInitializer loadedTypeInitializer, TypeInitializer typeInitializer, TypeAttributeAppender typeAttributeAppender, AsmVisitorWrapper asmVisitorWrapper, AnnotationValueFilter.Factory annotationValueFilterFactory, AnnotationRetention annotationRetention, AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy, Implementation.Context.Factory implementationContextFactory, TypeValidation typeValidation, AsmClassReader.Factory classReaderFactory, AsmClassWriter.Factory classWriterFactory, TypePool typePool, TypeDescription originalType, ClassFileLocator classFileLocator, MethodRegistry.Prepared methodRegistry, Implementation.Target.Factory implementationTargetFactory, MethodRebaseResolver methodRebaseResolver) { super(instrumentedType, classFileVersion, fieldPool, recordComponentPool, auxiliaryTypes, fields, methods, instrumentedMethods, recordComponents, loadedTypeInitializer, typeInitializer, typeAttributeAppender, asmVisitorWrapper, annotationValueFilterFactory, annotationRetention, auxiliaryTypeNamingStrategy, implementationContextFactory, typeValidation, classReaderFactory, classWriterFactory, typePool, originalType, classFileLocator); this.methodRegistry = methodRegistry; this.implementationTargetFactory = implementationTargetFactory; this.methodRebaseResolver = methodRebaseResolver; } protected ClassVisitor writeTo(ClassVisitor classVisitor, TypeInitializer typeInitializer, TypeWriter.Default.ForInlining.ContextRegistry contextRegistry, int writerFlags, int readerFlags) { RedefinitionClassVisitor redefinitionClassVisitor = new RedefinitionClassVisitor(classVisitor, typeInitializer, contextRegistry, writerFlags, readerFlags); return this.originalType.getName().equals(this.instrumentedType.getName()) ? (ClassVisitor)redefinitionClassVisitor : (ClassVisitor)new OpenedClassRemapper((ClassVisitor)redefinitionClassVisitor, (Remapper)new SimpleRemapper(OpenedClassReader.ASM_API, this.originalType.getInternalName(), this.instrumentedType.getInternalName())); } public boolean equals(@MaybeNull Object param2Object) { return !super.equals(param2Object) ? false : ((this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.methodRegistry.equals(((WithFullProcessing)param2Object).methodRegistry) ? false : (!this.implementationTargetFactory.equals(((WithFullProcessing)param2Object).implementationTargetFactory) ? false : (!!this.methodRebaseResolver.equals(((WithFullProcessing)param2Object).methodRebaseResolver))))))); } public int hashCode() { return ((super.hashCode() * 31 + this.methodRegistry.hashCode()) * 31 + this.implementationTargetFactory.hashCode()) * 31 + this.methodRebaseResolver.hashCode(); } protected static class OpenedClassRemapper extends ClassRemapper { protected OpenedClassRemapper(ClassVisitor classVisitor, Remapper remapper) { super(OpenedClassReader.ASM_API, classVisitor, remapper); } } protected static interface InitializationHandler { void complete(ClassVisitor param4ClassVisitor, Implementation.Context.ExtractableView param4ExtractableView); public static class Creating extends TypeInitializer.Drain.Default implements InitializationHandler { protected Creating(TypeDescription instrumentedType, TypeWriter.MethodPool methodPool, AnnotationValueFilter.Factory annotationValueFilterFactory) { super(instrumentedType, methodPool, annotationValueFilterFactory); } public void complete(ClassVisitor classVisitor, Implementation.Context.ExtractableView implementationContext) { implementationContext.drain(this, classVisitor, this.annotationValueFilterFactory); } } public static abstract class Appending extends MethodVisitor implements InitializationHandler, TypeInitializer.Drain { protected final TypeDescription instrumentedType; protected final TypeWriter.MethodPool.Record record; protected final AnnotationValueFilter.Factory annotationValueFilterFactory; protected final FrameWriter frameWriter; protected int stackSize; protected int localVariableLength; protected Appending(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) { super(OpenedClassReader.ASM_API, methodVisitor); this.instrumentedType = instrumentedType; this.record = record; this.annotationValueFilterFactory = annotationValueFilterFactory; if (!requireFrames) { this.frameWriter = FrameWriter.NoOp.INSTANCE; } else if (expandFrames) { this.frameWriter = FrameWriter.Expanding.INSTANCE; } else { this.frameWriter = new FrameWriter.Active(); }  } protected static TypeWriter.Default.ForInlining.WithFullProcessing.InitializationHandler of(boolean enabled, MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool methodPool, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) { return enabled ? withDrain(methodVisitor, instrumentedType, methodPool, annotationValueFilterFactory, requireFrames, expandFrames) : withoutDrain(methodVisitor, instrumentedType, methodPool, annotationValueFilterFactory, requireFrames, expandFrames); } private static WithDrain withDrain(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool methodPool, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) { TypeWriter.MethodPool.Record record = methodPool.target((MethodDescription)new MethodDescription.Latent.TypeInitializer(instrumentedType)); return record.getSort().isImplemented() ? new WithDrain.WithActiveRecord(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames) : new WithDrain.WithoutActiveRecord(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames); } private static WithoutDrain withoutDrain(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool methodPool, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) { TypeWriter.MethodPool.Record record = methodPool.target((MethodDescription)new MethodDescription.Latent.TypeInitializer(instrumentedType)); return record.getSort().isImplemented() ? new WithoutDrain.WithActiveRecord(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames) : new WithoutDrain.WithoutActiveRecord(methodVisitor, instrumentedType, record, annotationValueFilterFactory); } public void visitCode() { this.record.applyAttributes(this.mv, this.annotationValueFilterFactory); super.visitCode(); onStart(); } protected abstract void onStart(); public void visitFrame(int type, int localVariableLength, @MaybeNull Object[] localVariable, int stackSize, @MaybeNull Object[] stack) { super.visitFrame(type, localVariableLength, localVariable, stackSize, stack); this.frameWriter.onFrame(type, localVariableLength); } public void visitMaxs(int stackSize, int localVariableLength) { this.stackSize = stackSize; this.localVariableLength = localVariableLength; } public abstract void visitEnd(); public void apply(ClassVisitor classVisitor, TypeInitializer typeInitializer, Implementation.Context implementationContext) { ByteCodeAppender.Size size = typeInitializer.apply(this.mv, implementationContext, (MethodDescription)new MethodDescription.Latent.TypeInitializer(this.instrumentedType)); this.stackSize = Math.max(this.stackSize, size.getOperandStackSize()); this.localVariableLength = Math.max(this.localVariableLength, size.getLocalVariableSize()); onComplete(implementationContext); } protected abstract void onComplete(Implementation.Context param5Context); public void complete(ClassVisitor classVisitor, Implementation.Context.ExtractableView implementationContext) { implementationContext.drain(this, classVisitor, this.annotationValueFilterFactory); this.mv.visitMaxs(this.stackSize, this.localVariableLength); this.mv.visitEnd(); } protected static interface FrameWriter { public static final Object[] EMPTY = new Object[0]; void onFrame(int param6Int1, int param6Int2); void emitFrame(MethodVisitor param6MethodVisitor); public enum NoOp implements FrameWriter { INSTANCE; public void onFrame(int type, int localVariableLength) {} public void emitFrame(MethodVisitor methodVisitor) {} } public enum Expanding implements FrameWriter { INSTANCE; public void onFrame(int type, int localVariableLength) {} public void emitFrame(MethodVisitor methodVisitor) { methodVisitor.visitFrame(-1, EMPTY.length, EMPTY, EMPTY.length, EMPTY); methodVisitor.visitInsn(0); } } public static class Active implements FrameWriter { private int currentLocalVariableLength; public void onFrame(int type, int localVariableLength) { switch (type) { case 3: case 4: return;case 1: this.currentLocalVariableLength += localVariableLength;case 2: this.currentLocalVariableLength -= localVariableLength;case -1: case 0: this.currentLocalVariableLength = localVariableLength; }  throw new IllegalStateException("Unexpected frame type: " + type); } public void emitFrame(MethodVisitor methodVisitor) { if (this.currentLocalVariableLength == 0) { methodVisitor.visitFrame(3, EMPTY.length, EMPTY, EMPTY.length, EMPTY); } else if (this.currentLocalVariableLength > 3) { methodVisitor.visitFrame(0, EMPTY.length, EMPTY, EMPTY.length, EMPTY); } else { methodVisitor.visitFrame(2, this.currentLocalVariableLength, EMPTY, EMPTY.length, EMPTY); }  methodVisitor.visitInsn(0); this.currentLocalVariableLength = 0; } } } public enum NoOp implements FrameWriter { INSTANCE; public void onFrame(int type, int localVariableLength) {} public void emitFrame(MethodVisitor methodVisitor) {} } public enum Expanding implements FrameWriter { INSTANCE; public void onFrame(int type, int localVariableLength) {} public void emitFrame(MethodVisitor methodVisitor) { methodVisitor.visitFrame(-1, EMPTY.length, EMPTY, EMPTY.length, EMPTY); methodVisitor.visitInsn(0); } } public static class Active implements FrameWriter { private int currentLocalVariableLength; public void onFrame(int type, int localVariableLength) { switch (type) { case 3: case 4: return;case 1: this.currentLocalVariableLength += localVariableLength;case 2: this.currentLocalVariableLength -= localVariableLength;case -1: case 0: this.currentLocalVariableLength = localVariableLength; }  throw new IllegalStateException("Unexpected frame type: " + type); } public void emitFrame(MethodVisitor methodVisitor) { if (this.currentLocalVariableLength == 0) { methodVisitor.visitFrame(3, EMPTY.length, EMPTY, EMPTY.length, EMPTY); } else if (this.currentLocalVariableLength > 3) { methodVisitor.visitFrame(0, EMPTY.length, EMPTY, EMPTY.length, EMPTY); } else { methodVisitor.visitFrame(2, this.currentLocalVariableLength, EMPTY, EMPTY.length, EMPTY); }  methodVisitor.visitInsn(0); this.currentLocalVariableLength = 0; } } protected static abstract class WithoutDrain extends Appending { protected WithoutDrain(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) { super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames); } protected void onStart() {} public void visitEnd() {} protected static class WithoutActiveRecord extends WithoutDrain { protected WithoutActiveRecord(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory) { super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, false, false); } protected void onComplete(Implementation.Context implementationContext) {} } protected static class WithActiveRecord extends WithoutDrain { private final Label label; protected WithActiveRecord(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) { super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames); this.label = new Label(); } public void visitInsn(int opcode) { if (opcode == 177) { this.mv.visitJumpInsn(167, this.label); } else { super.visitInsn(opcode); }  } protected void onComplete(Implementation.Context implementationContext) { this.mv.visitLabel(this.label); this.frameWriter.emitFrame(this.mv); ByteCodeAppender.Size size = this.record.applyCode(this.mv, implementationContext); this.stackSize = Math.max(this.stackSize, size.getOperandStackSize()); this.localVariableLength = Math.max(this.localVariableLength, size.getLocalVariableSize()); } } } protected static class WithoutActiveRecord extends WithoutDrain { protected WithoutActiveRecord(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory) { super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, false, false); } protected void onComplete(Implementation.Context implementationContext) {} } protected static class WithActiveRecord extends WithoutDrain { private final Label label; protected WithActiveRecord(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) { super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames); this.label = new Label(); } public void visitInsn(int opcode) { if (opcode == 177) { this.mv.visitJumpInsn(167, this.label); } else { super.visitInsn(opcode); }  } protected void onComplete(Implementation.Context implementationContext) { this.mv.visitLabel(this.label); this.frameWriter.emitFrame(this.mv); ByteCodeAppender.Size size = this.record.applyCode(this.mv, implementationContext); this.stackSize = Math.max(this.stackSize, size.getOperandStackSize()); this.localVariableLength = Math.max(this.localVariableLength, size.getLocalVariableSize()); } } protected static abstract class WithDrain extends Appending { protected final Label appended; protected final Label original; protected WithDrain(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) { super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames); this.appended = new Label(); this.original = new Label(); } protected void onStart() { this.mv.visitJumpInsn(167, this.appended); this.mv.visitLabel(this.original); this.frameWriter.emitFrame(this.mv); } public void visitEnd() { this.mv.visitLabel(this.appended); this.frameWriter.emitFrame(this.mv); } protected void onComplete(Implementation.Context implementationContext) { this.mv.visitJumpInsn(167, this.original); onAfterComplete(implementationContext); } protected abstract void onAfterComplete(Implementation.Context param6Context); protected static class WithoutActiveRecord extends WithDrain { protected WithoutActiveRecord(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) { super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames); } protected void onAfterComplete(Implementation.Context implementationContext) {} } protected static class WithActiveRecord extends WithDrain { private final Label label; protected WithActiveRecord(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) { super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames); this.label = new Label(); } public void visitInsn(int opcode) { if (opcode == 177) { this.mv.visitJumpInsn(167, this.label); } else { super.visitInsn(opcode); }  } protected void onAfterComplete(Implementation.Context implementationContext) { this.mv.visitLabel(this.label); this.frameWriter.emitFrame(this.mv); ByteCodeAppender.Size size = this.record.applyCode(this.mv, implementationContext); this.stackSize = Math.max(this.stackSize, size.getOperandStackSize()); this.localVariableLength = Math.max(this.localVariableLength, size.getLocalVariableSize()); } } } protected static class WithoutActiveRecord extends WithDrain { protected WithoutActiveRecord(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) { super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames); } protected void onAfterComplete(Implementation.Context implementationContext) {} } protected static class WithActiveRecord extends WithDrain { private final Label label; protected WithActiveRecord(MethodVisitor methodVisitor, TypeDescription instrumentedType, TypeWriter.MethodPool.Record record, AnnotationValueFilter.Factory annotationValueFilterFactory, boolean requireFrames, boolean expandFrames) { super(methodVisitor, instrumentedType, record, annotationValueFilterFactory, requireFrames, expandFrames); this.label = new Label(); } public void visitInsn(int opcode) { if (opcode == 177) { this.mv.visitJumpInsn(167, this.label); } else { super.visitInsn(opcode); }  } protected void onAfterComplete(Implementation.Context implementationContext) { this.mv.visitLabel(this.label); this.frameWriter.emitFrame(this.mv); ByteCodeAppender.Size size = this.record.applyCode(this.mv, implementationContext); this.stackSize = Math.max(this.stackSize, size.getOperandStackSize()); this.localVariableLength = Math.max(this.localVariableLength, size.getLocalVariableSize()); } } } } @SuppressFBWarnings(value = {"UWF_FIELD_NOT_INITIALIZED_IN_CONSTRUCTOR"}, justification = "Field access order is implied by ASM.") protected class RedefinitionClassVisitor extends MetadataAwareClassVisitor { private final TypeInitializer typeInitializer; private final TypeWriter.Default.ForInlining.ContextRegistry contextRegistry; private final int writerFlags; private final int readerFlags; private final LinkedHashMap<TypeWriter.Default.SignatureKey, FieldDescription> declarableFields; private final LinkedHashMap<TypeWriter.Default.SignatureKey, MethodDescription> declarableMethods; private final LinkedHashMap<String, RecordComponentDescription> declarableRecordComponents; private final Set<String> nestMembers; private final LinkedHashMap<String, TypeDescription> declaredTypes; @MaybeNull private final Set<String> permittedSubclasses; @UnknownNull private TypeWriter.MethodPool methodPool; @UnknownNull private TypeWriter.Default.ForInlining.WithFullProcessing.InitializationHandler initializationHandler; @UnknownNull private Implementation.Context.ExtractableView implementationContext; private boolean retainDeprecationModifiers; private final Set<TypeWriter.Default.SignatureKey> fieldKeys = new HashSet<TypeWriter.Default.SignatureKey>(); private final Set<TypeWriter.Default.SignatureKey> methodsKeys = new HashSet<TypeWriter.Default.SignatureKey>(); protected RedefinitionClassVisitor(ClassVisitor classVisitor, TypeInitializer typeInitializer, TypeWriter.Default.ForInlining.ContextRegistry contextRegistry, int writerFlags, int readerFlags) { super(OpenedClassReader.ASM_API, classVisitor); this.typeInitializer = typeInitializer; this.contextRegistry = contextRegistry; this.writerFlags = writerFlags; this.readerFlags = readerFlags; this.declarableFields = new LinkedHashMap<TypeWriter.Default.SignatureKey, FieldDescription>((int)Math.ceil(TypeWriter.Default.ForInlining.WithFullProcessing.this.fields.size() / 0.75D)); for (FieldDescription fieldDescription : TypeWriter.Default.ForInlining.WithFullProcessing.this.fields) this.declarableFields.put(new TypeWriter.Default.SignatureKey(fieldDescription.getInternalName(), fieldDescription.getDescriptor()), fieldDescription);  this.declarableMethods = new LinkedHashMap<TypeWriter.Default.SignatureKey, MethodDescription>((int)Math.ceil(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedMethods.size() / 0.75D)); for (MethodDescription methodDescription : TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedMethods) this.declarableMethods.put(new TypeWriter.Default.SignatureKey(methodDescription.getInternalName(), methodDescription.getDescriptor()), methodDescription);  this.declarableRecordComponents = new LinkedHashMap<String, RecordComponentDescription>((int)Math.ceil(TypeWriter.Default.ForInlining.WithFullProcessing.this.recordComponents.size() / 0.75D)); for (RecordComponentDescription recordComponentDescription : TypeWriter.Default.ForInlining.WithFullProcessing.this.recordComponents) this.declarableRecordComponents.put(recordComponentDescription.getActualName(), recordComponentDescription);  if (TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isNestHost()) { this.nestMembers = new LinkedHashSet<String>((int)Math.ceil(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getNestMembers().size() / 0.75D)); for (TypeDescription typeDescription : TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getNestMembers().filter((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.is(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType)))) this.nestMembers.add(typeDescription.getInternalName());  } else { this.nestMembers = Collections.emptySet(); }  this.declaredTypes = new LinkedHashMap<String, TypeDescription>((int)Math.ceil(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getDeclaredTypes().size() / 0.75D)); for (TypeDescription typeDescription : TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getDeclaredTypes()) this.declaredTypes.put(typeDescription.getInternalName(), typeDescription);  if (TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isSealed()) { this.permittedSubclasses = new LinkedHashSet<String>((int)Math.ceil(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getPermittedSubtypes().size() / 0.75D)); for (TypeDescription typeDescription : TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getPermittedSubtypes()) this.permittedSubclasses.add(typeDescription.getInternalName());  } else { this.permittedSubclasses = null; }  } @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Relying on correlated type properties.") public void visit(int classFileVersionNumber, int modifiers, String internalName, String genericSignature, String superClassInternalName, String[] interfaceTypeInternalName) { ClassFileVersion classFileVersion = ClassFileVersion.ofMinorMajor(classFileVersionNumber); this.methodPool = TypeWriter.Default.ForInlining.WithFullProcessing.this.methodRegistry.compile(TypeWriter.Default.ForInlining.WithFullProcessing.this.implementationTargetFactory, classFileVersion); this.initializationHandler = new TypeWriter.Default.ForInlining.WithFullProcessing.InitializationHandler.Creating(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType, this.methodPool, TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory); this.implementationContext = TypeWriter.Default.ForInlining.WithFullProcessing.this.implementationContextFactory.make(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType, TypeWriter.Default.ForInlining.WithFullProcessing.this.auxiliaryTypeNamingStrategy, this.typeInitializer, classFileVersion, TypeWriter.Default.ForInlining.WithFullProcessing.this.classFileVersion, ((this.writerFlags & 0x2) == 0 && classFileVersion.isAtLeast(ClassFileVersion.JAVA_V6)) ? (((this.readerFlags & 0x8) == 0) ? Implementation.Context.FrameGeneration.GENERATE : Implementation.Context.FrameGeneration.EXPAND) : Implementation.Context.FrameGeneration.DISABLED); this.retainDeprecationModifiers = classFileVersion.isLessThan(ClassFileVersion.JAVA_V5); this.contextRegistry.setImplementationContext(this.implementationContext); this.cv = TypeWriter.Default.ForInlining.WithFullProcessing.this.asmVisitorWrapper.wrap(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType, this.cv, (Implementation.Context)this.implementationContext, TypeWriter.Default.ForInlining.WithFullProcessing.this.typePool, TypeWriter.Default.ForInlining.WithFullProcessing.this.fields, TypeWriter.Default.ForInlining.WithFullProcessing.this.methods, this.writerFlags, this.readerFlags); this.cv.visit(classFileVersionNumber, TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getActualModifiers(((modifiers & 0x20) != 0 && !TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isInterface())) | resolveDeprecationModifiers(modifiers) | (((modifiers & 0x10) != 0 && TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isAnonymousType()) ? 16 : 0), TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getInternalName(), TypeDescription.AbstractBase.RAW_TYPES ? genericSignature : TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getGenericSignature(), (TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getSuperClass() == null) ? (TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isInterface() ? TypeDescription.ForLoadedType.of(Object.class).getInternalName() : TypeWriter.Default.NO_REFERENCE) : TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getSuperClass().asErasure().getInternalName(), TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getInterfaces().asErasures().toInternalNames()); } protected void onVisitNestHost(String nestHost) { onNestHost(); } protected void onNestHost() { if (!TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isNestHost()) this.cv.visitNestHost(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getNestHost().getInternalName());  } protected void onVisitPermittedSubclass(String permittedSubclass) { if (this.permittedSubclasses != null && this.permittedSubclasses.remove(permittedSubclass)) this.cv.visitPermittedSubclass(permittedSubclass);  } protected void onVisitOuterClass(String owner, @MaybeNull String name, @MaybeNull String descriptor) { try { onOuterType(); } catch (Throwable ignored) { this.cv.visitOuterClass(owner, name, descriptor); }  } @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH"}, justification = "Relying on correlated type properties.") protected void onOuterType() { MethodDescription.InDefinedShape enclosingMethod = TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getEnclosingMethod(); if (enclosingMethod != null) { this.cv.visitOuterClass(enclosingMethod.getDeclaringType().getInternalName(), enclosingMethod.getInternalName(), enclosingMethod.getDescriptor()); } else if (TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isLocalType() || TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isAnonymousType()) { this.cv.visitOuterClass(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getEnclosingType().getInternalName(), TypeWriter.Default.NO_REFERENCE, TypeWriter.Default.NO_REFERENCE); }  } protected void onAfterAttributes() { TypeWriter.Default.ForInlining.WithFullProcessing.this.typeAttributeAppender.apply(this.cv, TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType, TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory.on(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType)); } @MaybeNull protected AnnotationVisitor onVisitTypeAnnotation(int typeReference, TypePath typePath, String descriptor, boolean visible) { return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? this.cv.visitTypeAnnotation(typeReference, typePath, descriptor, visible) : TypeWriter.Default.ForInlining.IGNORE_ANNOTATION; } @MaybeNull protected AnnotationVisitor onVisitAnnotation(String descriptor, boolean visible) { return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? this.cv.visitAnnotation(descriptor, visible) : TypeWriter.Default.ForInlining.IGNORE_ANNOTATION; } @MaybeNull protected RecordComponentVisitor onVisitRecordComponent(String name, String descriptor, @MaybeNull String genericSignature) { RecordComponentDescription recordComponentDescription = this.declarableRecordComponents.remove(name); if (recordComponentDescription != null) { TypeWriter.RecordComponentPool.Record record = TypeWriter.Default.ForInlining.WithFullProcessing.this.recordComponentPool.target(recordComponentDescription); if (!record.isImplicit()) return redefine(record, genericSignature);  }  return this.cv.visitRecordComponent(name, descriptor, genericSignature); } @MaybeNull protected RecordComponentVisitor redefine(TypeWriter.RecordComponentPool.Record record, @MaybeNull String genericSignature) { RecordComponentDescription recordComponentDescription = record.getRecordComponent(); RecordComponentVisitor recordComponentVisitor = this.cv.visitRecordComponent(recordComponentDescription.getActualName(), recordComponentDescription.getDescriptor(), TypeDescription.AbstractBase.RAW_TYPES ? genericSignature : recordComponentDescription.getGenericSignature()); return (recordComponentVisitor == null) ? TypeWriter.Default.ForInlining.IGNORE_RECORD_COMPONENT : new AttributeObtainingRecordComponentVisitor(recordComponentVisitor, record); } @MaybeNull protected FieldVisitor onVisitField(int modifiers, String internalName, String descriptor, @MaybeNull String genericSignature, @MaybeNull Object value) { TypeWriter.Default.SignatureKey key = new TypeWriter.Default.SignatureKey(internalName, descriptor); this.fieldKeys.add(key); FieldDescription fieldDescription = this.declarableFields.remove(key); if (fieldDescription != null) { TypeWriter.FieldPool.Record record = TypeWriter.Default.ForInlining.WithFullProcessing.this.fieldPool.target(fieldDescription); if (!record.isImplicit()) return redefine(record, value, modifiers, genericSignature);  }  return this.cv.visitField(modifiers, internalName, descriptor, genericSignature, value); } @MaybeNull protected FieldVisitor redefine(TypeWriter.FieldPool.Record record, @MaybeNull Object value, int modifiers, @MaybeNull String genericSignature) { FieldDescription instrumentedField = record.getField(); FieldVisitor fieldVisitor = this.cv.visitField(instrumentedField.getActualModifiers() | resolveDeprecationModifiers(modifiers), instrumentedField.getInternalName(), instrumentedField.getDescriptor(), TypeDescription.AbstractBase.RAW_TYPES ? genericSignature : instrumentedField.getGenericSignature(), record.resolveDefault(value)); return (fieldVisitor == null) ? TypeWriter.Default.ForInlining.IGNORE_FIELD : new AttributeObtainingFieldVisitor(fieldVisitor, record); } @MaybeNull protected MethodVisitor onVisitMethod(int modifiers, String internalName, String descriptor, @MaybeNull String genericSignature, @MaybeNull String[] exceptionName) { if (internalName.equals("<clinit>")) { MethodVisitor methodVisitor = this.cv.visitMethod(modifiers, internalName, descriptor, genericSignature, exceptionName); return (methodVisitor == null) ? TypeWriter.Default.ForInlining.IGNORE_METHOD : (MethodVisitor)(this.initializationHandler = TypeWriter.Default.ForInlining.WithFullProcessing.InitializationHandler.Appending.of(this.implementationContext.isEnabled(), methodVisitor, TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType, this.methodPool, TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory, ((this.writerFlags & 0x2) == 0 && this.implementationContext.getClassFileVersion().isAtLeast(ClassFileVersion.JAVA_V6)), ((this.readerFlags & 0x8) != 0))); }  TypeWriter.Default.SignatureKey key = new TypeWriter.Default.SignatureKey(internalName, descriptor); this.methodsKeys.add(key); MethodDescription methodDescription = this.declarableMethods.remove(key); return (methodDescription == null) ? this.cv.visitMethod(modifiers, internalName, descriptor, genericSignature, exceptionName) : redefine(methodDescription, ((modifiers & 0x400) != 0), modifiers, genericSignature); } @MaybeNull protected MethodVisitor redefine(MethodDescription methodDescription, boolean abstractOrigin, int modifiers, @MaybeNull String genericSignature) { TypeWriter.MethodPool.Record record = this.methodPool.target(methodDescription); if (!record.getSort().isDefined()) return this.cv.visitMethod(methodDescription.getActualModifiers() | resolveDeprecationModifiers(modifiers), methodDescription.getInternalName(), methodDescription.getDescriptor(), TypeDescription.AbstractBase.RAW_TYPES ? genericSignature : methodDescription.getGenericSignature(), methodDescription.getExceptionTypes().asErasures().toInternalNames());  MethodDescription implementedMethod = record.getMethod(); MethodVisitor methodVisitor = this.cv.visitMethod(ModifierContributor.Resolver.of(Collections.singleton(record.getVisibility())).resolve(implementedMethod.getActualModifiers(record.getSort().isImplemented())) | resolveDeprecationModifiers(modifiers), implementedMethod.getInternalName(), implementedMethod.getDescriptor(), TypeDescription.AbstractBase.RAW_TYPES ? genericSignature : implementedMethod.getGenericSignature(), implementedMethod.getExceptionTypes().asErasures().toInternalNames()); if (methodVisitor == null) return TypeWriter.Default.ForInlining.IGNORE_METHOD;  if (abstractOrigin) return new AttributeObtainingMethodVisitor(methodVisitor, record);  if (methodDescription.isNative()) { MethodRebaseResolver.Resolution resolution = TypeWriter.Default.ForInlining.WithFullProcessing.this.methodRebaseResolver.resolve((MethodDescription.InDefinedShape)implementedMethod.asDefined()); if (resolution.isRebased()) { MethodVisitor rebasedMethodVisitor = visitMethod(resolution.getResolvedMethod().getActualModifiers() | resolveDeprecationModifiers(modifiers), resolution.getResolvedMethod().getInternalName(), resolution.getResolvedMethod().getDescriptor(), TypeDescription.AbstractBase.RAW_TYPES ? genericSignature : implementedMethod.getGenericSignature(), resolution.getResolvedMethod().getExceptionTypes().asErasures().toInternalNames()); if (rebasedMethodVisitor != null) rebasedMethodVisitor.visitEnd();  }  return new AttributeObtainingMethodVisitor(methodVisitor, record); }  return new CodePreservingMethodVisitor(methodVisitor, record, TypeWriter.Default.ForInlining.WithFullProcessing.this.methodRebaseResolver.resolve((MethodDescription.InDefinedShape)implementedMethod.asDefined())); } protected void onVisitInnerClass(String internalName, @MaybeNull String outerName, @MaybeNull String innerName, int modifiers) { if (!internalName.equals(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getInternalName())) { TypeDescription declaredType = this.declaredTypes.remove(internalName); if (declaredType == null) { this.cv.visitInnerClass(internalName, outerName, innerName, modifiers); } else { this.cv.visitInnerClass(internalName, (declaredType.isMemberType() || (outerName != null && innerName == null && declaredType.isAnonymousType())) ? TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getInternalName() : TypeWriter.Default.NO_REFERENCE, declaredType.isAnonymousType() ? TypeWriter.Default.NO_REFERENCE : declaredType.getSimpleName(), declaredType.getModifiers()); }  }  } protected void onVisitNestMember(String nestMember) { if (TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isNestHost() && this.nestMembers.remove(nestMember)) this.cv.visitNestMember(nestMember);  } protected void onVisitEnd() { for (String nestMember : this.nestMembers) this.cv.visitNestMember(nestMember);  if (this.permittedSubclasses != null) for (String permittedSubclass : this.permittedSubclasses) this.cv.visitPermittedSubclass(permittedSubclass);   TypeDescription declaringType = TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getDeclaringType(); if (declaringType != null) { this.cv.visitInnerClass(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getInternalName(), declaringType.getInternalName(), TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getSimpleName(), TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getModifiers()); } else if (TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isLocalType()) { this.cv.visitInnerClass(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getInternalName(), TypeWriter.Default.NO_REFERENCE, TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getSimpleName(), TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getModifiers()); } else if (TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.isAnonymousType()) { this.cv.visitInnerClass(TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getInternalName(), TypeWriter.Default.NO_REFERENCE, TypeWriter.Default.NO_REFERENCE, TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getModifiers()); }  for (TypeDescription typeDescription : this.declaredTypes.values()) this.cv.visitInnerClass(typeDescription.getInternalName(), typeDescription.isMemberType() ? TypeWriter.Default.ForInlining.WithFullProcessing.this.instrumentedType.getInternalName() : TypeWriter.Default.NO_REFERENCE, typeDescription.isAnonymousType() ? TypeWriter.Default.NO_REFERENCE : typeDescription.getSimpleName(), typeDescription.getModifiers());  for (RecordComponentDescription recordComponent : this.declarableRecordComponents.values()) TypeWriter.Default.ForInlining.WithFullProcessing.this.recordComponentPool.target(recordComponent).apply(this.cv, TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory);  for (FieldDescription fieldDescription : this.declarableFields.values()) TypeWriter.Default.ForInlining.WithFullProcessing.this.fieldPool.target(fieldDescription).apply(new DeduplicatingClassVisitor(this.cv), TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory);  for (MethodDescription methodDescription : this.declarableMethods.values()) this.methodPool.target(methodDescription).apply(new DeduplicatingClassVisitor(this.cv), (Implementation.Context)this.implementationContext, TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory);  this.initializationHandler.complete(this.cv, this.implementationContext); this.cv.visitEnd(); } private int resolveDeprecationModifiers(int modifiers) { return (this.retainDeprecationModifiers && (modifiers & 0x20000) != 0) ? 131072 : 0; } protected class DeduplicatingClassVisitor extends ClassVisitor { protected DeduplicatingClassVisitor(ClassVisitor classVisitor) { super(OpenedClassReader.ASM_API, classVisitor); } @MaybeNull public FieldVisitor visitField(int access, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull Object value) { if (TypeWriter.Default.ForInlining.WithFullProcessing.RedefinitionClassVisitor.this.fieldKeys.contains(new TypeWriter.Default.SignatureKey(internalName, descriptor))) throw new IllegalStateException("Field already defined: " + internalName + descriptor);  return super.visitField(access, internalName, descriptor, signature, value); } @MaybeNull public MethodVisitor visitMethod(int access, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull String[] exception) { if (TypeWriter.Default.ForInlining.WithFullProcessing.RedefinitionClassVisitor.this.methodsKeys.contains(new TypeWriter.Default.SignatureKey(internalName, descriptor))) { if ((access & 0x40) != 0) return null;  throw new IllegalStateException("Method already defined: " + internalName + descriptor); }  return super.visitMethod(access, internalName, descriptor, signature, exception); } } protected class AttributeObtainingFieldVisitor extends FieldVisitor { private final TypeWriter.FieldPool.Record record; protected AttributeObtainingFieldVisitor(FieldVisitor fieldVisitor, TypeWriter.FieldPool.Record record) { super(OpenedClassReader.ASM_API, fieldVisitor); this.record = record; } @MaybeNull public AnnotationVisitor visitTypeAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) { return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super.visitTypeAnnotation(typeReference, typePath, descriptor, visible) : TypeWriter.Default.ForInlining.IGNORE_ANNOTATION; } @MaybeNull public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) { return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super.visitAnnotation(descriptor, visible) : TypeWriter.Default.ForInlining.IGNORE_ANNOTATION; } public void visitEnd() { this.record.apply(this.fv, TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory); super.visitEnd(); } } protected class AttributeObtainingRecordComponentVisitor extends RecordComponentVisitor { private final TypeWriter.RecordComponentPool.Record record; protected AttributeObtainingRecordComponentVisitor(RecordComponentVisitor recordComponentVisitor, TypeWriter.RecordComponentPool.Record record) { super(OpenedClassReader.ASM_API, recordComponentVisitor); this.record = record; } public AnnotationVisitor visitTypeAnnotation(int typeReference, TypePath typePath, String descriptor, boolean visible) { return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super.visitTypeAnnotation(typeReference, typePath, descriptor, visible) : TypeWriter.Default.ForInlining.IGNORE_ANNOTATION; } public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) { return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super.visitAnnotation(descriptor, visible) : TypeWriter.Default.ForInlining.IGNORE_ANNOTATION; } public void visitEnd() { this.record.apply(getDelegate(), TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory); super.visitEnd(); } } protected class CodePreservingMethodVisitor extends MethodVisitor { private final MethodVisitor actualMethodVisitor; private final TypeWriter.MethodPool.Record record; private final MethodRebaseResolver.Resolution resolution; protected CodePreservingMethodVisitor(MethodVisitor actualMethodVisitor, TypeWriter.MethodPool.Record record, MethodRebaseResolver.Resolution resolution) { super(OpenedClassReader.ASM_API, actualMethodVisitor); this.actualMethodVisitor = actualMethodVisitor; this.record = record; this.resolution = resolution; record.applyHead(actualMethodVisitor); } @MaybeNull public AnnotationVisitor visitAnnotationDefault() { return TypeWriter.Default.ForInlining.IGNORE_ANNOTATION; } @MaybeNull public AnnotationVisitor visitTypeAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) { return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super.visitTypeAnnotation(typeReference, typePath, descriptor, visible) : TypeWriter.Default.ForInlining.IGNORE_ANNOTATION; } @MaybeNull public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) { return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super.visitAnnotation(descriptor, visible) : TypeWriter.Default.ForInlining.IGNORE_ANNOTATION; } public void visitAnnotableParameterCount(int count, boolean visible) { if (TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled()) super.visitAnnotableParameterCount(count, visible);  } @MaybeNull public AnnotationVisitor visitParameterAnnotation(int index, String descriptor, boolean visible) { return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super.visitParameterAnnotation(index, descriptor, visible) : TypeWriter.Default.ForInlining.IGNORE_ANNOTATION; } public void visitCode() { this.record.applyBody(this.actualMethodVisitor, (Implementation.Context)TypeWriter.Default.ForInlining.WithFullProcessing.RedefinitionClassVisitor.this.implementationContext, TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory); this.actualMethodVisitor.visitEnd(); if (this.resolution.isRebased()) { this.mv = TypeWriter.Default.ForInlining.WithFullProcessing.RedefinitionClassVisitor.this.cv.visitMethod(this.resolution.getResolvedMethod().getActualModifiers(), this.resolution.getResolvedMethod().getInternalName(), this.resolution.getResolvedMethod().getDescriptor(), this.resolution.getResolvedMethod().getGenericSignature(), this.resolution.getResolvedMethod().getExceptionTypes().asErasures().toInternalNames()); super.visitCode(); if (!this.resolution.getAppendedParameters().isEmpty() && TypeWriter.Default.ForInlining.WithFullProcessing.RedefinitionClassVisitor.this.implementationContext.getFrameGeneration().isActive()) { if (TypeWriter.Default.ForInlining.WithFullProcessing.RedefinitionClassVisitor.this.implementationContext.getFrameGeneration() == Implementation.Context.FrameGeneration.GENERATE && this.resolution.getAppendedParameters().size() < 4) { visitFrame(2, this.resolution.getAppendedParameters().size(), TypeWriter.Default.ForInlining.WithFullProcessing.EMPTY, TypeWriter.Default.ForInlining.WithFullProcessing.EMPTY.length, TypeWriter.Default.ForInlining.WithFullProcessing.EMPTY); } else { Object[] frame = new Object[this.resolution.getResolvedMethod().getParameters().size() - this.resolution.getAppendedParameters().size() + 1]; frame[0] = Opcodes.UNINITIALIZED_THIS; for (int index = 1; index < frame.length; index++) { TypeDescription.Generic generic = ((ParameterDescription.InDefinedShape)this.resolution.getResolvedMethod().getParameters().get(index - 1)).getType(); if (generic.represents(boolean.class) || generic.represents(byte.class) || generic.represents(short.class) || generic.represents(char.class) || generic.represents(int.class)) { frame[index] = Opcodes.INTEGER; } else if (generic.represents(long.class)) { frame[index] = Opcodes.LONG; } else if (generic.represents(float.class)) { frame[index] = Opcodes.FLOAT; } else if (generic.represents(double.class)) { frame[index] = Opcodes.DOUBLE; } else { frame[index] = generic.asErasure().getInternalName(); }  }  visitFrame(((TypeWriter.Default.ForInlining.WithFullProcessing.RedefinitionClassVisitor.this.readerFlags & 0x8) == 0) ? 0 : -1, frame.length, frame, TypeWriter.Default.ForInlining.WithFullProcessing.EMPTY.length, TypeWriter.Default.ForInlining.WithFullProcessing.EMPTY); }  visitInsn(0); }  } else { this.mv = TypeWriter.Default.ForInlining.IGNORE_METHOD; super.visitCode(); }  } public void visitMaxs(int stackSize, int localVariableLength) { super.visitMaxs(stackSize, Math.max(localVariableLength, this.resolution.getResolvedMethod().getStackSize())); } } protected class AttributeObtainingMethodVisitor extends MethodVisitor { private final MethodVisitor actualMethodVisitor; private final TypeWriter.MethodPool.Record record; protected AttributeObtainingMethodVisitor(MethodVisitor actualMethodVisitor, TypeWriter.MethodPool.Record record) { super(OpenedClassReader.ASM_API, actualMethodVisitor); this.actualMethodVisitor = actualMethodVisitor; this.record = record; record.applyHead(actualMethodVisitor); } @MaybeNull public AnnotationVisitor visitAnnotationDefault() { return TypeWriter.Default.ForInlining.IGNORE_ANNOTATION; } @MaybeNull public AnnotationVisitor visitTypeAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) { return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super.visitTypeAnnotation(typeReference, typePath, descriptor, visible) : TypeWriter.Default.ForInlining.IGNORE_ANNOTATION; } @MaybeNull public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) { return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super.visitAnnotation(descriptor, visible) : TypeWriter.Default.ForInlining.IGNORE_ANNOTATION; } public void visitAnnotableParameterCount(int count, boolean visible) { if (TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled()) super.visitAnnotableParameterCount(count, visible);  } @MaybeNull public AnnotationVisitor visitParameterAnnotation(int index, String descriptor, boolean visible) { return TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationRetention.isEnabled() ? super.visitParameterAnnotation(index, descriptor, visible) : TypeWriter.Default.ForInlining.IGNORE_ANNOTATION; } public void visitCode() { this.mv = TypeWriter.Default.ForInlining.IGNORE_METHOD; } public void visitEnd() { this.record.applyBody(this.actualMethodVisitor, (Implementation.Context)TypeWriter.Default.ForInlining.WithFullProcessing.RedefinitionClassVisitor.this.implementationContext, TypeWriter.Default.ForInlining.WithFullProcessing.this.annotationValueFilterFactory); this.actualMethodVisitor.visitEnd(); } } } } protected static class WithDecorationOnly<V> extends ForInlining<V> { protected WithDecorationOnly(TypeDescription instrumentedType, ClassFileVersion classFileVersion, List<? extends DynamicType> auxiliaryTypes, MethodList<?> methods, TypeAttributeAppender typeAttributeAppender, AsmVisitorWrapper asmVisitorWrapper, AnnotationValueFilter.Factory annotationValueFilterFactory, AnnotationRetention annotationRetention, AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy, Implementation.Context.Factory implementationContextFactory, TypeValidation typeValidation, AsmClassReader.Factory classReaderFactory, AsmClassWriter.Factory classWriterFactory, TypePool typePool, ClassFileLocator classFileLocator) { super(instrumentedType, classFileVersion, TypeWriter.FieldPool.Disabled.INSTANCE, TypeWriter.RecordComponentPool.Disabled.INSTANCE, auxiliaryTypes, (FieldList<FieldDescription.InDefinedShape>)new LazyFieldList(instrumentedType), methods, (MethodList<?>)new MethodList.Empty(), (RecordComponentList<RecordComponentDescription.InDefinedShape>)new RecordComponentList.Empty(), (LoadedTypeInitializer)LoadedTypeInitializer.NoOp.INSTANCE, TypeInitializer.None.INSTANCE, typeAttributeAppender, asmVisitorWrapper, annotationValueFilterFactory, annotationRetention, auxiliaryTypeNamingStrategy, implementationContextFactory, typeValidation, classReaderFactory, classWriterFactory, typePool, instrumentedType, classFileLocator); } protected ClassVisitor writeTo(ClassVisitor classVisitor, TypeInitializer typeInitializer, TypeWriter.Default.ForInlining.ContextRegistry contextRegistry, int writerFlags, int readerFlags) { if (typeInitializer.isDefined()) throw new UnsupportedOperationException("Cannot apply a type initializer for a decoration");  return (ClassVisitor)new DecorationClassVisitor(classVisitor, contextRegistry, writerFlags, readerFlags); } protected static class LazyFieldList extends FieldList.AbstractBase<FieldDescription.InDefinedShape> { private final TypeDescription instrumentedType; protected LazyFieldList(TypeDescription instrumentedType) { this.instrumentedType = instrumentedType; } public FieldDescription.InDefinedShape get(int index) { return (FieldDescription.InDefinedShape)this.instrumentedType.getDeclaredFields().get(index); } public int size() { return this.instrumentedType.getDeclaredFields().size(); } } @SuppressFBWarnings(value = {"UWF_FIELD_NOT_INITIALIZED_IN_CONSTRUCTOR"}, justification = "Field access order is implied by ASM.") protected class DecorationClassVisitor extends MetadataAwareClassVisitor implements TypeInitializer.Drain { protected void onVisitEnd() { this.implementationContext.drain(this, this.cv, TypeWriter.Default.ForInlining.WithDecorationOnly.this.annotationValueFilterFactory); this.cv.visitEnd(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final TypeWriter.Default.ForInlining.ContextRegistry contextRegistry;
/*      */ 
/*      */         
/*      */         private final int writerFlags;
/*      */ 
/*      */         
/*      */         private final int readerFlags;
/*      */ 
/*      */         
/*      */         @UnknownNull
/*      */         private Implementation.Context.ExtractableView implementationContext;
/*      */ 
/*      */ 
/*      */         
/*      */         protected DecorationClassVisitor(ClassVisitor classVisitor, TypeWriter.Default.ForInlining.ContextRegistry contextRegistry, int writerFlags, int readerFlags) {
/*      */           super(OpenedClassReader.ASM_API, classVisitor);
/*      */           this.contextRegistry = contextRegistry;
/*      */           this.writerFlags = writerFlags;
/*      */           this.readerFlags = readerFlags;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public void visit(int classFileVersionNumber, int modifiers, String internalName, String genericSignature, String superClassInternalName, String[] interfaceTypeInternalName) {
/*      */           ClassFileVersion classFileVersion = ClassFileVersion.ofMinorMajor(classFileVersionNumber);
/*      */           this.implementationContext = TypeWriter.Default.ForInlining.WithDecorationOnly.this.implementationContextFactory.make(TypeWriter.Default.ForInlining.WithDecorationOnly.this.instrumentedType, TypeWriter.Default.ForInlining.WithDecorationOnly.this.auxiliaryTypeNamingStrategy, TypeWriter.Default.ForInlining.WithDecorationOnly.this.typeInitializer, classFileVersion, TypeWriter.Default.ForInlining.WithDecorationOnly.this.classFileVersion, ((this.writerFlags & 0x2) == 0 && classFileVersion.isAtLeast(ClassFileVersion.JAVA_V6)) ? (((this.readerFlags & 0x8) == 0) ? Implementation.Context.FrameGeneration.GENERATE : Implementation.Context.FrameGeneration.EXPAND) : Implementation.Context.FrameGeneration.DISABLED);
/*      */           this.contextRegistry.setImplementationContext(this.implementationContext);
/*      */           this.cv = TypeWriter.Default.ForInlining.WithDecorationOnly.this.asmVisitorWrapper.wrap(TypeWriter.Default.ForInlining.WithDecorationOnly.this.instrumentedType, this.cv, (Implementation.Context)this.implementationContext, TypeWriter.Default.ForInlining.WithDecorationOnly.this.typePool, TypeWriter.Default.ForInlining.WithDecorationOnly.this.fields, TypeWriter.Default.ForInlining.WithDecorationOnly.this.methods, this.writerFlags, this.readerFlags);
/*      */           this.cv.visit(classFileVersionNumber, modifiers, internalName, genericSignature, superClassInternalName, interfaceTypeInternalName);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         @MaybeNull
/*      */         protected AnnotationVisitor onVisitTypeAnnotation(int typeReference, TypePath typePath, String descriptor, boolean visible) {
/*      */           return TypeWriter.Default.ForInlining.WithDecorationOnly.this.annotationRetention.isEnabled() ? this.cv.visitTypeAnnotation(typeReference, typePath, descriptor, visible) : TypeWriter.Default.ForInlining.IGNORE_ANNOTATION;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         @MaybeNull
/*      */         protected AnnotationVisitor onVisitAnnotation(String descriptor, boolean visible) {
/*      */           return TypeWriter.Default.ForInlining.WithDecorationOnly.this.annotationRetention.isEnabled() ? this.cv.visitAnnotation(descriptor, visible) : TypeWriter.Default.ForInlining.IGNORE_ANNOTATION;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         protected void onAfterAttributes() {
/*      */           TypeWriter.Default.ForInlining.WithDecorationOnly.this.typeAttributeAppender.apply(this.cv, TypeWriter.Default.ForInlining.WithDecorationOnly.this.instrumentedType, TypeWriter.Default.ForInlining.WithDecorationOnly.this.annotationValueFilterFactory.on(TypeWriter.Default.ForInlining.WithDecorationOnly.this.instrumentedType));
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public void apply(ClassVisitor classVisitor, TypeInitializer typeInitializer, Implementation.Context implementationContext) {} }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class ForCreation<U>
/*      */       extends Default<U>
/*      */     {
/*      */       private final TypeWriter.MethodPool methodPool;
/*      */ 
/*      */ 
/*      */       
/*      */       protected ForCreation(TypeDescription instrumentedType, ClassFileVersion classFileVersion, TypeWriter.FieldPool fieldPool, TypeWriter.MethodPool methodPool, TypeWriter.RecordComponentPool recordComponentPool, List<? extends DynamicType> auxiliaryTypes, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, MethodList<?> instrumentedMethods, RecordComponentList<RecordComponentDescription.InDefinedShape> recordComponents, LoadedTypeInitializer loadedTypeInitializer, TypeInitializer typeInitializer, TypeAttributeAppender typeAttributeAppender, AsmVisitorWrapper asmVisitorWrapper, AnnotationValueFilter.Factory annotationValueFilterFactory, AnnotationRetention annotationRetention, AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy, Implementation.Context.Factory implementationContextFactory, TypeValidation typeValidation, AsmClassReader.Factory classReaderFactory, AsmClassWriter.Factory classWriterFactory, TypePool typePool) {
/* 6005 */         super(instrumentedType, classFileVersion, fieldPool, recordComponentPool, auxiliaryTypes, fields, methods, instrumentedMethods, recordComponents, loadedTypeInitializer, typeInitializer, typeAttributeAppender, asmVisitorWrapper, annotationValueFilterFactory, annotationRetention, auxiliaryTypeNamingStrategy, implementationContextFactory, typeValidation, classReaderFactory, classWriterFactory, typePool);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6026 */         this.methodPool = methodPool;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ContextClassVisitor wrap(ClassVisitor classVisitor, int writerFlags, int readerFlags) {
/* 6033 */         Implementation.Context.ExtractableView implementationContext = this.implementationContextFactory.make(this.instrumentedType, this.auxiliaryTypeNamingStrategy, this.typeInitializer, this.classFileVersion, this.classFileVersion, ((writerFlags & 0x2) == 0 && this.classFileVersion
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 6038 */             .isAtLeast(ClassFileVersion.JAVA_V6)) ? (((readerFlags & 0x8) == 0) ? Implementation.Context.FrameGeneration.GENERATE : Implementation.Context.FrameGeneration.EXPAND) : Implementation.Context.FrameGeneration.DISABLED);
/*      */ 
/*      */         
/* 6041 */         return new ImplementationContextClassVisitor((ClassVisitor)new CreationClassVisitor(this.asmVisitorWrapper.wrap(this.instrumentedType, 
/* 6042 */                 TypeWriter.Default.ValidatingClassVisitor.of(classVisitor, this.typeValidation), (Implementation.Context)implementationContext, this.typePool, this.fields, this.methods, this.asmVisitorWrapper
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 6047 */                 .mergeWriter(writerFlags), this.asmVisitorWrapper
/* 6048 */                 .mergeReader(readerFlags)), implementationContext), implementationContext);
/*      */       }
/*      */ 
/*      */       
/*      */       @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Relying on correlated type properties.")
/*      */       protected TypeWriter.Default<U>.UnresolvedType create(TypeInitializer typeInitializer, TypeWriter.Default.ClassDumpAction.Dispatcher dispatcher) {
/* 6054 */         int writerFlags = this.asmVisitorWrapper.mergeWriter(0), readerFlags = this.asmVisitorWrapper.mergeReader(0);
/* 6055 */         AsmClassWriter classWriter = this.classWriterFactory.make(writerFlags, this.typePool);
/* 6056 */         Implementation.Context.ExtractableView implementationContext = this.implementationContextFactory.make(this.instrumentedType, this.auxiliaryTypeNamingStrategy, typeInitializer, this.classFileVersion, this.classFileVersion, ((writerFlags & 0x2) == 0 && this.classFileVersion
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 6061 */             .isAtLeast(ClassFileVersion.JAVA_V6)) ? (((readerFlags & 0x8) == 0) ? Implementation.Context.FrameGeneration.GENERATE : Implementation.Context.FrameGeneration.EXPAND) : Implementation.Context.FrameGeneration.DISABLED);
/*      */ 
/*      */         
/* 6064 */         ClassVisitor classVisitor = this.asmVisitorWrapper.wrap(this.instrumentedType, 
/* 6065 */             TypeWriter.Default.ValidatingClassVisitor.of(classWriter.getVisitor(), this.typeValidation), (Implementation.Context)implementationContext, this.typePool, this.fields, this.methods, writerFlags, readerFlags);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6072 */         classVisitor.visit(this.classFileVersion.getMinorMajorVersion(), this.instrumentedType
/* 6073 */             .getActualModifiers(!this.instrumentedType.isInterface()), this.instrumentedType
/* 6074 */             .getInternalName(), this.instrumentedType
/* 6075 */             .getGenericSignature(), (
/* 6076 */             (this.instrumentedType.getSuperClass() == null) ? 
/* 6077 */             TypeDescription.ForLoadedType.of(Object.class) : this.instrumentedType
/* 6078 */             .getSuperClass().asErasure()).getInternalName(), this.instrumentedType
/* 6079 */             .getInterfaces().asErasures().toInternalNames());
/* 6080 */         if (!this.instrumentedType.isNestHost()) {
/* 6081 */           classVisitor.visitNestHost(this.instrumentedType.getNestHost().getInternalName());
/*      */         }
/* 6083 */         MethodDescription.InDefinedShape enclosingMethod = this.instrumentedType.getEnclosingMethod();
/* 6084 */         if (enclosingMethod != null) {
/* 6085 */           classVisitor.visitOuterClass(enclosingMethod.getDeclaringType().getInternalName(), enclosingMethod
/* 6086 */               .getInternalName(), enclosingMethod
/* 6087 */               .getDescriptor());
/* 6088 */         } else if (this.instrumentedType.isLocalType() || this.instrumentedType.isAnonymousType()) {
/* 6089 */           classVisitor.visitOuterClass(this.instrumentedType.getEnclosingType().getInternalName(), TypeWriter.Default.NO_REFERENCE, TypeWriter.Default.NO_REFERENCE);
/*      */         } 
/* 6091 */         this.typeAttributeAppender.apply(classVisitor, this.instrumentedType, this.annotationValueFilterFactory.on(this.instrumentedType));
/* 6092 */         if (this.instrumentedType.isNestHost()) {
/* 6093 */           for (TypeDescription typeDescription : this.instrumentedType.getNestMembers().filter((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.is(this.instrumentedType)))) {
/* 6094 */             classVisitor.visitNestMember(typeDescription.getInternalName());
/*      */           }
/*      */         }
/* 6097 */         for (TypeDescription typeDescription : this.instrumentedType.getPermittedSubtypes()) {
/* 6098 */           classVisitor.visitPermittedSubclass(typeDescription.getInternalName());
/*      */         }
/* 6100 */         TypeDescription declaringType = this.instrumentedType.getDeclaringType();
/* 6101 */         if (declaringType != null) {
/* 6102 */           classVisitor.visitInnerClass(this.instrumentedType.getInternalName(), declaringType
/* 6103 */               .getInternalName(), this.instrumentedType
/* 6104 */               .getSimpleName(), this.instrumentedType
/* 6105 */               .getModifiers());
/* 6106 */         } else if (this.instrumentedType.isLocalType()) {
/* 6107 */           classVisitor.visitInnerClass(this.instrumentedType.getInternalName(), TypeWriter.Default
/* 6108 */               .NO_REFERENCE, this.instrumentedType
/* 6109 */               .getSimpleName(), this.instrumentedType
/* 6110 */               .getModifiers());
/* 6111 */         } else if (this.instrumentedType.isAnonymousType()) {
/* 6112 */           classVisitor.visitInnerClass(this.instrumentedType.getInternalName(), TypeWriter.Default
/* 6113 */               .NO_REFERENCE, TypeWriter.Default
/* 6114 */               .NO_REFERENCE, this.instrumentedType
/* 6115 */               .getModifiers());
/*      */         } 
/* 6117 */         for (TypeDescription typeDescription : this.instrumentedType.getDeclaredTypes()) {
/* 6118 */           classVisitor.visitInnerClass(typeDescription.getInternalName(), 
/* 6119 */               typeDescription.isMemberType() ? this.instrumentedType
/* 6120 */               .getInternalName() : TypeWriter.Default
/* 6121 */               .NO_REFERENCE, 
/* 6122 */               typeDescription.isAnonymousType() ? TypeWriter.Default
/* 6123 */               .NO_REFERENCE : typeDescription
/* 6124 */               .getSimpleName(), typeDescription
/* 6125 */               .getModifiers());
/*      */         }
/* 6127 */         for (RecordComponentDescription recordComponentDescription : this.recordComponents) {
/* 6128 */           this.recordComponentPool.target(recordComponentDescription).apply(classVisitor, this.annotationValueFilterFactory);
/*      */         }
/* 6130 */         for (FieldDescription fieldDescription : this.fields) {
/* 6131 */           this.fieldPool.target(fieldDescription).apply(classVisitor, this.annotationValueFilterFactory);
/*      */         }
/* 6133 */         for (MethodDescription methodDescription : this.instrumentedMethods) {
/* 6134 */           this.methodPool.target(methodDescription).apply(classVisitor, (Implementation.Context)implementationContext, this.annotationValueFilterFactory);
/*      */         }
/* 6136 */         implementationContext.drain(new TypeInitializer.Drain.Default(this.instrumentedType, this.methodPool, this.annotationValueFilterFactory), classVisitor, this.annotationValueFilterFactory);
/*      */ 
/*      */         
/* 6139 */         classVisitor.visitEnd();
/* 6140 */         return new TypeWriter.Default.UnresolvedType(classWriter.getBinaryRepresentation(), implementationContext.getAuxiliaryTypes());
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return !super.equals(param2Object) ? false : ((this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.methodPool.equals(((ForCreation)param2Object).methodPool)))));
/*      */       }
/*      */       
/*      */       public int hashCode() {
/*      */         return super.hashCode() * 31 + this.methodPool.hashCode();
/*      */       }
/*      */       
/*      */       protected class CreationClassVisitor
/*      */         extends MetadataAwareClassVisitor
/*      */       {
/*      */         private final Implementation.Context.ExtractableView implementationContext;
/* 6156 */         private final Set<String> declaredTypes = new HashSet<String>();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6161 */         private final Set<TypeWriter.Default.SignatureKey> visitedFields = new HashSet<TypeWriter.Default.SignatureKey>();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6166 */         private final Set<TypeWriter.Default.SignatureKey> visitedMethods = new HashSet<TypeWriter.Default.SignatureKey>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected CreationClassVisitor(ClassVisitor classVisitor, Implementation.Context.ExtractableView implementationContext) {
/* 6175 */           super(OpenedClassReader.ASM_API, classVisitor);
/* 6176 */           this.implementationContext = implementationContext;
/*      */         }
/*      */ 
/*      */         
/*      */         protected void onAfterAttributes() {
/* 6181 */           TypeWriter.Default.ForCreation.this.typeAttributeAppender.apply(this.cv, TypeWriter.Default.ForCreation.this.instrumentedType, TypeWriter.Default.ForCreation.this.annotationValueFilterFactory.on(TypeWriter.Default.ForCreation.this.instrumentedType));
/*      */         }
/*      */ 
/*      */         
/*      */         protected void onVisitInnerClass(String internalName, @MaybeNull String outerName, @MaybeNull String innerName, int modifiers) {
/* 6186 */           this.declaredTypes.add(internalName);
/* 6187 */           super.onVisitInnerClass(internalName, outerName, innerName, modifiers);
/*      */         }
/*      */ 
/*      */         
/*      */         @MaybeNull
/*      */         protected FieldVisitor onVisitField(int modifiers, String name, String descriptor, @MaybeNull String signature, @MaybeNull Object value) {
/* 6193 */           this.visitedFields.add(new TypeWriter.Default.SignatureKey(name, descriptor));
/* 6194 */           return super.onVisitField(modifiers, name, descriptor, signature, value);
/*      */         }
/*      */ 
/*      */         
/*      */         @MaybeNull
/*      */         protected MethodVisitor onVisitMethod(int modifiers, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull String[] exception) {
/* 6200 */           this.visitedMethods.add(new TypeWriter.Default.SignatureKey(internalName, descriptor));
/* 6201 */           return super.onVisitMethod(modifiers, internalName, descriptor, signature, exception);
/*      */         }
/*      */ 
/*      */         
/*      */         protected void onVisitEnd() {
/* 6206 */           for (TypeDescription typeDescription : TypeWriter.Default.ForCreation.this.instrumentedType.getDeclaredTypes()) {
/* 6207 */             if (!this.declaredTypes.contains(typeDescription.getInternalName())) {
/* 6208 */               this.cv.visitInnerClass(typeDescription.getInternalName(), 
/* 6209 */                   typeDescription.isMemberType() ? TypeWriter.Default.ForCreation.this.instrumentedType
/* 6210 */                   .getInternalName() : TypeWriter.Default
/* 6211 */                   .NO_REFERENCE, 
/* 6212 */                   typeDescription.isAnonymousType() ? TypeWriter.Default
/* 6213 */                   .NO_REFERENCE : typeDescription
/* 6214 */                   .getSimpleName(), typeDescription
/* 6215 */                   .getModifiers());
/*      */             }
/*      */           } 
/* 6218 */           for (FieldDescription fieldDescription : TypeWriter.Default.ForCreation.this.fields) {
/* 6219 */             if (!this.visitedFields.contains(new TypeWriter.Default.SignatureKey(fieldDescription.getName(), fieldDescription.getDescriptor()))) {
/* 6220 */               TypeWriter.Default.ForCreation.this.fieldPool.target(fieldDescription).apply(this.cv, TypeWriter.Default.ForCreation.this.annotationValueFilterFactory);
/*      */             }
/*      */           } 
/* 6223 */           for (MethodDescription methodDescription : TypeWriter.Default.ForCreation.this.instrumentedMethods) {
/* 6224 */             if (!this.visitedMethods.contains(new TypeWriter.Default.SignatureKey(methodDescription.getInternalName(), methodDescription.getDescriptor()))) {
/* 6225 */               TypeWriter.Default.ForCreation.this.methodPool.target(methodDescription).apply(this.cv, (Implementation.Context)this.implementationContext, TypeWriter.Default.ForCreation.this.annotationValueFilterFactory);
/*      */             }
/*      */           } 
/* 6228 */           this.implementationContext.drain(new TypeInitializer.Drain.Default(TypeWriter.Default.ForCreation.this.instrumentedType, TypeWriter.Default.ForCreation.this
/* 6229 */                 .methodPool, TypeWriter.Default.ForCreation.this.annotationValueFilterFactory), this.cv, TypeWriter.Default.ForCreation.this.annotationValueFilterFactory);
/*      */           
/* 6231 */           super.onVisitEnd();
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected class ImplementationContextClassVisitor
/*      */         extends ContextClassVisitor
/*      */       {
/*      */         private final Implementation.Context.ExtractableView implementationContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected ImplementationContextClassVisitor(ClassVisitor classVisitor, Implementation.Context.ExtractableView implementationContext) {
/* 6252 */           super(classVisitor);
/* 6253 */           this.implementationContext = implementationContext;
/*      */         }
/*      */ 
/*      */         
/*      */         public List<DynamicType> getAuxiliaryTypes() {
/* 6258 */           return CompoundList.of(TypeWriter.Default.ForCreation.this.auxiliaryTypes, this.implementationContext.getAuxiliaryTypes());
/*      */         }
/*      */ 
/*      */         
/*      */         public LoadedTypeInitializer getLoadedTypeInitializer() {
/* 6263 */           return TypeWriter.Default.ForCreation.this.loadedTypeInitializer;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     protected static class ClassDumpAction
/*      */       implements PrivilegedExceptionAction<Void>
/*      */     {
/*      */       @AlwaysNull
/* 6278 */       private static final Void NOTHING = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final String target;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final TypeDescription instrumentedType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final boolean original;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final long suffix;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final byte[] binaryRepresentation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected ClassDumpAction(String target, TypeDescription instrumentedType, boolean original, long suffix, byte[] binaryRepresentation) {
/* 6315 */         this.target = target;
/* 6316 */         this.instrumentedType = instrumentedType;
/* 6317 */         this.original = original;
/* 6318 */         this.suffix = suffix;
/* 6319 */         this.binaryRepresentation = binaryRepresentation;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Void run() throws Exception {
/* 6326 */         OutputStream outputStream = new FileOutputStream(new File(this.target, this.instrumentedType.getName() + (this.original ? "-original." : ".") + this.suffix + ".class"));
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 6331 */           outputStream.write(this.binaryRepresentation);
/* 6332 */           return NOTHING;
/*      */         } finally {
/* 6334 */           outputStream.close();
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.original != ((ClassDumpAction)param2Object).original) ? false : ((this.suffix != ((ClassDumpAction)param2Object).suffix) ? false : (!this.target.equals(((ClassDumpAction)param2Object).target) ? false : (!this.instrumentedType.equals(((ClassDumpAction)param2Object).instrumentedType) ? false : (!!Arrays.equals(this.binaryRepresentation, ((ClassDumpAction)param2Object).binaryRepresentation))))))));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return ((((getClass().hashCode() * 31 + this.target.hashCode()) * 31 + this.instrumentedType.hashCode()) * 31 + this.original) * 31 + (int)(this.suffix ^ this.suffix >>> 32L)) * 31 + Arrays.hashCode(this.binaryRepresentation);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       protected static interface Dispatcher
/*      */       {
/*      */         void dump(TypeDescription param3TypeDescription, boolean param3Boolean, byte[] param3ArrayOfbyte);
/*      */ 
/*      */         
/*      */         public enum Disabled
/*      */           implements Dispatcher
/*      */         {
/* 6360 */           INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void dump(TypeDescription instrumentedType, boolean original, byte[] binaryRepresentation) {}
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         public static class Enabled
/*      */           implements Dispatcher
/*      */         {
/*      */           private final String folder;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final long timestamp;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected Enabled(String folder, long timestamp) {
/* 6393 */             this.folder = folder;
/* 6394 */             this.timestamp = timestamp;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public void dump(TypeDescription instrumentedType, boolean original, byte[] binaryRepresentation)
/*      */           {
/*      */             
/* 6402 */             try { TypeWriter.Default.doPrivileged(new TypeWriter.Default.ClassDumpAction(this.folder, instrumentedType, original, this.timestamp, binaryRepresentation)); }
/* 6403 */             catch (Exception exception)
/* 6404 */             { exception.printStackTrace(); }  } public boolean equals(@MaybeNull Object param4Object) { return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : ((this.timestamp != ((Enabled)param4Object).timestamp) ? false : (!!this.folder.equals(((Enabled)param4Object).folder))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.folder.hashCode()) * 31 + (int)(this.timestamp ^ this.timestamp >>> 32L); } } } } public enum Disabled implements ClassDumpAction.Dispatcher { INSTANCE; public void dump(TypeDescription instrumentedType, boolean original, byte[] binaryRepresentation) {} } protected static interface Dispatcher { void dump(TypeDescription param2TypeDescription, boolean param2Boolean, byte[] param2ArrayOfbyte); public enum Disabled implements Dispatcher { INSTANCE; public void dump(TypeDescription instrumentedType, boolean original, byte[] binaryRepresentation) {} } @Enhance public static class Enabled implements Dispatcher { private final String folder; private final long timestamp; protected Enabled(String folder, long timestamp) { this.folder = folder; this.timestamp = timestamp; } public void dump(TypeDescription instrumentedType, boolean original, byte[] binaryRepresentation) { try { TypeWriter.Default.doPrivileged(new TypeWriter.Default.ClassDumpAction(this.folder, instrumentedType, original, this.timestamp, binaryRepresentation)); } catch (Exception exception) { exception.printStackTrace(); }  } public boolean equals(@MaybeNull Object param4Object) { return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : ((this.timestamp != ((Enabled)param4Object).timestamp) ? false : (!!this.folder.equals(((Enabled)param4Object).folder))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.folder.hashCode()) * 31 + (int)(this.timestamp ^ this.timestamp >>> 32L); } } } @Enhance public static class Enabled implements ClassDumpAction.Dispatcher { private final String folder; private final long timestamp; protected Enabled(String folder, long timestamp) { this.folder = folder; this.timestamp = timestamp; } public void dump(TypeDescription instrumentedType, boolean original, byte[] binaryRepresentation) { try { TypeWriter.Default.doPrivileged(new TypeWriter.Default.ClassDumpAction(this.folder, instrumentedType, original, this.timestamp, binaryRepresentation)); } catch (Exception exception) { exception.printStackTrace(); }
/*      */          }
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.timestamp != ((Enabled)param2Object).timestamp) ? false : (!!this.folder.equals(((Enabled)param2Object).folder)))));
/*      */       }
/*      */       
/*      */       public int hashCode() {
/*      */         return (getClass().hashCode() * 31 + this.folder.hashCode()) * 31 + (int)(this.timestamp ^ this.timestamp >>> 32L);
/*      */       } }
/*      */   
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\scaffold\TypeWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */