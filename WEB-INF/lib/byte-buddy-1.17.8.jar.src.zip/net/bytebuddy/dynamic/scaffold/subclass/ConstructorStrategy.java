/*     */ package net.bytebuddy.dynamic.scaffold.subclass;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.Transformer;
/*     */ import net.bytebuddy.dynamic.scaffold.MethodRegistry;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.MethodCall;
/*     */ import net.bytebuddy.implementation.SuperMethodCall;
/*     */ import net.bytebuddy.implementation.attribute.MethodAttributeAppender;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.matcher.LatentMatcher;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ConstructorStrategy
/*     */ {
/*     */   List<MethodDescription.Token> extractConstructors(TypeDescription paramTypeDescription);
/*     */   
/*     */   MethodRegistry inject(TypeDescription paramTypeDescription, MethodRegistry paramMethodRegistry);
/*     */   
/*     */   public enum Default
/*     */     implements ConstructorStrategy
/*     */   {
/*  76 */     NO_CONSTRUCTORS
/*     */     {
/*     */       protected List<MethodDescription.Token> doExtractConstructors(TypeDescription superClass) {
/*  79 */         return Collections.emptyList();
/*     */       }
/*     */ 
/*     */       
/*     */       protected MethodRegistry doInject(MethodRegistry methodRegistry, MethodAttributeAppender.Factory methodAttributeAppenderFactory) {
/*  84 */         return methodRegistry;
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     DEFAULT_CONSTRUCTOR
/*     */     {
/*     */       protected List<MethodDescription.Token> doExtractConstructors(TypeDescription instrumentedType) {
/*  97 */         TypeDescription.Generic superClass = instrumentedType.getSuperClass();
/*     */ 
/*     */         
/* 100 */         MethodList<?> defaultConstructors = (superClass == null) ? (MethodList<?>)new MethodList.Empty() : (MethodList)superClass.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isConstructor().and((ElementMatcher)ElementMatchers.takesArguments(0)).and((ElementMatcher)ElementMatchers.isVisibleTo(instrumentedType)));
/* 101 */         if (defaultConstructors.size() == 1) {
/* 102 */           return Collections.singletonList(new MethodDescription.Token(1));
/*     */         }
/* 104 */         throw new IllegalArgumentException(instrumentedType.getSuperClass() + " declares no constructor that is visible to " + instrumentedType);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       protected MethodRegistry doInject(MethodRegistry methodRegistry, MethodAttributeAppender.Factory methodAttributeAppenderFactory) {
/* 110 */         return methodRegistry.append((LatentMatcher)new LatentMatcher.Resolved((ElementMatcher)ElementMatchers.isConstructor()), (MethodRegistry.Handler)new MethodRegistry.Handler.ForImplementation((Implementation)SuperMethodCall.INSTANCE), methodAttributeAppenderFactory, 
/*     */ 
/*     */             
/* 113 */             Transformer.NoOp.make());
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     IMITATE_SUPER_CLASS
/*     */     {
/*     */       protected List<MethodDescription.Token> doExtractConstructors(TypeDescription instrumentedType) {
/* 126 */         TypeDescription.Generic superClass = instrumentedType.getSuperClass();
/* 127 */         return (List<MethodDescription.Token>)((superClass == null) ? new MethodList.Empty() : superClass
/*     */           
/* 129 */           .getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isConstructor().and((ElementMatcher)ElementMatchers.isVisibleTo(instrumentedType)))).asTokenList((ElementMatcher)ElementMatchers.is(instrumentedType));
/*     */       }
/*     */ 
/*     */       
/*     */       public MethodRegistry doInject(MethodRegistry methodRegistry, MethodAttributeAppender.Factory methodAttributeAppenderFactory) {
/* 134 */         return methodRegistry.append((LatentMatcher)new LatentMatcher.Resolved((ElementMatcher)ElementMatchers.isConstructor()), (MethodRegistry.Handler)new MethodRegistry.Handler.ForImplementation((Implementation)SuperMethodCall.INSTANCE), methodAttributeAppenderFactory, 
/*     */ 
/*     */             
/* 137 */             Transformer.NoOp.make());
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     IMITATE_SUPER_CLASS_PUBLIC
/*     */     {
/*     */       protected List<MethodDescription.Token> doExtractConstructors(TypeDescription instrumentedType) {
/* 149 */         TypeDescription.Generic superClass = instrumentedType.getSuperClass();
/* 150 */         return (List<MethodDescription.Token>)((superClass == null) ? new MethodList.Empty() : superClass
/*     */           
/* 152 */           .getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isPublic().and((ElementMatcher)ElementMatchers.isConstructor()))).asTokenList((ElementMatcher)ElementMatchers.is(instrumentedType));
/*     */       }
/*     */ 
/*     */       
/*     */       public MethodRegistry doInject(MethodRegistry methodRegistry, MethodAttributeAppender.Factory methodAttributeAppenderFactory) {
/* 157 */         return methodRegistry.append((LatentMatcher)new LatentMatcher.Resolved((ElementMatcher)ElementMatchers.isConstructor()), (MethodRegistry.Handler)new MethodRegistry.Handler.ForImplementation((Implementation)SuperMethodCall.INSTANCE), methodAttributeAppenderFactory, 
/*     */ 
/*     */             
/* 160 */             Transformer.NoOp.make());
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     IMITATE_SUPER_CLASS_OPENING
/*     */     {
/*     */       protected List<MethodDescription.Token> doExtractConstructors(TypeDescription instrumentedType) {
/* 172 */         TypeDescription.Generic superClass = instrumentedType.getSuperClass();
/* 173 */         return (List<MethodDescription.Token>)((superClass == null) ? new MethodList.Empty() : superClass
/*     */           
/* 175 */           .getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isConstructor().and((ElementMatcher)ElementMatchers.isVisibleTo(instrumentedType)))).asTokenList((ElementMatcher)ElementMatchers.is(instrumentedType));
/*     */       }
/*     */ 
/*     */       
/*     */       public MethodRegistry doInject(MethodRegistry methodRegistry, MethodAttributeAppender.Factory methodAttributeAppenderFactory) {
/* 180 */         return methodRegistry.append((LatentMatcher)new LatentMatcher.Resolved((ElementMatcher)ElementMatchers.isConstructor()), (MethodRegistry.Handler)new MethodRegistry.Handler.ForImplementation((Implementation)SuperMethodCall.INSTANCE), methodAttributeAppenderFactory, 
/*     */ 
/*     */             
/* 183 */             Transformer.NoOp.make());
/*     */       }
/*     */ 
/*     */       
/*     */       protected int resolveModifier(int modifiers) {
/* 188 */         return 1;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<MethodDescription.Token> extractConstructors(TypeDescription instrumentedType) {
/* 196 */       List<MethodDescription.Token> tokens = doExtractConstructors(instrumentedType), stripped = new ArrayList<MethodDescription.Token>(tokens.size());
/* 197 */       for (MethodDescription.Token token : tokens) {
/* 198 */         stripped.add(new MethodDescription.Token(token.getName(), 
/* 199 */               resolveModifier(token.getModifiers()), (List)token
/* 200 */               .getTypeVariableTokens(), token
/* 201 */               .getReturnType(), (List)token
/* 202 */               .getParameterTokens(), (List)token
/* 203 */               .getExceptionTypes(), (List)token
/* 204 */               .getAnnotations(), token
/* 205 */               .getDefaultValue(), TypeDescription.Generic.UNDEFINED));
/*     */       }
/*     */       
/* 208 */       return stripped;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected int resolveModifier(int modifiers) {
/* 218 */       return modifiers;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodRegistry inject(TypeDescription instrumentedType, MethodRegistry methodRegistry) {
/* 233 */       return doInject(methodRegistry, (MethodAttributeAppender.Factory)MethodAttributeAppender.NoOp.INSTANCE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConstructorStrategy with(MethodAttributeAppender.Factory methodAttributeAppenderFactory) {
/* 252 */       return new WithMethodAttributeAppenderFactory(this, methodAttributeAppenderFactory);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ConstructorStrategy withInheritedAnnotations() {
/* 261 */       return new WithMethodAttributeAppenderFactory(this, (MethodAttributeAppender.Factory)MethodAttributeAppender.ForInstrumentedMethod.EXCLUDING_RECEIVER);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected abstract List<MethodDescription.Token> doExtractConstructors(TypeDescription param1TypeDescription);
/*     */ 
/*     */ 
/*     */     
/*     */     protected abstract MethodRegistry doInject(MethodRegistry param1MethodRegistry, MethodAttributeAppender.Factory param1Factory);
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     protected static class WithMethodAttributeAppenderFactory
/*     */       implements ConstructorStrategy
/*     */     {
/*     */       private final ConstructorStrategy.Default delegate;
/*     */ 
/*     */       
/*     */       private final MethodAttributeAppender.Factory methodAttributeAppenderFactory;
/*     */ 
/*     */ 
/*     */       
/*     */       protected WithMethodAttributeAppenderFactory(ConstructorStrategy.Default delegate, MethodAttributeAppender.Factory methodAttributeAppenderFactory) {
/* 287 */         this.delegate = delegate;
/* 288 */         this.methodAttributeAppenderFactory = methodAttributeAppenderFactory;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public List<MethodDescription.Token> extractConstructors(TypeDescription instrumentedType) {
/* 295 */         return this.delegate.extractConstructors(instrumentedType);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public MethodRegistry inject(TypeDescription instrumentedType, MethodRegistry methodRegistry) {
/* 302 */         return this.delegate.doInject(methodRegistry, this.methodAttributeAppenderFactory);
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.delegate.equals(((WithMethodAttributeAppenderFactory)param2Object).delegate) ? false : (!!this.methodAttributeAppenderFactory.equals(((WithMethodAttributeAppenderFactory)param2Object).methodAttributeAppenderFactory)))));
/*     */       }
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return (getClass().hashCode() * 31 + this.delegate.hashCode()) * 31 + this.methodAttributeAppenderFactory.hashCode();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class ForDefaultConstructor
/*     */     implements ConstructorStrategy
/*     */   {
/*     */     private final ElementMatcher<? super MethodDescription> elementMatcher;
/*     */     
/*     */     private final MethodAttributeAppender.Factory methodAttributeAppenderFactory;
/*     */     
/*     */     public ForDefaultConstructor() {
/* 327 */       this((ElementMatcher<? super MethodDescription>)ElementMatchers.any());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForDefaultConstructor(ElementMatcher<? super MethodDescription> elementMatcher) {
/* 336 */       this(elementMatcher, (MethodAttributeAppender.Factory)MethodAttributeAppender.NoOp.INSTANCE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForDefaultConstructor(MethodAttributeAppender.Factory methodAttributeAppenderFactory) {
/* 345 */       this((ElementMatcher<? super MethodDescription>)ElementMatchers.any(), methodAttributeAppenderFactory);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForDefaultConstructor(ElementMatcher<? super MethodDescription> elementMatcher, MethodAttributeAppender.Factory methodAttributeAppenderFactory) {
/* 356 */       this.elementMatcher = elementMatcher;
/* 357 */       this.methodAttributeAppenderFactory = methodAttributeAppenderFactory;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<MethodDescription.Token> extractConstructors(TypeDescription instrumentedType) {
/* 364 */       TypeDescription.Generic superClass = instrumentedType.getSuperClass();
/* 365 */       if (superClass == null)
/* 366 */         throw new IllegalArgumentException("Cannot extract constructors for " + instrumentedType); 
/* 367 */       if (((MethodList)superClass.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isConstructor())).isEmpty()) {
/* 368 */         throw new IllegalStateException("Cannot define default constructor for class without super class constructor");
/*     */       }
/* 370 */       return Collections.singletonList(new MethodDescription.Token(1));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodRegistry inject(TypeDescription instrumentedType, MethodRegistry methodRegistry) {
/*     */       MethodCall methodCall;
/* 377 */       TypeDescription.Generic superClass = instrumentedType.getSuperClass();
/* 378 */       if (superClass == null) {
/* 379 */         throw new IllegalArgumentException("Cannot inject constructors for " + instrumentedType);
/*     */       }
/* 381 */       MethodList<?> candidates = (MethodList)superClass.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isConstructor().and(this.elementMatcher));
/* 382 */       if (candidates.isEmpty())
/* 383 */         throw new IllegalStateException("No possible candidate for super constructor invocation in " + superClass); 
/* 384 */       if (!((MethodList)candidates.filter((ElementMatcher)ElementMatchers.takesArguments(0))).isEmpty()) {
/* 385 */         candidates = (MethodList)candidates.filter((ElementMatcher)ElementMatchers.takesArguments(0));
/* 386 */       } else if (candidates.size() > 1) {
/* 387 */         throw new IllegalStateException("More than one possible super constructor for constructor delegation: " + candidates);
/*     */       } 
/* 389 */       MethodCall.WithoutSpecifiedTarget withoutSpecifiedTarget = MethodCall.invoke((MethodDescription)candidates.getOnly());
/* 390 */       for (TypeDescription typeDescription : ((MethodDescription)candidates.getOnly()).getParameters().asTypeList().asErasures()) {
/* 391 */         methodCall = withoutSpecifiedTarget.with(new Object[] { typeDescription.getDefaultValue() });
/*     */       } 
/* 393 */       return methodRegistry.append((LatentMatcher)new LatentMatcher.Resolved((ElementMatcher)ElementMatchers.isConstructor().and((ElementMatcher)ElementMatchers.takesArguments(0))), (MethodRegistry.Handler)new MethodRegistry.Handler.ForImplementation((Implementation)methodCall), this.methodAttributeAppenderFactory, 
/*     */ 
/*     */           
/* 396 */           Transformer.NoOp.make());
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.elementMatcher.equals(((ForDefaultConstructor)param1Object).elementMatcher) ? false : (!!this.methodAttributeAppenderFactory.equals(((ForDefaultConstructor)param1Object).methodAttributeAppenderFactory)))));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return (getClass().hashCode() * 31 + this.elementMatcher.hashCode()) * 31 + this.methodAttributeAppenderFactory.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\scaffold\subclass\ConstructorStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */