/*     */ package net.bytebuddy.dynamic.scaffold.inline;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.bytebuddy.ClassFileVersion;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.annotation.AnnotationList;
/*     */ import net.bytebuddy.description.annotation.AnnotationValue;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.ParameterDescription;
/*     */ import net.bytebuddy.description.method.ParameterList;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.description.type.TypeList;
/*     */ import net.bytebuddy.dynamic.DynamicType;
/*     */ import net.bytebuddy.implementation.MethodAccessorFactory;
/*     */ import net.bytebuddy.implementation.auxiliary.AuxiliaryType;
/*     */ import net.bytebuddy.implementation.auxiliary.TrivialType;
/*     */ import net.bytebuddy.utility.CompoundList;
/*     */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface MethodRebaseResolver
/*     */ {
/*     */   Resolution resolve(MethodDescription.InDefinedShape paramInDefinedShape);
/*     */   
/*     */   List<DynamicType> getAuxiliaryTypes();
/*     */   
/*     */   Map<MethodDescription.SignatureToken, Resolution> asTokenMap();
/*     */   
/*     */   public enum Disabled
/*     */     implements MethodRebaseResolver
/*     */   {
/*  78 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodRebaseResolver.Resolution resolve(MethodDescription.InDefinedShape methodDescription) {
/*  84 */       return new MethodRebaseResolver.Resolution.Preserved(methodDescription);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<DynamicType> getAuxiliaryTypes() {
/*  91 */       return Collections.emptyList();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<MethodDescription.SignatureToken, MethodRebaseResolver.Resolution> asTokenMap() {
/*  98 */       return Collections.emptyMap();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Resolution
/*     */   {
/*     */     boolean isRebased();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MethodDescription.InDefinedShape getResolvedMethod();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TypeList getAppendedParameters();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     public static class Preserved
/*     */       implements Resolution
/*     */     {
/*     */       private final MethodDescription.InDefinedShape methodDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Preserved(MethodDescription.InDefinedShape methodDescription) {
/* 147 */         this.methodDescription = methodDescription;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean isRebased() {
/* 154 */         return false;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public MethodDescription.InDefinedShape getResolvedMethod() {
/* 161 */         return this.methodDescription;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TypeList getAppendedParameters() {
/* 168 */         throw new IllegalStateException("Cannot process additional parameters for non-rebased method: " + this.methodDescription);
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.methodDescription.equals(((Preserved)param2Object).methodDescription))));
/*     */       }
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return getClass().hashCode() * 31 + this.methodDescription.hashCode();
/*     */       }
/*     */     }
/*     */     
/*     */     @Enhance
/*     */     public static class ForRebasedMethod
/*     */       implements Resolution
/*     */     {
/*     */       private final MethodDescription.InDefinedShape methodDescription;
/*     */       
/*     */       protected ForRebasedMethod(MethodDescription.InDefinedShape methodDescription) {
/* 189 */         this.methodDescription = methodDescription;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public static MethodRebaseResolver.Resolution of(TypeDescription instrumentedType, MethodDescription.InDefinedShape methodDescription, MethodNameTransformer methodNameTransformer) {
/* 203 */         return new ForRebasedMethod((MethodDescription.InDefinedShape)new RebasedMethod(instrumentedType, methodDescription, methodNameTransformer));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean isRebased() {
/* 210 */         return true;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public MethodDescription.InDefinedShape getResolvedMethod() {
/* 217 */         return this.methodDescription;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TypeList getAppendedParameters() {
/* 224 */         return (TypeList)new TypeList.Empty();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.methodDescription.equals(((ForRebasedMethod)param2Object).methodDescription))));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return getClass().hashCode() * 31 + this.methodDescription.hashCode();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       protected static class RebasedMethod
/*     */         extends MethodDescription.InDefinedShape.AbstractBase
/*     */       {
/*     */         private final TypeDescription instrumentedType;
/*     */ 
/*     */         
/*     */         private final MethodDescription.InDefinedShape methodDescription;
/*     */ 
/*     */         
/*     */         private final MethodNameTransformer methodNameTransformer;
/*     */ 
/*     */ 
/*     */         
/*     */         protected RebasedMethod(TypeDescription instrumentedType, MethodDescription.InDefinedShape methodDescription, MethodNameTransformer methodNameTransformer) {
/* 255 */           this.instrumentedType = instrumentedType;
/* 256 */           this.methodDescription = methodDescription;
/* 257 */           this.methodNameTransformer = methodNameTransformer;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public TypeDescription.Generic getReturnType() {
/* 264 */           return this.methodDescription.getReturnType().asRawType();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public ParameterList<ParameterDescription.InDefinedShape> getParameters() {
/* 271 */           return (ParameterList<ParameterDescription.InDefinedShape>)new ParameterList.Explicit.ForTypes((MethodDescription.InDefinedShape)this, (List)this.methodDescription.getParameters().asTypeList().asRawTypes());
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public TypeList.Generic getExceptionTypes() {
/* 278 */           return this.methodDescription.getExceptionTypes().asRawTypes();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         @AlwaysNull
/*     */         public AnnotationValue<?, ?> getDefaultValue() {
/* 286 */           return AnnotationValue.UNDEFINED;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public TypeList.Generic getTypeVariables() {
/* 293 */           return (TypeList.Generic)new TypeList.Generic.Empty();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public AnnotationList getDeclaredAnnotations() {
/* 300 */           return (AnnotationList)new AnnotationList.Empty();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         @Nonnull
/*     */         public TypeDescription getDeclaringType() {
/* 308 */           return this.methodDescription.getDeclaringType();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public int getModifiers() {
/* 315 */           return 0x1000 | (
/* 316 */             this.methodDescription.isStatic() ? 8 : 0) | (
/* 317 */             this.methodDescription.isNative() ? 272 : 0) | ((this.instrumentedType
/* 318 */             .isInterface() && !this.methodDescription.isNative()) ? 1 : 2);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public String getInternalName() {
/* 325 */           return this.methodNameTransformer.transform((MethodDescription)this.methodDescription);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     public static class ForRebasedConstructor
/*     */       implements Resolution
/*     */     {
/*     */       private final MethodDescription.InDefinedShape methodDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final TypeDescription placeholderType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected ForRebasedConstructor(MethodDescription.InDefinedShape methodDescription, TypeDescription placeholderType) {
/* 353 */         this.methodDescription = methodDescription;
/* 354 */         this.placeholderType = placeholderType;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public static MethodRebaseResolver.Resolution of(MethodDescription.InDefinedShape methodDescription, TypeDescription placeholderType) {
/* 365 */         return new ForRebasedConstructor((MethodDescription.InDefinedShape)new RebasedConstructor(methodDescription, placeholderType), placeholderType);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean isRebased() {
/* 372 */         return true;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public MethodDescription.InDefinedShape getResolvedMethod() {
/* 379 */         return this.methodDescription;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TypeList getAppendedParameters() {
/* 386 */         return (TypeList)new TypeList.Explicit(new TypeDescription[] { this.placeholderType });
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.methodDescription.equals(((ForRebasedConstructor)param2Object).methodDescription) ? false : (!!this.placeholderType.equals(((ForRebasedConstructor)param2Object).placeholderType)))));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return (getClass().hashCode() * 31 + this.methodDescription.hashCode()) * 31 + this.placeholderType.hashCode();
/*     */       }
/*     */ 
/*     */       
/*     */       protected static class RebasedConstructor
/*     */         extends MethodDescription.InDefinedShape.AbstractBase
/*     */       {
/*     */         private final MethodDescription.InDefinedShape methodDescription;
/*     */         
/*     */         private final TypeDescription placeholderType;
/*     */ 
/*     */         
/*     */         protected RebasedConstructor(MethodDescription.InDefinedShape methodDescription, TypeDescription placeholderType) {
/* 411 */           this.methodDescription = methodDescription;
/* 412 */           this.placeholderType = placeholderType;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public TypeDescription.Generic getReturnType() {
/* 419 */           return TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(void.class);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public ParameterList<ParameterDescription.InDefinedShape> getParameters() {
/* 426 */           return (ParameterList<ParameterDescription.InDefinedShape>)new ParameterList.Explicit.ForTypes((MethodDescription.InDefinedShape)this, CompoundList.of((List)this.methodDescription.getParameters().asTypeList().asErasures(), this.placeholderType));
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public TypeList.Generic getExceptionTypes() {
/* 433 */           return this.methodDescription.getExceptionTypes().asRawTypes();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         @AlwaysNull
/*     */         public AnnotationValue<?, ?> getDefaultValue() {
/* 441 */           return AnnotationValue.UNDEFINED;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public TypeList.Generic getTypeVariables() {
/* 448 */           return (TypeList.Generic)new TypeList.Generic.Empty();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public AnnotationList getDeclaredAnnotations() {
/* 455 */           return (AnnotationList)new AnnotationList.Empty();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         @Nonnull
/*     */         public TypeDescription getDeclaringType() {
/* 463 */           return this.methodDescription.getDeclaringType();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public int getModifiers() {
/* 470 */           return 4098;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public String getInternalName() {
/* 477 */           return "<init>";
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Default
/*     */     implements MethodRebaseResolver
/*     */   {
/*     */     private final Map<MethodDescription.InDefinedShape, MethodRebaseResolver.Resolution> resolutions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<DynamicType> dynamicTypes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Default(Map<MethodDescription.InDefinedShape, MethodRebaseResolver.Resolution> resolutions, List<DynamicType> dynamicTypes) {
/* 506 */       this.resolutions = resolutions;
/* 507 */       this.dynamicTypes = dynamicTypes;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static MethodRebaseResolver make(TypeDescription instrumentedType, Set<? extends MethodDescription.SignatureToken> rebaseables, ClassFileVersion classFileVersion, AuxiliaryType.NamingStrategy auxiliaryTypeNamingStrategy, MethodNameTransformer methodNameTransformer) {
/* 525 */       DynamicType placeholderType = null;
/* 526 */       Map<MethodDescription.InDefinedShape, MethodRebaseResolver.Resolution> resolutions = new HashMap<MethodDescription.InDefinedShape, MethodRebaseResolver.Resolution>();
/* 527 */       for (MethodDescription.InDefinedShape instrumentedMethod : instrumentedType.getDeclaredMethods()) {
/* 528 */         if (rebaseables.contains(instrumentedMethod.asSignatureToken())) {
/*     */           MethodRebaseResolver.Resolution resolution;
/* 530 */           if (instrumentedMethod.isConstructor()) {
/* 531 */             if (placeholderType == null) {
/* 532 */               placeholderType = TrivialType.SIGNATURE_RELEVANT.make(auxiliaryTypeNamingStrategy.name(instrumentedType, (AuxiliaryType)TrivialType.SIGNATURE_RELEVANT), classFileVersion, (MethodAccessorFactory)MethodAccessorFactory.Illegal.INSTANCE);
/*     */             }
/*     */ 
/*     */             
/* 536 */             resolution = MethodRebaseResolver.Resolution.ForRebasedConstructor.of(instrumentedMethod, placeholderType.getTypeDescription());
/*     */           } else {
/* 538 */             resolution = MethodRebaseResolver.Resolution.ForRebasedMethod.of(instrumentedType, instrumentedMethod, methodNameTransformer);
/*     */           } 
/* 540 */           resolutions.put(instrumentedMethod, resolution);
/*     */         } 
/*     */       } 
/* 543 */       return (placeholderType == null) ? new Default(resolutions, 
/* 544 */           Collections.emptyList()) : new Default(resolutions, 
/* 545 */           Collections.singletonList(placeholderType));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodRebaseResolver.Resolution resolve(MethodDescription.InDefinedShape methodDescription) {
/* 552 */       MethodRebaseResolver.Resolution resolution = this.resolutions.get(methodDescription);
/* 553 */       return (resolution == null) ? new MethodRebaseResolver.Resolution.Preserved(methodDescription) : resolution;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public List<DynamicType> getAuxiliaryTypes() {
/* 562 */       return this.dynamicTypes;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<MethodDescription.SignatureToken, MethodRebaseResolver.Resolution> asTokenMap() {
/* 569 */       Map<MethodDescription.SignatureToken, MethodRebaseResolver.Resolution> tokenMap = new HashMap<MethodDescription.SignatureToken, MethodRebaseResolver.Resolution>();
/* 570 */       for (Map.Entry<MethodDescription.InDefinedShape, MethodRebaseResolver.Resolution> entry : this.resolutions.entrySet()) {
/* 571 */         tokenMap.put(((MethodDescription.InDefinedShape)entry.getKey()).asSignatureToken(), entry.getValue());
/*     */       }
/* 573 */       return tokenMap;
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.resolutions.equals(((Default)param1Object).resolutions) ? false : (!!this.dynamicTypes.equals(((Default)param1Object).dynamicTypes)))));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return (getClass().hashCode() * 31 + this.resolutions.hashCode()) * 31 + this.dynamicTypes.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\scaffold\inline\MethodRebaseResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */