/*     */ package net.bytebuddy.dynamic.scaffold.inline;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.ClassFileVersion;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.description.type.TypeList;
/*     */ import net.bytebuddy.dynamic.scaffold.MethodGraph;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*     */ import net.bytebuddy.implementation.bytecode.constant.DefaultValue;
/*     */ import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.utility.CompoundList;
/*     */ import net.bytebuddy.utility.JavaConstant;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class RebaseImplementationTarget
/*     */   extends Implementation.Target.AbstractBase
/*     */ {
/*     */   private final Map<MethodDescription.SignatureToken, MethodRebaseResolver.Resolution> rebaseableMethods;
/*     */   
/*     */   protected RebaseImplementationTarget(TypeDescription instrumentedType, MethodGraph.Linked methodGraph, Implementation.Target.AbstractBase.DefaultMethodInvocation defaultMethodInvocation, Map<MethodDescription.SignatureToken, MethodRebaseResolver.Resolution> rebaseableMethods) {
/*  66 */     super(instrumentedType, methodGraph, defaultMethodInvocation);
/*  67 */     this.rebaseableMethods = rebaseableMethods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Implementation.Target of(TypeDescription instrumentedType, MethodGraph.Linked methodGraph, ClassFileVersion classFileVersion, MethodRebaseResolver methodRebaseResolver) {
/*  83 */     return (Implementation.Target)new RebaseImplementationTarget(instrumentedType, methodGraph, Implementation.Target.AbstractBase.DefaultMethodInvocation.of(classFileVersion), methodRebaseResolver.asTokenMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Implementation.SpecialMethodInvocation invokeSuper(MethodDescription.SignatureToken token) {
/*  90 */     MethodRebaseResolver.Resolution resolution = this.rebaseableMethods.get(token);
/*  91 */     return (resolution == null) ? 
/*  92 */       invokeSuper(this.methodGraph.getSuperClassGraph().locate(token)) : 
/*  93 */       invokeSuper(resolution);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Implementation.SpecialMethodInvocation invokeSuper(MethodGraph.Node node) {
/* 103 */     TypeDescription.Generic superClass = this.instrumentedType.getSuperClass();
/* 104 */     return (node.getSort().isResolved() && superClass != null) ? 
/* 105 */       Implementation.SpecialMethodInvocation.Simple.of(node.getRepresentative(), superClass.asErasure()) : (Implementation.SpecialMethodInvocation)Implementation.SpecialMethodInvocation.Illegal.INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Implementation.SpecialMethodInvocation invokeSuper(MethodRebaseResolver.Resolution resolution) {
/* 116 */     return resolution.isRebased() ? 
/* 117 */       RebasedMethodInvocation.of(resolution.getResolvedMethod(), this.instrumentedType, resolution.getAppendedParameters()) : 
/* 118 */       Implementation.SpecialMethodInvocation.Simple.of((MethodDescription)resolution.getResolvedMethod(), this.instrumentedType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDescription getOriginType() {
/* 125 */     return this.instrumentedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return !super.equals(paramObject) ? false : ((this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.rebaseableMethods.equals(((RebaseImplementationTarget)paramObject).rebaseableMethods)))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*     */     return super.hashCode() * 31 + this.rebaseableMethods.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class RebasedMethodInvocation
/*     */     extends Implementation.SpecialMethodInvocation.AbstractBase
/*     */   {
/*     */     private final MethodDescription.InDefinedShape methodDescription;
/*     */ 
/*     */ 
/*     */     
/*     */     private final TypeDescription instrumentedType;
/*     */ 
/*     */ 
/*     */     
/*     */     private final StackManipulation stackManipulation;
/*     */ 
/*     */ 
/*     */     
/*     */     private final TypeList prependedParameters;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected RebasedMethodInvocation(MethodDescription.InDefinedShape methodDescription, TypeDescription instrumentedType, StackManipulation stackManipulation, TypeList prependedParameters) {
/* 166 */       this.methodDescription = methodDescription;
/* 167 */       this.instrumentedType = instrumentedType;
/* 168 */       this.stackManipulation = stackManipulation;
/* 169 */       this.prependedParameters = prependedParameters;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static Implementation.SpecialMethodInvocation of(MethodDescription.InDefinedShape resolvedMethod, TypeDescription instrumentedType, TypeList prependedParameters) {
/* 183 */       StackManipulation stackManipulation = resolvedMethod.isStatic() ? (StackManipulation)MethodInvocation.invoke(resolvedMethod) : MethodInvocation.invoke(resolvedMethod).special(instrumentedType);
/* 184 */       if (stackManipulation.isValid()) {
/* 185 */         List<StackManipulation> stackManipulations = new ArrayList<StackManipulation>(prependedParameters.size() + 1);
/* 186 */         for (TypeDescription prependedParameter : prependedParameters) {
/* 187 */           stackManipulations.add(DefaultValue.of((TypeDefinition)prependedParameter));
/*     */         }
/* 189 */         stackManipulations.add(stackManipulation);
/* 190 */         return (Implementation.SpecialMethodInvocation)new RebasedMethodInvocation(resolvedMethod, instrumentedType, (StackManipulation)new StackManipulation.Compound(stackManipulations), prependedParameters);
/*     */       } 
/* 192 */       return (Implementation.SpecialMethodInvocation)Implementation.SpecialMethodInvocation.Illegal.INSTANCE;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodDescription getMethodDescription() {
/* 200 */       return (MethodDescription)this.methodDescription;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeDescription getTypeDescription() {
/* 207 */       return this.instrumentedType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 214 */       return this.stackManipulation.apply(methodVisitor, implementationContext);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Implementation.SpecialMethodInvocation withCheckedCompatibilityTo(MethodDescription.TypeToken token) {
/* 221 */       if (this.methodDescription.asTypeToken().equals(new MethodDescription.TypeToken(token.getReturnType(), 
/* 222 */             CompoundList.of(token.getParameterTypes(), (List)this.prependedParameters)))) {
/* 223 */         return (Implementation.SpecialMethodInvocation)this;
/*     */       }
/* 225 */       return (Implementation.SpecialMethodInvocation)Implementation.SpecialMethodInvocation.Illegal.INSTANCE;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public JavaConstant.MethodHandle toMethodHandle() {
/* 231 */       return this.methodDescription.isStatic() ? 
/* 232 */         JavaConstant.MethodHandle.of(this.methodDescription) : 
/* 233 */         JavaConstant.MethodHandle.ofSpecial(this.methodDescription, this.instrumentedType);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Factory
/*     */     implements Implementation.Target.Factory
/*     */   {
/*     */     private final MethodRebaseResolver methodRebaseResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Factory(MethodRebaseResolver methodRebaseResolver) {
/* 254 */       this.methodRebaseResolver = methodRebaseResolver;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Implementation.Target make(TypeDescription instrumentedType, MethodGraph.Linked methodGraph, ClassFileVersion classFileVersion) {
/* 261 */       return RebaseImplementationTarget.of(instrumentedType, methodGraph, classFileVersion, this.methodRebaseResolver);
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.methodRebaseResolver.equals(((Factory)param1Object).methodRebaseResolver))));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.methodRebaseResolver.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\scaffold\inline\RebaseImplementationTarget.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */