/*    */ package net.bytebuddy.dynamic.scaffold.inline;
/*    */ 
/*    */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*    */ import net.bytebuddy.description.method.MethodDescription;
/*    */ import net.bytebuddy.description.type.TypeDescription;
/*    */ import net.bytebuddy.matcher.ElementMatcher;
/*    */ import net.bytebuddy.matcher.ElementMatchers;
/*    */ import net.bytebuddy.matcher.LatentMatcher;
/*    */ import net.bytebuddy.utility.nullability.MaybeNull;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Enhance
/*    */ public class InliningImplementationMatcher
/*    */   implements LatentMatcher<MethodDescription>
/*    */ {
/*    */   private final LatentMatcher<? super MethodDescription> ignoredMethods;
/*    */   private final ElementMatcher<? super MethodDescription> predefinedMethodSignatures;
/*    */   
/*    */   protected InliningImplementationMatcher(LatentMatcher<? super MethodDescription> ignoredMethods, ElementMatcher<? super MethodDescription> predefinedMethodSignatures) {
/* 51 */     this.ignoredMethods = ignoredMethods;
/* 52 */     this.predefinedMethodSignatures = predefinedMethodSignatures;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected static LatentMatcher<MethodDescription> of(LatentMatcher<? super MethodDescription> ignoredMethods, TypeDescription originalType) {
/* 65 */     ElementMatcher.Junction<MethodDescription> predefinedMethodSignatures = ElementMatchers.none();
/* 66 */     for (MethodDescription methodDescription : originalType.getDeclaredMethods()) {
/*    */ 
/*    */       
/* 69 */       ElementMatcher.Junction<MethodDescription> signature = methodDescription.isConstructor() ? ElementMatchers.isConstructor() : ElementMatchers.named(methodDescription.getName());
/* 70 */       signature = signature.and((ElementMatcher)ElementMatchers.returns(methodDescription.getReturnType().asErasure()));
/* 71 */       signature = signature.and((ElementMatcher)ElementMatchers.takesArguments((Iterable)methodDescription.getParameters().asTypeList().asErasures()));
/* 72 */       predefinedMethodSignatures = predefinedMethodSignatures.or((ElementMatcher)signature);
/*    */     } 
/* 74 */     return new InliningImplementationMatcher(ignoredMethods, (ElementMatcher<? super MethodDescription>)predefinedMethodSignatures);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ElementMatcher<? super MethodDescription> resolve(TypeDescription typeDescription) {
/* 81 */     return (ElementMatcher<? super MethodDescription>)ElementMatchers.not(this.ignoredMethods.resolve(typeDescription))
/* 82 */       .and((ElementMatcher)ElementMatchers.isVirtual().and((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.isFinal())).or((ElementMatcher)ElementMatchers.isDeclaredBy(typeDescription)))
/* 83 */       .or((ElementMatcher)ElementMatchers.isDeclaredBy(typeDescription).and((ElementMatcher)ElementMatchers.not(this.predefinedMethodSignatures)));
/*    */   }
/*    */   
/*    */   public boolean equals(@MaybeNull Object paramObject) {
/*    */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.ignoredMethods.equals(((InliningImplementationMatcher)paramObject).ignoredMethods) ? false : (!!this.predefinedMethodSignatures.equals(((InliningImplementationMatcher)paramObject).predefinedMethodSignatures)))));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/*    */     return (getClass().hashCode() * 31 + this.ignoredMethods.hashCode()) * 31 + this.predefinedMethodSignatures.hashCode();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\scaffold\inline\InliningImplementationMatcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */