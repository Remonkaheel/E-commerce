/*      */ package net.bytebuddy.dynamic.scaffold;
/*      */ 
/*      */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*      */ import net.bytebuddy.description.method.MethodDescription;
/*      */ import net.bytebuddy.description.method.MethodList;
/*      */ import net.bytebuddy.description.modifier.Visibility;
/*      */ import net.bytebuddy.description.type.TypeDefinition;
/*      */ import net.bytebuddy.description.type.TypeDescription;
/*      */ import net.bytebuddy.description.type.TypeList;
/*      */ import net.bytebuddy.matcher.ElementMatcher;
/*      */ import net.bytebuddy.matcher.ElementMatchers;
/*      */ import net.bytebuddy.matcher.FilterableList;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface MethodGraph
/*      */ {
/*      */   Node locate(MethodDescription.SignatureToken paramSignatureToken);
/*      */   
/*      */   NodeList listNodes();
/*      */   
/*      */   public enum Empty
/*      */     implements Linked, Compiler
/*      */   {
/*   63 */     INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodGraph.Node locate(MethodDescription.SignatureToken token) {
/*   69 */       return MethodGraph.Node.Unresolved.INSTANCE;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodGraph.NodeList listNodes() {
/*   76 */       return new MethodGraph.NodeList(Collections.emptyList());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodGraph getSuperClassGraph() {
/*   83 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodGraph getInterfaceGraph(TypeDescription typeDescription) {
/*   90 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodGraph.Linked compile(TypeDefinition typeDefinition) {
/*   97 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public MethodGraph.Linked compile(TypeDescription typeDescription) {
/*  105 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodGraph.Linked compile(TypeDefinition typeDefinition, TypeDescription viewPoint) {
/*  112 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public MethodGraph.Linked compile(TypeDescription typeDefinition, TypeDescription viewPoint) {
/*  120 */       return this;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface Linked
/*      */     extends MethodGraph
/*      */   {
/*      */     MethodGraph getSuperClassGraph();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MethodGraph getInterfaceGraph(TypeDescription param1TypeDescription);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class Delegation
/*      */       implements Linked
/*      */     {
/*      */       private final MethodGraph methodGraph;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final MethodGraph superClassGraph;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final Map<TypeDescription, MethodGraph> interfaceGraphs;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Delegation(MethodGraph methodGraph, MethodGraph superClassGraph, Map<TypeDescription, MethodGraph> interfaceGraphs) {
/*  174 */         this.methodGraph = methodGraph;
/*  175 */         this.superClassGraph = superClassGraph;
/*  176 */         this.interfaceGraphs = interfaceGraphs;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodGraph getSuperClassGraph() {
/*  183 */         return this.superClassGraph;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodGraph getInterfaceGraph(TypeDescription typeDescription) {
/*  190 */         MethodGraph interfaceGraph = this.interfaceGraphs.get(typeDescription);
/*  191 */         return (interfaceGraph == null) ? MethodGraph.Empty.INSTANCE : interfaceGraph;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodGraph.Node locate(MethodDescription.SignatureToken token) {
/*  200 */         return this.methodGraph.locate(token);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodGraph.NodeList listNodes() {
/*  207 */         return this.methodGraph.listNodes();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.methodGraph.equals(((Delegation)param2Object).methodGraph) ? false : (!this.superClassGraph.equals(((Delegation)param2Object).superClassGraph) ? false : (!!this.interfaceGraphs.equals(((Delegation)param2Object).interfaceGraphs))))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return ((getClass().hashCode() * 31 + this.methodGraph.hashCode()) * 31 + this.superClassGraph.hashCode()) * 31 + this.interfaceGraphs.hashCode();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface Node
/*      */   {
/*      */     Sort getSort();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MethodDescription getRepresentative();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Set<MethodDescription.TypeToken> getMethodTypes();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Visibility getVisibility();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public enum Sort
/*      */     {
/*  254 */       VISIBLE(true, true, true),
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  259 */       RESOLVED(true, true, false),
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  264 */       AMBIGUOUS(true, false, false),
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  269 */       UNRESOLVED(false, false, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final boolean resolved;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final boolean unique;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final boolean madeVisible;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Sort(boolean resolved, boolean unique, boolean madeVisible) {
/*  294 */         this.resolved = resolved;
/*  295 */         this.unique = unique;
/*  296 */         this.madeVisible = madeVisible;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isResolved() {
/*  305 */         return this.resolved;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isUnique() {
/*  314 */         return this.unique;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isMadeVisible() {
/*  323 */         return this.madeVisible;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public enum Unresolved
/*      */       implements Node
/*      */     {
/*  335 */       INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodGraph.Node.Sort getSort() {
/*  341 */         return MethodGraph.Node.Sort.UNRESOLVED;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodDescription getRepresentative() {
/*  348 */         throw new IllegalStateException("Cannot resolve the method of an illegal node");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Set<MethodDescription.TypeToken> getMethodTypes() {
/*  355 */         throw new IllegalStateException("Cannot resolve bridge method of an illegal node");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Visibility getVisibility() {
/*  362 */         throw new IllegalStateException("Cannot resolve visibility of an illegal node");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class Simple
/*      */       implements Node
/*      */     {
/*      */       private final MethodDescription methodDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Simple(MethodDescription methodDescription) {
/*  383 */         this.methodDescription = methodDescription;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodGraph.Node.Sort getSort() {
/*  390 */         return MethodGraph.Node.Sort.RESOLVED;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodDescription getRepresentative() {
/*  397 */         return this.methodDescription;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Set<MethodDescription.TypeToken> getMethodTypes() {
/*  404 */         return Collections.emptySet();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Visibility getVisibility() {
/*  411 */         return this.methodDescription.getVisibility();
/*      */       }
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.methodDescription.equals(((Simple)param2Object).methodDescription))));
/*      */       }
/*      */       
/*      */       public int hashCode() {
/*      */         return getClass().hashCode() * 31 + this.methodDescription.hashCode();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   @SuppressFBWarnings(value = {"IC_SUPERCLASS_USES_SUBCLASS_DURING_INITIALIZATION"}, justification = "Safe initialization is implied.")
/*  425 */   public static interface Compiler { public static final Compiler DEFAULT = Default.forJavaHierarchy();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MethodGraph.Linked compile(TypeDefinition param1TypeDefinition);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     MethodGraph.Linked compile(TypeDescription param1TypeDescription);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MethodGraph.Linked compile(TypeDefinition param1TypeDefinition, TypeDescription param1TypeDescription);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     MethodGraph.Linked compile(TypeDescription param1TypeDescription1, TypeDescription param1TypeDescription2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public enum ForDeclaredMethods
/*      */       implements Compiler
/*      */     {
/*  473 */       INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodGraph.Linked compile(TypeDefinition typeDefinition) {
/*  479 */         return compile(typeDefinition, typeDefinition.asErasure());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Deprecated
/*      */       public MethodGraph.Linked compile(TypeDescription typeDescription) {
/*  487 */         return compile((TypeDefinition)typeDescription, typeDescription);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodGraph.Linked compile(TypeDefinition typeDefinition, TypeDescription viewPoint) {
/*  494 */         LinkedHashMap<MethodDescription.SignatureToken, MethodGraph.Node> nodes = new LinkedHashMap<MethodDescription.SignatureToken, MethodGraph.Node>();
/*  495 */         for (MethodDescription methodDescription : typeDefinition.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isVirtual().and((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.isBridge())).and((ElementMatcher)ElementMatchers.isVisibleTo(viewPoint)))) {
/*  496 */           nodes.put(methodDescription.asSignatureToken(), new MethodGraph.Node.Simple(methodDescription));
/*      */         }
/*  498 */         return new MethodGraph.Linked.Delegation(new MethodGraph.Simple(nodes), MethodGraph.Empty.INSTANCE, Collections.emptyMap());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Deprecated
/*      */       public MethodGraph.Linked compile(TypeDescription typeDefinition, TypeDescription viewPoint) {
/*  506 */         return compile((TypeDefinition)typeDefinition, viewPoint);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static abstract class AbstractBase
/*      */       implements Compiler
/*      */     {
/*      */       public MethodGraph.Linked compile(TypeDefinition typeDefinition) {
/*  519 */         return compile(typeDefinition, typeDefinition.asErasure());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Deprecated
/*      */       public MethodGraph.Linked compile(TypeDescription typeDescription) {
/*  527 */         return compile((TypeDefinition)typeDescription, typeDescription);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Deprecated
/*      */       public MethodGraph.Linked compile(TypeDescription typeDefinition, TypeDescription viewPoint) {
/*  535 */         return compile((TypeDefinition)typeDefinition, viewPoint);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class Default<T>
/*      */       extends AbstractBase
/*      */     {
/*      */       private final Harmonizer<T> harmonizer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final Merger merger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final ElementMatcher<? super MethodDescription> matcher;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected Default(Harmonizer<T> harmonizer, Merger merger, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/*  575 */         this(harmonizer, merger, visitor, (ElementMatcher<? super MethodDescription>)ElementMatchers.any());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Default(Harmonizer<T> harmonizer, Merger merger, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor, ElementMatcher<? super MethodDescription> matcher) {
/*  587 */         this.harmonizer = harmonizer;
/*  588 */         this.merger = merger;
/*  589 */         this.visitor = visitor;
/*  590 */         this.matcher = matcher;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static <S> MethodGraph.Compiler of(Harmonizer<S> harmonizer, Merger merger) {
/*  602 */         return new Default<S>(harmonizer, merger, (TypeDescription.Generic.Visitor<? extends TypeDescription.Generic>)TypeDescription.Generic.Visitor.Reifying.INITIATING);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static <S> MethodGraph.Compiler of(Harmonizer<S> harmonizer, Merger merger, ElementMatcher<? super MethodDescription> matcher) {
/*  615 */         return new Default<S>(harmonizer, merger, (TypeDescription.Generic.Visitor<? extends TypeDescription.Generic>)TypeDescription.Generic.Visitor.Reifying.INITIATING, matcher);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static <S> MethodGraph.Compiler of(Harmonizer<S> harmonizer, Merger merger, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/*  628 */         return new Default<S>(harmonizer, merger, visitor);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static MethodGraph.Compiler forJavaHierarchy() {
/*  644 */         return of(Harmonizer.ForJavaMethod.INSTANCE, Merger.Directional.LEFT);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static MethodGraph.Compiler forJVMHierarchy() {
/*  660 */         return of(Harmonizer.ForJVMMethod.INSTANCE, Merger.Directional.LEFT);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodGraph.Linked compile(TypeDefinition typeDefinition, TypeDescription viewPoint) {
/*      */         Key.Store<T> store;
/*  667 */         Map<TypeDefinition, Key.Store<T>> snapshots = new HashMap<TypeDefinition, Key.Store<T>>();
/*  668 */         Key.Store<?> rootStore = doAnalyze(typeDefinition, snapshots, (ElementMatcher<? super MethodDescription>)ElementMatchers.isVirtual().and((ElementMatcher)ElementMatchers.isVisibleTo(viewPoint)).and(this.matcher));
/*  669 */         TypeDescription.Generic superClass = typeDefinition.getSuperClass();
/*  670 */         TypeList.Generic generic = typeDefinition.getInterfaces();
/*  671 */         Map<TypeDescription, MethodGraph> interfaceGraphs = new HashMap<TypeDescription, MethodGraph>();
/*  672 */         for (TypeDescription.Generic interfaceType : generic) {
/*  673 */           Key.Store<T> store1 = snapshots.get(interfaceType);
/*  674 */           if (store1 == null) {
/*  675 */             throw new IllegalStateException("Failed to resolve interface type " + interfaceType + " from " + snapshots.keySet());
/*      */           }
/*  677 */           interfaceGraphs.put(interfaceType.asErasure(), store1.asGraph(this.merger));
/*      */         } 
/*      */         
/*  680 */         if (superClass == null) {
/*  681 */           store = null;
/*      */         } else {
/*  683 */           store = snapshots.get(superClass);
/*  684 */           if (store == null) {
/*  685 */             throw new IllegalStateException("Failed to resolve super class " + superClass + " from " + snapshots.keySet());
/*      */           }
/*      */         } 
/*  688 */         return new MethodGraph.Linked.Delegation(rootStore.asGraph(this.merger), (store == null) ? MethodGraph.Empty.INSTANCE : store
/*      */ 
/*      */             
/*  691 */             .asGraph(this.merger), interfaceGraphs);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected Key.Store<T> analyze(TypeDefinition typeDefinition, TypeDefinition key, Map<TypeDefinition, Key.Store<T>> snapshots, ElementMatcher<? super MethodDescription> relevanceMatcher) {
/*  708 */         Key.Store<T> store = snapshots.get(key);
/*  709 */         if (store == null) {
/*  710 */           store = doAnalyze(typeDefinition, snapshots, relevanceMatcher);
/*  711 */           snapshots.put(key, store);
/*      */         } 
/*  713 */         return store;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected Key.Store<T> analyzeNullable(@MaybeNull TypeDescription.Generic typeDescription, Map<TypeDefinition, Key.Store<T>> snapshots, ElementMatcher<? super MethodDescription> relevanceMatcher) {
/*  727 */         return (typeDescription == null) ? new Key.Store<T>() : 
/*      */           
/*  729 */           analyze((TypeDefinition)typeDescription.accept(this.visitor), (TypeDefinition)typeDescription, snapshots, relevanceMatcher);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected Key.Store<T> doAnalyze(TypeDefinition typeDefinition, Map<TypeDefinition, Key.Store<T>> snapshots, ElementMatcher<? super MethodDescription> relevanceMatcher) {
/*  743 */         Key.Store<T> store = analyzeNullable(typeDefinition.getSuperClass(), snapshots, relevanceMatcher);
/*  744 */         Key.Store<T> interfaceStore = new Key.Store<T>();
/*  745 */         for (TypeDescription.Generic interfaceType : typeDefinition.getInterfaces()) {
/*  746 */           interfaceStore = interfaceStore.combineWith(analyze((TypeDefinition)interfaceType.accept(this.visitor), (TypeDefinition)interfaceType, snapshots, relevanceMatcher));
/*      */         }
/*  748 */         return store.inject(interfaceStore).registerTopLevel((List<? extends MethodDescription>)typeDefinition.getDeclaredMethods().filter(relevanceMatcher), this.harmonizer);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.harmonizer.equals(((Default)param2Object).harmonizer) ? false : (!this.merger.equals(((Default)param2Object).merger) ? false : (!this.visitor.equals(((Default)param2Object).visitor) ? false : (!!this.matcher.equals(((Default)param2Object).matcher)))))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return (((getClass().hashCode() * 31 + this.harmonizer.hashCode()) * 31 + this.merger.hashCode()) * 31 + this.visitor.hashCode()) * 31 + this.matcher.hashCode();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public enum ForJavaMethod
/*      */         implements Harmonizer<Harmonizer.ForJavaMethod.Token>
/*      */       {
/*  775 */         INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Token harmonize(MethodDescription.TypeToken typeToken) {
/*  781 */           return new Token(typeToken);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected static class Token
/*      */         {
/*      */           private final MethodDescription.TypeToken typeToken;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final int hashCode;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected Token(MethodDescription.TypeToken typeToken) {
/*  805 */             this.typeToken = typeToken;
/*  806 */             this.hashCode = typeToken.getParameterTypes().hashCode();
/*      */           }
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*  811 */             return this.hashCode;
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object other) {
/*  816 */             return (this == other || (other instanceof Token && this.typeToken.getParameterTypes().equals(((Token)other).typeToken.getParameterTypes())));
/*      */           }
/*      */           
/*      */           public String toString()
/*      */           {
/*  821 */             return this.typeToken.getParameterTypes().toString(); } } } public static interface Harmonizer<S> { S harmonize(MethodDescription.TypeToken param3TypeToken); public enum ForJavaMethod implements Harmonizer<ForJavaMethod.Token> { INSTANCE; public Token harmonize(MethodDescription.TypeToken typeToken) { return new Token(typeToken); } protected static class Token { private final MethodDescription.TypeToken typeToken; private final int hashCode; protected Token(MethodDescription.TypeToken typeToken) { this.typeToken = typeToken; this.hashCode = typeToken.getParameterTypes().hashCode(); } public int hashCode() { return this.hashCode; } public boolean equals(@MaybeNull Object other) { return (this == other || (other instanceof Token && this.typeToken.getParameterTypes().equals(((Token)other).typeToken.getParameterTypes()))); } public String toString() { return this.typeToken.getParameterTypes().toString(); }
/*      */              }
/*      */            }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public enum ForJVMMethod
/*      */           implements Harmonizer<ForJVMMethod.Token>
/*      */         {
/*  834 */           INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Token harmonize(MethodDescription.TypeToken typeToken) {
/*  840 */             return new Token(typeToken);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected static class Token
/*      */           {
/*      */             private final MethodDescription.TypeToken typeToken;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final int hashCode;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public Token(MethodDescription.TypeToken typeToken) {
/*  864 */               this.typeToken = typeToken;
/*  865 */               this.hashCode = typeToken.getReturnType().hashCode() + 31 * typeToken.getParameterTypes().hashCode();
/*      */             }
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*  870 */               return this.hashCode;
/*      */             }
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object other) {
/*  875 */               if (this == other)
/*  876 */                 return true; 
/*  877 */               if (!(other instanceof Token)) {
/*  878 */                 return false;
/*      */               }
/*  880 */               Token token = (Token)other;
/*  881 */               return (this.typeToken.getReturnType().equals(token.typeToken.getReturnType()) && this.typeToken
/*  882 */                 .getParameterTypes().equals(token.typeToken.getParameterTypes()));
/*      */             }
/*      */             
/*      */             public String toString()
/*      */             {
/*  887 */               return this.typeToken.toString(); } } } } public enum ForJVMMethod implements Harmonizer<Harmonizer.ForJVMMethod.Token> { INSTANCE; public Token harmonize(MethodDescription.TypeToken typeToken) { return new Token(typeToken); } protected static class Token { private final MethodDescription.TypeToken typeToken; private final int hashCode; public Token(MethodDescription.TypeToken typeToken) { this.typeToken = typeToken; this.hashCode = typeToken.getReturnType().hashCode() + 31 * typeToken.getParameterTypes().hashCode(); } public int hashCode() { return this.hashCode; } public boolean equals(@MaybeNull Object other) { if (this == other) return true;  if (!(other instanceof Token)) return false;  Token token = (Token)other; return (this.typeToken.getReturnType().equals(token.typeToken.getReturnType()) && this.typeToken.getParameterTypes().equals(token.typeToken.getParameterTypes())); } public String toString() { return this.typeToken.toString(); }
/*      */            }
/*      */          }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static interface Merger
/*      */       {
/*      */         MethodDescription merge(MethodDescription param3MethodDescription1, MethodDescription param3MethodDescription2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public enum Directional
/*      */           implements Merger
/*      */         {
/*  916 */           LEFT(true),
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  921 */           RIGHT(false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final boolean left;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           Directional(boolean left) {
/*  934 */             this.left = left;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public MethodDescription merge(MethodDescription left, MethodDescription right)
/*      */           {
/*  941 */             return this.left ? left : right; } } } public enum Directional implements Merger { LEFT(true), RIGHT(false); private final boolean left; Directional(boolean left) { this.left = left; } public MethodDescription merge(MethodDescription left, MethodDescription right) { return this.left ? left : right; }
/*      */          }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected static abstract class Key<S>
/*      */       {
/*      */         protected final String internalName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final int parameterCount;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected Key(String internalName, int parameterCount) {
/*  973 */           this.internalName = internalName;
/*  974 */           this.parameterCount = parameterCount;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected abstract Set<S> getIdentifiers();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*  986 */           return this.internalName.hashCode() + 31 * this.parameterCount;
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object other) {
/*  991 */           if (this == other)
/*  992 */             return true; 
/*  993 */           if (!(other instanceof Key)) {
/*  994 */             return false;
/*      */           }
/*  996 */           Key<?> key = (Key)other;
/*  997 */           return (this.internalName.equals(key.internalName) && this.parameterCount == key.parameterCount && 
/*      */             
/*  999 */             !Collections.disjoint(getIdentifiers(), key.getIdentifiers()));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected static class Harmonized<V>
/*      */           extends Key<V>
/*      */         {
/*      */           private final Map<V, Set<MethodDescription.TypeToken>> identifiers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected Harmonized(String internalName, int parameterCount, Map<V, Set<MethodDescription.TypeToken>> identifiers) {
/* 1023 */             super(internalName, parameterCount);
/* 1024 */             this.identifiers = identifiers;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected static <Q> Harmonized<Q> of(MethodDescription methodDescription, MethodGraph.Compiler.Default.Harmonizer<Q> harmonizer) {
/* 1036 */             MethodDescription.TypeToken typeToken = methodDescription.asTypeToken();
/* 1037 */             return new Harmonized<Q>(methodDescription.getInternalName(), methodDescription
/* 1038 */                 .getParameters().size(), 
/* 1039 */                 Collections.singletonMap(harmonizer.harmonize(typeToken), Collections.emptySet()));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected MethodGraph.Compiler.Default.Key.Detached detach(MethodDescription.TypeToken typeToken) {
/* 1049 */             Set<MethodDescription.TypeToken> identifiers = new HashSet<MethodDescription.TypeToken>();
/* 1050 */             for (Set<MethodDescription.TypeToken> typeTokens : this.identifiers.values()) {
/* 1051 */               identifiers.addAll(typeTokens);
/*      */             }
/* 1053 */             identifiers.add(typeToken);
/* 1054 */             return new MethodGraph.Compiler.Default.Key.Detached(this.internalName, this.parameterCount, identifiers);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected Harmonized<V> combineWith(Harmonized<V> key) {
/* 1064 */             Map<V, Set<MethodDescription.TypeToken>> identifiers = new HashMap<V, Set<MethodDescription.TypeToken>>(this.identifiers);
/* 1065 */             for (Map.Entry<V, Set<MethodDescription.TypeToken>> entry : key.identifiers.entrySet()) {
/* 1066 */               Set<MethodDescription.TypeToken> typeTokens = identifiers.get(entry.getKey());
/* 1067 */               if (typeTokens == null) {
/* 1068 */                 identifiers.put(entry.getKey(), entry.getValue()); continue;
/*      */               } 
/* 1070 */               typeTokens = new HashSet<MethodDescription.TypeToken>(typeTokens);
/* 1071 */               typeTokens.addAll(entry.getValue());
/* 1072 */               identifiers.put(entry.getKey(), typeTokens);
/*      */             } 
/*      */             
/* 1075 */             return new Harmonized(this.internalName, this.parameterCount, identifiers);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected Harmonized<V> extend(MethodDescription.InDefinedShape methodDescription, MethodGraph.Compiler.Default.Harmonizer<V> harmonizer) {
/* 1086 */             Map<V, Set<MethodDescription.TypeToken>> identifiers = new HashMap<V, Set<MethodDescription.TypeToken>>(this.identifiers);
/* 1087 */             MethodDescription.TypeToken typeToken = methodDescription.asTypeToken();
/* 1088 */             V identifier = harmonizer.harmonize(typeToken);
/* 1089 */             Set<MethodDescription.TypeToken> typeTokens = identifiers.get(identifier);
/* 1090 */             if (typeTokens == null) {
/* 1091 */               identifiers.put(identifier, Collections.singleton(typeToken));
/*      */             } else {
/* 1093 */               typeTokens = new HashSet<MethodDescription.TypeToken>(typeTokens);
/* 1094 */               typeTokens.add(typeToken);
/* 1095 */               identifiers.put(identifier, typeTokens);
/*      */             } 
/* 1097 */             return new Harmonized(this.internalName, this.parameterCount, identifiers);
/*      */           }
/*      */ 
/*      */           
/*      */           protected Set<V> getIdentifiers() {
/* 1102 */             return this.identifiers.keySet();
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected static class Detached
/*      */           extends Key<MethodDescription.TypeToken>
/*      */         {
/*      */           private final Set<MethodDescription.TypeToken> identifiers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected Detached(String internalName, int parameterCount, Set<MethodDescription.TypeToken> identifiers) {
/* 1124 */             super(internalName, parameterCount);
/* 1125 */             this.identifiers = identifiers;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected static Detached of(MethodDescription.SignatureToken token) {
/* 1135 */             return new Detached(token.getName(), token.getParameterTypes().size(), Collections.singleton(token.asTypeToken()));
/*      */           }
/*      */ 
/*      */           
/*      */           protected Set<MethodDescription.TypeToken> getIdentifiers() {
/* 1140 */             return this.identifiers;
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         protected static class Store<V>
/*      */         {
/*      */           private final LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>> entries;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected Store() {
/* 1161 */             this(new LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>>());
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private Store(LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>> entries) {
/* 1170 */             this.entries = entries;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private static <W> Entry<W> combine(Entry<W> left, Entry<W> right) {
/* 1182 */             Set<MethodDescription> leftMethods = left.getCandidates(), rightMethods = right.getCandidates();
/* 1183 */             LinkedHashSet<MethodDescription> combined = new LinkedHashSet<MethodDescription>();
/* 1184 */             combined.addAll(leftMethods);
/* 1185 */             combined.addAll(rightMethods);
/* 1186 */             for (MethodDescription leftMethod : leftMethods) {
/* 1187 */               TypeDescription leftType = leftMethod.getDeclaringType().asErasure();
/* 1188 */               for (MethodDescription rightMethod : rightMethods) {
/* 1189 */                 TypeDescription rightType = rightMethod.getDeclaringType().asErasure();
/* 1190 */                 if (leftType.equals(rightType))
/*      */                   break; 
/* 1192 */                 if (leftType.isAssignableTo(rightType)) {
/* 1193 */                   combined.remove(rightMethod); break;
/*      */                 } 
/* 1195 */                 if (leftType.isAssignableFrom(rightType)) {
/* 1196 */                   combined.remove(leftMethod);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */             
/* 1201 */             MethodGraph.Compiler.Default.Key.Harmonized<W> key = left.getKey().combineWith(right.getKey());
/* 1202 */             Visibility visibility = left.getVisibility().expandTo(right.getVisibility());
/* 1203 */             return (combined.size() == 1) ? new Entry.Resolved<W>(key, combined
/* 1204 */                 .iterator().next(), visibility, false) : new Entry.Ambiguous<W>(key, combined, visibility);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected Store<V> registerTopLevel(List<? extends MethodDescription> methodDescriptions, MethodGraph.Compiler.Default.Harmonizer<V> harmonizer) {
/* 1216 */             if (methodDescriptions.isEmpty()) {
/* 1217 */               return this;
/*      */             }
/* 1219 */             LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>> entries = new LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>>(this.entries);
/* 1220 */             for (MethodDescription methodDescription : methodDescriptions) {
/* 1221 */               MethodGraph.Compiler.Default.Key.Harmonized<V> key = MethodGraph.Compiler.Default.Key.Harmonized.of(methodDescription, harmonizer);
/* 1222 */               Entry<V> currentEntry = entries.remove(key);
/*      */               
/* 1224 */               Entry<V> extendedEntry = ((currentEntry == null) ? new Entry.Initial<V>(key) : currentEntry).extendBy(methodDescription, harmonizer);
/* 1225 */               entries.put(extendedEntry.getKey(), extendedEntry);
/*      */             } 
/* 1227 */             return new Store(entries);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected Store<V> combineWith(Store<V> store) {
/* 1237 */             if (this.entries.isEmpty())
/* 1238 */               return store; 
/* 1239 */             if (store.entries.isEmpty()) {
/* 1240 */               return this;
/*      */             }
/* 1242 */             LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>> entries = new LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>>(this.entries);
/* 1243 */             for (Entry<V> entry : store.entries.values()) {
/* 1244 */               Entry<V> previousEntry = entries.remove(entry.getKey());
/*      */               
/* 1246 */               Entry<V> injectedEntry = (previousEntry == null) ? entry : combine(previousEntry, entry);
/* 1247 */               entries.put(injectedEntry.getKey(), injectedEntry);
/*      */             } 
/* 1249 */             return new Store(entries);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected Store<V> inject(Store<V> store) {
/* 1259 */             if (this.entries.isEmpty())
/* 1260 */               return store; 
/* 1261 */             if (store.entries.isEmpty()) {
/* 1262 */               return this;
/*      */             }
/* 1264 */             LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>> entries = new LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>>(this.entries);
/* 1265 */             for (Entry<V> entry : store.entries.values()) {
/* 1266 */               Entry<V> previous = entries.remove(entry.getKey());
/*      */               
/* 1268 */               Entry<V> injectedEntry = (previous == null) ? entry : previous.inject(entry);
/* 1269 */               entries.put(injectedEntry.getKey(), injectedEntry);
/*      */             } 
/* 1271 */             return new Store(entries);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected MethodGraph asGraph(MethodGraph.Compiler.Default.Merger merger) {
/* 1281 */             LinkedHashMap<MethodGraph.Compiler.Default.Key<MethodDescription.TypeToken>, MethodGraph.Node> entries = new LinkedHashMap<MethodGraph.Compiler.Default.Key<MethodDescription.TypeToken>, MethodGraph.Node>();
/* 1282 */             for (Entry<V> entry : this.entries.values()) {
/* 1283 */               MethodGraph.Node node = entry.asNode(merger);
/* 1284 */               entries.put(entry.getKey().detach(node.getRepresentative().asTypeToken()), node);
/*      */             } 
/* 1286 */             return new Graph(entries);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.entries.equals(((Store)param4Object).entries))));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return getClass().hashCode() * 31 + this.entries.hashCode();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static class Initial<U>
/*      */             implements Entry<U>
/*      */           {
/*      */             private final MethodGraph.Compiler.Default.Key.Harmonized<U> key;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected Initial(MethodGraph.Compiler.Default.Key.Harmonized<U> key) {
/* 1360 */               this.key = key;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MethodGraph.Compiler.Default.Key.Harmonized<U> getKey() {
/* 1367 */               throw new IllegalStateException("Cannot extract key from initial entry:" + this);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public Set<MethodDescription> getCandidates() {
/* 1374 */               throw new IllegalStateException("Cannot extract method from initial entry:" + this);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public Visibility getVisibility() {
/* 1381 */               throw new IllegalStateException("Cannot extract visibility from initial entry:" + this);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MethodGraph.Compiler.Default.Key.Store.Entry<U> extendBy(MethodDescription methodDescription, MethodGraph.Compiler.Default.Harmonizer<U> harmonizer) {
/* 1388 */               return new MethodGraph.Compiler.Default.Key.Store.Entry.Resolved<U>(this.key.extend((MethodDescription.InDefinedShape)methodDescription.asDefined(), harmonizer), methodDescription, methodDescription
/*      */                   
/* 1390 */                   .getVisibility(), false);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MethodGraph.Compiler.Default.Key.Store.Entry<U> inject(MethodGraph.Compiler.Default.Key.Store.Entry<U> entry) {
/* 1398 */               throw new IllegalStateException("Cannot inject into initial entry without a registered method: " + this);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MethodGraph.Node asNode(MethodGraph.Compiler.Default.Merger merger) {
/* 1405 */               throw new IllegalStateException("Cannot transform initial entry without a registered method: " + this);
/*      */             }
/*      */ 
/*      */             
/*      */             public int hashCode() {
/* 1410 */               return this.key.hashCode();
/*      */             }
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object other) {
/* 1415 */               if (this == other)
/* 1416 */                 return true; 
/* 1417 */               if (other == null || getClass() != other.getClass()) {
/* 1418 */                 return false;
/*      */               }
/* 1420 */               Initial<?> initial = (Initial)other;
/* 1421 */               return this.key.equals(initial.key);
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @Enhance
/*      */           public static class Resolved<U>
/*      */             implements Entry<U>
/*      */           {
/*      */             private static final int MADE_VISIBLE = 5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private static final boolean NOT_MADE_VISIBLE = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final MethodGraph.Compiler.Default.Key.Harmonized<U> key;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final MethodDescription methodDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final Visibility visibility;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final boolean madeVisible;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected Resolved(MethodGraph.Compiler.Default.Key.Harmonized<U> key, MethodDescription methodDescription, Visibility visibility) {
/* 1472 */               this(key, methodDescription, visibility, false);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected Resolved(MethodGraph.Compiler.Default.Key.Harmonized<U> key, MethodDescription methodDescription, Visibility visibility, boolean madeVisible) {
/* 1484 */               this.key = key;
/* 1485 */               this.methodDescription = methodDescription;
/* 1486 */               this.visibility = visibility;
/* 1487 */               this.madeVisible = madeVisible;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private static <V> MethodGraph.Compiler.Default.Key.Store.Entry<V> of(MethodGraph.Compiler.Default.Key.Harmonized<V> key, MethodDescription override, MethodDescription original, Visibility visibility) {
/* 1501 */               visibility = visibility.expandTo(original.getVisibility()).expandTo(override.getVisibility());
/* 1502 */               if (override.isBridge()) {  } else {  }  return 
/* 1503 */                 new Resolved<V>(key, override, visibility, false);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MethodGraph.Compiler.Default.Key.Harmonized<U> getKey() {
/* 1511 */               return this.key;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public Set<MethodDescription> getCandidates() {
/* 1518 */               return Collections.singleton(this.methodDescription);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public Visibility getVisibility() {
/* 1525 */               return this.visibility;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MethodGraph.Compiler.Default.Key.Store.Entry<U> extendBy(MethodDescription methodDescription, MethodGraph.Compiler.Default.Harmonizer<U> harmonizer) {
/* 1532 */               MethodGraph.Compiler.Default.Key.Harmonized<U> key = this.key.extend((MethodDescription.InDefinedShape)methodDescription.asDefined(), harmonizer);
/* 1533 */               Visibility visibility = this.visibility.expandTo(methodDescription.getVisibility());
/* 1534 */               return methodDescription.getDeclaringType().equals(this.methodDescription.getDeclaringType()) ? 
/* 1535 */                 MethodGraph.Compiler.Default.Key.Store.Entry.Ambiguous.<U>of(key, methodDescription, this.methodDescription, visibility) : 
/* 1536 */                 of(key, methodDescription, this.methodDescription, visibility);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MethodGraph.Compiler.Default.Key.Store.Entry<U> inject(MethodGraph.Compiler.Default.Key.Store.Entry<U> entry) {
/* 1543 */               if (this.methodDescription.getDeclaringType().isInterface()) {
/* 1544 */                 LinkedHashSet<MethodDescription> candidates = new LinkedHashSet<MethodDescription>();
/* 1545 */                 candidates.add(this.methodDescription);
/* 1546 */                 TypeDescription target = this.methodDescription.getDeclaringType().asErasure();
/* 1547 */                 for (MethodDescription methodDescription : entry.getCandidates()) {
/* 1548 */                   if (methodDescription.getDeclaringType().asErasure().isAssignableTo(target)) {
/* 1549 */                     candidates.remove(this.methodDescription);
/* 1550 */                     candidates.add(methodDescription); continue;
/* 1551 */                   }  if (!methodDescription.getDeclaringType().asErasure().isAssignableFrom(target)) {
/* 1552 */                     candidates.add(methodDescription);
/*      */                   }
/*      */                 } 
/* 1555 */                 return (candidates.size() == 1) ? new Resolved(this.key
/* 1556 */                     .combineWith(entry.getKey()), candidates.iterator().next(), this.visibility.expandTo(entry.getVisibility()), this.madeVisible) : new MethodGraph.Compiler.Default.Key.Store.Entry.Ambiguous<U>(this.key
/* 1557 */                     .combineWith(entry.getKey()), candidates, this.visibility.expandTo(entry.getVisibility()));
/*      */               } 
/* 1559 */               return new Resolved(this.key.combineWith(entry.getKey()), this.methodDescription, this.visibility.expandTo(entry.getVisibility()), this.madeVisible);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MethodGraph.Node asNode(MethodGraph.Compiler.Default.Merger merger) {
/* 1567 */               return new Node(this.key.detach(this.methodDescription.asTypeToken()), this.methodDescription, this.visibility, this.madeVisible);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : ((this.madeVisible != ((Resolved)param5Object).madeVisible) ? false : (!this.visibility.equals(((Resolved)param5Object).visibility) ? false : (!this.key.equals(((Resolved)param5Object).key) ? false : (!!this.methodDescription.equals(((Resolved)param5Object).methodDescription)))))));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               return (((getClass().hashCode() * 31 + this.key.hashCode()) * 31 + this.methodDescription.hashCode()) * 31 + this.visibility.hashCode()) * 31 + this.madeVisible;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             protected static class Node
/*      */               implements MethodGraph.Node
/*      */             {
/*      */               private final MethodGraph.Compiler.Default.Key.Detached key;
/*      */ 
/*      */               
/*      */               private final MethodDescription methodDescription;
/*      */ 
/*      */               
/*      */               private final Visibility visibility;
/*      */ 
/*      */               
/*      */               private final boolean visible;
/*      */ 
/*      */ 
/*      */               
/*      */               protected Node(MethodGraph.Compiler.Default.Key.Detached key, MethodDescription methodDescription, Visibility visibility, boolean visible) {
/* 1605 */                 this.key = key;
/* 1606 */                 this.methodDescription = methodDescription;
/* 1607 */                 this.visibility = visibility;
/* 1608 */                 this.visible = visible;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MethodGraph.Node.Sort getSort() {
/* 1615 */                 return this.visible ? MethodGraph.Node.Sort.VISIBLE : MethodGraph.Node.Sort.RESOLVED;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MethodDescription getRepresentative() {
/* 1624 */                 return this.methodDescription;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Set<MethodDescription.TypeToken> getMethodTypes() {
/* 1631 */                 return this.key.getIdentifiers();
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public Visibility getVisibility()
/*      */               {
/* 1638 */                 return this.visibility; } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : ((this.visible != ((Node)param7Object).visible) ? false : (!this.visibility.equals(((Node)param7Object).visibility) ? false : (!this.key.equals(((Node)param7Object).key) ? false : (!!this.methodDescription.equals(((Node)param7Object).methodDescription))))))); } public int hashCode() { return (((getClass().hashCode() * 31 + this.key.hashCode()) * 31 + this.methodDescription.hashCode()) * 31 + this.visibility.hashCode()) * 31 + this.visible; } } } protected static interface Entry<W> { MethodGraph.Compiler.Default.Key.Harmonized<W> getKey(); Set<MethodDescription> getCandidates(); Visibility getVisibility(); Entry<W> extendBy(MethodDescription param5MethodDescription, MethodGraph.Compiler.Default.Harmonizer<W> param5Harmonizer); Entry<W> inject(Entry<W> param5Entry); MethodGraph.Node asNode(MethodGraph.Compiler.Default.Merger param5Merger); public static class Initial<U> implements Entry<U> { private final MethodGraph.Compiler.Default.Key.Harmonized<U> key; protected Initial(MethodGraph.Compiler.Default.Key.Harmonized<U> key) { this.key = key; } public MethodGraph.Compiler.Default.Key.Harmonized<U> getKey() { throw new IllegalStateException("Cannot extract key from initial entry:" + this); } public Set<MethodDescription> getCandidates() { throw new IllegalStateException("Cannot extract method from initial entry:" + this); } public Visibility getVisibility() { throw new IllegalStateException("Cannot extract visibility from initial entry:" + this); } public MethodGraph.Compiler.Default.Key.Store.Entry<U> extendBy(MethodDescription methodDescription, MethodGraph.Compiler.Default.Harmonizer<U> harmonizer) { return new MethodGraph.Compiler.Default.Key.Store.Entry.Resolved<U>(this.key.extend((MethodDescription.InDefinedShape)methodDescription.asDefined(), harmonizer), methodDescription, methodDescription.getVisibility(), false); } public MethodGraph.Compiler.Default.Key.Store.Entry<U> inject(MethodGraph.Compiler.Default.Key.Store.Entry<U> entry) { throw new IllegalStateException("Cannot inject into initial entry without a registered method: " + this); } public MethodGraph.Node asNode(MethodGraph.Compiler.Default.Merger merger) { throw new IllegalStateException("Cannot transform initial entry without a registered method: " + this); } public int hashCode() { return this.key.hashCode(); } public boolean equals(@MaybeNull Object other) { if (this == other) return true;  if (other == null || getClass() != other.getClass()) return false;  Initial<?> initial = (Initial)other; return this.key.equals(initial.key); } } @Enhance public static class Resolved<U> implements Entry<U> { private static final int MADE_VISIBLE = 5; private static final boolean NOT_MADE_VISIBLE = false; private final MethodGraph.Compiler.Default.Key.Harmonized<U> key; private final MethodDescription methodDescription; private final Visibility visibility; private final boolean madeVisible; protected Resolved(MethodGraph.Compiler.Default.Key.Harmonized<U> key, MethodDescription methodDescription, Visibility visibility) { this(key, methodDescription, visibility, false); } protected Resolved(MethodGraph.Compiler.Default.Key.Harmonized<U> key, MethodDescription methodDescription, Visibility visibility, boolean madeVisible) { this.key = key; this.methodDescription = methodDescription; this.visibility = visibility; this.madeVisible = madeVisible; } private static <V> MethodGraph.Compiler.Default.Key.Store.Entry<V> of(MethodGraph.Compiler.Default.Key.Harmonized<V> key, MethodDescription override, MethodDescription original, Visibility visibility) { visibility = visibility.expandTo(original.getVisibility()).expandTo(override.getVisibility()); if (override.isBridge()) {  } else {  }  return new Resolved<V>(key, override, visibility, false); } public MethodGraph.Compiler.Default.Key.Harmonized<U> getKey() { return this.key; } public Set<MethodDescription> getCandidates() { return Collections.singleton(this.methodDescription); } public Visibility getVisibility() { return this.visibility; } public MethodGraph.Compiler.Default.Key.Store.Entry<U> extendBy(MethodDescription methodDescription, MethodGraph.Compiler.Default.Harmonizer<U> harmonizer) { MethodGraph.Compiler.Default.Key.Harmonized<U> key = this.key.extend((MethodDescription.InDefinedShape)methodDescription.asDefined(), harmonizer); Visibility visibility = this.visibility.expandTo(methodDescription.getVisibility()); return methodDescription.getDeclaringType().equals(this.methodDescription.getDeclaringType()) ? MethodGraph.Compiler.Default.Key.Store.Entry.Ambiguous.<U>of(key, methodDescription, this.methodDescription, visibility) : of(key, methodDescription, this.methodDescription, visibility); } public MethodGraph.Compiler.Default.Key.Store.Entry<U> inject(MethodGraph.Compiler.Default.Key.Store.Entry<U> entry) { if (this.methodDescription.getDeclaringType().isInterface()) { LinkedHashSet<MethodDescription> candidates = new LinkedHashSet<MethodDescription>(); candidates.add(this.methodDescription); TypeDescription target = this.methodDescription.getDeclaringType().asErasure(); for (MethodDescription methodDescription : entry.getCandidates()) { if (methodDescription.getDeclaringType().asErasure().isAssignableTo(target)) { candidates.remove(this.methodDescription); candidates.add(methodDescription); continue; }  if (!methodDescription.getDeclaringType().asErasure().isAssignableFrom(target)) candidates.add(methodDescription);  }  return (candidates.size() == 1) ? new Resolved(this.key.combineWith(entry.getKey()), candidates.iterator().next(), this.visibility.expandTo(entry.getVisibility()), this.madeVisible) : new MethodGraph.Compiler.Default.Key.Store.Entry.Ambiguous<U>(this.key.combineWith(entry.getKey()), candidates, this.visibility.expandTo(entry.getVisibility())); }  return new Resolved(this.key.combineWith(entry.getKey()), this.methodDescription, this.visibility.expandTo(entry.getVisibility()), this.madeVisible); } public MethodGraph.Node asNode(MethodGraph.Compiler.Default.Merger merger) { return new Node(this.key.detach(this.methodDescription.asTypeToken()), this.methodDescription, this.visibility, this.madeVisible); } public boolean equals(@MaybeNull Object param6Object) { return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : ((this.madeVisible != ((Resolved)param6Object).madeVisible) ? false : (!this.visibility.equals(((Resolved)param6Object).visibility) ? false : (!this.key.equals(((Resolved)param6Object).key) ? false : (!!this.methodDescription.equals(((Resolved)param6Object).methodDescription))))))); } public int hashCode() { return (((getClass().hashCode() * 31 + this.key.hashCode()) * 31 + this.methodDescription.hashCode()) * 31 + this.visibility.hashCode()) * 31 + this.madeVisible; } @Enhance protected static class Node implements MethodGraph.Node { private final MethodGraph.Compiler.Default.Key.Detached key; private final MethodDescription methodDescription; private final Visibility visibility; private final boolean visible; protected Node(MethodGraph.Compiler.Default.Key.Detached key, MethodDescription methodDescription, Visibility visibility, boolean visible) { this.key = key; this.methodDescription = methodDescription; this.visibility = visibility; this.visible = visible; } public MethodGraph.Node.Sort getSort() { return this.visible ? MethodGraph.Node.Sort.VISIBLE : MethodGraph.Node.Sort.RESOLVED; } public MethodDescription getRepresentative() { return this.methodDescription; } public Set<MethodDescription.TypeToken> getMethodTypes() { return this.key.getIdentifiers(); } public Visibility getVisibility() { return this.visibility; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public boolean equals(@MaybeNull Object param7Object) {
/*      */                   return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : ((this.visible != ((Node)param7Object).visible) ? false : (!this.visibility.equals(((Node)param7Object).visibility) ? false : (!this.key.equals(((Node)param7Object).key) ? false : (!!this.methodDescription.equals(((Node)param7Object).methodDescription)))))));
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public int hashCode() {
/*      */                   return (((getClass().hashCode() * 31 + this.key.hashCode()) * 31 + this.methodDescription.hashCode()) * 31 + this.visibility.hashCode()) * 31 + this.visible;
/*      */                 } }
/*      */                }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             public static class Ambiguous<U>
/*      */               implements Entry<U>
/*      */             {
/*      */               private final MethodGraph.Compiler.Default.Key.Harmonized<U> key;
/*      */ 
/*      */               
/*      */               private final LinkedHashSet<MethodDescription> methodDescriptions;
/*      */ 
/*      */               
/*      */               private final Visibility visibility;
/*      */ 
/*      */ 
/*      */               
/*      */               protected Ambiguous(MethodGraph.Compiler.Default.Key.Harmonized<U> key, LinkedHashSet<MethodDescription> methodDescriptions, Visibility visibility) {
/* 1674 */                 this.key = key;
/* 1675 */                 this.methodDescriptions = methodDescriptions;
/* 1676 */                 this.visibility = visibility;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected static <Q> MethodGraph.Compiler.Default.Key.Store.Entry<Q> of(MethodGraph.Compiler.Default.Key.Harmonized<Q> key, MethodDescription left, MethodDescription right, Visibility visibility) {
/* 1690 */                 visibility = visibility.expandTo(left.getVisibility()).expandTo(right.getVisibility());
/* 1691 */                 if ((left.isBridge() ^ right.isBridge()) != 0) {  } else {  }  return 
/* 1692 */                   new Ambiguous<Q>(key, new LinkedHashSet<MethodDescription>(
/* 1693 */                       Arrays.asList(new MethodDescription[] { left, right }, )), visibility);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MethodGraph.Compiler.Default.Key.Harmonized<U> getKey() {
/* 1700 */                 return this.key;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Set<MethodDescription> getCandidates() {
/* 1707 */                 return this.methodDescriptions;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Visibility getVisibility() {
/* 1714 */                 return this.visibility;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MethodGraph.Compiler.Default.Key.Store.Entry<U> extendBy(MethodDescription methodDescription, MethodGraph.Compiler.Default.Harmonizer<U> harmonizer) {
/* 1721 */                 MethodGraph.Compiler.Default.Key.Harmonized<U> key = this.key.extend((MethodDescription.InDefinedShape)methodDescription.asDefined(), harmonizer);
/* 1722 */                 LinkedHashSet<MethodDescription> methodDescriptions = new LinkedHashSet<MethodDescription>();
/* 1723 */                 TypeDescription declaringType = methodDescription.getDeclaringType().asErasure();
/* 1724 */                 boolean bridge = methodDescription.isBridge();
/* 1725 */                 Visibility visibility = this.visibility;
/* 1726 */                 for (MethodDescription extendedMethod : this.methodDescriptions) {
/* 1727 */                   if (extendedMethod.getDeclaringType().asErasure().equals(declaringType)) {
/* 1728 */                     if (extendedMethod.isBridge() ^ bridge) {
/* 1729 */                       methodDescriptions.add(bridge ? extendedMethod : methodDescription);
/*      */                     } else {
/* 1731 */                       methodDescriptions.add(methodDescription);
/* 1732 */                       methodDescriptions.add(extendedMethod);
/*      */                     } 
/*      */                   }
/* 1735 */                   visibility = visibility.expandTo(extendedMethod.getVisibility());
/*      */                 } 
/* 1737 */                 if (methodDescriptions.isEmpty())
/* 1738 */                   return new MethodGraph.Compiler.Default.Key.Store.Entry.Resolved<U>(key, methodDescription, visibility, bridge); 
/* 1739 */                 if (methodDescriptions.size() == 1) {
/* 1740 */                   return new MethodGraph.Compiler.Default.Key.Store.Entry.Resolved<U>(key, methodDescriptions.iterator().next(), visibility, false);
/*      */                 }
/* 1742 */                 return new Ambiguous(key, methodDescriptions, visibility);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MethodGraph.Compiler.Default.Key.Store.Entry<U> inject(MethodGraph.Compiler.Default.Key.Store.Entry<U> entry) {
/* 1750 */                 LinkedHashSet<MethodDescription> methodDescriptions = new LinkedHashSet<MethodDescription>();
/*      */                 
/* 1752 */                 label32: for (MethodDescription methodDescription : this.methodDescriptions) {
/* 1753 */                   TypeDescription target = methodDescription.getDeclaringType().asErasure();
/* 1754 */                   for (MethodDescription candidate : entry.getCandidates()) {
/* 1755 */                     TypeDescription typeDescription = candidate.getDeclaringType().asErasure();
/* 1756 */                     if (!typeDescription.equals(target) && typeDescription.isAssignableTo(target)) {
/*      */                       continue label32;
/*      */                     }
/*      */                   } 
/* 1760 */                   methodDescriptions.add(methodDescription);
/*      */                 } 
/*      */                 
/* 1763 */                 label31: for (MethodDescription candidate : entry.getCandidates()) {
/* 1764 */                   TypeDescription target = candidate.getDeclaringType().asErasure();
/* 1765 */                   for (MethodDescription methodDescription : this.methodDescriptions) {
/* 1766 */                     if (methodDescription.getDeclaringType().asErasure().isAssignableTo(target)) {
/*      */                       continue label31;
/*      */                     }
/*      */                   } 
/* 1770 */                   methodDescriptions.add(candidate);
/*      */                 } 
/* 1772 */                 return (methodDescriptions.size() == 1) ? new MethodGraph.Compiler.Default.Key.Store.Entry.Resolved<U>(this.key
/* 1773 */                     .combineWith(entry.getKey()), methodDescriptions.iterator().next(), this.visibility.expandTo(entry.getVisibility())) : new Ambiguous(this.key
/* 1774 */                     .combineWith(entry.getKey()), methodDescriptions, this.visibility.expandTo(entry.getVisibility()));
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MethodGraph.Node asNode(MethodGraph.Compiler.Default.Merger merger) {
/* 1781 */                 Iterator<MethodDescription> iterator = this.methodDescriptions.iterator();
/* 1782 */                 MethodDescription methodDescription = iterator.next();
/* 1783 */                 while (iterator.hasNext()) {
/* 1784 */                   methodDescription = merger.merge(methodDescription, iterator.next());
/*      */                 }
/* 1786 */                 return new Node(this.key.detach(methodDescription.asTypeToken()), methodDescription, this.visibility);
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param6Object) {
/*      */                 return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : (!this.visibility.equals(((Ambiguous)param6Object).visibility) ? false : (!this.key.equals(((Ambiguous)param6Object).key) ? false : (!!this.methodDescriptions.equals(((Ambiguous)param6Object).methodDescriptions))))));
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return ((getClass().hashCode() * 31 + this.key.hashCode()) * 31 + this.methodDescriptions.hashCode()) * 31 + this.visibility.hashCode();
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               @Enhance
/*      */               protected static class Node
/*      */                 implements MethodGraph.Node
/*      */               {
/*      */                 private final MethodGraph.Compiler.Default.Key.Detached key;
/*      */ 
/*      */                 
/*      */                 private final MethodDescription methodDescription;
/*      */                 
/*      */                 private final Visibility visibility;
/*      */ 
/*      */                 
/*      */                 protected Node(MethodGraph.Compiler.Default.Key.Detached key, MethodDescription methodDescription, Visibility visibility) {
/* 1816 */                   this.key = key;
/* 1817 */                   this.methodDescription = methodDescription;
/* 1818 */                   this.visibility = visibility;
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public MethodGraph.Node.Sort getSort() {
/* 1825 */                   return MethodGraph.Node.Sort.AMBIGUOUS;
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public MethodDescription getRepresentative() {
/* 1832 */                   return this.methodDescription;
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public Set<MethodDescription.TypeToken> getMethodTypes() {
/* 1839 */                   return this.key.getIdentifiers();
/*      */                 }
/*      */ 
/*      */ 
/*      */                 
/*      */                 public Visibility getVisibility()
/*      */                 {
/* 1846 */                   return this.visibility; } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.visibility.equals(((Node)param7Object).visibility) ? false : (!this.key.equals(((Node)param7Object).key) ? false : (!!this.methodDescription.equals(((Node)param7Object).methodDescription)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.key.hashCode()) * 31 + this.methodDescription.hashCode()) * 31 + this.visibility.hashCode(); } } } } @Enhance public static class Ambiguous<U> implements Entry<U> { private final MethodGraph.Compiler.Default.Key.Harmonized<U> key; private final LinkedHashSet<MethodDescription> methodDescriptions; private final Visibility visibility; protected Ambiguous(MethodGraph.Compiler.Default.Key.Harmonized<U> key, LinkedHashSet<MethodDescription> methodDescriptions, Visibility visibility) { this.key = key; this.methodDescriptions = methodDescriptions; this.visibility = visibility; } protected static <Q> MethodGraph.Compiler.Default.Key.Store.Entry<Q> of(MethodGraph.Compiler.Default.Key.Harmonized<Q> key, MethodDescription left, MethodDescription right, Visibility visibility) { visibility = visibility.expandTo(left.getVisibility()).expandTo(right.getVisibility()); if ((left.isBridge() ^ right.isBridge()) != 0) {  } else {  }  return new Ambiguous<Q>(key, new LinkedHashSet<MethodDescription>(Arrays.asList(new MethodDescription[] { left, right }, )), visibility); } public MethodGraph.Compiler.Default.Key.Harmonized<U> getKey() { return this.key; } public Set<MethodDescription> getCandidates() { return this.methodDescriptions; } public Visibility getVisibility() { return this.visibility; } public MethodGraph.Compiler.Default.Key.Store.Entry<U> extendBy(MethodDescription methodDescription, MethodGraph.Compiler.Default.Harmonizer<U> harmonizer) { MethodGraph.Compiler.Default.Key.Harmonized<U> key = this.key.extend((MethodDescription.InDefinedShape)methodDescription.asDefined(), harmonizer); LinkedHashSet<MethodDescription> methodDescriptions = new LinkedHashSet<MethodDescription>(); TypeDescription declaringType = methodDescription.getDeclaringType().asErasure(); boolean bridge = methodDescription.isBridge(); Visibility visibility = this.visibility; for (MethodDescription extendedMethod : this.methodDescriptions) { if (extendedMethod.getDeclaringType().asErasure().equals(declaringType)) if (extendedMethod.isBridge() ^ bridge) { methodDescriptions.add(bridge ? extendedMethod : methodDescription); } else { methodDescriptions.add(methodDescription); methodDescriptions.add(extendedMethod); }   visibility = visibility.expandTo(extendedMethod.getVisibility()); }  if (methodDescriptions.isEmpty()) return new MethodGraph.Compiler.Default.Key.Store.Entry.Resolved<U>(key, methodDescription, visibility, bridge);  if (methodDescriptions.size() == 1) return new MethodGraph.Compiler.Default.Key.Store.Entry.Resolved<U>(key, methodDescriptions.iterator().next(), visibility, false);  return new Ambiguous(key, methodDescriptions, visibility); } public MethodGraph.Compiler.Default.Key.Store.Entry<U> inject(MethodGraph.Compiler.Default.Key.Store.Entry<U> entry) { LinkedHashSet<MethodDescription> methodDescriptions = new LinkedHashSet<MethodDescription>(); label32: for (MethodDescription methodDescription : this.methodDescriptions) { TypeDescription target = methodDescription.getDeclaringType().asErasure(); for (MethodDescription candidate : entry.getCandidates()) { TypeDescription typeDescription = candidate.getDeclaringType().asErasure(); if (!typeDescription.equals(target) && typeDescription.isAssignableTo(target)) continue label32;  }  methodDescriptions.add(methodDescription); }  label31: for (MethodDescription candidate : entry.getCandidates()) { TypeDescription target = candidate.getDeclaringType().asErasure(); for (MethodDescription methodDescription : this.methodDescriptions) { if (methodDescription.getDeclaringType().asErasure().isAssignableTo(target)) continue label31;  }  methodDescriptions.add(candidate); }  return (methodDescriptions.size() == 1) ? new MethodGraph.Compiler.Default.Key.Store.Entry.Resolved<U>(this.key.combineWith(entry.getKey()), methodDescriptions.iterator().next(), this.visibility.expandTo(entry.getVisibility())) : new Ambiguous(this.key.combineWith(entry.getKey()), methodDescriptions, this.visibility.expandTo(entry.getVisibility())); } public MethodGraph.Node asNode(MethodGraph.Compiler.Default.Merger merger) { Iterator<MethodDescription> iterator = this.methodDescriptions.iterator(); MethodDescription methodDescription = iterator.next(); while (iterator.hasNext()) methodDescription = merger.merge(methodDescription, iterator.next());  return new Node(this.key.detach(methodDescription.asTypeToken()), methodDescription, this.visibility); } public boolean equals(@MaybeNull Object param5Object) { return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!this.visibility.equals(((Ambiguous)param5Object).visibility) ? false : (!this.key.equals(((Ambiguous)param5Object).key) ? false : (!!this.methodDescriptions.equals(((Ambiguous)param5Object).methodDescriptions)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.key.hashCode()) * 31 + this.methodDescriptions.hashCode()) * 31 + this.visibility.hashCode(); } @Enhance protected static class Node implements MethodGraph.Node { private final MethodGraph.Compiler.Default.Key.Detached key; private final MethodDescription methodDescription; private final Visibility visibility; protected Node(MethodGraph.Compiler.Default.Key.Detached key, MethodDescription methodDescription, Visibility visibility) { this.key = key; this.methodDescription = methodDescription; this.visibility = visibility; } public MethodGraph.Node.Sort getSort() { return MethodGraph.Node.Sort.AMBIGUOUS; } public MethodDescription getRepresentative() { return this.methodDescription; } public Set<MethodDescription.TypeToken> getMethodTypes() { return this.key.getIdentifiers(); } public Visibility getVisibility() { return this.visibility; }
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.visibility.equals(((Node)param7Object).visibility) ? false : (!this.key.equals(((Node)param7Object).key) ? false : (!!this.methodDescription.equals(((Node)param7Object).methodDescription))))));
/*      */               }
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return ((getClass().hashCode() * 31 + this.key.hashCode()) * 31 + this.methodDescription.hashCode()) * 31 + this.visibility.hashCode();
/*      */               } }
/*      */              }
/*      */ 
/*      */ 
/*      */           
/*      */           @Enhance
/*      */           protected static class Graph
/*      */             implements MethodGraph
/*      */           {
/*      */             private final LinkedHashMap<MethodGraph.Compiler.Default.Key<MethodDescription.TypeToken>, MethodGraph.Node> entries;
/*      */             
/*      */             protected Graph(LinkedHashMap<MethodGraph.Compiler.Default.Key<MethodDescription.TypeToken>, MethodGraph.Node> entries) {
/* 1869 */               this.entries = entries;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MethodGraph.Node locate(MethodDescription.SignatureToken token) {
/* 1876 */               MethodGraph.Node node = this.entries.get(MethodGraph.Compiler.Default.Key.Detached.of(token));
/* 1877 */               return (node == null) ? MethodGraph.Node.Unresolved.INSTANCE : node;
/*      */             }
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.entries.equals(((Graph)param5Object).entries))));
/*      */             }
/*      */             public int hashCode() {
/*      */               return getClass().hashCode() * 31 + this.entries.hashCode();
/*      */             }
/*      */             
/* 1886 */             public MethodGraph.NodeList listNodes() { return new MethodGraph.NodeList(new ArrayList<MethodGraph.Node>(this.entries.values())); } } } } @Enhance protected static class Store<V> { private final LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>> entries; protected Store() { this(new LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>>()); } private Store(LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>> entries) { this.entries = entries; } private static <W> Entry<W> combine(Entry<W> left, Entry<W> right) { Set<MethodDescription> leftMethods = left.getCandidates(), rightMethods = right.getCandidates(); LinkedHashSet<MethodDescription> combined = new LinkedHashSet<MethodDescription>(); combined.addAll(leftMethods); combined.addAll(rightMethods); for (MethodDescription leftMethod : leftMethods) { TypeDescription leftType = leftMethod.getDeclaringType().asErasure(); for (MethodDescription rightMethod : rightMethods) { TypeDescription rightType = rightMethod.getDeclaringType().asErasure(); if (leftType.equals(rightType)) break;  if (leftType.isAssignableTo(rightType)) { combined.remove(rightMethod); break; }  if (leftType.isAssignableFrom(rightType)) combined.remove(leftMethod);  }  }  MethodGraph.Compiler.Default.Key.Harmonized<W> key = left.getKey().combineWith(right.getKey()); Visibility visibility = left.getVisibility().expandTo(right.getVisibility()); return (combined.size() == 1) ? new Entry.Resolved<W>(key, combined.iterator().next(), visibility, false) : new Entry.Ambiguous<W>(key, combined, visibility); } protected Store<V> registerTopLevel(List<? extends MethodDescription> methodDescriptions, MethodGraph.Compiler.Default.Harmonizer<V> harmonizer) { if (methodDescriptions.isEmpty()) return this;  LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>> entries = new LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>>(this.entries); for (MethodDescription methodDescription : methodDescriptions) { MethodGraph.Compiler.Default.Key.Harmonized<V> key = MethodGraph.Compiler.Default.Key.Harmonized.of(methodDescription, harmonizer); Entry<V> currentEntry = entries.remove(key); Entry<V> extendedEntry = ((currentEntry == null) ? new Entry.Initial<V>(key) : currentEntry).extendBy(methodDescription, harmonizer); entries.put(extendedEntry.getKey(), extendedEntry); }  return new Store(entries); } protected Store<V> combineWith(Store<V> store) { if (this.entries.isEmpty()) return store;  if (store.entries.isEmpty()) return this;  LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>> entries = new LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>>(this.entries); for (Entry<V> entry : store.entries.values()) { Entry<V> previousEntry = entries.remove(entry.getKey()); Entry<V> injectedEntry = (previousEntry == null) ? entry : combine(previousEntry, entry); entries.put(injectedEntry.getKey(), injectedEntry); }  return new Store(entries); } protected Store<V> inject(Store<V> store) { if (this.entries.isEmpty()) return store;  if (store.entries.isEmpty()) return this;  LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>> entries = new LinkedHashMap<MethodGraph.Compiler.Default.Key.Harmonized<V>, Entry<V>>(this.entries); for (Entry<V> entry : store.entries.values()) { Entry<V> previous = entries.remove(entry.getKey()); Entry<V> injectedEntry = (previous == null) ? entry : previous.inject(entry); entries.put(injectedEntry.getKey(), injectedEntry); }  return new Store(entries); } protected MethodGraph asGraph(MethodGraph.Compiler.Default.Merger merger) { LinkedHashMap<MethodGraph.Compiler.Default.Key<MethodDescription.TypeToken>, MethodGraph.Node> entries = new LinkedHashMap<MethodGraph.Compiler.Default.Key<MethodDescription.TypeToken>, MethodGraph.Node>(); for (Entry<V> entry : this.entries.values()) { MethodGraph.Node node = entry.asNode(merger); entries.put(entry.getKey().detach(node.getRepresentative().asTypeToken()), node); }  return new Graph(entries); } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.entries.equals(((Store)param3Object).entries)))); } public int hashCode() { return getClass().hashCode() * 31 + this.entries.hashCode(); } public static class Initial<U> implements Entry<U> { private final MethodGraph.Compiler.Default.Key.Harmonized<U> key; protected Initial(MethodGraph.Compiler.Default.Key.Harmonized<U> key) { this.key = key; } public MethodGraph.Compiler.Default.Key.Harmonized<U> getKey() { throw new IllegalStateException("Cannot extract key from initial entry:" + this); } public Set<MethodDescription> getCandidates() { throw new IllegalStateException("Cannot extract method from initial entry:" + this); } public Visibility getVisibility() { throw new IllegalStateException("Cannot extract visibility from initial entry:" + this); } public MethodGraph.Compiler.Default.Key.Store.Entry<U> extendBy(MethodDescription methodDescription, MethodGraph.Compiler.Default.Harmonizer<U> harmonizer) { return new MethodGraph.Compiler.Default.Key.Store.Entry.Resolved<U>(this.key.extend((MethodDescription.InDefinedShape)methodDescription.asDefined(), harmonizer), methodDescription, methodDescription.getVisibility(), false); } public MethodGraph.Compiler.Default.Key.Store.Entry<U> inject(MethodGraph.Compiler.Default.Key.Store.Entry<U> entry) { throw new IllegalStateException("Cannot inject into initial entry without a registered method: " + this); } public MethodGraph.Node asNode(MethodGraph.Compiler.Default.Merger merger) { throw new IllegalStateException("Cannot transform initial entry without a registered method: " + this); } public int hashCode() { return this.key.hashCode(); } public boolean equals(@MaybeNull Object other) { if (this == other) return true;  if (other == null || getClass() != other.getClass()) return false;  Initial<?> initial = (Initial)other; return this.key.equals(initial.key); } } @Enhance public static class Resolved<U> implements Entry<U> { private static final int MADE_VISIBLE = 5; private static final boolean NOT_MADE_VISIBLE = false; private final MethodGraph.Compiler.Default.Key.Harmonized<U> key; private final MethodDescription methodDescription; private final Visibility visibility; private final boolean madeVisible; protected Resolved(MethodGraph.Compiler.Default.Key.Harmonized<U> key, MethodDescription methodDescription, Visibility visibility) { this(key, methodDescription, visibility, false); } protected Resolved(MethodGraph.Compiler.Default.Key.Harmonized<U> key, MethodDescription methodDescription, Visibility visibility, boolean madeVisible) { this.key = key; this.methodDescription = methodDescription; this.visibility = visibility; this.madeVisible = madeVisible; } private static <V> MethodGraph.Compiler.Default.Key.Store.Entry<V> of(MethodGraph.Compiler.Default.Key.Harmonized<V> key, MethodDescription override, MethodDescription original, Visibility visibility) { visibility = visibility.expandTo(original.getVisibility()).expandTo(override.getVisibility()); if (override.isBridge()) {  } else {  }  return new Resolved<V>(key, override, visibility, false); } public MethodGraph.Compiler.Default.Key.Harmonized<U> getKey() { return this.key; } public Set<MethodDescription> getCandidates() { return Collections.singleton(this.methodDescription); } public Visibility getVisibility() { return this.visibility; } public MethodGraph.Compiler.Default.Key.Store.Entry<U> extendBy(MethodDescription methodDescription, MethodGraph.Compiler.Default.Harmonizer<U> harmonizer) { MethodGraph.Compiler.Default.Key.Harmonized<U> key = this.key.extend((MethodDescription.InDefinedShape)methodDescription.asDefined(), harmonizer); Visibility visibility = this.visibility.expandTo(methodDescription.getVisibility()); return methodDescription.getDeclaringType().equals(this.methodDescription.getDeclaringType()) ? MethodGraph.Compiler.Default.Key.Store.Entry.Ambiguous.<U>of(key, methodDescription, this.methodDescription, visibility) : of(key, methodDescription, this.methodDescription, visibility); } public MethodGraph.Compiler.Default.Key.Store.Entry<U> inject(MethodGraph.Compiler.Default.Key.Store.Entry<U> entry) { if (this.methodDescription.getDeclaringType().isInterface()) { LinkedHashSet<MethodDescription> candidates = new LinkedHashSet<MethodDescription>(); candidates.add(this.methodDescription); TypeDescription target = this.methodDescription.getDeclaringType().asErasure(); for (MethodDescription methodDescription : entry.getCandidates()) { if (methodDescription.getDeclaringType().asErasure().isAssignableTo(target)) { candidates.remove(this.methodDescription); candidates.add(methodDescription); continue; }  if (!methodDescription.getDeclaringType().asErasure().isAssignableFrom(target)) candidates.add(methodDescription);  }  return (candidates.size() == 1) ? new Resolved(this.key.combineWith(entry.getKey()), candidates.iterator().next(), this.visibility.expandTo(entry.getVisibility()), this.madeVisible) : new MethodGraph.Compiler.Default.Key.Store.Entry.Ambiguous<U>(this.key.combineWith(entry.getKey()), candidates, this.visibility.expandTo(entry.getVisibility())); }  return new Resolved(this.key.combineWith(entry.getKey()), this.methodDescription, this.visibility.expandTo(entry.getVisibility()), this.madeVisible); } public MethodGraph.Node asNode(MethodGraph.Compiler.Default.Merger merger) { return new Node(this.key.detach(this.methodDescription.asTypeToken()), this.methodDescription, this.visibility, this.madeVisible); } public boolean equals(@MaybeNull Object param5Object) { return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : ((this.madeVisible != ((Resolved)param5Object).madeVisible) ? false : (!this.visibility.equals(((Resolved)param5Object).visibility) ? false : (!this.key.equals(((Resolved)param5Object).key) ? false : (!!this.methodDescription.equals(((Resolved)param5Object).methodDescription))))))); } public int hashCode() { return (((getClass().hashCode() * 31 + this.key.hashCode()) * 31 + this.methodDescription.hashCode()) * 31 + this.visibility.hashCode()) * 31 + this.madeVisible; } @Enhance protected static class Node implements MethodGraph.Node { private final MethodGraph.Compiler.Default.Key.Detached key; private final MethodDescription methodDescription; private final Visibility visibility; private final boolean visible; protected Node(MethodGraph.Compiler.Default.Key.Detached key, MethodDescription methodDescription, Visibility visibility, boolean visible) { this.key = key; this.methodDescription = methodDescription; this.visibility = visibility; this.visible = visible; } public MethodGraph.Node.Sort getSort() { return this.visible ? MethodGraph.Node.Sort.VISIBLE : MethodGraph.Node.Sort.RESOLVED; } public MethodDescription getRepresentative() { return this.methodDescription; } public Set<MethodDescription.TypeToken> getMethodTypes() { return this.key.getIdentifiers(); } public Visibility getVisibility() { return this.visibility; } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : ((this.visible != ((Node)param7Object).visible) ? false : (!this.visibility.equals(((Node)param7Object).visibility) ? false : (!this.key.equals(((Node)param7Object).key) ? false : (!!this.methodDescription.equals(((Node)param7Object).methodDescription))))))); } public int hashCode() { return (((getClass().hashCode() * 31 + this.key.hashCode()) * 31 + this.methodDescription.hashCode()) * 31 + this.visibility.hashCode()) * 31 + this.visible; } } } protected static interface Entry<W> { MethodGraph.Compiler.Default.Key.Harmonized<W> getKey(); Set<MethodDescription> getCandidates(); Visibility getVisibility(); Entry<W> extendBy(MethodDescription param5MethodDescription, MethodGraph.Compiler.Default.Harmonizer<W> param5Harmonizer); Entry<W> inject(Entry<W> param5Entry); MethodGraph.Node asNode(MethodGraph.Compiler.Default.Merger param5Merger); public static class Initial<U> implements Entry<U> { private final MethodGraph.Compiler.Default.Key.Harmonized<U> key; protected Initial(MethodGraph.Compiler.Default.Key.Harmonized<U> key) { this.key = key; } public MethodGraph.Compiler.Default.Key.Harmonized<U> getKey() { throw new IllegalStateException("Cannot extract key from initial entry:" + this); } public Set<MethodDescription> getCandidates() { throw new IllegalStateException("Cannot extract method from initial entry:" + this); } public Visibility getVisibility() { throw new IllegalStateException("Cannot extract visibility from initial entry:" + this); } public MethodGraph.Compiler.Default.Key.Store.Entry<U> extendBy(MethodDescription methodDescription, MethodGraph.Compiler.Default.Harmonizer<U> harmonizer) { return new MethodGraph.Compiler.Default.Key.Store.Entry.Resolved<U>(this.key.extend((MethodDescription.InDefinedShape)methodDescription.asDefined(), harmonizer), methodDescription, methodDescription.getVisibility(), false); } public MethodGraph.Compiler.Default.Key.Store.Entry<U> inject(MethodGraph.Compiler.Default.Key.Store.Entry<U> entry) { throw new IllegalStateException("Cannot inject into initial entry without a registered method: " + this); } public MethodGraph.Node asNode(MethodGraph.Compiler.Default.Merger merger) { throw new IllegalStateException("Cannot transform initial entry without a registered method: " + this); } public int hashCode() { return this.key.hashCode(); } public boolean equals(@MaybeNull Object other) { if (this == other) return true;  if (other == null || getClass() != other.getClass()) return false;  Initial<?> initial = (Initial)other; return this.key.equals(initial.key); } } @Enhance public static class Resolved<U> implements Entry<U> { private static final int MADE_VISIBLE = 5; private static final boolean NOT_MADE_VISIBLE = false; private final MethodGraph.Compiler.Default.Key.Harmonized<U> key; private final MethodDescription methodDescription; private final Visibility visibility; private final boolean madeVisible; protected Resolved(MethodGraph.Compiler.Default.Key.Harmonized<U> key, MethodDescription methodDescription, Visibility visibility) { this(key, methodDescription, visibility, false); } protected Resolved(MethodGraph.Compiler.Default.Key.Harmonized<U> key, MethodDescription methodDescription, Visibility visibility, boolean madeVisible) { this.key = key; this.methodDescription = methodDescription; this.visibility = visibility; this.madeVisible = madeVisible; } private static <V> MethodGraph.Compiler.Default.Key.Store.Entry<V> of(MethodGraph.Compiler.Default.Key.Harmonized<V> key, MethodDescription override, MethodDescription original, Visibility visibility) { visibility = visibility.expandTo(original.getVisibility()).expandTo(override.getVisibility()); if (override.isBridge()) {  } else {  }  return new Resolved<V>(key, override, visibility, false); } public MethodGraph.Compiler.Default.Key.Harmonized<U> getKey() { return this.key; } public Set<MethodDescription> getCandidates() { return Collections.singleton(this.methodDescription); } public Visibility getVisibility() { return this.visibility; } public MethodGraph.Compiler.Default.Key.Store.Entry<U> extendBy(MethodDescription methodDescription, MethodGraph.Compiler.Default.Harmonizer<U> harmonizer) { MethodGraph.Compiler.Default.Key.Harmonized<U> key = this.key.extend((MethodDescription.InDefinedShape)methodDescription.asDefined(), harmonizer); Visibility visibility = this.visibility.expandTo(methodDescription.getVisibility()); return methodDescription.getDeclaringType().equals(this.methodDescription.getDeclaringType()) ? MethodGraph.Compiler.Default.Key.Store.Entry.Ambiguous.<U>of(key, methodDescription, this.methodDescription, visibility) : of(key, methodDescription, this.methodDescription, visibility); } public MethodGraph.Compiler.Default.Key.Store.Entry<U> inject(MethodGraph.Compiler.Default.Key.Store.Entry<U> entry) { if (this.methodDescription.getDeclaringType().isInterface()) { LinkedHashSet<MethodDescription> candidates = new LinkedHashSet<MethodDescription>(); candidates.add(this.methodDescription); TypeDescription target = this.methodDescription.getDeclaringType().asErasure(); for (MethodDescription methodDescription : entry.getCandidates()) { if (methodDescription.getDeclaringType().asErasure().isAssignableTo(target)) { candidates.remove(this.methodDescription); candidates.add(methodDescription); continue; }  if (!methodDescription.getDeclaringType().asErasure().isAssignableFrom(target)) candidates.add(methodDescription);  }  return (candidates.size() == 1) ? new Resolved(this.key.combineWith(entry.getKey()), candidates.iterator().next(), this.visibility.expandTo(entry.getVisibility()), this.madeVisible) : new MethodGraph.Compiler.Default.Key.Store.Entry.Ambiguous<U>(this.key.combineWith(entry.getKey()), candidates, this.visibility.expandTo(entry.getVisibility())); }  return new Resolved(this.key.combineWith(entry.getKey()), this.methodDescription, this.visibility.expandTo(entry.getVisibility()), this.madeVisible); } public MethodGraph.Node asNode(MethodGraph.Compiler.Default.Merger merger) { return new Node(this.key.detach(this.methodDescription.asTypeToken()), this.methodDescription, this.visibility, this.madeVisible); } public boolean equals(@MaybeNull Object param6Object) { return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : ((this.madeVisible != ((Resolved)param6Object).madeVisible) ? false : (!this.visibility.equals(((Resolved)param6Object).visibility) ? false : (!this.key.equals(((Resolved)param6Object).key) ? false : (!!this.methodDescription.equals(((Resolved)param6Object).methodDescription))))))); } public int hashCode() { return (((getClass().hashCode() * 31 + this.key.hashCode()) * 31 + this.methodDescription.hashCode()) * 31 + this.visibility.hashCode()) * 31 + this.madeVisible; } @Enhance protected static class Node implements MethodGraph.Node { private final MethodGraph.Compiler.Default.Key.Detached key; private final MethodDescription methodDescription; private final Visibility visibility; private final boolean visible; protected Node(MethodGraph.Compiler.Default.Key.Detached key, MethodDescription methodDescription, Visibility visibility, boolean visible) { this.key = key; this.methodDescription = methodDescription; this.visibility = visibility; this.visible = visible; } public MethodGraph.Node.Sort getSort() { return this.visible ? MethodGraph.Node.Sort.VISIBLE : MethodGraph.Node.Sort.RESOLVED; } public MethodDescription getRepresentative() { return this.methodDescription; } public Set<MethodDescription.TypeToken> getMethodTypes() { return this.key.getIdentifiers(); } public Visibility getVisibility() { return this.visibility; } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : ((this.visible != ((Node)param7Object).visible) ? false : (!this.visibility.equals(((Node)param7Object).visibility) ? false : (!this.key.equals(((Node)param7Object).key) ? false : (!!this.methodDescription.equals(((Node)param7Object).methodDescription))))))); } public int hashCode() { return (((getClass().hashCode() * 31 + this.key.hashCode()) * 31 + this.methodDescription.hashCode()) * 31 + this.visibility.hashCode()) * 31 + this.visible; } } } @Enhance public static class Ambiguous<U> implements Entry<U> { private final MethodGraph.Compiler.Default.Key.Harmonized<U> key; private final LinkedHashSet<MethodDescription> methodDescriptions; private final Visibility visibility; protected Ambiguous(MethodGraph.Compiler.Default.Key.Harmonized<U> key, LinkedHashSet<MethodDescription> methodDescriptions, Visibility visibility) { this.key = key; this.methodDescriptions = methodDescriptions; this.visibility = visibility; } protected static <Q> MethodGraph.Compiler.Default.Key.Store.Entry<Q> of(MethodGraph.Compiler.Default.Key.Harmonized<Q> key, MethodDescription left, MethodDescription right, Visibility visibility) { visibility = visibility.expandTo(left.getVisibility()).expandTo(right.getVisibility()); if ((left.isBridge() ^ right.isBridge()) != 0) {  } else {  }  return new Ambiguous<Q>(key, new LinkedHashSet<MethodDescription>(Arrays.asList(new MethodDescription[] { left, right }, )), visibility); } public MethodGraph.Compiler.Default.Key.Harmonized<U> getKey() { return this.key; } public Set<MethodDescription> getCandidates() { return this.methodDescriptions; } public Visibility getVisibility() { return this.visibility; } public MethodGraph.Compiler.Default.Key.Store.Entry<U> extendBy(MethodDescription methodDescription, MethodGraph.Compiler.Default.Harmonizer<U> harmonizer) { MethodGraph.Compiler.Default.Key.Harmonized<U> key = this.key.extend((MethodDescription.InDefinedShape)methodDescription.asDefined(), harmonizer); LinkedHashSet<MethodDescription> methodDescriptions = new LinkedHashSet<MethodDescription>(); TypeDescription declaringType = methodDescription.getDeclaringType().asErasure(); boolean bridge = methodDescription.isBridge(); Visibility visibility = this.visibility; for (MethodDescription extendedMethod : this.methodDescriptions) { if (extendedMethod.getDeclaringType().asErasure().equals(declaringType)) if (extendedMethod.isBridge() ^ bridge) { methodDescriptions.add(bridge ? extendedMethod : methodDescription); } else { methodDescriptions.add(methodDescription); methodDescriptions.add(extendedMethod); }   visibility = visibility.expandTo(extendedMethod.getVisibility()); }  if (methodDescriptions.isEmpty()) return new MethodGraph.Compiler.Default.Key.Store.Entry.Resolved<U>(key, methodDescription, visibility, bridge);  if (methodDescriptions.size() == 1) return new MethodGraph.Compiler.Default.Key.Store.Entry.Resolved<U>(key, methodDescriptions.iterator().next(), visibility, false);  return new Ambiguous(key, methodDescriptions, visibility); } public MethodGraph.Compiler.Default.Key.Store.Entry<U> inject(MethodGraph.Compiler.Default.Key.Store.Entry<U> entry) { LinkedHashSet<MethodDescription> methodDescriptions = new LinkedHashSet<MethodDescription>(); label32: for (MethodDescription methodDescription : this.methodDescriptions) { TypeDescription target = methodDescription.getDeclaringType().asErasure(); for (MethodDescription candidate : entry.getCandidates()) { TypeDescription typeDescription = candidate.getDeclaringType().asErasure(); if (!typeDescription.equals(target) && typeDescription.isAssignableTo(target)) continue label32;  }  methodDescriptions.add(methodDescription); }  label31: for (MethodDescription candidate : entry.getCandidates()) { TypeDescription target = candidate.getDeclaringType().asErasure(); for (MethodDescription methodDescription : this.methodDescriptions) { if (methodDescription.getDeclaringType().asErasure().isAssignableTo(target)) continue label31;  }  methodDescriptions.add(candidate); }  return (methodDescriptions.size() == 1) ? new MethodGraph.Compiler.Default.Key.Store.Entry.Resolved<U>(this.key.combineWith(entry.getKey()), methodDescriptions.iterator().next(), this.visibility.expandTo(entry.getVisibility())) : new Ambiguous(this.key.combineWith(entry.getKey()), methodDescriptions, this.visibility.expandTo(entry.getVisibility())); } public MethodGraph.Node asNode(MethodGraph.Compiler.Default.Merger merger) { Iterator<MethodDescription> iterator = this.methodDescriptions.iterator(); MethodDescription methodDescription = iterator.next(); while (iterator.hasNext()) methodDescription = merger.merge(methodDescription, iterator.next());  return new Node(this.key.detach(methodDescription.asTypeToken()), methodDescription, this.visibility); } public boolean equals(@MaybeNull Object param6Object) { return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : (!this.visibility.equals(((Ambiguous)param6Object).visibility) ? false : (!this.key.equals(((Ambiguous)param6Object).key) ? false : (!!this.methodDescriptions.equals(((Ambiguous)param6Object).methodDescriptions)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.key.hashCode()) * 31 + this.methodDescriptions.hashCode()) * 31 + this.visibility.hashCode(); } @Enhance protected static class Node implements MethodGraph.Node { private final MethodGraph.Compiler.Default.Key.Detached key; private final MethodDescription methodDescription; private final Visibility visibility; protected Node(MethodGraph.Compiler.Default.Key.Detached key, MethodDescription methodDescription, Visibility visibility) { this.key = key; this.methodDescription = methodDescription; this.visibility = visibility; } public MethodGraph.Node.Sort getSort() { return MethodGraph.Node.Sort.AMBIGUOUS; } public MethodDescription getRepresentative() { return this.methodDescription; } public Set<MethodDescription.TypeToken> getMethodTypes() { return this.key.getIdentifiers(); } public Visibility getVisibility() { return this.visibility; } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.visibility.equals(((Node)param7Object).visibility) ? false : (!this.key.equals(((Node)param7Object).key) ? false : (!!this.methodDescription.equals(((Node)param7Object).methodDescription)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.key.hashCode()) * 31 + this.methodDescription.hashCode()) * 31 + this.visibility.hashCode(); } } } } @Enhance public static class Ambiguous<U> implements Entry<U> { private final MethodGraph.Compiler.Default.Key.Harmonized<U> key; private final LinkedHashSet<MethodDescription> methodDescriptions; private final Visibility visibility; protected Ambiguous(MethodGraph.Compiler.Default.Key.Harmonized<U> key, LinkedHashSet<MethodDescription> methodDescriptions, Visibility visibility) { this.key = key; this.methodDescriptions = methodDescriptions; this.visibility = visibility; } protected static <Q> MethodGraph.Compiler.Default.Key.Store.Entry<Q> of(MethodGraph.Compiler.Default.Key.Harmonized<Q> key, MethodDescription left, MethodDescription right, Visibility visibility) { visibility = visibility.expandTo(left.getVisibility()).expandTo(right.getVisibility()); if ((left.isBridge() ^ right.isBridge()) != 0) {  } else {  }  return new Ambiguous<Q>(key, new LinkedHashSet<MethodDescription>(Arrays.asList(new MethodDescription[] { left, right }, )), visibility); } public MethodGraph.Compiler.Default.Key.Harmonized<U> getKey() { return this.key; } public Set<MethodDescription> getCandidates() { return this.methodDescriptions; } public Visibility getVisibility() { return this.visibility; } public MethodGraph.Compiler.Default.Key.Store.Entry<U> extendBy(MethodDescription methodDescription, MethodGraph.Compiler.Default.Harmonizer<U> harmonizer) { MethodGraph.Compiler.Default.Key.Harmonized<U> key = this.key.extend((MethodDescription.InDefinedShape)methodDescription.asDefined(), harmonizer); LinkedHashSet<MethodDescription> methodDescriptions = new LinkedHashSet<MethodDescription>(); TypeDescription declaringType = methodDescription.getDeclaringType().asErasure(); boolean bridge = methodDescription.isBridge(); Visibility visibility = this.visibility; for (MethodDescription extendedMethod : this.methodDescriptions) { if (extendedMethod.getDeclaringType().asErasure().equals(declaringType)) if (extendedMethod.isBridge() ^ bridge) { methodDescriptions.add(bridge ? extendedMethod : methodDescription); } else { methodDescriptions.add(methodDescription); methodDescriptions.add(extendedMethod); }   visibility = visibility.expandTo(extendedMethod.getVisibility()); }  if (methodDescriptions.isEmpty()) return new MethodGraph.Compiler.Default.Key.Store.Entry.Resolved<U>(key, methodDescription, visibility, bridge);  if (methodDescriptions.size() == 1) return new MethodGraph.Compiler.Default.Key.Store.Entry.Resolved<U>(key, methodDescriptions.iterator().next(), visibility, false);  return new Ambiguous(key, methodDescriptions, visibility); } public MethodGraph.Compiler.Default.Key.Store.Entry<U> inject(MethodGraph.Compiler.Default.Key.Store.Entry<U> entry) { LinkedHashSet<MethodDescription> methodDescriptions = new LinkedHashSet<MethodDescription>(); label32: for (MethodDescription methodDescription : this.methodDescriptions) { TypeDescription target = methodDescription.getDeclaringType().asErasure(); for (MethodDescription candidate : entry.getCandidates()) { TypeDescription typeDescription = candidate.getDeclaringType().asErasure(); if (!typeDescription.equals(target) && typeDescription.isAssignableTo(target)) continue label32;  }  methodDescriptions.add(methodDescription); }  label31: for (MethodDescription candidate : entry.getCandidates()) { TypeDescription target = candidate.getDeclaringType().asErasure(); for (MethodDescription methodDescription : this.methodDescriptions) { if (methodDescription.getDeclaringType().asErasure().isAssignableTo(target)) continue label31;  }  methodDescriptions.add(candidate); }  return (methodDescriptions.size() == 1) ? new MethodGraph.Compiler.Default.Key.Store.Entry.Resolved<U>(this.key.combineWith(entry.getKey()), methodDescriptions.iterator().next(), this.visibility.expandTo(entry.getVisibility())) : new Ambiguous(this.key.combineWith(entry.getKey()), methodDescriptions, this.visibility.expandTo(entry.getVisibility())); } public MethodGraph.Node asNode(MethodGraph.Compiler.Default.Merger merger) { Iterator<MethodDescription> iterator = this.methodDescriptions.iterator(); MethodDescription methodDescription = iterator.next(); while (iterator.hasNext()) methodDescription = merger.merge(methodDescription, iterator.next());  return new Node(this.key.detach(methodDescription.asTypeToken()), methodDescription, this.visibility); } public boolean equals(@MaybeNull Object param5Object) { return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!this.visibility.equals(((Ambiguous)param5Object).visibility) ? false : (!this.key.equals(((Ambiguous)param5Object).key) ? false : (!!this.methodDescriptions.equals(((Ambiguous)param5Object).methodDescriptions)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.key.hashCode()) * 31 + this.methodDescriptions.hashCode()) * 31 + this.visibility.hashCode(); } @Enhance protected static class Node implements MethodGraph.Node { private final MethodGraph.Compiler.Default.Key.Detached key; private final MethodDescription methodDescription; private final Visibility visibility; protected Node(MethodGraph.Compiler.Default.Key.Detached key, MethodDescription methodDescription, Visibility visibility) { this.key = key; this.methodDescription = methodDescription; this.visibility = visibility; } public MethodGraph.Node.Sort getSort() { return MethodGraph.Node.Sort.AMBIGUOUS; } public MethodDescription getRepresentative() { return this.methodDescription; } public Set<MethodDescription.TypeToken> getMethodTypes() { return this.key.getIdentifiers(); } public Visibility getVisibility() { return this.visibility; } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.visibility.equals(((Node)param7Object).visibility) ? false : (!this.key.equals(((Node)param7Object).key) ? false : (!!this.methodDescription.equals(((Node)param7Object).methodDescription)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.key.hashCode()) * 31 + this.methodDescription.hashCode()) * 31 + this.visibility.hashCode(); } } } @Enhance protected static class Graph implements MethodGraph { public MethodGraph.NodeList listNodes() { return new MethodGraph.NodeList(new ArrayList<MethodGraph.Node>(this.entries.values())); }
/*      */           
/*      */           private final LinkedHashMap<MethodGraph.Compiler.Default.Key<MethodDescription.TypeToken>, MethodGraph.Node> entries;
/*      */           
/*      */           protected Graph(LinkedHashMap<MethodGraph.Compiler.Default.Key<MethodDescription.TypeToken>, MethodGraph.Node> entries) {
/*      */             this.entries = entries;
/*      */           }
/*      */           
/*      */           public MethodGraph.Node locate(MethodDescription.SignatureToken token) {
/*      */             MethodGraph.Node node = this.entries.get(MethodGraph.Compiler.Default.Key.Detached.of(token));
/*      */             return (node == null) ? MethodGraph.Node.Unresolved.INSTANCE : node;
/*      */           }
/*      */           
/*      */           public boolean equals(@MaybeNull Object param5Object) {
/*      */             return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.entries.equals(((Graph)param5Object).entries))));
/*      */           }
/*      */           
/*      */           public int hashCode() {
/*      */             return getClass().hashCode() * 31 + this.entries.hashCode();
/*      */           } } } } }
/*      */   
/*      */   public static class NodeList extends FilterableList.AbstractBase<Node, NodeList> { private final List<? extends MethodGraph.Node> nodes;
/*      */     
/*      */     public NodeList(List<? extends MethodGraph.Node> nodes) {
/* 1910 */       this.nodes = nodes;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodGraph.Node get(int index) {
/* 1917 */       return this.nodes.get(index);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int size() {
/* 1924 */       return this.nodes.size();
/*      */     }
/*      */ 
/*      */     
/*      */     protected NodeList wrap(List<MethodGraph.Node> values) {
/* 1929 */       return new NodeList(values);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodList<?> asMethodList() {
/* 1938 */       List<MethodDescription> methodDescriptions = new ArrayList<MethodDescription>(size());
/* 1939 */       for (MethodGraph.Node node : this.nodes) {
/* 1940 */         methodDescriptions.add(node.getRepresentative());
/*      */       }
/* 1942 */       return (MethodList<?>)new MethodList.Explicit(methodDescriptions);
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static class Simple
/*      */     implements MethodGraph
/*      */   {
/*      */     private final LinkedHashMap<MethodDescription.SignatureToken, MethodGraph.Node> nodes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Simple(LinkedHashMap<MethodDescription.SignatureToken, MethodGraph.Node> nodes) {
/* 1963 */       this.nodes = nodes;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static MethodGraph of(List<? extends MethodDescription> methodDescriptions) {
/* 1973 */       LinkedHashMap<MethodDescription.SignatureToken, MethodGraph.Node> nodes = new LinkedHashMap<MethodDescription.SignatureToken, MethodGraph.Node>();
/* 1974 */       for (MethodDescription methodDescription : methodDescriptions) {
/* 1975 */         nodes.put(methodDescription.asSignatureToken(), new MethodGraph.Node.Simple(methodDescription));
/*      */       }
/* 1977 */       return new Simple(nodes);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodGraph.Node locate(MethodDescription.SignatureToken token) {
/* 1984 */       MethodGraph.Node node = this.nodes.get(token);
/* 1985 */       return (node == null) ? MethodGraph.Node.Unresolved.INSTANCE : node;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodGraph.NodeList listNodes() {
/* 1994 */       return new MethodGraph.NodeList(new ArrayList<MethodGraph.Node>(this.nodes.values()));
/*      */     }
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.nodes.equals(((Simple)param1Object).nodes))));
/*      */     }
/*      */     
/*      */     public int hashCode() {
/*      */       return getClass().hashCode() * 31 + this.nodes.hashCode();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\scaffold\MethodGraph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */