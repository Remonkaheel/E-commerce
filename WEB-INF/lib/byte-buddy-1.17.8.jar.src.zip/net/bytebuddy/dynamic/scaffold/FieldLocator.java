/*     */ package net.bytebuddy.dynamic.scaffold;
/*     */ 
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.field.FieldList;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface FieldLocator
/*     */ {
/*     */   Resolution locate(String paramString);
/*     */   
/*     */   Resolution locate(String paramString, TypeDescription paramTypeDescription);
/*     */   
/*     */   public static interface Resolution
/*     */   {
/*     */     boolean isResolved();
/*     */     
/*     */     FieldDescription getField();
/*     */     
/*     */     public enum Illegal
/*     */       implements Resolution
/*     */     {
/*  78 */       INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean isResolved() {
/*  84 */         return false;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public FieldDescription getField() {
/*  91 */         throw new IllegalStateException("Could not locate field");
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     public static class Simple
/*     */       implements Resolution
/*     */     {
/*     */       private final FieldDescription fieldDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected Simple(FieldDescription fieldDescription) {
/* 112 */         this.fieldDescription = fieldDescription;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public static FieldLocator.Resolution ofBeanAccessor(FieldLocator fieldLocator, MethodDescription methodDescription) {
/*     */         String name;
/* 125 */         if (ElementMatchers.isSetter().matches(methodDescription)) {
/* 126 */           name = methodDescription.getInternalName().substring(3);
/* 127 */         } else if (ElementMatchers.isGetter().matches(methodDescription)) {
/* 128 */           name = methodDescription.getInternalName().substring(methodDescription.getInternalName().startsWith("is") ? 2 : 3);
/*     */         } else {
/* 130 */           return FieldLocator.Resolution.Illegal.INSTANCE;
/*     */         } 
/* 132 */         FieldLocator.Resolution resolution = fieldLocator.locate(Character.toLowerCase(name.charAt(0)) + name.substring(1));
/* 133 */         return resolution.isResolved() ? resolution : fieldLocator
/*     */           
/* 135 */           .locate(Character.toUpperCase(name.charAt(0)) + name.substring(1));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean isResolved() {
/* 142 */         return true;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public FieldDescription getField() {
/* 149 */         return this.fieldDescription;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.fieldDescription.equals(((Simple)param2Object).fieldDescription))));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return getClass().hashCode() * 31 + this.fieldDescription.hashCode();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static interface Factory
/*     */   {
/*     */     FieldLocator make(TypeDescription param1TypeDescription);
/*     */   }
/*     */ 
/*     */   
/*     */   public enum NoOp
/*     */     implements FieldLocator, Factory
/*     */   {
/* 176 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldLocator make(TypeDescription typeDescription) {
/* 182 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldLocator.Resolution locate(String name) {
/* 189 */       return FieldLocator.Resolution.Illegal.INSTANCE;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldLocator.Resolution locate(String name, TypeDescription type) {
/* 196 */       return FieldLocator.Resolution.Illegal.INSTANCE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static abstract class AbstractBase
/*     */     implements FieldLocator
/*     */   {
/*     */     protected final TypeDescription accessingType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected AbstractBase(TypeDescription accessingType) {
/* 217 */       this.accessingType = accessingType;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldLocator.Resolution locate(String name) {
/* 224 */       FieldList<?> candidates = locate((ElementMatcher<? super FieldDescription>)ElementMatchers.named(name).and((ElementMatcher)ElementMatchers.isVisibleTo(this.accessingType)));
/* 225 */       return (candidates.size() == 1) ? new FieldLocator.Resolution.Simple((FieldDescription)candidates
/* 226 */           .getOnly()) : FieldLocator.Resolution.Illegal.INSTANCE;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldLocator.Resolution locate(String name, TypeDescription type) {
/* 234 */       FieldList<?> candidates = locate((ElementMatcher<? super FieldDescription>)ElementMatchers.named(name).and((ElementMatcher)ElementMatchers.fieldType(type)).and((ElementMatcher)ElementMatchers.isVisibleTo(this.accessingType)));
/* 235 */       return (candidates.size() == 1) ? new FieldLocator.Resolution.Simple((FieldDescription)candidates
/* 236 */           .getOnly()) : FieldLocator.Resolution.Illegal.INSTANCE;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected abstract FieldList<?> locate(ElementMatcher<? super FieldDescription> param1ElementMatcher);
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.accessingType.equals(((AbstractBase)param1Object).accessingType))));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.accessingType.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class ForExactType
/*     */     extends AbstractBase
/*     */   {
/*     */     private final TypeDescription typeDescription;
/*     */ 
/*     */     
/*     */     public ForExactType(TypeDescription typeDescription) {
/* 266 */       this(typeDescription, typeDescription);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForExactType(TypeDescription typeDescription, TypeDescription accessingType) {
/* 276 */       super(accessingType);
/* 277 */       this.typeDescription = typeDescription;
/*     */     }
/*     */ 
/*     */     
/*     */     protected FieldList<?> locate(ElementMatcher<? super FieldDescription> matcher) {
/* 282 */       return (FieldList)this.typeDescription.getDeclaredFields().filter(matcher);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return !super.equals(param1Object) ? false : ((this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.typeDescription.equals(((ForExactType)param1Object).typeDescription)))));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return super.hashCode() * 31 + this.typeDescription.hashCode();
/*     */     }
/*     */     
/*     */     @Enhance
/*     */     public static class Factory
/*     */       implements FieldLocator.Factory
/*     */     {
/*     */       private final TypeDescription typeDescription;
/*     */       
/*     */       public Factory(TypeDescription typeDescription) {
/* 302 */         this.typeDescription = typeDescription;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public FieldLocator make(TypeDescription typeDescription) {
/* 309 */         return new FieldLocator.ForExactType(this.typeDescription, typeDescription);
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.typeDescription.equals(((Factory)param2Object).typeDescription))));
/*     */       }
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return getClass().hashCode() * 31 + this.typeDescription.hashCode();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @Enhance
/*     */   public static class ForClassHierarchy
/*     */     extends AbstractBase
/*     */   {
/*     */     private final TypeDescription typeDescription;
/*     */     
/*     */     public ForClassHierarchy(TypeDescription typeDescription) {
/* 331 */       this(typeDescription, typeDescription);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForClassHierarchy(TypeDescription typeDescription, TypeDescription accessingType) {
/* 341 */       super(accessingType);
/* 342 */       this.typeDescription = typeDescription;
/*     */     } public boolean equals(@MaybeNull Object param1Object) {
/*     */       return !super.equals(param1Object) ? false : ((this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.typeDescription.equals(((ForClassHierarchy)param1Object).typeDescription)))));
/*     */     }
/*     */     protected FieldList<?> locate(ElementMatcher<? super FieldDescription> matcher) {
/* 347 */       for (TypeDefinition typeDefinition : this.typeDescription) {
/* 348 */         FieldList<?> candidates = (FieldList)typeDefinition.getDeclaredFields().filter(matcher);
/* 349 */         if (!candidates.isEmpty()) {
/* 350 */           return candidates;
/*     */         }
/*     */       } 
/* 353 */       return (FieldList<?>)new FieldList.Empty();
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return super.hashCode() * 31 + this.typeDescription.hashCode();
/*     */     }
/*     */     
/*     */     public enum Factory
/*     */       implements FieldLocator.Factory
/*     */     {
/* 364 */       INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public FieldLocator make(TypeDescription typeDescription) {
/* 370 */         return new FieldLocator.ForClassHierarchy(typeDescription);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ForTopLevelType
/*     */     extends AbstractBase
/*     */   {
/*     */     protected ForTopLevelType(TypeDescription typeDescription) {
/* 386 */       super(typeDescription);
/*     */     }
/*     */ 
/*     */     
/*     */     protected FieldList<?> locate(ElementMatcher<? super FieldDescription> matcher) {
/* 391 */       return (FieldList)this.accessingType.getDeclaredFields().filter(matcher);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public enum Factory
/*     */       implements FieldLocator.Factory
/*     */     {
/* 402 */       INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public FieldLocator make(TypeDescription typeDescription) {
/* 408 */         return new FieldLocator.ForTopLevelType(typeDescription);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\scaffold\FieldLocator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */