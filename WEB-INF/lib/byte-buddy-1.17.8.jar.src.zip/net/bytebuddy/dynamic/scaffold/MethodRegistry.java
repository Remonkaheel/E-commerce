/*      */ package net.bytebuddy.dynamic.scaffold;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import net.bytebuddy.ClassFileVersion;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*      */ import net.bytebuddy.description.annotation.AnnotationValue;
/*      */ import net.bytebuddy.description.method.MethodDescription;
/*      */ import net.bytebuddy.description.method.MethodList;
/*      */ import net.bytebuddy.description.modifier.Visibility;
/*      */ import net.bytebuddy.description.type.TypeDefinition;
/*      */ import net.bytebuddy.description.type.TypeDescription;
/*      */ import net.bytebuddy.dynamic.Transformer;
/*      */ import net.bytebuddy.dynamic.VisibilityBridgeStrategy;
/*      */ import net.bytebuddy.implementation.Implementation;
/*      */ import net.bytebuddy.implementation.LoadedTypeInitializer;
/*      */ import net.bytebuddy.implementation.attribute.MethodAttributeAppender;
/*      */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*      */ import net.bytebuddy.matcher.ElementMatcher;
/*      */ import net.bytebuddy.matcher.ElementMatchers;
/*      */ import net.bytebuddy.matcher.LatentMatcher;
/*      */ import net.bytebuddy.utility.CompoundList;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface MethodRegistry
/*      */ {
/*      */   MethodRegistry prepend(LatentMatcher<? super MethodDescription> paramLatentMatcher, Handler paramHandler, MethodAttributeAppender.Factory paramFactory, Transformer<MethodDescription> paramTransformer);
/*      */   
/*      */   MethodRegistry append(LatentMatcher<? super MethodDescription> paramLatentMatcher, Handler paramHandler, MethodAttributeAppender.Factory paramFactory, Transformer<MethodDescription> paramTransformer);
/*      */   
/*      */   Prepared prepare(InstrumentedType paramInstrumentedType, MethodGraph.Compiler paramCompiler, TypeValidation paramTypeValidation, VisibilityBridgeStrategy paramVisibilityBridgeStrategy, LatentMatcher<? super MethodDescription> paramLatentMatcher);
/*      */   
/*      */   public static interface Handler
/*      */     extends InstrumentedType.Prepareable
/*      */   {
/*      */     Compiled compile(Implementation.Target param1Target);
/*      */     
/*      */     public enum ForAbstractMethod
/*      */       implements Handler, Compiled
/*      */     {
/*  110 */       INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public InstrumentedType prepare(InstrumentedType instrumentedType) {
/*  116 */         return instrumentedType;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodRegistry.Handler.Compiled compile(Implementation.Target implementationTarget) {
/*  123 */         return this;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeWriter.MethodPool.Record assemble(MethodDescription methodDescription, MethodAttributeAppender attributeAppender, Visibility visibility) {
/*  130 */         return new TypeWriter.MethodPool.Record.ForDefinedMethod.WithoutBody(methodDescription, attributeAppender, visibility);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public enum ForVisibilityBridge
/*      */       implements Handler
/*      */     {
/*  142 */       INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public InstrumentedType prepare(InstrumentedType instrumentedType) {
/*  148 */         throw new IllegalStateException("A visibility bridge handler must not apply any preparations");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Compiled compile(Implementation.Target implementationTarget) {
/*  155 */         return new Compiled(implementationTarget.getInstrumentedType());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       protected static class Compiled
/*      */         implements MethodRegistry.Handler.Compiled
/*      */       {
/*      */         private final TypeDescription instrumentedType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected Compiled(TypeDescription instrumentedType) {
/*  175 */           this.instrumentedType = instrumentedType;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TypeWriter.MethodPool.Record assemble(MethodDescription methodDescription, MethodAttributeAppender attributeAppender, Visibility visibility) {
/*  182 */           return TypeWriter.MethodPool.Record.ForDefinedMethod.OfVisibilityBridge.of(this.instrumentedType, methodDescription, attributeAppender);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.instrumentedType.equals(((Compiled)param3Object).instrumentedType))));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return getClass().hashCode() * 31 + this.instrumentedType.hashCode();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static interface Compiled
/*      */     {
/*      */       TypeWriter.MethodPool.Record assemble(MethodDescription param2MethodDescription, MethodAttributeAppender param2MethodAttributeAppender, Visibility param2Visibility);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class ForImplementation
/*      */       implements Handler
/*      */     {
/*      */       private final Implementation implementation;
/*      */ 
/*      */ 
/*      */       
/*      */       public ForImplementation(Implementation implementation) {
/*  220 */         this.implementation = implementation;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public InstrumentedType prepare(InstrumentedType instrumentedType) {
/*  227 */         return this.implementation.prepare(instrumentedType);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Compiled compile(Implementation.Target implementationTarget) {
/*  234 */         return new Compiled(this.implementation.appender(implementationTarget));
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.implementation.equals(((ForImplementation)param2Object).implementation))));
/*      */       }
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return getClass().hashCode() * 31 + this.implementation.hashCode();
/*      */       }
/*      */       
/*      */       @Enhance
/*      */       protected static class Compiled
/*      */         implements MethodRegistry.Handler.Compiled
/*      */       {
/*      */         private final ByteCodeAppender byteCodeAppender;
/*      */         
/*      */         protected Compiled(ByteCodeAppender byteCodeAppender) {
/*  254 */           this.byteCodeAppender = byteCodeAppender;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public TypeWriter.MethodPool.Record assemble(MethodDescription methodDescription, MethodAttributeAppender attributeAppender, Visibility visibility) {
/*  261 */           return new TypeWriter.MethodPool.Record.ForDefinedMethod.WithBody(methodDescription, this.byteCodeAppender, attributeAppender, visibility);
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.byteCodeAppender.equals(((Compiled)param3Object).byteCodeAppender))));
/*      */         }
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return getClass().hashCode() * 31 + this.byteCodeAppender.hashCode();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     @Enhance
/*      */     public static class ForAnnotationValue
/*      */       implements Handler, Compiled
/*      */     {
/*      */       private final AnnotationValue<?, ?> annotationValue;
/*      */       
/*      */       public ForAnnotationValue(AnnotationValue<?, ?> annotationValue) {
/*  283 */         this.annotationValue = annotationValue;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public InstrumentedType prepare(InstrumentedType instrumentedType) {
/*  290 */         return instrumentedType;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodRegistry.Handler.Compiled compile(Implementation.Target implementationTarget) {
/*  297 */         return this;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeWriter.MethodPool.Record assemble(MethodDescription methodDescription, MethodAttributeAppender attributeAppender, Visibility visibility) {
/*  304 */         return new TypeWriter.MethodPool.Record.ForDefinedMethod.WithAnnotationDefaultValue(methodDescription, this.annotationValue, attributeAppender);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.annotationValue.equals(((ForAnnotationValue)param2Object).annotationValue))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return getClass().hashCode() * 31 + this.annotationValue.hashCode();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface Prepared
/*      */   {
/*      */     TypeDescription getInstrumentedType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MethodList<?> getMethods();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MethodList<?> getInstrumentedMethods();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     LoadedTypeInitializer getLoadedTypeInitializer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     TypeInitializer getTypeInitializer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MethodRegistry.Compiled compile(Implementation.Target.Factory param1Factory, ClassFileVersion param1ClassFileVersion);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface Compiled
/*      */     extends TypeWriter.MethodPool
/*      */   {
/*      */     TypeDescription getInstrumentedType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MethodList<?> getMethods();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MethodList<?> getInstrumentedMethods();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     LoadedTypeInitializer getLoadedTypeInitializer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     TypeInitializer getTypeInitializer();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static class Default
/*      */     implements MethodRegistry
/*      */   {
/*      */     private final List<Entry> entries;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Default() {
/*  415 */       this.entries = Collections.emptyList();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Default(List<Entry> entries) {
/*  424 */       this.entries = entries;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodRegistry prepend(LatentMatcher<? super MethodDescription> matcher, MethodRegistry.Handler handler, MethodAttributeAppender.Factory attributeAppenderFactory, Transformer<MethodDescription> transformer) {
/*  434 */       return new Default(CompoundList.of(new Entry(matcher, handler, attributeAppenderFactory, transformer), this.entries));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodRegistry append(LatentMatcher<? super MethodDescription> matcher, MethodRegistry.Handler handler, MethodAttributeAppender.Factory attributeAppenderFactory, Transformer<MethodDescription> transformer) {
/*  444 */       return new Default(CompoundList.of(this.entries, new Entry(matcher, handler, attributeAppenderFactory, transformer)));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MethodRegistry.Prepared prepare(InstrumentedType instrumentedType, MethodGraph.Compiler methodGraphCompiler, TypeValidation typeValidation, VisibilityBridgeStrategy visibilityBridgeStrategy, LatentMatcher<? super MethodDescription> ignoredMethods) {
/*  455 */       LinkedHashMap<MethodDescription, Prepared.Entry> implementations = new LinkedHashMap<MethodDescription, Prepared.Entry>();
/*  456 */       Set<MethodRegistry.Handler> handlers = new HashSet<MethodRegistry.Handler>();
/*  457 */       Set<MethodDescription> declaredMethods = new HashSet<MethodDescription>((Collection<? extends MethodDescription>)instrumentedType.getDeclaredMethods());
/*  458 */       for (Entry entry : this.entries) {
/*  459 */         if (handlers.add(entry.getHandler())) {
/*  460 */           InstrumentedType typeDescription = entry.getHandler().prepare(instrumentedType);
/*  461 */           if (instrumentedType != typeDescription) {
/*  462 */             for (MethodDescription methodDescription : typeDescription.getDeclaredMethods()) {
/*  463 */               if (!declaredMethods.contains(methodDescription)) {
/*  464 */                 implementations.put(methodDescription, entry.asSupplementaryEntry(methodDescription));
/*  465 */                 declaredMethods.add(methodDescription);
/*      */               } 
/*      */             } 
/*  468 */             instrumentedType = typeDescription;
/*      */           } 
/*      */         } 
/*      */       } 
/*  472 */       MethodGraph.Linked methodGraph = methodGraphCompiler.compile((TypeDefinition)instrumentedType);
/*      */ 
/*      */ 
/*      */       
/*  476 */       ElementMatcher.Junction junction = ElementMatchers.failSafe((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.anyOf(implementations.keySet())).and((ElementMatcher)ElementMatchers.returns((ElementMatcher)ElementMatchers.isVisibleTo(instrumentedType))).and((ElementMatcher)ElementMatchers.hasParameters((ElementMatcher)ElementMatchers.whereNone((ElementMatcher)ElementMatchers.hasType((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.isVisibleTo(instrumentedType))))))).and(ignoredMethods.resolve(instrumentedType));
/*  477 */       List<MethodDescription> methods = new ArrayList<MethodDescription>();
/*  478 */       for (MethodGraph.Node node : methodGraph.listNodes()) {
/*  479 */         MethodDescription methodDescription = node.getRepresentative();
/*  480 */         boolean visibilityBridge = (instrumentedType.isPublic() && !instrumentedType.isInterface());
/*  481 */         if (junction.matches(methodDescription)) {
/*  482 */           for (Entry entry : this.entries) {
/*  483 */             if (entry.resolve(instrumentedType).matches(methodDescription)) {
/*  484 */               implementations.put(methodDescription, entry.asPreparedEntry(instrumentedType, methodDescription, node
/*      */                     
/*  486 */                     .getMethodTypes(), node
/*  487 */                     .getVisibility()));
/*  488 */               visibilityBridge = false;
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         }
/*  493 */         if (visibilityBridge && 
/*  494 */           !node.getSort().isMadeVisible() && methodDescription
/*  495 */           .isPublic() && 
/*  496 */           !methodDescription.isAbstract() && !methodDescription.isFinal() && methodDescription
/*  497 */           .getDeclaringType().isPackagePrivate() && visibilityBridgeStrategy
/*  498 */           .generateVisibilityBridge(methodDescription))
/*      */         {
/*  500 */           implementations.put(methodDescription, Prepared.Entry.forVisibilityBridge(methodDescription, node.getVisibility()));
/*      */         }
/*  502 */         methods.add(methodDescription);
/*      */       } 
/*  504 */       for (MethodDescription methodDescription : CompoundList.of((List)instrumentedType
/*  505 */           .getDeclaredMethods().filter((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.isVirtual()).and((ElementMatcher)junction)), new MethodDescription.Latent.TypeInitializer(instrumentedType))) {
/*      */         
/*  507 */         for (Entry entry : this.entries) {
/*  508 */           if (entry.resolve(instrumentedType).matches(methodDescription)) {
/*  509 */             implementations.put(methodDescription, entry.asPreparedEntry(instrumentedType, methodDescription, methodDescription.getVisibility()));
/*      */             break;
/*      */           } 
/*      */         } 
/*  513 */         methods.add(methodDescription);
/*      */       } 
/*  515 */       return new Prepared(implementations, instrumentedType
/*  516 */           .getLoadedTypeInitializer(), instrumentedType
/*  517 */           .getTypeInitializer(), 
/*  518 */           typeValidation.isEnabled() ? instrumentedType
/*  519 */           .validated() : instrumentedType, methodGraph, (MethodList<?>)new MethodList.Explicit(methods));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.entries.equals(((Default)param1Object).entries))));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return getClass().hashCode() * 31 + this.entries.hashCode();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     protected static class Entry
/*      */       implements LatentMatcher<MethodDescription>
/*      */     {
/*      */       private final LatentMatcher<? super MethodDescription> matcher;
/*      */ 
/*      */ 
/*      */       
/*      */       private final MethodRegistry.Handler handler;
/*      */ 
/*      */ 
/*      */       
/*      */       private final MethodAttributeAppender.Factory attributeAppenderFactory;
/*      */ 
/*      */ 
/*      */       
/*      */       private final Transformer<MethodDescription> transformer;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected Entry(LatentMatcher<? super MethodDescription> matcher, MethodRegistry.Handler handler, MethodAttributeAppender.Factory attributeAppenderFactory, Transformer<MethodDescription> transformer) {
/*  563 */         this.matcher = matcher;
/*  564 */         this.handler = handler;
/*  565 */         this.attributeAppenderFactory = attributeAppenderFactory;
/*  566 */         this.transformer = transformer;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected MethodRegistry.Default.Prepared.Entry asPreparedEntry(TypeDescription instrumentedType, MethodDescription methodDescription, Visibility visibility) {
/*  578 */         return asPreparedEntry(instrumentedType, methodDescription, Collections.emptySet(), visibility);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected MethodRegistry.Default.Prepared.Entry asPreparedEntry(TypeDescription instrumentedType, MethodDescription methodDescription, Set<MethodDescription.TypeToken> methodTypes, Visibility visibility) {
/*  594 */         return new MethodRegistry.Default.Prepared.Entry(this.handler, this.attributeAppenderFactory, (MethodDescription)this.transformer
/*      */             
/*  596 */             .transform(instrumentedType, methodDescription), methodTypes, visibility, false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected MethodRegistry.Default.Prepared.Entry asSupplementaryEntry(MethodDescription methodDescription) {
/*  609 */         return new MethodRegistry.Default.Prepared.Entry(this.handler, 
/*  610 */             MethodAttributeAppender.Explicit.of(methodDescription), methodDescription, 
/*      */             
/*  612 */             Collections.emptySet(), methodDescription
/*  613 */             .getVisibility(), false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected MethodRegistry.Handler getHandler() {
/*  623 */         return this.handler;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ElementMatcher<? super MethodDescription> resolve(TypeDescription typeDescription) {
/*  630 */         return this.matcher.resolve(typeDescription);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.matcher.equals(((Entry)param2Object).matcher) ? false : (!this.handler.equals(((Entry)param2Object).handler) ? false : (!this.attributeAppenderFactory.equals(((Entry)param2Object).attributeAppenderFactory) ? false : (!!this.transformer.equals(((Entry)param2Object).transformer)))))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return (((getClass().hashCode() * 31 + this.matcher.hashCode()) * 31 + this.handler.hashCode()) * 31 + this.attributeAppenderFactory.hashCode()) * 31 + this.transformer.hashCode();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     protected static class Prepared
/*      */       implements MethodRegistry.Prepared
/*      */     {
/*      */       private final LinkedHashMap<MethodDescription, Entry> implementations;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final LoadedTypeInitializer loadedTypeInitializer;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final TypeInitializer typeInitializer;
/*      */ 
/*      */ 
/*      */       
/*      */       private final TypeDescription instrumentedType;
/*      */ 
/*      */ 
/*      */       
/*      */       private final MethodGraph.Linked methodGraph;
/*      */ 
/*      */ 
/*      */       
/*      */       private final MethodList<?> methods;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected Prepared(LinkedHashMap<MethodDescription, Entry> implementations, LoadedTypeInitializer loadedTypeInitializer, TypeInitializer typeInitializer, TypeDescription instrumentedType, MethodGraph.Linked methodGraph, MethodList<?> methods) {
/*  686 */         this.implementations = implementations;
/*  687 */         this.loadedTypeInitializer = loadedTypeInitializer;
/*  688 */         this.typeInitializer = typeInitializer;
/*  689 */         this.instrumentedType = instrumentedType;
/*  690 */         this.methodGraph = methodGraph;
/*  691 */         this.methods = methods;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeDescription getInstrumentedType() {
/*  698 */         return this.instrumentedType;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public LoadedTypeInitializer getLoadedTypeInitializer() {
/*  705 */         return this.loadedTypeInitializer;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeInitializer getTypeInitializer() {
/*  712 */         return this.typeInitializer;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodList<?> getMethods() {
/*  719 */         return this.methods;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodList<?> getInstrumentedMethods() {
/*  726 */         return (MethodList)(new MethodList.Explicit(new ArrayList(this.implementations.keySet()))).filter((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.isTypeInitializer()));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodRegistry.Compiled compile(Implementation.Target.Factory implementationTargetFactory, ClassFileVersion classFileVersion) {
/*  733 */         Map<MethodRegistry.Handler, MethodRegistry.Handler.Compiled> compilationCache = new HashMap<MethodRegistry.Handler, MethodRegistry.Handler.Compiled>();
/*  734 */         Map<MethodAttributeAppender.Factory, MethodAttributeAppender> attributeAppenderCache = new HashMap<MethodAttributeAppender.Factory, MethodAttributeAppender>();
/*  735 */         LinkedHashMap<MethodDescription, MethodRegistry.Default.Compiled.Entry> entries = new LinkedHashMap<MethodDescription, MethodRegistry.Default.Compiled.Entry>();
/*  736 */         Implementation.Target implementationTarget = implementationTargetFactory.make(this.instrumentedType, this.methodGraph, classFileVersion);
/*  737 */         for (Map.Entry<MethodDescription, Entry> entry : this.implementations.entrySet()) {
/*  738 */           MethodRegistry.Handler.Compiled cachedHandler = compilationCache.get(((Entry)entry.getValue()).getHandler());
/*  739 */           if (cachedHandler == null) {
/*  740 */             cachedHandler = ((Entry)entry.getValue()).getHandler().compile(implementationTarget);
/*  741 */             compilationCache.put(((Entry)entry.getValue()).getHandler(), cachedHandler);
/*      */           } 
/*  743 */           MethodAttributeAppender cachedAttributeAppender = attributeAppenderCache.get(((Entry)entry.getValue()).getAppenderFactory());
/*  744 */           if (cachedAttributeAppender == null) {
/*  745 */             cachedAttributeAppender = ((Entry)entry.getValue()).getAppenderFactory().make(this.instrumentedType);
/*  746 */             attributeAppenderCache.put(((Entry)entry.getValue()).getAppenderFactory(), cachedAttributeAppender);
/*      */           } 
/*  748 */           entries.put(entry.getKey(), new MethodRegistry.Default.Compiled.Entry(cachedHandler, cachedAttributeAppender, ((Entry)entry
/*      */                 
/*  750 */                 .getValue()).getMethodDescription(), ((Entry)entry
/*  751 */                 .getValue()).resolveBridgeTypes(), ((Entry)entry
/*  752 */                 .getValue()).getVisibility(), ((Entry)entry
/*  753 */                 .getValue()).isBridgeMethod()));
/*      */         } 
/*  755 */         return new MethodRegistry.Default.Compiled(this.instrumentedType, this.loadedTypeInitializer, this.typeInitializer, this.methods, entries, classFileVersion
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  760 */             .isAtLeast(ClassFileVersion.JAVA_V5));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.implementations.equals(((Prepared)param2Object).implementations) ? false : (!this.loadedTypeInitializer.equals(((Prepared)param2Object).loadedTypeInitializer) ? false : (!this.typeInitializer.equals(((Prepared)param2Object).typeInitializer) ? false : (!this.instrumentedType.equals(((Prepared)param2Object).instrumentedType) ? false : (!this.methodGraph.equals(((Prepared)param2Object).methodGraph) ? false : (!!this.methods.equals(((Prepared)param2Object).methods)))))))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return (((((getClass().hashCode() * 31 + this.implementations.hashCode()) * 31 + this.loadedTypeInitializer.hashCode()) * 31 + this.typeInitializer.hashCode()) * 31 + this.instrumentedType.hashCode()) * 31 + this.methodGraph.hashCode()) * 31 + this.methods.hashCode();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       protected static class Entry
/*      */       {
/*      */         private final MethodRegistry.Handler handler;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final MethodAttributeAppender.Factory attributeAppenderFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final MethodDescription methodDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final Set<MethodDescription.TypeToken> typeTokens;
/*      */ 
/*      */ 
/*      */         
/*      */         private final Visibility visibility;
/*      */ 
/*      */ 
/*      */         
/*      */         private final boolean bridgeMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected Entry(MethodRegistry.Handler handler, MethodAttributeAppender.Factory attributeAppenderFactory, MethodDescription methodDescription, Set<MethodDescription.TypeToken> typeTokens, Visibility visibility, boolean bridgeMethod) {
/*  815 */           this.handler = handler;
/*  816 */           this.attributeAppenderFactory = attributeAppenderFactory;
/*  817 */           this.methodDescription = methodDescription;
/*  818 */           this.typeTokens = typeTokens;
/*  819 */           this.visibility = visibility;
/*  820 */           this.bridgeMethod = bridgeMethod;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected static Entry forVisibilityBridge(MethodDescription bridgeTarget, Visibility visibility) {
/*  831 */           return new Entry(MethodRegistry.Handler.ForVisibilityBridge.INSTANCE, 
/*  832 */               MethodAttributeAppender.Explicit.of(bridgeTarget), bridgeTarget, 
/*      */               
/*  834 */               Collections.emptySet(), visibility, true);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected MethodRegistry.Handler getHandler() {
/*  845 */           return this.handler;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected MethodAttributeAppender.Factory getAppenderFactory() {
/*  854 */           return this.attributeAppenderFactory;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected MethodDescription getMethodDescription() {
/*  863 */           return this.methodDescription;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected Set<MethodDescription.TypeToken> resolveBridgeTypes() {
/*  872 */           HashSet<MethodDescription.TypeToken> typeTokens = new HashSet<MethodDescription.TypeToken>(this.typeTokens);
/*  873 */           typeTokens.remove(this.methodDescription.asTypeToken());
/*  874 */           return typeTokens;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected Visibility getVisibility() {
/*  883 */           return this.visibility;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected boolean isBridgeMethod()
/*      */         {
/*  892 */           return this.bridgeMethod; } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.bridgeMethod != ((Entry)param3Object).bridgeMethod) ? false : (!this.visibility.equals(((Entry)param3Object).visibility) ? false : (!this.handler.equals(((Entry)param3Object).handler) ? false : (!this.attributeAppenderFactory.equals(((Entry)param3Object).attributeAppenderFactory) ? false : (!this.methodDescription.equals(((Entry)param3Object).methodDescription) ? false : (!!this.typeTokens.equals(((Entry)param3Object).typeTokens))))))))); } public int hashCode() { return (((((getClass().hashCode() * 31 + this.handler.hashCode()) * 31 + this.attributeAppenderFactory.hashCode()) * 31 + this.methodDescription.hashCode()) * 31 + this.typeTokens.hashCode()) * 31 + this.visibility.hashCode()) * 31 + this.bridgeMethod; } } } @Enhance protected static class Entry { private final MethodRegistry.Handler handler; private final MethodAttributeAppender.Factory attributeAppenderFactory; private final MethodDescription methodDescription; protected boolean isBridgeMethod() { return this.bridgeMethod; }
/*      */       
/*      */       private final Set<MethodDescription.TypeToken> typeTokens; private final Visibility visibility;
/*      */       private final boolean bridgeMethod;
/*      */       
/*      */       protected Entry(MethodRegistry.Handler handler, MethodAttributeAppender.Factory attributeAppenderFactory, MethodDescription methodDescription, Set<MethodDescription.TypeToken> typeTokens, Visibility visibility, boolean bridgeMethod) {
/*      */         this.handler = handler;
/*      */         this.attributeAppenderFactory = attributeAppenderFactory;
/*      */         this.methodDescription = methodDescription;
/*      */         this.typeTokens = typeTokens;
/*      */         this.visibility = visibility;
/*      */         this.bridgeMethod = bridgeMethod;
/*      */       }
/*      */       
/*      */       protected static Entry forVisibilityBridge(MethodDescription bridgeTarget, Visibility visibility) {
/*      */         return new Entry(MethodRegistry.Handler.ForVisibilityBridge.INSTANCE, MethodAttributeAppender.Explicit.of(bridgeTarget), bridgeTarget, Collections.emptySet(), visibility, true);
/*      */       }
/*      */       
/*      */       protected MethodRegistry.Handler getHandler() {
/*      */         return this.handler;
/*      */       }
/*      */       
/*      */       protected MethodAttributeAppender.Factory getAppenderFactory() {
/*      */         return this.attributeAppenderFactory;
/*      */       }
/*      */       
/*      */       protected MethodDescription getMethodDescription() {
/*      */         return this.methodDescription;
/*      */       }
/*      */       
/*      */       protected Set<MethodDescription.TypeToken> resolveBridgeTypes() {
/*      */         HashSet<MethodDescription.TypeToken> typeTokens = new HashSet<MethodDescription.TypeToken>(this.typeTokens);
/*      */         typeTokens.remove(this.methodDescription.asTypeToken());
/*      */         return typeTokens;
/*      */       }
/*      */       
/*      */       protected Visibility getVisibility() {
/*      */         return this.visibility;
/*      */       }
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.bridgeMethod != ((Entry)param2Object).bridgeMethod) ? false : (!this.visibility.equals(((Entry)param2Object).visibility) ? false : (!this.handler.equals(((Entry)param2Object).handler) ? false : (!this.attributeAppenderFactory.equals(((Entry)param2Object).attributeAppenderFactory) ? false : (!this.methodDescription.equals(((Entry)param2Object).methodDescription) ? false : (!!this.typeTokens.equals(((Entry)param2Object).typeTokens)))))))));
/*      */       }
/*      */       
/*      */       public int hashCode() {
/*      */         return (((((getClass().hashCode() * 31 + this.handler.hashCode()) * 31 + this.attributeAppenderFactory.hashCode()) * 31 + this.methodDescription.hashCode()) * 31 + this.typeTokens.hashCode()) * 31 + this.visibility.hashCode()) * 31 + this.bridgeMethod;
/*      */       } }
/*      */     
/*      */     @Enhance
/*      */     protected static class Compiled implements MethodRegistry.Compiled { private final TypeDescription instrumentedType;
/*      */       private final LoadedTypeInitializer loadedTypeInitializer;
/*      */       private final TypeInitializer typeInitializer;
/*      */       private final MethodList<?> methods;
/*      */       private final LinkedHashMap<MethodDescription, Entry> implementations;
/*      */       private final boolean supportsBridges;
/*      */       
/*      */       protected Compiled(TypeDescription instrumentedType, LoadedTypeInitializer loadedTypeInitializer, TypeInitializer typeInitializer, MethodList<?> methods, LinkedHashMap<MethodDescription, Entry> implementations, boolean supportsBridges) {
/*  949 */         this.instrumentedType = instrumentedType;
/*  950 */         this.loadedTypeInitializer = loadedTypeInitializer;
/*  951 */         this.typeInitializer = typeInitializer;
/*  952 */         this.methods = methods;
/*  953 */         this.implementations = implementations;
/*  954 */         this.supportsBridges = supportsBridges;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeDescription getInstrumentedType() {
/*  961 */         return this.instrumentedType;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public LoadedTypeInitializer getLoadedTypeInitializer() {
/*  968 */         return this.loadedTypeInitializer;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeInitializer getTypeInitializer() {
/*  975 */         return this.typeInitializer;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodList<?> getMethods() {
/*  982 */         return this.methods;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MethodList<?> getInstrumentedMethods() {
/*  989 */         return (MethodList)(new MethodList.Explicit(new ArrayList(this.implementations.keySet()))).filter((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.isTypeInitializer()));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypeWriter.MethodPool.Record target(MethodDescription methodDescription) {
/*  996 */         Entry entry = this.implementations.get(methodDescription);
/*  997 */         return (entry == null) ? new TypeWriter.MethodPool.Record.ForNonImplementedMethod(methodDescription) : entry
/*      */           
/*  999 */           .bind(this.instrumentedType, this.supportsBridges);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.supportsBridges != ((Compiled)param2Object).supportsBridges) ? false : (!this.instrumentedType.equals(((Compiled)param2Object).instrumentedType) ? false : (!this.loadedTypeInitializer.equals(((Compiled)param2Object).loadedTypeInitializer) ? false : (!this.typeInitializer.equals(((Compiled)param2Object).typeInitializer) ? false : (!this.methods.equals(((Compiled)param2Object).methods) ? false : (!!this.implementations.equals(((Compiled)param2Object).implementations)))))))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return (((((getClass().hashCode() * 31 + this.instrumentedType.hashCode()) * 31 + this.loadedTypeInitializer.hashCode()) * 31 + this.typeInitializer.hashCode()) * 31 + this.methods.hashCode()) * 31 + this.implementations.hashCode()) * 31 + this.supportsBridges;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       protected static class Entry
/*      */       {
/*      */         private final MethodRegistry.Handler.Compiled handler;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final MethodAttributeAppender attributeAppender;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final MethodDescription methodDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final Set<MethodDescription.TypeToken> bridgeTypes;
/*      */ 
/*      */ 
/*      */         
/*      */         private final Visibility visibility;
/*      */ 
/*      */ 
/*      */         
/*      */         private final boolean bridgeMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected Entry(MethodRegistry.Handler.Compiled handler, MethodAttributeAppender attributeAppender, MethodDescription methodDescription, Set<MethodDescription.TypeToken> bridgeTypes, Visibility visibility, boolean bridgeMethod) {
/* 1054 */           this.handler = handler;
/* 1055 */           this.attributeAppender = attributeAppender;
/* 1056 */           this.methodDescription = methodDescription;
/* 1057 */           this.bridgeTypes = bridgeTypes;
/* 1058 */           this.visibility = visibility;
/* 1059 */           this.bridgeMethod = bridgeMethod;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected TypeWriter.MethodPool.Record bind(TypeDescription instrumentedType, boolean supportsBridges) {
/* 1070 */           if (this.bridgeMethod && !supportsBridges) {
/* 1071 */             return new TypeWriter.MethodPool.Record.ForNonImplementedMethod(this.methodDescription);
/*      */           }
/* 1073 */           TypeWriter.MethodPool.Record record = this.handler.assemble(this.methodDescription, this.attributeAppender, this.visibility);
/* 1074 */           return supportsBridges ? 
/* 1075 */             TypeWriter.MethodPool.Record.AccessBridgeWrapper.of(record, instrumentedType, this.methodDescription, this.bridgeTypes, this.attributeAppender) : record;
/*      */         }
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.bridgeMethod != ((Entry)param3Object).bridgeMethod) ? false : (!this.visibility.equals(((Entry)param3Object).visibility) ? false : (!this.handler.equals(((Entry)param3Object).handler) ? false : (!this.attributeAppender.equals(((Entry)param3Object).attributeAppender) ? false : (!this.methodDescription.equals(((Entry)param3Object).methodDescription) ? false : (!!this.bridgeTypes.equals(((Entry)param3Object).bridgeTypes)))))))));
/*      */         }
/*      */         
/*      */         public int hashCode() {
/*      */           return (((((getClass().hashCode() * 31 + this.handler.hashCode()) * 31 + this.attributeAppender.hashCode()) * 31 + this.methodDescription.hashCode()) * 31 + this.bridgeTypes.hashCode()) * 31 + this.visibility.hashCode()) * 31 + this.bridgeMethod;
/*      */         }
/*      */       } }
/*      */   
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\scaffold\MethodRegistry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */