/*     */ package net.bytebuddy.dynamic.scaffold;
/*     */ 
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.jar.asm.ClassReader;
/*     */ import net.bytebuddy.jar.asm.ClassWriter;
/*     */ import net.bytebuddy.pool.TypePool;
/*     */ import net.bytebuddy.utility.AsmClassReader;
/*     */ import net.bytebuddy.utility.AsmClassWriter;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public interface ClassWriterStrategy
/*     */ {
/*     */   ClassWriter resolve(int paramInt, TypePool paramTypePool);
/*     */   
/*     */   ClassWriter resolve(int paramInt, TypePool paramTypePool, ClassReader paramClassReader);
/*     */   
/*     */   @Deprecated
/*     */   public enum Default
/*     */     implements ClassWriterStrategy
/*     */   {
/*  63 */     CONSTANT_POOL_RETAINING
/*     */     {
/*     */       public ClassWriter resolve(int flags, TypePool typePool, ClassReader classReader) {
/*  66 */         return (ClassWriter)new ClassWriterStrategy.FrameComputingClassWriter(classReader, flags, typePool);
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     CONSTANT_POOL_DISCARDING
/*     */     {
/*     */       public ClassWriter resolve(int flags, TypePool typePool, ClassReader classReader) {
/*  76 */         return resolve(flags, typePool);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassWriter resolve(int flags, TypePool typePool) {
/*  84 */       return (ClassWriter)new ClassWriterStrategy.FrameComputingClassWriter(flags, typePool);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Delegating
/*     */     implements AsmClassWriter.Factory
/*     */   {
/*     */     private final ClassWriterStrategy classWriterStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Delegating(ClassWriterStrategy classWriterStrategy) {
/* 105 */       this.classWriterStrategy = classWriterStrategy;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AsmClassWriter make(int flags) {
/* 112 */       return make(flags, (TypePool)TypePool.Empty.INSTANCE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AsmClassWriter make(int flags, AsmClassReader classReader) {
/* 119 */       return make(flags, classReader, (TypePool)TypePool.Empty.INSTANCE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AsmClassWriter make(int flags, TypePool typePool) {
/* 126 */       return (AsmClassWriter)new AsmClassWriter.ForAsm(this.classWriterStrategy.resolve(flags, typePool));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AsmClassWriter make(int flags, AsmClassReader classReader, TypePool typePool) {
/* 133 */       ClassReader unwrapped = (ClassReader)classReader.unwrap(ClassReader.class);
/* 134 */       return (AsmClassWriter)new AsmClassWriter.ForAsm((unwrapped == null) ? this.classWriterStrategy
/* 135 */           .resolve(flags, typePool) : this.classWriterStrategy
/* 136 */           .resolve(flags, typePool, unwrapped));
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.classWriterStrategy.equals(((Delegating)param1Object).classWriterStrategy))));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.classWriterStrategy.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static class FrameComputingClassWriter
/*     */     extends AsmClassWriter.FrameComputingClassWriter
/*     */   {
/*     */     public FrameComputingClassWriter(int flags, TypePool typePool) {
/* 156 */       super(flags, typePool);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FrameComputingClassWriter(ClassReader classReader, int flags, TypePool typePool) {
/* 167 */       super(classReader, flags, typePool);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\scaffold\ClassWriterStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */