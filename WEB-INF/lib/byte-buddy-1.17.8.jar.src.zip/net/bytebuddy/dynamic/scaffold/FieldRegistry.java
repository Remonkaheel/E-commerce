/*     */ package net.bytebuddy.dynamic.scaffold;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.Transformer;
/*     */ import net.bytebuddy.implementation.attribute.FieldAttributeAppender;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.LatentMatcher;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface FieldRegistry
/*     */ {
/*     */   FieldRegistry prepend(LatentMatcher<? super FieldDescription> paramLatentMatcher, FieldAttributeAppender.Factory paramFactory, @MaybeNull Object paramObject, Transformer<FieldDescription> paramTransformer);
/*     */   
/*     */   Compiled compile(TypeDescription paramTypeDescription);
/*     */   
/*     */   public static interface Compiled
/*     */     extends TypeWriter.FieldPool
/*     */   {
/*     */     public enum NoOp
/*     */       implements Compiled
/*     */     {
/*  76 */       INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TypeWriter.FieldPool.Record target(FieldDescription fieldDescription) {
/*  82 */         return new TypeWriter.FieldPool.Record.ForImplicitField(fieldDescription);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Default
/*     */     implements FieldRegistry
/*     */   {
/*     */     private final List<Entry> entries;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Default() {
/* 102 */       this(Collections.emptyList());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Default(List<Entry> entries) {
/* 111 */       this.entries = entries;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldRegistry prepend(LatentMatcher<? super FieldDescription> matcher, FieldAttributeAppender.Factory fieldAttributeAppenderFactory, @MaybeNull Object defaultValue, Transformer<FieldDescription> transformer) {
/* 121 */       List<Entry> entries = new ArrayList<Entry>(this.entries.size() + 1);
/* 122 */       entries.add(new Entry(matcher, fieldAttributeAppenderFactory, defaultValue, transformer));
/* 123 */       entries.addAll(this.entries);
/* 124 */       return new Default(entries);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldRegistry.Compiled compile(TypeDescription instrumentedType) {
/* 131 */       List<Compiled.Entry> entries = new ArrayList<Compiled.Entry>(this.entries.size());
/* 132 */       Map<FieldAttributeAppender.Factory, FieldAttributeAppender> fieldAttributeAppenders = new HashMap<FieldAttributeAppender.Factory, FieldAttributeAppender>();
/* 133 */       for (Entry entry : this.entries) {
/* 134 */         FieldAttributeAppender fieldAttributeAppender = fieldAttributeAppenders.get(entry.getFieldAttributeAppenderFactory());
/* 135 */         if (fieldAttributeAppender == null) {
/* 136 */           fieldAttributeAppender = entry.getFieldAttributeAppenderFactory().make(instrumentedType);
/* 137 */           fieldAttributeAppenders.put(entry.getFieldAttributeAppenderFactory(), fieldAttributeAppender);
/*     */         } 
/* 139 */         entries.add(new Compiled.Entry(entry.resolve(instrumentedType), fieldAttributeAppender, entry.getDefaultValue(), entry.getTransformer()));
/*     */       } 
/* 141 */       return new Compiled(instrumentedType, entries);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.entries.equals(((Default)param1Object).entries))));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.entries.hashCode();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     protected static class Entry
/*     */       implements LatentMatcher<FieldDescription>
/*     */     {
/*     */       private final LatentMatcher<? super FieldDescription> matcher;
/*     */ 
/*     */ 
/*     */       
/*     */       private final FieldAttributeAppender.Factory fieldAttributeAppenderFactory;
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*     */       private final Object defaultValue;
/*     */ 
/*     */ 
/*     */       
/*     */       private final Transformer<FieldDescription> transformer;
/*     */ 
/*     */ 
/*     */       
/*     */       protected Entry(LatentMatcher<? super FieldDescription> matcher, FieldAttributeAppender.Factory fieldAttributeAppenderFactory, @MaybeNull Object defaultValue, Transformer<FieldDescription> transformer) {
/* 184 */         this.matcher = matcher;
/* 185 */         this.fieldAttributeAppenderFactory = fieldAttributeAppenderFactory;
/* 186 */         this.defaultValue = defaultValue;
/* 187 */         this.transformer = transformer;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected FieldAttributeAppender.Factory getFieldAttributeAppenderFactory() {
/* 196 */         return this.fieldAttributeAppenderFactory;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       protected Object getDefaultValue() {
/* 206 */         return this.defaultValue;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected Transformer<FieldDescription> getTransformer() {
/* 215 */         return this.transformer;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ElementMatcher<? super FieldDescription> resolve(TypeDescription typeDescription) {
/* 222 */         return this.matcher.resolve(typeDescription);
/*     */       } public boolean equals(@MaybeNull Object param2Object) { if (this == param2Object)
/*     */           return true; 
/*     */         if (param2Object == null)
/*     */           return false; 
/*     */         if (getClass() != param2Object.getClass())
/*     */           return false; 
/*     */         if (!this.matcher.equals(((Entry)param2Object).matcher))
/*     */           return false; 
/*     */         if (!this.fieldAttributeAppenderFactory.equals(((Entry)param2Object).fieldAttributeAppenderFactory))
/*     */           return false; 
/*     */         Object object1 = ((Entry)param2Object).defaultValue;
/*     */         Object object2 = this.defaultValue;
/*     */         if (object1 != null) {
/*     */           if (object2 != null) {
/*     */             if (!object2.equals(object1))
/*     */               return false; 
/*     */           } else {
/*     */             return false;
/*     */           } 
/*     */         } else if (object2 != null) {
/*     */           return false;
/*     */         } 
/*     */         return !!this.transformer.equals(((Entry)param2Object).transformer); } public int hashCode() { Object object = this.defaultValue;
/*     */         if (object != null);
/*     */         return (((getClass().hashCode() * 31 + this.matcher.hashCode()) * 31 + this.fieldAttributeAppenderFactory.hashCode()) * 31 + object.hashCode()) * 31 + this.transformer.hashCode(); } } @Enhance
/*     */     protected static class Compiled implements FieldRegistry.Compiled { private final TypeDescription instrumentedType; private final List<Entry> entries;
/* 249 */       protected Compiled(TypeDescription instrumentedType, List<Entry> entries) { this.instrumentedType = instrumentedType;
/* 250 */         this.entries = entries; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TypeWriter.FieldPool.Record target(FieldDescription fieldDescription) {
/* 257 */         for (Entry entry : this.entries) {
/* 258 */           if (entry.matches(fieldDescription)) {
/* 259 */             return entry.bind(this.instrumentedType, fieldDescription);
/*     */           }
/*     */         } 
/* 262 */         return new TypeWriter.FieldPool.Record.ForImplicitField(fieldDescription);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.instrumentedType.equals(((Compiled)param2Object).instrumentedType) ? false : (!!this.entries.equals(((Compiled)param2Object).entries)))));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return (getClass().hashCode() * 31 + this.instrumentedType.hashCode()) * 31 + this.entries.hashCode();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Enhance
/*     */       protected static class Entry
/*     */         implements ElementMatcher<FieldDescription>
/*     */       {
/*     */         private final ElementMatcher<? super FieldDescription> matcher;
/*     */ 
/*     */ 
/*     */         
/*     */         private final FieldAttributeAppender fieldAttributeAppender;
/*     */ 
/*     */ 
/*     */         
/*     */         @MaybeNull
/*     */         @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*     */         private final Object defaultValue;
/*     */ 
/*     */ 
/*     */         
/*     */         private final Transformer<FieldDescription> transformer;
/*     */ 
/*     */ 
/*     */         
/*     */         protected Entry(ElementMatcher<? super FieldDescription> matcher, FieldAttributeAppender fieldAttributeAppender, @MaybeNull Object defaultValue, Transformer<FieldDescription> transformer) {
/* 305 */           this.matcher = matcher;
/* 306 */           this.fieldAttributeAppender = fieldAttributeAppender;
/* 307 */           this.defaultValue = defaultValue;
/* 308 */           this.transformer = transformer;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         protected TypeWriter.FieldPool.Record bind(TypeDescription instrumentedType, FieldDescription fieldDescription) {
/* 319 */           return new TypeWriter.FieldPool.Record.ForExplicitField(this.fieldAttributeAppender, this.defaultValue, (FieldDescription)this.transformer.transform(instrumentedType, fieldDescription));
/*     */         } public boolean equals(@MaybeNull Object param3Object) { if (this == param3Object)
/*     */             return true;  if (param3Object == null)
/*     */             return false;  if (getClass() != param3Object.getClass())
/*     */             return false;  if (!this.matcher.equals(((Entry)param3Object).matcher))
/*     */             return false;  if (!this.fieldAttributeAppender.equals(((Entry)param3Object).fieldAttributeAppender))
/*     */             return false;  Object object1 = ((Entry)param3Object).defaultValue; Object object2 = this.defaultValue; if (object1 != null) { if (object2 != null) { if (!object2.equals(object1))
/* 326 */                 return false;  } else { return false; }  } else if (object2 != null) { return false; }  return !!this.transformer.equals(((Entry)param3Object).transformer); } public boolean matches(@MaybeNull FieldDescription target) { return this.matcher.matches(target); } public int hashCode() { Object object = this.defaultValue; if (object != null); return (((getClass().hashCode() * 31 + this.matcher.hashCode()) * 31 + this.fieldAttributeAppender.hashCode()) * 31 + object.hashCode()) * 31 + this.transformer.hashCode(); } } } @Enhance protected static class Entry implements ElementMatcher<FieldDescription> { public boolean matches(@MaybeNull FieldDescription target) { return this.matcher.matches(target); }
/*     */ 
/*     */       
/*     */       private final ElementMatcher<? super FieldDescription> matcher;
/*     */       private final FieldAttributeAppender fieldAttributeAppender;
/*     */       @MaybeNull
/*     */       @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*     */       private final Object defaultValue;
/*     */       private final Transformer<FieldDescription> transformer;
/*     */       
/*     */       protected Entry(ElementMatcher<? super FieldDescription> matcher, FieldAttributeAppender fieldAttributeAppender, @MaybeNull Object defaultValue, Transformer<FieldDescription> transformer) {
/*     */         this.matcher = matcher;
/*     */         this.fieldAttributeAppender = fieldAttributeAppender;
/*     */         this.defaultValue = defaultValue;
/*     */         this.transformer = transformer;
/*     */       }
/*     */       
/*     */       protected TypeWriter.FieldPool.Record bind(TypeDescription instrumentedType, FieldDescription fieldDescription) {
/*     */         return new TypeWriter.FieldPool.Record.ForExplicitField(this.fieldAttributeAppender, this.defaultValue, (FieldDescription)this.transformer.transform(instrumentedType, fieldDescription));
/*     */       }
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         if (this == param2Object)
/*     */           return true; 
/*     */         if (param2Object == null)
/*     */           return false; 
/*     */         if (getClass() != param2Object.getClass())
/*     */           return false; 
/*     */         if (!this.matcher.equals(((Entry)param2Object).matcher))
/*     */           return false; 
/*     */         if (!this.fieldAttributeAppender.equals(((Entry)param2Object).fieldAttributeAppender))
/*     */           return false; 
/*     */         Object object1 = ((Entry)param2Object).defaultValue;
/*     */         Object object2 = this.defaultValue;
/*     */         if (object1 != null) {
/*     */           if (object2 != null) {
/*     */             if (!object2.equals(object1))
/*     */               return false; 
/*     */           } else {
/*     */             return false;
/*     */           } 
/*     */         } else if (object2 != null) {
/*     */           return false;
/*     */         } 
/*     */         return !!this.transformer.equals(((Entry)param2Object).transformer);
/*     */       }
/*     */       
/*     */       public int hashCode() {
/*     */         Object object = this.defaultValue;
/*     */         if (object != null);
/*     */         return (((getClass().hashCode() * 31 + this.matcher.hashCode()) * 31 + this.fieldAttributeAppender.hashCode()) * 31 + object.hashCode()) * 31 + this.transformer.hashCode();
/*     */       } }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\scaffold\FieldRegistry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */