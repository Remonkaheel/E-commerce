/*    */ package net.bytebuddy.dynamic.scaffold;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum TypeValidation
/*    */ {
/* 36 */   ENABLED(true),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   DISABLED(false);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final boolean enabled;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   TypeValidation(boolean enabled) {
/* 54 */     this.enabled = enabled;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static TypeValidation of(boolean enabled) {
/* 64 */     return enabled ? ENABLED : DISABLED;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isEnabled() {
/* 75 */     return this.enabled;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\scaffold\TypeValidation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */