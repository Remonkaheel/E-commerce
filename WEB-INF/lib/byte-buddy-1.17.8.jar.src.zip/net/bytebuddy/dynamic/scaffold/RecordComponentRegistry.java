/*     */ package net.bytebuddy.dynamic.scaffold;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.type.RecordComponentDescription;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.Transformer;
/*     */ import net.bytebuddy.implementation.attribute.RecordComponentAttributeAppender;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.LatentMatcher;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface RecordComponentRegistry
/*     */ {
/*     */   RecordComponentRegistry prepend(LatentMatcher<? super RecordComponentDescription> paramLatentMatcher, RecordComponentAttributeAppender.Factory paramFactory, Transformer<RecordComponentDescription> paramTransformer);
/*     */   
/*     */   Compiled compile(TypeDescription paramTypeDescription);
/*     */   
/*     */   public static interface Compiled
/*     */     extends TypeWriter.RecordComponentPool
/*     */   {
/*     */     public enum NoOp
/*     */       implements Compiled
/*     */     {
/*  74 */       INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TypeWriter.RecordComponentPool.Record target(RecordComponentDescription recordComponentDescription) {
/*  80 */         return new TypeWriter.RecordComponentPool.Record.ForImplicitRecordComponent(recordComponentDescription);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Default
/*     */     implements RecordComponentRegistry
/*     */   {
/*     */     private final List<Entry> entries;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Default() {
/* 100 */       this(Collections.emptyList());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Default(List<Entry> entries) {
/* 109 */       this.entries = entries;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RecordComponentRegistry prepend(LatentMatcher<? super RecordComponentDescription> matcher, RecordComponentAttributeAppender.Factory recordComponentAttributeAppenderFactory, Transformer<RecordComponentDescription> transformer) {
/* 118 */       List<Entry> entries = new ArrayList<Entry>(this.entries.size() + 1);
/* 119 */       entries.add(new Entry(matcher, recordComponentAttributeAppenderFactory, transformer));
/* 120 */       entries.addAll(this.entries);
/* 121 */       return new Default(entries);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RecordComponentRegistry.Compiled compile(TypeDescription instrumentedType) {
/* 128 */       List<Compiled.Entry> entries = new ArrayList<Compiled.Entry>(this.entries.size());
/* 129 */       Map<RecordComponentAttributeAppender.Factory, RecordComponentAttributeAppender> recordComponentAttributeAppenders = new HashMap<RecordComponentAttributeAppender.Factory, RecordComponentAttributeAppender>();
/* 130 */       for (Entry entry : this.entries) {
/* 131 */         RecordComponentAttributeAppender recordComponentAttributeAppender = recordComponentAttributeAppenders.get(entry.getRecordComponentAttributeAppender());
/* 132 */         if (recordComponentAttributeAppender == null) {
/* 133 */           recordComponentAttributeAppender = entry.getRecordComponentAttributeAppender().make(instrumentedType);
/* 134 */           recordComponentAttributeAppenders.put(entry.getRecordComponentAttributeAppender(), recordComponentAttributeAppender);
/*     */         } 
/* 136 */         entries.add(new Compiled.Entry(entry.resolve(instrumentedType), recordComponentAttributeAppender, entry.getTransformer()));
/*     */       } 
/* 138 */       return new Compiled(instrumentedType, entries);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.entries.equals(((Default)param1Object).entries))));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.entries.hashCode();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     protected static class Entry
/*     */       implements LatentMatcher<RecordComponentDescription>
/*     */     {
/*     */       private final LatentMatcher<? super RecordComponentDescription> matcher;
/*     */ 
/*     */       
/*     */       private final RecordComponentAttributeAppender.Factory recordComponentAttributeAppender;
/*     */ 
/*     */       
/*     */       private final Transformer<RecordComponentDescription> transformer;
/*     */ 
/*     */ 
/*     */       
/*     */       protected Entry(LatentMatcher<? super RecordComponentDescription> matcher, RecordComponentAttributeAppender.Factory recordComponentAttributeAppender, Transformer<RecordComponentDescription> transformer) {
/* 172 */         this.matcher = matcher;
/* 173 */         this.recordComponentAttributeAppender = recordComponentAttributeAppender;
/* 174 */         this.transformer = transformer;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected RecordComponentAttributeAppender.Factory getRecordComponentAttributeAppender() {
/* 183 */         return this.recordComponentAttributeAppender;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected Transformer<RecordComponentDescription> getTransformer() {
/* 192 */         return this.transformer;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ElementMatcher<? super RecordComponentDescription> resolve(TypeDescription typeDescription) {
/* 199 */         return this.matcher.resolve(typeDescription);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.matcher.equals(((Entry)param2Object).matcher) ? false : (!this.recordComponentAttributeAppender.equals(((Entry)param2Object).recordComponentAttributeAppender) ? false : (!!this.transformer.equals(((Entry)param2Object).transformer))))));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return ((getClass().hashCode() * 31 + this.matcher.hashCode()) * 31 + this.recordComponentAttributeAppender.hashCode()) * 31 + this.transformer.hashCode();
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     protected static class Compiled
/*     */       implements RecordComponentRegistry.Compiled
/*     */     {
/*     */       private final TypeDescription instrumentedType;
/*     */       
/*     */       private final List<Entry> entries;
/*     */ 
/*     */       
/*     */       protected Compiled(TypeDescription instrumentedType, List<Entry> entries) {
/* 226 */         this.instrumentedType = instrumentedType;
/* 227 */         this.entries = entries;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TypeWriter.RecordComponentPool.Record target(RecordComponentDescription recordComponentDescription) {
/* 234 */         for (Entry entry : this.entries) {
/* 235 */           if (entry.matches(recordComponentDescription)) {
/* 236 */             return entry.bind(this.instrumentedType, recordComponentDescription);
/*     */           }
/*     */         } 
/* 239 */         return new TypeWriter.RecordComponentPool.Record.ForImplicitRecordComponent(recordComponentDescription);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.instrumentedType.equals(((Compiled)param2Object).instrumentedType) ? false : (!!this.entries.equals(((Compiled)param2Object).entries)))));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return (getClass().hashCode() * 31 + this.instrumentedType.hashCode()) * 31 + this.entries.hashCode();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       @Enhance
/*     */       protected static class Entry
/*     */         implements ElementMatcher<RecordComponentDescription>
/*     */       {
/*     */         private final ElementMatcher<? super RecordComponentDescription> matcher;
/*     */ 
/*     */         
/*     */         private final RecordComponentAttributeAppender recordComponentAttributeAppender;
/*     */ 
/*     */         
/*     */         private final Transformer<RecordComponentDescription> transformer;
/*     */ 
/*     */ 
/*     */         
/*     */         protected Entry(ElementMatcher<? super RecordComponentDescription> matcher, RecordComponentAttributeAppender recordComponentAttributeAppender, Transformer<RecordComponentDescription> transformer) {
/* 273 */           this.matcher = matcher;
/* 274 */           this.recordComponentAttributeAppender = recordComponentAttributeAppender;
/* 275 */           this.transformer = transformer;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         protected TypeWriter.RecordComponentPool.Record bind(TypeDescription instrumentedType, RecordComponentDescription recordComponentDescription) {
/* 286 */           return new TypeWriter.RecordComponentPool.Record.ForExplicitRecordComponent(this.recordComponentAttributeAppender, (RecordComponentDescription)this.transformer.transform(instrumentedType, recordComponentDescription));
/*     */         }
/*     */         public boolean equals(@MaybeNull Object param3Object) {
/*     */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.matcher.equals(((Entry)param3Object).matcher) ? false : (!this.recordComponentAttributeAppender.equals(((Entry)param3Object).recordComponentAttributeAppender) ? false : (!!this.transformer.equals(((Entry)param3Object).transformer))))));
/*     */         } public int hashCode() {
/*     */           return ((getClass().hashCode() * 31 + this.matcher.hashCode()) * 31 + this.recordComponentAttributeAppender.hashCode()) * 31 + this.transformer.hashCode();
/*     */         }
/* 293 */         public boolean matches(@MaybeNull RecordComponentDescription target) { return this.matcher.matches(target); } } } @Enhance protected static class Entry implements ElementMatcher<RecordComponentDescription> { public boolean matches(@MaybeNull RecordComponentDescription target) { return this.matcher.matches(target); }
/*     */ 
/*     */       
/*     */       private final ElementMatcher<? super RecordComponentDescription> matcher;
/*     */       private final RecordComponentAttributeAppender recordComponentAttributeAppender;
/*     */       private final Transformer<RecordComponentDescription> transformer;
/*     */       
/*     */       protected Entry(ElementMatcher<? super RecordComponentDescription> matcher, RecordComponentAttributeAppender recordComponentAttributeAppender, Transformer<RecordComponentDescription> transformer) {
/*     */         this.matcher = matcher;
/*     */         this.recordComponentAttributeAppender = recordComponentAttributeAppender;
/*     */         this.transformer = transformer;
/*     */       }
/*     */       
/*     */       protected TypeWriter.RecordComponentPool.Record bind(TypeDescription instrumentedType, RecordComponentDescription recordComponentDescription) {
/*     */         return new TypeWriter.RecordComponentPool.Record.ForExplicitRecordComponent(this.recordComponentAttributeAppender, (RecordComponentDescription)this.transformer.transform(instrumentedType, recordComponentDescription));
/*     */       }
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.matcher.equals(((Entry)param2Object).matcher) ? false : (!this.recordComponentAttributeAppender.equals(((Entry)param2Object).recordComponentAttributeAppender) ? false : (!!this.transformer.equals(((Entry)param2Object).transformer))))));
/*     */       }
/*     */       
/*     */       public int hashCode() {
/*     */         return ((getClass().hashCode() * 31 + this.matcher.hashCode()) * 31 + this.recordComponentAttributeAppender.hashCode()) * 31 + this.transformer.hashCode();
/*     */       } }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\scaffold\RecordComponentRegistry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */