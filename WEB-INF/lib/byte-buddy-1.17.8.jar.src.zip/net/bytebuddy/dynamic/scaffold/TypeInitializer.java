/*     */ package net.bytebuddy.dynamic.scaffold;
/*     */ 
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.attribute.AnnotationValueFilter;
/*     */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface TypeInitializer
/*     */   extends ByteCodeAppender
/*     */ {
/*     */   boolean isDefined();
/*     */   
/*     */   TypeInitializer expandWith(ByteCodeAppender paramByteCodeAppender);
/*     */   
/*     */   TypeWriter.MethodPool.Record wrap(TypeWriter.MethodPool.Record paramRecord);
/*     */   
/*     */   public static interface Drain
/*     */   {
/*     */     void apply(ClassVisitor param1ClassVisitor, TypeInitializer param1TypeInitializer, Implementation.Context param1Context);
/*     */     
/*     */     @Enhance
/*     */     public static class Default
/*     */       implements Drain
/*     */     {
/*     */       protected final TypeDescription instrumentedType;
/*     */       protected final TypeWriter.MethodPool methodPool;
/*     */       protected final AnnotationValueFilter.Factory annotationValueFilterFactory;
/*     */       
/*     */       public Default(TypeDescription instrumentedType, TypeWriter.MethodPool methodPool, AnnotationValueFilter.Factory annotationValueFilterFactory) {
/* 101 */         this.instrumentedType = instrumentedType;
/* 102 */         this.methodPool = methodPool;
/* 103 */         this.annotationValueFilterFactory = annotationValueFilterFactory;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void apply(ClassVisitor classVisitor, TypeInitializer typeInitializer, Implementation.Context implementationContext) {
/* 110 */         typeInitializer.wrap(this.methodPool.target((MethodDescription)new MethodDescription.Latent.TypeInitializer(this.instrumentedType))).apply(classVisitor, implementationContext, this.annotationValueFilterFactory);
/*     */       }
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.instrumentedType.equals(((Default)param2Object).instrumentedType) ? false : (!this.methodPool.equals(((Default)param2Object).methodPool) ? false : (!!this.annotationValueFilterFactory.equals(((Default)param2Object).annotationValueFilterFactory))))));
/*     */       }
/*     */       
/*     */       public int hashCode() {
/*     */         return ((getClass().hashCode() * 31 + this.instrumentedType.hashCode()) * 31 + this.methodPool.hashCode()) * 31 + this.annotationValueFilterFactory.hashCode();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public enum None
/*     */     implements TypeInitializer {
/* 125 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isDefined() {
/* 131 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeInitializer expandWith(ByteCodeAppender byteCodeAppenderFactory) {
/* 138 */       return new TypeInitializer.Simple(byteCodeAppenderFactory);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeWriter.MethodPool.Record wrap(TypeWriter.MethodPool.Record record) {
/* 145 */       return record;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/* 152 */       return ByteCodeAppender.Size.ZERO;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Simple
/*     */     implements TypeInitializer
/*     */   {
/*     */     private final ByteCodeAppender byteCodeAppender;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Simple(ByteCodeAppender byteCodeAppender) {
/* 173 */       this.byteCodeAppender = byteCodeAppender;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isDefined() {
/* 180 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeInitializer expandWith(ByteCodeAppender byteCodeAppender) {
/* 187 */       return new Simple((ByteCodeAppender)new ByteCodeAppender.Compound(new ByteCodeAppender[] { this.byteCodeAppender, byteCodeAppender }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeWriter.MethodPool.Record wrap(TypeWriter.MethodPool.Record record) {
/* 194 */       return record.prepend(this.byteCodeAppender);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/* 201 */       return this.byteCodeAppender.apply(methodVisitor, implementationContext, instrumentedMethod);
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.byteCodeAppender.equals(((Simple)param1Object).byteCodeAppender))));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.byteCodeAppender.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\scaffold\TypeInitializer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */