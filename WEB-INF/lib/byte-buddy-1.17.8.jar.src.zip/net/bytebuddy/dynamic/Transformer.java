/*     */ package net.bytebuddy.dynamic;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nonnull;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.build.SafeVarargsPlugin.Enhance;
/*     */ import net.bytebuddy.description.ByteCodeElement;
/*     */ import net.bytebuddy.description.TypeVariableSource;
/*     */ import net.bytebuddy.description.annotation.AnnotationList;
/*     */ import net.bytebuddy.description.annotation.AnnotationSource;
/*     */ import net.bytebuddy.description.annotation.AnnotationValue;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.ParameterDescription;
/*     */ import net.bytebuddy.description.method.ParameterList;
/*     */ import net.bytebuddy.description.modifier.ModifierContributor;
/*     */ import net.bytebuddy.description.type.TypeDefinition;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.description.type.TypeList;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Transformer<T>
/*     */ {
/*     */   T transform(TypeDescription paramTypeDescription, T paramT);
/*     */   
/*     */   public enum NoOp
/*     */     implements Transformer<Object>
/*     */   {
/*  65 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static <T> Transformer<T> make() {
/*  75 */       return INSTANCE;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object transform(TypeDescription instrumentedType, Object target) {
/*  82 */       return target;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class ForField
/*     */     implements Transformer<FieldDescription>
/*     */   {
/*     */     private final Transformer<FieldDescription.Token> transformer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForField(Transformer<FieldDescription.Token> transformer) {
/* 103 */       this.transformer = transformer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Transformer<FieldDescription> withModifiers(ModifierContributor.ForField... modifierContributor) {
/* 113 */       return withModifiers(Arrays.asList(modifierContributor));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Transformer<FieldDescription> withModifiers(List<? extends ModifierContributor.ForField> modifierContributors) {
/* 123 */       return new ForField(new FieldModifierTransformer(ModifierContributor.Resolver.of(modifierContributors)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming declaring type for type member.")
/*     */     public FieldDescription transform(TypeDescription instrumentedType, FieldDescription fieldDescription) {
/* 131 */       return (FieldDescription)new TransformedField(instrumentedType, fieldDescription
/* 132 */           .getDeclaringType(), (FieldDescription.Token)this.transformer
/* 133 */           .transform(instrumentedType, fieldDescription.asToken((ElementMatcher)ElementMatchers.none())), (FieldDescription.InDefinedShape)fieldDescription
/* 134 */           .asDefined());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.transformer.equals(((ForField)param1Object).transformer))));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.transformer.hashCode();
/*     */     }
/*     */     
/*     */     @Enhance
/*     */     protected static class FieldModifierTransformer
/*     */       implements Transformer<FieldDescription.Token>
/*     */     {
/*     */       private final ModifierContributor.Resolver<ModifierContributor.ForField> resolver;
/*     */       
/*     */       protected FieldModifierTransformer(ModifierContributor.Resolver<ModifierContributor.ForField> resolver) {
/* 154 */         this.resolver = resolver;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public FieldDescription.Token transform(TypeDescription instrumentedType, FieldDescription.Token target) {
/* 161 */         return new FieldDescription.Token(target.getName(), this.resolver
/* 162 */             .resolve(target.getModifiers()), target
/* 163 */             .getType(), (List)target
/* 164 */             .getAnnotations());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.resolver.equals(((FieldModifierTransformer)param2Object).resolver))));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return getClass().hashCode() * 31 + this.resolver.hashCode();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static class TransformedField
/*     */       extends FieldDescription.AbstractBase
/*     */     {
/*     */       private final TypeDescription instrumentedType;
/*     */ 
/*     */ 
/*     */       
/*     */       private final TypeDefinition declaringType;
/*     */ 
/*     */ 
/*     */       
/*     */       private final FieldDescription.Token token;
/*     */ 
/*     */ 
/*     */       
/*     */       private final FieldDescription.InDefinedShape fieldDescription;
/*     */ 
/*     */ 
/*     */       
/*     */       protected TransformedField(TypeDescription instrumentedType, TypeDefinition declaringType, FieldDescription.Token token, FieldDescription.InDefinedShape fieldDescription) {
/* 205 */         this.instrumentedType = instrumentedType;
/* 206 */         this.declaringType = declaringType;
/* 207 */         this.token = token;
/* 208 */         this.fieldDescription = fieldDescription;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TypeDescription.Generic getType() {
/* 215 */         return (TypeDescription.Generic)this.token.getType().accept((TypeDescription.Generic.Visitor)TypeDescription.Generic.Visitor.Substitutor.ForAttachment.of(this.instrumentedType));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public AnnotationList getDeclaredAnnotations() {
/* 222 */         return this.token.getAnnotations();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Nonnull
/*     */       public TypeDefinition getDeclaringType() {
/* 230 */         return this.declaringType;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int getModifiers() {
/* 237 */         return this.token.getModifiers();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public FieldDescription.InDefinedShape asDefined() {
/* 244 */         return this.fieldDescription;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public String getName() {
/* 251 */         return this.token.getName();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class ForMethod
/*     */     implements Transformer<MethodDescription>
/*     */   {
/*     */     private final Transformer<MethodDescription.Token> transformer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForMethod(Transformer<MethodDescription.Token> transformer) {
/* 273 */       this.transformer = transformer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Transformer<MethodDescription> withModifiers(ModifierContributor.ForMethod... modifierContributor) {
/* 284 */       return withModifiers(Arrays.asList(modifierContributor));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Transformer<MethodDescription> withModifiers(List<? extends ModifierContributor.ForMethod> modifierContributors) {
/* 295 */       return new ForMethod(new MethodModifierTransformer(ModifierContributor.Resolver.of(modifierContributors)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodDescription transform(TypeDescription instrumentedType, MethodDescription methodDescription) {
/* 302 */       return (MethodDescription)new TransformedMethod(instrumentedType, methodDescription
/* 303 */           .getDeclaringType(), (MethodDescription.Token)this.transformer
/* 304 */           .transform(instrumentedType, methodDescription.asToken((ElementMatcher)ElementMatchers.none())), (MethodDescription.InDefinedShape)methodDescription
/* 305 */           .asDefined());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.transformer.equals(((ForMethod)param1Object).transformer))));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.transformer.hashCode();
/*     */     }
/*     */     
/*     */     @Enhance
/*     */     protected static class MethodModifierTransformer
/*     */       implements Transformer<MethodDescription.Token>
/*     */     {
/*     */       private final ModifierContributor.Resolver<ModifierContributor.ForMethod> resolver;
/*     */       
/*     */       protected MethodModifierTransformer(ModifierContributor.Resolver<ModifierContributor.ForMethod> resolver) {
/* 325 */         this.resolver = resolver;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public MethodDescription.Token transform(TypeDescription instrumentedType, MethodDescription.Token target) {
/* 332 */         return new MethodDescription.Token(target.getName(), this.resolver
/* 333 */             .resolve(target.getModifiers()), (List)target
/* 334 */             .getTypeVariableTokens(), target
/* 335 */             .getReturnType(), (List)target
/* 336 */             .getParameterTokens(), (List)target
/* 337 */             .getExceptionTypes(), (List)target
/* 338 */             .getAnnotations(), target
/* 339 */             .getDefaultValue(), target
/* 340 */             .getReceiverType());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.resolver.equals(((MethodModifierTransformer)param2Object).resolver))));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return getClass().hashCode() * 31 + this.resolver.hashCode();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static class TransformedMethod
/*     */       extends MethodDescription.AbstractBase
/*     */     {
/*     */       private final TypeDescription instrumentedType;
/*     */ 
/*     */ 
/*     */       
/*     */       private final TypeDefinition declaringType;
/*     */ 
/*     */ 
/*     */       
/*     */       private final MethodDescription.Token token;
/*     */ 
/*     */ 
/*     */       
/*     */       private final MethodDescription.InDefinedShape methodDescription;
/*     */ 
/*     */ 
/*     */       
/*     */       protected TransformedMethod(TypeDescription instrumentedType, TypeDefinition declaringType, MethodDescription.Token token, MethodDescription.InDefinedShape methodDescription) {
/* 381 */         this.instrumentedType = instrumentedType;
/* 382 */         this.declaringType = declaringType;
/* 383 */         this.token = token;
/* 384 */         this.methodDescription = methodDescription;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TypeList.Generic getTypeVariables() {
/* 391 */         return (TypeList.Generic)new TypeList.Generic.ForDetachedTypes.OfTypeVariables((TypeVariableSource)this, (List)this.token.getTypeVariableTokens(), (TypeDescription.Generic.Visitor)new AttachmentVisitor());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TypeDescription.Generic getReturnType() {
/* 398 */         return (TypeDescription.Generic)this.token.getReturnType().accept((TypeDescription.Generic.Visitor)new AttachmentVisitor());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ParameterList<?> getParameters() {
/* 405 */         return (ParameterList<?>)new TransformedParameterList();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TypeList.Generic getExceptionTypes() {
/* 412 */         return (TypeList.Generic)new TypeList.Generic.ForDetachedTypes((List)this.token.getExceptionTypes(), (TypeDescription.Generic.Visitor)new AttachmentVisitor());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public AnnotationList getDeclaredAnnotations() {
/* 419 */         return this.token.getAnnotations();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public String getInternalName() {
/* 426 */         return this.token.getName();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Nonnull
/*     */       public TypeDefinition getDeclaringType() {
/* 434 */         return this.declaringType;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int getModifiers() {
/* 441 */         return this.token.getModifiers();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationValue<?, ?> getDefaultValue() {
/* 449 */         return this.token.getDefaultValue();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public MethodDescription.InDefinedShape asDefined() {
/* 456 */         return this.methodDescription;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TypeDescription.Generic getReceiverType() {
/* 463 */         TypeDescription.Generic receiverType = this.token.getReceiverType();
/* 464 */         return (receiverType == null) ? TypeDescription.Generic.UNDEFINED : (TypeDescription.Generic)receiverType
/*     */           
/* 466 */           .accept((TypeDescription.Generic.Visitor)new AttachmentVisitor());
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected class TransformedParameterList
/*     */         extends ParameterList.AbstractBase<ParameterDescription>
/*     */       {
/*     */         public ParameterDescription get(int index) {
/* 478 */           return (ParameterDescription)new Transformer.ForMethod.TransformedMethod.TransformedParameter(index, (ParameterDescription.Token)Transformer.ForMethod.TransformedMethod.this.token.getParameterTokens().get(index));
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public int size() {
/* 485 */           return Transformer.ForMethod.TransformedMethod.this.token.getParameterTokens().size();
/*     */         }
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected class TransformedParameter
/*     */         extends ParameterDescription.AbstractBase
/*     */       {
/*     */         private final int index;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final ParameterDescription.Token parameterToken;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         protected TransformedParameter(int index, ParameterDescription.Token parameterToken) {
/* 511 */           this.index = index;
/* 512 */           this.parameterToken = parameterToken;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public TypeDescription.Generic getType() {
/* 519 */           return (TypeDescription.Generic)this.parameterToken.getType().accept((TypeDescription.Generic.Visitor)new Transformer.ForMethod.TransformedMethod.AttachmentVisitor());
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public MethodDescription getDeclaringMethod() {
/* 526 */           return (MethodDescription)Transformer.ForMethod.TransformedMethod.this;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public int getIndex() {
/* 533 */           return this.index;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public boolean isNamed() {
/* 540 */           return (this.parameterToken.getName() != null);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public boolean hasModifiers() {
/* 547 */           return (this.parameterToken.getModifiers() != null);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public String getName() {
/* 554 */           String name = this.parameterToken.getName();
/* 555 */           return (name == null) ? super
/* 556 */             .getName() : name;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public int getModifiers() {
/* 564 */           Integer modifiers = this.parameterToken.getModifiers();
/* 565 */           return (modifiers == null) ? super
/* 566 */             .getModifiers() : modifiers
/* 567 */             .intValue();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public AnnotationList getDeclaredAnnotations() {
/* 574 */           return this.parameterToken.getAnnotations();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public ParameterDescription.InDefinedShape asDefined() {
/* 581 */           return (ParameterDescription.InDefinedShape)Transformer.ForMethod.TransformedMethod.this.methodDescription.getParameters().get(this.index);
/*     */         }
/*     */       }
/*     */       
/*     */       @Enhance(includeSyntheticFields = true)
/*     */       protected class AttachmentVisitor
/*     */         extends TypeDescription.Generic.Visitor.Substitutor.WithoutTypeSubstitution {
/*     */         public int hashCode() {
/*     */           return getClass().hashCode() * 31 + Transformer.ForMethod.TransformedMethod.this.hashCode();
/*     */         }
/*     */         
/*     */         public boolean equals(@MaybeNull Object param3Object) {
/*     */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!Transformer.ForMethod.TransformedMethod.this.equals(Transformer.ForMethod.TransformedMethod.this))));
/*     */         }
/*     */         
/*     */         public TypeDescription.Generic onTypeVariable(TypeDescription.Generic typeVariable) {
/* 597 */           TypeList.Generic candidates = (TypeList.Generic)Transformer.ForMethod.TransformedMethod.this.getTypeVariables().filter((ElementMatcher)ElementMatchers.named(typeVariable.getSymbol()));
/* 598 */           return (TypeDescription.Generic)new TypeDescription.Generic.OfTypeVariable.WithAnnotationOverlay(candidates.isEmpty() ? Transformer.ForMethod.TransformedMethod.this
/* 599 */               .instrumentedType.findExpectedVariable(typeVariable.getSymbol()) : (TypeDescription.Generic)candidates
/* 600 */               .getOnly(), (AnnotationSource)typeVariable);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Compound<S>
/*     */     implements Transformer<S>
/*     */   {
/*     */     @Enhance
/*     */     @SafeVarargs
/*     */     public Compound(Transformer<S>... transformer) {
/* 627 */       this(Arrays.asList(transformer));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 636 */     private final List<Transformer<S>> transformers = new ArrayList<Transformer<S>>(); public Compound(List<? extends Transformer<S>> transformers) {
/* 637 */       for (Transformer<S> transformer : transformers) {
/* 638 */         if (transformer instanceof Compound) {
/* 639 */           this.transformers.addAll(((Compound)transformer).transformers); continue;
/* 640 */         }  if (!(transformer instanceof Transformer.NoOp)) {
/* 641 */           this.transformers.add(transformer);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public S transform(TypeDescription instrumentedType, S target) {
/* 650 */       for (Transformer<S> transformer : this.transformers) {
/* 651 */         target = transformer.transform(instrumentedType, target);
/*     */       }
/* 653 */       return target;
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.transformers.equals(((Compound)param1Object).transformers))));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.transformers.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\Transformer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */