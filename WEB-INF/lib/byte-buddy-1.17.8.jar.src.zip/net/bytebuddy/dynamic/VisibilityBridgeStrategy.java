/*    */ package net.bytebuddy.dynamic;
/*    */ 
/*    */ import net.bytebuddy.description.method.MethodDescription;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface VisibilityBridgeStrategy
/*    */ {
/*    */   boolean generateVisibilityBridge(MethodDescription paramMethodDescription);
/*    */   
/*    */   public enum Default
/*    */     implements VisibilityBridgeStrategy
/*    */   {
/* 43 */     ALWAYS
/*    */     {
/*    */       
/*    */       public boolean generateVisibilityBridge(MethodDescription methodDescription)
/*    */       {
/* 48 */         return true;
/*    */       }
/*    */     },
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 55 */     ON_NON_GENERIC_METHOD
/*    */     {
/*    */       
/*    */       public boolean generateVisibilityBridge(MethodDescription methodDescription)
/*    */       {
/* 60 */         return !methodDescription.isGenerified();
/*    */       }
/*    */     },
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 67 */     NEVER
/*    */     {
/*    */       
/*    */       public boolean generateVisibilityBridge(MethodDescription methodDescription)
/*    */       {
/* 72 */         return false;
/*    */       }
/*    */     };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\VisibilityBridgeStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */