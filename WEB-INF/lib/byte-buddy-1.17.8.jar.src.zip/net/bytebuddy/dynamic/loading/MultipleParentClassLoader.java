/*     */ package net.bytebuddy.dynamic.loading;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.Set;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ import net.bytebuddy.utility.nullability.UnknownNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MultipleParentClassLoader
/*     */   extends InjectionClassLoader
/*     */ {
/*     */   private final List<? extends ClassLoader> parents;
/*     */   
/*     */   static {
/*  58 */     doRegisterAsParallelCapable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressFBWarnings(value = {"DP_DO_INSIDE_DO_PRIVILEGED"}, justification = "Must be invoked from targeting class loader type.")
/*     */   private static void doRegisterAsParallelCapable() {
/*     */     try {
/*  67 */       Method method = ClassLoader.class.getDeclaredMethod("registerAsParallelCapable", new Class[0]);
/*  68 */       method.setAccessible(true);
/*  69 */       method.invoke(null, new Object[0]);
/*  70 */     } catch (Throwable throwable) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipleParentClassLoader(List<? extends ClassLoader> parents) {
/*  87 */     this(ClassLoadingStrategy.BOOTSTRAP_LOADER, parents);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipleParentClassLoader(@MaybeNull ClassLoader parent, List<? extends ClassLoader> parents) {
/*  99 */     this(parent, parents, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipleParentClassLoader(@MaybeNull ClassLoader parent, List<? extends ClassLoader> parents, boolean sealed) {
/* 112 */     super(parent, sealed);
/* 113 */     this.parents = parents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
/* 120 */     for (ClassLoader parent : this.parents) {
/*     */       try {
/* 122 */         Class<?> type = parent.loadClass(name);
/* 123 */         if (resolve) {
/* 124 */           resolveClass(type);
/*     */         }
/* 126 */         return type;
/* 127 */       } catch (ClassNotFoundException classNotFoundException) {}
/*     */     } 
/*     */ 
/*     */     
/* 131 */     return super.loadClass(name, resolve);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getResource(String name) {
/* 138 */     for (ClassLoader parent : this.parents) {
/* 139 */       URL url = parent.getResource(name);
/* 140 */       if (url != null) {
/* 141 */         return url;
/*     */       }
/*     */     } 
/* 144 */     return super.getResource(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enumeration<URL> getResources(String name) throws IOException {
/* 151 */     List<Enumeration<URL>> enumerations = new ArrayList<Enumeration<URL>>(this.parents.size() + 1);
/* 152 */     for (ClassLoader parent : this.parents) {
/* 153 */       enumerations.add(parent.getResources(name));
/*     */     }
/* 155 */     enumerations.add(super.getResources(name));
/* 156 */     return new CompoundEnumeration(enumerations);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Map<String, Class<?>> doDefineClasses(Map<String, byte[]> typeDefinitions) {
/* 161 */     Map<String, Class<?>> types = new HashMap<String, Class<?>>();
/* 162 */     for (Map.Entry<String, byte[]> entry : typeDefinitions.entrySet()) {
/* 163 */       types.put(entry.getKey(), defineClass(entry.getKey(), entry.getValue(), 0, ((byte[])entry.getValue()).length));
/*     */     }
/* 165 */     return types;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class CompoundEnumeration
/*     */     implements Enumeration<URL>
/*     */   {
/*     */     private static final int FIRST = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<Enumeration<URL>> enumerations;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @UnknownNull
/*     */     private Enumeration<URL> current;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected CompoundEnumeration(List<Enumeration<URL>> enumerations) {
/* 195 */       this.enumerations = enumerations;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasMoreElements() {
/* 202 */       if (this.current != null && this.current.hasMoreElements())
/* 203 */         return true; 
/* 204 */       if (!this.enumerations.isEmpty()) {
/* 205 */         this.current = this.enumerations.remove(0);
/* 206 */         return hasMoreElements();
/*     */       } 
/* 208 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @SuppressFBWarnings(value = {"UWF_FIELD_NOT_INITIALIZED_IN_CONSTRUCTOR"}, justification = "Null reference is avoided by element check.")
/*     */     public URL nextElement() {
/* 217 */       if (hasMoreElements()) {
/* 218 */         return this.current.nextElement();
/*     */       }
/* 220 */       throw new NoSuchElementException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Builder
/*     */   {
/*     */     private final boolean sealed;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<? extends ClassLoader> classLoaders;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder() {
/* 250 */       this(true);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder(boolean sealed) {
/* 259 */       this(Collections.emptyList(), sealed);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Builder(List<? extends ClassLoader> classLoaders, boolean sealed) {
/* 269 */       this.classLoaders = classLoaders;
/* 270 */       this.sealed = sealed;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder append(Class<?>... type) {
/* 282 */       return append(Arrays.asList(type));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder append(Collection<? extends Class<?>> types) {
/* 293 */       List<ClassLoader> classLoaders = new ArrayList<ClassLoader>(types.size());
/* 294 */       for (Class<?> type : types) {
/* 295 */         classLoaders.add(type.getClassLoader());
/*     */       }
/* 297 */       return append(classLoaders);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder append(ClassLoader... classLoader) {
/* 308 */       return append(Arrays.asList(classLoader));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder append(List<? extends ClassLoader> classLoaders) {
/* 319 */       List<ClassLoader> filtered = new ArrayList<ClassLoader>(this.classLoaders.size() + classLoaders.size());
/* 320 */       filtered.addAll(this.classLoaders);
/* 321 */       Set<ClassLoader> registered = new HashSet<ClassLoader>(this.classLoaders);
/* 322 */       for (ClassLoader classLoader : classLoaders) {
/* 323 */         if (classLoader != null && registered.add(classLoader)) {
/* 324 */           filtered.add(classLoader);
/*     */         }
/*     */       } 
/* 327 */       return new Builder(filtered, this.sealed);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder appendMostSpecific(Class<?>... type) {
/* 340 */       return appendMostSpecific(Arrays.asList(type));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder appendMostSpecific(Collection<? extends Class<?>> types) {
/* 352 */       List<ClassLoader> classLoaders = new ArrayList<ClassLoader>(types.size());
/* 353 */       for (Class<?> type : types) {
/* 354 */         classLoaders.add(type.getClassLoader());
/*     */       }
/* 356 */       return appendMostSpecific(classLoaders);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder appendMostSpecific(ClassLoader... classLoader) {
/* 367 */       return appendMostSpecific(Arrays.asList(classLoader));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder appendMostSpecific(List<? extends ClassLoader> classLoaders) {
/* 378 */       List<ClassLoader> filtered = new ArrayList<ClassLoader>(this.classLoaders.size() + classLoaders.size());
/* 379 */       filtered.addAll(this.classLoaders);
/*     */       
/* 381 */       label32: for (ClassLoader classLoader : classLoaders) {
/* 382 */         if (classLoader == null) {
/*     */           continue;
/*     */         }
/* 385 */         ClassLoader candidate = classLoader;
/*     */         while (true) {
/* 387 */           Iterator<ClassLoader> iterator = filtered.iterator();
/* 388 */           while (iterator.hasNext()) {
/* 389 */             ClassLoader previous = iterator.next();
/* 390 */             if (previous.equals(candidate)) {
/* 391 */               iterator.remove();
/*     */             }
/*     */           } 
/* 394 */           if ((candidate = candidate.getParent()) == null)
/* 395 */           { label29: for (iterator = filtered.iterator(); iterator.hasNext(); ) { ClassLoader previous = iterator.next();
/*     */               
/* 397 */               while (!previous.equals(classLoader))
/*     */               
/*     */               { 
/* 400 */                 if ((previous = previous.getParent()) == null)
/*     */                   continue label29;  }  continue label32; }  break; } 
/* 402 */         }  filtered.add(classLoader);
/*     */       } 
/* 404 */       return new Builder(filtered, this.sealed);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder filter(ElementMatcher<? super ClassLoader> matcher) {
/* 414 */       List<ClassLoader> classLoaders = new ArrayList<ClassLoader>(this.classLoaders.size());
/* 415 */       for (ClassLoader classLoader : this.classLoaders) {
/* 416 */         if (matcher.matches(classLoader)) {
/* 417 */           classLoaders.add(classLoader);
/*     */         }
/*     */       } 
/* 420 */       return new Builder(classLoaders, this.sealed);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassLoader build() {
/* 438 */       return (this.classLoaders.size() == 1) ? this.classLoaders
/* 439 */         .get(0) : 
/* 440 */         doBuild(ClassLoadingStrategy.BOOTSTRAP_LOADER);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassLoader build(ClassLoader parent) {
/* 459 */       return (this.classLoaders.isEmpty() || (this.classLoaders.size() == 1 && this.classLoaders.contains(parent))) ? parent : 
/*     */         
/* 461 */         filter((ElementMatcher<? super ClassLoader>)ElementMatchers.not((ElementMatcher)ElementMatchers.is(parent))).doBuild(parent);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @SuppressFBWarnings(value = {"DP_CREATE_CLASSLOADER_INSIDE_DO_PRIVILEGED"}, justification = "Assuring privilege is explicit user responsibility.")
/*     */     private ClassLoader doBuild(@MaybeNull ClassLoader parent) {
/* 472 */       return new MultipleParentClassLoader(parent, this.classLoaders, this.sealed);
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : ((this.sealed != ((Builder)param1Object).sealed) ? false : (!!this.classLoaders.equals(((Builder)param1Object).classLoaders)))));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return (getClass().hashCode() * 31 + this.sealed) * 31 + this.classLoaders.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\loading\MultipleParentClassLoader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */