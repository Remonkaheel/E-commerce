/*     */ package net.bytebuddy.dynamic.loading;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.lang.instrument.Instrumentation;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ClassLoadingStrategy<T extends ClassLoader>
/*     */ {
/*     */   @AlwaysNull
/*  40 */   public static final ClassLoader BOOTSTRAP_LOADER = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @AlwaysNull
/*  46 */   public static final ProtectionDomain NO_PROTECTION_DOMAIN = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map<TypeDescription, Class<?>> load(@MaybeNull T paramT, Map<TypeDescription, byte[]> paramMap);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Default
/*     */     implements Configurable<ClassLoader>
/*     */   {
/*  73 */     WRAPPER((String)new WrappingDispatcher(ByteArrayClassLoader.PersistenceHandler.LATENT, false)),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     WRAPPER_PERSISTENT((String)new WrappingDispatcher(ByteArrayClassLoader.PersistenceHandler.MANIFEST, false)),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     CHILD_FIRST((String)new WrappingDispatcher(ByteArrayClassLoader.PersistenceHandler.LATENT, true)),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     CHILD_FIRST_PERSISTENT((String)new WrappingDispatcher(ByteArrayClassLoader.PersistenceHandler.MANIFEST, true)),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     INJECTION((String)new InjectionDispatcher());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static final boolean DEFAULT_FORBID_EXISTING = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final ClassLoadingStrategy.Configurable<ClassLoader> dispatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Default(ClassLoadingStrategy.Configurable<ClassLoader> dispatcher) {
/* 141 */       this.dispatcher = dispatcher;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<TypeDescription, Class<?>> load(@MaybeNull ClassLoader classLoader, Map<TypeDescription, byte[]> types) {
/* 148 */       return this.dispatcher.load(classLoader, types);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassLoadingStrategy.Configurable<ClassLoader> with(ProtectionDomain protectionDomain) {
/* 155 */       return this.dispatcher.with(protectionDomain);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassLoadingStrategy.Configurable<ClassLoader> with(PackageDefinitionStrategy packageDefinitionStrategy) {
/* 162 */       return this.dispatcher.with(packageDefinitionStrategy);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassLoadingStrategy.Configurable<ClassLoader> allowExistingTypes() {
/* 169 */       return this.dispatcher.allowExistingTypes();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassLoadingStrategy.Configurable<ClassLoader> opened() {
/* 176 */       return this.dispatcher.opened();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     protected static class InjectionDispatcher
/*     */       implements ClassLoadingStrategy.Configurable<ClassLoader>
/*     */     {
/*     */       @MaybeNull
/*     */       @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*     */       private final ProtectionDomain protectionDomain;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final PackageDefinitionStrategy packageDefinitionStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final boolean forbidExisting;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected InjectionDispatcher() {
/* 213 */         this(NO_PROTECTION_DOMAIN, PackageDefinitionStrategy.NoOp.INSTANCE, true);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private InjectionDispatcher(@MaybeNull ProtectionDomain protectionDomain, PackageDefinitionStrategy packageDefinitionStrategy, boolean forbidExisting) {
/* 226 */         this.protectionDomain = protectionDomain;
/* 227 */         this.packageDefinitionStrategy = packageDefinitionStrategy;
/* 228 */         this.forbidExisting = forbidExisting;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Map<TypeDescription, Class<?>> load(@MaybeNull ClassLoader classLoader, Map<TypeDescription, byte[]> types) {
/* 235 */         if (classLoader == null) {
/* 236 */           throw new IllegalArgumentException("Cannot inject classes into the bootstrap class loader");
/*     */         }
/* 238 */         return (new ClassInjector.UsingReflection(classLoader, this.protectionDomain, this.packageDefinitionStrategy, this.forbidExisting))
/*     */ 
/*     */           
/* 241 */           .inject(types);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ClassLoadingStrategy.Configurable<ClassLoader> with(ProtectionDomain protectionDomain) {
/* 248 */         return new InjectionDispatcher(protectionDomain, this.packageDefinitionStrategy, this.forbidExisting);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ClassLoadingStrategy.Configurable<ClassLoader> with(PackageDefinitionStrategy packageDefinitionStrategy) {
/* 255 */         return new InjectionDispatcher(this.protectionDomain, packageDefinitionStrategy, this.forbidExisting);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ClassLoadingStrategy.Configurable<ClassLoader> allowExistingTypes() {
/* 262 */         return new InjectionDispatcher(this.protectionDomain, this.packageDefinitionStrategy, false);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ClassLoadingStrategy.Configurable<ClassLoader> opened() {
/* 269 */         return this;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         if (this == param2Object) {
/*     */           return true;
/*     */         }
/*     */         if (param2Object == null) {
/*     */           return false;
/*     */         }
/*     */         if (getClass() != param2Object.getClass()) {
/*     */           return false;
/*     */         }
/*     */         if (this.forbidExisting != ((InjectionDispatcher)param2Object).forbidExisting) {
/*     */           return false;
/*     */         }
/*     */         ProtectionDomain protectionDomain1 = ((InjectionDispatcher)param2Object).protectionDomain;
/*     */         ProtectionDomain protectionDomain2 = this.protectionDomain;
/*     */         if (protectionDomain1 != null) {
/*     */           if (protectionDomain2 != null) {
/*     */             if (!protectionDomain2.equals(protectionDomain1)) {
/*     */               return false;
/*     */             }
/*     */           } else {
/*     */             return false;
/*     */           } 
/*     */         } else if (protectionDomain2 != null) {
/*     */           return false;
/*     */         } 
/*     */         return !!this.packageDefinitionStrategy.equals(((InjectionDispatcher)param2Object).packageDefinitionStrategy);
/*     */       }
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         ProtectionDomain protectionDomain = this.protectionDomain;
/*     */         if (protectionDomain != null);
/*     */         return ((getClass().hashCode() * 31 + protectionDomain.hashCode()) * 31 + this.packageDefinitionStrategy.hashCode()) * 31 + this.forbidExisting;
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     protected static class WrappingDispatcher
/*     */       implements ClassLoadingStrategy.Configurable<ClassLoader>
/*     */     {
/*     */       private static final boolean CHILD_FIRST = true;
/*     */       
/*     */       private static final boolean PARENT_FIRST = false;
/*     */       
/*     */       @MaybeNull
/*     */       @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*     */       private final ProtectionDomain protectionDomain;
/*     */       private final ByteArrayClassLoader.PersistenceHandler persistenceHandler;
/*     */       private final PackageDefinitionStrategy packageDefinitionStrategy;
/*     */       private final boolean childFirst;
/*     */       private final boolean forbidExisting;
/*     */       private final boolean sealed;
/*     */       
/*     */       protected WrappingDispatcher(ByteArrayClassLoader.PersistenceHandler persistenceHandler, boolean childFirst) {
/* 329 */         this(NO_PROTECTION_DOMAIN, PackageDefinitionStrategy.Trivial.INSTANCE, persistenceHandler, childFirst, true, true);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private WrappingDispatcher(@MaybeNull ProtectionDomain protectionDomain, PackageDefinitionStrategy packageDefinitionStrategy, ByteArrayClassLoader.PersistenceHandler persistenceHandler, boolean childFirst, boolean forbidExisting, boolean sealed) {
/* 353 */         this.protectionDomain = protectionDomain;
/* 354 */         this.packageDefinitionStrategy = packageDefinitionStrategy;
/* 355 */         this.persistenceHandler = persistenceHandler;
/* 356 */         this.childFirst = childFirst;
/* 357 */         this.forbidExisting = forbidExisting;
/* 358 */         this.sealed = sealed;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Map<TypeDescription, Class<?>> load(@MaybeNull ClassLoader classLoader, Map<TypeDescription, byte[]> types) {
/* 365 */         return this.childFirst ? 
/* 366 */           ByteArrayClassLoader.ChildFirst.load(classLoader, types, this.protectionDomain, this.persistenceHandler, this.packageDefinitionStrategy, this.forbidExisting, this.sealed) : 
/* 367 */           ByteArrayClassLoader.load(classLoader, types, this.protectionDomain, this.persistenceHandler, this.packageDefinitionStrategy, this.forbidExisting, this.sealed);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ClassLoadingStrategy.Configurable<ClassLoader> with(ProtectionDomain protectionDomain) {
/* 374 */         return new WrappingDispatcher(protectionDomain, this.packageDefinitionStrategy, this.persistenceHandler, this.childFirst, this.forbidExisting, this.sealed);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ClassLoadingStrategy.Configurable<ClassLoader> with(PackageDefinitionStrategy packageDefinitionStrategy) {
/* 381 */         return new WrappingDispatcher(this.protectionDomain, packageDefinitionStrategy, this.persistenceHandler, this.childFirst, this.forbidExisting, this.sealed);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ClassLoadingStrategy.Configurable<ClassLoader> allowExistingTypes() {
/* 388 */         return new WrappingDispatcher(this.protectionDomain, this.packageDefinitionStrategy, this.persistenceHandler, this.childFirst, false, this.sealed);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ClassLoadingStrategy.Configurable<ClassLoader> opened() {
/* 395 */         return new WrappingDispatcher(this.protectionDomain, this.packageDefinitionStrategy, this.persistenceHandler, this.childFirst, this.forbidExisting, false);
/*     */       }
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         if (this == param2Object) {
/*     */           return true;
/*     */         }
/*     */         if (param2Object == null) {
/*     */           return false;
/*     */         }
/*     */         if (getClass() != param2Object.getClass()) {
/*     */           return false;
/*     */         }
/*     */         if (this.childFirst != ((WrappingDispatcher)param2Object).childFirst) {
/*     */           return false;
/*     */         }
/*     */         if (this.forbidExisting != ((WrappingDispatcher)param2Object).forbidExisting)
/*     */           return false; 
/*     */         if (this.sealed != ((WrappingDispatcher)param2Object).sealed)
/*     */           return false; 
/*     */         if (!this.persistenceHandler.equals(((WrappingDispatcher)param2Object).persistenceHandler))
/*     */           return false; 
/*     */         ProtectionDomain protectionDomain1 = ((WrappingDispatcher)param2Object).protectionDomain;
/*     */         ProtectionDomain protectionDomain2 = this.protectionDomain;
/*     */         if (protectionDomain1 != null) {
/*     */           if (protectionDomain2 != null) {
/*     */             if (!protectionDomain2.equals(protectionDomain1))
/*     */               return false; 
/*     */           } else {
/*     */             return false;
/*     */           } 
/*     */         } else if (protectionDomain2 != null) {
/*     */           return false;
/*     */         } 
/*     */         return !!this.packageDefinitionStrategy.equals(((WrappingDispatcher)param2Object).packageDefinitionStrategy);
/*     */       }
/*     */       
/*     */       public int hashCode() {
/*     */         ProtectionDomain protectionDomain = this.protectionDomain;
/*     */         if (protectionDomain != null);
/*     */         return (((((getClass().hashCode() * 31 + protectionDomain.hashCode()) * 31 + this.persistenceHandler.hashCode()) * 31 + this.packageDefinitionStrategy.hashCode()) * 31 + this.childFirst) * 31 + this.forbidExisting) * 31 + this.sealed;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface Configurable<S extends ClassLoader>
/*     */     extends ClassLoadingStrategy<S>
/*     */   {
/*     */     Configurable<S> with(ProtectionDomain param1ProtectionDomain);
/*     */     
/*     */     Configurable<S> with(PackageDefinitionStrategy param1PackageDefinitionStrategy);
/*     */     
/*     */     Configurable<S> allowExistingTypes();
/*     */     
/*     */     Configurable<S> opened();
/*     */   }
/*     */   
/*     */   @Enhance
/*     */   public static class UsingLookup
/*     */     implements ClassLoadingStrategy<ClassLoader>
/*     */   {
/*     */     private final ClassInjector classInjector;
/*     */     
/*     */     protected UsingLookup(ClassInjector classInjector) {
/* 459 */       this.classInjector = classInjector;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ClassLoadingStrategy<ClassLoader> of(Object lookup) {
/* 469 */       return new UsingLookup(ClassInjector.UsingLookup.of(lookup));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ClassLoadingStrategy<ClassLoader> withFallback(Callable<?> lookup) {
/* 484 */       return withFallback(lookup, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static ClassLoadingStrategy<ClassLoader> withFallback(Callable<?> lookup, boolean wrapper) {
/* 500 */       if (ClassInjector.UsingLookup.isAvailable())
/*     */         try {
/* 502 */           return of(lookup.call());
/* 503 */         } catch (Exception exception) {
/* 504 */           throw new IllegalStateException(exception);
/*     */         }  
/* 506 */       if (ClassInjector.UsingUnsafe.isAvailable())
/* 507 */         return new ClassLoadingStrategy.ForUnsafeInjection(); 
/* 508 */       if (wrapper) {
/* 509 */         return ClassLoadingStrategy.Default.WRAPPER;
/*     */       }
/* 511 */       throw new IllegalStateException("Neither lookup or unsafe class injection is available");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<TypeDescription, Class<?>> load(@MaybeNull ClassLoader classLoader, Map<TypeDescription, byte[]> types) {
/* 519 */       return this.classInjector.inject(types);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.classInjector.equals(((UsingLookup)param1Object).classInjector))));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.classInjector.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class ForBootstrapInjection
/*     */     implements ClassLoadingStrategy<ClassLoader>
/*     */   {
/*     */     private final Instrumentation instrumentation;
/*     */     
/*     */     private final File folder;
/*     */ 
/*     */     
/*     */     public ForBootstrapInjection(Instrumentation instrumentation, File folder) {
/* 547 */       this.instrumentation = instrumentation;
/* 548 */       this.folder = folder;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<TypeDescription, Class<?>> load(@MaybeNull ClassLoader classLoader, Map<TypeDescription, byte[]> types) {
/* 556 */       ClassInjector classInjector = (classLoader == null) ? ClassInjector.UsingInstrumentation.of(this.folder, ClassInjector.UsingInstrumentation.Target.BOOTSTRAP, this.instrumentation) : new ClassInjector.UsingReflection(classLoader);
/*     */       
/* 558 */       return classInjector.inject(types);
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.instrumentation.equals(((ForBootstrapInjection)param1Object).instrumentation) ? false : (!!this.folder.equals(((ForBootstrapInjection)param1Object).folder)))));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return (getClass().hashCode() * 31 + this.instrumentation.hashCode()) * 31 + this.folder.hashCode();
/*     */     }
/*     */   }
/*     */   
/*     */   @Enhance
/*     */   public static class ForUnsafeInjection
/*     */     implements ClassLoadingStrategy<ClassLoader>
/*     */   {
/*     */     @MaybeNull
/*     */     @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*     */     private final ProtectionDomain protectionDomain;
/*     */     
/*     */     public ForUnsafeInjection() {
/* 579 */       this(NO_PROTECTION_DOMAIN);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForUnsafeInjection(@MaybeNull ProtectionDomain protectionDomain) {
/* 588 */       this.protectionDomain = protectionDomain;
/*     */     } public boolean equals(@MaybeNull Object param1Object) { if (this == param1Object)
/*     */         return true;  if (param1Object == null)
/*     */         return false;  if (getClass() != param1Object.getClass())
/*     */         return false;  ProtectionDomain protectionDomain1 = ((ForUnsafeInjection)param1Object).protectionDomain; ProtectionDomain protectionDomain2 = this.protectionDomain; if (protectionDomain1 != null) { if (protectionDomain2 != null) { if (!protectionDomain2.equals(protectionDomain1))
/*     */             return false;  } else { return false; }  }
/*     */       else if (protectionDomain2 != null) { return false; }
/* 595 */        return true; } public Map<TypeDescription, Class<?>> load(@MaybeNull ClassLoader classLoader, Map<TypeDescription, byte[]> types) { return (new ClassInjector.UsingUnsafe(classLoader, this.protectionDomain)).inject(types); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       ProtectionDomain protectionDomain = this.protectionDomain;
/*     */       if (protectionDomain != null);
/*     */       return getClass().hashCode() * 31 + protectionDomain.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class ForJnaInjection
/*     */     implements ClassLoadingStrategy<ClassLoader>
/*     */   {
/*     */     public ForJnaInjection() {
/* 617 */       this(NO_PROTECTION_DOMAIN);
/*     */     }
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*     */     private final ProtectionDomain protectionDomain;
/*     */     
/*     */     public ForJnaInjection(@MaybeNull ProtectionDomain protectionDomain) {
/* 626 */       this.protectionDomain = protectionDomain;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<TypeDescription, Class<?>> load(@MaybeNull ClassLoader classLoader, Map<TypeDescription, byte[]> types) {
/* 633 */       return (new ClassInjector.UsingUnsafe(classLoader, this.protectionDomain)).inject(types);
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       if (this == param1Object)
/*     */         return true; 
/*     */       if (param1Object == null)
/*     */         return false; 
/*     */       if (getClass() != param1Object.getClass())
/*     */         return false; 
/*     */       ProtectionDomain protectionDomain1 = ((ForJnaInjection)param1Object).protectionDomain;
/*     */       ProtectionDomain protectionDomain2 = this.protectionDomain;
/*     */       if (protectionDomain1 != null) {
/*     */         if (protectionDomain2 != null) {
/*     */           if (!protectionDomain2.equals(protectionDomain1))
/*     */             return false; 
/*     */         } else {
/*     */           return false;
/*     */         } 
/*     */       } else if (protectionDomain2 != null) {
/*     */         return false;
/*     */       } 
/*     */       return true;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       ProtectionDomain protectionDomain = this.protectionDomain;
/*     */       if (protectionDomain != null);
/*     */       return getClass().hashCode() * 31 + protectionDomain.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\loading\ClassLoadingStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */