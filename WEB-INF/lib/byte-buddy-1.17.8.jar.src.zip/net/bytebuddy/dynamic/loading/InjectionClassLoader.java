/*     */ package net.bytebuddy.dynamic.loading;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class InjectionClassLoader
/*     */   extends ClassLoader
/*     */ {
/*     */   private final AtomicBoolean sealed;
/*     */   
/*     */   static {
/*  43 */     doRegisterAsParallelCapable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SuppressFBWarnings(value = {"DP_DO_INSIDE_DO_PRIVILEGED"}, justification = "Must be invoked from targeting class loader type.")
/*     */   private static void doRegisterAsParallelCapable() {
/*     */     try {
/*  52 */       Method method = ClassLoader.class.getDeclaredMethod("registerAsParallelCapable", new Class[0]);
/*  53 */       method.setAccessible(true);
/*  54 */       method.invoke(null, new Object[0]);
/*  55 */     } catch (Throwable throwable) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InjectionClassLoader(@MaybeNull ClassLoader parent, boolean sealed) {
/*  72 */     super(parent);
/*  73 */     this.sealed = new AtomicBoolean(sealed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSealed() {
/*  82 */     return this.sealed.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean seal() {
/*  91 */     return !this.sealed.getAndSet(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> defineClass(String name, byte[] binaryRepresentation) throws ClassNotFoundException {
/* 103 */     return defineClasses((Map)Collections.singletonMap(name, binaryRepresentation)).get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Class<?>> defineClasses(Map<String, byte[]> typeDefinitions) throws ClassNotFoundException {
/* 114 */     if (this.sealed.get()) {
/* 115 */       throw new IllegalStateException("Cannot inject classes into a sealed class loader");
/*     */     }
/* 117 */     return doDefineClasses(typeDefinitions);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Map<String, Class<?>> doDefineClasses(Map<String, byte[]> paramMap) throws ClassNotFoundException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Strategy
/*     */     implements ClassLoadingStrategy<InjectionClassLoader>
/*     */   {
/* 137 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Map<TypeDescription, Class<?>> load(@MaybeNull InjectionClassLoader classLoader, Map<TypeDescription, byte[]> types) {
/* 143 */       if (classLoader == null) {
/* 144 */         throw new IllegalArgumentException("Cannot add types to bootstrap class loader: " + types);
/*     */       }
/* 146 */       Map<String, byte[]> typeDefinitions = (Map)new LinkedHashMap<String, byte>();
/* 147 */       Map<String, TypeDescription> typeDescriptions = new HashMap<String, TypeDescription>();
/* 148 */       for (Map.Entry<TypeDescription, byte[]> entry : types.entrySet()) {
/* 149 */         typeDefinitions.put(((TypeDescription)entry.getKey()).getName(), entry.getValue());
/* 150 */         typeDescriptions.put(((TypeDescription)entry.getKey()).getName(), entry.getKey());
/*     */       } 
/* 152 */       Map<TypeDescription, Class<?>> loadedTypes = new HashMap<TypeDescription, Class<?>>();
/*     */       try {
/* 154 */         for (Map.Entry<String, Class<?>> entry : classLoader.defineClasses(typeDefinitions).entrySet()) {
/* 155 */           loadedTypes.put(typeDescriptions.get(entry.getKey()), entry.getValue());
/*     */         }
/* 157 */       } catch (ClassNotFoundException exception) {
/* 158 */         throw new IllegalStateException("Cannot load classes: " + types, exception);
/*     */       } 
/* 160 */       return loadedTypes;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\loading\InjectionClassLoader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */