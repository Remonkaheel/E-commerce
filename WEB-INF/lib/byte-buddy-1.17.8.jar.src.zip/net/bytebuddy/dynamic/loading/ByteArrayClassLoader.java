/*      */ package net.bytebuddy.dynamic.loading;
/*      */ 
/*      */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URI;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.net.URLEncoder;
/*      */ import java.net.URLStreamHandler;
/*      */ import java.security.AccessControlContext;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.ProtectionDomain;
/*      */ import java.util.Arrays;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentMap;
/*      */ import net.bytebuddy.ClassFileVersion;
/*      */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*      */ import net.bytebuddy.description.type.TypeDescription;
/*      */ import net.bytebuddy.utility.GraalImageCode;
/*      */ import net.bytebuddy.utility.JavaModule;
/*      */ import net.bytebuddy.utility.dispatcher.JavaDispatcher;
/*      */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Defaults;
/*      */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.IsConstructor;
/*      */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.IsStatic;
/*      */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Proxied;
/*      */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ByteArrayClassLoader
/*      */   extends InjectionClassLoader
/*      */ {
/*      */   public static final String URL_SCHEMA = "bytebuddy";
/*      */   private static final int FROM_BEGINNING = 0;
/*      */   @AlwaysNull
/*   73 */   private static final URL NO_URL = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   78 */   private static final PackageLookupStrategy PACKAGE_LOOKUP_STRATEGY = doPrivileged(PackageLookupStrategy.CreationAction.INSTANCE);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   83 */   protected static final SynchronizationStrategy.Initializable SYNCHRONIZATION_STRATEGY = doPrivileged(SynchronizationStrategy.CreationAction.INSTANCE); protected final ConcurrentMap<String, byte[]> typeDefinitions; protected final PersistenceHandler persistenceHandler; @MaybeNull
/*      */   protected final ProtectionDomain protectionDomain; protected final PackageDefinitionStrategy packageDefinitionStrategy; protected final ClassFilePostProcessor classFilePostProcessor;
/*      */   @MaybeNull
/*      */   protected final Object accessControlContext;
/*      */   private static final boolean ACCESS_CONTROLLER;
/*      */   
/*   89 */   static { doRegisterAsParallelCapable(); } static { 
/*   90 */     try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*      */      }
/*      */ 
/*      */ 
/*      */   
/*      */   @SuppressFBWarnings(value = {"DP_DO_INSIDE_DO_PRIVILEGED"}, justification = "Must be invoked from targeting class loader type.")
/*      */   private static void doRegisterAsParallelCapable() {
/*      */     try {
/*   98 */       Method method = ClassLoader.class.getDeclaredMethod("registerAsParallelCapable", new Class[0]);
/*   99 */       method.setAccessible(true);
/*  100 */       method.invoke(null, new Object[0]);
/*  101 */     } catch (Throwable throwable) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   private static <T> T doPrivileged(PrivilegedAction<T> action) {
/*  115 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteArrayClassLoader(@MaybeNull ClassLoader parent, Map<String, byte[]> typeDefinitions) {
/*  157 */     this(parent, true, typeDefinitions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteArrayClassLoader(@MaybeNull ClassLoader parent, boolean sealed, Map<String, byte[]> typeDefinitions) {
/*  168 */     this(parent, sealed, typeDefinitions, PersistenceHandler.LATENT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteArrayClassLoader(@MaybeNull ClassLoader parent, Map<String, byte[]> typeDefinitions, PersistenceHandler persistenceHandler) {
/*  179 */     this(parent, true, typeDefinitions, persistenceHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteArrayClassLoader(@MaybeNull ClassLoader parent, boolean sealed, Map<String, byte[]> typeDefinitions, PersistenceHandler persistenceHandler) {
/*  191 */     this(parent, sealed, typeDefinitions, ClassLoadingStrategy.NO_PROTECTION_DOMAIN, persistenceHandler, PackageDefinitionStrategy.Trivial.INSTANCE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteArrayClassLoader(@MaybeNull ClassLoader parent, Map<String, byte[]> typeDefinitions, @MaybeNull ProtectionDomain protectionDomain, PersistenceHandler persistenceHandler, PackageDefinitionStrategy packageDefinitionStrategy) {
/*  208 */     this(parent, true, typeDefinitions, protectionDomain, persistenceHandler, packageDefinitionStrategy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteArrayClassLoader(@MaybeNull ClassLoader parent, boolean sealed, Map<String, byte[]> typeDefinitions, @MaybeNull ProtectionDomain protectionDomain, PersistenceHandler persistenceHandler, PackageDefinitionStrategy packageDefinitionStrategy) {
/*  227 */     this(parent, sealed, typeDefinitions, protectionDomain, persistenceHandler, packageDefinitionStrategy, ClassFilePostProcessor.NoOp.INSTANCE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteArrayClassLoader(@MaybeNull ClassLoader parent, Map<String, byte[]> typeDefinitions, @MaybeNull ProtectionDomain protectionDomain, PersistenceHandler persistenceHandler, PackageDefinitionStrategy packageDefinitionStrategy, ClassFilePostProcessor classFilePostProcessor) {
/*  246 */     this(parent, true, typeDefinitions, protectionDomain, persistenceHandler, packageDefinitionStrategy, classFilePostProcessor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteArrayClassLoader(@MaybeNull ClassLoader parent, boolean sealed, Map<String, byte[]> typeDefinitions, @MaybeNull ProtectionDomain protectionDomain, PersistenceHandler persistenceHandler, PackageDefinitionStrategy packageDefinitionStrategy, ClassFilePostProcessor classFilePostProcessor) {
/*  267 */     super(parent, sealed);
/*  268 */     this.typeDefinitions = (ConcurrentMap)new ConcurrentHashMap<String, byte>((Map)typeDefinitions);
/*  269 */     this.protectionDomain = protectionDomain;
/*  270 */     this.persistenceHandler = persistenceHandler;
/*  271 */     this.packageDefinitionStrategy = packageDefinitionStrategy;
/*  272 */     this.classFilePostProcessor = classFilePostProcessor;
/*  273 */     this.accessControlContext = getContext();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @MaybeNull
/*      */   @Enhance
/*      */   private static Object getContext() {
/*  284 */     return ACCESS_CONTROLLER ? AccessController.getContext() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   private static <T> T doPrivileged(PrivilegedAction<T> action, @MaybeNull Object context) {
/*  297 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0, (AccessControlContext)SYNTHETIC_LOCAL_VARIABLE_1) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object methodHandle() throws Exception {
/*  307 */     return Class.forName("java.lang.invoke.MethodHandles").getMethod("lookup", new Class[0]).invoke(null, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<TypeDescription, Class<?>> load(@MaybeNull ClassLoader classLoader, Map<TypeDescription, byte[]> types) {
/*  318 */     return load(classLoader, types, ClassLoadingStrategy.NO_PROTECTION_DOMAIN, PersistenceHandler.LATENT, PackageDefinitionStrategy.Trivial.INSTANCE, false, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @SuppressFBWarnings(value = {"DP_CREATE_CLASSLOADER_INSIDE_DO_PRIVILEGED"}, justification = "Assuring privilege is explicit user responsibility.")
/*      */   public static Map<TypeDescription, Class<?>> load(@MaybeNull ClassLoader classLoader, Map<TypeDescription, byte[]> types, @MaybeNull ProtectionDomain protectionDomain, PersistenceHandler persistenceHandler, PackageDefinitionStrategy packageDefinitionStrategy, boolean forbidExisting, boolean sealed) {
/*  347 */     Map<String, byte[]> typesByName = (Map)new HashMap<String, byte>();
/*  348 */     for (Map.Entry<TypeDescription, byte[]> entry : types.entrySet()) {
/*  349 */       typesByName.put(((TypeDescription)entry.getKey()).getName(), entry.getValue());
/*      */     }
/*  351 */     classLoader = new ByteArrayClassLoader(classLoader, sealed, typesByName, protectionDomain, persistenceHandler, packageDefinitionStrategy, ClassFilePostProcessor.NoOp.INSTANCE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  358 */     Map<TypeDescription, Class<?>> result = new LinkedHashMap<TypeDescription, Class<?>>();
/*  359 */     for (TypeDescription typeDescription : types.keySet()) {
/*      */       try {
/*  361 */         Class<?> type = Class.forName(typeDescription.getName(), false, classLoader);
/*  362 */         if (!GraalImageCode.getCurrent().isNativeImageExecution() && forbidExisting && type.getClassLoader() != classLoader) {
/*  363 */           throw new IllegalStateException("Class already loaded: " + type);
/*      */         }
/*  365 */         result.put(typeDescription, type);
/*  366 */       } catch (ClassNotFoundException exception) {
/*  367 */         throw new IllegalStateException("Cannot load class " + typeDescription, exception);
/*      */       } 
/*      */     } 
/*  370 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Map<String, Class<?>> doDefineClasses(Map<String, byte[]> typeDefinitions) throws ClassNotFoundException {
/*  375 */     Map<String, byte[]> previous = (Map)new HashMap<String, byte>();
/*  376 */     for (Map.Entry<String, byte[]> entry : typeDefinitions.entrySet()) {
/*  377 */       previous.put(entry.getKey(), this.typeDefinitions.putIfAbsent(entry.getKey(), entry.getValue()));
/*      */     }
/*      */     try {
/*  380 */       Map<String, Class<?>> types = new LinkedHashMap<String, Class<?>>();
/*  381 */       for (String name : typeDefinitions.keySet()) {
/*  382 */         synchronized (SYNCHRONIZATION_STRATEGY.initialize().getClassLoadingLock(this, name)) {
/*  383 */           types.put(name, loadClass(name));
/*      */         } 
/*      */       } 
/*  386 */       return types;
/*      */     } finally {
/*  388 */       for (Map.Entry<String, byte[]> entry : previous.entrySet()) {
/*  389 */         if (entry.getValue() == null) {
/*  390 */           this.persistenceHandler.release(entry.getKey(), this.typeDefinitions); continue;
/*      */         } 
/*  392 */         this.typeDefinitions.put(entry.getKey(), entry.getValue());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Class<?> findClass(String name) throws ClassNotFoundException {
/*  402 */     byte[] binaryRepresentation = this.persistenceHandler.lookup(name, this.typeDefinitions);
/*  403 */     if (binaryRepresentation == null) {
/*  404 */       throw new ClassNotFoundException(name);
/*      */     }
/*  406 */     return doPrivileged(new ClassDefinitionAction(name, this.classFilePostProcessor.transform(this, name, this.protectionDomain, binaryRepresentation)), this.accessControlContext);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @MaybeNull
/*      */   protected URL findResource(String name) {
/*  418 */     return this.persistenceHandler.url(name, this.typeDefinitions);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Enumeration<URL> findResources(String name) {
/*  425 */     URL url = this.persistenceHandler.url(name, this.typeDefinitions);
/*  426 */     return (url == null) ? EmptyEnumeration.INSTANCE : new SingletonEnumeration(url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @MaybeNull
/*      */   private Package doGetPackage(String name) {
/*  440 */     return getPackage(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum CreationAction
/*      */     implements PrivilegedAction<SynchronizationStrategy.Initializable>
/*      */   {
/*  478 */     INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.")
/*      */     public ByteArrayClassLoader.SynchronizationStrategy.Initializable run()
/*      */     {
/*      */       
/*  487 */       try { Class<?> methodType = Class.forName("java.lang.invoke.MethodType"), methodHandle = Class.forName("java.lang.invoke.MethodHandle");
/*  488 */         return new ByteArrayClassLoader.SynchronizationStrategy.ForJava8CapableVm(Class.forName("java.lang.invoke.MethodHandles$Lookup")
/*  489 */             .getMethod("findVirtual", new Class[] { Class.class, String.class, methodType
/*  490 */               }).invoke(ByteArrayClassLoader.methodHandle(), new Object[] { ClassLoader.class, "getClassLoadingLock", methodType.getMethod("methodType", new Class[] { Class.class, Class[].class
/*      */                   
/*  492 */                   }).invoke(null, new Object[] { Object.class, { String.class }
/*  493 */                   }) }), methodHandle.getMethod("bindTo", new Class[] { Object.class }), methodHandle
/*  494 */             .getMethod("invokeWithArguments", new Class[] { Object[].class })); }
/*  495 */       catch (Exception ignored)
/*      */       
/*      */       { 
/*  498 */         return (ClassFileVersion.ofThisVm(ClassFileVersion.JAVA_V5).isAtLeast(ClassFileVersion.JAVA_V9) && ByteArrayClassLoader.class.getClassLoader() == null) ? ByteArrayClassLoader.SynchronizationStrategy.ForLegacyVm.INSTANCE : new ByteArrayClassLoader.SynchronizationStrategy.ForJava7CapableVm(ClassLoader.class
/*      */             
/*  500 */             .getDeclaredMethod("getClassLoadingLock", new Class[] { String.class })); }
/*      */       
/*  502 */       catch (Exception ignored)
/*  503 */       { return ByteArrayClassLoader.SynchronizationStrategy.ForLegacyVm.INSTANCE; }  } } protected static interface SynchronizationStrategy { Object getClassLoadingLock(ByteArrayClassLoader param1ByteArrayClassLoader, String param1String); public static interface Initializable { ByteArrayClassLoader.SynchronizationStrategy initialize(); } public enum CreationAction implements PrivilegedAction<Initializable> { @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.") public ByteArrayClassLoader.SynchronizationStrategy.Initializable run() { try { Class<?> methodType = Class.forName("java.lang.invoke.MethodType"), methodHandle = Class.forName("java.lang.invoke.MethodHandle"); return new ByteArrayClassLoader.SynchronizationStrategy.ForJava8CapableVm(Class.forName("java.lang.invoke.MethodHandles$Lookup").getMethod("findVirtual", new Class[] { Class.class, String.class, methodType }).invoke(ByteArrayClassLoader.methodHandle(), new Object[] { ClassLoader.class, "getClassLoadingLock", methodType.getMethod("methodType", new Class[] { Class.class, Class[].class }).invoke(null, new Object[] { Object.class, { String.class } }) }), methodHandle.getMethod("bindTo", new Class[] { Object.class }), methodHandle.getMethod("invokeWithArguments", new Class[] { Object[].class })); } catch (Exception ignored) { return (ClassFileVersion.ofThisVm(ClassFileVersion.JAVA_V5).isAtLeast(ClassFileVersion.JAVA_V9) && ByteArrayClassLoader.class.getClassLoader() == null) ? ByteArrayClassLoader.SynchronizationStrategy.ForLegacyVm.INSTANCE : new ByteArrayClassLoader.SynchronizationStrategy.ForJava7CapableVm(ClassLoader.class.getDeclaredMethod("getClassLoadingLock", new Class[] { String.class })); } catch (Exception ignored) { return ByteArrayClassLoader.SynchronizationStrategy.ForLegacyVm.INSTANCE; }
/*      */          }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       INSTANCE; }
/*      */ 
/*      */ 
/*      */     
/*      */     public enum ForLegacyVm
/*      */       implements SynchronizationStrategy, Initializable
/*      */     {
/*  516 */       INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Object getClassLoadingLock(ByteArrayClassLoader classLoader, String name) {
/*  522 */         return classLoader;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ByteArrayClassLoader.SynchronizationStrategy initialize() {
/*  529 */         return this;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class ForJava7CapableVm
/*      */       implements SynchronizationStrategy, Initializable
/*      */     {
/*      */       private final Method method;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected ForJava7CapableVm(Method method) {
/*  550 */         this.method = method;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Object getClassLoadingLock(ByteArrayClassLoader classLoader, String name) {
/*      */         try {
/*  558 */           return this.method.invoke(classLoader, new Object[] { name });
/*  559 */         } catch (IllegalAccessException exception) {
/*  560 */           throw new IllegalStateException(exception);
/*  561 */         } catch (InvocationTargetException exception) {
/*  562 */           throw new IllegalStateException(exception.getTargetException());
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @SuppressFBWarnings(value = {"DP_DO_INSIDE_DO_PRIVILEGED"}, justification = "Assuring privilege is explicit user responsibility.")
/*      */       public ByteArrayClassLoader.SynchronizationStrategy initialize() {
/*      */         try {
/*  572 */           this.method.setAccessible(true);
/*  573 */           return this;
/*  574 */         } catch (Exception ignored) {
/*  575 */           return ByteArrayClassLoader.SynchronizationStrategy.ForLegacyVm.INSTANCE;
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.method.equals(((ForJava7CapableVm)param2Object).method))));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return getClass().hashCode() * 31 + this.method.hashCode();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class ForJava8CapableVm
/*      */       implements SynchronizationStrategy, Initializable
/*      */     {
/*      */       private final Object methodHandle;
/*      */ 
/*      */       
/*      */       private final Method bindTo;
/*      */ 
/*      */       
/*      */       private final Method invokeWithArguments;
/*      */ 
/*      */ 
/*      */       
/*      */       protected ForJava8CapableVm(Object methodHandle, Method bindTo, Method invokeWithArguments) {
/*  609 */         this.methodHandle = methodHandle;
/*  610 */         this.bindTo = bindTo;
/*  611 */         this.invokeWithArguments = invokeWithArguments;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ByteArrayClassLoader.SynchronizationStrategy initialize() {
/*  618 */         return this;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Object getClassLoadingLock(ByteArrayClassLoader classLoader, String name) {
/*      */         try {
/*  626 */           return this.invokeWithArguments.invoke(this.bindTo.invoke(this.methodHandle, new Object[] { classLoader }), new Object[] { { name } });
/*  627 */         } catch (IllegalAccessException exception) {
/*  628 */           throw new IllegalStateException(exception);
/*  629 */         } catch (InvocationTargetException exception) {
/*  630 */           throw new IllegalStateException(exception.getTargetException());
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.methodHandle.equals(((ForJava8CapableVm)param2Object).methodHandle) ? false : (!this.bindTo.equals(((ForJava8CapableVm)param2Object).bindTo) ? false : (!!this.invokeWithArguments.equals(((ForJava8CapableVm)param2Object).invokeWithArguments))))));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return ((getClass().hashCode() * 31 + this.methodHandle.hashCode()) * 31 + this.bindTo.hashCode()) * 31 + this.invokeWithArguments.hashCode();
/*      */       }
/*      */     } }
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance(includeSyntheticFields = true)
/*      */   protected class ClassDefinitionAction
/*      */     implements PrivilegedAction<Class<?>>
/*      */   {
/*      */     private final String name;
/*      */     
/*      */     private final byte[] binaryRepresentation;
/*      */ 
/*      */     
/*      */     protected ClassDefinitionAction(String name, byte[] binaryRepresentation) {
/*  659 */       this.name = name;
/*  660 */       this.binaryRepresentation = binaryRepresentation;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Class<?> run() {
/*  667 */       int packageIndex = this.name.lastIndexOf('.');
/*  668 */       if (packageIndex != -1) {
/*  669 */         String packageName = this.name.substring(0, packageIndex);
/*  670 */         PackageDefinitionStrategy.Definition definition = ByteArrayClassLoader.this.packageDefinitionStrategy.define(ByteArrayClassLoader.this, packageName, this.name);
/*  671 */         if (definition.isDefined()) {
/*  672 */           Package definedPackage = ByteArrayClassLoader.PACKAGE_LOOKUP_STRATEGY.apply(ByteArrayClassLoader.this, packageName);
/*  673 */           if (definedPackage == null) {
/*  674 */             ByteArrayClassLoader.this.definePackage(packageName, definition
/*  675 */                 .getSpecificationTitle(), definition
/*  676 */                 .getSpecificationVersion(), definition
/*  677 */                 .getSpecificationVendor(), definition
/*  678 */                 .getImplementationTitle(), definition
/*  679 */                 .getImplementationVersion(), definition
/*  680 */                 .getImplementationVendor(), definition
/*  681 */                 .getSealBase());
/*  682 */           } else if (!definition.isCompatibleTo(definedPackage)) {
/*  683 */             throw new SecurityException("Sealing violation for package " + packageName);
/*      */           } 
/*      */         } 
/*      */       } 
/*  687 */       return ByteArrayClassLoader.this.defineClass(this.name, this.binaryRepresentation, 0, this.binaryRepresentation.length, ByteArrayClassLoader.this.protectionDomain);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.name.equals(((ClassDefinitionAction)param1Object).name) ? false : (!Arrays.equals(this.binaryRepresentation, ((ClassDefinitionAction)param1Object).binaryRepresentation) ? false : (!!ByteArrayClassLoader.this.equals(ByteArrayClassLoader.this))))));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return ((getClass().hashCode() * 31 + this.name.hashCode()) * 31 + Arrays.hashCode(this.binaryRepresentation)) * 31 + ByteArrayClassLoader.this.hashCode();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum CreationAction
/*      */     implements PrivilegedAction<PackageLookupStrategy>
/*      */   {
/*  714 */     INSTANCE;
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.")
/*      */     public ByteArrayClassLoader.PackageLookupStrategy run()
/*      */     {
/*  721 */       if (JavaModule.isSupported()) {
/*      */         try {
/*  723 */           return new ByteArrayClassLoader.PackageLookupStrategy.ForJava9CapableVm(ClassLoader.class.getMethod("getDefinedPackage", new Class[] { String.class }));
/*  724 */         } catch (Exception ignored) {
/*  725 */           return ByteArrayClassLoader.PackageLookupStrategy.ForLegacyVm.INSTANCE;
/*      */         } 
/*      */       }
/*  728 */       return ByteArrayClassLoader.PackageLookupStrategy.ForLegacyVm.INSTANCE; } } protected static interface PackageLookupStrategy { @MaybeNull Package apply(ByteArrayClassLoader param1ByteArrayClassLoader, String param1String); public enum CreationAction implements PrivilegedAction<PackageLookupStrategy> { INSTANCE; @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.") public ByteArrayClassLoader.PackageLookupStrategy run() { if (JavaModule.isSupported()) try { return new ByteArrayClassLoader.PackageLookupStrategy.ForJava9CapableVm(ClassLoader.class.getMethod("getDefinedPackage", new Class[] { String.class })); } catch (Exception ignored) { return ByteArrayClassLoader.PackageLookupStrategy.ForLegacyVm.INSTANCE; }   return ByteArrayClassLoader.PackageLookupStrategy.ForLegacyVm.INSTANCE; }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public enum ForLegacyVm
/*      */       implements PackageLookupStrategy
/*      */     {
/*  741 */       INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       public Package apply(ByteArrayClassLoader classLoader, String name) {
/*  748 */         return classLoader.doGetPackage(name);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class ForJava9CapableVm
/*      */       implements PackageLookupStrategy
/*      */     {
/*      */       private final Method getDefinedPackage;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected ForJava9CapableVm(Method getDefinedPackage) {
/*  769 */         this.getDefinedPackage = getDefinedPackage;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       public Package apply(ByteArrayClassLoader classLoader, String name) {
/*      */         try {
/*  778 */           return (Package)this.getDefinedPackage.invoke(classLoader, new Object[] { name });
/*  779 */         } catch (IllegalAccessException exception) {
/*  780 */           throw new IllegalStateException(exception);
/*  781 */         } catch (InvocationTargetException exception) {
/*  782 */           throw new IllegalStateException(exception.getTargetException());
/*      */         } 
/*      */       }
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.getDefinedPackage.equals(((ForJava9CapableVm)param2Object).getDefinedPackage))));
/*      */       }
/*      */       
/*      */       public int hashCode() {
/*      */         return getClass().hashCode() * 31 + this.getDefinedPackage.hashCode();
/*      */       }
/*      */     } }
/*      */ 
/*      */   
/*      */   public enum PersistenceHandler {
/*  797 */     MANIFEST(true)
/*      */     {
/*      */       protected byte[] lookup(String name, ConcurrentMap<String, byte[]> typeDefinitions) {
/*  800 */         return typeDefinitions.get(name);
/*      */       }
/*      */ 
/*      */       
/*      */       protected URL url(String resourceName, ConcurrentMap<String, byte[]> typeDefinitions) {
/*  805 */         if (!resourceName.endsWith(".class"))
/*  806 */           return ByteArrayClassLoader.NO_URL; 
/*  807 */         if (resourceName.startsWith("/")) {
/*  808 */           resourceName = resourceName.substring(1);
/*      */         }
/*  810 */         String typeName = resourceName.replace('/', '.').substring(0, resourceName.length() - ".class".length());
/*  811 */         byte[] binaryRepresentation = typeDefinitions.get(typeName);
/*  812 */         return (binaryRepresentation == null) ? ByteArrayClassLoader
/*  813 */           .NO_URL : 
/*  814 */           (URL)ByteArrayClassLoader.doPrivileged(new UrlDefinitionAction(resourceName, binaryRepresentation));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected void release(String name, ConcurrentMap<String, byte[]> typeDefinitions) {}
/*      */     },
/*  827 */     LATENT(false)
/*      */     {
/*      */       protected byte[] lookup(String name, ConcurrentMap<String, byte[]> typeDefinitions) {
/*  830 */         return typeDefinitions.remove(name);
/*      */       }
/*      */ 
/*      */       
/*      */       protected URL url(String resourceName, ConcurrentMap<String, byte[]> typeDefinitions) {
/*  835 */         return ByteArrayClassLoader.NO_URL;
/*      */       }
/*      */ 
/*      */       
/*      */       protected void release(String name, ConcurrentMap<String, byte[]> typeDefinitions) {
/*  840 */         typeDefinitions.remove(name);
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String CLASS_FILE_SUFFIX = ".class";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean manifest;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     PersistenceHandler(boolean manifest) {
/*  860 */       this.manifest = manifest;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isManifest() {
/*  869 */       return this.manifest;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     protected abstract byte[] lookup(String param1String, ConcurrentMap<String, byte[]> param1ConcurrentMap);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     protected abstract URL url(String param1String, ConcurrentMap<String, byte[]> param1ConcurrentMap);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected abstract void release(String param1String, ConcurrentMap<String, byte[]> param1ConcurrentMap);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     protected static class UrlDefinitionAction
/*      */       implements PrivilegedAction<URL>
/*      */     {
/*  909 */       private static final Dispatcher DISPATCHER = doPrivileged(JavaDispatcher.of(Dispatcher.class)); private static final String ENCODING = "UTF-8"; private static final int NO_PORT = -1; private static final String NO_FILE = ""; private final String typeName; private final byte[] binaryRepresentation; private static final boolean ACCESS_CONTROLLER; static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*      */          }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected UrlDefinitionAction(String typeName, byte[] binaryRepresentation) {
/*  943 */         this.typeName = typeName;
/*  944 */         this.binaryRepresentation = binaryRepresentation;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       private static <T> T doPrivileged(PrivilegedAction<T> action) {
/*  956 */         return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public URL run() {
/*      */         try {
/*  964 */           String path = URLEncoder.encode(this.typeName.replace('.', '/'), "UTF-8");
/*  965 */           URLStreamHandler handler = new ByteArrayUrlStreamHandler(this.binaryRepresentation);
/*  966 */           URL url = DISPATCHER.of(URI.create("bytebuddy://" + path), handler);
/*  967 */           return (url == null) ? DISPATCHER
/*  968 */             .make("bytebuddy", path, -1, "", handler) : url;
/*      */         }
/*  970 */         catch (MalformedURLException exception) {
/*  971 */           throw new IllegalStateException("Cannot create URL for " + this.typeName, exception);
/*  972 */         } catch (UnsupportedEncodingException exception) {
/*  973 */           throw new IllegalStateException("Could not find encoding: UTF-8", exception);
/*      */         } 
/*      */       } public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.typeName.equals(((UrlDefinitionAction)param2Object).typeName) ? false : (!!Arrays.equals(this.binaryRepresentation, ((UrlDefinitionAction)param2Object).binaryRepresentation)))));
/*      */       }
/*      */       public int hashCode() {
/*      */         return (getClass().hashCode() * 31 + this.typeName.hashCode()) * 31 + Arrays.hashCode(this.binaryRepresentation);
/*      */       }
/*      */       @Proxied("java.net.URL")
/*      */       protected static interface Dispatcher {
/*      */         @IsConstructor
/*      */         @Proxied("make")
/*      */         URL make(String param3String1, String param3String2, int param3Int, String param3String3, URLStreamHandler param3URLStreamHandler) throws MalformedURLException;
/*      */         @MaybeNull
/*      */         @IsStatic
/*      */         @Defaults
/*      */         @Proxied("of")
/*      */         URL of(URI param3URI, URLStreamHandler param3URLStreamHandler) throws MalformedURLException; }
/*      */       @Enhance
/*      */       protected static class ByteArrayUrlStreamHandler extends URLStreamHandler { private final byte[] binaryRepresentation;
/*      */         protected ByteArrayUrlStreamHandler(byte[] binaryRepresentation) {
/*  994 */           this.binaryRepresentation = binaryRepresentation;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected URLConnection openConnection(URL url) {
/* 1001 */           return new ByteArrayUrlConnection(url, new ByteArrayInputStream(this.binaryRepresentation));
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!Arrays.equals(this.binaryRepresentation, ((ByteArrayUrlStreamHandler)param3Object).binaryRepresentation))));
/*      */         }
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return getClass().hashCode() * 31 + Arrays.hashCode(this.binaryRepresentation);
/*      */         }
/*      */ 
/*      */         
/*      */         protected static class ByteArrayUrlConnection
/*      */           extends URLConnection
/*      */         {
/*      */           private final InputStream inputStream;
/*      */           
/*      */           protected ByteArrayUrlConnection(URL url, InputStream inputStream) {
/* 1021 */             super(url);
/* 1022 */             this.inputStream = inputStream;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void connect() {
/* 1029 */             this.connected = true;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public InputStream getInputStream() {
/* 1036 */             connect();
/* 1037 */             return this.inputStream;
/*      */           }
/*      */         } }
/*      */     
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ChildFirst
/*      */     extends ByteArrayClassLoader
/*      */   {
/*      */     private static final String CLASS_FILE_SUFFIX = ".class";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static {
/* 1099 */       doRegisterAsParallelCapable();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"DP_DO_INSIDE_DO_PRIVILEGED"}, justification = "Must be invoked from targeting class loader type.")
/*      */     private static void doRegisterAsParallelCapable() {
/*      */       try {
/* 1108 */         Method method = ClassLoader.class.getDeclaredMethod("registerAsParallelCapable", new Class[0]);
/* 1109 */         method.setAccessible(true);
/* 1110 */         method.invoke(null, new Object[0]);
/* 1111 */       } catch (Throwable throwable) {}
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ChildFirst(@MaybeNull ClassLoader parent, Map<String, byte[]> typeDefinitions) {
/* 1123 */       super(parent, typeDefinitions);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ChildFirst(@MaybeNull ClassLoader parent, boolean sealed, Map<String, byte[]> typeDefinitions) {
/* 1134 */       super(parent, sealed, typeDefinitions);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ChildFirst(@MaybeNull ClassLoader parent, Map<String, byte[]> typeDefinitions, ByteArrayClassLoader.PersistenceHandler persistenceHandler) {
/* 1145 */       super(parent, typeDefinitions, persistenceHandler);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ChildFirst(@MaybeNull ClassLoader parent, boolean sealed, Map<String, byte[]> typeDefinitions, ByteArrayClassLoader.PersistenceHandler persistenceHandler) {
/* 1157 */       super(parent, sealed, typeDefinitions, persistenceHandler);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ChildFirst(@MaybeNull ClassLoader parent, Map<String, byte[]> typeDefinitions, @MaybeNull ProtectionDomain protectionDomain, ByteArrayClassLoader.PersistenceHandler persistenceHandler, PackageDefinitionStrategy packageDefinitionStrategy) {
/* 1174 */       super(parent, typeDefinitions, protectionDomain, persistenceHandler, packageDefinitionStrategy);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ChildFirst(@MaybeNull ClassLoader parent, boolean sealed, Map<String, byte[]> typeDefinitions, @MaybeNull ProtectionDomain protectionDomain, ByteArrayClassLoader.PersistenceHandler persistenceHandler, PackageDefinitionStrategy packageDefinitionStrategy) {
/* 1193 */       super(parent, sealed, typeDefinitions, protectionDomain, persistenceHandler, packageDefinitionStrategy);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ChildFirst(@MaybeNull ClassLoader parent, Map<String, byte[]> typeDefinitions, @MaybeNull ProtectionDomain protectionDomain, ByteArrayClassLoader.PersistenceHandler persistenceHandler, PackageDefinitionStrategy packageDefinitionStrategy, ClassFilePostProcessor classFilePostProcessor) {
/* 1212 */       super(parent, typeDefinitions, protectionDomain, persistenceHandler, packageDefinitionStrategy, classFilePostProcessor);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ChildFirst(@MaybeNull ClassLoader parent, boolean sealed, Map<String, byte[]> typeDefinitions, @MaybeNull ProtectionDomain protectionDomain, ByteArrayClassLoader.PersistenceHandler persistenceHandler, PackageDefinitionStrategy packageDefinitionStrategy, ClassFilePostProcessor classFilePostProcessor) {
/* 1233 */       super(parent, sealed, typeDefinitions, protectionDomain, persistenceHandler, packageDefinitionStrategy, classFilePostProcessor);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Map<TypeDescription, Class<?>> load(@MaybeNull ClassLoader classLoader, Map<TypeDescription, byte[]> types) {
/* 1244 */       return load(classLoader, types, ClassLoadingStrategy.NO_PROTECTION_DOMAIN, ByteArrayClassLoader.PersistenceHandler.LATENT, PackageDefinitionStrategy.Trivial.INSTANCE, false, true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"DP_CREATE_CLASSLOADER_INSIDE_DO_PRIVILEGED"}, justification = "Assuring privilege is explicit user responsibility.")
/*      */     public static Map<TypeDescription, Class<?>> load(@MaybeNull ClassLoader classLoader, Map<TypeDescription, byte[]> types, @MaybeNull ProtectionDomain protectionDomain, ByteArrayClassLoader.PersistenceHandler persistenceHandler, PackageDefinitionStrategy packageDefinitionStrategy, boolean forbidExisting, boolean sealed) {
/* 1273 */       Map<String, byte[]> typesByName = (Map)new HashMap<String, byte>();
/* 1274 */       for (Map.Entry<TypeDescription, byte[]> entry : types.entrySet()) {
/* 1275 */         typesByName.put(((TypeDescription)entry.getKey()).getName(), entry.getValue());
/*      */       }
/* 1277 */       classLoader = new ChildFirst(classLoader, sealed, typesByName, protectionDomain, persistenceHandler, packageDefinitionStrategy, ClassFilePostProcessor.NoOp.INSTANCE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1284 */       Map<TypeDescription, Class<?>> result = new LinkedHashMap<TypeDescription, Class<?>>();
/* 1285 */       for (TypeDescription typeDescription : types.keySet()) {
/*      */         try {
/* 1287 */           Class<?> type = Class.forName(typeDescription.getName(), false, classLoader);
/* 1288 */           if (!GraalImageCode.getCurrent().isNativeImageExecution() && forbidExisting && type.getClassLoader() != classLoader) {
/* 1289 */             throw new IllegalStateException("Class already loaded: " + type);
/*      */           }
/* 1291 */           result.put(typeDescription, type);
/* 1292 */         } catch (ClassNotFoundException exception) {
/* 1293 */           throw new IllegalStateException("Cannot load class " + typeDescription, exception);
/*      */         } 
/*      */       } 
/* 1296 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
/* 1303 */       synchronized (SYNCHRONIZATION_STRATEGY.initialize().getClassLoadingLock(this, name)) {
/* 1304 */         Class<?> type = findLoadedClass(name);
/* 1305 */         if (type != null) {
/* 1306 */           return type;
/*      */         }
/*      */         try {
/* 1309 */           type = findClass(name);
/* 1310 */           if (resolve) {
/* 1311 */             resolveClass(type);
/*      */           }
/* 1313 */           return type;
/* 1314 */         } catch (ClassNotFoundException exception) {
/*      */ 
/*      */ 
/*      */           
/* 1318 */           return super.loadClass(name, resolve);
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public URL getResource(String name) {
/* 1327 */       URL url = this.persistenceHandler.url(name, this.typeDefinitions);
/*      */ 
/*      */ 
/*      */       
/* 1331 */       return (url != null || isShadowed(name)) ? url : super
/*      */         
/* 1333 */         .getResource(name);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Enumeration<URL> getResources(String name) throws IOException {
/* 1340 */       URL url = this.persistenceHandler.url(name, this.typeDefinitions);
/* 1341 */       return (url == null) ? super
/* 1342 */         .getResources(name) : new PrependingEnumeration(url, super
/* 1343 */           .getResources(name));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean isShadowed(String resource) {
/* 1353 */       if (this.persistenceHandler.isManifest() || !resource.endsWith(".class")) {
/* 1354 */         return false;
/*      */       }
/*      */       
/* 1357 */       String name = resource.replace('/', '.').substring(0, resource.length() - ".class".length());
/* 1358 */       synchronized (SYNCHRONIZATION_STRATEGY.initialize().getClassLoadingLock(this, name)) {
/* 1359 */         if (this.typeDefinitions.containsKey(name)) {
/* 1360 */           return true;
/*      */         }
/* 1362 */         Class<?> loadedClass = findLoadedClass(name);
/* 1363 */         return (loadedClass != null && loadedClass.getClassLoader() == this);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected static class PrependingEnumeration
/*      */       implements Enumeration<URL>
/*      */     {
/*      */       @MaybeNull
/*      */       private URL nextElement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final Enumeration<URL> enumeration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected PrependingEnumeration(URL url, Enumeration<URL> enumeration) {
/* 1390 */         this.nextElement = url;
/* 1391 */         this.enumeration = enumeration;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean hasMoreElements() {
/* 1398 */         return (this.nextElement != null && this.enumeration.hasMoreElements());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public URL nextElement() {
/* 1405 */         if (this.nextElement != null && this.enumeration.hasMoreElements()) {
/*      */           try {
/* 1407 */             return this.nextElement;
/*      */           } finally {
/* 1409 */             this.nextElement = this.enumeration.nextElement();
/*      */           } 
/*      */         }
/* 1412 */         throw new NoSuchElementException();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected enum EmptyEnumeration
/*      */     implements Enumeration<URL>
/*      */   {
/* 1426 */     INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasMoreElements() {
/* 1432 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public URL nextElement() {
/* 1439 */       throw new NoSuchElementException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static class SingletonEnumeration
/*      */     implements Enumeration<URL>
/*      */   {
/*      */     @MaybeNull
/*      */     private URL element;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected SingletonEnumeration(URL element) {
/* 1460 */       this.element = element;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasMoreElements() {
/* 1467 */       return (this.element != null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public URL nextElement() {
/* 1474 */       if (this.element == null) {
/* 1475 */         throw new NoSuchElementException();
/*      */       }
/*      */       try {
/* 1478 */         return this.element;
/*      */       } finally {
/* 1480 */         this.element = null;
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   public static interface Initializable {
/*      */     ByteArrayClassLoader.SynchronizationStrategy initialize();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\loading\ByteArrayClassLoader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */