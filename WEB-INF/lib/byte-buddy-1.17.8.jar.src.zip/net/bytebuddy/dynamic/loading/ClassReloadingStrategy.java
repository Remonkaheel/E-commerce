/*     */ package net.bytebuddy.dynamic.loading;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.instrument.ClassDefinition;
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import java.lang.instrument.Instrumentation;
/*     */ import java.lang.instrument.UnmodifiableClassException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import net.bytebuddy.agent.builder.AgentBuilder;
/*     */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.ClassFileLocator;
/*     */ import net.bytebuddy.utility.JavaModule;
/*     */ import net.bytebuddy.utility.dispatcher.JavaDispatcher;
/*     */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Proxied;
/*     */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class ClassReloadingStrategy
/*     */   implements ClassLoadingStrategy<ClassLoader>
/*     */ {
/*  59 */   protected static final Dispatcher DISPATCHER = doPrivileged(JavaDispatcher.of(Dispatcher.class)); private final Instrumentation instrumentation; private final Strategy strategy; private final BootstrapInjection bootstrapInjection; private final Map<String, Class<?>> preregisteredTypes; private static final boolean ACCESS_CONTROLLER; static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*     */      }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassReloadingStrategy(Instrumentation instrumentation, Strategy strategy) {
/*  90 */     this(instrumentation, strategy, BootstrapInjection.Disabled.INSTANCE, 
/*     */ 
/*     */         
/*  93 */         Collections.emptyMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ClassReloadingStrategy(Instrumentation instrumentation, Strategy strategy, BootstrapInjection bootstrapInjection, Map<String, Class<?>> preregisteredTypes) {
/* 108 */     this.instrumentation = instrumentation;
/* 109 */     this.strategy = strategy.validate(instrumentation);
/* 110 */     this.bootstrapInjection = bootstrapInjection;
/* 111 */     this.preregisteredTypes = preregisteredTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 123 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassReloadingStrategy of(Instrumentation instrumentation) {
/* 136 */     if (DISPATCHER.isRetransformClassesSupported(instrumentation))
/* 137 */       return new ClassReloadingStrategy(instrumentation, Strategy.RETRANSFORMATION); 
/* 138 */     if (instrumentation.isRedefineClassesSupported()) {
/* 139 */       return new ClassReloadingStrategy(instrumentation, Strategy.REDEFINITION);
/*     */     }
/* 141 */     throw new IllegalArgumentException("Instrumentation does not support reloading of classes: " + instrumentation);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Instrumentation resolveByteBuddyAgentInstrumentation() {
/*     */     try {
/* 152 */       Class<?> installer = ClassLoader.getSystemClassLoader().loadClass("net.bytebuddy.agent.Installer");
/* 153 */       JavaModule source = JavaModule.ofType(AgentBuilder.class), target = JavaModule.ofType(installer);
/* 154 */       if (source != null && !source.canRead(target)) {
/* 155 */         Class<?> module = Class.forName("java.lang.Module");
/* 156 */         module.getMethod("addReads", new Class[] { module }).invoke(source.unwrap(), new Object[] { target.unwrap() });
/*     */       } 
/* 158 */       return (Instrumentation)installer.getMethod("getInstrumentation", new Class[0]).invoke(null, new Object[0]);
/* 159 */     } catch (RuntimeException exception) {
/* 160 */       throw exception;
/* 161 */     } catch (Exception exception) {
/* 162 */       throw new IllegalStateException("The Byte Buddy agent is not installed or not accessible", exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassReloadingStrategy fromInstalledAgent() {
/* 183 */     return of(resolveByteBuddyAgentInstrumentation());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassReloadingStrategy fromInstalledAgent(Strategy strategy) {
/* 203 */     return new ClassReloadingStrategy(resolveByteBuddyAgentInstrumentation(), strategy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<TypeDescription, Class<?>> load(@MaybeNull ClassLoader classLoader, Map<TypeDescription, byte[]> types) {
/* 210 */     Map<String, Class<?>> availableTypes = new HashMap<String, Class<?>>(this.preregisteredTypes);
/* 211 */     for (Class<?> type : this.instrumentation.getInitiatedClasses(classLoader)) {
/* 212 */       availableTypes.put(TypeDescription.ForLoadedType.getName(type), type);
/*     */     }
/* 214 */     Map<Class<?>, ClassDefinition> classDefinitions = new ConcurrentHashMap<Class<?>, ClassDefinition>();
/* 215 */     Map<TypeDescription, Class<?>> loadedClasses = new HashMap<TypeDescription, Class<?>>();
/* 216 */     Map<TypeDescription, byte[]> unloadedClasses = (Map)new LinkedHashMap<TypeDescription, byte>();
/* 217 */     for (Map.Entry<TypeDescription, byte[]> entry : types.entrySet()) {
/* 218 */       Class<?> type = availableTypes.get(((TypeDescription)entry.getKey()).getName());
/* 219 */       if (type != null) {
/* 220 */         classDefinitions.put(type, new ClassDefinition(type, entry.getValue()));
/* 221 */         loadedClasses.put(entry.getKey(), type); continue;
/*     */       } 
/* 223 */       unloadedClasses.put(entry.getKey(), entry.getValue());
/*     */     } 
/*     */     
/*     */     try {
/* 227 */       this.strategy.apply(this.instrumentation, classDefinitions);
/* 228 */       if (!unloadedClasses.isEmpty()) {
/* 229 */         loadedClasses.putAll(((classLoader == null) ? this.bootstrapInjection
/* 230 */             .make(this.instrumentation) : new ClassInjector.UsingReflection(classLoader))
/* 231 */             .inject(unloadedClasses));
/*     */       }
/* 233 */     } catch (ClassNotFoundException exception) {
/* 234 */       throw new IllegalArgumentException("Could not locate classes for redefinition", exception);
/* 235 */     } catch (UnmodifiableClassException exception) {
/* 236 */       throw new IllegalStateException("Cannot redefine specified class", exception);
/*     */     } 
/* 238 */     return loadedClasses;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassReloadingStrategy reset(Class<?>... type) throws IOException {
/* 249 */     return (type.length == 0) ? this : 
/*     */       
/* 251 */       reset(ClassFileLocator.ForClassLoader.of(type[0].getClassLoader()), type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassReloadingStrategy reset(ClassFileLocator classFileLocator, Class<?>... type) throws IOException {
/* 263 */     if (type.length > 0) {
/*     */       try {
/* 265 */         this.strategy.reset(this.instrumentation, classFileLocator, Arrays.asList(type));
/* 266 */       } catch (ClassNotFoundException exception) {
/* 267 */         throw new IllegalArgumentException("Cannot locate types " + Arrays.toString(type), exception);
/* 268 */       } catch (UnmodifiableClassException exception) {
/* 269 */         throw new IllegalStateException("Cannot reset types " + Arrays.toString(type), exception);
/*     */       } 
/*     */     }
/* 272 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassReloadingStrategy enableBootstrapInjection(File folder) {
/* 282 */     return new ClassReloadingStrategy(this.instrumentation, this.strategy, new BootstrapInjection.Enabled(folder), this.preregisteredTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassReloadingStrategy preregistered(Class<?>... type) {
/* 292 */     Map<String, Class<?>> preregisteredTypes = new HashMap<String, Class<?>>(this.preregisteredTypes);
/* 293 */     for (Class<?> aType : type) {
/* 294 */       preregisteredTypes.put(TypeDescription.ForLoadedType.getName(aType), aType);
/*     */     }
/* 296 */     return new ClassReloadingStrategy(this.instrumentation, this.strategy, this.bootstrapInjection, preregisteredTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.strategy.equals(((ClassReloadingStrategy)paramObject).strategy) ? false : (!this.instrumentation.equals(((ClassReloadingStrategy)paramObject).instrumentation) ? false : (!this.bootstrapInjection.equals(((ClassReloadingStrategy)paramObject).bootstrapInjection) ? false : (!!this.preregisteredTypes.equals(((ClassReloadingStrategy)paramObject).preregisteredTypes)))))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*     */     return (((getClass().hashCode() * 31 + this.instrumentation.hashCode()) * 31 + this.strategy.hashCode()) * 31 + this.bootstrapInjection.hashCode()) * 31 + this.preregisteredTypes.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Strategy
/*     */   {
/* 355 */     REDEFINITION(true)
/*     */     {
/*     */       protected void apply(Instrumentation instrumentation, Map<Class<?>, ClassDefinition> classDefinitions) throws UnmodifiableClassException, ClassNotFoundException
/*     */       {
/* 359 */         instrumentation.redefineClasses((ClassDefinition[])classDefinitions.values().toArray((Object[])new ClassDefinition[0]));
/*     */       }
/*     */ 
/*     */       
/*     */       protected Strategy validate(Instrumentation instrumentation) {
/* 364 */         if (!instrumentation.isRedefineClassesSupported()) {
/* 365 */           throw new IllegalArgumentException("Does not support redefinition: " + instrumentation);
/*     */         }
/* 367 */         return this;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public void reset(Instrumentation instrumentation, ClassFileLocator classFileLocator, List<Class<?>> types) throws IOException, UnmodifiableClassException, ClassNotFoundException {
/* 373 */         Map<Class<?>, ClassDefinition> classDefinitions = new HashMap<Class<?>, ClassDefinition>(types.size());
/* 374 */         for (Class<?> type : types) {
/* 375 */           classDefinitions.put(type, new ClassDefinition(type, classFileLocator.locate(TypeDescription.ForLoadedType.getName(type)).resolve()));
/*     */         }
/* 377 */         apply(instrumentation, classDefinitions);
/*     */       }
/*     */     },
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 392 */     RETRANSFORMATION(false)
/*     */     {
/*     */       protected void apply(Instrumentation instrumentation, Map<Class<?>, ClassDefinition> classDefinitions) throws UnmodifiableClassException {
/* 395 */         ClassRedefinitionTransformer classRedefinitionTransformer = new ClassRedefinitionTransformer(classDefinitions);
/* 396 */         synchronized (this) {
/* 397 */           ClassReloadingStrategy.DISPATCHER.addTransformer(instrumentation, classRedefinitionTransformer, true);
/*     */           try {
/* 399 */             ClassReloadingStrategy.DISPATCHER.retransformClasses(instrumentation, (Class[])classDefinitions.keySet().toArray((Object[])new Class[0]));
/*     */           } finally {
/* 401 */             instrumentation.removeTransformer(classRedefinitionTransformer);
/*     */           } 
/*     */         } 
/* 404 */         classRedefinitionTransformer.assertTransformation();
/*     */       }
/*     */ 
/*     */       
/*     */       protected Strategy validate(Instrumentation instrumentation) {
/* 409 */         if (!ClassReloadingStrategy.DISPATCHER.isRetransformClassesSupported(instrumentation)) {
/* 410 */           throw new IllegalArgumentException("Does not support retransformation: " + instrumentation);
/*     */         }
/* 412 */         return this;
/*     */       }
/*     */ 
/*     */       
/*     */       public void reset(Instrumentation instrumentation, ClassFileLocator classFileLocator, List<Class<?>> types) throws UnmodifiableClassException, ClassNotFoundException {
/* 417 */         for (Class<?> type : types) {
/* 418 */           if (!ClassReloadingStrategy.DISPATCHER.isModifiableClass(instrumentation, type)) {
/* 419 */             throw new IllegalArgumentException("Cannot modify type: " + type);
/*     */           }
/*     */         } 
/* 422 */         ClassReloadingStrategy.DISPATCHER.addTransformer(instrumentation, ClassResettingTransformer.INSTANCE, true);
/*     */         try {
/* 424 */           ClassReloadingStrategy.DISPATCHER.retransformClasses(instrumentation, (Class[])types.<Class<?>[]>toArray((Class<?>[][])new Class[0]));
/*     */         } finally {
/* 426 */           instrumentation.removeTransformer(ClassResettingTransformer.INSTANCE);
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @AlwaysNull
/* 435 */     private static final byte[] NO_REDEFINITION = null;
/*     */ 
/*     */ 
/*     */     
/*     */     private static final boolean REDEFINE_CLASSES = true;
/*     */ 
/*     */ 
/*     */     
/*     */     private final boolean redefinition;
/*     */ 
/*     */ 
/*     */     
/*     */     static {
/*     */     
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     Strategy(boolean redefinition) {
/* 454 */       this.redefinition = redefinition;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isRedefinition() {
/* 482 */       return this.redefinition;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected abstract void apply(Instrumentation param1Instrumentation, Map<Class<?>, ClassDefinition> param1Map) throws UnmodifiableClassException, ClassNotFoundException;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected abstract Strategy validate(Instrumentation param1Instrumentation);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract void reset(Instrumentation param1Instrumentation, ClassFileLocator param1ClassFileLocator, List<Class<?>> param1List) throws IOException, UnmodifiableClassException, ClassNotFoundException;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static class ClassRedefinitionTransformer
/*     */       implements ClassFileTransformer
/*     */     {
/*     */       private final Map<Class<?>, ClassDefinition> redefinedClasses;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected ClassRedefinitionTransformer(Map<Class<?>, ClassDefinition> redefinedClasses) {
/* 513 */         this.redefinedClasses = redefinedClasses;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public byte[] transform(@MaybeNull ClassLoader classLoader, @MaybeNull String internalTypeName, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain, byte[] classfileBuffer) {
/* 525 */         if (internalTypeName == null) {
/* 526 */           return ClassReloadingStrategy.Strategy.NO_REDEFINITION;
/*     */         }
/* 528 */         ClassDefinition redefinedClass = this.redefinedClasses.remove(classBeingRedefined);
/* 529 */         return (redefinedClass == null) ? ClassReloadingStrategy.Strategy
/* 530 */           .NO_REDEFINITION : redefinedClass
/* 531 */           .getDefinitionClassFile();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void assertTransformation() {
/* 538 */         if (!this.redefinedClasses.isEmpty()) {
/* 539 */           throw new IllegalStateException("Could not transform: " + this.redefinedClasses.keySet());
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected enum ClassResettingTransformer
/*     */       implements ClassFileTransformer
/*     */     {
/* 552 */       INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public byte[] transform(@MaybeNull ClassLoader classLoader, @MaybeNull String internalTypeName, @MaybeNull Class<?> classBeingRedefined, @MaybeNull ProtectionDomain protectionDomain, byte[] classfileBuffer) {
/* 563 */         return ClassReloadingStrategy.Strategy.NO_REDEFINITION;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Disabled
/*     */     implements BootstrapInjection
/*     */   {
/* 589 */     INSTANCE;
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassInjector make(Instrumentation instrumentation)
/*     */     {
/* 595 */       throw new IllegalStateException("Bootstrap injection is not enabled"); } } protected static interface BootstrapInjection { ClassInjector make(Instrumentation param1Instrumentation); public enum Disabled implements BootstrapInjection { INSTANCE; public ClassInjector make(Instrumentation instrumentation) { throw new IllegalStateException("Bootstrap injection is not enabled"); }
/*     */        }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     public static class Enabled
/*     */       implements BootstrapInjection
/*     */     {
/*     */       private final File folder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected Enabled(File folder) {
/* 616 */         this.folder = folder;
/*     */       }
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.folder.equals(((Enabled)param2Object).folder))));
/*     */       } public int hashCode() {
/*     */         return getClass().hashCode() * 31 + this.folder.hashCode();
/*     */       }
/* 623 */       public ClassInjector make(Instrumentation instrumentation) { return ClassInjector.UsingInstrumentation.of(this.folder, ClassInjector.UsingInstrumentation.Target.BOOTSTRAP, instrumentation); } } } @Enhance public static class Enabled implements BootstrapInjection { public ClassInjector make(Instrumentation instrumentation) { return ClassInjector.UsingInstrumentation.of(this.folder, ClassInjector.UsingInstrumentation.Target.BOOTSTRAP, instrumentation); }
/*     */ 
/*     */     
/*     */     private final File folder;
/*     */     
/*     */     protected Enabled(File folder) {
/*     */       this.folder = folder;
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.folder.equals(((Enabled)param1Object).folder))));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.folder.hashCode();
/*     */     } }
/*     */ 
/*     */   
/*     */   @Proxied("java.lang.instrument.Instrumentation")
/*     */   protected static interface Dispatcher {
/*     */     @Proxied("isModifiableClass")
/*     */     boolean isModifiableClass(Instrumentation param1Instrumentation, Class<?> param1Class);
/*     */     
/*     */     @Proxied("isRetransformClassesSupported")
/*     */     boolean isRetransformClassesSupported(Instrumentation param1Instrumentation);
/*     */     
/*     */     @Proxied("addTransformer")
/*     */     void addTransformer(Instrumentation param1Instrumentation, ClassFileTransformer param1ClassFileTransformer, boolean param1Boolean);
/*     */     
/*     */     @Proxied("retransformClasses")
/*     */     void retransformClasses(Instrumentation param1Instrumentation, Class<?>[] param1ArrayOfClass) throws UnmodifiableClassException;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\loading\ClassReloadingStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */