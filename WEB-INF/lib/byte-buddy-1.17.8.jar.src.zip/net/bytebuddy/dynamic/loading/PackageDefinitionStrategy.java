/*     */ package net.bytebuddy.dynamic.loading;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.jar.Attributes;
/*     */ import java.util.jar.Manifest;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling;
/*     */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface PackageDefinitionStrategy
/*     */ {
/*     */   Definition define(ClassLoader paramClassLoader, String paramString1, String paramString2);
/*     */   
/*     */   public enum NoOp
/*     */     implements PackageDefinitionStrategy
/*     */   {
/*  58 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PackageDefinitionStrategy.Definition define(ClassLoader classLoader, String packageName, String typeName) {
/*  64 */       return PackageDefinitionStrategy.Definition.Undefined.INSTANCE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Trivial
/*     */     implements PackageDefinitionStrategy
/*     */   {
/*  76 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PackageDefinitionStrategy.Definition define(ClassLoader classLoader, String packageName, String typeName) {
/*  82 */       return PackageDefinitionStrategy.Definition.Trivial.INSTANCE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Definition
/*     */   {
/*     */     boolean isDefined();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     String getSpecificationTitle();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     String getSpecificationVersion();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     String getSpecificationVendor();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     String getImplementationTitle();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     String getImplementationVersion();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     String getImplementationVendor();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     URL getSealBase();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isCompatibleTo(Package param1Package);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public enum Undefined
/*     */       implements Definition
/*     */     {
/* 177 */       INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean isDefined() {
/* 183 */         return false;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public String getSpecificationTitle() {
/* 190 */         throw new IllegalStateException("Cannot read property of undefined package");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public String getSpecificationVersion() {
/* 197 */         throw new IllegalStateException("Cannot read property of undefined package");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public String getSpecificationVendor() {
/* 204 */         throw new IllegalStateException("Cannot read property of undefined package");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public String getImplementationTitle() {
/* 211 */         throw new IllegalStateException("Cannot read property of undefined package");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public String getImplementationVersion() {
/* 218 */         throw new IllegalStateException("Cannot read property of undefined package");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public String getImplementationVendor() {
/* 225 */         throw new IllegalStateException("Cannot read property of undefined package");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public URL getSealBase() {
/* 232 */         throw new IllegalStateException("Cannot read property of undefined package");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean isCompatibleTo(Package definedPackage) {
/* 239 */         throw new IllegalStateException("Cannot check compatibility to undefined package");
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public enum Trivial
/*     */       implements Definition
/*     */     {
/* 251 */       INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @AlwaysNull
/* 263 */       private static final URL NOT_SEALED = null; @AlwaysNull
/*     */       private static final String NO_VALUE = null;
/*     */       static {
/*     */       
/*     */       }
/*     */       public boolean isDefined() {
/* 269 */         return true;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public String getSpecificationTitle() {
/* 277 */         return NO_VALUE;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public String getSpecificationVersion() {
/* 285 */         return NO_VALUE;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public String getSpecificationVendor() {
/* 293 */         return NO_VALUE;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public String getImplementationTitle() {
/* 301 */         return NO_VALUE;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public String getImplementationVersion() {
/* 309 */         return NO_VALUE;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public String getImplementationVendor() {
/* 316 */         return NO_VALUE;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public URL getSealBase() {
/* 324 */         return NOT_SEALED;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean isCompatibleTo(Package definedPackage) {
/* 331 */         return true;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class Simple
/*     */       implements Definition
/*     */     {
/*     */       @MaybeNull
/*     */       protected final URL sealBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       private final String specificationTitle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       private final String specificationVersion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       private final String specificationVendor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       private final String implementationTitle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       private final String implementationVersion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       private final String implementationVendor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public Simple(@MaybeNull String specificationTitle, @MaybeNull String specificationVersion, @MaybeNull String specificationVendor, @MaybeNull String implementationTitle, @MaybeNull String implementationVersion, @MaybeNull String implementationVendor, @MaybeNull URL sealBase) {
/* 400 */         this.specificationTitle = specificationTitle;
/* 401 */         this.specificationVersion = specificationVersion;
/* 402 */         this.specificationVendor = specificationVendor;
/* 403 */         this.implementationTitle = implementationTitle;
/* 404 */         this.implementationVersion = implementationVersion;
/* 405 */         this.implementationVendor = implementationVendor;
/* 406 */         this.sealBase = sealBase;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean isDefined() {
/* 413 */         return true;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public String getSpecificationTitle() {
/* 421 */         return this.specificationTitle;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public String getSpecificationVersion() {
/* 429 */         return this.specificationVersion;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public String getSpecificationVendor() {
/* 437 */         return this.specificationVendor;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public String getImplementationTitle() {
/* 445 */         return this.implementationTitle;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public String getImplementationVersion() {
/* 453 */         return this.implementationVersion;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public String getImplementationVendor() {
/* 461 */         return this.implementationVendor;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public URL getSealBase() {
/* 469 */         return this.sealBase;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean isCompatibleTo(Package definedPackage) {
/* 476 */         if (this.sealBase == null) {
/* 477 */           return !definedPackage.isSealed();
/*     */         }
/* 479 */         return definedPackage.isSealed(this.sealBase);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       @SuppressFBWarnings(value = {"DMI_BLOCKING_METHODS_ON_URL"}, justification = "Package sealing relies on URL equality.")
/*     */       public int hashCode() {
/* 486 */         int result = (this.specificationTitle != null) ? this.specificationTitle.hashCode() : 0;
/* 487 */         result = 31 * result + ((this.specificationVersion != null) ? this.specificationVersion.hashCode() : 0);
/* 488 */         result = 31 * result + ((this.specificationVendor != null) ? this.specificationVendor.hashCode() : 0);
/* 489 */         result = 31 * result + ((this.implementationTitle != null) ? this.implementationTitle.hashCode() : 0);
/* 490 */         result = 31 * result + ((this.implementationVersion != null) ? this.implementationVersion.hashCode() : 0);
/* 491 */         result = 31 * result + ((this.implementationVendor != null) ? this.implementationVendor.hashCode() : 0);
/* 492 */         result = 31 * result + ((this.sealBase != null) ? this.sealBase.hashCode() : 0);
/* 493 */         return result;
/*     */       }
/*     */ 
/*     */       
/*     */       @SuppressFBWarnings(value = {"DMI_BLOCKING_METHODS_ON_URL"}, justification = "Package sealing relies on URL equality.")
/*     */       public boolean equals(@MaybeNull Object other) {
/* 499 */         if (this == other)
/* 500 */           return true; 
/* 501 */         if (other == null || getClass() != other.getClass()) {
/* 502 */           return false;
/*     */         }
/* 504 */         Simple simple = (Simple)other;
/* 505 */         if (((this.specificationTitle != null) ? !this.specificationTitle.equals(simple.specificationTitle) : (simple.specificationTitle != null)) || ((this.specificationVersion != null) ? 
/* 506 */           !this.specificationVersion.equals(simple.specificationVersion) : (simple.specificationVersion != null)) || ((this.specificationVendor != null) ? 
/* 507 */           !this.specificationVendor.equals(simple.specificationVendor) : (simple.specificationVendor != null)) || ((this.implementationTitle != null) ? 
/* 508 */           !this.implementationTitle.equals(simple.implementationTitle) : (simple.implementationTitle != null)) || ((this.implementationVersion != null) ? 
/* 509 */           !this.implementationVersion.equals(simple.implementationVersion) : (simple.implementationVersion != null)) || ((this.implementationVendor != null) ? 
/* 510 */           !this.implementationVendor.equals(simple.implementationVendor) : (simple.implementationVendor != null)) || ((this.sealBase != null) ? 
/* 511 */           !this.sealBase.equals(simple.sealBase) : (simple.sealBase != null))) {
/*     */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class ManifestReading
/*     */     implements PackageDefinitionStrategy
/*     */   {
/*     */     @AlwaysNull
/* 526 */     private static final URL NOT_SEALED = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 531 */     private static final Attributes.Name[] ATTRIBUTE_NAMES = new Attributes.Name[] { Attributes.Name.SPECIFICATION_TITLE, Attributes.Name.SPECIFICATION_VERSION, Attributes.Name.SPECIFICATION_VENDOR, Attributes.Name.IMPLEMENTATION_TITLE, Attributes.Name.IMPLEMENTATION_VERSION, Attributes.Name.IMPLEMENTATION_VENDOR, Attributes.Name.SEALED };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final SealBaseLocator sealBaseLocator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ManifestReading() {
/* 550 */       this(new SealBaseLocator.ForTypeResourceUrl());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ManifestReading(SealBaseLocator sealBaseLocator) {
/* 559 */       this.sealBaseLocator = sealBaseLocator;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PackageDefinitionStrategy.Definition define(ClassLoader classLoader, String packageName, String typeName) {
/* 566 */       InputStream inputStream = classLoader.getResourceAsStream("META-INF/MANIFEST.MF");
/* 567 */       if (inputStream != null) {
/*     */         try {
/*     */           try {
/* 570 */             Manifest manifest = new Manifest(inputStream);
/* 571 */             Map<Attributes.Name, String> values = new HashMap<Attributes.Name, String>();
/* 572 */             Attributes mainAttributes = manifest.getMainAttributes();
/* 573 */             if (mainAttributes != null) {
/* 574 */               for (Attributes.Name attributeName : ATTRIBUTE_NAMES) {
/* 575 */                 values.put(attributeName, mainAttributes.getValue(attributeName));
/*     */               }
/*     */             }
/* 578 */             Attributes attributes = manifest.getAttributes(packageName.replace('.', '/').concat("/"));
/* 579 */             if (attributes != null) {
/* 580 */               for (Attributes.Name attributeName : ATTRIBUTE_NAMES) {
/* 581 */                 String value = attributes.getValue(attributeName);
/* 582 */                 if (value != null) {
/* 583 */                   values.put(attributeName, value);
/*     */                 }
/*     */               } 
/*     */             }
/* 587 */             return new PackageDefinitionStrategy.Definition.Simple(values.get(Attributes.Name.SPECIFICATION_TITLE), values
/* 588 */                 .get(Attributes.Name.SPECIFICATION_VERSION), values
/* 589 */                 .get(Attributes.Name.SPECIFICATION_VENDOR), values
/* 590 */                 .get(Attributes.Name.IMPLEMENTATION_TITLE), values
/* 591 */                 .get(Attributes.Name.IMPLEMENTATION_VERSION), values
/* 592 */                 .get(Attributes.Name.IMPLEMENTATION_VENDOR), 
/* 593 */                 Boolean.parseBoolean(values.get(Attributes.Name.SEALED)) ? this.sealBaseLocator
/* 594 */                 .findSealBase(classLoader, typeName) : NOT_SEALED);
/*     */           } finally {
/*     */             
/* 597 */             inputStream.close();
/*     */           } 
/* 599 */         } catch (IOException exception) {
/* 600 */           throw new IllegalStateException("Error while reading manifest file", exception);
/*     */         } 
/*     */       }
/* 603 */       return PackageDefinitionStrategy.Definition.Trivial.INSTANCE;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.sealBaseLocator.equals(((ManifestReading)param1Object).sealBaseLocator))));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.sealBaseLocator.hashCode();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public static interface SealBaseLocator
/*     */     {
/*     */       @MaybeNull
/*     */       URL findSealBase(ClassLoader param2ClassLoader, String param2String);
/*     */ 
/*     */ 
/*     */       
/*     */       public enum NonSealing
/*     */         implements SealBaseLocator
/*     */       {
/* 630 */         INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         @MaybeNull
/*     */         public URL findSealBase(ClassLoader classLoader, String typeName) {
/* 637 */           return PackageDefinitionStrategy.ManifestReading.NOT_SEALED;
/*     */         }
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Enhance
/*     */       public static class ForFixedValue
/*     */         implements SealBaseLocator
/*     */       {
/*     */         @MaybeNull
/*     */         @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*     */         private final URL sealBase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public ForFixedValue(@MaybeNull URL sealBase) {
/* 660 */           this.sealBase = sealBase;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         @MaybeNull
/*     */         public URL findSealBase(ClassLoader classLoader, String typeName) {
/* 668 */           return this.sealBase;
/*     */         }
/*     */ 
/*     */         
/*     */         @SuppressFBWarnings(value = {"DMI_BLOCKING_METHODS_ON_URL"}, justification = "Package sealing relies on URL equality.")
/*     */         public int hashCode() {
/* 674 */           return (this.sealBase == null) ? 17 : this.sealBase
/*     */             
/* 676 */             .hashCode();
/*     */         }
/*     */ 
/*     */         
/*     */         @SuppressFBWarnings(value = {"DMI_BLOCKING_METHODS_ON_URL"}, justification = "Package sealing relies on URL equality.")
/*     */         public boolean equals(@MaybeNull Object other) {
/* 682 */           if (this == other)
/* 683 */             return true; 
/* 684 */           if (other == null || getClass() != other.getClass()) {
/* 685 */             return false;
/*     */           }
/* 687 */           ForFixedValue forFixedValue = (ForFixedValue)other;
/* 688 */           return (this.sealBase == null) ? ((forFixedValue.sealBase == null)) : this.sealBase
/*     */             
/* 690 */             .equals(forFixedValue.sealBase);
/*     */         }
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @Enhance
/*     */       public static class ForTypeResourceUrl
/*     */         implements SealBaseLocator
/*     */       {
/*     */         private static final int EXCLUDE_INITIAL_SLASH = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private static final String CLASS_FILE_EXTENSION = ".class";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private static final String JAR_FILE = "jar";
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private static final String FILE_SYSTEM = "file";
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private static final String RUNTIME_IMAGE = "jrt";
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final PackageDefinitionStrategy.ManifestReading.SealBaseLocator fallback;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public ForTypeResourceUrl() {
/* 737 */           this(PackageDefinitionStrategy.ManifestReading.SealBaseLocator.NonSealing.INSTANCE);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public ForTypeResourceUrl(PackageDefinitionStrategy.ManifestReading.SealBaseLocator fallback) {
/* 746 */           this.fallback = fallback;
/*     */         }
/*     */         public boolean equals(@MaybeNull Object param3Object) {
/*     */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.fallback.equals(((ForTypeResourceUrl)param3Object).fallback))));
/*     */         } public int hashCode() {
/*     */           return getClass().hashCode() * 31 + this.fallback.hashCode();
/*     */         }
/*     */         @MaybeNull
/* 754 */         public URL findSealBase(ClassLoader classLoader, String typeName) { URL url = classLoader.getResource(typeName.replace('.', '/') + ".class");
/* 755 */           if (url != null) {
/*     */             try {
/* 757 */               if (url.getProtocol().equals("jar"))
/* 758 */                 return URI.create(url.getPath().substring(0, url.getPath().indexOf('!'))).toURL(); 
/* 759 */               if (url.getProtocol().equals("file"))
/* 760 */                 return url; 
/* 761 */               if (url.getProtocol().equals("jrt")) {
/* 762 */                 String path = url.getPath();
/* 763 */                 int modulePathIndex = path.indexOf('/', 1);
/* 764 */                 return (modulePathIndex == -1) ? url : 
/*     */                   
/* 766 */                   URI.create("jrt:" + path.substring(0, modulePathIndex)).toURL();
/*     */               } 
/* 768 */             } catch (MalformedURLException exception) {
/* 769 */               throw new IllegalStateException("Unexpected URL: " + url, exception);
/*     */             } 
/*     */           }
/* 772 */           return this.fallback.findSealBase(classLoader, typeName); } } } @Enhance public static class ForTypeResourceUrl implements SealBaseLocator { @MaybeNull public URL findSealBase(ClassLoader classLoader, String typeName) { URL url = classLoader.getResource(typeName.replace('.', '/') + ".class"); if (url != null) try { if (url.getProtocol().equals("jar")) return URI.create(url.getPath().substring(0, url.getPath().indexOf('!'))).toURL();  if (url.getProtocol().equals("file")) return url;  if (url.getProtocol().equals("jrt")) { String path = url.getPath(); int modulePathIndex = path.indexOf('/', 1); return (modulePathIndex == -1) ? url : URI.create("jrt:" + path.substring(0, modulePathIndex)).toURL(); }  } catch (MalformedURLException exception) { throw new IllegalStateException("Unexpected URL: " + url, exception); }   return this.fallback.findSealBase(classLoader, typeName); }
/*     */ 
/*     */       
/*     */       private static final int EXCLUDE_INITIAL_SLASH = 1;
/*     */       private static final String CLASS_FILE_EXTENSION = ".class";
/*     */       private static final String JAR_FILE = "jar";
/*     */       private static final String FILE_SYSTEM = "file";
/*     */       private static final String RUNTIME_IMAGE = "jrt";
/*     */       private final PackageDefinitionStrategy.ManifestReading.SealBaseLocator fallback;
/*     */       
/*     */       public ForTypeResourceUrl() {
/*     */         this(PackageDefinitionStrategy.ManifestReading.SealBaseLocator.NonSealing.INSTANCE);
/*     */       }
/*     */       
/*     */       public ForTypeResourceUrl(PackageDefinitionStrategy.ManifestReading.SealBaseLocator fallback) {
/*     */         this.fallback = fallback;
/*     */       }
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.fallback.equals(((ForTypeResourceUrl)param2Object).fallback))));
/*     */       }
/*     */       
/*     */       public int hashCode() {
/*     */         return getClass().hashCode() * 31 + this.fallback.hashCode();
/*     */       } }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\loading\PackageDefinitionStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */