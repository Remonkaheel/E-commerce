/*     */ package net.bytebuddy.dynamic.loading;
/*     */ 
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import java.lang.instrument.IllegalClassFormatException;
/*     */ import java.security.AllPermission;
/*     */ import java.security.Permission;
/*     */ import java.security.PermissionCollection;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ClassFilePostProcessor
/*     */ {
/*     */   byte[] transform(@MaybeNull ClassLoader paramClassLoader, String paramString, @MaybeNull ProtectionDomain paramProtectionDomain, byte[] paramArrayOfbyte);
/*     */   
/*     */   public enum NoOp
/*     */     implements ClassFilePostProcessor
/*     */   {
/*  55 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public byte[] transform(@MaybeNull ClassLoader classLoader, String name, @MaybeNull ProtectionDomain protectionDomain, byte[] binaryRepresentation) {
/*  61 */       return binaryRepresentation;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class ForClassFileTransformer
/*     */     implements ClassFilePostProcessor
/*     */   {
/*  74 */     protected static final ProtectionDomain ALL_PRIVILEGES = new ProtectionDomain(null, new AllPermissionsCollection());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @AlwaysNull
/*  80 */     private static final Class<?> UNLOADED_TYPE = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final ClassFileTransformer classFileTransformer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForClassFileTransformer(ClassFileTransformer classFileTransformer) {
/*  93 */       this.classFileTransformer = classFileTransformer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public byte[] transform(@MaybeNull ClassLoader classLoader, String name, @MaybeNull ProtectionDomain protectionDomain, byte[] binaryRepresentation) {
/*     */       try {
/* 101 */         byte[] transformed = this.classFileTransformer.transform(classLoader, name.replace('.', '/'), UNLOADED_TYPE, (protectionDomain == null) ? ALL_PRIVILEGES : protectionDomain, binaryRepresentation);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 107 */         return (transformed == null) ? binaryRepresentation : transformed;
/* 108 */       } catch (IllegalClassFormatException exception) {
/* 109 */         throw new IllegalStateException("Failed to transform " + name, exception);
/*     */       } 
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.classFileTransformer.equals(((ForClassFileTransformer)param1Object).classFileTransformer))));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.classFileTransformer.hashCode();
/*     */     }
/*     */     
/*     */     @Enhance
/*     */     protected static class AllPermissionsCollection extends PermissionCollection {
/*     */       private static final long serialVersionUID = 1L;
/*     */       
/*     */       public void add(Permission permission) {
/* 126 */         throw new UnsupportedOperationException("add");
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean implies(Permission permission) {
/* 131 */         return true;
/*     */       }
/*     */ 
/*     */       
/*     */       public Enumeration<Permission> elements() {
/* 136 */         return Collections.enumeration(Collections.singleton(new AllPermission()));
/*     */       }
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : (!(getClass() != param2Object.getClass())));
/*     */       }
/*     */       
/*     */       public int hashCode() {
/*     */         return getClass().hashCode();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\loading\ClassFilePostProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */