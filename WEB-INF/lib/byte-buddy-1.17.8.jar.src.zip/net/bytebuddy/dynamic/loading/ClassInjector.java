/*      */ package net.bytebuddy.dynamic.loading;
/*      */ 
/*      */ import com.sun.jna.FunctionMapper;
/*      */ import com.sun.jna.JNIEnv;
/*      */ import com.sun.jna.LastErrorException;
/*      */ import com.sun.jna.Library;
/*      */ import com.sun.jna.Native;
/*      */ import com.sun.jna.NativeLibrary;
/*      */ import com.sun.jna.Platform;
/*      */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.lang.instrument.Instrumentation;
/*      */ import java.lang.reflect.AccessibleObject;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Type;
/*      */ import java.net.URL;
/*      */ import java.security.AccessController;
/*      */ import java.security.Permission;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.ProtectionDomain;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.jar.JarEntry;
/*      */ import java.util.jar.JarFile;
/*      */ import java.util.jar.JarOutputStream;
/*      */ import net.bytebuddy.ByteBuddy;
/*      */ import net.bytebuddy.ClassFileVersion;
/*      */ import net.bytebuddy.asm.AsmVisitorWrapper;
/*      */ import net.bytebuddy.asm.MemberRemoval;
/*      */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling;
/*      */ import net.bytebuddy.description.modifier.ModifierContributor;
/*      */ import net.bytebuddy.description.modifier.Visibility;
/*      */ import net.bytebuddy.description.type.PackageDescription;
/*      */ import net.bytebuddy.description.type.TypeDescription;
/*      */ import net.bytebuddy.dynamic.ClassFileLocator;
/*      */ import net.bytebuddy.dynamic.DynamicType;
/*      */ import net.bytebuddy.dynamic.scaffold.TypeValidation;
/*      */ import net.bytebuddy.dynamic.scaffold.subclass.ConstructorStrategy;
/*      */ import net.bytebuddy.implementation.FixedValue;
/*      */ import net.bytebuddy.implementation.Implementation;
/*      */ import net.bytebuddy.implementation.MethodCall;
/*      */ import net.bytebuddy.matcher.ElementMatcher;
/*      */ import net.bytebuddy.matcher.ElementMatchers;
/*      */ import net.bytebuddy.utility.GraalImageCode;
/*      */ import net.bytebuddy.utility.JavaModule;
/*      */ import net.bytebuddy.utility.JavaType;
/*      */ import net.bytebuddy.utility.RandomString;
/*      */ import net.bytebuddy.utility.dispatcher.JavaDispatcher;
/*      */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Defaults;
/*      */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.IsStatic;
/*      */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Proxied;
/*      */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ import net.bytebuddy.utility.nullability.UnknownNull;
/*      */ import net.bytebuddy.utility.privilege.GetMethodAction;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface ClassInjector
/*      */ {
/*      */   public static final boolean ALLOW_EXISTING_TYPES = false;
/*      */   
/*      */   boolean isAlive();
/*      */   
/*      */   Map<TypeDescription, Class<?>> inject(Set<? extends TypeDescription> paramSet, ClassFileLocator paramClassFileLocator);
/*      */   
/*      */   Map<String, Class<?>> injectRaw(Set<String> paramSet, ClassFileLocator paramClassFileLocator);
/*      */   
/*      */   Map<TypeDescription, Class<?>> inject(Map<? extends TypeDescription, byte[]> paramMap);
/*      */   
/*      */   Map<String, Class<?>> injectRaw(Map<String, byte[]> paramMap);
/*      */   
/*      */   public static abstract class AbstractBase
/*      */     implements ClassInjector
/*      */   {
/*      */     @MaybeNull
/*  133 */     protected static final Permission SUPPRESS_ACCESS_CHECKS = toSuppressAccessChecks();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown define null as value.")
/*      */     private static Permission toSuppressAccessChecks() {
/*      */       try {
/*  144 */         return Class.forName("java.lang.reflect.ReflectPermission")
/*  145 */           .getConstructor(new Class[] { String.class
/*  146 */             }).newInstance(new Object[] { "suppressAccessChecks" });
/*  147 */       } catch (Exception ignored) {
/*  148 */         return null;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Map<TypeDescription, Class<?>> inject(Set<? extends TypeDescription> types, ClassFileLocator classFileLocator) {
/*  156 */       Set<String> names = new LinkedHashSet<String>();
/*  157 */       for (TypeDescription type : types) {
/*  158 */         names.add(type.getName());
/*      */       }
/*  160 */       Map<String, Class<?>> loadedTypes = injectRaw(names, classFileLocator);
/*  161 */       Map<TypeDescription, Class<?>> result = new HashMap<TypeDescription, Class<?>>();
/*  162 */       for (TypeDescription type : types) {
/*  163 */         result.put(type, loadedTypes.get(type.getName()));
/*      */       }
/*  165 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Map<TypeDescription, Class<?>> inject(Map<? extends TypeDescription, byte[]> types) {
/*  172 */       Map<String, byte[]> binaryRepresentations = (Map)new LinkedHashMap<String, byte>();
/*  173 */       for (Map.Entry<? extends TypeDescription, byte[]> entry : types.entrySet()) {
/*  174 */         binaryRepresentations.put(((TypeDescription)entry.getKey()).getName(), entry.getValue());
/*      */       }
/*  176 */       Map<String, Class<?>> loadedTypes = injectRaw(binaryRepresentations);
/*  177 */       Map<TypeDescription, Class<?>> result = new HashMap<TypeDescription, Class<?>>();
/*  178 */       for (TypeDescription typeDescription : types.keySet()) {
/*  179 */         result.put(typeDescription, loadedTypes.get(typeDescription.getName()));
/*      */       }
/*  181 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Map<String, Class<?>> injectRaw(Map<String, byte[]> types) {
/*  188 */       return injectRaw(types.keySet(), (ClassFileLocator)new ClassFileLocator.Simple(types));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static class UsingReflection
/*      */     extends AbstractBase
/*      */   {
/*  201 */     private static final Dispatcher.Initializable DISPATCHER = doPrivileged(Dispatcher.CreationAction.INSTANCE);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  206 */     private static final System SYSTEM = doPrivileged(JavaDispatcher.of(System.class));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  211 */     private static final Method CHECK_PERMISSION = doPrivileged((PrivilegedAction<Method>)new GetMethodAction("java.lang.SecurityManager", "checkPermission", new Class[] { Permission.class })); private final ClassLoader classLoader; @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) private final ProtectionDomain protectionDomain; private final PackageDefinitionStrategy packageDefinitionStrategy; private final boolean forbidExisting; private static final boolean ACCESS_CONTROLLER; static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UsingReflection(ClassLoader classLoader) {
/*  244 */       this(classLoader, ClassLoadingStrategy.NO_PROTECTION_DOMAIN);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UsingReflection(ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain) {
/*  255 */       this(classLoader, protectionDomain, PackageDefinitionStrategy.Trivial.INSTANCE, false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UsingReflection(ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain, PackageDefinitionStrategy packageDefinitionStrategy, boolean forbidExisting) {
/*  273 */       if (classLoader == null) {
/*  274 */         throw new IllegalArgumentException("Cannot inject classes into the bootstrap class loader");
/*      */       }
/*  276 */       this.classLoader = classLoader;
/*  277 */       this.protectionDomain = protectionDomain;
/*  278 */       this.packageDefinitionStrategy = packageDefinitionStrategy;
/*  279 */       this.forbidExisting = forbidExisting;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/*  291 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isAlive() {
/*  298 */       return isAvailable();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Map<String, Class<?>> injectRaw(Set<String> names, ClassFileLocator classFileLocator) {
/*  305 */       Dispatcher dispatcher = DISPATCHER.initialize();
/*  306 */       Map<String, Class<?>> result = new HashMap<String, Class<?>>();
/*  307 */       for (String name : names) {
/*  308 */         synchronized (dispatcher.getClassLoadingLock(this.classLoader, name)) {
/*  309 */           Class<?> type = dispatcher.findClass(this.classLoader, name);
/*  310 */           if (type == null) {
/*  311 */             int packageIndex = name.lastIndexOf('.');
/*  312 */             if (packageIndex != -1) {
/*  313 */               String packageName = name.substring(0, packageIndex);
/*  314 */               PackageDefinitionStrategy.Definition definition = this.packageDefinitionStrategy.define(this.classLoader, packageName, name);
/*  315 */               if (definition.isDefined()) {
/*  316 */                 Package definedPackage = dispatcher.getDefinedPackage(this.classLoader, packageName);
/*  317 */                 if (definedPackage == null) {
/*      */                   try {
/*  319 */                     dispatcher.definePackage(this.classLoader, packageName, definition
/*      */                         
/*  321 */                         .getSpecificationTitle(), definition
/*  322 */                         .getSpecificationVersion(), definition
/*  323 */                         .getSpecificationVendor(), definition
/*  324 */                         .getImplementationTitle(), definition
/*  325 */                         .getImplementationVersion(), definition
/*  326 */                         .getImplementationVendor(), definition
/*  327 */                         .getSealBase());
/*  328 */                   } catch (IllegalStateException exception) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/*  337 */                     definedPackage = dispatcher.getPackage(this.classLoader, packageName);
/*  338 */                     if (definedPackage == null)
/*  339 */                       throw exception; 
/*  340 */                     if (!definition.isCompatibleTo(definedPackage)) {
/*  341 */                       throw new SecurityException("Sealing violation for package " + packageName + " (getPackage fallback)");
/*      */                     }
/*      */                   } 
/*  344 */                 } else if (!definition.isCompatibleTo(definedPackage)) {
/*  345 */                   throw new SecurityException("Sealing violation for package " + packageName);
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */             try {
/*  350 */               type = dispatcher.defineClass(this.classLoader, name, classFileLocator.locate(name).resolve(), this.protectionDomain);
/*  351 */             } catch (IOException exception) {
/*  352 */               throw new IllegalStateException("Could not resolve type description for " + name, exception);
/*      */             } 
/*  354 */           } else if (this.forbidExisting) {
/*  355 */             throw new IllegalStateException("Cannot inject already loaded type: " + type);
/*      */           } 
/*  357 */           result.put(name, type);
/*      */         } 
/*      */       } 
/*  360 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static boolean isAvailable() {
/*  369 */       return DISPATCHER.isAvailable();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassInjector ofSystemClassLoader() {
/*  378 */       return new UsingReflection(ClassLoader.getSystemClassLoader());
/*      */     } public boolean equals(@MaybeNull Object param1Object) { if (this == param1Object)
/*      */         return true;  if (param1Object == null)
/*      */         return false;  if (getClass() != param1Object.getClass())
/*      */         return false;  if (this.forbidExisting != ((UsingReflection)param1Object).forbidExisting)
/*      */         return false;  if (!this.classLoader.equals(((UsingReflection)param1Object).classLoader))
/*      */         return false;  ProtectionDomain protectionDomain1 = ((UsingReflection)param1Object).protectionDomain; ProtectionDomain protectionDomain2 = this.protectionDomain; if (protectionDomain1 != null) { if (protectionDomain2 != null) { if (!protectionDomain2.equals(protectionDomain1))
/*      */             return false;  } else { return false; }
/*      */          }
/*      */       else if (protectionDomain2 != null) { return false; }
/*      */        return !!this.packageDefinitionStrategy.equals(((UsingReflection)param1Object).packageDefinitionStrategy); } public int hashCode() { ProtectionDomain protectionDomain = this.protectionDomain; if (protectionDomain != null); return (((getClass().hashCode() * 31 + this.classLoader.hashCode()) * 31 + protectionDomain.hashCode()) * 31 + this.packageDefinitionStrategy.hashCode()) * 31 + this.forbidExisting; } @Proxied("java.lang.System") protected static interface System {
/*      */       @MaybeNull @IsStatic @Defaults @Proxied("getSecurityManager") Object getSecurityManager(); }
/*  390 */     protected static interface Dispatcher { @AlwaysNull public static final Class<?> UNDEFINED = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Object getClassLoadingLock(ClassLoader param2ClassLoader, String param2String);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       Class<?> findClass(ClassLoader param2ClassLoader, String param2String);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Class<?> defineClass(ClassLoader param2ClassLoader, String param2String, byte[] param2ArrayOfbyte, @MaybeNull ProtectionDomain param2ProtectionDomain);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       Package getDefinedPackage(ClassLoader param2ClassLoader, String param2String);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       Package getPackage(ClassLoader param2ClassLoader, String param2String);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Package definePackage(ClassLoader param2ClassLoader, String param2String1, @MaybeNull String param2String2, @MaybeNull String param2String3, @MaybeNull String param2String4, @MaybeNull String param2String5, @MaybeNull String param2String6, @MaybeNull String param2String7, @MaybeNull URL param2URL);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static interface Initializable
/*      */       {
/*      */         boolean isAvailable();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         ClassInjector.UsingReflection.Dispatcher initialize();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         public static class Unavailable
/*      */           implements ClassInjector.UsingReflection.Dispatcher, Initializable
/*      */         {
/*      */           private final String message;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected Unavailable(String message) {
/*  502 */             this.message = message;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean isAvailable() {
/*  509 */             return false;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public ClassInjector.UsingReflection.Dispatcher initialize() {
/*  516 */             return this;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Object getClassLoadingLock(ClassLoader classLoader, String name) {
/*  523 */             return classLoader;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Class<?> findClass(ClassLoader classLoader, String name) {
/*      */             try {
/*  531 */               return classLoader.loadClass(name);
/*  532 */             } catch (ClassNotFoundException ignored) {
/*  533 */               return UNDEFINED;
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Class<?> defineClass(ClassLoader classLoader, String name, byte[] binaryRepresentation, @MaybeNull ProtectionDomain protectionDomain) {
/*  541 */             throw new UnsupportedOperationException("Cannot define class using reflection: " + this.message);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Package getDefinedPackage(ClassLoader classLoader, String name) {
/*  548 */             throw new UnsupportedOperationException("Cannot get defined package using reflection: " + this.message);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Package getPackage(ClassLoader classLoader, String name) {
/*  555 */             throw new UnsupportedOperationException("Cannot get package using reflection: " + this.message);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Package definePackage(ClassLoader classLoader, String name, @MaybeNull String specificationTitle, @MaybeNull String specificationVersion, @MaybeNull String specificationVendor, @MaybeNull String implementationTitle, @MaybeNull String implementationVersion, @MaybeNull String implementationVendor, @MaybeNull URL sealBase) {
/*  570 */             throw new UnsupportedOperationException("Cannot define package using injection: " + this.message);
/*      */           }
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.message.equals(((Unavailable)param4Object).message))));
/*      */           }
/*      */           
/*      */           public int hashCode() {
/*      */             return getClass().hashCode() * 31 + this.message.hashCode();
/*      */           } }
/*      */       }
/*      */       
/*      */       public enum CreationAction implements PrivilegedAction<Initializable> {
/*  583 */         INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.")
/*      */         public ClassInjector.UsingReflection.Dispatcher.Initializable run() {
/*      */           try {
/*  591 */             if (JavaModule.isSupported()) {
/*  592 */               return ClassInjector.UsingUnsafe.isAvailable() ? 
/*  593 */                 ClassInjector.UsingReflection.Dispatcher.UsingUnsafeInjection.make() : 
/*  594 */                 ClassInjector.UsingReflection.Dispatcher.UsingUnsafeOverride.make();
/*      */             }
/*  596 */             return ClassInjector.UsingReflection.Dispatcher.Direct.make();
/*      */           }
/*  598 */           catch (InvocationTargetException exception) {
/*  599 */             return new ClassInjector.UsingReflection.Dispatcher.Initializable.Unavailable(exception.getTargetException().getMessage());
/*  600 */           } catch (Exception exception) {
/*  601 */             return new ClassInjector.UsingReflection.Dispatcher.Initializable.Unavailable(exception.getMessage());
/*      */           } 
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static abstract class Direct
/*      */         implements Dispatcher, Initializable
/*      */       {
/*      */         protected final Method findLoadedClass;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final Method defineClass;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @UnknownNull
/*      */         protected final Method getDefinedPackage;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final Method getPackage;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected final Method definePackage;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected Direct(Method findLoadedClass, Method defineClass, @MaybeNull Method getDefinedPackage, Method getPackage, Method definePackage) {
/*  652 */           this.findLoadedClass = findLoadedClass;
/*  653 */           this.defineClass = defineClass;
/*  654 */           this.getDefinedPackage = getDefinedPackage;
/*  655 */           this.getPackage = getPackage;
/*  656 */           this.definePackage = definePackage;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @SuppressFBWarnings(value = {"DP_DO_INSIDE_DO_PRIVILEGED"}, justification = "Assuring privilege is explicit user responsibility.")
/*      */         protected static ClassInjector.UsingReflection.Dispatcher.Initializable make() throws Exception {
/*      */           Method getDefinedPackage;
/*  668 */           if (JavaModule.isSupported()) {
/*      */             try {
/*  670 */               getDefinedPackage = ClassLoader.class.getMethod("getDefinedPackage", new Class[] { String.class });
/*  671 */             } catch (NoSuchMethodException ignored) {
/*  672 */               getDefinedPackage = null;
/*      */             } 
/*      */           } else {
/*  675 */             getDefinedPackage = null;
/*      */           } 
/*  677 */           Method getPackage = ClassLoader.class.getDeclaredMethod("getPackage", new Class[] { String.class });
/*  678 */           getPackage.setAccessible(true);
/*  679 */           Method findLoadedClass = ClassLoader.class.getDeclaredMethod("findLoadedClass", new Class[] { String.class });
/*  680 */           findLoadedClass.setAccessible(true);
/*  681 */           Method defineClass = ClassLoader.class.getDeclaredMethod("defineClass", new Class[] { String.class, byte[].class, int.class, int.class, ProtectionDomain.class });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  687 */           defineClass.setAccessible(true);
/*  688 */           Method definePackage = ClassLoader.class.getDeclaredMethod("definePackage", new Class[] { String.class, String.class, String.class, String.class, String.class, String.class, String.class, URL.class });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  697 */           definePackage.setAccessible(true);
/*      */           try {
/*  699 */             Method getClassLoadingLock = ClassLoader.class.getDeclaredMethod("getClassLoadingLock", new Class[] { String.class });
/*  700 */             getClassLoadingLock.setAccessible(true);
/*  701 */             return new ForJava7CapableVm(findLoadedClass, defineClass, getDefinedPackage, getPackage, definePackage, getClassLoadingLock);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  707 */           catch (NoSuchMethodException ignored) {
/*  708 */             return new ForLegacyVm(findLoadedClass, defineClass, getDefinedPackage, getPackage, definePackage);
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isAvailable() {
/*  716 */           return true;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public ClassInjector.UsingReflection.Dispatcher initialize() {
/*  723 */           Object securityManager = ClassInjector.UsingReflection.SYSTEM.getSecurityManager();
/*  724 */           if (securityManager != null) {
/*      */             try {
/*  726 */               ClassInjector.UsingReflection.CHECK_PERMISSION.invoke(securityManager, new Object[] { ClassInjector.AbstractBase.SUPPRESS_ACCESS_CHECKS });
/*  727 */             } catch (InvocationTargetException exception) {
/*  728 */               return new ClassInjector.UsingReflection.Dispatcher.Unavailable(exception.getTargetException().getMessage());
/*  729 */             } catch (Exception exception) {
/*  730 */               return new ClassInjector.UsingReflection.Dispatcher.Unavailable(exception.getMessage());
/*      */             } 
/*      */           }
/*  733 */           return this;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Class<?> findClass(ClassLoader classLoader, String name) {
/*      */           try {
/*  741 */             return (Class)this.findLoadedClass.invoke(classLoader, new Object[] { name });
/*  742 */           } catch (IllegalAccessException exception) {
/*  743 */             throw new IllegalStateException(exception);
/*  744 */           } catch (InvocationTargetException exception) {
/*  745 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Class<?> defineClass(ClassLoader classLoader, String name, byte[] binaryRepresentation, @MaybeNull ProtectionDomain protectionDomain) {
/*      */           try {
/*  754 */             return (Class)this.defineClass.invoke(classLoader, new Object[] { name, binaryRepresentation, Integer.valueOf(0), Integer.valueOf(binaryRepresentation.length), protectionDomain });
/*  755 */           } catch (IllegalAccessException exception) {
/*  756 */             throw new IllegalStateException(exception);
/*  757 */           } catch (InvocationTargetException exception) {
/*  758 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @MaybeNull
/*      */         public Package getDefinedPackage(ClassLoader classLoader, String name) {
/*  767 */           if (this.getDefinedPackage == null) {
/*  768 */             return getPackage(classLoader, name);
/*      */           }
/*      */           try {
/*  771 */             return (Package)this.getDefinedPackage.invoke(classLoader, new Object[] { name });
/*  772 */           } catch (IllegalAccessException exception) {
/*  773 */             throw new IllegalStateException(exception);
/*  774 */           } catch (InvocationTargetException exception) {
/*  775 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Package getPackage(ClassLoader classLoader, String name) {
/*      */           try {
/*  784 */             return (Package)this.getPackage.invoke(classLoader, new Object[] { name });
/*  785 */           } catch (IllegalAccessException exception) {
/*  786 */             throw new IllegalStateException(exception);
/*  787 */           } catch (InvocationTargetException exception) {
/*  788 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Package definePackage(ClassLoader classLoader, String name, @MaybeNull String specificationTitle, @MaybeNull String specificationVersion, @MaybeNull String specificationVendor, @MaybeNull String implementationTitle, @MaybeNull String implementationVersion, @MaybeNull String implementationVendor, @MaybeNull URL sealBase) {
/*      */           try {
/*  805 */             return (Package)this.definePackage.invoke(classLoader, new Object[] { name, specificationTitle, specificationVersion, specificationVendor, implementationTitle, implementationVersion, implementationVendor, sealBase });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  814 */           catch (IllegalAccessException exception) {
/*  815 */             throw new IllegalStateException(exception);
/*  816 */           } catch (InvocationTargetException exception) {
/*  817 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.findLoadedClass.equals(((Direct)param3Object).findLoadedClass) ? false : (!this.defineClass.equals(((Direct)param3Object).defineClass) ? false : (!this.getDefinedPackage.equals(((Direct)param3Object).getDefinedPackage) ? false : (!this.getPackage.equals(((Direct)param3Object).getPackage) ? false : (!!this.definePackage.equals(((Direct)param3Object).definePackage))))))));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return ((((getClass().hashCode() * 31 + this.findLoadedClass.hashCode()) * 31 + this.defineClass.hashCode()) * 31 + this.getDefinedPackage.hashCode()) * 31 + this.getPackage.hashCode()) * 31 + this.definePackage.hashCode();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         protected static class ForJava7CapableVm
/*      */           extends Direct
/*      */         {
/*      */           private final Method getClassLoadingLock;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected ForJava7CapableVm(Method findLoadedClass, Method defineClass, @MaybeNull Method getDefinedPackage, Method getPackage, Method definePackage, Method getClassLoadingLock) {
/*  848 */             super(findLoadedClass, defineClass, getDefinedPackage, getPackage, definePackage);
/*  849 */             this.getClassLoadingLock = getClassLoadingLock;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Object getClassLoadingLock(ClassLoader classLoader, String name) {
/*      */             try {
/*  857 */               return this.getClassLoadingLock.invoke(classLoader, new Object[] { name });
/*  858 */             } catch (IllegalAccessException exception) {
/*  859 */               throw new IllegalStateException(exception);
/*  860 */             } catch (InvocationTargetException exception) {
/*  861 */               throw new IllegalStateException(exception.getTargetException());
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.getClassLoadingLock.equals(((ForJava7CapableVm)param4Object).getClassLoadingLock)))));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return super.hashCode() * 31 + this.getClassLoadingLock.hashCode();
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         protected static class ForLegacyVm
/*      */           extends Direct
/*      */         {
/*      */           protected ForLegacyVm(Method findLoadedClass, Method defineClass, @MaybeNull Method getDefinedPackage, Method getPackage, Method definePackage) {
/*  885 */             super(findLoadedClass, defineClass, getDefinedPackage, getPackage, definePackage);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Object getClassLoadingLock(ClassLoader classLoader, String name) {
/*  892 */             return classLoader;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static class UsingUnsafeInjection
/*      */         implements Dispatcher, Initializable
/*      */       {
/*      */         private final Object accessor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final Method findLoadedClass;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final Method defineClass;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @UnknownNull
/*      */         private final Method getDefinedPackage;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final Method getPackage;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final Method definePackage;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final Method getClassLoadingLock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected UsingUnsafeInjection(Object accessor, Method findLoadedClass, Method defineClass, @MaybeNull Method getDefinedPackage, Method getPackage, Method definePackage, Method getClassLoadingLock) {
/*  959 */           this.accessor = accessor;
/*  960 */           this.findLoadedClass = findLoadedClass;
/*  961 */           this.defineClass = defineClass;
/*  962 */           this.getDefinedPackage = getDefinedPackage;
/*  963 */           this.getPackage = getPackage;
/*  964 */           this.definePackage = definePackage;
/*  965 */           this.getClassLoadingLock = getClassLoadingLock;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @SuppressFBWarnings(value = {"DP_DO_INSIDE_DO_PRIVILEGED"}, justification = "Assuring privilege is explicit user responsibility.")
/*      */         protected static ClassInjector.UsingReflection.Dispatcher.Initializable make() throws Exception {
/*      */           Method getDefinedPackage;
/*  976 */           if (Boolean.parseBoolean(System.getProperty("net.bytebuddy.safe", Boolean.toString(GraalImageCode.getCurrent().isDefined())))) {
/*  977 */             return new ClassInjector.UsingReflection.Dispatcher.Initializable.Unavailable("Use of Unsafe was disabled by system property");
/*      */           }
/*  979 */           Class<?> unsafe = Class.forName("sun.misc.Unsafe");
/*  980 */           Field theUnsafe = unsafe.getDeclaredField("theUnsafe");
/*  981 */           theUnsafe.setAccessible(true);
/*  982 */           Object unsafeInstance = theUnsafe.get(null);
/*      */           
/*  984 */           if (JavaModule.isSupported()) {
/*      */             try {
/*  986 */               getDefinedPackage = ClassLoader.class.getDeclaredMethod("getDefinedPackage", new Class[] { String.class });
/*  987 */             } catch (NoSuchMethodException ignored) {
/*  988 */               getDefinedPackage = null;
/*      */             } 
/*      */           } else {
/*  991 */             getDefinedPackage = null;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1019 */           DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition receiverTypeDefinition = (new ByteBuddy()).with(TypeValidation.DISABLED).subclass(Object.class, (ConstructorStrategy)ConstructorStrategy.Default.NO_CONSTRUCTORS).name(ClassLoader.class.getName() + "$ByteBuddyAccessor$V1").defineMethod("findLoadedClass", Class.class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC }).withParameters(new Type[] { ClassLoader.class, String.class }).intercept((Implementation)MethodCall.invoke(ClassLoader.class.getDeclaredMethod("findLoadedClass", new Class[] { String.class })).onArgument(0).withArgument(new int[] { 1 })).defineMethod("defineClass", Class.class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC }).withParameters(new Type[] { ClassLoader.class, String.class, byte[].class, int.class, int.class, ProtectionDomain.class }).intercept((Implementation)MethodCall.invoke(ClassLoader.class.getDeclaredMethod("defineClass", new Class[] { String.class, byte[].class, int.class, int.class, ProtectionDomain.class })).onArgument(0).withArgument(new int[] { 1, 2, 3, 4, 5 })).defineMethod("getPackage", Package.class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC }).withParameters(new Type[] { ClassLoader.class, String.class }).intercept((Implementation)MethodCall.invoke(ClassLoader.class.getDeclaredMethod("getPackage", new Class[] { String.class })).onArgument(0).withArgument(new int[] { 1 })).defineMethod("definePackage", Package.class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC }).withParameters(new Type[] { ClassLoader.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, URL.class }).intercept((Implementation)MethodCall.invoke(ClassLoader.class
/* 1020 */                 .getDeclaredMethod("definePackage", new Class[] { String.class, String.class, String.class, String.class, String.class, String.class, String.class, URL.class
/* 1021 */                   })).onArgument(0)
/* 1022 */               .withArgument(new int[] { 1, 2, 3, 4, 5, 6, 7, 8 }));
/* 1023 */           if (getDefinedPackage != null)
/*      */           {
/*      */ 
/*      */             
/* 1027 */             receiverTypeDefinition = receiverTypeDefinition.defineMethod("getDefinedPackage", Package.class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC }).withParameters(new Type[] { ClassLoader.class, String.class }).intercept((Implementation)MethodCall.invoke(getDefinedPackage)
/* 1028 */                 .onArgument(0)
/* 1029 */                 .withArgument(new int[] { 1 }));
/*      */           }
/*      */ 
/*      */           
/*      */           try {
/* 1034 */             receiverTypeDefinition = receiverTypeDefinition.defineMethod("getClassLoadingLock", Object.class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC }).withParameters(new Type[] { ClassLoader.class, String.class }).intercept((Implementation)MethodCall.invoke(ClassLoader.class.getDeclaredMethod("getClassLoadingLock", new Class[] { String.class
/* 1035 */                     })).onArgument(0)
/* 1036 */                 .withArgument(new int[] { 1 }));
/* 1037 */           } catch (NoSuchMethodException ignored) {
/*      */ 
/*      */             
/* 1040 */             receiverTypeDefinition = receiverTypeDefinition.defineMethod("getClassLoadingLock", Object.class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC }).withParameters(new Type[] { ClassLoader.class, String.class }).intercept((Implementation)FixedValue.argument(0));
/*      */           } 
/*      */ 
/*      */           
/* 1044 */           Class<?> type = receiverTypeDefinition.make().load(ClassLoadingStrategy.BOOTSTRAP_LOADER, new ClassLoadingStrategy.ForUnsafeInjection()).getLoaded();
/* 1045 */           return new UsingUnsafeInjection(unsafe
/* 1046 */               .getMethod("allocateInstance", new Class[] { Class.class }).invoke(unsafeInstance, new Object[] { type }), type
/* 1047 */               .getMethod("findLoadedClass", new Class[] { ClassLoader.class, String.class }), type
/* 1048 */               .getMethod("defineClass", new Class[] { ClassLoader.class, String.class, byte[].class, int.class, int.class, ProtectionDomain.class }), (getDefinedPackage != null) ? type
/* 1049 */               .getMethod("getDefinedPackage", new Class[] { ClassLoader.class, String.class }) : null, type
/* 1050 */               .getMethod("getPackage", new Class[] { ClassLoader.class, String.class }), type
/* 1051 */               .getMethod("definePackage", new Class[] { ClassLoader.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, URL.class }), type
/* 1052 */               .getMethod("getClassLoadingLock", new Class[] { ClassLoader.class, String.class }));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isAvailable() {
/* 1059 */           return true;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public ClassInjector.UsingReflection.Dispatcher initialize() {
/* 1066 */           Object securityManager = ClassInjector.UsingReflection.SYSTEM.getSecurityManager();
/* 1067 */           if (securityManager != null) {
/*      */             try {
/* 1069 */               ClassInjector.UsingReflection.CHECK_PERMISSION.invoke(securityManager, new Object[] { ClassInjector.AbstractBase.SUPPRESS_ACCESS_CHECKS });
/* 1070 */             } catch (InvocationTargetException exception) {
/* 1071 */               return new ClassInjector.UsingReflection.Dispatcher.Unavailable(exception.getTargetException().getMessage());
/* 1072 */             } catch (Exception exception) {
/* 1073 */               return new ClassInjector.UsingReflection.Dispatcher.Unavailable(exception.getMessage());
/*      */             } 
/*      */           }
/* 1076 */           return this;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Object getClassLoadingLock(ClassLoader classLoader, String name) {
/*      */           try {
/* 1084 */             return this.getClassLoadingLock.invoke(this.accessor, new Object[] { classLoader, name });
/* 1085 */           } catch (IllegalAccessException exception) {
/* 1086 */             throw new IllegalStateException(exception);
/* 1087 */           } catch (InvocationTargetException exception) {
/* 1088 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Class<?> findClass(ClassLoader classLoader, String name) {
/*      */           try {
/* 1097 */             return (Class)this.findLoadedClass.invoke(this.accessor, new Object[] { classLoader, name });
/* 1098 */           } catch (IllegalAccessException exception) {
/* 1099 */             throw new IllegalStateException(exception);
/* 1100 */           } catch (InvocationTargetException exception) {
/* 1101 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Class<?> defineClass(ClassLoader classLoader, String name, byte[] binaryRepresentation, @MaybeNull ProtectionDomain protectionDomain) {
/*      */           try {
/* 1110 */             return (Class)this.defineClass.invoke(this.accessor, new Object[] { classLoader, name, binaryRepresentation, Integer.valueOf(0), Integer.valueOf(binaryRepresentation.length), protectionDomain });
/* 1111 */           } catch (IllegalAccessException exception) {
/* 1112 */             throw new IllegalStateException(exception);
/* 1113 */           } catch (InvocationTargetException exception) {
/* 1114 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @MaybeNull
/*      */         public Package getDefinedPackage(ClassLoader classLoader, String name) {
/* 1123 */           if (this.getDefinedPackage == null) {
/* 1124 */             return getPackage(classLoader, name);
/*      */           }
/*      */           try {
/* 1127 */             return (Package)this.getDefinedPackage.invoke(this.accessor, new Object[] { classLoader, name });
/* 1128 */           } catch (IllegalAccessException exception) {
/* 1129 */             throw new IllegalStateException(exception);
/* 1130 */           } catch (InvocationTargetException exception) {
/* 1131 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Package getPackage(ClassLoader classLoader, String name) {
/*      */           try {
/* 1140 */             return (Package)this.getPackage.invoke(this.accessor, new Object[] { classLoader, name });
/* 1141 */           } catch (IllegalAccessException exception) {
/* 1142 */             throw new IllegalStateException(exception);
/* 1143 */           } catch (InvocationTargetException exception) {
/* 1144 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Package definePackage(ClassLoader classLoader, String name, @MaybeNull String specificationTitle, @MaybeNull String specificationVersion, @MaybeNull String specificationVendor, @MaybeNull String implementationTitle, @MaybeNull String implementationVersion, @MaybeNull String implementationVendor, @MaybeNull URL sealBase) {
/*      */           try {
/* 1161 */             return (Package)this.definePackage.invoke(this.accessor, new Object[] { classLoader, name, specificationTitle, specificationVersion, specificationVendor, implementationTitle, implementationVersion, implementationVendor, sealBase });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/* 1171 */           catch (IllegalAccessException exception) {
/* 1172 */             throw new IllegalStateException(exception);
/* 1173 */           } catch (InvocationTargetException exception) {
/* 1174 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.accessor.equals(((UsingUnsafeInjection)param3Object).accessor) ? false : (!this.findLoadedClass.equals(((UsingUnsafeInjection)param3Object).findLoadedClass) ? false : (!this.defineClass.equals(((UsingUnsafeInjection)param3Object).defineClass) ? false : (!this.getDefinedPackage.equals(((UsingUnsafeInjection)param3Object).getDefinedPackage) ? false : (!this.getPackage.equals(((UsingUnsafeInjection)param3Object).getPackage) ? false : (!this.definePackage.equals(((UsingUnsafeInjection)param3Object).definePackage) ? false : (!!this.getClassLoadingLock.equals(((UsingUnsafeInjection)param3Object).getClassLoadingLock))))))))));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return ((((((getClass().hashCode() * 31 + this.accessor.hashCode()) * 31 + this.findLoadedClass.hashCode()) * 31 + this.defineClass.hashCode()) * 31 + this.getDefinedPackage.hashCode()) * 31 + this.getPackage.hashCode()) * 31 + this.definePackage.hashCode()) * 31 + this.getClassLoadingLock.hashCode();
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static abstract class UsingUnsafeOverride
/*      */         implements Dispatcher, Initializable
/*      */       {
/*      */         protected final Method findLoadedClass;
/*      */ 
/*      */ 
/*      */         
/*      */         protected final Method defineClass;
/*      */ 
/*      */ 
/*      */         
/*      */         @MaybeNull
/*      */         protected final Method getDefinedPackage;
/*      */ 
/*      */ 
/*      */         
/*      */         protected final Method getPackage;
/*      */ 
/*      */ 
/*      */         
/*      */         protected final Method definePackage;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected UsingUnsafeOverride(Method findLoadedClass, Method defineClass, @MaybeNull Method getDefinedPackage, Method getPackage, Method definePackage) {
/* 1225 */           this.findLoadedClass = findLoadedClass;
/* 1226 */           this.defineClass = defineClass;
/* 1227 */           this.getDefinedPackage = getDefinedPackage;
/* 1228 */           this.getPackage = getPackage;
/* 1229 */           this.definePackage = definePackage;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @SuppressFBWarnings(value = {"DP_DO_INSIDE_DO_PRIVILEGED"}, justification = "Assuring privilege is explicit user responsibility.")
/*      */         protected static ClassInjector.UsingReflection.Dispatcher.Initializable make() throws Exception {
/*      */           Field override;
/*      */           Method getDefinedPackage;
/* 1240 */           if (Boolean.parseBoolean(System.getProperty("net.bytebuddy.safe", Boolean.toString(GraalImageCode.getCurrent().isDefined())))) {
/* 1241 */             return new ClassInjector.UsingReflection.Dispatcher.Initializable.Unavailable("Use of Unsafe was disabled by system property");
/*      */           }
/* 1243 */           Class<?> unsafeType = Class.forName("sun.misc.Unsafe");
/* 1244 */           Field theUnsafe = unsafeType.getDeclaredField("theUnsafe");
/* 1245 */           theUnsafe.setAccessible(true);
/* 1246 */           Object unsafe = theUnsafe.get(null);
/*      */           
/*      */           try {
/* 1249 */             override = AccessibleObject.class.getDeclaredField("override");
/* 1250 */           } catch (NoSuchFieldException ignored) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1263 */             override = (new ByteBuddy()).redefine(AccessibleObject.class).name("net.bytebuddy.mirror." + AccessibleObject.class.getSimpleName()).noNestMate().visit((AsmVisitorWrapper)(new MemberRemoval()).stripInvokables((ElementMatcher)ElementMatchers.any())).make().load(AccessibleObject.class.getClassLoader(), ClassLoadingStrategy.Default.WRAPPER.with(AccessibleObject.class.getProtectionDomain())).getLoaded().getDeclaredField("override");
/*      */           } 
/* 1265 */           long offset = ((Long)unsafeType
/* 1266 */             .getMethod("objectFieldOffset", new Class[] { Field.class
/* 1267 */               }).invoke(unsafe, new Object[] { override })).longValue();
/* 1268 */           Method putBoolean = unsafeType.getMethod("putBoolean", new Class[] { Object.class, long.class, boolean.class });
/*      */           
/* 1270 */           if (JavaModule.isSupported()) {
/*      */             try {
/* 1272 */               getDefinedPackage = ClassLoader.class.getMethod("getDefinedPackage", new Class[] { String.class });
/* 1273 */             } catch (NoSuchMethodException ignored) {
/* 1274 */               getDefinedPackage = null;
/*      */             } 
/*      */           } else {
/* 1277 */             getDefinedPackage = null;
/*      */           } 
/* 1279 */           Method getPackage = ClassLoader.class.getDeclaredMethod("getPackage", new Class[] { String.class });
/* 1280 */           putBoolean.invoke(unsafe, new Object[] { getPackage, Long.valueOf(offset), Boolean.valueOf(true) });
/* 1281 */           Method findLoadedClass = ClassLoader.class.getDeclaredMethod("findLoadedClass", new Class[] { String.class });
/* 1282 */           Method defineClass = ClassLoader.class.getDeclaredMethod("defineClass", new Class[] { String.class, byte[].class, int.class, int.class, ProtectionDomain.class });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1288 */           Method definePackage = ClassLoader.class.getDeclaredMethod("definePackage", new Class[] { String.class, String.class, String.class, String.class, String.class, String.class, String.class, URL.class });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1297 */           putBoolean.invoke(unsafe, new Object[] { defineClass, Long.valueOf(offset), Boolean.valueOf(true) });
/* 1298 */           putBoolean.invoke(unsafe, new Object[] { findLoadedClass, Long.valueOf(offset), Boolean.valueOf(true) });
/* 1299 */           putBoolean.invoke(unsafe, new Object[] { definePackage, Long.valueOf(offset), Boolean.valueOf(true) });
/*      */           try {
/* 1301 */             Method getClassLoadingLock = ClassLoader.class.getDeclaredMethod("getClassLoadingLock", new Class[] { String.class });
/* 1302 */             putBoolean.invoke(unsafe, new Object[] { getClassLoadingLock, Long.valueOf(offset), Boolean.valueOf(true) });
/* 1303 */             return new ForJava7CapableVm(findLoadedClass, defineClass, getDefinedPackage, getPackage, definePackage, getClassLoadingLock);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/* 1309 */           catch (NoSuchMethodException ignored) {
/* 1310 */             return new ForLegacyVm(findLoadedClass, defineClass, getDefinedPackage, getPackage, definePackage);
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isAvailable() {
/* 1318 */           return true;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public ClassInjector.UsingReflection.Dispatcher initialize() {
/* 1325 */           Object securityManager = ClassInjector.UsingReflection.SYSTEM.getSecurityManager();
/* 1326 */           if (securityManager != null) {
/*      */             try {
/* 1328 */               ClassInjector.UsingReflection.CHECK_PERMISSION.invoke(securityManager, new Object[] { ClassInjector.AbstractBase.SUPPRESS_ACCESS_CHECKS });
/* 1329 */             } catch (InvocationTargetException exception) {
/* 1330 */               return new ClassInjector.UsingReflection.Dispatcher.Unavailable(exception.getTargetException().getMessage());
/* 1331 */             } catch (Exception exception) {
/* 1332 */               return new ClassInjector.UsingReflection.Dispatcher.Unavailable(exception.getMessage());
/*      */             } 
/*      */           }
/* 1335 */           return this;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Class<?> findClass(ClassLoader classLoader, String name) {
/*      */           try {
/* 1343 */             return (Class)this.findLoadedClass.invoke(classLoader, new Object[] { name });
/* 1344 */           } catch (IllegalAccessException exception) {
/* 1345 */             throw new IllegalStateException(exception);
/* 1346 */           } catch (InvocationTargetException exception) {
/* 1347 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Class<?> defineClass(ClassLoader classLoader, String name, byte[] binaryRepresentation, @MaybeNull ProtectionDomain protectionDomain) {
/*      */           try {
/* 1356 */             return (Class)this.defineClass.invoke(classLoader, new Object[] { name, binaryRepresentation, Integer.valueOf(0), Integer.valueOf(binaryRepresentation.length), protectionDomain });
/* 1357 */           } catch (IllegalAccessException exception) {
/* 1358 */             throw new IllegalStateException(exception);
/* 1359 */           } catch (InvocationTargetException exception) {
/* 1360 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @MaybeNull
/*      */         public Package getDefinedPackage(ClassLoader classLoader, String name) {
/* 1369 */           if (this.getDefinedPackage == null) {
/* 1370 */             return getPackage(classLoader, name);
/*      */           }
/*      */           try {
/* 1373 */             return (Package)this.getDefinedPackage.invoke(classLoader, new Object[] { name });
/* 1374 */           } catch (IllegalAccessException exception) {
/* 1375 */             throw new IllegalStateException(exception);
/* 1376 */           } catch (InvocationTargetException exception) {
/* 1377 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Package getPackage(ClassLoader classLoader, String name) {
/*      */           try {
/* 1386 */             return (Package)this.getPackage.invoke(classLoader, new Object[] { name });
/* 1387 */           } catch (IllegalAccessException exception) {
/* 1388 */             throw new IllegalStateException(exception);
/* 1389 */           } catch (InvocationTargetException exception) {
/* 1390 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Package definePackage(ClassLoader classLoader, String name, @MaybeNull String specificationTitle, @MaybeNull String specificationVersion, @MaybeNull String specificationVendor, @MaybeNull String implementationTitle, @MaybeNull String implementationVersion, @MaybeNull String implementationVendor, @MaybeNull URL sealBase) {
/*      */           try {
/* 1407 */             return (Package)this.definePackage.invoke(classLoader, new Object[] { name, specificationTitle, specificationVersion, specificationVendor, implementationTitle, implementationVersion, implementationVendor, sealBase });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/* 1416 */           catch (IllegalAccessException exception) {
/* 1417 */             throw new IllegalStateException(exception);
/* 1418 */           } catch (InvocationTargetException exception) {
/* 1419 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         protected static class ForJava7CapableVm
/*      */           extends UsingUnsafeOverride
/*      */         {
/*      */           private final Method getClassLoadingLock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected ForJava7CapableVm(Method findLoadedClass, Method defineClass, @MaybeNull Method getDefinedPackage, Method getPackage, Method definePackage, Method getClassLoadingLock) {
/* 1450 */             super(findLoadedClass, defineClass, getDefinedPackage, getPackage, definePackage);
/* 1451 */             this.getClassLoadingLock = getClassLoadingLock;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Object getClassLoadingLock(ClassLoader classLoader, String name) {
/*      */             try {
/* 1459 */               return this.getClassLoadingLock.invoke(classLoader, new Object[] { name });
/* 1460 */             } catch (IllegalAccessException exception) {
/* 1461 */               throw new IllegalStateException(exception);
/* 1462 */             } catch (InvocationTargetException exception) {
/* 1463 */               throw new IllegalStateException(exception.getTargetException());
/*      */             } 
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.getClassLoadingLock.equals(((ForJava7CapableVm)param4Object).getClassLoadingLock))));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return getClass().hashCode() * 31 + this.getClassLoadingLock.hashCode();
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         protected static class ForLegacyVm
/*      */           extends UsingUnsafeOverride
/*      */         {
/*      */           protected ForLegacyVm(Method findLoadedClass, Method defineClass, @MaybeNull Method getDefinedPackage, Method getPackage, Method definePackage) {
/* 1487 */             super(findLoadedClass, defineClass, getDefinedPackage, getPackage, definePackage);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Object getClassLoadingLock(ClassLoader classLoader, String name) {
/* 1494 */             return classLoader;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static class Unavailable
/*      */         implements Dispatcher
/*      */       {
/*      */         private final String message;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected Unavailable(String message) {
/* 1516 */           this.message = message;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Object getClassLoadingLock(ClassLoader classLoader, String name) {
/* 1523 */           return classLoader;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Class<?> findClass(ClassLoader classLoader, String name) {
/*      */           try {
/* 1531 */             return classLoader.loadClass(name);
/* 1532 */           } catch (ClassNotFoundException ignored) {
/* 1533 */             return UNDEFINED;
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Class<?> defineClass(ClassLoader classLoader, String name, byte[] binaryRepresentation, @MaybeNull ProtectionDomain protectionDomain) {
/* 1541 */           throw new UnsupportedOperationException("Cannot define class using reflection: " + this.message);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Package getDefinedPackage(ClassLoader classLoader, String name) {
/* 1548 */           throw new UnsupportedOperationException("Cannot get defined package using reflection: " + this.message);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Package getPackage(ClassLoader classLoader, String name) {
/* 1555 */           throw new UnsupportedOperationException("Cannot get package using reflection: " + this.message);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.message.equals(((Unavailable)param3Object).message))));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Package definePackage(ClassLoader classLoader, String name, @MaybeNull String specificationTitle, @MaybeNull String specificationVersion, @MaybeNull String specificationVendor, @MaybeNull String implementationTitle, @MaybeNull String implementationVersion, @MaybeNull String implementationVendor, @MaybeNull URL sealBase) {
/* 1570 */           throw new UnsupportedOperationException("Cannot define package using injection: " + this.message);
/*      */         }
/*      */         public int hashCode() { return getClass().hashCode() * 31 + this.message.hashCode(); } } }
/*      */      public static interface Initializable {
/*      */       boolean isAvailable(); ClassInjector.UsingReflection.Dispatcher initialize(); @Enhance
/*      */       public static class Unavailable implements ClassInjector.UsingReflection.Dispatcher, Initializable {
/*      */         private final String message; protected Unavailable(String message) { this.message = message; } public boolean isAvailable() { return false; } public ClassInjector.UsingReflection.Dispatcher initialize() { return this; } public Object getClassLoadingLock(ClassLoader classLoader, String name) { return classLoader; } public Class<?> findClass(ClassLoader classLoader, String name) { try {
/*      */             return classLoader.loadClass(name);
/*      */           } catch (ClassNotFoundException ignored) {
/*      */             return UNDEFINED;
/*      */           }  } public Class<?> defineClass(ClassLoader classLoader, String name, byte[] binaryRepresentation, @MaybeNull ProtectionDomain protectionDomain) { throw new UnsupportedOperationException("Cannot define class using reflection: " + this.message); } public Package getDefinedPackage(ClassLoader classLoader, String name) {
/*      */           throw new UnsupportedOperationException("Cannot get defined package using reflection: " + this.message);
/*      */         } public Package getPackage(ClassLoader classLoader, String name) {
/*      */           throw new UnsupportedOperationException("Cannot get package using reflection: " + this.message);
/*      */         } public Package definePackage(ClassLoader classLoader, String name, @MaybeNull String specificationTitle, @MaybeNull String specificationVersion, @MaybeNull String specificationVendor, @MaybeNull String implementationTitle, @MaybeNull String implementationVersion, @MaybeNull String implementationVendor, @MaybeNull URL sealBase) {
/*      */           throw new UnsupportedOperationException("Cannot define package using injection: " + this.message);
/*      */         } public boolean equals(@MaybeNull Object param4Object) {
/*      */           return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.message.equals(((Unavailable)param4Object).message))));
/*      */         } public int hashCode() {
/*      */           return getClass().hashCode() * 31 + this.message.hashCode();
/*      */         }
/*      */       }
/*      */     } public enum CreationAction implements PrivilegedAction<Dispatcher.Initializable> {
/*      */       INSTANCE; @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.")
/*      */       public ClassInjector.UsingReflection.Dispatcher.Initializable run() {
/*      */         try {
/*      */           if (JavaModule.isSupported())
/*      */             return ClassInjector.UsingUnsafe.isAvailable() ? ClassInjector.UsingReflection.Dispatcher.UsingUnsafeInjection.make() : ClassInjector.UsingReflection.Dispatcher.UsingUnsafeOverride.make(); 
/*      */           return ClassInjector.UsingReflection.Dispatcher.Direct.make();
/*      */         } catch (InvocationTargetException exception) {
/*      */           return new ClassInjector.UsingReflection.Dispatcher.Initializable.Unavailable(exception.getTargetException().getMessage());
/*      */         } catch (Exception exception) {
/*      */           return new ClassInjector.UsingReflection.Dispatcher.Initializable.Unavailable(exception.getMessage());
/*      */         } 
/*      */       }
/*      */     }
/*      */   } @Enhance
/* 1607 */   public static class UsingLookup extends AbstractBase { private static final MethodHandles METHOD_HANDLES = doPrivileged(JavaDispatcher.of(MethodHandles.class));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1612 */     private static final MethodHandles.Lookup METHOD_HANDLES_LOOKUP = doPrivileged(JavaDispatcher.of(MethodHandles.Lookup.class)); private static final int PACKAGE_LOOKUP = 8; private final Object lookup; private static final boolean ACCESS_CONTROLLER; static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected UsingLookup(Object lookup) {
/* 1630 */       this.lookup = lookup;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 1642 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static UsingLookup of(Object lookup) {
/* 1652 */       if (!isAvailable())
/* 1653 */         throw new IllegalStateException("The current VM does not support class definition via method handle lookups"); 
/* 1654 */       if (!JavaType.METHOD_HANDLES_LOOKUP.isInstance(lookup))
/* 1655 */         throw new IllegalArgumentException("Not a method handle lookup: " + lookup); 
/* 1656 */       if ((METHOD_HANDLES_LOOKUP.lookupModes(lookup) & 0x8) == 0) {
/* 1657 */         throw new IllegalArgumentException("Lookup does not imply package-access: " + lookup);
/*      */       }
/* 1659 */       return new UsingLookup(lookup);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Class<?> lookupType() {
/* 1668 */       return METHOD_HANDLES_LOOKUP.lookupClass(this.lookup);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UsingLookup in(Class<?> type) {
/*      */       try {
/* 1679 */         return new UsingLookup(METHOD_HANDLES.privateLookupIn(type, this.lookup));
/* 1680 */       } catch (IllegalAccessException exception) {
/* 1681 */         throw new IllegalStateException("Cannot access " + type.getName() + " from " + this.lookup, exception);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isAlive() {
/* 1689 */       return isAvailable();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Map<String, Class<?>> injectRaw(Set<String> names, ClassFileLocator classFileLocator) {
/* 1696 */       PackageDescription target = TypeDescription.ForLoadedType.of(lookupType()).getPackage();
/* 1697 */       if (target == null) {
/* 1698 */         throw new IllegalArgumentException("Cannot inject array or primitive type");
/*      */       }
/* 1700 */       Map<String, Class<?>> result = new HashMap<String, Class<?>>();
/* 1701 */       for (String name : names) {
/* 1702 */         int index = name.lastIndexOf('.');
/* 1703 */         if (!target.getName().equals((index == -1) ? "" : name.substring(0, index))) {
/* 1704 */           throw new IllegalArgumentException(name + " must be defined in the same package as " + this.lookup);
/*      */         }
/*      */         try {
/* 1707 */           result.put(name, METHOD_HANDLES_LOOKUP.defineClass(this.lookup, classFileLocator.locate(name).resolve()));
/* 1708 */         } catch (Exception exception) {
/* 1709 */           throw new IllegalStateException(exception);
/*      */         } 
/*      */       } 
/* 1712 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static boolean isAvailable() {
/* 1721 */       return JavaType.MODULE.isAvailable();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.lookup.equals(((UsingLookup)param1Object).lookup))));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return getClass().hashCode() * 31 + this.lookup.hashCode();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     @Proxied("java.lang.invoke.MethodHandles")
/*      */     protected static interface MethodHandles
/*      */     {
/*      */       @IsStatic
/*      */       @Proxied("privateLookupIn")
/*      */       Object privateLookupIn(Class<?> param2Class, @Proxied("java.lang.invoke.MethodHandles$Lookup") Object param2Object) throws IllegalAccessException;
/*      */ 
/*      */ 
/*      */       
/*      */       @Proxied("java.lang.invoke.MethodHandles$Lookup")
/*      */       public static interface Lookup
/*      */       {
/*      */         @Proxied("lookupClass")
/*      */         Class<?> lookupClass(Object param3Object);
/*      */ 
/*      */ 
/*      */         
/*      */         @Proxied("lookupModes")
/*      */         int lookupModes(Object param3Object);
/*      */ 
/*      */ 
/*      */         
/*      */         @Proxied("defineClass")
/*      */         Class<?> defineClass(Object param3Object, byte[] param3ArrayOfbyte) throws IllegalAccessException;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     @Proxied("java.lang.invoke.MethodHandles$Lookup")
/*      */     public static interface Lookup
/*      */     {
/*      */       @Proxied("lookupClass")
/*      */       Class<?> lookupClass(Object param2Object);
/*      */ 
/*      */       
/*      */       @Proxied("lookupModes")
/*      */       int lookupModes(Object param2Object);
/*      */ 
/*      */       
/*      */       @Proxied("defineClass")
/*      */       Class<?> defineClass(Object param2Object, byte[] param2ArrayOfbyte) throws IllegalAccessException;
/*      */     } }
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static class UsingUnsafe
/*      */     extends AbstractBase
/*      */   {
/*      */     public static final String SAFE_PROPERTY = "net.bytebuddy.safe";
/*      */     
/* 1790 */     private static final Dispatcher.Initializable DISPATCHER = doPrivileged(Dispatcher.CreationAction.INSTANCE);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1795 */     private static final System SYSTEM = doPrivileged(JavaDispatcher.of(System.class));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1800 */     private static final Method CHECK_PERMISSION = doPrivileged((PrivilegedAction<Method>)new GetMethodAction("java.lang.SecurityManager", "checkPermission", new Class[] { Permission.class }));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1807 */     private static final Object BOOTSTRAP_LOADER_LOCK = new Object(); @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) private final ClassLoader classLoader; @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) private final ProtectionDomain protectionDomain; private final Dispatcher.Initializable dispatcher; private static final boolean ACCESS_CONTROLLER; static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UsingUnsafe(@MaybeNull ClassLoader classLoader) {
/* 1834 */       this(classLoader, ClassLoadingStrategy.NO_PROTECTION_DOMAIN);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UsingUnsafe(@MaybeNull ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain) {
/* 1844 */       this(classLoader, protectionDomain, DISPATCHER);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected UsingUnsafe(@MaybeNull ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain, Dispatcher.Initializable dispatcher) {
/* 1855 */       this.classLoader = classLoader;
/* 1856 */       this.protectionDomain = protectionDomain;
/* 1857 */       this.dispatcher = dispatcher;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 1869 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isAlive() {
/* 1876 */       return this.dispatcher.isAvailable();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Map<String, Class<?>> injectRaw(Set<String> names, ClassFileLocator classFileLocator) {
/* 1883 */       Dispatcher dispatcher = this.dispatcher.initialize();
/* 1884 */       Map<String, Class<?>> result = new HashMap<String, Class<?>>();
/* 1885 */       synchronized ((this.classLoader == null) ? BOOTSTRAP_LOADER_LOCK : this.classLoader) {
/*      */ 
/*      */         
/* 1888 */         for (String name : names) {
/*      */           try {
/* 1890 */             result.put(name, Class.forName(name, false, this.classLoader));
/* 1891 */           } catch (ClassNotFoundException ignored) {
/*      */             try {
/* 1893 */               result.put(name, dispatcher.defineClass(this.classLoader, name, classFileLocator.locate(name).resolve(), this.protectionDomain));
/* 1894 */             } catch (RuntimeException exception) {
/*      */               
/*      */               try {
/* 1897 */                 result.put(name, Class.forName(name, false, this.classLoader));
/* 1898 */               } catch (ClassNotFoundException ignored2) {
/* 1899 */                 throw exception;
/*      */               } 
/* 1901 */             } catch (IOException exception) {
/* 1902 */               throw new IllegalStateException("Failed to resolve binary representation of " + name, exception);
/* 1903 */             } catch (Error error) {
/*      */               
/*      */               try {
/* 1906 */                 result.put(name, Class.forName(name, false, this.classLoader));
/* 1907 */               } catch (ClassNotFoundException ignored2) {
/* 1908 */                 throw error;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1914 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static boolean isAvailable() {
/* 1923 */       return DISPATCHER.isAvailable();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassInjector ofSystemLoader() {
/* 1932 */       return new UsingUnsafe(ClassLoader.getSystemClassLoader());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassInjector ofPlatformLoader() {
/* 1942 */       return new UsingUnsafe(ClassLoader.getSystemClassLoader().getParent());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassInjector ofBootLoader() {
/* 1951 */       return new UsingUnsafe(ClassLoadingStrategy.BOOTSTRAP_LOADER);
/*      */     }
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       if (this == param1Object) {
/*      */         return true;
/*      */       }
/*      */       if (param1Object == null) {
/*      */         return false;
/*      */       }
/*      */       if (getClass() != param1Object.getClass())
/*      */         return false; 
/*      */       ClassLoader classLoader1 = ((UsingUnsafe)param1Object).classLoader;
/*      */       ClassLoader classLoader2 = this.classLoader;
/*      */       if (classLoader1 != null) {
/*      */         if (classLoader2 != null) {
/*      */           if (!classLoader2.equals(classLoader1))
/*      */             return false; 
/*      */         } else {
/*      */           return false;
/*      */         } 
/*      */       } else if (classLoader2 != null) {
/*      */         return false;
/*      */       } 
/*      */       ProtectionDomain protectionDomain1 = ((UsingUnsafe)param1Object).protectionDomain;
/*      */       ProtectionDomain protectionDomain2 = this.protectionDomain;
/*      */       if (protectionDomain1 != null) {
/*      */         if (protectionDomain2 != null) {
/*      */           if (!protectionDomain2.equals(protectionDomain1))
/*      */             return false; 
/*      */         } else {
/*      */           return false;
/*      */         } 
/*      */       } else if (protectionDomain2 != null) {
/*      */         return false;
/*      */       } 
/*      */       return !!this.dispatcher.equals(((UsingUnsafe)param1Object).dispatcher);
/*      */     }
/*      */     
/*      */     public int hashCode() {
/*      */       ClassLoader classLoader = this.classLoader;
/*      */       if (classLoader != null);
/*      */       ProtectionDomain protectionDomain = this.protectionDomain;
/*      */       if (protectionDomain != null);
/*      */       return ((getClass().hashCode() * 31 + classLoader.hashCode()) * 31 + protectionDomain.hashCode()) * 31 + this.dispatcher.hashCode();
/*      */     }
/*      */     
/*      */     public enum CreationAction
/*      */       implements PrivilegedAction<Dispatcher.Initializable>
/*      */     {
/* 2001 */       INSTANCE;
/*      */ 
/*      */ 
/*      */       
/*      */       @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.")
/*      */       public ClassInjector.UsingUnsafe.Dispatcher.Initializable run()
/*      */       {
/* 2008 */         if (Boolean.parseBoolean(System.getProperty("net.bytebuddy.safe", Boolean.toString(GraalImageCode.getCurrent().isDefined())))) {
/* 2009 */           return new ClassInjector.UsingUnsafe.Dispatcher.Unavailable("Use of Unsafe was disabled by system property");
/*      */         }
/*      */         
/* 2012 */         try { Class<?> unsafeType = Class.forName("sun.misc.Unsafe");
/* 2013 */           Field theUnsafe = unsafeType.getDeclaredField("theUnsafe");
/* 2014 */           theUnsafe.setAccessible(true);
/* 2015 */           Object unsafe = theUnsafe.get(null);
/*      */           try {
/* 2017 */             Method defineClass = unsafeType.getMethod("defineClass", new Class[] { String.class, byte[].class, int.class, int.class, ClassLoader.class, ProtectionDomain.class });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2024 */             defineClass.setAccessible(true);
/* 2025 */             return new ClassInjector.UsingUnsafe.Dispatcher.Enabled(unsafe, defineClass);
/* 2026 */           } catch (Exception exception) {
/*      */             try {
/*      */               Field override;
/*      */               try {
/* 2030 */                 override = AccessibleObject.class.getDeclaredField("override");
/* 2031 */               } catch (NoSuchFieldException ignored) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 2044 */                 override = (new ByteBuddy()).redefine(AccessibleObject.class).name("net.bytebuddy.mirror." + AccessibleObject.class.getSimpleName()).noNestMate().visit((AsmVisitorWrapper)(new MemberRemoval()).stripInvokables((ElementMatcher)ElementMatchers.any())).make().load(AccessibleObject.class.getClassLoader(), ClassLoadingStrategy.Default.WRAPPER.with(AccessibleObject.class.getProtectionDomain())).getLoaded().getDeclaredField("override");
/*      */               } 
/* 2046 */               long offset = ((Long)unsafeType
/* 2047 */                 .getMethod("objectFieldOffset", new Class[] { Field.class
/* 2048 */                   }).invoke(unsafe, new Object[] { override })).longValue();
/* 2049 */               Method putBoolean = unsafeType.getMethod("putBoolean", new Class[] { Object.class, long.class, boolean.class });
/* 2050 */               Class<?> internalUnsafe = Class.forName("jdk.internal.misc.Unsafe");
/* 2051 */               Field theUnsafeInternal = internalUnsafe.getDeclaredField("theUnsafe");
/* 2052 */               putBoolean.invoke(unsafe, new Object[] { theUnsafeInternal, Long.valueOf(offset), Boolean.valueOf(true) });
/* 2053 */               Method defineClassInternal = internalUnsafe.getMethod("defineClass", new Class[] { String.class, byte[].class, int.class, int.class, ClassLoader.class, ProtectionDomain.class });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 2060 */               putBoolean.invoke(unsafe, new Object[] { defineClassInternal, Long.valueOf(offset), Boolean.valueOf(true) });
/* 2061 */               return new ClassInjector.UsingUnsafe.Dispatcher.Enabled(theUnsafeInternal.get(null), defineClassInternal);
/* 2062 */             } catch (Exception ignored) {
/* 2063 */               throw exception;
/*      */             } 
/*      */           }  }
/* 2066 */         catch (Exception exception)
/* 2067 */         { return new ClassInjector.UsingUnsafe.Dispatcher.Unavailable(exception.getMessage()); }  } } public static interface Initializable { boolean isAvailable(); ClassInjector.UsingUnsafe.Dispatcher initialize(); } protected static interface Dispatcher { Class<?> defineClass(@MaybeNull ClassLoader param2ClassLoader, String param2String, byte[] param2ArrayOfbyte, @MaybeNull ProtectionDomain param2ProtectionDomain); public static interface Initializable { boolean isAvailable(); ClassInjector.UsingUnsafe.Dispatcher initialize(); } public enum CreationAction implements PrivilegedAction<Initializable> { @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.") public ClassInjector.UsingUnsafe.Dispatcher.Initializable run() { if (Boolean.parseBoolean(System.getProperty("net.bytebuddy.safe", Boolean.toString(GraalImageCode.getCurrent().isDefined())))) return new ClassInjector.UsingUnsafe.Dispatcher.Unavailable("Use of Unsafe was disabled by system property");  try { Class<?> unsafeType = Class.forName("sun.misc.Unsafe"); Field theUnsafe = unsafeType.getDeclaredField("theUnsafe"); theUnsafe.setAccessible(true); Object unsafe = theUnsafe.get(null); try { Method defineClass = unsafeType.getMethod("defineClass", new Class[] { String.class, byte[].class, int.class, int.class, ClassLoader.class, ProtectionDomain.class }); defineClass.setAccessible(true); return new ClassInjector.UsingUnsafe.Dispatcher.Enabled(unsafe, defineClass); } catch (Exception exception) { try { Field override; try { override = AccessibleObject.class.getDeclaredField("override"); } catch (NoSuchFieldException ignored) { override = (new ByteBuddy()).redefine(AccessibleObject.class).name("net.bytebuddy.mirror." + AccessibleObject.class.getSimpleName()).noNestMate().visit((AsmVisitorWrapper)(new MemberRemoval()).stripInvokables((ElementMatcher)ElementMatchers.any())).make().load(AccessibleObject.class.getClassLoader(), ClassLoadingStrategy.Default.WRAPPER.with(AccessibleObject.class.getProtectionDomain())).getLoaded().getDeclaredField("override"); }  long offset = ((Long)unsafeType.getMethod("objectFieldOffset", new Class[] { Field.class }).invoke(unsafe, new Object[] { override })).longValue(); Method putBoolean = unsafeType.getMethod("putBoolean", new Class[] { Object.class, long.class, boolean.class }); Class<?> internalUnsafe = Class.forName("jdk.internal.misc.Unsafe"); Field theUnsafeInternal = internalUnsafe.getDeclaredField("theUnsafe"); putBoolean.invoke(unsafe, new Object[] { theUnsafeInternal, Long.valueOf(offset), Boolean.valueOf(true) }); Method defineClassInternal = internalUnsafe.getMethod("defineClass", new Class[] { String.class, byte[].class, int.class, int.class, ClassLoader.class, ProtectionDomain.class }); putBoolean.invoke(unsafe, new Object[] { defineClassInternal, Long.valueOf(offset), Boolean.valueOf(true) }); return new ClassInjector.UsingUnsafe.Dispatcher.Enabled(theUnsafeInternal.get(null), defineClassInternal); } catch (Exception ignored) { throw exception; }  }  } catch (Exception exception) { return new ClassInjector.UsingUnsafe.Dispatcher.Unavailable(exception.getMessage()); }
/*      */            }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         INSTANCE; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static class Enabled
/*      */         implements Dispatcher, Initializable
/*      */       {
/*      */         private final Object unsafe;
/*      */ 
/*      */ 
/*      */         
/*      */         private final Method defineClass;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected Enabled(Object unsafe, Method defineClass) {
/* 2095 */           this.unsafe = unsafe;
/* 2096 */           this.defineClass = defineClass;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isAvailable() {
/* 2103 */           return true;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public ClassInjector.UsingUnsafe.Dispatcher initialize() {
/* 2110 */           Object securityManager = ClassInjector.UsingUnsafe.SYSTEM.getSecurityManager();
/* 2111 */           if (securityManager != null) {
/*      */             try {
/* 2113 */               ClassInjector.UsingUnsafe.CHECK_PERMISSION.invoke(securityManager, new Object[] { ClassInjector.AbstractBase.SUPPRESS_ACCESS_CHECKS });
/* 2114 */             } catch (InvocationTargetException exception) {
/* 2115 */               return new ClassInjector.UsingUnsafe.Dispatcher.Unavailable(exception.getTargetException().getMessage());
/* 2116 */             } catch (Exception exception) {
/* 2117 */               return new ClassInjector.UsingUnsafe.Dispatcher.Unavailable(exception.getMessage());
/*      */             } 
/*      */           }
/* 2120 */           return this;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Class<?> defineClass(@MaybeNull ClassLoader classLoader, String name, byte[] binaryRepresentation, @MaybeNull ProtectionDomain protectionDomain) {
/*      */           try {
/* 2128 */             return (Class)this.defineClass.invoke(this.unsafe, new Object[] { name, binaryRepresentation, 
/*      */ 
/*      */                   
/* 2131 */                   Integer.valueOf(0), 
/* 2132 */                   Integer.valueOf(binaryRepresentation.length), classLoader, protectionDomain });
/*      */           
/*      */           }
/* 2135 */           catch (IllegalAccessException exception) {
/* 2136 */             throw new IllegalStateException(exception);
/* 2137 */           } catch (InvocationTargetException exception) {
/* 2138 */             throw new IllegalStateException(exception.getTargetException());
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.unsafe.equals(((Enabled)param3Object).unsafe) ? false : (!!this.defineClass.equals(((Enabled)param3Object).defineClass)))));
/*      */         }
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return (getClass().hashCode() * 31 + this.unsafe.hashCode()) * 31 + this.defineClass.hashCode();
/*      */         }
/*      */       }
/*      */       
/*      */       @Enhance
/*      */       public static class Unavailable
/*      */         implements Dispatcher, Initializable
/*      */       {
/*      */         private final String message;
/*      */         
/*      */         protected Unavailable(String message) {
/* 2160 */           this.message = message;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isAvailable() {
/* 2167 */           return false;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public ClassInjector.UsingUnsafe.Dispatcher initialize() {
/* 2174 */           throw new UnsupportedOperationException("Could not access Unsafe class: " + this.message);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Class<?> defineClass(@MaybeNull ClassLoader classLoader, String name, byte[] binaryRepresentation, @MaybeNull ProtectionDomain protectionDomain) {
/* 2181 */           throw new UnsupportedOperationException("Could not access Unsafe class: " + this.message);
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.message.equals(((Unavailable)param3Object).message))));
/*      */         }
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return getClass().hashCode() * 31 + this.message.hashCode();
/*      */         }
/*      */       } }
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class Factory
/*      */     {
/*      */       private final ClassInjector.UsingUnsafe.Dispatcher.Initializable dispatcher;
/*      */       
/*      */       public Factory() {
/* 2203 */         this(AccessResolver.Default.INSTANCE);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should not be rethrown but trigger a fallback.")
/*      */       public Factory(AccessResolver accessResolver) {
/*      */         ClassInjector.UsingUnsafe.Dispatcher.Initializable dispatcher;
/* 2214 */         if (ClassInjector.UsingUnsafe.DISPATCHER.isAvailable()) {
/* 2215 */           dispatcher = ClassInjector.UsingUnsafe.DISPATCHER;
/*      */         } else {
/*      */           try {
/* 2218 */             Class<?> unsafeType = Class.forName("jdk.internal.misc.Unsafe");
/* 2219 */             Field theUnsafe = unsafeType.getDeclaredField("theUnsafe");
/* 2220 */             accessResolver.apply(theUnsafe);
/* 2221 */             Object unsafe = theUnsafe.get(null);
/* 2222 */             Method defineClass = unsafeType.getMethod("defineClass", new Class[] { String.class, byte[].class, int.class, int.class, ClassLoader.class, ProtectionDomain.class });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2229 */             accessResolver.apply(defineClass);
/* 2230 */             dispatcher = new ClassInjector.UsingUnsafe.Dispatcher.Enabled(unsafe, defineClass);
/* 2231 */           } catch (Exception exception) {
/* 2232 */             dispatcher = new ClassInjector.UsingUnsafe.Dispatcher.Unavailable(exception.getMessage());
/*      */           } 
/*      */         } 
/* 2235 */         this.dispatcher = dispatcher;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected Factory(ClassInjector.UsingUnsafe.Dispatcher.Initializable dispatcher) {
/* 2244 */         this.dispatcher = dispatcher;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static Factory resolve(Instrumentation instrumentation) {
/* 2256 */         return resolve(instrumentation, false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION", "NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Exception intends to trigger disabled injection strategy. Modules are assumed if module system is supported.")
/*      */       public static Factory resolve(Instrumentation instrumentation, boolean local) {
/* 2273 */         if (ClassInjector.UsingUnsafe.isAvailable() || !JavaModule.isSupported()) {
/* 2274 */           return new Factory();
/*      */         }
/*      */         try {
/* 2277 */           Class<?> type = Class.forName("jdk.internal.misc.Unsafe");
/* 2278 */           PackageDescription.ForLoadedPackage forLoadedPackage = new PackageDescription.ForLoadedPackage(type.getPackage());
/* 2279 */           JavaModule source = JavaModule.ofType(type), target = JavaModule.ofType(ClassInjector.UsingUnsafe.class);
/* 2280 */           if (source.isOpened((PackageDescription)forLoadedPackage, target))
/* 2281 */             return new Factory(); 
/* 2282 */           if (local) {
/* 2283 */             JavaModule javaModule = JavaModule.ofType(AccessResolver.Default.class);
/* 2284 */             ClassInjector.UsingInstrumentation.redefineModule(instrumentation, source, 
/*      */                 
/* 2286 */                 Collections.singleton(javaModule), 
/* 2287 */                 Collections.emptyMap(), 
/* 2288 */                 Collections.singletonMap(forLoadedPackage.getName(), Collections.singleton(javaModule)), 
/* 2289 */                 Collections.emptySet(), 
/* 2290 */                 Collections.emptyMap());
/* 2291 */             return new Factory();
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2301 */           Class<? extends AccessResolver> resolver = (new ByteBuddy()).subclass(AccessResolver.class).method((ElementMatcher)ElementMatchers.named("apply")).intercept((Implementation)MethodCall.invoke(AccessibleObject.class.getMethod("setAccessible", new Class[] { boolean.class })).onArgument(0).with(new Object[] { Boolean.valueOf(true) })).make().load(AccessResolver.class.getClassLoader(), ClassLoadingStrategy.Default.WRAPPER.with(AccessResolver.class.getProtectionDomain())).getLoaded();
/* 2302 */           JavaModule module = JavaModule.ofType(resolver);
/* 2303 */           ClassInjector.UsingInstrumentation.redefineModule(instrumentation, source, 
/*      */               
/* 2305 */               Collections.singleton(module), 
/* 2306 */               Collections.emptyMap(), 
/* 2307 */               Collections.singletonMap(forLoadedPackage.getName(), Collections.singleton(module)), 
/* 2308 */               Collections.emptySet(), 
/* 2309 */               Collections.emptyMap());
/* 2310 */           return new Factory(resolver.getConstructor(new Class[0]).newInstance(new Object[0]));
/*      */         }
/* 2312 */         catch (Exception exception) {
/* 2313 */           return new Factory(new ClassInjector.UsingUnsafe.Dispatcher.Unavailable(exception.getMessage()));
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isAvailable() {
/* 2324 */         return this.dispatcher.isAvailable();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ClassInjector make(@MaybeNull ClassLoader classLoader) {
/* 2334 */         return make(classLoader, ClassLoadingStrategy.NO_PROTECTION_DOMAIN);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ClassInjector make(@MaybeNull ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain) {
/* 2345 */         return new ClassInjector.UsingUnsafe(classLoader, protectionDomain, this.dispatcher);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.dispatcher.equals(((Factory)param2Object).dispatcher))));
/*      */       }
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return getClass().hashCode() * 31 + this.dispatcher.hashCode();
/*      */       }
/*      */ 
/*      */       
/*      */       public static interface AccessResolver
/*      */       {
/*      */         void apply(AccessibleObject param3AccessibleObject);
/*      */ 
/*      */         
/*      */         public enum Default
/*      */           implements AccessResolver
/*      */         {
/* 2368 */           INSTANCE;
/*      */ 
/*      */ 
/*      */           
/*      */           public void apply(AccessibleObject accessibleObject)
/*      */           {
/* 2374 */             accessibleObject.setAccessible(true); } } } public enum Default implements AccessResolver { INSTANCE; public void apply(AccessibleObject accessibleObject) { accessibleObject.setAccessible(true); }
/*      */          }
/*      */     
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Proxied("java.lang.System")
/*      */     protected static interface System
/*      */     {
/*      */       @MaybeNull
/*      */       @IsStatic
/*      */       @Defaults
/*      */       @Proxied("getSecurityManager")
/*      */       Object getSecurityManager();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static class UsingInstrumentation
/*      */     extends AbstractBase
/*      */   {
/*      */     private static final String JAR = "jar";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final String CLASS_FILE_EXTENSION = ".class";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2418 */     private static final Dispatcher DISPATCHER = doPrivileged(JavaDispatcher.of(Dispatcher.class)); private final Instrumentation instrumentation; private final Target target; private final File folder; private final RandomString randomString; private static final boolean ACCESS_CONTROLLER; static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected UsingInstrumentation(File folder, Target target, Instrumentation instrumentation, RandomString randomString) {
/* 2452 */       this.folder = folder;
/* 2453 */       this.target = target;
/* 2454 */       this.instrumentation = instrumentation;
/* 2455 */       this.randomString = randomString;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 2467 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static void redefineModule(Instrumentation instrumentation, JavaModule target, Set<JavaModule> reads, Map<String, Set<JavaModule>> exports, Map<String, Set<JavaModule>> opens, Set<Class<?>> uses, Map<Class<?>, List<Class<?>>> provides) {
/* 2488 */       if (!DISPATCHER.isModifiableModule(instrumentation, target.unwrap())) {
/* 2489 */         throw new IllegalArgumentException("Cannot modify module: " + target);
/*      */       }
/* 2491 */       Set<Object> unwrappedReads = new HashSet();
/* 2492 */       for (JavaModule read : reads) {
/* 2493 */         unwrappedReads.add(read.unwrap());
/*      */       }
/* 2495 */       Map<String, Set<?>> unwrappedExports = new HashMap<String, Set<?>>();
/* 2496 */       for (Map.Entry<String, Set<JavaModule>> entry : exports.entrySet()) {
/* 2497 */         Set<Object> modules = new HashSet();
/* 2498 */         for (JavaModule module : entry.getValue()) {
/* 2499 */           modules.add(module.unwrap());
/*      */         }
/* 2501 */         unwrappedExports.put(entry.getKey(), modules);
/*      */       } 
/* 2503 */       Map<String, Set<?>> unwrappedOpens = new HashMap<String, Set<?>>();
/* 2504 */       for (Map.Entry<String, Set<JavaModule>> entry : opens.entrySet()) {
/* 2505 */         Set<Object> modules = new HashSet();
/* 2506 */         for (JavaModule module : entry.getValue()) {
/* 2507 */           modules.add(module.unwrap());
/*      */         }
/* 2509 */         unwrappedOpens.put(entry.getKey(), modules);
/*      */       } 
/* 2511 */       DISPATCHER.redefineModule(instrumentation, target.unwrap(), unwrappedReads, unwrappedExports, unwrappedOpens, uses, provides);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassInjector of(File folder, Target target, Instrumentation instrumentation) {
/* 2523 */       return new UsingInstrumentation(folder, target, instrumentation, new RandomString());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isAlive() {
/* 2530 */       return isAvailable();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"OS_OPEN_STREAM_EXCEPTION_PATH"}, justification = "Outer stream holds file handle and is closed")
/*      */     public Map<String, Class<?>> injectRaw(Set<String> names, ClassFileLocator classFileLocator) {
/* 2538 */       File file = new File(this.folder, "jar" + this.randomString.nextString() + "." + "jar");
/*      */       try {
/* 2540 */         if (!file.createNewFile()) {
/* 2541 */           throw new IllegalStateException("Cannot create file " + file);
/*      */         }
/*      */         try {
/* 2544 */           OutputStream outputStream = new FileOutputStream(file);
/*      */           try {
/* 2546 */             JarOutputStream jarOutputStream = new JarOutputStream(outputStream);
/* 2547 */             for (String name : names) {
/* 2548 */               jarOutputStream.putNextEntry(new JarEntry(name.replace('.', '/') + ".class"));
/* 2549 */               jarOutputStream.write(classFileLocator.locate(name).resolve());
/*      */             } 
/* 2551 */             jarOutputStream.close();
/*      */           } finally {
/* 2553 */             outputStream.close();
/*      */           } 
/* 2555 */           JarFile jarFile = new JarFile(file, false, 1);
/*      */           try {
/* 2557 */             this.target.inject(this.instrumentation, jarFile);
/*      */           } finally {
/* 2559 */             jarFile.close();
/*      */           } 
/* 2561 */           Map<String, Class<?>> result = new HashMap<String, Class<?>>();
/* 2562 */           for (String name : names) {
/* 2563 */             result.put(name, Class.forName(name, false, this.target.getClassLoader()));
/*      */           }
/* 2565 */           return result;
/*      */         } finally {
/* 2567 */           if (!file.delete()) {
/* 2568 */             file.deleteOnExit();
/*      */           }
/*      */         } 
/* 2571 */       } catch (IOException exception) {
/* 2572 */         throw new IllegalStateException("Cannot write jar file to disk", exception);
/* 2573 */       } catch (ClassNotFoundException exception) {
/* 2574 */         throw new IllegalStateException("Cannot load injected class", exception);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static boolean isAvailable() {
/* 2584 */       return ClassFileVersion.ofThisVm(ClassFileVersion.JAVA_V5).isAtLeast(ClassFileVersion.JAVA_V6);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.target.equals(((UsingInstrumentation)param1Object).target) ? false : (!this.instrumentation.equals(((UsingInstrumentation)param1Object).instrumentation) ? false : (!this.folder.equals(((UsingInstrumentation)param1Object).folder) ? false : (!!this.randomString.equals(((UsingInstrumentation)param1Object).randomString)))))));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return (((getClass().hashCode() * 31 + this.instrumentation.hashCode()) * 31 + this.target.hashCode()) * 31 + this.folder.hashCode()) * 31 + this.randomString.hashCode();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public enum Target
/*      */     {
/* 2646 */       BOOTSTRAP(null)
/*      */       {
/*      */         protected void inject(Instrumentation instrumentation, JarFile jarFile) {
/* 2649 */           ClassInjector.UsingInstrumentation.DISPATCHER.appendToBootstrapClassLoaderSearch(instrumentation, jarFile);
/*      */         }
/*      */       },
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2656 */       SYSTEM((String)ClassLoader.getSystemClassLoader())
/*      */       {
/*      */         protected void inject(Instrumentation instrumentation, JarFile jarFile) {
/* 2659 */           ClassInjector.UsingInstrumentation.DISPATCHER.appendToSystemClassLoaderSearch(instrumentation, jarFile);
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       private final ClassLoader classLoader;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       Target(ClassLoader classLoader) {
/* 2675 */         this.classLoader = classLoader;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       protected ClassLoader getClassLoader() {
/* 2685 */         return this.classLoader;
/*      */       }
/*      */       
/*      */       protected abstract void inject(Instrumentation param2Instrumentation, JarFile param2JarFile);
/*      */     }
/*      */     
/*      */     @Proxied("java.lang.instrument.Instrumentation")
/*      */     protected static interface Dispatcher {
/*      */       @Proxied("appendToBootstrapClassLoaderSearch")
/*      */       void appendToBootstrapClassLoaderSearch(Instrumentation param2Instrumentation, JarFile param2JarFile);
/*      */       
/*      */       @Proxied("appendToSystemClassLoaderSearch")
/*      */       void appendToSystemClassLoaderSearch(Instrumentation param2Instrumentation, JarFile param2JarFile);
/*      */       
/*      */       @Proxied("isModifiableModule")
/*      */       boolean isModifiableModule(Instrumentation param2Instrumentation, @Proxied("java.lang.Module") Object param2Object);
/*      */       
/*      */       @Proxied("redefineModule")
/*      */       void redefineModule(Instrumentation param2Instrumentation, @Proxied("java.lang.Module") Object param2Object, Set<?> param2Set, Map<String, Set<?>> param2Map1, Map<String, Set<?>> param2Map2, Set<Class<?>> param2Set1, Map<Class<?>, List<Class<?>>> param2Map);
/*      */     }
/*      */   }
/*      */   
/*      */   @Enhance
/*      */   public static class UsingJna extends AbstractBase {
/* 2709 */     private static final Dispatcher DISPATCHER = doPrivileged(Dispatcher.CreationAction.INSTANCE);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2714 */     private static final Object BOOTSTRAP_LOADER_LOCK = new Object(); @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) private final ClassLoader classLoader; @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) private final ProtectionDomain protectionDomain; private static final boolean ACCESS_CONTROLLER; static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UsingJna(@MaybeNull ClassLoader classLoader) {
/* 2736 */       this(classLoader, ClassLoadingStrategy.NO_PROTECTION_DOMAIN);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UsingJna(@MaybeNull ClassLoader classLoader, @MaybeNull ProtectionDomain protectionDomain) {
/* 2746 */       this.classLoader = classLoader;
/* 2747 */       this.protectionDomain = protectionDomain;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 2759 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static boolean isAvailable() {
/* 2768 */       return DISPATCHER.isAvailable();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassInjector ofSystemLoader() {
/* 2777 */       return new UsingJna(ClassLoader.getSystemClassLoader());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassInjector ofPlatformLoader() {
/* 2787 */       return new UsingJna(ClassLoader.getSystemClassLoader().getParent());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassInjector ofBootLoader() {
/* 2796 */       return new UsingJna(ClassLoadingStrategy.BOOTSTRAP_LOADER);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isAlive() {
/* 2803 */       return DISPATCHER.isAvailable();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Map<String, Class<?>> injectRaw(Set<String> names, ClassFileLocator classFileLocator) {
/* 2810 */       Map<String, Class<?>> result = new HashMap<String, Class<?>>();
/* 2811 */       synchronized ((this.classLoader == null) ? BOOTSTRAP_LOADER_LOCK : this.classLoader) {
/*      */ 
/*      */         
/* 2814 */         for (String name : names) {
/*      */           try {
/* 2816 */             result.put(name, Class.forName(name, false, this.classLoader));
/* 2817 */           } catch (ClassNotFoundException ignored) {
/*      */             try {
/* 2819 */               result.put(name, DISPATCHER.defineClass(this.classLoader, name, classFileLocator.locate(name).resolve(), this.protectionDomain));
/* 2820 */             } catch (IOException exception) {
/* 2821 */               throw new IllegalStateException("Failed to resolve binary representation of " + name, exception);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 2826 */       return result;
/*      */     } public boolean equals(@MaybeNull Object param1Object) { if (this == param1Object)
/*      */         return true; 
/*      */       if (param1Object == null)
/*      */         return false; 
/*      */       if (getClass() != param1Object.getClass())
/*      */         return false; 
/*      */       ClassLoader classLoader1 = ((UsingJna)param1Object).classLoader;
/*      */       ClassLoader classLoader2 = this.classLoader;
/*      */       if (classLoader1 != null) {
/*      */         if (classLoader2 != null) {
/*      */           if (!classLoader2.equals(classLoader1))
/*      */             return false; 
/*      */         } else {
/*      */           return false;
/*      */         } 
/*      */       } else if (classLoader2 != null) {
/*      */         return false;
/*      */       } 
/*      */       ProtectionDomain protectionDomain1 = ((UsingJna)param1Object).protectionDomain;
/*      */       ProtectionDomain protectionDomain2 = this.protectionDomain;
/*      */       if (protectionDomain1 != null) {
/*      */         if (protectionDomain2 != null) {
/*      */           if (!protectionDomain2.equals(protectionDomain1))
/*      */             return false; 
/*      */         } else {
/*      */           return false;
/*      */         } 
/*      */       } else if (protectionDomain2 != null) {
/*      */         return false;
/*      */       } 
/*      */       return true; } public int hashCode() {
/*      */       ClassLoader classLoader = this.classLoader;
/*      */       if (classLoader != null);
/*      */       ProtectionDomain protectionDomain = this.protectionDomain;
/*      */       if (protectionDomain != null);
/*      */       return (getClass().hashCode() * 31 + classLoader.hashCode()) * 31 + protectionDomain.hashCode();
/* 2863 */     } public enum CreationAction implements PrivilegedAction<Dispatcher> { INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ClassInjector.UsingJna.Dispatcher run()
/*      */       {
/* 2870 */         if (System.getProperty("java.vm.name", "").toUpperCase(Locale.US).contains("J9")) {
/* 2871 */           return new ClassInjector.UsingJna.Dispatcher.Unavailable("J9 does not support JNA-based class definition");
/*      */         }
/*      */         
/* 2874 */         try { Map<String, Object> options = new HashMap<String, Object>();
/* 2875 */           options.put("allow-objects", Boolean.TRUE);
/* 2876 */           if (Platform.isWindows() && !Platform.is64Bit()) {
/* 2877 */             options.put("function-mapper", ClassInjector.UsingJna.Dispatcher.Windows32BitFunctionMapper.INSTANCE);
/*      */           }
/* 2879 */           return new ClassInjector.UsingJna.Dispatcher.Enabled((ClassInjector.UsingJna.Dispatcher.Jvm)Native.loadLibrary("jvm", ClassInjector.UsingJna.Dispatcher.Jvm.class, options)); }
/* 2880 */         catch (Throwable throwable)
/* 2881 */         { return new ClassInjector.UsingJna.Dispatcher.Unavailable(throwable.getMessage()); }  } } protected static interface Dispatcher { boolean isAvailable(); Class<?> defineClass(@MaybeNull ClassLoader param2ClassLoader, String param2String, byte[] param2ArrayOfbyte, @MaybeNull ProtectionDomain param2ProtectionDomain); public enum CreationAction implements PrivilegedAction<Dispatcher> { INSTANCE; public ClassInjector.UsingJna.Dispatcher run() { if (System.getProperty("java.vm.name", "").toUpperCase(Locale.US).contains("J9")) return new ClassInjector.UsingJna.Dispatcher.Unavailable("J9 does not support JNA-based class definition");  try { Map<String, Object> options = new HashMap<String, Object>(); options.put("allow-objects", Boolean.TRUE); if (Platform.isWindows() && !Platform.is64Bit()) options.put("function-mapper", ClassInjector.UsingJna.Dispatcher.Windows32BitFunctionMapper.INSTANCE);  return new ClassInjector.UsingJna.Dispatcher.Enabled((ClassInjector.UsingJna.Dispatcher.Jvm)Native.loadLibrary("jvm", ClassInjector.UsingJna.Dispatcher.Jvm.class, options)); } catch (Throwable throwable) { return new ClassInjector.UsingJna.Dispatcher.Unavailable(throwable.getMessage()); }
/*      */            }
/*      */          }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public enum Windows32BitFunctionMapper
/*      */         implements FunctionMapper
/*      */       {
/* 2894 */         INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public String getFunctionName(NativeLibrary library, Method method) {
/* 2900 */           if (method.getName().equals("JVM_DefineClass")) {
/* 2901 */             return "_JVM_DefineClass@24";
/*      */           }
/* 2903 */           return method.getName();
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static class Enabled
/*      */         implements Dispatcher
/*      */       {
/*      */         private final ClassInjector.UsingJna.Dispatcher.Jvm jvm;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected Enabled(ClassInjector.UsingJna.Dispatcher.Jvm jvm) {
/* 2924 */           this.jvm = jvm;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isAvailable() {
/* 2931 */           return true;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Class<?> defineClass(@MaybeNull ClassLoader classLoader, String name, byte[] binaryRepresentation, @MaybeNull ProtectionDomain protectionDomain) {
/* 2938 */           return this.jvm.JVM_DefineClass(JNIEnv.CURRENT, name
/* 2939 */               .replace('.', '/'), classLoader, binaryRepresentation, binaryRepresentation.length, protectionDomain);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.jvm.equals(((Enabled)param3Object).jvm))));
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return getClass().hashCode() * 31 + this.jvm.hashCode();
/*      */         }
/*      */       }
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static class Unavailable
/*      */         implements Dispatcher
/*      */       {
/*      */         private final String error;
/*      */ 
/*      */         
/*      */         protected Unavailable(String error) {
/* 2964 */           this.error = error;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean isAvailable() {
/* 2971 */           return false;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Class<?> defineClass(@MaybeNull ClassLoader classLoader, String name, byte[] binaryRepresentation, @MaybeNull ProtectionDomain protectionDomain) {
/* 2978 */           throw new UnsupportedOperationException("JNA is not available and JNA-based injection cannot be used: " + this.error);
/*      */         }
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.error.equals(((Unavailable)param3Object).error))));
/*      */         }
/*      */         
/*      */         public int hashCode() {
/*      */           return getClass().hashCode() * 31 + this.error.hashCode();
/*      */         }
/*      */       }
/*      */       
/*      */       public static interface Jvm extends Library {
/*      */         Class<?> JVM_DefineClass(JNIEnv param3JNIEnv, String param3String, @MaybeNull ClassLoader param3ClassLoader, byte[] param3ArrayOfbyte, int param3Int, @MaybeNull ProtectionDomain param3ProtectionDomain) throws LastErrorException;
/*      */       } }
/*      */   
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\loading\ClassInjector.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */