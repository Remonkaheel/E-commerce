/*     */ package net.bytebuddy.dynamic;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.dynamic.loading.ClassLoadingStrategy;
/*     */ import net.bytebuddy.dynamic.scaffold.TypeInitializer;
/*     */ import net.bytebuddy.implementation.LoadedTypeInitializer;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface TypeResolutionStrategy
/*     */ {
/*     */   Resolved resolve();
/*     */   
/*     */   public static interface Resolved
/*     */   {
/*     */     TypeInitializer injectedInto(TypeInitializer param1TypeInitializer);
/*     */     
/*     */     <S extends ClassLoader> Map<TypeDescription, Class<?>> initialize(DynamicType param1DynamicType, @MaybeNull S param1S, ClassLoadingStrategy<? super S> param1ClassLoadingStrategy);
/*     */   }
/*     */   
/*     */   public enum Passive
/*     */     implements TypeResolutionStrategy, Resolved
/*     */   {
/*  79 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeResolutionStrategy.Resolved resolve() {
/*  85 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeInitializer injectedInto(TypeInitializer typeInitializer) {
/*  92 */       return typeInitializer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <S extends ClassLoader> Map<TypeDescription, Class<?>> initialize(DynamicType dynamicType, @MaybeNull S classLoader, ClassLoadingStrategy<? super S> classLoadingStrategy) {
/* 101 */       Map<TypeDescription, Class<?>> types = classLoadingStrategy.load((ClassLoader)classLoader, dynamicType.getAllTypes());
/* 102 */       for (Map.Entry<TypeDescription, LoadedTypeInitializer> entry : dynamicType.getLoadedTypeInitializers().entrySet()) {
/* 103 */         ((LoadedTypeInitializer)entry.getValue()).onLoad(types.get(entry.getKey()));
/*     */       }
/* 105 */       return new HashMap<TypeDescription, Class<?>>(types);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Active
/*     */     implements TypeResolutionStrategy
/*     */   {
/*     */     private final NexusAccessor nexusAccessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Active() {
/* 125 */       this(new NexusAccessor());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Active(NexusAccessor nexusAccessor) {
/* 134 */       this.nexusAccessor = nexusAccessor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @SuppressFBWarnings(value = {"DMI_RANDOM_USED_ONLY_ONCE"}, justification = "Avoids thread-contention.")
/*     */     public TypeResolutionStrategy.Resolved resolve() {
/* 142 */       return new Resolved(this.nexusAccessor, (new Random()).nextInt());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.nexusAccessor.equals(((Active)param1Object).nexusAccessor))));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.nexusAccessor.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     protected static class Resolved
/*     */       implements TypeResolutionStrategy.Resolved
/*     */     {
/*     */       private final NexusAccessor nexusAccessor;
/*     */       
/*     */       private final int identification;
/*     */ 
/*     */       
/*     */       protected Resolved(NexusAccessor nexusAccessor, int identification) {
/* 168 */         this.nexusAccessor = nexusAccessor;
/* 169 */         this.identification = identification;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public TypeInitializer injectedInto(TypeInitializer typeInitializer) {
/* 176 */         return typeInitializer.expandWith(new NexusAccessor.InitializationAppender(this.identification));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public <S extends ClassLoader> Map<TypeDescription, Class<?>> initialize(DynamicType dynamicType, @MaybeNull S classLoader, ClassLoadingStrategy<? super S> classLoadingStrategy) {
/* 185 */         Map<TypeDescription, LoadedTypeInitializer> loadedTypeInitializers = new HashMap<TypeDescription, LoadedTypeInitializer>(dynamicType.getLoadedTypeInitializers());
/* 186 */         TypeDescription instrumentedType = dynamicType.getTypeDescription();
/* 187 */         Map<TypeDescription, Class<?>> types = classLoadingStrategy.load((ClassLoader)classLoader, dynamicType.getAllTypes());
/* 188 */         this.nexusAccessor.register(instrumentedType.getName(), ((Class)types
/* 189 */             .get(instrumentedType)).getClassLoader(), this.identification, loadedTypeInitializers
/*     */             
/* 191 */             .remove(instrumentedType));
/* 192 */         for (Map.Entry<TypeDescription, LoadedTypeInitializer> entry : loadedTypeInitializers.entrySet()) {
/* 193 */           ((LoadedTypeInitializer)entry.getValue()).onLoad(types.get(entry.getKey()));
/*     */         }
/* 195 */         return types;
/*     */       }
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.identification != ((Resolved)param2Object).identification) ? false : (!!this.nexusAccessor.equals(((Resolved)param2Object).nexusAccessor)))));
/*     */       }
/*     */       
/*     */       public int hashCode() {
/*     */         return (getClass().hashCode() * 31 + this.nexusAccessor.hashCode()) * 31 + this.identification;
/*     */       } }
/*     */   }
/*     */   
/*     */   public enum Lazy implements TypeResolutionStrategy, Resolved {
/* 208 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeResolutionStrategy.Resolved resolve() {
/* 214 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeInitializer injectedInto(TypeInitializer typeInitializer) {
/* 221 */       return typeInitializer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <S extends ClassLoader> Map<TypeDescription, Class<?>> initialize(DynamicType dynamicType, @MaybeNull S classLoader, ClassLoadingStrategy<? super S> classLoadingStrategy) {
/* 230 */       return classLoadingStrategy.load((ClassLoader)classLoader, dynamicType.getAllTypes());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Disabled
/*     */     implements TypeResolutionStrategy, Resolved
/*     */   {
/* 242 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeResolutionStrategy.Resolved resolve() {
/* 248 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeInitializer injectedInto(TypeInitializer typeInitializer) {
/* 255 */       return typeInitializer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public <S extends ClassLoader> Map<TypeDescription, Class<?>> initialize(DynamicType dynamicType, @MaybeNull S classLoader, ClassLoadingStrategy<? super S> classLoadingStrategy) {
/* 264 */       throw new IllegalStateException("Cannot initialize a dynamic type for a disabled type resolution strategy");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\TypeResolutionStrategy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */