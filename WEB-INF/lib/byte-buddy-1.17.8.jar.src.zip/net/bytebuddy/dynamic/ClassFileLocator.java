/*      */ package net.bytebuddy.dynamic;
/*      */ 
/*      */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*      */ import java.io.Closeable;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.instrument.ClassFileTransformer;
/*      */ import java.lang.instrument.Instrumentation;
/*      */ import java.lang.instrument.UnmodifiableClassException;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.URL;
/*      */ import java.net.URLClassLoader;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.ProtectionDomain;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.SortedSet;
/*      */ import java.util.TreeSet;
/*      */ import java.util.Vector;
/*      */ import java.util.jar.JarEntry;
/*      */ import java.util.jar.JarFile;
/*      */ import java.util.jar.Manifest;
/*      */ import java.util.regex.Pattern;
/*      */ import java.util.zip.ZipEntry;
/*      */ import java.util.zip.ZipFile;
/*      */ import net.bytebuddy.ClassFileVersion;
/*      */ import net.bytebuddy.agent.builder.AgentBuilder;
/*      */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling;
/*      */ import net.bytebuddy.description.type.TypeDescription;
/*      */ import net.bytebuddy.dynamic.loading.ClassLoadingStrategy;
/*      */ import net.bytebuddy.matcher.ElementMatcher;
/*      */ import net.bytebuddy.matcher.ElementMatchers;
/*      */ import net.bytebuddy.utility.JavaModule;
/*      */ import net.bytebuddy.utility.JavaType;
/*      */ import net.bytebuddy.utility.StreamDrainer;
/*      */ import net.bytebuddy.utility.dispatcher.JavaDispatcher;
/*      */ import net.bytebuddy.utility.dispatcher.JavaDispatcher.Proxied;
/*      */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface ClassFileLocator
/*      */   extends Closeable
/*      */ {
/*      */   public static final String CLASS_FILE_EXTENSION = ".class";
/*      */   public static final String META_INF_VERSIONS = "META-INF/versions/";
/*      */   
/*      */   Resolution locate(String paramString) throws IOException;
/*      */   
/*      */   public static interface Resolution
/*      */   {
/*      */     boolean isResolved();
/*      */     
/*      */     byte[] resolve();
/*      */     
/*      */     @Enhance
/*      */     public static class Illegal
/*      */       implements Resolution
/*      */     {
/*      */       private final String typeName;
/*      */       
/*      */       public Illegal(String typeName) {
/*  116 */         this.typeName = typeName;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isResolved() {
/*  123 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public byte[] resolve() {
/*  130 */         throw new IllegalStateException("Could not locate class file for " + this.typeName);
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.typeName.equals(((Illegal)param2Object).typeName))));
/*      */       }
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return getClass().hashCode() * 31 + this.typeName.hashCode();
/*      */       }
/*      */     }
/*      */     
/*      */     @Enhance
/*      */     public static class Explicit
/*      */       implements Resolution
/*      */     {
/*      */       private final byte[] binaryRepresentation;
/*      */       
/*      */       @SuppressFBWarnings(value = {"EI_EXPOSE_REP2"}, justification = "The array is not modified by class contract.")
/*      */       public Explicit(byte[] binaryRepresentation) {
/*  152 */         this.binaryRepresentation = binaryRepresentation;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isResolved() {
/*  159 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @SuppressFBWarnings(value = {"EI_EXPOSE_REP"}, justification = "The array is not modified by class contract.")
/*      */       public byte[] resolve() {
/*  167 */         return this.binaryRepresentation;
/*      */       }
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!Arrays.equals(this.binaryRepresentation, ((Explicit)param2Object).binaryRepresentation))));
/*      */       }
/*      */       
/*      */       public int hashCode() {
/*      */         return getClass().hashCode() * 31 + Arrays.hashCode(this.binaryRepresentation);
/*      */       } }
/*      */   }
/*      */   
/*      */   public enum NoOp implements ClassFileLocator {
/*  180 */     INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ClassFileLocator.Resolution locate(String name) {
/*  186 */       return new ClassFileLocator.Resolution.Illegal(name);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static abstract class MultiReleaseAware
/*      */     implements ClassFileLocator
/*      */   {
/*      */     private static final String MULTI_RELEASE_ATTRIBUTE = "Multi-Release";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  211 */     protected static final int[] NO_MULTI_RELEASE = new int[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int[] version;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected MultiReleaseAware(int[] version) {
/*  226 */       this.version = version;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ClassFileLocator.Resolution locate(String name) throws IOException {
/*  233 */       String path = name.replace('.', '/') + ".class";
/*  234 */       for (int index = 0; index < this.version.length + 1; index++) {
/*  235 */         byte[] binaryRepresentation = doLocate((index == this.version.length) ? path : ("META-INF/versions/" + this.version[index] + "/" + path));
/*  236 */         if (binaryRepresentation != null) {
/*  237 */           return new ClassFileLocator.Resolution.Explicit(binaryRepresentation);
/*      */         }
/*      */       } 
/*  240 */       return new ClassFileLocator.Resolution.Illegal(name);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     protected abstract byte[] doLocate(String param1String) throws IOException;
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!Arrays.equals(this.version, ((MultiReleaseAware)param1Object).version))));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return getClass().hashCode() * 31 + Arrays.hashCode(this.version);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static class Simple
/*      */     implements ClassFileLocator
/*      */   {
/*      */     private final Map<String, byte[]> classFiles;
/*      */ 
/*      */     
/*      */     public Simple(Map<String, byte[]> classFiles) {
/*  271 */       this.classFiles = classFiles;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator of(String typeName, byte[] binaryRepresentation) {
/*  282 */       return new Simple((Map)Collections.singletonMap(typeName, binaryRepresentation));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator of(DynamicType dynamicType) {
/*  292 */       return of(dynamicType.getAllTypes());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator of(Map<TypeDescription, byte[]> binaryRepresentations) {
/*  302 */       Map<String, byte[]> classFiles = (Map)new HashMap<String, byte>();
/*  303 */       for (Map.Entry<TypeDescription, byte[]> entry : binaryRepresentations.entrySet()) {
/*  304 */         classFiles.put(((TypeDescription)entry.getKey()).getName(), entry.getValue());
/*      */       }
/*  306 */       return new Simple(classFiles);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator ofResources(Map<String, byte[]> binaryRepresentations) {
/*  316 */       Map<String, byte[]> classFiles = (Map)new HashMap<String, byte>();
/*  317 */       for (Map.Entry<String, byte[]> entry : binaryRepresentations.entrySet()) {
/*  318 */         if (((String)entry.getKey()).endsWith(".class")) {
/*  319 */           classFiles.put(((String)entry.getKey()).substring(0, ((String)entry.getKey()).length() - ".class".length()).replace('/', '.'), entry.getValue());
/*      */         }
/*      */       } 
/*  322 */       return new Simple(classFiles);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ClassFileLocator.Resolution locate(String name) {
/*  329 */       byte[] binaryRepresentation = this.classFiles.get(name);
/*  330 */       return (binaryRepresentation == null) ? new ClassFileLocator.Resolution.Illegal(name) : new ClassFileLocator.Resolution.Explicit(binaryRepresentation);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.classFiles.equals(((Simple)param1Object).classFiles))));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return getClass().hashCode() * 31 + this.classFiles.hashCode();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static class ForClassLoader
/*      */     implements ClassFileLocator
/*      */   {
/*  356 */     private static final ClassLoader BOOT_LOADER_PROXY = doPrivileged(BootLoaderProxyCreationAction.INSTANCE); private final ClassLoader classLoader; private static final boolean ACCESS_CONTROLLER; static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected ForClassLoader(ClassLoader classLoader) {
/*  369 */       this.classLoader = classLoader;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/*  381 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator ofSystemLoader() {
/*  390 */       return new ForClassLoader(ClassLoader.getSystemClassLoader());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator ofPlatformLoader() {
/*  400 */       return of(ClassLoader.getSystemClassLoader().getParent());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator ofBootLoader() {
/*  409 */       return new ForClassLoader(BOOT_LOADER_PROXY);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator of(@MaybeNull ClassLoader classLoader) {
/*  419 */       return new ForClassLoader((classLoader == null) ? BOOT_LOADER_PROXY : classLoader);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static byte[] read(Class<?> type) {
/*      */       try {
/*  431 */         ClassLoader classLoader = type.getClassLoader();
/*  432 */         return locate((classLoader == null) ? BOOT_LOADER_PROXY : classLoader, TypeDescription.ForLoadedType.getName(type)).resolve();
/*  433 */       } catch (IOException exception) {
/*  434 */         throw new IllegalStateException("Cannot read class file for " + type, exception);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Map<Class<?>, byte[]> read(Class<?>... type) {
/*  446 */       return read(Arrays.asList(type));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Map<Class<?>, byte[]> read(Collection<? extends Class<?>> types) {
/*  457 */       Map<Class<?>, byte[]> result = (Map)new HashMap<Class<?>, byte>();
/*  458 */       for (Class<?> type : types) {
/*  459 */         result.put(type, read(type));
/*      */       }
/*  461 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Map<String, byte[]> readToNames(Class<?>... type) {
/*  472 */       return readToNames(Arrays.asList(type));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static Map<String, byte[]> readToNames(Collection<? extends Class<?>> types) {
/*  483 */       Map<String, byte[]> result = (Map)new HashMap<String, byte>();
/*  484 */       for (Class<?> type : types) {
/*  485 */         result.put(type.getName(), read(type));
/*      */       }
/*  487 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ClassFileLocator.Resolution locate(String name) throws IOException {
/*  494 */       return locate(this.classLoader, name);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected static ClassFileLocator.Resolution locate(ClassLoader classLoader, String name) throws IOException {
/*  513 */       InputStream inputStream = classLoader.getResourceAsStream(name.replace('.', '/') + ".class");
/*  514 */       if (inputStream != null) {
/*      */         try {
/*  516 */           return new ClassFileLocator.Resolution.Explicit(StreamDrainer.DEFAULT.drain(inputStream));
/*      */         } finally {
/*  518 */           inputStream.close();
/*      */         } 
/*      */       }
/*  521 */       return new ClassFileLocator.Resolution.Illegal(name);
/*      */     }
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.classLoader.equals(((ForClassLoader)param1Object).classLoader))));
/*      */     }
/*      */     
/*      */     public int hashCode() {
/*      */       return getClass().hashCode() * 31 + this.classLoader.hashCode();
/*      */     }
/*      */     
/*      */     protected enum BootLoaderProxyCreationAction implements PrivilegedAction<ClassLoader> {
/*  533 */       INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ClassLoader run() {
/*  539 */         return new URLClassLoader(new URL[0], ClassLoadingStrategy.BOOTSTRAP_LOADER);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class WeaklyReferenced
/*      */       extends WeakReference<ClassLoader>
/*      */       implements ClassFileLocator
/*      */     {
/*      */       private final int hashCode;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected WeaklyReferenced(ClassLoader classLoader) {
/*  566 */         super(classLoader);
/*  567 */         this.hashCode = System.identityHashCode(classLoader);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static ClassFileLocator of(@MaybeNull ClassLoader classLoader) {
/*  581 */         return (classLoader == null || classLoader == ClassLoader.getSystemClassLoader() || classLoader == ClassLoader.getSystemClassLoader().getParent()) ? ClassFileLocator.ForClassLoader.of(classLoader) : new WeaklyReferenced(classLoader);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ClassFileLocator.Resolution locate(String name) throws IOException {
/*  588 */         ClassLoader classLoader = get();
/*  589 */         return (classLoader == null) ? new ClassFileLocator.Resolution.Illegal(name) : ClassFileLocator.ForClassLoader.locate(classLoader, name);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public void close() {}
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*  601 */         return this.hashCode;
/*      */       }
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object other) {
/*  606 */         if (this == other)
/*  607 */           return true; 
/*  608 */         if (other == null || getClass() != other.getClass()) {
/*  609 */           return false;
/*      */         }
/*  611 */         WeaklyReferenced weaklyReferenced = (WeaklyReferenced)other;
/*  612 */         ClassLoader classLoader = weaklyReferenced.get();
/*  613 */         return (classLoader != null && get() == classLoader);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static class ForModule
/*      */     implements ClassFileLocator
/*      */   {
/*  633 */     private static final Object[] NO_ARGUMENT = new Object[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final JavaModule module;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected ForModule(JavaModule module) {
/*  646 */       this.module = module;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @SuppressFBWarnings(value = {"REC_CATCH_EXCEPTION"}, justification = "Exception should always be wrapped for clarity")
/*      */     public static ClassFileLocator ofBootLayer() {
/*      */       try {
/*  658 */         Map<String, ClassFileLocator> bootModules = new HashMap<String, ClassFileLocator>();
/*  659 */         Class<?> layerType = Class.forName("java.lang.ModuleLayer");
/*  660 */         Method getPackages = JavaType.MODULE.load().getMethod("getPackages", new Class[0]);
/*  661 */         for (Object rawModule : layerType.getMethod("modules", new Class[0]).invoke(layerType.getMethod("boot", new Class[0]).invoke(null, new Object[0]), new Object[0])) {
/*  662 */           ClassFileLocator classFileLocator = of(JavaModule.of(rawModule));
/*  663 */           for (Object packageName : getPackages.invoke(rawModule, NO_ARGUMENT)) {
/*  664 */             bootModules.put((String)packageName, classFileLocator);
/*      */           }
/*      */         } 
/*  667 */         return new ClassFileLocator.PackageDiscriminating(bootModules);
/*  668 */       } catch (Exception exception) {
/*  669 */         throw new IllegalStateException("Cannot process boot layer", exception);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator of(JavaModule module) {
/*  681 */       return module.isNamed() ? new ForModule(module) : ClassFileLocator.ForClassLoader.of(module.getClassLoader());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ClassFileLocator.Resolution locate(String name) throws IOException {
/*  688 */       return locate(this.module, name);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected static ClassFileLocator.Resolution locate(JavaModule module, String typeName) throws IOException {
/*  700 */       InputStream inputStream = module.getResourceAsStream(typeName.replace('.', '/') + ".class");
/*  701 */       if (inputStream != null) {
/*      */         try {
/*  703 */           return new ClassFileLocator.Resolution.Explicit(StreamDrainer.DEFAULT.drain(inputStream));
/*      */         } finally {
/*  705 */           inputStream.close();
/*      */         } 
/*      */       }
/*  708 */       return new ClassFileLocator.Resolution.Illegal(typeName);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.module.equals(((ForModule)param1Object).module))));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return getClass().hashCode() * 31 + this.module.hashCode();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class WeaklyReferenced
/*      */       extends WeakReference<Object>
/*      */       implements ClassFileLocator
/*      */     {
/*      */       private final int hashCode;
/*      */ 
/*      */ 
/*      */       
/*      */       protected WeaklyReferenced(Object module) {
/*  742 */         super(module);
/*  743 */         this.hashCode = System.identityHashCode(module);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static ClassFileLocator of(JavaModule module) {
/*  754 */         if (module.isNamed()) {
/*  755 */           return (module.getClassLoader() == null || module.getClassLoader() == ClassLoader.getSystemClassLoader() || module.getClassLoader() == ClassLoader.getSystemClassLoader().getParent()) ? new ClassFileLocator.ForModule(module) : new WeaklyReferenced(module.unwrap());
/*      */         }
/*  757 */         return ClassFileLocator.ForClassLoader.WeaklyReferenced.of(module.getClassLoader());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ClassFileLocator.Resolution locate(String name) throws IOException {
/*  765 */         Object module = get();
/*  766 */         return (module == null) ? new ClassFileLocator.Resolution.Illegal(name) : ClassFileLocator.ForModule.locate(JavaModule.of(module), name);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public void close() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*  780 */         return this.hashCode;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object other) {
/*  787 */         if (this == other)
/*  788 */           return true; 
/*  789 */         if (other == null || getClass() != other.getClass()) {
/*  790 */           return false;
/*      */         }
/*  792 */         WeaklyReferenced weaklyReferenced = (WeaklyReferenced)other;
/*  793 */         Object module = weaklyReferenced.get();
/*  794 */         return (module != null && get() == module);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static class ForJarFile
/*      */     extends MultiReleaseAware
/*      */   {
/*  808 */     private static final List<String> RUNTIME_LOCATIONS = Arrays.asList(new String[] { "lib/rt.jar", "../lib/rt.jar", "../Classes/classes.jar" });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final JarFile jarFile;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.IGNORE)
/*      */     private final boolean close;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ForJarFile(JarFile jarFile) {
/*  828 */       this(NO_MULTI_RELEASE, jarFile, false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected ForJarFile(int[] version, JarFile jarFile, boolean close) {
/*  840 */       super(version);
/*  841 */       this.jarFile = jarFile;
/*  842 */       this.close = close;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator of(File file) throws IOException {
/*  853 */       return new ForJarFile(ClassFileLocator.MultiReleaseAware.NO_MULTI_RELEASE, new JarFile(file, false, 1), true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator of(File file, ClassFileVersion classFileVersion) throws IOException {
/*  866 */       return of(new JarFile(file, false, 1), classFileVersion, true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator of(JarFile jarFile, ClassFileVersion classFileVersion) throws IOException {
/*  880 */       return of(jarFile, classFileVersion, false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static ClassFileLocator of(JarFile jarFile, ClassFileVersion classFileVersion, boolean close) throws IOException {
/*      */       int[] version;
/*  894 */       if (classFileVersion.getJavaVersion() < 9) {
/*  895 */         return new ForJarFile(jarFile);
/*      */       }
/*  897 */       Manifest manifest = jarFile.getManifest();
/*      */       
/*  899 */       if (manifest != null && Boolean.parseBoolean(manifest.getMainAttributes().getValue("Multi-Release"))) {
/*  900 */         SortedSet<Integer> versions = new TreeSet<Integer>();
/*  901 */         Enumeration<JarEntry> enumeration = jarFile.entries();
/*  902 */         while (enumeration.hasMoreElements()) {
/*  903 */           String name = ((JarEntry)enumeration.nextElement()).getName();
/*  904 */           if (name.endsWith(".class") && name.startsWith("META-INF/versions/")) {
/*      */             try {
/*  906 */               int candidate = Integer.parseInt(name.substring("META-INF/versions/".length(), name.indexOf('/', "META-INF/versions/".length())));
/*  907 */               if (candidate > 7 && candidate <= classFileVersion.getJavaVersion()) {
/*  908 */                 versions.add(Integer.valueOf(candidate));
/*      */               }
/*  910 */             } catch (NumberFormatException numberFormatException) {}
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  915 */         version = new int[versions.size()];
/*  916 */         Iterator<Integer> iterator = versions.iterator();
/*  917 */         for (int index = 0; index < versions.size(); index++) {
/*  918 */           version[versions.size() - index - 1] = ((Integer)iterator.next()).intValue();
/*      */         }
/*      */       } else {
/*  921 */         version = ClassFileLocator.MultiReleaseAware.NO_MULTI_RELEASE;
/*      */       } 
/*  923 */       return new ForJarFile(version, jarFile, close);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator ofClassPath() throws IOException {
/*  935 */       return ofClassPath(System.getProperty("java.class.path"));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator ofClassPath(String classPath) throws IOException {
/*  951 */       ClassFileVersion classFileVersion = ClassFileVersion.ofThisVm();
/*  952 */       List<ClassFileLocator> classFileLocators = new ArrayList<ClassFileLocator>();
/*  953 */       for (String element : Pattern.compile(File.pathSeparator, 16).split(classPath)) {
/*  954 */         File file = new File(element);
/*  955 */         if (file.isDirectory()) {
/*  956 */           classFileLocators.add(ClassFileLocator.ForFolder.of(file, classFileVersion));
/*  957 */         } else if (file.isFile()) {
/*  958 */           classFileLocators.add(of(file, classFileVersion));
/*      */         } 
/*      */       } 
/*  961 */       return new ClassFileLocator.Compound(classFileLocators);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator ofRuntimeJar() throws IOException {
/*  971 */       String javaHome = System.getProperty("java.home").replace('\\', '/');
/*  972 */       File runtimeJar = null;
/*  973 */       for (String location : RUNTIME_LOCATIONS) {
/*  974 */         File candidate = new File(javaHome, location);
/*  975 */         if (candidate.isFile()) {
/*  976 */           runtimeJar = candidate;
/*      */           break;
/*      */         } 
/*      */       } 
/*  980 */       if (runtimeJar == null) {
/*  981 */         throw new IllegalStateException("Runtime jar does not exist in " + javaHome + " for any of " + RUNTIME_LOCATIONS);
/*      */       }
/*  983 */       return of(runtimeJar);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     @SuppressFBWarnings(value = {"PZLA_PREFER_ZERO_LENGTH_ARRAYS"}, justification = "Null value indicates failed lookup.")
/*      */     protected byte[] doLocate(String path) throws IOException {
/*  992 */       ZipEntry zipEntry = this.jarFile.getEntry(path);
/*  993 */       if (zipEntry == null) {
/*  994 */         return null;
/*      */       }
/*  996 */       InputStream inputStream = this.jarFile.getInputStream(zipEntry);
/*      */       try {
/*  998 */         return StreamDrainer.DEFAULT.drain(inputStream);
/*      */       } finally {
/* 1000 */         inputStream.close();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() throws IOException {
/* 1009 */       if (this.close) {
/* 1010 */         this.jarFile.close();
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return !super.equals(param1Object) ? false : ((this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.jarFile.equals(((ForJarFile)param1Object).jarFile)))));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return super.hashCode() * 31 + this.jarFile.hashCode();
/*      */     }
/*      */   }
/*      */   
/*      */   @Enhance
/*      */   public static class ForModuleFile
/*      */     implements ClassFileLocator
/*      */   {
/*      */     private static final String JMOD_FILE_EXTENSION = ".jmod";
/* 1030 */     private static final List<String> BOOT_LOCATIONS = Arrays.asList(new String[] { "jmods", "../jmods", "modules" });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final ZipFile zipFile;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ForModuleFile(ZipFile zipFile) {
/* 1043 */       this.zipFile = zipFile;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator ofBootPath() throws IOException {
/* 1053 */       String javaHome = System.getProperty("java.home").replace('\\', '/');
/* 1054 */       File bootPath = null;
/* 1055 */       for (String location : BOOT_LOCATIONS) {
/* 1056 */         File candidate = new File(javaHome, location);
/* 1057 */         if (candidate.isDirectory()) {
/* 1058 */           bootPath = candidate;
/*      */           break;
/*      */         } 
/*      */       } 
/* 1062 */       if (bootPath == null) {
/* 1063 */         throw new IllegalStateException("Boot modules do not exist in " + javaHome + " for any of " + BOOT_LOCATIONS);
/*      */       }
/* 1065 */       return ofBootPath(bootPath);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator ofBootPath(File bootPath) throws IOException {
/* 1076 */       File[] module = bootPath.listFiles();
/* 1077 */       if (module == null) {
/* 1078 */         return ClassFileLocator.NoOp.INSTANCE;
/*      */       }
/* 1080 */       ClassFileVersion classFileVersion = ClassFileVersion.ofThisVm();
/* 1081 */       List<ClassFileLocator> classFileLocators = new ArrayList<ClassFileLocator>(module.length);
/* 1082 */       for (File aModule : module) {
/* 1083 */         if (aModule.isFile()) {
/* 1084 */           classFileLocators.add(of(aModule));
/* 1085 */         } else if (aModule.isDirectory()) {
/* 1086 */           classFileLocators.add(ClassFileLocator.ForFolder.of(aModule, classFileVersion));
/*      */         } 
/*      */       } 
/* 1089 */       return new ClassFileLocator.Compound(classFileLocators);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator ofModulePath() throws IOException {
/* 1104 */       String modulePath = System.getProperty("jdk.module.path");
/* 1105 */       return (modulePath == null) ? ClassFileLocator.NoOp.INSTANCE : ofModulePath(modulePath);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator ofModulePath(String modulePath) throws IOException {
/* 1122 */       return ofModulePath(modulePath, System.getProperty("user.dir"));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator ofModulePath(String modulePath, String baseFolder) throws IOException {
/* 1139 */       ClassFileVersion classFileVersion = ClassFileVersion.ofThisVm();
/* 1140 */       List<ClassFileLocator> classFileLocators = new ArrayList<ClassFileLocator>();
/* 1141 */       for (String element : Pattern.compile(System.getProperty("path.separator"), 16).split(modulePath)) {
/* 1142 */         File file = new File(baseFolder, element);
/* 1143 */         if (file.isDirectory()) {
/* 1144 */           File[] module = file.listFiles();
/* 1145 */           if (module != null) {
/* 1146 */             for (File aModule : module) {
/* 1147 */               if (aModule.isDirectory()) {
/* 1148 */                 classFileLocators.add(ClassFileLocator.ForFolder.of(aModule, classFileVersion));
/* 1149 */               } else if (aModule.isFile()) {
/* 1150 */                 classFileLocators.add(aModule.getName().endsWith(".jmod") ? of(aModule) : ClassFileLocator.ForJarFile.of(aModule, classFileVersion));
/*      */               } 
/*      */             } 
/*      */           }
/* 1154 */         } else if (file.isFile()) {
/* 1155 */           classFileLocators.add(file.getName().endsWith(".jmod") ? of(file) : ClassFileLocator.ForJarFile.of(file));
/*      */         } 
/*      */       } 
/* 1158 */       return new ClassFileLocator.Compound(classFileLocators);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator of(File file) throws IOException {
/* 1169 */       return new ForModuleFile(new ZipFile(file));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ClassFileLocator.Resolution locate(String name) throws IOException {
/* 1176 */       ZipEntry zipEntry = this.zipFile.getEntry("classes/" + name.replace('.', '/') + ".class");
/* 1177 */       if (zipEntry == null) {
/* 1178 */         return new ClassFileLocator.Resolution.Illegal(name);
/*      */       }
/* 1180 */       InputStream inputStream = this.zipFile.getInputStream(zipEntry);
/*      */       try {
/* 1182 */         return new ClassFileLocator.Resolution.Explicit(StreamDrainer.DEFAULT.drain(inputStream));
/*      */       } finally {
/* 1184 */         inputStream.close();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() throws IOException {
/* 1193 */       this.zipFile.close();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.zipFile.equals(((ForModuleFile)param1Object).zipFile))));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return getClass().hashCode() * 31 + this.zipFile.hashCode();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static class ForFolder
/*      */     extends MultiReleaseAware
/*      */   {
/*      */     private final File folder;
/*      */ 
/*      */     
/*      */     public ForFolder(File folder) {
/* 1216 */       this(NO_MULTI_RELEASE, folder);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected ForFolder(int[] version, File folder) {
/* 1227 */       super(version);
/* 1228 */       this.folder = folder;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator of(File folder, ClassFileVersion classFileVersion) throws IOException {
/*      */       boolean multiRelease;
/*      */       int[] version;
/* 1241 */       if (classFileVersion.getJavaVersion() < 9) {
/* 1242 */         return new ForFolder(NO_MULTI_RELEASE, folder);
/*      */       }
/* 1244 */       File manifest = new File(folder, "META-INF/MANIFEST.MF");
/*      */       
/* 1246 */       if (manifest.exists()) {
/* 1247 */         InputStream inputStream = new FileInputStream(manifest);
/*      */         try {
/* 1249 */           multiRelease = Boolean.parseBoolean((new Manifest(inputStream)).getMainAttributes().getValue("Multi-Release"));
/*      */         } finally {
/* 1251 */           inputStream.close();
/*      */         } 
/*      */       } else {
/* 1254 */         multiRelease = false;
/*      */       } 
/*      */       
/* 1257 */       if (multiRelease) {
/* 1258 */         File[] file = (new File(folder, "META-INF/versions/")).listFiles();
/* 1259 */         if (file != null) {
/* 1260 */           SortedSet<Integer> versions = new TreeSet<Integer>();
/* 1261 */           for (int index = 0; index < file.length; index++) {
/*      */             try {
/* 1263 */               int candidate = Integer.parseInt(file[index].getName());
/* 1264 */               if (candidate > 7 && candidate <= classFileVersion.getJavaVersion()) {
/* 1265 */                 versions.add(Integer.valueOf(candidate));
/*      */               }
/* 1267 */             } catch (NumberFormatException numberFormatException) {}
/*      */           } 
/*      */ 
/*      */           
/* 1271 */           version = new int[versions.size()];
/* 1272 */           Iterator<Integer> iterator = versions.iterator();
/* 1273 */           for (int i = 0; i < versions.size(); i++) {
/* 1274 */             version[versions.size() - i - 1] = ((Integer)iterator.next()).intValue();
/*      */           }
/*      */         } else {
/* 1277 */           version = NO_MULTI_RELEASE;
/*      */         } 
/*      */       } else {
/* 1280 */         version = NO_MULTI_RELEASE;
/*      */       } 
/* 1282 */       return new ForFolder(version, folder);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     @SuppressFBWarnings(value = {"PZLA_PREFER_ZERO_LENGTH_ARRAYS"}, justification = "Null value indicates failed lookup.")
/*      */     protected byte[] doLocate(String path) throws IOException {
/* 1292 */       File file = new File(this.folder, path);
/* 1293 */       if (file.exists()) {
/* 1294 */         InputStream inputStream = new FileInputStream(file);
/*      */         try {
/* 1296 */           return StreamDrainer.DEFAULT.drain(inputStream);
/*      */         } finally {
/* 1298 */           inputStream.close();
/*      */         } 
/*      */       } 
/* 1301 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return !super.equals(param1Object) ? false : ((this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.folder.equals(((ForFolder)param1Object).folder)))));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return super.hashCode() * 31 + this.folder.hashCode();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static class ForUrl
/*      */     implements ClassFileLocator
/*      */   {
/*      */     private final ClassLoader classLoader;
/*      */     
/*      */     private static final boolean ACCESS_CONTROLLER;
/*      */ 
/*      */     
/*      */     public ForUrl(URL... url) {
/* 1331 */       this.classLoader = doPrivileged(new ClassLoaderCreationAction(url));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ForUrl(Collection<? extends URL> urls) {
/* 1340 */       this(urls.<URL>toArray(new URL[0]));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 1352 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ClassFileLocator.Resolution locate(String name) throws IOException {
/* 1359 */       return ClassFileLocator.ForClassLoader.locate(this.classLoader, name);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() throws IOException {
/* 1366 */       if (this.classLoader instanceof Closeable)
/* 1367 */         ((Closeable)this.classLoader).close(); 
/*      */     }
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.classLoader.equals(((ForUrl)param1Object).classLoader))));
/*      */     }
/*      */     public int hashCode() {
/*      */       return getClass().hashCode() * 31 + this.classLoader.hashCode();
/*      */     }
/*      */     static {
/*      */       try {
/*      */         Class.forName("java.security.AccessController", false, (ClassLoader)null);
/*      */         ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true"));
/*      */       } catch (ClassNotFoundException classNotFoundException) {
/*      */         ACCESS_CONTROLLER = false;
/*      */       } catch (SecurityException securityException) {
/*      */         ACCESS_CONTROLLER = true;
/*      */       } 
/*      */     }
/*      */     @Enhance
/*      */     protected static class ClassLoaderCreationAction implements PrivilegedAction<ClassLoader> { private final URL[] url;
/*      */       protected ClassLoaderCreationAction(URL[] url) {
/* 1388 */         this.url = url;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ClassLoader run() {
/* 1395 */         return new URLClassLoader(this.url, ClassLoadingStrategy.BOOTSTRAP_LOADER);
/*      */       }
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!Arrays.equals((Object[])this.url, (Object[])((ClassLoaderCreationAction)param2Object).url))));
/*      */       }
/*      */       
/*      */       public int hashCode() {
/*      */         return getClass().hashCode() * 31 + Arrays.hashCode((Object[])this.url);
/*      */       } }
/*      */   
/*      */   }
/*      */   
/*      */   @Enhance
/*      */   public static class ForInstrumentation
/*      */     implements ClassFileLocator {
/* 1411 */     private static final Dispatcher DISPATCHER = doPrivileged(JavaDispatcher.of(Dispatcher.class)); private final Instrumentation instrumentation; private final ClassLoadingDelegate classLoadingDelegate; private static final boolean ACCESS_CONTROLLER; static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ForInstrumentation(Instrumentation instrumentation, @MaybeNull ClassLoader classLoader) {
/* 1430 */       this(instrumentation, ClassLoadingDelegate.Default.of(classLoader));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 1442 */       return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ForInstrumentation(Instrumentation instrumentation, ClassLoadingDelegate classLoadingDelegate) {
/* 1452 */       if (!DISPATCHER.isRetransformClassesSupported(instrumentation)) {
/* 1453 */         throw new IllegalArgumentException(instrumentation + " does not support retransformation");
/*      */       }
/* 1455 */       this.instrumentation = instrumentation;
/* 1456 */       this.classLoadingDelegate = classLoadingDelegate;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static Instrumentation resolveByteBuddyAgentInstrumentation() {
/*      */       try {
/* 1466 */         Class<?> installer = ClassLoader.getSystemClassLoader().loadClass("net.bytebuddy.agent.Installer");
/* 1467 */         JavaModule source = JavaModule.ofType(AgentBuilder.class), target = JavaModule.ofType(installer);
/* 1468 */         if (source != null && !source.canRead(target)) {
/* 1469 */           Class<?> module = Class.forName("java.lang.Module");
/* 1470 */           module.getMethod("addReads", new Class[] { module }).invoke(source.unwrap(), new Object[] { target.unwrap() });
/*      */         } 
/* 1472 */         return (Instrumentation)installer.getMethod("getInstrumentation", new Class[0]).invoke(null, new Object[0]);
/* 1473 */       } catch (RuntimeException exception) {
/* 1474 */         throw exception;
/* 1475 */       } catch (Exception exception) {
/* 1476 */         throw new IllegalStateException("The Byte Buddy agent is not installed or not accessible", exception);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator fromInstalledAgent(@MaybeNull ClassLoader classLoader) {
/* 1488 */       return new ForInstrumentation(resolveByteBuddyAgentInstrumentation(), classLoader);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static ClassFileLocator of(Instrumentation instrumentation, Class<?> type) {
/* 1499 */       return new ForInstrumentation(instrumentation, ClassLoadingDelegate.Explicit.of(type));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ClassFileLocator.Resolution locate(String name) {
/*      */       try {
/* 1507 */         ExtractionClassFileTransformer classFileTransformer = new ExtractionClassFileTransformer(this.classLoadingDelegate.getClassLoader(), name);
/* 1508 */         DISPATCHER.addTransformer(this.instrumentation, classFileTransformer, true);
/*      */         try {
/* 1510 */           DISPATCHER.retransformClasses(this.instrumentation, new Class[] { this.classLoadingDelegate.locate(name) });
/* 1511 */           byte[] binaryRepresentation = classFileTransformer.getBinaryRepresentation();
/* 1512 */           return (ClassFileLocator.Resolution)((binaryRepresentation == null) ? new ClassFileLocator.Resolution.Illegal(name) : new ClassFileLocator.Resolution.Explicit(binaryRepresentation));
/*      */         } finally {
/* 1514 */           this.instrumentation.removeTransformer(classFileTransformer);
/*      */         } 
/* 1516 */       } catch (RuntimeException exception) {
/* 1517 */         throw exception;
/* 1518 */       } catch (Exception ignored) {
/* 1519 */         return new ClassFileLocator.Resolution.Illegal(name);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.instrumentation.equals(((ForInstrumentation)param1Object).instrumentation) ? false : (!!this.classLoadingDelegate.equals(((ForInstrumentation)param1Object).classLoadingDelegate)))));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return (getClass().hashCode() * 31 + this.instrumentation.hashCode()) * 31 + this.classLoadingDelegate.hashCode();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class Default
/*      */       implements ClassLoadingDelegate
/*      */     {
/* 1594 */       private static final ClassLoader BOOT_LOADER_PROXY = (ClassLoader)ClassFileLocator.ForInstrumentation.doPrivileged(BootLoaderProxyCreationAction.INSTANCE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected final ClassLoader classLoader;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected Default(ClassLoader classLoader) {
/* 1607 */         this.classLoader = classLoader;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static ClassFileLocator.ForInstrumentation.ClassLoadingDelegate of(@MaybeNull ClassLoader classLoader) {
/* 1617 */         return ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.ForDelegatingClassLoader.isDelegating(classLoader) ? new ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.ForDelegatingClassLoader(classLoader) : new Default((classLoader == null) ? BOOT_LOADER_PROXY : classLoader);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public Class<?> locate(String name) throws ClassNotFoundException {
/* 1624 */         return this.classLoader.loadClass(name);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       public ClassLoader getClassLoader() {
/* 1632 */         return (this.classLoader == BOOT_LOADER_PROXY) ? ClassLoadingStrategy.BOOTSTRAP_LOADER : this.classLoader;
/*      */       }
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.classLoader.equals(((Default)param2Object).classLoader))));
/*      */       }
/*      */       
/*      */       public int hashCode() {
/*      */         return getClass().hashCode() * 31 + this.classLoader.hashCode();
/*      */       }
/*      */       
/* 1643 */       protected enum BootLoaderProxyCreationAction implements PrivilegedAction<ClassLoader> { INSTANCE;
/*      */ 
/*      */ 
/*      */         
/*      */         public ClassLoader run()
/*      */         {
/* 1649 */           return new URLClassLoader(new URL[0], ClassLoadingStrategy.BOOTSTRAP_LOADER); } } } public static interface ClassLoadingDelegate { Class<?> locate(String param2String) throws ClassNotFoundException; @MaybeNull ClassLoader getClassLoader(); @Enhance public static class Default implements ClassLoadingDelegate { private static final ClassLoader BOOT_LOADER_PROXY = (ClassLoader)ClassFileLocator.ForInstrumentation.doPrivileged(BootLoaderProxyCreationAction.INSTANCE); protected final ClassLoader classLoader; protected Default(ClassLoader classLoader) { this.classLoader = classLoader; } public static ClassFileLocator.ForInstrumentation.ClassLoadingDelegate of(@MaybeNull ClassLoader classLoader) { return ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.ForDelegatingClassLoader.isDelegating(classLoader) ? new ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.ForDelegatingClassLoader(classLoader) : new Default((classLoader == null) ? BOOT_LOADER_PROXY : classLoader); } public Class<?> locate(String name) throws ClassNotFoundException { return this.classLoader.loadClass(name); } @MaybeNull public ClassLoader getClassLoader() { return (this.classLoader == BOOT_LOADER_PROXY) ? ClassLoadingStrategy.BOOTSTRAP_LOADER : this.classLoader; } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.classLoader.equals(((Default)param3Object).classLoader)))); } public int hashCode() { return getClass().hashCode() * 31 + this.classLoader.hashCode(); } protected enum BootLoaderProxyCreationAction implements PrivilegedAction<ClassLoader> { public ClassLoader run() { return new URLClassLoader(new URL[0], ClassLoadingStrategy.BOOTSTRAP_LOADER); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           INSTANCE; }
/*      */          }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static class ForDelegatingClassLoader
/*      */         extends Default
/*      */       {
/*      */         private static final String DELEGATING_CLASS_LOADER_NAME = "sun.reflect.DelegatingClassLoader";
/*      */ 
/*      */ 
/*      */         
/*      */         private static final int ONLY = 0;
/*      */ 
/*      */ 
/*      */         
/* 1673 */         private static final Dispatcher.Initializable DISPATCHER = doPrivileged(Dispatcher.CreationAction.INSTANCE); private static final boolean ACCESS_CONTROLLER; static { try { Class.forName("java.security.AccessController", false, (ClassLoader)null); ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true")); } catch (ClassNotFoundException classNotFoundException) { ACCESS_CONTROLLER = false; } catch (SecurityException securityException) { ACCESS_CONTROLLER = true; }
/*      */            }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected ForDelegatingClassLoader(ClassLoader classLoader) {
/* 1681 */           super(classLoader);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 1693 */           return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected static boolean isDelegating(@MaybeNull ClassLoader classLoader) {
/* 1703 */           return (classLoader != null && classLoader.getClass().getName().equals("sun.reflect.DelegatingClassLoader"));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Class<?> locate(String name) throws ClassNotFoundException {
/*      */           Vector<Class<?>> classes;
/*      */           try {
/* 1712 */             classes = DISPATCHER.initialize().extract(this.classLoader);
/* 1713 */           } catch (RuntimeException ignored) {
/* 1714 */             return super.locate(name);
/*      */           } 
/* 1716 */           if (classes.size() != 1) {
/* 1717 */             return super.locate(name);
/*      */           }
/* 1719 */           Class<?> type = classes.get(0);
/* 1720 */           return TypeDescription.ForLoadedType.getName(type).equals(name) ? type : super.locate(name);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public enum CreationAction
/*      */           implements PrivilegedAction<Dispatcher.Initializable>
/*      */         {
/* 1757 */           INSTANCE;
/*      */ 
/*      */ 
/*      */           
/*      */           public ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.ForDelegatingClassLoader.Dispatcher.Initializable run()
/*      */           {
/*      */             
/* 1764 */             try { return new ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.ForDelegatingClassLoader.Dispatcher.Resolved(ClassLoader.class.getDeclaredField("classes")); }
/* 1765 */             catch (Exception exception)
/* 1766 */             { return new ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.ForDelegatingClassLoader.Dispatcher.Unresolved(exception.getMessage()); }  } } public static interface Initializable { ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.ForDelegatingClassLoader.Dispatcher initialize(); } protected static interface Dispatcher { Vector<Class<?>> extract(ClassLoader param4ClassLoader); public static interface Initializable { ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.ForDelegatingClassLoader.Dispatcher initialize(); } public enum CreationAction implements PrivilegedAction<Initializable> { INSTANCE; public ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.ForDelegatingClassLoader.Dispatcher.Initializable run() { try { return new ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.ForDelegatingClassLoader.Dispatcher.Resolved(ClassLoader.class.getDeclaredField("classes")); } catch (Exception exception) { return new ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.ForDelegatingClassLoader.Dispatcher.Unresolved(exception.getMessage()); }
/*      */                }
/*      */              }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @Enhance
/*      */           public static class Resolved
/*      */             implements Dispatcher, Initializable, PrivilegedAction<Dispatcher>
/*      */           {
/*      */             private final Field field;
/*      */ 
/*      */ 
/*      */             
/*      */             private static final boolean ACCESS_CONTROLLER;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public Resolved(Field field) {
/* 1788 */               this.field = field;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             private static <T> T doPrivileged(PrivilegedAction<T> action) {
/* 1800 */               return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.ForDelegatingClassLoader.Dispatcher initialize() {
/* 1807 */               return doPrivileged(this);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public Vector<Class<?>> extract(ClassLoader classLoader) {
/*      */               try {
/* 1816 */                 return (Vector<Class<?>>)this.field.get(classLoader);
/* 1817 */               } catch (IllegalAccessException exception) {
/* 1818 */                 throw new IllegalStateException("Cannot access field", exception);
/*      */               } 
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.ForDelegatingClassLoader.Dispatcher run() {
/* 1826 */               this.field.setAccessible(true);
/* 1827 */               return this;
/*      */             }
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.field.equals(((Resolved)param5Object).field))));
/*      */             }
/*      */             public int hashCode() {
/*      */               return getClass().hashCode() * 31 + this.field.hashCode();
/*      */             }
/*      */             static {
/*      */               try {
/*      */                 Class.forName("java.security.AccessController", false, (ClassLoader)null);
/*      */                 ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true"));
/*      */               } catch (ClassNotFoundException classNotFoundException) {
/*      */                 ACCESS_CONTROLLER = false;
/*      */               } catch (SecurityException securityException) {
/*      */                 ACCESS_CONTROLLER = true;
/*      */               } 
/*      */             } }
/*      */           @Enhance
/*      */           public static class Unresolved implements Initializable { private final String message;
/*      */             public Unresolved(String message) {
/* 1848 */               this.message = message;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.ForDelegatingClassLoader.Dispatcher initialize() {
/* 1855 */               throw new UnsupportedOperationException("Could not locate classes vector: " + this.message);
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.message.equals(((Unresolved)param5Object).message))));
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               return getClass().hashCode() * 31 + this.message.hashCode();
/*      */             } }
/*      */            }
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static class Explicit
/*      */         implements ClassLoadingDelegate
/*      */       {
/*      */         private final ClassFileLocator.ForInstrumentation.ClassLoadingDelegate fallbackDelegate;
/*      */ 
/*      */         
/*      */         private final Map<String, Class<?>> types;
/*      */ 
/*      */ 
/*      */         
/*      */         public Explicit(@MaybeNull ClassLoader classLoader, Collection<? extends Class<?>> types) {
/* 1887 */           this(ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.Default.of(classLoader), types);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Explicit(ClassFileLocator.ForInstrumentation.ClassLoadingDelegate fallbackDelegate, Collection<? extends Class<?>> types) {
/* 1899 */           this.fallbackDelegate = fallbackDelegate;
/* 1900 */           this.types = new HashMap<String, Class<?>>();
/* 1901 */           for (Class<?> type : types) {
/* 1902 */             this.types.put(TypeDescription.ForLoadedType.getName(type), type);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public static ClassFileLocator.ForInstrumentation.ClassLoadingDelegate of(Class<?> type) {
/* 1913 */           return new Explicit(type.getClassLoader(), Collections.singleton(type));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Class<?> locate(String name) throws ClassNotFoundException {
/* 1920 */           Class<?> type = this.types.get(name);
/* 1921 */           return (type == null) ? this.fallbackDelegate.locate(name) : type;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         @MaybeNull
/*      */         public ClassLoader getClassLoader()
/*      */         {
/* 1929 */           return this.fallbackDelegate.getClassLoader(); } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.fallbackDelegate.equals(((Explicit)param3Object).fallbackDelegate) ? false : (!!this.types.equals(((Explicit)param3Object).types))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.fallbackDelegate.hashCode()) * 31 + this.types.hashCode(); } } } @Enhance public static class Explicit implements ClassLoadingDelegate { private final ClassFileLocator.ForInstrumentation.ClassLoadingDelegate fallbackDelegate; private final Map<String, Class<?>> types; public Explicit(@MaybeNull ClassLoader classLoader, Collection<? extends Class<?>> types) { this(ClassFileLocator.ForInstrumentation.ClassLoadingDelegate.Default.of(classLoader), types); } public Explicit(ClassFileLocator.ForInstrumentation.ClassLoadingDelegate fallbackDelegate, Collection<? extends Class<?>> types) { this.fallbackDelegate = fallbackDelegate; this.types = new HashMap<String, Class<?>>(); for (Class<?> type : types) this.types.put(TypeDescription.ForLoadedType.getName(type), type);  } public static ClassFileLocator.ForInstrumentation.ClassLoadingDelegate of(Class<?> type) { return new Explicit(type.getClassLoader(), Collections.singleton(type)); } public Class<?> locate(String name) throws ClassNotFoundException { Class<?> type = this.types.get(name); return (type == null) ? this.fallbackDelegate.locate(name) : type; } @MaybeNull public ClassLoader getClassLoader() { return this.fallbackDelegate.getClassLoader(); }
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.fallbackDelegate.equals(((Explicit)param2Object).fallbackDelegate) ? false : (!!this.types.equals(((Explicit)param2Object).types)))));
/*      */       }
/*      */       
/*      */       public int hashCode() {
/*      */         return (getClass().hashCode() * 31 + this.fallbackDelegate.hashCode()) * 31 + this.types.hashCode();
/*      */       } }
/*      */ 
/*      */     
/*      */     protected static class ExtractionClassFileTransformer implements ClassFileTransformer {
/*      */       @AlwaysNull
/* 1943 */       private static final byte[] DO_NOT_TRANSFORM = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       private final ClassLoader classLoader;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final String typeName;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       @SuppressFBWarnings(value = {"VO_VOLATILE_REFERENCE_TO_ARRAY"}, justification = "The array is not to be modified by contract")
/*      */       private volatile byte[] binaryRepresentation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected ExtractionClassFileTransformer(@MaybeNull ClassLoader classLoader, String typeName) {
/* 1970 */         this.classLoader = classLoader;
/* 1971 */         this.typeName = typeName;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       @SuppressFBWarnings(value = {"EI_EXPOSE_REP", "EI_EXPOSE_REP2"}, justification = "The array is not modified by class contract.")
/*      */       public byte[] transform(@MaybeNull ClassLoader classLoader, @MaybeNull String internalName, @MaybeNull Class<?> redefinedType, @MaybeNull ProtectionDomain protectionDomain, byte[] binaryRepresentation) {
/* 1984 */         if (internalName != null && ElementMatchers.isChildOf(this.classLoader).matches(classLoader) && this.typeName.equals(internalName.replace('/', '.'))) {
/* 1985 */           this.binaryRepresentation = (byte[])binaryRepresentation.clone();
/*      */         }
/* 1987 */         return DO_NOT_TRANSFORM;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       @SuppressFBWarnings(value = {"EI_EXPOSE_REP"}, justification = "The array is not to be modified by contract")
/*      */       protected byte[] getBinaryRepresentation() {
/* 1999 */         return this.binaryRepresentation;
/*      */       }
/*      */     }
/*      */     
/*      */     @Proxied("java.lang.instrument.Instrumentation")
/*      */     protected static interface Dispatcher {
/*      */       @Proxied("isRetransformClassesSupported")
/*      */       boolean isRetransformClassesSupported(Instrumentation param2Instrumentation);
/*      */       
/*      */       @Proxied("addTransformer")
/*      */       void addTransformer(Instrumentation param2Instrumentation, ClassFileTransformer param2ClassFileTransformer, boolean param2Boolean);
/*      */       
/*      */       @Proxied("retransformClasses")
/*      */       void retransformClasses(Instrumentation param2Instrumentation, Class<?>[] param2ArrayOfClass) throws UnmodifiableClassException;
/*      */     }
/*      */   }
/*      */   
/*      */   @Enhance
/*      */   public static class PackageDiscriminating implements ClassFileLocator {
/*      */     private final Map<String, ClassFileLocator> classFileLocators;
/*      */     
/*      */     public PackageDiscriminating(Map<String, ClassFileLocator> classFileLocators) {
/* 2021 */       this.classFileLocators = classFileLocators;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ClassFileLocator.Resolution locate(String name) throws IOException {
/* 2028 */       int packageIndex = name.lastIndexOf('.');
/* 2029 */       ClassFileLocator classFileLocator = this.classFileLocators.get((packageIndex == -1) ? "" : name.substring(0, packageIndex));
/* 2030 */       return (classFileLocator == null) ? new ClassFileLocator.Resolution.Illegal(name) : classFileLocator.locate(name);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() throws IOException {
/* 2037 */       for (ClassFileLocator classFileLocator : this.classFileLocators.values()) {
/* 2038 */         classFileLocator.close();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.classFileLocators.equals(((PackageDiscriminating)param1Object).classFileLocators))));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return getClass().hashCode() * 31 + this.classFileLocators.hashCode();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static class Filtering
/*      */     implements ClassFileLocator
/*      */   {
/*      */     private final ElementMatcher<? super String> matcher;
/*      */     
/*      */     private final ClassFileLocator delegate;
/*      */ 
/*      */     
/*      */     public Filtering(ElementMatcher<? super String> matcher, ClassFileLocator delegate) {
/* 2066 */       this.matcher = matcher;
/* 2067 */       this.delegate = delegate;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ClassFileLocator.Resolution locate(String name) throws IOException {
/* 2074 */       return this.matcher.matches(name) ? this.delegate.locate(name) : new ClassFileLocator.Resolution.Illegal(name);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() throws IOException {
/* 2081 */       this.delegate.close();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.matcher.equals(((Filtering)param1Object).matcher) ? false : (!!this.delegate.equals(((Filtering)param1Object).delegate)))));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return (getClass().hashCode() * 31 + this.matcher.hashCode()) * 31 + this.delegate.hashCode();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static class Compound
/*      */     implements ClassFileLocator, Closeable
/*      */   {
/*      */     public Compound(ClassFileLocator... classFileLocator) {
/* 2106 */       this(Arrays.asList(classFileLocator));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2116 */     private final List<ClassFileLocator> classFileLocators = new ArrayList<ClassFileLocator>(); public Compound(List<? extends ClassFileLocator> classFileLocators) {
/* 2117 */       for (ClassFileLocator classFileLocator : classFileLocators) {
/* 2118 */         if (classFileLocator instanceof Compound) {
/* 2119 */           this.classFileLocators.addAll(((Compound)classFileLocator).classFileLocators); continue;
/* 2120 */         }  if (!(classFileLocator instanceof ClassFileLocator.NoOp)) {
/* 2121 */           this.classFileLocators.add(classFileLocator);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ClassFileLocator.Resolution locate(String name) throws IOException {
/* 2130 */       for (ClassFileLocator classFileLocator : this.classFileLocators) {
/* 2131 */         ClassFileLocator.Resolution resolution = classFileLocator.locate(name);
/* 2132 */         if (resolution.isResolved()) {
/* 2133 */           return resolution;
/*      */         }
/*      */       } 
/* 2136 */       return new ClassFileLocator.Resolution.Illegal(name);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() throws IOException {
/* 2143 */       for (ClassFileLocator classFileLocator : this.classFileLocators)
/* 2144 */         classFileLocator.close(); 
/*      */     }
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.classFileLocators.equals(((Compound)param1Object).classFileLocators))));
/*      */     }
/*      */     
/*      */     public int hashCode() {
/*      */       return getClass().hashCode() * 31 + this.classFileLocators.hashCode();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\dynamic\ClassFileLocator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */