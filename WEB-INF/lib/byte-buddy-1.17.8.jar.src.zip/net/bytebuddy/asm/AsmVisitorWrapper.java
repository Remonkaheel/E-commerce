/*     */ package net.bytebuddy.asm;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.field.FieldList;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.jar.asm.FieldVisitor;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.pool.TypePool;
/*     */ import net.bytebuddy.utility.CompoundList;
/*     */ import net.bytebuddy.utility.OpenedClassReader;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface AsmVisitorWrapper
/*     */ {
/*     */   public static final int NO_FLAGS = 0;
/*     */   
/*     */   int mergeWriter(int paramInt);
/*     */   
/*     */   int mergeReader(int paramInt);
/*     */   
/*     */   ClassVisitor wrap(TypeDescription paramTypeDescription, ClassVisitor paramClassVisitor, Implementation.Context paramContext, TypePool paramTypePool, FieldList<FieldDescription.InDefinedShape> paramFieldList, MethodList<?> paramMethodList, int paramInt1, int paramInt2);
/*     */   
/*     */   public enum NoOp
/*     */     implements AsmVisitorWrapper
/*     */   {
/* 102 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int mergeWriter(int flags) {
/* 108 */       return flags;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int mergeReader(int flags) {
/* 115 */       return flags;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassVisitor wrap(TypeDescription instrumentedType, ClassVisitor classVisitor, Implementation.Context implementationContext, TypePool typePool, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, int writerFlags, int readerFlags) {
/* 129 */       return classVisitor;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class AbstractBase
/*     */     implements AsmVisitorWrapper
/*     */   {
/*     */     public int mergeWriter(int flags) {
/* 142 */       return flags;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int mergeReader(int flags) {
/* 149 */       return flags;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class ForDeclaredFields
/*     */     extends AbstractBase
/*     */   {
/*     */     private final List<Entry> entries;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForDeclaredFields() {
/* 168 */       this(Collections.emptyList());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected ForDeclaredFields(List<Entry> entries) {
/* 177 */       this.entries = entries;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForDeclaredFields field(ElementMatcher<? super FieldDescription.InDefinedShape> matcher, FieldVisitorWrapper... fieldVisitorWrapper) {
/* 189 */       return field(matcher, Arrays.asList(fieldVisitorWrapper));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForDeclaredFields field(ElementMatcher<? super FieldDescription.InDefinedShape> matcher, List<? extends FieldVisitorWrapper> fieldVisitorWrappers) {
/* 201 */       return new ForDeclaredFields(CompoundList.of(this.entries, new Entry(matcher, fieldVisitorWrappers)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassVisitor wrap(TypeDescription instrumentedType, ClassVisitor classVisitor, Implementation.Context implementationContext, TypePool typePool, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, int writerFlags, int readerFlags) {
/* 215 */       Map<String, FieldDescription.InDefinedShape> mapped = new HashMap<String, FieldDescription.InDefinedShape>();
/* 216 */       for (FieldDescription.InDefinedShape fieldDescription : fields) {
/* 217 */         mapped.put(fieldDescription.getInternalName() + fieldDescription.getDescriptor(), fieldDescription);
/*     */       }
/* 219 */       return new DispatchingVisitor(classVisitor, instrumentedType, mapped);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.entries.equals(((ForDeclaredFields)param1Object).entries))));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.entries.hashCode();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static interface FieldVisitorWrapper
/*     */     {
/*     */       FieldVisitor wrap(TypeDescription param2TypeDescription, FieldDescription.InDefinedShape param2InDefinedShape, FieldVisitor param2FieldVisitor);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     protected static class Entry
/*     */       implements ElementMatcher<FieldDescription.InDefinedShape>, FieldVisitorWrapper
/*     */     {
/*     */       private final ElementMatcher<? super FieldDescription.InDefinedShape> matcher;
/*     */ 
/*     */ 
/*     */       
/*     */       private final List<? extends AsmVisitorWrapper.ForDeclaredFields.FieldVisitorWrapper> fieldVisitorWrappers;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected Entry(ElementMatcher<? super FieldDescription.InDefinedShape> matcher, List<? extends AsmVisitorWrapper.ForDeclaredFields.FieldVisitorWrapper> fieldVisitorWrappers) {
/* 261 */         this.matcher = matcher;
/* 262 */         this.fieldVisitorWrappers = fieldVisitorWrappers;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean matches(@MaybeNull FieldDescription.InDefinedShape target) {
/* 269 */         return this.matcher.matches(target);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public FieldVisitor wrap(TypeDescription instrumentedType, FieldDescription.InDefinedShape fieldDescription, FieldVisitor fieldVisitor) {
/* 276 */         for (AsmVisitorWrapper.ForDeclaredFields.FieldVisitorWrapper fieldVisitorWrapper : this.fieldVisitorWrappers) {
/* 277 */           fieldVisitor = fieldVisitorWrapper.wrap(instrumentedType, fieldDescription, fieldVisitor);
/*     */         }
/* 279 */         return fieldVisitor;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.matcher.equals(((Entry)param2Object).matcher) ? false : (!!this.fieldVisitorWrappers.equals(((Entry)param2Object).fieldVisitorWrappers)))));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return (getClass().hashCode() * 31 + this.matcher.hashCode()) * 31 + this.fieldVisitorWrappers.hashCode();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected class DispatchingVisitor
/*     */       extends ClassVisitor
/*     */     {
/*     */       private final TypeDescription instrumentedType;
/*     */       
/*     */       private final Map<String, FieldDescription.InDefinedShape> fields;
/*     */ 
/*     */       
/*     */       protected DispatchingVisitor(ClassVisitor classVisitor, TypeDescription instrumentedType, Map<String, FieldDescription.InDefinedShape> fields) {
/* 306 */         super(OpenedClassReader.ASM_API, classVisitor);
/* 307 */         this.instrumentedType = instrumentedType;
/* 308 */         this.fields = fields;
/*     */       }
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public FieldVisitor visitField(int modifiers, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull Object value) {
/* 314 */         FieldVisitor fieldVisitor = super.visitField(modifiers, internalName, descriptor, signature, value);
/* 315 */         FieldDescription.InDefinedShape fieldDescription = this.fields.get(internalName + descriptor);
/* 316 */         if (fieldVisitor != null && fieldDescription != null) {
/* 317 */           for (AsmVisitorWrapper.ForDeclaredFields.Entry entry : AsmVisitorWrapper.ForDeclaredFields.this.entries) {
/* 318 */             if (entry.matches(fieldDescription)) {
/* 319 */               fieldVisitor = entry.wrap(this.instrumentedType, fieldDescription, fieldVisitor);
/*     */             }
/*     */           } 
/*     */         }
/* 323 */         return fieldVisitor;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class ForDeclaredMethods
/*     */     implements AsmVisitorWrapper
/*     */   {
/*     */     private final List<Entry> entries;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int writerFlags;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int readerFlags;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForDeclaredMethods() {
/* 358 */       this(Collections.emptyList(), 0, 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected ForDeclaredMethods(List<Entry> entries, int writerFlags, int readerFlags) {
/* 369 */       this.entries = entries;
/* 370 */       this.writerFlags = writerFlags;
/* 371 */       this.readerFlags = readerFlags;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForDeclaredMethods method(ElementMatcher<? super MethodDescription> matcher, MethodVisitorWrapper... methodVisitorWrapper) {
/* 383 */       return method(matcher, Arrays.asList(methodVisitorWrapper));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForDeclaredMethods method(ElementMatcher<? super MethodDescription> matcher, List<? extends MethodVisitorWrapper> methodVisitorWrappers) {
/* 395 */       return invokable((ElementMatcher<? super MethodDescription>)ElementMatchers.isMethod().and(matcher), methodVisitorWrappers);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForDeclaredMethods constructor(ElementMatcher<? super MethodDescription> matcher, MethodVisitorWrapper... methodVisitorWrapper) {
/* 407 */       return constructor(matcher, Arrays.asList(methodVisitorWrapper));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForDeclaredMethods constructor(ElementMatcher<? super MethodDescription> matcher, List<? extends MethodVisitorWrapper> methodVisitorWrappers) {
/* 419 */       return invokable((ElementMatcher<? super MethodDescription>)ElementMatchers.isConstructor().and(matcher), methodVisitorWrappers);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForDeclaredMethods invokable(ElementMatcher<? super MethodDescription> matcher, MethodVisitorWrapper... methodVisitorWrapper) {
/* 431 */       return invokable(matcher, Arrays.asList(methodVisitorWrapper));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForDeclaredMethods invokable(ElementMatcher<? super MethodDescription> matcher, List<? extends MethodVisitorWrapper> methodVisitorWrappers) {
/* 443 */       return new ForDeclaredMethods(CompoundList.of(this.entries, new Entry(matcher, methodVisitorWrappers)), this.writerFlags, this.readerFlags);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForDeclaredMethods writerFlags(int flags) {
/* 453 */       return new ForDeclaredMethods(this.entries, this.writerFlags | flags, this.readerFlags);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForDeclaredMethods readerFlags(int flags) {
/* 463 */       return new ForDeclaredMethods(this.entries, this.writerFlags, this.readerFlags | flags);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int mergeWriter(int flags) {
/* 470 */       return flags | this.writerFlags;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int mergeReader(int flags) {
/* 477 */       return flags | this.readerFlags;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassVisitor wrap(TypeDescription instrumentedType, ClassVisitor classVisitor, Implementation.Context implementationContext, TypePool typePool, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, int writerFlags, int readerFlags) {
/* 491 */       Map<String, MethodDescription> mapped = new HashMap<String, MethodDescription>();
/* 492 */       for (MethodDescription methodDescription : CompoundList.of((List)methods, new MethodDescription.Latent.TypeInitializer(instrumentedType))) {
/* 493 */         mapped.put(methodDescription.getInternalName() + methodDescription.getDescriptor(), methodDescription);
/*     */       }
/* 495 */       return new DispatchingVisitor(classVisitor, instrumentedType, implementationContext, typePool, mapped, writerFlags, readerFlags);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : ((this.writerFlags != ((ForDeclaredMethods)param1Object).writerFlags) ? false : ((this.readerFlags != ((ForDeclaredMethods)param1Object).readerFlags) ? false : (!!this.entries.equals(((ForDeclaredMethods)param1Object).entries))))));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return ((getClass().hashCode() * 31 + this.entries.hashCode()) * 31 + this.writerFlags) * 31 + this.readerFlags;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static interface MethodVisitorWrapper
/*     */     {
/*     */       MethodVisitor wrap(TypeDescription param2TypeDescription, MethodDescription param2MethodDescription, MethodVisitor param2MethodVisitor, Implementation.Context param2Context, TypePool param2TypePool, int param2Int1, int param2Int2);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Enhance
/*     */     protected static class Entry
/*     */       implements ElementMatcher<MethodDescription>, MethodVisitorWrapper
/*     */     {
/*     */       private final ElementMatcher<? super MethodDescription> matcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final List<? extends AsmVisitorWrapper.ForDeclaredMethods.MethodVisitorWrapper> methodVisitorWrappers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected Entry(ElementMatcher<? super MethodDescription> matcher, List<? extends AsmVisitorWrapper.ForDeclaredMethods.MethodVisitorWrapper> methodVisitorWrappers) {
/* 553 */         this.matcher = matcher;
/* 554 */         this.methodVisitorWrappers = methodVisitorWrappers;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean matches(@MaybeNull MethodDescription target) {
/* 561 */         return this.matcher.matches(target);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public MethodVisitor wrap(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, TypePool typePool, int writerFlags, int readerFlags) {
/* 574 */         for (AsmVisitorWrapper.ForDeclaredMethods.MethodVisitorWrapper methodVisitorWrapper : this.methodVisitorWrappers) {
/* 575 */           methodVisitor = methodVisitorWrapper.wrap(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, typePool, writerFlags, readerFlags);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 583 */         return methodVisitor;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public boolean equals(@MaybeNull Object param2Object) {
/*     */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.matcher.equals(((Entry)param2Object).matcher) ? false : (!!this.methodVisitorWrappers.equals(((Entry)param2Object).methodVisitorWrappers)))));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public int hashCode() {
/*     */         return (getClass().hashCode() * 31 + this.matcher.hashCode()) * 31 + this.methodVisitorWrappers.hashCode();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected class DispatchingVisitor
/*     */       extends ClassVisitor
/*     */     {
/*     */       private final TypeDescription instrumentedType;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final Implementation.Context implementationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final TypePool typePool;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final int writerFlags;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final int readerFlags;
/*     */ 
/*     */ 
/*     */       
/*     */       private final Map<String, MethodDescription> methods;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected DispatchingVisitor(ClassVisitor classVisitor, TypeDescription instrumentedType, Implementation.Context implementationContext, TypePool typePool, Map<String, MethodDescription> methods, int writerFlags, int readerFlags) {
/* 640 */         super(OpenedClassReader.ASM_API, classVisitor);
/* 641 */         this.instrumentedType = instrumentedType;
/* 642 */         this.implementationContext = implementationContext;
/* 643 */         this.typePool = typePool;
/* 644 */         this.methods = methods;
/* 645 */         this.writerFlags = writerFlags;
/* 646 */         this.readerFlags = readerFlags;
/*     */       }
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public MethodVisitor visitMethod(int modifiers, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull String[] exceptions) {
/* 652 */         MethodVisitor methodVisitor = super.visitMethod(modifiers, internalName, descriptor, signature, exceptions);
/* 653 */         MethodDescription methodDescription = this.methods.get(internalName + descriptor);
/* 654 */         if (methodVisitor != null && methodDescription != null) {
/* 655 */           for (AsmVisitorWrapper.ForDeclaredMethods.Entry entry : AsmVisitorWrapper.ForDeclaredMethods.this.entries) {
/* 656 */             if (entry.matches(methodDescription)) {
/* 657 */               methodVisitor = entry.wrap(this.instrumentedType, methodDescription, methodVisitor, this.implementationContext, this.typePool, this.writerFlags, this.readerFlags);
/*     */             }
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 667 */         return methodVisitor;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   public static class Compound
/*     */     implements AsmVisitorWrapper
/*     */   {
/*     */     public Compound(AsmVisitorWrapper... asmVisitorWrapper) {
/* 692 */       this(Arrays.asList(asmVisitorWrapper));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 704 */     private final List<AsmVisitorWrapper> asmVisitorWrappers = new ArrayList<AsmVisitorWrapper>(); public Compound(List<? extends AsmVisitorWrapper> asmVisitorWrappers) {
/* 705 */       for (AsmVisitorWrapper asmVisitorWrapper : asmVisitorWrappers) {
/* 706 */         if (asmVisitorWrapper instanceof Compound) {
/* 707 */           this.asmVisitorWrappers.addAll(((Compound)asmVisitorWrapper).asmVisitorWrappers); continue;
/* 708 */         }  if (!(asmVisitorWrapper instanceof AsmVisitorWrapper.NoOp)) {
/* 709 */           this.asmVisitorWrappers.add(asmVisitorWrapper);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int mergeWriter(int flags) {
/* 718 */       for (AsmVisitorWrapper asmVisitorWrapper : this.asmVisitorWrappers) {
/* 719 */         flags = asmVisitorWrapper.mergeWriter(flags);
/*     */       }
/* 721 */       return flags;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int mergeReader(int flags) {
/* 728 */       for (AsmVisitorWrapper asmVisitorWrapper : this.asmVisitorWrappers) {
/* 729 */         flags = asmVisitorWrapper.mergeReader(flags);
/*     */       }
/* 731 */       return flags;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ClassVisitor wrap(TypeDescription instrumentedType, ClassVisitor classVisitor, Implementation.Context implementationContext, TypePool typePool, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, int writerFlags, int readerFlags) {
/* 745 */       for (AsmVisitorWrapper asmVisitorWrapper : this.asmVisitorWrappers) {
/* 746 */         classVisitor = asmVisitorWrapper.wrap(instrumentedType, classVisitor, implementationContext, typePool, fields, methods, writerFlags, readerFlags);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 755 */       return classVisitor;
/*     */     }
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.asmVisitorWrappers.equals(((Compound)param1Object).asmVisitorWrappers))));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*     */       return getClass().hashCode() * 31 + this.asmVisitorWrappers.hashCode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\asm\AsmVisitorWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */