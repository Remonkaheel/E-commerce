/*      */ package net.bytebuddy.asm;
/*      */ 
/*      */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*      */ import java.io.Serializable;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.annotation.Documented;
/*      */ import java.lang.annotation.ElementType;
/*      */ import java.lang.annotation.Retention;
/*      */ import java.lang.annotation.RetentionPolicy;
/*      */ import java.lang.annotation.Target;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Type;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import net.bytebuddy.ClassFileVersion;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling;
/*      */ import net.bytebuddy.build.SafeVarargsPlugin.Enhance;
/*      */ import net.bytebuddy.description.ByteCodeElement;
/*      */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*      */ import net.bytebuddy.description.annotation.AnnotationValue;
/*      */ import net.bytebuddy.description.enumeration.EnumerationDescription;
/*      */ import net.bytebuddy.description.field.FieldDescription;
/*      */ import net.bytebuddy.description.field.FieldList;
/*      */ import net.bytebuddy.description.method.MethodDescription;
/*      */ import net.bytebuddy.description.method.MethodList;
/*      */ import net.bytebuddy.description.method.ParameterDescription;
/*      */ import net.bytebuddy.description.type.TypeDefinition;
/*      */ import net.bytebuddy.description.type.TypeDescription;
/*      */ import net.bytebuddy.description.type.TypeList;
/*      */ import net.bytebuddy.dynamic.ClassFileLocator;
/*      */ import net.bytebuddy.dynamic.TargetType;
/*      */ import net.bytebuddy.dynamic.scaffold.FieldLocator;
/*      */ import net.bytebuddy.dynamic.scaffold.MethodGraph;
/*      */ import net.bytebuddy.implementation.Implementation;
/*      */ import net.bytebuddy.implementation.bytecode.Duplication;
/*      */ import net.bytebuddy.implementation.bytecode.Removal;
/*      */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*      */ import net.bytebuddy.implementation.bytecode.StackSize;
/*      */ import net.bytebuddy.implementation.bytecode.TypeCreation;
/*      */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*      */ import net.bytebuddy.implementation.bytecode.collection.ArrayFactory;
/*      */ import net.bytebuddy.implementation.bytecode.constant.ClassConstant;
/*      */ import net.bytebuddy.implementation.bytecode.constant.DefaultValue;
/*      */ import net.bytebuddy.implementation.bytecode.constant.FieldConstant;
/*      */ import net.bytebuddy.implementation.bytecode.constant.JavaConstantValue;
/*      */ import net.bytebuddy.implementation.bytecode.constant.MethodConstant;
/*      */ import net.bytebuddy.implementation.bytecode.constant.NullConstant;
/*      */ import net.bytebuddy.implementation.bytecode.constant.SerializedConstant;
/*      */ import net.bytebuddy.implementation.bytecode.constant.TextConstant;
/*      */ import net.bytebuddy.implementation.bytecode.member.FieldAccess;
/*      */ import net.bytebuddy.implementation.bytecode.member.Invokedynamic;
/*      */ import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
/*      */ import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;
/*      */ import net.bytebuddy.jar.asm.MethodVisitor;
/*      */ import net.bytebuddy.jar.asm.Type;
/*      */ import net.bytebuddy.matcher.ElementMatcher;
/*      */ import net.bytebuddy.matcher.ElementMatchers;
/*      */ import net.bytebuddy.pool.TypePool;
/*      */ import net.bytebuddy.utility.CompoundList;
/*      */ import net.bytebuddy.utility.ConstantValue;
/*      */ import net.bytebuddy.utility.JavaConstant;
/*      */ import net.bytebuddy.utility.JavaType;
/*      */ import net.bytebuddy.utility.OpenedClassReader;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ import net.bytebuddy.utility.visitor.LocalVariableAwareMethodVisitor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Enhance
/*      */ public class MemberSubstitution
/*      */   implements AsmVisitorWrapper.ForDeclaredMethods.MethodVisitorWrapper
/*      */ {
/*      */   protected static final int THIS_REFERENCE = 0;
/*      */   private final MethodGraph.Compiler methodGraphCompiler;
/*      */   private final TypePoolResolver typePoolResolver;
/*      */   private final boolean strict;
/*      */   private final boolean failIfNoMatch;
/*      */   private final Replacement.Factory replacementFactory;
/*      */   
/*      */   protected MemberSubstitution(boolean strict) {
/*  125 */     this(MethodGraph.Compiler.DEFAULT, TypePoolResolver.OfImplicitPool.INSTANCE, strict, false, Replacement.NoOp.INSTANCE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MemberSubstitution(MethodGraph.Compiler methodGraphCompiler, TypePoolResolver typePoolResolver, boolean strict, boolean failIfNoMatch, Replacement.Factory replacementFactory) {
/*  142 */     this.methodGraphCompiler = methodGraphCompiler;
/*  143 */     this.typePoolResolver = typePoolResolver;
/*  144 */     this.failIfNoMatch = failIfNoMatch;
/*  145 */     this.strict = strict;
/*  146 */     this.replacementFactory = replacementFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MemberSubstitution strict() {
/*  156 */     return new MemberSubstitution(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MemberSubstitution relaxed() {
/*  167 */     return new MemberSubstitution(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WithoutSpecification<Target.ForMember> element(ElementMatcher<? super ByteCodeElement.Member> matcher) {
/*  177 */     return new WithoutSpecification.ForMatchedByteCodeElement(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WithoutSpecification.ForMatchedField field(ElementMatcher<? super FieldDescription> matcher) {
/*  187 */     return new WithoutSpecification.ForMatchedField(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WithoutSpecification.ForMatchedMethod method(ElementMatcher<? super MethodDescription> matcher) {
/*  197 */     return new WithoutSpecification.ForMatchedMethod(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WithoutSpecification<Target.ForMember> constructor(ElementMatcher<? super MethodDescription> matcher) {
/*  207 */     return invokable((ElementMatcher<? super MethodDescription>)ElementMatchers.isConstructor().and(matcher));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WithoutSpecification<Target.ForMember> invokable(ElementMatcher<? super MethodDescription> matcher) {
/*  217 */     return new WithoutSpecification.ForMatchedMethod(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, matcher);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WithoutSpecification.ForMatchedDynamicInvocation lambdaExpression() {
/*  226 */     return dynamic(new LambdaMetaFactoryMatcher());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WithoutSpecification.ForMatchedDynamicInvocation dynamic(ElementMatcher<? super JavaConstant.MethodHandle> matcher) {
/*  236 */     return new WithoutSpecification.ForMatchedDynamicInvocation(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, matcher, 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  242 */         ElementMatchers.any(), 
/*  243 */         ElementMatchers.any(), 
/*  244 */         ElementMatchers.any());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MemberSubstitution with(MethodGraph.Compiler methodGraphCompiler) {
/*  254 */     return new MemberSubstitution(methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MemberSubstitution with(TypePoolResolver typePoolResolver) {
/*  264 */     return new MemberSubstitution(this.methodGraphCompiler, typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MemberSubstitution failIfNoMatch(boolean failIfNoMatch) {
/*  274 */     return new MemberSubstitution(this.methodGraphCompiler, this.typePoolResolver, this.strict, failIfNoMatch, this.replacementFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AsmVisitorWrapper.ForDeclaredMethods on(ElementMatcher<? super MethodDescription> matcher) {
/*  284 */     return (new AsmVisitorWrapper.ForDeclaredMethods()).invokable(matcher, new AsmVisitorWrapper.ForDeclaredMethods.MethodVisitorWrapper[] { this });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MethodVisitor wrap(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, TypePool typePool, int writerFlags, int readerFlags) {
/*  297 */     typePool = this.typePoolResolver.resolve(instrumentedType, instrumentedMethod, typePool);
/*  298 */     return (MethodVisitor)new SubstitutingMethodVisitor(methodVisitor, instrumentedType, instrumentedMethod, this.methodGraphCompiler, this.strict, this.failIfNoMatch, this.replacementFactory
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  304 */         .make(instrumentedType, instrumentedMethod, typePool), implementationContext, typePool, implementationContext
/*      */ 
/*      */         
/*  307 */         .getClassFileVersion().isAtLeast(ClassFileVersion.JAVA_V11));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(@MaybeNull Object paramObject) {
/*      */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : ((this.strict != ((MemberSubstitution)paramObject).strict) ? false : ((this.failIfNoMatch != ((MemberSubstitution)paramObject).failIfNoMatch) ? false : (!this.methodGraphCompiler.equals(((MemberSubstitution)paramObject).methodGraphCompiler) ? false : (!this.typePoolResolver.equals(((MemberSubstitution)paramObject).typePoolResolver) ? false : (!!this.replacementFactory.equals(((MemberSubstitution)paramObject).replacementFactory))))))));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*      */     return ((((getClass().hashCode() * 31 + this.methodGraphCompiler.hashCode()) * 31 + this.typePoolResolver.hashCode()) * 31 + this.strict) * 31 + this.failIfNoMatch) * 31 + this.replacementFactory.hashCode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   public static abstract class WithoutSpecification<T extends Target>
/*      */   {
/*      */     protected final MethodGraph.Compiler methodGraphCompiler;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final MemberSubstitution.TypePoolResolver typePoolResolver;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final boolean strict;
/*      */ 
/*      */ 
/*      */     
/*      */     protected final boolean failIfNoMatch;
/*      */ 
/*      */ 
/*      */     
/*      */     protected final MemberSubstitution.Replacement.Factory replacementFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected WithoutSpecification(MethodGraph.Compiler methodGraphCompiler, MemberSubstitution.TypePoolResolver typePoolResolver, boolean strict, boolean failIfNoMatch, MemberSubstitution.Replacement.Factory replacementFactory) {
/*  357 */       this.methodGraphCompiler = methodGraphCompiler;
/*  358 */       this.typePoolResolver = typePoolResolver;
/*  359 */       this.strict = strict;
/*  360 */       this.failIfNoMatch = failIfNoMatch;
/*  361 */       this.replacementFactory = replacementFactory;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MemberSubstitution stub() {
/*  372 */       return replaceWith(MemberSubstitution.Substitution.Stubbing.INSTANCE);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MemberSubstitution replaceWithConstant(Object value) {
/*  382 */       ConstantValue constant = ConstantValue.Simple.wrap(value);
/*  383 */       return replaceWith(new MemberSubstitution.Substitution.ForValue(constant.toStackManipulation(), constant.getTypeDescription().asGenericType()));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MemberSubstitution replaceWith(Field field) {
/*  401 */       return replaceWith((FieldDescription)new FieldDescription.ForLoadedField(field));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MemberSubstitution replaceWith(FieldDescription fieldDescription) {
/*  419 */       return replaceWith(new MemberSubstitution.Substitution.ForFieldAccess.OfGivenField(fieldDescription));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MemberSubstitution replaceWithField(ElementMatcher<? super FieldDescription> matcher) {
/*  432 */       return replaceWith(new MemberSubstitution.Substitution.ForFieldAccess.OfMatchedField(matcher));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MemberSubstitution replaceWith(Method method) {
/*  450 */       return replaceWith((MethodDescription)new MethodDescription.ForLoadedMethod(method));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MemberSubstitution replaceWith(MethodDescription methodDescription) {
/*  471 */       if (!methodDescription.isMethod()) {
/*  472 */         throw new IllegalArgumentException("Cannot use " + methodDescription + " as a replacement");
/*      */       }
/*  474 */       return replaceWith(new MemberSubstitution.Substitution.ForMethodInvocation.OfGivenMethod(methodDescription));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MemberSubstitution replaceWithMethod(ElementMatcher<? super MethodDescription> matcher) {
/*  487 */       return replaceWithMethod(matcher, this.methodGraphCompiler);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MemberSubstitution replaceWithMethod(ElementMatcher<? super MethodDescription> matcher, MethodGraph.Compiler methodGraphCompiler) {
/*  501 */       return replaceWith(new MemberSubstitution.Substitution.ForMethodInvocation.OfMatchedMethod(matcher, methodGraphCompiler));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MemberSubstitution replaceWithInstrumentedMethod() {
/*  512 */       return replaceWith(MemberSubstitution.Substitution.ForMethodInvocation.OfInstrumentedMethod.INSTANCE);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     @SafeVarargs
/*      */     public final MemberSubstitution replaceWithChain(MemberSubstitution.Substitution.Chain.Step.Factory<? super T>... step) {
/*  525 */       return replaceWithChain(Arrays.asList(step));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MemberSubstitution replaceWithChain(List<? extends MemberSubstitution.Substitution.Chain.Step.Factory<? super T>> steps) {
/*  536 */       return replaceWith(MemberSubstitution.Substitution.Chain.<T>withDefaultAssigner().executing(steps));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract MemberSubstitution replaceWith(MemberSubstitution.Substitution.Factory<? super T> param1Factory);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : ((this.strict != ((WithoutSpecification)param1Object).strict) ? false : ((this.failIfNoMatch != ((WithoutSpecification)param1Object).failIfNoMatch) ? false : (!this.methodGraphCompiler.equals(((WithoutSpecification)param1Object).methodGraphCompiler) ? false : (!this.typePoolResolver.equals(((WithoutSpecification)param1Object).typePoolResolver) ? false : (!!this.replacementFactory.equals(((WithoutSpecification)param1Object).replacementFactory))))))));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return ((((getClass().hashCode() * 31 + this.methodGraphCompiler.hashCode()) * 31 + this.typePoolResolver.hashCode()) * 31 + this.strict) * 31 + this.failIfNoMatch) * 31 + this.replacementFactory.hashCode();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class ForMatchedDynamicInvocation
/*      */       extends WithoutSpecification<MemberSubstitution.Target.ForDynamicInvocation>
/*      */     {
/*      */       private final ElementMatcher<? super JavaConstant.MethodHandle> handleMatcher;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final ElementMatcher.Junction<? super String> nameMatcher;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final ElementMatcher.Junction<? super JavaConstant.MethodType> typeMatcher;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final ElementMatcher.Junction<? super List<? extends JavaConstant>> argumentsMatcher;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected ForMatchedDynamicInvocation(MethodGraph.Compiler methodGraphCompiler, MemberSubstitution.TypePoolResolver typePoolResolver, boolean strict, boolean failIfNoMatch, MemberSubstitution.Replacement.Factory replacementFactory, ElementMatcher<? super JavaConstant.MethodHandle> handleMatcher, ElementMatcher.Junction<? super String> nameMatcher, ElementMatcher.Junction<? super JavaConstant.MethodType> typeMatcher, ElementMatcher.Junction<? super List<? extends JavaConstant>> argumentsMatcher) {
/*  595 */         super(methodGraphCompiler, typePoolResolver, strict, failIfNoMatch, replacementFactory);
/*  596 */         this.handleMatcher = handleMatcher;
/*  597 */         this.nameMatcher = nameMatcher;
/*  598 */         this.typeMatcher = typeMatcher;
/*  599 */         this.argumentsMatcher = argumentsMatcher;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ForMatchedDynamicInvocation withName(ElementMatcher<? super String> nameMatcher) {
/*  609 */         return new ForMatchedDynamicInvocation(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, this.handleMatcher, this.nameMatcher
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  615 */             .and(nameMatcher), this.typeMatcher, this.argumentsMatcher);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ForMatchedDynamicInvocation withType(ElementMatcher<? super JavaConstant.MethodType> typeMatcher) {
/*  627 */         return new ForMatchedDynamicInvocation(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, this.handleMatcher, this.nameMatcher, this.typeMatcher
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  634 */             .and(typeMatcher), this.argumentsMatcher);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ForMatchedDynamicInvocation withArguments(ElementMatcher<? super List<? extends JavaConstant>> argumentsMatcher) {
/*  645 */         return new ForMatchedDynamicInvocation(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, this.handleMatcher, this.nameMatcher, this.typeMatcher, this.argumentsMatcher
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  653 */             .and(argumentsMatcher));
/*      */       }
/*      */ 
/*      */       
/*      */       public MemberSubstitution replaceWith(MemberSubstitution.Substitution.Factory<? super MemberSubstitution.Target.ForDynamicInvocation> substitutionFactory) {
/*  658 */         return new MemberSubstitution(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, new MemberSubstitution.Replacement.Factory.Compound(new MemberSubstitution.Replacement.Factory[] { this.replacementFactory, new MemberSubstitution.Replacement.ForDynamicInvocation.Factory(this.handleMatcher, this.nameMatcher, this.typeMatcher, (ElementMatcher.Junction)this.argumentsMatcher, substitutionFactory) }));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return !super.equals(param2Object) ? false : ((this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.handleMatcher.equals(((ForMatchedDynamicInvocation)param2Object).handleMatcher) ? false : (!this.nameMatcher.equals(((ForMatchedDynamicInvocation)param2Object).nameMatcher) ? false : (!this.typeMatcher.equals(((ForMatchedDynamicInvocation)param2Object).typeMatcher) ? false : (!!this.argumentsMatcher.equals(((ForMatchedDynamicInvocation)param2Object).argumentsMatcher))))))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return (((super.hashCode() * 31 + this.handleMatcher.hashCode()) * 31 + this.nameMatcher.hashCode()) * 31 + this.typeMatcher.hashCode()) * 31 + this.argumentsMatcher.hashCode();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     protected static class ForMatchedByteCodeElement
/*      */       extends WithoutSpecification<MemberSubstitution.Target.ForMember>
/*      */     {
/*      */       private final ElementMatcher<? super ByteCodeElement.Member> matcher;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected ForMatchedByteCodeElement(MethodGraph.Compiler methodGraphCompiler, MemberSubstitution.TypePoolResolver typePoolResolver, boolean strict, boolean failIfNoMatch, MemberSubstitution.Replacement.Factory replacementFactory, ElementMatcher<? super ByteCodeElement.Member> matcher) {
/*  697 */         super(methodGraphCompiler, typePoolResolver, strict, failIfNoMatch, replacementFactory);
/*  698 */         this.matcher = matcher;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution replaceWith(MemberSubstitution.Substitution.Factory<? super MemberSubstitution.Target.ForMember> substitutionFactory) {
/*  705 */         return new MemberSubstitution(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, new MemberSubstitution.Replacement.Factory.Compound(new MemberSubstitution.Replacement.Factory[] { this.replacementFactory, 
/*      */ 
/*      */ 
/*      */                 
/*  709 */                 MemberSubstitution.Replacement.ForElementMatchers.Factory.of(this.matcher, substitutionFactory) }));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return !super.equals(param2Object) ? false : ((this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.matcher.equals(((ForMatchedByteCodeElement)param2Object).matcher)))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return super.hashCode() * 31 + this.matcher.hashCode();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class ForMatchedField
/*      */       extends WithoutSpecification<MemberSubstitution.Target.ForMember>
/*      */     {
/*      */       private final ElementMatcher<? super FieldDescription> matcher;
/*      */ 
/*      */ 
/*      */       
/*      */       private final boolean matchRead;
/*      */ 
/*      */ 
/*      */       
/*      */       private final boolean matchWrite;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected ForMatchedField(MethodGraph.Compiler methodGraphCompiler, MemberSubstitution.TypePoolResolver typePoolResolver, boolean strict, boolean failIfNoMatch, MemberSubstitution.Replacement.Factory replacementFactory, ElementMatcher<? super FieldDescription> matcher) {
/*  750 */         this(methodGraphCompiler, typePoolResolver, strict, failIfNoMatch, replacementFactory, matcher, true, true);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected ForMatchedField(MethodGraph.Compiler methodGraphCompiler, MemberSubstitution.TypePoolResolver typePoolResolver, boolean strict, boolean failIfNoMatch, MemberSubstitution.Replacement.Factory replacementFactory, ElementMatcher<? super FieldDescription> matcher, boolean matchRead, boolean matchWrite) {
/*  773 */         super(methodGraphCompiler, typePoolResolver, strict, failIfNoMatch, replacementFactory);
/*  774 */         this.matcher = matcher;
/*  775 */         this.matchRead = matchRead;
/*  776 */         this.matchWrite = matchWrite;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution.WithoutSpecification<MemberSubstitution.Target.ForMember> onRead() {
/*  785 */         return new ForMatchedField(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, this.matcher, true, false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution.WithoutSpecification<MemberSubstitution.Target.ForMember> onWrite() {
/*  794 */         return new ForMatchedField(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, this.matcher, false, true);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution replaceWith(MemberSubstitution.Substitution.Factory<? super MemberSubstitution.Target.ForMember> substitutionFactory) {
/*  801 */         return new MemberSubstitution(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, new MemberSubstitution.Replacement.Factory.Compound(new MemberSubstitution.Replacement.Factory[] { this.replacementFactory, 
/*      */ 
/*      */ 
/*      */                 
/*  805 */                 MemberSubstitution.Replacement.ForElementMatchers.Factory.ofField(this.matcher, this.matchRead, this.matchWrite, substitutionFactory) }));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return !super.equals(param2Object) ? false : ((this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.matchRead != ((ForMatchedField)param2Object).matchRead) ? false : ((this.matchWrite != ((ForMatchedField)param2Object).matchWrite) ? false : (!!this.matcher.equals(((ForMatchedField)param2Object).matcher)))))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return ((super.hashCode() * 31 + this.matcher.hashCode()) * 31 + this.matchRead) * 31 + this.matchWrite;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class ForMatchedMethod
/*      */       extends WithoutSpecification<MemberSubstitution.Target.ForMember>
/*      */     {
/*      */       private final ElementMatcher<? super MethodDescription> matcher;
/*      */ 
/*      */ 
/*      */       
/*      */       private final boolean includeVirtualCalls;
/*      */ 
/*      */ 
/*      */       
/*      */       private final boolean includeSuperCalls;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected ForMatchedMethod(MethodGraph.Compiler methodGraphCompiler, MemberSubstitution.TypePoolResolver typePoolResolver, boolean strict, boolean failIfNoMatch, MemberSubstitution.Replacement.Factory replacementFactory, ElementMatcher<? super MethodDescription> matcher) {
/*  846 */         this(methodGraphCompiler, typePoolResolver, strict, failIfNoMatch, replacementFactory, matcher, true, true);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected ForMatchedMethod(MethodGraph.Compiler methodGraphCompiler, MemberSubstitution.TypePoolResolver typePoolResolver, boolean strict, boolean failIfNoMatch, MemberSubstitution.Replacement.Factory replacementFactory, ElementMatcher<? super MethodDescription> matcher, boolean includeVirtualCalls, boolean includeSuperCalls) {
/*  869 */         super(methodGraphCompiler, typePoolResolver, strict, failIfNoMatch, replacementFactory);
/*  870 */         this.matcher = matcher;
/*  871 */         this.includeVirtualCalls = includeVirtualCalls;
/*  872 */         this.includeSuperCalls = includeSuperCalls;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution.WithoutSpecification<MemberSubstitution.Target.ForMember> onVirtualCall() {
/*  881 */         return new ForMatchedMethod(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  886 */             (ElementMatcher<? super MethodDescription>)ElementMatchers.isVirtual().and(this.matcher), true, false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution.WithoutSpecification<MemberSubstitution.Target.ForMember> onSuperCall() {
/*  897 */         return new ForMatchedMethod(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  902 */             (ElementMatcher<? super MethodDescription>)ElementMatchers.isVirtual().and(this.matcher), false, true);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution replaceWith(MemberSubstitution.Substitution.Factory<? super MemberSubstitution.Target.ForMember> substitutionFactory)
/*      */       {
/*  911 */         return new MemberSubstitution(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, new MemberSubstitution.Replacement.Factory.Compound(new MemberSubstitution.Replacement.Factory[] { this.replacementFactory, 
/*      */ 
/*      */ 
/*      */                 
/*  915 */                 MemberSubstitution.Replacement.ForElementMatchers.Factory.ofMethod(this.matcher, this.includeVirtualCalls, this.includeSuperCalls, substitutionFactory) })); } public boolean equals(@MaybeNull Object param2Object) { return !super.equals(param2Object) ? false : ((this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.includeVirtualCalls != ((ForMatchedMethod)param2Object).includeVirtualCalls) ? false : ((this.includeSuperCalls != ((ForMatchedMethod)param2Object).includeSuperCalls) ? false : (!!this.matcher.equals(((ForMatchedMethod)param2Object).matcher))))))); } public int hashCode() { return ((super.hashCode() * 31 + this.matcher.hashCode()) * 31 + this.includeVirtualCalls) * 31 + this.includeSuperCalls; } } } @Enhance public static class ForMatchedDynamicInvocation extends WithoutSpecification<Target.ForDynamicInvocation> { private final ElementMatcher<? super JavaConstant.MethodHandle> handleMatcher; private final ElementMatcher.Junction<? super String> nameMatcher; private final ElementMatcher.Junction<? super JavaConstant.MethodType> typeMatcher; private final ElementMatcher.Junction<? super List<? extends JavaConstant>> argumentsMatcher; protected ForMatchedDynamicInvocation(MethodGraph.Compiler methodGraphCompiler, MemberSubstitution.TypePoolResolver typePoolResolver, boolean strict, boolean failIfNoMatch, MemberSubstitution.Replacement.Factory replacementFactory, ElementMatcher<? super JavaConstant.MethodHandle> handleMatcher, ElementMatcher.Junction<? super String> nameMatcher, ElementMatcher.Junction<? super JavaConstant.MethodType> typeMatcher, ElementMatcher.Junction<? super List<? extends JavaConstant>> argumentsMatcher) { super(methodGraphCompiler, typePoolResolver, strict, failIfNoMatch, replacementFactory); this.handleMatcher = handleMatcher; this.nameMatcher = nameMatcher; this.typeMatcher = typeMatcher; this.argumentsMatcher = argumentsMatcher; } public ForMatchedDynamicInvocation withName(ElementMatcher<? super String> nameMatcher) { return new ForMatchedDynamicInvocation(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, this.handleMatcher, this.nameMatcher.and(nameMatcher), this.typeMatcher, this.argumentsMatcher); } public ForMatchedDynamicInvocation withType(ElementMatcher<? super JavaConstant.MethodType> typeMatcher) { return new ForMatchedDynamicInvocation(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, this.handleMatcher, this.nameMatcher, this.typeMatcher.and(typeMatcher), this.argumentsMatcher); } public ForMatchedDynamicInvocation withArguments(ElementMatcher<? super List<? extends JavaConstant>> argumentsMatcher) { return new ForMatchedDynamicInvocation(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, this.handleMatcher, this.nameMatcher, this.typeMatcher, this.argumentsMatcher.and(argumentsMatcher)); } public MemberSubstitution replaceWith(MemberSubstitution.Substitution.Factory<? super MemberSubstitution.Target.ForDynamicInvocation> substitutionFactory) { return new MemberSubstitution(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, new MemberSubstitution.Replacement.Factory.Compound(new MemberSubstitution.Replacement.Factory[] { this.replacementFactory, new MemberSubstitution.Replacement.ForDynamicInvocation.Factory(this.handleMatcher, this.nameMatcher, this.typeMatcher, (ElementMatcher.Junction)this.argumentsMatcher, substitutionFactory) })); } public boolean equals(@MaybeNull Object param1Object) { return !super.equals(param1Object) ? false : ((this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.handleMatcher.equals(((ForMatchedDynamicInvocation)param1Object).handleMatcher) ? false : (!this.nameMatcher.equals(((ForMatchedDynamicInvocation)param1Object).nameMatcher) ? false : (!this.typeMatcher.equals(((ForMatchedDynamicInvocation)param1Object).typeMatcher) ? false : (!!this.argumentsMatcher.equals(((ForMatchedDynamicInvocation)param1Object).argumentsMatcher)))))))); } public int hashCode() { return (((super.hashCode() * 31 + this.handleMatcher.hashCode()) * 31 + this.nameMatcher.hashCode()) * 31 + this.typeMatcher.hashCode()) * 31 + this.argumentsMatcher.hashCode(); } } @Enhance protected static class ForMatchedByteCodeElement extends WithoutSpecification<Target.ForMember> { private final ElementMatcher<? super ByteCodeElement.Member> matcher; protected ForMatchedByteCodeElement(MethodGraph.Compiler methodGraphCompiler, MemberSubstitution.TypePoolResolver typePoolResolver, boolean strict, boolean failIfNoMatch, MemberSubstitution.Replacement.Factory replacementFactory, ElementMatcher<? super ByteCodeElement.Member> matcher) { super(methodGraphCompiler, typePoolResolver, strict, failIfNoMatch, replacementFactory); this.matcher = matcher; } public MemberSubstitution replaceWith(MemberSubstitution.Substitution.Factory<? super MemberSubstitution.Target.ForMember> substitutionFactory) { return new MemberSubstitution(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, new MemberSubstitution.Replacement.Factory.Compound(new MemberSubstitution.Replacement.Factory[] { this.replacementFactory, MemberSubstitution.Replacement.ForElementMatchers.Factory.of(this.matcher, substitutionFactory) })); } public boolean equals(@MaybeNull Object param1Object) { return !super.equals(param1Object) ? false : ((this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.matcher.equals(((ForMatchedByteCodeElement)param1Object).matcher))))); } public int hashCode() { return super.hashCode() * 31 + this.matcher.hashCode(); } } @Enhance public static class ForMatchedField extends WithoutSpecification<Target.ForMember> { private final ElementMatcher<? super FieldDescription> matcher; private final boolean matchRead; private final boolean matchWrite; protected ForMatchedField(MethodGraph.Compiler methodGraphCompiler, MemberSubstitution.TypePoolResolver typePoolResolver, boolean strict, boolean failIfNoMatch, MemberSubstitution.Replacement.Factory replacementFactory, ElementMatcher<? super FieldDescription> matcher) { this(methodGraphCompiler, typePoolResolver, strict, failIfNoMatch, replacementFactory, matcher, true, true); } protected ForMatchedField(MethodGraph.Compiler methodGraphCompiler, MemberSubstitution.TypePoolResolver typePoolResolver, boolean strict, boolean failIfNoMatch, MemberSubstitution.Replacement.Factory replacementFactory, ElementMatcher<? super FieldDescription> matcher, boolean matchRead, boolean matchWrite) { super(methodGraphCompiler, typePoolResolver, strict, failIfNoMatch, replacementFactory); this.matcher = matcher; this.matchRead = matchRead; this.matchWrite = matchWrite; } public MemberSubstitution.WithoutSpecification<MemberSubstitution.Target.ForMember> onRead() { return new ForMatchedField(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, this.matcher, true, false); } public MemberSubstitution.WithoutSpecification<MemberSubstitution.Target.ForMember> onWrite() { return new ForMatchedField(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, this.matcher, false, true); } public MemberSubstitution replaceWith(MemberSubstitution.Substitution.Factory<? super MemberSubstitution.Target.ForMember> substitutionFactory) { return new MemberSubstitution(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, new MemberSubstitution.Replacement.Factory.Compound(new MemberSubstitution.Replacement.Factory[] { this.replacementFactory, MemberSubstitution.Replacement.ForElementMatchers.Factory.ofField(this.matcher, this.matchRead, this.matchWrite, substitutionFactory) })); } public boolean equals(@MaybeNull Object param1Object) { return !super.equals(param1Object) ? false : ((this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : ((this.matchRead != ((ForMatchedField)param1Object).matchRead) ? false : ((this.matchWrite != ((ForMatchedField)param1Object).matchWrite) ? false : (!!this.matcher.equals(((ForMatchedField)param1Object).matcher))))))); } public int hashCode() { return ((super.hashCode() * 31 + this.matcher.hashCode()) * 31 + this.matchRead) * 31 + this.matchWrite; } } @Enhance public static class ForMatchedMethod extends WithoutSpecification<Target.ForMember> { private final ElementMatcher<? super MethodDescription> matcher; private final boolean includeVirtualCalls; private final boolean includeSuperCalls; protected ForMatchedMethod(MethodGraph.Compiler methodGraphCompiler, MemberSubstitution.TypePoolResolver typePoolResolver, boolean strict, boolean failIfNoMatch, MemberSubstitution.Replacement.Factory replacementFactory, ElementMatcher<? super MethodDescription> matcher) { this(methodGraphCompiler, typePoolResolver, strict, failIfNoMatch, replacementFactory, matcher, true, true); } protected ForMatchedMethod(MethodGraph.Compiler methodGraphCompiler, MemberSubstitution.TypePoolResolver typePoolResolver, boolean strict, boolean failIfNoMatch, MemberSubstitution.Replacement.Factory replacementFactory, ElementMatcher<? super MethodDescription> matcher, boolean includeVirtualCalls, boolean includeSuperCalls) { super(methodGraphCompiler, typePoolResolver, strict, failIfNoMatch, replacementFactory); this.matcher = matcher; this.includeVirtualCalls = includeVirtualCalls; this.includeSuperCalls = includeSuperCalls; } public MemberSubstitution.WithoutSpecification<MemberSubstitution.Target.ForMember> onVirtualCall() { return new ForMatchedMethod(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, (ElementMatcher<? super MethodDescription>)ElementMatchers.isVirtual().and(this.matcher), true, false); } public MemberSubstitution.WithoutSpecification<MemberSubstitution.Target.ForMember> onSuperCall() { return new ForMatchedMethod(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, this.replacementFactory, (ElementMatcher<? super MethodDescription>)ElementMatchers.isVirtual().and(this.matcher), false, true); } public MemberSubstitution replaceWith(MemberSubstitution.Substitution.Factory<? super MemberSubstitution.Target.ForMember> substitutionFactory) { return new MemberSubstitution(this.methodGraphCompiler, this.typePoolResolver, this.strict, this.failIfNoMatch, new MemberSubstitution.Replacement.Factory.Compound(new MemberSubstitution.Replacement.Factory[] { this.replacementFactory, MemberSubstitution.Replacement.ForElementMatchers.Factory.ofMethod(this.matcher, this.includeVirtualCalls, this.includeSuperCalls, substitutionFactory) })); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return !super.equals(param1Object) ? false : ((this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : ((this.includeVirtualCalls != ((ForMatchedMethod)param1Object).includeVirtualCalls) ? false : ((this.includeSuperCalls != ((ForMatchedMethod)param1Object).includeSuperCalls) ? false : (!!this.matcher.equals(((ForMatchedMethod)param1Object).matcher)))))));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return ((super.hashCode() * 31 + this.matcher.hashCode()) * 31 + this.includeVirtualCalls) * 31 + this.includeSuperCalls;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum OfImplicitPool
/*      */     implements TypePoolResolver
/*      */   {
/*  943 */     INSTANCE;
/*      */ 
/*      */ 
/*      */     
/*      */     public TypePool resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool)
/*      */     {
/*  949 */       return typePool; } } public static interface TypePoolResolver { TypePool resolve(TypeDescription param1TypeDescription, MethodDescription param1MethodDescription, TypePool param1TypePool); public enum OfImplicitPool implements TypePoolResolver { INSTANCE; public TypePool resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) { return typePool; }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class ForExplicitPool
/*      */       implements TypePoolResolver
/*      */     {
/*      */       private final TypePool typePool;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ForExplicitPool(TypePool typePool) {
/*  970 */         this.typePool = typePool;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypePool resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) {
/*  977 */         return this.typePool;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.typePool.equals(((ForExplicitPool)param2Object).typePool))));
/*      */       }
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return getClass().hashCode() * 31 + this.typePool.hashCode();
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class ForClassFileLocator
/*      */       implements TypePoolResolver
/*      */     {
/*      */       private final ClassFileLocator classFileLocator;
/*      */       
/*      */       private final TypePool.Default.ReaderMode readerMode;
/*      */ 
/*      */       
/*      */       public ForClassFileLocator(ClassFileLocator classFileLocator) {
/* 1003 */         this(classFileLocator, TypePool.Default.ReaderMode.FAST);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ForClassFileLocator(ClassFileLocator classFileLocator, TypePool.Default.ReaderMode readerMode) {
/* 1013 */         this.classFileLocator = classFileLocator;
/* 1014 */         this.readerMode = readerMode;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static MemberSubstitution.TypePoolResolver of(@MaybeNull ClassLoader classLoader) {
/* 1024 */         return new ForClassFileLocator(ClassFileLocator.ForClassLoader.of(classLoader));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public TypePool resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) {
/* 1031 */         return (TypePool)new TypePool.Default((TypePool.CacheProvider)new TypePool.CacheProvider.Simple(), this.classFileLocator, this.readerMode, typePool);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.readerMode.equals(((ForClassFileLocator)param2Object).readerMode) ? false : (!!this.classFileLocator.equals(((ForClassFileLocator)param2Object).classFileLocator)))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return (getClass().hashCode() * 31 + this.classFileLocator.hashCode()) * 31 + this.readerMode.hashCode();
/*      */       }
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ForMember
/*      */     implements Target
/*      */   {
/*      */     private final TypeDescription receiverType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final ByteCodeElement.Member member;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected ForMember(TypeDescription receiverType, ByteCodeElement.Member member) {
/* 1077 */       this.receiverType = receiverType;
/* 1078 */       this.member = member;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getName() {
/* 1085 */       return this.member.getInternalName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isStaticDispatch() {
/* 1092 */       return (this.member.isStatic() || (this.member instanceof MethodDescription && ((MethodDescription)this.member)
/*      */         
/* 1094 */         .isConstructor()));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDescription getReceiverType() {
/* 1103 */       return this.receiverType;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ByteCodeElement.Member getMember()
/*      */     {
/* 1112 */       return this.member; } } public static interface Target { String getName(); boolean isStaticDispatch(); public static class ForMember implements Target { private final TypeDescription receiverType; private final ByteCodeElement.Member member; protected ForMember(TypeDescription receiverType, ByteCodeElement.Member member) { this.receiverType = receiverType; this.member = member; } public String getName() { return this.member.getInternalName(); } public boolean isStaticDispatch() { return (this.member.isStatic() || (this.member instanceof MethodDescription && ((MethodDescription)this.member).isConstructor())); } public TypeDescription getReceiverType() { return this.receiverType; } public ByteCodeElement.Member getMember() { return this.member; }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static class ForDynamicInvocation
/*      */       implements Target
/*      */     {
/*      */       private final JavaConstant.MethodType methodType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final String name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final List<? extends JavaConstant> arguments;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected ForDynamicInvocation(JavaConstant.MethodType methodType, String name, List<? extends JavaConstant> arguments) {
/* 1144 */         this.methodType = methodType;
/* 1145 */         this.name = name;
/* 1146 */         this.arguments = arguments;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean isStaticDispatch() {
/* 1153 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public JavaConstant.MethodType getMethodType() {
/* 1162 */         return this.methodType;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public String getName() {
/* 1169 */         return this.name;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public List<? extends JavaConstant> getArguments() {
/* 1178 */         return this.arguments;
/*      */       }
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface Substitution<T extends Target>
/*      */   {
/*      */     StackManipulation resolve(T param1T, TypeList.Generic param1Generic, TypeDescription.Generic param1Generic1, JavaConstant.MethodHandle param1MethodHandle, StackManipulation param1StackManipulation, int param1Int);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static interface Factory<S extends MemberSubstitution.Target>
/*      */     {
/*      */       MemberSubstitution.Substitution<? super S> make(TypeDescription param2TypeDescription, MethodDescription param2MethodDescription, TypePool param2TypePool);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public enum Stubbing
/*      */       implements Substitution<MemberSubstitution.Target>, Factory<MemberSubstitution.Target>
/*      */     {
/* 1235 */       INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution.Substitution<MemberSubstitution.Target> make(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) {
/* 1241 */         return this;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public StackManipulation resolve(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, JavaConstant.MethodHandle methodHandle, StackManipulation stackManipulation, int freeOffset) {
/* 1253 */         List<StackManipulation> stackManipulations = new ArrayList<StackManipulation>(parameters.size());
/* 1254 */         for (int index = parameters.size() - 1; index >= 0; index--) {
/* 1255 */           stackManipulations.add(Removal.of((TypeDefinition)parameters.get(index)));
/*      */         }
/* 1257 */         return (StackManipulation)new StackManipulation.Compound(CompoundList.of(stackManipulations, DefaultValue.of((TypeDefinition)result.asErasure())));
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class ForValue
/*      */       implements Substitution<MemberSubstitution.Target>, Factory<MemberSubstitution.Target>
/*      */     {
/*      */       private final StackManipulation stackManipulation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final TypeDescription.Generic typeDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public ForValue(StackManipulation stackManipulation, TypeDescription.Generic typeDescription) {
/* 1284 */         this.stackManipulation = stackManipulation;
/* 1285 */         this.typeDescription = typeDescription;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution.Substitution<MemberSubstitution.Target> make(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) {
/* 1292 */         return this;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public StackManipulation resolve(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, JavaConstant.MethodHandle methodHandle, StackManipulation stackManipulation, int freeOffset) {
/* 1304 */         List<StackManipulation> stackManipulations = new ArrayList<StackManipulation>(parameters.size());
/* 1305 */         for (int index = parameters.size() - 1; index >= 0; index--) {
/* 1306 */           stackManipulations.add(Removal.of((TypeDefinition)parameters.get(index)));
/*      */         }
/* 1308 */         if (!this.typeDescription.asErasure().isAssignableTo(result.asErasure())) {
/* 1309 */           throw new IllegalStateException("Cannot assign " + this.typeDescription + " to " + result);
/*      */         }
/* 1311 */         return (StackManipulation)new StackManipulation.Compound(CompoundList.of(stackManipulations, this.stackManipulation));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.stackManipulation.equals(((ForValue)param2Object).stackManipulation) ? false : (!!this.typeDescription.equals(((ForValue)param2Object).typeDescription)))));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return (getClass().hashCode() * 31 + this.stackManipulation.hashCode()) * 31 + this.typeDescription.hashCode();
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class ForFieldAccess
/*      */       implements Substitution<MemberSubstitution.Target>
/*      */     {
/*      */       private final TypeDescription instrumentedType;
/*      */       
/*      */       private final FieldResolver fieldResolver;
/*      */ 
/*      */       
/*      */       public ForFieldAccess(TypeDescription instrumentedType, FieldResolver fieldResolver) {
/* 1338 */         this.instrumentedType = instrumentedType;
/* 1339 */         this.fieldResolver = fieldResolver;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming declaring type for type member.")
/*      */       public StackManipulation resolve(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, JavaConstant.MethodHandle methodHandle, StackManipulation stackManipulation, int freeOffset) {
/* 1352 */         FieldDescription fieldDescription = this.fieldResolver.resolve(target, parameters, result);
/* 1353 */         if (!fieldDescription.isAccessibleTo(this.instrumentedType))
/* 1354 */           throw new IllegalStateException(this.instrumentedType + " cannot access " + fieldDescription); 
/* 1355 */         if (result.represents(void.class)) {
/* 1356 */           if (parameters.size() != (fieldDescription.isStatic() ? 1 : 2))
/* 1357 */             throw new IllegalStateException("Cannot set " + fieldDescription + " with " + parameters); 
/* 1358 */           if (!fieldDescription.isStatic() && !((TypeDescription.Generic)parameters.get(0)).asErasure().isAssignableTo(fieldDescription.getDeclaringType().asErasure()))
/* 1359 */             throw new IllegalStateException("Cannot set " + fieldDescription + " on " + parameters.get(0)); 
/* 1360 */           if (!((TypeDescription.Generic)parameters.get(fieldDescription.isStatic() ? 0 : 1)).asErasure().isAssignableTo(fieldDescription.getType().asErasure())) {
/* 1361 */             throw new IllegalStateException("Cannot set " + fieldDescription + " to " + parameters.get(fieldDescription.isStatic() ? 0 : 1));
/*      */           }
/* 1363 */           return FieldAccess.forField(fieldDescription).write();
/*      */         } 
/* 1365 */         if (parameters.size() != (fieldDescription.isStatic() ? 0 : 1))
/* 1366 */           throw new IllegalStateException("Cannot set " + fieldDescription + " with " + parameters); 
/* 1367 */         if (!fieldDescription.isStatic() && !((TypeDescription.Generic)parameters.get(0)).asErasure().isAssignableTo(fieldDescription.getDeclaringType().asErasure()))
/* 1368 */           throw new IllegalStateException("Cannot get " + fieldDescription + " on " + parameters.get(0)); 
/* 1369 */         if (!fieldDescription.getType().asErasure().isAssignableTo(result.asErasure())) {
/* 1370 */           throw new IllegalStateException("Cannot get " + fieldDescription + " as " + result);
/*      */         }
/* 1372 */         return FieldAccess.forField(fieldDescription).read();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.instrumentedType.equals(((ForFieldAccess)param2Object).instrumentedType) ? false : (!!this.fieldResolver.equals(((ForFieldAccess)param2Object).fieldResolver)))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return (getClass().hashCode() * 31 + this.instrumentedType.hashCode()) * 31 + this.fieldResolver.hashCode();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static interface FieldResolver
/*      */       {
/*      */         FieldDescription resolve(MemberSubstitution.Target param3Target, TypeList.Generic param3Generic, TypeDescription.Generic param3Generic1);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         public static class Simple
/*      */           implements FieldResolver
/*      */         {
/*      */           private final FieldDescription fieldDescription;
/*      */ 
/*      */ 
/*      */           
/*      */           public Simple(FieldDescription fieldDescription) {
/* 1408 */             this.fieldDescription = fieldDescription;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public FieldDescription resolve(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result) {
/* 1415 */             return this.fieldDescription;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.fieldDescription.equals(((Simple)param4Object).fieldDescription))));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return getClass().hashCode() * 31 + this.fieldDescription.hashCode();
/*      */           }
/*      */         }
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         public static class ForElementMatcher
/*      */           implements FieldResolver
/*      */         {
/*      */           private final TypeDescription instrumentedType;
/*      */           
/*      */           private final ElementMatcher<? super FieldDescription> matcher;
/*      */ 
/*      */           
/*      */           protected ForElementMatcher(TypeDescription instrumentedType, ElementMatcher<? super FieldDescription> matcher) {
/* 1442 */             this.instrumentedType = instrumentedType;
/* 1443 */             this.matcher = matcher;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public FieldDescription resolve(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result) {
/* 1450 */             if (parameters.isEmpty())
/* 1451 */               throw new IllegalStateException("Cannot substitute parameterless instruction with " + parameters); 
/* 1452 */             if (((TypeDescription.Generic)parameters.get(0)).isPrimitive() || ((TypeDescription.Generic)parameters.get(0)).isArray()) {
/* 1453 */               throw new IllegalStateException("Cannot access field on primitive or array type for " + parameters.get(0));
/*      */             }
/* 1455 */             TypeDefinition current = (TypeDefinition)((TypeDescription.Generic)parameters.get(0)).accept((TypeDescription.Generic.Visitor)new TypeDescription.Generic.Visitor.Substitutor.ForReplacement(this.instrumentedType));
/*      */             while (true) {
/* 1457 */               FieldList<?> fields = (FieldList)current.getDeclaredFields().filter((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.isStatic()).and((ElementMatcher)ElementMatchers.isVisibleTo(this.instrumentedType)).and(this.matcher));
/* 1458 */               if (fields.size() == 1)
/* 1459 */                 return (FieldDescription)fields.getOnly(); 
/* 1460 */               if (fields.size() > 1) {
/* 1461 */                 throw new IllegalStateException("Ambiguous field location of " + fields);
/*      */               }
/* 1463 */               TypeDescription.Generic generic = current.getSuperClass();
/* 1464 */               if (generic == null) {
/* 1465 */                 throw new IllegalStateException("Cannot locate field matching " + this.matcher + " on " + target);
/*      */               }
/*      */             } 
/*      */           }
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.instrumentedType.equals(((ForElementMatcher)param4Object).instrumentedType) ? false : (!!this.matcher.equals(((ForElementMatcher)param4Object).matcher)))));
/*      */           }
/*      */           
/*      */           public int hashCode() {
/*      */             return (getClass().hashCode() * 31 + this.instrumentedType.hashCode()) * 31 + this.matcher.hashCode();
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */       @Enhance
/*      */       public static class OfGivenField
/*      */         implements MemberSubstitution.Substitution.Factory<MemberSubstitution.Target>
/*      */       {
/*      */         private final FieldDescription fieldDescription;
/*      */         
/*      */         public OfGivenField(FieldDescription fieldDescription) {
/* 1487 */           this.fieldDescription = fieldDescription;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public MemberSubstitution.Substitution<MemberSubstitution.Target> make(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) {
/* 1494 */           return new MemberSubstitution.Substitution.ForFieldAccess(instrumentedType, new MemberSubstitution.Substitution.ForFieldAccess.FieldResolver.Simple(this.fieldDescription));
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.fieldDescription.equals(((OfGivenField)param3Object).fieldDescription))));
/*      */         }
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return getClass().hashCode() * 31 + this.fieldDescription.hashCode();
/*      */         }
/*      */       }
/*      */       
/*      */       @Enhance
/*      */       public static class OfMatchedField
/*      */         implements MemberSubstitution.Substitution.Factory<MemberSubstitution.Target>
/*      */       {
/*      */         private final ElementMatcher<? super FieldDescription> matcher;
/*      */         
/*      */         public OfMatchedField(ElementMatcher<? super FieldDescription> matcher) {
/* 1515 */           this.matcher = matcher;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public MemberSubstitution.Substitution<MemberSubstitution.Target> make(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) {
/* 1522 */           return new MemberSubstitution.Substitution.ForFieldAccess(instrumentedType, new MemberSubstitution.Substitution.ForFieldAccess.FieldResolver.ForElementMatcher(instrumentedType, this.matcher));
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.matcher.equals(((OfMatchedField)param3Object).matcher))));
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return getClass().hashCode() * 31 + this.matcher.hashCode();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class ForMethodInvocation
/*      */       implements Substitution<MemberSubstitution.Target>
/*      */     {
/*      */       private final TypeDescription instrumentedType;
/*      */       
/*      */       private final MethodResolver methodResolver;
/*      */ 
/*      */       
/*      */       public ForMethodInvocation(TypeDescription instrumentedType, MethodResolver methodResolver) {
/* 1550 */         this.instrumentedType = instrumentedType;
/* 1551 */         this.methodResolver = methodResolver;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public StackManipulation resolve(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, JavaConstant.MethodHandle methodHandle, StackManipulation stackManipulation, int freeOffset) {
/* 1563 */         MethodDescription methodDescription = this.methodResolver.resolve(target, parameters, result);
/* 1564 */         if (!methodDescription.isAccessibleTo(this.instrumentedType)) {
/* 1565 */           throw new IllegalStateException(this.instrumentedType + " cannot access " + methodDescription);
/*      */         }
/*      */ 
/*      */         
/* 1569 */         TypeList.Generic mapped = methodDescription.isStatic() ? methodDescription.getParameters().asTypeList() : (TypeList.Generic)new TypeList.Generic.Explicit(CompoundList.of(methodDescription.getDeclaringType(), (List)methodDescription.getParameters().asTypeList()));
/* 1570 */         if (!methodDescription.getReturnType().asErasure().isAssignableTo(result.asErasure()))
/* 1571 */           throw new IllegalStateException("Cannot assign return value of " + methodDescription + " to " + result); 
/* 1572 */         if (mapped.size() != parameters.size()) {
/* 1573 */           throw new IllegalStateException("Cannot invoke " + methodDescription + " on " + parameters.size() + " parameters");
/*      */         }
/* 1575 */         for (int index = 0; index < mapped.size(); index++) {
/* 1576 */           if (!((TypeDescription.Generic)parameters.get(index)).asErasure().isAssignableTo(((TypeDescription.Generic)mapped.get(index)).asErasure())) {
/* 1577 */             throw new IllegalStateException("Cannot invoke " + methodDescription + " on parameter " + index + " of type " + parameters.get(index));
/*      */           }
/*      */         } 
/* 1580 */         return methodDescription.isVirtual() ? MethodInvocation.invoke(methodDescription).virtual(((TypeDescription.Generic)mapped.get(0)).asErasure()) : (StackManipulation)MethodInvocation.invoke(methodDescription);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.instrumentedType.equals(((ForMethodInvocation)param2Object).instrumentedType) ? false : (!!this.methodResolver.equals(((ForMethodInvocation)param2Object).methodResolver)))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return (getClass().hashCode() * 31 + this.instrumentedType.hashCode()) * 31 + this.methodResolver.hashCode();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static interface MethodResolver
/*      */       {
/*      */         MethodDescription resolve(MemberSubstitution.Target param3Target, TypeList.Generic param3Generic, TypeDescription.Generic param3Generic1);
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         public static class Simple
/*      */           implements MethodResolver
/*      */         {
/*      */           private final MethodDescription methodDescription;
/*      */ 
/*      */ 
/*      */           
/*      */           public Simple(MethodDescription methodDescription) {
/* 1615 */             this.methodDescription = methodDescription;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MethodDescription resolve(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result) {
/* 1622 */             return this.methodDescription;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.methodDescription.equals(((Simple)param4Object).methodDescription))));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return getClass().hashCode() * 31 + this.methodDescription.hashCode();
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         public static class Matching
/*      */           implements MethodResolver
/*      */         {
/*      */           private final TypeDescription instrumentedType;
/*      */ 
/*      */           
/*      */           private final MethodGraph.Compiler methodGraphCompiler;
/*      */ 
/*      */           
/*      */           private final ElementMatcher<? super MethodDescription> matcher;
/*      */ 
/*      */ 
/*      */           
/*      */           public Matching(TypeDescription instrumentedType, MethodGraph.Compiler methodGraphCompiler, ElementMatcher<? super MethodDescription> matcher) {
/* 1655 */             this.instrumentedType = instrumentedType;
/* 1656 */             this.methodGraphCompiler = methodGraphCompiler;
/* 1657 */             this.matcher = matcher;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MethodDescription resolve(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result) {
/* 1664 */             if (parameters.isEmpty())
/* 1665 */               throw new IllegalStateException("Cannot substitute parameterless instruction with " + parameters); 
/* 1666 */             if (((TypeDescription.Generic)parameters.get(0)).isPrimitive() || ((TypeDescription.Generic)parameters.get(0)).isArray()) {
/* 1667 */               throw new IllegalStateException("Cannot invoke method on primitive or array type for " + parameters.get(0));
/*      */             }
/* 1669 */             TypeDefinition typeDefinition = (TypeDefinition)((TypeDescription.Generic)parameters.get(0)).accept((TypeDescription.Generic.Visitor)new TypeDescription.Generic.Visitor.Substitutor.ForReplacement(this.instrumentedType));
/* 1670 */             List<MethodDescription> candidates = CompoundList.of((List)this.methodGraphCompiler.compile(typeDefinition, this.instrumentedType).listNodes()
/* 1671 */                 .asMethodList()
/* 1672 */                 .filter(this.matcher), (List)typeDefinition.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isPrivate().and((ElementMatcher)ElementMatchers.isVisibleTo(this.instrumentedType)).and(this.matcher)));
/* 1673 */             if (candidates.size() == 1) {
/* 1674 */               return candidates.get(0);
/*      */             }
/* 1676 */             throw new IllegalStateException("Not exactly one method that matches " + this.matcher + ": " + candidates);
/*      */           }
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.instrumentedType.equals(((Matching)param4Object).instrumentedType) ? false : (!this.methodGraphCompiler.equals(((Matching)param4Object).methodGraphCompiler) ? false : (!!this.matcher.equals(((Matching)param4Object).matcher))))));
/*      */           }
/*      */           
/*      */           public int hashCode() {
/*      */             return ((getClass().hashCode() * 31 + this.instrumentedType.hashCode()) * 31 + this.methodGraphCompiler.hashCode()) * 31 + this.matcher.hashCode();
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */       enum OfInstrumentedMethod implements MemberSubstitution.Substitution.Factory<MemberSubstitution.Target> {
/* 1690 */         INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public MemberSubstitution.Substitution<MemberSubstitution.Target> make(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) {
/* 1696 */           return new MemberSubstitution.Substitution.ForMethodInvocation(instrumentedType, new MemberSubstitution.Substitution.ForMethodInvocation.MethodResolver.Simple(instrumentedMethod));
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static class OfGivenMethod
/*      */         implements MemberSubstitution.Substitution.Factory<MemberSubstitution.Target>
/*      */       {
/*      */         private final MethodDescription methodDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public OfGivenMethod(MethodDescription methodDescription) {
/* 1717 */           this.methodDescription = methodDescription;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public MemberSubstitution.Substitution<MemberSubstitution.Target> make(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) {
/* 1724 */           return new MemberSubstitution.Substitution.ForMethodInvocation(instrumentedType, new MemberSubstitution.Substitution.ForMethodInvocation.MethodResolver.Simple(this.methodDescription));
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.methodDescription.equals(((OfGivenMethod)param3Object).methodDescription))));
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return getClass().hashCode() * 31 + this.methodDescription.hashCode();
/*      */         }
/*      */       }
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static class OfMatchedMethod
/*      */         implements MemberSubstitution.Substitution.Factory<MemberSubstitution.Target>
/*      */       {
/*      */         private final ElementMatcher<? super MethodDescription> matcher;
/*      */         
/*      */         private final MethodGraph.Compiler methodGraphCompiler;
/*      */ 
/*      */         
/*      */         public OfMatchedMethod(ElementMatcher<? super MethodDescription> matcher, MethodGraph.Compiler methodGraphCompiler) {
/* 1751 */           this.matcher = matcher;
/* 1752 */           this.methodGraphCompiler = methodGraphCompiler;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public MemberSubstitution.Substitution<MemberSubstitution.Target> make(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) {
/* 1759 */           return new MemberSubstitution.Substitution.ForMethodInvocation(instrumentedType, new MemberSubstitution.Substitution.ForMethodInvocation.MethodResolver.Matching(instrumentedType, this.methodGraphCompiler, this.matcher));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.matcher.equals(((OfMatchedMethod)param3Object).matcher) ? false : (!!this.methodGraphCompiler.equals(((OfMatchedMethod)param3Object).methodGraphCompiler)))));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return (getClass().hashCode() * 31 + this.matcher.hashCode()) * 31 + this.methodGraphCompiler.hashCode();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class Chain<S extends MemberSubstitution.Target>
/*      */       implements Substitution<S>
/*      */     {
/*      */       private final Assigner assigner;
/*      */ 
/*      */       
/*      */       private final Assigner.Typing typing;
/*      */ 
/*      */       
/*      */       private final List<Step<? super S>> steps;
/*      */ 
/*      */ 
/*      */       
/*      */       protected Chain(Assigner assigner, Assigner.Typing typing, List<Step<? super S>> steps) {
/* 1795 */         this.assigner = assigner;
/* 1796 */         this.typing = typing;
/* 1797 */         this.steps = steps;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static <U extends MemberSubstitution.Target> Factory<U> withDefaultAssigner() {
/* 1807 */         return with(Assigner.DEFAULT, Assigner.Typing.STATIC);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static <U extends MemberSubstitution.Target> Factory<U> with(Assigner assigner, Assigner.Typing typing) {
/* 1819 */         return new Factory<U>(assigner, typing, Collections.emptyList());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public StackManipulation resolve(S target, TypeList.Generic parameters, TypeDescription.Generic result, JavaConstant.MethodHandle methodHandle, StackManipulation stackManipulation, int freeOffset) {
/* 1833 */         List<StackManipulation> stackManipulations = new ArrayList<StackManipulation>(1 + parameters.size() + this.steps.size() * 2 + (result.represents(void.class) ? 0 : 2));
/* 1834 */         Map<Integer, Integer> offsets = new HashMap<Integer, Integer>();
/* 1835 */         for (int index = parameters.size() - 1; index >= 0; index--) {
/* 1836 */           stackManipulations.add(MethodVariableAccess.of((TypeDefinition)parameters.get(index)).storeAt(freeOffset));
/* 1837 */           offsets.put(Integer.valueOf(index), Integer.valueOf(freeOffset));
/* 1838 */           freeOffset += ((TypeDescription.Generic)parameters.get(index)).getStackSize().getSize();
/*      */         } 
/* 1840 */         stackManipulations.add(DefaultValue.of((TypeDefinition)result));
/* 1841 */         TypeDescription.Generic current = result;
/* 1842 */         for (Step<? super S> step : this.steps) {
/* 1843 */           Step.Resolution resolution = step.resolve(target, parameters, result, methodHandle, stackManipulation, current, offsets, freeOffset);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1851 */           stackManipulations.add(resolution.getStackManipulation());
/* 1852 */           current = resolution.getResultType();
/*      */         } 
/* 1854 */         StackManipulation assignment = this.assigner.assign(current, result, this.typing);
/* 1855 */         if (!assignment.isValid()) {
/* 1856 */           throw new IllegalStateException("Failed to assign " + current + " to " + result);
/*      */         }
/* 1858 */         stackManipulations.add(assignment);
/* 1859 */         return (StackManipulation)new StackManipulation.Compound(stackManipulations);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.typing.equals(((Chain)param2Object).typing) ? false : (!this.assigner.equals(((Chain)param2Object).assigner) ? false : (!!this.steps.equals(((Chain)param2Object).steps))))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return ((getClass().hashCode() * 31 + this.assigner.hashCode()) * 31 + this.typing.hashCode()) * 31 + this.steps.hashCode();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static interface Resolution
/*      */       {
/*      */         StackManipulation getStackManipulation();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         TypeDescription.Generic getResultType();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public static interface Step<U extends MemberSubstitution.Target>
/*      */       {
/*      */         Resolution resolve(U param3U, TypeList.Generic param3Generic, TypeDescription.Generic param3Generic1, JavaConstant.MethodHandle param3MethodHandle, StackManipulation param3StackManipulation, TypeDescription.Generic param3Generic2, Map<Integer, Integer> param3Map, int param3Int);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public static interface Resolution
/*      */         {
/*      */           StackManipulation getStackManipulation();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           TypeDescription.Generic getResultType();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public static interface Factory<V extends MemberSubstitution.Target>
/*      */         {
/*      */           MemberSubstitution.Substitution.Chain.Step<V> make(Assigner param4Assigner, Assigner.Typing param4Typing, TypeDescription param4TypeDescription, MethodDescription param4MethodDescription);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public enum OfOriginalExpression
/*      */           implements Step<MemberSubstitution.Target>, Factory<MemberSubstitution.Target>
/*      */         {
/* 1938 */           INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MemberSubstitution.Substitution.Chain.Step.Resolution resolve(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, JavaConstant.MethodHandle methodHandle, StackManipulation stackManipulation, TypeDescription.Generic current, Map<Integer, Integer> offsets, int freeOffset) {
/* 1952 */             if (target instanceof MemberSubstitution.Target.ForMember) {
/* 1953 */               List<StackManipulation> stackManipulations; ByteCodeElement.Member member = ((MemberSubstitution.Target.ForMember)target).getMember();
/* 1954 */               if (member instanceof MethodDescription && ((MethodDescription)member).isConstructor()) {
/* 1955 */                 stackManipulations = new ArrayList<StackManipulation>(parameters.size() + 4);
/* 1956 */                 stackManipulations.add(Removal.of((TypeDefinition)current));
/* 1957 */                 stackManipulations.add(TypeCreation.of(member.getDeclaringType().asErasure()));
/* 1958 */                 stackManipulations.add(Duplication.SINGLE);
/*      */               } else {
/* 1960 */                 stackManipulations = new ArrayList<StackManipulation>(parameters.size() + 4);
/* 1961 */                 stackManipulations.add(Removal.of((TypeDefinition)current));
/*      */               } 
/* 1963 */               for (int index = 0; index < parameters.size(); index++) {
/* 1964 */                 stackManipulations.add(MethodVariableAccess.of((TypeDefinition)parameters.get(index)).loadFrom(((Integer)offsets.get(Integer.valueOf(index))).intValue()));
/*      */               }
/* 1966 */               if (member instanceof MethodDescription) {
/* 1967 */                 stackManipulations.add(stackManipulation);
/* 1968 */                 return new MemberSubstitution.Substitution.Chain.Step.Simple((StackManipulation)new StackManipulation.Compound(stackManipulations), ((MethodDescription)member).isConstructor() ? member
/* 1969 */                     .getDeclaringType().asGenericType() : ((MethodDescription)member)
/* 1970 */                     .getReturnType());
/* 1971 */               }  if (member instanceof FieldDescription) {
/* 1972 */                 if (member.isStatic()) {
/* 1973 */                   if (parameters.isEmpty()) {
/* 1974 */                     stackManipulations.add(stackManipulation);
/* 1975 */                     return new MemberSubstitution.Substitution.Chain.Step.Simple((StackManipulation)new StackManipulation.Compound(stackManipulations), ((FieldDescription)member).getType());
/*      */                   } 
/* 1977 */                   stackManipulations.add(stackManipulation);
/* 1978 */                   return new MemberSubstitution.Substitution.Chain.Step.Simple((StackManipulation)new StackManipulation.Compound(stackManipulations), TypeDefinition.Sort.describe(void.class));
/*      */                 } 
/*      */                 
/* 1981 */                 if (parameters.size() == 1) {
/* 1982 */                   stackManipulations.add(FieldAccess.forField((FieldDescription)member).read());
/* 1983 */                   return new MemberSubstitution.Substitution.Chain.Step.Simple((StackManipulation)new StackManipulation.Compound(stackManipulations), ((FieldDescription)member).getType());
/*      */                 } 
/* 1985 */                 stackManipulations.add(FieldAccess.forField((FieldDescription)member).write());
/* 1986 */                 return new MemberSubstitution.Substitution.Chain.Step.Simple((StackManipulation)new StackManipulation.Compound(stackManipulations), TypeDefinition.Sort.describe(void.class));
/*      */               } 
/*      */ 
/*      */               
/* 1990 */               throw new IllegalStateException("Unexpected member: " + member);
/*      */             } 
/* 1992 */             if (target instanceof MemberSubstitution.Target.ForDynamicInvocation) {
/* 1993 */               List<StackManipulation> stackManipulations = new ArrayList<StackManipulation>(parameters.size() + 4);
/* 1994 */               stackManipulations.add(Removal.of((TypeDefinition)current));
/* 1995 */               for (int index = 0; index < parameters.size(); index++) {
/* 1996 */                 stackManipulations.add(MethodVariableAccess.of((TypeDefinition)parameters.get(index)).loadFrom(((Integer)offsets.get(Integer.valueOf(index))).intValue()));
/*      */               }
/* 1998 */               stackManipulations.add(stackManipulation);
/* 1999 */               return new MemberSubstitution.Substitution.Chain.Step.Simple((StackManipulation)new StackManipulation.Compound(stackManipulations), ((MemberSubstitution.Target.ForDynamicInvocation)target).getMethodType().getReturnType().asGenericType());
/*      */             } 
/* 2001 */             throw new IllegalStateException("Unexpected target: " + target);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MemberSubstitution.Substitution.Chain.Step<MemberSubstitution.Target> make(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 2009 */             return this;
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         public static class Simple
/*      */           implements Step<MemberSubstitution.Target>, Factory<MemberSubstitution.Target>, Resolution
/*      */         {
/*      */           private final StackManipulation stackManipulation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private final TypeDescription.Generic resultType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Simple(StackManipulation stackManipulation, Type resultType) {
/* 2036 */             this(stackManipulation, TypeDefinition.Sort.describe(resultType));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public Simple(StackManipulation stackManipulation, TypeDescription.Generic resultType) {
/* 2046 */             this.stackManipulation = stackManipulation;
/* 2047 */             this.resultType = resultType;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> of(Object value) {
/* 2057 */             ConstantValue constant = ConstantValue.Simple.wrap(value);
/* 2058 */             return new Simple(constant.toStackManipulation(), constant.getTypeDescription().asGenericType());
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MemberSubstitution.Substitution.Chain.Step<MemberSubstitution.Target> make(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 2065 */             return this;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MemberSubstitution.Substitution.Chain.Step.Resolution resolve(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, JavaConstant.MethodHandle methodHandle, StackManipulation stackManipulation, TypeDescription.Generic current, Map<Integer, Integer> offsets, int freeOffset) {
/* 2079 */             return current.represents(void.class) ? this : new Simple((StackManipulation)new StackManipulation.Compound(new StackManipulation[] {
/*      */                     
/* 2081 */                     Removal.of((TypeDefinition)current), this.stackManipulation }, ), this.resultType);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public StackManipulation getStackManipulation() {
/* 2088 */             return this.stackManipulation;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public TypeDescription.Generic getResultType() {
/* 2095 */             return this.resultType;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.stackManipulation.equals(((Simple)param4Object).stackManipulation) ? false : (!!this.resultType.equals(((Simple)param4Object).resultType)))));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return (getClass().hashCode() * 31 + this.stackManipulation.hashCode()) * 31 + this.resultType.hashCode();
/*      */           }
/*      */         }
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         public static class ForAssignment
/*      */           implements Step<MemberSubstitution.Target>
/*      */         {
/*      */           @MaybeNull
/*      */           @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*      */           private final TypeDescription.Generic result;
/*      */           
/*      */           private final Assigner assigner;
/*      */ 
/*      */           
/*      */           protected ForAssignment(@MaybeNull TypeDescription.Generic result, Assigner assigner) {
/* 2124 */             this.result = result;
/* 2125 */             this.assigner = assigner;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> castTo(Type type) {
/* 2135 */             return new Factory(TypeDefinition.Sort.describe(type));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> castTo(TypeDescription.Generic typeDescription) {
/* 2145 */             return new Factory(typeDescription);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> castToSubstitutionResult() {
/* 2154 */             return new Factory(null);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MemberSubstitution.Substitution.Chain.Step.Resolution resolve(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, JavaConstant.MethodHandle methodHandle, StackManipulation stackManipulation, TypeDescription.Generic current, Map<Integer, Integer> offsets, int freeOffset) {
/* 2168 */             StackManipulation assignment = this.assigner.assign(current, (this.result == null) ? result : this.result, Assigner.Typing.DYNAMIC);
/* 2169 */             if (!assignment.isValid()) {
/* 2170 */               throw new IllegalStateException("Failed to assign " + current + " to " + ((this.result == null) ? result : this.result));
/*      */             }
/* 2172 */             return new MemberSubstitution.Substitution.Chain.Step.Simple(assignment, (this.result == null) ? result : this.result);
/*      */           } public boolean equals(@MaybeNull Object param4Object) { if (this == param4Object)
/*      */               return true; 
/*      */             if (param4Object == null)
/*      */               return false; 
/*      */             if (getClass() != param4Object.getClass())
/*      */               return false; 
/*      */             TypeDescription.Generic generic1 = ((ForAssignment)param4Object).result;
/*      */             TypeDescription.Generic generic2 = this.result;
/*      */             if (generic1 != null) {
/*      */               if (generic2 != null) {
/*      */                 if (!generic2.equals(generic1))
/*      */                   return false; 
/*      */               } else {
/*      */                 return false;
/*      */               } 
/*      */             } else if (generic2 != null) {
/*      */               return false;
/*      */             } 
/*      */             return !!this.assigner.equals(((ForAssignment)param4Object).assigner); } public int hashCode() { TypeDescription.Generic generic = this.result;
/*      */             if (generic != null);
/*      */             return (getClass().hashCode() * 31 + generic.hashCode()) * 31 + this.assigner.hashCode(); } @Enhance protected static class Factory implements MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> { @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) private final TypeDescription.Generic result;
/* 2194 */             protected Factory(@MaybeNull TypeDescription.Generic result) { this.result = result; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step<MemberSubstitution.Target> make(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 2201 */               return new MemberSubstitution.Substitution.Chain.Step.ForAssignment(this.result, assigner);
/*      */             }
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               if (this == param5Object) {
/*      */                 return true;
/*      */               }
/*      */               if (param5Object == null) {
/*      */                 return false;
/*      */               }
/*      */               if (getClass() != param5Object.getClass())
/*      */                 return false; 
/*      */               TypeDescription.Generic generic1 = ((Factory)param5Object).result;
/*      */               TypeDescription.Generic generic2 = this.result;
/*      */               if (generic1 != null) {
/*      */                 if (generic2 != null) {
/*      */                   if (!generic2.equals(generic1))
/*      */                     return false; 
/*      */                 } else {
/*      */                   return false;
/*      */                 } 
/*      */               } else if (generic2 != null) {
/*      */                 return false;
/*      */               } 
/*      */               return true;
/*      */             }
/*      */             
/*      */             public int hashCode() {
/*      */               TypeDescription.Generic generic = this.result;
/*      */               if (generic != null);
/*      */               return getClass().hashCode() * 31 + generic.hashCode();
/*      */             } }
/*      */         
/*      */         }
/*      */         
/*      */         @Enhance
/*      */         public static class ForArgumentSubstitution
/*      */           implements Step<MemberSubstitution.Target>
/*      */         {
/*      */           private final StackManipulation substitution;
/*      */           private final TypeDescription.Generic typeDescription;
/*      */           private final int index;
/*      */           private final Assigner assigner;
/*      */           private final Assigner.Typing typing;
/*      */           
/*      */           protected ForArgumentSubstitution(StackManipulation substitution, TypeDescription.Generic typeDescription, int index, Assigner assigner, Assigner.Typing typing) {
/* 2247 */             this.substitution = substitution;
/* 2248 */             this.typeDescription = typeDescription;
/* 2249 */             this.index = index;
/* 2250 */             this.assigner = assigner;
/* 2251 */             this.typing = typing;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> of(Object value, int index) {
/* 2262 */             if (index < 0) {
/* 2263 */               throw new IllegalArgumentException("Index cannot be negative: " + index);
/*      */             }
/* 2265 */             ConstantValue constant = ConstantValue.Simple.wrap(value);
/* 2266 */             return new Factory(constant.toStackManipulation(), constant.getTypeDescription().asGenericType(), index);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MemberSubstitution.Substitution.Chain.Step.Resolution resolve(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, JavaConstant.MethodHandle methodHandle, StackManipulation stackManipulation, TypeDescription.Generic current, Map<Integer, Integer> offsets, int freeOffset) {
/* 2280 */             if (this.index >= parameters.size()) {
/* 2281 */               throw new IllegalStateException(target + " has not " + this.index + " arguments");
/*      */             }
/* 2283 */             StackManipulation assignment = this.assigner.assign(this.typeDescription, (TypeDescription.Generic)parameters.get(this.index), this.typing);
/* 2284 */             if (!assignment.isValid()) {
/* 2285 */               throw new IllegalStateException("Cannot assign " + this.typeDescription + " to " + parameters.get(this.index));
/*      */             }
/* 2287 */             return new MemberSubstitution.Substitution.Chain.Step.Simple((StackManipulation)new StackManipulation.Compound(new StackManipulation[] { this.substitution, assignment, MethodVariableAccess.of((TypeDefinition)parameters.get(this.index)).storeAt(((Integer)offsets.get(Integer.valueOf(this.index))).intValue()) }, ), current);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : ((this.index != ((ForArgumentSubstitution)param4Object).index) ? false : (!this.typing.equals(((ForArgumentSubstitution)param4Object).typing) ? false : (!this.substitution.equals(((ForArgumentSubstitution)param4Object).substitution) ? false : (!this.typeDescription.equals(((ForArgumentSubstitution)param4Object).typeDescription) ? false : (!!this.assigner.equals(((ForArgumentSubstitution)param4Object).assigner))))))));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return ((((getClass().hashCode() * 31 + this.substitution.hashCode()) * 31 + this.typeDescription.hashCode()) * 31 + this.index) * 31 + this.assigner.hashCode()) * 31 + this.typing.hashCode();
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           @Enhance
/*      */           public static class Factory
/*      */             implements MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target>
/*      */           {
/*      */             private final StackManipulation stackManipulation;
/*      */ 
/*      */             
/*      */             private final TypeDescription.Generic typeDescription;
/*      */ 
/*      */             
/*      */             private final int index;
/*      */ 
/*      */ 
/*      */             
/*      */             public Factory(StackManipulation stackManipulation, Type type, int index) {
/* 2319 */               this(stackManipulation, TypeDefinition.Sort.describe(type), index);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public Factory(StackManipulation stackManipulation, TypeDescription.Generic typeDescription, int index) {
/* 2330 */               this.stackManipulation = stackManipulation;
/* 2331 */               this.typeDescription = typeDescription;
/* 2332 */               this.index = index;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step<MemberSubstitution.Target> make(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 2339 */               return new MemberSubstitution.Substitution.Chain.Step.ForArgumentSubstitution(this.stackManipulation, this.typeDescription, this.index, assigner, typing);
/*      */             }
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : ((this.index != ((Factory)param5Object).index) ? false : (!this.stackManipulation.equals(((Factory)param5Object).stackManipulation) ? false : (!!this.typeDescription.equals(((Factory)param5Object).typeDescription))))));
/*      */             }
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               return ((getClass().hashCode() * 31 + this.stackManipulation.hashCode()) * 31 + this.typeDescription.hashCode()) * 31 + this.index;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */         @Enhance
/*      */         public static class ForArgumentLoading
/*      */           implements Step<MemberSubstitution.Target>, Factory<MemberSubstitution.Target>
/*      */         {
/*      */           private final int index;
/*      */           
/*      */           protected ForArgumentLoading(int index) {
/* 2361 */             this.index = index;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> ofTarget(int index) {
/* 2371 */             if (index < 0) {
/* 2372 */               throw new IllegalArgumentException("Argument index cannot be negative: " + index);
/*      */             }
/* 2374 */             return new ForArgumentLoading(index);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> ofInstrumentedMethod(int index) {
/* 2384 */             if (index < 0) {
/* 2385 */               throw new IllegalArgumentException("Argument index cannot be negative: " + index);
/*      */             }
/* 2387 */             return new OfInstrumentedMethod(index);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> ofThis() {
/* 2396 */             return OfInstrumentedMethodThis.INSTANCE;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MemberSubstitution.Substitution.Chain.Step<MemberSubstitution.Target> make(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 2403 */             return this;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MemberSubstitution.Substitution.Chain.Step.Resolution resolve(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, JavaConstant.MethodHandle methodHandle, StackManipulation stackManipulation, TypeDescription.Generic current, Map<Integer, Integer> offsets, int freeOffset) {
/* 2417 */             if (this.index >= parameters.size()) {
/* 2418 */               throw new IllegalStateException(target + " has not " + this.index + " arguments");
/*      */             }
/* 2420 */             return new MemberSubstitution.Substitution.Chain.Step.Simple((StackManipulation)new StackManipulation.Compound(new StackManipulation[] { Removal.of((TypeDefinition)current), MethodVariableAccess.of((TypeDefinition)parameters.get(this.index)).loadFrom(((Integer)offsets.get(Integer.valueOf(this.index))).intValue()) }, ), (TypeDescription.Generic)parameters.get(this.index));
/*      */           }
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!(this.index != ((ForArgumentLoading)param4Object).index))));
/*      */           }
/*      */           
/*      */           public int hashCode() {
/*      */             return getClass().hashCode() * 31 + this.index;
/*      */           }
/*      */           
/* 2431 */           protected enum OfInstrumentedMethodThis implements MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> { INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step<MemberSubstitution.Target> make(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 2440 */               if (instrumentedMethod.isStatic()) {
/* 2441 */                 throw new IllegalStateException(instrumentedMethod + " is static and does not define a this reference");
/*      */               }
/* 2443 */               return new MemberSubstitution.Substitution.Chain.Step.Simple(MethodVariableAccess.loadThis(), instrumentedType.asGenericType());
/*      */             } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @Enhance
/*      */           protected static class OfInstrumentedMethod
/*      */             implements MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target>
/*      */           {
/*      */             private final int index;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected OfInstrumentedMethod(int index) {
/* 2464 */               this.index = index;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step<MemberSubstitution.Target> make(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 2474 */               if (instrumentedMethod.getParameters().size() < this.index) {
/* 2475 */                 throw new IllegalStateException(instrumentedMethod + " does not declare " + this.index + " parameters");
/*      */               }
/* 2477 */               ParameterDescription parameterDescription = (ParameterDescription)instrumentedMethod.getParameters().get(this.index);
/* 2478 */               return new MemberSubstitution.Substitution.Chain.Step.Simple(MethodVariableAccess.load(parameterDescription), parameterDescription.getType());
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!(this.index != ((OfInstrumentedMethod)param5Object).index))));
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               return getClass().hashCode() * 31 + this.index;
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         public static abstract class ForField
/*      */           implements Step<MemberSubstitution.Target>
/*      */         {
/*      */           protected final FieldDescription fieldDescription;
/*      */ 
/*      */           
/*      */           protected final Assigner assigner;
/*      */ 
/*      */           
/*      */           protected final Assigner.Typing typing;
/*      */ 
/*      */ 
/*      */           
/*      */           protected ForField(FieldDescription fieldDescription, Assigner assigner, Assigner.Typing typing) {
/* 2512 */             this.fieldDescription = fieldDescription;
/* 2513 */             this.assigner = assigner;
/* 2514 */             this.typing = typing;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Field description always has declaring type.")
/*      */           public MemberSubstitution.Substitution.Chain.Step.Resolution resolve(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, JavaConstant.MethodHandle methodHandle, StackManipulation stackManipulation, TypeDescription.Generic current, Map<Integer, Integer> offsets, int freeOffset) {
/* 2529 */             List<StackManipulation> stackManipulations = new ArrayList<StackManipulation>(2);
/* 2530 */             if (this.fieldDescription.isStatic()) {
/* 2531 */               stackManipulations.add(Removal.of((TypeDefinition)current));
/*      */             } else {
/* 2533 */               StackManipulation assignment = this.assigner.assign(current, this.fieldDescription.getDeclaringType().asGenericType(), this.typing);
/* 2534 */               if (!assignment.isValid()) {
/* 2535 */                 throw new IllegalStateException("Cannot assign " + current + " to " + this.fieldDescription.getDeclaringType());
/*      */               }
/* 2537 */               stackManipulations.add(assignment);
/*      */             } 
/* 2539 */             return doResolve(target, parameters, offsets, (StackManipulation)new StackManipulation.Compound(stackManipulations));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected abstract MemberSubstitution.Substitution.Chain.Step.Resolution doResolve(MemberSubstitution.Target param4Target, TypeList.Generic param4Generic, Map<Integer, Integer> param4Map, StackManipulation param4StackManipulation);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.typing.equals(((ForField)param4Object).typing) ? false : (!this.fieldDescription.equals(((ForField)param4Object).fieldDescription) ? false : (!!this.assigner.equals(((ForField)param4Object).assigner))))));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return ((getClass().hashCode() * 31 + this.fieldDescription.hashCode()) * 31 + this.assigner.hashCode()) * 31 + this.typing.hashCode();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @Enhance
/*      */           public static class Read
/*      */             extends ForField
/*      */           {
/*      */             protected Read(FieldDescription fieldDescription, Assigner assigner, Assigner.Typing typing) {
/* 2570 */               super(fieldDescription, assigner, typing);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected MemberSubstitution.Substitution.Chain.Step.Resolution doResolve(MemberSubstitution.Target target, TypeList.Generic parameters, Map<Integer, Integer> offsets, StackManipulation stackManipulation) {
/* 2580 */               return new MemberSubstitution.Substitution.Chain.Step.Simple((StackManipulation)new StackManipulation.Compound(new StackManipulation[] { stackManipulation, FieldAccess.forField(this.fieldDescription).read() }, ), this.fieldDescription.getType());
/*      */             }
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return !super.equals(param5Object) ? false : ((this == param5Object) ? true : ((param5Object == null) ? false : (!(getClass() != param5Object.getClass()))));
/*      */             }
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               return super.hashCode();
/*      */             }
/*      */             
/*      */             @Enhance
/*      */             public static class Factory
/*      */               implements MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target>
/*      */             {
/*      */               private final FieldDescription fieldDescription;
/*      */               
/*      */               public Factory(Field field) {
/* 2600 */                 this((FieldDescription)new FieldDescription.ForLoadedField(field));
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Factory(FieldDescription fieldDescription) {
/* 2609 */                 this.fieldDescription = fieldDescription;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step<MemberSubstitution.Target> make(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 2616 */                 return new MemberSubstitution.Substitution.Chain.Step.ForField.Read(this.fieldDescription, assigner, typing);
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param6Object) {
/*      */                 return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : (!!this.fieldDescription.equals(((Factory)param6Object).fieldDescription))));
/*      */               }
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return getClass().hashCode() * 31 + this.fieldDescription.hashCode();
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/*      */           
/*      */           @Enhance
/*      */           public static class Write
/*      */             extends ForField
/*      */           {
/*      */             private final int index;
/*      */ 
/*      */             
/*      */             protected Write(FieldDescription fieldDescription, Assigner assigner, Assigner.Typing typing, int index) {
/* 2641 */               super(fieldDescription, assigner, typing);
/* 2642 */               this.index = index;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected MemberSubstitution.Substitution.Chain.Step.Resolution doResolve(MemberSubstitution.Target target, TypeList.Generic parameters, Map<Integer, Integer> offsets, StackManipulation stackManipulation) {
/* 2652 */               int index = target.isStaticDispatch() ? this.index : (this.index + 1);
/* 2653 */               if (index >= parameters.size()) {
/* 2654 */                 throw new IllegalStateException("Target does not define an argument with index " + index);
/*      */               }
/* 2656 */               StackManipulation assignment = this.assigner.assign((TypeDescription.Generic)parameters.get(index), this.fieldDescription.getType(), this.typing);
/* 2657 */               if (!assignment.isValid()) {
/* 2658 */                 throw new IllegalStateException("Cannot write " + parameters.get(index) + " to " + this.fieldDescription);
/*      */               }
/* 2660 */               return new MemberSubstitution.Substitution.Chain.Step.Simple((StackManipulation)new StackManipulation.Compound(new StackManipulation[] { stackManipulation, 
/* 2661 */                       MethodVariableAccess.of((TypeDefinition)parameters.get(index)).loadFrom(((Integer)offsets.get(Integer.valueOf(index))).intValue()), assignment, 
/*      */                       
/* 2663 */                       FieldAccess.forField(this.fieldDescription).write() }, ), TypeDefinition.Sort.describe(void.class));
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return !super.equals(param5Object) ? false : ((this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!(this.index != ((Write)param5Object).index)))));
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               return super.hashCode() * 31 + this.index;
/*      */             }
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             public static class Factory
/*      */               implements MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target>
/*      */             {
/*      */               private final FieldDescription fieldDescription;
/*      */               
/*      */               private final int index;
/*      */ 
/*      */               
/*      */               public Factory(Field field, int index) {
/* 2689 */                 this((FieldDescription)new FieldDescription.ForLoadedField(field), index);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Factory(FieldDescription fieldDescription, int index) {
/* 2699 */                 this.fieldDescription = fieldDescription;
/* 2700 */                 this.index = index;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step<MemberSubstitution.Target> make(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 2707 */                 return new MemberSubstitution.Substitution.Chain.Step.ForField.Write(this.fieldDescription, assigner, typing, this.index);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param6Object) {
/*      */                 return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : ((this.index != ((Factory)param6Object).index) ? false : (!!this.fieldDescription.equals(((Factory)param6Object).fieldDescription)))));
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return (getClass().hashCode() * 31 + this.fieldDescription.hashCode()) * 31 + this.index;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         public static class ForInvocation
/*      */           implements Step<MemberSubstitution.Target>
/*      */         {
/*      */           private final MethodDescription methodDescription;
/*      */ 
/*      */ 
/*      */           
/*      */           private final Map<Integer, Integer> substitutions;
/*      */ 
/*      */           
/*      */           private final Assigner assigner;
/*      */ 
/*      */           
/*      */           private final Assigner.Typing typing;
/*      */ 
/*      */ 
/*      */           
/*      */           protected ForInvocation(MethodDescription methodDescription, Map<Integer, Integer> substitutions, Assigner assigner, Assigner.Typing typing) {
/* 2749 */             this.methodDescription = methodDescription;
/* 2750 */             this.substitutions = substitutions;
/* 2751 */             this.assigner = assigner;
/* 2752 */             this.typing = typing;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MemberSubstitution.Substitution.Chain.Step.Resolution resolve(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, JavaConstant.MethodHandle methodHandle, StackManipulation stackManipulation, TypeDescription.Generic current, Map<Integer, Integer> offsets, int freeOffset) {
/* 2766 */             List<StackManipulation> stackManipulations = new ArrayList<StackManipulation>(3 + parameters.size() * 2);
/* 2767 */             if (this.methodDescription.isStatic()) {
/* 2768 */               stackManipulations.add(Removal.of((TypeDefinition)current));
/* 2769 */             } else if (this.methodDescription.isConstructor()) {
/* 2770 */               stackManipulations.add(Removal.of((TypeDefinition)current));
/* 2771 */               stackManipulations.add(TypeCreation.of(this.methodDescription.getDeclaringType().asErasure()));
/*      */             } else {
/* 2773 */               StackManipulation assignment = this.assigner.assign(current, this.methodDescription.getDeclaringType().asGenericType(), this.typing);
/* 2774 */               if (!assignment.isValid()) {
/* 2775 */                 throw new IllegalStateException("Cannot assign " + current + " to " + this.methodDescription.getDeclaringType());
/*      */               }
/* 2777 */               stackManipulations.add(assignment);
/*      */             } 
/* 2779 */             boolean shift = !target.isStaticDispatch();
/* 2780 */             for (int index = 0; index < this.methodDescription.getParameters().size(); index++) {
/* 2781 */               int substitution = this.substitutions.containsKey(Integer.valueOf(index + (shift ? 1 : 0))) ? ((Integer)this.substitutions.get(Integer.valueOf(index + (shift ? 1 : 0)))).intValue() : (index + (shift ? 1 : 0));
/* 2782 */               if (substitution >= parameters.size()) {
/* 2783 */                 throw new IllegalStateException(target + " does not support an index " + substitution);
/*      */               }
/* 2785 */               stackManipulations.add(MethodVariableAccess.of((TypeDefinition)parameters.get(substitution)).loadFrom(((Integer)offsets.get(Integer.valueOf(substitution))).intValue()));
/* 2786 */               StackManipulation assignment = this.assigner.assign((TypeDescription.Generic)parameters.get(substitution), ((ParameterDescription)this.methodDescription.getParameters().get(index)).getType(), this.typing);
/* 2787 */               if (!assignment.isValid()) {
/* 2788 */                 throw new IllegalStateException("Cannot assign parameter with " + index + " of type " + parameters.get(substitution) + " to " + this.methodDescription);
/*      */               }
/* 2790 */               stackManipulations.add(assignment);
/*      */             } 
/* 2792 */             stackManipulations.add(MethodInvocation.invoke(this.methodDescription));
/* 2793 */             return new MemberSubstitution.Substitution.Chain.Step.Simple((StackManipulation)new StackManipulation.Compound(stackManipulations), this.methodDescription.getReturnType());
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.typing.equals(((ForInvocation)param4Object).typing) ? false : (!this.methodDescription.equals(((ForInvocation)param4Object).methodDescription) ? false : (!this.substitutions.equals(((ForInvocation)param4Object).substitutions) ? false : (!!this.assigner.equals(((ForInvocation)param4Object).assigner)))))));
/*      */           }
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return (((getClass().hashCode() * 31 + this.methodDescription.hashCode()) * 31 + this.substitutions.hashCode()) * 31 + this.assigner.hashCode()) * 31 + this.typing.hashCode();
/*      */           }
/*      */ 
/*      */           
/*      */           @Enhance
/*      */           public static class Factory
/*      */             implements MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target>
/*      */           {
/*      */             private final MethodDescription methodDescription;
/*      */             
/*      */             private final Map<Integer, Integer> substitutions;
/*      */ 
/*      */             
/*      */             public Factory(Method method) {
/* 2818 */               this((MethodDescription)new MethodDescription.ForLoadedMethod(method));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public Factory(Method method, Map<Integer, Integer> substitutions) {
/* 2829 */               this((MethodDescription)new MethodDescription.ForLoadedMethod(method), substitutions);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public Factory(Constructor<?> constructor) {
/* 2838 */               this((MethodDescription)new MethodDescription.ForLoadedConstructor(constructor));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public Factory(Constructor<?> constructor, Map<Integer, Integer> substitutions) {
/* 2849 */               this((MethodDescription)new MethodDescription.ForLoadedConstructor(constructor), substitutions);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public Factory(MethodDescription methodDescription) {
/* 2858 */               this(methodDescription, Collections.emptyMap());
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public Factory(MethodDescription methodDescription, Map<Integer, Integer> substitutions) {
/* 2869 */               this.methodDescription = methodDescription;
/* 2870 */               this.substitutions = substitutions;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step<MemberSubstitution.Target> make(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 2877 */               return new MemberSubstitution.Substitution.Chain.Step.ForInvocation(this.methodDescription, this.substitutions, assigner, typing);
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!this.methodDescription.equals(((Factory)param5Object).methodDescription) ? false : (!!this.substitutions.equals(((Factory)param5Object).substitutions)))));
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               return (getClass().hashCode() * 31 + this.methodDescription.hashCode()) * 31 + this.substitutions.hashCode();
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         public static class ForDelegation
/*      */           implements Step<MemberSubstitution.Target>
/*      */         {
/*      */           private final TypeDescription.Generic returned;
/*      */ 
/*      */           
/*      */           private final Dispatcher.Resolved dispatcher;
/*      */           
/*      */           private final List<OffsetMapping.Resolved> offsetMappings;
/*      */ 
/*      */           
/*      */           protected ForDelegation(TypeDescription.Generic returned, Dispatcher.Resolved dispatcher, List<OffsetMapping.Resolved> offsetMappings) {
/* 2909 */             this.returned = returned;
/* 2910 */             this.dispatcher = dispatcher;
/* 2911 */             this.offsetMappings = offsetMappings;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> to(Method method) {
/* 2921 */             return to((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> to(Constructor<?> constructor) {
/* 2931 */             return to((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(constructor));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> to(MethodDescription.InDefinedShape methodDescription) {
/* 2941 */             if (methodDescription.isTypeInitializer()) {
/* 2942 */               throw new IllegalArgumentException("Cannot delegate to a type initializer: " + methodDescription);
/*      */             }
/* 2944 */             return to(methodDescription, Dispatcher.ForRegularInvocation.Factory.INSTANCE, Collections.emptyList());
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           private static MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> to(MethodDescription.InDefinedShape delegate, Dispatcher.Factory dispatcherFactory, List<? extends OffsetMapping.Factory<?>> userFactories) {
/* 2956 */             if (delegate.isTypeInitializer()) {
/* 2957 */               throw new IllegalArgumentException("Cannot delegate to type initializer: " + delegate);
/*      */             }
/* 2959 */             return new Factory(delegate, dispatcherFactory.make(delegate), CompoundList.of(Arrays.asList(new OffsetMapping.Factory[] { OffsetMapping.ForArgument.Factory.INSTANCE, OffsetMapping.ForThisReference.Factory.INSTANCE, OffsetMapping.ForAllArguments.Factory.INSTANCE, OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, OffsetMapping.ForHandle.Factory.INSTANCE, OffsetMapping.ForDynamicConstant.Factory.INSTANCE, OffsetMapping.ForField.Unresolved.Factory.INSTANCE, OffsetMapping.ForFieldHandle.Unresolved.GetterFactory.INSTANCE, OffsetMapping.ForFieldHandle.Unresolved.SetterFactory.INSTANCE, OffsetMapping.ForOrigin.Factory.INSTANCE, OffsetMapping.ForStubValue.Factory.INSTANCE, new OffsetMapping.ForStackManipulation.OfDefaultValue<MemberSubstitution.Unused>(MemberSubstitution.Unused.class), OffsetMapping.ForCurrent.Factory.INSTANCE }, ), userFactories));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static WithCustomMapping withCustomMapping() {
/* 2981 */             return new WithCustomMapping(Dispatcher.ForRegularInvocation.Factory.INSTANCE, Collections.emptyMap());
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MemberSubstitution.Substitution.Chain.Step.Resolution resolve(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, JavaConstant.MethodHandle methodHandle, StackManipulation stackManipulation, TypeDescription.Generic current, Map<Integer, Integer> offsets, int freeOffset) {
/* 2995 */             List<StackManipulation> stackManipulations = new ArrayList<StackManipulation>(this.offsetMappings.size() + 3);
/* 2996 */             stackManipulations.add(current.represents(void.class) ? (StackManipulation)StackManipulation.Trivial.INSTANCE : 
/*      */                 
/* 2998 */                 MethodVariableAccess.of((TypeDefinition)current).storeAt(freeOffset));
/* 2999 */             stackManipulations.add(this.dispatcher.initialize());
/* 3000 */             for (OffsetMapping.Resolved offsetMapping : this.offsetMappings) {
/* 3001 */               stackManipulations.add(offsetMapping.apply(target, parameters, result, current, methodHandle, offsets, freeOffset));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 3009 */             stackManipulations.add(this.dispatcher.apply(target, methodHandle));
/* 3010 */             return new MemberSubstitution.Substitution.Chain.Step.Simple((StackManipulation)new StackManipulation.Compound(stackManipulations), this.returned);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public boolean equals(@MaybeNull Object param4Object) {
/*      */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.returned.equals(((ForDelegation)param4Object).returned) ? false : (!this.dispatcher.equals(((ForDelegation)param4Object).dispatcher) ? false : (!!this.offsetMappings.equals(((ForDelegation)param4Object).offsetMappings))))));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public int hashCode() {
/*      */             return ((getClass().hashCode() * 31 + this.returned.hashCode()) * 31 + this.dispatcher.hashCode()) * 31 + this.offsetMappings.hashCode();
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           @Enhance
/*      */           protected static class Factory
/*      */             implements MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target>
/*      */           {
/*      */             private final MethodDescription.InDefinedShape delegate;
/*      */ 
/*      */             
/*      */             private final MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher dispatcher;
/*      */ 
/*      */             
/*      */             private final List<MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping> offsetMappings;
/*      */ 
/*      */ 
/*      */             
/*      */             protected Factory(MethodDescription.InDefinedShape delegate, MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher dispatcher, List<? extends MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<?>> factories) {
/* 3042 */               Map<TypeDescription, MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<?>> offsetMappings = new HashMap<TypeDescription, MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<?>>();
/* 3043 */               for (MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<?> factory : factories) {
/* 3044 */                 offsetMappings.put(TypeDescription.ForLoadedType.of(factory.getAnnotationType()), factory);
/*      */               }
/* 3046 */               this.offsetMappings = new ArrayList<MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping>(factories.size());
/* 3047 */               if (delegate.isMethod() && !delegate.isStatic()) {
/* 3048 */                 MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping offsetMapping = null;
/* 3049 */                 for (AnnotationDescription annotationDescription : delegate.getDeclaredAnnotations()) {
/* 3050 */                   MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<?> factory = offsetMappings.get(annotationDescription.getAnnotationType());
/* 3051 */                   if (factory != null) {
/* 3052 */                     MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping current = factory.make(delegate, annotationDescription.prepare(factory.getAnnotationType()));
/* 3053 */                     if (offsetMapping == null) {
/* 3054 */                       offsetMapping = current; continue;
/*      */                     } 
/* 3056 */                     throw new IllegalStateException(delegate + " is bound to both " + current + " and " + offsetMapping);
/*      */                   } 
/*      */                 } 
/*      */                 
/* 3060 */                 this.offsetMappings.add((offsetMapping == null) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForThisReference(delegate
/* 3061 */                       .getDeclaringType().asGenericType(), null, MemberSubstitution.Source.SUBSTITUTED_ELEMENT, false) : offsetMapping);
/*      */               } 
/*      */               
/* 3064 */               for (int index = 0; index < delegate.getParameters().size(); index++) {
/* 3065 */                 ParameterDescription.InDefinedShape parameterDescription = (ParameterDescription.InDefinedShape)delegate.getParameters().get(index);
/* 3066 */                 MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping offsetMapping = null;
/* 3067 */                 for (AnnotationDescription annotationDescription : parameterDescription.getDeclaredAnnotations()) {
/* 3068 */                   MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<?> factory = offsetMappings.get(annotationDescription.getAnnotationType());
/* 3069 */                   if (factory != null) {
/* 3070 */                     MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping current = factory.make(parameterDescription, annotationDescription.prepare(factory.getAnnotationType()));
/* 3071 */                     if (offsetMapping == null) {
/* 3072 */                       offsetMapping = current; continue;
/*      */                     } 
/* 3074 */                     throw new IllegalStateException(parameterDescription + " is bound to both " + current + " and " + offsetMapping);
/*      */                   } 
/*      */                 } 
/*      */                 
/* 3078 */                 this.offsetMappings.add((offsetMapping == null) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForArgument(parameterDescription
/* 3079 */                       .getType(), index, null, MemberSubstitution.Source.SUBSTITUTED_ELEMENT, false) : offsetMapping);
/*      */               } 
/*      */               
/* 3082 */               this.delegate = delegate;
/* 3083 */               this.dispatcher = dispatcher;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step<MemberSubstitution.Target> make(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 3090 */               List<MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved> targets = new ArrayList<MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved>(this.offsetMappings.size());
/* 3091 */               for (MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping offsetMapping : this.offsetMappings) {
/* 3092 */                 targets.add(offsetMapping.resolve(assigner, typing, instrumentedType, instrumentedMethod));
/*      */               }
/* 3094 */               return new MemberSubstitution.Substitution.Chain.Step.ForDelegation(this.delegate.getReturnType(), this.dispatcher.resolve(instrumentedType, instrumentedMethod), targets);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!this.delegate.equals(((Factory)param5Object).delegate) ? false : (!this.dispatcher.equals(((Factory)param5Object).dispatcher) ? false : (!!this.offsetMappings.equals(((Factory)param5Object).offsetMappings))))));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               return ((getClass().hashCode() * 31 + this.delegate.hashCode()) * 31 + this.dispatcher.hashCode()) * 31 + this.offsetMappings.hashCode();
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static interface Resolved
/*      */           {
/*      */             StackManipulation apply(MemberSubstitution.Target param5Target, TypeList.Generic param5Generic, TypeDescription.Generic param5Generic1, TypeDescription.Generic param5Generic2, JavaConstant.MethodHandle param5MethodHandle, Map<Integer, Integer> param5Map, int param5Int);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             public static class ForStackManipulation
/*      */               implements Resolved
/*      */             {
/*      */               private final StackManipulation stackManipulation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public ForStackManipulation(StackManipulation stackManipulation) {
/* 3156 */                 this.stackManipulation = stackManipulation;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) {
/* 3169 */                 return this.stackManipulation;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.stackManipulation.equals(((ForStackManipulation)param7Object).stackManipulation))));
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return getClass().hashCode() * 31 + this.stackManipulation.hashCode();
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static interface Factory<T extends Annotation>
/*      */           {
/*      */             Class<T> getAnnotationType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape param5InDefinedShape, AnnotationDescription.Loadable<T> param5Loadable);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape param5InDefinedShape, AnnotationDescription.Loadable<T> param5Loadable);
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public static abstract class AbstractBase<S extends Annotation>
/*      */               implements Factory<S>
/*      */             {
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<S> annotation) {
/* 3217 */                 return make(target.getDeclaringType().asGenericType(), annotation);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<S> annotation) {
/* 3224 */                 return make(target.getType(), annotation);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected abstract MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(TypeDescription.Generic param7Generic, AnnotationDescription.Loadable<S> param7Loadable);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public static abstract class WithParameterSupportOnly<S extends Annotation>
/*      */               implements Factory<S>
/*      */             {
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<S> annotation) {
/* 3248 */                 throw new UnsupportedOperationException("This factory does not support binding a method receiver");
/*      */               }
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             public static class Simple<S extends Annotation>
/*      */               extends AbstractBase<S>
/*      */             {
/*      */               private final Class<S> annotationType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping offsetMapping;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Simple(Class<S> annotationType, MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping offsetMapping) {
/* 3277 */                 this.annotationType = annotationType;
/* 3278 */                 this.offsetMapping = offsetMapping;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Class<S> getAnnotationType() {
/* 3285 */                 return this.annotationType;
/*      */               }
/*      */ 
/*      */               
/*      */               protected MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(TypeDescription.Generic target, AnnotationDescription.Loadable<S> annotation) {
/* 3290 */                 return this.offsetMapping;
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.annotationType.equals(((Simple)param7Object).annotationType) ? false : (!!this.offsetMapping.equals(((Simple)param7Object).offsetMapping)))));
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return (getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.offsetMapping.hashCode();
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           @Enhance
/*      */           public static class ForStackManipulation
/*      */             implements OffsetMapping
/*      */           {
/*      */             private final StackManipulation stackManipulation;
/*      */ 
/*      */             
/*      */             private final TypeDescription.Generic typeDescription;
/*      */ 
/*      */             
/*      */             private final TypeDescription.Generic targetType;
/*      */ 
/*      */ 
/*      */             
/*      */             public ForStackManipulation(StackManipulation stackManipulation, TypeDescription.Generic typeDescription, TypeDescription.Generic targetType) {
/* 3324 */               this.targetType = targetType;
/* 3325 */               this.stackManipulation = stackManipulation;
/* 3326 */               this.typeDescription = typeDescription;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public static <S extends Annotation> MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<S> of(Class<S> annotationType, @MaybeNull Object value) {
/* 3338 */               return (value == null) ? new OfDefaultValue<S>(annotationType) : new Factory<S>(annotationType, 
/*      */                   
/* 3340 */                   ConstantValue.Simple.wrap(value));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 3347 */               return new Resolved(assigner, typing, this.stackManipulation, this.typeDescription, this.targetType);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!this.stackManipulation.equals(((ForStackManipulation)param5Object).stackManipulation) ? false : (!this.typeDescription.equals(((ForStackManipulation)param5Object).typeDescription) ? false : (!!this.targetType.equals(((ForStackManipulation)param5Object).targetType))))));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               return ((getClass().hashCode() * 31 + this.stackManipulation.hashCode()) * 31 + this.typeDescription.hashCode()) * 31 + this.targetType.hashCode();
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             protected static class Resolved
/*      */               implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved
/*      */             {
/*      */               private final Assigner assigner;
/*      */ 
/*      */ 
/*      */               
/*      */               private final Assigner.Typing typing;
/*      */ 
/*      */ 
/*      */               
/*      */               private final StackManipulation stackManipulation;
/*      */ 
/*      */ 
/*      */               
/*      */               private final TypeDescription.Generic typeDescription;
/*      */ 
/*      */ 
/*      */               
/*      */               private final TypeDescription.Generic targetType;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected Resolved(Assigner assigner, Assigner.Typing typing, StackManipulation stackManipulation, TypeDescription.Generic typeDescription, TypeDescription.Generic targetType) {
/* 3395 */                 this.assigner = assigner;
/* 3396 */                 this.typing = typing;
/* 3397 */                 this.stackManipulation = stackManipulation;
/* 3398 */                 this.typeDescription = typeDescription;
/* 3399 */                 this.targetType = targetType;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) {
/* 3412 */                 StackManipulation assignment = this.assigner.assign(this.typeDescription, this.targetType, this.typing);
/* 3413 */                 if (!assignment.isValid()) {
/* 3414 */                   throw new IllegalStateException("Cannot assign " + this.typeDescription + " to " + this.targetType);
/*      */                 }
/* 3416 */                 return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { this.stackManipulation, assignment });
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.typing.equals(((Resolved)param7Object).typing) ? false : (!this.assigner.equals(((Resolved)param7Object).assigner) ? false : (!this.stackManipulation.equals(((Resolved)param7Object).stackManipulation) ? false : (!this.typeDescription.equals(((Resolved)param7Object).typeDescription) ? false : (!!this.targetType.equals(((Resolved)param7Object).targetType))))))));
/*      */               }
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return ((((getClass().hashCode() * 31 + this.assigner.hashCode()) * 31 + this.typing.hashCode()) * 31 + this.stackManipulation.hashCode()) * 31 + this.typeDescription.hashCode()) * 31 + this.targetType.hashCode();
/*      */               }
/*      */             }
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             public static class OfDefaultValue<T extends Annotation>
/*      */               implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<T>
/*      */             {
/*      */               private final Class<T> annotationType;
/*      */ 
/*      */               
/*      */               public OfDefaultValue(Class<T> annotationType) {
/* 3440 */                 this.annotationType = annotationType;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Class<T> getAnnotationType() {
/* 3447 */                 return this.annotationType;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation) {
/* 3454 */                 throw new UnsupportedOperationException("This factory does not support binding a method receiver");
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation) {
/* 3461 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation(DefaultValue.of((TypeDefinition)target.getType()), target.getType(), target.getType());
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.annotationType.equals(((OfDefaultValue)param7Object).annotationType))));
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return getClass().hashCode() * 31 + this.annotationType.hashCode();
/*      */               }
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             public static class OfAnnotationProperty<T extends Annotation>
/*      */               extends MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory.WithParameterSupportOnly<T>
/*      */             {
/*      */               private final Class<T> annotationType;
/*      */ 
/*      */               
/*      */               private final MethodDescription.InDefinedShape property;
/*      */ 
/*      */               
/*      */               protected OfAnnotationProperty(Class<T> annotationType, MethodDescription.InDefinedShape property) {
/* 3490 */                 this.annotationType = annotationType;
/* 3491 */                 this.property = property;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public static <S extends Annotation> MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<S> of(Class<S> annotationType, String property) {
/* 3504 */                 if (!annotationType.isAnnotation()) {
/* 3505 */                   throw new IllegalArgumentException("Not an annotation type: " + annotationType);
/*      */                 }
/*      */                 try {
/* 3508 */                   return new OfAnnotationProperty<S>(annotationType, (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(annotationType.getMethod(property, new Class[0])));
/* 3509 */                 } catch (NoSuchMethodException exception) {
/* 3510 */                   throw new IllegalArgumentException("Cannot find a property " + property + " on " + annotationType, exception);
/*      */                 } 
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Class<T> getAnnotationType() {
/* 3518 */                 return this.annotationType;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation) {
/* 3525 */                 ConstantValue value = ConstantValue.Simple.wrapOrNull(annotation.getValue(this.property).resolve());
/* 3526 */                 if (value == null) {
/* 3527 */                   throw new IllegalStateException("Not a constant value property: " + this.property);
/*      */                 }
/* 3529 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation(value.toStackManipulation(), value.getTypeDescription().asGenericType(), target.getType());
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.annotationType.equals(((OfAnnotationProperty)param7Object).annotationType) ? false : (!!this.property.equals(((OfAnnotationProperty)param7Object).property)))));
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return (getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.property.hashCode();
/*      */               }
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             public static class OfSerializedConstant<T extends Annotation>
/*      */               extends MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory.AbstractBase<T>
/*      */             {
/*      */               private final Class<T> annotationType;
/*      */ 
/*      */               
/*      */               private final StackManipulation deserialization;
/*      */ 
/*      */               
/*      */               private final TypeDescription.Generic typeDescription;
/*      */ 
/*      */ 
/*      */               
/*      */               protected OfSerializedConstant(Class<T> annotationType, StackManipulation deserialization, TypeDescription.Generic typeDescription) {
/* 3564 */                 this.annotationType = annotationType;
/* 3565 */                 this.deserialization = deserialization;
/* 3566 */                 this.typeDescription = typeDescription;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public static <S extends Annotation, U extends Serializable> MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<S> of(Class<S> type, U value, Class<? super U> targetType) {
/* 3580 */                 if (!targetType.isInstance(value)) {
/* 3581 */                   throw new IllegalArgumentException((new StringBuilder()).append(value).append(" is no instance of ").append(targetType).toString());
/*      */                 }
/* 3583 */                 return new OfSerializedConstant<S>(type, SerializedConstant.of((Serializable)value), TypeDescription.ForLoadedType.of(targetType).asGenericType());
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Class<T> getAnnotationType() {
/* 3590 */                 return this.annotationType;
/*      */               }
/*      */ 
/*      */               
/*      */               protected MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(TypeDescription.Generic target, AnnotationDescription.Loadable<T> annotation) {
/* 3595 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation(this.deserialization, this.typeDescription, target);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.annotationType.equals(((OfSerializedConstant)param7Object).annotationType) ? false : (!this.deserialization.equals(((OfSerializedConstant)param7Object).deserialization) ? false : (!!this.typeDescription.equals(((OfSerializedConstant)param7Object).typeDescription))))));
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return ((getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.deserialization.hashCode()) * 31 + this.typeDescription.hashCode();
/*      */               }
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             public static class OfDynamicInvocation<T extends Annotation>
/*      */               extends MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory.AbstractBase<T>
/*      */             {
/*      */               private final Class<T> annotationType;
/*      */ 
/*      */               
/*      */               private final MethodDescription.InDefinedShape bootstrapMethod;
/*      */ 
/*      */               
/*      */               private final List<? extends JavaConstant> arguments;
/*      */ 
/*      */ 
/*      */               
/*      */               public OfDynamicInvocation(Class<T> annotationType, MethodDescription.InDefinedShape bootstrapMethod, List<? extends JavaConstant> arguments) {
/* 3630 */                 this.annotationType = annotationType;
/* 3631 */                 this.bootstrapMethod = bootstrapMethod;
/* 3632 */                 this.arguments = arguments;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Class<T> getAnnotationType() {
/* 3639 */                 return this.annotationType;
/*      */               }
/*      */ 
/*      */               
/*      */               protected MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(TypeDescription.Generic target, AnnotationDescription.Loadable<T> annotation) {
/* 3644 */                 if (!target.isInterface())
/* 3645 */                   throw new IllegalArgumentException(target + " is not an interface"); 
/* 3646 */                 if (!target.getInterfaces().isEmpty())
/* 3647 */                   throw new IllegalArgumentException(target + " must not extend other interfaces"); 
/* 3648 */                 if (!target.isPublic()) {
/* 3649 */                   throw new IllegalArgumentException(target + " is mot public");
/*      */                 }
/* 3651 */                 MethodList<?> methodCandidates = (MethodList)target.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isAbstract());
/* 3652 */                 if (methodCandidates.size() != 1) {
/* 3653 */                   throw new IllegalArgumentException(target + " must declare exactly one abstract method");
/*      */                 }
/* 3655 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation(MethodInvocation.invoke(this.bootstrapMethod).dynamic(((MethodDescription)methodCandidates.getOnly()).getInternalName(), target
/* 3656 */                       .asErasure(), 
/* 3657 */                       Collections.emptyList(), this.arguments), target, target);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.annotationType.equals(((OfDynamicInvocation)param7Object).annotationType) ? false : (!this.bootstrapMethod.equals(((OfDynamicInvocation)param7Object).bootstrapMethod) ? false : (!!this.arguments.equals(((OfDynamicInvocation)param7Object).arguments))))));
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return ((getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.bootstrapMethod.hashCode()) * 31 + this.arguments.hashCode();
/*      */               }
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             public static class Factory<T extends Annotation>
/*      */               extends MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory.AbstractBase<T>
/*      */             {
/*      */               private final Class<T> annotationType;
/*      */ 
/*      */               
/*      */               private final StackManipulation stackManipulation;
/*      */ 
/*      */               
/*      */               private final TypeDescription.Generic typeDescription;
/*      */ 
/*      */ 
/*      */               
/*      */               public Factory(Class<T> annotationType, ConstantValue value) {
/* 3692 */                 this(annotationType, value.toStackManipulation(), value.getTypeDescription().asGenericType());
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Factory(Class<T> annotationType, StackManipulation stackManipulation, TypeDescription.Generic typeDescription) {
/* 3703 */                 this.annotationType = annotationType;
/* 3704 */                 this.stackManipulation = stackManipulation;
/* 3705 */                 this.typeDescription = typeDescription;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Class<T> getAnnotationType() {
/* 3712 */                 return this.annotationType;
/*      */               }
/*      */ 
/*      */               
/*      */               protected MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(TypeDescription.Generic target, AnnotationDescription.Loadable<T> annotation) {
/* 3717 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation(this.stackManipulation, this.typeDescription, target);
/*      */               }
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.annotationType.equals(((Factory)param7Object).annotationType) ? false : (!this.stackManipulation.equals(((Factory)param7Object).stackManipulation) ? false : (!!this.typeDescription.equals(((Factory)param7Object).typeDescription))))));
/*      */               }
/*      */               
/*      */               public int hashCode() {
/*      */                 return ((getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.stackManipulation.hashCode()) * 31 + this.typeDescription.hashCode();
/*      */               } }
/*      */           }
/*      */           
/*      */           @Enhance
/*      */           public static class OfDefaultValue<T extends Annotation> implements OffsetMapping.Factory<T> {
/*      */             private final Class<T> annotationType;
/*      */             
/*      */             public OfDefaultValue(Class<T> annotationType) {
/*      */               this.annotationType = annotationType;
/*      */             }
/*      */             
/*      */             public Class<T> getAnnotationType() {
/*      */               return this.annotationType;
/*      */             }
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation) {
/*      */               throw new UnsupportedOperationException("This factory does not support binding a method receiver");
/*      */             }
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation) {
/*      */               return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation(DefaultValue.of((TypeDefinition)target.getType()), target.getType(), target.getType());
/*      */             }
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.annotationType.equals(((OfDefaultValue)param5Object).annotationType))));
/*      */             }
/*      */             
/*      */             public int hashCode() {
/*      */               return getClass().hashCode() * 31 + this.annotationType.hashCode();
/*      */             }
/*      */           }
/*      */           
/*      */           @Enhance
/*      */           public static class ForArgument implements OffsetMapping { private final TypeDescription.Generic targetType;
/*      */             private final int index;
/*      */             @MaybeNull
/*      */             @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*      */             private final Assigner.Typing typing;
/*      */             private final MemberSubstitution.Source source;
/*      */             private final boolean optional;
/*      */             
/*      */             public ForArgument(TypeDescription.Generic targetType, int index, @MaybeNull Assigner.Typing typing, MemberSubstitution.Source source, boolean optional) {
/* 3768 */               this.targetType = targetType;
/* 3769 */               this.index = index;
/* 3770 */               this.typing = typing;
/* 3771 */               this.source = source;
/* 3772 */               this.optional = optional;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 3779 */               return new Resolved(this.targetType, this.index, (this.typing == null) ? typing : this.typing, this.source, this.optional, assigner, instrumentedMethod);
/*      */             } public boolean equals(@MaybeNull Object param5Object) { if (this == param5Object)
/*      */                 return true;  if (param5Object == null)
/*      */                 return false;  if (getClass() != param5Object.getClass())
/*      */                 return false;  if (this.index != ((ForArgument)param5Object).index)
/*      */                 return false;  if (this.optional != ((ForArgument)param5Object).optional)
/*      */                 return false;  Assigner.Typing typing1 = ((ForArgument)param5Object).typing; Assigner.Typing typing2 = this.typing; if (typing1 != null) { if (typing2 != null) { if (!typing2.equals(typing1))
/*      */                     return false;  }
/*      */                 else { return false; }
/*      */                  }
/*      */               else if (typing2 != null) { return false; }
/*      */                return !this.source.equals(((ForArgument)param5Object).source) ? false : (!!this.targetType.equals(((ForArgument)param5Object).targetType)); } public int hashCode() { Assigner.Typing typing = this.typing; if (typing != null); return ((((getClass().hashCode() * 31 + this.targetType.hashCode()) * 31 + this.index) * 31 + typing.hashCode()) * 31 + this.source.hashCode()) * 31 + this.optional; }
/* 3791 */             protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.Argument> { INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape ARGUMENT_OPTIONAL;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape ARGUMENT_SOURCE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape ARGUMENT_TYPING;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape ARGUMENT_VALUE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               static {
/* 3817 */                 MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.Argument.class).getDeclaredMethods();
/* 3818 */                 ARGUMENT_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly();
/* 3819 */                 ARGUMENT_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/* 3820 */                 ARGUMENT_SOURCE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("source"))).getOnly();
/* 3821 */                 ARGUMENT_OPTIONAL = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("optional"))).getOnly();
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Class<MemberSubstitution.Argument> getAnnotationType() {
/* 3828 */                 return MemberSubstitution.Argument.class;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Argument> annotation) {
/* 3835 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForArgument(target.getDeclaringType().asGenericType(), ((Integer)annotation
/* 3836 */                     .getValue(ARGUMENT_VALUE).resolve(Integer.class)).intValue(), (Assigner.Typing)((EnumerationDescription)annotation
/* 3837 */                     .getValue(ARGUMENT_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (MemberSubstitution.Source)((EnumerationDescription)annotation
/* 3838 */                     .getValue(ARGUMENT_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation
/* 3839 */                     .getValue(ARGUMENT_OPTIONAL).resolve(Boolean.class)).booleanValue());
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Argument> annotation) {
/* 3846 */                 int index = ((Integer)annotation.getValue(ARGUMENT_VALUE).resolve(Integer.class)).intValue();
/* 3847 */                 if (index < 0) {
/* 3848 */                   throw new IllegalStateException("Cannot assign negative parameter index " + index + " for " + target);
/*      */                 }
/* 3850 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForArgument(target.getType(), index, (Assigner.Typing)((EnumerationDescription)annotation
/*      */                     
/* 3852 */                     .getValue(ARGUMENT_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (MemberSubstitution.Source)((EnumerationDescription)annotation
/* 3853 */                     .getValue(ARGUMENT_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation
/* 3854 */                     .getValue(ARGUMENT_OPTIONAL).resolve(Boolean.class)).booleanValue());
/*      */               } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             protected static class Resolved
/*      */               implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved
/*      */             {
/*      */               private final TypeDescription.Generic targetType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final int index;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final Assigner.Typing typing;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final MemberSubstitution.Source source;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final boolean optional;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final Assigner assigner;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final MethodDescription instrumentedMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected Resolved(TypeDescription.Generic targetType, int index, Assigner.Typing typing, MemberSubstitution.Source source, boolean optional, Assigner assigner, MethodDescription instrumentedMethod) {
/* 3920 */                 this.targetType = targetType;
/* 3921 */                 this.index = index;
/* 3922 */                 this.typing = typing;
/* 3923 */                 this.source = source;
/* 3924 */                 this.optional = optional;
/* 3925 */                 this.assigner = assigner;
/* 3926 */                 this.instrumentedMethod = instrumentedMethod;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) {
/* 3939 */                 MemberSubstitution.Source.Value value = this.source.argument(this.index, parameters, offsets, target, this.instrumentedMethod);
/* 3940 */                 if (value != null) {
/* 3941 */                   StackManipulation assignment = this.assigner.assign(value.getTypeDescription(), this.targetType, this.typing);
/* 3942 */                   if (!assignment.isValid()) {
/* 3943 */                     throw new IllegalStateException("Cannot assign " + value.getTypeDescription() + " to " + this.targetType);
/*      */                   }
/* 3945 */                   return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { MethodVariableAccess.of((TypeDefinition)value.getTypeDescription()).loadFrom(value.getOffset()), assignment });
/* 3946 */                 }  if (this.optional) {
/* 3947 */                   return DefaultValue.of((TypeDefinition)this.targetType);
/*      */                 }
/* 3949 */                 throw new IllegalStateException("No argument with index " + this.index + " available for " + target);
/*      */               }
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : ((this.index != ((Resolved)param7Object).index) ? false : ((this.optional != ((Resolved)param7Object).optional) ? false : (!this.typing.equals(((Resolved)param7Object).typing) ? false : (!this.source.equals(((Resolved)param7Object).source) ? false : (!this.targetType.equals(((Resolved)param7Object).targetType) ? false : (!this.assigner.equals(((Resolved)param7Object).assigner) ? false : (!!this.instrumentedMethod.equals(((Resolved)param7Object).instrumentedMethod))))))))));
/*      */               }
/*      */               public int hashCode() {
/*      */                 return ((((((getClass().hashCode() * 31 + this.targetType.hashCode()) * 31 + this.index) * 31 + this.typing.hashCode()) * 31 + this.source.hashCode()) * 31 + this.optional) * 31 + this.assigner.hashCode()) * 31 + this.instrumentedMethod.hashCode();
/*      */               } } }
/*      */           protected enum Factory implements OffsetMapping.Factory<MemberSubstitution.Argument> { INSTANCE; private static final MethodDescription.InDefinedShape ARGUMENT_OPTIONAL;
/*      */             private static final MethodDescription.InDefinedShape ARGUMENT_SOURCE;
/*      */             private static final MethodDescription.InDefinedShape ARGUMENT_TYPING;
/*      */             private static final MethodDescription.InDefinedShape ARGUMENT_VALUE;
/*      */             
/*      */             static {
/*      */               MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.Argument.class).getDeclaredMethods();
/*      */               ARGUMENT_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly();
/*      */               ARGUMENT_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*      */               ARGUMENT_SOURCE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("source"))).getOnly();
/*      */               ARGUMENT_OPTIONAL = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("optional"))).getOnly();
/*      */             }
/*      */             
/*      */             public Class<MemberSubstitution.Argument> getAnnotationType() {
/*      */               return MemberSubstitution.Argument.class;
/*      */             }
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Argument> annotation) {
/*      */               return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForArgument(target.getDeclaringType().asGenericType(), ((Integer)annotation.getValue(ARGUMENT_VALUE).resolve(Integer.class)).intValue(), (Assigner.Typing)((EnumerationDescription)annotation.getValue(ARGUMENT_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(ARGUMENT_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation.getValue(ARGUMENT_OPTIONAL).resolve(Boolean.class)).booleanValue());
/*      */             }
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Argument> annotation) {
/*      */               int index = ((Integer)annotation.getValue(ARGUMENT_VALUE).resolve(Integer.class)).intValue();
/*      */               if (index < 0)
/*      */                 throw new IllegalStateException("Cannot assign negative parameter index " + index + " for " + target); 
/*      */               return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForArgument(target.getType(), index, (Assigner.Typing)((EnumerationDescription)annotation.getValue(ARGUMENT_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(ARGUMENT_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation.getValue(ARGUMENT_OPTIONAL).resolve(Boolean.class)).booleanValue());
/*      */             } }
/*      */           
/*      */           @Enhance
/*      */           public static class ForThisReference implements OffsetMapping { private final TypeDescription.Generic targetType;
/*      */             @MaybeNull
/*      */             @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*      */             private final Assigner.Typing typing;
/*      */             private final MemberSubstitution.Source source;
/*      */             private final boolean optional;
/*      */             
/*      */             public ForThisReference(TypeDescription.Generic targetType, @MaybeNull Assigner.Typing typing, MemberSubstitution.Source source, boolean optional) {
/* 3994 */               this.targetType = targetType;
/* 3995 */               this.typing = typing;
/* 3996 */               this.source = source;
/* 3997 */               this.optional = optional;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 4004 */               return new Resolved(this.targetType, (this.typing == null) ? typing : this.typing, this.source, this.optional, assigner, instrumentedMethod);
/*      */             }
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               if (this == param5Object) {
/*      */                 return true;
/*      */               }
/*      */               if (param5Object == null) {
/*      */                 return false;
/*      */               }
/*      */               if (getClass() != param5Object.getClass()) {
/*      */                 return false;
/*      */               }
/*      */               if (this.optional != ((ForThisReference)param5Object).optional) {
/*      */                 return false;
/*      */               }
/*      */               Assigner.Typing typing1 = ((ForThisReference)param5Object).typing;
/*      */               Assigner.Typing typing2 = this.typing;
/*      */               if (typing1 != null) {
/*      */                 if (typing2 != null) {
/*      */                   if (!typing2.equals(typing1)) {
/*      */                     return false;
/*      */                   }
/*      */                 } else {
/*      */                   return false;
/*      */                 } 
/*      */               } else if (typing2 != null) {
/*      */                 return false;
/*      */               } 
/*      */               return !this.source.equals(((ForThisReference)param5Object).source) ? false : (!!this.targetType.equals(((ForThisReference)param5Object).targetType));
/*      */             }
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               Assigner.Typing typing = this.typing;
/*      */               if (typing != null);
/*      */               return (((getClass().hashCode() * 31 + this.targetType.hashCode()) * 31 + typing.hashCode()) * 31 + this.source.hashCode()) * 31 + this.optional;
/*      */             }
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             protected static class Resolved
/*      */               implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved
/*      */             {
/*      */               private final TypeDescription.Generic targetType;
/*      */               
/*      */               private final Assigner.Typing typing;
/*      */               
/*      */               private final MemberSubstitution.Source source;
/*      */               
/*      */               private final boolean optional;
/*      */               
/*      */               private final Assigner assigner;
/*      */               private final MethodDescription instrumentedMethod;
/*      */               
/*      */               protected Resolved(TypeDescription.Generic targetType, Assigner.Typing typing, MemberSubstitution.Source source, boolean optional, Assigner assigner, MethodDescription instrumentedMethod) {
/* 4061 */                 this.targetType = targetType;
/* 4062 */                 this.typing = typing;
/* 4063 */                 this.source = source;
/* 4064 */                 this.optional = optional;
/* 4065 */                 this.assigner = assigner;
/* 4066 */                 this.instrumentedMethod = instrumentedMethod;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) {
/* 4079 */                 MemberSubstitution.Source.Value value = this.source.self(parameters, offsets, target, this.instrumentedMethod);
/* 4080 */                 if (value != null) {
/* 4081 */                   StackManipulation assignment = this.assigner.assign(value.getTypeDescription(), this.targetType, this.typing);
/* 4082 */                   if (!assignment.isValid()) {
/* 4083 */                     throw new IllegalStateException("Cannot assign " + value.getTypeDescription() + " to " + this.targetType);
/*      */                   }
/* 4085 */                   return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { MethodVariableAccess.of((TypeDefinition)value.getTypeDescription()).loadFrom(value.getOffset()), assignment });
/* 4086 */                 }  if (this.optional) {
/* 4087 */                   return DefaultValue.of((TypeDefinition)this.targetType);
/*      */                 }
/* 4089 */                 throw new IllegalStateException("No this reference available for " + target);
/*      */               }
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : ((this.optional != ((Resolved)param7Object).optional) ? false : (!this.typing.equals(((Resolved)param7Object).typing) ? false : (!this.source.equals(((Resolved)param7Object).source) ? false : (!this.targetType.equals(((Resolved)param7Object).targetType) ? false : (!this.assigner.equals(((Resolved)param7Object).assigner) ? false : (!!this.instrumentedMethod.equals(((Resolved)param7Object).instrumentedMethod)))))))));
/*      */               }
/*      */               
/*      */               public int hashCode() {
/*      */                 return (((((getClass().hashCode() * 31 + this.targetType.hashCode()) * 31 + this.typing.hashCode()) * 31 + this.source.hashCode()) * 31 + this.optional) * 31 + this.assigner.hashCode()) * 31 + this.instrumentedMethod.hashCode();
/*      */               }
/*      */             }
/*      */             
/*      */             protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.This> {
/* 4102 */               INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape THIS_OPTIONAL;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape THIS_SOURCE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape THIS_TYPING;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               static {
/* 4123 */                 MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.This.class).getDeclaredMethods();
/* 4124 */                 THIS_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/* 4125 */                 THIS_SOURCE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("source"))).getOnly();
/* 4126 */                 THIS_OPTIONAL = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("optional"))).getOnly();
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Class<MemberSubstitution.This> getAnnotationType() {
/* 4133 */                 return MemberSubstitution.This.class;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.This> annotation) {
/* 4140 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForThisReference(target.getDeclaringType().asGenericType(), (Assigner.Typing)((EnumerationDescription)annotation
/* 4141 */                     .getValue(THIS_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (MemberSubstitution.Source)((EnumerationDescription)annotation
/* 4142 */                     .getValue(THIS_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation
/* 4143 */                     .getValue(THIS_OPTIONAL).resolve(Boolean.class)).booleanValue());
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.This> annotation)
/*      */               {
/* 4150 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForThisReference(target.getType(), (Assigner.Typing)((EnumerationDescription)annotation
/* 4151 */                     .getValue(THIS_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (MemberSubstitution.Source)((EnumerationDescription)annotation
/* 4152 */                     .getValue(THIS_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation
/* 4153 */                     .getValue(THIS_OPTIONAL).resolve(Boolean.class)).booleanValue()); } } } protected enum Factory implements OffsetMapping.Factory<MemberSubstitution.This> { INSTANCE; private static final MethodDescription.InDefinedShape THIS_OPTIONAL; private static final MethodDescription.InDefinedShape THIS_SOURCE; private static final MethodDescription.InDefinedShape THIS_TYPING; static { MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.This.class).getDeclaredMethods(); THIS_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly(); THIS_SOURCE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("source"))).getOnly(); THIS_OPTIONAL = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("optional"))).getOnly(); } public Class<MemberSubstitution.This> getAnnotationType() { return MemberSubstitution.This.class; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.This> annotation) { return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForThisReference(target.getDeclaringType().asGenericType(), (Assigner.Typing)((EnumerationDescription)annotation.getValue(THIS_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(THIS_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation.getValue(THIS_OPTIONAL).resolve(Boolean.class)).booleanValue()); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.This> annotation) { return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForThisReference(target.getType(), (Assigner.Typing)((EnumerationDescription)annotation.getValue(THIS_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(THIS_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation.getValue(THIS_OPTIONAL).resolve(Boolean.class)).booleanValue()); }
/*      */              }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @Enhance
/*      */           public static class ForAllArguments
/*      */             implements OffsetMapping
/*      */           {
/*      */             private final TypeDescription.Generic targetComponentType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @MaybeNull
/*      */             @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*      */             private final Assigner.Typing typing;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final MemberSubstitution.Source source;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final boolean includeSelf;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final boolean nullIfEmpty;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public ForAllArguments(TypeDescription.Generic targetComponentType, @MaybeNull Assigner.Typing typing, MemberSubstitution.Source source, boolean includeSelf, boolean nullIfEmpty) {
/* 4201 */               this.targetComponentType = targetComponentType;
/* 4202 */               this.typing = typing;
/* 4203 */               this.source = source;
/* 4204 */               this.includeSelf = includeSelf;
/* 4205 */               this.nullIfEmpty = nullIfEmpty;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 4212 */               return new Resolved(this.targetComponentType, (this.typing == null) ? typing : this.typing, this.source, this.includeSelf, this.nullIfEmpty, assigner, instrumentedMethod);
/*      */             } public boolean equals(@MaybeNull Object param5Object) { if (this == param5Object)
/*      */                 return true;  if (param5Object == null)
/*      */                 return false;  if (getClass() != param5Object.getClass())
/*      */                 return false;  if (this.includeSelf != ((ForAllArguments)param5Object).includeSelf)
/*      */                 return false;  if (this.nullIfEmpty != ((ForAllArguments)param5Object).nullIfEmpty)
/*      */                 return false;  Assigner.Typing typing1 = ((ForAllArguments)param5Object).typing; Assigner.Typing typing2 = this.typing; if (typing1 != null) { if (typing2 != null) { if (!typing2.equals(typing1))
/*      */                     return false;  } else { return false; }
/*      */                  }
/*      */               else if (typing2 != null) { return false; }
/*      */                return !this.source.equals(((ForAllArguments)param5Object).source) ? false : (!!this.targetComponentType.equals(((ForAllArguments)param5Object).targetComponentType)); } public int hashCode() { Assigner.Typing typing = this.typing; if (typing != null); return ((((getClass().hashCode() * 31 + this.targetComponentType.hashCode()) * 31 + typing.hashCode()) * 31 + this.source.hashCode()) * 31 + this.includeSelf) * 31 + this.nullIfEmpty; }
/* 4223 */             protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.AllArguments> { INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape ALL_ARGUMENTS_NULL_IF_EMPTY;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape ALL_ARGUMENTS_INCLUDE_SELF;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape ALL_ARGUMENTS_SOURCE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape ALL_ARGUMENTS_TYPING;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               static {
/* 4249 */                 MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.AllArguments.class).getDeclaredMethods();
/* 4250 */                 ALL_ARGUMENTS_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/* 4251 */                 ALL_ARGUMENTS_SOURCE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("source"))).getOnly();
/* 4252 */                 ALL_ARGUMENTS_INCLUDE_SELF = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("includeSelf"))).getOnly();
/* 4253 */                 ALL_ARGUMENTS_NULL_IF_EMPTY = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("nullIfEmpty"))).getOnly();
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Class<MemberSubstitution.AllArguments> getAnnotationType() {
/* 4260 */                 return MemberSubstitution.AllArguments.class;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.AllArguments> annotation) {
/* 4267 */                 throw new UnsupportedOperationException("This factory does not support binding a method receiver");
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.AllArguments> annotation) {
/* 4275 */                 if (!target.getType().isArray()) {
/* 4276 */                   throw new IllegalStateException("Expected array as parameter type for " + target);
/*      */                 }
/* 4278 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForAllArguments(target.getType().getComponentType(), (Assigner.Typing)((EnumerationDescription)annotation
/* 4279 */                     .getValue(ALL_ARGUMENTS_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (MemberSubstitution.Source)((EnumerationDescription)annotation
/* 4280 */                     .getValue(ALL_ARGUMENTS_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation
/* 4281 */                     .getValue(ALL_ARGUMENTS_INCLUDE_SELF).resolve(Boolean.class)).booleanValue(), ((Boolean)annotation
/* 4282 */                     .getValue(ALL_ARGUMENTS_NULL_IF_EMPTY).resolve(Boolean.class)).booleanValue());
/*      */               } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             protected static class Resolved
/*      */               implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved
/*      */             {
/*      */               private final TypeDescription.Generic targetComponentType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final Assigner.Typing typing;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final MemberSubstitution.Source source;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final boolean includeSelf;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final boolean nullIfEmpty;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final Assigner assigner;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final MethodDescription instrumentedMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected Resolved(TypeDescription.Generic targetComponentType, Assigner.Typing typing, MemberSubstitution.Source source, boolean includeSelf, boolean nullIfEmpty, Assigner assigner, MethodDescription instrumentedMethod) {
/* 4345 */                 this.targetComponentType = targetComponentType;
/* 4346 */                 this.typing = typing;
/* 4347 */                 this.source = source;
/* 4348 */                 this.includeSelf = includeSelf;
/* 4349 */                 this.nullIfEmpty = nullIfEmpty;
/* 4350 */                 this.assigner = assigner;
/* 4351 */                 this.instrumentedMethod = instrumentedMethod;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) {
/* 4364 */                 List<MemberSubstitution.Source.Value> values = this.source.arguments(this.includeSelf, parameters, offsets, target, this.instrumentedMethod);
/* 4365 */                 if (this.nullIfEmpty && values.isEmpty()) {
/* 4366 */                   return (StackManipulation)NullConstant.INSTANCE;
/*      */                 }
/* 4368 */                 List<StackManipulation> stackManipulations = new ArrayList<StackManipulation>();
/* 4369 */                 for (MemberSubstitution.Source.Value value : values) {
/* 4370 */                   StackManipulation assignment = this.assigner.assign(value.getTypeDescription(), this.targetComponentType, this.typing);
/* 4371 */                   if (!assignment.isValid()) {
/* 4372 */                     throw new IllegalStateException("Cannot assign " + value.getTypeDescription() + " to " + this.targetComponentType);
/*      */                   }
/* 4374 */                   stackManipulations.add(new StackManipulation.Compound(new StackManipulation[] { MethodVariableAccess.of((TypeDefinition)value.getTypeDescription()).loadFrom(value.getOffset()), assignment }));
/*      */                 } 
/* 4376 */                 return ArrayFactory.forType(this.targetComponentType).withValues(stackManipulations);
/*      */               } public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : ((this.includeSelf != ((Resolved)param7Object).includeSelf) ? false : ((this.nullIfEmpty != ((Resolved)param7Object).nullIfEmpty) ? false : (!this.typing.equals(((Resolved)param7Object).typing) ? false : (!this.source.equals(((Resolved)param7Object).source) ? false : (!this.targetComponentType.equals(((Resolved)param7Object).targetComponentType) ? false : (!this.assigner.equals(((Resolved)param7Object).assigner) ? false : (!!this.instrumentedMethod.equals(((Resolved)param7Object).instrumentedMethod))))))))));
/*      */               } public int hashCode() {
/*      */                 return ((((((getClass().hashCode() * 31 + this.targetComponentType.hashCode()) * 31 + this.typing.hashCode()) * 31 + this.source.hashCode()) * 31 + this.includeSelf) * 31 + this.nullIfEmpty) * 31 + this.assigner.hashCode()) * 31 + this.instrumentedMethod.hashCode();
/*      */               } } }
/*      */           protected enum Factory implements OffsetMapping.Factory<MemberSubstitution.AllArguments> { INSTANCE; private static final MethodDescription.InDefinedShape ALL_ARGUMENTS_NULL_IF_EMPTY; private static final MethodDescription.InDefinedShape ALL_ARGUMENTS_INCLUDE_SELF; private static final MethodDescription.InDefinedShape ALL_ARGUMENTS_SOURCE; private static final MethodDescription.InDefinedShape ALL_ARGUMENTS_TYPING;
/*      */             static {
/*      */               MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.AllArguments.class).getDeclaredMethods();
/*      */               ALL_ARGUMENTS_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*      */               ALL_ARGUMENTS_SOURCE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("source"))).getOnly();
/*      */               ALL_ARGUMENTS_INCLUDE_SELF = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("includeSelf"))).getOnly();
/*      */               ALL_ARGUMENTS_NULL_IF_EMPTY = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("nullIfEmpty"))).getOnly();
/*      */             }
/*      */             public Class<MemberSubstitution.AllArguments> getAnnotationType() {
/*      */               return MemberSubstitution.AllArguments.class;
/*      */             }
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.AllArguments> annotation) {
/*      */               throw new UnsupportedOperationException("This factory does not support binding a method receiver");
/*      */             }
/*      */             @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.AllArguments> annotation) {
/*      */               if (!target.getType().isArray())
/*      */                 throw new IllegalStateException("Expected array as parameter type for " + target); 
/*      */               return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForAllArguments(target.getType().getComponentType(), (Assigner.Typing)((EnumerationDescription)annotation.getValue(ALL_ARGUMENTS_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(ALL_ARGUMENTS_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation.getValue(ALL_ARGUMENTS_INCLUDE_SELF).resolve(Boolean.class)).booleanValue(), ((Boolean)annotation.getValue(ALL_ARGUMENTS_NULL_IF_EMPTY).resolve(Boolean.class)).booleanValue());
/*      */             } }
/*      */           @Enhance
/*      */           public static class ForSelfCallHandle implements OffsetMapping { private final MemberSubstitution.Source source; private final boolean bound;
/*      */             public ForSelfCallHandle(MemberSubstitution.Source source, boolean bound) {
/* 4405 */               this.source = source;
/* 4406 */               this.bound = bound;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 4413 */               return this.bound ? new Bound(this.source, instrumentedMethod) : new Unbound(this.source, instrumentedMethod);
/*      */             }
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : ((this.bound != ((ForSelfCallHandle)param5Object).bound) ? false : (!!this.source.equals(((ForSelfCallHandle)param5Object).source)))));
/*      */             }
/*      */             
/*      */             public int hashCode() {
/*      */               return (getClass().hashCode() * 31 + this.source.hashCode()) * 31 + this.bound;
/*      */             }
/*      */             
/* 4424 */             protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.SelfCallHandle> { INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape SELF_CALL_HANDLE_BOUND;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape SELF_CALL_HANDLE_SOURCE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               static {
/* 4440 */                 MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.SelfCallHandle.class).getDeclaredMethods();
/* 4441 */                 SELF_CALL_HANDLE_SOURCE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("source"))).getOnly();
/* 4442 */                 SELF_CALL_HANDLE_BOUND = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bound"))).getOnly();
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Class<MemberSubstitution.SelfCallHandle> getAnnotationType() {
/* 4449 */                 return MemberSubstitution.SelfCallHandle.class;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.SelfCallHandle> annotation) {
/* 4456 */                 throw new UnsupportedOperationException("This factory does not support binding a method receiver");
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.SelfCallHandle> annotation) {
/* 4463 */                 if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) {
/* 4464 */                   throw new IllegalStateException("Cannot assign method handle to " + target);
/*      */                 }
/* 4466 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForSelfCallHandle((MemberSubstitution.Source)((EnumerationDescription)annotation
/* 4467 */                     .getValue(SELF_CALL_HANDLE_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation
/* 4468 */                     .getValue(SELF_CALL_HANDLE_BOUND).resolve(Boolean.class)).booleanValue());
/*      */               } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             protected static class Bound
/*      */               implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved
/*      */             {
/*      */               private final MemberSubstitution.Source source;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final MethodDescription instrumentedMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected Bound(MemberSubstitution.Source source, MethodDescription instrumentedMethod) {
/* 4495 */                 this.source = source;
/* 4496 */                 this.instrumentedMethod = instrumentedMethod;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) {
/* 4509 */                 MemberSubstitution.Source.Value dispatched = this.source.self(parameters, offsets, target, this.instrumentedMethod);
/* 4510 */                 List<MemberSubstitution.Source.Value> values = this.source.arguments(false, parameters, offsets, target, this.instrumentedMethod);
/*      */ 
/*      */                 
/* 4513 */                 List<StackManipulation> stackManipulations = new ArrayList<StackManipulation>(1 + values.size() + ((dispatched == null) ? 0 : 2) + (values.isEmpty() ? 0 : 1));
/* 4514 */                 stackManipulations.add(this.source.handle(methodHandle, this.instrumentedMethod).toStackManipulation());
/* 4515 */                 if (dispatched != null) {
/* 4516 */                   stackManipulations.add(MethodVariableAccess.of((TypeDefinition)dispatched.getTypeDescription()).loadFrom(dispatched.getOffset()));
/* 4517 */                   stackManipulations.add(MethodInvocation.invoke((MethodDescription.InDefinedShape)new MethodDescription.Latent(JavaType.METHOD_HANDLE.getTypeStub(), new MethodDescription.Token("bindTo", 1, JavaType.METHOD_HANDLE
/*      */                             
/* 4519 */                             .getTypeStub().asGenericType(), (List)new TypeList.Generic.Explicit(new TypeDefinition[] {
/* 4520 */                                 (TypeDefinition)TypeDefinition.Sort.describe(Object.class) })))));
/*      */                 } 
/* 4522 */                 if (!values.isEmpty()) {
/* 4523 */                   for (MemberSubstitution.Source.Value value : values) {
/* 4524 */                     stackManipulations.add(MethodVariableAccess.of((TypeDefinition)value.getTypeDescription()).loadFrom(value.getOffset()));
/*      */                   }
/* 4526 */                   stackManipulations.add(MethodInvocation.invoke((MethodDescription.InDefinedShape)new MethodDescription.Latent(JavaType.METHOD_HANDLES.getTypeStub(), new MethodDescription.Token("insertArguments", 9, JavaType.METHOD_HANDLE
/*      */                             
/* 4528 */                             .getTypeStub().asGenericType(), (List)new TypeList.Generic.Explicit(new TypeDefinition[] { (TypeDefinition)JavaType.METHOD_HANDLE
/* 4529 */                                 .getTypeStub(), (TypeDefinition)TypeDefinition.Sort.describe(int.class), (TypeDefinition)TypeDefinition.Sort.describe(Object[].class) })))));
/*      */                 } 
/* 4531 */                 return (StackManipulation)new StackManipulation.Compound(stackManipulations);
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.source.equals(((Bound)param7Object).source) ? false : (!!this.instrumentedMethod.equals(((Bound)param7Object).instrumentedMethod)))));
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return (getClass().hashCode() * 31 + this.source.hashCode()) * 31 + this.instrumentedMethod.hashCode();
/*      */               }
/*      */             }
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             protected static class Unbound
/*      */               implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved
/*      */             {
/*      */               private final MemberSubstitution.Source source;
/*      */               
/*      */               private final MethodDescription instrumentedMethod;
/*      */ 
/*      */               
/*      */               protected Unbound(MemberSubstitution.Source source, MethodDescription instrumentedMethod) {
/* 4558 */                 this.source = source;
/* 4559 */                 this.instrumentedMethod = instrumentedMethod;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) {
/* 4572 */                 return this.source.handle(methodHandle, this.instrumentedMethod).toStackManipulation();
/*      */               }
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.source.equals(((Unbound)param7Object).source) ? false : (!!this.instrumentedMethod.equals(((Unbound)param7Object).instrumentedMethod)))));
/*      */               }
/*      */               
/*      */               public int hashCode() {
/*      */                 return (getClass().hashCode() * 31 + this.source.hashCode()) * 31 + this.instrumentedMethod.hashCode();
/*      */               }
/*      */             } }
/*      */ 
/*      */           
/*      */           protected enum Factory
/*      */             implements OffsetMapping.Factory<MemberSubstitution.SelfCallHandle> {
/*      */             INSTANCE;
/*      */             private static final MethodDescription.InDefinedShape SELF_CALL_HANDLE_BOUND;
/*      */             private static final MethodDescription.InDefinedShape SELF_CALL_HANDLE_SOURCE;
/*      */             
/*      */             static {
/*      */               MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.SelfCallHandle.class).getDeclaredMethods();
/*      */               SELF_CALL_HANDLE_SOURCE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("source"))).getOnly();
/*      */               SELF_CALL_HANDLE_BOUND = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bound"))).getOnly();
/*      */             }
/*      */             
/*      */             public Class<MemberSubstitution.SelfCallHandle> getAnnotationType() {
/*      */               return MemberSubstitution.SelfCallHandle.class;
/*      */             }
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.SelfCallHandle> annotation) {
/*      */               throw new UnsupportedOperationException("This factory does not support binding a method receiver");
/*      */             }
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.SelfCallHandle> annotation) {
/*      */               if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub()))
/*      */                 throw new IllegalStateException("Cannot assign method handle to " + target); 
/*      */               return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForSelfCallHandle((MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(SELF_CALL_HANDLE_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation.getValue(SELF_CALL_HANDLE_BOUND).resolve(Boolean.class)).booleanValue());
/*      */             }
/*      */           }
/*      */           
/*      */           @Enhance
/*      */           public static class ForHandle
/*      */             implements OffsetMapping {
/*      */             private final JavaConstant.MethodHandle.HandleType type;
/*      */             private final TypeDescription owner;
/*      */             private final String name;
/*      */             private final TypeDescription returnType;
/*      */             private final List<? extends TypeDescription> parameterTypes;
/*      */             
/*      */             protected ForHandle(JavaConstant.MethodHandle.HandleType type, TypeDescription owner, String name, TypeDescription returnType, List<? extends TypeDescription> parameterTypes) {
/* 4622 */               this.type = type;
/* 4623 */               this.owner = owner;
/* 4624 */               this.name = name;
/* 4625 */               this.returnType = returnType;
/* 4626 */               this.parameterTypes = parameterTypes;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 4636 */               return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved.ForStackManipulation((StackManipulation)new JavaConstantValue((JavaConstant)new JavaConstant.MethodHandle(this.type, 
/* 4637 */                       this.owner.represents(void.class) ? instrumentedType : this.owner, this.name, this.returnType, this.parameterTypes)));
/*      */             }
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!this.type.equals(((ForHandle)param5Object).type) ? false : (!this.name.equals(((ForHandle)param5Object).name) ? false : (!this.owner.equals(((ForHandle)param5Object).owner) ? false : (!this.returnType.equals(((ForHandle)param5Object).returnType) ? false : (!!this.parameterTypes.equals(((ForHandle)param5Object).parameterTypes))))))));
/*      */             }
/*      */             
/*      */             public int hashCode() {
/*      */               return ((((getClass().hashCode() * 31 + this.type.hashCode()) * 31 + this.owner.hashCode()) * 31 + this.name.hashCode()) * 31 + this.returnType.hashCode()) * 31 + this.parameterTypes.hashCode();
/*      */             }
/*      */             
/*      */             protected enum Factory
/*      */               implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.Handle>
/*      */             {
/* 4651 */               INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape HANDLE_PARAMETER_TYPES;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape HANDLE_RETURN_TYPE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape HANDLE_NAME;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape HANDLE_OWNER;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape HANDLE_TYPE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               static {
/* 4682 */                 MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.Handle.class).getDeclaredMethods();
/* 4683 */                 HANDLE_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("type"))).getOnly();
/* 4684 */                 HANDLE_OWNER = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("owner"))).getOnly();
/* 4685 */                 HANDLE_NAME = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("name"))).getOnly();
/* 4686 */                 HANDLE_RETURN_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("returnType"))).getOnly();
/* 4687 */                 HANDLE_PARAMETER_TYPES = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("parameterTypes"))).getOnly();
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Class<MemberSubstitution.Handle> getAnnotationType() {
/* 4694 */                 return MemberSubstitution.Handle.class;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Handle> annotation) {
/* 4701 */                 throw new UnsupportedOperationException("This factory does not support binding a method receiver");
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Handle> annotation)
/*      */               {
/* 4708 */                 if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) {
/* 4709 */                   throw new IllegalStateException("Cannot assign method handle to " + target);
/*      */                 }
/* 4711 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForHandle((JavaConstant.MethodHandle.HandleType)((EnumerationDescription)annotation
/* 4712 */                     .getValue(HANDLE_TYPE).resolve(EnumerationDescription.class)).load(JavaConstant.MethodHandle.HandleType.class), (TypeDescription)annotation
/* 4713 */                     .getValue(HANDLE_OWNER).resolve(TypeDescription.class), (String)annotation
/* 4714 */                     .getValue(HANDLE_NAME).resolve(String.class), (TypeDescription)annotation
/* 4715 */                     .getValue(HANDLE_RETURN_TYPE).resolve(TypeDescription.class), 
/* 4716 */                     Arrays.asList((Object[])annotation.getValue(HANDLE_PARAMETER_TYPES).resolve(TypeDescription[].class))); } } } protected enum Factory implements OffsetMapping.Factory<MemberSubstitution.Handle> { INSTANCE; private static final MethodDescription.InDefinedShape HANDLE_PARAMETER_TYPES; private static final MethodDescription.InDefinedShape HANDLE_RETURN_TYPE; private static final MethodDescription.InDefinedShape HANDLE_NAME; private static final MethodDescription.InDefinedShape HANDLE_OWNER; private static final MethodDescription.InDefinedShape HANDLE_TYPE; static { MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.Handle.class).getDeclaredMethods(); HANDLE_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("type"))).getOnly(); HANDLE_OWNER = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("owner"))).getOnly(); HANDLE_NAME = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("name"))).getOnly(); HANDLE_RETURN_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("returnType"))).getOnly(); HANDLE_PARAMETER_TYPES = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("parameterTypes"))).getOnly(); } public Class<MemberSubstitution.Handle> getAnnotationType() { return MemberSubstitution.Handle.class; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Handle> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Handle> annotation) { if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) throw new IllegalStateException("Cannot assign method handle to " + target);  return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForHandle((JavaConstant.MethodHandle.HandleType)((EnumerationDescription)annotation.getValue(HANDLE_TYPE).resolve(EnumerationDescription.class)).load(JavaConstant.MethodHandle.HandleType.class), (TypeDescription)annotation.getValue(HANDLE_OWNER).resolve(TypeDescription.class), (String)annotation.getValue(HANDLE_NAME).resolve(String.class), (TypeDescription)annotation.getValue(HANDLE_RETURN_TYPE).resolve(TypeDescription.class), Arrays.asList((Object[])annotation.getValue(HANDLE_PARAMETER_TYPES).resolve(TypeDescription[].class))); }
/*      */              }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @Enhance
/*      */           public static class ForDynamicConstant
/*      */             implements OffsetMapping
/*      */           {
/*      */             private final String name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final TypeDescription typeDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final JavaConstant.MethodHandle.HandleType bootstrapType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final TypeDescription bootstrapOwner;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final String bootstrapName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final TypeDescription bootstrapReturnType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final List<? extends TypeDescription> bootstrapParameterTypes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final List<JavaConstant> arguments;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             private final boolean invokedynamic;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public ForDynamicConstant(String name, TypeDescription typeDescription, JavaConstant.MethodHandle.HandleType bootstrapType, TypeDescription bootstrapOwner, String bootstrapName, TypeDescription bootstrapReturnType, List<? extends TypeDescription> bootstrapParameterTypes, List<JavaConstant> arguments, boolean invokedynamic) {
/* 4794 */               this.name = name;
/* 4795 */               this.typeDescription = typeDescription;
/* 4796 */               this.bootstrapType = bootstrapType;
/* 4797 */               this.bootstrapOwner = bootstrapOwner;
/* 4798 */               this.bootstrapName = bootstrapName;
/* 4799 */               this.bootstrapReturnType = bootstrapReturnType;
/* 4800 */               this.bootstrapParameterTypes = bootstrapParameterTypes;
/* 4801 */               this.arguments = arguments;
/* 4802 */               this.invokedynamic = invokedynamic;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 4812 */               if (this.invokedynamic) {
/* 4813 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved.ForStackManipulation((StackManipulation)new Invokedynamic(this.name, 
/* 4814 */                       JavaConstant.MethodType.of(this.typeDescription, new TypeDescription[0]), new JavaConstant.MethodHandle(this.bootstrapType, 
/*      */                         
/* 4816 */                         this.bootstrapOwner.represents(void.class) ? instrumentedType : this.bootstrapOwner, this.bootstrapName, this.bootstrapReturnType, this.bootstrapParameterTypes), this.arguments));
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 4822 */               return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved.ForStackManipulation((StackManipulation)new JavaConstantValue((JavaConstant)new JavaConstant.Dynamic(this.name, this.typeDescription, new JavaConstant.MethodHandle(this.bootstrapType, 
/*      */ 
/*      */ 
/*      */                         
/* 4826 */                         this.bootstrapOwner.represents(void.class) ? instrumentedType : this.bootstrapOwner, this.bootstrapName, this.bootstrapReturnType, this.bootstrapParameterTypes), this.arguments)));
/*      */             }
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : ((this.invokedynamic != ((ForDynamicConstant)param5Object).invokedynamic) ? false : (!this.bootstrapType.equals(((ForDynamicConstant)param5Object).bootstrapType) ? false : (!this.name.equals(((ForDynamicConstant)param5Object).name) ? false : (!this.bootstrapName.equals(((ForDynamicConstant)param5Object).bootstrapName) ? false : (!this.typeDescription.equals(((ForDynamicConstant)param5Object).typeDescription) ? false : (!this.bootstrapOwner.equals(((ForDynamicConstant)param5Object).bootstrapOwner) ? false : (!this.bootstrapReturnType.equals(((ForDynamicConstant)param5Object).bootstrapReturnType) ? false : (!this.bootstrapParameterTypes.equals(((ForDynamicConstant)param5Object).bootstrapParameterTypes) ? false : (!!this.arguments.equals(((ForDynamicConstant)param5Object).arguments))))))))))));
/*      */             }
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               return ((((((((getClass().hashCode() * 31 + this.name.hashCode()) * 31 + this.typeDescription.hashCode()) * 31 + this.bootstrapType.hashCode()) * 31 + this.bootstrapOwner.hashCode()) * 31 + this.bootstrapName.hashCode()) * 31 + this.bootstrapReturnType.hashCode()) * 31 + this.bootstrapParameterTypes.hashCode()) * 31 + this.arguments.hashCode()) * 31 + this.invokedynamic;
/*      */             }
/*      */             
/*      */             protected enum Factory
/*      */               implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.DynamicConstant>
/*      */             {
/* 4842 */               INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape INVOKEDYNAMIC;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape BOOTSTRAP_PARAMETER_TYPES;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape BOOTSTRAP_RETURN_TYPE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape BOOTSTRAP_NAME;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape BOOTSTRAP_OWNER;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape BOOTSTRAP_TYPE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private static final MethodDescription.InDefinedShape NAME;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               static {
/* 4883 */                 MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.DynamicConstant.class).getDeclaredMethods();
/* 4884 */                 NAME = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("name"))).getOnly();
/* 4885 */                 BOOTSTRAP_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapType"))).getOnly();
/* 4886 */                 BOOTSTRAP_OWNER = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapOwner"))).getOnly();
/* 4887 */                 BOOTSTRAP_NAME = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapName"))).getOnly();
/* 4888 */                 BOOTSTRAP_RETURN_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapReturnType"))).getOnly();
/* 4889 */                 BOOTSTRAP_PARAMETER_TYPES = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapParameterTypes"))).getOnly();
/* 4890 */                 INVOKEDYNAMIC = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("invokedynamic"))).getOnly();
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Class<MemberSubstitution.DynamicConstant> getAnnotationType() {
/* 4897 */                 return MemberSubstitution.DynamicConstant.class;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.DynamicConstant> annotation) {
/* 4904 */                 throw new UnsupportedOperationException("This factory does not support binding a method receiver");
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.DynamicConstant> annotation)
/*      */               {
/* 4911 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForDynamicConstant((String)annotation
/* 4912 */                     .getValue(NAME).resolve(String.class), target
/* 4913 */                     .getType().asErasure(), (JavaConstant.MethodHandle.HandleType)((EnumerationDescription)annotation
/* 4914 */                     .getValue(BOOTSTRAP_TYPE).resolve(EnumerationDescription.class)).load(JavaConstant.MethodHandle.HandleType.class), (TypeDescription)annotation
/* 4915 */                     .getValue(BOOTSTRAP_OWNER).resolve(TypeDescription.class), (String)annotation
/* 4916 */                     .getValue(BOOTSTRAP_NAME).resolve(String.class), (TypeDescription)annotation
/* 4917 */                     .getValue(BOOTSTRAP_RETURN_TYPE).resolve(TypeDescription.class), 
/* 4918 */                     Arrays.asList((Object[])annotation.getValue(BOOTSTRAP_PARAMETER_TYPES).resolve(TypeDescription[].class)), 
/* 4919 */                     Collections.emptyList(), ((Boolean)annotation
/* 4920 */                     .getValue(INVOKEDYNAMIC).resolve(Boolean.class)).booleanValue()); } } } protected enum Factory implements OffsetMapping.Factory<MemberSubstitution.DynamicConstant> { INSTANCE; private static final MethodDescription.InDefinedShape INVOKEDYNAMIC; private static final MethodDescription.InDefinedShape BOOTSTRAP_PARAMETER_TYPES; private static final MethodDescription.InDefinedShape BOOTSTRAP_RETURN_TYPE; private static final MethodDescription.InDefinedShape BOOTSTRAP_NAME; private static final MethodDescription.InDefinedShape BOOTSTRAP_OWNER; private static final MethodDescription.InDefinedShape BOOTSTRAP_TYPE; private static final MethodDescription.InDefinedShape NAME; static { MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.DynamicConstant.class).getDeclaredMethods(); NAME = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("name"))).getOnly(); BOOTSTRAP_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapType"))).getOnly(); BOOTSTRAP_OWNER = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapOwner"))).getOnly(); BOOTSTRAP_NAME = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapName"))).getOnly(); BOOTSTRAP_RETURN_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapReturnType"))).getOnly(); BOOTSTRAP_PARAMETER_TYPES = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapParameterTypes"))).getOnly(); INVOKEDYNAMIC = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("invokedynamic"))).getOnly(); } public Class<MemberSubstitution.DynamicConstant> getAnnotationType() { return MemberSubstitution.DynamicConstant.class; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.DynamicConstant> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.DynamicConstant> annotation) { return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForDynamicConstant((String)annotation.getValue(NAME).resolve(String.class), target.getType().asErasure(), (JavaConstant.MethodHandle.HandleType)((EnumerationDescription)annotation.getValue(BOOTSTRAP_TYPE).resolve(EnumerationDescription.class)).load(JavaConstant.MethodHandle.HandleType.class), (TypeDescription)annotation.getValue(BOOTSTRAP_OWNER).resolve(TypeDescription.class), (String)annotation.getValue(BOOTSTRAP_NAME).resolve(String.class), (TypeDescription)annotation.getValue(BOOTSTRAP_RETURN_TYPE).resolve(TypeDescription.class), Arrays.asList((Object[])annotation.getValue(BOOTSTRAP_PARAMETER_TYPES).resolve(TypeDescription[].class)), Collections.emptyList(), ((Boolean)annotation.getValue(INVOKEDYNAMIC).resolve(Boolean.class)).booleanValue()); }
/*      */              }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           @Enhance
/*      */           public static abstract class ForField
/*      */             implements OffsetMapping
/*      */           {
/*      */             private static final MethodDescription.InDefinedShape FIELD_VALUE_VALUE;
/*      */ 
/*      */             
/*      */             private static final MethodDescription.InDefinedShape FIELD_VALUE_DECLARING_TYPE;
/*      */ 
/*      */             
/*      */             private static final MethodDescription.InDefinedShape FIELD_VALUE_TYPING;
/*      */ 
/*      */             
/*      */             private final TypeDescription.Generic target;
/*      */ 
/*      */             
/*      */             @MaybeNull
/*      */             @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*      */             private final Assigner.Typing typing;
/*      */ 
/*      */ 
/*      */             
/*      */             static {
/* 4950 */               MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.FieldValue.class).getDeclaredMethods();
/* 4951 */               FIELD_VALUE_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly();
/* 4952 */               FIELD_VALUE_DECLARING_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("declaringType"))).getOnly();
/* 4953 */               FIELD_VALUE_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected ForField(TypeDescription.Generic target, @MaybeNull Assigner.Typing typing) {
/* 4975 */               this.target = target;
/* 4976 */               this.typing = typing;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 4983 */               FieldDescription fieldDescription = resolve(instrumentedType, instrumentedMethod);
/* 4984 */               if (!fieldDescription.isStatic() && instrumentedMethod.isStatic()) {
/* 4985 */                 throw new IllegalStateException("Cannot access non-static field " + fieldDescription + " from static method " + instrumentedMethod);
/*      */               }
/* 4987 */               StackManipulation assignment = assigner.assign(fieldDescription.getType(), this.target, (this.typing == null) ? typing : this.typing);
/* 4988 */               if (!assignment.isValid()) {
/* 4989 */                 throw new IllegalStateException("Cannot assign " + fieldDescription + " to " + this.target);
/*      */               }
/* 4991 */               return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved.ForStackManipulation((StackManipulation)new StackManipulation.Compound(new StackManipulation[] { fieldDescription.isStatic() ? (StackManipulation)StackManipulation.Trivial.INSTANCE : 
/*      */                       
/* 4993 */                       MethodVariableAccess.loadThis(), FieldAccess.forField(fieldDescription).read(), assignment }));
/*      */             }
/*      */             protected abstract FieldDescription resolve(TypeDescription param5TypeDescription, MethodDescription param5MethodDescription);
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               if (this == param5Object)
/*      */                 return true; 
/*      */               if (param5Object == null)
/*      */                 return false; 
/*      */               if (getClass() != param5Object.getClass())
/*      */                 return false; 
/*      */               Assigner.Typing typing1 = ((ForField)param5Object).typing;
/*      */               Assigner.Typing typing2 = this.typing;
/*      */               if (typing1 != null) {
/*      */                 if (typing2 != null) {
/*      */                   if (!typing2.equals(typing1))
/*      */                     return false; 
/*      */                 } else {
/*      */                   return false;
/*      */                 } 
/*      */               } else if (typing2 != null) {
/*      */                 return false;
/*      */               } 
/*      */               return !!this.target.equals(((ForField)param5Object).target);
/*      */             }
/*      */             
/*      */             public int hashCode() {
/*      */               Assigner.Typing typing = this.typing;
/*      */               if (typing != null);
/*      */               return (getClass().hashCode() * 31 + this.target.hashCode()) * 31 + typing.hashCode();
/*      */             }
/*      */             
/*      */             @Enhance
/*      */             public static abstract class Unresolved extends ForField { protected static final String BEAN_PROPERTY = "";
/*      */               private final String name;
/*      */               
/*      */               protected Unresolved(TypeDescription.Generic target, Assigner.Typing typing, String name) {
/* 5029 */                 super(target, typing);
/* 5030 */                 this.name = name;
/*      */               }
/*      */ 
/*      */               
/*      */               protected FieldDescription resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 5035 */                 FieldLocator locator = fieldLocator(instrumentedType);
/*      */ 
/*      */                 
/* 5038 */                 FieldLocator.Resolution resolution = this.name.equals("") ? FieldLocator.Resolution.Simple.ofBeanAccessor(locator, instrumentedMethod) : locator.locate(this.name);
/* 5039 */                 if (!resolution.isResolved()) {
/* 5040 */                   throw new IllegalStateException("Cannot locate field named " + this.name + " for " + instrumentedType);
/*      */                 }
/* 5042 */                 return resolution.getField();
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               protected abstract FieldLocator fieldLocator(TypeDescription param7TypeDescription);
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return !super.equals(param7Object) ? false : ((this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.name.equals(((Unresolved)param7Object).name)))));
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return super.hashCode() * 31 + this.name.hashCode();
/*      */               }
/*      */ 
/*      */               
/*      */               public static class WithImplicitType
/*      */                 extends Unresolved
/*      */               {
/*      */                 protected WithImplicitType(TypeDescription.Generic target, AnnotationDescription.Loadable<MemberSubstitution.FieldValue> annotation) {
/* 5066 */                   this(target, (Assigner.Typing)((EnumerationDescription)annotation
/* 5067 */                       .getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$000()).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (String)annotation
/* 5068 */                       .getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$100()).resolve(String.class));
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public WithImplicitType(TypeDescription.Generic target, Assigner.Typing typing, String name) {
/* 5079 */                   super(target, typing, name);
/*      */                 }
/*      */ 
/*      */                 
/*      */                 protected FieldLocator fieldLocator(TypeDescription instrumentedType) {
/* 5084 */                   return (FieldLocator)new FieldLocator.ForClassHierarchy(instrumentedType);
/*      */                 }
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               @Enhance
/*      */               public static class WithExplicitType
/*      */                 extends Unresolved
/*      */               {
/*      */                 private final TypeDescription declaringType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 protected WithExplicitType(TypeDescription.Generic target, AnnotationDescription.Loadable<MemberSubstitution.FieldValue> annotation, TypeDescription declaringType) {
/* 5107 */                   this(target, (Assigner.Typing)((EnumerationDescription)annotation
/* 5108 */                       .getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$000()).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (String)annotation
/* 5109 */                       .getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$100()).resolve(String.class), declaringType);
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public WithExplicitType(TypeDescription.Generic target, Assigner.Typing typing, String name, TypeDescription declaringType) {
/* 5122 */                   super(target, typing, name);
/* 5123 */                   this.declaringType = declaringType;
/*      */                 }
/*      */ 
/*      */                 
/*      */                 protected FieldLocator fieldLocator(TypeDescription instrumentedType) {
/* 5128 */                   if (!this.declaringType.represents(TargetType.class) && !instrumentedType.isAssignableTo(this.declaringType)) {
/* 5129 */                     throw new IllegalStateException(this.declaringType + " is no super type of " + instrumentedType);
/*      */                   }
/* 5131 */                   return (FieldLocator)new FieldLocator.ForExactType(TargetType.resolve(this.declaringType, instrumentedType));
/*      */                 }
/*      */                 
/*      */                 public boolean equals(@MaybeNull Object param8Object) {
/*      */                   return !super.equals(param8Object) ? false : ((this == param8Object) ? true : ((param8Object == null) ? false : ((getClass() != param8Object.getClass()) ? false : (!!this.declaringType.equals(((WithExplicitType)param8Object).declaringType)))));
/*      */                 }
/*      */                 
/*      */                 public int hashCode() {
/*      */                   return super.hashCode() * 31 + this.declaringType.hashCode();
/*      */                 } }
/*      */               
/*      */               protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.FieldValue> {
/* 5143 */                 INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public Class<MemberSubstitution.FieldValue> getAnnotationType() {
/* 5149 */                   return MemberSubstitution.FieldValue.class;
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldValue> annotation) {
/* 5156 */                   TypeDescription declaringType = (TypeDescription)annotation.getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$200()).resolve(TypeDescription.class);
/* 5157 */                   return declaringType.represents(void.class) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Unresolved.WithImplicitType(target
/* 5158 */                       .getDeclaringType().asGenericType(), annotation) : new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Unresolved.WithExplicitType(target
/* 5159 */                       .getDeclaringType().asGenericType(), annotation, declaringType);
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldValue> annotation) {
/* 5166 */                   TypeDescription declaringType = (TypeDescription)annotation.getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$200()).resolve(TypeDescription.class);
/* 5167 */                   return declaringType.represents(void.class) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Unresolved.WithImplicitType(target
/* 5168 */                       .getType(), annotation) : new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Unresolved.WithExplicitType(target
/* 5169 */                       .getType(), annotation, declaringType);
/*      */                 }
/*      */               } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             public static class Resolved
/*      */               extends ForField
/*      */             {
/*      */               private final FieldDescription fieldDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Resolved(TypeDescription.Generic target, Assigner.Typing typing, FieldDescription fieldDescription) {
/* 5193 */                 super(target, typing);
/* 5194 */                 this.fieldDescription = fieldDescription;
/*      */               }
/*      */ 
/*      */               
/*      */               @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming declaring type for type member.")
/*      */               protected FieldDescription resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 5200 */                 if (!this.fieldDescription.isStatic() && !this.fieldDescription.getDeclaringType().asErasure().isAssignableFrom(instrumentedType))
/* 5201 */                   throw new IllegalStateException(this.fieldDescription + " is no member of " + instrumentedType); 
/* 5202 */                 if (!this.fieldDescription.isVisibleTo(instrumentedType)) {
/* 5203 */                   throw new IllegalStateException("Cannot access " + this.fieldDescription + " from " + instrumentedType);
/*      */                 }
/* 5205 */                 return this.fieldDescription;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return !super.equals(param7Object) ? false : ((this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.fieldDescription.equals(((Resolved)param7Object).fieldDescription)))));
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return super.hashCode() * 31 + this.fieldDescription.hashCode();
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               @Enhance
/*      */               public static class Factory<T extends Annotation>
/*      */                 extends MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory.AbstractBase<T>
/*      */               {
/*      */                 private final Class<T> annotationType;
/*      */ 
/*      */                 
/*      */                 private final FieldDescription fieldDescription;
/*      */ 
/*      */                 
/*      */                 private final Assigner.Typing typing;
/*      */ 
/*      */ 
/*      */                 
/*      */                 public Factory(Class<T> annotationType, FieldDescription fieldDescription) {
/* 5238 */                   this(annotationType, fieldDescription, Assigner.Typing.STATIC);
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public Factory(Class<T> annotationType, FieldDescription fieldDescription, Assigner.Typing typing) {
/* 5249 */                   this.annotationType = annotationType;
/* 5250 */                   this.fieldDescription = fieldDescription;
/* 5251 */                   this.typing = typing;
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public Class<T> getAnnotationType() {
/* 5258 */                   return this.annotationType;
/*      */                 }
/*      */                 
/*      */                 protected MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(TypeDescription.Generic target, AnnotationDescription.Loadable<T> annotation)
/*      */                 {
/* 5263 */                   return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Resolved(target, this.typing, this.fieldDescription);
/*      */                 } public boolean equals(@MaybeNull Object param8Object) { return (this == param8Object) ? true : ((param8Object == null) ? false : ((getClass() != param8Object.getClass()) ? false : (!this.typing.equals(((Factory)param8Object).typing) ? false : (!this.annotationType.equals(((Factory)param8Object).annotationType) ? false : (!!this.fieldDescription.equals(((Factory)param8Object).fieldDescription)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.fieldDescription.hashCode()) * 31 + this.typing.hashCode(); } }
/*      */             }
/*      */           } @Enhance public static abstract class Unresolved extends OffsetMapping.ForField { protected static final String BEAN_PROPERTY = ""; private final String name; protected Unresolved(TypeDescription.Generic target, Assigner.Typing typing, String name) { super(target, typing); this.name = name; } protected FieldDescription resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) { FieldLocator locator = fieldLocator(instrumentedType); FieldLocator.Resolution resolution = this.name.equals("") ? FieldLocator.Resolution.Simple.ofBeanAccessor(locator, instrumentedMethod) : locator.locate(this.name); if (!resolution.isResolved()) throw new IllegalStateException("Cannot locate field named " + this.name + " for " + instrumentedType);  return resolution.getField(); } protected abstract FieldLocator fieldLocator(TypeDescription param5TypeDescription); public boolean equals(@MaybeNull Object param5Object) { return !super.equals(param5Object) ? false : ((this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.name.equals(((Unresolved)param5Object).name))))); }
/*      */             public int hashCode() { return super.hashCode() * 31 + this.name.hashCode(); }
/*      */             public static class WithImplicitType extends Unresolved { protected WithImplicitType(TypeDescription.Generic target, AnnotationDescription.Loadable<MemberSubstitution.FieldValue> annotation) { this(target, (Assigner.Typing)((EnumerationDescription)annotation.getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$000()).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (String)annotation.getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$100()).resolve(String.class)); }
/*      */               public WithImplicitType(TypeDescription.Generic target, Assigner.Typing typing, String name) { super(target, typing, name); }
/*      */               protected FieldLocator fieldLocator(TypeDescription instrumentedType) { return (FieldLocator)new FieldLocator.ForClassHierarchy(instrumentedType); } }
/*      */             @Enhance public static class WithExplicitType extends Unresolved { private final TypeDescription declaringType;
/*      */               protected WithExplicitType(TypeDescription.Generic target, AnnotationDescription.Loadable<MemberSubstitution.FieldValue> annotation, TypeDescription declaringType) { this(target, (Assigner.Typing)((EnumerationDescription)annotation.getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$000()).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (String)annotation.getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$100()).resolve(String.class), declaringType); }
/*      */               public WithExplicitType(TypeDescription.Generic target, Assigner.Typing typing, String name, TypeDescription declaringType) { super(target, typing, name); this.declaringType = declaringType; }
/*      */               protected FieldLocator fieldLocator(TypeDescription instrumentedType) { if (!this.declaringType.represents(TargetType.class) && !instrumentedType.isAssignableTo(this.declaringType)) throw new IllegalStateException(this.declaringType + " is no super type of " + instrumentedType);  return (FieldLocator)new FieldLocator.ForExactType(TargetType.resolve(this.declaringType, instrumentedType)); }
/*      */               public boolean equals(@MaybeNull Object param8Object) { return !super.equals(param8Object) ? false : ((this == param8Object) ? true : ((param8Object == null) ? false : ((getClass() != param8Object.getClass()) ? false : (!!this.declaringType.equals(((WithExplicitType)param8Object).declaringType))))); }
/*      */               public int hashCode() { return super.hashCode() * 31 + this.declaringType.hashCode(); } }
/*      */             protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.FieldValue> { INSTANCE;
/*      */               public Class<MemberSubstitution.FieldValue> getAnnotationType() { return MemberSubstitution.FieldValue.class; }
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldValue> annotation) { TypeDescription declaringType = (TypeDescription)annotation.getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$200()).resolve(TypeDescription.class); return declaringType.represents(void.class) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Unresolved.WithImplicitType(target.getDeclaringType().asGenericType(), annotation) : new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Unresolved.WithExplicitType(target.getDeclaringType().asGenericType(), annotation, declaringType); }
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldValue> annotation) { TypeDescription declaringType = (TypeDescription)annotation.getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$200()).resolve(TypeDescription.class); return declaringType.represents(void.class) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Unresolved.WithImplicitType(target.getType(), annotation) : new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Unresolved.WithExplicitType(target.getType(), annotation, declaringType); } } }
/*      */           protected enum Factory implements OffsetMapping.Factory<MemberSubstitution.FieldValue> { INSTANCE;
/*      */             public Class<MemberSubstitution.FieldValue> getAnnotationType() { return MemberSubstitution.FieldValue.class; }
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldValue> annotation) { TypeDescription declaringType = (TypeDescription)annotation.getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$200()).resolve(TypeDescription.class); return declaringType.represents(void.class) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Unresolved.WithImplicitType(target.getDeclaringType().asGenericType(), annotation) : new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Unresolved.WithExplicitType(target.getDeclaringType().asGenericType(), annotation, declaringType); }
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldValue> annotation) { TypeDescription declaringType = (TypeDescription)annotation.getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$200()).resolve(TypeDescription.class); return declaringType.represents(void.class) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Unresolved.WithImplicitType(target.getType(), annotation) : new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Unresolved.WithExplicitType(target.getType(), annotation, declaringType); } }
/*      */           @Enhance public static abstract class ForFieldHandle implements OffsetMapping { private final Access access;
/* 5286 */             protected ForFieldHandle(Access access) { this.access = access; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 5293 */               FieldDescription fieldDescription = resolve(instrumentedType, instrumentedMethod);
/* 5294 */               if (!fieldDescription.isStatic() && instrumentedMethod.isStatic()) {
/* 5295 */                 throw new IllegalStateException("Cannot access non-static field " + fieldDescription + " from static method " + instrumentedMethod);
/*      */               }
/* 5297 */               if (fieldDescription.isStatic()) {
/* 5298 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved.ForStackManipulation(this.access.resolve((FieldDescription.InDefinedShape)fieldDescription.asDefined()).toStackManipulation());
/*      */               }
/* 5300 */               return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved.ForStackManipulation((StackManipulation)new StackManipulation.Compound(new StackManipulation[] { this.access
/* 5301 */                       .resolve((FieldDescription.InDefinedShape)fieldDescription.asDefined()).toStackManipulation(), MethodVariableAccess.REFERENCE.loadFrom(0), 
/* 5302 */                       (StackManipulation)MethodInvocation.invoke((MethodDescription.InDefinedShape)new MethodDescription.Latent(JavaType.METHOD_HANDLE.getTypeStub(), new MethodDescription.Token("bindTo", 1, JavaType.METHOD_HANDLE
/*      */                             
/* 5304 */                             .getTypeStub().asGenericType(), (List)new TypeList.Generic.Explicit(new TypeDefinition[] {
/* 5305 */                                 (TypeDefinition)TypeDefinition.Sort.describe(Object.class)
/*      */                               })))) }));
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             protected abstract FieldDescription resolve(TypeDescription param5TypeDescription, MethodDescription param5MethodDescription);
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.access.equals(((ForFieldHandle)param5Object).access))));
/*      */             }
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               return getClass().hashCode() * 31 + this.access.hashCode();
/*      */             }
/*      */ 
/*      */             
/*      */             public enum Access
/*      */             {
/* 5326 */               GETTER
/*      */               {
/*      */                 protected JavaConstant.MethodHandle resolve(FieldDescription.InDefinedShape fieldDescription) {
/* 5329 */                   return JavaConstant.MethodHandle.ofGetter(fieldDescription);
/*      */                 }
/*      */               },
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 5336 */               SETTER
/*      */               {
/*      */                 protected JavaConstant.MethodHandle resolve(FieldDescription.InDefinedShape fieldDescription) {
/* 5339 */                   return JavaConstant.MethodHandle.ofSetter(fieldDescription);
/*      */                 }
/*      */               };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected abstract JavaConstant.MethodHandle resolve(FieldDescription.InDefinedShape param7InDefinedShape);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             public static abstract class Unresolved
/*      */               extends ForFieldHandle
/*      */             {
/*      */               protected static final String BEAN_PROPERTY = "";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final String name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Unresolved(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access access, String name) {
/* 5375 */                 super(access);
/* 5376 */                 this.name = name;
/*      */               }
/*      */ 
/*      */               
/*      */               protected FieldDescription resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 5381 */                 FieldLocator locator = fieldLocator(instrumentedType);
/*      */ 
/*      */                 
/* 5384 */                 FieldLocator.Resolution resolution = this.name.equals("") ? FieldLocator.Resolution.Simple.ofBeanAccessor(locator, instrumentedMethod) : locator.locate(this.name);
/* 5385 */                 if (!resolution.isResolved()) {
/* 5386 */                   throw new IllegalStateException("Cannot locate field named " + this.name + " for " + instrumentedType);
/*      */                 }
/* 5388 */                 return resolution.getField();
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               protected abstract FieldLocator fieldLocator(TypeDescription param7TypeDescription);
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return !super.equals(param7Object) ? false : ((this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.name.equals(((Unresolved)param7Object).name)))));
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return super.hashCode() * 31 + this.name.hashCode();
/*      */               }
/*      */ 
/*      */               
/*      */               public static class WithImplicitType
/*      */                 extends Unresolved
/*      */               {
/*      */                 public WithImplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access access, String name) {
/* 5412 */                   super(access, name);
/*      */                 }
/*      */ 
/*      */                 
/*      */                 protected FieldLocator fieldLocator(TypeDescription instrumentedType) {
/* 5417 */                   return (FieldLocator)new FieldLocator.ForClassHierarchy(instrumentedType);
/*      */                 }
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               @Enhance
/*      */               public static class WithExplicitType
/*      */                 extends Unresolved
/*      */               {
/*      */                 private final TypeDescription declaringType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public WithExplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access access, String name, TypeDescription declaringType) {
/* 5440 */                   super(access, name);
/* 5441 */                   this.declaringType = declaringType;
/*      */                 }
/*      */ 
/*      */                 
/*      */                 protected FieldLocator fieldLocator(TypeDescription instrumentedType) {
/* 5446 */                   if (!this.declaringType.represents(TargetType.class) && !instrumentedType.isAssignableTo(this.declaringType)) {
/* 5447 */                     throw new IllegalStateException(this.declaringType + " is no super type of " + instrumentedType);
/*      */                   }
/* 5449 */                   return (FieldLocator)new FieldLocator.ForExactType(TargetType.resolve(this.declaringType, instrumentedType));
/*      */                 }
/*      */                 
/*      */                 public boolean equals(@MaybeNull Object param8Object) {
/*      */                   return !super.equals(param8Object) ? false : ((this == param8Object) ? true : ((param8Object == null) ? false : ((getClass() != param8Object.getClass()) ? false : (!!this.declaringType.equals(((WithExplicitType)param8Object).declaringType)))));
/*      */                 }
/*      */                 
/*      */                 public int hashCode() {
/*      */                   return super.hashCode() * 31 + this.declaringType.hashCode();
/*      */                 } }
/*      */               
/*      */               protected enum GetterFactory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.FieldGetterHandle> {
/* 5461 */                 INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 private static final MethodDescription.InDefinedShape FIELD_GETTER_HANDLE_DECLARING_TYPE;
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 private static final MethodDescription.InDefinedShape FIELD_GETTER_HANDLE_VALUE;
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 static {
/* 5477 */                   MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.FieldGetterHandle.class).getDeclaredMethods();
/* 5478 */                   FIELD_GETTER_HANDLE_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly();
/* 5479 */                   FIELD_GETTER_HANDLE_DECLARING_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("declaringType"))).getOnly();
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public Class<MemberSubstitution.FieldGetterHandle> getAnnotationType() {
/* 5486 */                   return MemberSubstitution.FieldGetterHandle.class;
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldGetterHandle> annotation) {
/* 5493 */                   throw new UnsupportedOperationException("This factory does not support binding a method receiver");
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldGetterHandle> annotation) {
/* 5500 */                   if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) {
/* 5501 */                     throw new IllegalStateException("Cannot assign method handle to " + target);
/*      */                   }
/* 5503 */                   TypeDescription declaringType = (TypeDescription)annotation.getValue(FIELD_GETTER_HANDLE_DECLARING_TYPE).resolve(TypeDescription.class);
/* 5504 */                   return declaringType.represents(void.class) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Unresolved.WithImplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access.GETTER, (String)annotation
/* 5505 */                       .getValue(FIELD_GETTER_HANDLE_VALUE).resolve(String.class)) : new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Unresolved.WithExplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access.GETTER, (String)annotation
/* 5506 */                       .getValue(FIELD_GETTER_HANDLE_VALUE).resolve(String.class), declaringType);
/*      */                 }
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected enum SetterFactory
/*      */                 implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.FieldSetterHandle>
/*      */               {
/* 5518 */                 INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 private static final MethodDescription.InDefinedShape FIELD_SETTER_HANDLE_DECLARING_TYPE;
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 private static final MethodDescription.InDefinedShape FIELD_SETTER_HANDLE_VALUE;
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 static {
/* 5534 */                   MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.FieldSetterHandle.class).getDeclaredMethods();
/* 5535 */                   FIELD_SETTER_HANDLE_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly();
/* 5536 */                   FIELD_SETTER_HANDLE_DECLARING_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("declaringType"))).getOnly();
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public Class<MemberSubstitution.FieldSetterHandle> getAnnotationType() {
/* 5543 */                   return MemberSubstitution.FieldSetterHandle.class;
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldSetterHandle> annotation) {
/* 5550 */                   throw new UnsupportedOperationException("This factory does not support binding a method receiver");
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldSetterHandle> annotation) {
/* 5557 */                   if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) {
/* 5558 */                     throw new IllegalStateException("Cannot assign method handle to " + target);
/*      */                   }
/* 5560 */                   TypeDescription declaringType = (TypeDescription)annotation.getValue(FIELD_SETTER_HANDLE_DECLARING_TYPE).resolve(TypeDescription.class);
/* 5561 */                   return declaringType.represents(void.class) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Unresolved.WithImplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access.SETTER, (String)annotation
/* 5562 */                       .getValue(FIELD_SETTER_HANDLE_VALUE).resolve(String.class)) : new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Unresolved.WithExplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access.SETTER, (String)annotation
/* 5563 */                       .getValue(FIELD_SETTER_HANDLE_VALUE).resolve(String.class), declaringType);
/*      */                 }
/*      */               }
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             public static class Resolved
/*      */               extends ForFieldHandle
/*      */             {
/*      */               private final FieldDescription fieldDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public Resolved(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access access, FieldDescription fieldDescription) {
/* 5586 */                 super(access);
/* 5587 */                 this.fieldDescription = fieldDescription;
/*      */               }
/*      */ 
/*      */               
/*      */               @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming declaring type for type member.")
/*      */               protected FieldDescription resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 5593 */                 if (!this.fieldDescription.isStatic() && !this.fieldDescription.getDeclaringType().asErasure().isAssignableFrom(instrumentedType))
/* 5594 */                   throw new IllegalStateException(this.fieldDescription + " is no member of " + instrumentedType); 
/* 5595 */                 if (!this.fieldDescription.isVisibleTo(instrumentedType)) {
/* 5596 */                   throw new IllegalStateException("Cannot access " + this.fieldDescription + " from " + instrumentedType);
/*      */                 }
/* 5598 */                 return this.fieldDescription;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return !super.equals(param7Object) ? false : ((this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.fieldDescription.equals(((Resolved)param7Object).fieldDescription)))));
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return super.hashCode() * 31 + this.fieldDescription.hashCode();
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               @Enhance
/*      */               public static class Factory<T extends Annotation>
/*      */                 implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<T>
/*      */               {
/*      */                 private final Class<T> annotationType;
/*      */ 
/*      */                 
/*      */                 private final FieldDescription fieldDescription;
/*      */ 
/*      */                 
/*      */                 private final MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access access;
/*      */ 
/*      */ 
/*      */                 
/*      */                 public Factory(Class<T> annotationType, FieldDescription fieldDescription, MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access access) {
/* 5632 */                   this.annotationType = annotationType;
/* 5633 */                   this.fieldDescription = fieldDescription;
/* 5634 */                   this.access = access;
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public Class<T> getAnnotationType() {
/* 5641 */                   return this.annotationType;
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation) {
/* 5648 */                   throw new UnsupportedOperationException("This factory does not support binding a method receiver");
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation) {
/* 5655 */                   if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) {
/* 5656 */                     throw new IllegalStateException("Cannot assign method handle to " + target);
/*      */                   }
/* 5658 */                   return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Resolved(this.access, this.fieldDescription);
/*      */                 } public boolean equals(@MaybeNull Object param8Object) { return (this == param8Object) ? true : ((param8Object == null) ? false : ((getClass() != param8Object.getClass()) ? false : (!this.access.equals(((Factory)param8Object).access) ? false : (!this.annotationType.equals(((Factory)param8Object).annotationType) ? false : (!!this.fieldDescription.equals(((Factory)param8Object).fieldDescription)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.fieldDescription.hashCode()) * 31 + this.access.hashCode(); }
/*      */               }
/*      */             } } @Enhance public static abstract class Unresolved extends OffsetMapping.ForFieldHandle { protected static final String BEAN_PROPERTY = ""; private final String name; public Unresolved(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access access, String name) { super(access); this.name = name; } protected FieldDescription resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) { FieldLocator locator = fieldLocator(instrumentedType); FieldLocator.Resolution resolution = this.name.equals("") ? FieldLocator.Resolution.Simple.ofBeanAccessor(locator, instrumentedMethod) : locator.locate(this.name); if (!resolution.isResolved()) throw new IllegalStateException("Cannot locate field named " + this.name + " for " + instrumentedType);  return resolution.getField(); } protected abstract FieldLocator fieldLocator(TypeDescription param5TypeDescription); public boolean equals(@MaybeNull Object param5Object) { return !super.equals(param5Object) ? false : ((this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.name.equals(((Unresolved)param5Object).name))))); } public int hashCode() { return super.hashCode() * 31 + this.name.hashCode(); } public static class WithImplicitType extends Unresolved { public WithImplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access access, String name) { super(access, name); } protected FieldLocator fieldLocator(TypeDescription instrumentedType) { return (FieldLocator)new FieldLocator.ForClassHierarchy(instrumentedType); } } @Enhance public static class WithExplicitType extends Unresolved { private final TypeDescription declaringType;
/*      */               public WithExplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access access, String name, TypeDescription declaringType) { super(access, name); this.declaringType = declaringType; }
/*      */               protected FieldLocator fieldLocator(TypeDescription instrumentedType) { if (!this.declaringType.represents(TargetType.class) && !instrumentedType.isAssignableTo(this.declaringType)) throw new IllegalStateException(this.declaringType + " is no super type of " + instrumentedType);  return (FieldLocator)new FieldLocator.ForExactType(TargetType.resolve(this.declaringType, instrumentedType)); }
/*      */               public boolean equals(@MaybeNull Object param8Object) { return !super.equals(param8Object) ? false : ((this == param8Object) ? true : ((param8Object == null) ? false : ((getClass() != param8Object.getClass()) ? false : (!!this.declaringType.equals(((WithExplicitType)param8Object).declaringType))))); }
/*      */               public int hashCode() { return super.hashCode() * 31 + this.declaringType.hashCode(); } }
/*      */             protected enum GetterFactory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.FieldGetterHandle> { INSTANCE; private static final MethodDescription.InDefinedShape FIELD_GETTER_HANDLE_DECLARING_TYPE; private static final MethodDescription.InDefinedShape FIELD_GETTER_HANDLE_VALUE;
/*      */               static { MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.FieldGetterHandle.class).getDeclaredMethods(); FIELD_GETTER_HANDLE_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly(); FIELD_GETTER_HANDLE_DECLARING_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("declaringType"))).getOnly(); }
/*      */               public Class<MemberSubstitution.FieldGetterHandle> getAnnotationType() { return MemberSubstitution.FieldGetterHandle.class; }
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldGetterHandle> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); }
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldGetterHandle> annotation) { if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) throw new IllegalStateException("Cannot assign method handle to " + target);  TypeDescription declaringType = (TypeDescription)annotation.getValue(FIELD_GETTER_HANDLE_DECLARING_TYPE).resolve(TypeDescription.class); return declaringType.represents(void.class) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Unresolved.WithImplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access.GETTER, (String)annotation.getValue(FIELD_GETTER_HANDLE_VALUE).resolve(String.class)) : new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Unresolved.WithExplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access.GETTER, (String)annotation.getValue(FIELD_GETTER_HANDLE_VALUE).resolve(String.class), declaringType); } }
/*      */             protected enum SetterFactory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.FieldSetterHandle> { INSTANCE; private static final MethodDescription.InDefinedShape FIELD_SETTER_HANDLE_DECLARING_TYPE; private static final MethodDescription.InDefinedShape FIELD_SETTER_HANDLE_VALUE;
/*      */               static { MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.FieldSetterHandle.class).getDeclaredMethods(); FIELD_SETTER_HANDLE_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly(); FIELD_SETTER_HANDLE_DECLARING_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("declaringType"))).getOnly(); }
/*      */               public Class<MemberSubstitution.FieldSetterHandle> getAnnotationType() { return MemberSubstitution.FieldSetterHandle.class; }
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldSetterHandle> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); }
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldSetterHandle> annotation) { if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) throw new IllegalStateException("Cannot assign method handle to " + target);  TypeDescription declaringType = (TypeDescription)annotation.getValue(FIELD_SETTER_HANDLE_DECLARING_TYPE).resolve(TypeDescription.class); return declaringType.represents(void.class) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Unresolved.WithImplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access.SETTER, (String)annotation.getValue(FIELD_SETTER_HANDLE_VALUE).resolve(String.class)) : new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Unresolved.WithExplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access.SETTER, (String)annotation.getValue(FIELD_SETTER_HANDLE_VALUE).resolve(String.class), declaringType); } } }
/*      */           protected enum GetterFactory implements OffsetMapping.Factory<MemberSubstitution.FieldGetterHandle> { INSTANCE; private static final MethodDescription.InDefinedShape FIELD_GETTER_HANDLE_DECLARING_TYPE; private static final MethodDescription.InDefinedShape FIELD_GETTER_HANDLE_VALUE;
/*      */             static { MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.FieldGetterHandle.class).getDeclaredMethods(); FIELD_GETTER_HANDLE_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly(); FIELD_GETTER_HANDLE_DECLARING_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("declaringType"))).getOnly(); }
/*      */             public Class<MemberSubstitution.FieldGetterHandle> getAnnotationType() { return MemberSubstitution.FieldGetterHandle.class; }
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldGetterHandle> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); }
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldGetterHandle> annotation) { if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) throw new IllegalStateException("Cannot assign method handle to " + target);  TypeDescription declaringType = (TypeDescription)annotation.getValue(FIELD_GETTER_HANDLE_DECLARING_TYPE).resolve(TypeDescription.class); return declaringType.represents(void.class) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Unresolved.WithImplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access.GETTER, (String)annotation.getValue(FIELD_GETTER_HANDLE_VALUE).resolve(String.class)) : new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Unresolved.WithExplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access.GETTER, (String)annotation.getValue(FIELD_GETTER_HANDLE_VALUE).resolve(String.class), declaringType); } }
/*      */           protected enum SetterFactory implements OffsetMapping.Factory<MemberSubstitution.FieldSetterHandle> { INSTANCE; private static final MethodDescription.InDefinedShape FIELD_SETTER_HANDLE_DECLARING_TYPE; private static final MethodDescription.InDefinedShape FIELD_SETTER_HANDLE_VALUE;
/*      */             static { MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.FieldSetterHandle.class).getDeclaredMethods(); FIELD_SETTER_HANDLE_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly(); FIELD_SETTER_HANDLE_DECLARING_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("declaringType"))).getOnly(); }
/*      */             public Class<MemberSubstitution.FieldSetterHandle> getAnnotationType() { return MemberSubstitution.FieldSetterHandle.class; }
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldSetterHandle> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); }
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldSetterHandle> annotation) { if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) throw new IllegalStateException("Cannot assign method handle to " + target);  TypeDescription declaringType = (TypeDescription)annotation.getValue(FIELD_SETTER_HANDLE_DECLARING_TYPE).resolve(TypeDescription.class); return declaringType.represents(void.class) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Unresolved.WithImplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access.SETTER, (String)annotation.getValue(FIELD_SETTER_HANDLE_VALUE).resolve(String.class)) : new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Unresolved.WithExplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access.SETTER, (String)annotation.getValue(FIELD_SETTER_HANDLE_VALUE).resolve(String.class), declaringType); } }
/*      */           @Enhance public static class ForOrigin implements OffsetMapping { private final Sort sort; private final MemberSubstitution.Source source;
/* 5687 */             protected ForOrigin(Sort sort, MemberSubstitution.Source source) { this.sort = sort;
/* 5688 */               this.source = source; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 5695 */               return new Resolved(this.sort, this.source, instrumentedMethod);
/*      */             }
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!this.sort.equals(((ForOrigin)param5Object).sort) ? false : (!!this.source.equals(((ForOrigin)param5Object).source)))));
/*      */             }
/*      */             
/*      */             public int hashCode() {
/*      */               return (getClass().hashCode() * 31 + this.sort.hashCode()) * 31 + this.source.hashCode();
/*      */             }
/*      */             
/* 5706 */             protected enum Sort { METHOD
/*      */               {
/*      */                 protected boolean isRepresentable(ByteCodeElement.Member member) {
/* 5709 */                   return (member instanceof MethodDescription && ((MethodDescription)member).isMethod());
/*      */                 }
/*      */ 
/*      */                 
/*      */                 protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) {
/* 5714 */                   return (StackManipulation)MethodConstant.of((MethodDescription.InDefinedShape)((MethodDescription)member).asDefined());
/*      */                 }
/*      */               },
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 5721 */               CONSTRUCTOR
/*      */               {
/*      */                 protected boolean isRepresentable(ByteCodeElement.Member member) {
/* 5724 */                   return (member instanceof MethodDescription && ((MethodDescription)member).isConstructor());
/*      */                 }
/*      */ 
/*      */                 
/*      */                 protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) {
/* 5729 */                   return (StackManipulation)MethodConstant.of((MethodDescription.InDefinedShape)((MethodDescription)member).asDefined());
/*      */                 }
/*      */               },
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 5736 */               FIELD
/*      */               {
/*      */                 protected boolean isRepresentable(ByteCodeElement.Member member) {
/* 5739 */                   return member instanceof FieldDescription;
/*      */                 }
/*      */ 
/*      */                 
/*      */                 protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) {
/* 5744 */                   return (StackManipulation)new FieldConstant((FieldDescription.InDefinedShape)((FieldDescription)member).asDefined());
/*      */                 }
/*      */               },
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 5751 */               EXECUTABLE
/*      */               {
/*      */                 protected boolean isRepresentable(ByteCodeElement.Member member) {
/* 5754 */                   return member instanceof MethodDescription;
/*      */                 }
/*      */ 
/*      */                 
/*      */                 protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) {
/* 5759 */                   return (StackManipulation)MethodConstant.of((MethodDescription.InDefinedShape)((MethodDescription)member).asDefined());
/*      */                 }
/*      */               },
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 5766 */               TYPE
/*      */               {
/*      */                 protected boolean isRepresentable(ByteCodeElement.Member member) {
/* 5769 */                   return true;
/*      */                 }
/*      */ 
/*      */                 
/*      */                 protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) {
/* 5774 */                   return ClassConstant.of(member.getDeclaringType().asErasure());
/*      */                 }
/*      */               },
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 5781 */               LOOKUP
/*      */               {
/*      */                 protected boolean isRepresentable(ByteCodeElement.Member member) {
/* 5784 */                   return true;
/*      */                 }
/*      */ 
/*      */                 
/*      */                 protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) {
/* 5789 */                   return MethodInvocation.lookup();
/*      */                 }
/*      */               },
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 5796 */               METHOD_HANDLE
/*      */               {
/*      */                 protected boolean isRepresentable(ByteCodeElement.Member member) {
/* 5799 */                   return true;
/*      */                 }
/*      */ 
/*      */                 
/*      */                 protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) {
/*      */                   JavaConstant.MethodHandle handle;
/* 5805 */                   if (member instanceof MethodDescription) {
/* 5806 */                     handle = JavaConstant.MethodHandle.of((MethodDescription.InDefinedShape)((MethodDescription)member).asDefined());
/* 5807 */                   } else if (member instanceof FieldDescription) {
/*      */ 
/*      */                     
/* 5810 */                     handle = returnType.represents(void.class) ? JavaConstant.MethodHandle.ofSetter((FieldDescription.InDefinedShape)((FieldDescription)member).asDefined()) : JavaConstant.MethodHandle.ofGetter((FieldDescription.InDefinedShape)((FieldDescription)member).asDefined());
/*      */                   } else {
/* 5812 */                     throw new IllegalStateException("Unexpected byte code element: " + member);
/*      */                   } 
/* 5814 */                   return handle.toStackManipulation();
/*      */                 }
/*      */               },
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 5821 */               METHOD_TYPE
/*      */               {
/*      */                 protected boolean isRepresentable(ByteCodeElement.Member member) {
/* 5824 */                   return true;
/*      */                 }
/*      */ 
/*      */                 
/*      */                 protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) {
/* 5829 */                   return JavaConstant.MethodType.of(returnType, parameterTypes).toStackManipulation();
/*      */                 }
/*      */               },
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 5836 */               STRING
/*      */               {
/*      */                 protected boolean isRepresentable(ByteCodeElement.Member member) {
/* 5839 */                   return true;
/*      */                 }
/*      */ 
/*      */                 
/*      */                 protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) {
/* 5844 */                   return (StackManipulation)new TextConstant(member.toString());
/*      */                 }
/*      */               };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected abstract boolean isRepresentable(ByteCodeElement.Member param7Member);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected abstract StackManipulation resolve(ByteCodeElement.Member param7Member, List<TypeDescription> param7List, TypeDescription param7TypeDescription); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             protected enum Factory
/*      */               implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.Origin>
/*      */             {
/* 5875 */               INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 5880 */               private static final MethodDescription.InDefinedShape ORIGIN_TYPE = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(MemberSubstitution.Origin.class)
/* 5881 */                 .getDeclaredMethods()
/* 5882 */                 .filter((ElementMatcher)ElementMatchers.named("source")))
/* 5883 */                 .getOnly();
/*      */               static {
/*      */               
/*      */               }
/*      */               
/*      */               public Class<MemberSubstitution.Origin> getAnnotationType() {
/* 5889 */                 return MemberSubstitution.Origin.class;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Origin> annotation) {
/* 5896 */                 throw new UnsupportedOperationException("This factory does not support binding a method receiver");
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Origin> annotation) {
/*      */                 MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort sort;
/* 5904 */                 if (target.getType().asErasure().represents(Class.class)) {
/* 5905 */                   sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.TYPE;
/* 5906 */                 } else if (target.getType().asErasure().represents(Method.class)) {
/* 5907 */                   sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.METHOD;
/* 5908 */                 } else if (target.getType().asErasure().represents(Constructor.class)) {
/* 5909 */                   sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.CONSTRUCTOR;
/* 5910 */                 } else if (target.getType().asErasure().represents(Field.class)) {
/* 5911 */                   sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.FIELD;
/* 5912 */                 } else if (JavaType.EXECUTABLE.getTypeStub().equals(target.getType().asErasure())) {
/* 5913 */                   sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.EXECUTABLE;
/* 5914 */                 } else if (JavaType.METHOD_HANDLE.getTypeStub().equals(target.getType().asErasure())) {
/* 5915 */                   sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.METHOD_HANDLE;
/* 5916 */                 } else if (JavaType.METHOD_TYPE.getTypeStub().equals(target.getType().asErasure())) {
/* 5917 */                   sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.METHOD_TYPE;
/* 5918 */                 } else if (JavaType.METHOD_HANDLES_LOOKUP.getTypeStub().equals(target.getType().asErasure())) {
/* 5919 */                   sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.LOOKUP;
/* 5920 */                 } else if (target.getType().asErasure().isAssignableFrom(String.class)) {
/* 5921 */                   sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.STRING;
/*      */                 } else {
/* 5923 */                   throw new IllegalStateException("Non-supported type " + target.getType() + " for @Origin annotation");
/*      */                 } 
/* 5925 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin(sort, (MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(ORIGIN_TYPE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class));
/*      */               }
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             protected static class Resolved
/*      */               implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved
/*      */             {
/*      */               private final MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort sort;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final MemberSubstitution.Source source;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final MethodDescription instrumentedMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected Resolved(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort sort, MemberSubstitution.Source source, MethodDescription instrumentedMethod) {
/* 5958 */                 this.sort = sort;
/* 5959 */                 this.source = source;
/* 5960 */                 this.instrumentedMethod = instrumentedMethod;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) {
/* 5973 */                 if (!this.source.isRepresentable(this.sort, target, this.instrumentedMethod)) {
/* 5974 */                   throw new IllegalStateException("Cannot represent " + this.sort + " for " + this.source + " in " + this.instrumentedMethod);
/*      */                 }
/* 5976 */                 return this.source.resolve(this.sort, target, parameters, result, this.instrumentedMethod);
/*      */               } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.sort.equals(((Resolved)param7Object).sort) ? false : (!this.source.equals(((Resolved)param7Object).source) ? false : (!!this.instrumentedMethod.equals(((Resolved)param7Object).instrumentedMethod)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.sort.hashCode()) * 31 + this.source.hashCode()) * 31 + this.instrumentedMethod.hashCode(); } } } protected enum Factory implements OffsetMapping.Factory<MemberSubstitution.Origin> { INSTANCE; private static final MethodDescription.InDefinedShape ORIGIN_TYPE = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(MemberSubstitution.Origin.class).getDeclaredMethods().filter((ElementMatcher)ElementMatchers.named("source"))).getOnly();
/*      */             static {  }
/*      */             public Class<MemberSubstitution.Origin> getAnnotationType() { return MemberSubstitution.Origin.class; }
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Origin> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); }
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Origin> annotation) { MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort sort; if (target.getType().asErasure().represents(Class.class)) { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.TYPE; }
/*      */               else if (target.getType().asErasure().represents(Method.class)) { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.METHOD; }
/*      */               else if (target.getType().asErasure().represents(Constructor.class)) { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.CONSTRUCTOR; }
/*      */               else if (target.getType().asErasure().represents(Field.class)) { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.FIELD; }
/*      */               else if (JavaType.EXECUTABLE.getTypeStub().equals(target.getType().asErasure())) { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.EXECUTABLE; }
/*      */               else if (JavaType.METHOD_HANDLE.getTypeStub().equals(target.getType().asErasure()))
/*      */               { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.METHOD_HANDLE; }
/*      */               else if (JavaType.METHOD_TYPE.getTypeStub().equals(target.getType().asErasure()))
/*      */               { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.METHOD_TYPE; }
/*      */               else if (JavaType.METHOD_HANDLES_LOOKUP.getTypeStub().equals(target.getType().asErasure()))
/*      */               { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.LOOKUP; }
/*      */               else if (target.getType().asErasure().isAssignableFrom(String.class))
/*      */               { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.STRING; }
/*      */               else
/*      */               { throw new IllegalStateException("Non-supported type " + target.getType() + " for @Origin annotation"); }
/*      */                return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin(sort, (MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(ORIGIN_TYPE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class)); } }
/*      */           @Enhance public static class ForStubValue implements OffsetMapping { private final MemberSubstitution.Source source;
/* 5998 */             protected ForStubValue(MemberSubstitution.Source source) { this.source = source; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 6005 */               return new Resolved(this.source, instrumentedMethod);
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.source.equals(((ForStubValue)param5Object).source))));
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public int hashCode() {
/*      */               return getClass().hashCode() * 31 + this.source.hashCode();
/*      */             }
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             protected static class Resolved
/*      */               implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved
/*      */             {
/*      */               private final MemberSubstitution.Source source;
/*      */               
/*      */               private final MethodDescription instrumentedMethod;
/*      */ 
/*      */               
/*      */               protected Resolved(MemberSubstitution.Source source, MethodDescription instrumentedMethod) {
/* 6031 */                 this.source = source;
/* 6032 */                 this.instrumentedMethod = instrumentedMethod;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) {
/* 6045 */                 return DefaultValue.of((TypeDefinition)this.source.handle(methodHandle, this.instrumentedMethod).getReturnType());
/*      */               }
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.source.equals(((Resolved)param7Object).source) ? false : (!!this.instrumentedMethod.equals(((Resolved)param7Object).instrumentedMethod)))));
/*      */               }
/*      */               
/*      */               public int hashCode() {
/*      */                 return (getClass().hashCode() * 31 + this.source.hashCode()) * 31 + this.instrumentedMethod.hashCode();
/*      */               }
/*      */             }
/*      */             
/*      */             @Enhance
/* 6058 */             protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.StubValue> { INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 6063 */               private static final MethodDescription.InDefinedShape STUB_VALUE_SOURCE = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(MemberSubstitution.StubValue.class)
/* 6064 */                 .getDeclaredMethods()
/* 6065 */                 .filter((ElementMatcher)ElementMatchers.named("source")))
/* 6066 */                 .getOnly();
/*      */               static {
/*      */               
/*      */               }
/*      */               
/*      */               public Class<MemberSubstitution.StubValue> getAnnotationType() {
/* 6072 */                 return MemberSubstitution.StubValue.class;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.StubValue> annotation) {
/* 6079 */                 throw new UnsupportedOperationException("This factory does not support binding a method receiver");
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.StubValue> annotation)
/*      */               {
/* 6086 */                 if (!target.getType().represents(Object.class)) {
/* 6087 */                   throw new IllegalStateException("Expected " + target + " to declare an Object type");
/*      */                 }
/* 6089 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStubValue((MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(STUB_VALUE_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class)); } } } @Enhance protected enum Factory implements OffsetMapping.Factory<MemberSubstitution.StubValue> { INSTANCE; private static final MethodDescription.InDefinedShape STUB_VALUE_SOURCE = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(MemberSubstitution.StubValue.class).getDeclaredMethods().filter((ElementMatcher)ElementMatchers.named("source"))).getOnly(); static {  } public Class<MemberSubstitution.StubValue> getAnnotationType() { return MemberSubstitution.StubValue.class; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.StubValue> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.StubValue> annotation) { if (!target.getType().represents(Object.class)) throw new IllegalStateException("Expected " + target + " to declare an Object type");  return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStubValue((MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(STUB_VALUE_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class)); } } public static interface OffsetMapping { Resolved resolve(Assigner param5Assigner, Assigner.Typing param5Typing, TypeDescription param5TypeDescription, MethodDescription param5MethodDescription); public static interface Resolved { StackManipulation apply(MemberSubstitution.Target param6Target, TypeList.Generic param6Generic, TypeDescription.Generic param6Generic1, TypeDescription.Generic param6Generic2, JavaConstant.MethodHandle param6MethodHandle, Map<Integer, Integer> param6Map, int param6Int); @Enhance public static class ForStackManipulation implements Resolved { private final StackManipulation stackManipulation; public ForStackManipulation(StackManipulation stackManipulation) { this.stackManipulation = stackManipulation; } public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) { return this.stackManipulation; } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.stackManipulation.equals(((ForStackManipulation)param7Object).stackManipulation)))); } public int hashCode() { return getClass().hashCode() * 31 + this.stackManipulation.hashCode(); } } } public static interface Factory<T extends Annotation> { Class<T> getAnnotationType(); MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape param6InDefinedShape, AnnotationDescription.Loadable<T> param6Loadable); MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape param6InDefinedShape, AnnotationDescription.Loadable<T> param6Loadable); public static abstract class AbstractBase<S extends Annotation> implements Factory<S> { public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<S> annotation) { return make(target.getDeclaringType().asGenericType(), annotation); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<S> annotation) { return make(target.getType(), annotation); } protected abstract MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(TypeDescription.Generic param7Generic, AnnotationDescription.Loadable<S> param7Loadable); } public static abstract class WithParameterSupportOnly<S extends Annotation> implements Factory<S> { public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<S> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); } } @Enhance public static class Simple<S extends Annotation> extends AbstractBase<S> { private final Class<S> annotationType; private final MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping offsetMapping; public Simple(Class<S> annotationType, MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping offsetMapping) { this.annotationType = annotationType; this.offsetMapping = offsetMapping; } public Class<S> getAnnotationType() { return this.annotationType; } protected MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(TypeDescription.Generic target, AnnotationDescription.Loadable<S> annotation) { return this.offsetMapping; } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.annotationType.equals(((Simple)param7Object).annotationType) ? false : (!!this.offsetMapping.equals(((Simple)param7Object).offsetMapping))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.offsetMapping.hashCode(); } } } @Enhance public static class ForStackManipulation implements OffsetMapping { private final StackManipulation stackManipulation; private final TypeDescription.Generic typeDescription; private final TypeDescription.Generic targetType; public ForStackManipulation(StackManipulation stackManipulation, TypeDescription.Generic typeDescription, TypeDescription.Generic targetType) { this.targetType = targetType; this.stackManipulation = stackManipulation; this.typeDescription = typeDescription; } public static <S extends Annotation> MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<S> of(Class<S> annotationType, @MaybeNull Object value) { return (value == null) ? new OfDefaultValue<S>(annotationType) : new Factory<S>(annotationType, ConstantValue.Simple.wrap(value)); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return new Resolved(assigner, typing, this.stackManipulation, this.typeDescription, this.targetType); } public boolean equals(@MaybeNull Object param6Object) { return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : (!this.stackManipulation.equals(((ForStackManipulation)param6Object).stackManipulation) ? false : (!this.typeDescription.equals(((ForStackManipulation)param6Object).typeDescription) ? false : (!!this.targetType.equals(((ForStackManipulation)param6Object).targetType)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.stackManipulation.hashCode()) * 31 + this.typeDescription.hashCode()) * 31 + this.targetType.hashCode(); } @Enhance protected static class Resolved implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved { private final Assigner assigner; private final Assigner.Typing typing; private final StackManipulation stackManipulation; private final TypeDescription.Generic typeDescription; private final TypeDescription.Generic targetType; protected Resolved(Assigner assigner, Assigner.Typing typing, StackManipulation stackManipulation, TypeDescription.Generic typeDescription, TypeDescription.Generic targetType) { this.assigner = assigner; this.typing = typing; this.stackManipulation = stackManipulation; this.typeDescription = typeDescription; this.targetType = targetType; } public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) { StackManipulation assignment = this.assigner.assign(this.typeDescription, this.targetType, this.typing); if (!assignment.isValid()) throw new IllegalStateException("Cannot assign " + this.typeDescription + " to " + this.targetType);  return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { this.stackManipulation, assignment }); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.typing.equals(((Resolved)param7Object).typing) ? false : (!this.assigner.equals(((Resolved)param7Object).assigner) ? false : (!this.stackManipulation.equals(((Resolved)param7Object).stackManipulation) ? false : (!this.typeDescription.equals(((Resolved)param7Object).typeDescription) ? false : (!!this.targetType.equals(((Resolved)param7Object).targetType)))))))); } public int hashCode() { return ((((getClass().hashCode() * 31 + this.assigner.hashCode()) * 31 + this.typing.hashCode()) * 31 + this.stackManipulation.hashCode()) * 31 + this.typeDescription.hashCode()) * 31 + this.targetType.hashCode(); } } @Enhance public static class OfDefaultValue<T extends Annotation> implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<T> { private final Class<T> annotationType; public OfDefaultValue(Class<T> annotationType) { this.annotationType = annotationType; } public Class<T> getAnnotationType() { return this.annotationType; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation) { return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation(DefaultValue.of((TypeDefinition)target.getType()), target.getType(), target.getType()); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.annotationType.equals(((OfDefaultValue)param7Object).annotationType)))); } public int hashCode() { return getClass().hashCode() * 31 + this.annotationType.hashCode(); } } @Enhance public static class OfAnnotationProperty<T extends Annotation> extends MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory.WithParameterSupportOnly<T> { private final Class<T> annotationType; private final MethodDescription.InDefinedShape property; protected OfAnnotationProperty(Class<T> annotationType, MethodDescription.InDefinedShape property) { this.annotationType = annotationType; this.property = property; } public static <S extends Annotation> MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<S> of(Class<S> annotationType, String property) { if (!annotationType.isAnnotation()) throw new IllegalArgumentException("Not an annotation type: " + annotationType);  try { return new OfAnnotationProperty<S>(annotationType, (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(annotationType.getMethod(property, new Class[0]))); } catch (NoSuchMethodException exception) { throw new IllegalArgumentException("Cannot find a property " + property + " on " + annotationType, exception); }  } public Class<T> getAnnotationType() { return this.annotationType; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation) { ConstantValue value = ConstantValue.Simple.wrapOrNull(annotation.getValue(this.property).resolve()); if (value == null) throw new IllegalStateException("Not a constant value property: " + this.property);  return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation(value.toStackManipulation(), value.getTypeDescription().asGenericType(), target.getType()); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.annotationType.equals(((OfAnnotationProperty)param7Object).annotationType) ? false : (!!this.property.equals(((OfAnnotationProperty)param7Object).property))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.property.hashCode(); } } @Enhance public static class OfSerializedConstant<T extends Annotation> extends MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory.AbstractBase<T> { private final Class<T> annotationType; private final StackManipulation deserialization; private final TypeDescription.Generic typeDescription; protected OfSerializedConstant(Class<T> annotationType, StackManipulation deserialization, TypeDescription.Generic typeDescription) { this.annotationType = annotationType; this.deserialization = deserialization; this.typeDescription = typeDescription; } public static <S extends Annotation, U extends Serializable> MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<S> of(Class<S> type, U value, Class<? super U> targetType) { if (!targetType.isInstance(value)) throw new IllegalArgumentException((new StringBuilder()).append(value).append(" is no instance of ").append(targetType).toString());  return new OfSerializedConstant<S>(type, SerializedConstant.of((Serializable)value), TypeDescription.ForLoadedType.of(targetType).asGenericType()); } public Class<T> getAnnotationType() { return this.annotationType; } protected MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(TypeDescription.Generic target, AnnotationDescription.Loadable<T> annotation) { return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation(this.deserialization, this.typeDescription, target); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.annotationType.equals(((OfSerializedConstant)param7Object).annotationType) ? false : (!this.deserialization.equals(((OfSerializedConstant)param7Object).deserialization) ? false : (!!this.typeDescription.equals(((OfSerializedConstant)param7Object).typeDescription)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.deserialization.hashCode()) * 31 + this.typeDescription.hashCode(); } } @Enhance public static class OfDynamicInvocation<T extends Annotation> extends MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory.AbstractBase<T> { private final Class<T> annotationType; private final MethodDescription.InDefinedShape bootstrapMethod; private final List<? extends JavaConstant> arguments; public OfDynamicInvocation(Class<T> annotationType, MethodDescription.InDefinedShape bootstrapMethod, List<? extends JavaConstant> arguments) { this.annotationType = annotationType; this.bootstrapMethod = bootstrapMethod; this.arguments = arguments; } public Class<T> getAnnotationType() { return this.annotationType; } protected MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(TypeDescription.Generic target, AnnotationDescription.Loadable<T> annotation) { if (!target.isInterface()) throw new IllegalArgumentException(target + " is not an interface");  if (!target.getInterfaces().isEmpty()) throw new IllegalArgumentException(target + " must not extend other interfaces");  if (!target.isPublic()) throw new IllegalArgumentException(target + " is mot public");  MethodList<?> methodCandidates = (MethodList)target.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isAbstract()); if (methodCandidates.size() != 1) throw new IllegalArgumentException(target + " must declare exactly one abstract method");  return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation(MethodInvocation.invoke(this.bootstrapMethod).dynamic(((MethodDescription)methodCandidates.getOnly()).getInternalName(), target.asErasure(), Collections.emptyList(), this.arguments), target, target); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.annotationType.equals(((OfDynamicInvocation)param7Object).annotationType) ? false : (!this.bootstrapMethod.equals(((OfDynamicInvocation)param7Object).bootstrapMethod) ? false : (!!this.arguments.equals(((OfDynamicInvocation)param7Object).arguments)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.bootstrapMethod.hashCode()) * 31 + this.arguments.hashCode(); } } @Enhance public static class Factory<T extends Annotation> extends MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory.AbstractBase<T> { private final Class<T> annotationType; private final StackManipulation stackManipulation; private final TypeDescription.Generic typeDescription; public Factory(Class<T> annotationType, ConstantValue value) { this(annotationType, value.toStackManipulation(), value.getTypeDescription().asGenericType()); } public Factory(Class<T> annotationType, StackManipulation stackManipulation, TypeDescription.Generic typeDescription) { this.annotationType = annotationType; this.stackManipulation = stackManipulation; this.typeDescription = typeDescription; } public Class<T> getAnnotationType() { return this.annotationType; } protected MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(TypeDescription.Generic target, AnnotationDescription.Loadable<T> annotation) { return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation(this.stackManipulation, this.typeDescription, target); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.annotationType.equals(((Factory)param7Object).annotationType) ? false : (!this.stackManipulation.equals(((Factory)param7Object).stackManipulation) ? false : (!!this.typeDescription.equals(((Factory)param7Object).typeDescription)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.stackManipulation.hashCode()) * 31 + this.typeDescription.hashCode(); } } } @Enhance public static class ForArgument implements OffsetMapping { private final TypeDescription.Generic targetType; private final int index; @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) private final Assigner.Typing typing; private final MemberSubstitution.Source source; private final boolean optional; public ForArgument(TypeDescription.Generic targetType, int index, @MaybeNull Assigner.Typing typing, MemberSubstitution.Source source, boolean optional) { this.targetType = targetType; this.index = index; this.typing = typing; this.source = source; this.optional = optional; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return new Resolved(this.targetType, this.index, (this.typing == null) ? typing : this.typing, this.source, this.optional, assigner, instrumentedMethod); } public boolean equals(@MaybeNull Object param6Object) { if (this == param6Object) return true;  if (param6Object == null) return false;  if (getClass() != param6Object.getClass()) return false;  if (this.index != ((ForArgument)param6Object).index) return false;  if (this.optional != ((ForArgument)param6Object).optional) return false;  Assigner.Typing typing1 = ((ForArgument)param6Object).typing; Assigner.Typing typing2 = this.typing; if (typing1 != null) { if (typing2 != null) { if (!typing2.equals(typing1)) return false;  } else { return false; }  } else if (typing2 != null) { return false; }  return !this.source.equals(((ForArgument)param6Object).source) ? false : (!!this.targetType.equals(((ForArgument)param6Object).targetType)); } public int hashCode() { Assigner.Typing typing = this.typing; if (typing != null); return ((((getClass().hashCode() * 31 + this.targetType.hashCode()) * 31 + this.index) * 31 + typing.hashCode()) * 31 + this.source.hashCode()) * 31 + this.optional; } protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.Argument> { INSTANCE; private static final MethodDescription.InDefinedShape ARGUMENT_OPTIONAL; private static final MethodDescription.InDefinedShape ARGUMENT_SOURCE; private static final MethodDescription.InDefinedShape ARGUMENT_TYPING; private static final MethodDescription.InDefinedShape ARGUMENT_VALUE; static { MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.Argument.class).getDeclaredMethods(); ARGUMENT_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly(); ARGUMENT_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly(); ARGUMENT_SOURCE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("source"))).getOnly(); ARGUMENT_OPTIONAL = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("optional"))).getOnly(); } public Class<MemberSubstitution.Argument> getAnnotationType() { return MemberSubstitution.Argument.class; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Argument> annotation) { return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForArgument(target.getDeclaringType().asGenericType(), ((Integer)annotation.getValue(ARGUMENT_VALUE).resolve(Integer.class)).intValue(), (Assigner.Typing)((EnumerationDescription)annotation.getValue(ARGUMENT_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(ARGUMENT_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation.getValue(ARGUMENT_OPTIONAL).resolve(Boolean.class)).booleanValue()); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Argument> annotation) { int index = ((Integer)annotation.getValue(ARGUMENT_VALUE).resolve(Integer.class)).intValue(); if (index < 0) throw new IllegalStateException("Cannot assign negative parameter index " + index + " for " + target);  return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForArgument(target.getType(), index, (Assigner.Typing)((EnumerationDescription)annotation.getValue(ARGUMENT_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(ARGUMENT_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation.getValue(ARGUMENT_OPTIONAL).resolve(Boolean.class)).booleanValue()); } } @Enhance protected static class Resolved implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved { private final TypeDescription.Generic targetType; private final int index; private final Assigner.Typing typing; private final MemberSubstitution.Source source; private final boolean optional; private final Assigner assigner; private final MethodDescription instrumentedMethod; protected Resolved(TypeDescription.Generic targetType, int index, Assigner.Typing typing, MemberSubstitution.Source source, boolean optional, Assigner assigner, MethodDescription instrumentedMethod) { this.targetType = targetType; this.index = index; this.typing = typing; this.source = source; this.optional = optional; this.assigner = assigner; this.instrumentedMethod = instrumentedMethod; } public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) { MemberSubstitution.Source.Value value = this.source.argument(this.index, parameters, offsets, target, this.instrumentedMethod); if (value != null) { StackManipulation assignment = this.assigner.assign(value.getTypeDescription(), this.targetType, this.typing); if (!assignment.isValid()) throw new IllegalStateException("Cannot assign " + value.getTypeDescription() + " to " + this.targetType);  return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { MethodVariableAccess.of((TypeDefinition)value.getTypeDescription()).loadFrom(value.getOffset()), assignment }); }  if (this.optional) return DefaultValue.of((TypeDefinition)this.targetType);  throw new IllegalStateException("No argument with index " + this.index + " available for " + target); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : ((this.index != ((Resolved)param7Object).index) ? false : ((this.optional != ((Resolved)param7Object).optional) ? false : (!this.typing.equals(((Resolved)param7Object).typing) ? false : (!this.source.equals(((Resolved)param7Object).source) ? false : (!this.targetType.equals(((Resolved)param7Object).targetType) ? false : (!this.assigner.equals(((Resolved)param7Object).assigner) ? false : (!!this.instrumentedMethod.equals(((Resolved)param7Object).instrumentedMethod)))))))))); } public int hashCode() { return ((((((getClass().hashCode() * 31 + this.targetType.hashCode()) * 31 + this.index) * 31 + this.typing.hashCode()) * 31 + this.source.hashCode()) * 31 + this.optional) * 31 + this.assigner.hashCode()) * 31 + this.instrumentedMethod.hashCode(); } } } @Enhance public static class ForThisReference implements OffsetMapping { private final TypeDescription.Generic targetType; @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) private final Assigner.Typing typing; private final MemberSubstitution.Source source; private final boolean optional; public ForThisReference(TypeDescription.Generic targetType, @MaybeNull Assigner.Typing typing, MemberSubstitution.Source source, boolean optional) { this.targetType = targetType; this.typing = typing; this.source = source; this.optional = optional; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return new Resolved(this.targetType, (this.typing == null) ? typing : this.typing, this.source, this.optional, assigner, instrumentedMethod); } public boolean equals(@MaybeNull Object param6Object) { if (this == param6Object) return true;  if (param6Object == null) return false;  if (getClass() != param6Object.getClass()) return false;  if (this.optional != ((ForThisReference)param6Object).optional) return false;  Assigner.Typing typing1 = ((ForThisReference)param6Object).typing; Assigner.Typing typing2 = this.typing; if (typing1 != null) { if (typing2 != null) { if (!typing2.equals(typing1)) return false;  } else { return false; }  } else if (typing2 != null) { return false; }  return !this.source.equals(((ForThisReference)param6Object).source) ? false : (!!this.targetType.equals(((ForThisReference)param6Object).targetType)); } public int hashCode() { Assigner.Typing typing = this.typing; if (typing != null); return (((getClass().hashCode() * 31 + this.targetType.hashCode()) * 31 + typing.hashCode()) * 31 + this.source.hashCode()) * 31 + this.optional; } @Enhance protected static class Resolved implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved { private final TypeDescription.Generic targetType; private final Assigner.Typing typing; private final MemberSubstitution.Source source; private final boolean optional; private final Assigner assigner; private final MethodDescription instrumentedMethod; protected Resolved(TypeDescription.Generic targetType, Assigner.Typing typing, MemberSubstitution.Source source, boolean optional, Assigner assigner, MethodDescription instrumentedMethod) { this.targetType = targetType; this.typing = typing; this.source = source; this.optional = optional; this.assigner = assigner; this.instrumentedMethod = instrumentedMethod; } public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) { MemberSubstitution.Source.Value value = this.source.self(parameters, offsets, target, this.instrumentedMethod); if (value != null) { StackManipulation assignment = this.assigner.assign(value.getTypeDescription(), this.targetType, this.typing); if (!assignment.isValid()) throw new IllegalStateException("Cannot assign " + value.getTypeDescription() + " to " + this.targetType);  return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { MethodVariableAccess.of((TypeDefinition)value.getTypeDescription()).loadFrom(value.getOffset()), assignment }); }  if (this.optional) return DefaultValue.of((TypeDefinition)this.targetType);  throw new IllegalStateException("No this reference available for " + target); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : ((this.optional != ((Resolved)param7Object).optional) ? false : (!this.typing.equals(((Resolved)param7Object).typing) ? false : (!this.source.equals(((Resolved)param7Object).source) ? false : (!this.targetType.equals(((Resolved)param7Object).targetType) ? false : (!this.assigner.equals(((Resolved)param7Object).assigner) ? false : (!!this.instrumentedMethod.equals(((Resolved)param7Object).instrumentedMethod))))))))); } public int hashCode() { return (((((getClass().hashCode() * 31 + this.targetType.hashCode()) * 31 + this.typing.hashCode()) * 31 + this.source.hashCode()) * 31 + this.optional) * 31 + this.assigner.hashCode()) * 31 + this.instrumentedMethod.hashCode(); } } protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.This> { INSTANCE; private static final MethodDescription.InDefinedShape THIS_OPTIONAL; private static final MethodDescription.InDefinedShape THIS_SOURCE; private static final MethodDescription.InDefinedShape THIS_TYPING; static { MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.This.class).getDeclaredMethods(); THIS_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly(); THIS_SOURCE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("source"))).getOnly(); THIS_OPTIONAL = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("optional"))).getOnly(); } public Class<MemberSubstitution.This> getAnnotationType() { return MemberSubstitution.This.class; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.This> annotation) { return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForThisReference(target.getDeclaringType().asGenericType(), (Assigner.Typing)((EnumerationDescription)annotation.getValue(THIS_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(THIS_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation.getValue(THIS_OPTIONAL).resolve(Boolean.class)).booleanValue()); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.This> annotation) { return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForThisReference(target.getType(), (Assigner.Typing)((EnumerationDescription)annotation.getValue(THIS_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(THIS_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation.getValue(THIS_OPTIONAL).resolve(Boolean.class)).booleanValue()); } } } @Enhance public static class ForAllArguments implements OffsetMapping { private final TypeDescription.Generic targetComponentType; @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) private final Assigner.Typing typing; private final MemberSubstitution.Source source; private final boolean includeSelf; private final boolean nullIfEmpty; public ForAllArguments(TypeDescription.Generic targetComponentType, @MaybeNull Assigner.Typing typing, MemberSubstitution.Source source, boolean includeSelf, boolean nullIfEmpty) { this.targetComponentType = targetComponentType; this.typing = typing; this.source = source; this.includeSelf = includeSelf; this.nullIfEmpty = nullIfEmpty; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return new Resolved(this.targetComponentType, (this.typing == null) ? typing : this.typing, this.source, this.includeSelf, this.nullIfEmpty, assigner, instrumentedMethod); } public boolean equals(@MaybeNull Object param6Object) { if (this == param6Object) return true;  if (param6Object == null) return false;  if (getClass() != param6Object.getClass()) return false;  if (this.includeSelf != ((ForAllArguments)param6Object).includeSelf) return false;  if (this.nullIfEmpty != ((ForAllArguments)param6Object).nullIfEmpty) return false;  Assigner.Typing typing1 = ((ForAllArguments)param6Object).typing; Assigner.Typing typing2 = this.typing; if (typing1 != null) { if (typing2 != null) { if (!typing2.equals(typing1)) return false;  } else { return false; }  } else if (typing2 != null) { return false; }  return !this.source.equals(((ForAllArguments)param6Object).source) ? false : (!!this.targetComponentType.equals(((ForAllArguments)param6Object).targetComponentType)); } public int hashCode() { Assigner.Typing typing = this.typing; if (typing != null); return ((((getClass().hashCode() * 31 + this.targetComponentType.hashCode()) * 31 + typing.hashCode()) * 31 + this.source.hashCode()) * 31 + this.includeSelf) * 31 + this.nullIfEmpty; } protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.AllArguments> { INSTANCE; private static final MethodDescription.InDefinedShape ALL_ARGUMENTS_NULL_IF_EMPTY; private static final MethodDescription.InDefinedShape ALL_ARGUMENTS_INCLUDE_SELF; private static final MethodDescription.InDefinedShape ALL_ARGUMENTS_SOURCE; private static final MethodDescription.InDefinedShape ALL_ARGUMENTS_TYPING; static { MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.AllArguments.class).getDeclaredMethods(); ALL_ARGUMENTS_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly(); ALL_ARGUMENTS_SOURCE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("source"))).getOnly(); ALL_ARGUMENTS_INCLUDE_SELF = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("includeSelf"))).getOnly(); ALL_ARGUMENTS_NULL_IF_EMPTY = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("nullIfEmpty"))).getOnly(); } public Class<MemberSubstitution.AllArguments> getAnnotationType() { return MemberSubstitution.AllArguments.class; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.AllArguments> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); } @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.") public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.AllArguments> annotation) { if (!target.getType().isArray()) throw new IllegalStateException("Expected array as parameter type for " + target);  return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForAllArguments(target.getType().getComponentType(), (Assigner.Typing)((EnumerationDescription)annotation.getValue(ALL_ARGUMENTS_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(ALL_ARGUMENTS_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation.getValue(ALL_ARGUMENTS_INCLUDE_SELF).resolve(Boolean.class)).booleanValue(), ((Boolean)annotation.getValue(ALL_ARGUMENTS_NULL_IF_EMPTY).resolve(Boolean.class)).booleanValue()); } } @Enhance protected static class Resolved implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved { private final TypeDescription.Generic targetComponentType; private final Assigner.Typing typing; private final MemberSubstitution.Source source; private final boolean includeSelf; private final boolean nullIfEmpty; private final Assigner assigner; private final MethodDescription instrumentedMethod; protected Resolved(TypeDescription.Generic targetComponentType, Assigner.Typing typing, MemberSubstitution.Source source, boolean includeSelf, boolean nullIfEmpty, Assigner assigner, MethodDescription instrumentedMethod) { this.targetComponentType = targetComponentType; this.typing = typing; this.source = source; this.includeSelf = includeSelf; this.nullIfEmpty = nullIfEmpty; this.assigner = assigner; this.instrumentedMethod = instrumentedMethod; } public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) { List<MemberSubstitution.Source.Value> values = this.source.arguments(this.includeSelf, parameters, offsets, target, this.instrumentedMethod); if (this.nullIfEmpty && values.isEmpty()) return (StackManipulation)NullConstant.INSTANCE;  List<StackManipulation> stackManipulations = new ArrayList<StackManipulation>(); for (MemberSubstitution.Source.Value value : values) { StackManipulation assignment = this.assigner.assign(value.getTypeDescription(), this.targetComponentType, this.typing); if (!assignment.isValid()) throw new IllegalStateException("Cannot assign " + value.getTypeDescription() + " to " + this.targetComponentType);  stackManipulations.add(new StackManipulation.Compound(new StackManipulation[] { MethodVariableAccess.of((TypeDefinition)value.getTypeDescription()).loadFrom(value.getOffset()), assignment })); }  return ArrayFactory.forType(this.targetComponentType).withValues(stackManipulations); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : ((this.includeSelf != ((Resolved)param7Object).includeSelf) ? false : ((this.nullIfEmpty != ((Resolved)param7Object).nullIfEmpty) ? false : (!this.typing.equals(((Resolved)param7Object).typing) ? false : (!this.source.equals(((Resolved)param7Object).source) ? false : (!this.targetComponentType.equals(((Resolved)param7Object).targetComponentType) ? false : (!this.assigner.equals(((Resolved)param7Object).assigner) ? false : (!!this.instrumentedMethod.equals(((Resolved)param7Object).instrumentedMethod)))))))))); } public int hashCode() { return ((((((getClass().hashCode() * 31 + this.targetComponentType.hashCode()) * 31 + this.typing.hashCode()) * 31 + this.source.hashCode()) * 31 + this.includeSelf) * 31 + this.nullIfEmpty) * 31 + this.assigner.hashCode()) * 31 + this.instrumentedMethod.hashCode(); } } } @Enhance public static class ForSelfCallHandle implements OffsetMapping { private final MemberSubstitution.Source source; private final boolean bound; public ForSelfCallHandle(MemberSubstitution.Source source, boolean bound) { this.source = source; this.bound = bound; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return this.bound ? new Bound(this.source, instrumentedMethod) : new Unbound(this.source, instrumentedMethod); } public boolean equals(@MaybeNull Object param6Object) { return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : ((this.bound != ((ForSelfCallHandle)param6Object).bound) ? false : (!!this.source.equals(((ForSelfCallHandle)param6Object).source))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.source.hashCode()) * 31 + this.bound; } protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.SelfCallHandle> { INSTANCE; private static final MethodDescription.InDefinedShape SELF_CALL_HANDLE_BOUND; private static final MethodDescription.InDefinedShape SELF_CALL_HANDLE_SOURCE; static { MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.SelfCallHandle.class).getDeclaredMethods(); SELF_CALL_HANDLE_SOURCE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("source"))).getOnly(); SELF_CALL_HANDLE_BOUND = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bound"))).getOnly(); } public Class<MemberSubstitution.SelfCallHandle> getAnnotationType() { return MemberSubstitution.SelfCallHandle.class; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.SelfCallHandle> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.SelfCallHandle> annotation) { if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) throw new IllegalStateException("Cannot assign method handle to " + target);  return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForSelfCallHandle((MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(SELF_CALL_HANDLE_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class), ((Boolean)annotation.getValue(SELF_CALL_HANDLE_BOUND).resolve(Boolean.class)).booleanValue()); } } @Enhance protected static class Bound implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved { private final MemberSubstitution.Source source; private final MethodDescription instrumentedMethod; protected Bound(MemberSubstitution.Source source, MethodDescription instrumentedMethod) { this.source = source; this.instrumentedMethod = instrumentedMethod; } public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) { MemberSubstitution.Source.Value dispatched = this.source.self(parameters, offsets, target, this.instrumentedMethod); List<MemberSubstitution.Source.Value> values = this.source.arguments(false, parameters, offsets, target, this.instrumentedMethod); List<StackManipulation> stackManipulations = new ArrayList<StackManipulation>(1 + values.size() + ((dispatched == null) ? 0 : 2) + (values.isEmpty() ? 0 : 1)); stackManipulations.add(this.source.handle(methodHandle, this.instrumentedMethod).toStackManipulation()); if (dispatched != null) { stackManipulations.add(MethodVariableAccess.of((TypeDefinition)dispatched.getTypeDescription()).loadFrom(dispatched.getOffset())); stackManipulations.add(MethodInvocation.invoke((MethodDescription.InDefinedShape)new MethodDescription.Latent(JavaType.METHOD_HANDLE.getTypeStub(), new MethodDescription.Token("bindTo", 1, JavaType.METHOD_HANDLE.getTypeStub().asGenericType(), (List)new TypeList.Generic.Explicit(new TypeDefinition[] { (TypeDefinition)TypeDefinition.Sort.describe(Object.class) }))))); }  if (!values.isEmpty()) { for (MemberSubstitution.Source.Value value : values) stackManipulations.add(MethodVariableAccess.of((TypeDefinition)value.getTypeDescription()).loadFrom(value.getOffset()));  stackManipulations.add(MethodInvocation.invoke((MethodDescription.InDefinedShape)new MethodDescription.Latent(JavaType.METHOD_HANDLES.getTypeStub(), new MethodDescription.Token("insertArguments", 9, JavaType.METHOD_HANDLE.getTypeStub().asGenericType(), (List)new TypeList.Generic.Explicit(new TypeDefinition[] { (TypeDefinition)JavaType.METHOD_HANDLE.getTypeStub(), (TypeDefinition)TypeDefinition.Sort.describe(int.class), (TypeDefinition)TypeDefinition.Sort.describe(Object[].class) }))))); }  return (StackManipulation)new StackManipulation.Compound(stackManipulations); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.source.equals(((Bound)param7Object).source) ? false : (!!this.instrumentedMethod.equals(((Bound)param7Object).instrumentedMethod))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.source.hashCode()) * 31 + this.instrumentedMethod.hashCode(); } } @Enhance protected static class Unbound implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved { private final MemberSubstitution.Source source; private final MethodDescription instrumentedMethod; protected Unbound(MemberSubstitution.Source source, MethodDescription instrumentedMethod) { this.source = source; this.instrumentedMethod = instrumentedMethod; } public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) { return this.source.handle(methodHandle, this.instrumentedMethod).toStackManipulation(); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.source.equals(((Unbound)param7Object).source) ? false : (!!this.instrumentedMethod.equals(((Unbound)param7Object).instrumentedMethod))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.source.hashCode()) * 31 + this.instrumentedMethod.hashCode(); } } } @Enhance public static class ForHandle implements OffsetMapping { private final JavaConstant.MethodHandle.HandleType type; private final TypeDescription owner; private final String name; private final TypeDescription returnType; private final List<? extends TypeDescription> parameterTypes; protected ForHandle(JavaConstant.MethodHandle.HandleType type, TypeDescription owner, String name, TypeDescription returnType, List<? extends TypeDescription> parameterTypes) { this.type = type; this.owner = owner; this.name = name; this.returnType = returnType; this.parameterTypes = parameterTypes; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved.ForStackManipulation((StackManipulation)new JavaConstantValue((JavaConstant)new JavaConstant.MethodHandle(this.type, this.owner.represents(void.class) ? instrumentedType : this.owner, this.name, this.returnType, this.parameterTypes))); } public boolean equals(@MaybeNull Object param6Object) { return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : (!this.type.equals(((ForHandle)param6Object).type) ? false : (!this.name.equals(((ForHandle)param6Object).name) ? false : (!this.owner.equals(((ForHandle)param6Object).owner) ? false : (!this.returnType.equals(((ForHandle)param6Object).returnType) ? false : (!!this.parameterTypes.equals(((ForHandle)param6Object).parameterTypes)))))))); } public int hashCode() { return ((((getClass().hashCode() * 31 + this.type.hashCode()) * 31 + this.owner.hashCode()) * 31 + this.name.hashCode()) * 31 + this.returnType.hashCode()) * 31 + this.parameterTypes.hashCode(); } protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.Handle> { INSTANCE; private static final MethodDescription.InDefinedShape HANDLE_PARAMETER_TYPES; private static final MethodDescription.InDefinedShape HANDLE_RETURN_TYPE; private static final MethodDescription.InDefinedShape HANDLE_NAME; private static final MethodDescription.InDefinedShape HANDLE_OWNER; private static final MethodDescription.InDefinedShape HANDLE_TYPE; static { MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.Handle.class).getDeclaredMethods(); HANDLE_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("type"))).getOnly(); HANDLE_OWNER = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("owner"))).getOnly(); HANDLE_NAME = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("name"))).getOnly(); HANDLE_RETURN_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("returnType"))).getOnly(); HANDLE_PARAMETER_TYPES = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("parameterTypes"))).getOnly(); } public Class<MemberSubstitution.Handle> getAnnotationType() { return MemberSubstitution.Handle.class; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Handle> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Handle> annotation) { if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) throw new IllegalStateException("Cannot assign method handle to " + target);  return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForHandle((JavaConstant.MethodHandle.HandleType)((EnumerationDescription)annotation.getValue(HANDLE_TYPE).resolve(EnumerationDescription.class)).load(JavaConstant.MethodHandle.HandleType.class), (TypeDescription)annotation.getValue(HANDLE_OWNER).resolve(TypeDescription.class), (String)annotation.getValue(HANDLE_NAME).resolve(String.class), (TypeDescription)annotation.getValue(HANDLE_RETURN_TYPE).resolve(TypeDescription.class), Arrays.asList((Object[])annotation.getValue(HANDLE_PARAMETER_TYPES).resolve(TypeDescription[].class))); } } } @Enhance public static class ForDynamicConstant implements OffsetMapping { private final String name; private final TypeDescription typeDescription; private final JavaConstant.MethodHandle.HandleType bootstrapType; private final TypeDescription bootstrapOwner; private final String bootstrapName; private final TypeDescription bootstrapReturnType; private final List<? extends TypeDescription> bootstrapParameterTypes; private final List<JavaConstant> arguments; private final boolean invokedynamic; public ForDynamicConstant(String name, TypeDescription typeDescription, JavaConstant.MethodHandle.HandleType bootstrapType, TypeDescription bootstrapOwner, String bootstrapName, TypeDescription bootstrapReturnType, List<? extends TypeDescription> bootstrapParameterTypes, List<JavaConstant> arguments, boolean invokedynamic) { this.name = name; this.typeDescription = typeDescription; this.bootstrapType = bootstrapType; this.bootstrapOwner = bootstrapOwner; this.bootstrapName = bootstrapName; this.bootstrapReturnType = bootstrapReturnType; this.bootstrapParameterTypes = bootstrapParameterTypes; this.arguments = arguments; this.invokedynamic = invokedynamic; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) { if (this.invokedynamic) return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved.ForStackManipulation((StackManipulation)new Invokedynamic(this.name, JavaConstant.MethodType.of(this.typeDescription, new TypeDescription[0]), new JavaConstant.MethodHandle(this.bootstrapType, this.bootstrapOwner.represents(void.class) ? instrumentedType : this.bootstrapOwner, this.bootstrapName, this.bootstrapReturnType, this.bootstrapParameterTypes), this.arguments));  return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved.ForStackManipulation((StackManipulation)new JavaConstantValue((JavaConstant)new JavaConstant.Dynamic(this.name, this.typeDescription, new JavaConstant.MethodHandle(this.bootstrapType, this.bootstrapOwner.represents(void.class) ? instrumentedType : this.bootstrapOwner, this.bootstrapName, this.bootstrapReturnType, this.bootstrapParameterTypes), this.arguments))); } public boolean equals(@MaybeNull Object param6Object) { return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : ((this.invokedynamic != ((ForDynamicConstant)param6Object).invokedynamic) ? false : (!this.bootstrapType.equals(((ForDynamicConstant)param6Object).bootstrapType) ? false : (!this.name.equals(((ForDynamicConstant)param6Object).name) ? false : (!this.bootstrapName.equals(((ForDynamicConstant)param6Object).bootstrapName) ? false : (!this.typeDescription.equals(((ForDynamicConstant)param6Object).typeDescription) ? false : (!this.bootstrapOwner.equals(((ForDynamicConstant)param6Object).bootstrapOwner) ? false : (!this.bootstrapReturnType.equals(((ForDynamicConstant)param6Object).bootstrapReturnType) ? false : (!this.bootstrapParameterTypes.equals(((ForDynamicConstant)param6Object).bootstrapParameterTypes) ? false : (!!this.arguments.equals(((ForDynamicConstant)param6Object).arguments)))))))))))); } public int hashCode() { return ((((((((getClass().hashCode() * 31 + this.name.hashCode()) * 31 + this.typeDescription.hashCode()) * 31 + this.bootstrapType.hashCode()) * 31 + this.bootstrapOwner.hashCode()) * 31 + this.bootstrapName.hashCode()) * 31 + this.bootstrapReturnType.hashCode()) * 31 + this.bootstrapParameterTypes.hashCode()) * 31 + this.arguments.hashCode()) * 31 + this.invokedynamic; } protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.DynamicConstant> { INSTANCE; private static final MethodDescription.InDefinedShape INVOKEDYNAMIC; private static final MethodDescription.InDefinedShape BOOTSTRAP_PARAMETER_TYPES; private static final MethodDescription.InDefinedShape BOOTSTRAP_RETURN_TYPE; private static final MethodDescription.InDefinedShape BOOTSTRAP_NAME; private static final MethodDescription.InDefinedShape BOOTSTRAP_OWNER; private static final MethodDescription.InDefinedShape BOOTSTRAP_TYPE; private static final MethodDescription.InDefinedShape NAME; static { MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.DynamicConstant.class).getDeclaredMethods(); NAME = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("name"))).getOnly(); BOOTSTRAP_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapType"))).getOnly(); BOOTSTRAP_OWNER = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapOwner"))).getOnly(); BOOTSTRAP_NAME = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapName"))).getOnly(); BOOTSTRAP_RETURN_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapReturnType"))).getOnly(); BOOTSTRAP_PARAMETER_TYPES = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapParameterTypes"))).getOnly(); INVOKEDYNAMIC = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("invokedynamic"))).getOnly(); } public Class<MemberSubstitution.DynamicConstant> getAnnotationType() { return MemberSubstitution.DynamicConstant.class; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.DynamicConstant> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.DynamicConstant> annotation) { return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForDynamicConstant((String)annotation.getValue(NAME).resolve(String.class), target.getType().asErasure(), (JavaConstant.MethodHandle.HandleType)((EnumerationDescription)annotation.getValue(BOOTSTRAP_TYPE).resolve(EnumerationDescription.class)).load(JavaConstant.MethodHandle.HandleType.class), (TypeDescription)annotation.getValue(BOOTSTRAP_OWNER).resolve(TypeDescription.class), (String)annotation.getValue(BOOTSTRAP_NAME).resolve(String.class), (TypeDescription)annotation.getValue(BOOTSTRAP_RETURN_TYPE).resolve(TypeDescription.class), Arrays.asList((Object[])annotation.getValue(BOOTSTRAP_PARAMETER_TYPES).resolve(TypeDescription[].class)), Collections.emptyList(), ((Boolean)annotation.getValue(INVOKEDYNAMIC).resolve(Boolean.class)).booleanValue()); } } } @Enhance public static abstract class ForField implements OffsetMapping { private static final MethodDescription.InDefinedShape FIELD_VALUE_VALUE; private static final MethodDescription.InDefinedShape FIELD_VALUE_DECLARING_TYPE; private static final MethodDescription.InDefinedShape FIELD_VALUE_TYPING; private final TypeDescription.Generic target; @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) private final Assigner.Typing typing; static { MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.FieldValue.class).getDeclaredMethods(); FIELD_VALUE_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly(); FIELD_VALUE_DECLARING_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("declaringType"))).getOnly(); FIELD_VALUE_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly(); } protected ForField(TypeDescription.Generic target, @MaybeNull Assigner.Typing typing) { this.target = target; this.typing = typing; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) { FieldDescription fieldDescription = resolve(instrumentedType, instrumentedMethod); if (!fieldDescription.isStatic() && instrumentedMethod.isStatic()) throw new IllegalStateException("Cannot access non-static field " + fieldDescription + " from static method " + instrumentedMethod);  StackManipulation assignment = assigner.assign(fieldDescription.getType(), this.target, (this.typing == null) ? typing : this.typing); if (!assignment.isValid()) throw new IllegalStateException("Cannot assign " + fieldDescription + " to " + this.target);  return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved.ForStackManipulation((StackManipulation)new StackManipulation.Compound(new StackManipulation[] { fieldDescription.isStatic() ? (StackManipulation)StackManipulation.Trivial.INSTANCE : MethodVariableAccess.loadThis(), FieldAccess.forField(fieldDescription).read(), assignment })); } protected abstract FieldDescription resolve(TypeDescription param6TypeDescription, MethodDescription param6MethodDescription); public boolean equals(@MaybeNull Object param6Object) { if (this == param6Object) return true;  if (param6Object == null) return false;  if (getClass() != param6Object.getClass()) return false;  Assigner.Typing typing1 = ((ForField)param6Object).typing; Assigner.Typing typing2 = this.typing; if (typing1 != null) { if (typing2 != null) { if (!typing2.equals(typing1)) return false;  } else { return false; }  } else if (typing2 != null) { return false; }  return !!this.target.equals(((ForField)param6Object).target); } public int hashCode() { Assigner.Typing typing = this.typing; if (typing != null); return (getClass().hashCode() * 31 + this.target.hashCode()) * 31 + typing.hashCode(); } @Enhance public static abstract class Unresolved extends ForField { protected static final String BEAN_PROPERTY = ""; private final String name; protected Unresolved(TypeDescription.Generic target, Assigner.Typing typing, String name) { super(target, typing); this.name = name; } protected FieldDescription resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) { FieldLocator locator = fieldLocator(instrumentedType); FieldLocator.Resolution resolution = this.name.equals("") ? FieldLocator.Resolution.Simple.ofBeanAccessor(locator, instrumentedMethod) : locator.locate(this.name); if (!resolution.isResolved()) throw new IllegalStateException("Cannot locate field named " + this.name + " for " + instrumentedType);  return resolution.getField(); } protected abstract FieldLocator fieldLocator(TypeDescription param7TypeDescription); public boolean equals(@MaybeNull Object param7Object) { return !super.equals(param7Object) ? false : ((this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.name.equals(((Unresolved)param7Object).name))))); } public int hashCode() { return super.hashCode() * 31 + this.name.hashCode(); } public static class WithImplicitType extends Unresolved { protected WithImplicitType(TypeDescription.Generic target, AnnotationDescription.Loadable<MemberSubstitution.FieldValue> annotation) { this(target, (Assigner.Typing)((EnumerationDescription)annotation.getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$000()).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (String)annotation.getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$100()).resolve(String.class)); } public WithImplicitType(TypeDescription.Generic target, Assigner.Typing typing, String name) { super(target, typing, name); } protected FieldLocator fieldLocator(TypeDescription instrumentedType) { return (FieldLocator)new FieldLocator.ForClassHierarchy(instrumentedType); } } @Enhance public static class WithExplicitType extends Unresolved { private final TypeDescription declaringType; protected WithExplicitType(TypeDescription.Generic target, AnnotationDescription.Loadable<MemberSubstitution.FieldValue> annotation, TypeDescription declaringType) { this(target, (Assigner.Typing)((EnumerationDescription)annotation.getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$000()).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (String)annotation.getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$100()).resolve(String.class), declaringType); } public WithExplicitType(TypeDescription.Generic target, Assigner.Typing typing, String name, TypeDescription declaringType) { super(target, typing, name); this.declaringType = declaringType; } protected FieldLocator fieldLocator(TypeDescription instrumentedType) { if (!this.declaringType.represents(TargetType.class) && !instrumentedType.isAssignableTo(this.declaringType)) throw new IllegalStateException(this.declaringType + " is no super type of " + instrumentedType);  return (FieldLocator)new FieldLocator.ForExactType(TargetType.resolve(this.declaringType, instrumentedType)); } public boolean equals(@MaybeNull Object param8Object) { return !super.equals(param8Object) ? false : ((this == param8Object) ? true : ((param8Object == null) ? false : ((getClass() != param8Object.getClass()) ? false : (!!this.declaringType.equals(((WithExplicitType)param8Object).declaringType))))); } public int hashCode() { return super.hashCode() * 31 + this.declaringType.hashCode(); } } protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.FieldValue> { INSTANCE; public Class<MemberSubstitution.FieldValue> getAnnotationType() { return MemberSubstitution.FieldValue.class; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldValue> annotation) { TypeDescription declaringType = (TypeDescription)annotation.getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$200()).resolve(TypeDescription.class); return declaringType.represents(void.class) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Unresolved.WithImplicitType(target.getDeclaringType().asGenericType(), annotation) : new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Unresolved.WithExplicitType(target.getDeclaringType().asGenericType(), annotation, declaringType); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldValue> annotation) { TypeDescription declaringType = (TypeDescription)annotation.getValue(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.access$200()).resolve(TypeDescription.class); return declaringType.represents(void.class) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Unresolved.WithImplicitType(target.getType(), annotation) : new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Unresolved.WithExplicitType(target.getType(), annotation, declaringType); } } } @Enhance public static class Resolved extends ForField { private final FieldDescription fieldDescription; public Resolved(TypeDescription.Generic target, Assigner.Typing typing, FieldDescription fieldDescription) { super(target, typing); this.fieldDescription = fieldDescription; } @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming declaring type for type member.") protected FieldDescription resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) { if (!this.fieldDescription.isStatic() && !this.fieldDescription.getDeclaringType().asErasure().isAssignableFrom(instrumentedType)) throw new IllegalStateException(this.fieldDescription + " is no member of " + instrumentedType);  if (!this.fieldDescription.isVisibleTo(instrumentedType)) throw new IllegalStateException("Cannot access " + this.fieldDescription + " from " + instrumentedType);  return this.fieldDescription; } public boolean equals(@MaybeNull Object param7Object) { return !super.equals(param7Object) ? false : ((this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.fieldDescription.equals(((Resolved)param7Object).fieldDescription))))); } public int hashCode() { return super.hashCode() * 31 + this.fieldDescription.hashCode(); } @Enhance public static class Factory<T extends Annotation> extends MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory.AbstractBase<T> { private final Class<T> annotationType; private final FieldDescription fieldDescription; private final Assigner.Typing typing; public Factory(Class<T> annotationType, FieldDescription fieldDescription) { this(annotationType, fieldDescription, Assigner.Typing.STATIC); } public Factory(Class<T> annotationType, FieldDescription fieldDescription, Assigner.Typing typing) { this.annotationType = annotationType; this.fieldDescription = fieldDescription; this.typing = typing; } public Class<T> getAnnotationType() { return this.annotationType; } protected MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(TypeDescription.Generic target, AnnotationDescription.Loadable<T> annotation) { return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Resolved(target, this.typing, this.fieldDescription); } public boolean equals(@MaybeNull Object param8Object) { return (this == param8Object) ? true : ((param8Object == null) ? false : ((getClass() != param8Object.getClass()) ? false : (!this.typing.equals(((Factory)param8Object).typing) ? false : (!this.annotationType.equals(((Factory)param8Object).annotationType) ? false : (!!this.fieldDescription.equals(((Factory)param8Object).fieldDescription)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.fieldDescription.hashCode()) * 31 + this.typing.hashCode(); } } } } @Enhance public static abstract class ForFieldHandle implements OffsetMapping { private final Access access; protected ForFieldHandle(Access access) { this.access = access; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) { FieldDescription fieldDescription = resolve(instrumentedType, instrumentedMethod); if (!fieldDescription.isStatic() && instrumentedMethod.isStatic()) throw new IllegalStateException("Cannot access non-static field " + fieldDescription + " from static method " + instrumentedMethod);  if (fieldDescription.isStatic()) return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved.ForStackManipulation(this.access.resolve((FieldDescription.InDefinedShape)fieldDescription.asDefined()).toStackManipulation());  return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved.ForStackManipulation((StackManipulation)new StackManipulation.Compound(new StackManipulation[] { this.access.resolve((FieldDescription.InDefinedShape)fieldDescription.asDefined()).toStackManipulation(), MethodVariableAccess.REFERENCE.loadFrom(0), (StackManipulation)MethodInvocation.invoke((MethodDescription.InDefinedShape)new MethodDescription.Latent(JavaType.METHOD_HANDLE.getTypeStub(), new MethodDescription.Token("bindTo", 1, JavaType.METHOD_HANDLE.getTypeStub().asGenericType(), (List)new TypeList.Generic.Explicit(new TypeDefinition[] { (TypeDefinition)TypeDefinition.Sort.describe(Object.class) })))) })); } protected abstract FieldDescription resolve(TypeDescription param6TypeDescription, MethodDescription param6MethodDescription); public boolean equals(@MaybeNull Object param6Object) { return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : (!!this.access.equals(((ForFieldHandle)param6Object).access)))); } public int hashCode() { return getClass().hashCode() * 31 + this.access.hashCode(); } public enum Access { GETTER { protected JavaConstant.MethodHandle resolve(FieldDescription.InDefinedShape fieldDescription) { return JavaConstant.MethodHandle.ofGetter(fieldDescription); } }, SETTER { protected JavaConstant.MethodHandle resolve(FieldDescription.InDefinedShape fieldDescription) { return JavaConstant.MethodHandle.ofSetter(fieldDescription); } }; protected abstract JavaConstant.MethodHandle resolve(FieldDescription.InDefinedShape param7InDefinedShape); } @Enhance public static abstract class Unresolved extends ForFieldHandle { protected static final String BEAN_PROPERTY = ""; private final String name; public Unresolved(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access access, String name) { super(access); this.name = name; } protected FieldDescription resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) { FieldLocator locator = fieldLocator(instrumentedType); FieldLocator.Resolution resolution = this.name.equals("") ? FieldLocator.Resolution.Simple.ofBeanAccessor(locator, instrumentedMethod) : locator.locate(this.name); if (!resolution.isResolved()) throw new IllegalStateException("Cannot locate field named " + this.name + " for " + instrumentedType);  return resolution.getField(); } protected abstract FieldLocator fieldLocator(TypeDescription param7TypeDescription); public boolean equals(@MaybeNull Object param7Object) { return !super.equals(param7Object) ? false : ((this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.name.equals(((Unresolved)param7Object).name))))); } public int hashCode() { return super.hashCode() * 31 + this.name.hashCode(); } public static class WithImplicitType extends Unresolved { public WithImplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access access, String name) { super(access, name); } protected FieldLocator fieldLocator(TypeDescription instrumentedType) { return (FieldLocator)new FieldLocator.ForClassHierarchy(instrumentedType); } } @Enhance public static class WithExplicitType extends Unresolved { private final TypeDescription declaringType; public WithExplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access access, String name, TypeDescription declaringType) { super(access, name); this.declaringType = declaringType; } protected FieldLocator fieldLocator(TypeDescription instrumentedType) { if (!this.declaringType.represents(TargetType.class) && !instrumentedType.isAssignableTo(this.declaringType)) throw new IllegalStateException(this.declaringType + " is no super type of " + instrumentedType);  return (FieldLocator)new FieldLocator.ForExactType(TargetType.resolve(this.declaringType, instrumentedType)); } public boolean equals(@MaybeNull Object param8Object) { return !super.equals(param8Object) ? false : ((this == param8Object) ? true : ((param8Object == null) ? false : ((getClass() != param8Object.getClass()) ? false : (!!this.declaringType.equals(((WithExplicitType)param8Object).declaringType))))); } public int hashCode() { return super.hashCode() * 31 + this.declaringType.hashCode(); } } protected enum GetterFactory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.FieldGetterHandle> { INSTANCE; private static final MethodDescription.InDefinedShape FIELD_GETTER_HANDLE_DECLARING_TYPE; private static final MethodDescription.InDefinedShape FIELD_GETTER_HANDLE_VALUE; static { MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.FieldGetterHandle.class).getDeclaredMethods(); FIELD_GETTER_HANDLE_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly(); FIELD_GETTER_HANDLE_DECLARING_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("declaringType"))).getOnly(); } public Class<MemberSubstitution.FieldGetterHandle> getAnnotationType() { return MemberSubstitution.FieldGetterHandle.class; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldGetterHandle> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldGetterHandle> annotation) { if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) throw new IllegalStateException("Cannot assign method handle to " + target);  TypeDescription declaringType = (TypeDescription)annotation.getValue(FIELD_GETTER_HANDLE_DECLARING_TYPE).resolve(TypeDescription.class); return declaringType.represents(void.class) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Unresolved.WithImplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access.GETTER, (String)annotation.getValue(FIELD_GETTER_HANDLE_VALUE).resolve(String.class)) : new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Unresolved.WithExplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access.GETTER, (String)annotation.getValue(FIELD_GETTER_HANDLE_VALUE).resolve(String.class), declaringType); } } protected enum SetterFactory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.FieldSetterHandle> { INSTANCE; private static final MethodDescription.InDefinedShape FIELD_SETTER_HANDLE_DECLARING_TYPE; private static final MethodDescription.InDefinedShape FIELD_SETTER_HANDLE_VALUE; static { MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(MemberSubstitution.FieldSetterHandle.class).getDeclaredMethods(); FIELD_SETTER_HANDLE_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly(); FIELD_SETTER_HANDLE_DECLARING_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("declaringType"))).getOnly(); } public Class<MemberSubstitution.FieldSetterHandle> getAnnotationType() { return MemberSubstitution.FieldSetterHandle.class; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldSetterHandle> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.FieldSetterHandle> annotation) { if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) throw new IllegalStateException("Cannot assign method handle to " + target);  TypeDescription declaringType = (TypeDescription)annotation.getValue(FIELD_SETTER_HANDLE_DECLARING_TYPE).resolve(TypeDescription.class); return declaringType.represents(void.class) ? new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Unresolved.WithImplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access.SETTER, (String)annotation.getValue(FIELD_SETTER_HANDLE_VALUE).resolve(String.class)) : new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Unresolved.WithExplicitType(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access.SETTER, (String)annotation.getValue(FIELD_SETTER_HANDLE_VALUE).resolve(String.class), declaringType); } } } @Enhance public static class Resolved extends ForFieldHandle { private final FieldDescription fieldDescription; public Resolved(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access access, FieldDescription fieldDescription) { super(access); this.fieldDescription = fieldDescription; } @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming declaring type for type member.") protected FieldDescription resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) { if (!this.fieldDescription.isStatic() && !this.fieldDescription.getDeclaringType().asErasure().isAssignableFrom(instrumentedType)) throw new IllegalStateException(this.fieldDescription + " is no member of " + instrumentedType);  if (!this.fieldDescription.isVisibleTo(instrumentedType)) throw new IllegalStateException("Cannot access " + this.fieldDescription + " from " + instrumentedType);  return this.fieldDescription; } public boolean equals(@MaybeNull Object param7Object) { return !super.equals(param7Object) ? false : ((this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!!this.fieldDescription.equals(((Resolved)param7Object).fieldDescription))))); } public int hashCode() { return super.hashCode() * 31 + this.fieldDescription.hashCode(); } @Enhance public static class Factory<T extends Annotation> implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<T> { private final Class<T> annotationType; private final FieldDescription fieldDescription; private final MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access access; public Factory(Class<T> annotationType, FieldDescription fieldDescription, MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Access access) { this.annotationType = annotationType; this.fieldDescription = fieldDescription; this.access = access; } public Class<T> getAnnotationType() { return this.annotationType; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation) { if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) throw new IllegalStateException("Cannot assign method handle to " + target);  return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForFieldHandle.Resolved(this.access, this.fieldDescription); } public boolean equals(@MaybeNull Object param8Object) { return (this == param8Object) ? true : ((param8Object == null) ? false : ((getClass() != param8Object.getClass()) ? false : (!this.access.equals(((Factory)param8Object).access) ? false : (!this.annotationType.equals(((Factory)param8Object).annotationType) ? false : (!!this.fieldDescription.equals(((Factory)param8Object).fieldDescription)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.fieldDescription.hashCode()) * 31 + this.access.hashCode(); } } } } @Enhance public static class ForOrigin implements OffsetMapping { private final Sort sort; private final MemberSubstitution.Source source; protected ForOrigin(Sort sort, MemberSubstitution.Source source) { this.sort = sort; this.source = source; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return new Resolved(this.sort, this.source, instrumentedMethod); } public boolean equals(@MaybeNull Object param6Object) { return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : (!this.sort.equals(((ForOrigin)param6Object).sort) ? false : (!!this.source.equals(((ForOrigin)param6Object).source))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.sort.hashCode()) * 31 + this.source.hashCode(); } protected enum Sort { METHOD { protected boolean isRepresentable(ByteCodeElement.Member member) { return (member instanceof MethodDescription && ((MethodDescription)member).isMethod()); } protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) { return (StackManipulation)MethodConstant.of((MethodDescription.InDefinedShape)((MethodDescription)member).asDefined()); } }, CONSTRUCTOR { protected boolean isRepresentable(ByteCodeElement.Member member) { return (member instanceof MethodDescription && ((MethodDescription)member).isConstructor()); } protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) { return (StackManipulation)MethodConstant.of((MethodDescription.InDefinedShape)((MethodDescription)member).asDefined()); } }, FIELD { protected boolean isRepresentable(ByteCodeElement.Member member) { return member instanceof FieldDescription; } protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) { return (StackManipulation)new FieldConstant((FieldDescription.InDefinedShape)((FieldDescription)member).asDefined()); } }, EXECUTABLE { protected boolean isRepresentable(ByteCodeElement.Member member) { return member instanceof MethodDescription; } protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) { return (StackManipulation)MethodConstant.of((MethodDescription.InDefinedShape)((MethodDescription)member).asDefined()); } }, TYPE { protected boolean isRepresentable(ByteCodeElement.Member member) { return true; } protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) { return ClassConstant.of(member.getDeclaringType().asErasure()); } }, LOOKUP { protected boolean isRepresentable(ByteCodeElement.Member member) { return true; } protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) { return MethodInvocation.lookup(); } }, METHOD_HANDLE { protected boolean isRepresentable(ByteCodeElement.Member member) { return true; } protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) { JavaConstant.MethodHandle handle; if (member instanceof MethodDescription) { handle = JavaConstant.MethodHandle.of((MethodDescription.InDefinedShape)((MethodDescription)member).asDefined()); } else if (member instanceof FieldDescription) { handle = returnType.represents(void.class) ? JavaConstant.MethodHandle.ofSetter((FieldDescription.InDefinedShape)((FieldDescription)member).asDefined()) : JavaConstant.MethodHandle.ofGetter((FieldDescription.InDefinedShape)((FieldDescription)member).asDefined()); } else { throw new IllegalStateException("Unexpected byte code element: " + member); }  return handle.toStackManipulation(); } }, METHOD_TYPE { protected boolean isRepresentable(ByteCodeElement.Member member) { return true; } protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) { return JavaConstant.MethodType.of(returnType, parameterTypes).toStackManipulation(); } }, STRING { protected boolean isRepresentable(ByteCodeElement.Member member) { return true; } protected StackManipulation resolve(ByteCodeElement.Member member, List<TypeDescription> parameterTypes, TypeDescription returnType) { return (StackManipulation)new TextConstant(member.toString()); } }; protected abstract boolean isRepresentable(ByteCodeElement.Member param7Member); protected abstract StackManipulation resolve(ByteCodeElement.Member param7Member, List<TypeDescription> param7List, TypeDescription param7TypeDescription); } protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.Origin> { INSTANCE; private static final MethodDescription.InDefinedShape ORIGIN_TYPE = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(MemberSubstitution.Origin.class).getDeclaredMethods().filter((ElementMatcher)ElementMatchers.named("source"))).getOnly(); static {  } public Class<MemberSubstitution.Origin> getAnnotationType() { return MemberSubstitution.Origin.class; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Origin> annotation) { throw new UnsupportedOperationException("This factory does not support binding a method receiver"); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Origin> annotation) { MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort sort; if (target.getType().asErasure().represents(Class.class)) { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.TYPE; } else if (target.getType().asErasure().represents(Method.class)) { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.METHOD; } else if (target.getType().asErasure().represents(Constructor.class)) { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.CONSTRUCTOR; } else if (target.getType().asErasure().represents(Field.class)) { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.FIELD; } else if (JavaType.EXECUTABLE.getTypeStub().equals(target.getType().asErasure())) { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.EXECUTABLE; } else if (JavaType.METHOD_HANDLE.getTypeStub().equals(target.getType().asErasure())) { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.METHOD_HANDLE; } else if (JavaType.METHOD_TYPE.getTypeStub().equals(target.getType().asErasure())) { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.METHOD_TYPE; } else if (JavaType.METHOD_HANDLES_LOOKUP.getTypeStub().equals(target.getType().asErasure())) { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.LOOKUP; } else if (target.getType().asErasure().isAssignableFrom(String.class)) { sort = MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort.STRING; } else { throw new IllegalStateException("Non-supported type " + target.getType() + " for @Origin annotation"); }  return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin(sort, (MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(ORIGIN_TYPE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class)); } } @Enhance protected static class Resolved implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved { private final MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort sort; private final MemberSubstitution.Source source; private final MethodDescription instrumentedMethod; protected Resolved(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort sort, MemberSubstitution.Source source, MethodDescription instrumentedMethod) { this.sort = sort; this.source = source; this.instrumentedMethod = instrumentedMethod; } public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) { if (!this.source.isRepresentable(this.sort, target, this.instrumentedMethod)) throw new IllegalStateException("Cannot represent " + this.sort + " for " + this.source + " in " + this.instrumentedMethod);  return this.source.resolve(this.sort, target, parameters, result, this.instrumentedMethod); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.sort.equals(((Resolved)param7Object).sort) ? false : (!this.source.equals(((Resolved)param7Object).source) ? false : (!!this.instrumentedMethod.equals(((Resolved)param7Object).instrumentedMethod)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.sort.hashCode()) * 31 + this.source.hashCode()) * 31 + this.instrumentedMethod.hashCode(); } } } @Enhance public static class ForStubValue implements OffsetMapping { private final MemberSubstitution.Source source; protected ForStubValue(MemberSubstitution.Source source) { this.source = source; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return new Resolved(this.source, instrumentedMethod); } public boolean equals(@MaybeNull Object param6Object) { return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : (!!this.source.equals(((ForStubValue)param6Object).source)))); } public int hashCode() { return getClass().hashCode() * 31 + this.source.hashCode(); } @Enhance protected static class Resolved implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved { private final MemberSubstitution.Source source; private final MethodDescription instrumentedMethod; protected Resolved(MemberSubstitution.Source source, MethodDescription instrumentedMethod) { this.source = source; this.instrumentedMethod = instrumentedMethod; } public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) { return DefaultValue.of((TypeDefinition)this.source.handle(methodHandle, this.instrumentedMethod).getReturnType()); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.source.equals(((Resolved)param7Object).source) ? false : (!!this.instrumentedMethod.equals(((Resolved)param7Object).instrumentedMethod))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.source.hashCode()) * 31 + this.instrumentedMethod.hashCode(); } } @Enhance protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.StubValue> { INSTANCE; public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.StubValue> annotation) { if (!target.getType().represents(Object.class)) throw new IllegalStateException("Expected " + target + " to declare an Object type");  return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStubValue((MemberSubstitution.Source)((EnumerationDescription)annotation.getValue(STUB_VALUE_SOURCE).resolve(EnumerationDescription.class)).load(MemberSubstitution.Source.class)); }
/*      */ 
/*      */ 
/*      */                 
/*      */                 private static final MethodDescription.InDefinedShape STUB_VALUE_SOURCE = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(MemberSubstitution.StubValue.class).getDeclaredMethods().filter((ElementMatcher)ElementMatchers.named("source"))).getOnly();
/*      */                 
/*      */                 static {
/*      */                 
/*      */                 }
/*      */                 
/*      */                 public Class<MemberSubstitution.StubValue> getAnnotationType() {
/*      */                   return MemberSubstitution.StubValue.class;
/*      */                 }
/*      */                 
/*      */                 public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.StubValue> annotation) {
/*      */                   throw new UnsupportedOperationException("This factory does not support binding a method receiver");
/*      */                 } }
/*      */                }
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             public static class ForCurrent
/*      */               implements OffsetMapping
/*      */             {
/*      */               private final TypeDescription.Generic targetType;
/*      */               @MaybeNull
/*      */               @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*      */               private final Assigner.Typing typing;
/*      */               
/*      */               public ForCurrent(TypeDescription.Generic targetType, @MaybeNull Assigner.Typing typing) {
/* 6119 */                 this.targetType = targetType;
/* 6120 */                 this.typing = typing;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 6127 */                 return new Resolved(this.targetType, assigner, (this.typing == null) ? typing : this.typing);
/*      */               } public boolean equals(@MaybeNull Object param6Object) { if (this == param6Object)
/*      */                   return true;  if (param6Object == null)
/*      */                   return false;  if (getClass() != param6Object.getClass())
/*      */                   return false;  Assigner.Typing typing1 = ((ForCurrent)param6Object).typing; Assigner.Typing typing2 = this.typing; if (typing1 != null) { if (typing2 != null) { if (!typing2.equals(typing1))
/*      */                       return false;  }
/*      */                   else { return false; }
/*      */                    }
/*      */                 else if (typing2 != null)
/*      */                 { return false; }
/*      */                  return !!this.targetType.equals(((ForCurrent)param6Object).targetType); } public int hashCode() { Assigner.Typing typing = this.typing; if (typing != null); return (getClass().hashCode() * 31 + this.targetType.hashCode()) * 31 + typing.hashCode(); }
/* 6138 */               protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.Current> { INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 6143 */                 private static final MethodDescription.InDefinedShape CURRENT_TYPING = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(MemberSubstitution.Current.class)
/* 6144 */                   .getDeclaredMethods()
/* 6145 */                   .filter((ElementMatcher)ElementMatchers.named("typing")))
/* 6146 */                   .getOnly();
/*      */                 static {
/*      */                 
/*      */                 }
/*      */                 
/*      */                 public Class<MemberSubstitution.Current> getAnnotationType() {
/* 6152 */                   return MemberSubstitution.Current.class;
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Current> annotation) {
/* 6159 */                   return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForCurrent(target.getDeclaringType().asGenericType(), (Assigner.Typing)((EnumerationDescription)annotation
/* 6160 */                       .getValue(CURRENT_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class));
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Current> annotation) {
/* 6167 */                   return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForCurrent(target.getType(), (Assigner.Typing)((EnumerationDescription)annotation.getValue(CURRENT_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class));
/*      */                 } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               @Enhance
/*      */               protected static class Resolved
/*      */                 implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved
/*      */               {
/*      */                 private final TypeDescription.Generic targetType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 private final Assigner assigner;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 private final Assigner.Typing typing;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public Resolved(TypeDescription.Generic targetType, Assigner assigner, Assigner.Typing typing) {
/* 6200 */                   this.targetType = targetType;
/* 6201 */                   this.assigner = assigner;
/* 6202 */                   this.typing = typing;
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset)
/*      */                 {
/* 6215 */                   StackManipulation assignment = this.assigner.assign(current, this.targetType, this.typing);
/* 6216 */                   if (!assignment.isValid()) {
/* 6217 */                     throw new IllegalStateException("Cannot assign " + current + " to " + this.targetType);
/*      */                   }
/* 6219 */                   return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { MethodVariableAccess.of((TypeDefinition)current).loadFrom(offset), assignment }); } public boolean equals(@MaybeNull Object param7Object) { return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.typing.equals(((Resolved)param7Object).typing) ? false : (!this.targetType.equals(((Resolved)param7Object).targetType) ? false : (!!this.assigner.equals(((Resolved)param7Object).assigner)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.targetType.hashCode()) * 31 + this.assigner.hashCode()) * 31 + this.typing.hashCode(); } } } } @Enhance public static class ForCurrent implements OffsetMapping { private final TypeDescription.Generic targetType; @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) private final Assigner.Typing typing; public ForCurrent(TypeDescription.Generic targetType, @MaybeNull Assigner.Typing typing) { this.targetType = targetType; this.typing = typing; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved resolve(Assigner assigner, Assigner.Typing typing, TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return new Resolved(this.targetType, assigner, (this.typing == null) ? typing : this.typing); } public boolean equals(@MaybeNull Object param5Object) { if (this == param5Object) return true;  if (param5Object == null) return false;  if (getClass() != param5Object.getClass()) return false;  Assigner.Typing typing1 = ((ForCurrent)param5Object).typing; Assigner.Typing typing2 = this.typing; if (typing1 != null) { if (typing2 != null) { if (!typing2.equals(typing1)) return false;  } else { return false; }  } else if (typing2 != null) { return false; }  return !!this.targetType.equals(((ForCurrent)param5Object).targetType); } public int hashCode() { Assigner.Typing typing = this.typing; if (typing != null); return (getClass().hashCode() * 31 + this.targetType.hashCode()) * 31 + typing.hashCode(); } protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<MemberSubstitution.Current> { INSTANCE; private static final MethodDescription.InDefinedShape CURRENT_TYPING = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(MemberSubstitution.Current.class).getDeclaredMethods().filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly(); static {  } public Class<MemberSubstitution.Current> getAnnotationType() { return MemberSubstitution.Current.class; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Current> annotation) { return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForCurrent(target.getDeclaringType().asGenericType(), (Assigner.Typing)((EnumerationDescription)annotation.getValue(CURRENT_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class)); } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Current> annotation) { return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForCurrent(target.getType(), (Assigner.Typing)((EnumerationDescription)annotation.getValue(CURRENT_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class)); } } @Enhance protected static class Resolved implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Resolved { private final TypeDescription.Generic targetType; private final Assigner assigner; private final Assigner.Typing typing; public Resolved(TypeDescription.Generic targetType, Assigner assigner, Assigner.Typing typing) { this.targetType = targetType; this.assigner = assigner; this.typing = typing; } public StackManipulation apply(MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, TypeDescription.Generic current, JavaConstant.MethodHandle methodHandle, Map<Integer, Integer> offsets, int offset) { StackManipulation assignment = this.assigner.assign(current, this.targetType, this.typing); if (!assignment.isValid()) throw new IllegalStateException("Cannot assign " + current + " to " + this.targetType);  return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { MethodVariableAccess.of((TypeDefinition)current).loadFrom(offset), assignment }); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param7Object) {
/*      */                 return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.typing.equals(((Resolved)param7Object).typing) ? false : (!this.targetType.equals(((Resolved)param7Object).targetType) ? false : (!!this.assigner.equals(((Resolved)param7Object).assigner))))));
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return ((getClass().hashCode() * 31 + this.targetType.hashCode()) * 31 + this.assigner.hashCode()) * 31 + this.typing.hashCode();
/*      */               } }
/*      */              }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           protected enum Factory
/*      */             implements OffsetMapping.Factory<MemberSubstitution.Current>
/*      */           {
/*      */             INSTANCE;
/*      */ 
/*      */ 
/*      */             
/*      */             private static final MethodDescription.InDefinedShape CURRENT_TYPING = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(MemberSubstitution.Current.class).getDeclaredMethods().filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             static {
/*      */             
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public Class<MemberSubstitution.Current> getAnnotationType() {
/*      */               return MemberSubstitution.Current.class;
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(MethodDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Current> annotation) {
/*      */               return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForCurrent(target.getDeclaringType().asGenericType(), (Assigner.Typing)((EnumerationDescription)annotation.getValue(CURRENT_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class));
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<MemberSubstitution.Current> annotation) {
/*      */               return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForCurrent(target.getType(), (Assigner.Typing)((EnumerationDescription)annotation.getValue(CURRENT_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class));
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           @Enhance
/*      */           public static class ForRegularInvocation
/*      */             implements Dispatcher, Dispatcher.Resolved
/*      */           {
/*      */             private final MethodDescription delegate;
/*      */ 
/*      */ 
/*      */             
/*      */             protected ForRegularInvocation(MethodDescription delegate) {
/* 6287 */               this.delegate = delegate;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher.Resolved resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 6294 */               return this;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public StackManipulation initialize() {
/* 6301 */               return this.delegate.isConstructor() ? (StackManipulation)new StackManipulation.Compound(new StackManipulation[] {
/* 6302 */                     TypeCreation.of(this.delegate.getDeclaringType().asErasure()), (StackManipulation)Duplication.SINGLE }) : (StackManipulation)StackManipulation.Trivial.INSTANCE;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public StackManipulation apply(MemberSubstitution.Target target, JavaConstant.MethodHandle methodHandle) {
/* 6310 */               return (StackManipulation)MethodInvocation.invoke(this.delegate);
/*      */             }
/*      */             
/*      */             public boolean equals(@MaybeNull Object param5Object) {
/*      */               return (this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.delegate.equals(((ForRegularInvocation)param5Object).delegate))));
/*      */             }
/*      */             
/*      */             public int hashCode() {
/*      */               return getClass().hashCode() * 31 + this.delegate.hashCode();
/*      */             }
/*      */             
/* 6321 */             protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher.Factory { INSTANCE;
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher make(MethodDescription.InDefinedShape delegate)
/*      */               {
/* 6327 */                 return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher.ForRegularInvocation((MethodDescription)delegate); } } } protected enum Factory implements Dispatcher.Factory { INSTANCE; public MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher make(MethodDescription.InDefinedShape delegate) { return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher.ForRegularInvocation((MethodDescription)delegate); } } protected static interface Dispatcher { Resolved resolve(TypeDescription param5TypeDescription, MethodDescription param5MethodDescription); public static interface Resolved { StackManipulation initialize(); StackManipulation apply(MemberSubstitution.Target param6Target, JavaConstant.MethodHandle param6MethodHandle); } public static interface Factory { MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher make(MethodDescription.InDefinedShape param6InDefinedShape); } @Enhance public static class ForRegularInvocation implements Dispatcher, Resolved { private final MethodDescription delegate; protected ForRegularInvocation(MethodDescription delegate) { this.delegate = delegate; } public MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher.Resolved resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return this; } public StackManipulation initialize() { return this.delegate.isConstructor() ? (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { TypeCreation.of(this.delegate.getDeclaringType().asErasure()), (StackManipulation)Duplication.SINGLE }) : (StackManipulation)StackManipulation.Trivial.INSTANCE; } public StackManipulation apply(MemberSubstitution.Target target, JavaConstant.MethodHandle methodHandle) { return (StackManipulation)MethodInvocation.invoke(this.delegate); } public boolean equals(@MaybeNull Object param6Object) { return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : (!!this.delegate.equals(((ForRegularInvocation)param6Object).delegate)))); } public int hashCode() { return getClass().hashCode() * 31 + this.delegate.hashCode(); } protected enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher.Factory { INSTANCE; public MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher make(MethodDescription.InDefinedShape delegate) { return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher.ForRegularInvocation((MethodDescription)delegate); }
/*      */                  }
/*      */                }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             public static class ForDynamicInvocation
/*      */               implements Dispatcher
/*      */             {
/*      */               private final MethodDescription.InDefinedShape bootstrapMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final MethodDescription.InDefinedShape delegate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               private final MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver resolver;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected ForDynamicInvocation(MethodDescription.InDefinedShape bootstrapMethod, MethodDescription.InDefinedShape delegate, MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver resolver) {
/* 6363 */                 this.bootstrapMethod = bootstrapMethod;
/* 6364 */                 this.delegate = delegate;
/* 6365 */                 this.resolver = resolver;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected static MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher.Factory of(MethodDescription.InDefinedShape bootstrapMethod, MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver.Factory resolverFactory) {
/* 6377 */                 if (!bootstrapMethod.isInvokeBootstrap()) {
/* 6378 */                   throw new IllegalStateException("Not a bootstrap method: " + bootstrapMethod);
/*      */                 }
/* 6380 */                 return new Factory(bootstrapMethod, resolverFactory);
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher.Resolved resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 6387 */                 return new Resolved(this.bootstrapMethod, this.delegate, this.resolver.resolve(instrumentedType, instrumentedMethod));
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param6Object) {
/*      */                 return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : (!this.bootstrapMethod.equals(((ForDynamicInvocation)param6Object).bootstrapMethod) ? false : (!this.delegate.equals(((ForDynamicInvocation)param6Object).delegate) ? false : (!!this.resolver.equals(((ForDynamicInvocation)param6Object).resolver))))));
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return ((getClass().hashCode() * 31 + this.bootstrapMethod.hashCode()) * 31 + this.delegate.hashCode()) * 31 + this.resolver.hashCode();
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               @Enhance
/*      */               protected static class Resolved
/*      */                 implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher.Resolved
/*      */               {
/*      */                 private final MethodDescription.InDefinedShape bootstrapMethod;
/*      */ 
/*      */                 
/*      */                 private final MethodDescription.InDefinedShape delegate;
/*      */ 
/*      */                 
/*      */                 private final MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver.Resolved resolver;
/*      */ 
/*      */ 
/*      */                 
/*      */                 protected Resolved(MethodDescription.InDefinedShape bootstrapMethod, MethodDescription.InDefinedShape delegate, MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver.Resolved resolver) {
/* 6421 */                   this.bootstrapMethod = bootstrapMethod;
/* 6422 */                   this.delegate = delegate;
/* 6423 */                   this.resolver = resolver;
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public StackManipulation initialize() {
/* 6430 */                   return (StackManipulation)StackManipulation.Trivial.INSTANCE;
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public StackManipulation apply(MemberSubstitution.Target target, JavaConstant.MethodHandle methodHandle) {
/* 6437 */                   List<JavaConstant> constants = this.resolver.make(target, methodHandle);
/* 6438 */                   if (!this.bootstrapMethod.isInvokeBootstrap((List)TypeList.Explicit.of(constants))) {
/* 6439 */                     throw new IllegalArgumentException(this.bootstrapMethod + " is not accepting advice bootstrap arguments: " + constants);
/*      */                   }
/* 6441 */                   return MethodInvocation.invoke(this.bootstrapMethod).dynamic(this.delegate.getInternalName(), this.delegate
/* 6442 */                       .getReturnType().asErasure(), (List)this.delegate
/* 6443 */                       .getParameters().asTypeList().asErasures(), constants);
/*      */                 }
/*      */ 
/*      */ 
/*      */                 
/*      */                 public boolean equals(@MaybeNull Object param7Object) {
/*      */                   return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.bootstrapMethod.equals(((Resolved)param7Object).bootstrapMethod) ? false : (!this.delegate.equals(((Resolved)param7Object).delegate) ? false : (!!this.resolver.equals(((Resolved)param7Object).resolver))))));
/*      */                 }
/*      */ 
/*      */ 
/*      */                 
/*      */                 public int hashCode() {
/*      */                   return ((getClass().hashCode() * 31 + this.bootstrapMethod.hashCode()) * 31 + this.delegate.hashCode()) * 31 + this.resolver.hashCode();
/*      */                 }
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               @Enhance
/*      */               protected static class Factory
/*      */                 implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher.Factory
/*      */               {
/*      */                 private final MethodDescription.InDefinedShape bootstrapMethod;
/*      */ 
/*      */                 
/*      */                 private final MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver.Factory resolverFactory;
/*      */ 
/*      */                 
/*      */                 protected Factory(MethodDescription.InDefinedShape bootstrapMethod, MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver.Factory resolverFactory) {
/* 6472 */                   this.bootstrapMethod = bootstrapMethod;
/* 6473 */                   this.resolverFactory = resolverFactory;
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher make(MethodDescription.InDefinedShape delegate) {
/* 6480 */                   return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher.ForDynamicInvocation(this.bootstrapMethod, delegate, this.resolverFactory.make(delegate));
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public boolean equals(@MaybeNull Object param7Object) {
/*      */                   return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.bootstrapMethod.equals(((Factory)param7Object).bootstrapMethod) ? false : (!!this.resolverFactory.equals(((Factory)param7Object).resolverFactory)))));
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public int hashCode() {
/*      */                   return (getClass().hashCode() * 31 + this.bootstrapMethod.hashCode()) * 31 + this.resolverFactory.hashCode();
/*      */                 }
/*      */               }
/*      */             } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public static interface BootstrapArgumentResolver
/*      */           {
/*      */             Resolved resolve(TypeDescription param5TypeDescription, MethodDescription param5MethodDescription);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             @Enhance
/*      */             public static class ForDefaultValues
/*      */               implements BootstrapArgumentResolver
/*      */             {
/*      */               private final MethodDescription.InDefinedShape delegate;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               protected ForDefaultValues(MethodDescription.InDefinedShape delegate) {
/* 6557 */                 this.delegate = delegate;
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               public MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver.Resolved resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 6564 */                 return new Resolved(this.delegate, instrumentedType, instrumentedMethod);
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public boolean equals(@MaybeNull Object param6Object) {
/*      */                 return (this == param6Object) ? true : ((param6Object == null) ? false : ((getClass() != param6Object.getClass()) ? false : (!!this.delegate.equals(((ForDefaultValues)param6Object).delegate))));
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               public int hashCode() {
/*      */                 return getClass().hashCode() * 31 + this.delegate.hashCode();
/*      */               }
/*      */ 
/*      */ 
/*      */               
/*      */               @Enhance
/*      */               protected static class Resolved
/*      */                 implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver.Resolved
/*      */               {
/*      */                 private final MethodDescription.InDefinedShape delegate;
/*      */ 
/*      */                 
/*      */                 private final TypeDescription instrumentedType;
/*      */ 
/*      */                 
/*      */                 private final MethodDescription instrumentedMethod;
/*      */ 
/*      */ 
/*      */                 
/*      */                 protected Resolved(MethodDescription.InDefinedShape delegate, TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/* 6596 */                   this.delegate = delegate;
/* 6597 */                   this.instrumentedType = instrumentedType;
/* 6598 */                   this.instrumentedMethod = instrumentedMethod;
/*      */                 }
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public List<JavaConstant> make(MemberSubstitution.Target target, JavaConstant.MethodHandle methodHandle) {
/* 6605 */                   if (this.instrumentedMethod.isTypeInitializer()) {
/* 6606 */                     return Arrays.asList(new JavaConstant[] { JavaConstant.Simple.ofLoaded(this.delegate.getDeclaringType().getName()), 
/* 6607 */                           JavaConstant.Simple.of((target instanceof MemberSubstitution.Target.ForMember) ? ((MemberSubstitution.Target.ForMember)target)
/* 6608 */                             .getReceiverType() : 
/* 6609 */                             TypeDescription.ForLoadedType.of(void.class)), 
/* 6610 */                           JavaConstant.Simple.ofLoaded(target.getName()), (JavaConstant)methodHandle, 
/*      */                           
/* 6612 */                           JavaConstant.Simple.of(this.instrumentedType), 
/* 6613 */                           JavaConstant.Simple.ofLoaded(this.instrumentedMethod.getInternalName()) });
/*      */                   }
/* 6615 */                   return Arrays.asList(new JavaConstant[] { JavaConstant.Simple.ofLoaded(this.delegate.getDeclaringType().getName()), 
/* 6616 */                         JavaConstant.Simple.of((target instanceof MemberSubstitution.Target.ForMember) ? ((MemberSubstitution.Target.ForMember)target)
/* 6617 */                           .getReceiverType() : 
/* 6618 */                           TypeDescription.ForLoadedType.of(void.class)), 
/* 6619 */                         JavaConstant.Simple.ofLoaded(target.getName()), (JavaConstant)methodHandle, 
/*      */                         
/* 6621 */                         JavaConstant.Simple.of(this.instrumentedType), 
/* 6622 */                         JavaConstant.Simple.ofLoaded(this.instrumentedMethod.getInternalName()), 
/* 6623 */                         (JavaConstant)JavaConstant.MethodHandle.of((MethodDescription.InDefinedShape)this.instrumentedMethod.asDefined()) });
/*      */                 }
/*      */                 
/*      */                 public boolean equals(@MaybeNull Object param7Object) {
/*      */                   return (this == param7Object) ? true : ((param7Object == null) ? false : ((getClass() != param7Object.getClass()) ? false : (!this.delegate.equals(((Resolved)param7Object).delegate) ? false : (!this.instrumentedType.equals(((Resolved)param7Object).instrumentedType) ? false : (!!this.instrumentedMethod.equals(((Resolved)param7Object).instrumentedMethod))))));
/*      */                 }
/*      */                 
/*      */                 public int hashCode() {
/*      */                   return ((getClass().hashCode() * 31 + this.delegate.hashCode()) * 31 + this.instrumentedType.hashCode()) * 31 + this.instrumentedMethod.hashCode();
/*      */                 }
/*      */               }
/*      */               
/*      */               public enum Factory implements MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver.Factory {
/* 6636 */                 INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 public MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver make(MethodDescription.InDefinedShape delegate) {
/* 6642 */                   return new MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver.ForDefaultValues(delegate);
/*      */                 }
/*      */               }
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             public static interface Factory
/*      */             {
/*      */               MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver make(MethodDescription.InDefinedShape param6InDefinedShape);
/*      */             }
/*      */ 
/*      */             
/*      */             public static interface Resolved
/*      */             {
/*      */               List<JavaConstant> make(MemberSubstitution.Target param6Target, JavaConstant.MethodHandle param6MethodHandle);
/*      */             }
/*      */           }
/*      */ 
/*      */           
/*      */           public static class WithCustomMapping
/*      */           {
/*      */             private final MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher.Factory dispatcherFactory;
/*      */             
/*      */             private final Map<Class<? extends Annotation>, MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<?>> offsetMappings;
/*      */ 
/*      */             
/*      */             protected WithCustomMapping(MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher.Factory dispatcherFactory, Map<Class<? extends Annotation>, MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<?>> offsetMappings) {
/* 6670 */               this.dispatcherFactory = dispatcherFactory;
/* 6671 */               this.offsetMappings = offsetMappings;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bind(Class<T> type, @MaybeNull Object value) {
/* 6684 */               return bind(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation.of(type, value));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bind(Class<T> type, Field field) {
/* 6697 */               return bind(type, (FieldDescription)new FieldDescription.ForLoadedField(field));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bind(Class<T> type, FieldDescription fieldDescription) {
/* 6711 */               return bind(new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForField.Resolved.Factory(type, fieldDescription));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bind(Class<T> type, Class<?> value) {
/* 6723 */               return bind(type, TypeDescription.ForLoadedType.of(value));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bind(Class<T> type, TypeDescription value) {
/* 6735 */               return bind(new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation.Factory(type, ConstantValue.Simple.wrap(value)));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bind(Class<T> type, Enum<?> value) {
/* 6747 */               return bind(type, (EnumerationDescription)new EnumerationDescription.ForLoadedEnumeration(value));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bind(Class<T> type, EnumerationDescription value) {
/* 6759 */               return bind(new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation.Factory(type, ConstantValue.Simple.wrap(value)));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bindSerialized(Class<T> type, Serializable value) {
/* 6772 */               return bindSerialized(type, value, value.getClass());
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation, S extends Serializable> WithCustomMapping bindSerialized(Class<T> type, S value, Class<? super S> targetType) {
/* 6786 */               return bind(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation.OfSerializedConstant.of(type, (Serializable)value, targetType));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bindProperty(Class<T> type, String property) {
/* 6798 */               return bind(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation.OfAnnotationProperty.of(type, property));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bind(Class<T> type, ConstantValue constant) {
/* 6810 */               return bind(new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation.Factory(type, constant.toStackManipulation(), constant.getTypeDescription().asGenericType()));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bind(Class<T> type, StackManipulation stackManipulation, Type targetType) {
/* 6823 */               return bind(type, stackManipulation, TypeDefinition.Sort.describe(targetType));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bind(Class<T> type, StackManipulation stackManipulation, TypeDescription.Generic targetType) {
/* 6836 */               return bind(new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation.Factory(type, stackManipulation, targetType));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bindLambda(Class<T> type, Constructor<?> constructor, Class<?> functionalInterface) {
/* 6849 */               return bindLambda(type, (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(constructor), TypeDescription.ForLoadedType.of(functionalInterface));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bindLambda(Class<T> type, Constructor<?> constructor, Class<?> functionalInterface, MethodGraph.Compiler methodGraphCompiler) {
/* 6863 */               return bindLambda(type, (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(constructor), TypeDescription.ForLoadedType.of(functionalInterface), methodGraphCompiler);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bindLambda(Class<T> type, Method method, Class<?> functionalInterface) {
/* 6876 */               return bindLambda(type, (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method), TypeDescription.ForLoadedType.of(functionalInterface));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bindLambda(Class<T> type, Method method, Class<?> functionalInterface, MethodGraph.Compiler methodGraphCompiler) {
/* 6890 */               return bindLambda(type, (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method), TypeDescription.ForLoadedType.of(functionalInterface), methodGraphCompiler);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bindLambda(Class<T> type, MethodDescription.InDefinedShape methodDescription, TypeDescription functionalInterface) {
/* 6903 */               return bindLambda(type, methodDescription, functionalInterface, MethodGraph.Compiler.DEFAULT);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bindLambda(Class<T> type, MethodDescription.InDefinedShape methodDescription, TypeDescription functionalInterface, MethodGraph.Compiler methodGraphCompiler) {
/* 6920 */               if (!functionalInterface.isInterface()) {
/* 6921 */                 throw new IllegalArgumentException(functionalInterface + " is not an interface type");
/*      */               }
/* 6923 */               MethodList<?> methods = (MethodList)methodGraphCompiler.compile((TypeDefinition)functionalInterface).listNodes().asMethodList().filter((ElementMatcher)ElementMatchers.isAbstract());
/* 6924 */               if (methods.size() != 1) {
/* 6925 */                 throw new IllegalArgumentException(functionalInterface + " does not define exactly one abstract method: " + methods);
/*      */               }
/* 6927 */               return bindDynamic(type, (MethodDescription.InDefinedShape)new MethodDescription.Latent((TypeDescription)new TypeDescription.Latent("java.lang.invoke.LambdaMetafactory", 1, 
/*      */                       
/* 6929 */                       TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class), new TypeDescription.Generic[0]), "metafactory", 9, 
/*      */ 
/*      */                     
/* 6932 */                     Collections.emptyList(), JavaType.CALL_SITE
/* 6933 */                     .getTypeStub().asGenericType(), 
/* 6934 */                     Arrays.asList(new ParameterDescription.Token[] {
/* 6935 */                         new ParameterDescription.Token(JavaType.METHOD_HANDLES_LOOKUP.getTypeStub().asGenericType()), new ParameterDescription.Token(
/* 6936 */                           TypeDescription.ForLoadedType.of(String.class).asGenericType()), new ParameterDescription.Token(JavaType.METHOD_TYPE
/* 6937 */                           .getTypeStub().asGenericType()), new ParameterDescription.Token(JavaType.METHOD_TYPE
/* 6938 */                           .getTypeStub().asGenericType()), new ParameterDescription.Token(JavaType.METHOD_HANDLE
/* 6939 */                           .getTypeStub().asGenericType()), new ParameterDescription.Token(JavaType.METHOD_TYPE
/* 6940 */                           .getTypeStub().asGenericType())
/* 6941 */                       }, ), Collections.emptyList(), 
/* 6942 */                     Collections.emptyList(), AnnotationValue.UNDEFINED, TypeDescription.Generic.UNDEFINED), new Object[] {
/*      */ 
/*      */                     
/* 6945 */                     JavaConstant.MethodType.ofSignature((MethodDescription)methods.asDefined().getOnly()), 
/* 6946 */                     JavaConstant.MethodHandle.of(methodDescription), 
/* 6947 */                     JavaConstant.MethodType.ofSignature((MethodDescription)methods.asDefined().getOnly())
/*      */                   });
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bindDynamic(Class<T> type, Method bootstrapMethod, Object... constant) {
/* 6960 */               return bindDynamic(type, bootstrapMethod, Arrays.asList(constant));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bindDynamic(Class<T> type, Method bootstrapMethod, List<?> constants) {
/* 6973 */               return bindDynamic(type, (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(bootstrapMethod), constants);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bindDynamic(Class<T> type, Constructor<?> bootstrapMethod, Object... constant) {
/* 6986 */               return bindDynamic(type, bootstrapMethod, Arrays.asList(constant));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bindDynamic(Class<T> type, Constructor<?> bootstrapMethod, List<?> constants) {
/* 6999 */               return bindDynamic(type, (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(bootstrapMethod), constants);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bindDynamic(Class<T> type, MethodDescription.InDefinedShape bootstrapMethod, Object... constant) {
/* 7012 */               return bindDynamic(type, bootstrapMethod, Arrays.asList(constant));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bindDynamic(Class<T> type, MethodDescription.InDefinedShape bootstrapMethod, List<?> constants) {
/* 7025 */               List<JavaConstant> arguments = JavaConstant.Simple.wrap(constants);
/* 7026 */               if (!bootstrapMethod.isInvokeBootstrap((List)TypeList.Explicit.of(arguments))) {
/* 7027 */                 throw new IllegalArgumentException("Not a valid bootstrap method " + bootstrapMethod + " for " + arguments);
/*      */               }
/* 7029 */               return bind(new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForStackManipulation.OfDynamicInvocation(type, bootstrapMethod, arguments));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public <T extends Annotation> WithCustomMapping bind(Class<T> type, MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping offsetMapping) {
/* 7041 */               return bind(new MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory.Simple(type, offsetMapping));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public WithCustomMapping bind(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<?> offsetMapping) {
/* 7052 */               Map<Class<? extends Annotation>, MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<?>> offsetMappings = new LinkedHashMap<Class<? extends Annotation>, MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.Factory<?>>(this.offsetMappings);
/* 7053 */               if (!offsetMapping.getAnnotationType().isAnnotation())
/* 7054 */                 throw new IllegalArgumentException("Not an annotation type: " + offsetMapping.getAnnotationType()); 
/* 7055 */               if (offsetMappings.put((Class)offsetMapping.getAnnotationType(), offsetMapping) != null) {
/* 7056 */                 throw new IllegalArgumentException("Annotation type already mapped: " + offsetMapping.getAnnotationType());
/*      */               }
/* 7058 */               return new WithCustomMapping(this.dispatcherFactory, offsetMappings);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public WithCustomMapping bootstrap(Constructor<?> constructor) {
/* 7080 */               return bootstrap((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(constructor));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public WithCustomMapping bootstrap(Constructor<?> constructor, MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver.Factory resolverFactory) {
/* 7091 */               return bootstrap((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(constructor), resolverFactory);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public WithCustomMapping bootstrap(Method method) {
/* 7113 */               return bootstrap((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public WithCustomMapping bootstrap(Method method, MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver.Factory resolverFactory) {
/* 7124 */               return bootstrap((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method), resolverFactory);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public WithCustomMapping bootstrap(MethodDescription.InDefinedShape bootstrap) {
/* 7147 */               return bootstrap(bootstrap, MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver.ForDefaultValues.Factory.INSTANCE);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public WithCustomMapping bootstrap(MethodDescription.InDefinedShape bootstrap, MemberSubstitution.Substitution.Chain.Step.ForDelegation.BootstrapArgumentResolver.Factory resolverFactory) {
/* 7158 */               return new WithCustomMapping(MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher.ForDynamicInvocation.of(bootstrap, resolverFactory), this.offsetMappings);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> to(Method method) {
/* 7168 */               return to((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> to(Constructor<?> constructor) {
/* 7178 */               return to((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(constructor));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             public MemberSubstitution.Substitution.Chain.Step.Factory<MemberSubstitution.Target> to(MethodDescription.InDefinedShape methodDescription) {
/* 7188 */               return MemberSubstitution.Substitution.Chain.Step.ForDelegation.access$500(methodDescription, this.dispatcherFactory, new ArrayList(this.offsetMappings.values()));
/*      */             }
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public static interface Resolved
/*      */           {
/*      */             StackManipulation initialize();
/*      */ 
/*      */ 
/*      */             
/*      */             StackManipulation apply(MemberSubstitution.Target param5Target, JavaConstant.MethodHandle param5MethodHandle);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           public static interface Factory
/*      */           {
/*      */             MemberSubstitution.Substitution.Chain.Step.ForDelegation.Dispatcher make(MethodDescription.InDefinedShape param5InDefinedShape);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       public static class Factory<U extends MemberSubstitution.Target>
/*      */         implements MemberSubstitution.Substitution.Factory<U>
/*      */       {
/*      */         private final Assigner assigner;
/*      */         
/*      */         private final Assigner.Typing typing;
/*      */         
/*      */         private final List<MemberSubstitution.Substitution.Chain.Step.Factory<? super U>> steps;
/*      */ 
/*      */         
/*      */         protected Factory(Assigner assigner, Assigner.Typing typing, List<MemberSubstitution.Substitution.Chain.Step.Factory<? super U>> steps) {
/* 7225 */           this.assigner = assigner;
/* 7226 */           this.typing = typing;
/* 7227 */           this.steps = steps;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public MemberSubstitution.Substitution<? super U> make(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) {
/* 7234 */           if (this.steps.isEmpty()) {
/* 7235 */             return MemberSubstitution.Substitution.Stubbing.INSTANCE;
/*      */           }
/* 7237 */           List<MemberSubstitution.Substitution.Chain.Step<? super U>> steps = new ArrayList<MemberSubstitution.Substitution.Chain.Step<? super U>>(this.steps.size());
/* 7238 */           for (MemberSubstitution.Substitution.Chain.Step.Factory<? super U> step : this.steps) {
/* 7239 */             steps.add(step.make(this.assigner, this.typing, instrumentedType, instrumentedMethod));
/*      */           }
/* 7241 */           return new MemberSubstitution.Substitution.Chain<U>(this.assigner, this.typing, steps);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         @Enhance
/*      */         @SafeVarargs
/*      */         public final Factory<U> executing(MemberSubstitution.Substitution.Chain.Step.Factory<? super U>... step) {
/* 7253 */           return executing(Arrays.asList(step));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public Factory<U> executing(List<? extends MemberSubstitution.Substitution.Chain.Step.Factory<? super U>> steps) {
/* 7263 */           return new Factory(this.assigner, this.typing, CompoundList.of(this.steps, steps));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.typing.equals(((Factory)param3Object).typing) ? false : (!this.assigner.equals(((Factory)param3Object).assigner) ? false : (!!this.steps.equals(((Factory)param3Object).steps))))));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return ((getClass().hashCode() * 31 + this.assigner.hashCode()) * 31 + this.typing.hashCode()) * 31 + this.steps.hashCode();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static interface Factory
/*      */   {
/*      */     MemberSubstitution.Replacement make(TypeDescription param1TypeDescription, MethodDescription param1MethodDescription, TypePool param1TypePool);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class Compound
/*      */       implements Factory
/*      */     {
/*      */       protected Compound(MemberSubstitution.Replacement.Factory... factory) {
/* 7533 */         this(Arrays.asList(factory));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7542 */       private final List<MemberSubstitution.Replacement.Factory> factories = new ArrayList<MemberSubstitution.Replacement.Factory>(); protected Compound(List<? extends MemberSubstitution.Replacement.Factory> factories) {
/* 7543 */         for (MemberSubstitution.Replacement.Factory factory : factories) {
/* 7544 */           if (factory instanceof Compound) {
/* 7545 */             this.factories.addAll(((Compound)factory).factories); continue;
/* 7546 */           }  if (!(factory instanceof MemberSubstitution.Replacement.NoOp)) {
/* 7547 */             this.factories.add(factory);
/*      */           }
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution.Replacement make(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) {
/* 7556 */         List<MemberSubstitution.Replacement> replacements = new ArrayList<MemberSubstitution.Replacement>();
/* 7557 */         for (MemberSubstitution.Replacement.Factory factory : this.factories) {
/* 7558 */           replacements.add(factory.make(instrumentedType, instrumentedMethod, typePool));
/*      */         }
/* 7560 */         return new MemberSubstitution.Replacement.ForFirstBinding(replacements);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param3Object) {
/*      */         return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.factories.equals(((Compound)param3Object).factories))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return getClass().hashCode() * 31 + this.factories.hashCode();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum NoOp
/*      */     implements Replacement, Replacement.Factory
/*      */   {
/* 7631 */     INSTANCE;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MemberSubstitution.Replacement make(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) {
/* 7637 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MemberSubstitution.Replacement.Binding bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypeDescription typeDescription, FieldDescription fieldDescription, boolean writeAccess) {
/* 7648 */       return MemberSubstitution.Replacement.Binding.Unresolved.INSTANCE;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MemberSubstitution.Replacement.Binding bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypeDescription typeDescription, MethodDescription methodDescription, MemberSubstitution.Replacement.InvocationType invocationType) {
/* 7659 */       return MemberSubstitution.Replacement.Binding.Unresolved.INSTANCE;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MemberSubstitution.Replacement.Binding bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, JavaConstant.MethodHandle methodHandle, JavaConstant.MethodType methodType, String name, List<JavaConstant> constants)
/*      */     {
/* 7671 */       return MemberSubstitution.Replacement.Binding.Unresolved.INSTANCE; } } protected static interface Replacement { Binding bind(TypeDescription param1TypeDescription1, MethodDescription param1MethodDescription, TypeDescription param1TypeDescription2, FieldDescription param1FieldDescription, boolean param1Boolean); Binding bind(TypeDescription param1TypeDescription1, MethodDescription param1MethodDescription1, TypeDescription param1TypeDescription2, MethodDescription param1MethodDescription2, InvocationType param1InvocationType); Binding bind(TypeDescription param1TypeDescription, MethodDescription param1MethodDescription, JavaConstant.MethodHandle param1MethodHandle, JavaConstant.MethodType param1MethodType, String param1String, List<JavaConstant> param1List); public static interface Binding { boolean isBound(); StackManipulation make(TypeList.Generic param2Generic, TypeDescription.Generic param2Generic1, JavaConstant.MethodHandle param2MethodHandle, StackManipulation param2StackManipulation, int param2Int); public enum Unresolved implements Binding { INSTANCE; public boolean isBound() { return false; } public StackManipulation make(TypeList.Generic parameters, TypeDescription.Generic result, JavaConstant.MethodHandle methodHandle, StackManipulation stackManipulation, int freeOffset) { throw new IllegalStateException("Cannot resolve unresolved binding"); } } @Enhance public static class ForMember implements Binding { private final TypeDescription receiver; private final ByteCodeElement.Member member; private final MemberSubstitution.Substitution<? super MemberSubstitution.Target.ForMember> substitution; protected ForMember(TypeDescription receiver, ByteCodeElement.Member member, MemberSubstitution.Substitution<? super MemberSubstitution.Target.ForMember> substitution) { this.receiver = receiver; this.member = member; this.substitution = substitution; } public boolean isBound() { return true; } public StackManipulation make(TypeList.Generic parameters, TypeDescription.Generic result, JavaConstant.MethodHandle methodHandle, StackManipulation stackManipulation, int freeOffset) { return this.substitution.resolve(new MemberSubstitution.Target.ForMember(this.receiver, this.member), parameters, result, methodHandle, stackManipulation, freeOffset); } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.receiver.equals(((ForMember)param3Object).receiver) ? false : (!this.member.equals(((ForMember)param3Object).member) ? false : (!!this.substitution.equals(((ForMember)param3Object).substitution)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.receiver.hashCode()) * 31 + this.member.hashCode()) * 31 + this.substitution.hashCode(); } } @Enhance public static class ForDynamicInvocation implements Binding { private final JavaConstant.MethodType methodType; private final String name; private final List<JavaConstant> arguments; private final MemberSubstitution.Substitution<? super MemberSubstitution.Target.ForDynamicInvocation> substitution; protected ForDynamicInvocation(JavaConstant.MethodType methodType, String name, List<JavaConstant> arguments, MemberSubstitution.Substitution<? super MemberSubstitution.Target.ForDynamicInvocation> substitution) { this.methodType = methodType; this.name = name; this.arguments = arguments; this.substitution = substitution; } public boolean isBound() { return true; } public StackManipulation make(TypeList.Generic parameters, TypeDescription.Generic result, JavaConstant.MethodHandle methodHandle, StackManipulation stackManipulation, int freeOffset) { return this.substitution.resolve(new MemberSubstitution.Target.ForDynamicInvocation(this.methodType, this.name, this.arguments), parameters, result, methodHandle, stackManipulation, freeOffset); } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.name.equals(((ForDynamicInvocation)param3Object).name) ? false : (!this.methodType.equals(((ForDynamicInvocation)param3Object).methodType) ? false : (!this.arguments.equals(((ForDynamicInvocation)param3Object).arguments) ? false : (!!this.substitution.equals(((ForDynamicInvocation)param3Object).substitution))))))); } public int hashCode() { return (((getClass().hashCode() * 31 + this.methodType.hashCode()) * 31 + this.name.hashCode()) * 31 + this.arguments.hashCode()) * 31 + this.substitution.hashCode(); } } } public static interface Factory { MemberSubstitution.Replacement make(TypeDescription param2TypeDescription, MethodDescription param2MethodDescription, TypePool param2TypePool); @Enhance public static class Compound implements Factory { protected Compound(MemberSubstitution.Replacement.Factory... factory) { this(Arrays.asList(factory)); } private final List<MemberSubstitution.Replacement.Factory> factories = new ArrayList<MemberSubstitution.Replacement.Factory>(); protected Compound(List<? extends MemberSubstitution.Replacement.Factory> factories) { for (MemberSubstitution.Replacement.Factory factory : factories) { if (factory instanceof Compound) { this.factories.addAll(((Compound)factory).factories); continue; }  if (!(factory instanceof MemberSubstitution.Replacement.NoOp)) this.factories.add(factory);  }  } public MemberSubstitution.Replacement make(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) { List<MemberSubstitution.Replacement> replacements = new ArrayList<MemberSubstitution.Replacement>(); for (MemberSubstitution.Replacement.Factory factory : this.factories) replacements.add(factory.make(instrumentedType, instrumentedMethod, typePool));  return new MemberSubstitution.Replacement.ForFirstBinding(replacements); } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.factories.equals(((Compound)param3Object).factories)))); } public int hashCode() { return getClass().hashCode() * 31 + this.factories.hashCode(); } } } public enum InvocationType { VIRTUAL, SUPER, OTHER; protected static InvocationType of(int opcode, MethodDescription methodDescription) { switch (opcode) { case 182: case 185: return VIRTUAL;case 183: return methodDescription.isVirtual() ? SUPER : OTHER; }  return OTHER; } protected boolean matches(boolean includeVirtualCalls, boolean includeSuperCalls) { switch (this) { case VIRTUAL: return includeVirtualCalls;case SUPER: return includeSuperCalls; }  return true; } } public enum NoOp implements Replacement, Factory { INSTANCE; public MemberSubstitution.Replacement make(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) { return this; } public MemberSubstitution.Replacement.Binding bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypeDescription typeDescription, FieldDescription fieldDescription, boolean writeAccess) { return MemberSubstitution.Replacement.Binding.Unresolved.INSTANCE; } public MemberSubstitution.Replacement.Binding bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypeDescription typeDescription, MethodDescription methodDescription, MemberSubstitution.Replacement.InvocationType invocationType) { return MemberSubstitution.Replacement.Binding.Unresolved.INSTANCE; } public MemberSubstitution.Replacement.Binding bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, JavaConstant.MethodHandle methodHandle, JavaConstant.MethodType methodType, String name, List<JavaConstant> constants) { return MemberSubstitution.Replacement.Binding.Unresolved.INSTANCE; }
/*      */        }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class ForElementMatchers
/*      */       implements Replacement
/*      */     {
/*      */       private final ElementMatcher<? super FieldDescription> fieldMatcher;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final ElementMatcher<? super MethodDescription> methodMatcher;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final boolean matchFieldRead;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final boolean matchFieldWrite;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final boolean includeVirtualCalls;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final boolean includeSuperCalls;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final MemberSubstitution.Substitution<? super MemberSubstitution.Target.ForMember> substitution;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected ForElementMatchers(ElementMatcher<? super FieldDescription> fieldMatcher, ElementMatcher<? super MethodDescription> methodMatcher, boolean matchFieldRead, boolean matchFieldWrite, boolean includeVirtualCalls, boolean includeSuperCalls, MemberSubstitution.Substitution<? super MemberSubstitution.Target.ForMember> substitution) {
/* 7734 */         this.fieldMatcher = fieldMatcher;
/* 7735 */         this.methodMatcher = methodMatcher;
/* 7736 */         this.matchFieldRead = matchFieldRead;
/* 7737 */         this.matchFieldWrite = matchFieldWrite;
/* 7738 */         this.includeVirtualCalls = includeVirtualCalls;
/* 7739 */         this.includeSuperCalls = includeSuperCalls;
/* 7740 */         this.substitution = substitution;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution.Replacement.Binding bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypeDescription typeDescription, FieldDescription fieldDescription, boolean writeAccess) {
/*      */         // Byte code:
/*      */         //   0: iload #5
/*      */         //   2: ifeq -> 15
/*      */         //   5: aload_0
/*      */         //   6: getfield matchFieldWrite : Z
/*      */         //   9: ifeq -> 53
/*      */         //   12: goto -> 22
/*      */         //   15: aload_0
/*      */         //   16: getfield matchFieldRead : Z
/*      */         //   19: ifeq -> 53
/*      */         //   22: aload_0
/*      */         //   23: getfield fieldMatcher : Lnet/bytebuddy/matcher/ElementMatcher;
/*      */         //   26: aload #4
/*      */         //   28: invokeinterface matches : (Ljava/lang/Object;)Z
/*      */         //   33: ifeq -> 53
/*      */         //   36: new net/bytebuddy/asm/MemberSubstitution$Replacement$Binding$ForMember
/*      */         //   39: dup
/*      */         //   40: aload_3
/*      */         //   41: aload #4
/*      */         //   43: aload_0
/*      */         //   44: getfield substitution : Lnet/bytebuddy/asm/MemberSubstitution$Substitution;
/*      */         //   47: invokespecial <init> : (Lnet/bytebuddy/description/type/TypeDescription;Lnet/bytebuddy/description/ByteCodeElement$Member;Lnet/bytebuddy/asm/MemberSubstitution$Substitution;)V
/*      */         //   50: goto -> 56
/*      */         //   53: getstatic net/bytebuddy/asm/MemberSubstitution$Replacement$Binding$Unresolved.INSTANCE : Lnet/bytebuddy/asm/MemberSubstitution$Replacement$Binding$Unresolved;
/*      */         //   56: areturn
/*      */         // Line number table:
/*      */         //   Java source line number -> byte code offset
/*      */         //   #7751	-> 0
/*      */         // Local variable table:
/*      */         //   start	length	slot	name	descriptor
/*      */         //   0	57	0	this	Lnet/bytebuddy/asm/MemberSubstitution$Replacement$ForElementMatchers;
/*      */         //   0	57	1	instrumentedType	Lnet/bytebuddy/description/type/TypeDescription;
/*      */         //   0	57	2	instrumentedMethod	Lnet/bytebuddy/description/method/MethodDescription;
/*      */         //   0	57	3	typeDescription	Lnet/bytebuddy/description/type/TypeDescription;
/*      */         //   0	57	4	fieldDescription	Lnet/bytebuddy/description/field/FieldDescription;
/*      */         //   0	57	5	writeAccess	Z
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution.Replacement.Binding bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypeDescription typeDescription, MethodDescription methodDescription, MemberSubstitution.Replacement.InvocationType invocationType) {
/* 7764 */         return (invocationType.matches(this.includeVirtualCalls, this.includeSuperCalls) && this.methodMatcher.matches(methodDescription)) ? new MemberSubstitution.Replacement.Binding.ForMember(typeDescription, (ByteCodeElement.Member)methodDescription, this.substitution) : MemberSubstitution.Replacement.Binding.Unresolved.INSTANCE;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution.Replacement.Binding bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, JavaConstant.MethodHandle methodHandle, JavaConstant.MethodType methodType, String name, List<JavaConstant> constants) {
/* 7778 */         return MemberSubstitution.Replacement.Binding.Unresolved.INSTANCE;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.matchFieldRead != ((ForElementMatchers)param2Object).matchFieldRead) ? false : ((this.matchFieldWrite != ((ForElementMatchers)param2Object).matchFieldWrite) ? false : ((this.includeVirtualCalls != ((ForElementMatchers)param2Object).includeVirtualCalls) ? false : ((this.includeSuperCalls != ((ForElementMatchers)param2Object).includeSuperCalls) ? false : (!this.fieldMatcher.equals(((ForElementMatchers)param2Object).fieldMatcher) ? false : (!this.methodMatcher.equals(((ForElementMatchers)param2Object).methodMatcher) ? false : (!!this.substitution.equals(((ForElementMatchers)param2Object).substitution))))))))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return ((((((getClass().hashCode() * 31 + this.fieldMatcher.hashCode()) * 31 + this.methodMatcher.hashCode()) * 31 + this.matchFieldRead) * 31 + this.matchFieldWrite) * 31 + this.includeVirtualCalls) * 31 + this.includeSuperCalls) * 31 + this.substitution.hashCode();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       protected static class Factory
/*      */         implements MemberSubstitution.Replacement.Factory
/*      */       {
/*      */         private final ElementMatcher<? super FieldDescription> fieldMatcher;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final ElementMatcher<? super MethodDescription> methodMatcher;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final boolean matchFieldRead;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final boolean matchFieldWrite;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final boolean includeVirtualCalls;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         private final boolean includeSuperCalls;
/*      */ 
/*      */ 
/*      */         
/*      */         private final MemberSubstitution.Substitution.Factory<? super MemberSubstitution.Target.ForMember> substitutionFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected Factory(ElementMatcher<? super FieldDescription> fieldMatcher, ElementMatcher<? super MethodDescription> methodMatcher, boolean matchFieldRead, boolean matchFieldWrite, boolean includeVirtualCalls, boolean includeSuperCalls, MemberSubstitution.Substitution.Factory<? super MemberSubstitution.Target.ForMember> substitutionFactory) {
/* 7840 */           this.fieldMatcher = fieldMatcher;
/* 7841 */           this.methodMatcher = methodMatcher;
/* 7842 */           this.matchFieldRead = matchFieldRead;
/* 7843 */           this.matchFieldWrite = matchFieldWrite;
/* 7844 */           this.includeVirtualCalls = includeVirtualCalls;
/* 7845 */           this.includeSuperCalls = includeSuperCalls;
/* 7846 */           this.substitutionFactory = substitutionFactory;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected static MemberSubstitution.Replacement.Factory of(ElementMatcher<? super ByteCodeElement.Member> matcher, MemberSubstitution.Substitution.Factory<? super MemberSubstitution.Target.ForMember> factory) {
/* 7857 */           return new Factory((ElementMatcher)matcher, (ElementMatcher)matcher, true, true, true, true, factory);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected static MemberSubstitution.Replacement.Factory ofField(ElementMatcher<? super FieldDescription> matcher, boolean matchFieldRead, boolean matchFieldWrite, MemberSubstitution.Substitution.Factory<? super MemberSubstitution.Target.ForMember> factory) {
/* 7870 */           return new Factory(matcher, (ElementMatcher<? super MethodDescription>)ElementMatchers.none(), matchFieldRead, matchFieldWrite, false, false, factory);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected static MemberSubstitution.Replacement.Factory ofMethod(ElementMatcher<? super MethodDescription> matcher, boolean includeVirtualCalls, boolean includeSuperCalls, MemberSubstitution.Substitution.Factory<? super MemberSubstitution.Target.ForMember> factory) {
/* 7883 */           return new Factory((ElementMatcher<? super FieldDescription>)ElementMatchers.none(), matcher, false, false, includeVirtualCalls, includeSuperCalls, factory);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public MemberSubstitution.Replacement make(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) {
/* 7890 */           return new MemberSubstitution.Replacement.ForElementMatchers(this.fieldMatcher, this.methodMatcher, this.matchFieldRead, this.matchFieldWrite, this.includeVirtualCalls, this.includeSuperCalls, this.substitutionFactory
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 7896 */               .make(instrumentedType, instrumentedMethod, typePool));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.matchFieldRead != ((Factory)param3Object).matchFieldRead) ? false : ((this.matchFieldWrite != ((Factory)param3Object).matchFieldWrite) ? false : ((this.includeVirtualCalls != ((Factory)param3Object).includeVirtualCalls) ? false : ((this.includeSuperCalls != ((Factory)param3Object).includeSuperCalls) ? false : (!this.fieldMatcher.equals(((Factory)param3Object).fieldMatcher) ? false : (!this.methodMatcher.equals(((Factory)param3Object).methodMatcher) ? false : (!!this.substitutionFactory.equals(((Factory)param3Object).substitutionFactory))))))))));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return ((((((getClass().hashCode() * 31 + this.fieldMatcher.hashCode()) * 31 + this.methodMatcher.hashCode()) * 31 + this.matchFieldRead) * 31 + this.matchFieldWrite) * 31 + this.includeVirtualCalls) * 31 + this.includeSuperCalls) * 31 + this.substitutionFactory.hashCode();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     public static class ForDynamicInvocation
/*      */       implements Replacement
/*      */     {
/*      */       private final ElementMatcher<? super JavaConstant.MethodHandle> handleMatcher;
/*      */ 
/*      */ 
/*      */       
/*      */       private final ElementMatcher.Junction<? super String> nameMatcher;
/*      */ 
/*      */ 
/*      */       
/*      */       private final ElementMatcher.Junction<? super JavaConstant.MethodType> typeMatcher;
/*      */ 
/*      */ 
/*      */       
/*      */       private final ElementMatcher.Junction<? super List<JavaConstant>> argumentsMatcher;
/*      */ 
/*      */ 
/*      */       
/*      */       private final MemberSubstitution.Substitution<? super MemberSubstitution.Target.ForDynamicInvocation> substitution;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected ForDynamicInvocation(ElementMatcher<? super JavaConstant.MethodHandle> handleMatcher, ElementMatcher.Junction<? super String> nameMatcher, ElementMatcher.Junction<? super JavaConstant.MethodType> typeMatcher, ElementMatcher.Junction<? super List<JavaConstant>> argumentsMatcher, MemberSubstitution.Substitution<? super MemberSubstitution.Target.ForDynamicInvocation> substitution) {
/* 7946 */         this.handleMatcher = handleMatcher;
/* 7947 */         this.nameMatcher = nameMatcher;
/* 7948 */         this.typeMatcher = typeMatcher;
/* 7949 */         this.argumentsMatcher = argumentsMatcher;
/* 7950 */         this.substitution = substitution;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution.Replacement.Binding bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypeDescription typeDescription, FieldDescription fieldDescription, boolean writeAccess) {
/* 7961 */         return MemberSubstitution.Replacement.Binding.Unresolved.INSTANCE;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution.Replacement.Binding bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypeDescription typeDescription, MethodDescription methodDescription, MemberSubstitution.Replacement.InvocationType invocationType) {
/* 7972 */         return MemberSubstitution.Replacement.Binding.Unresolved.INSTANCE;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution.Replacement.Binding bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, JavaConstant.MethodHandle methodHandle, JavaConstant.MethodType methodType, String name, List<JavaConstant> constants) {
/* 7984 */         if (this.handleMatcher.matches(methodHandle) && this.nameMatcher
/* 7985 */           .matches(name) && this.typeMatcher
/* 7986 */           .matches(methodType) && this.argumentsMatcher
/* 7987 */           .matches(constants)) {
/* 7988 */           return new MemberSubstitution.Replacement.Binding.ForDynamicInvocation(methodType, name, constants, this.substitution);
/*      */         }
/* 7990 */         return MemberSubstitution.Replacement.Binding.Unresolved.INSTANCE;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.handleMatcher.equals(((ForDynamicInvocation)param2Object).handleMatcher) ? false : (!this.nameMatcher.equals(((ForDynamicInvocation)param2Object).nameMatcher) ? false : (!this.typeMatcher.equals(((ForDynamicInvocation)param2Object).typeMatcher) ? false : (!this.argumentsMatcher.equals(((ForDynamicInvocation)param2Object).argumentsMatcher) ? false : (!!this.substitution.equals(((ForDynamicInvocation)param2Object).substitution))))))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return ((((getClass().hashCode() * 31 + this.handleMatcher.hashCode()) * 31 + this.nameMatcher.hashCode()) * 31 + this.typeMatcher.hashCode()) * 31 + this.argumentsMatcher.hashCode()) * 31 + this.substitution.hashCode();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @Enhance
/*      */       protected static class Factory
/*      */         implements MemberSubstitution.Replacement.Factory
/*      */       {
/*      */         private final ElementMatcher<? super JavaConstant.MethodHandle> handleMatcher;
/*      */ 
/*      */ 
/*      */         
/*      */         private final ElementMatcher.Junction<? super String> nameMatcher;
/*      */ 
/*      */ 
/*      */         
/*      */         private final ElementMatcher.Junction<? super JavaConstant.MethodType> typeMatcher;
/*      */ 
/*      */ 
/*      */         
/*      */         private final ElementMatcher.Junction<? super List<JavaConstant>> argumentsMatcher;
/*      */ 
/*      */ 
/*      */         
/*      */         private final MemberSubstitution.Substitution.Factory<? super MemberSubstitution.Target.ForDynamicInvocation> substitutionFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         protected Factory(ElementMatcher<? super JavaConstant.MethodHandle> handleMatcher, ElementMatcher.Junction<? super String> nameMatcher, ElementMatcher.Junction<? super JavaConstant.MethodType> typeMatcher, ElementMatcher.Junction<? super List<JavaConstant>> argumentsMatcher, MemberSubstitution.Substitution.Factory<? super MemberSubstitution.Target.ForDynamicInvocation> substitutionFactory) {
/* 8038 */           this.handleMatcher = handleMatcher;
/* 8039 */           this.nameMatcher = nameMatcher;
/* 8040 */           this.typeMatcher = typeMatcher;
/* 8041 */           this.argumentsMatcher = argumentsMatcher;
/* 8042 */           this.substitutionFactory = substitutionFactory;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         public MemberSubstitution.Replacement make(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypePool typePool) {
/* 8049 */           return new MemberSubstitution.Replacement.ForDynamicInvocation(this.handleMatcher, this.nameMatcher, this.typeMatcher, this.argumentsMatcher, this.substitutionFactory
/*      */ 
/*      */ 
/*      */               
/* 8053 */               .make(instrumentedType, instrumentedMethod, typePool));
/*      */         }
/*      */ 
/*      */         
/*      */         public boolean equals(@MaybeNull Object param3Object) {
/*      */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.handleMatcher.equals(((Factory)param3Object).handleMatcher) ? false : (!this.nameMatcher.equals(((Factory)param3Object).nameMatcher) ? false : (!this.typeMatcher.equals(((Factory)param3Object).typeMatcher) ? false : (!this.argumentsMatcher.equals(((Factory)param3Object).argumentsMatcher) ? false : (!!this.substitutionFactory.equals(((Factory)param3Object).substitutionFactory))))))));
/*      */         }
/*      */ 
/*      */         
/*      */         public int hashCode() {
/*      */           return ((((getClass().hashCode() * 31 + this.handleMatcher.hashCode()) * 31 + this.nameMatcher.hashCode()) * 31 + this.typeMatcher.hashCode()) * 31 + this.argumentsMatcher.hashCode()) * 31 + this.substitutionFactory.hashCode();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     @Enhance
/*      */     public static class ForFirstBinding
/*      */       implements Replacement
/*      */     {
/*      */       private final List<? extends MemberSubstitution.Replacement> replacements;
/*      */       
/*      */       protected ForFirstBinding(List<? extends MemberSubstitution.Replacement> replacements) {
/* 8075 */         this.replacements = replacements;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution.Replacement.Binding bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypeDescription typeDescription, FieldDescription fieldDescription, boolean writeAccess) {
/* 8086 */         for (MemberSubstitution.Replacement replacement : this.replacements) {
/* 8087 */           MemberSubstitution.Replacement.Binding binding = replacement.bind(instrumentedType, instrumentedMethod, typeDescription, fieldDescription, writeAccess);
/* 8088 */           if (binding.isBound()) {
/* 8089 */             return binding;
/*      */           }
/*      */         } 
/* 8092 */         return MemberSubstitution.Replacement.Binding.Unresolved.INSTANCE;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution.Replacement.Binding bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, TypeDescription typeDescription, MethodDescription methodDescription, MemberSubstitution.Replacement.InvocationType invocationType) {
/* 8103 */         for (MemberSubstitution.Replacement replacement : this.replacements) {
/* 8104 */           MemberSubstitution.Replacement.Binding binding = replacement.bind(instrumentedType, instrumentedMethod, typeDescription, methodDescription, invocationType);
/* 8105 */           if (binding.isBound()) {
/* 8106 */             return binding;
/*      */           }
/*      */         } 
/* 8109 */         return MemberSubstitution.Replacement.Binding.Unresolved.INSTANCE;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public MemberSubstitution.Replacement.Binding bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, JavaConstant.MethodHandle methodHandle, JavaConstant.MethodType methodType, String name, List<JavaConstant> constants) {
/* 8121 */         for (MemberSubstitution.Replacement replacement : this.replacements) {
/* 8122 */           MemberSubstitution.Replacement.Binding binding = replacement.bind(instrumentedType, instrumentedMethod, methodHandle, methodType, name, constants);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 8128 */           if (binding.isBound()) {
/* 8129 */             return binding;
/*      */           }
/*      */         } 
/* 8132 */         return MemberSubstitution.Replacement.Binding.Unresolved.INSTANCE;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.replacements.equals(((ForFirstBinding)param2Object).replacements))));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public int hashCode() {
/*      */         return getClass().hashCode() * 31 + this.replacements.hashCode();
/*      */       }
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static class SubstitutingMethodVisitor
/*      */     extends LocalVariableAwareMethodVisitor
/*      */   {
/*      */     private final TypeDescription instrumentedType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final MethodDescription instrumentedMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final MethodGraph.Compiler methodGraphCompiler;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean strict;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean failIfNoMatch;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final MemberSubstitution.Replacement replacement;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Implementation.Context implementationContext;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TypePool typePool;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean virtualPrivateCalls;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int stackSizeBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int localVariableExtension;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean matched;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected SubstitutingMethodVisitor(MethodVisitor methodVisitor, TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodGraph.Compiler methodGraphCompiler, boolean strict, boolean failIfNoMatch, MemberSubstitution.Replacement replacement, Implementation.Context implementationContext, TypePool typePool, boolean virtualPrivateCalls) {
/* 8226 */       super(methodVisitor, instrumentedMethod);
/* 8227 */       this.instrumentedType = instrumentedType;
/* 8228 */       this.instrumentedMethod = instrumentedMethod;
/* 8229 */       this.methodGraphCompiler = methodGraphCompiler;
/* 8230 */       this.strict = strict;
/* 8231 */       this.failIfNoMatch = failIfNoMatch;
/* 8232 */       this.replacement = replacement;
/* 8233 */       this.implementationContext = implementationContext;
/* 8234 */       this.typePool = typePool;
/* 8235 */       this.virtualPrivateCalls = virtualPrivateCalls;
/* 8236 */       this.stackSizeBuffer = 0;
/* 8237 */       this.localVariableExtension = 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitFieldInsn(int opcode, String owner, String internalName, String descriptor) {
/* 8242 */       TypePool.Resolution resolution = this.typePool.describe(owner.replace('/', '.'));
/* 8243 */       if (resolution.isResolved()) {
/*      */         FieldList<?> candidates;
/* 8245 */         Iterator<TypeDefinition> iterator = resolution.resolve().iterator();
/*      */         do {
/* 8247 */           candidates = (FieldList)((TypeDefinition)iterator.next()).getDeclaredFields().filter(this.strict ? 
/* 8248 */               (ElementMatcher)ElementMatchers.named(internalName).and((ElementMatcher)ElementMatchers.hasDescriptor(descriptor)) : 
/* 8249 */               (ElementMatcher)ElementMatchers.failSafe((ElementMatcher)ElementMatchers.named(internalName).and((ElementMatcher)ElementMatchers.hasDescriptor(descriptor))));
/* 8250 */         } while (iterator.hasNext() && candidates.isEmpty());
/* 8251 */         if (!candidates.isEmpty()) {
/* 8252 */           MemberSubstitution.Replacement.Binding binding = this.replacement.bind(this.instrumentedType, this.instrumentedMethod, resolution
/*      */               
/* 8254 */               .resolve(), (FieldDescription)candidates
/* 8255 */               .getOnly(), (opcode == 181 || opcode == 179));
/*      */           
/* 8257 */           if (binding.isBound()) {
/*      */             TypeList.Generic.Explicit explicit3, explicit2, explicit1; TypeList.Generic.Empty empty;
/*      */             TypeDescription.Generic result;
/*      */             boolean read;
/* 8261 */             switch (opcode) {
/*      */               case 181:
/* 8263 */                 explicit3 = new TypeList.Generic.Explicit(new TypeDefinition[] { ((FieldDescription)candidates.getOnly()).getDeclaringType(), (TypeDefinition)((FieldDescription)candidates.getOnly()).getType() });
/* 8264 */                 result = TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(void.class);
/* 8265 */                 read = false;
/*      */                 break;
/*      */               case 179:
/* 8268 */                 explicit2 = new TypeList.Generic.Explicit(new TypeDefinition[] { (TypeDefinition)((FieldDescription)candidates.getOnly()).getType() });
/* 8269 */                 result = TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(void.class);
/* 8270 */                 read = false;
/*      */                 break;
/*      */               case 180:
/* 8273 */                 explicit1 = new TypeList.Generic.Explicit(new TypeDefinition[] { ((FieldDescription)candidates.getOnly()).getDeclaringType() });
/* 8274 */                 result = ((FieldDescription)candidates.getOnly()).getType();
/* 8275 */                 read = true;
/*      */                 break;
/*      */               case 178:
/* 8278 */                 empty = new TypeList.Generic.Empty();
/* 8279 */                 result = ((FieldDescription)candidates.getOnly()).getType();
/* 8280 */                 read = true;
/*      */                 break;
/*      */               default:
/* 8283 */                 throw new IllegalStateException("Unexpected opcode: " + opcode);
/*      */             } 
/* 8285 */             this.stackSizeBuffer = Math.max(this.stackSizeBuffer, binding.make((TypeList.Generic)empty, result, read ? 
/*      */ 
/*      */                   
/* 8288 */                   JavaConstant.MethodHandle.ofGetter((FieldDescription.InDefinedShape)((FieldDescription)candidates.getOnly()).asDefined()) : 
/* 8289 */                   JavaConstant.MethodHandle.ofSetter((FieldDescription.InDefinedShape)((FieldDescription)candidates.getOnly()).asDefined()), read ? 
/*      */                   
/* 8291 */                   FieldAccess.forField((FieldDescription)candidates.getOnly()).read() : 
/* 8292 */                   FieldAccess.forField((FieldDescription)candidates.getOnly()).write(), 
/* 8293 */                   getFreeOffset()).apply(new LocalVariableTracingMethodVisitor(this.mv), this.implementationContext).getMaximalSize());
/* 8294 */             this.matched = true;
/*      */             return;
/*      */           } 
/* 8297 */         } else if (this.strict) {
/* 8298 */           throw new IllegalStateException("Could not resolve " + owner.replace('/', '.') + "." + internalName + descriptor + " using " + this.typePool);
/*      */         } 
/* 8300 */       } else if (this.strict) {
/* 8301 */         throw new IllegalStateException("Could not resolve " + owner.replace('/', '.') + " using " + this.typePool);
/*      */       } 
/* 8303 */       super.visitFieldInsn(opcode, owner, internalName, descriptor);
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitMethodInsn(int opcode, String owner, String internalName, String descriptor, boolean isInterface) {
/* 8308 */       TypePool.Resolution resolution = this.typePool.describe(owner.replace('/', '.'));
/* 8309 */       if (resolution.isResolved()) {
/*      */         MethodList<?> candidates;
/* 8311 */         if (opcode == 183 && internalName.equals("<init>")) {
/* 8312 */           candidates = (MethodList)resolution.resolve().getDeclaredMethods().filter(this.strict ? 
/* 8313 */               (ElementMatcher)ElementMatchers.isConstructor().and((ElementMatcher)ElementMatchers.hasDescriptor(descriptor)) : 
/* 8314 */               (ElementMatcher)ElementMatchers.failSafe((ElementMatcher)ElementMatchers.isConstructor().and((ElementMatcher)ElementMatchers.hasDescriptor(descriptor))));
/* 8315 */         } else if (opcode == 184) {
/* 8316 */           Iterator<TypeDefinition> iterator = resolution.resolve().iterator();
/*      */           do {
/* 8318 */             candidates = (MethodList)((TypeDefinition)iterator.next()).getDeclaredMethods().filter(this.strict ? 
/* 8319 */                 (ElementMatcher)ElementMatchers.named(internalName).and((ElementMatcher)ElementMatchers.hasDescriptor(descriptor)) : 
/* 8320 */                 (ElementMatcher)ElementMatchers.failSafe((ElementMatcher)ElementMatchers.named(internalName).and((ElementMatcher)ElementMatchers.hasDescriptor(descriptor))));
/* 8321 */           } while (iterator.hasNext() && candidates.isEmpty());
/* 8322 */         } else if (opcode == 183) {
/* 8323 */           candidates = (MethodList)resolution.resolve().getDeclaredMethods().filter(this.strict ? 
/* 8324 */               (ElementMatcher)ElementMatchers.named(internalName).and((ElementMatcher)ElementMatchers.hasDescriptor(descriptor)) : 
/* 8325 */               (ElementMatcher)ElementMatchers.failSafe((ElementMatcher)ElementMatchers.named(internalName).and((ElementMatcher)ElementMatchers.hasDescriptor(descriptor))));
/* 8326 */         } else if (this.virtualPrivateCalls) {
/* 8327 */           candidates = (MethodList)resolution.resolve().getDeclaredMethods().filter(this.strict ? 
/* 8328 */               (ElementMatcher)ElementMatchers.isPrivate().and((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.isStatic())).and((ElementMatcher)ElementMatchers.named(internalName).and((ElementMatcher)ElementMatchers.hasDescriptor(descriptor))) : 
/* 8329 */               (ElementMatcher)ElementMatchers.failSafe((ElementMatcher)ElementMatchers.isPrivate().and((ElementMatcher)ElementMatchers.not((ElementMatcher)ElementMatchers.isStatic())).and((ElementMatcher)ElementMatchers.named(internalName).and((ElementMatcher)ElementMatchers.hasDescriptor(descriptor)))));
/* 8330 */           if (candidates.isEmpty()) {
/* 8331 */             candidates = (MethodList)this.methodGraphCompiler.compile((TypeDefinition)resolution.resolve(), this.instrumentedType).listNodes().asMethodList().filter(this.strict ? 
/* 8332 */                 (ElementMatcher)ElementMatchers.named(internalName).and((ElementMatcher)ElementMatchers.hasDescriptor(descriptor)) : 
/* 8333 */                 (ElementMatcher)ElementMatchers.failSafe((ElementMatcher)ElementMatchers.named(internalName).and((ElementMatcher)ElementMatchers.hasDescriptor(descriptor))));
/*      */           }
/*      */         } else {
/* 8336 */           candidates = (MethodList)this.methodGraphCompiler.compile((TypeDefinition)resolution.resolve(), this.instrumentedType).listNodes().asMethodList().filter(this.strict ? 
/* 8337 */               (ElementMatcher)ElementMatchers.named(internalName).and((ElementMatcher)ElementMatchers.hasDescriptor(descriptor)) : 
/* 8338 */               (ElementMatcher)ElementMatchers.failSafe((ElementMatcher)ElementMatchers.named(internalName).and((ElementMatcher)ElementMatchers.hasDescriptor(descriptor))));
/*      */         } 
/* 8340 */         if (!candidates.isEmpty()) {
/* 8341 */           MemberSubstitution.Replacement.Binding binding = this.replacement.bind(this.instrumentedType, this.instrumentedMethod, resolution
/*      */               
/* 8343 */               .resolve(), (MethodDescription)candidates
/* 8344 */               .getOnly(), 
/* 8345 */               MemberSubstitution.Replacement.InvocationType.of(opcode, (MethodDescription)candidates.getOnly()));
/* 8346 */           if (binding.isBound()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 8359 */             StackManipulation.Size size = binding.make((((MethodDescription)candidates.getOnly()).isStatic() || ((MethodDescription)candidates.getOnly()).isConstructor()) ? ((MethodDescription)candidates.getOnly()).getParameters().asTypeList() : (TypeList.Generic)new TypeList.Generic.Explicit(CompoundList.of(resolution.resolve(), (List)((MethodDescription)candidates.getOnly()).getParameters().asTypeList())), ((MethodDescription)candidates.getOnly()).isConstructor() ? ((MethodDescription)candidates.getOnly()).getDeclaringType().asGenericType() : ((MethodDescription)candidates.getOnly()).getReturnType(), (opcode == 183 && ((MethodDescription)candidates.getOnly()).isMethod() && !((MethodDescription)candidates.getOnly()).isPrivate()) ? JavaConstant.MethodHandle.ofSpecial((MethodDescription.InDefinedShape)((MethodDescription)candidates.getOnly()).asDefined(), resolution.resolve()) : JavaConstant.MethodHandle.of((MethodDescription.InDefinedShape)((MethodDescription)candidates.getOnly()).asDefined()), (opcode == 183 && ((MethodDescription)candidates.getOnly()).isMethod() && !((MethodDescription)candidates.getOnly()).isPrivate()) ? MethodInvocation.invoke((MethodDescription)candidates.getOnly()).special(resolution.resolve()) : (StackManipulation)MethodInvocation.invoke((MethodDescription)candidates.getOnly()), getFreeOffset()).apply(new LocalVariableTracingMethodVisitor(this.mv), this.implementationContext);
/* 8360 */             if (((MethodDescription)candidates.getOnly()).isConstructor()) {
/* 8361 */               this.stackSizeBuffer = Math.max(this.stackSizeBuffer, size.getMaximalSize() + 2);
/* 8362 */               this.stackSizeBuffer = Math.max(this.stackSizeBuffer, (new StackManipulation.Compound(new StackManipulation[] { Duplication.SINGLE.flipOver((TypeDefinition)TypeDescription.ForLoadedType.of(Object.class)), (StackManipulation)Removal.SINGLE, (StackManipulation)Removal.SINGLE, Duplication.SINGLE
/*      */ 
/*      */                       
/* 8365 */                       .flipOver((TypeDefinition)TypeDescription.ForLoadedType.of(Object.class)), (StackManipulation)Removal.SINGLE, (StackManipulation)Removal.SINGLE
/*      */                     
/* 8367 */                     })).apply(this.mv, this.implementationContext).getMaximalSize() + StackSize.SINGLE.getSize());
/*      */             } else {
/* 8369 */               this.stackSizeBuffer = Math.max(this.stackSizeBuffer, size.getMaximalSize());
/*      */             } 
/* 8371 */             this.matched = true;
/*      */             return;
/*      */           } 
/* 8374 */         } else if (this.strict) {
/* 8375 */           throw new IllegalStateException("Could not resolve " + owner.replace('/', '.') + "." + internalName + descriptor + " using " + this.typePool);
/*      */         } 
/* 8377 */       } else if (this.strict) {
/* 8378 */         throw new IllegalStateException("Could not resolve " + owner.replace('/', '.') + " using " + this.typePool);
/*      */       } 
/* 8380 */       super.visitMethodInsn(opcode, owner, internalName, descriptor, isInterface);
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitInvokeDynamicInsn(String name, String descriptor, net.bytebuddy.jar.asm.Handle handle, Object... argument) {
/*      */       JavaConstant.MethodHandle methodHandle;
/*      */       JavaConstant.MethodType methodType;
/* 8387 */       List<JavaConstant> constants = new ArrayList<JavaConstant>(argument.length);
/*      */       try {
/* 8389 */         methodHandle = JavaConstant.MethodHandle.ofAsm(this.typePool, handle);
/* 8390 */         methodType = JavaConstant.MethodType.ofAsm(this.typePool, Type.getMethodType(descriptor));
/* 8391 */         for (Object anArgument : argument) {
/* 8392 */           constants.add(JavaConstant.Simple.ofAsm(this.typePool, anArgument));
/*      */         }
/* 8394 */       } catch (net.bytebuddy.pool.TypePool.Resolution.NoSuchTypeException exception) {
/* 8395 */         if (this.strict) {
/* 8396 */           throw new IllegalStateException("Could not resolve " + exception.getName() + " using " + this.typePool);
/*      */         }
/* 8398 */         methodHandle = null;
/* 8399 */         methodType = null;
/*      */       } 
/* 8401 */       if (methodHandle != null && methodType != null && constants.size() == argument.length) {
/* 8402 */         MemberSubstitution.Replacement.Binding binding = this.replacement.bind(this.instrumentedType, this.instrumentedMethod, methodHandle, methodType, name, constants);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 8408 */         if (binding.isBound()) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 8413 */           StackManipulation.Size size = binding.make(methodType.getParameterTypes().asGenericTypes(), methodType.getReturnType().asGenericType(), methodHandle, (StackManipulation)new Invokedynamic(name, methodType, methodHandle, constants), getFreeOffset()).apply(new LocalVariableTracingMethodVisitor(this.mv), this.implementationContext);
/* 8414 */           this.stackSizeBuffer = Math.max(this.stackSizeBuffer, size.getMaximalSize());
/* 8415 */           this.matched = true;
/*      */           return;
/*      */         } 
/*      */       } 
/* 8419 */       super.visitInvokeDynamicInsn(name, descriptor, handle, argument);
/*      */     }
/*      */ 
/*      */     
/*      */     public void visitMaxs(int stackSize, int localVariableLength) {
/* 8424 */       if (this.failIfNoMatch && !this.matched) {
/* 8425 */         throw new IllegalStateException("No substitution found within " + this.instrumentedMethod + " of " + this.instrumentedType);
/*      */       }
/* 8427 */       super.visitMaxs(stackSize + this.stackSizeBuffer, Math.max(this.localVariableExtension, localVariableLength));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private class LocalVariableTracingMethodVisitor
/*      */       extends MethodVisitor
/*      */     {
/*      */       private LocalVariableTracingMethodVisitor(MethodVisitor methodVisitor) {
/* 8441 */         super(OpenedClassReader.ASM_API, methodVisitor);
/*      */       }
/*      */ 
/*      */       
/*      */       @SuppressFBWarnings(value = {"SF_SWITCH_NO_DEFAULT"}, justification = "No action required on default option.")
/*      */       public void visitVarInsn(int opcode, int offset) {
/* 8447 */         switch (opcode) {
/*      */           case 54:
/*      */           case 56:
/*      */           case 58:
/* 8451 */             MemberSubstitution.SubstitutingMethodVisitor.this.localVariableExtension = Math.max(MemberSubstitution.SubstitutingMethodVisitor.this.localVariableExtension, offset + 1);
/*      */             break;
/*      */           case 55:
/*      */           case 57:
/* 8455 */             MemberSubstitution.SubstitutingMethodVisitor.this.localVariableExtension = Math.max(MemberSubstitution.SubstitutingMethodVisitor.this.localVariableExtension, offset + 2);
/*      */             break;
/*      */         } 
/* 8458 */         super.visitVarInsn(opcode, offset);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Source
/*      */   {
/* 8983 */     SUBSTITUTED_ELEMENT
/*      */     {
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       protected Value self(TypeList.Generic parameters, Map<Integer, Integer> offsets, MemberSubstitution.Target target, MethodDescription instrumentedMethod)
/*      */       {
/* 8990 */         return target.isStaticDispatch() ? null : new Value((TypeDescription.Generic)parameters
/*      */             
/* 8992 */             .get(0), ((Integer)offsets.get(Integer.valueOf(0))).intValue());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       protected Value argument(int index, TypeList.Generic parameters, Map<Integer, Integer> offsets, MemberSubstitution.Target target, MethodDescription instrumentedMethod) {
/* 9002 */         if (index < parameters.size() - (target.isStaticDispatch() ? 0 : 1)) {  } else {  }  return 
/* 9003 */           null;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected List<Value> arguments(boolean includesSelf, TypeList.Generic parameters, Map<Integer, Integer> offsets, MemberSubstitution.Target target, MethodDescription instrumentedMethod) {
/* 9013 */         List<Value> values = new ArrayList<Value>(parameters.size() - ((!includesSelf && target.isStaticDispatch()) ? 1 : 0));
/* 9014 */         for (int index = (target.isStaticDispatch() || includesSelf) ? 0 : 1; index < parameters.size(); index++) {
/* 9015 */           values.add(new Value((TypeDescription.Generic)parameters.get(index), ((Integer)offsets.get(Integer.valueOf(index))).intValue()));
/*      */         }
/* 9017 */         return values;
/*      */       }
/*      */ 
/*      */       
/*      */       protected JavaConstant.MethodHandle handle(JavaConstant.MethodHandle methodHandle, MethodDescription instrumentedMethod) {
/* 9022 */         return methodHandle;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected boolean isRepresentable(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort sort, MemberSubstitution.Target target, MethodDescription instrumentedMethod) {
/* 9029 */         return (target instanceof MemberSubstitution.Target.ForMember && sort.isRepresentable(((MemberSubstitution.Target.ForMember)target).getMember()));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected StackManipulation resolve(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort sort, MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, MethodDescription instrumentedMethod) {
/* 9038 */         ByteCodeElement.Member member = ((MemberSubstitution.Target.ForMember)target).getMember();
/* 9039 */         return sort.resolve(member, (List<TypeDescription>)parameters.asErasures(), result.asErasure());
/*      */       }
/*      */     },
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 9046 */     ENCLOSING_METHOD
/*      */     {
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       protected Value self(TypeList.Generic parameters, Map<Integer, Integer> offsets, MemberSubstitution.Target target, MethodDescription instrumentedMethod)
/*      */       {
/* 9053 */         return instrumentedMethod.isStatic() ? null : new Value(instrumentedMethod
/*      */             
/* 9055 */             .getDeclaringType().asGenericType(), 0);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       @MaybeNull
/*      */       protected Value argument(int index, TypeList.Generic parameters, Map<Integer, Integer> offsets, MemberSubstitution.Target target, MethodDescription instrumentedMethod) {
/* 9065 */         if (index < instrumentedMethod.getParameters().size()) {
/* 9066 */           ParameterDescription parameterDescription = (ParameterDescription)instrumentedMethod.getParameters().get(index);
/* 9067 */           return new Value(parameterDescription.getType(), parameterDescription.getOffset());
/*      */         } 
/* 9069 */         return null;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected List<Value> arguments(boolean includesSelf, TypeList.Generic parameters, Map<Integer, Integer> offsets, MemberSubstitution.Target target, MethodDescription instrumentedMethod) {
/*      */         List<Value> values;
/* 9080 */         if (includesSelf && !instrumentedMethod.isStatic()) {
/* 9081 */           values = new ArrayList<Value>(instrumentedMethod.getParameters().size() + 1);
/* 9082 */           values.add(new Value(instrumentedMethod.getDeclaringType().asGenericType(), 0));
/*      */         } else {
/* 9084 */           values = new ArrayList<Value>(instrumentedMethod.getParameters().size());
/*      */         } 
/* 9086 */         for (ParameterDescription parameterDescription : instrumentedMethod.getParameters()) {
/* 9087 */           values.add(new Value(parameterDescription.getType(), parameterDescription.getOffset()));
/*      */         }
/* 9089 */         return values;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       protected JavaConstant.MethodHandle handle(JavaConstant.MethodHandle methodHandle, MethodDescription instrumentedMethod) {
/* 9095 */         return JavaConstant.MethodHandle.of((MethodDescription.InDefinedShape)instrumentedMethod.asDefined());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected boolean isRepresentable(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort sort, MemberSubstitution.Target target, MethodDescription instrumentedMethod) {
/* 9102 */         return sort.isRepresentable((ByteCodeElement.Member)instrumentedMethod);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected StackManipulation resolve(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort sort, MemberSubstitution.Target target, TypeList.Generic parameters, TypeDescription.Generic result, MethodDescription instrumentedMethod) {
/* 9111 */         return sort.resolve((ByteCodeElement.Member)instrumentedMethod, (instrumentedMethod
/* 9112 */             .isStatic() || instrumentedMethod.isConstructor()) ? (List<TypeDescription>)instrumentedMethod
/* 9113 */             .getParameters().asTypeList().asErasures() : 
/* 9114 */             CompoundList.of(instrumentedMethod.getDeclaringType().asErasure(), (List)instrumentedMethod.getParameters().asTypeList().asErasures()), 
/* 9115 */             instrumentedMethod.isConstructor() ? instrumentedMethod
/* 9116 */             .getDeclaringType().asErasure() : instrumentedMethod
/* 9117 */             .getReturnType().asErasure());
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     protected abstract Value self(TypeList.Generic param1Generic, Map<Integer, Integer> param1Map, MemberSubstitution.Target param1Target, MethodDescription param1MethodDescription);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     protected abstract Value argument(int param1Int, TypeList.Generic param1Generic, Map<Integer, Integer> param1Map, MemberSubstitution.Target param1Target, MethodDescription param1MethodDescription);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected abstract List<Value> arguments(boolean param1Boolean, TypeList.Generic param1Generic, Map<Integer, Integer> param1Map, MemberSubstitution.Target param1Target, MethodDescription param1MethodDescription);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected abstract JavaConstant.MethodHandle handle(JavaConstant.MethodHandle param1MethodHandle, MethodDescription param1MethodDescription);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected abstract boolean isRepresentable(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort param1Sort, MemberSubstitution.Target param1Target, MethodDescription param1MethodDescription);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected abstract StackManipulation resolve(MemberSubstitution.Substitution.Chain.Step.ForDelegation.OffsetMapping.ForOrigin.Sort param1Sort, MemberSubstitution.Target param1Target, TypeList.Generic param1Generic, TypeDescription.Generic param1Generic1, MethodDescription param1MethodDescription);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Enhance
/*      */     protected static class Value
/*      */     {
/*      */       private final TypeDescription.Generic typeDescription;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       private final int offset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected Value(TypeDescription.Generic typeDescription, int offset) {
/* 9230 */         this.typeDescription = typeDescription;
/* 9231 */         this.offset = offset;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected TypeDescription.Generic getTypeDescription() {
/* 9240 */         return this.typeDescription;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       protected int getOffset() {
/* 9249 */         return this.offset;
/*      */       }
/*      */       
/*      */       public boolean equals(@MaybeNull Object param2Object) {
/*      */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.offset != ((Value)param2Object).offset) ? false : (!!this.typeDescription.equals(((Value)param2Object).typeDescription)))));
/*      */       }
/*      */       
/*      */       public int hashCode() {
/*      */         return (getClass().hashCode() * 31 + this.typeDescription.hashCode()) * 31 + this.offset;
/*      */       } }
/*      */   }
/*      */   
/*      */   protected static class LambdaMetaFactoryMatcher implements ElementMatcher<JavaConstant.MethodHandle> {
/*      */     public boolean matches(@MaybeNull JavaConstant.MethodHandle target) {
/* 9263 */       return (target != null && target.getOwnerType().getName().equals("java.lang.invoke.LambdaMetafactory"));
/*      */     }
/*      */   }
/*      */   
/*      */   @Documented
/*      */   @Retention(RetentionPolicy.RUNTIME)
/*      */   @Target({ElementType.PARAMETER, ElementType.METHOD, ElementType.CONSTRUCTOR})
/*      */   public static @interface Current {
/*      */     Assigner.Typing typing() default Assigner.Typing.STATIC;
/*      */   }
/*      */   
/*      */   @Documented
/*      */   @Retention(RetentionPolicy.RUNTIME)
/*      */   @Target({ElementType.PARAMETER})
/*      */   public static @interface StubValue {
/*      */     MemberSubstitution.Source source() default MemberSubstitution.Source.SUBSTITUTED_ELEMENT;
/*      */   }
/*      */   
/*      */   @Documented
/*      */   @Retention(RetentionPolicy.RUNTIME)
/*      */   @Target({ElementType.PARAMETER})
/*      */   public static @interface Unused {}
/*      */   
/*      */   @Documented
/*      */   @Retention(RetentionPolicy.RUNTIME)
/*      */   @Target({ElementType.PARAMETER})
/*      */   public static @interface Origin {
/*      */     MemberSubstitution.Source source() default MemberSubstitution.Source.SUBSTITUTED_ELEMENT;
/*      */   }
/*      */   
/*      */   @Documented
/*      */   @Retention(RetentionPolicy.RUNTIME)
/*      */   @Target({ElementType.PARAMETER})
/*      */   public static @interface FieldSetterHandle {
/*      */     String value() default "";
/*      */     
/*      */     Class<?> declaringType() default void.class;
/*      */   }
/*      */   
/*      */   @Documented
/*      */   @Retention(RetentionPolicy.RUNTIME)
/*      */   @Target({ElementType.PARAMETER})
/*      */   public static @interface FieldGetterHandle {
/*      */     String value() default "";
/*      */     
/*      */     Class<?> declaringType() default void.class;
/*      */   }
/*      */   
/*      */   @Documented
/*      */   @Retention(RetentionPolicy.RUNTIME)
/*      */   @Target({ElementType.PARAMETER, ElementType.METHOD, ElementType.CONSTRUCTOR})
/*      */   public static @interface FieldValue {
/*      */     String value() default "";
/*      */     
/*      */     Class<?> declaringType() default void.class;
/*      */     
/*      */     Assigner.Typing typing() default Assigner.Typing.STATIC;
/*      */   }
/*      */   
/*      */   @Documented
/*      */   @Retention(RetentionPolicy.RUNTIME)
/*      */   @Target({ElementType.PARAMETER})
/*      */   public static @interface DynamicConstant {
/*      */     String name() default "_";
/*      */     
/*      */     JavaConstant.MethodHandle.HandleType bootstrapType();
/*      */     
/*      */     Class<?> bootstrapOwner() default void.class;
/*      */     
/*      */     String bootstrapName();
/*      */     
/*      */     Class<?> bootstrapReturnType();
/*      */     
/*      */     Class<?>[] bootstrapParameterTypes();
/*      */     
/*      */     boolean invokedynamic() default false;
/*      */   }
/*      */   
/*      */   @Documented
/*      */   @Retention(RetentionPolicy.RUNTIME)
/*      */   @Target({ElementType.PARAMETER})
/*      */   public static @interface Handle {
/*      */     JavaConstant.MethodHandle.HandleType type();
/*      */     
/*      */     Class<?> owner() default void.class;
/*      */     
/*      */     String name();
/*      */     
/*      */     Class<?> returnType();
/*      */     
/*      */     Class<?>[] parameterTypes();
/*      */   }
/*      */   
/*      */   @Documented
/*      */   @Retention(RetentionPolicy.RUNTIME)
/*      */   @Target({ElementType.PARAMETER})
/*      */   public static @interface SelfCallHandle {
/*      */     MemberSubstitution.Source source() default MemberSubstitution.Source.SUBSTITUTED_ELEMENT;
/*      */     
/*      */     boolean bound() default true;
/*      */   }
/*      */   
/*      */   @Documented
/*      */   @Retention(RetentionPolicy.RUNTIME)
/*      */   @Target({ElementType.PARAMETER})
/*      */   public static @interface AllArguments {
/*      */     Assigner.Typing typing() default Assigner.Typing.STATIC;
/*      */     
/*      */     MemberSubstitution.Source source() default MemberSubstitution.Source.SUBSTITUTED_ELEMENT;
/*      */     
/*      */     boolean includeSelf() default false;
/*      */     
/*      */     boolean nullIfEmpty() default false;
/*      */   }
/*      */   
/*      */   @Documented
/*      */   @Retention(RetentionPolicy.RUNTIME)
/*      */   @Target({ElementType.PARAMETER, ElementType.METHOD, ElementType.CONSTRUCTOR})
/*      */   public static @interface Argument {
/*      */     int value();
/*      */     
/*      */     Assigner.Typing typing() default Assigner.Typing.STATIC;
/*      */     
/*      */     MemberSubstitution.Source source() default MemberSubstitution.Source.SUBSTITUTED_ELEMENT;
/*      */     
/*      */     boolean optional() default false;
/*      */   }
/*      */   
/*      */   @Documented
/*      */   @Retention(RetentionPolicy.RUNTIME)
/*      */   @Target({ElementType.PARAMETER, ElementType.METHOD, ElementType.CONSTRUCTOR})
/*      */   public static @interface This {
/*      */     Assigner.Typing typing() default Assigner.Typing.STATIC;
/*      */     
/*      */     MemberSubstitution.Source source() default MemberSubstitution.Source.SUBSTITUTED_ELEMENT;
/*      */     
/*      */     boolean optional() default false;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\asm\MemberSubstitution.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */