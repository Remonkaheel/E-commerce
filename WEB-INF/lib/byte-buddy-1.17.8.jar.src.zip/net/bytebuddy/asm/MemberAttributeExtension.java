/*     */ package net.bytebuddy.asm;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*     */ import net.bytebuddy.description.annotation.AnnotationList;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.implementation.attribute.AnnotationValueFilter;
/*     */ import net.bytebuddy.implementation.attribute.FieldAttributeAppender;
/*     */ import net.bytebuddy.implementation.attribute.MethodAttributeAppender;
/*     */ import net.bytebuddy.jar.asm.FieldVisitor;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.pool.TypePool;
/*     */ import net.bytebuddy.utility.OpenedClassReader;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public abstract class MemberAttributeExtension<T>
/*     */ {
/*     */   protected final AnnotationValueFilter.Factory annotationValueFilterFactory;
/*     */   protected final T attributeAppenderFactory;
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.annotationValueFilterFactory.equals(((MemberAttributeExtension)paramObject).annotationValueFilterFactory) ? false : (!!this.attributeAppenderFactory.equals(((MemberAttributeExtension)paramObject).attributeAppenderFactory)))));
/*     */   }
/*     */   
/*     */   protected MemberAttributeExtension(AnnotationValueFilter.Factory annotationValueFilterFactory, T attributeAppenderFactory) {
/*  65 */     this.annotationValueFilterFactory = annotationValueFilterFactory;
/*  66 */     this.attributeAppenderFactory = attributeAppenderFactory;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return (getClass().hashCode() * 31 + this.annotationValueFilterFactory.hashCode()) * 31 + this.attributeAppenderFactory.hashCode();
/*     */   }
/*     */   
/*     */   public static class ForField
/*     */     extends MemberAttributeExtension<FieldAttributeAppender.Factory>
/*     */     implements AsmVisitorWrapper.ForDeclaredFields.FieldVisitorWrapper
/*     */   {
/*     */     public ForField() {
/*  78 */       this((AnnotationValueFilter.Factory)AnnotationValueFilter.Default.APPEND_DEFAULTS);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForField(AnnotationValueFilter.Factory annotationValueFilterFactory) {
/*  87 */       this(annotationValueFilterFactory, (FieldAttributeAppender.Factory)FieldAttributeAppender.NoOp.INSTANCE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected ForField(AnnotationValueFilter.Factory annotationValueFilterFactory, FieldAttributeAppender.Factory attributeAppenderFactory) {
/*  97 */       super(annotationValueFilterFactory, attributeAppenderFactory);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForField annotate(Annotation... annotation) {
/* 107 */       return annotate(Arrays.asList(annotation));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForField annotate(List<? extends Annotation> annotations) {
/* 117 */       return annotate((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForField annotate(AnnotationDescription... annotation) {
/* 127 */       return annotate(Arrays.asList(annotation));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForField annotate(Collection<? extends AnnotationDescription> annotations) {
/* 137 */       return attribute((FieldAttributeAppender.Factory)new FieldAttributeAppender.Explicit(new ArrayList<AnnotationDescription>(annotations)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForField attribute(FieldAttributeAppender.Factory attributeAppenderFactory) {
/* 147 */       return new ForField(this.annotationValueFilterFactory, (FieldAttributeAppender.Factory)new FieldAttributeAppender.Factory.Compound(new FieldAttributeAppender.Factory[] { this.attributeAppenderFactory, attributeAppenderFactory }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldVisitor wrap(TypeDescription instrumentedType, FieldDescription.InDefinedShape fieldDescription, FieldVisitor fieldVisitor) {
/* 154 */       return new FieldAttributeVisitor(fieldVisitor, (FieldDescription)fieldDescription, this.attributeAppenderFactory
/*     */           
/* 156 */           .make(instrumentedType), this.annotationValueFilterFactory
/* 157 */           .on((FieldDescription)fieldDescription));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AsmVisitorWrapper on(ElementMatcher<? super FieldDescription.InDefinedShape> matcher) {
/* 167 */       return (new AsmVisitorWrapper.ForDeclaredFields()).field(matcher, new AsmVisitorWrapper.ForDeclaredFields.FieldVisitorWrapper[] { this });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static class FieldAttributeVisitor
/*     */       extends FieldVisitor
/*     */     {
/*     */       private final FieldDescription fieldDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final FieldAttributeAppender fieldAttributeAppender;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final AnnotationValueFilter annotationValueFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private FieldAttributeVisitor(FieldVisitor fieldVisitor, FieldDescription fieldDescription, FieldAttributeAppender fieldAttributeAppender, AnnotationValueFilter annotationValueFilter) {
/* 202 */         super(OpenedClassReader.ASM_API, fieldVisitor);
/* 203 */         this.fieldDescription = fieldDescription;
/* 204 */         this.fieldAttributeAppender = fieldAttributeAppender;
/* 205 */         this.annotationValueFilter = annotationValueFilter;
/*     */       }
/*     */ 
/*     */       
/*     */       public void visitEnd() {
/* 210 */         this.fieldAttributeAppender.apply(this.fv, this.fieldDescription, this.annotationValueFilter);
/* 211 */         super.visitEnd();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ForMethod
/*     */     extends MemberAttributeExtension<MethodAttributeAppender.Factory>
/*     */     implements AsmVisitorWrapper.ForDeclaredMethods.MethodVisitorWrapper
/*     */   {
/*     */     public ForMethod() {
/* 225 */       this((AnnotationValueFilter.Factory)AnnotationValueFilter.Default.APPEND_DEFAULTS);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForMethod(AnnotationValueFilter.Factory annotationValueFilterFactory) {
/* 234 */       this(annotationValueFilterFactory, (MethodAttributeAppender.Factory)MethodAttributeAppender.NoOp.INSTANCE);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected ForMethod(AnnotationValueFilter.Factory annotationValueFilterFactory, MethodAttributeAppender.Factory attributeAppenderFactory) {
/* 244 */       super(annotationValueFilterFactory, attributeAppenderFactory);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForMethod annotateMethod(Annotation... annotation) {
/* 254 */       return annotateMethod(Arrays.asList(annotation));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForMethod annotateMethod(List<? extends Annotation> annotations) {
/* 264 */       return annotateMethod((Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForMethod annotateMethod(AnnotationDescription... annotation) {
/* 274 */       return annotateMethod(Arrays.asList(annotation));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForMethod annotateMethod(Collection<? extends AnnotationDescription> annotations) {
/* 284 */       return attribute((MethodAttributeAppender.Factory)new MethodAttributeAppender.Explicit(new ArrayList<AnnotationDescription>(annotations)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForMethod annotateParameter(int index, Annotation... annotation) {
/* 295 */       return annotateParameter(index, Arrays.asList(annotation));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForMethod annotateParameter(int index, List<? extends Annotation> annotations) {
/* 306 */       return annotateParameter(index, (Collection<? extends AnnotationDescription>)new AnnotationList.ForLoadedAnnotations(annotations));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForMethod annotateParameter(int index, AnnotationDescription... annotation) {
/* 317 */       return annotateParameter(index, Arrays.asList(annotation));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForMethod annotateParameter(int index, Collection<? extends AnnotationDescription> annotations) {
/* 328 */       if (index < 0) {
/* 329 */         throw new IllegalArgumentException("Parameter index cannot be negative: " + index);
/*     */       }
/* 331 */       return attribute((MethodAttributeAppender.Factory)new MethodAttributeAppender.Explicit(index, new ArrayList<AnnotationDescription>(annotations)));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ForMethod attribute(MethodAttributeAppender.Factory attributeAppenderFactory) {
/* 342 */       return new ForMethod(this.annotationValueFilterFactory, (MethodAttributeAppender.Factory)new MethodAttributeAppender.Factory.Compound(new MethodAttributeAppender.Factory[] { this.attributeAppenderFactory, attributeAppenderFactory }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodVisitor wrap(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, TypePool typePool, int writerFlags, int readerFlags) {
/* 355 */       return new AttributeAppendingMethodVisitor(methodVisitor, instrumentedMethod, this.attributeAppenderFactory
/*     */           
/* 357 */           .make(instrumentedType), this.annotationValueFilterFactory
/* 358 */           .on(instrumentedMethod));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AsmVisitorWrapper on(ElementMatcher<? super MethodDescription> matcher) {
/* 368 */       return (new AsmVisitorWrapper.ForDeclaredMethods()).invokable(matcher, new AsmVisitorWrapper.ForDeclaredMethods.MethodVisitorWrapper[] { this });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static class AttributeAppendingMethodVisitor
/*     */       extends MethodVisitor
/*     */     {
/*     */       private final MethodDescription methodDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final MethodAttributeAppender methodAttributeAppender;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private final AnnotationValueFilter annotationValueFilter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private boolean applicable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private AttributeAppendingMethodVisitor(MethodVisitor methodVisitor, MethodDescription methodDescription, MethodAttributeAppender methodAttributeAppender, AnnotationValueFilter annotationValueFilter) {
/* 406 */         super(OpenedClassReader.ASM_API, methodVisitor);
/* 407 */         this.methodDescription = methodDescription;
/* 408 */         this.methodAttributeAppender = methodAttributeAppender;
/* 409 */         this.annotationValueFilter = annotationValueFilter;
/* 410 */         this.applicable = true;
/*     */       }
/*     */ 
/*     */       
/*     */       public void visitCode() {
/* 415 */         if (this.applicable) {
/* 416 */           this.methodAttributeAppender.apply(this.mv, this.methodDescription, this.annotationValueFilter);
/* 417 */           this.applicable = false;
/*     */         } 
/* 419 */         super.visitCode();
/*     */       }
/*     */ 
/*     */       
/*     */       public void visitEnd() {
/* 424 */         if (this.applicable) {
/* 425 */           this.methodAttributeAppender.apply(this.mv, this.methodDescription, this.annotationValueFilter);
/* 426 */           this.applicable = false;
/*     */         } 
/* 428 */         super.visitEnd();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\asm\MemberAttributeExtension.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */