/*       */ package net.bytebuddy.asm;
/*       */ 
/*       */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*       */ import java.io.IOException;
/*       */ import java.io.Serializable;
/*       */ import java.lang.annotation.Annotation;
/*       */ import java.lang.annotation.Documented;
/*       */ import java.lang.annotation.ElementType;
/*       */ import java.lang.annotation.Repeatable;
/*       */ import java.lang.annotation.Retention;
/*       */ import java.lang.annotation.RetentionPolicy;
/*       */ import java.lang.annotation.Target;
/*       */ import java.lang.reflect.Constructor;
/*       */ import java.lang.reflect.Field;
/*       */ import java.lang.reflect.Method;
/*       */ import java.lang.reflect.Type;
/*       */ import java.util.ArrayList;
/*       */ import java.util.Arrays;
/*       */ import java.util.Collection;
/*       */ import java.util.Collections;
/*       */ import java.util.HashMap;
/*       */ import java.util.IdentityHashMap;
/*       */ import java.util.LinkedHashMap;
/*       */ import java.util.List;
/*       */ import java.util.Map;
/*       */ import java.util.SortedMap;
/*       */ import java.util.TreeMap;
/*       */ import net.bytebuddy.ClassFileVersion;
/*       */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*       */ import net.bytebuddy.build.RepeatedAnnotationPlugin.Enhance;
/*       */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*       */ import net.bytebuddy.description.annotation.AnnotationValue;
/*       */ import net.bytebuddy.description.enumeration.EnumerationDescription;
/*       */ import net.bytebuddy.description.field.FieldDescription;
/*       */ import net.bytebuddy.description.method.MethodDescription;
/*       */ import net.bytebuddy.description.method.MethodList;
/*       */ import net.bytebuddy.description.method.ParameterDescription;
/*       */ import net.bytebuddy.description.method.ParameterList;
/*       */ import net.bytebuddy.description.type.TypeDefinition;
/*       */ import net.bytebuddy.description.type.TypeDescription;
/*       */ import net.bytebuddy.description.type.TypeList;
/*       */ import net.bytebuddy.dynamic.ClassFileLocator;
/*       */ import net.bytebuddy.dynamic.TargetType;
/*       */ import net.bytebuddy.dynamic.scaffold.FieldLocator;
/*       */ import net.bytebuddy.dynamic.scaffold.InstrumentedType;
/*       */ import net.bytebuddy.dynamic.scaffold.MethodGraph;
/*       */ import net.bytebuddy.implementation.FieldAccessor;
/*       */ import net.bytebuddy.implementation.Implementation;
/*       */ import net.bytebuddy.implementation.SuperMethodCall;
/*       */ import net.bytebuddy.implementation.bytecode.Addition;
/*       */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*       */ import net.bytebuddy.implementation.bytecode.Duplication;
/*       */ import net.bytebuddy.implementation.bytecode.Removal;
/*       */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*       */ import net.bytebuddy.implementation.bytecode.StackSize;
/*       */ import net.bytebuddy.implementation.bytecode.Throw;
/*       */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*       */ import net.bytebuddy.implementation.bytecode.collection.ArrayAccess;
/*       */ import net.bytebuddy.implementation.bytecode.collection.ArrayFactory;
/*       */ import net.bytebuddy.implementation.bytecode.constant.ClassConstant;
/*       */ import net.bytebuddy.implementation.bytecode.constant.DefaultValue;
/*       */ import net.bytebuddy.implementation.bytecode.constant.IntegerConstant;
/*       */ import net.bytebuddy.implementation.bytecode.constant.JavaConstantValue;
/*       */ import net.bytebuddy.implementation.bytecode.constant.MethodConstant;
/*       */ import net.bytebuddy.implementation.bytecode.constant.NullConstant;
/*       */ import net.bytebuddy.implementation.bytecode.constant.SerializedConstant;
/*       */ import net.bytebuddy.implementation.bytecode.member.FieldAccess;
/*       */ import net.bytebuddy.implementation.bytecode.member.Invokedynamic;
/*       */ import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
/*       */ import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;
/*       */ import net.bytebuddy.jar.asm.AnnotationVisitor;
/*       */ import net.bytebuddy.jar.asm.Attribute;
/*       */ import net.bytebuddy.jar.asm.ClassVisitor;
/*       */ import net.bytebuddy.jar.asm.Label;
/*       */ import net.bytebuddy.jar.asm.MethodVisitor;
/*       */ import net.bytebuddy.jar.asm.Opcodes;
/*       */ import net.bytebuddy.jar.asm.Type;
/*       */ import net.bytebuddy.jar.asm.TypePath;
/*       */ import net.bytebuddy.matcher.ElementMatcher;
/*       */ import net.bytebuddy.matcher.ElementMatchers;
/*       */ import net.bytebuddy.pool.TypePool;
/*       */ import net.bytebuddy.utility.AsmClassReader;
/*       */ import net.bytebuddy.utility.CompoundList;
/*       */ import net.bytebuddy.utility.ConstantValue;
/*       */ import net.bytebuddy.utility.JavaConstant;
/*       */ import net.bytebuddy.utility.JavaType;
/*       */ import net.bytebuddy.utility.OpenedClassReader;
/*       */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*       */ import net.bytebuddy.utility.nullability.MaybeNull;
/*       */ import net.bytebuddy.utility.visitor.ExceptionTableSensitiveMethodVisitor;
/*       */ import net.bytebuddy.utility.visitor.LineNumberPrependingMethodVisitor;
/*       */ import net.bytebuddy.utility.visitor.StackAwareMethodVisitor;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ @Enhance
/*       */ public class Advice
/*       */   implements AsmVisitorWrapper.ForDeclaredMethods.MethodVisitorWrapper, Implementation
/*       */ {
/*       */   @AlwaysNull
/*   167 */   private static final AsmClassReader UNDEFINED = null;
/*       */ 
/*       */ 
/*       */   
/*       */   private static final MethodDescription.InDefinedShape SKIP_ON;
/*       */ 
/*       */ 
/*       */   
/*       */   private static final MethodDescription.InDefinedShape SKIP_ON_INDEX;
/*       */ 
/*       */ 
/*       */   
/*       */   private static final MethodDescription.InDefinedShape PREPEND_LINE_NUMBER;
/*       */ 
/*       */ 
/*       */   
/*       */   private static final MethodDescription.InDefinedShape INLINE_ENTER;
/*       */ 
/*       */ 
/*       */   
/*       */   private static final MethodDescription.InDefinedShape SUPPRESS_ENTER;
/*       */ 
/*       */ 
/*       */   
/*       */   private static final MethodDescription.InDefinedShape REPEAT_ON;
/*       */ 
/*       */ 
/*       */   
/*       */   private static final MethodDescription.InDefinedShape REPEAT_ON_INDEX;
/*       */ 
/*       */ 
/*       */   
/*       */   private static final MethodDescription.InDefinedShape ON_THROWABLE;
/*       */ 
/*       */   
/*       */   private static final MethodDescription.InDefinedShape BACKUP_ARGUMENTS;
/*       */ 
/*       */   
/*       */   private static final MethodDescription.InDefinedShape INLINE_EXIT;
/*       */ 
/*       */   
/*       */   private static final MethodDescription.InDefinedShape SUPPRESS_EXIT;
/*       */ 
/*       */   
/*       */   private final Dispatcher.Resolved.ForMethodEnter methodEnter;
/*       */ 
/*       */   
/*       */   private final Dispatcher.Resolved.ForMethodExit methodExit;
/*       */ 
/*       */   
/*       */   private final Assigner assigner;
/*       */ 
/*       */   
/*       */   private final ExceptionHandler exceptionHandler;
/*       */ 
/*       */   
/*       */   private final Implementation delegate;
/*       */ 
/*       */ 
/*       */   
/*       */   static {
/*   228 */     MethodList<MethodDescription.InDefinedShape> enter = TypeDescription.ForLoadedType.of(OnMethodEnter.class).getDeclaredMethods();
/*   229 */     SKIP_ON = (MethodDescription.InDefinedShape)((MethodList)enter.filter((ElementMatcher)ElementMatchers.named("skipOn"))).getOnly();
/*   230 */     SKIP_ON_INDEX = (MethodDescription.InDefinedShape)((MethodList)enter.filter((ElementMatcher)ElementMatchers.named("skipOnIndex"))).getOnly();
/*   231 */     PREPEND_LINE_NUMBER = (MethodDescription.InDefinedShape)((MethodList)enter.filter((ElementMatcher)ElementMatchers.named("prependLineNumber"))).getOnly();
/*   232 */     INLINE_ENTER = (MethodDescription.InDefinedShape)((MethodList)enter.filter((ElementMatcher)ElementMatchers.named("inline"))).getOnly();
/*   233 */     SUPPRESS_ENTER = (MethodDescription.InDefinedShape)((MethodList)enter.filter((ElementMatcher)ElementMatchers.named("suppress"))).getOnly();
/*   234 */     MethodList<MethodDescription.InDefinedShape> exit = TypeDescription.ForLoadedType.of(OnMethodExit.class).getDeclaredMethods();
/*   235 */     REPEAT_ON = (MethodDescription.InDefinedShape)((MethodList)exit.filter((ElementMatcher)ElementMatchers.named("repeatOn"))).getOnly();
/*   236 */     REPEAT_ON_INDEX = (MethodDescription.InDefinedShape)((MethodList)exit.filter((ElementMatcher)ElementMatchers.named("repeatOnIndex"))).getOnly();
/*   237 */     ON_THROWABLE = (MethodDescription.InDefinedShape)((MethodList)exit.filter((ElementMatcher)ElementMatchers.named("onThrowable"))).getOnly();
/*   238 */     BACKUP_ARGUMENTS = (MethodDescription.InDefinedShape)((MethodList)exit.filter((ElementMatcher)ElementMatchers.named("backupArguments"))).getOnly();
/*   239 */     INLINE_EXIT = (MethodDescription.InDefinedShape)((MethodList)exit.filter((ElementMatcher)ElementMatchers.named("inline"))).getOnly();
/*   240 */     SUPPRESS_EXIT = (MethodDescription.InDefinedShape)((MethodList)exit.filter((ElementMatcher)ElementMatchers.named("suppress"))).getOnly();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected Advice(Dispatcher.Resolved.ForMethodEnter methodEnter, Dispatcher.Resolved.ForMethodExit methodExit) {
/*   275 */     this(methodEnter, methodExit, Assigner.DEFAULT, ExceptionHandler.Default.SUPPRESSING, (Implementation)SuperMethodCall.INSTANCE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private Advice(Dispatcher.Resolved.ForMethodEnter methodEnter, Dispatcher.Resolved.ForMethodExit methodExit, Assigner assigner, ExceptionHandler exceptionHandler, Implementation delegate) {
/*   292 */     this.methodEnter = methodEnter;
/*   293 */     this.methodExit = methodExit;
/*   294 */     this.assigner = assigner;
/*   295 */     this.exceptionHandler = exceptionHandler;
/*   296 */     this.delegate = delegate;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Advice to(Class<?> advice) {
/*   307 */     return to(advice, ClassFileLocator.ForClassLoader.of(advice.getClassLoader()));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Advice to(Class<?> advice, ClassFileLocator classFileLocator) {
/*   318 */     return to(TypeDescription.ForLoadedType.of(advice), classFileLocator);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Advice to(TypeDescription advice) {
/*   330 */     return to(advice, (ClassFileLocator)ClassFileLocator.NoOp.INSTANCE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Advice to(TypeDescription advice, ClassFileLocator classFileLocator) {
/*   341 */     return to(advice, PostProcessor.NoOp.INSTANCE, classFileLocator, 
/*       */ 
/*       */         
/*   344 */         Collections.emptyList(), Delegator.ForRegularInvocation.Factory.INSTANCE, (AsmClassReader.Factory)AsmClassReader.Factory.Default.IMPLICIT);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected static Advice to(TypeDescription advice, PostProcessor.Factory postProcessorFactory, ClassFileLocator classFileLocator, List<? extends OffsetMapping.Factory<?>> userFactories, Delegator.Factory delegatorFactory, AsmClassReader.Factory classReaderFactory) {
/*   366 */     Dispatcher.Unresolved methodEnter = Dispatcher.Inactive.INSTANCE, methodExit = Dispatcher.Inactive.INSTANCE;
/*   367 */     for (MethodDescription.InDefinedShape methodDescription : advice.getDeclaredMethods()) {
/*   368 */       methodEnter = locate((Class)OnMethodEnter.class, INLINE_ENTER, methodEnter, methodDescription, delegatorFactory);
/*   369 */       methodExit = locate((Class)OnMethodExit.class, INLINE_EXIT, methodExit, methodDescription, delegatorFactory);
/*       */     } 
/*   371 */     if (!methodEnter.isAlive() && !methodExit.isAlive()) {
/*   372 */       throw new IllegalArgumentException("No advice defined by " + advice);
/*       */     }
/*       */     
/*       */     try {
/*   376 */       AsmClassReader classReader = (methodEnter.isBinary() || methodExit.isBinary()) ? classReaderFactory.make(classFileLocator.locate(advice.getName()).resolve()) : UNDEFINED;
/*       */       
/*   378 */       return new Advice(methodEnter.asMethodEnter(userFactories, classReader, methodExit, postProcessorFactory), methodExit
/*   379 */           .asMethodExit(userFactories, classReader, methodEnter, postProcessorFactory));
/*   380 */     } catch (IOException exception) {
/*   381 */       throw new IllegalStateException("Error reading class file of " + advice, exception);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Advice to(Class<?> enterAdvice, Class<?> exitAdvice) {
/*   394 */     ClassLoader enterLoader = enterAdvice.getClassLoader(), exitLoader = exitAdvice.getClassLoader();
/*   395 */     return to(enterAdvice, exitAdvice, (enterLoader == exitLoader) ? 
/*   396 */         ClassFileLocator.ForClassLoader.of(enterLoader) : (ClassFileLocator)new ClassFileLocator.Compound(new ClassFileLocator[] {
/*   397 */             ClassFileLocator.ForClassLoader.of(enterLoader), ClassFileLocator.ForClassLoader.of(exitLoader)
/*       */           }));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Advice to(Class<?> enterAdvice, Class<?> exitAdvice, ClassFileLocator classFileLocator) {
/*   409 */     return to(TypeDescription.ForLoadedType.of(enterAdvice), TypeDescription.ForLoadedType.of(exitAdvice), classFileLocator);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Advice to(TypeDescription enterAdvice, TypeDescription exitAdvice) {
/*   422 */     return to(enterAdvice, exitAdvice, (ClassFileLocator)ClassFileLocator.NoOp.INSTANCE);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static Advice to(TypeDescription enterAdvice, TypeDescription exitAdvice, ClassFileLocator classFileLocator) {
/*   434 */     return to(enterAdvice, exitAdvice, PostProcessor.NoOp.INSTANCE, classFileLocator, 
/*       */ 
/*       */ 
/*       */         
/*   438 */         Collections.emptyList(), Delegator.ForRegularInvocation.Factory.INSTANCE, (AsmClassReader.Factory)AsmClassReader.Factory.Default.IMPLICIT);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected static Advice to(TypeDescription enterAdvice, TypeDescription exitAdvice, PostProcessor.Factory postProcessorFactory, ClassFileLocator classFileLocator, List<? extends OffsetMapping.Factory<?>> userFactories, Delegator.Factory delegatorFactory, AsmClassReader.Factory classReaderFactory) {
/*   462 */     Dispatcher.Unresolved methodEnter = Dispatcher.Inactive.INSTANCE, methodExit = Dispatcher.Inactive.INSTANCE;
/*   463 */     for (MethodDescription.InDefinedShape methodDescription : enterAdvice.getDeclaredMethods()) {
/*   464 */       methodEnter = locate((Class)OnMethodEnter.class, INLINE_ENTER, methodEnter, methodDescription, delegatorFactory);
/*       */     }
/*   466 */     if (!methodEnter.isAlive()) {
/*   467 */       throw new IllegalArgumentException("No enter advice defined by " + enterAdvice);
/*       */     }
/*   469 */     for (MethodDescription.InDefinedShape methodDescription : exitAdvice.getDeclaredMethods()) {
/*   470 */       methodExit = locate((Class)OnMethodExit.class, INLINE_EXIT, methodExit, methodDescription, delegatorFactory);
/*       */     }
/*   472 */     if (!methodExit.isAlive()) {
/*   473 */       throw new IllegalArgumentException("No exit advice defined by " + exitAdvice);
/*       */     }
/*       */     try {
/*   476 */       return new Advice(methodEnter.asMethodEnter(userFactories, methodEnter.isBinary() ? classReaderFactory
/*   477 */             .make(classFileLocator.locate(enterAdvice.getName()).resolve()) : UNDEFINED, methodExit, postProcessorFactory), methodExit
/*   478 */           .asMethodExit(userFactories, methodExit.isBinary() ? classReaderFactory
/*   479 */             .make(classFileLocator.locate(exitAdvice.getName()).resolve()) : UNDEFINED, methodEnter, postProcessorFactory));
/*       */     }
/*   481 */     catch (IOException exception) {
/*   482 */       throw new IllegalStateException("Error reading class file of " + enterAdvice + " or " + exitAdvice, exception);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static Dispatcher.Unresolved locate(Class<? extends Annotation> type, MethodDescription.InDefinedShape property, Dispatcher.Unresolved dispatcher, MethodDescription.InDefinedShape methodDescription, Delegator.Factory delegatorFactory) {
/*   501 */     AnnotationDescription.Loadable loadable = methodDescription.getDeclaredAnnotations().ofType(type);
/*   502 */     if (loadable == null)
/*   503 */       return dispatcher; 
/*   504 */     if (dispatcher.isAlive())
/*   505 */       throw new IllegalStateException("Duplicate advice for " + dispatcher + " and " + methodDescription); 
/*   506 */     if (!methodDescription.isStatic()) {
/*   507 */       throw new IllegalStateException("Advice for " + methodDescription + " is not static");
/*       */     }
/*   509 */     return ((Boolean)loadable.getValue(property).resolve(Boolean.class)).booleanValue() ? new Dispatcher.Inlining(methodDescription) : new Dispatcher.Delegating(methodDescription, delegatorFactory);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static WithCustomMapping withCustomMapping() {
/*   522 */     return new WithCustomMapping();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public AsmVisitorWrapper.ForDeclaredMethods on(ElementMatcher<? super MethodDescription> matcher) {
/*   532 */     return (new AsmVisitorWrapper.ForDeclaredMethods()).invokable(matcher, new AsmVisitorWrapper.ForDeclaredMethods.MethodVisitorWrapper[] { this });
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public MethodVisitor wrap(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, TypePool typePool, int writerFlags, int readerFlags) {
/*   545 */     return (instrumentedMethod.isAbstract() || instrumentedMethod.isNative()) ? methodVisitor : 
/*       */       
/*   547 */       doWrap(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, writerFlags, readerFlags);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected MethodVisitor doWrap(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, int writerFlags, int readerFlags) {
/*       */     LineNumberPrependingMethodVisitor lineNumberPrependingMethodVisitor;
/*   567 */     if (this.methodEnter.isPrependLineNumber()) {
/*   568 */       lineNumberPrependingMethodVisitor = new LineNumberPrependingMethodVisitor(methodVisitor);
/*       */     }
/*   570 */     if (!this.methodExit.isAlive()) {
/*   571 */       return (MethodVisitor)new AdviceVisitor.WithoutExitAdvice((MethodVisitor)lineNumberPrependingMethodVisitor, implementationContext, this.assigner, this.exceptionHandler
/*       */ 
/*       */           
/*   574 */           .resolve(instrumentedMethod, instrumentedType), instrumentedType, instrumentedMethod, this.methodEnter, writerFlags, readerFlags);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*   580 */     if (this.methodExit.getThrowable().represents(NoExceptionHandler.class)) {
/*   581 */       return (MethodVisitor)new AdviceVisitor.WithExitAdvice.WithoutExceptionHandling((MethodVisitor)lineNumberPrependingMethodVisitor, implementationContext, this.assigner, this.exceptionHandler
/*       */ 
/*       */           
/*   584 */           .resolve(instrumentedMethod, instrumentedType), instrumentedType, instrumentedMethod, this.methodEnter, this.methodExit, writerFlags, readerFlags);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*   591 */     if (instrumentedMethod.isConstructor()) {
/*   592 */       throw new IllegalStateException("Cannot catch exception during constructor call for " + instrumentedMethod);
/*       */     }
/*   594 */     return (MethodVisitor)new AdviceVisitor.WithExitAdvice.WithExceptionHandling((MethodVisitor)lineNumberPrependingMethodVisitor, implementationContext, this.assigner, this.exceptionHandler
/*       */ 
/*       */         
/*   597 */         .resolve(instrumentedMethod, instrumentedType), instrumentedType, instrumentedMethod, this.methodEnter, this.methodExit, writerFlags, readerFlags, this.methodExit
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*   604 */         .getThrowable());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public InstrumentedType prepare(InstrumentedType instrumentedType) {
/*   612 */     return this.delegate.prepare(instrumentedType);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ByteCodeAppender appender(Implementation.Target implementationTarget) {
/*   619 */     return new Appender(this, implementationTarget, this.delegate.appender(implementationTarget));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Advice withAssigner(Assigner assigner) {
/*   629 */     return new Advice(this.methodEnter, this.methodExit, assigner, this.exceptionHandler, this.delegate);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Advice withExceptionPrinting() {
/*   638 */     return withExceptionHandler(ExceptionHandler.Default.PRINTING);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Advice withExceptionHandler(StackManipulation exceptionHandler) {
/*   649 */     return withExceptionHandler(new ExceptionHandler.Simple(exceptionHandler));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Advice withExceptionHandler(ExceptionHandler exceptionHandler) {
/*   660 */     return new Advice(this.methodEnter, this.methodExit, this.assigner, exceptionHandler, this.delegate);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Implementation wrap(Implementation implementation) {
/*   670 */     return new Advice(this.methodEnter, this.methodExit, this.assigner, this.exceptionHandler, implementation);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean equals(@MaybeNull Object paramObject) {
/*       */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.methodEnter.equals(((Advice)paramObject).methodEnter) ? false : (!this.methodExit.equals(((Advice)paramObject).methodExit) ? false : (!this.assigner.equals(((Advice)paramObject).assigner) ? false : (!this.exceptionHandler.equals(((Advice)paramObject).exceptionHandler) ? false : (!!this.delegate.equals(((Advice)paramObject).delegate))))))));
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int hashCode() {
/*       */     return ((((getClass().hashCode() * 31 + this.methodEnter.hashCode()) * 31 + this.methodExit.hashCode()) * 31 + this.assigner.hashCode()) * 31 + this.exceptionHandler.hashCode()) * 31 + this.delegate.hashCode();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface Factory<T extends Annotation>
/*       */   {
/*       */     Class<T> getAnnotationType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     Advice.OffsetMapping make(ParameterDescription.InDefinedShape param1InDefinedShape, AnnotationDescription.Loadable<T> param1Loadable, AdviceType param1AdviceType);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum AdviceType
/*       */     {
/*  1440 */       DELEGATION(true),
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1445 */       INLINING(false);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final boolean delegation;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       AdviceType(boolean delegation) {
/*  1458 */         this.delegation = delegation;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isDelegation() {
/*  1467 */         return this.delegation;
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class Simple<T extends Annotation>
/*       */       implements Factory<T>
/*       */     {
/*       */       private final Class<T> annotationType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final Advice.OffsetMapping offsetMapping;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Simple(Class<T> annotationType, Advice.OffsetMapping offsetMapping) {
/*  1496 */         this.annotationType = annotationType;
/*  1497 */         this.offsetMapping = offsetMapping;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Class<T> getAnnotationType() {
/*  1504 */         return this.annotationType;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  1511 */         return this.offsetMapping;
/*       */       }
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param3Object) {
/*       */         return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.annotationType.equals(((Simple)param3Object).annotationType) ? false : (!!this.offsetMapping.equals(((Simple)param3Object).offsetMapping)))));
/*       */       }
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return (getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.offsetMapping.hashCode();
/*       */       }
/*       */     }
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class Illegal<T extends Annotation>
/*       */       implements Factory<T>
/*       */     {
/*       */       private final Class<T> annotationType;
/*       */ 
/*       */       
/*       */       public Illegal(Class<T> annotationType) {
/*  1534 */         this.annotationType = annotationType;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Class<T> getAnnotationType() {
/*  1541 */         return this.annotationType;
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType)
/*       */       {
/*  1548 */         throw new IllegalStateException("Usage of " + this.annotationType + " is not allowed on " + target); } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.annotationType.equals(((Illegal)param3Object).annotationType)))); } public int hashCode() { return getClass().hashCode() * 31 + this.annotationType.hashCode(); } } } public static interface OffsetMapping { Target resolve(TypeDescription param1TypeDescription, MethodDescription param1MethodDescription, Assigner param1Assigner, Advice.ArgumentHandler param1ArgumentHandler, Sort param1Sort); public static interface Target { StackManipulation resolveRead(); StackManipulation resolveWrite(); StackManipulation resolveIncrement(int param2Int); public static abstract class AbstractReadOnlyAdapter implements Target { public StackManipulation resolveWrite() { throw new IllegalStateException("Cannot write to read-only value"); } public StackManipulation resolveIncrement(int value) { throw new IllegalStateException("Cannot write to read-only value"); } } @Enhance public static abstract class ForDefaultValue implements Target { protected final TypeDefinition typeDefinition; protected final StackManipulation readAssignment; protected ForDefaultValue(TypeDefinition typeDefinition, StackManipulation readAssignment) { this.typeDefinition = typeDefinition; this.readAssignment = readAssignment; } public StackManipulation resolveRead() { return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { DefaultValue.of(this.typeDefinition), this.readAssignment }); } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.typeDefinition.equals(((ForDefaultValue)param3Object).typeDefinition) ? false : (!!this.readAssignment.equals(((ForDefaultValue)param3Object).readAssignment))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.typeDefinition.hashCode()) * 31 + this.readAssignment.hashCode(); } public static class ReadOnly extends ForDefaultValue { public ReadOnly(TypeDefinition typeDefinition) { this(typeDefinition, (StackManipulation)StackManipulation.Trivial.INSTANCE); } public ReadOnly(TypeDefinition typeDefinition, StackManipulation readAssignment) { super(typeDefinition, readAssignment); } public StackManipulation resolveWrite() { throw new IllegalStateException("Cannot write to read-only default value"); } public StackManipulation resolveIncrement(int value) { throw new IllegalStateException("Cannot write to read-only default value"); } } public static class ReadWrite extends ForDefaultValue { public ReadWrite(TypeDefinition typeDefinition) { this(typeDefinition, (StackManipulation)StackManipulation.Trivial.INSTANCE); } public ReadWrite(TypeDefinition typeDefinition, StackManipulation readAssignment) { super(typeDefinition, readAssignment); } public StackManipulation resolveWrite() { return Removal.of(this.typeDefinition); } public StackManipulation resolveIncrement(int value) { return (StackManipulation)StackManipulation.Trivial.INSTANCE; } } } @Enhance public static abstract class ForVariable implements Target { protected final TypeDefinition typeDefinition; protected final int offset; protected final StackManipulation readAssignment; protected ForVariable(TypeDefinition typeDefinition, int offset, StackManipulation readAssignment) { this.typeDefinition = typeDefinition; this.offset = offset; this.readAssignment = readAssignment; } public StackManipulation resolveRead() { return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { MethodVariableAccess.of(this.typeDefinition).loadFrom(this.offset), this.readAssignment }); } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.offset != ((ForVariable)param3Object).offset) ? false : (!this.typeDefinition.equals(((ForVariable)param3Object).typeDefinition) ? false : (!!this.readAssignment.equals(((ForVariable)param3Object).readAssignment)))))); } public int hashCode() { return ((getClass().hashCode() * 31 + this.typeDefinition.hashCode()) * 31 + this.offset) * 31 + this.readAssignment.hashCode(); } public static class ReadOnly extends ForVariable { public ReadOnly(TypeDefinition typeDefinition, int offset) { this(typeDefinition, offset, (StackManipulation)StackManipulation.Trivial.INSTANCE); } public ReadOnly(TypeDefinition typeDefinition, int offset, StackManipulation readAssignment) { super(typeDefinition, offset, readAssignment); } public StackManipulation resolveWrite() { throw new IllegalStateException("Cannot write to read-only parameter " + this.typeDefinition + " at " + this.offset); } public StackManipulation resolveIncrement(int value) { throw new IllegalStateException("Cannot write to read-only variable " + this.typeDefinition + " at " + this.offset); } } @Enhance public static class ReadWrite extends ForVariable { private final StackManipulation writeAssignment; public ReadWrite(TypeDefinition typeDefinition, int offset) { this(typeDefinition, offset, (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)StackManipulation.Trivial.INSTANCE); } public ReadWrite(TypeDefinition typeDefinition, int offset, StackManipulation readAssignment, StackManipulation writeAssignment) { super(typeDefinition, offset, readAssignment); this.writeAssignment = writeAssignment; } public StackManipulation resolveWrite() { return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { this.writeAssignment, MethodVariableAccess.of(this.typeDefinition).storeAt(this.offset) }); } public StackManipulation resolveIncrement(int value) { return this.typeDefinition.represents(int.class) ? MethodVariableAccess.of(this.typeDefinition).increment(this.offset, value) : (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { resolveRead(), IntegerConstant.forValue(1), (StackManipulation)Addition.INTEGER, resolveWrite() }); } public boolean equals(@MaybeNull Object param4Object) { return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.writeAssignment.equals(((ReadWrite)param4Object).writeAssignment))))); } public int hashCode() { return super.hashCode() * 31 + this.writeAssignment.hashCode(); } } } @Enhance public static abstract class ForArray implements Target { protected final TypeDescription.Generic target; protected final List<? extends StackManipulation> valueReads; protected ForArray(TypeDescription.Generic target, List<? extends StackManipulation> valueReads) { this.target = target; this.valueReads = valueReads; } public StackManipulation resolveRead() { return ArrayFactory.forType(this.target).withValues(this.valueReads); } public StackManipulation resolveIncrement(int value) { throw new IllegalStateException("Cannot increment read-only array value"); } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.target.equals(((ForArray)param3Object).target) ? false : (!!this.valueReads.equals(((ForArray)param3Object).valueReads))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.target.hashCode()) * 31 + this.valueReads.hashCode(); } public static class ReadOnly extends ForArray { public ReadOnly(TypeDescription.Generic target, List<? extends StackManipulation> valueReads) { super(target, valueReads); } public StackManipulation resolveWrite() { throw new IllegalStateException("Cannot write to read-only array value"); } } @Enhance public static class ReadWrite extends ForArray { private final List<? extends StackManipulation> valueWrites; public ReadWrite(TypeDescription.Generic target, List<? extends StackManipulation> valueReads, List<? extends StackManipulation> valueWrites) { super(target, valueReads); this.valueWrites = valueWrites; } public StackManipulation resolveWrite() { return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { ArrayAccess.of((TypeDefinition)this.target).forEach(this.valueWrites), (StackManipulation)Removal.SINGLE }); } public boolean equals(@MaybeNull Object param4Object) { return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.valueWrites.equals(((ReadWrite)param4Object).valueWrites))))); } public int hashCode() { return super.hashCode() * 31 + this.valueWrites.hashCode(); } } } @Enhance public static abstract class ForField implements Target { protected final FieldDescription fieldDescription; protected final StackManipulation readAssignment; protected ForField(FieldDescription fieldDescription, StackManipulation readAssignment) { this.fieldDescription = fieldDescription; this.readAssignment = readAssignment; } public StackManipulation resolveRead() { return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { this.fieldDescription.isStatic() ? (StackManipulation)StackManipulation.Trivial.INSTANCE : MethodVariableAccess.loadThis(), FieldAccess.forField(this.fieldDescription).read(), this.readAssignment }); } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.fieldDescription.equals(((ForField)param3Object).fieldDescription) ? false : (!!this.readAssignment.equals(((ForField)param3Object).readAssignment))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.fieldDescription.hashCode()) * 31 + this.readAssignment.hashCode(); } public static class ReadOnly extends ForField { public ReadOnly(FieldDescription fieldDescription) { this(fieldDescription, (StackManipulation)StackManipulation.Trivial.INSTANCE); } public ReadOnly(FieldDescription fieldDescription, StackManipulation readAssignment) { super(fieldDescription, readAssignment); } public StackManipulation resolveWrite() { throw new IllegalStateException("Cannot write to read-only field value"); } public StackManipulation resolveIncrement(int value) { throw new IllegalStateException("Cannot write to read-only field value"); } } @Enhance public static class WriteOnly implements Advice.OffsetMapping.Target { private final FieldDescription fieldDescription; private final StackManipulation writeAssignment; protected WriteOnly(FieldDescription fieldDescription, StackManipulation writeAssignment) { this.fieldDescription = fieldDescription; this.writeAssignment = writeAssignment; } public StackManipulation resolveRead() { throw new IllegalStateException("Cannot read write-only field value"); } public StackManipulation resolveWrite() { StackManipulation.Compound compound; if (this.fieldDescription.isStatic()) { StackManipulation.Trivial trivial = StackManipulation.Trivial.INSTANCE; } else { compound = new StackManipulation.Compound(new StackManipulation[] { MethodVariableAccess.loadThis(), Duplication.SINGLE.flipOver((TypeDefinition)this.fieldDescription.getType()), (StackManipulation)Removal.SINGLE }); }  return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { this.writeAssignment, (StackManipulation)compound, FieldAccess.forField(this.fieldDescription).write() }); } public StackManipulation resolveIncrement(int value) { throw new IllegalStateException("Cannot increment write-only field value"); } public boolean equals(@MaybeNull Object param4Object) { return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.fieldDescription.equals(((WriteOnly)param4Object).fieldDescription) ? false : (!!this.writeAssignment.equals(((WriteOnly)param4Object).writeAssignment))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.fieldDescription.hashCode()) * 31 + this.writeAssignment.hashCode(); } } @Enhance public static class ReadWrite extends ForField { private final StackManipulation writeAssignment; public ReadWrite(FieldDescription fieldDescription) { this(fieldDescription, (StackManipulation)StackManipulation.Trivial.INSTANCE, (StackManipulation)StackManipulation.Trivial.INSTANCE); } public ReadWrite(FieldDescription fieldDescription, StackManipulation readAssignment, StackManipulation writeAssignment) { super(fieldDescription, readAssignment); this.writeAssignment = writeAssignment; } public StackManipulation resolveWrite() { StackManipulation.Compound compound; if (this.fieldDescription.isStatic()) { StackManipulation.Trivial trivial = StackManipulation.Trivial.INSTANCE; } else { compound = new StackManipulation.Compound(new StackManipulation[] { MethodVariableAccess.loadThis(), Duplication.SINGLE.flipOver((TypeDefinition)this.fieldDescription.getType()), (StackManipulation)Removal.SINGLE }); }  return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { this.writeAssignment, (StackManipulation)compound, FieldAccess.forField(this.fieldDescription).write() }); } public StackManipulation resolveIncrement(int value) { return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { resolveRead(), IntegerConstant.forValue(value), (StackManipulation)Addition.INTEGER, resolveWrite() }); } public boolean equals(@MaybeNull Object param4Object) { return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.writeAssignment.equals(((ReadWrite)param4Object).writeAssignment))))); } public int hashCode() { return super.hashCode() * 31 + this.writeAssignment.hashCode(); } } } @Enhance public static class ForStackManipulation implements Target { private final StackManipulation stackManipulation; public ForStackManipulation(StackManipulation stackManipulation) { this.stackManipulation = stackManipulation; } public static Advice.OffsetMapping.Target of(MethodDescription.InDefinedShape methodDescription) { return new ForStackManipulation((StackManipulation)MethodConstant.of(methodDescription)); } public static Advice.OffsetMapping.Target of(TypeDescription typeDescription) { return new ForStackManipulation(ClassConstant.of(typeDescription)); } public static Advice.OffsetMapping.Target of(@MaybeNull Object value) { return new ForStackManipulation((value == null) ? (StackManipulation)NullConstant.INSTANCE : ConstantValue.Simple.wrap(value).toStackManipulation()); } public StackManipulation resolveRead() { return this.stackManipulation; } public StackManipulation resolveWrite() { throw new IllegalStateException("Cannot write to constant value: " + this.stackManipulation); } public StackManipulation resolveIncrement(int value) { throw new IllegalStateException("Cannot write to constant value: " + this.stackManipulation); } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.stackManipulation.equals(((ForStackManipulation)param3Object).stackManipulation)))); } public int hashCode() { return getClass().hashCode() * 31 + this.stackManipulation.hashCode(); } @Enhance public static class Writable implements Advice.OffsetMapping.Target { private final StackManipulation read; private final StackManipulation write; public Writable(StackManipulation read, StackManipulation write) { this.read = read; this.write = write; } public StackManipulation resolveRead() { return this.read; } public StackManipulation resolveWrite() { return this.write; } public StackManipulation resolveIncrement(int value) { throw new IllegalStateException("Cannot increment mutable constant value: " + this.write); } public boolean equals(@MaybeNull Object param4Object) { return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.read.equals(((Writable)param4Object).read) ? false : (!!this.write.equals(((Writable)param4Object).write))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.read.hashCode()) * 31 + this.write.hashCode(); } } } } public static interface Factory<T extends Annotation> { Class<T> getAnnotationType(); Advice.OffsetMapping make(ParameterDescription.InDefinedShape param2InDefinedShape, AnnotationDescription.Loadable<T> param2Loadable, AdviceType param2AdviceType); public enum AdviceType { DELEGATION(true), INLINING(false); private final boolean delegation; AdviceType(boolean delegation) { this.delegation = delegation; } public boolean isDelegation() { return this.delegation; } } @Enhance public static class Simple<T extends Annotation> implements Factory<T> { private final Class<T> annotationType; private final Advice.OffsetMapping offsetMapping; public Simple(Class<T> annotationType, Advice.OffsetMapping offsetMapping) { this.annotationType = annotationType; this.offsetMapping = offsetMapping; } public Class<T> getAnnotationType() { return this.annotationType; } public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) { return this.offsetMapping; } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.annotationType.equals(((Simple)param3Object).annotationType) ? false : (!!this.offsetMapping.equals(((Simple)param3Object).offsetMapping))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.offsetMapping.hashCode(); } } @Enhance public static class Illegal<T extends Annotation> implements Factory<T> { private final Class<T> annotationType; public Illegal(Class<T> annotationType) { this.annotationType = annotationType; } public Class<T> getAnnotationType() { return this.annotationType; } public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) { throw new IllegalStateException("Usage of " + this.annotationType + " is not allowed on " + target); }
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.annotationType.equals(((Illegal)param3Object).annotationType))));
/*       */         }
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.annotationType.hashCode();
/*       */         } } }
/*       */ 
/*       */     
/*       */     public enum Sort {
/*  1561 */       ENTER
/*       */       {
/*       */         public boolean isPremature(MethodDescription methodDescription) {
/*  1564 */           return methodDescription.isConstructor();
/*       */         }
/*       */       },
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  1571 */       EXIT
/*       */       {
/*       */         public boolean isPremature(MethodDescription methodDescription) {
/*  1574 */           return false;
/*       */         }
/*       */       };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public abstract boolean isPremature(MethodDescription param2MethodDescription);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static abstract class ForArgument
/*       */       implements OffsetMapping
/*       */     {
/*       */       protected final TypeDescription.Generic target;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final boolean readOnly;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final Assigner.Typing typing;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected ForArgument(TypeDescription.Generic target, boolean readOnly, Assigner.Typing typing) {
/*  1617 */         this.target = target;
/*  1618 */         this.readOnly = readOnly;
/*  1619 */         this.typing = typing;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  1630 */         ParameterDescription parameterDescription = resolve(instrumentedMethod);
/*  1631 */         StackManipulation readAssignment = assigner.assign(parameterDescription.getType(), this.target, this.typing);
/*  1632 */         if (!readAssignment.isValid())
/*  1633 */           throw new IllegalStateException("Cannot assign " + parameterDescription + " to " + this.target); 
/*  1634 */         if (this.readOnly) {
/*  1635 */           return new Advice.OffsetMapping.Target.ForVariable.ReadOnly((TypeDefinition)parameterDescription.getType(), argumentHandler.argument(parameterDescription.getOffset()), readAssignment);
/*       */         }
/*  1637 */         StackManipulation writeAssignment = assigner.assign(this.target, parameterDescription.getType(), this.typing);
/*  1638 */         if (!writeAssignment.isValid()) {
/*  1639 */           throw new IllegalStateException("Cannot assign " + parameterDescription + " to " + this.target);
/*       */         }
/*  1641 */         return new Advice.OffsetMapping.Target.ForVariable.ReadWrite((TypeDefinition)parameterDescription.getType(), argumentHandler.argument(parameterDescription.getOffset()), readAssignment, writeAssignment);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract ParameterDescription resolve(MethodDescription param2MethodDescription);
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.readOnly != ((ForArgument)param2Object).readOnly) ? false : (!this.typing.equals(((ForArgument)param2Object).typing) ? false : (!!this.target.equals(((ForArgument)param2Object).target))))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return ((getClass().hashCode() * 31 + this.target.hashCode()) * 31 + this.readOnly) * 31 + this.typing.hashCode();
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Unresolved
/*       */         extends ForArgument
/*       */       {
/*       */         private final int index;
/*       */ 
/*       */         
/*       */         private final boolean optional;
/*       */ 
/*       */ 
/*       */         
/*       */         protected Unresolved(TypeDescription.Generic target, AnnotationDescription.Loadable<Advice.Argument> annotation) {
/*  1677 */           this(target, ((Boolean)annotation.getValue(Factory.access$100()).resolve(Boolean.class)).booleanValue(), (Assigner.Typing)((EnumerationDescription)annotation
/*  1678 */               .getValue(Factory.access$200()).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), ((Integer)annotation
/*  1679 */               .getValue(Factory.access$300()).resolve(Integer.class)).intValue(), ((Boolean)annotation
/*  1680 */               .getValue(Factory.access$400()).resolve(Boolean.class)).booleanValue());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Unresolved(ParameterDescription parameterDescription) {
/*  1689 */           this(parameterDescription.getType(), true, Assigner.Typing.STATIC, parameterDescription.getIndex());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Unresolved(TypeDescription.Generic target, boolean readOnly, Assigner.Typing typing, int index) {
/*  1701 */           this(target, readOnly, typing, index, false);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Unresolved(TypeDescription.Generic target, boolean readOnly, Assigner.Typing typing, int index, boolean optional) {
/*  1714 */           super(target, readOnly, typing);
/*  1715 */           this.index = index;
/*  1716 */           this.optional = optional;
/*       */         }
/*       */ 
/*       */         
/*       */         protected ParameterDescription resolve(MethodDescription instrumentedMethod) {
/*  1721 */           ParameterList<?> parameters = instrumentedMethod.getParameters();
/*  1722 */           if (parameters.size() <= this.index) {
/*  1723 */             throw new IllegalStateException(instrumentedMethod + " does not define an index " + this.index);
/*       */           }
/*  1725 */           return (ParameterDescription)parameters.get(this.index);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  1737 */           if (this.optional && instrumentedMethod.getParameters().size() <= this.index) {
/*  1738 */             return this.readOnly ? new Advice.OffsetMapping.Target.ForDefaultValue.ReadOnly((TypeDefinition)this.target) : new Advice.OffsetMapping.Target.ForDefaultValue.ReadWrite((TypeDefinition)this.target);
/*       */           }
/*       */ 
/*       */           
/*  1742 */           return super.resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, sort);
/*       */         }
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.index != ((Unresolved)param3Object).index) ? false : (!(this.optional != ((Unresolved)param3Object).optional))))));
/*       */         }
/*       */         
/*       */         public int hashCode() {
/*       */           return (super.hashCode() * 31 + this.index) * 31 + this.optional;
/*       */         }
/*       */         
/*  1753 */         protected enum Factory implements Advice.OffsetMapping.Factory<Advice.Argument> { INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape ARGUMENT_OPTIONAL;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape ARGUMENT_TYPING;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape ARGUMENT_READ_ONLY;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape ARGUMENT_VALUE;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           static {
/*  1779 */             MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.Argument.class).getDeclaredMethods();
/*  1780 */             ARGUMENT_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly();
/*  1781 */             ARGUMENT_READ_ONLY = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("readOnly"))).getOnly();
/*  1782 */             ARGUMENT_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*  1783 */             ARGUMENT_OPTIONAL = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("optional"))).getOnly();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Class<Advice.Argument> getAnnotationType() {
/*  1790 */             return Advice.Argument.class;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.Argument> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  1799 */             if (adviceType.isDelegation() && !((Boolean)annotation.getValue(ARGUMENT_READ_ONLY).resolve(Boolean.class)).booleanValue()) {
/*  1800 */               throw new IllegalStateException("Cannot define writable field access for " + target + " when using delegation");
/*       */             }
/*  1802 */             return new Advice.OffsetMapping.ForArgument.Unresolved(target.getType(), annotation);
/*       */           } }
/*       */       
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Resolved
/*       */         extends ForArgument
/*       */       {
/*       */         private final ParameterDescription parameterDescription;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Resolved(TypeDescription.Generic target, boolean readOnly, Assigner.Typing typing, ParameterDescription parameterDescription) {
/*  1828 */           super(target, readOnly, typing);
/*  1829 */           this.parameterDescription = parameterDescription;
/*       */         }
/*       */ 
/*       */         
/*       */         protected ParameterDescription resolve(MethodDescription instrumentedMethod) {
/*  1834 */           if (!this.parameterDescription.getDeclaringMethod().equals(instrumentedMethod)) {
/*  1835 */             throw new IllegalStateException(this.parameterDescription + " is not a parameter of " + instrumentedMethod);
/*       */           }
/*  1837 */           return this.parameterDescription;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.parameterDescription.equals(((Resolved)param3Object).parameterDescription)))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return super.hashCode() * 31 + this.parameterDescription.hashCode();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class Factory<T extends Annotation>
/*       */           implements Advice.OffsetMapping.Factory<T>
/*       */         {
/*       */           private final Class<T> annotationType;
/*       */ 
/*       */           
/*       */           private final ParameterDescription parameterDescription;
/*       */ 
/*       */           
/*       */           private final boolean readOnly;
/*       */ 
/*       */           
/*       */           private final Assigner.Typing typing;
/*       */ 
/*       */ 
/*       */           
/*       */           public Factory(Class<T> annotationType, ParameterDescription parameterDescription) {
/*  1875 */             this(annotationType, parameterDescription, true, Assigner.Typing.STATIC);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Factory(Class<T> annotationType, ParameterDescription parameterDescription, boolean readOnly, Assigner.Typing typing) {
/*  1887 */             this.annotationType = annotationType;
/*  1888 */             this.parameterDescription = parameterDescription;
/*  1889 */             this.readOnly = readOnly;
/*  1890 */             this.typing = typing;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Class<T> getAnnotationType() {
/*  1897 */             return this.annotationType;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  1906 */             return new Advice.OffsetMapping.ForArgument.Resolved(target.getType(), this.readOnly, this.typing, this.parameterDescription);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : ((this.readOnly != ((Factory)param4Object).readOnly) ? false : (!this.typing.equals(((Factory)param4Object).typing) ? false : (!this.annotationType.equals(((Factory)param4Object).annotationType) ? false : (!!this.parameterDescription.equals(((Factory)param4Object).parameterDescription)))))));
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return (((getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.parameterDescription.hashCode()) * 31 + this.readOnly) * 31 + this.typing.hashCode();
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForThisReference
/*       */       implements OffsetMapping
/*       */     {
/*       */       private final TypeDescription.Generic target;
/*       */ 
/*       */       
/*       */       private final boolean readOnly;
/*       */ 
/*       */       
/*       */       private final Assigner.Typing typing;
/*       */ 
/*       */       
/*       */       private final boolean optional;
/*       */ 
/*       */ 
/*       */       
/*       */       protected ForThisReference(TypeDescription.Generic target, AnnotationDescription.Loadable<Advice.This> annotation) {
/*  1945 */         this(target, ((Boolean)annotation
/*  1946 */             .getValue(Factory.access$500()).resolve(Boolean.class)).booleanValue(), (Assigner.Typing)((EnumerationDescription)annotation
/*  1947 */             .getValue(Factory.access$600()).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), ((Boolean)annotation
/*  1948 */             .getValue(Factory.access$700()).resolve(Boolean.class)).booleanValue());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForThisReference(TypeDescription.Generic target, boolean readOnly, Assigner.Typing typing, boolean optional) {
/*  1960 */         this.target = target;
/*  1961 */         this.readOnly = readOnly;
/*  1962 */         this.typing = typing;
/*  1963 */         this.optional = optional;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  1974 */         if (instrumentedMethod.isStatic() || sort.isPremature(instrumentedMethod)) {
/*  1975 */           if (this.optional) {
/*  1976 */             return this.readOnly ? new Advice.OffsetMapping.Target.ForDefaultValue.ReadOnly((TypeDefinition)instrumentedType) : new Advice.OffsetMapping.Target.ForDefaultValue.ReadWrite((TypeDefinition)instrumentedType);
/*       */           }
/*       */ 
/*       */           
/*  1980 */           throw new IllegalStateException("Cannot map this reference for static method or constructor start: " + instrumentedMethod);
/*       */         } 
/*       */         
/*  1983 */         StackManipulation readAssignment = assigner.assign(instrumentedType.asGenericType(), this.target, this.typing);
/*  1984 */         if (!readAssignment.isValid())
/*  1985 */           throw new IllegalStateException("Cannot assign " + instrumentedType + " to " + this.target); 
/*  1986 */         if (this.readOnly) {
/*  1987 */           return new Advice.OffsetMapping.Target.ForVariable.ReadOnly((TypeDefinition)instrumentedType.asGenericType(), argumentHandler.argument(0), readAssignment);
/*       */         }
/*  1989 */         StackManipulation writeAssignment = assigner.assign(this.target, instrumentedType.asGenericType(), this.typing);
/*  1990 */         if (!writeAssignment.isValid()) {
/*  1991 */           throw new IllegalStateException("Cannot assign " + this.target + " to " + instrumentedType);
/*       */         }
/*  1993 */         return new Advice.OffsetMapping.Target.ForVariable.ReadWrite((TypeDefinition)instrumentedType.asGenericType(), argumentHandler.argument(0), readAssignment, writeAssignment);
/*       */       }
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.readOnly != ((ForThisReference)param2Object).readOnly) ? false : ((this.optional != ((ForThisReference)param2Object).optional) ? false : (!this.typing.equals(((ForThisReference)param2Object).typing) ? false : (!!this.target.equals(((ForThisReference)param2Object).target)))))));
/*       */       }
/*       */       
/*       */       public int hashCode() {
/*       */         return (((getClass().hashCode() * 31 + this.target.hashCode()) * 31 + this.readOnly) * 31 + this.typing.hashCode()) * 31 + this.optional;
/*       */       }
/*       */       
/*       */       protected enum Factory
/*       */         implements Advice.OffsetMapping.Factory<Advice.This> {
/*  2006 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape THIS_OPTIONAL;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape THIS_TYPING;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape THIS_READ_ONLY;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         static {
/*  2027 */           MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.This.class).getDeclaredMethods();
/*  2028 */           THIS_READ_ONLY = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("readOnly"))).getOnly();
/*  2029 */           THIS_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*  2030 */           THIS_OPTIONAL = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("optional"))).getOnly();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Class<Advice.This> getAnnotationType() {
/*  2037 */           return Advice.This.class;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.This> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  2046 */           if (adviceType.isDelegation() && !((Boolean)annotation.getValue(THIS_READ_ONLY).resolve(Boolean.class)).booleanValue()) {
/*  2047 */             throw new IllegalStateException("Cannot write to this reference for " + target + " in read-only context");
/*       */           }
/*  2049 */           return new Advice.OffsetMapping.ForThisReference(target.getType(), annotation);
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForAllArguments
/*       */       implements OffsetMapping
/*       */     {
/*       */       private final TypeDescription.Generic target;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final boolean readOnly;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final Assigner.Typing typing;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final boolean includeSelf;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final boolean nullIfEmpty;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected ForAllArguments(TypeDescription.Generic target, AnnotationDescription.Loadable<Advice.AllArguments> annotation) {
/*  2094 */         this(target, ((Boolean)annotation.getValue(Factory.access$800()).resolve(Boolean.class)).booleanValue(), (Assigner.Typing)((EnumerationDescription)annotation
/*  2095 */             .getValue(Factory.access$900()).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), ((Boolean)annotation
/*  2096 */             .getValue(Factory.access$1000()).resolve(Boolean.class)).booleanValue(), ((Boolean)annotation
/*  2097 */             .getValue(Factory.access$1100()).resolve(Boolean.class)).booleanValue());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForAllArguments(TypeDescription.Generic target, boolean readOnly, Assigner.Typing typing, boolean includeSelf, boolean nullIfEmpty) {
/*  2112 */         this.target = target;
/*  2113 */         this.readOnly = readOnly;
/*  2114 */         this.typing = typing;
/*  2115 */         this.includeSelf = includeSelf;
/*  2116 */         this.nullIfEmpty = nullIfEmpty;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  2127 */         if (this.nullIfEmpty && instrumentedMethod.getParameters().isEmpty() && (!this.includeSelf || instrumentedMethod.isStatic())) {
/*  2128 */           return this.readOnly ? new Advice.OffsetMapping.Target.ForStackManipulation((StackManipulation)NullConstant.INSTANCE) : new Advice.OffsetMapping.Target.ForStackManipulation.Writable((StackManipulation)NullConstant.INSTANCE, (StackManipulation)Removal.SINGLE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  2134 */         List<StackManipulation> reads = new ArrayList<StackManipulation>(((this.includeSelf && !instrumentedMethod.isStatic()) ? 1 : 0) + instrumentedMethod.getParameters().size());
/*  2135 */         if (this.includeSelf && !instrumentedMethod.isStatic()) {
/*  2136 */           if (sort.isPremature(instrumentedMethod) && instrumentedMethod.isConstructor()) {
/*  2137 */             throw new IllegalStateException("Cannot include self in all arguments array from " + instrumentedMethod);
/*       */           }
/*  2139 */           StackManipulation assignment = assigner.assign(instrumentedMethod.getDeclaringType().asGenericType(), this.target, this.typing);
/*  2140 */           if (!assignment.isValid()) {
/*  2141 */             throw new IllegalStateException("Cannot assign " + instrumentedMethod.getDeclaringType() + " to " + this.target);
/*       */           }
/*  2143 */           reads.add(new StackManipulation.Compound(new StackManipulation[] { MethodVariableAccess.REFERENCE
/*  2144 */                   .loadFrom(argumentHandler.argument(0)), assignment }));
/*       */         } 
/*       */         
/*  2147 */         for (ParameterDescription parameterDescription : instrumentedMethod.getParameters()) {
/*  2148 */           StackManipulation assignment = assigner.assign(parameterDescription.getType(), this.target, this.typing);
/*  2149 */           if (!assignment.isValid()) {
/*  2150 */             throw new IllegalStateException("Cannot assign " + parameterDescription + " to " + this.target);
/*       */           }
/*  2152 */           reads.add(new StackManipulation.Compound(new StackManipulation[] {
/*  2153 */                   MethodVariableAccess.of((TypeDefinition)parameterDescription.getType()).loadFrom(argumentHandler.argument(parameterDescription.getOffset())), assignment
/*       */                 }));
/*       */         } 
/*  2156 */         if (this.readOnly) {
/*  2157 */           return new Advice.OffsetMapping.Target.ForArray.ReadOnly(this.target, reads);
/*       */         }
/*       */ 
/*       */         
/*  2161 */         List<StackManipulation> writes = new ArrayList<StackManipulation>(2 * (((this.includeSelf && !instrumentedMethod.isStatic()) ? 1 : 0) + instrumentedMethod.getParameters().size()));
/*  2162 */         if (this.includeSelf && !instrumentedMethod.isStatic()) {
/*  2163 */           StackManipulation assignment = assigner.assign(this.target, instrumentedMethod.getDeclaringType().asGenericType(), this.typing);
/*  2164 */           if (!assignment.isValid()) {
/*  2165 */             throw new IllegalStateException("Cannot assign " + this.target + " to " + instrumentedMethod.getDeclaringType());
/*       */           }
/*  2167 */           writes.add(new StackManipulation.Compound(new StackManipulation[] { assignment, MethodVariableAccess.REFERENCE
/*       */                   
/*  2169 */                   .storeAt(argumentHandler.argument(0)) }));
/*       */         } 
/*  2171 */         for (ParameterDescription parameterDescription : instrumentedMethod.getParameters()) {
/*  2172 */           StackManipulation assignment = assigner.assign(this.target, parameterDescription.getType(), this.typing);
/*  2173 */           if (!assignment.isValid()) {
/*  2174 */             throw new IllegalStateException("Cannot assign " + this.target + " to " + parameterDescription);
/*       */           }
/*  2176 */           writes.add(new StackManipulation.Compound(new StackManipulation[] { assignment, 
/*       */                   
/*  2178 */                   MethodVariableAccess.of((TypeDefinition)parameterDescription.getType()).storeAt(argumentHandler.argument(parameterDescription.getOffset())) }));
/*       */         } 
/*  2180 */         return new Advice.OffsetMapping.Target.ForArray.ReadWrite(this.target, reads, writes);
/*       */       }
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.readOnly != ((ForAllArguments)param2Object).readOnly) ? false : ((this.includeSelf != ((ForAllArguments)param2Object).includeSelf) ? false : ((this.nullIfEmpty != ((ForAllArguments)param2Object).nullIfEmpty) ? false : (!this.typing.equals(((ForAllArguments)param2Object).typing) ? false : (!!this.target.equals(((ForAllArguments)param2Object).target))))))));
/*       */       }
/*       */       
/*       */       public int hashCode() {
/*       */         return ((((getClass().hashCode() * 31 + this.target.hashCode()) * 31 + this.readOnly) * 31 + this.typing.hashCode()) * 31 + this.includeSelf) * 31 + this.nullIfEmpty;
/*       */       }
/*       */       
/*       */       protected enum Factory implements Advice.OffsetMapping.Factory<Advice.AllArguments> {
/*  2192 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape ALL_ARGUMENTS_NULL_IF_EMPTY;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape ALL_ARGUMENTS_INCLUDE_SELF;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape ALL_ARGUMENTS_TYPING;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape ALL_ARGUMENTS_READ_ONLY;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         static {
/*  2218 */           MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.AllArguments.class).getDeclaredMethods();
/*  2219 */           ALL_ARGUMENTS_READ_ONLY = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("readOnly"))).getOnly();
/*  2220 */           ALL_ARGUMENTS_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*  2221 */           ALL_ARGUMENTS_INCLUDE_SELF = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("includeSelf"))).getOnly();
/*  2222 */           ALL_ARGUMENTS_NULL_IF_EMPTY = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("nullIfEmpty"))).getOnly();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Class<Advice.AllArguments> getAnnotationType() {
/*  2229 */           return Advice.AllArguments.class;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.AllArguments> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  2239 */           if (!target.getType().represents(Object.class) && !target.getType().isArray())
/*  2240 */             throw new IllegalStateException("Cannot use AllArguments annotation on a non-array type"); 
/*  2241 */           if (adviceType.isDelegation() && !((Boolean)annotation.getValue(ALL_ARGUMENTS_READ_ONLY).resolve(Boolean.class)).booleanValue()) {
/*  2242 */             throw new IllegalStateException("Cannot define writable field access for " + target);
/*       */           }
/*  2244 */           return new Advice.OffsetMapping.ForAllArguments(target.getType().represents(Object.class) ? 
/*  2245 */               TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class) : target
/*  2246 */               .getType().getComponentType(), annotation);
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum ForInstrumentedType
/*       */       implements OffsetMapping
/*       */     {
/*  2260 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  2270 */         return Advice.OffsetMapping.Target.ForStackManipulation.of(instrumentedType);
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum ForInstrumentedMethod
/*       */       implements OffsetMapping
/*       */     {
/*  2282 */       METHOD
/*       */       {
/*       */         protected boolean isRepresentable(MethodDescription instrumentedMethod) {
/*  2285 */           return instrumentedMethod.isMethod();
/*       */         }
/*       */ 
/*       */         
/*       */         protected Advice.OffsetMapping.Target resolve(MethodDescription.InDefinedShape methodDescription) {
/*  2290 */           return Advice.OffsetMapping.Target.ForStackManipulation.of(methodDescription);
/*       */         }
/*       */       },
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2297 */       CONSTRUCTOR
/*       */       {
/*       */         protected boolean isRepresentable(MethodDescription instrumentedMethod) {
/*  2300 */           return instrumentedMethod.isConstructor();
/*       */         }
/*       */ 
/*       */         
/*       */         protected Advice.OffsetMapping.Target resolve(MethodDescription.InDefinedShape methodDescription) {
/*  2305 */           return Advice.OffsetMapping.Target.ForStackManipulation.of(methodDescription);
/*       */         }
/*       */       },
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2312 */       EXECUTABLE
/*       */       {
/*       */         protected boolean isRepresentable(MethodDescription instrumentedMethod) {
/*  2315 */           return true;
/*       */         }
/*       */ 
/*       */         
/*       */         protected Advice.OffsetMapping.Target resolve(MethodDescription.InDefinedShape methodDescription) {
/*  2320 */           return Advice.OffsetMapping.Target.ForStackManipulation.of(methodDescription);
/*       */         }
/*       */       },
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2328 */       METHOD_HANDLE
/*       */       {
/*       */         protected boolean isRepresentable(MethodDescription instrumentedMethod) {
/*  2331 */           return true;
/*       */         }
/*       */ 
/*       */         
/*       */         protected Advice.OffsetMapping.Target resolve(MethodDescription.InDefinedShape methodDescription) {
/*  2336 */           return new Advice.OffsetMapping.Target.ForStackManipulation(JavaConstant.MethodHandle.of(methodDescription).toStackManipulation());
/*       */         }
/*       */       },
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2343 */       METHOD_TYPE
/*       */       {
/*       */         protected boolean isRepresentable(MethodDescription instrumentedMethod) {
/*  2346 */           return true;
/*       */         }
/*       */ 
/*       */         
/*       */         protected Advice.OffsetMapping.Target resolve(MethodDescription.InDefinedShape methodDescription) {
/*  2351 */           return new Advice.OffsetMapping.Target.ForStackManipulation(JavaConstant.MethodType.of((MethodDescription)methodDescription).toStackManipulation());
/*       */         }
/*       */       };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  2363 */         if (!isRepresentable(instrumentedMethod)) {
/*  2364 */           throw new IllegalStateException("Cannot represent " + instrumentedMethod + " as the specified constant");
/*       */         }
/*  2366 */         return resolve((MethodDescription.InDefinedShape)instrumentedMethod.asDefined());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract boolean isRepresentable(MethodDescription param2MethodDescription);
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract Advice.OffsetMapping.Target resolve(MethodDescription.InDefinedShape param2InDefinedShape);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static abstract class ForField
/*       */       implements OffsetMapping
/*       */     {
/*       */       private static final MethodDescription.InDefinedShape FIELD_VALUE;
/*       */ 
/*       */ 
/*       */       
/*       */       private static final MethodDescription.InDefinedShape FIELD_DECLARING_TYPE;
/*       */ 
/*       */ 
/*       */       
/*       */       private static final MethodDescription.InDefinedShape FIELD_READ_ONLY;
/*       */ 
/*       */ 
/*       */       
/*       */       private static final MethodDescription.InDefinedShape FIELD_TYPING;
/*       */ 
/*       */ 
/*       */       
/*       */       private final TypeDescription.Generic target;
/*       */ 
/*       */ 
/*       */       
/*       */       private final boolean readOnly;
/*       */ 
/*       */ 
/*       */       
/*       */       private final Assigner.Typing typing;
/*       */ 
/*       */ 
/*       */       
/*       */       static {
/*  2416 */         MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.FieldValue.class).getDeclaredMethods();
/*  2417 */         FIELD_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly();
/*  2418 */         FIELD_DECLARING_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("declaringType"))).getOnly();
/*  2419 */         FIELD_READ_ONLY = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("readOnly"))).getOnly();
/*  2420 */         FIELD_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected ForField(TypeDescription.Generic target, boolean readOnly, Assigner.Typing typing) {
/*  2446 */         this.target = target;
/*  2447 */         this.readOnly = readOnly;
/*  2448 */         this.typing = typing;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  2459 */         FieldDescription fieldDescription = resolve(instrumentedType, instrumentedMethod);
/*  2460 */         if (!fieldDescription.isStatic() && instrumentedMethod.isStatic()) {
/*  2461 */           throw new IllegalStateException("Cannot access non-static field " + fieldDescription + " from static method " + instrumentedMethod);
/*       */         }
/*  2463 */         if (sort.isPremature(instrumentedMethod) && !fieldDescription.isStatic()) {
/*  2464 */           if (this.readOnly) {
/*  2465 */             throw new IllegalStateException("Cannot read " + fieldDescription + " before super constructor call");
/*       */           }
/*  2467 */           StackManipulation stackManipulation = assigner.assign(this.target, fieldDescription.getType(), this.typing);
/*  2468 */           if (!stackManipulation.isValid()) {
/*  2469 */             throw new IllegalStateException("Cannot assign " + this.target + " to " + fieldDescription);
/*       */           }
/*  2471 */           return new Advice.OffsetMapping.Target.ForField.WriteOnly((FieldDescription)fieldDescription.asDefined(), stackManipulation);
/*       */         } 
/*       */         
/*  2474 */         StackManipulation readAssignment = assigner.assign(fieldDescription.getType(), this.target, this.typing);
/*  2475 */         if (!readAssignment.isValid())
/*  2476 */           throw new IllegalStateException("Cannot assign " + fieldDescription + " to " + this.target); 
/*  2477 */         if (this.readOnly) {
/*  2478 */           return new Advice.OffsetMapping.Target.ForField.ReadOnly(fieldDescription, readAssignment);
/*       */         }
/*  2480 */         StackManipulation writeAssignment = assigner.assign(this.target, fieldDescription.getType(), this.typing);
/*  2481 */         if (!writeAssignment.isValid()) {
/*  2482 */           throw new IllegalStateException("Cannot assign " + this.target + " to " + fieldDescription);
/*       */         }
/*  2484 */         return new Advice.OffsetMapping.Target.ForField.ReadWrite((FieldDescription)fieldDescription.asDefined(), readAssignment, writeAssignment);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract FieldDescription resolve(TypeDescription param2TypeDescription, MethodDescription param2MethodDescription);
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.readOnly != ((ForField)param2Object).readOnly) ? false : (!this.typing.equals(((ForField)param2Object).typing) ? false : (!!this.target.equals(((ForField)param2Object).target))))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return ((getClass().hashCode() * 31 + this.target.hashCode()) * 31 + this.readOnly) * 31 + this.typing.hashCode();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static abstract class Unresolved
/*       */         extends ForField
/*       */       {
/*       */         protected static final String BEAN_PROPERTY = "";
/*       */ 
/*       */ 
/*       */         
/*       */         private final String name;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Unresolved(TypeDescription.Generic target, boolean readOnly, Assigner.Typing typing, String name) {
/*  2523 */           super(target, readOnly, typing);
/*  2524 */           this.name = name;
/*       */         }
/*       */ 
/*       */         
/*       */         protected FieldDescription resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/*  2529 */           FieldLocator locator = fieldLocator(instrumentedType);
/*       */ 
/*       */           
/*  2532 */           FieldLocator.Resolution resolution = this.name.equals("") ? FieldLocator.Resolution.Simple.ofBeanAccessor(locator, instrumentedMethod) : locator.locate(this.name);
/*  2533 */           if (!resolution.isResolved()) {
/*  2534 */             throw new IllegalStateException("Cannot locate field named " + this.name + " for " + instrumentedType);
/*       */           }
/*  2536 */           return resolution.getField();
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         protected abstract FieldLocator fieldLocator(TypeDescription param3TypeDescription);
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.name.equals(((Unresolved)param3Object).name)))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return super.hashCode() * 31 + this.name.hashCode();
/*       */         }
/*       */ 
/*       */         
/*       */         public static class WithImplicitType
/*       */           extends Unresolved
/*       */         {
/*       */           protected WithImplicitType(TypeDescription.Generic target, AnnotationDescription.Loadable<Advice.FieldValue> annotation) {
/*  2560 */             this(target, ((Boolean)annotation
/*  2561 */                 .getValue(Advice.OffsetMapping.ForField.access$1300()).resolve(Boolean.class)).booleanValue(), (Assigner.Typing)((EnumerationDescription)annotation
/*  2562 */                 .getValue(Advice.OffsetMapping.ForField.access$1400()).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (String)annotation
/*  2563 */                 .getValue(Advice.OffsetMapping.ForField.access$1500()).resolve(String.class));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public WithImplicitType(TypeDescription.Generic target, boolean readOnly, Assigner.Typing typing, String name) {
/*  2575 */             super(target, readOnly, typing, name);
/*       */           }
/*       */ 
/*       */           
/*       */           protected FieldLocator fieldLocator(TypeDescription instrumentedType) {
/*  2580 */             return (FieldLocator)new FieldLocator.ForClassHierarchy(instrumentedType);
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class WithExplicitType
/*       */           extends Unresolved
/*       */         {
/*       */           private final TypeDescription declaringType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected WithExplicitType(TypeDescription.Generic target, AnnotationDescription.Loadable<Advice.FieldValue> annotation, TypeDescription declaringType) {
/*  2605 */             this(target, ((Boolean)annotation
/*  2606 */                 .getValue(Advice.OffsetMapping.ForField.access$1300()).resolve(Boolean.class)).booleanValue(), (Assigner.Typing)((EnumerationDescription)annotation
/*  2607 */                 .getValue(Advice.OffsetMapping.ForField.access$1400()).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), (String)annotation
/*  2608 */                 .getValue(Advice.OffsetMapping.ForField.access$1500()).resolve(String.class), declaringType);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public WithExplicitType(TypeDescription.Generic target, boolean readOnly, Assigner.Typing typing, String name, TypeDescription declaringType) {
/*  2626 */             super(target, readOnly, typing, name);
/*  2627 */             this.declaringType = declaringType;
/*       */           }
/*       */ 
/*       */           
/*       */           protected FieldLocator fieldLocator(TypeDescription instrumentedType) {
/*  2632 */             if (!this.declaringType.represents(TargetType.class) && !instrumentedType.isAssignableTo(this.declaringType)) {
/*  2633 */               throw new IllegalStateException(this.declaringType + " is no super type of " + instrumentedType);
/*       */             }
/*  2635 */             return (FieldLocator)new FieldLocator.ForExactType(TargetType.resolve(this.declaringType, instrumentedType));
/*       */           }
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.declaringType.equals(((WithExplicitType)param4Object).declaringType)))));
/*       */           }
/*       */           
/*       */           public int hashCode() {
/*       */             return super.hashCode() * 31 + this.declaringType.hashCode();
/*       */           } }
/*       */         
/*       */         protected enum Factory implements Advice.OffsetMapping.Factory<Advice.FieldValue> {
/*  2647 */           INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Class<Advice.FieldValue> getAnnotationType() {
/*  2653 */             return Advice.FieldValue.class;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.FieldValue> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  2662 */             if (adviceType.isDelegation() && !((Boolean)annotation.getValue(Advice.OffsetMapping.ForField.access$1300()).resolve(Boolean.class)).booleanValue()) {
/*  2663 */               throw new IllegalStateException("Cannot write to field for " + target + " in read-only context");
/*       */             }
/*  2665 */             TypeDescription declaringType = (TypeDescription)annotation.getValue(Advice.OffsetMapping.ForField.access$1600()).resolve(TypeDescription.class);
/*  2666 */             return declaringType.represents(void.class) ? new Advice.OffsetMapping.ForField.Unresolved.WithImplicitType(target
/*  2667 */                 .getType(), annotation) : new Advice.OffsetMapping.ForField.Unresolved.WithExplicitType(target
/*  2668 */                 .getType(), annotation, declaringType);
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Resolved
/*       */         extends ForField
/*       */       {
/*       */         private final FieldDescription fieldDescription;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Resolved(TypeDescription.Generic target, boolean readOnly, Assigner.Typing typing, FieldDescription fieldDescription) {
/*  2694 */           super(target, readOnly, typing);
/*  2695 */           this.fieldDescription = fieldDescription;
/*       */         }
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming declaring type for type member.")
/*       */         protected FieldDescription resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/*  2701 */           if (!this.fieldDescription.isStatic() && !this.fieldDescription.getDeclaringType().asErasure().isAssignableFrom(instrumentedType))
/*  2702 */             throw new IllegalStateException(this.fieldDescription + " is no member of " + instrumentedType); 
/*  2703 */           if (!this.fieldDescription.isVisibleTo(instrumentedType)) {
/*  2704 */             throw new IllegalStateException("Cannot access " + this.fieldDescription + " from " + instrumentedType);
/*       */           }
/*  2706 */           return this.fieldDescription;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.fieldDescription.equals(((Resolved)param3Object).fieldDescription)))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return super.hashCode() * 31 + this.fieldDescription.hashCode();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class Factory<T extends Annotation>
/*       */           implements Advice.OffsetMapping.Factory<T>
/*       */         {
/*       */           private final Class<T> annotationType;
/*       */ 
/*       */           
/*       */           private final FieldDescription fieldDescription;
/*       */ 
/*       */           
/*       */           private final boolean readOnly;
/*       */ 
/*       */           
/*       */           private final Assigner.Typing typing;
/*       */ 
/*       */ 
/*       */           
/*       */           public Factory(Class<T> annotationType, FieldDescription fieldDescription) {
/*  2744 */             this(annotationType, fieldDescription, true, Assigner.Typing.STATIC);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Factory(Class<T> annotationType, FieldDescription fieldDescription, boolean readOnly, Assigner.Typing typing) {
/*  2756 */             this.annotationType = annotationType;
/*  2757 */             this.fieldDescription = fieldDescription;
/*  2758 */             this.readOnly = readOnly;
/*  2759 */             this.typing = typing;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Class<T> getAnnotationType() {
/*  2766 */             return this.annotationType;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  2775 */             return new Advice.OffsetMapping.ForField.Resolved(target.getType(), this.readOnly, this.typing, this.fieldDescription);
/*       */           }
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : ((this.readOnly != ((Factory)param4Object).readOnly) ? false : (!this.typing.equals(((Factory)param4Object).typing) ? false : (!this.annotationType.equals(((Factory)param4Object).annotationType) ? false : (!!this.fieldDescription.equals(((Factory)param4Object).fieldDescription)))))));
/*       */           }
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return (((getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.fieldDescription.hashCode()) * 31 + this.readOnly) * 31 + this.typing.hashCode();
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */     
/*       */     @Enhance
/*       */     public static abstract class ForFieldHandle
/*       */       implements OffsetMapping
/*       */     {
/*       */       private final Access access;
/*       */       
/*       */       protected ForFieldHandle(Access access) {
/*  2798 */         this.access = access;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  2809 */         FieldDescription fieldDescription = resolve(instrumentedType, instrumentedMethod);
/*  2810 */         if (!fieldDescription.isStatic() && instrumentedMethod.isStatic()) {
/*  2811 */           throw new IllegalStateException("Cannot access non-static field " + fieldDescription + " from static method " + instrumentedMethod);
/*       */         }
/*  2813 */         if (sort.isPremature(instrumentedMethod) && !fieldDescription.isStatic())
/*  2814 */           throw new IllegalStateException("Cannot access " + fieldDescription + " before super constructor call"); 
/*  2815 */         if (fieldDescription.isStatic()) {
/*  2816 */           return new Advice.OffsetMapping.Target.ForStackManipulation(this.access.resolve((FieldDescription.InDefinedShape)fieldDescription.asDefined()).toStackManipulation());
/*       */         }
/*  2818 */         return new Advice.OffsetMapping.Target.ForStackManipulation((StackManipulation)new StackManipulation.Compound(new StackManipulation[] { this.access
/*  2819 */                 .resolve((FieldDescription.InDefinedShape)fieldDescription.asDefined()).toStackManipulation(), MethodVariableAccess.REFERENCE
/*  2820 */                 .loadFrom(argumentHandler.argument(0)), 
/*  2821 */                 (StackManipulation)MethodInvocation.invoke((MethodDescription.InDefinedShape)new MethodDescription.Latent(JavaType.METHOD_HANDLE.getTypeStub(), new MethodDescription.Token("bindTo", 1, JavaType.METHOD_HANDLE
/*       */                       
/*  2823 */                       .getTypeStub().asGenericType(), (List)new TypeList.Generic.Explicit(new TypeDefinition[] {
/*  2824 */                           (TypeDefinition)TypeDefinition.Sort.describe(Object.class)
/*       */                         })))) }));
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract FieldDescription resolve(TypeDescription param2TypeDescription, MethodDescription param2MethodDescription);
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.access.equals(((ForFieldHandle)param2Object).access))));
/*       */       }
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.access.hashCode();
/*       */       }
/*       */ 
/*       */       
/*       */       public enum Access
/*       */       {
/*  2845 */         GETTER
/*       */         {
/*       */           protected JavaConstant.MethodHandle resolve(FieldDescription.InDefinedShape fieldDescription) {
/*  2848 */             return JavaConstant.MethodHandle.ofGetter(fieldDescription);
/*       */           }
/*       */         },
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  2855 */         SETTER
/*       */         {
/*       */           protected JavaConstant.MethodHandle resolve(FieldDescription.InDefinedShape fieldDescription) {
/*  2858 */             return JavaConstant.MethodHandle.ofSetter(fieldDescription);
/*       */           }
/*       */         };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected abstract JavaConstant.MethodHandle resolve(FieldDescription.InDefinedShape param3InDefinedShape);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static abstract class Unresolved
/*       */         extends ForFieldHandle
/*       */       {
/*       */         protected static final String BEAN_PROPERTY = "";
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final String name;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Unresolved(Advice.OffsetMapping.ForFieldHandle.Access access, String name) {
/*  2894 */           super(access);
/*  2895 */           this.name = name;
/*       */         }
/*       */ 
/*       */         
/*       */         protected FieldDescription resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/*  2900 */           FieldLocator locator = fieldLocator(instrumentedType);
/*       */ 
/*       */           
/*  2903 */           FieldLocator.Resolution resolution = this.name.equals("") ? FieldLocator.Resolution.Simple.ofBeanAccessor(locator, instrumentedMethod) : locator.locate(this.name);
/*  2904 */           if (!resolution.isResolved()) {
/*  2905 */             throw new IllegalStateException("Cannot locate field named " + this.name + " for " + instrumentedType);
/*       */           }
/*  2907 */           return resolution.getField();
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         protected abstract FieldLocator fieldLocator(TypeDescription param3TypeDescription);
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.name.equals(((Unresolved)param3Object).name)))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return super.hashCode() * 31 + this.name.hashCode();
/*       */         }
/*       */ 
/*       */         
/*       */         public static class WithImplicitType
/*       */           extends Unresolved
/*       */         {
/*       */           public WithImplicitType(Advice.OffsetMapping.ForFieldHandle.Access access, String name) {
/*  2931 */             super(access, name);
/*       */           }
/*       */ 
/*       */           
/*       */           protected FieldLocator fieldLocator(TypeDescription instrumentedType) {
/*  2936 */             return (FieldLocator)new FieldLocator.ForClassHierarchy(instrumentedType);
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class WithExplicitType
/*       */           extends Unresolved
/*       */         {
/*       */           private final TypeDescription declaringType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public WithExplicitType(Advice.OffsetMapping.ForFieldHandle.Access access, String name, TypeDescription declaringType) {
/*  2959 */             super(access, name);
/*  2960 */             this.declaringType = declaringType;
/*       */           }
/*       */ 
/*       */           
/*       */           protected FieldLocator fieldLocator(TypeDescription instrumentedType) {
/*  2965 */             if (!this.declaringType.represents(TargetType.class) && !instrumentedType.isAssignableTo(this.declaringType)) {
/*  2966 */               throw new IllegalStateException(this.declaringType + " is no super type of " + instrumentedType);
/*       */             }
/*  2968 */             return (FieldLocator)new FieldLocator.ForExactType(TargetType.resolve(this.declaringType, instrumentedType));
/*       */           }
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.declaringType.equals(((WithExplicitType)param4Object).declaringType)))));
/*       */           }
/*       */           
/*       */           public int hashCode() {
/*       */             return super.hashCode() * 31 + this.declaringType.hashCode();
/*       */           } }
/*       */         
/*       */         protected enum ReaderFactory implements Advice.OffsetMapping.Factory<Advice.FieldGetterHandle> {
/*  2980 */           INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape FIELD_GETTER_HANDLE_DECLARING_TYPE;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape FIELD_GETTER_HANDLE_VALUE;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           static {
/*  2996 */             MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.FieldGetterHandle.class).getDeclaredMethods();
/*  2997 */             FIELD_GETTER_HANDLE_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly();
/*  2998 */             FIELD_GETTER_HANDLE_DECLARING_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("declaringType"))).getOnly();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Class<Advice.FieldGetterHandle> getAnnotationType() {
/*  3005 */             return Advice.FieldGetterHandle.class;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.FieldGetterHandle> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  3014 */             if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) {
/*  3015 */               throw new IllegalStateException("Cannot assign method handle to " + target);
/*       */             }
/*  3017 */             TypeDescription declaringType = (TypeDescription)annotation.getValue(FIELD_GETTER_HANDLE_DECLARING_TYPE).resolve(TypeDescription.class);
/*  3018 */             return declaringType.represents(void.class) ? new Advice.OffsetMapping.ForFieldHandle.Unresolved.WithImplicitType(Advice.OffsetMapping.ForFieldHandle.Access.GETTER, (String)annotation
/*  3019 */                 .getValue(FIELD_GETTER_HANDLE_VALUE).resolve(String.class)) : new Advice.OffsetMapping.ForFieldHandle.Unresolved.WithExplicitType(Advice.OffsetMapping.ForFieldHandle.Access.GETTER, (String)annotation
/*  3020 */                 .getValue(FIELD_GETTER_HANDLE_VALUE).resolve(String.class), declaringType);
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected enum WriterFactory
/*       */           implements Advice.OffsetMapping.Factory<Advice.FieldSetterHandle>
/*       */         {
/*  3032 */           INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape FIELD_SETTER_HANDLE_DECLARING_TYPE;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape FIELD_SETTER_HANDLE_VALUE;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           static {
/*  3048 */             MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.FieldSetterHandle.class).getDeclaredMethods();
/*  3049 */             FIELD_SETTER_HANDLE_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly();
/*  3050 */             FIELD_SETTER_HANDLE_DECLARING_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("declaringType"))).getOnly();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Class<Advice.FieldSetterHandle> getAnnotationType() {
/*  3057 */             return Advice.FieldSetterHandle.class;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.FieldSetterHandle> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  3066 */             if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) {
/*  3067 */               throw new IllegalStateException("Cannot assign method handle to " + target);
/*       */             }
/*  3069 */             TypeDescription declaringType = (TypeDescription)annotation.getValue(FIELD_SETTER_HANDLE_DECLARING_TYPE).resolve(TypeDescription.class);
/*  3070 */             return declaringType.represents(void.class) ? new Advice.OffsetMapping.ForFieldHandle.Unresolved.WithImplicitType(Advice.OffsetMapping.ForFieldHandle.Access.SETTER, (String)annotation
/*  3071 */                 .getValue(FIELD_SETTER_HANDLE_VALUE).resolve(String.class)) : new Advice.OffsetMapping.ForFieldHandle.Unresolved.WithExplicitType(Advice.OffsetMapping.ForFieldHandle.Access.SETTER, (String)annotation
/*  3072 */                 .getValue(FIELD_SETTER_HANDLE_VALUE).resolve(String.class), declaringType);
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Resolved
/*       */         extends ForFieldHandle
/*       */       {
/*       */         private final FieldDescription fieldDescription;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Resolved(Advice.OffsetMapping.ForFieldHandle.Access access, FieldDescription fieldDescription) {
/*  3095 */           super(access);
/*  3096 */           this.fieldDescription = fieldDescription;
/*       */         }
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming declaring type for type member.")
/*       */         protected FieldDescription resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/*  3102 */           if (!this.fieldDescription.isStatic() && !this.fieldDescription.getDeclaringType().asErasure().isAssignableFrom(instrumentedType))
/*  3103 */             throw new IllegalStateException(this.fieldDescription + " is no member of " + instrumentedType); 
/*  3104 */           if (!this.fieldDescription.isVisibleTo(instrumentedType)) {
/*  3105 */             throw new IllegalStateException("Cannot access " + this.fieldDescription + " from " + instrumentedType);
/*       */           }
/*  3107 */           return this.fieldDescription;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.fieldDescription.equals(((Resolved)param3Object).fieldDescription)))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return super.hashCode() * 31 + this.fieldDescription.hashCode();
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class Factory<T extends Annotation>
/*       */           implements Advice.OffsetMapping.Factory<T>
/*       */         {
/*       */           private final Class<T> annotationType;
/*       */ 
/*       */           
/*       */           private final FieldDescription fieldDescription;
/*       */ 
/*       */           
/*       */           private final Advice.OffsetMapping.ForFieldHandle.Access access;
/*       */ 
/*       */ 
/*       */           
/*       */           public Factory(Class<T> annotationType, FieldDescription fieldDescription, Advice.OffsetMapping.ForFieldHandle.Access access) {
/*  3141 */             this.annotationType = annotationType;
/*  3142 */             this.fieldDescription = fieldDescription;
/*  3143 */             this.access = access;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Class<T> getAnnotationType() {
/*  3150 */             return this.annotationType;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  3159 */             if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) {
/*  3160 */               throw new IllegalStateException("Cannot assign method handle to " + target);
/*       */             }
/*  3162 */             return new Advice.OffsetMapping.ForFieldHandle.Resolved(this.access, this.fieldDescription);
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.access.equals(((Factory)param4Object).access) ? false : (!this.annotationType.equals(((Factory)param4Object).annotationType) ? false : (!!this.fieldDescription.equals(((Factory)param4Object).fieldDescription))))));
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return ((getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.fieldDescription.hashCode()) * 31 + this.access.hashCode();
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForOrigin
/*       */       implements OffsetMapping
/*       */     {
/*       */       private static final char DELIMITER = '#';
/*       */ 
/*       */       
/*       */       private static final char ESCAPE = '\\';
/*       */       
/*       */       private final List<Renderer> renderers;
/*       */ 
/*       */       
/*       */       public ForOrigin(List<Renderer> renderers) {
/*  3195 */         this.renderers = renderers;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static Advice.OffsetMapping parse(String pattern) {
/*  3205 */         if (pattern.equals("")) {
/*  3206 */           return new ForOrigin(Collections.singletonList(Renderer.ForStringRepresentation.INSTANCE));
/*       */         }
/*  3208 */         List<Renderer> renderers = new ArrayList<Renderer>(pattern.length());
/*  3209 */         int from = 0;
/*  3210 */         for (int to = pattern.indexOf('#'); to != -1; to = pattern.indexOf('#', from)) {
/*  3211 */           if (to != 0 && pattern.charAt(to - 1) == '\\' && (to == 1 || pattern.charAt(to - 2) != '\\')) {
/*  3212 */             renderers.add(new Renderer.ForConstantValue(pattern.substring(from, Math.max(0, to - 1)) + '#'));
/*  3213 */             from = to + 1;
/*       */           } else {
/*  3215 */             if (pattern.length() == to + 1) {
/*  3216 */               throw new IllegalStateException("Missing sort descriptor for " + pattern + " at index " + to);
/*       */             }
/*  3218 */             renderers.add(new Renderer.ForConstantValue(pattern.substring(from, to).replace("\\\\", "\\")));
/*  3219 */             switch (pattern.charAt(to + 1)) {
/*       */               case 'm':
/*  3221 */                 renderers.add(Renderer.ForMethodName.INSTANCE);
/*       */                 break;
/*       */               case 't':
/*  3224 */                 renderers.add(Renderer.ForTypeName.INSTANCE);
/*       */                 break;
/*       */               case 'd':
/*  3227 */                 renderers.add(Renderer.ForDescriptor.INSTANCE);
/*       */                 break;
/*       */               case 'r':
/*  3230 */                 renderers.add(Renderer.ForReturnTypeName.INSTANCE);
/*       */                 break;
/*       */               case 's':
/*  3233 */                 renderers.add(Renderer.ForJavaSignature.INSTANCE);
/*       */                 break;
/*       */               case 'p':
/*  3236 */                 renderers.add(Renderer.ForPropertyName.INSTANCE);
/*       */                 break;
/*       */               default:
/*  3239 */                 throw new IllegalStateException("Illegal sort descriptor " + pattern.charAt(to + 1) + " for " + pattern);
/*       */             } 
/*  3241 */             from = to + 2;
/*       */           } 
/*  3243 */         }  renderers.add(new Renderer.ForConstantValue(pattern.substring(from)));
/*  3244 */         return new ForOrigin(renderers);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  3256 */         StringBuilder stringBuilder = new StringBuilder();
/*  3257 */         for (Renderer renderer : this.renderers) {
/*  3258 */           stringBuilder.append(renderer.apply(instrumentedType, instrumentedMethod));
/*       */         }
/*  3260 */         return Advice.OffsetMapping.Target.ForStackManipulation.of(stringBuilder.toString());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.renderers.equals(((ForOrigin)param2Object).renderers))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.renderers.hashCode();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum ForMethodName
/*       */         implements Renderer
/*       */       {
/*  3285 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static final char SYMBOL = 'm';
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public String apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/*  3296 */           return instrumentedMethod.getInternalName();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum ForTypeName
/*       */         implements Renderer
/*       */       {
/*  3308 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static final char SYMBOL = 't';
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public String apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/*  3319 */           return instrumentedType.getName();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum ForDescriptor
/*       */         implements Renderer
/*       */       {
/*  3331 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static final char SYMBOL = 'd';
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public String apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/*  3342 */           return instrumentedMethod.getDescriptor();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum ForJavaSignature
/*       */         implements Renderer
/*       */       {
/*  3354 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static final char SYMBOL = 's';
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public String apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/*  3365 */           StringBuilder stringBuilder = new StringBuilder("(");
/*  3366 */           boolean comma = false;
/*  3367 */           for (TypeDescription typeDescription : instrumentedMethod.getParameters().asTypeList().asErasures()) {
/*  3368 */             if (comma) {
/*  3369 */               stringBuilder.append(',');
/*       */             } else {
/*  3371 */               comma = true;
/*       */             } 
/*  3373 */             stringBuilder.append(typeDescription.getName());
/*       */           } 
/*  3375 */           return stringBuilder.append(')').toString();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum ForReturnTypeName
/*       */         implements Renderer
/*       */       {
/*  3387 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static final char SYMBOL = 'r';
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public String apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/*  3398 */           return instrumentedMethod.getReturnType().asErasure().getName();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum ForStringRepresentation
/*       */         implements Renderer
/*       */       {
/*  3410 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public String apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/*  3416 */           return instrumentedMethod.toString();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class ForConstantValue
/*       */         implements Renderer
/*       */       {
/*       */         private final String value;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public ForConstantValue(String value) {
/*  3437 */           this.value = value;
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public String apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod)
/*       */         {
/*  3444 */           return this.value; } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.value.equals(((ForConstantValue)param3Object).value)))); } public int hashCode() { return getClass().hashCode() * 31 + this.value.hashCode(); } } public static interface Renderer { String apply(TypeDescription param3TypeDescription, MethodDescription param3MethodDescription); public enum ForMethodName implements Renderer { INSTANCE; public static final char SYMBOL = 'm'; public String apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return instrumentedMethod.getInternalName(); } } public enum ForTypeName implements Renderer { INSTANCE; public static final char SYMBOL = 't'; public String apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return instrumentedType.getName(); } } public enum ForDescriptor implements Renderer { INSTANCE; public static final char SYMBOL = 'd'; public String apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return instrumentedMethod.getDescriptor(); } } public enum ForJavaSignature implements Renderer { INSTANCE; public static final char SYMBOL = 's'; public String apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) { StringBuilder stringBuilder = new StringBuilder("("); boolean comma = false; for (TypeDescription typeDescription : instrumentedMethod.getParameters().asTypeList().asErasures()) { if (comma) { stringBuilder.append(','); } else { comma = true; }  stringBuilder.append(typeDescription.getName()); }  return stringBuilder.append(')').toString(); } } public enum ForReturnTypeName implements Renderer { INSTANCE; public static final char SYMBOL = 'r'; public String apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return instrumentedMethod.getReturnType().asErasure().getName(); } } public enum ForStringRepresentation implements Renderer { INSTANCE; public String apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return instrumentedMethod.toString(); } } @Enhance public static class ForConstantValue implements Renderer { private final String value; public ForConstantValue(String value) { this.value = value; } public String apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return this.value; }
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.value.equals(((ForConstantValue)param4Object).value))));
/*       */           }
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.value.hashCode();
/*       */           } }
/*       */ 
/*       */         
/*  3456 */         public enum ForPropertyName implements Renderer { INSTANCE;
/*       */ 
/*       */ 
/*       */           
/*       */           public static final char SYMBOL = 'p';
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public String apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod)
/*       */           {
/*  3467 */             return FieldAccessor.FieldNameExtractor.ForBeanProperty.INSTANCE.resolve(instrumentedMethod); } } } public enum ForPropertyName implements Renderer { INSTANCE; public static final char SYMBOL = 'p'; public String apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return FieldAccessor.FieldNameExtractor.ForBeanProperty.INSTANCE.resolve(instrumentedMethod); }
/*       */          }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected enum Factory
/*       */         implements Advice.OffsetMapping.Factory<Advice.Origin>
/*       */       {
/*  3480 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  3485 */         private static final MethodDescription.InDefinedShape ORIGIN_VALUE = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(Advice.Origin.class)
/*  3486 */           .getDeclaredMethods()
/*  3487 */           .filter((ElementMatcher)ElementMatchers.named("value")))
/*  3488 */           .getOnly();
/*       */         static {
/*       */         
/*       */         }
/*       */         
/*       */         public Class<Advice.Origin> getAnnotationType() {
/*  3494 */           return Advice.Origin.class;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.Origin> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  3503 */           if (target.getType().asErasure().represents(Class.class))
/*  3504 */             return Advice.OffsetMapping.ForInstrumentedType.INSTANCE; 
/*  3505 */           if (target.getType().asErasure().represents(Method.class))
/*  3506 */             return Advice.OffsetMapping.ForInstrumentedMethod.METHOD; 
/*  3507 */           if (target.getType().asErasure().represents(Constructor.class))
/*  3508 */             return Advice.OffsetMapping.ForInstrumentedMethod.CONSTRUCTOR; 
/*  3509 */           if (JavaType.EXECUTABLE.getTypeStub().equals(target.getType().asErasure()))
/*  3510 */             return Advice.OffsetMapping.ForInstrumentedMethod.EXECUTABLE; 
/*  3511 */           if (JavaType.METHOD_HANDLE.getTypeStub().equals(target.getType().asErasure()))
/*  3512 */             return Advice.OffsetMapping.ForInstrumentedMethod.METHOD_HANDLE; 
/*  3513 */           if (JavaType.METHOD_TYPE.getTypeStub().equals(target.getType().asErasure()))
/*  3514 */             return Advice.OffsetMapping.ForInstrumentedMethod.METHOD_TYPE; 
/*  3515 */           if (JavaType.METHOD_HANDLES_LOOKUP.getTypeStub().equals(target.getType().asErasure())) {
/*  3516 */             return new Advice.OffsetMapping.ForStackManipulation(MethodInvocation.lookup(), JavaType.METHOD_HANDLES_LOOKUP
/*  3517 */                 .getTypeStub().asGenericType(), target
/*  3518 */                 .getType(), Assigner.Typing.STATIC);
/*       */           }
/*  3520 */           if (target.getType().asErasure().isAssignableFrom(String.class)) {
/*  3521 */             return Advice.OffsetMapping.ForOrigin.parse((String)annotation.getValue(ORIGIN_VALUE).resolve(String.class));
/*       */           }
/*  3523 */           throw new IllegalStateException("Non-supported type " + target.getType() + " for @Origin annotation");
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum ForSelfCallHandle
/*       */       implements OffsetMapping
/*       */     {
/*  3537 */       BOUND
/*       */       {
/*       */         
/*       */         protected StackManipulation decorate(MethodDescription methodDescription, StackManipulation stackManipulation)
/*       */         {
/*  3542 */           List<StackManipulation> stackManipulations = new ArrayList<StackManipulation>(1 + (methodDescription.isStatic() ? 0 : 2) + methodDescription.getParameters().size() * 3);
/*  3543 */           stackManipulations.add(stackManipulation);
/*  3544 */           if (!methodDescription.isStatic()) {
/*  3545 */             stackManipulations.add(MethodVariableAccess.loadThis());
/*  3546 */             stackManipulations.add(MethodInvocation.invoke((MethodDescription.InDefinedShape)new MethodDescription.Latent(JavaType.METHOD_HANDLE.getTypeStub(), new MethodDescription.Token("bindTo", 1, JavaType.METHOD_HANDLE
/*       */                       
/*  3548 */                       .getTypeStub().asGenericType(), (List)new TypeList.Generic.Explicit(new TypeDefinition[] {
/*  3549 */                           (TypeDefinition)TypeDefinition.Sort.describe(Object.class) })))));
/*       */           } 
/*  3551 */           if (!methodDescription.getParameters().isEmpty()) {
/*  3552 */             List<StackManipulation> values = new ArrayList<StackManipulation>(methodDescription.getParameters().size());
/*  3553 */             for (ParameterDescription parameterDescription : methodDescription.getParameters()) {
/*  3554 */               if (parameterDescription.getType().isPrimitive()) {  } else {  }  values.add(
/*       */ 
/*       */                   
/*  3557 */                   MethodVariableAccess.load(parameterDescription));
/*       */             } 
/*  3559 */             stackManipulations.add(IntegerConstant.forValue(0));
/*  3560 */             stackManipulations.add(ArrayFactory.forType(TypeDescription.ForLoadedType.of(Object.class).asGenericType()).withValues(values));
/*  3561 */             stackManipulations.add(
/*  3562 */                 MethodInvocation.invoke((MethodDescription.InDefinedShape)new MethodDescription.Latent(JavaType.METHOD_HANDLES.getTypeStub(), new MethodDescription.Token("insertArguments", 9, JavaType.METHOD_HANDLE
/*       */                       
/*  3564 */                       .getTypeStub().asGenericType(), (List)new TypeList.Generic.Explicit(new TypeDefinition[] { (TypeDefinition)JavaType.METHOD_HANDLE
/*  3565 */                           .getTypeStub(), (TypeDefinition)TypeDefinition.Sort.describe(int.class), 
/*  3566 */                           (TypeDefinition)TypeDefinition.Sort.describe(Object[].class) })))));
/*       */           } 
/*  3568 */           return (StackManipulation)new StackManipulation.Compound(stackManipulations);
/*       */         }
/*       */       },
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3575 */       UNBOUND
/*       */       {
/*       */         protected StackManipulation decorate(MethodDescription methodDescription, StackManipulation stackManipulation) {
/*  3578 */           return stackManipulation;
/*       */         }
/*       */       };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  3590 */         if (!instrumentedMethod.isMethod()) {
/*  3591 */           throw new IllegalStateException();
/*       */         }
/*       */ 
/*       */         
/*  3595 */         StackManipulation stackManipulation = (instrumentedMethod.isStatic() ? JavaConstant.MethodHandle.of((MethodDescription.InDefinedShape)instrumentedMethod.asDefined()) : JavaConstant.MethodHandle.ofSpecial((MethodDescription.InDefinedShape)instrumentedMethod.asDefined(), instrumentedType)).toStackManipulation();
/*  3596 */         return new Advice.OffsetMapping.Target.ForStackManipulation(decorate(instrumentedMethod, stackManipulation));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract StackManipulation decorate(MethodDescription param2MethodDescription, StackManipulation param2StackManipulation);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected enum Factory
/*       */         implements Advice.OffsetMapping.Factory<Advice.SelfCallHandle>
/*       */       {
/*  3616 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  3621 */         private static final MethodDescription.InDefinedShape SELF_CALL_HANDLE_BOUND = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(Advice.SelfCallHandle.class)
/*  3622 */           .getDeclaredMethods()
/*  3623 */           .filter((ElementMatcher)ElementMatchers.named("bound")))
/*  3624 */           .getOnly();
/*       */         static {
/*       */         
/*       */         }
/*       */         
/*       */         public Class<Advice.SelfCallHandle> getAnnotationType() {
/*  3630 */           return Advice.SelfCallHandle.class;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.SelfCallHandle> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  3639 */           if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) {
/*  3640 */             throw new IllegalStateException("Cannot assign a MethodHandle to " + target);
/*       */           }
/*  3642 */           return ((Boolean)annotation.getValue(SELF_CALL_HANDLE_BOUND).resolve(Boolean.class)).booleanValue() ? Advice.OffsetMapping.ForSelfCallHandle.BOUND : Advice.OffsetMapping.ForSelfCallHandle.UNBOUND;
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForHandle
/*       */       implements OffsetMapping
/*       */     {
/*       */       private final JavaConstant.MethodHandle.HandleType type;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TypeDescription owner;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final String name;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TypeDescription returnType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final List<? extends TypeDescription> parameterTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected ForHandle(JavaConstant.MethodHandle.HandleType type, TypeDescription owner, String name, TypeDescription returnType, List<? extends TypeDescription> parameterTypes) {
/*  3694 */         this.type = type;
/*  3695 */         this.owner = owner;
/*  3696 */         this.name = name;
/*  3697 */         this.returnType = returnType;
/*  3698 */         this.parameterTypes = parameterTypes;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  3709 */         return new Advice.OffsetMapping.Target.ForStackManipulation((StackManipulation)new JavaConstantValue((JavaConstant)new JavaConstant.MethodHandle(this.type, 
/*  3710 */                 this.owner.represents(void.class) ? instrumentedType : this.owner, this.name, this.returnType, this.parameterTypes)));
/*       */       }
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.type.equals(((ForHandle)param2Object).type) ? false : (!this.name.equals(((ForHandle)param2Object).name) ? false : (!this.owner.equals(((ForHandle)param2Object).owner) ? false : (!this.returnType.equals(((ForHandle)param2Object).returnType) ? false : (!!this.parameterTypes.equals(((ForHandle)param2Object).parameterTypes))))))));
/*       */       }
/*       */       
/*       */       public int hashCode() {
/*       */         return ((((getClass().hashCode() * 31 + this.type.hashCode()) * 31 + this.owner.hashCode()) * 31 + this.name.hashCode()) * 31 + this.returnType.hashCode()) * 31 + this.parameterTypes.hashCode();
/*       */       }
/*       */       
/*       */       protected enum Factory
/*       */         implements Advice.OffsetMapping.Factory<Advice.Handle>
/*       */       {
/*  3724 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape PARAMETER_TYPES;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape RETURN_TYPE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape NAME;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape OWNER;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape TYPE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         static {
/*  3755 */           MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.Handle.class).getDeclaredMethods();
/*  3756 */           TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("type"))).getOnly();
/*  3757 */           OWNER = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("owner"))).getOnly();
/*  3758 */           NAME = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("name"))).getOnly();
/*  3759 */           RETURN_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("returnType"))).getOnly();
/*  3760 */           PARAMETER_TYPES = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("parameterTypes"))).getOnly();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Class<Advice.Handle> getAnnotationType() {
/*  3767 */           return Advice.Handle.class;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.Handle> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  3776 */           if (!target.getType().asErasure().isAssignableFrom(JavaType.METHOD_HANDLE.getTypeStub())) {
/*  3777 */             throw new IllegalStateException("Cannot assign a MethodHandle to " + target);
/*       */           }
/*  3779 */           return new Advice.OffsetMapping.ForHandle((JavaConstant.MethodHandle.HandleType)((EnumerationDescription)annotation.getValue(TYPE).resolve(EnumerationDescription.class)).load(JavaConstant.MethodHandle.HandleType.class), (TypeDescription)annotation
/*  3780 */               .getValue(OWNER).resolve(TypeDescription.class), (String)annotation
/*  3781 */               .getValue(NAME).resolve(String.class), (TypeDescription)annotation
/*  3782 */               .getValue(RETURN_TYPE).resolve(TypeDescription.class), 
/*  3783 */               Arrays.asList((Object[])annotation.getValue(PARAMETER_TYPES).resolve(TypeDescription[].class)));
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForDynamicConstant
/*       */       implements OffsetMapping
/*       */     {
/*       */       private final String name;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TypeDescription typeDescription;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final JavaConstant.MethodHandle.HandleType bootstrapType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TypeDescription bootstrapOwner;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final String bootstrapName;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TypeDescription bootstrapReturnType;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final List<? extends TypeDescription> bootstrapParameterTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final List<JavaConstant> arguments;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final boolean invokedynamic;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForDynamicConstant(String name, TypeDescription typeDescription, JavaConstant.MethodHandle.HandleType bootstrapType, TypeDescription bootstrapOwner, String bootstrapName, TypeDescription bootstrapReturnType, List<? extends TypeDescription> bootstrapParameterTypes, List<JavaConstant> arguments, boolean invokedynamic) {
/*  3848 */         this.name = name;
/*  3849 */         this.typeDescription = typeDescription;
/*  3850 */         this.bootstrapType = bootstrapType;
/*  3851 */         this.bootstrapOwner = bootstrapOwner;
/*  3852 */         this.bootstrapName = bootstrapName;
/*  3853 */         this.bootstrapReturnType = bootstrapReturnType;
/*  3854 */         this.bootstrapParameterTypes = bootstrapParameterTypes;
/*  3855 */         this.arguments = arguments;
/*  3856 */         this.invokedynamic = invokedynamic;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  3867 */         TypeDescription bootstrapOwner = this.bootstrapOwner.represents(void.class) ? instrumentedType : this.bootstrapOwner;
/*  3868 */         if (this.invokedynamic) {
/*  3869 */           return new Advice.OffsetMapping.Target.ForStackManipulation((StackManipulation)new Invokedynamic(this.name, 
/*  3870 */                 JavaConstant.MethodType.of(this.typeDescription, new TypeDescription[0]), new JavaConstant.MethodHandle(this.bootstrapType, bootstrapOwner, this.bootstrapName, this.bootstrapReturnType, this.bootstrapParameterTypes), this.arguments));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  3878 */         return new Advice.OffsetMapping.Target.ForStackManipulation((StackManipulation)new JavaConstantValue((JavaConstant)new JavaConstant.Dynamic(this.name, this.typeDescription, new JavaConstant.MethodHandle(this.bootstrapType, bootstrapOwner, this.bootstrapName, this.bootstrapReturnType, this.bootstrapParameterTypes), this.arguments)));
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.invokedynamic != ((ForDynamicConstant)param2Object).invokedynamic) ? false : (!this.bootstrapType.equals(((ForDynamicConstant)param2Object).bootstrapType) ? false : (!this.name.equals(((ForDynamicConstant)param2Object).name) ? false : (!this.bootstrapName.equals(((ForDynamicConstant)param2Object).bootstrapName) ? false : (!this.typeDescription.equals(((ForDynamicConstant)param2Object).typeDescription) ? false : (!this.bootstrapOwner.equals(((ForDynamicConstant)param2Object).bootstrapOwner) ? false : (!this.bootstrapReturnType.equals(((ForDynamicConstant)param2Object).bootstrapReturnType) ? false : (!this.bootstrapParameterTypes.equals(((ForDynamicConstant)param2Object).bootstrapParameterTypes) ? false : (!!this.arguments.equals(((ForDynamicConstant)param2Object).arguments))))))))))));
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return ((((((((getClass().hashCode() * 31 + this.name.hashCode()) * 31 + this.typeDescription.hashCode()) * 31 + this.bootstrapType.hashCode()) * 31 + this.bootstrapOwner.hashCode()) * 31 + this.bootstrapName.hashCode()) * 31 + this.bootstrapReturnType.hashCode()) * 31 + this.bootstrapParameterTypes.hashCode()) * 31 + this.arguments.hashCode()) * 31 + this.invokedynamic;
/*       */       }
/*       */ 
/*       */       
/*       */       protected enum Factory
/*       */         implements Advice.OffsetMapping.Factory<Advice.DynamicConstant>
/*       */       {
/*  3897 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape INVOKEDYNAMIC;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape BOOTSTRAP_PARAMETER_TYPES;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape BOOTSTRAP_RETURN_TYPE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape BOOTSTRAP_NAME;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape BOOTSTRAP_OWNER;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape BOOTSTRAP_TYPE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape NAME;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         static {
/*  3938 */           MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.DynamicConstant.class).getDeclaredMethods();
/*  3939 */           NAME = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("name"))).getOnly();
/*  3940 */           BOOTSTRAP_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapType"))).getOnly();
/*  3941 */           BOOTSTRAP_OWNER = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapOwner"))).getOnly();
/*  3942 */           BOOTSTRAP_NAME = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapName"))).getOnly();
/*  3943 */           BOOTSTRAP_RETURN_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapReturnType"))).getOnly();
/*  3944 */           BOOTSTRAP_PARAMETER_TYPES = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("bootstrapParameterTypes"))).getOnly();
/*  3945 */           INVOKEDYNAMIC = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("invokedynamic"))).getOnly();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Class<Advice.DynamicConstant> getAnnotationType() {
/*  3952 */           return Advice.DynamicConstant.class;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.DynamicConstant> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  3961 */           return new Advice.OffsetMapping.ForDynamicConstant((String)annotation.getValue(NAME).resolve(String.class), target
/*  3962 */               .getType().asErasure(), (JavaConstant.MethodHandle.HandleType)((EnumerationDescription)annotation
/*  3963 */               .getValue(BOOTSTRAP_TYPE).resolve(EnumerationDescription.class)).load(JavaConstant.MethodHandle.HandleType.class), (TypeDescription)annotation
/*  3964 */               .getValue(BOOTSTRAP_OWNER).resolve(TypeDescription.class), (String)annotation
/*  3965 */               .getValue(BOOTSTRAP_NAME).resolve(String.class), (TypeDescription)annotation
/*  3966 */               .getValue(BOOTSTRAP_RETURN_TYPE).resolve(TypeDescription.class), 
/*  3967 */               Arrays.asList((Object[])annotation.getValue(BOOTSTRAP_PARAMETER_TYPES).resolve(TypeDescription[].class)), 
/*  3968 */               Collections.emptyList(), ((Boolean)annotation
/*  3969 */               .getValue(INVOKEDYNAMIC).resolve(Boolean.class)).booleanValue());
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForUnusedValue
/*       */       implements OffsetMapping
/*       */     {
/*       */       private final TypeDefinition target;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForUnusedValue(TypeDefinition target) {
/*  3991 */         this.target = target;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  4002 */         return new Advice.OffsetMapping.Target.ForDefaultValue.ReadWrite(this.target);
/*       */       }
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.target.equals(((ForUnusedValue)param2Object).target))));
/*       */       }
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.target.hashCode();
/*       */       }
/*       */       
/*  4013 */       protected enum Factory implements Advice.OffsetMapping.Factory<Advice.Unused> { INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Class<Advice.Unused> getAnnotationType() {
/*  4019 */           return Advice.Unused.class;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.Unused> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  4028 */           return new Advice.OffsetMapping.ForUnusedValue((TypeDefinition)target.getType());
/*       */         } }
/*       */     
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum ForStubValue
/*       */       implements OffsetMapping, Factory<Advice.StubValue>
/*       */     {
/*  4042 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  4052 */         return new Advice.OffsetMapping.Target.ForDefaultValue.ReadOnly((TypeDefinition)instrumentedMethod.getReturnType(), assigner.assign(instrumentedMethod.getReturnType(), 
/*  4053 */               TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class), Assigner.Typing.DYNAMIC));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Class<Advice.StubValue> getAnnotationType() {
/*  4061 */         return Advice.StubValue.class;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.StubValue> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  4070 */         if (!target.getType().represents(Object.class)) {
/*  4071 */           throw new IllegalStateException("Cannot use StubValue on non-Object parameter type " + target);
/*       */         }
/*  4073 */         return this;
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForEnterValue
/*       */       implements OffsetMapping
/*       */     {
/*       */       private final TypeDescription.Generic target;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TypeDescription.Generic enterType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final boolean readOnly;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final Assigner.Typing typing;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected ForEnterValue(TypeDescription.Generic target, TypeDescription.Generic enterType, AnnotationDescription.Loadable<Advice.Enter> annotation) {
/*  4112 */         this(target, enterType, ((Boolean)annotation
/*       */             
/*  4114 */             .getValue(Factory.access$1900()).resolve(Boolean.class)).booleanValue(), (Assigner.Typing)((EnumerationDescription)annotation
/*  4115 */             .getValue(Factory.access$2000()).resolve(EnumerationDescription.class)).load(Assigner.Typing.class));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForEnterValue(TypeDescription.Generic target, TypeDescription.Generic enterType, boolean readOnly, Assigner.Typing typing) {
/*  4127 */         this.target = target;
/*  4128 */         this.enterType = enterType;
/*  4129 */         this.readOnly = readOnly;
/*  4130 */         this.typing = typing;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  4141 */         StackManipulation readAssignment = assigner.assign(this.enterType, this.target, this.typing);
/*  4142 */         if (!readAssignment.isValid())
/*  4143 */           throw new IllegalStateException("Cannot assign " + this.enterType + " to " + this.target); 
/*  4144 */         if (this.readOnly) {
/*  4145 */           return new Advice.OffsetMapping.Target.ForVariable.ReadOnly((TypeDefinition)this.target, argumentHandler.enter(), readAssignment);
/*       */         }
/*  4147 */         StackManipulation writeAssignment = assigner.assign(this.target, this.enterType, this.typing);
/*  4148 */         if (!writeAssignment.isValid()) {
/*  4149 */           throw new IllegalStateException("Cannot assign " + this.target + " to " + this.enterType);
/*       */         }
/*  4151 */         return new Advice.OffsetMapping.Target.ForVariable.ReadWrite((TypeDefinition)this.target, argumentHandler.enter(), readAssignment, writeAssignment);
/*       */       }
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.readOnly != ((ForEnterValue)param2Object).readOnly) ? false : (!this.typing.equals(((ForEnterValue)param2Object).typing) ? false : (!this.target.equals(((ForEnterValue)param2Object).target) ? false : (!!this.enterType.equals(((ForEnterValue)param2Object).enterType)))))));
/*       */       }
/*       */       
/*       */       public int hashCode() {
/*       */         return (((getClass().hashCode() * 31 + this.target.hashCode()) * 31 + this.enterType.hashCode()) * 31 + this.readOnly) * 31 + this.typing.hashCode();
/*       */       }
/*       */       
/*       */       @Enhance
/*       */       protected static class Factory
/*       */         implements Advice.OffsetMapping.Factory<Advice.Enter>
/*       */       {
/*       */         private static final MethodDescription.InDefinedShape ENTER_READ_ONLY;
/*       */         private static final MethodDescription.InDefinedShape ENTER_TYPING;
/*       */         private final TypeDefinition enterType;
/*       */         
/*       */         static {
/*  4172 */           MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.Enter.class).getDeclaredMethods();
/*  4173 */           ENTER_READ_ONLY = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("readOnly"))).getOnly();
/*  4174 */           ENTER_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Factory(TypeDefinition enterType) {
/*  4188 */           this.enterType = enterType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static Advice.OffsetMapping.Factory<Advice.Enter> of(TypeDefinition typeDefinition) {
/*  4198 */           return typeDefinition.represents(void.class) ? new Advice.OffsetMapping.Factory.Illegal<Advice.Enter>(Advice.Enter.class) : new Factory(typeDefinition);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Class<Advice.Enter> getAnnotationType() {
/*  4207 */           return Advice.Enter.class;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.Enter> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  4216 */           if (adviceType.isDelegation() && !((Boolean)annotation.getValue(ENTER_READ_ONLY).resolve(Boolean.class)).booleanValue()) {
/*  4217 */             throw new IllegalStateException("Cannot use writable " + target + " on read-only parameter");
/*       */           }
/*  4219 */           return new Advice.OffsetMapping.ForEnterValue(target.getType(), this.enterType.asGenericType(), annotation);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.enterType.equals(((Factory)param3Object).enterType))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.enterType.hashCode();
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForExitValue
/*       */       implements OffsetMapping
/*       */     {
/*       */       private final TypeDescription.Generic target;
/*       */ 
/*       */       
/*       */       private final TypeDescription.Generic exitType;
/*       */ 
/*       */       
/*       */       private final boolean readOnly;
/*       */ 
/*       */       
/*       */       private final Assigner.Typing typing;
/*       */ 
/*       */ 
/*       */       
/*       */       protected ForExitValue(TypeDescription.Generic target, TypeDescription.Generic exitType, AnnotationDescription.Loadable<Advice.Exit> annotation) {
/*  4259 */         this(target, exitType, ((Boolean)annotation
/*       */             
/*  4261 */             .getValue(Factory.access$2100()).resolve(Boolean.class)).booleanValue(), (Assigner.Typing)((EnumerationDescription)annotation
/*  4262 */             .getValue(Factory.access$2200()).resolve(EnumerationDescription.class)).load(Assigner.Typing.class));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForExitValue(TypeDescription.Generic target, TypeDescription.Generic exitType, boolean readOnly, Assigner.Typing typing) {
/*  4274 */         this.target = target;
/*  4275 */         this.exitType = exitType;
/*  4276 */         this.readOnly = readOnly;
/*  4277 */         this.typing = typing;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  4288 */         StackManipulation readAssignment = assigner.assign(this.exitType, this.target, this.typing);
/*  4289 */         if (!readAssignment.isValid())
/*  4290 */           throw new IllegalStateException("Cannot assign " + this.exitType + " to " + this.target); 
/*  4291 */         if (this.readOnly) {
/*  4292 */           return new Advice.OffsetMapping.Target.ForVariable.ReadOnly((TypeDefinition)this.target, argumentHandler.exit(), readAssignment);
/*       */         }
/*  4294 */         StackManipulation writeAssignment = assigner.assign(this.target, this.exitType, this.typing);
/*  4295 */         if (!writeAssignment.isValid()) {
/*  4296 */           throw new IllegalStateException("Cannot assign " + this.target + " to " + this.exitType);
/*       */         }
/*  4298 */         return new Advice.OffsetMapping.Target.ForVariable.ReadWrite((TypeDefinition)this.target, argumentHandler.exit(), readAssignment, writeAssignment);
/*       */       }
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.readOnly != ((ForExitValue)param2Object).readOnly) ? false : (!this.typing.equals(((ForExitValue)param2Object).typing) ? false : (!this.target.equals(((ForExitValue)param2Object).target) ? false : (!!this.exitType.equals(((ForExitValue)param2Object).exitType)))))));
/*       */       }
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return (((getClass().hashCode() * 31 + this.target.hashCode()) * 31 + this.exitType.hashCode()) * 31 + this.readOnly) * 31 + this.typing.hashCode();
/*       */       }
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       protected static class Factory
/*       */         implements Advice.OffsetMapping.Factory<Advice.Exit>
/*       */       {
/*       */         private static final MethodDescription.InDefinedShape EXIT_READ_ONLY;
/*       */         
/*       */         private static final MethodDescription.InDefinedShape EXIT_TYPING;
/*       */         private final TypeDefinition exitType;
/*       */         
/*       */         static {
/*  4322 */           MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.Exit.class).getDeclaredMethods();
/*  4323 */           EXIT_READ_ONLY = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("readOnly"))).getOnly();
/*  4324 */           EXIT_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Factory(TypeDefinition exitType) {
/*  4338 */           this.exitType = exitType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static Advice.OffsetMapping.Factory<Advice.Exit> of(TypeDefinition typeDefinition) {
/*  4348 */           return typeDefinition.represents(void.class) ? new Advice.OffsetMapping.Factory.Illegal<Advice.Exit>(Advice.Exit.class) : new Factory(typeDefinition);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Class<Advice.Exit> getAnnotationType() {
/*  4357 */           return Advice.Exit.class;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.Exit> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  4366 */           if (adviceType.isDelegation() && !((Boolean)annotation.getValue(EXIT_READ_ONLY).resolve(Boolean.class)).booleanValue()) {
/*  4367 */             throw new IllegalStateException("Cannot use writable " + target + " on read-only parameter");
/*       */           }
/*  4369 */           return new Advice.OffsetMapping.ForExitValue(target.getType(), this.exitType.asGenericType(), annotation);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.exitType.equals(((Factory)param3Object).exitType))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.exitType.hashCode();
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForLocalValue
/*       */       implements OffsetMapping
/*       */     {
/*       */       private final TypeDescription.Generic target;
/*       */ 
/*       */       
/*       */       private final TypeDescription.Generic localType;
/*       */ 
/*       */       
/*       */       private final String name;
/*       */ 
/*       */ 
/*       */       
/*       */       public ForLocalValue(TypeDescription.Generic target, TypeDescription.Generic localType, String name) {
/*  4404 */         this.target = target;
/*  4405 */         this.localType = localType;
/*  4406 */         this.name = name;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  4417 */         StackManipulation readAssignment = assigner.assign(this.localType, this.target, Assigner.Typing.STATIC);
/*  4418 */         StackManipulation writeAssignment = assigner.assign(this.target, this.localType, Assigner.Typing.STATIC);
/*  4419 */         if (!readAssignment.isValid() || !writeAssignment.isValid()) {
/*  4420 */           throw new IllegalStateException("Cannot assign " + this.localType + " to " + this.target);
/*       */         }
/*  4422 */         return new Advice.OffsetMapping.Target.ForVariable.ReadWrite((TypeDefinition)this.target, argumentHandler.named(this.name), readAssignment, writeAssignment);
/*       */       }
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.name.equals(((ForLocalValue)param2Object).name) ? false : (!this.target.equals(((ForLocalValue)param2Object).target) ? false : (!!this.localType.equals(((ForLocalValue)param2Object).localType))))));
/*       */       }
/*       */       
/*       */       public int hashCode() {
/*       */         return ((getClass().hashCode() * 31 + this.target.hashCode()) * 31 + this.localType.hashCode()) * 31 + this.name.hashCode();
/*       */       }
/*       */       
/*       */       @Enhance
/*       */       protected static class Factory implements Advice.OffsetMapping.Factory<Advice.Local> {
/*  4435 */         protected static final MethodDescription.InDefinedShape LOCAL_VALUE = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(Advice.Local.class)
/*  4436 */           .getDeclaredMethods()
/*  4437 */           .filter((ElementMatcher)ElementMatchers.named("value")))
/*  4438 */           .getOnly();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final Map<String, TypeDefinition> namedTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Factory(Map<String, TypeDefinition> namedTypes) {
/*  4451 */           this.namedTypes = namedTypes;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Class<Advice.Local> getAnnotationType() {
/*  4458 */           return Advice.Local.class;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.Local> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  4467 */           String name = (String)annotation.getValue(LOCAL_VALUE).resolve(String.class);
/*  4468 */           TypeDefinition namedType = this.namedTypes.get(name);
/*  4469 */           if (namedType == null) {
/*  4470 */             throw new IllegalStateException("Named local variable is unknown: " + name);
/*       */           }
/*  4472 */           return new Advice.OffsetMapping.ForLocalValue(target.getType(), namedType.asGenericType(), name);
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.namedTypes.equals(((Factory)param3Object).namedTypes))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.namedTypes.hashCode();
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForReturnValue
/*       */       implements OffsetMapping
/*       */     {
/*       */       private final TypeDescription.Generic target;
/*       */ 
/*       */       
/*       */       private final boolean readOnly;
/*       */ 
/*       */       
/*       */       private final Assigner.Typing typing;
/*       */ 
/*       */       
/*       */       protected ForReturnValue(TypeDescription.Generic target, AnnotationDescription.Loadable<Advice.Return> annotation) {
/*  4505 */         this(target, ((Boolean)annotation
/*  4506 */             .getValue(Factory.access$2300()).resolve(Boolean.class)).booleanValue(), (Assigner.Typing)((EnumerationDescription)annotation
/*  4507 */             .getValue(Factory.access$2400()).resolve(EnumerationDescription.class)).load(Assigner.Typing.class));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForReturnValue(TypeDescription.Generic target, boolean readOnly, Assigner.Typing typing) {
/*  4518 */         this.target = target;
/*  4519 */         this.readOnly = readOnly;
/*  4520 */         this.typing = typing;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  4531 */         StackManipulation readAssignment = assigner.assign(instrumentedMethod.getReturnType(), this.target, this.typing);
/*  4532 */         if (!readAssignment.isValid())
/*  4533 */           throw new IllegalStateException("Cannot assign " + instrumentedMethod.getReturnType() + " to " + this.target); 
/*  4534 */         if (this.readOnly) {
/*  4535 */           return instrumentedMethod.getReturnType().represents(void.class) ? new Advice.OffsetMapping.Target.ForDefaultValue.ReadOnly((TypeDefinition)this.target) : new Advice.OffsetMapping.Target.ForVariable.ReadOnly((TypeDefinition)instrumentedMethod
/*       */               
/*  4537 */               .getReturnType(), argumentHandler.returned(), readAssignment);
/*       */         }
/*  4539 */         StackManipulation writeAssignment = assigner.assign(this.target, instrumentedMethod.getReturnType(), this.typing);
/*  4540 */         if (!writeAssignment.isValid()) {
/*  4541 */           throw new IllegalStateException("Cannot assign " + this.target + " to " + instrumentedMethod.getReturnType());
/*       */         }
/*  4543 */         return instrumentedMethod.getReturnType().represents(void.class) ? new Advice.OffsetMapping.Target.ForDefaultValue.ReadWrite((TypeDefinition)this.target) : new Advice.OffsetMapping.Target.ForVariable.ReadWrite((TypeDefinition)instrumentedMethod
/*       */             
/*  4545 */             .getReturnType(), argumentHandler.returned(), readAssignment, writeAssignment);
/*       */       }
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.readOnly != ((ForReturnValue)param2Object).readOnly) ? false : (!this.typing.equals(((ForReturnValue)param2Object).typing) ? false : (!!this.target.equals(((ForReturnValue)param2Object).target))))));
/*       */       }
/*       */       
/*       */       public int hashCode() {
/*       */         return ((getClass().hashCode() * 31 + this.target.hashCode()) * 31 + this.readOnly) * 31 + this.typing.hashCode();
/*       */       }
/*       */       
/*       */       protected enum Factory implements Advice.OffsetMapping.Factory<Advice.Return> {
/*  4557 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape RETURN_TYPING;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape RETURN_READ_ONLY;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         static {
/*  4573 */           MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.Return.class).getDeclaredMethods();
/*  4574 */           RETURN_READ_ONLY = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("readOnly"))).getOnly();
/*  4575 */           RETURN_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Class<Advice.Return> getAnnotationType() {
/*  4582 */           return Advice.Return.class;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.Return> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  4591 */           if (adviceType.isDelegation() && !((Boolean)annotation.getValue(RETURN_READ_ONLY).resolve(Boolean.class)).booleanValue()) {
/*  4592 */             throw new IllegalStateException("Cannot write return value for " + target + " in read-only context");
/*       */           }
/*  4594 */           return new Advice.OffsetMapping.ForReturnValue(target.getType(), annotation);
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForThrowable
/*       */       implements OffsetMapping
/*       */     {
/*       */       private final TypeDescription.Generic target;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final boolean readOnly;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final Assigner.Typing typing;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected ForThrowable(TypeDescription.Generic target, AnnotationDescription.Loadable<Advice.Thrown> annotation) {
/*  4628 */         this(target, ((Boolean)annotation
/*  4629 */             .getValue(Factory.access$2500()).resolve(Boolean.class)).booleanValue(), (Assigner.Typing)((EnumerationDescription)annotation
/*  4630 */             .getValue(Factory.access$2600()).resolve(EnumerationDescription.class)).load(Assigner.Typing.class));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForThrowable(TypeDescription.Generic target, boolean readOnly, Assigner.Typing typing) {
/*  4641 */         this.target = target;
/*  4642 */         this.readOnly = readOnly;
/*  4643 */         this.typing = typing;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  4654 */         StackManipulation readAssignment = assigner.assign(TypeDescription.ForLoadedType.of(Throwable.class).asGenericType(), this.target, this.typing);
/*  4655 */         if (!readAssignment.isValid())
/*  4656 */           throw new IllegalStateException("Cannot assign Throwable to " + this.target); 
/*  4657 */         if (this.readOnly) {
/*  4658 */           return new Advice.OffsetMapping.Target.ForVariable.ReadOnly((TypeDefinition)TypeDescription.ForLoadedType.of(Throwable.class), argumentHandler.thrown(), readAssignment);
/*       */         }
/*  4660 */         StackManipulation writeAssignment = assigner.assign(this.target, TypeDescription.ForLoadedType.of(Throwable.class).asGenericType(), this.typing);
/*  4661 */         if (!writeAssignment.isValid()) {
/*  4662 */           throw new IllegalStateException("Cannot assign " + this.target + " to Throwable");
/*       */         }
/*  4664 */         return new Advice.OffsetMapping.Target.ForVariable.ReadWrite((TypeDefinition)TypeDescription.ForLoadedType.of(Throwable.class), argumentHandler.thrown(), readAssignment, writeAssignment);
/*       */       }
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.readOnly != ((ForThrowable)param2Object).readOnly) ? false : (!this.typing.equals(((ForThrowable)param2Object).typing) ? false : (!!this.target.equals(((ForThrowable)param2Object).target))))));
/*       */       }
/*       */       
/*       */       public int hashCode() {
/*       */         return ((getClass().hashCode() * 31 + this.target.hashCode()) * 31 + this.readOnly) * 31 + this.typing.hashCode();
/*       */       }
/*       */       
/*       */       protected enum Factory implements Advice.OffsetMapping.Factory<Advice.Thrown> {
/*  4676 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape THROWN_TYPING;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private static final MethodDescription.InDefinedShape THROWN_READ_ONLY;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         static {
/*  4692 */           MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.Thrown.class).getDeclaredMethods();
/*  4693 */           THROWN_READ_ONLY = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("readOnly"))).getOnly();
/*  4694 */           THROWN_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.")
/*       */         protected static Advice.OffsetMapping.Factory<?> of(MethodDescription.InDefinedShape adviceMethod) {
/*  4705 */           return 
/*       */ 
/*       */ 
/*       */             
/*  4709 */             ((TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.ON_THROWABLE).resolve(TypeDescription.class)).represents(Advice.NoExceptionHandler.class) ? new Advice.OffsetMapping.Factory.Illegal(Advice.Thrown.class) : INSTANCE;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Class<Advice.Thrown> getAnnotationType() {
/*  4716 */           return Advice.Thrown.class;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<Advice.Thrown> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  4725 */           if (adviceType.isDelegation() && !((Boolean)annotation.getValue(THROWN_READ_ONLY).resolve(Boolean.class)).booleanValue()) {
/*  4726 */             throw new IllegalStateException("Cannot use writable " + target + " on read-only parameter");
/*       */           }
/*  4728 */           return new Advice.OffsetMapping.ForThrowable(target.getType(), annotation);
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForStackManipulation
/*       */       implements OffsetMapping
/*       */     {
/*       */       private final StackManipulation stackManipulation;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TypeDescription.Generic typeDescription;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TypeDescription.Generic targetType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final Assigner.Typing typing;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public ForStackManipulation(StackManipulation stackManipulation, TypeDescription.Generic typeDescription, TypeDescription.Generic targetType, Assigner.Typing typing) {
/*  4772 */         this.stackManipulation = stackManipulation;
/*  4773 */         this.typeDescription = typeDescription;
/*  4774 */         this.targetType = targetType;
/*  4775 */         this.typing = typing;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  4786 */         StackManipulation assignment = assigner.assign(this.typeDescription, this.targetType, this.typing);
/*  4787 */         if (!assignment.isValid()) {
/*  4788 */           throw new IllegalStateException("Cannot assign " + this.typeDescription + " to " + this.targetType);
/*       */         }
/*  4790 */         return new Advice.OffsetMapping.Target.ForStackManipulation((StackManipulation)new StackManipulation.Compound(new StackManipulation[] { this.stackManipulation, assignment }));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.typing.equals(((ForStackManipulation)param2Object).typing) ? false : (!this.stackManipulation.equals(((ForStackManipulation)param2Object).stackManipulation) ? false : (!this.typeDescription.equals(((ForStackManipulation)param2Object).typeDescription) ? false : (!!this.targetType.equals(((ForStackManipulation)param2Object).targetType)))))));
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return (((getClass().hashCode() * 31 + this.stackManipulation.hashCode()) * 31 + this.typeDescription.hashCode()) * 31 + this.targetType.hashCode()) * 31 + this.typing.hashCode();
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Factory<T extends Annotation>
/*       */         implements Advice.OffsetMapping.Factory<T>
/*       */       {
/*       */         private final Class<T> annotationType;
/*       */ 
/*       */         
/*       */         private final StackManipulation stackManipulation;
/*       */ 
/*       */         
/*       */         private final TypeDescription.Generic typeDescription;
/*       */ 
/*       */ 
/*       */         
/*       */         public Factory(Class<T> annotationType, TypeDescription typeDescription) {
/*  4823 */           this(annotationType, ClassConstant.of(typeDescription), TypeDescription.ForLoadedType.of(Class.class).asGenericType());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Factory(Class<T> annotationType, EnumerationDescription enumerationDescription) {
/*  4833 */           this(annotationType, FieldAccess.forEnumeration(enumerationDescription), enumerationDescription.getEnumerationType().asGenericType());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Factory(Class<T> annotationType, ConstantValue constant) {
/*  4843 */           this(annotationType, constant.toStackManipulation(), constant.getTypeDescription().asGenericType());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Factory(Class<T> annotationType, StackManipulation stackManipulation, TypeDescription.Generic typeDescription) {
/*  4854 */           this.annotationType = annotationType;
/*  4855 */           this.stackManipulation = stackManipulation;
/*  4856 */           this.typeDescription = typeDescription;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static <S extends Annotation> Advice.OffsetMapping.Factory<S> of(Class<S> annotationType, @MaybeNull Object value) {
/*  4868 */           return (value == null) ? new Advice.OffsetMapping.ForStackManipulation.OfDefaultValue<S>(annotationType) : new Factory<S>(annotationType, 
/*       */               
/*  4870 */               ConstantValue.Simple.wrap(value));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Class<T> getAnnotationType() {
/*  4877 */           return this.annotationType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  4886 */           return new Advice.OffsetMapping.ForStackManipulation(this.stackManipulation, this.typeDescription, target.getType(), Assigner.Typing.STATIC);
/*       */         }
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.annotationType.equals(((Factory)param3Object).annotationType) ? false : (!this.stackManipulation.equals(((Factory)param3Object).stackManipulation) ? false : (!!this.typeDescription.equals(((Factory)param3Object).typeDescription))))));
/*       */         }
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return ((getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.stackManipulation.hashCode()) * 31 + this.typeDescription.hashCode();
/*       */         }
/*       */       }
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class OfDefaultValue<T extends Annotation>
/*       */         implements Advice.OffsetMapping.Factory<T>
/*       */       {
/*       */         private final Class<T> annotationType;
/*       */ 
/*       */         
/*       */         public OfDefaultValue(Class<T> annotationType) {
/*  4909 */           this.annotationType = annotationType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Class<T> getAnnotationType() {
/*  4916 */           return this.annotationType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  4923 */           return new Advice.OffsetMapping.ForStackManipulation(DefaultValue.of((TypeDefinition)target.getType()), target.getType(), target.getType(), Assigner.Typing.STATIC);
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.annotationType.equals(((OfDefaultValue)param3Object).annotationType))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.annotationType.hashCode();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class OfAnnotationProperty<T extends Annotation>
/*       */         implements Advice.OffsetMapping.Factory<T>
/*       */       {
/*       */         private final Class<T> annotationType;
/*       */ 
/*       */         
/*       */         private final MethodDescription.InDefinedShape property;
/*       */ 
/*       */         
/*       */         protected OfAnnotationProperty(Class<T> annotationType, MethodDescription.InDefinedShape property) {
/*  4952 */           this.annotationType = annotationType;
/*  4953 */           this.property = property;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static <S extends Annotation> Advice.OffsetMapping.Factory<S> of(Class<S> annotationType, String property) {
/*  4965 */           if (!annotationType.isAnnotation()) {
/*  4966 */             throw new IllegalArgumentException("Not an annotation type: " + annotationType);
/*       */           }
/*       */           try {
/*  4969 */             return new OfAnnotationProperty<S>(annotationType, (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(annotationType.getMethod(property, new Class[0])));
/*  4970 */           } catch (NoSuchMethodException exception) {
/*  4971 */             throw new IllegalArgumentException("Cannot find a property " + property + " on " + annotationType, exception);
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Class<T> getAnnotationType() {
/*  4979 */           return this.annotationType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  4986 */           ConstantValue value = ConstantValue.Simple.wrapOrNull(annotation.getValue(this.property).resolve());
/*  4987 */           if (value == null) {
/*  4988 */             throw new IllegalStateException("Property does not represent a constant value: " + this.property);
/*       */           }
/*  4990 */           return new Advice.OffsetMapping.ForStackManipulation(value.toStackManipulation(), value
/*  4991 */               .getTypeDescription().asGenericType(), target
/*  4992 */               .getType(), Assigner.Typing.STATIC);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.annotationType.equals(((OfAnnotationProperty)param3Object).annotationType) ? false : (!!this.property.equals(((OfAnnotationProperty)param3Object).property)))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return (getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.property.hashCode();
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class OfDynamicInvocation<T extends Annotation>
/*       */         implements Advice.OffsetMapping.Factory<T>
/*       */       {
/*       */         private final Class<T> annotationType;
/*       */ 
/*       */         
/*       */         private final MethodDescription.InDefinedShape bootstrapMethod;
/*       */ 
/*       */         
/*       */         private final List<? extends JavaConstant> arguments;
/*       */ 
/*       */ 
/*       */         
/*       */         public OfDynamicInvocation(Class<T> annotationType, MethodDescription.InDefinedShape bootstrapMethod, List<? extends JavaConstant> arguments) {
/*  5028 */           this.annotationType = annotationType;
/*  5029 */           this.bootstrapMethod = bootstrapMethod;
/*  5030 */           this.arguments = arguments;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Class<T> getAnnotationType() {
/*  5037 */           return this.annotationType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  5044 */           if (!target.getType().isInterface())
/*  5045 */             throw new IllegalArgumentException(target.getType() + " is not an interface"); 
/*  5046 */           if (!target.getType().getInterfaces().isEmpty())
/*  5047 */             throw new IllegalArgumentException(target.getType() + " must not extend other interfaces"); 
/*  5048 */           if (!target.getType().isPublic()) {
/*  5049 */             throw new IllegalArgumentException(target.getType() + " is mot public");
/*       */           }
/*  5051 */           MethodList<?> methodCandidates = (MethodList)target.getType().getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isAbstract());
/*  5052 */           if (methodCandidates.size() != 1) {
/*  5053 */             throw new IllegalArgumentException(target.getType() + " must declare exactly one abstract method");
/*       */           }
/*  5055 */           return new Advice.OffsetMapping.ForStackManipulation(MethodInvocation.invoke(this.bootstrapMethod).dynamic(((MethodDescription)methodCandidates.getOnly()).getInternalName(), target
/*  5056 */                 .getType().asErasure(), 
/*  5057 */                 Collections.emptyList(), this.arguments), target
/*  5058 */               .getType(), target.getType(), Assigner.Typing.STATIC);
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.annotationType.equals(((OfDynamicInvocation)param3Object).annotationType) ? false : (!this.bootstrapMethod.equals(((OfDynamicInvocation)param3Object).bootstrapMethod) ? false : (!!this.arguments.equals(((OfDynamicInvocation)param3Object).arguments))))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return ((getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.bootstrapMethod.hashCode()) * 31 + this.arguments.hashCode();
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForSerializedValue
/*       */       implements OffsetMapping
/*       */     {
/*       */       private final TypeDescription.Generic target;
/*       */ 
/*       */       
/*       */       private final TypeDescription typeDescription;
/*       */ 
/*       */       
/*       */       private final StackManipulation deserialization;
/*       */ 
/*       */ 
/*       */       
/*       */       public ForSerializedValue(TypeDescription.Generic target, TypeDescription typeDescription, StackManipulation deserialization) {
/*  5092 */         this.target = target;
/*  5093 */         this.typeDescription = typeDescription;
/*  5094 */         this.deserialization = deserialization;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.OffsetMapping.Target resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.OffsetMapping.Sort sort) {
/*  5105 */         StackManipulation assignment = assigner.assign(this.typeDescription.asGenericType(), this.target, Assigner.Typing.DYNAMIC);
/*  5106 */         if (!assignment.isValid()) {
/*  5107 */           throw new IllegalStateException("Cannot assign " + this.typeDescription + " to " + this.target);
/*       */         }
/*  5109 */         return new Advice.OffsetMapping.Target.ForStackManipulation((StackManipulation)new StackManipulation.Compound(new StackManipulation[] { this.deserialization, assignment }));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.target.equals(((ForSerializedValue)param2Object).target) ? false : (!this.typeDescription.equals(((ForSerializedValue)param2Object).typeDescription) ? false : (!!this.deserialization.equals(((ForSerializedValue)param2Object).deserialization))))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return ((getClass().hashCode() * 31 + this.target.hashCode()) * 31 + this.typeDescription.hashCode()) * 31 + this.deserialization.hashCode();
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Factory<T extends Annotation>
/*       */         implements Advice.OffsetMapping.Factory<T>
/*       */       {
/*       */         private final Class<T> annotationType;
/*       */ 
/*       */         
/*       */         private final TypeDescription typeDescription;
/*       */ 
/*       */         
/*       */         private final StackManipulation deserialization;
/*       */ 
/*       */ 
/*       */         
/*       */         protected Factory(Class<T> annotationType, TypeDescription typeDescription, StackManipulation deserialization) {
/*  5143 */           this.annotationType = annotationType;
/*  5144 */           this.typeDescription = typeDescription;
/*  5145 */           this.deserialization = deserialization;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public static <S extends Annotation, U extends Serializable> Advice.OffsetMapping.Factory<S> of(Class<S> annotationType, U target, Class<? super U> targetType) {
/*  5159 */           if (!targetType.isInstance(target)) {
/*  5160 */             throw new IllegalArgumentException((new StringBuilder()).append(target).append(" is no instance of ").append(targetType).toString());
/*       */           }
/*  5162 */           return new Factory<S>(annotationType, TypeDescription.ForLoadedType.of(targetType), SerializedConstant.of((Serializable)target));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Class<T> getAnnotationType() {
/*  5169 */           return this.annotationType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.OffsetMapping make(ParameterDescription.InDefinedShape target, AnnotationDescription.Loadable<T> annotation, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  5176 */           return new Advice.OffsetMapping.ForSerializedValue(target.getType(), this.typeDescription, this.deserialization);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.annotationType.equals(((Factory)param3Object).annotationType) ? false : (!this.typeDescription.equals(((Factory)param3Object).typeDescription) ? false : (!!this.deserialization.equals(((Factory)param3Object).deserialization))))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return ((getClass().hashCode() * 31 + this.annotationType.hashCode()) * 31 + this.typeDescription.hashCode()) * 31 + this.deserialization.hashCode();
/*       */         }
/*       */       }
/*       */     } }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface ArgumentHandler
/*       */   {
/*       */     public static final int THIS_REFERENCE = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int argument(int param1Int);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int exit();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int enter();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int named(String param1String);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int returned();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int thrown();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface ForInstrumentedMethod
/*       */       extends ArgumentHandler
/*       */     {
/*       */       int prepare(MethodVisitor param2MethodVisitor);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Advice.ArgumentHandler.ForAdvice bindEnter(MethodDescription.TypeToken param2TypeToken);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Advice.ArgumentHandler.ForAdvice bindExit(MethodDescription.TypeToken param2TypeToken, boolean param2Boolean);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       boolean isCopyingArguments();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       List<TypeDescription> getNamedTypes();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static abstract class Default
/*       */         implements ForInstrumentedMethod
/*       */       {
/*       */         protected final MethodDescription instrumentedMethod;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final TypeDefinition exitType;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final SortedMap<String, TypeDefinition> namedTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final TypeDefinition enterType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Default(MethodDescription instrumentedMethod, TypeDefinition exitType, SortedMap<String, TypeDefinition> namedTypes, TypeDefinition enterType) {
/*  5317 */           this.instrumentedMethod = instrumentedMethod;
/*  5318 */           this.namedTypes = namedTypes;
/*  5319 */           this.exitType = exitType;
/*  5320 */           this.enterType = enterType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int exit() {
/*  5327 */           return this.instrumentedMethod.getStackSize();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int named(String name) {
/*  5334 */           return this.instrumentedMethod.getStackSize() + this.exitType
/*  5335 */             .getStackSize().getSize() + 
/*  5336 */             StackSize.of(this.namedTypes.headMap(name).values());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int enter() {
/*  5343 */           return this.instrumentedMethod.getStackSize() + this.exitType
/*  5344 */             .getStackSize().getSize() + 
/*  5345 */             StackSize.of(this.namedTypes.values());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int returned() {
/*  5352 */           return this.instrumentedMethod.getStackSize() + this.exitType
/*  5353 */             .getStackSize().getSize() + 
/*  5354 */             StackSize.of(this.namedTypes.values()) + this.enterType
/*  5355 */             .getStackSize().getSize();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int thrown() {
/*  5362 */           return this.instrumentedMethod.getStackSize() + this.exitType
/*  5363 */             .getStackSize().getSize() + 
/*  5364 */             StackSize.of(this.namedTypes.values()) + this.enterType
/*  5365 */             .getStackSize().getSize() + this.instrumentedMethod
/*  5366 */             .getReturnType().getStackSize().getSize();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.ArgumentHandler.ForAdvice bindEnter(MethodDescription.TypeToken typeToken) {
/*  5373 */           return new Advice.ArgumentHandler.ForAdvice.Default.ForMethodEnter(this.instrumentedMethod, typeToken, this.exitType, this.namedTypes);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.ArgumentHandler.ForAdvice bindExit(MethodDescription.TypeToken typeToken, boolean skipThrowable) {
/*  5380 */           return new Advice.ArgumentHandler.ForAdvice.Default.ForMethodExit(this.instrumentedMethod, typeToken, this.exitType, this.namedTypes, this.enterType, skipThrowable ? StackSize.ZERO : StackSize.SINGLE);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public List<TypeDescription> getNamedTypes() {
/*  5392 */           List<TypeDescription> namedTypes = new ArrayList<TypeDescription>(this.namedTypes.size());
/*  5393 */           for (TypeDefinition typeDefinition : this.namedTypes.values()) {
/*  5394 */             namedTypes.add(typeDefinition.asErasure());
/*       */           }
/*  5396 */           return namedTypes;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         protected static class Simple
/*       */           extends Default
/*       */         {
/*       */           protected Simple(MethodDescription instrumentedMethod, TypeDefinition exitType, SortedMap<String, TypeDefinition> namedTypes, TypeDefinition enterType) {
/*  5417 */             super(instrumentedMethod, exitType, namedTypes, enterType);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int argument(int offset) {
/*  5424 */             return (offset < this.instrumentedMethod.getStackSize()) ? offset : (offset + this.exitType
/*       */               
/*  5426 */               .getStackSize().getSize() + StackSize.of(this.namedTypes.values()) + this.enterType.getStackSize().getSize());
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean isCopyingArguments() {
/*  5433 */             return false;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int prepare(MethodVisitor methodVisitor) {
/*  5440 */             return 0;
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : (!(getClass() != param4Object.getClass())));
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode();
/*       */           }
/*       */         }
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         protected static class Copying
/*       */           extends Default
/*       */         {
/*       */           protected Copying(MethodDescription instrumentedMethod, TypeDefinition exitType, SortedMap<String, TypeDefinition> namedTypes, TypeDefinition enterType) {
/*  5462 */             super(instrumentedMethod, exitType, namedTypes, enterType);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int argument(int offset) {
/*  5469 */             return this.instrumentedMethod.getStackSize() + this.exitType
/*  5470 */               .getStackSize().getSize() + 
/*  5471 */               StackSize.of(this.namedTypes.values()) + this.enterType
/*  5472 */               .getStackSize().getSize() + offset;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean isCopyingArguments() {
/*  5480 */             return true;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int prepare(MethodVisitor methodVisitor) {
/*       */             StackSize stackSize;
/*  5488 */             if (!this.instrumentedMethod.isStatic()) {
/*  5489 */               methodVisitor.visitVarInsn(25, 0);
/*  5490 */               methodVisitor.visitVarInsn(58, this.instrumentedMethod.getStackSize() + this.exitType
/*  5491 */                   .getStackSize().getSize() + 
/*  5492 */                   StackSize.of(this.namedTypes.values()) + this.enterType
/*  5493 */                   .getStackSize().getSize());
/*  5494 */               stackSize = StackSize.SINGLE;
/*       */             } else {
/*  5496 */               stackSize = StackSize.ZERO;
/*       */             } 
/*  5498 */             for (ParameterDescription parameterDescription : this.instrumentedMethod.getParameters()) {
/*  5499 */               Type type = Type.getType(parameterDescription.getType().asErasure().getDescriptor());
/*  5500 */               methodVisitor.visitVarInsn(type.getOpcode(21), parameterDescription.getOffset());
/*  5501 */               methodVisitor.visitVarInsn(type.getOpcode(54), this.instrumentedMethod.getStackSize() + this.exitType
/*  5502 */                   .getStackSize().getSize() + 
/*  5503 */                   StackSize.of(this.namedTypes.values()) + this.enterType
/*  5504 */                   .getStackSize().getSize() + parameterDescription
/*  5505 */                   .getOffset());
/*  5506 */               stackSize = stackSize.maximum(parameterDescription.getType().getStackSize());
/*       */             } 
/*  5508 */             return stackSize.getSize();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : (!(getClass() != param4Object.getClass())));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode();
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface ForAdvice
/*       */       extends ArgumentHandler
/*       */     {
/*       */       int mapped(int param2Int);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static abstract class Default
/*       */         implements ForAdvice
/*       */       {
/*       */         protected final MethodDescription instrumentedMethod;
/*       */ 
/*       */ 
/*       */         
/*       */         protected final MethodDescription.TypeToken typeToken;
/*       */ 
/*       */ 
/*       */         
/*       */         protected final TypeDefinition exitType;
/*       */ 
/*       */ 
/*       */         
/*       */         protected final SortedMap<String, TypeDefinition> namedTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Default(MethodDescription instrumentedMethod, MethodDescription.TypeToken typeToken, TypeDefinition exitType, SortedMap<String, TypeDefinition> namedTypes) {
/*  5564 */           this.instrumentedMethod = instrumentedMethod;
/*  5565 */           this.typeToken = typeToken;
/*  5566 */           this.exitType = exitType;
/*  5567 */           this.namedTypes = namedTypes;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int argument(int offset) {
/*  5574 */           return offset;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int exit() {
/*  5581 */           return this.instrumentedMethod.getStackSize();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int named(String name) {
/*  5588 */           return this.instrumentedMethod.getStackSize() + this.exitType
/*  5589 */             .getStackSize().getSize() + 
/*  5590 */             StackSize.of(this.namedTypes.headMap(name).values());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int enter() {
/*  5597 */           return this.instrumentedMethod.getStackSize() + this.exitType
/*  5598 */             .getStackSize().getSize() + 
/*  5599 */             StackSize.of(this.namedTypes.values());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         protected static class ForMethodEnter
/*       */           extends Default
/*       */         {
/*       */           protected ForMethodEnter(MethodDescription instrumentedMethod, MethodDescription.TypeToken typeToken, TypeDefinition exitType, SortedMap<String, TypeDefinition> namedTypes) {
/*  5620 */             super(instrumentedMethod, typeToken, exitType, namedTypes);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int returned() {
/*  5627 */             throw new IllegalStateException("Cannot resolve the return value offset during enter advice");
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int thrown() {
/*  5634 */             throw new IllegalStateException("Cannot resolve the thrown value offset during enter advice");
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int mapped(int offset) {
/*  5641 */             return this.instrumentedMethod.getStackSize() + this.exitType
/*  5642 */               .getStackSize().getSize() + 
/*  5643 */               StackSize.of(this.namedTypes.values()) - 
/*  5644 */               StackSize.of(this.typeToken.getParameterTypes()) + offset;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : (!(getClass() != param4Object.getClass())));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode();
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         protected static class ForMethodExit
/*       */           extends Default
/*       */         {
/*       */           private final TypeDefinition enterType;
/*       */ 
/*       */ 
/*       */           
/*       */           private final StackSize throwableSize;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected ForMethodExit(MethodDescription instrumentedMethod, MethodDescription.TypeToken typeToken, TypeDefinition exitType, SortedMap<String, TypeDefinition> namedTypes, TypeDefinition enterType, StackSize throwableSize) {
/*  5680 */             super(instrumentedMethod, typeToken, exitType, namedTypes);
/*  5681 */             this.enterType = enterType;
/*  5682 */             this.throwableSize = throwableSize;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int returned() {
/*  5689 */             return this.instrumentedMethod.getStackSize() + this.exitType
/*  5690 */               .getStackSize().getSize() + 
/*  5691 */               StackSize.of(this.namedTypes.values()) + this.enterType
/*  5692 */               .getStackSize().getSize();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int thrown() {
/*  5699 */             return this.instrumentedMethod.getStackSize() + this.exitType
/*  5700 */               .getStackSize().getSize() + 
/*  5701 */               StackSize.of(this.namedTypes.values()) + this.enterType
/*  5702 */               .getStackSize().getSize() + this.instrumentedMethod
/*  5703 */               .getReturnType().getStackSize().getSize();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int mapped(int offset) {
/*  5710 */             return this.instrumentedMethod.getStackSize() + this.exitType
/*  5711 */               .getStackSize().getSize() + 
/*  5712 */               StackSize.of(this.namedTypes.values()) + this.enterType
/*  5713 */               .getStackSize().getSize() + this.instrumentedMethod
/*  5714 */               .getReturnType().getStackSize().getSize() + this.throwableSize
/*  5715 */               .getSize() - 
/*  5716 */               StackSize.of(this.typeToken.getParameterTypes()) + offset;
/*       */           }
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.throwableSize.equals(((ForMethodExit)param4Object).throwableSize) ? false : (!!this.enterType.equals(((ForMethodExit)param4Object).enterType)))));
/*       */           }
/*       */           
/*       */           public int hashCode() {
/*       */             return (getClass().hashCode() * 31 + this.enterType.hashCode()) * 31 + this.throwableSize.hashCode();
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */     
/*       */     public enum Factory {
/*  5731 */       SIMPLE
/*       */       {
/*       */ 
/*       */         
/*       */         protected Advice.ArgumentHandler.ForInstrumentedMethod resolve(MethodDescription instrumentedMethod, TypeDefinition enterType, TypeDefinition exitType, SortedMap<String, TypeDefinition> namedTypes)
/*       */         {
/*  5737 */           return new Advice.ArgumentHandler.ForInstrumentedMethod.Default.Simple(instrumentedMethod, exitType, namedTypes, enterType);
/*       */         }
/*       */       },
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5747 */       COPYING
/*       */       {
/*       */ 
/*       */         
/*       */         protected Advice.ArgumentHandler.ForInstrumentedMethod resolve(MethodDescription instrumentedMethod, TypeDefinition enterType, TypeDefinition exitType, SortedMap<String, TypeDefinition> namedTypes)
/*       */         {
/*  5753 */           return new Advice.ArgumentHandler.ForInstrumentedMethod.Default.Copying(instrumentedMethod, exitType, namedTypes, enterType);
/*       */         }
/*       */       };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract Advice.ArgumentHandler.ForInstrumentedMethod resolve(MethodDescription param2MethodDescription, TypeDefinition param2TypeDefinition1, TypeDefinition param2TypeDefinition2, SortedMap<String, TypeDefinition> param2SortedMap);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface Factory
/*       */   {
/*       */     Advice.PostProcessor make(List<? extends AnnotationDescription> param1List, TypeDescription param1TypeDescription, boolean param1Boolean);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class Compound
/*       */       implements Factory
/*       */     {
/*       */       public Compound(Advice.PostProcessor.Factory... factory) {
/*  5845 */         this(Arrays.asList(factory));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  5854 */       private final List<Advice.PostProcessor.Factory> factories = new ArrayList<Advice.PostProcessor.Factory>(); public Compound(List<? extends Advice.PostProcessor.Factory> factories) {
/*  5855 */         for (Advice.PostProcessor.Factory factory : factories) {
/*  5856 */           if (factory instanceof Compound) {
/*  5857 */             this.factories.addAll(((Compound)factory).factories); continue;
/*  5858 */           }  if (!(factory instanceof Advice.PostProcessor.NoOp)) {
/*  5859 */             this.factories.add(factory);
/*       */           }
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.PostProcessor make(List<? extends AnnotationDescription> annotations, TypeDescription returnType, boolean exit) {
/*  5868 */         List<Advice.PostProcessor> postProcessors = new ArrayList<Advice.PostProcessor>(this.factories.size());
/*  5869 */         for (Advice.PostProcessor.Factory factory : this.factories) {
/*  5870 */           postProcessors.add(factory.make(annotations, returnType, exit));
/*       */         }
/*  5872 */         return new Advice.PostProcessor.Compound(postProcessors);
/*       */       }
/*       */       
/*       */       public boolean equals(@MaybeNull Object param3Object) {
/*       */         return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.factories.equals(((Compound)param3Object).factories))));
/*       */       }
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.factories.hashCode();
/*       */       }
/*       */     }
/*       */   }
/*       */   
/*  5885 */   public enum NoOp implements PostProcessor, PostProcessor.Factory { INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public StackManipulation resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.StackMapFrameHandler.ForPostProcessor stackMapFrameHandler, StackManipulation exceptionHandler) {
/*  5896 */       return (StackManipulation)StackManipulation.Trivial.INSTANCE;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     public Advice.PostProcessor make(List<? extends AnnotationDescription> annotations, TypeDescription returnType, boolean exit)
/*       */     {
/*  5903 */       return this; } } public static interface PostProcessor { StackManipulation resolve(TypeDescription param1TypeDescription, MethodDescription param1MethodDescription, Assigner param1Assigner, Advice.ArgumentHandler param1ArgumentHandler, Advice.StackMapFrameHandler.ForPostProcessor param1ForPostProcessor, StackManipulation param1StackManipulation); public static interface Factory { Advice.PostProcessor make(List<? extends AnnotationDescription> param2List, TypeDescription param2TypeDescription, boolean param2Boolean); @Enhance public static class Compound implements Factory { public Compound(Advice.PostProcessor.Factory... factory) { this(Arrays.asList(factory)); } private final List<Advice.PostProcessor.Factory> factories = new ArrayList<Advice.PostProcessor.Factory>(); public Compound(List<? extends Advice.PostProcessor.Factory> factories) { for (Advice.PostProcessor.Factory factory : factories) { if (factory instanceof Compound) { this.factories.addAll(((Compound)factory).factories); continue; }  if (!(factory instanceof Advice.PostProcessor.NoOp)) this.factories.add(factory);  }  } public Advice.PostProcessor make(List<? extends AnnotationDescription> annotations, TypeDescription returnType, boolean exit) { List<Advice.PostProcessor> postProcessors = new ArrayList<Advice.PostProcessor>(this.factories.size()); for (Advice.PostProcessor.Factory factory : this.factories) postProcessors.add(factory.make(annotations, returnType, exit));  return new Advice.PostProcessor.Compound(postProcessors); } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.factories.equals(((Compound)param3Object).factories)))); } public int hashCode() { return getClass().hashCode() * 31 + this.factories.hashCode(); } } } public enum NoOp implements PostProcessor, Factory { INSTANCE; public StackManipulation resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.StackMapFrameHandler.ForPostProcessor stackMapFrameHandler, StackManipulation exceptionHandler) { return (StackManipulation)StackManipulation.Trivial.INSTANCE; } public Advice.PostProcessor make(List<? extends AnnotationDescription> annotations, TypeDescription returnType, boolean exit) { return this; }
/*       */        }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class Compound
/*       */       implements PostProcessor
/*       */     {
/*       */       private final List<Advice.PostProcessor> postProcessors;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected Compound(List<Advice.PostProcessor> postProcessors) {
/*  5924 */         this.postProcessors = postProcessors;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public StackManipulation resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.StackMapFrameHandler.ForPostProcessor stackMapFrameHandler, StackManipulation exceptionHandler) {
/*  5936 */         List<StackManipulation> stackManipulations = new ArrayList<StackManipulation>(this.postProcessors.size());
/*  5937 */         for (Advice.PostProcessor postProcessor : this.postProcessors) {
/*  5938 */           stackManipulations.add(postProcessor.resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, stackMapFrameHandler, exceptionHandler));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  5945 */         return (StackManipulation)new StackManipulation.Compound(stackManipulations);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.postProcessors.equals(((Compound)param2Object).postProcessors))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return getClass().hashCode() * 31 + this.postProcessors.hashCode();
/*       */       }
/*       */     } }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Enhance
/*       */   public static class ForRegularInvocation
/*       */     implements Delegator
/*       */   {
/*       */     private final MethodDescription.InDefinedShape adviceMethod;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected ForRegularInvocation(MethodDescription.InDefinedShape adviceMethod) {
/*  6011 */       this.adviceMethod = adviceMethod;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public StackManipulation apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/*  6018 */       return (StackManipulation)MethodInvocation.invoke(this.adviceMethod);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public MethodDescription.TypeToken getTypeToken() {
/*  6025 */       return this.adviceMethod.asTypeToken();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public void assertVisibility(TypeDescription instrumentedType) {
/*  6032 */       if (!this.adviceMethod.isVisibleTo(instrumentedType))
/*  6033 */         throw new IllegalStateException(this.adviceMethod + " is not visible to " + instrumentedType); 
/*       */     }
/*       */     
/*       */     public boolean equals(@MaybeNull Object param1Object) {
/*       */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.adviceMethod.equals(((ForRegularInvocation)param1Object).adviceMethod))));
/*       */     }
/*       */     
/*       */     public int hashCode() {
/*       */       return getClass().hashCode() * 31 + this.adviceMethod.hashCode();
/*       */     }
/*       */     
/*       */     protected enum Factory implements Advice.Delegator.Factory {
/*  6045 */       INSTANCE;
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.Delegator make(MethodDescription.InDefinedShape adviceMethod, boolean exit)
/*       */       {
/*  6051 */         return new Advice.Delegator.ForRegularInvocation(adviceMethod); } } } protected enum Factory implements Delegator.Factory { INSTANCE; public Advice.Delegator make(MethodDescription.InDefinedShape adviceMethod, boolean exit) { return new Advice.Delegator.ForRegularInvocation(adviceMethod); } } protected static interface Delegator { StackManipulation apply(TypeDescription param1TypeDescription, MethodDescription param1MethodDescription); MethodDescription.TypeToken getTypeToken(); void assertVisibility(TypeDescription param1TypeDescription); public static interface Factory { Advice.Delegator make(MethodDescription.InDefinedShape param2InDefinedShape, boolean param2Boolean); } @Enhance public static class ForRegularInvocation implements Delegator { private final MethodDescription.InDefinedShape adviceMethod; protected ForRegularInvocation(MethodDescription.InDefinedShape adviceMethod) { this.adviceMethod = adviceMethod; } public StackManipulation apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) { return (StackManipulation)MethodInvocation.invoke(this.adviceMethod); } public MethodDescription.TypeToken getTypeToken() { return this.adviceMethod.asTypeToken(); } public void assertVisibility(TypeDescription instrumentedType) { if (!this.adviceMethod.isVisibleTo(instrumentedType)) throw new IllegalStateException(this.adviceMethod + " is not visible to " + instrumentedType);  } public boolean equals(@MaybeNull Object param2Object) { return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.adviceMethod.equals(((ForRegularInvocation)param2Object).adviceMethod)))); } public int hashCode() { return getClass().hashCode() * 31 + this.adviceMethod.hashCode(); } protected enum Factory implements Advice.Delegator.Factory { INSTANCE; public Advice.Delegator make(MethodDescription.InDefinedShape adviceMethod, boolean exit) { return new Advice.Delegator.ForRegularInvocation(adviceMethod); }
/*       */          }
/*       */        }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForDynamicInvocation
/*       */       implements Delegator
/*       */     {
/*       */       private final MethodDescription.InDefinedShape bootstrapMethod;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final MethodDescription.SignatureToken signatureToken;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final Advice.BootstrapArgumentResolver resolver;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected ForDynamicInvocation(MethodDescription.InDefinedShape bootstrapMethod, MethodDescription.SignatureToken signatureToken, Advice.BootstrapArgumentResolver resolver) {
/*  6087 */         this.bootstrapMethod = bootstrapMethod;
/*  6088 */         this.signatureToken = signatureToken;
/*  6089 */         this.resolver = resolver;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static Advice.Delegator.Factory of(MethodDescription.InDefinedShape bootstrapMethod, Advice.BootstrapArgumentResolver.Factory resolverFactory, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/*  6107 */         if (!bootstrapMethod.isInvokeBootstrap()) {
/*  6108 */           throw new IllegalArgumentException("Not a suitable bootstrap target: " + bootstrapMethod);
/*       */         }
/*  6110 */         return new Factory(bootstrapMethod, resolverFactory, visitor);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public StackManipulation apply(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/*  6117 */         List<JavaConstant> constants = this.resolver.resolve(instrumentedType, instrumentedMethod);
/*  6118 */         if (!this.bootstrapMethod.isInvokeBootstrap((List)TypeList.Explicit.of(constants))) {
/*  6119 */           throw new IllegalStateException("Cannot invoke " + this.bootstrapMethod + " with arguments: " + constants);
/*       */         }
/*  6121 */         return MethodInvocation.invoke(this.bootstrapMethod).dynamic(this.signatureToken.getName(), this.signatureToken
/*  6122 */             .getReturnType(), this.signatureToken
/*  6123 */             .getParameterTypes(), constants);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public MethodDescription.TypeToken getTypeToken() {
/*  6131 */         return this.signatureToken.asTypeToken();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void assertVisibility(TypeDescription instrumentedType) {
/*  6138 */         if (!this.bootstrapMethod.isVisibleTo(instrumentedType)) {
/*  6139 */           throw new IllegalStateException(this.bootstrapMethod + " is not visible to " + instrumentedType);
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.bootstrapMethod.equals(((ForDynamicInvocation)param2Object).bootstrapMethod) ? false : (!this.signatureToken.equals(((ForDynamicInvocation)param2Object).signatureToken) ? false : (!!this.resolver.equals(((ForDynamicInvocation)param2Object).resolver))))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return ((getClass().hashCode() * 31 + this.bootstrapMethod.hashCode()) * 31 + this.signatureToken.hashCode()) * 31 + this.resolver.hashCode();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       protected static class Factory
/*       */         implements Advice.Delegator.Factory
/*       */       {
/*       */         private final MethodDescription.InDefinedShape bootstrapMethod;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final Advice.BootstrapArgumentResolver.Factory resolverFactory;
/*       */ 
/*       */ 
/*       */         
/*       */         private final TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Factory(MethodDescription.InDefinedShape bootstrapMethod, Advice.BootstrapArgumentResolver.Factory resolverFactory, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/*  6182 */           this.bootstrapMethod = bootstrapMethod;
/*  6183 */           this.resolverFactory = resolverFactory;
/*  6184 */           this.visitor = visitor;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.Delegator make(MethodDescription.InDefinedShape adviceMethod, boolean exit) {
/*  6191 */           return new Advice.Delegator.ForDynamicInvocation(this.bootstrapMethod, new MethodDescription.SignatureToken(adviceMethod
/*  6192 */                 .getInternalName(), ((TypeDescription.Generic)adviceMethod
/*  6193 */                 .getReturnType().accept(this.visitor)).asErasure(), (List)adviceMethod
/*  6194 */                 .getParameters().asTypeList().accept(this.visitor).asErasures()), this.resolverFactory
/*  6195 */               .resolve(adviceMethod, exit));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.bootstrapMethod.equals(((Factory)param3Object).bootstrapMethod) ? false : (!this.resolverFactory.equals(((Factory)param3Object).resolverFactory) ? false : (!!this.visitor.equals(((Factory)param3Object).visitor))))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return ((getClass().hashCode() * 31 + this.bootstrapMethod.hashCode()) * 31 + this.resolverFactory.hashCode()) * 31 + this.visitor.hashCode();
/*       */         }
/*       */       }
/*       */     } }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface BootstrapArgumentResolver
/*       */   {
/*       */     List<JavaConstant> resolve(TypeDescription param1TypeDescription, MethodDescription param1MethodDescription);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class ForDefaultValues
/*       */       implements BootstrapArgumentResolver
/*       */     {
/*       */       private final MethodDescription.InDefinedShape adviceMethod;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final boolean exit;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected ForDefaultValues(MethodDescription.InDefinedShape adviceMethod, boolean exit) {
/*  6260 */         this.adviceMethod = adviceMethod;
/*  6261 */         this.exit = exit;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public List<JavaConstant> resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod) {
/*  6268 */         if (instrumentedMethod.isTypeInitializer()) {
/*  6269 */           return Arrays.asList(new JavaConstant[] { JavaConstant.Simple.ofLoaded(this.adviceMethod.getDeclaringType().getName()), 
/*  6270 */                 JavaConstant.Simple.ofLoaded(Integer.valueOf(this.exit ? 1 : 0)), 
/*  6271 */                 JavaConstant.Simple.of(instrumentedType), 
/*  6272 */                 JavaConstant.Simple.ofLoaded(instrumentedMethod.getInternalName()) });
/*       */         }
/*  6274 */         return Arrays.asList(new JavaConstant[] { JavaConstant.Simple.ofLoaded(this.adviceMethod.getDeclaringType().getName()), 
/*  6275 */               JavaConstant.Simple.ofLoaded(Integer.valueOf(this.exit ? 1 : 0)), 
/*  6276 */               JavaConstant.Simple.of(instrumentedType), 
/*  6277 */               JavaConstant.Simple.ofLoaded(instrumentedMethod.getInternalName()), 
/*  6278 */               (JavaConstant)JavaConstant.MethodHandle.of((MethodDescription.InDefinedShape)instrumentedMethod.asDefined()) });
/*       */       }
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.exit != ((ForDefaultValues)param2Object).exit) ? false : (!!this.adviceMethod.equals(((ForDefaultValues)param2Object).adviceMethod)))));
/*       */       }
/*       */       
/*       */       public int hashCode() {
/*       */         return (getClass().hashCode() * 31 + this.adviceMethod.hashCode()) * 31 + this.exit;
/*       */       }
/*       */       
/*       */       public enum Factory implements Advice.BootstrapArgumentResolver.Factory {
/*  6290 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.BootstrapArgumentResolver resolve(MethodDescription.InDefinedShape adviceMethod, boolean exit) {
/*  6296 */           return new Advice.BootstrapArgumentResolver.ForDefaultValues(adviceMethod, exit);
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface Factory
/*       */     {
/*       */       Advice.BootstrapArgumentResolver resolve(MethodDescription.InDefinedShape param2InDefinedShape, boolean param2Boolean);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected static interface MethodSizeHandler
/*       */   {
/*       */     public static final int UNDEFINED_SIZE = 32767;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     void requireStackSize(int param1Int);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     void requireLocalVariableLength(int param1Int);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface ForInstrumentedMethod
/*       */       extends MethodSizeHandler
/*       */     {
/*       */       Advice.MethodSizeHandler.ForAdvice bindEnter(MethodDescription.TypeToken param2TypeToken);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Advice.MethodSizeHandler.ForAdvice bindExit(MethodDescription.TypeToken param2TypeToken);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       int compoundStackSize(int param2Int);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       int compoundLocalVariableLength(int param2Int);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface ForAdvice
/*       */       extends MethodSizeHandler
/*       */     {
/*       */       void requireStackSizePadding(int param2Int);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       void requireLocalVariableLengthPadding(int param2Int);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       void recordMaxima(int param2Int1, int param2Int2);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum NoOp
/*       */       implements ForInstrumentedMethod, ForAdvice
/*       */     {
/*  6401 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.MethodSizeHandler.ForAdvice bindEnter(MethodDescription.TypeToken typeToken) {
/*  6407 */         return this;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.MethodSizeHandler.ForAdvice bindExit(MethodDescription.TypeToken typeToken) {
/*  6414 */         return this;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int compoundStackSize(int stackSize) {
/*  6421 */         return 32767;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int compoundLocalVariableLength(int localVariableLength) {
/*  6428 */         return 32767;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void requireStackSize(int stackSize) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void requireLocalVariableLength(int localVariableLength) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void requireStackSizePadding(int stackSizePadding) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void requireLocalVariableLengthPadding(int localVariableLengthPadding) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void recordMaxima(int stackSize, int localVariableLength) {}
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static abstract class Default
/*       */       implements ForInstrumentedMethod
/*       */     {
/*       */       protected final MethodDescription instrumentedMethod;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final List<? extends TypeDescription> initialTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final List<? extends TypeDescription> preMethodTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final List<? extends TypeDescription> postMethodTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected int stackSize;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected int localVariableLength;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected Default(MethodDescription instrumentedMethod, List<? extends TypeDescription> initialTypes, List<? extends TypeDescription> preMethodTypes, List<? extends TypeDescription> postMethodTypes) {
/*  6514 */         this.instrumentedMethod = instrumentedMethod;
/*  6515 */         this.initialTypes = initialTypes;
/*  6516 */         this.preMethodTypes = preMethodTypes;
/*  6517 */         this.postMethodTypes = postMethodTypes;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static Advice.MethodSizeHandler.ForInstrumentedMethod of(MethodDescription instrumentedMethod, List<? extends TypeDescription> initialTypes, List<? extends TypeDescription> preMethodTypes, List<? extends TypeDescription> postMethodTypes, boolean copyArguments, int writerFlags) {
/*  6537 */         if ((writerFlags & 0x3) != 0)
/*  6538 */           return Advice.MethodSizeHandler.NoOp.INSTANCE; 
/*  6539 */         if (copyArguments) {
/*  6540 */           return new WithCopiedArguments(instrumentedMethod, initialTypes, preMethodTypes, postMethodTypes);
/*       */         }
/*  6542 */         return new WithRetainedArguments(instrumentedMethod, initialTypes, preMethodTypes, postMethodTypes);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.MethodSizeHandler.ForAdvice bindEnter(MethodDescription.TypeToken typeToken) {
/*  6550 */         return new ForAdvice(typeToken, this.instrumentedMethod.getStackSize() + StackSize.of(this.initialTypes));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void requireStackSize(int stackSize) {
/*  6557 */         this.stackSize = Math.max(this.stackSize, stackSize);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void requireLocalVariableLength(int localVariableLength) {
/*  6564 */         this.localVariableLength = Math.max(this.localVariableLength, localVariableLength);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int compoundStackSize(int stackSize) {
/*  6571 */         return Math.max(this.stackSize, stackSize);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int compoundLocalVariableLength(int localVariableLength) {
/*  6578 */         return Math.max(this.localVariableLength, localVariableLength + 
/*  6579 */             StackSize.of(this.postMethodTypes) + 
/*  6580 */             StackSize.of(this.initialTypes) + 
/*  6581 */             StackSize.of(this.preMethodTypes));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static class WithRetainedArguments
/*       */         extends Default
/*       */       {
/*       */         protected WithRetainedArguments(MethodDescription instrumentedMethod, List<? extends TypeDescription> initialTypes, List<? extends TypeDescription> preMethodTypes, List<? extends TypeDescription> postMethodTypes) {
/*  6601 */           super(instrumentedMethod, initialTypes, preMethodTypes, postMethodTypes);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.MethodSizeHandler.ForAdvice bindExit(MethodDescription.TypeToken typeToken) {
/*  6608 */           return new Advice.MethodSizeHandler.Default.ForAdvice(typeToken, this.instrumentedMethod.getStackSize() + 
/*  6609 */               StackSize.of(this.postMethodTypes) + 
/*  6610 */               StackSize.of(this.initialTypes) + 
/*  6611 */               StackSize.of(this.preMethodTypes));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int compoundLocalVariableLength(int localVariableLength) {
/*  6618 */           return Math.max(this.localVariableLength, localVariableLength + 
/*  6619 */               StackSize.of(this.postMethodTypes) + 
/*  6620 */               StackSize.of(this.initialTypes) + 
/*  6621 */               StackSize.of(this.preMethodTypes));
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static class WithCopiedArguments
/*       */         extends Default
/*       */       {
/*       */         protected WithCopiedArguments(MethodDescription instrumentedMethod, List<? extends TypeDescription> initialTypes, List<? extends TypeDescription> preMethodTypes, List<? extends TypeDescription> postMethodTypes) {
/*  6642 */           super(instrumentedMethod, initialTypes, preMethodTypes, postMethodTypes);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.MethodSizeHandler.ForAdvice bindExit(MethodDescription.TypeToken typeToken) {
/*  6649 */           return new Advice.MethodSizeHandler.Default.ForAdvice(typeToken, 2 * this.instrumentedMethod.getStackSize() + 
/*  6650 */               StackSize.of(this.initialTypes) + 
/*  6651 */               StackSize.of(this.preMethodTypes) + 
/*  6652 */               StackSize.of(this.postMethodTypes));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int compoundLocalVariableLength(int localVariableLength) {
/*  6659 */           return Math.max(this.localVariableLength, localVariableLength + this.instrumentedMethod
/*  6660 */               .getStackSize() + 
/*  6661 */               StackSize.of(this.postMethodTypes) + 
/*  6662 */               StackSize.of(this.initialTypes) + 
/*  6663 */               StackSize.of(this.preMethodTypes));
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected class ForAdvice
/*       */         implements Advice.MethodSizeHandler.ForAdvice
/*       */       {
/*       */         private final MethodDescription.TypeToken typeToken;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final int baseLocalVariableLength;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private int stackSizePadding;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private int localVariableLengthPadding;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForAdvice(MethodDescription.TypeToken typeToken, int baseLocalVariableLength) {
/*  6700 */           this.typeToken = typeToken;
/*  6701 */           this.baseLocalVariableLength = baseLocalVariableLength;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void requireStackSize(int stackSize) {
/*  6708 */           Advice.MethodSizeHandler.Default.this.requireStackSize(stackSize);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void requireLocalVariableLength(int localVariableLength) {
/*  6715 */           Advice.MethodSizeHandler.Default.this.requireLocalVariableLength(localVariableLength);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void requireStackSizePadding(int stackSizePadding) {
/*  6722 */           this.stackSizePadding = Math.max(this.stackSizePadding, stackSizePadding);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void requireLocalVariableLengthPadding(int localVariableLengthPadding) {
/*  6729 */           this.localVariableLengthPadding = Math.max(this.localVariableLengthPadding, localVariableLengthPadding);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void recordMaxima(int stackSize, int localVariableLength) {
/*  6736 */           Advice.MethodSizeHandler.Default.this.requireStackSize(stackSize + this.stackSizePadding);
/*  6737 */           Advice.MethodSizeHandler.Default.this.requireLocalVariableLength(localVariableLength - 
/*  6738 */               StackSize.of(this.typeToken.getParameterTypes()) + this.baseLocalVariableLength + this.localVariableLengthPadding);
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static interface StackMapFrameHandler
/*       */   {
/*       */     void translateFrame(MethodVisitor param1MethodVisitor, int param1Int1, int param1Int2, @MaybeNull Object[] param1ArrayOfObject1, int param1Int3, @MaybeNull Object[] param1ArrayOfObject2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     void injectReturnFrame(MethodVisitor param1MethodVisitor);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     void injectExceptionFrame(MethodVisitor param1MethodVisitor);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     void injectCompletionFrame(MethodVisitor param1MethodVisitor);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface ForPostProcessor
/*       */     {
/*       */       void injectIntermediateFrame(MethodVisitor param2MethodVisitor, List<? extends TypeDescription> param2List);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface ForInstrumentedMethod
/*       */       extends StackMapFrameHandler
/*       */     {
/*       */       Advice.StackMapFrameHandler.ForAdvice bindEnter(MethodDescription.TypeToken param2TypeToken);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Advice.StackMapFrameHandler.ForAdvice bindExit(MethodDescription.TypeToken param2TypeToken);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       int getReaderHint();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       void injectInitializationFrame(MethodVisitor param2MethodVisitor);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       void injectStartFrame(MethodVisitor param2MethodVisitor);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       void injectPostCompletionFrame(MethodVisitor param2MethodVisitor);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface ForAdvice
/*       */       extends StackMapFrameHandler, ForPostProcessor {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public enum NoOp
/*       */       implements ForInstrumentedMethod, ForAdvice
/*       */     {
/*  6869 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.StackMapFrameHandler.ForAdvice bindEnter(MethodDescription.TypeToken typeToken) {
/*  6875 */         return this;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.StackMapFrameHandler.ForAdvice bindExit(MethodDescription.TypeToken typeToken) {
/*  6882 */         return this;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int getReaderHint() {
/*  6889 */         return 4;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void translateFrame(MethodVisitor methodVisitor, int type, int localVariableLength, @MaybeNull Object[] localVariable, int stackSize, @MaybeNull Object[] stack) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void injectReturnFrame(MethodVisitor methodVisitor) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void injectExceptionFrame(MethodVisitor methodVisitor) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void injectCompletionFrame(MethodVisitor methodVisitor) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void injectInitializationFrame(MethodVisitor methodVisitor) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void injectStartFrame(MethodVisitor methodVisitor) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void injectPostCompletionFrame(MethodVisitor methodVisitor) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void injectIntermediateFrame(MethodVisitor methodVisitor, List<? extends TypeDescription> stack) {}
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static abstract class Default
/*       */       implements ForInstrumentedMethod
/*       */     {
/*  6962 */       protected static final Object[] EMPTY = new Object[0];
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final TypeDescription instrumentedType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final MethodDescription instrumentedMethod;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final List<? extends TypeDescription> initialTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final List<? extends TypeDescription> latentTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final List<? extends TypeDescription> preMethodTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final List<? extends TypeDescription> postMethodTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final boolean expandFrames;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected int currentFrameDivergence;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected Default(TypeDescription instrumentedType, MethodDescription instrumentedMethod, List<? extends TypeDescription> initialTypes, List<? extends TypeDescription> latentTypes, List<? extends TypeDescription> preMethodTypes, List<? extends TypeDescription> postMethodTypes, boolean expandFrames) {
/*  7022 */         this.instrumentedType = instrumentedType;
/*  7023 */         this.instrumentedMethod = instrumentedMethod;
/*  7024 */         this.initialTypes = initialTypes;
/*  7025 */         this.latentTypes = latentTypes;
/*  7026 */         this.preMethodTypes = preMethodTypes;
/*  7027 */         this.postMethodTypes = postMethodTypes;
/*  7028 */         this.expandFrames = expandFrames;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static Advice.StackMapFrameHandler.ForInstrumentedMethod of(TypeDescription instrumentedType, MethodDescription instrumentedMethod, List<? extends TypeDescription> initialTypes, List<? extends TypeDescription> latentTypes, List<? extends TypeDescription> preMethodTypes, List<? extends TypeDescription> postMethodTypes, boolean exitAdvice, boolean copyArguments, ClassFileVersion classFileVersion, int writerFlags, int readerFlags) {
/*  7058 */         if ((writerFlags & 0x2) != 0 || classFileVersion.isLessThan(ClassFileVersion.JAVA_V6))
/*  7059 */           return Advice.StackMapFrameHandler.NoOp.INSTANCE; 
/*  7060 */         if (!exitAdvice && initialTypes.isEmpty()) {
/*  7061 */           return new Trivial(instrumentedType, instrumentedMethod, latentTypes, ((readerFlags & 0x8) != 0));
/*       */         }
/*       */ 
/*       */         
/*  7065 */         if (copyArguments) {
/*  7066 */           return new WithPreservedArguments.WithArgumentCopy(instrumentedType, instrumentedMethod, initialTypes, latentTypes, preMethodTypes, postMethodTypes, ((readerFlags & 0x8) != 0));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  7074 */         return new WithPreservedArguments.WithoutArgumentCopy(instrumentedType, instrumentedMethod, initialTypes, latentTypes, preMethodTypes, postMethodTypes, ((readerFlags & 0x8) != 0), 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*  7081 */             !instrumentedMethod.isConstructor());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.StackMapFrameHandler.ForAdvice bindEnter(MethodDescription.TypeToken typeToken) {
/*  7089 */         return new ForAdvice(typeToken, this.initialTypes, this.latentTypes, this.preMethodTypes, TranslationMode.ENTER, this.instrumentedMethod.isConstructor() ? Initialization.UNITIALIZED : Initialization.INITIALIZED);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int getReaderHint() {
/*  7098 */         return this.expandFrames ? 8 : 0;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected void translateFrame(MethodVisitor methodVisitor, TranslationMode translationMode, boolean isStatic, MethodDescription.TypeToken typeToken, List<? extends TypeDescription> additionalTypes, int type, int localVariableLength, @MaybeNull Object[] localVariable, int stackSize, @MaybeNull Object[] stack) {
/*       */         int offset, index;
/*       */         Object[] translated;
/*       */         int i;
/*  7127 */         switch (type) {
/*       */           case 3:
/*       */           case 4:
/*       */             break;
/*       */           case 1:
/*  7132 */             this.currentFrameDivergence += localVariableLength;
/*       */             break;
/*       */           case 2:
/*  7135 */             this.currentFrameDivergence -= localVariableLength;
/*  7136 */             if (this.currentFrameDivergence < 0) {
/*  7137 */               throw new IllegalStateException(typeToken + " dropped " + Math.abs(this.currentFrameDivergence) + " implicit frames");
/*       */             }
/*       */             break;
/*       */           case -1:
/*       */           case 0:
/*  7142 */             if (typeToken.getParameterTypes().size() + (isStatic ? 0 : 1) > localVariableLength) {
/*  7143 */               throw new IllegalStateException("Inconsistent frame length for " + typeToken + ": " + localVariableLength);
/*       */             }
/*       */             
/*  7146 */             if (isStatic) {
/*  7147 */               offset = 0;
/*       */             } else {
/*  7149 */               if (!translationMode.isPossibleThisFrameValue(this.instrumentedType, this.instrumentedMethod, localVariable[0])) {
/*  7150 */                 throw new IllegalStateException(typeToken + " is inconsistent for 'this' reference: " + localVariable[0]);
/*       */               }
/*  7152 */               offset = 1;
/*       */             } 
/*  7154 */             for (index = 0; index < typeToken.getParameterTypes().size(); index++) {
/*  7155 */               if (!Initialization.INITIALIZED.toFrame(typeToken.getParameterTypes().get(index)).equals(localVariable[index + offset])) {
/*  7156 */                 throw new IllegalStateException(typeToken + " is inconsistent at " + index + ": " + localVariable[index + offset]);
/*       */               }
/*       */             } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*  7164 */             translated = new Object[localVariableLength - (isStatic ? 0 : 1) - typeToken.getParameterTypes().size() + (this.instrumentedMethod.isStatic() ? 0 : 1) + this.instrumentedMethod.getParameters().size() + additionalTypes.size()];
/*  7165 */             i = translationMode.copy(this.instrumentedType, this.instrumentedMethod, localVariable, translated);
/*  7166 */             for (TypeDescription typeDescription : additionalTypes) {
/*  7167 */               translated[i++] = Initialization.INITIALIZED.toFrame(typeDescription);
/*       */             }
/*  7169 */             if (translated.length != i) {
/*  7170 */               System.arraycopy(localVariable, typeToken
/*  7171 */                   .getParameterTypes().size() + (isStatic ? 0 : 1), translated, i, translated.length - i);
/*       */             }
/*       */ 
/*       */ 
/*       */             
/*  7176 */             localVariableLength = translated.length;
/*  7177 */             localVariable = translated;
/*  7178 */             this.currentFrameDivergence = translated.length - i;
/*       */             break;
/*       */           default:
/*  7181 */             throw new IllegalArgumentException("Unexpected frame type: " + type);
/*       */         } 
/*  7183 */         methodVisitor.visitFrame(type, localVariableLength, localVariable, stackSize, stack);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected void injectFullFrame(MethodVisitor methodVisitor, Initialization initialization, List<? extends TypeDescription> typesInArray, List<? extends TypeDescription> typesOnStack) {
/*  7200 */         Object[] localVariable = new Object[this.instrumentedMethod.getParameters().size() + (this.instrumentedMethod.isStatic() ? 0 : 1) + typesInArray.size()];
/*  7201 */         int index = 0;
/*  7202 */         if (!this.instrumentedMethod.isStatic()) {
/*  7203 */           localVariable[index++] = initialization.toFrame(this.instrumentedType);
/*       */         }
/*  7205 */         for (TypeDescription typeDescription : this.instrumentedMethod.getParameters().asTypeList().asErasures()) {
/*  7206 */           localVariable[index++] = Initialization.INITIALIZED.toFrame(typeDescription);
/*       */         }
/*  7208 */         for (TypeDescription typeDescription : typesInArray) {
/*  7209 */           localVariable[index++] = Initialization.INITIALIZED.toFrame(typeDescription);
/*       */         }
/*  7211 */         index = 0;
/*  7212 */         Object[] stackType = new Object[typesOnStack.size()];
/*  7213 */         for (TypeDescription typeDescription : typesOnStack) {
/*  7214 */           stackType[index++] = Initialization.INITIALIZED.toFrame(typeDescription);
/*       */         }
/*  7216 */         methodVisitor.visitFrame(this.expandFrames ? -1 : 0, localVariable.length, localVariable, stackType.length, stackType);
/*  7217 */         this.currentFrameDivergence = 0;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected enum TranslationMode
/*       */       {
/*  7228 */         COPY
/*       */         {
/*       */ 
/*       */           
/*       */           protected int copy(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Object[] localVariable, Object[] translated)
/*       */           {
/*  7234 */             int length = instrumentedMethod.getParameters().size() + (instrumentedMethod.isStatic() ? 0 : 1);
/*  7235 */             System.arraycopy(localVariable, 0, translated, 0, length);
/*  7236 */             return length;
/*       */           }
/*       */ 
/*       */           
/*       */           protected boolean isPossibleThisFrameValue(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Object frame) {
/*  7241 */             return ((instrumentedMethod.isConstructor() && Opcodes.UNINITIALIZED_THIS.equals(frame)) || Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(instrumentedType).equals(frame));
/*       */           }
/*       */         },
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  7248 */         ENTER
/*       */         {
/*       */ 
/*       */           
/*       */           protected int copy(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Object[] localVariable, Object[] translated)
/*       */           {
/*  7254 */             int index = 0;
/*  7255 */             if (!instrumentedMethod.isStatic()) {
/*  7256 */               translated[index++] = instrumentedMethod.isConstructor() ? Opcodes.UNINITIALIZED_THIS : Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED
/*       */                 
/*  7258 */                 .toFrame(instrumentedType);
/*       */             }
/*  7260 */             for (TypeDescription typeDescription : instrumentedMethod.getParameters().asTypeList().asErasures()) {
/*  7261 */               translated[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);
/*       */             }
/*  7263 */             return index;
/*       */           }
/*       */ 
/*       */           
/*       */           protected boolean isPossibleThisFrameValue(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Object frame) {
/*  7268 */             return instrumentedMethod.isConstructor() ? Opcodes.UNINITIALIZED_THIS
/*  7269 */               .equals(frame) : Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED
/*  7270 */               .toFrame(instrumentedType).equals(frame);
/*       */           }
/*       */         },
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  7277 */         EXIT
/*       */         {
/*       */ 
/*       */           
/*       */           protected int copy(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Object[] localVariable, Object[] translated)
/*       */           {
/*  7283 */             int index = 0;
/*  7284 */             if (!instrumentedMethod.isStatic()) {
/*  7285 */               translated[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(instrumentedType);
/*       */             }
/*  7287 */             for (TypeDescription typeDescription : instrumentedMethod.getParameters().asTypeList().asErasures()) {
/*  7288 */               translated[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);
/*       */             }
/*  7290 */             return index;
/*       */           }
/*       */ 
/*       */           
/*       */           protected boolean isPossibleThisFrameValue(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Object frame) {
/*  7295 */             return Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(instrumentedType).equals(frame);
/*       */           }
/*       */         };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected abstract int copy(TypeDescription param3TypeDescription, MethodDescription param3MethodDescription, Object[] param3ArrayOfObject1, Object[] param3ArrayOfObject2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected abstract boolean isPossibleThisFrameValue(TypeDescription param3TypeDescription, MethodDescription param3MethodDescription, Object param3Object);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected enum Initialization
/*       */       {
/*  7332 */         UNITIALIZED
/*       */         {
/*       */           
/*       */           protected Object toFrame(TypeDescription typeDescription)
/*       */           {
/*  7337 */             if (typeDescription.isPrimitive()) {
/*  7338 */               throw new IllegalArgumentException("Cannot assume primitive uninitialized value: " + typeDescription);
/*       */             }
/*  7340 */             return Opcodes.UNINITIALIZED_THIS;
/*       */           }
/*       */         },
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  7347 */         INITIALIZED
/*       */         {
/*       */           
/*       */           protected Object toFrame(TypeDescription typeDescription)
/*       */           {
/*  7352 */             if (typeDescription.represents(boolean.class) || typeDescription
/*  7353 */               .represents(byte.class) || typeDescription
/*  7354 */               .represents(short.class) || typeDescription
/*  7355 */               .represents(char.class) || typeDescription
/*  7356 */               .represents(int.class))
/*  7357 */               return Opcodes.INTEGER; 
/*  7358 */             if (typeDescription.represents(long.class))
/*  7359 */               return Opcodes.LONG; 
/*  7360 */             if (typeDescription.represents(float.class))
/*  7361 */               return Opcodes.FLOAT; 
/*  7362 */             if (typeDescription.represents(double.class)) {
/*  7363 */               return Opcodes.DOUBLE;
/*       */             }
/*  7365 */             return typeDescription.getInternalName();
/*       */           }
/*       */         };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected abstract Object toFrame(TypeDescription param3TypeDescription);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static class Trivial
/*       */         extends Default
/*       */       {
/*       */         protected Trivial(TypeDescription instrumentedType, MethodDescription instrumentedMethod, List<? extends TypeDescription> latentTypes, boolean expandFrames) {
/*  7393 */           super(instrumentedType, instrumentedMethod, 
/*       */               
/*  7395 */               Collections.emptyList(), latentTypes, 
/*       */               
/*  7397 */               Collections.emptyList(), 
/*  7398 */               Collections.emptyList(), expandFrames);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void translateFrame(MethodVisitor methodVisitor, int type, int localVariableLength, @MaybeNull Object[] localVariable, int stackSize, @MaybeNull Object[] stack) {
/*  7411 */           methodVisitor.visitFrame(type, localVariableLength, localVariable, stackSize, stack);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.StackMapFrameHandler.ForAdvice bindExit(MethodDescription.TypeToken typeToken) {
/*  7418 */           throw new IllegalStateException("Did not expect exit advice " + typeToken + " for " + this.instrumentedMethod);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void injectReturnFrame(MethodVisitor methodVisitor) {
/*  7425 */           throw new IllegalStateException("Did not expect return frame for " + this.instrumentedMethod);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void injectExceptionFrame(MethodVisitor methodVisitor) {
/*  7432 */           throw new IllegalStateException("Did not expect exception frame for " + this.instrumentedMethod);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void injectCompletionFrame(MethodVisitor methodVisitor) {
/*  7439 */           throw new IllegalStateException("Did not expect completion frame for " + this.instrumentedMethod);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void injectPostCompletionFrame(MethodVisitor methodVisitor) {
/*  7446 */           throw new IllegalStateException("Did not expect post completion frame for " + this.instrumentedMethod);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void injectInitializationFrame(MethodVisitor methodVisitor) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void injectStartFrame(MethodVisitor methodVisitor) {}
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static abstract class WithPreservedArguments
/*       */         extends Default
/*       */       {
/*       */         protected boolean allowCompactCompletionFrame;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected WithPreservedArguments(TypeDescription instrumentedType, MethodDescription instrumentedMethod, List<? extends TypeDescription> initialTypes, List<? extends TypeDescription> latentTypes, List<? extends TypeDescription> preMethodTypes, List<? extends TypeDescription> postMethodTypes, boolean expandFrames, boolean allowCompactCompletionFrame) {
/*  7494 */           super(instrumentedType, instrumentedMethod, initialTypes, latentTypes, preMethodTypes, postMethodTypes, expandFrames);
/*  7495 */           this.allowCompactCompletionFrame = allowCompactCompletionFrame;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"RC_REF_COMPARISON_BAD_PRACTICE"}, justification = "ASM models frames by reference identity.")
/*       */         protected void translateFrame(MethodVisitor methodVisitor, Advice.StackMapFrameHandler.Default.TranslationMode translationMode, boolean isStatic, MethodDescription.TypeToken typeToken, List<? extends TypeDescription> additionalTypes, int type, int localVariableLength, @MaybeNull Object[] localVariable, int stackSize, @MaybeNull Object[] stack) {
/*  7510 */           if (type == 0 && localVariableLength > 0 && localVariable[0] != Opcodes.UNINITIALIZED_THIS) {
/*  7511 */             this.allowCompactCompletionFrame = true;
/*       */           }
/*  7513 */           super.translateFrame(methodVisitor, translationMode, isStatic, typeToken, additionalTypes, type, localVariableLength, localVariable, stackSize, stack);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.StackMapFrameHandler.ForAdvice bindExit(MethodDescription.TypeToken typeToken) {
/*  7520 */           return new Advice.StackMapFrameHandler.Default.ForAdvice(typeToken, 
/*  7521 */               CompoundList.of(this.initialTypes, this.preMethodTypes, this.postMethodTypes), 
/*  7522 */               Collections.emptyList(), 
/*  7523 */               Collections.emptyList(), Advice.StackMapFrameHandler.Default.TranslationMode.EXIT, Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void injectReturnFrame(MethodVisitor methodVisitor) {
/*  7532 */           if (!this.expandFrames && this.currentFrameDivergence == 0) {
/*  7533 */             if (this.instrumentedMethod.getReturnType().represents(void.class)) {
/*  7534 */               methodVisitor.visitFrame(3, EMPTY.length, EMPTY, EMPTY.length, EMPTY);
/*       */             } else {
/*  7536 */               methodVisitor.visitFrame(4, EMPTY.length, EMPTY, 1, new Object[] { Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED
/*       */ 
/*       */ 
/*       */                     
/*  7540 */                     .toFrame(this.instrumentedMethod.getReturnType().asErasure()) });
/*       */             } 
/*       */           } else {
/*  7543 */             injectFullFrame(methodVisitor, Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED, CompoundList.of(this.initialTypes, this.preMethodTypes), 
/*  7544 */                 this.instrumentedMethod.getReturnType().represents(void.class) ? 
/*  7545 */                 Collections.<TypeDescription>emptyList() : 
/*  7546 */                 Collections.<TypeDescription>singletonList(this.instrumentedMethod.getReturnType().asErasure()));
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void injectExceptionFrame(MethodVisitor methodVisitor) {
/*  7554 */           if (!this.expandFrames && this.currentFrameDivergence == 0) {
/*  7555 */             methodVisitor.visitFrame(4, EMPTY.length, EMPTY, 1, new Object[] { Type.getInternalName(Throwable.class) });
/*       */           } else {
/*  7557 */             injectFullFrame(methodVisitor, Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED, CompoundList.of(this.initialTypes, this.preMethodTypes), 
/*  7558 */                 Collections.singletonList(TypeDescription.ForLoadedType.of(Throwable.class)));
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void injectCompletionFrame(MethodVisitor methodVisitor) {
/*  7566 */           if (this.allowCompactCompletionFrame && !this.expandFrames && this.currentFrameDivergence == 0 && this.postMethodTypes.size() < 4) {
/*  7567 */             if (this.postMethodTypes.isEmpty()) {
/*  7568 */               methodVisitor.visitFrame(3, EMPTY.length, EMPTY, EMPTY.length, EMPTY);
/*       */             } else {
/*  7570 */               Object[] local = new Object[this.postMethodTypes.size()];
/*  7571 */               int index = 0;
/*  7572 */               for (TypeDescription typeDescription : this.postMethodTypes) {
/*  7573 */                 local[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);
/*       */               }
/*  7575 */               methodVisitor.visitFrame(1, local.length, local, EMPTY.length, EMPTY);
/*       */             } 
/*       */           } else {
/*  7578 */             injectFullFrame(methodVisitor, Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED, CompoundList.of(this.initialTypes, this.preMethodTypes, this.postMethodTypes), 
/*  7579 */                 Collections.emptyList());
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void injectPostCompletionFrame(MethodVisitor methodVisitor) {
/*  7587 */           if (!this.expandFrames && this.currentFrameDivergence == 0) {
/*  7588 */             methodVisitor.visitFrame(3, EMPTY.length, EMPTY, EMPTY.length, EMPTY);
/*       */           } else {
/*  7590 */             injectFullFrame(methodVisitor, Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED, CompoundList.of(this.initialTypes, this.preMethodTypes, this.postMethodTypes), 
/*  7591 */                 Collections.emptyList());
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void injectInitializationFrame(MethodVisitor methodVisitor) {
/*  7599 */           if (!this.initialTypes.isEmpty()) {
/*  7600 */             if (!this.expandFrames && this.initialTypes.size() < 4) {
/*  7601 */               Object[] localVariable = new Object[this.initialTypes.size()];
/*  7602 */               int index = 0;
/*  7603 */               for (TypeDescription typeDescription : this.initialTypes) {
/*  7604 */                 localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);
/*       */               }
/*  7606 */               methodVisitor.visitFrame(1, localVariable.length, localVariable, EMPTY.length, EMPTY);
/*       */             }
/*       */             else {
/*       */               
/*  7610 */               Object[] localVariable = new Object[(this.instrumentedMethod.isStatic() ? 0 : 1) + this.instrumentedMethod.getParameters().size() + this.initialTypes.size()];
/*  7611 */               int index = 0;
/*  7612 */               if (this.instrumentedMethod.isConstructor()) {
/*  7613 */                 localVariable[index++] = Opcodes.UNINITIALIZED_THIS;
/*  7614 */               } else if (!this.instrumentedMethod.isStatic()) {
/*  7615 */                 localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(this.instrumentedType);
/*       */               } 
/*  7617 */               for (TypeDescription typeDescription : this.instrumentedMethod.getParameters().asTypeList().asErasures()) {
/*  7618 */                 localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);
/*       */               }
/*  7620 */               for (TypeDescription typeDescription : this.initialTypes) {
/*  7621 */                 localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);
/*       */               }
/*  7623 */               methodVisitor.visitFrame(this.expandFrames ? -1 : 0, localVariable.length, localVariable, EMPTY.length, EMPTY);
/*       */             } 
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class WithoutArgumentCopy
/*       */           extends WithPreservedArguments
/*       */         {
/*       */           protected WithoutArgumentCopy(TypeDescription instrumentedType, MethodDescription instrumentedMethod, List<? extends TypeDescription> initialTypes, List<? extends TypeDescription> latentTypes, List<? extends TypeDescription> preMethodTypes, List<? extends TypeDescription> postMethodTypes, boolean expandFrames, boolean allowCompactCompletionFrame) {
/*  7653 */             super(instrumentedType, instrumentedMethod, initialTypes, latentTypes, preMethodTypes, postMethodTypes, expandFrames, allowCompactCompletionFrame);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void injectStartFrame(MethodVisitor methodVisitor) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void translateFrame(MethodVisitor methodVisitor, int type, int localVariableLength, @MaybeNull Object[] localVariable, int stackSize, @MaybeNull Object[] stack) {
/*  7672 */             translateFrame(methodVisitor, Advice.StackMapFrameHandler.Default.TranslationMode.COPY, this.instrumentedMethod
/*       */                 
/*  7674 */                 .isStatic(), this.instrumentedMethod
/*  7675 */                 .asTypeToken(), 
/*  7676 */                 CompoundList.of(this.initialTypes, this.preMethodTypes), type, localVariableLength, localVariable, stackSize, stack);
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class WithArgumentCopy
/*       */           extends WithPreservedArguments
/*       */         {
/*       */           protected WithArgumentCopy(TypeDescription instrumentedType, MethodDescription instrumentedMethod, List<? extends TypeDescription> initialTypes, List<? extends TypeDescription> latentTypes, List<? extends TypeDescription> preMethodTypes, List<? extends TypeDescription> postMethodTypes, boolean expandFrames) {
/*  7708 */             super(instrumentedType, instrumentedMethod, initialTypes, latentTypes, preMethodTypes, postMethodTypes, expandFrames, true);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void injectStartFrame(MethodVisitor methodVisitor) {
/*  7715 */             if (!this.instrumentedMethod.isStatic() || !this.instrumentedMethod.getParameters().isEmpty()) {
/*  7716 */               if (!this.expandFrames && (this.instrumentedMethod.isStatic() ? 0 : 1) + this.instrumentedMethod.getParameters().size() < 4) {
/*  7717 */                 Object[] localVariable = new Object[(this.instrumentedMethod.isStatic() ? 0 : 1) + this.instrumentedMethod.getParameters().size()];
/*  7718 */                 int index = 0;
/*  7719 */                 if (this.instrumentedMethod.isConstructor()) {
/*  7720 */                   localVariable[index++] = Opcodes.UNINITIALIZED_THIS;
/*  7721 */                 } else if (!this.instrumentedMethod.isStatic()) {
/*  7722 */                   localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(this.instrumentedType);
/*       */                 } 
/*  7724 */                 for (TypeDescription typeDescription : this.instrumentedMethod.getParameters().asTypeList().asErasures()) {
/*  7725 */                   localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);
/*       */                 }
/*  7727 */                 methodVisitor.visitFrame(1, localVariable.length, localVariable, EMPTY.length, EMPTY);
/*       */               
/*       */               }
/*       */               else {
/*       */                 
/*  7732 */                 Object[] localVariable = new Object[(this.instrumentedMethod.isStatic() ? 0 : 2) + this.instrumentedMethod.getParameters().size() * 2 + this.initialTypes.size() + this.preMethodTypes.size()];
/*  7733 */                 int index = 0;
/*  7734 */                 if (this.instrumentedMethod.isConstructor()) {
/*  7735 */                   localVariable[index++] = Opcodes.UNINITIALIZED_THIS;
/*  7736 */                 } else if (!this.instrumentedMethod.isStatic()) {
/*  7737 */                   localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(this.instrumentedType);
/*       */                 } 
/*  7739 */                 for (TypeDescription typeDescription : this.instrumentedMethod.getParameters().asTypeList().asErasures()) {
/*  7740 */                   localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);
/*       */                 }
/*  7742 */                 for (TypeDescription typeDescription : this.initialTypes) {
/*  7743 */                   localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);
/*       */                 }
/*  7745 */                 for (TypeDescription typeDescription : this.preMethodTypes) {
/*  7746 */                   localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);
/*       */                 }
/*  7748 */                 if (this.instrumentedMethod.isConstructor()) {
/*  7749 */                   localVariable[index++] = Opcodes.UNINITIALIZED_THIS;
/*  7750 */                 } else if (!this.instrumentedMethod.isStatic()) {
/*  7751 */                   localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(this.instrumentedType);
/*       */                 } 
/*  7753 */                 for (TypeDescription typeDescription : this.instrumentedMethod.getParameters().asTypeList().asErasures()) {
/*  7754 */                   localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);
/*       */                 }
/*  7756 */                 methodVisitor.visitFrame(this.expandFrames ? -1 : 0, localVariable.length, localVariable, EMPTY.length, EMPTY);
/*       */               } 
/*       */             }
/*  7759 */             this.currentFrameDivergence = (this.instrumentedMethod.isStatic() ? 0 : 1) + this.instrumentedMethod.getParameters().size();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"RC_REF_COMPARISON_BAD_PRACTICE"}, justification = "ASM models frames by reference identity.")
/*       */           public void translateFrame(MethodVisitor methodVisitor, int type, int localVariableLength, @MaybeNull Object[] localVariable, int stackSize, @MaybeNull Object[] stack)
/*       */           {
/*       */             Object[] translated;
/*       */             int index;
/*  7772 */             switch (type) {
/*       */               case 3:
/*       */               case 4:
/*       */                 break;
/*       */               case 1:
/*  7777 */                 this.currentFrameDivergence += localVariableLength;
/*       */                 break;
/*       */               case 2:
/*  7780 */                 this.currentFrameDivergence -= localVariableLength;
/*       */                 break;
/*       */ 
/*       */ 
/*       */ 
/*       */               
/*       */               case -1:
/*       */               case 0:
/*  7788 */                 translated = new Object[localVariableLength + (this.instrumentedMethod.isStatic() ? 0 : 1) + this.instrumentedMethod.getParameters().size() + this.initialTypes.size() + this.preMethodTypes.size()];
/*  7789 */                 index = 0;
/*  7790 */                 if (this.instrumentedMethod.isConstructor()) {
/*  7791 */                   Advice.StackMapFrameHandler.Default.Initialization initialization = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED;
/*  7792 */                   for (int variableIndex = 0; variableIndex < localVariableLength; variableIndex++) {
/*  7793 */                     if (localVariable[variableIndex] == Opcodes.UNINITIALIZED_THIS) {
/*  7794 */                       initialization = Advice.StackMapFrameHandler.Default.Initialization.UNITIALIZED;
/*       */                       break;
/*       */                     } 
/*       */                   } 
/*  7798 */                   translated[index++] = initialization.toFrame(this.instrumentedType);
/*  7799 */                 } else if (!this.instrumentedMethod.isStatic()) {
/*  7800 */                   translated[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(this.instrumentedType);
/*       */                 } 
/*  7802 */                 for (TypeDescription typeDescription : this.instrumentedMethod.getParameters().asTypeList().asErasures()) {
/*  7803 */                   translated[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);
/*       */                 }
/*  7805 */                 for (TypeDescription typeDescription : this.initialTypes) {
/*  7806 */                   translated[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);
/*       */                 }
/*  7808 */                 for (TypeDescription typeDescription : this.preMethodTypes) {
/*  7809 */                   translated[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);
/*       */                 }
/*  7811 */                 if (localVariableLength > 0) {
/*  7812 */                   System.arraycopy(localVariable, 0, translated, index, localVariableLength);
/*       */                 }
/*  7814 */                 localVariableLength = translated.length;
/*  7815 */                 localVariable = translated;
/*  7816 */                 this.currentFrameDivergence = localVariableLength;
/*       */                 break;
/*       */               default:
/*  7819 */                 throw new IllegalArgumentException("Unexpected frame type: " + type);
/*       */             } 
/*  7821 */             if (this.instrumentedMethod.isConstructor() && this.currentFrameDivergence < this.instrumentedMethod.getStackSize()) {
/*  7822 */               throw new IllegalStateException(this.instrumentedMethod + " dropped implicit 'this' frame");
/*       */             }
/*  7824 */             methodVisitor.visitFrame(type, localVariableLength, localVariable, stackSize, stack); } } } protected static class WithoutArgumentCopy extends WithPreservedArguments { protected WithoutArgumentCopy(TypeDescription instrumentedType, MethodDescription instrumentedMethod, List<? extends TypeDescription> initialTypes, List<? extends TypeDescription> latentTypes, List<? extends TypeDescription> preMethodTypes, List<? extends TypeDescription> postMethodTypes, boolean expandFrames, boolean allowCompactCompletionFrame) { super(instrumentedType, instrumentedMethod, initialTypes, latentTypes, preMethodTypes, postMethodTypes, expandFrames, allowCompactCompletionFrame); } public void injectStartFrame(MethodVisitor methodVisitor) {} public void translateFrame(MethodVisitor methodVisitor, int type, int localVariableLength, @MaybeNull Object[] localVariable, int stackSize, @MaybeNull Object[] stack) { translateFrame(methodVisitor, Advice.StackMapFrameHandler.Default.TranslationMode.COPY, this.instrumentedMethod.isStatic(), this.instrumentedMethod.asTypeToken(), CompoundList.of(this.initialTypes, this.preMethodTypes), type, localVariableLength, localVariable, stackSize, stack); } } protected static class WithArgumentCopy extends WithPreservedArguments { protected WithArgumentCopy(TypeDescription instrumentedType, MethodDescription instrumentedMethod, List<? extends TypeDescription> initialTypes, List<? extends TypeDescription> latentTypes, List<? extends TypeDescription> preMethodTypes, List<? extends TypeDescription> postMethodTypes, boolean expandFrames) { super(instrumentedType, instrumentedMethod, initialTypes, latentTypes, preMethodTypes, postMethodTypes, expandFrames, true); } public void injectStartFrame(MethodVisitor methodVisitor) { if (!this.instrumentedMethod.isStatic() || !this.instrumentedMethod.getParameters().isEmpty()) if (!this.expandFrames && (this.instrumentedMethod.isStatic() ? 0 : 1) + this.instrumentedMethod.getParameters().size() < 4) { Object[] localVariable = new Object[(this.instrumentedMethod.isStatic() ? 0 : 1) + this.instrumentedMethod.getParameters().size()]; int index = 0; if (this.instrumentedMethod.isConstructor()) { localVariable[index++] = Opcodes.UNINITIALIZED_THIS; } else if (!this.instrumentedMethod.isStatic()) { localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(this.instrumentedType); }  for (TypeDescription typeDescription : this.instrumentedMethod.getParameters().asTypeList().asErasures()) localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);  methodVisitor.visitFrame(1, localVariable.length, localVariable, EMPTY.length, EMPTY); } else { Object[] localVariable = new Object[(this.instrumentedMethod.isStatic() ? 0 : 2) + this.instrumentedMethod.getParameters().size() * 2 + this.initialTypes.size() + this.preMethodTypes.size()]; int index = 0; if (this.instrumentedMethod.isConstructor()) { localVariable[index++] = Opcodes.UNINITIALIZED_THIS; } else if (!this.instrumentedMethod.isStatic()) { localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(this.instrumentedType); }  for (TypeDescription typeDescription : this.instrumentedMethod.getParameters().asTypeList().asErasures()) localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);  for (TypeDescription typeDescription : this.initialTypes) localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);  for (TypeDescription typeDescription : this.preMethodTypes) localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);  if (this.instrumentedMethod.isConstructor()) { localVariable[index++] = Opcodes.UNINITIALIZED_THIS; } else if (!this.instrumentedMethod.isStatic()) { localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(this.instrumentedType); }  for (TypeDescription typeDescription : this.instrumentedMethod.getParameters().asTypeList().asErasures()) localVariable[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);  methodVisitor.visitFrame(this.expandFrames ? -1 : 0, localVariable.length, localVariable, EMPTY.length, EMPTY); }   this.currentFrameDivergence = (this.instrumentedMethod.isStatic() ? 0 : 1) + this.instrumentedMethod.getParameters().size(); } @SuppressFBWarnings(value = {"RC_REF_COMPARISON_BAD_PRACTICE"}, justification = "ASM models frames by reference identity.") public void translateFrame(MethodVisitor methodVisitor, int type, int localVariableLength, @MaybeNull Object[] localVariable, int stackSize, @MaybeNull Object[] stack) { Object[] translated; int index; switch (type) { case 3: case 4: break;case 1: this.currentFrameDivergence += localVariableLength; break;case 2: this.currentFrameDivergence -= localVariableLength; break;case -1: case 0: translated = new Object[localVariableLength + (this.instrumentedMethod.isStatic() ? 0 : 1) + this.instrumentedMethod.getParameters().size() + this.initialTypes.size() + this.preMethodTypes.size()]; index = 0; if (this.instrumentedMethod.isConstructor()) { Advice.StackMapFrameHandler.Default.Initialization initialization = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED; for (int variableIndex = 0; variableIndex < localVariableLength; variableIndex++) { if (localVariable[variableIndex] == Opcodes.UNINITIALIZED_THIS) { initialization = Advice.StackMapFrameHandler.Default.Initialization.UNITIALIZED; break; }  }  translated[index++] = initialization.toFrame(this.instrumentedType); } else if (!this.instrumentedMethod.isStatic()) { translated[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(this.instrumentedType); }  for (TypeDescription typeDescription : this.instrumentedMethod.getParameters().asTypeList().asErasures()) translated[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);  for (TypeDescription typeDescription : this.initialTypes) translated[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);  for (TypeDescription typeDescription : this.preMethodTypes) translated[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);  if (localVariableLength > 0) System.arraycopy(localVariable, 0, translated, index, localVariableLength);  localVariableLength = translated.length; localVariable = translated; this.currentFrameDivergence = localVariableLength; break;default: throw new IllegalArgumentException("Unexpected frame type: " + type); }  if (this.instrumentedMethod.isConstructor() && this.currentFrameDivergence < this.instrumentedMethod.getStackSize()) throw new IllegalStateException(this.instrumentedMethod + " dropped implicit 'this' frame");  methodVisitor.visitFrame(type, localVariableLength, localVariable, stackSize, stack); }
/*       */          }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected class ForAdvice
/*       */         implements Advice.StackMapFrameHandler.ForAdvice
/*       */       {
/*       */         protected final MethodDescription.TypeToken typeToken;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final List<? extends TypeDescription> startTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final List<? extends TypeDescription> intermediateTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final List<? extends TypeDescription> endTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final Advice.StackMapFrameHandler.Default.TranslationMode translationMode;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final Advice.StackMapFrameHandler.Default.Initialization initialization;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private boolean intermediate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected ForAdvice(MethodDescription.TypeToken typeToken, List<? extends TypeDescription> startTypes, List<? extends TypeDescription> intermediateTypes, List<? extends TypeDescription> endTypes, Advice.StackMapFrameHandler.Default.TranslationMode translationMode, Advice.StackMapFrameHandler.Default.Initialization initialization) {
/*  7886 */           this.typeToken = typeToken;
/*  7887 */           this.startTypes = startTypes;
/*  7888 */           this.intermediateTypes = intermediateTypes;
/*  7889 */           this.endTypes = endTypes;
/*  7890 */           this.translationMode = translationMode;
/*  7891 */           this.initialization = initialization;
/*  7892 */           this.intermediate = false;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void translateFrame(MethodVisitor methodVisitor, int type, int localVariableLength, @MaybeNull Object[] localVariable, int stackSize, @MaybeNull Object[] stack) {
/*  7904 */           Advice.StackMapFrameHandler.Default.this.translateFrame(methodVisitor, this.translationMode, true, this.typeToken, this.startTypes, type, localVariableLength, localVariable, stackSize, stack);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void injectReturnFrame(MethodVisitor methodVisitor) {
/*  7920 */           if (!Advice.StackMapFrameHandler.Default.this.expandFrames && Advice.StackMapFrameHandler.Default.this.currentFrameDivergence == 0) {
/*  7921 */             if (this.typeToken.getReturnType().represents(void.class)) {
/*  7922 */               methodVisitor.visitFrame(3, Advice.StackMapFrameHandler.Default.EMPTY.length, Advice.StackMapFrameHandler.Default.EMPTY, Advice.StackMapFrameHandler.Default.EMPTY.length, Advice.StackMapFrameHandler.Default.EMPTY);
/*       */             } else {
/*  7924 */               methodVisitor.visitFrame(4, Advice.StackMapFrameHandler.Default.EMPTY.length, Advice.StackMapFrameHandler.Default.EMPTY, 1, new Object[] { Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED
/*       */ 
/*       */ 
/*       */                     
/*  7928 */                     .toFrame(this.typeToken.getReturnType()) });
/*       */             } 
/*       */           } else {
/*  7931 */             Advice.StackMapFrameHandler.Default.this.injectFullFrame(methodVisitor, this.initialization, this.startTypes, this.typeToken.getReturnType().represents(void.class) ? 
/*  7932 */                 Collections.<TypeDescription>emptyList() : 
/*  7933 */                 Collections.<TypeDescription>singletonList(this.typeToken.getReturnType()));
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void injectExceptionFrame(MethodVisitor methodVisitor) {
/*  7941 */           if (!Advice.StackMapFrameHandler.Default.this.expandFrames && Advice.StackMapFrameHandler.Default.this.currentFrameDivergence == 0) {
/*  7942 */             methodVisitor.visitFrame(4, Advice.StackMapFrameHandler.Default.EMPTY.length, Advice.StackMapFrameHandler.Default.EMPTY, 1, new Object[] { Type.getInternalName(Throwable.class) });
/*       */           } else {
/*  7944 */             Advice.StackMapFrameHandler.Default.this.injectFullFrame(methodVisitor, this.initialization, this.startTypes, Collections.singletonList(TypeDescription.ForLoadedType.of(Throwable.class)));
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void injectCompletionFrame(MethodVisitor methodVisitor) {
/*  7952 */           if (Advice.StackMapFrameHandler.Default.this.expandFrames) {
/*  7953 */             Advice.StackMapFrameHandler.Default.this.injectFullFrame(methodVisitor, this.initialization, CompoundList.of(this.startTypes, this.endTypes), Collections.emptyList());
/*  7954 */           } else if (Advice.StackMapFrameHandler.Default.this.currentFrameDivergence == 0 && (this.intermediate || this.endTypes.size() < 4)) {
/*  7955 */             if (this.intermediate || this.endTypes.isEmpty()) {
/*  7956 */               methodVisitor.visitFrame(3, Advice.StackMapFrameHandler.Default.EMPTY.length, Advice.StackMapFrameHandler.Default.EMPTY, Advice.StackMapFrameHandler.Default.EMPTY.length, Advice.StackMapFrameHandler.Default.EMPTY);
/*       */             } else {
/*  7958 */               Object[] local = new Object[this.endTypes.size()];
/*  7959 */               int index = 0;
/*  7960 */               for (TypeDescription typeDescription : this.endTypes) {
/*  7961 */                 local[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);
/*       */               }
/*  7963 */               methodVisitor.visitFrame(1, local.length, local, Advice.StackMapFrameHandler.Default.EMPTY.length, Advice.StackMapFrameHandler.Default.EMPTY);
/*       */             } 
/*  7965 */           } else if (Advice.StackMapFrameHandler.Default.this.currentFrameDivergence < 3 && this.endTypes.isEmpty()) {
/*  7966 */             methodVisitor.visitFrame(2, Advice.StackMapFrameHandler.Default.this.currentFrameDivergence, Advice.StackMapFrameHandler.Default.EMPTY, Advice.StackMapFrameHandler.Default.EMPTY.length, Advice.StackMapFrameHandler.Default.EMPTY);
/*  7967 */             Advice.StackMapFrameHandler.Default.this.currentFrameDivergence = 0;
/*       */           } else {
/*  7969 */             Advice.StackMapFrameHandler.Default.this.injectFullFrame(methodVisitor, this.initialization, CompoundList.of(this.startTypes, this.endTypes), Collections.emptyList());
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void injectIntermediateFrame(MethodVisitor methodVisitor, List<? extends TypeDescription> stack) {
/*  7977 */           if (Advice.StackMapFrameHandler.Default.this.expandFrames) {
/*  7978 */             Advice.StackMapFrameHandler.Default.this.injectFullFrame(methodVisitor, this.initialization, CompoundList.of(this.startTypes, this.intermediateTypes), stack);
/*  7979 */           } else if (this.intermediate && stack.size() < 2) {
/*  7980 */             if (stack.isEmpty()) {
/*  7981 */               methodVisitor.visitFrame(3, Advice.StackMapFrameHandler.Default.EMPTY.length, Advice.StackMapFrameHandler.Default.EMPTY, Advice.StackMapFrameHandler.Default.EMPTY.length, Advice.StackMapFrameHandler.Default.EMPTY);
/*       */             } else {
/*  7983 */               methodVisitor.visitFrame(4, Advice.StackMapFrameHandler.Default.EMPTY.length, Advice.StackMapFrameHandler.Default.EMPTY, 1, new Object[] { Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(stack.get(0)) });
/*       */             } 
/*  7985 */           } else if (Advice.StackMapFrameHandler.Default.this.currentFrameDivergence == 0 && this.intermediateTypes
/*  7986 */             .size() < 4 && (stack
/*  7987 */             .isEmpty() || (stack.size() < 2 && this.intermediateTypes.isEmpty()))) {
/*  7988 */             if (this.intermediateTypes.isEmpty()) {
/*  7989 */               if (stack.isEmpty()) {
/*  7990 */                 methodVisitor.visitFrame(3, Advice.StackMapFrameHandler.Default.EMPTY.length, Advice.StackMapFrameHandler.Default.EMPTY, Advice.StackMapFrameHandler.Default.EMPTY.length, Advice.StackMapFrameHandler.Default.EMPTY);
/*       */               } else {
/*  7992 */                 methodVisitor.visitFrame(4, Advice.StackMapFrameHandler.Default.EMPTY.length, Advice.StackMapFrameHandler.Default.EMPTY, 1, new Object[] { Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(stack.get(0)) });
/*       */               } 
/*       */             } else {
/*  7995 */               Object[] local = new Object[this.intermediateTypes.size()];
/*  7996 */               int index = 0;
/*  7997 */               for (TypeDescription typeDescription : this.intermediateTypes) {
/*  7998 */                 local[index++] = Advice.StackMapFrameHandler.Default.Initialization.INITIALIZED.toFrame(typeDescription);
/*       */               }
/*  8000 */               methodVisitor.visitFrame(1, local.length, local, Advice.StackMapFrameHandler.Default.EMPTY.length, Advice.StackMapFrameHandler.Default.EMPTY);
/*       */             } 
/*  8002 */           } else if (Advice.StackMapFrameHandler.Default.this.currentFrameDivergence < 3 && this.intermediateTypes.isEmpty() && stack.isEmpty()) {
/*  8003 */             methodVisitor.visitFrame(2, Advice.StackMapFrameHandler.Default.this.currentFrameDivergence, Advice.StackMapFrameHandler.Default.EMPTY, Advice.StackMapFrameHandler.Default.EMPTY.length, Advice.StackMapFrameHandler.Default.EMPTY);
/*       */           } else {
/*  8005 */             Advice.StackMapFrameHandler.Default.this.injectFullFrame(methodVisitor, this.initialization, CompoundList.of(this.startTypes, this.intermediateTypes), stack);
/*       */           } 
/*  8007 */           Advice.StackMapFrameHandler.Default.this.currentFrameDivergence = this.intermediateTypes.size() - this.endTypes.size();
/*  8008 */           this.intermediate = true;
/*       */         }
/*       */       }
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public enum Default
/*       */     implements ExceptionHandler
/*       */   {
/*  8036 */     SUPPRESSING
/*       */     {
/*       */       public StackManipulation resolve(MethodDescription instrumentedMethod, TypeDescription instrumentedType) {
/*  8039 */         return (StackManipulation)Removal.SINGLE;
/*       */       }
/*       */     },
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  8046 */     PRINTING
/*       */     {
/*       */       public StackManipulation resolve(MethodDescription instrumentedMethod, TypeDescription instrumentedType) {
/*       */         try {
/*  8050 */           return (StackManipulation)MethodInvocation.invoke((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(Throwable.class.getMethod("printStackTrace", new Class[0])));
/*  8051 */         } catch (NoSuchMethodException exception) {
/*  8052 */           throw new IllegalStateException("Cannot locate Throwable::printStackTrace");
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         }
/*       */       
/*       */       }
/*       */     },
/*  8062 */     RETHROWING
/*       */     {
/*       */       public StackManipulation resolve(MethodDescription instrumentedMethod, TypeDescription instrumentedType) {
/*  8065 */         return (StackManipulation)Throw.INSTANCE; } }; } public static interface ExceptionHandler { StackManipulation resolve(MethodDescription param1MethodDescription, TypeDescription param1TypeDescription); public enum Default implements ExceptionHandler { SUPPRESSING { public StackManipulation resolve(MethodDescription instrumentedMethod, TypeDescription instrumentedType) { return (StackManipulation)Removal.SINGLE; } }, PRINTING { public StackManipulation resolve(MethodDescription instrumentedMethod, TypeDescription instrumentedType) { try { return (StackManipulation)MethodInvocation.invoke((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(Throwable.class.getMethod("printStackTrace", new Class[0]))); } catch (NoSuchMethodException exception) { throw new IllegalStateException("Cannot locate Throwable::printStackTrace"); }  } }, RETHROWING { public StackManipulation resolve(MethodDescription instrumentedMethod, TypeDescription instrumentedType) { return (StackManipulation)Throw.INSTANCE; }
/*       */          }
/*       */       ; }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class Simple
/*       */       implements ExceptionHandler
/*       */     {
/*       */       private final StackManipulation stackManipulation;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Simple(StackManipulation stackManipulation) {
/*  8087 */         this.stackManipulation = stackManipulation;
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public StackManipulation resolve(MethodDescription instrumentedMethod, TypeDescription instrumentedType)
/*       */       {
/*  8094 */         return this.stackManipulation; } public boolean equals(@MaybeNull Object param2Object) { return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.stackManipulation.equals(((Simple)param2Object).stackManipulation)))); } public int hashCode() { return getClass().hashCode() * 31 + this.stackManipulation.hashCode(); } } } @Enhance public static class Simple implements ExceptionHandler { private final StackManipulation stackManipulation; public Simple(StackManipulation stackManipulation) { this.stackManipulation = stackManipulation; } public StackManipulation resolve(MethodDescription instrumentedMethod, TypeDescription instrumentedType) { return this.stackManipulation; }
/*       */ 
/*       */     
/*       */     public boolean equals(@MaybeNull Object param1Object) {
/*       */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.stackManipulation.equals(((Simple)param1Object).stackManipulation))));
/*       */     }
/*       */     
/*       */     public int hashCode() {
/*       */       return getClass().hashCode() * 31 + this.stackManipulation.hashCode();
/*       */     } }
/*       */ 
/*       */   
/*       */   protected static interface Dispatcher {
/*       */     @AlwaysNull
/*  8108 */     public static final MethodVisitor IGNORE_METHOD = null;
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @AlwaysNull
/*  8114 */     public static final AnnotationVisitor IGNORE_ANNOTATION = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     boolean isAlive();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     TypeDefinition getAdviceType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface Unresolved
/*       */       extends Dispatcher
/*       */     {
/*       */       boolean isBinary();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Map<String, TypeDefinition> getNamedTypes();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Advice.Dispatcher.Resolved.ForMethodEnter asMethodEnter(List<? extends Advice.OffsetMapping.Factory<?>> param2List, @MaybeNull AsmClassReader param2AsmClassReader, Unresolved param2Unresolved, Advice.PostProcessor.Factory param2Factory);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Advice.Dispatcher.Resolved.ForMethodExit asMethodExit(List<? extends Advice.OffsetMapping.Factory<?>> param2List, @MaybeNull AsmClassReader param2AsmClassReader, Unresolved param2Unresolved, Advice.PostProcessor.Factory param2Factory);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface SuppressionHandler
/*       */     {
/*       */       Bound bind(StackManipulation param2StackManipulation);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static interface Bound
/*       */       {
/*       */         void onPrepare(MethodVisitor param3MethodVisitor);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         void onStart(MethodVisitor param3MethodVisitor);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         void onEnd(MethodVisitor param3MethodVisitor, Implementation.Context param3Context, Advice.MethodSizeHandler.ForAdvice param3ForAdvice, Advice.StackMapFrameHandler.ForAdvice param3ForAdvice1, TypeDefinition param3TypeDefinition);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         void onEndWithSkip(MethodVisitor param3MethodVisitor, Implementation.Context param3Context, Advice.MethodSizeHandler.ForAdvice param3ForAdvice, Advice.StackMapFrameHandler.ForAdvice param3ForAdvice1, TypeDefinition param3TypeDefinition);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum NoOp
/*       */         implements SuppressionHandler, Bound
/*       */       {
/*  8249 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.Dispatcher.SuppressionHandler.Bound bind(StackManipulation exceptionHandler) {
/*  8255 */           return this;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onPrepare(MethodVisitor methodVisitor) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onStart(MethodVisitor methodVisitor) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onEnd(MethodVisitor methodVisitor, Implementation.Context implementationContext, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDefinition returnType) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void onEndWithSkip(MethodVisitor methodVisitor, Implementation.Context implementationContext, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDefinition returnType) {}
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Suppressing
/*       */         implements SuppressionHandler
/*       */       {
/*       */         private final TypeDescription suppressedType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Suppressing(TypeDescription suppressedType) {
/*  8312 */           this.suppressedType = suppressedType;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static Advice.Dispatcher.SuppressionHandler of(TypeDescription suppressedType) {
/*  8322 */           return suppressedType.represents(Advice.NoExceptionHandler.class) ? Advice.Dispatcher.SuppressionHandler.NoOp.INSTANCE : new Suppressing(suppressedType);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.Dispatcher.SuppressionHandler.Bound bind(StackManipulation exceptionHandler) {
/*  8331 */           return new Bound(this.suppressedType, exceptionHandler);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!!this.suppressedType.equals(((Suppressing)param3Object).suppressedType))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.suppressedType.hashCode();
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         protected static class Bound
/*       */           implements Advice.Dispatcher.SuppressionHandler.Bound
/*       */         {
/*       */           private final TypeDescription suppressedType;
/*       */ 
/*       */           
/*       */           private final StackManipulation exceptionHandler;
/*       */ 
/*       */           
/*       */           private final Label startOfMethod;
/*       */ 
/*       */           
/*       */           private final Label endOfMethod;
/*       */ 
/*       */ 
/*       */           
/*       */           protected Bound(TypeDescription suppressedType, StackManipulation exceptionHandler) {
/*  8366 */             this.suppressedType = suppressedType;
/*  8367 */             this.exceptionHandler = exceptionHandler;
/*  8368 */             this.startOfMethod = new Label();
/*  8369 */             this.endOfMethod = new Label();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void onPrepare(MethodVisitor methodVisitor) {
/*  8376 */             methodVisitor.visitTryCatchBlock(this.startOfMethod, this.endOfMethod, this.endOfMethod, this.suppressedType.getInternalName());
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void onStart(MethodVisitor methodVisitor) {
/*  8383 */             methodVisitor.visitLabel(this.startOfMethod);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void onEnd(MethodVisitor methodVisitor, Implementation.Context implementationContext, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDefinition returnType) {
/*  8394 */             methodVisitor.visitLabel(this.endOfMethod);
/*  8395 */             stackMapFrameHandler.injectExceptionFrame(methodVisitor);
/*  8396 */             methodSizeHandler.requireStackSize(1 + this.exceptionHandler.apply(methodVisitor, implementationContext).getMaximalSize());
/*  8397 */             if (returnType.represents(boolean.class) || returnType
/*  8398 */               .represents(byte.class) || returnType
/*  8399 */               .represents(short.class) || returnType
/*  8400 */               .represents(char.class) || returnType
/*  8401 */               .represents(int.class)) {
/*  8402 */               methodVisitor.visitInsn(3);
/*  8403 */             } else if (returnType.represents(long.class)) {
/*  8404 */               methodVisitor.visitInsn(9);
/*  8405 */             } else if (returnType.represents(float.class)) {
/*  8406 */               methodVisitor.visitInsn(11);
/*  8407 */             } else if (returnType.represents(double.class)) {
/*  8408 */               methodVisitor.visitInsn(14);
/*  8409 */             } else if (!returnType.represents(void.class)) {
/*  8410 */               methodVisitor.visitInsn(1);
/*       */             } 
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void onEndWithSkip(MethodVisitor methodVisitor, Implementation.Context implementationContext, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDefinition returnType) {
/*  8422 */             Label skipExceptionHandler = new Label();
/*  8423 */             methodVisitor.visitJumpInsn(167, skipExceptionHandler);
/*  8424 */             onEnd(methodVisitor, implementationContext, methodSizeHandler, stackMapFrameHandler, returnType);
/*  8425 */             methodVisitor.visitLabel(skipExceptionHandler);
/*  8426 */             stackMapFrameHandler.injectReturnFrame(methodVisitor);
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface RelocationHandler
/*       */     {
/*       */       Bound bind(MethodDescription param2MethodDescription, Relocation param2Relocation);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static interface Relocation
/*       */       {
/*       */         void apply(MethodVisitor param3MethodVisitor);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class ForLabel
/*       */           implements Relocation
/*       */         {
/*       */           private final Label label;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public ForLabel(Label label) {
/*  8475 */             this.label = label;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void apply(MethodVisitor methodVisitor) {
/*  8482 */             methodVisitor.visitJumpInsn(167, this.label);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.label.equals(((ForLabel)param4Object).label))));
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return getClass().hashCode() * 31 + this.label.hashCode();
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public static interface Bound
/*       */       {
/*       */         public static final int NO_REQUIRED_SIZE = 0;
/*       */ 
/*       */ 
/*       */         
/*       */         int apply(MethodVisitor param3MethodVisitor, Implementation.Context param3Context, int param3Int);
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public enum Disabled
/*       */         implements RelocationHandler, Bound
/*       */       {
/*  8516 */         INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.Dispatcher.RelocationHandler.Bound bind(MethodDescription instrumentedMethod, Advice.Dispatcher.RelocationHandler.Relocation relocation) {
/*  8522 */           return this;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, int offset) {
/*  8529 */           return 0;
/*       */         }
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public enum ForValue
/*       */       {
/*  8541 */         BOOLEAN(21, 51, 154, 153, 0)
/*       */         {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected void convertValue(MethodVisitor methodVisitor) {}
/*       */         },
/*  8551 */         BYTE(21, 51, 154, 153, 0)
/*       */         {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected void convertValue(MethodVisitor methodVisitor) {}
/*       */         },
/*  8561 */         SHORT(21, 53, 154, 153, 0)
/*       */         {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected void convertValue(MethodVisitor methodVisitor) {}
/*       */         },
/*  8571 */         CHARACTER(21, 52, 154, 153, 0)
/*       */         {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected void convertValue(MethodVisitor methodVisitor) {}
/*       */         },
/*  8581 */         INTEGER(21, 46, 154, 153, 0)
/*       */         {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected void convertValue(MethodVisitor methodVisitor) {}
/*       */         },
/*  8591 */         LONG(22, 47, 154, 153, 0)
/*       */         {
/*       */           protected void convertValue(MethodVisitor methodVisitor) {
/*  8594 */             methodVisitor.visitInsn(136);
/*       */           }
/*       */         },
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  8601 */         FLOAT(23, 48, 154, 153, 2)
/*       */         {
/*       */           protected void convertValue(MethodVisitor methodVisitor) {
/*  8604 */             methodVisitor.visitInsn(11);
/*  8605 */             methodVisitor.visitInsn(149);
/*       */           }
/*       */         },
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  8612 */         DOUBLE(24, 49, 154, 153, 4)
/*       */         {
/*       */           protected void convertValue(MethodVisitor methodVisitor) {
/*  8615 */             methodVisitor.visitInsn(14);
/*  8616 */             methodVisitor.visitInsn(151);
/*       */           }
/*       */         },
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  8623 */         REFERENCE(25, 50, 199, 198, 0)
/*       */         {
/*       */           protected void convertValue(MethodVisitor methodVisitor) {}
/*       */         };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final int load;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final int arrayLoad;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final int defaultJump;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final int nonDefaultJump;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final int requiredSize;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         ForValue(int load, int arrayLoad, int defaultJump, int nonDefaultJump, int requiredSize) {
/*  8665 */           this.load = load;
/*  8666 */           this.arrayLoad = arrayLoad;
/*  8667 */           this.defaultJump = defaultJump;
/*  8668 */           this.nonDefaultJump = nonDefaultJump;
/*  8669 */           this.requiredSize = requiredSize;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static Advice.Dispatcher.RelocationHandler of(TypeDefinition typeDefinition, int index, boolean inverted) {
/*       */           ForValue skipDispatcher;
/*  8682 */           if (typeDefinition.represents(boolean.class))
/*  8683 */           { skipDispatcher = BOOLEAN; }
/*  8684 */           else if (typeDefinition.represents(byte.class))
/*  8685 */           { skipDispatcher = BYTE; }
/*  8686 */           else if (typeDefinition.represents(short.class))
/*  8687 */           { skipDispatcher = SHORT; }
/*  8688 */           else if (typeDefinition.represents(char.class))
/*  8689 */           { skipDispatcher = CHARACTER; }
/*  8690 */           else if (typeDefinition.represents(int.class))
/*  8691 */           { skipDispatcher = INTEGER; }
/*  8692 */           else if (typeDefinition.represents(long.class))
/*  8693 */           { skipDispatcher = LONG; }
/*  8694 */           else if (typeDefinition.represents(float.class))
/*  8695 */           { skipDispatcher = FLOAT; }
/*  8696 */           else if (typeDefinition.represents(double.class))
/*  8697 */           { skipDispatcher = DOUBLE; }
/*  8698 */           else { if (typeDefinition.represents(void.class)) {
/*  8699 */               throw new IllegalStateException("Cannot skip on default value for void return type");
/*       */             }
/*  8701 */             skipDispatcher = REFERENCE; }
/*       */           
/*  8703 */           skipDispatcher.getClass(); skipDispatcher.getClass(); return inverted ? new OfNonDefault(index) : new OfDefault(index);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected abstract void convertValue(MethodVisitor param3MethodVisitor);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance(includeSyntheticFields = true)
/*       */         protected class OfDefault
/*       */           implements Advice.Dispatcher.RelocationHandler
/*       */         {
/*       */           private final int index;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public OfDefault(int index) {
/*  8732 */             this.index = index;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Advice.Dispatcher.RelocationHandler.Bound bind(MethodDescription instrumentedMethod, Advice.Dispatcher.RelocationHandler.Relocation relocation) {
/*  8739 */             return new Advice.Dispatcher.RelocationHandler.ForValue.Bound(instrumentedMethod, relocation, this.index, false);
/*       */           }
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : ((this.index != ((OfDefault)param4Object).index) ? false : (!!Advice.Dispatcher.RelocationHandler.ForValue.this.equals(Advice.Dispatcher.RelocationHandler.ForValue.this)))));
/*       */           }
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return (getClass().hashCode() * 31 + this.index) * 31 + Advice.Dispatcher.RelocationHandler.ForValue.this.hashCode();
/*       */           }
/*       */         }
/*       */         
/*       */         @Enhance(includeSyntheticFields = true)
/*       */         protected class OfNonDefault
/*       */           implements Advice.Dispatcher.RelocationHandler
/*       */         {
/*       */           private final int index;
/*       */           
/*       */           protected OfNonDefault(int index) {
/*  8760 */             this.index = index;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Advice.Dispatcher.RelocationHandler.Bound bind(MethodDescription instrumentedMethod, Advice.Dispatcher.RelocationHandler.Relocation relocation) {
/*  8767 */             return new Advice.Dispatcher.RelocationHandler.ForValue.Bound(instrumentedMethod, relocation, this.index, true);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : ((this.index != ((OfNonDefault)param4Object).index) ? false : (!!Advice.Dispatcher.RelocationHandler.ForValue.this.equals(Advice.Dispatcher.RelocationHandler.ForValue.this)))));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return (getClass().hashCode() * 31 + this.index) * 31 + Advice.Dispatcher.RelocationHandler.ForValue.this.hashCode();
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance(includeSyntheticFields = true)
/*       */         protected class Bound
/*       */           implements Advice.Dispatcher.RelocationHandler.Bound
/*       */         {
/*       */           private final MethodDescription instrumentedMethod;
/*       */ 
/*       */           
/*       */           private final Advice.Dispatcher.RelocationHandler.Relocation relocation;
/*       */ 
/*       */           
/*       */           private final int index;
/*       */ 
/*       */           
/*       */           private final boolean inverted;
/*       */ 
/*       */ 
/*       */           
/*       */           protected Bound(MethodDescription instrumentedMethod, Advice.Dispatcher.RelocationHandler.Relocation relocation, int index, boolean inverted) {
/*  8806 */             this.instrumentedMethod = instrumentedMethod;
/*  8807 */             this.relocation = relocation;
/*  8808 */             this.index = index;
/*  8809 */             this.inverted = inverted;
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, int offset) {
/*       */             int size;
/*  8816 */             if (this.instrumentedMethod.isConstructor()) {
/*  8817 */               throw new IllegalStateException("Cannot skip code execution from constructor: " + this.instrumentedMethod);
/*       */             }
/*  8819 */             Label noSkip = new Label();
/*       */             
/*  8821 */             if (this.index < 0) {
/*  8822 */               size = Advice.Dispatcher.RelocationHandler.ForValue.access$3300(Advice.Dispatcher.RelocationHandler.ForValue.this);
/*  8823 */               methodVisitor.visitVarInsn(Advice.Dispatcher.RelocationHandler.ForValue.access$3400(Advice.Dispatcher.RelocationHandler.ForValue.this), offset);
/*       */             } else {
/*  8825 */               methodVisitor.visitVarInsn(25, offset);
/*  8826 */               methodVisitor.visitJumpInsn(198, noSkip);
/*  8827 */               methodVisitor.visitVarInsn(25, offset);
/*  8828 */               size = Math.max(Advice.Dispatcher.RelocationHandler.ForValue.access$3300(Advice.Dispatcher.RelocationHandler.ForValue.this), IntegerConstant.forValue(this.index)
/*  8829 */                   .apply(methodVisitor, implementationContext)
/*  8830 */                   .getMaximalSize() + 1);
/*  8831 */               methodVisitor.visitInsn(Advice.Dispatcher.RelocationHandler.ForValue.access$3500(Advice.Dispatcher.RelocationHandler.ForValue.this));
/*       */             } 
/*  8833 */             Advice.Dispatcher.RelocationHandler.ForValue.this.convertValue(methodVisitor);
/*  8834 */             methodVisitor.visitJumpInsn(this.inverted ? 
/*  8835 */                 Advice.Dispatcher.RelocationHandler.ForValue.access$3600(Advice.Dispatcher.RelocationHandler.ForValue.this) : 
/*  8836 */                 Advice.Dispatcher.RelocationHandler.ForValue.access$3700(Advice.Dispatcher.RelocationHandler.ForValue.this), noSkip);
/*  8837 */             this.relocation.apply(methodVisitor);
/*  8838 */             methodVisitor.visitLabel(noSkip);
/*  8839 */             return size;
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : ((this.index != ((Bound)param4Object).index) ? false : ((this.inverted != ((Bound)param4Object).inverted) ? false : (!Advice.Dispatcher.RelocationHandler.ForValue.this.equals(Advice.Dispatcher.RelocationHandler.ForValue.this) ? false : (!this.instrumentedMethod.equals(((Bound)param4Object).instrumentedMethod) ? false : (!!this.relocation.equals(((Bound)param4Object).relocation))))))));
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return ((((getClass().hashCode() * 31 + this.instrumentedMethod.hashCode()) * 31 + this.relocation.hashCode()) * 31 + this.index) * 31 + this.inverted) * 31 + Advice.Dispatcher.RelocationHandler.ForValue.this.hashCode();
/*       */           }
/*       */         }
/*       */       }
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class ForType
/*       */         implements RelocationHandler
/*       */       {
/*       */         private final TypeDescription typeDescription;
/*       */         
/*       */         private final int index;
/*       */ 
/*       */         
/*       */         protected ForType(TypeDescription typeDescription, int index) {
/*  8867 */           this.typeDescription = typeDescription;
/*  8868 */           this.index = index;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */         protected static Advice.Dispatcher.RelocationHandler of(TypeDescription typeDescription, int index, TypeDefinition returnedType) {
/*       */           TypeDefinition targetType;
/*  8882 */           if (index < 0) {
/*  8883 */             targetType = returnedType;
/*  8884 */           } else if (returnedType.isArray()) {
/*  8885 */             targetType = returnedType.getComponentType();
/*       */           } else {
/*  8887 */             throw new IllegalStateException(returnedType + " is not an array type but an index for a relocation is defined");
/*       */           } 
/*  8889 */           if (typeDescription.represents(void.class))
/*  8890 */             return Advice.Dispatcher.RelocationHandler.Disabled.INSTANCE; 
/*  8891 */           if (typeDescription.represents(Advice.OnDefaultValue.class))
/*  8892 */             return Advice.Dispatcher.RelocationHandler.ForValue.of(targetType, index, false); 
/*  8893 */           if (typeDescription.represents(Advice.OnNonDefaultValue.class))
/*  8894 */             return Advice.Dispatcher.RelocationHandler.ForValue.of(targetType, index, true); 
/*  8895 */           if (typeDescription.isPrimitive() || targetType.isPrimitive()) {
/*  8896 */             throw new IllegalStateException("Cannot relocate execution by instance type for primitive type");
/*       */           }
/*  8898 */           return new ForType(typeDescription, index);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.Dispatcher.RelocationHandler.Bound bind(MethodDescription instrumentedMethod, Advice.Dispatcher.RelocationHandler.Relocation relocation) {
/*  8906 */           return new Bound(instrumentedMethod, relocation);
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.index != ((ForType)param3Object).index) ? false : (!!this.typeDescription.equals(((ForType)param3Object).typeDescription)))));
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return (getClass().hashCode() * 31 + this.typeDescription.hashCode()) * 31 + this.index;
/*       */         }
/*       */ 
/*       */         
/*       */         @Enhance(includeSyntheticFields = true)
/*       */         protected class Bound
/*       */           implements Advice.Dispatcher.RelocationHandler.Bound
/*       */         {
/*       */           private final MethodDescription instrumentedMethod;
/*       */           
/*       */           private final Advice.Dispatcher.RelocationHandler.Relocation relocation;
/*       */ 
/*       */           
/*       */           protected Bound(MethodDescription instrumentedMethod, Advice.Dispatcher.RelocationHandler.Relocation relocation) {
/*  8932 */             this.instrumentedMethod = instrumentedMethod;
/*  8933 */             this.relocation = relocation;
/*       */           }
/*       */ 
/*       */ 
/*       */           
/*       */           public int apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, int offset) {
/*       */             int size;
/*  8940 */             if (this.instrumentedMethod.isConstructor()) {
/*  8941 */               throw new IllegalStateException("Cannot skip code execution from constructor: " + this.instrumentedMethod);
/*       */             }
/*  8943 */             methodVisitor.visitVarInsn(25, offset);
/*  8944 */             Label noSkip = new Label();
/*       */             
/*  8946 */             if (Advice.Dispatcher.RelocationHandler.ForType.access$3800(Advice.Dispatcher.RelocationHandler.ForType.this) < 0) {
/*  8947 */               size = 0;
/*       */             } else {
/*  8949 */               methodVisitor.visitJumpInsn(198, noSkip);
/*  8950 */               methodVisitor.visitVarInsn(25, offset);
/*       */ 
/*       */               
/*  8953 */               size = IntegerConstant.forValue(Advice.Dispatcher.RelocationHandler.ForType.access$3800(Advice.Dispatcher.RelocationHandler.ForType.this)).apply(methodVisitor, implementationContext).getMaximalSize() + 1;
/*  8954 */               methodVisitor.visitInsn(50);
/*       */             } 
/*  8956 */             methodVisitor.visitTypeInsn(193, Advice.Dispatcher.RelocationHandler.ForType.access$3900(Advice.Dispatcher.RelocationHandler.ForType.this).getInternalName());
/*  8957 */             methodVisitor.visitJumpInsn(153, noSkip);
/*  8958 */             this.relocation.apply(methodVisitor);
/*  8959 */             methodVisitor.visitLabel(noSkip);
/*  8960 */             return size;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.instrumentedMethod.equals(((Bound)param4Object).instrumentedMethod) ? false : (!this.relocation.equals(((Bound)param4Object).relocation) ? false : (!!Advice.Dispatcher.RelocationHandler.ForType.this.equals(Advice.Dispatcher.RelocationHandler.ForType.this))))));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return ((getClass().hashCode() * 31 + this.instrumentedMethod.hashCode()) * 31 + this.relocation.hashCode()) * 31 + Advice.Dispatcher.RelocationHandler.ForType.this.hashCode();
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface Resolved
/*       */       extends Dispatcher
/*       */     {
/*       */       Map<String, TypeDefinition> getNamedTypes();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Advice.Dispatcher.Bound bind(TypeDescription param2TypeDescription, MethodDescription param2MethodDescription, MethodVisitor param2MethodVisitor, Implementation.Context param2Context, Assigner param2Assigner, Advice.ArgumentHandler.ForInstrumentedMethod param2ForInstrumentedMethod, Advice.MethodSizeHandler.ForInstrumentedMethod param2ForInstrumentedMethod1, Advice.StackMapFrameHandler.ForInstrumentedMethod param2ForInstrumentedMethod2, StackManipulation param2StackManipulation, Advice.Dispatcher.RelocationHandler.Relocation param2Relocation);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static abstract class AbstractBase
/*       */         implements Resolved
/*       */       {
/*       */         protected final Advice.PostProcessor postProcessor;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final Map<Integer, Advice.OffsetMapping> offsetMappings;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final Advice.Dispatcher.SuppressionHandler suppressionHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final Advice.Dispatcher.RelocationHandler relocationHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected AbstractBase(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> factories, TypeDescription throwableType, TypeDescription relocatableType, int relocatableIndex, Advice.OffsetMapping.Factory.AdviceType adviceType) {
/*  9089 */           this.postProcessor = postProcessor;
/*  9090 */           Map<TypeDescription, Advice.OffsetMapping.Factory<?>> offsetMappings = new HashMap<TypeDescription, Advice.OffsetMapping.Factory<?>>();
/*  9091 */           for (Advice.OffsetMapping.Factory<?> factory : factories) {
/*  9092 */             offsetMappings.put(TypeDescription.ForLoadedType.of(factory.getAnnotationType()), factory);
/*       */           }
/*  9094 */           this.offsetMappings = new LinkedHashMap<Integer, Advice.OffsetMapping>();
/*  9095 */           for (ParameterDescription.InDefinedShape parameterDescription : adviceMethod.getParameters()) {
/*  9096 */             Advice.OffsetMapping offsetMapping = null;
/*  9097 */             for (AnnotationDescription annotationDescription : parameterDescription.getDeclaredAnnotations()) {
/*  9098 */               Advice.OffsetMapping.Factory<?> factory = offsetMappings.get(annotationDescription.getAnnotationType());
/*  9099 */               if (factory != null) {
/*       */                 
/*  9101 */                 Advice.OffsetMapping current = factory.make(parameterDescription, annotationDescription
/*  9102 */                     .prepare(factory.getAnnotationType()), adviceType);
/*       */                 
/*  9104 */                 if (offsetMapping == null) {
/*  9105 */                   offsetMapping = current; continue;
/*       */                 } 
/*  9107 */                 throw new IllegalStateException(parameterDescription + " is bound to both " + current + " and " + offsetMapping);
/*       */               } 
/*       */             } 
/*       */             
/*  9111 */             this.offsetMappings.put(Integer.valueOf(parameterDescription.getOffset()), (offsetMapping == null) ? new Advice.OffsetMapping.ForArgument.Unresolved((ParameterDescription)parameterDescription) : offsetMapping);
/*       */           } 
/*       */ 
/*       */           
/*  9115 */           this.suppressionHandler = Advice.Dispatcher.SuppressionHandler.Suppressing.of(throwableType);
/*  9116 */           this.relocationHandler = Advice.Dispatcher.RelocationHandler.ForType.of(relocatableType, relocatableIndex, (TypeDefinition)adviceMethod.getReturnType());
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean isAlive() {
/*  9123 */           return true;
/*       */         }
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.postProcessor.equals(((AbstractBase)param3Object).postProcessor) ? false : (!this.offsetMappings.equals(((AbstractBase)param3Object).offsetMappings) ? false : (!this.suppressionHandler.equals(((AbstractBase)param3Object).suppressionHandler) ? false : (!!this.relocationHandler.equals(((AbstractBase)param3Object).relocationHandler)))))));
/*       */         }
/*       */         
/*       */         public int hashCode() {
/*       */           return (((getClass().hashCode() * 31 + this.postProcessor.hashCode()) * 31 + this.offsetMappings.hashCode()) * 31 + this.suppressionHandler.hashCode()) * 31 + this.relocationHandler.hashCode();
/*       */         }
/*       */       }
/*       */       
/*       */       public static interface ForMethodExit extends Resolved {
/*       */         TypeDescription getThrowable();
/*       */         
/*       */         Advice.ArgumentHandler.Factory getArgumentHandlerFactory();
/*       */       }
/*       */       
/*       */       public static interface ForMethodEnter extends Resolved {
/*       */         boolean isPrependLineNumber();
/*       */         
/*       */         TypeDefinition getActualAdviceType();
/*       */       }
/*       */     }
/*       */     
/*       */     public static interface Bound {
/*       */       void prepare();
/*       */       
/*       */       void initialize();
/*       */       
/*       */       void apply();
/*       */     }
/*       */     
/*       */     public enum Inactive implements Unresolved, Resolved.ForMethodEnter, Resolved.ForMethodExit, Bound {
/*  9157 */       INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isAlive() {
/*  9163 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isBinary() {
/*  9170 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription getAdviceType() {
/*  9177 */         return TypeDescription.ForLoadedType.of(void.class);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isPrependLineNumber() {
/*  9184 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDefinition getActualAdviceType() {
/*  9191 */         return (TypeDefinition)TypeDescription.ForLoadedType.of(void.class);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Map<String, TypeDefinition> getNamedTypes() {
/*  9198 */         return Collections.emptyMap();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription getThrowable() {
/*  9205 */         return Advice.NoExceptionHandler.DESCRIPTION;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.ArgumentHandler.Factory getArgumentHandlerFactory() {
/*  9212 */         return Advice.ArgumentHandler.Factory.SIMPLE;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.Dispatcher.Resolved.ForMethodEnter asMethodEnter(List<? extends Advice.OffsetMapping.Factory<?>> userFactories, @MaybeNull AsmClassReader classReader, Advice.Dispatcher.Unresolved methodExit, Advice.PostProcessor.Factory postProcessorFactory) {
/*  9222 */         return this;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.Dispatcher.Resolved.ForMethodExit asMethodExit(List<? extends Advice.OffsetMapping.Factory<?>> userFactories, @MaybeNull AsmClassReader classReader, Advice.Dispatcher.Unresolved methodEnter, Advice.PostProcessor.Factory postProcessorFactory) {
/*  9232 */         return this;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void prepare() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void initialize() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void apply() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.Dispatcher.Bound bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) {
/*  9269 */         return this;
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class Inlining
/*       */       implements Unresolved
/*       */     {
/*       */       protected final MethodDescription.InDefinedShape adviceMethod;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final Map<String, TypeDefinition> namedTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected Inlining(MethodDescription.InDefinedShape adviceMethod) {
/*  9295 */         this.adviceMethod = adviceMethod;
/*  9296 */         this.namedTypes = new HashMap<String, TypeDefinition>();
/*  9297 */         for (ParameterDescription parameterDescription : adviceMethod.getParameters()) {
/*  9298 */           AnnotationDescription.Loadable<Advice.Local> annotationDescription = parameterDescription.getDeclaredAnnotations().ofType(Advice.Local.class);
/*  9299 */           if (annotationDescription != null) {
/*  9300 */             String name = (String)annotationDescription.getValue(Advice.OffsetMapping.ForLocalValue.Factory.LOCAL_VALUE).resolve(String.class);
/*  9301 */             TypeDefinition previous = (TypeDefinition)this.namedTypes.put(name, parameterDescription.getType());
/*  9302 */             if (previous != null && !previous.equals(parameterDescription.getType())) {
/*  9303 */               throw new IllegalStateException("Local variable for " + name + " is defined with inconsistent types");
/*       */             }
/*       */           } 
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isAlive() {
/*  9313 */         return true;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isBinary() {
/*  9320 */         return true;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDescription getAdviceType() {
/*  9327 */         return this.adviceMethod.getReturnType().asErasure();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Map<String, TypeDefinition> getNamedTypes() {
/*  9334 */         return this.namedTypes;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.Dispatcher.Resolved.ForMethodEnter asMethodEnter(List<? extends Advice.OffsetMapping.Factory<?>> userFactories, @MaybeNull AsmClassReader classReader, Advice.Dispatcher.Unresolved methodExit, Advice.PostProcessor.Factory postProcessorFactory) {
/*  9344 */         if (classReader == null) {
/*  9345 */           throw new IllegalStateException("Class reader not expected null");
/*       */         }
/*  9347 */         return Resolved.ForMethodEnter.of(this.adviceMethod, postProcessorFactory
/*  9348 */             .make((List<? extends AnnotationDescription>)this.adviceMethod.getDeclaredAnnotations(), this.adviceMethod.getReturnType().asErasure(), false), this.namedTypes, userFactories, methodExit
/*       */ 
/*       */             
/*  9351 */             .getAdviceType(), classReader, methodExit
/*       */             
/*  9353 */             .isAlive());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.Dispatcher.Resolved.ForMethodExit asMethodExit(List<? extends Advice.OffsetMapping.Factory<?>> userFactories, @MaybeNull AsmClassReader classReader, Advice.Dispatcher.Unresolved methodEnter, Advice.PostProcessor.Factory postProcessorFactory) {
/*  9363 */         Map<String, TypeDefinition> namedTypes = new HashMap<String, TypeDefinition>(methodEnter.getNamedTypes()), uninitializedNamedTypes = new HashMap<String, TypeDefinition>();
/*  9364 */         for (Map.Entry<String, TypeDefinition> entry : this.namedTypes.entrySet()) {
/*  9365 */           TypeDefinition typeDefinition = namedTypes.get(entry.getKey()), uninitializedTypeDefinition = uninitializedNamedTypes.get(entry.getKey());
/*  9366 */           if (typeDefinition == null && uninitializedTypeDefinition == null) {
/*  9367 */             namedTypes.put(entry.getKey(), entry.getValue());
/*  9368 */             uninitializedNamedTypes.put(entry.getKey(), entry.getValue()); continue;
/*  9369 */           }  if (!((typeDefinition == null) ? uninitializedTypeDefinition : typeDefinition).equals(entry.getValue())) {
/*  9370 */             throw new IllegalStateException("Local variable for " + (String)entry.getKey() + " is defined with inconsistent types");
/*       */           }
/*       */         } 
/*  9373 */         return Resolved.ForMethodExit.of(this.adviceMethod, postProcessorFactory.make((List<? extends AnnotationDescription>)this.adviceMethod.getDeclaredAnnotations(), this.adviceMethod
/*  9374 */               .getReturnType().asErasure(), true), namedTypes, uninitializedNamedTypes, userFactories, classReader, methodEnter
/*  9375 */             .getAdviceType());
/*       */       }
/*       */ 
/*       */       
/*       */       public String toString() {
/*  9380 */         return "Delegate to " + this.adviceMethod;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.adviceMethod.equals(((Inlining)param2Object).adviceMethod) ? false : (!!this.namedTypes.equals(((Inlining)param2Object).namedTypes)))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return (getClass().hashCode() * 31 + this.adviceMethod.hashCode()) * 31 + this.namedTypes.hashCode();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static abstract class Resolved
/*       */         extends Advice.Dispatcher.Resolved.AbstractBase
/*       */       {
/*       */         protected final MethodDescription.InDefinedShape adviceMethod;
/*       */ 
/*       */ 
/*       */         
/*       */         protected final AsmClassReader classReader;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Resolved(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> factories, TypeDescription throwableType, TypeDescription relocatableType, int relocatableIndex, AsmClassReader classReader) {
/*  9416 */           super(adviceMethod, postProcessor, factories, throwableType, relocatableType, relocatableIndex, Advice.OffsetMapping.Factory.AdviceType.INLINING);
/*  9417 */           this.adviceMethod = adviceMethod;
/*  9418 */           this.classReader = classReader;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected abstract Map<Integer, TypeDefinition> resolveInitializationTypes(Advice.ArgumentHandler param3ArgumentHandler);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected abstract MethodVisitor apply(MethodVisitor param3MethodVisitor, Implementation.Context param3Context, Assigner param3Assigner, Advice.ArgumentHandler.ForInstrumentedMethod param3ForInstrumentedMethod, Advice.MethodSizeHandler.ForInstrumentedMethod param3ForInstrumentedMethod1, Advice.StackMapFrameHandler.ForInstrumentedMethod param3ForInstrumentedMethod2, TypeDescription param3TypeDescription, MethodDescription param3MethodDescription, Advice.Dispatcher.SuppressionHandler.Bound param3Bound, Advice.Dispatcher.RelocationHandler.Bound param3Bound1, StackManipulation param3StackManipulation);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected class AdviceMethodInliner
/*       */           extends ClassVisitor
/*       */           implements Advice.Dispatcher.Bound
/*       */         {
/*       */           protected final TypeDescription instrumentedType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final MethodDescription instrumentedMethod;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final MethodVisitor methodVisitor;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final Implementation.Context implementationContext;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final Assigner assigner;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final Advice.Dispatcher.RelocationHandler.Bound relocationHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final StackManipulation exceptionHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final AsmClassReader classReader;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final List<Label> labels;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected AdviceMethodInliner(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler, AsmClassReader classReader) {
/*  9556 */             super(OpenedClassReader.ASM_API);
/*  9557 */             this.instrumentedType = instrumentedType;
/*  9558 */             this.instrumentedMethod = instrumentedMethod;
/*  9559 */             this.methodVisitor = methodVisitor;
/*  9560 */             this.implementationContext = implementationContext;
/*  9561 */             this.assigner = assigner;
/*  9562 */             this.argumentHandler = argumentHandler;
/*  9563 */             this.methodSizeHandler = methodSizeHandler;
/*  9564 */             this.stackMapFrameHandler = stackMapFrameHandler;
/*  9565 */             this.suppressionHandler = suppressionHandler;
/*  9566 */             this.relocationHandler = relocationHandler;
/*  9567 */             this.exceptionHandler = exceptionHandler;
/*  9568 */             this.classReader = classReader;
/*  9569 */             this.labels = new ArrayList<Label>();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void prepare() {
/*  9576 */             this.classReader.accept(new ExceptionTableExtractor(), 6);
/*  9577 */             this.suppressionHandler.onPrepare(this.methodVisitor);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void initialize() {
/*  9584 */             for (Map.Entry<Integer, TypeDefinition> typeDefinition : Advice.Dispatcher.Inlining.Resolved.this.resolveInitializationTypes(this.argumentHandler).entrySet()) {
/*  9585 */               if (((TypeDefinition)typeDefinition.getValue()).represents(boolean.class) || ((TypeDefinition)typeDefinition
/*  9586 */                 .getValue()).represents(byte.class) || ((TypeDefinition)typeDefinition
/*  9587 */                 .getValue()).represents(short.class) || ((TypeDefinition)typeDefinition
/*  9588 */                 .getValue()).represents(char.class) || ((TypeDefinition)typeDefinition
/*  9589 */                 .getValue()).represents(int.class)) {
/*  9590 */                 this.methodVisitor.visitInsn(3);
/*  9591 */                 this.methodVisitor.visitVarInsn(54, ((Integer)typeDefinition.getKey()).intValue());
/*  9592 */               } else if (((TypeDefinition)typeDefinition.getValue()).represents(long.class)) {
/*  9593 */                 this.methodVisitor.visitInsn(9);
/*  9594 */                 this.methodVisitor.visitVarInsn(55, ((Integer)typeDefinition.getKey()).intValue());
/*  9595 */               } else if (((TypeDefinition)typeDefinition.getValue()).represents(float.class)) {
/*  9596 */                 this.methodVisitor.visitInsn(11);
/*  9597 */                 this.methodVisitor.visitVarInsn(56, ((Integer)typeDefinition.getKey()).intValue());
/*  9598 */               } else if (((TypeDefinition)typeDefinition.getValue()).represents(double.class)) {
/*  9599 */                 this.methodVisitor.visitInsn(14);
/*  9600 */                 this.methodVisitor.visitVarInsn(57, ((Integer)typeDefinition.getKey()).intValue());
/*       */               } else {
/*  9602 */                 this.methodVisitor.visitInsn(1);
/*  9603 */                 this.methodVisitor.visitVarInsn(58, ((Integer)typeDefinition.getKey()).intValue());
/*       */               } 
/*  9605 */               this.methodSizeHandler.requireStackSize(((TypeDefinition)typeDefinition.getValue()).getStackSize().getSize());
/*       */             } 
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void apply() {
/*  9613 */             this.classReader.accept(this, 0x2 | this.stackMapFrameHandler.getReaderHint());
/*       */           }
/*       */ 
/*       */           
/*       */           @MaybeNull
/*       */           public MethodVisitor visitMethod(int modifiers, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull String[] exception) {
/*  9619 */             return (Advice.Dispatcher.Inlining.Resolved.this.adviceMethod.getInternalName().equals(internalName) && Advice.Dispatcher.Inlining.Resolved.this.adviceMethod.getDescriptor().equals(descriptor)) ? new ExceptionTableSubstitutor(Advice.Dispatcher.Inlining.Resolved.this
/*  9620 */                 .apply(this.methodVisitor, this.implementationContext, this.assigner, this.argumentHandler, this.methodSizeHandler, this.stackMapFrameHandler, this.instrumentedType, this.instrumentedMethod, this.suppressionHandler, this.relocationHandler, this.exceptionHandler)) : Advice.Dispatcher.IGNORE_METHOD;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected class ExceptionTableExtractor
/*       */             extends ClassVisitor
/*       */           {
/*       */             protected ExceptionTableExtractor() {
/*  9642 */               super(OpenedClassReader.ASM_API);
/*       */             }
/*       */ 
/*       */             
/*       */             @MaybeNull
/*       */             public MethodVisitor visitMethod(int modifiers, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull String[] exception) {
/*  9648 */               return (Advice.Dispatcher.Inlining.Resolved.this.adviceMethod.getInternalName().equals(internalName) && Advice.Dispatcher.Inlining.Resolved.this.adviceMethod.getDescriptor().equals(descriptor)) ? new Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner.ExceptionTableCollector(Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner.this.methodVisitor) : Advice.Dispatcher.IGNORE_METHOD;
/*       */             }
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected class ExceptionTableCollector
/*       */             extends MethodVisitor
/*       */           {
/*       */             private final MethodVisitor methodVisitor;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             protected ExceptionTableCollector(MethodVisitor methodVisitor) {
/*  9671 */               super(OpenedClassReader.ASM_API);
/*  9672 */               this.methodVisitor = methodVisitor;
/*       */             }
/*       */ 
/*       */             
/*       */             public void visitTryCatchBlock(Label start, Label end, Label handler, @MaybeNull String type) {
/*  9677 */               this.methodVisitor.visitTryCatchBlock(start, end, handler, type);
/*  9678 */               Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner.this.labels.addAll(Arrays.asList(new Label[] { start, end, handler }));
/*       */             }
/*       */ 
/*       */             
/*       */             @MaybeNull
/*       */             public AnnotationVisitor visitTryCatchAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) {
/*  9684 */               return this.methodVisitor.visitTryCatchAnnotation(typeReference, typePath, descriptor, visible);
/*       */             }
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected class ExceptionTableSubstitutor
/*       */             extends MethodVisitor
/*       */           {
/*       */             private final Map<Label, Label> substitutions;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             private int index;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             protected ExceptionTableSubstitutor(MethodVisitor methodVisitor) {
/*  9712 */               super(OpenedClassReader.ASM_API, methodVisitor);
/*  9713 */               this.substitutions = new IdentityHashMap<Label, Label>();
/*       */             }
/*       */ 
/*       */             
/*       */             public void visitTryCatchBlock(Label start, Label end, Label handler, String type) {
/*  9718 */               this.substitutions.put(start, Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner.this.labels.get(this.index++));
/*  9719 */               this.substitutions.put(end, Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner.this.labels.get(this.index++));
/*  9720 */               Label actualHandler = Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner.this.labels.get(this.index++);
/*  9721 */               this.substitutions.put(handler, actualHandler);
/*  9722 */               ((Advice.Dispatcher.Inlining.CodeTranslationVisitor)this.mv).propagateHandler(actualHandler);
/*       */             }
/*       */ 
/*       */             
/*       */             @MaybeNull
/*       */             public AnnotationVisitor visitTryCatchAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) {
/*  9728 */               return Advice.Dispatcher.IGNORE_ANNOTATION;
/*       */             }
/*       */ 
/*       */             
/*       */             public void visitLabel(Label label) {
/*  9733 */               super.visitLabel(resolve(label));
/*       */             }
/*       */ 
/*       */             
/*       */             public void visitJumpInsn(int opcode, Label label) {
/*  9738 */               super.visitJumpInsn(opcode, resolve(label));
/*       */             }
/*       */ 
/*       */             
/*       */             public void visitTableSwitchInsn(int minimum, int maximum, Label defaultOption, Label... label) {
/*  9743 */               super.visitTableSwitchInsn(minimum, maximum, defaultOption, resolve(label));
/*       */             }
/*       */ 
/*       */             
/*       */             public void visitLookupSwitchInsn(Label defaultOption, int[] keys, Label[] label) {
/*  9748 */               super.visitLookupSwitchInsn(resolve(defaultOption), keys, resolve(label));
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             private Label[] resolve(Label[] label) {
/*  9758 */               Label[] resolved = new Label[label.length];
/*  9759 */               int index = 0;
/*  9760 */               for (Label aLabel : label) {
/*  9761 */                 resolved[index++] = resolve(aLabel);
/*       */               }
/*  9763 */               return resolved;
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             private Label resolve(Label label) {
/*  9773 */               Label substitution = this.substitutions.get(label);
/*  9774 */               return (substitution == null) ? label : substitution;
/*       */             }
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         protected static abstract class ForMethodEnter
/*       */           extends Resolved
/*       */           implements Advice.Dispatcher.Resolved.ForMethodEnter
/*       */         {
/*       */           private final Map<String, TypeDefinition> namedTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final boolean prependLineNumber;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.")
/*       */           protected ForMethodEnter(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, AsmClassReader classReader) {
/*  9815 */             super(adviceMethod, postProcessor, 
/*       */                 
/*  9817 */                 CompoundList.of(Arrays.asList(new Advice.OffsetMapping.Factory[] {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */                       
/*       */                       Advice.OffsetMapping.ForArgument.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForAllArguments.Factory.INSTANCE, Advice.OffsetMapping.ForThisReference.Factory.INSTANCE, Advice.OffsetMapping.ForField.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.ReaderFactory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.WriterFactory.INSTANCE, Advice.OffsetMapping.ForOrigin.Factory.INSTANCE, Advice.OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, Advice.OffsetMapping.ForHandle.Factory.INSTANCE, Advice.OffsetMapping.ForDynamicConstant.Factory.INSTANCE,
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */                       
/*  9830 */                       Advice.OffsetMapping.ForUnusedValue.Factory.INSTANCE, Advice.OffsetMapping.ForStubValue.INSTANCE, Advice.OffsetMapping.ForThrowable.Factory.INSTANCE, Advice.OffsetMapping.ForExitValue.Factory.of(exitType), new Advice.OffsetMapping.ForLocalValue.Factory(namedTypes), new Advice.OffsetMapping.Factory.Illegal<Advice.Thrown>(Advice.Thrown.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Enter>(Advice.Enter.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Return>(Advice.Return.class)
/*       */                     },
/*       */ 
/*       */ 
/*       */                   
/*  9835 */                   ), userFactories), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SUPPRESS_ENTER).resolve(TypeDescription.class), (TypeDescription)adviceMethod
/*  9836 */                 .getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SKIP_ON).resolve(TypeDescription.class), ((Integer)adviceMethod
/*  9837 */                 .getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SKIP_ON_INDEX).resolve(Integer.class)).intValue(), classReader);
/*       */             
/*  9839 */             this.namedTypes = namedTypes;
/*  9840 */             this.prependLineNumber = ((Boolean)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.PREPEND_LINE_NUMBER).resolve(Boolean.class)).booleanValue();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected static Advice.Dispatcher.Resolved.ForMethodEnter of(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, AsmClassReader classReader, boolean methodExit) {
/*  9862 */             return methodExit ? new WithRetainedEnterType(adviceMethod, postProcessor, namedTypes, userFactories, exitType, classReader) : new WithDiscardedEnterType(adviceMethod, postProcessor, namedTypes, userFactories, exitType, classReader);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected Map<Integer, TypeDefinition> resolveInitializationTypes(Advice.ArgumentHandler argumentHandler) {
/*  9869 */             SortedMap<Integer, TypeDefinition> resolved = new TreeMap<Integer, TypeDefinition>();
/*  9870 */             for (Map.Entry<String, TypeDefinition> entry : this.namedTypes.entrySet()) {
/*  9871 */               resolved.put(Integer.valueOf(argumentHandler.named(entry.getKey())), entry.getValue());
/*       */             }
/*  9873 */             return resolved;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Advice.Dispatcher.Bound bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) {
/*  9889 */             return new Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, this.suppressionHandler
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */                 
/*  9897 */                 .bind(exceptionHandler), this.relocationHandler
/*  9898 */                 .bind(instrumentedMethod, relocation), exceptionHandler, this.classReader);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean isPrependLineNumber() {
/*  9907 */             return this.prependLineNumber;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeDefinition getActualAdviceType() {
/*  9914 */             return (TypeDefinition)this.adviceMethod.getReturnType();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Map<String, TypeDefinition> getNamedTypes() {
/*  9921 */             return this.namedTypes;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected MethodVisitor apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) {
/*  9936 */             MethodDescription.TypeToken typeToken = this.adviceMethod.asTypeToken();
/*  9937 */             return doApply(methodVisitor, implementationContext, assigner, argumentHandler
/*       */ 
/*       */                 
/*  9940 */                 .bindEnter(typeToken), methodSizeHandler
/*  9941 */                 .bindEnter(typeToken), stackMapFrameHandler
/*  9942 */                 .bindEnter(typeToken), instrumentedType, instrumentedMethod, suppressionHandler, relocationHandler, exceptionHandler);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected MethodVisitor doApply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) {
/*  9977 */             Map<Integer, Advice.OffsetMapping.Target> offsetMappings = new HashMap<Integer, Advice.OffsetMapping.Target>();
/*  9978 */             for (Map.Entry<Integer, Advice.OffsetMapping> entry : this.offsetMappings.entrySet()) {
/*  9979 */               offsetMappings.put(entry.getKey(), ((Advice.OffsetMapping)entry.getValue()).resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, Advice.OffsetMapping.Sort.ENTER));
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*  9985 */             return new Advice.Dispatcher.Inlining.CodeTranslationVisitor(methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, instrumentedType, instrumentedMethod, assigner, this.adviceMethod, offsetMappings, suppressionHandler, relocationHandler, exceptionHandler, this.postProcessor, false);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : ((this.prependLineNumber != ((ForMethodEnter)param4Object).prependLineNumber) ? false : (!!this.namedTypes.equals(((ForMethodEnter)param4Object).namedTypes))))));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return (super.hashCode() * 31 + this.namedTypes.hashCode()) * 31 + this.prependLineNumber;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected static class WithRetainedEnterType
/*       */             extends ForMethodEnter
/*       */           {
/*       */             protected WithRetainedEnterType(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, AsmClassReader classReader) {
/* 10024 */               super(adviceMethod, postProcessor, namedTypes, userFactories, exitType, classReader);
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeDefinition getAdviceType() {
/* 10031 */               return (TypeDefinition)this.adviceMethod.getReturnType();
/*       */             }
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected static class WithDiscardedEnterType
/*       */             extends ForMethodEnter
/*       */           {
/*       */             protected WithDiscardedEnterType(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, AsmClassReader classReader) {
/* 10056 */               super(adviceMethod, postProcessor, namedTypes, userFactories, exitType, classReader);
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeDefinition getAdviceType() {
/* 10063 */               return (TypeDefinition)TypeDescription.ForLoadedType.of(void.class);
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             protected MethodVisitor doApply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) {
/* 10080 */               methodSizeHandler.requireLocalVariableLengthPadding(this.adviceMethod.getReturnType().getStackSize().getSize());
/* 10081 */               return super.doApply(methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, instrumentedType, instrumentedMethod, suppressionHandler, relocationHandler, exceptionHandler);
/*       */             }
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         protected static abstract class ForMethodExit
/*       */           extends Resolved
/*       */           implements Advice.Dispatcher.Resolved.ForMethodExit
/*       */         {
/*       */           private final Map<String, TypeDefinition> uninitializedNamedTypes;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final boolean backupArguments;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.")
/*       */           protected ForMethodExit(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, Map<String, TypeDefinition> uninitializedNamedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, AsmClassReader classReader, TypeDefinition enterType) {
/* 10132 */             super(adviceMethod, postProcessor, 
/*       */                 
/* 10134 */                 CompoundList.of(Arrays.asList(new Advice.OffsetMapping.Factory[] {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */                       
/*       */                       Advice.OffsetMapping.ForArgument.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForAllArguments.Factory.INSTANCE, Advice.OffsetMapping.ForThisReference.Factory.INSTANCE, Advice.OffsetMapping.ForField.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.ReaderFactory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.WriterFactory.INSTANCE, Advice.OffsetMapping.ForOrigin.Factory.INSTANCE, Advice.OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, Advice.OffsetMapping.ForHandle.Factory.INSTANCE, Advice.OffsetMapping.ForDynamicConstant.Factory.INSTANCE,
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */                       
/* 10146 */                       Advice.OffsetMapping.ForUnusedValue.Factory.INSTANCE, Advice.OffsetMapping.ForStubValue.INSTANCE, Advice.OffsetMapping.ForEnterValue.Factory.of(enterType), 
/* 10147 */                       Advice.OffsetMapping.ForExitValue.Factory.of((TypeDefinition)adviceMethod.getReturnType()), new Advice.OffsetMapping.ForLocalValue.Factory(namedTypes), Advice.OffsetMapping.ForReturnValue.Factory.INSTANCE, 
/*       */ 
/*       */                       
/* 10150 */                       Advice.OffsetMapping.ForThrowable.Factory.of(adviceMethod)
/*       */                     },
/* 10152 */                   ), userFactories), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.SUPPRESS_EXIT).resolve(TypeDescription.class), (TypeDescription)adviceMethod
/* 10153 */                 .getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.REPEAT_ON).resolve(TypeDescription.class), ((Integer)adviceMethod
/* 10154 */                 .getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.REPEAT_ON_INDEX).resolve(Integer.class)).intValue(), classReader);
/*       */             
/* 10156 */             this.uninitializedNamedTypes = uninitializedNamedTypes;
/* 10157 */             this.backupArguments = ((Boolean)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.BACKUP_ARGUMENTS).resolve(Boolean.class)).booleanValue();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.")
/*       */           protected static Advice.Dispatcher.Resolved.ForMethodExit of(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, Map<String, TypeDefinition> uninitializedNamedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, AsmClassReader classReader, TypeDefinition enterType) {
/* 10182 */             TypeDescription throwable = (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.ON_THROWABLE).resolve(TypeDescription.class);
/* 10183 */             return throwable.represents(Advice.NoExceptionHandler.class) ? new WithoutExceptionHandler(adviceMethod, postProcessor, namedTypes, uninitializedNamedTypes, userFactories, classReader, enterType) : new WithExceptionHandler(adviceMethod, postProcessor, namedTypes, uninitializedNamedTypes, userFactories, classReader, enterType, throwable);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Map<String, TypeDefinition> getNamedTypes() {
/* 10192 */             return this.uninitializedNamedTypes;
/*       */           }
/*       */ 
/*       */           
/*       */           protected Map<Integer, TypeDefinition> resolveInitializationTypes(Advice.ArgumentHandler argumentHandler) {
/* 10197 */             SortedMap<Integer, TypeDefinition> resolved = new TreeMap<Integer, TypeDefinition>();
/* 10198 */             for (Map.Entry<String, TypeDefinition> entry : this.uninitializedNamedTypes.entrySet()) {
/* 10199 */               resolved.put(Integer.valueOf(argumentHandler.named(entry.getKey())), entry.getValue());
/*       */             }
/* 10201 */             if (!this.adviceMethod.getReturnType().represents(void.class)) {
/* 10202 */               resolved.put(Integer.valueOf(argumentHandler.exit()), this.adviceMethod.getReturnType());
/*       */             }
/* 10204 */             return resolved;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected MethodVisitor apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) {
/* 10219 */             MethodDescription.TypeToken typeToken = this.adviceMethod.asTypeToken();
/* 10220 */             return doApply(methodVisitor, implementationContext, assigner, argumentHandler
/*       */ 
/*       */                 
/* 10223 */                 .bindExit(typeToken, getThrowable().represents(Advice.NoExceptionHandler.class)), methodSizeHandler
/* 10224 */                 .bindExit(typeToken), stackMapFrameHandler
/* 10225 */                 .bindExit(typeToken), instrumentedType, instrumentedMethod, suppressionHandler, relocationHandler, exceptionHandler);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private MethodVisitor doApply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) {
/* 10260 */             Map<Integer, Advice.OffsetMapping.Target> offsetMappings = new HashMap<Integer, Advice.OffsetMapping.Target>();
/* 10261 */             for (Map.Entry<Integer, Advice.OffsetMapping> entry : this.offsetMappings.entrySet()) {
/* 10262 */               offsetMappings.put(entry.getKey(), ((Advice.OffsetMapping)entry.getValue()).resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, Advice.OffsetMapping.Sort.EXIT));
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/* 10268 */             return new Advice.Dispatcher.Inlining.CodeTranslationVisitor(methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, instrumentedType, instrumentedMethod, assigner, this.adviceMethod, offsetMappings, suppressionHandler, relocationHandler, exceptionHandler, this.postProcessor, true);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Advice.ArgumentHandler.Factory getArgumentHandlerFactory() {
/* 10289 */             return this.backupArguments ? Advice.ArgumentHandler.Factory.COPYING : Advice.ArgumentHandler.Factory.SIMPLE;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeDefinition getAdviceType() {
/* 10298 */             return (TypeDefinition)this.adviceMethod.getReturnType();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Advice.Dispatcher.Bound bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) {
/* 10314 */             return new Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, this.suppressionHandler
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */                 
/* 10322 */                 .bind(exceptionHandler), this.relocationHandler
/* 10323 */                 .bind(instrumentedMethod, relocation), exceptionHandler, this.classReader);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : ((this.backupArguments != ((ForMethodExit)param4Object).backupArguments) ? false : (!!this.uninitializedNamedTypes.equals(((ForMethodExit)param4Object).uninitializedNamedTypes))))));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return (super.hashCode() * 31 + this.uninitializedNamedTypes.hashCode()) * 31 + this.backupArguments;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @Enhance
/*       */           protected static class WithExceptionHandler
/*       */             extends ForMethodExit
/*       */           {
/*       */             private final TypeDescription throwable;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             protected WithExceptionHandler(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, Map<String, TypeDefinition> uninitializedNamedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, AsmClassReader classReader, TypeDefinition enterType, TypeDescription throwable) {
/* 10360 */               super(adviceMethod, postProcessor, namedTypes, uninitializedNamedTypes, userFactories, classReader, enterType);
/* 10361 */               this.throwable = throwable;
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeDescription getThrowable() {
/* 10368 */               return this.throwable;
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public boolean equals(@MaybeNull Object param5Object) {
/*       */               return !super.equals(param5Object) ? false : ((this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.throwable.equals(((WithExceptionHandler)param5Object).throwable)))));
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public int hashCode() {
/*       */               return super.hashCode() * 31 + this.throwable.hashCode();
/*       */             }
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected static class WithoutExceptionHandler
/*       */             extends ForMethodExit
/*       */           {
/*       */             protected WithoutExceptionHandler(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, Map<String, TypeDefinition> uninitializedNamedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, AsmClassReader classReader, TypeDefinition enterType) {
/* 10396 */               super(adviceMethod, postProcessor, namedTypes, uninitializedNamedTypes, userFactories, classReader, enterType);
/*       */             }
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeDescription getThrowable()
/*       */             {
/* 10403 */               return Advice.NoExceptionHandler.DESCRIPTION; } } } } @Enhance protected static abstract class ForMethodEnter extends Resolved implements Advice.Dispatcher.Resolved.ForMethodEnter { private final Map<String, TypeDefinition> namedTypes; private final boolean prependLineNumber; @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected ForMethodEnter(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, AsmClassReader classReader) { super(adviceMethod, postProcessor, CompoundList.of(Arrays.asList(new Advice.OffsetMapping.Factory[] { Advice.OffsetMapping.ForArgument.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForAllArguments.Factory.INSTANCE, Advice.OffsetMapping.ForThisReference.Factory.INSTANCE, Advice.OffsetMapping.ForField.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.ReaderFactory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.WriterFactory.INSTANCE, Advice.OffsetMapping.ForOrigin.Factory.INSTANCE, Advice.OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, Advice.OffsetMapping.ForHandle.Factory.INSTANCE, Advice.OffsetMapping.ForDynamicConstant.Factory.INSTANCE, Advice.OffsetMapping.ForUnusedValue.Factory.INSTANCE, Advice.OffsetMapping.ForStubValue.INSTANCE, Advice.OffsetMapping.ForThrowable.Factory.INSTANCE, Advice.OffsetMapping.ForExitValue.Factory.of(exitType), new Advice.OffsetMapping.ForLocalValue.Factory(namedTypes), new Advice.OffsetMapping.Factory.Illegal<Advice.Thrown>(Advice.Thrown.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Enter>(Advice.Enter.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Return>(Advice.Return.class) }, ), userFactories), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SUPPRESS_ENTER).resolve(TypeDescription.class), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SKIP_ON).resolve(TypeDescription.class), ((Integer)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SKIP_ON_INDEX).resolve(Integer.class)).intValue(), classReader); this.namedTypes = namedTypes; this.prependLineNumber = ((Boolean)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.PREPEND_LINE_NUMBER).resolve(Boolean.class)).booleanValue(); } protected static Advice.Dispatcher.Resolved.ForMethodEnter of(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, AsmClassReader classReader, boolean methodExit) { return methodExit ? new WithRetainedEnterType(adviceMethod, postProcessor, namedTypes, userFactories, exitType, classReader) : new WithDiscardedEnterType(adviceMethod, postProcessor, namedTypes, userFactories, exitType, classReader); } protected Map<Integer, TypeDefinition> resolveInitializationTypes(Advice.ArgumentHandler argumentHandler) { SortedMap<Integer, TypeDefinition> resolved = new TreeMap<Integer, TypeDefinition>(); for (Map.Entry<String, TypeDefinition> entry : this.namedTypes.entrySet()) resolved.put(Integer.valueOf(argumentHandler.named(entry.getKey())), entry.getValue());  return resolved; } public Advice.Dispatcher.Bound bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) { return new Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner(this, instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, this.suppressionHandler.bind(exceptionHandler), this.relocationHandler.bind(instrumentedMethod, relocation), exceptionHandler, this.classReader); } public boolean isPrependLineNumber() { return this.prependLineNumber; } public TypeDefinition getActualAdviceType() { return (TypeDefinition)this.adviceMethod.getReturnType(); } public Map<String, TypeDefinition> getNamedTypes() { return this.namedTypes; } protected MethodVisitor apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { MethodDescription.TypeToken typeToken = this.adviceMethod.asTypeToken(); return doApply(methodVisitor, implementationContext, assigner, argumentHandler.bindEnter(typeToken), methodSizeHandler.bindEnter(typeToken), stackMapFrameHandler.bindEnter(typeToken), instrumentedType, instrumentedMethod, suppressionHandler, relocationHandler, exceptionHandler); } protected MethodVisitor doApply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { Map<Integer, Advice.OffsetMapping.Target> offsetMappings = new HashMap<Integer, Advice.OffsetMapping.Target>(); for (Map.Entry<Integer, Advice.OffsetMapping> entry : this.offsetMappings.entrySet()) offsetMappings.put(entry.getKey(), ((Advice.OffsetMapping)entry.getValue()).resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, Advice.OffsetMapping.Sort.ENTER));  return new Advice.Dispatcher.Inlining.CodeTranslationVisitor(methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, instrumentedType, instrumentedMethod, assigner, this.adviceMethod, offsetMappings, suppressionHandler, relocationHandler, exceptionHandler, this.postProcessor, false); } public boolean equals(@MaybeNull Object param3Object) { return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.prependLineNumber != ((ForMethodEnter)param3Object).prependLineNumber) ? false : (!!this.namedTypes.equals(((ForMethodEnter)param3Object).namedTypes)))))); } public int hashCode() { return (super.hashCode() * 31 + this.namedTypes.hashCode()) * 31 + this.prependLineNumber; } protected static class WithRetainedEnterType extends ForMethodEnter { protected WithRetainedEnterType(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, AsmClassReader classReader) { super(adviceMethod, postProcessor, namedTypes, userFactories, exitType, classReader); } public TypeDefinition getAdviceType() { return (TypeDefinition)this.adviceMethod.getReturnType(); } } protected static class WithDiscardedEnterType extends ForMethodEnter { protected WithDiscardedEnterType(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, AsmClassReader classReader) { super(adviceMethod, postProcessor, namedTypes, userFactories, exitType, classReader); } public TypeDefinition getAdviceType() { return (TypeDefinition)TypeDescription.ForLoadedType.of(void.class); } protected MethodVisitor doApply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { methodSizeHandler.requireLocalVariableLengthPadding(this.adviceMethod.getReturnType().getStackSize().getSize()); return super.doApply(methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, instrumentedType, instrumentedMethod, suppressionHandler, relocationHandler, exceptionHandler); } } } @Enhance protected static abstract class ForMethodExit extends Resolved implements Advice.Dispatcher.Resolved.ForMethodExit { private final Map<String, TypeDefinition> uninitializedNamedTypes; private final boolean backupArguments; @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected ForMethodExit(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, Map<String, TypeDefinition> uninitializedNamedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, AsmClassReader classReader, TypeDefinition enterType) { super(adviceMethod, postProcessor, CompoundList.of(Arrays.asList(new Advice.OffsetMapping.Factory[] { Advice.OffsetMapping.ForArgument.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForAllArguments.Factory.INSTANCE, Advice.OffsetMapping.ForThisReference.Factory.INSTANCE, Advice.OffsetMapping.ForField.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.ReaderFactory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.WriterFactory.INSTANCE, Advice.OffsetMapping.ForOrigin.Factory.INSTANCE, Advice.OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, Advice.OffsetMapping.ForHandle.Factory.INSTANCE, Advice.OffsetMapping.ForDynamicConstant.Factory.INSTANCE, Advice.OffsetMapping.ForUnusedValue.Factory.INSTANCE, Advice.OffsetMapping.ForStubValue.INSTANCE, Advice.OffsetMapping.ForEnterValue.Factory.of(enterType), Advice.OffsetMapping.ForExitValue.Factory.of((TypeDefinition)adviceMethod.getReturnType()), new Advice.OffsetMapping.ForLocalValue.Factory(namedTypes), Advice.OffsetMapping.ForReturnValue.Factory.INSTANCE, Advice.OffsetMapping.ForThrowable.Factory.of(adviceMethod) }, ), userFactories), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.SUPPRESS_EXIT).resolve(TypeDescription.class), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.REPEAT_ON).resolve(TypeDescription.class), ((Integer)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.REPEAT_ON_INDEX).resolve(Integer.class)).intValue(), classReader); this.uninitializedNamedTypes = uninitializedNamedTypes; this.backupArguments = ((Boolean)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.BACKUP_ARGUMENTS).resolve(Boolean.class)).booleanValue(); } @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected static Advice.Dispatcher.Resolved.ForMethodExit of(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, Map<String, TypeDefinition> uninitializedNamedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, AsmClassReader classReader, TypeDefinition enterType) { TypeDescription throwable = (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.ON_THROWABLE).resolve(TypeDescription.class); return throwable.represents(Advice.NoExceptionHandler.class) ? new WithoutExceptionHandler(adviceMethod, postProcessor, namedTypes, uninitializedNamedTypes, userFactories, classReader, enterType) : new WithExceptionHandler(adviceMethod, postProcessor, namedTypes, uninitializedNamedTypes, userFactories, classReader, enterType, throwable); } public Map<String, TypeDefinition> getNamedTypes() { return this.uninitializedNamedTypes; } protected Map<Integer, TypeDefinition> resolveInitializationTypes(Advice.ArgumentHandler argumentHandler) { SortedMap<Integer, TypeDefinition> resolved = new TreeMap<Integer, TypeDefinition>(); for (Map.Entry<String, TypeDefinition> entry : this.uninitializedNamedTypes.entrySet()) resolved.put(Integer.valueOf(argumentHandler.named(entry.getKey())), entry.getValue());  if (!this.adviceMethod.getReturnType().represents(void.class)) resolved.put(Integer.valueOf(argumentHandler.exit()), this.adviceMethod.getReturnType());  return resolved; } protected MethodVisitor apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { MethodDescription.TypeToken typeToken = this.adviceMethod.asTypeToken(); return doApply(methodVisitor, implementationContext, assigner, argumentHandler.bindExit(typeToken, getThrowable().represents(Advice.NoExceptionHandler.class)), methodSizeHandler.bindExit(typeToken), stackMapFrameHandler.bindExit(typeToken), instrumentedType, instrumentedMethod, suppressionHandler, relocationHandler, exceptionHandler); } private MethodVisitor doApply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { Map<Integer, Advice.OffsetMapping.Target> offsetMappings = new HashMap<Integer, Advice.OffsetMapping.Target>(); for (Map.Entry<Integer, Advice.OffsetMapping> entry : this.offsetMappings.entrySet()) offsetMappings.put(entry.getKey(), ((Advice.OffsetMapping)entry.getValue()).resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, Advice.OffsetMapping.Sort.EXIT));  return new Advice.Dispatcher.Inlining.CodeTranslationVisitor(methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, instrumentedType, instrumentedMethod, assigner, this.adviceMethod, offsetMappings, suppressionHandler, relocationHandler, exceptionHandler, this.postProcessor, true); } public Advice.ArgumentHandler.Factory getArgumentHandlerFactory() { return this.backupArguments ? Advice.ArgumentHandler.Factory.COPYING : Advice.ArgumentHandler.Factory.SIMPLE; } public TypeDefinition getAdviceType() { return (TypeDefinition)this.adviceMethod.getReturnType(); } public Advice.Dispatcher.Bound bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) { return new Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner(this, instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, this.suppressionHandler.bind(exceptionHandler), this.relocationHandler.bind(instrumentedMethod, relocation), exceptionHandler, this.classReader); } public boolean equals(@MaybeNull Object param3Object) { return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.backupArguments != ((ForMethodExit)param3Object).backupArguments) ? false : (!!this.uninitializedNamedTypes.equals(((ForMethodExit)param3Object).uninitializedNamedTypes)))))); } public int hashCode() { return (super.hashCode() * 31 + this.uninitializedNamedTypes.hashCode()) * 31 + this.backupArguments; } @Enhance protected static class WithExceptionHandler extends ForMethodExit { private final TypeDescription throwable; protected WithExceptionHandler(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, Map<String, TypeDefinition> uninitializedNamedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, AsmClassReader classReader, TypeDefinition enterType, TypeDescription throwable) { super(adviceMethod, postProcessor, namedTypes, uninitializedNamedTypes, userFactories, classReader, enterType); this.throwable = throwable; } public TypeDescription getThrowable() { return this.throwable; } public boolean equals(@MaybeNull Object param5Object) { return !super.equals(param5Object) ? false : ((this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.throwable.equals(((WithExceptionHandler)param5Object).throwable))))); } public int hashCode() { return super.hashCode() * 31 + this.throwable.hashCode(); } } protected static class WithoutExceptionHandler extends ForMethodExit { protected WithoutExceptionHandler(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, Map<String, TypeDefinition> uninitializedNamedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, AsmClassReader classReader, TypeDefinition enterType) { super(adviceMethod, postProcessor, namedTypes, uninitializedNamedTypes, userFactories, classReader, enterType); } public TypeDescription getThrowable() { return Advice.NoExceptionHandler.DESCRIPTION; }
/*       */            }
/*       */          }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static class CodeTranslationVisitor
/*       */         extends MethodVisitor
/*       */       {
/*       */         protected final MethodVisitor methodVisitor;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final Implementation.Context implementationContext;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final Advice.ArgumentHandler.ForAdvice argumentHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final Advice.MethodSizeHandler.ForAdvice methodSizeHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final TypeDescription instrumentedType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final MethodDescription instrumentedMethod;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final Assigner assigner;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final MethodDescription.InDefinedShape adviceMethod;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final Map<Integer, Advice.OffsetMapping.Target> offsetMappings;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final Advice.Dispatcher.RelocationHandler.Bound relocationHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final StackManipulation exceptionHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final Advice.PostProcessor postProcessor;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final boolean exit;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final Label endOfMethod;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected CodeTranslationVisitor(MethodVisitor methodVisitor, Implementation.Context implementationContext, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, MethodDescription.InDefinedShape adviceMethod, Map<Integer, Advice.OffsetMapping.Target> offsetMappings, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler, Advice.PostProcessor postProcessor, boolean exit) {
/* 10528 */           super(OpenedClassReader.ASM_API, StackAwareMethodVisitor.of(methodVisitor, instrumentedMethod));
/* 10529 */           this.methodVisitor = methodVisitor;
/* 10530 */           this.implementationContext = implementationContext;
/* 10531 */           this.argumentHandler = argumentHandler;
/* 10532 */           this.methodSizeHandler = methodSizeHandler;
/* 10533 */           this.stackMapFrameHandler = stackMapFrameHandler;
/* 10534 */           this.instrumentedType = instrumentedType;
/* 10535 */           this.instrumentedMethod = instrumentedMethod;
/* 10536 */           this.assigner = assigner;
/* 10537 */           this.adviceMethod = adviceMethod;
/* 10538 */           this.offsetMappings = offsetMappings;
/* 10539 */           this.suppressionHandler = suppressionHandler;
/* 10540 */           this.relocationHandler = relocationHandler;
/* 10541 */           this.exceptionHandler = exceptionHandler;
/* 10542 */           this.postProcessor = postProcessor;
/* 10543 */           this.exit = exit;
/* 10544 */           this.endOfMethod = new Label();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected void propagateHandler(Label label) {
/* 10554 */           ((StackAwareMethodVisitor)this.mv).register(label, Collections.singletonList(StackSize.SINGLE));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public void visitParameter(String name, int modifiers) {}
/*       */ 
/*       */ 
/*       */         
/*       */         public void visitAnnotableParameterCount(int count, boolean visible) {}
/*       */ 
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public AnnotationVisitor visitAnnotationDefault() {
/* 10570 */           return Advice.Dispatcher.IGNORE_ANNOTATION;
/*       */         }
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/* 10576 */           return Advice.Dispatcher.IGNORE_ANNOTATION;
/*       */         }
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public AnnotationVisitor visitTypeAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) {
/* 10582 */           return Advice.Dispatcher.IGNORE_ANNOTATION;
/*       */         }
/*       */ 
/*       */         
/*       */         @MaybeNull
/*       */         public AnnotationVisitor visitParameterAnnotation(int index, String descriptor, boolean visible) {
/* 10588 */           return Advice.Dispatcher.IGNORE_ANNOTATION;
/*       */         }
/*       */ 
/*       */ 
/*       */         
/*       */         public void visitAttribute(Attribute attribute) {}
/*       */ 
/*       */ 
/*       */         
/*       */         public void visitCode() {
/* 10598 */           this.suppressionHandler.onStart(this.methodVisitor);
/*       */         }
/*       */ 
/*       */         
/*       */         public void visitFrame(int type, int localVariableLength, @MaybeNull Object[] localVariable, int stackSize, @MaybeNull Object[] stack) {
/* 10603 */           this.stackMapFrameHandler.translateFrame(this.methodVisitor, type, localVariableLength, localVariable, stackSize, stack);
/*       */         }
/*       */ 
/*       */         
/*       */         public void visitVarInsn(int opcode, int offset) {
/* 10608 */           Advice.OffsetMapping.Target target = this.offsetMappings.get(Integer.valueOf(offset));
/* 10609 */           if (target != null) {
/*       */             StackManipulation stackManipulation;
/*       */             StackSize expectedGrowth;
/* 10612 */             switch (opcode) {
/*       */               case 21:
/*       */               case 23:
/*       */               case 25:
/* 10616 */                 stackManipulation = target.resolveRead();
/* 10617 */                 expectedGrowth = StackSize.SINGLE;
/*       */                 break;
/*       */               case 22:
/*       */               case 24:
/* 10621 */                 stackManipulation = target.resolveRead();
/* 10622 */                 expectedGrowth = StackSize.DOUBLE;
/*       */                 break;
/*       */               case 54:
/*       */               case 55:
/*       */               case 56:
/*       */               case 57:
/*       */               case 58:
/* 10629 */                 stackManipulation = target.resolveWrite();
/* 10630 */                 expectedGrowth = StackSize.ZERO;
/*       */                 break;
/*       */               default:
/* 10633 */                 throw new IllegalStateException("Unexpected opcode: " + opcode);
/*       */             } 
/* 10635 */             this.methodSizeHandler.requireStackSizePadding(stackManipulation.apply(this.mv, this.implementationContext).getMaximalSize() - expectedGrowth.getSize());
/*       */           } else {
/* 10637 */             this.mv.visitVarInsn(opcode, this.argumentHandler.mapped(offset));
/*       */           } 
/*       */         }
/*       */ 
/*       */         
/*       */         public void visitIincInsn(int offset, int value) {
/* 10643 */           Advice.OffsetMapping.Target target = this.offsetMappings.get(Integer.valueOf(offset));
/* 10644 */           if (target != null) {
/* 10645 */             this.methodSizeHandler.requireStackSizePadding(target.resolveIncrement(value).apply(this.mv, this.implementationContext).getMaximalSize());
/*       */           } else {
/* 10647 */             this.mv.visitIincInsn(this.argumentHandler.mapped(offset), value);
/*       */           } 
/*       */         }
/*       */ 
/*       */         
/*       */         public void visitInsn(int opcode) {
/* 10653 */           switch (opcode) {
/*       */             case 177:
/* 10655 */               ((StackAwareMethodVisitor)this.mv).drainStack();
/*       */               break;
/*       */             case 172:
/* 10658 */               this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(54, 21, StackSize.SINGLE));
/*       */               break;
/*       */             case 176:
/* 10661 */               this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(58, 25, StackSize.SINGLE));
/*       */               break;
/*       */             case 174:
/* 10664 */               this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(56, 23, StackSize.SINGLE));
/*       */               break;
/*       */             case 173:
/* 10667 */               this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(55, 22, StackSize.DOUBLE));
/*       */               break;
/*       */             case 175:
/* 10670 */               this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(57, 24, StackSize.DOUBLE));
/*       */               break;
/*       */             default:
/* 10673 */               this.mv.visitInsn(opcode);
/*       */               return;
/*       */           } 
/* 10676 */           this.mv.visitJumpInsn(167, this.endOfMethod);
/*       */         }
/*       */ 
/*       */         
/*       */         public void visitEnd() {
/* 10681 */           this.suppressionHandler.onEnd(this.methodVisitor, this.implementationContext, this.methodSizeHandler, this.stackMapFrameHandler, (TypeDefinition)this.adviceMethod.getReturnType());
/* 10682 */           this.methodVisitor.visitLabel(this.endOfMethod);
/* 10683 */           if (this.adviceMethod.getReturnType().represents(boolean.class) || this.adviceMethod
/* 10684 */             .getReturnType().represents(byte.class) || this.adviceMethod
/* 10685 */             .getReturnType().represents(short.class) || this.adviceMethod
/* 10686 */             .getReturnType().represents(char.class) || this.adviceMethod
/* 10687 */             .getReturnType().represents(int.class)) {
/* 10688 */             this.stackMapFrameHandler.injectReturnFrame(this.methodVisitor);
/* 10689 */             this.methodVisitor.visitVarInsn(54, this.exit ? this.argumentHandler.exit() : this.argumentHandler.enter());
/* 10690 */           } else if (this.adviceMethod.getReturnType().represents(long.class)) {
/* 10691 */             this.stackMapFrameHandler.injectReturnFrame(this.methodVisitor);
/* 10692 */             this.methodVisitor.visitVarInsn(55, this.exit ? this.argumentHandler.exit() : this.argumentHandler.enter());
/* 10693 */           } else if (this.adviceMethod.getReturnType().represents(float.class)) {
/* 10694 */             this.stackMapFrameHandler.injectReturnFrame(this.methodVisitor);
/* 10695 */             this.methodVisitor.visitVarInsn(56, this.exit ? this.argumentHandler.exit() : this.argumentHandler.enter());
/* 10696 */           } else if (this.adviceMethod.getReturnType().represents(double.class)) {
/* 10697 */             this.stackMapFrameHandler.injectReturnFrame(this.methodVisitor);
/* 10698 */             this.methodVisitor.visitVarInsn(57, this.exit ? this.argumentHandler.exit() : this.argumentHandler.enter());
/* 10699 */           } else if (!this.adviceMethod.getReturnType().represents(void.class)) {
/* 10700 */             this.stackMapFrameHandler.injectReturnFrame(this.methodVisitor);
/* 10701 */             this.methodVisitor.visitVarInsn(58, this.exit ? this.argumentHandler.exit() : this.argumentHandler.enter());
/*       */           } 
/* 10703 */           this.methodSizeHandler.requireStackSize(this.postProcessor
/* 10704 */               .resolve(this.instrumentedType, this.instrumentedMethod, this.assigner, this.argumentHandler, this.stackMapFrameHandler, this.exceptionHandler)
/* 10705 */               .apply(this.methodVisitor, this.implementationContext).getMaximalSize());
/* 10706 */           this.methodSizeHandler.requireStackSize(this.relocationHandler.apply(this.methodVisitor, this.implementationContext, this.exit ? this.argumentHandler
/*       */                 
/* 10708 */                 .exit() : this.argumentHandler.enter()));
/* 10709 */           this.stackMapFrameHandler.injectCompletionFrame(this.methodVisitor);
/*       */         }
/*       */ 
/*       */         
/*       */         public void visitMaxs(int stackSize, int localVariableLength) {
/* 10714 */           this.methodSizeHandler.recordMaxima(stackSize, localVariableLength);
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     public static class Delegating
/*       */       implements Unresolved
/*       */     {
/*       */       protected final MethodDescription.InDefinedShape adviceMethod;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected final Advice.Delegator.Factory delegatorFactory;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected Delegating(MethodDescription.InDefinedShape adviceMethod, Advice.Delegator.Factory delegatorFactory) {
/* 10742 */         this.adviceMethod = adviceMethod;
/* 10743 */         this.delegatorFactory = delegatorFactory;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isAlive() {
/* 10750 */         return true;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isBinary() {
/* 10757 */         return false;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public TypeDefinition getAdviceType() {
/* 10764 */         return (TypeDefinition)this.adviceMethod.getReturnType();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Map<String, TypeDefinition> getNamedTypes() {
/* 10771 */         return Collections.emptyMap();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.Dispatcher.Resolved.ForMethodEnter asMethodEnter(List<? extends Advice.OffsetMapping.Factory<?>> userFactories, @MaybeNull AsmClassReader classReader, Advice.Dispatcher.Unresolved methodExit, Advice.PostProcessor.Factory postProcessorFactory) {
/* 10781 */         Advice.Delegator delegator = this.delegatorFactory.make(this.adviceMethod, false);
/* 10782 */         return Resolved.ForMethodEnter.of(this.adviceMethod, postProcessorFactory
/* 10783 */             .make((List<? extends AnnotationDescription>)this.adviceMethod.getDeclaredAnnotations(), delegator.getTypeToken().getReturnType(), false), delegator, userFactories, methodExit
/*       */ 
/*       */             
/* 10786 */             .getAdviceType(), methodExit
/* 10787 */             .isAlive());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.Dispatcher.Resolved.ForMethodExit asMethodExit(List<? extends Advice.OffsetMapping.Factory<?>> userFactories, @MaybeNull AsmClassReader classReader, Advice.Dispatcher.Unresolved methodEnter, Advice.PostProcessor.Factory postProcessorFactory) {
/* 10797 */         Map<String, TypeDefinition> namedTypes = methodEnter.getNamedTypes();
/* 10798 */         for (ParameterDescription parameterDescription : this.adviceMethod.getParameters()) {
/* 10799 */           AnnotationDescription.Loadable<Advice.Local> annotationDescription = parameterDescription.getDeclaredAnnotations().ofType(Advice.Local.class);
/* 10800 */           if (annotationDescription != null) {
/* 10801 */             String name = (String)annotationDescription.getValue(Advice.OffsetMapping.ForLocalValue.Factory.LOCAL_VALUE).resolve(String.class);
/* 10802 */             TypeDefinition typeDefinition = namedTypes.get(name);
/* 10803 */             if (typeDefinition == null)
/* 10804 */               throw new IllegalStateException(this.adviceMethod + " attempts use of undeclared local variable " + name); 
/* 10805 */             if (!typeDefinition.equals(parameterDescription.getType())) {
/* 10806 */               throw new IllegalStateException(this.adviceMethod + " does not read variable " + name + " as " + typeDefinition);
/*       */             }
/*       */           } 
/*       */         } 
/* 10810 */         Advice.Delegator delegator = this.delegatorFactory.make(this.adviceMethod, true);
/* 10811 */         return Resolved.ForMethodExit.of(this.adviceMethod, postProcessorFactory
/* 10812 */             .make((List<? extends AnnotationDescription>)this.adviceMethod.getDeclaredAnnotations(), delegator.getTypeToken().getReturnType(), true), delegator, namedTypes, userFactories, methodEnter
/*       */ 
/*       */ 
/*       */             
/* 10816 */             .getAdviceType());
/*       */       }
/*       */ 
/*       */       
/*       */       public String toString() {
/* 10821 */         return "Delegate to " + this.adviceMethod;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.adviceMethod.equals(((Delegating)param2Object).adviceMethod) ? false : (!!this.delegatorFactory.equals(((Delegating)param2Object).delegatorFactory)))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return (getClass().hashCode() * 31 + this.adviceMethod.hashCode()) * 31 + this.delegatorFactory.hashCode();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static abstract class Resolved
/*       */         extends Advice.Dispatcher.Resolved.AbstractBase
/*       */       {
/*       */         protected final Advice.Delegator delegator;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Resolved(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> factories, TypeDescription throwableType, TypeDescription relocatableType, int relocatableIndex, Advice.Delegator delegator) {
/* 10852 */           super(adviceMethod, postProcessor, factories, throwableType, relocatableType, relocatableIndex, Advice.OffsetMapping.Factory.AdviceType.DELEGATION);
/* 10853 */           this.delegator = delegator;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Map<String, TypeDefinition> getNamedTypes() {
/* 10860 */           return Collections.emptyMap();
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public Advice.Dispatcher.Bound bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) {
/* 10876 */           this.delegator.assertVisibility(instrumentedType);
/* 10877 */           return resolve(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, exceptionHandler, relocation);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected abstract Advice.Dispatcher.Bound resolve(TypeDescription param3TypeDescription, MethodDescription param3MethodDescription, MethodVisitor param3MethodVisitor, Implementation.Context param3Context, Assigner param3Assigner, Advice.ArgumentHandler.ForInstrumentedMethod param3ForInstrumentedMethod, Advice.MethodSizeHandler.ForInstrumentedMethod param3ForInstrumentedMethod1, Advice.StackMapFrameHandler.ForInstrumentedMethod param3ForInstrumentedMethod2, StackManipulation param3StackManipulation, Advice.Dispatcher.RelocationHandler.Relocation param3Relocation);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected static abstract class AdviceMethodWriter
/*       */           implements Advice.Dispatcher.Bound
/*       */         {
/*       */           protected final MethodDescription.TypeToken typeToken;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final TypeDescription instrumentedType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final MethodDescription instrumentedMethod;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final Assigner assigner;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final List<Advice.OffsetMapping.Target> offsetMappings;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final MethodVisitor methodVisitor;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final Implementation.Context implementationContext;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final Advice.ArgumentHandler.ForAdvice argumentHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final Advice.MethodSizeHandler.ForAdvice methodSizeHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected final Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final Advice.Dispatcher.RelocationHandler.Bound relocationHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final StackManipulation exceptionHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final Advice.PostProcessor postProcessor;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final Advice.Delegator delegator;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected AdviceMethodWriter(MethodDescription.TypeToken typeToken, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.PostProcessor postProcessor, List<Advice.OffsetMapping.Target> offsetMappings, MethodVisitor methodVisitor, Implementation.Context implementationContext, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler, Advice.Delegator delegator) {
/* 11030 */             this.typeToken = typeToken;
/* 11031 */             this.instrumentedType = instrumentedType;
/* 11032 */             this.instrumentedMethod = instrumentedMethod;
/* 11033 */             this.assigner = assigner;
/* 11034 */             this.postProcessor = postProcessor;
/* 11035 */             this.offsetMappings = offsetMappings;
/* 11036 */             this.methodVisitor = methodVisitor;
/* 11037 */             this.implementationContext = implementationContext;
/* 11038 */             this.argumentHandler = argumentHandler;
/* 11039 */             this.methodSizeHandler = methodSizeHandler;
/* 11040 */             this.stackMapFrameHandler = stackMapFrameHandler;
/* 11041 */             this.suppressionHandler = suppressionHandler;
/* 11042 */             this.relocationHandler = relocationHandler;
/* 11043 */             this.exceptionHandler = exceptionHandler;
/* 11044 */             this.delegator = delegator;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void prepare() {
/* 11051 */             this.suppressionHandler.onPrepare(this.methodVisitor);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public void apply() {
/* 11058 */             this.suppressionHandler.onStart(this.methodVisitor);
/* 11059 */             int index = 0, currentStackSize = 0, maximumStackSize = 0;
/* 11060 */             for (Advice.OffsetMapping.Target offsetMapping : this.offsetMappings) {
/* 11061 */               currentStackSize += ((TypeDescription)this.typeToken.getParameterTypes().get(index++)).getStackSize().getSize();
/* 11062 */               maximumStackSize = Math.max(maximumStackSize, currentStackSize + offsetMapping.resolveRead()
/* 11063 */                   .apply(this.methodVisitor, this.implementationContext)
/* 11064 */                   .getMaximalSize());
/*       */             } 
/* 11066 */             maximumStackSize = Math.max(maximumStackSize, this.delegator.apply(this.instrumentedType, this.instrumentedMethod)
/* 11067 */                 .apply(this.methodVisitor, this.implementationContext)
/* 11068 */                 .getMaximalSize());
/* 11069 */             this.suppressionHandler.onEndWithSkip(this.methodVisitor, this.implementationContext, this.methodSizeHandler, this.stackMapFrameHandler, (TypeDefinition)this.typeToken
/*       */ 
/*       */ 
/*       */                 
/* 11073 */                 .getReturnType());
/* 11074 */             if (this.typeToken.getReturnType().represents(boolean.class) || this.typeToken
/* 11075 */               .getReturnType().represents(byte.class) || this.typeToken
/* 11076 */               .getReturnType().represents(short.class) || this.typeToken
/* 11077 */               .getReturnType().represents(char.class) || this.typeToken
/* 11078 */               .getReturnType().represents(int.class)) {
/* 11079 */               this.methodVisitor.visitVarInsn(54, isExitAdvice() ? this.argumentHandler.exit() : this.argumentHandler.enter());
/* 11080 */             } else if (this.typeToken.getReturnType().represents(long.class)) {
/* 11081 */               this.methodVisitor.visitVarInsn(55, isExitAdvice() ? this.argumentHandler.exit() : this.argumentHandler.enter());
/* 11082 */             } else if (this.typeToken.getReturnType().represents(float.class)) {
/* 11083 */               this.methodVisitor.visitVarInsn(56, isExitAdvice() ? this.argumentHandler.exit() : this.argumentHandler.enter());
/* 11084 */             } else if (this.typeToken.getReturnType().represents(double.class)) {
/* 11085 */               this.methodVisitor.visitVarInsn(57, isExitAdvice() ? this.argumentHandler.exit() : this.argumentHandler.enter());
/* 11086 */             } else if (this.typeToken.getReturnType().represents(void.class)) {
/* 11087 */               this.methodVisitor.visitInsn(0);
/*       */             } else {
/* 11089 */               this.methodVisitor.visitVarInsn(58, isExitAdvice() ? this.argumentHandler.exit() : this.argumentHandler.enter());
/*       */             } 
/* 11091 */             this.methodSizeHandler.requireStackSize(this.postProcessor
/* 11092 */                 .resolve(this.instrumentedType, this.instrumentedMethod, this.assigner, this.argumentHandler, this.stackMapFrameHandler, this.exceptionHandler)
/* 11093 */                 .apply(this.methodVisitor, this.implementationContext).getMaximalSize());
/* 11094 */             this.methodSizeHandler.requireStackSize(this.relocationHandler.apply(this.methodVisitor, this.implementationContext, 
/*       */                   
/* 11096 */                   isExitAdvice() ? this.argumentHandler.exit() : this.argumentHandler.enter()));
/* 11097 */             this.stackMapFrameHandler.injectCompletionFrame(this.methodVisitor);
/* 11098 */             this.methodSizeHandler.requireStackSize(Math.max(maximumStackSize, this.typeToken.getReturnType().getStackSize().getSize()));
/* 11099 */             this.methodSizeHandler.requireLocalVariableLength(this.instrumentedMethod.getStackSize() + this.typeToken.getReturnType().getStackSize().getSize());
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected abstract boolean isExitAdvice();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected static class ForMethodEnter
/*       */             extends AdviceMethodWriter
/*       */           {
/*       */             protected ForMethodEnter(MethodDescription.TypeToken typeToken, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.PostProcessor postProcessor, List<Advice.OffsetMapping.Target> offsetMappings, MethodVisitor methodVisitor, Implementation.Context implementationContext, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler, Advice.Delegator delegator) {
/* 11148 */               super(typeToken, instrumentedType, instrumentedMethod, assigner, postProcessor, offsetMappings, methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, suppressionHandler, relocationHandler, exceptionHandler, delegator);
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public void initialize() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             protected boolean isExitAdvice() {
/* 11174 */               return false;
/*       */             }
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected static class ForMethodExit
/*       */             extends AdviceMethodWriter
/*       */           {
/*       */             protected ForMethodExit(MethodDescription.TypeToken typeToken, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.PostProcessor postProcessor, List<Advice.OffsetMapping.Target> offsetMappings, MethodVisitor methodVisitor, Implementation.Context implementationContext, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler, Advice.Delegator delegator) {
/* 11217 */               super(typeToken, instrumentedType, instrumentedMethod, assigner, postProcessor, offsetMappings, methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, suppressionHandler, relocationHandler, exceptionHandler, delegator);
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public void initialize() {
/* 11238 */               if (this.typeToken.getReturnType().represents(boolean.class) || this.typeToken
/* 11239 */                 .getReturnType().represents(byte.class) || this.typeToken
/* 11240 */                 .getReturnType().represents(short.class) || this.typeToken
/* 11241 */                 .getReturnType().represents(char.class) || this.typeToken
/* 11242 */                 .getReturnType().represents(int.class)) {
/* 11243 */                 this.methodVisitor.visitInsn(3);
/* 11244 */                 this.methodVisitor.visitVarInsn(54, this.argumentHandler.exit());
/* 11245 */               } else if (this.typeToken.getReturnType().represents(long.class)) {
/* 11246 */                 this.methodVisitor.visitInsn(9);
/* 11247 */                 this.methodVisitor.visitVarInsn(55, this.argumentHandler.exit());
/* 11248 */               } else if (this.typeToken.getReturnType().represents(float.class)) {
/* 11249 */                 this.methodVisitor.visitInsn(11);
/* 11250 */                 this.methodVisitor.visitVarInsn(56, this.argumentHandler.exit());
/* 11251 */               } else if (this.typeToken.getReturnType().represents(double.class)) {
/* 11252 */                 this.methodVisitor.visitInsn(14);
/* 11253 */                 this.methodVisitor.visitVarInsn(57, this.argumentHandler.exit());
/* 11254 */               } else if (!this.typeToken.getReturnType().represents(void.class)) {
/* 11255 */                 this.methodVisitor.visitInsn(1);
/* 11256 */                 this.methodVisitor.visitVarInsn(58, this.argumentHandler.exit());
/*       */               } 
/* 11258 */               this.methodSizeHandler.requireStackSize(this.typeToken.getReturnType().getStackSize().getSize());
/*       */             }
/*       */ 
/*       */             
/*       */             protected boolean isExitAdvice() {
/* 11263 */               return true;
/*       */             }
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         protected static abstract class ForMethodEnter
/*       */           extends Resolved
/*       */           implements Advice.Dispatcher.Resolved.ForMethodEnter
/*       */         {
/*       */           private final boolean prependLineNumber;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.")
/*       */           protected ForMethodEnter(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, Advice.Delegator delegator) {
/* 11295 */             super(adviceMethod, postProcessor, 
/*       */                 
/* 11297 */                 CompoundList.of(Arrays.asList(new Advice.OffsetMapping.Factory[] {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */                       
/*       */                       Advice.OffsetMapping.ForArgument.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForAllArguments.Factory.INSTANCE, Advice.OffsetMapping.ForThisReference.Factory.INSTANCE, Advice.OffsetMapping.ForField.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.ReaderFactory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.WriterFactory.INSTANCE, Advice.OffsetMapping.ForOrigin.Factory.INSTANCE, Advice.OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, Advice.OffsetMapping.ForHandle.Factory.INSTANCE, Advice.OffsetMapping.ForDynamicConstant.Factory.INSTANCE,
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */                       
/* 11309 */                       Advice.OffsetMapping.ForUnusedValue.Factory.INSTANCE, Advice.OffsetMapping.ForStubValue.INSTANCE, Advice.OffsetMapping.ForExitValue.Factory.of(exitType), new Advice.OffsetMapping.Factory.Illegal<Advice.Thrown>(Advice.Thrown.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Enter>(Advice.Enter.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Local>(Advice.Local.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Return>(Advice.Return.class)
/*       */                     },
/*       */ 
/*       */ 
/*       */                   
/* 11314 */                   ), userFactories), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SUPPRESS_ENTER).resolve(TypeDescription.class), (TypeDescription)adviceMethod
/* 11315 */                 .getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SKIP_ON).resolve(TypeDescription.class), ((Integer)adviceMethod
/* 11316 */                 .getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SKIP_ON_INDEX).resolve(Integer.class)).intValue(), delegator);
/*       */             
/* 11318 */             this.prependLineNumber = ((Boolean)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.PREPEND_LINE_NUMBER).resolve(Boolean.class)).booleanValue();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected static Advice.Dispatcher.Resolved.ForMethodEnter of(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Advice.Delegator delegator, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, boolean methodExit) {
/* 11338 */             return methodExit ? new WithRetainedEnterType(adviceMethod, postProcessor, userFactories, exitType, delegator) : new WithDiscardedEnterType(adviceMethod, postProcessor, userFactories, exitType, delegator);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean isPrependLineNumber() {
/* 11347 */             return this.prependLineNumber;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeDefinition getActualAdviceType() {
/* 11354 */             return (TypeDefinition)this.delegator.getTypeToken().getReturnType();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected Advice.Dispatcher.Bound resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) {
/* 11368 */             return doResolve(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler
/*       */ 
/*       */ 
/*       */ 
/*       */                 
/* 11373 */                 .bindEnter(this.delegator.getTypeToken()), methodSizeHandler
/* 11374 */                 .bindEnter(this.delegator.getTypeToken()), stackMapFrameHandler
/* 11375 */                 .bindEnter(this.delegator.getTypeToken()), this.suppressionHandler
/* 11376 */                 .bind(exceptionHandler), this.relocationHandler
/* 11377 */                 .bind(instrumentedMethod, relocation), exceptionHandler);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected Advice.Dispatcher.Bound doResolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) {
/* 11408 */             List<Advice.OffsetMapping.Target> offsetMappings = new ArrayList<Advice.OffsetMapping.Target>(this.offsetMappings.size());
/* 11409 */             for (Advice.OffsetMapping offsetMapping : this.offsetMappings.values()) {
/* 11410 */               offsetMappings.add(offsetMapping.resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, Advice.OffsetMapping.Sort.ENTER));
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/* 11416 */             return new Advice.Dispatcher.Delegating.Resolved.AdviceMethodWriter.ForMethodEnter(this.delegator.getTypeToken(), instrumentedType, instrumentedMethod, assigner, this.postProcessor, offsetMappings, methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, suppressionHandler, relocationHandler, exceptionHandler, this.delegator);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!(this.prependLineNumber != ((ForMethodEnter)param4Object).prependLineNumber)))));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return super.hashCode() * 31 + this.prependLineNumber;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected static class WithRetainedEnterType
/*       */             extends ForMethodEnter
/*       */           {
/*       */             protected WithRetainedEnterType(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, Advice.Delegator delegator) {
/* 11452 */               super(adviceMethod, postProcessor, userFactories, exitType, delegator);
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeDefinition getAdviceType() {
/* 11459 */               return (TypeDefinition)this.delegator.getTypeToken().getReturnType();
/*       */             }
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected static class WithDiscardedEnterType
/*       */             extends ForMethodEnter
/*       */           {
/*       */             protected WithDiscardedEnterType(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, Advice.Delegator delegator) {
/* 11482 */               super(adviceMethod, postProcessor, userFactories, exitType, delegator);
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeDefinition getAdviceType() {
/* 11489 */               return (TypeDefinition)TypeDescription.ForLoadedType.of(void.class);
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             protected Advice.Dispatcher.Bound doResolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) {
/* 11506 */               methodSizeHandler.requireLocalVariableLengthPadding(this.delegator.getTypeToken().getReturnType().getStackSize().getSize());
/* 11507 */               return super.doResolve(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, suppressionHandler, relocationHandler, exceptionHandler);
/*       */             }
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         protected static abstract class ForMethodExit
/*       */           extends Resolved
/*       */           implements Advice.Dispatcher.Resolved.ForMethodExit
/*       */         {
/*       */           private final boolean backupArguments;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.")
/*       */           protected ForMethodExit(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition enterType, Advice.Delegator delegator) {
/* 11551 */             super(adviceMethod, postProcessor, 
/*       */                 
/* 11553 */                 CompoundList.of(Arrays.asList(new Advice.OffsetMapping.Factory[] {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */                       
/*       */                       Advice.OffsetMapping.ForArgument.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForAllArguments.Factory.INSTANCE, Advice.OffsetMapping.ForThisReference.Factory.INSTANCE, Advice.OffsetMapping.ForField.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.ReaderFactory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.WriterFactory.INSTANCE, Advice.OffsetMapping.ForOrigin.Factory.INSTANCE, Advice.OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, Advice.OffsetMapping.ForHandle.Factory.INSTANCE, Advice.OffsetMapping.ForDynamicConstant.Factory.INSTANCE,
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */                       
/* 11565 */                       Advice.OffsetMapping.ForUnusedValue.Factory.INSTANCE, Advice.OffsetMapping.ForStubValue.INSTANCE, Advice.OffsetMapping.ForEnterValue.Factory.of(enterType), 
/* 11566 */                       Advice.OffsetMapping.ForExitValue.Factory.of((TypeDefinition)adviceMethod.getReturnType()), new Advice.OffsetMapping.ForLocalValue.Factory(namedTypes), Advice.OffsetMapping.ForReturnValue.Factory.INSTANCE, 
/*       */ 
/*       */                       
/* 11569 */                       Advice.OffsetMapping.ForThrowable.Factory.of(adviceMethod)
/*       */                     },
/* 11571 */                   ), userFactories), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.SUPPRESS_EXIT).resolve(TypeDescription.class), (TypeDescription)adviceMethod
/* 11572 */                 .getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.REPEAT_ON).resolve(TypeDescription.class), ((Integer)adviceMethod
/* 11573 */                 .getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.REPEAT_ON_INDEX).resolve(Integer.class)).intValue(), delegator);
/*       */             
/* 11575 */             this.backupArguments = ((Boolean)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.BACKUP_ARGUMENTS).resolve(Boolean.class)).booleanValue();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.")
/*       */           protected static Advice.Dispatcher.Resolved.ForMethodExit of(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Advice.Delegator delegator, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition enterType) {
/* 11599 */             TypeDescription throwable = (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.ON_THROWABLE).resolve(TypeDescription.class);
/* 11600 */             return throwable.represents(Advice.NoExceptionHandler.class) ? new WithoutExceptionHandler(adviceMethod, postProcessor, namedTypes, userFactories, enterType, delegator) : new WithExceptionHandler(adviceMethod, postProcessor, namedTypes, userFactories, enterType, throwable, delegator);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected Advice.Dispatcher.Bound resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) {
/* 11616 */             return doResolve(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler
/*       */ 
/*       */ 
/*       */ 
/*       */                 
/* 11621 */                 .bindExit(this.delegator.getTypeToken(), getThrowable().represents(Advice.NoExceptionHandler.class)), methodSizeHandler
/* 11622 */                 .bindExit(this.delegator.getTypeToken()), stackMapFrameHandler
/* 11623 */                 .bindExit(this.delegator.getTypeToken()), this.suppressionHandler
/* 11624 */                 .bind(exceptionHandler), this.relocationHandler
/* 11625 */                 .bind(instrumentedMethod, relocation), exceptionHandler);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private Advice.Dispatcher.Bound doResolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) {
/* 11656 */             List<Advice.OffsetMapping.Target> offsetMappings = new ArrayList<Advice.OffsetMapping.Target>(this.offsetMappings.size());
/* 11657 */             for (Advice.OffsetMapping offsetMapping : this.offsetMappings.values()) {
/* 11658 */               offsetMappings.add(offsetMapping.resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, Advice.OffsetMapping.Sort.EXIT));
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/* 11664 */             return new Advice.Dispatcher.Delegating.Resolved.AdviceMethodWriter.ForMethodExit(this.delegator.getTypeToken(), instrumentedType, instrumentedMethod, assigner, this.postProcessor, offsetMappings, methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, suppressionHandler, relocationHandler, exceptionHandler, this.delegator);
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Advice.ArgumentHandler.Factory getArgumentHandlerFactory() {
/* 11685 */             return this.backupArguments ? Advice.ArgumentHandler.Factory.COPYING : Advice.ArgumentHandler.Factory.SIMPLE;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public TypeDefinition getAdviceType() {
/* 11694 */             return (TypeDefinition)this.delegator.getTypeToken().getReturnType();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!(this.backupArguments != ((ForMethodExit)param4Object).backupArguments)))));
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public int hashCode() {
/*       */             return super.hashCode() * 31 + this.backupArguments;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @Enhance
/*       */           protected static class WithExceptionHandler
/*       */             extends ForMethodExit
/*       */           {
/*       */             private final TypeDescription throwable;
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             protected WithExceptionHandler(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition enterType, TypeDescription throwable, Advice.Delegator delegator) {
/* 11727 */               super(adviceMethod, postProcessor, namedTypes, userFactories, enterType, delegator);
/* 11728 */               this.throwable = throwable;
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeDescription getThrowable() {
/* 11735 */               return this.throwable;
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public boolean equals(@MaybeNull Object param5Object) {
/*       */               return !super.equals(param5Object) ? false : ((this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.throwable.equals(((WithExceptionHandler)param5Object).throwable)))));
/*       */             }
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             public int hashCode() {
/*       */               return super.hashCode() * 31 + this.throwable.hashCode();
/*       */             }
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected static class WithoutExceptionHandler
/*       */             extends ForMethodExit
/*       */           {
/*       */             protected WithoutExceptionHandler(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition enterType, Advice.Delegator delegator) {
/* 11761 */               super(adviceMethod, postProcessor, namedTypes, userFactories, enterType, delegator);
/*       */             }
/*       */ 
/*       */ 
/*       */             
/*       */             public TypeDescription getThrowable()
/*       */             {
/* 11768 */               return Advice.NoExceptionHandler.DESCRIPTION; } } } } @Enhance protected static abstract class ForMethodEnter extends Resolved implements Advice.Dispatcher.Resolved.ForMethodEnter { private final boolean prependLineNumber; @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected ForMethodEnter(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, Advice.Delegator delegator) { super(adviceMethod, postProcessor, CompoundList.of(Arrays.asList(new Advice.OffsetMapping.Factory[] { Advice.OffsetMapping.ForArgument.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForAllArguments.Factory.INSTANCE, Advice.OffsetMapping.ForThisReference.Factory.INSTANCE, Advice.OffsetMapping.ForField.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.ReaderFactory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.WriterFactory.INSTANCE, Advice.OffsetMapping.ForOrigin.Factory.INSTANCE, Advice.OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, Advice.OffsetMapping.ForHandle.Factory.INSTANCE, Advice.OffsetMapping.ForDynamicConstant.Factory.INSTANCE, Advice.OffsetMapping.ForUnusedValue.Factory.INSTANCE, Advice.OffsetMapping.ForStubValue.INSTANCE, Advice.OffsetMapping.ForExitValue.Factory.of(exitType), new Advice.OffsetMapping.Factory.Illegal<Advice.Thrown>(Advice.Thrown.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Enter>(Advice.Enter.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Local>(Advice.Local.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Return>(Advice.Return.class) }, ), userFactories), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SUPPRESS_ENTER).resolve(TypeDescription.class), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SKIP_ON).resolve(TypeDescription.class), ((Integer)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SKIP_ON_INDEX).resolve(Integer.class)).intValue(), delegator); this.prependLineNumber = ((Boolean)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.PREPEND_LINE_NUMBER).resolve(Boolean.class)).booleanValue(); } protected static Advice.Dispatcher.Resolved.ForMethodEnter of(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Advice.Delegator delegator, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, boolean methodExit) { return methodExit ? new WithRetainedEnterType(adviceMethod, postProcessor, userFactories, exitType, delegator) : new WithDiscardedEnterType(adviceMethod, postProcessor, userFactories, exitType, delegator); } public boolean isPrependLineNumber() { return this.prependLineNumber; } public TypeDefinition getActualAdviceType() { return (TypeDefinition)this.delegator.getTypeToken().getReturnType(); } protected Advice.Dispatcher.Bound resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) { return doResolve(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler.bindEnter(this.delegator.getTypeToken()), methodSizeHandler.bindEnter(this.delegator.getTypeToken()), stackMapFrameHandler.bindEnter(this.delegator.getTypeToken()), this.suppressionHandler.bind(exceptionHandler), this.relocationHandler.bind(instrumentedMethod, relocation), exceptionHandler); } protected Advice.Dispatcher.Bound doResolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { List<Advice.OffsetMapping.Target> offsetMappings = new ArrayList<Advice.OffsetMapping.Target>(this.offsetMappings.size()); for (Advice.OffsetMapping offsetMapping : this.offsetMappings.values()) offsetMappings.add(offsetMapping.resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, Advice.OffsetMapping.Sort.ENTER));  return new Advice.Dispatcher.Delegating.Resolved.AdviceMethodWriter.ForMethodEnter(this.delegator.getTypeToken(), instrumentedType, instrumentedMethod, assigner, this.postProcessor, offsetMappings, methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, suppressionHandler, relocationHandler, exceptionHandler, this.delegator); } public boolean equals(@MaybeNull Object param3Object) { return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!(this.prependLineNumber != ((ForMethodEnter)param3Object).prependLineNumber))))); } public int hashCode() { return super.hashCode() * 31 + this.prependLineNumber; } protected static class WithRetainedEnterType extends ForMethodEnter { protected WithRetainedEnterType(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, Advice.Delegator delegator) { super(adviceMethod, postProcessor, userFactories, exitType, delegator); } public TypeDefinition getAdviceType() { return (TypeDefinition)this.delegator.getTypeToken().getReturnType(); } } protected static class WithDiscardedEnterType extends ForMethodEnter { protected WithDiscardedEnterType(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, Advice.Delegator delegator) { super(adviceMethod, postProcessor, userFactories, exitType, delegator); } public TypeDefinition getAdviceType() { return (TypeDefinition)TypeDescription.ForLoadedType.of(void.class); } protected Advice.Dispatcher.Bound doResolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { methodSizeHandler.requireLocalVariableLengthPadding(this.delegator.getTypeToken().getReturnType().getStackSize().getSize()); return super.doResolve(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, suppressionHandler, relocationHandler, exceptionHandler); } } } @Enhance protected static abstract class ForMethodExit extends Resolved implements Advice.Dispatcher.Resolved.ForMethodExit { private final boolean backupArguments; @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected ForMethodExit(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition enterType, Advice.Delegator delegator) { super(adviceMethod, postProcessor, CompoundList.of(Arrays.asList(new Advice.OffsetMapping.Factory[] { Advice.OffsetMapping.ForArgument.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForAllArguments.Factory.INSTANCE, Advice.OffsetMapping.ForThisReference.Factory.INSTANCE, Advice.OffsetMapping.ForField.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.ReaderFactory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.WriterFactory.INSTANCE, Advice.OffsetMapping.ForOrigin.Factory.INSTANCE, Advice.OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, Advice.OffsetMapping.ForHandle.Factory.INSTANCE, Advice.OffsetMapping.ForDynamicConstant.Factory.INSTANCE, Advice.OffsetMapping.ForUnusedValue.Factory.INSTANCE, Advice.OffsetMapping.ForStubValue.INSTANCE, Advice.OffsetMapping.ForEnterValue.Factory.of(enterType), Advice.OffsetMapping.ForExitValue.Factory.of((TypeDefinition)adviceMethod.getReturnType()), new Advice.OffsetMapping.ForLocalValue.Factory(namedTypes), Advice.OffsetMapping.ForReturnValue.Factory.INSTANCE, Advice.OffsetMapping.ForThrowable.Factory.of(adviceMethod) }, ), userFactories), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.SUPPRESS_EXIT).resolve(TypeDescription.class), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.REPEAT_ON).resolve(TypeDescription.class), ((Integer)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.REPEAT_ON_INDEX).resolve(Integer.class)).intValue(), delegator); this.backupArguments = ((Boolean)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.BACKUP_ARGUMENTS).resolve(Boolean.class)).booleanValue(); } @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected static Advice.Dispatcher.Resolved.ForMethodExit of(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Advice.Delegator delegator, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition enterType) { TypeDescription throwable = (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.ON_THROWABLE).resolve(TypeDescription.class); return throwable.represents(Advice.NoExceptionHandler.class) ? new WithoutExceptionHandler(adviceMethod, postProcessor, namedTypes, userFactories, enterType, delegator) : new WithExceptionHandler(adviceMethod, postProcessor, namedTypes, userFactories, enterType, throwable, delegator); } protected Advice.Dispatcher.Bound resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) { return doResolve(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler.bindExit(this.delegator.getTypeToken(), getThrowable().represents(Advice.NoExceptionHandler.class)), methodSizeHandler.bindExit(this.delegator.getTypeToken()), stackMapFrameHandler.bindExit(this.delegator.getTypeToken()), this.suppressionHandler.bind(exceptionHandler), this.relocationHandler.bind(instrumentedMethod, relocation), exceptionHandler); } private Advice.Dispatcher.Bound doResolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { List<Advice.OffsetMapping.Target> offsetMappings = new ArrayList<Advice.OffsetMapping.Target>(this.offsetMappings.size()); for (Advice.OffsetMapping offsetMapping : this.offsetMappings.values()) offsetMappings.add(offsetMapping.resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, Advice.OffsetMapping.Sort.EXIT));  return new Advice.Dispatcher.Delegating.Resolved.AdviceMethodWriter.ForMethodExit(this.delegator.getTypeToken(), instrumentedType, instrumentedMethod, assigner, this.postProcessor, offsetMappings, methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, suppressionHandler, relocationHandler, exceptionHandler, this.delegator); } public Advice.ArgumentHandler.Factory getArgumentHandlerFactory() { return this.backupArguments ? Advice.ArgumentHandler.Factory.COPYING : Advice.ArgumentHandler.Factory.SIMPLE; } public TypeDefinition getAdviceType() { return (TypeDefinition)this.delegator.getTypeToken().getReturnType(); } public boolean equals(@MaybeNull Object param3Object) { return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!(this.backupArguments != ((ForMethodExit)param3Object).backupArguments))))); } public int hashCode() { return super.hashCode() * 31 + this.backupArguments; } @Enhance protected static class WithExceptionHandler extends ForMethodExit { private final TypeDescription throwable; protected WithExceptionHandler(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition enterType, TypeDescription throwable, Advice.Delegator delegator) { super(adviceMethod, postProcessor, namedTypes, userFactories, enterType, delegator); this.throwable = throwable; } public TypeDescription getThrowable() { return this.throwable; } public boolean equals(@MaybeNull Object param5Object) { return !super.equals(param5Object) ? false : ((this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.throwable.equals(((WithExceptionHandler)param5Object).throwable))))); } public int hashCode() { return super.hashCode() * 31 + this.throwable.hashCode(); } } protected static class WithoutExceptionHandler extends ForMethodExit { protected WithoutExceptionHandler(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition enterType, Advice.Delegator delegator) { super(adviceMethod, postProcessor, namedTypes, userFactories, enterType, delegator); } public TypeDescription getThrowable() { return Advice.NoExceptionHandler.DESCRIPTION; } } } } } public static interface Resolved extends Dispatcher { Map<String, TypeDefinition> getNamedTypes(); Advice.Dispatcher.Bound bind(TypeDescription param1TypeDescription, MethodDescription param1MethodDescription, MethodVisitor param1MethodVisitor, Implementation.Context param1Context, Assigner param1Assigner, Advice.ArgumentHandler.ForInstrumentedMethod param1ForInstrumentedMethod, Advice.MethodSizeHandler.ForInstrumentedMethod param1ForInstrumentedMethod1, Advice.StackMapFrameHandler.ForInstrumentedMethod param1ForInstrumentedMethod2, StackManipulation param1StackManipulation, Advice.Dispatcher.RelocationHandler.Relocation param1Relocation); @Enhance public static abstract class AbstractBase implements Resolved { protected final Advice.PostProcessor postProcessor; protected final Map<Integer, Advice.OffsetMapping> offsetMappings; protected final Advice.Dispatcher.SuppressionHandler suppressionHandler; protected final Advice.Dispatcher.RelocationHandler relocationHandler; protected AbstractBase(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> factories, TypeDescription throwableType, TypeDescription relocatableType, int relocatableIndex, Advice.OffsetMapping.Factory.AdviceType adviceType) { this.postProcessor = postProcessor; Map<TypeDescription, Advice.OffsetMapping.Factory<?>> offsetMappings = new HashMap<TypeDescription, Advice.OffsetMapping.Factory<?>>(); for (Advice.OffsetMapping.Factory<?> factory : factories) offsetMappings.put(TypeDescription.ForLoadedType.of(factory.getAnnotationType()), factory);  this.offsetMappings = new LinkedHashMap<Integer, Advice.OffsetMapping>(); for (ParameterDescription.InDefinedShape parameterDescription : adviceMethod.getParameters()) { Advice.OffsetMapping offsetMapping = null; for (AnnotationDescription annotationDescription : parameterDescription.getDeclaredAnnotations()) { Advice.OffsetMapping.Factory<?> factory = offsetMappings.get(annotationDescription.getAnnotationType()); if (factory != null) { Advice.OffsetMapping current = factory.make(parameterDescription, annotationDescription.prepare(factory.getAnnotationType()), adviceType); if (offsetMapping == null) { offsetMapping = current; continue; }  throw new IllegalStateException(parameterDescription + " is bound to both " + current + " and " + offsetMapping); }  }  this.offsetMappings.put(Integer.valueOf(parameterDescription.getOffset()), (offsetMapping == null) ? new Advice.OffsetMapping.ForArgument.Unresolved((ParameterDescription)parameterDescription) : offsetMapping); }  this.suppressionHandler = Advice.Dispatcher.SuppressionHandler.Suppressing.of(throwableType); this.relocationHandler = Advice.Dispatcher.RelocationHandler.ForType.of(relocatableType, relocatableIndex, (TypeDefinition)adviceMethod.getReturnType()); } public boolean isAlive() { return true; } public boolean equals(@MaybeNull Object param3Object) { return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!this.postProcessor.equals(((AbstractBase)param3Object).postProcessor) ? false : (!this.offsetMappings.equals(((AbstractBase)param3Object).offsetMappings) ? false : (!this.suppressionHandler.equals(((AbstractBase)param3Object).suppressionHandler) ? false : (!!this.relocationHandler.equals(((AbstractBase)param3Object).relocationHandler))))))); } public int hashCode() { return (((getClass().hashCode() * 31 + this.postProcessor.hashCode()) * 31 + this.offsetMappings.hashCode()) * 31 + this.suppressionHandler.hashCode()) * 31 + this.relocationHandler.hashCode(); } } public static interface ForMethodExit extends Resolved { TypeDescription getThrowable(); Advice.ArgumentHandler.Factory getArgumentHandlerFactory(); } public static interface ForMethodEnter extends Resolved { boolean isPrependLineNumber(); TypeDefinition getActualAdviceType(); } } public enum Inactive implements Dispatcher.Unresolved, Dispatcher.Resolved.ForMethodEnter, Dispatcher.Resolved.ForMethodExit, Dispatcher.Bound { INSTANCE; public boolean isAlive() { return false; } public boolean isBinary() { return false; } public TypeDescription getAdviceType() { return TypeDescription.ForLoadedType.of(void.class); } public boolean isPrependLineNumber() { return false; } public TypeDefinition getActualAdviceType() { return (TypeDefinition)TypeDescription.ForLoadedType.of(void.class); } public Map<String, TypeDefinition> getNamedTypes() { return Collections.emptyMap(); } public TypeDescription getThrowable() { return Advice.NoExceptionHandler.DESCRIPTION; } public Advice.ArgumentHandler.Factory getArgumentHandlerFactory() { return Advice.ArgumentHandler.Factory.SIMPLE; } public Advice.Dispatcher.Resolved.ForMethodEnter asMethodEnter(List<? extends Advice.OffsetMapping.Factory<?>> userFactories, @MaybeNull AsmClassReader classReader, Advice.Dispatcher.Unresolved methodExit, Advice.PostProcessor.Factory postProcessorFactory) { return this; } public Advice.Dispatcher.Resolved.ForMethodExit asMethodExit(List<? extends Advice.OffsetMapping.Factory<?>> userFactories, @MaybeNull AsmClassReader classReader, Advice.Dispatcher.Unresolved methodEnter, Advice.PostProcessor.Factory postProcessorFactory) { return this; } public void prepare() {} public void initialize() {} public void apply() {} public Advice.Dispatcher.Bound bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) { return this; } } @Enhance public static class Inlining implements Dispatcher.Unresolved { protected final MethodDescription.InDefinedShape adviceMethod; private final Map<String, TypeDefinition> namedTypes; protected Inlining(MethodDescription.InDefinedShape adviceMethod) { this.adviceMethod = adviceMethod; this.namedTypes = new HashMap<String, TypeDefinition>(); for (ParameterDescription parameterDescription : adviceMethod.getParameters()) { AnnotationDescription.Loadable<Advice.Local> annotationDescription = parameterDescription.getDeclaredAnnotations().ofType(Advice.Local.class); if (annotationDescription != null) { String name = (String)annotationDescription.getValue(Advice.OffsetMapping.ForLocalValue.Factory.LOCAL_VALUE).resolve(String.class); TypeDefinition previous = (TypeDefinition)this.namedTypes.put(name, parameterDescription.getType()); if (previous != null && !previous.equals(parameterDescription.getType())) throw new IllegalStateException("Local variable for " + name + " is defined with inconsistent types");  }  }  } public boolean isAlive() { return true; } public boolean isBinary() { return true; } public TypeDescription getAdviceType() { return this.adviceMethod.getReturnType().asErasure(); } public Map<String, TypeDefinition> getNamedTypes() { return this.namedTypes; } public Advice.Dispatcher.Resolved.ForMethodEnter asMethodEnter(List<? extends Advice.OffsetMapping.Factory<?>> userFactories, @MaybeNull AsmClassReader classReader, Advice.Dispatcher.Unresolved methodExit, Advice.PostProcessor.Factory postProcessorFactory) { if (classReader == null) throw new IllegalStateException("Class reader not expected null");  return Resolved.ForMethodEnter.of(this.adviceMethod, postProcessorFactory.make((List<? extends AnnotationDescription>)this.adviceMethod.getDeclaredAnnotations(), this.adviceMethod.getReturnType().asErasure(), false), this.namedTypes, userFactories, methodExit.getAdviceType(), classReader, methodExit.isAlive()); } public Advice.Dispatcher.Resolved.ForMethodExit asMethodExit(List<? extends Advice.OffsetMapping.Factory<?>> userFactories, @MaybeNull AsmClassReader classReader, Advice.Dispatcher.Unresolved methodEnter, Advice.PostProcessor.Factory postProcessorFactory) { Map<String, TypeDefinition> namedTypes = new HashMap<String, TypeDefinition>(methodEnter.getNamedTypes()), uninitializedNamedTypes = new HashMap<String, TypeDefinition>(); for (Map.Entry<String, TypeDefinition> entry : this.namedTypes.entrySet()) { TypeDefinition typeDefinition = namedTypes.get(entry.getKey()), uninitializedTypeDefinition = uninitializedNamedTypes.get(entry.getKey()); if (typeDefinition == null && uninitializedTypeDefinition == null) { namedTypes.put(entry.getKey(), entry.getValue()); uninitializedNamedTypes.put(entry.getKey(), entry.getValue()); continue; }  if (!((typeDefinition == null) ? uninitializedTypeDefinition : typeDefinition).equals(entry.getValue())) throw new IllegalStateException("Local variable for " + (String)entry.getKey() + " is defined with inconsistent types");  }  return Resolved.ForMethodExit.of(this.adviceMethod, postProcessorFactory.make((List<? extends AnnotationDescription>)this.adviceMethod.getDeclaredAnnotations(), this.adviceMethod.getReturnType().asErasure(), true), namedTypes, uninitializedNamedTypes, userFactories, classReader, methodEnter.getAdviceType()); } public String toString() { return "Delegate to " + this.adviceMethod; } public boolean equals(@MaybeNull Object param1Object) { return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.adviceMethod.equals(((Inlining)param1Object).adviceMethod) ? false : (!!this.namedTypes.equals(((Inlining)param1Object).namedTypes))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.adviceMethod.hashCode()) * 31 + this.namedTypes.hashCode(); } protected static abstract class Resolved extends Advice.Dispatcher.Resolved.AbstractBase { protected final MethodDescription.InDefinedShape adviceMethod; protected final AsmClassReader classReader; protected Resolved(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> factories, TypeDescription throwableType, TypeDescription relocatableType, int relocatableIndex, AsmClassReader classReader) { super(adviceMethod, postProcessor, factories, throwableType, relocatableType, relocatableIndex, Advice.OffsetMapping.Factory.AdviceType.INLINING); this.adviceMethod = adviceMethod; this.classReader = classReader; } protected abstract Map<Integer, TypeDefinition> resolveInitializationTypes(Advice.ArgumentHandler param3ArgumentHandler); protected abstract MethodVisitor apply(MethodVisitor param3MethodVisitor, Implementation.Context param3Context, Assigner param3Assigner, Advice.ArgumentHandler.ForInstrumentedMethod param3ForInstrumentedMethod, Advice.MethodSizeHandler.ForInstrumentedMethod param3ForInstrumentedMethod1, Advice.StackMapFrameHandler.ForInstrumentedMethod param3ForInstrumentedMethod2, TypeDescription param3TypeDescription, MethodDescription param3MethodDescription, Advice.Dispatcher.SuppressionHandler.Bound param3Bound, Advice.Dispatcher.RelocationHandler.Bound param3Bound1, StackManipulation param3StackManipulation); protected class AdviceMethodInliner extends ClassVisitor implements Advice.Dispatcher.Bound { protected final TypeDescription instrumentedType; protected final MethodDescription instrumentedMethod; protected final MethodVisitor methodVisitor; protected final Implementation.Context implementationContext; protected final Assigner assigner; protected final Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler; protected final Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler; protected final Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler; protected final Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler; protected final Advice.Dispatcher.RelocationHandler.Bound relocationHandler; protected final StackManipulation exceptionHandler; protected final AsmClassReader classReader; protected final List<Label> labels; protected AdviceMethodInliner(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler, AsmClassReader classReader) { super(OpenedClassReader.ASM_API); this.instrumentedType = instrumentedType; this.instrumentedMethod = instrumentedMethod; this.methodVisitor = methodVisitor; this.implementationContext = implementationContext; this.assigner = assigner; this.argumentHandler = argumentHandler; this.methodSizeHandler = methodSizeHandler; this.stackMapFrameHandler = stackMapFrameHandler; this.suppressionHandler = suppressionHandler; this.relocationHandler = relocationHandler; this.exceptionHandler = exceptionHandler; this.classReader = classReader; this.labels = new ArrayList<Label>(); } public void prepare() { this.classReader.accept(new ExceptionTableExtractor(), 6); this.suppressionHandler.onPrepare(this.methodVisitor); } public void initialize() { for (Map.Entry<Integer, TypeDefinition> typeDefinition : Advice.Dispatcher.Inlining.Resolved.this.resolveInitializationTypes(this.argumentHandler).entrySet()) { if (((TypeDefinition)typeDefinition.getValue()).represents(boolean.class) || ((TypeDefinition)typeDefinition.getValue()).represents(byte.class) || ((TypeDefinition)typeDefinition.getValue()).represents(short.class) || ((TypeDefinition)typeDefinition.getValue()).represents(char.class) || ((TypeDefinition)typeDefinition.getValue()).represents(int.class)) { this.methodVisitor.visitInsn(3); this.methodVisitor.visitVarInsn(54, ((Integer)typeDefinition.getKey()).intValue()); } else if (((TypeDefinition)typeDefinition.getValue()).represents(long.class)) { this.methodVisitor.visitInsn(9); this.methodVisitor.visitVarInsn(55, ((Integer)typeDefinition.getKey()).intValue()); } else if (((TypeDefinition)typeDefinition.getValue()).represents(float.class)) { this.methodVisitor.visitInsn(11); this.methodVisitor.visitVarInsn(56, ((Integer)typeDefinition.getKey()).intValue()); } else if (((TypeDefinition)typeDefinition.getValue()).represents(double.class)) { this.methodVisitor.visitInsn(14); this.methodVisitor.visitVarInsn(57, ((Integer)typeDefinition.getKey()).intValue()); } else { this.methodVisitor.visitInsn(1); this.methodVisitor.visitVarInsn(58, ((Integer)typeDefinition.getKey()).intValue()); }  this.methodSizeHandler.requireStackSize(((TypeDefinition)typeDefinition.getValue()).getStackSize().getSize()); }  } public void apply() { this.classReader.accept(this, 0x2 | this.stackMapFrameHandler.getReaderHint()); } @MaybeNull public MethodVisitor visitMethod(int modifiers, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull String[] exception) { return (Advice.Dispatcher.Inlining.Resolved.this.adviceMethod.getInternalName().equals(internalName) && Advice.Dispatcher.Inlining.Resolved.this.adviceMethod.getDescriptor().equals(descriptor)) ? new ExceptionTableSubstitutor(Advice.Dispatcher.Inlining.Resolved.this.apply(this.methodVisitor, this.implementationContext, this.assigner, this.argumentHandler, this.methodSizeHandler, this.stackMapFrameHandler, this.instrumentedType, this.instrumentedMethod, this.suppressionHandler, this.relocationHandler, this.exceptionHandler)) : Advice.Dispatcher.IGNORE_METHOD; } protected class ExceptionTableExtractor extends ClassVisitor { protected ExceptionTableExtractor() { super(OpenedClassReader.ASM_API); } @MaybeNull public MethodVisitor visitMethod(int modifiers, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull String[] exception) { return (Advice.Dispatcher.Inlining.Resolved.this.adviceMethod.getInternalName().equals(internalName) && Advice.Dispatcher.Inlining.Resolved.this.adviceMethod.getDescriptor().equals(descriptor)) ? new Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner.ExceptionTableCollector(Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner.this.methodVisitor) : Advice.Dispatcher.IGNORE_METHOD; } } protected class ExceptionTableCollector extends MethodVisitor { private final MethodVisitor methodVisitor; protected ExceptionTableCollector(MethodVisitor methodVisitor) { super(OpenedClassReader.ASM_API); this.methodVisitor = methodVisitor; } public void visitTryCatchBlock(Label start, Label end, Label handler, @MaybeNull String type) { this.methodVisitor.visitTryCatchBlock(start, end, handler, type); Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner.this.labels.addAll(Arrays.asList(new Label[] { start, end, handler })); } @MaybeNull public AnnotationVisitor visitTryCatchAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) { return this.methodVisitor.visitTryCatchAnnotation(typeReference, typePath, descriptor, visible); } } protected class ExceptionTableSubstitutor extends MethodVisitor { private final Map<Label, Label> substitutions; private int index; protected ExceptionTableSubstitutor(MethodVisitor methodVisitor) { super(OpenedClassReader.ASM_API, methodVisitor); this.substitutions = new IdentityHashMap<Label, Label>(); } public void visitTryCatchBlock(Label start, Label end, Label handler, String type) { this.substitutions.put(start, Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner.this.labels.get(this.index++)); this.substitutions.put(end, Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner.this.labels.get(this.index++)); Label actualHandler = Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner.this.labels.get(this.index++); this.substitutions.put(handler, actualHandler); ((Advice.Dispatcher.Inlining.CodeTranslationVisitor)this.mv).propagateHandler(actualHandler); } @MaybeNull public AnnotationVisitor visitTryCatchAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) { return Advice.Dispatcher.IGNORE_ANNOTATION; } public void visitLabel(Label label) { super.visitLabel(resolve(label)); } public void visitJumpInsn(int opcode, Label label) { super.visitJumpInsn(opcode, resolve(label)); } public void visitTableSwitchInsn(int minimum, int maximum, Label defaultOption, Label... label) { super.visitTableSwitchInsn(minimum, maximum, defaultOption, resolve(label)); } public void visitLookupSwitchInsn(Label defaultOption, int[] keys, Label[] label) { super.visitLookupSwitchInsn(resolve(defaultOption), keys, resolve(label)); } private Label[] resolve(Label[] label) { Label[] resolved = new Label[label.length]; int index = 0; for (Label aLabel : label) resolved[index++] = resolve(aLabel);  return resolved; } private Label resolve(Label label) { Label substitution = this.substitutions.get(label); return (substitution == null) ? label : substitution; } } } @Enhance protected static abstract class ForMethodEnter extends Resolved implements Advice.Dispatcher.Resolved.ForMethodEnter { private final Map<String, TypeDefinition> namedTypes; private final boolean prependLineNumber; @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected ForMethodEnter(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, AsmClassReader classReader) { super(adviceMethod, postProcessor, CompoundList.of(Arrays.asList(new Advice.OffsetMapping.Factory[] { Advice.OffsetMapping.ForArgument.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForAllArguments.Factory.INSTANCE, Advice.OffsetMapping.ForThisReference.Factory.INSTANCE, Advice.OffsetMapping.ForField.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.ReaderFactory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.WriterFactory.INSTANCE, Advice.OffsetMapping.ForOrigin.Factory.INSTANCE, Advice.OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, Advice.OffsetMapping.ForHandle.Factory.INSTANCE, Advice.OffsetMapping.ForDynamicConstant.Factory.INSTANCE, Advice.OffsetMapping.ForUnusedValue.Factory.INSTANCE, Advice.OffsetMapping.ForStubValue.INSTANCE, Advice.OffsetMapping.ForThrowable.Factory.INSTANCE, Advice.OffsetMapping.ForExitValue.Factory.of(exitType), new Advice.OffsetMapping.ForLocalValue.Factory(namedTypes), new Advice.OffsetMapping.Factory.Illegal<Advice.Thrown>(Advice.Thrown.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Enter>(Advice.Enter.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Return>(Advice.Return.class) }, ), userFactories), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SUPPRESS_ENTER).resolve(TypeDescription.class), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SKIP_ON).resolve(TypeDescription.class), ((Integer)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SKIP_ON_INDEX).resolve(Integer.class)).intValue(), classReader); this.namedTypes = namedTypes; this.prependLineNumber = ((Boolean)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.PREPEND_LINE_NUMBER).resolve(Boolean.class)).booleanValue(); } protected static Advice.Dispatcher.Resolved.ForMethodEnter of(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, AsmClassReader classReader, boolean methodExit) { return methodExit ? new WithRetainedEnterType(adviceMethod, postProcessor, namedTypes, userFactories, exitType, classReader) : new WithDiscardedEnterType(adviceMethod, postProcessor, namedTypes, userFactories, exitType, classReader); } protected Map<Integer, TypeDefinition> resolveInitializationTypes(Advice.ArgumentHandler argumentHandler) { SortedMap<Integer, TypeDefinition> resolved = new TreeMap<Integer, TypeDefinition>(); for (Map.Entry<String, TypeDefinition> entry : this.namedTypes.entrySet()) resolved.put(Integer.valueOf(argumentHandler.named(entry.getKey())), entry.getValue());  return resolved; } public Advice.Dispatcher.Bound bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) { return new Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, this.suppressionHandler.bind(exceptionHandler), this.relocationHandler.bind(instrumentedMethod, relocation), exceptionHandler, this.classReader); } public boolean isPrependLineNumber() { return this.prependLineNumber; } public TypeDefinition getActualAdviceType() { return (TypeDefinition)this.adviceMethod.getReturnType(); } public Map<String, TypeDefinition> getNamedTypes() { return this.namedTypes; } protected MethodVisitor apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { MethodDescription.TypeToken typeToken = this.adviceMethod.asTypeToken(); return doApply(methodVisitor, implementationContext, assigner, argumentHandler.bindEnter(typeToken), methodSizeHandler.bindEnter(typeToken), stackMapFrameHandler.bindEnter(typeToken), instrumentedType, instrumentedMethod, suppressionHandler, relocationHandler, exceptionHandler); } protected MethodVisitor doApply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { Map<Integer, Advice.OffsetMapping.Target> offsetMappings = new HashMap<Integer, Advice.OffsetMapping.Target>(); for (Map.Entry<Integer, Advice.OffsetMapping> entry : this.offsetMappings.entrySet()) offsetMappings.put(entry.getKey(), ((Advice.OffsetMapping)entry.getValue()).resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, Advice.OffsetMapping.Sort.ENTER));  return new Advice.Dispatcher.Inlining.CodeTranslationVisitor(methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, instrumentedType, instrumentedMethod, assigner, this.adviceMethod, offsetMappings, suppressionHandler, relocationHandler, exceptionHandler, this.postProcessor, false); } public boolean equals(@MaybeNull Object param4Object) { return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : ((this.prependLineNumber != ((ForMethodEnter)param4Object).prependLineNumber) ? false : (!!this.namedTypes.equals(((ForMethodEnter)param4Object).namedTypes)))))); } public int hashCode() { return (super.hashCode() * 31 + this.namedTypes.hashCode()) * 31 + this.prependLineNumber; } protected static class WithRetainedEnterType extends ForMethodEnter { protected WithRetainedEnterType(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, AsmClassReader classReader) { super(adviceMethod, postProcessor, namedTypes, userFactories, exitType, classReader); } public TypeDefinition getAdviceType() { return (TypeDefinition)this.adviceMethod.getReturnType(); } } protected static class WithDiscardedEnterType extends ForMethodEnter { protected WithDiscardedEnterType(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, AsmClassReader classReader) { super(adviceMethod, postProcessor, namedTypes, userFactories, exitType, classReader); } public TypeDefinition getAdviceType() { return (TypeDefinition)TypeDescription.ForLoadedType.of(void.class); } protected MethodVisitor doApply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { methodSizeHandler.requireLocalVariableLengthPadding(this.adviceMethod.getReturnType().getStackSize().getSize()); return super.doApply(methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, instrumentedType, instrumentedMethod, suppressionHandler, relocationHandler, exceptionHandler); } } } @Enhance protected static abstract class ForMethodExit extends Resolved implements Advice.Dispatcher.Resolved.ForMethodExit { private final Map<String, TypeDefinition> uninitializedNamedTypes; private final boolean backupArguments; @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected ForMethodExit(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, Map<String, TypeDefinition> uninitializedNamedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, AsmClassReader classReader, TypeDefinition enterType) { super(adviceMethod, postProcessor, CompoundList.of(Arrays.asList(new Advice.OffsetMapping.Factory[] { Advice.OffsetMapping.ForArgument.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForAllArguments.Factory.INSTANCE, Advice.OffsetMapping.ForThisReference.Factory.INSTANCE, Advice.OffsetMapping.ForField.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.ReaderFactory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.WriterFactory.INSTANCE, Advice.OffsetMapping.ForOrigin.Factory.INSTANCE, Advice.OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, Advice.OffsetMapping.ForHandle.Factory.INSTANCE, Advice.OffsetMapping.ForDynamicConstant.Factory.INSTANCE, Advice.OffsetMapping.ForUnusedValue.Factory.INSTANCE, Advice.OffsetMapping.ForStubValue.INSTANCE, Advice.OffsetMapping.ForEnterValue.Factory.of(enterType), Advice.OffsetMapping.ForExitValue.Factory.of((TypeDefinition)adviceMethod.getReturnType()), new Advice.OffsetMapping.ForLocalValue.Factory(namedTypes), Advice.OffsetMapping.ForReturnValue.Factory.INSTANCE, Advice.OffsetMapping.ForThrowable.Factory.of(adviceMethod) }, ), userFactories), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.SUPPRESS_EXIT).resolve(TypeDescription.class), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.REPEAT_ON).resolve(TypeDescription.class), ((Integer)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.REPEAT_ON_INDEX).resolve(Integer.class)).intValue(), classReader); this.uninitializedNamedTypes = uninitializedNamedTypes; this.backupArguments = ((Boolean)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.BACKUP_ARGUMENTS).resolve(Boolean.class)).booleanValue(); } @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected static Advice.Dispatcher.Resolved.ForMethodExit of(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, Map<String, TypeDefinition> uninitializedNamedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, AsmClassReader classReader, TypeDefinition enterType) { TypeDescription throwable = (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.ON_THROWABLE).resolve(TypeDescription.class); return throwable.represents(Advice.NoExceptionHandler.class) ? new WithoutExceptionHandler(adviceMethod, postProcessor, namedTypes, uninitializedNamedTypes, userFactories, classReader, enterType) : new WithExceptionHandler(adviceMethod, postProcessor, namedTypes, uninitializedNamedTypes, userFactories, classReader, enterType, throwable); } public Map<String, TypeDefinition> getNamedTypes() { return this.uninitializedNamedTypes; } protected Map<Integer, TypeDefinition> resolveInitializationTypes(Advice.ArgumentHandler argumentHandler) { SortedMap<Integer, TypeDefinition> resolved = new TreeMap<Integer, TypeDefinition>(); for (Map.Entry<String, TypeDefinition> entry : this.uninitializedNamedTypes.entrySet()) resolved.put(Integer.valueOf(argumentHandler.named(entry.getKey())), entry.getValue());  if (!this.adviceMethod.getReturnType().represents(void.class)) resolved.put(Integer.valueOf(argumentHandler.exit()), this.adviceMethod.getReturnType());  return resolved; } protected MethodVisitor apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { MethodDescription.TypeToken typeToken = this.adviceMethod.asTypeToken(); return doApply(methodVisitor, implementationContext, assigner, argumentHandler.bindExit(typeToken, getThrowable().represents(Advice.NoExceptionHandler.class)), methodSizeHandler.bindExit(typeToken), stackMapFrameHandler.bindExit(typeToken), instrumentedType, instrumentedMethod, suppressionHandler, relocationHandler, exceptionHandler); } private MethodVisitor doApply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { Map<Integer, Advice.OffsetMapping.Target> offsetMappings = new HashMap<Integer, Advice.OffsetMapping.Target>(); for (Map.Entry<Integer, Advice.OffsetMapping> entry : this.offsetMappings.entrySet()) offsetMappings.put(entry.getKey(), ((Advice.OffsetMapping)entry.getValue()).resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, Advice.OffsetMapping.Sort.EXIT));  return new Advice.Dispatcher.Inlining.CodeTranslationVisitor(methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, instrumentedType, instrumentedMethod, assigner, this.adviceMethod, offsetMappings, suppressionHandler, relocationHandler, exceptionHandler, this.postProcessor, true); } public Advice.ArgumentHandler.Factory getArgumentHandlerFactory() { return this.backupArguments ? Advice.ArgumentHandler.Factory.COPYING : Advice.ArgumentHandler.Factory.SIMPLE; } public TypeDefinition getAdviceType() { return (TypeDefinition)this.adviceMethod.getReturnType(); } public Advice.Dispatcher.Bound bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) { return new Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, this.suppressionHandler.bind(exceptionHandler), this.relocationHandler.bind(instrumentedMethod, relocation), exceptionHandler, this.classReader); } public boolean equals(@MaybeNull Object param4Object) { return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : ((this.backupArguments != ((ForMethodExit)param4Object).backupArguments) ? false : (!!this.uninitializedNamedTypes.equals(((ForMethodExit)param4Object).uninitializedNamedTypes)))))); } public int hashCode() { return (super.hashCode() * 31 + this.uninitializedNamedTypes.hashCode()) * 31 + this.backupArguments; } @Enhance protected static class WithExceptionHandler extends ForMethodExit { private final TypeDescription throwable; protected WithExceptionHandler(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, Map<String, TypeDefinition> uninitializedNamedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, AsmClassReader classReader, TypeDefinition enterType, TypeDescription throwable) { super(adviceMethod, postProcessor, namedTypes, uninitializedNamedTypes, userFactories, classReader, enterType); this.throwable = throwable; } public TypeDescription getThrowable() { return this.throwable; } public boolean equals(@MaybeNull Object param5Object) { return !super.equals(param5Object) ? false : ((this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.throwable.equals(((WithExceptionHandler)param5Object).throwable))))); } public int hashCode() { return super.hashCode() * 31 + this.throwable.hashCode(); } } protected static class WithoutExceptionHandler extends ForMethodExit { protected WithoutExceptionHandler(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, Map<String, TypeDefinition> uninitializedNamedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, AsmClassReader classReader, TypeDefinition enterType) { super(adviceMethod, postProcessor, namedTypes, uninitializedNamedTypes, userFactories, classReader, enterType); } public TypeDescription getThrowable() { return Advice.NoExceptionHandler.DESCRIPTION; } } } } @Enhance protected static abstract class ForMethodEnter extends Resolved implements Advice.Dispatcher.Resolved.ForMethodEnter { private final Map<String, TypeDefinition> namedTypes; private final boolean prependLineNumber; @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected ForMethodEnter(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, AsmClassReader classReader) { super(adviceMethod, postProcessor, CompoundList.of(Arrays.asList(new Advice.OffsetMapping.Factory[] { Advice.OffsetMapping.ForArgument.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForAllArguments.Factory.INSTANCE, Advice.OffsetMapping.ForThisReference.Factory.INSTANCE, Advice.OffsetMapping.ForField.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.ReaderFactory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.WriterFactory.INSTANCE, Advice.OffsetMapping.ForOrigin.Factory.INSTANCE, Advice.OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, Advice.OffsetMapping.ForHandle.Factory.INSTANCE, Advice.OffsetMapping.ForDynamicConstant.Factory.INSTANCE, Advice.OffsetMapping.ForUnusedValue.Factory.INSTANCE, Advice.OffsetMapping.ForStubValue.INSTANCE, Advice.OffsetMapping.ForThrowable.Factory.INSTANCE, Advice.OffsetMapping.ForExitValue.Factory.of(exitType), new Advice.OffsetMapping.ForLocalValue.Factory(namedTypes), new Advice.OffsetMapping.Factory.Illegal<Advice.Thrown>(Advice.Thrown.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Enter>(Advice.Enter.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Return>(Advice.Return.class) }, ), userFactories), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SUPPRESS_ENTER).resolve(TypeDescription.class), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SKIP_ON).resolve(TypeDescription.class), ((Integer)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SKIP_ON_INDEX).resolve(Integer.class)).intValue(), classReader); this.namedTypes = namedTypes; this.prependLineNumber = ((Boolean)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.PREPEND_LINE_NUMBER).resolve(Boolean.class)).booleanValue(); } protected static Advice.Dispatcher.Resolved.ForMethodEnter of(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, AsmClassReader classReader, boolean methodExit) { return methodExit ? new WithRetainedEnterType(adviceMethod, postProcessor, namedTypes, userFactories, exitType, classReader) : new WithDiscardedEnterType(adviceMethod, postProcessor, namedTypes, userFactories, exitType, classReader); } protected Map<Integer, TypeDefinition> resolveInitializationTypes(Advice.ArgumentHandler argumentHandler) { SortedMap<Integer, TypeDefinition> resolved = new TreeMap<Integer, TypeDefinition>(); for (Map.Entry<String, TypeDefinition> entry : this.namedTypes.entrySet()) resolved.put(Integer.valueOf(argumentHandler.named(entry.getKey())), entry.getValue());  return resolved; } public Advice.Dispatcher.Bound bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) { return new Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner(this, instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, this.suppressionHandler.bind(exceptionHandler), this.relocationHandler.bind(instrumentedMethod, relocation), exceptionHandler, this.classReader); } public boolean isPrependLineNumber() { return this.prependLineNumber; } public TypeDefinition getActualAdviceType() { return (TypeDefinition)this.adviceMethod.getReturnType(); } public Map<String, TypeDefinition> getNamedTypes() { return this.namedTypes; } protected MethodVisitor apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { MethodDescription.TypeToken typeToken = this.adviceMethod.asTypeToken(); return doApply(methodVisitor, implementationContext, assigner, argumentHandler.bindEnter(typeToken), methodSizeHandler.bindEnter(typeToken), stackMapFrameHandler.bindEnter(typeToken), instrumentedType, instrumentedMethod, suppressionHandler, relocationHandler, exceptionHandler); } protected MethodVisitor doApply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { Map<Integer, Advice.OffsetMapping.Target> offsetMappings = new HashMap<Integer, Advice.OffsetMapping.Target>(); for (Map.Entry<Integer, Advice.OffsetMapping> entry : this.offsetMappings.entrySet()) offsetMappings.put(entry.getKey(), ((Advice.OffsetMapping)entry.getValue()).resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, Advice.OffsetMapping.Sort.ENTER));  return new Advice.Dispatcher.Inlining.CodeTranslationVisitor(methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, instrumentedType, instrumentedMethod, assigner, this.adviceMethod, offsetMappings, suppressionHandler, relocationHandler, exceptionHandler, this.postProcessor, false); } public boolean equals(@MaybeNull Object param3Object) { return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.prependLineNumber != ((ForMethodEnter)param3Object).prependLineNumber) ? false : (!!this.namedTypes.equals(((ForMethodEnter)param3Object).namedTypes)))))); } public int hashCode() { return (super.hashCode() * 31 + this.namedTypes.hashCode()) * 31 + this.prependLineNumber; } protected static class WithRetainedEnterType extends ForMethodEnter { protected WithRetainedEnterType(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, AsmClassReader classReader) { super(adviceMethod, postProcessor, namedTypes, userFactories, exitType, classReader); } public TypeDefinition getAdviceType() { return (TypeDefinition)this.adviceMethod.getReturnType(); } } protected static class WithDiscardedEnterType extends ForMethodEnter { protected WithDiscardedEnterType(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, AsmClassReader classReader) { super(adviceMethod, postProcessor, namedTypes, userFactories, exitType, classReader); } public TypeDefinition getAdviceType() { return (TypeDefinition)TypeDescription.ForLoadedType.of(void.class); } protected MethodVisitor doApply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { methodSizeHandler.requireLocalVariableLengthPadding(this.adviceMethod.getReturnType().getStackSize().getSize()); return super.doApply(methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, instrumentedType, instrumentedMethod, suppressionHandler, relocationHandler, exceptionHandler); } } } @Enhance protected static abstract class ForMethodExit extends Resolved implements Advice.Dispatcher.Resolved.ForMethodExit { private final Map<String, TypeDefinition> uninitializedNamedTypes; private final boolean backupArguments; @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected ForMethodExit(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, Map<String, TypeDefinition> uninitializedNamedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, AsmClassReader classReader, TypeDefinition enterType) { super(adviceMethod, postProcessor, CompoundList.of(Arrays.asList(new Advice.OffsetMapping.Factory[] { Advice.OffsetMapping.ForArgument.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForAllArguments.Factory.INSTANCE, Advice.OffsetMapping.ForThisReference.Factory.INSTANCE, Advice.OffsetMapping.ForField.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.ReaderFactory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.WriterFactory.INSTANCE, Advice.OffsetMapping.ForOrigin.Factory.INSTANCE, Advice.OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, Advice.OffsetMapping.ForHandle.Factory.INSTANCE, Advice.OffsetMapping.ForDynamicConstant.Factory.INSTANCE, Advice.OffsetMapping.ForUnusedValue.Factory.INSTANCE, Advice.OffsetMapping.ForStubValue.INSTANCE, Advice.OffsetMapping.ForEnterValue.Factory.of(enterType), Advice.OffsetMapping.ForExitValue.Factory.of((TypeDefinition)adviceMethod.getReturnType()), new Advice.OffsetMapping.ForLocalValue.Factory(namedTypes), Advice.OffsetMapping.ForReturnValue.Factory.INSTANCE, Advice.OffsetMapping.ForThrowable.Factory.of(adviceMethod) }, ), userFactories), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.SUPPRESS_EXIT).resolve(TypeDescription.class), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.REPEAT_ON).resolve(TypeDescription.class), ((Integer)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.REPEAT_ON_INDEX).resolve(Integer.class)).intValue(), classReader); this.uninitializedNamedTypes = uninitializedNamedTypes; this.backupArguments = ((Boolean)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.BACKUP_ARGUMENTS).resolve(Boolean.class)).booleanValue(); } @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected static Advice.Dispatcher.Resolved.ForMethodExit of(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, Map<String, TypeDefinition> uninitializedNamedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, AsmClassReader classReader, TypeDefinition enterType) { TypeDescription throwable = (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.ON_THROWABLE).resolve(TypeDescription.class); return throwable.represents(Advice.NoExceptionHandler.class) ? new WithoutExceptionHandler(adviceMethod, postProcessor, namedTypes, uninitializedNamedTypes, userFactories, classReader, enterType) : new WithExceptionHandler(adviceMethod, postProcessor, namedTypes, uninitializedNamedTypes, userFactories, classReader, enterType, throwable); } public Map<String, TypeDefinition> getNamedTypes() { return this.uninitializedNamedTypes; } protected Map<Integer, TypeDefinition> resolveInitializationTypes(Advice.ArgumentHandler argumentHandler) { SortedMap<Integer, TypeDefinition> resolved = new TreeMap<Integer, TypeDefinition>(); for (Map.Entry<String, TypeDefinition> entry : this.uninitializedNamedTypes.entrySet()) resolved.put(Integer.valueOf(argumentHandler.named(entry.getKey())), entry.getValue());  if (!this.adviceMethod.getReturnType().represents(void.class)) resolved.put(Integer.valueOf(argumentHandler.exit()), this.adviceMethod.getReturnType());  return resolved; } protected MethodVisitor apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { MethodDescription.TypeToken typeToken = this.adviceMethod.asTypeToken(); return doApply(methodVisitor, implementationContext, assigner, argumentHandler.bindExit(typeToken, getThrowable().represents(Advice.NoExceptionHandler.class)), methodSizeHandler.bindExit(typeToken), stackMapFrameHandler.bindExit(typeToken), instrumentedType, instrumentedMethod, suppressionHandler, relocationHandler, exceptionHandler); } private MethodVisitor doApply(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { Map<Integer, Advice.OffsetMapping.Target> offsetMappings = new HashMap<Integer, Advice.OffsetMapping.Target>(); for (Map.Entry<Integer, Advice.OffsetMapping> entry : this.offsetMappings.entrySet()) offsetMappings.put(entry.getKey(), ((Advice.OffsetMapping)entry.getValue()).resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, Advice.OffsetMapping.Sort.EXIT));  return new Advice.Dispatcher.Inlining.CodeTranslationVisitor(methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, instrumentedType, instrumentedMethod, assigner, this.adviceMethod, offsetMappings, suppressionHandler, relocationHandler, exceptionHandler, this.postProcessor, true); } public Advice.ArgumentHandler.Factory getArgumentHandlerFactory() { return this.backupArguments ? Advice.ArgumentHandler.Factory.COPYING : Advice.ArgumentHandler.Factory.SIMPLE; } public TypeDefinition getAdviceType() { return (TypeDefinition)this.adviceMethod.getReturnType(); } public Advice.Dispatcher.Bound bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) { return new Advice.Dispatcher.Inlining.Resolved.AdviceMethodInliner(this, instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, this.suppressionHandler.bind(exceptionHandler), this.relocationHandler.bind(instrumentedMethod, relocation), exceptionHandler, this.classReader); } public boolean equals(@MaybeNull Object param3Object) { return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.backupArguments != ((ForMethodExit)param3Object).backupArguments) ? false : (!!this.uninitializedNamedTypes.equals(((ForMethodExit)param3Object).uninitializedNamedTypes)))))); } public int hashCode() { return (super.hashCode() * 31 + this.uninitializedNamedTypes.hashCode()) * 31 + this.backupArguments; } @Enhance protected static class WithExceptionHandler extends ForMethodExit { private final TypeDescription throwable; protected WithExceptionHandler(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, Map<String, TypeDefinition> uninitializedNamedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, AsmClassReader classReader, TypeDefinition enterType, TypeDescription throwable) { super(adviceMethod, postProcessor, namedTypes, uninitializedNamedTypes, userFactories, classReader, enterType); this.throwable = throwable; } public TypeDescription getThrowable() { return this.throwable; } public boolean equals(@MaybeNull Object param5Object) { return !super.equals(param5Object) ? false : ((this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.throwable.equals(((WithExceptionHandler)param5Object).throwable))))); } public int hashCode() { return super.hashCode() * 31 + this.throwable.hashCode(); } } protected static class WithoutExceptionHandler extends ForMethodExit { protected WithoutExceptionHandler(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, Map<String, TypeDefinition> uninitializedNamedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, AsmClassReader classReader, TypeDefinition enterType) { super(adviceMethod, postProcessor, namedTypes, uninitializedNamedTypes, userFactories, classReader, enterType); } public TypeDescription getThrowable() { return Advice.NoExceptionHandler.DESCRIPTION; } } } protected static class CodeTranslationVisitor extends MethodVisitor { protected final MethodVisitor methodVisitor; protected final Implementation.Context implementationContext; protected final Advice.ArgumentHandler.ForAdvice argumentHandler; protected final Advice.MethodSizeHandler.ForAdvice methodSizeHandler; protected final Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler; private final TypeDescription instrumentedType; private final MethodDescription instrumentedMethod; private final Assigner assigner; protected final MethodDescription.InDefinedShape adviceMethod; private final Map<Integer, Advice.OffsetMapping.Target> offsetMappings; private final Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler; private final Advice.Dispatcher.RelocationHandler.Bound relocationHandler; private final StackManipulation exceptionHandler; private final Advice.PostProcessor postProcessor; private final boolean exit; protected final Label endOfMethod; protected CodeTranslationVisitor(MethodVisitor methodVisitor, Implementation.Context implementationContext, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, MethodDescription.InDefinedShape adviceMethod, Map<Integer, Advice.OffsetMapping.Target> offsetMappings, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler, Advice.PostProcessor postProcessor, boolean exit) { super(OpenedClassReader.ASM_API, StackAwareMethodVisitor.of(methodVisitor, instrumentedMethod)); this.methodVisitor = methodVisitor; this.implementationContext = implementationContext; this.argumentHandler = argumentHandler; this.methodSizeHandler = methodSizeHandler; this.stackMapFrameHandler = stackMapFrameHandler; this.instrumentedType = instrumentedType; this.instrumentedMethod = instrumentedMethod; this.assigner = assigner; this.adviceMethod = adviceMethod; this.offsetMappings = offsetMappings; this.suppressionHandler = suppressionHandler; this.relocationHandler = relocationHandler; this.exceptionHandler = exceptionHandler; this.postProcessor = postProcessor; this.exit = exit; this.endOfMethod = new Label(); } protected void propagateHandler(Label label) { ((StackAwareMethodVisitor)this.mv).register(label, Collections.singletonList(StackSize.SINGLE)); } public void visitParameter(String name, int modifiers) {} public void visitAnnotableParameterCount(int count, boolean visible) {} @MaybeNull public AnnotationVisitor visitAnnotationDefault() { return Advice.Dispatcher.IGNORE_ANNOTATION; } @MaybeNull public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) { return Advice.Dispatcher.IGNORE_ANNOTATION; } @MaybeNull public AnnotationVisitor visitTypeAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) { return Advice.Dispatcher.IGNORE_ANNOTATION; } @MaybeNull public AnnotationVisitor visitParameterAnnotation(int index, String descriptor, boolean visible) { return Advice.Dispatcher.IGNORE_ANNOTATION; } public void visitAttribute(Attribute attribute) {} public void visitCode() { this.suppressionHandler.onStart(this.methodVisitor); } public void visitFrame(int type, int localVariableLength, @MaybeNull Object[] localVariable, int stackSize, @MaybeNull Object[] stack) { this.stackMapFrameHandler.translateFrame(this.methodVisitor, type, localVariableLength, localVariable, stackSize, stack); } public void visitVarInsn(int opcode, int offset) { Advice.OffsetMapping.Target target = this.offsetMappings.get(Integer.valueOf(offset)); if (target != null) { StackManipulation stackManipulation; StackSize expectedGrowth; switch (opcode) { case 21: case 23: case 25: stackManipulation = target.resolveRead(); expectedGrowth = StackSize.SINGLE; break;case 22: case 24: stackManipulation = target.resolveRead(); expectedGrowth = StackSize.DOUBLE; break;case 54: case 55: case 56: case 57: case 58: stackManipulation = target.resolveWrite(); expectedGrowth = StackSize.ZERO; break;default: throw new IllegalStateException("Unexpected opcode: " + opcode); }  this.methodSizeHandler.requireStackSizePadding(stackManipulation.apply(this.mv, this.implementationContext).getMaximalSize() - expectedGrowth.getSize()); } else { this.mv.visitVarInsn(opcode, this.argumentHandler.mapped(offset)); }  } public void visitIincInsn(int offset, int value) { Advice.OffsetMapping.Target target = this.offsetMappings.get(Integer.valueOf(offset)); if (target != null) { this.methodSizeHandler.requireStackSizePadding(target.resolveIncrement(value).apply(this.mv, this.implementationContext).getMaximalSize()); } else { this.mv.visitIincInsn(this.argumentHandler.mapped(offset), value); }  } public void visitInsn(int opcode) { switch (opcode) { case 177: ((StackAwareMethodVisitor)this.mv).drainStack(); break;case 172: this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(54, 21, StackSize.SINGLE)); break;case 176: this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(58, 25, StackSize.SINGLE)); break;case 174: this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(56, 23, StackSize.SINGLE)); break;case 173: this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(55, 22, StackSize.DOUBLE)); break;case 175: this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(57, 24, StackSize.DOUBLE)); break;default: this.mv.visitInsn(opcode); return; }  this.mv.visitJumpInsn(167, this.endOfMethod); } public void visitEnd() { this.suppressionHandler.onEnd(this.methodVisitor, this.implementationContext, this.methodSizeHandler, this.stackMapFrameHandler, (TypeDefinition)this.adviceMethod.getReturnType()); this.methodVisitor.visitLabel(this.endOfMethod); if (this.adviceMethod.getReturnType().represents(boolean.class) || this.adviceMethod.getReturnType().represents(byte.class) || this.adviceMethod.getReturnType().represents(short.class) || this.adviceMethod.getReturnType().represents(char.class) || this.adviceMethod.getReturnType().represents(int.class)) { this.stackMapFrameHandler.injectReturnFrame(this.methodVisitor); this.methodVisitor.visitVarInsn(54, this.exit ? this.argumentHandler.exit() : this.argumentHandler.enter()); } else if (this.adviceMethod.getReturnType().represents(long.class)) { this.stackMapFrameHandler.injectReturnFrame(this.methodVisitor); this.methodVisitor.visitVarInsn(55, this.exit ? this.argumentHandler.exit() : this.argumentHandler.enter()); } else if (this.adviceMethod.getReturnType().represents(float.class)) { this.stackMapFrameHandler.injectReturnFrame(this.methodVisitor); this.methodVisitor.visitVarInsn(56, this.exit ? this.argumentHandler.exit() : this.argumentHandler.enter()); } else if (this.adviceMethod.getReturnType().represents(double.class)) { this.stackMapFrameHandler.injectReturnFrame(this.methodVisitor); this.methodVisitor.visitVarInsn(57, this.exit ? this.argumentHandler.exit() : this.argumentHandler.enter()); } else if (!this.adviceMethod.getReturnType().represents(void.class)) { this.stackMapFrameHandler.injectReturnFrame(this.methodVisitor); this.methodVisitor.visitVarInsn(58, this.exit ? this.argumentHandler.exit() : this.argumentHandler.enter()); }  this.methodSizeHandler.requireStackSize(this.postProcessor.resolve(this.instrumentedType, this.instrumentedMethod, this.assigner, this.argumentHandler, this.stackMapFrameHandler, this.exceptionHandler).apply(this.methodVisitor, this.implementationContext).getMaximalSize()); this.methodSizeHandler.requireStackSize(this.relocationHandler.apply(this.methodVisitor, this.implementationContext, this.exit ? this.argumentHandler.exit() : this.argumentHandler.enter())); this.stackMapFrameHandler.injectCompletionFrame(this.methodVisitor); } public void visitMaxs(int stackSize, int localVariableLength) { this.methodSizeHandler.recordMaxima(stackSize, localVariableLength); } } } @Enhance public static class Delegating implements Dispatcher.Unresolved { protected final MethodDescription.InDefinedShape adviceMethod; protected final Advice.Delegator.Factory delegatorFactory; protected Delegating(MethodDescription.InDefinedShape adviceMethod, Advice.Delegator.Factory delegatorFactory) { this.adviceMethod = adviceMethod; this.delegatorFactory = delegatorFactory; } public boolean isAlive() { return true; } public boolean isBinary() { return false; } public TypeDefinition getAdviceType() { return (TypeDefinition)this.adviceMethod.getReturnType(); } public Map<String, TypeDefinition> getNamedTypes() { return Collections.emptyMap(); } public Advice.Dispatcher.Resolved.ForMethodEnter asMethodEnter(List<? extends Advice.OffsetMapping.Factory<?>> userFactories, @MaybeNull AsmClassReader classReader, Advice.Dispatcher.Unresolved methodExit, Advice.PostProcessor.Factory postProcessorFactory) { Advice.Delegator delegator = this.delegatorFactory.make(this.adviceMethod, false); return Resolved.ForMethodEnter.of(this.adviceMethod, postProcessorFactory.make((List<? extends AnnotationDescription>)this.adviceMethod.getDeclaredAnnotations(), delegator.getTypeToken().getReturnType(), false), delegator, userFactories, methodExit.getAdviceType(), methodExit.isAlive()); } public Advice.Dispatcher.Resolved.ForMethodExit asMethodExit(List<? extends Advice.OffsetMapping.Factory<?>> userFactories, @MaybeNull AsmClassReader classReader, Advice.Dispatcher.Unresolved methodEnter, Advice.PostProcessor.Factory postProcessorFactory) { Map<String, TypeDefinition> namedTypes = methodEnter.getNamedTypes(); for (ParameterDescription parameterDescription : this.adviceMethod.getParameters()) { AnnotationDescription.Loadable<Advice.Local> annotationDescription = parameterDescription.getDeclaredAnnotations().ofType(Advice.Local.class); if (annotationDescription != null) { String name = (String)annotationDescription.getValue(Advice.OffsetMapping.ForLocalValue.Factory.LOCAL_VALUE).resolve(String.class); TypeDefinition typeDefinition = namedTypes.get(name); if (typeDefinition == null) throw new IllegalStateException(this.adviceMethod + " attempts use of undeclared local variable " + name);  if (!typeDefinition.equals(parameterDescription.getType())) throw new IllegalStateException(this.adviceMethod + " does not read variable " + name + " as " + typeDefinition);  }  }  Advice.Delegator delegator = this.delegatorFactory.make(this.adviceMethod, true); return Resolved.ForMethodExit.of(this.adviceMethod, postProcessorFactory.make((List<? extends AnnotationDescription>)this.adviceMethod.getDeclaredAnnotations(), delegator.getTypeToken().getReturnType(), true), delegator, namedTypes, userFactories, methodEnter.getAdviceType()); } public String toString() { return "Delegate to " + this.adviceMethod; } public boolean equals(@MaybeNull Object param1Object) { return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.adviceMethod.equals(((Delegating)param1Object).adviceMethod) ? false : (!!this.delegatorFactory.equals(((Delegating)param1Object).delegatorFactory))))); } public int hashCode() { return (getClass().hashCode() * 31 + this.adviceMethod.hashCode()) * 31 + this.delegatorFactory.hashCode(); } protected static abstract class Resolved extends Advice.Dispatcher.Resolved.AbstractBase { protected final Advice.Delegator delegator; protected Resolved(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> factories, TypeDescription throwableType, TypeDescription relocatableType, int relocatableIndex, Advice.Delegator delegator) { super(adviceMethod, postProcessor, factories, throwableType, relocatableType, relocatableIndex, Advice.OffsetMapping.Factory.AdviceType.DELEGATION); this.delegator = delegator; } public Map<String, TypeDefinition> getNamedTypes() { return Collections.emptyMap(); } public Advice.Dispatcher.Bound bind(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) { this.delegator.assertVisibility(instrumentedType); return resolve(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, exceptionHandler, relocation); } protected abstract Advice.Dispatcher.Bound resolve(TypeDescription param3TypeDescription, MethodDescription param3MethodDescription, MethodVisitor param3MethodVisitor, Implementation.Context param3Context, Assigner param3Assigner, Advice.ArgumentHandler.ForInstrumentedMethod param3ForInstrumentedMethod, Advice.MethodSizeHandler.ForInstrumentedMethod param3ForInstrumentedMethod1, Advice.StackMapFrameHandler.ForInstrumentedMethod param3ForInstrumentedMethod2, StackManipulation param3StackManipulation, Advice.Dispatcher.RelocationHandler.Relocation param3Relocation); protected static abstract class AdviceMethodWriter implements Advice.Dispatcher.Bound { protected final MethodDescription.TypeToken typeToken; private final TypeDescription instrumentedType; private final MethodDescription instrumentedMethod; private final Assigner assigner; private final List<Advice.OffsetMapping.Target> offsetMappings; protected final MethodVisitor methodVisitor; protected final Implementation.Context implementationContext; protected final Advice.ArgumentHandler.ForAdvice argumentHandler; protected final Advice.MethodSizeHandler.ForAdvice methodSizeHandler; protected final Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler; private final Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler; private final Advice.Dispatcher.RelocationHandler.Bound relocationHandler; private final StackManipulation exceptionHandler; private final Advice.PostProcessor postProcessor; private final Advice.Delegator delegator; protected AdviceMethodWriter(MethodDescription.TypeToken typeToken, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.PostProcessor postProcessor, List<Advice.OffsetMapping.Target> offsetMappings, MethodVisitor methodVisitor, Implementation.Context implementationContext, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler, Advice.Delegator delegator) { this.typeToken = typeToken; this.instrumentedType = instrumentedType; this.instrumentedMethod = instrumentedMethod; this.assigner = assigner; this.postProcessor = postProcessor; this.offsetMappings = offsetMappings; this.methodVisitor = methodVisitor; this.implementationContext = implementationContext; this.argumentHandler = argumentHandler; this.methodSizeHandler = methodSizeHandler; this.stackMapFrameHandler = stackMapFrameHandler; this.suppressionHandler = suppressionHandler; this.relocationHandler = relocationHandler; this.exceptionHandler = exceptionHandler; this.delegator = delegator; } public void prepare() { this.suppressionHandler.onPrepare(this.methodVisitor); } public void apply() { this.suppressionHandler.onStart(this.methodVisitor); int index = 0, currentStackSize = 0, maximumStackSize = 0; for (Advice.OffsetMapping.Target offsetMapping : this.offsetMappings) { currentStackSize += ((TypeDescription)this.typeToken.getParameterTypes().get(index++)).getStackSize().getSize(); maximumStackSize = Math.max(maximumStackSize, currentStackSize + offsetMapping.resolveRead().apply(this.methodVisitor, this.implementationContext).getMaximalSize()); }  maximumStackSize = Math.max(maximumStackSize, this.delegator.apply(this.instrumentedType, this.instrumentedMethod).apply(this.methodVisitor, this.implementationContext).getMaximalSize()); this.suppressionHandler.onEndWithSkip(this.methodVisitor, this.implementationContext, this.methodSizeHandler, this.stackMapFrameHandler, (TypeDefinition)this.typeToken.getReturnType()); if (this.typeToken.getReturnType().represents(boolean.class) || this.typeToken.getReturnType().represents(byte.class) || this.typeToken.getReturnType().represents(short.class) || this.typeToken.getReturnType().represents(char.class) || this.typeToken.getReturnType().represents(int.class)) { this.methodVisitor.visitVarInsn(54, isExitAdvice() ? this.argumentHandler.exit() : this.argumentHandler.enter()); } else if (this.typeToken.getReturnType().represents(long.class)) { this.methodVisitor.visitVarInsn(55, isExitAdvice() ? this.argumentHandler.exit() : this.argumentHandler.enter()); } else if (this.typeToken.getReturnType().represents(float.class)) { this.methodVisitor.visitVarInsn(56, isExitAdvice() ? this.argumentHandler.exit() : this.argumentHandler.enter()); } else if (this.typeToken.getReturnType().represents(double.class)) { this.methodVisitor.visitVarInsn(57, isExitAdvice() ? this.argumentHandler.exit() : this.argumentHandler.enter()); } else if (this.typeToken.getReturnType().represents(void.class)) { this.methodVisitor.visitInsn(0); } else { this.methodVisitor.visitVarInsn(58, isExitAdvice() ? this.argumentHandler.exit() : this.argumentHandler.enter()); }  this.methodSizeHandler.requireStackSize(this.postProcessor.resolve(this.instrumentedType, this.instrumentedMethod, this.assigner, this.argumentHandler, this.stackMapFrameHandler, this.exceptionHandler).apply(this.methodVisitor, this.implementationContext).getMaximalSize()); this.methodSizeHandler.requireStackSize(this.relocationHandler.apply(this.methodVisitor, this.implementationContext, isExitAdvice() ? this.argumentHandler.exit() : this.argumentHandler.enter())); this.stackMapFrameHandler.injectCompletionFrame(this.methodVisitor); this.methodSizeHandler.requireStackSize(Math.max(maximumStackSize, this.typeToken.getReturnType().getStackSize().getSize())); this.methodSizeHandler.requireLocalVariableLength(this.instrumentedMethod.getStackSize() + this.typeToken.getReturnType().getStackSize().getSize()); } protected abstract boolean isExitAdvice(); protected static class ForMethodEnter extends AdviceMethodWriter { protected ForMethodEnter(MethodDescription.TypeToken typeToken, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.PostProcessor postProcessor, List<Advice.OffsetMapping.Target> offsetMappings, MethodVisitor methodVisitor, Implementation.Context implementationContext, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler, Advice.Delegator delegator) { super(typeToken, instrumentedType, instrumentedMethod, assigner, postProcessor, offsetMappings, methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, suppressionHandler, relocationHandler, exceptionHandler, delegator); } public void initialize() {} protected boolean isExitAdvice() { return false; } } protected static class ForMethodExit extends AdviceMethodWriter { protected ForMethodExit(MethodDescription.TypeToken typeToken, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.PostProcessor postProcessor, List<Advice.OffsetMapping.Target> offsetMappings, MethodVisitor methodVisitor, Implementation.Context implementationContext, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler, Advice.Delegator delegator) { super(typeToken, instrumentedType, instrumentedMethod, assigner, postProcessor, offsetMappings, methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, suppressionHandler, relocationHandler, exceptionHandler, delegator); } public void initialize() { if (this.typeToken.getReturnType().represents(boolean.class) || this.typeToken.getReturnType().represents(byte.class) || this.typeToken.getReturnType().represents(short.class) || this.typeToken.getReturnType().represents(char.class) || this.typeToken.getReturnType().represents(int.class)) { this.methodVisitor.visitInsn(3); this.methodVisitor.visitVarInsn(54, this.argumentHandler.exit()); } else if (this.typeToken.getReturnType().represents(long.class)) { this.methodVisitor.visitInsn(9); this.methodVisitor.visitVarInsn(55, this.argumentHandler.exit()); } else if (this.typeToken.getReturnType().represents(float.class)) { this.methodVisitor.visitInsn(11); this.methodVisitor.visitVarInsn(56, this.argumentHandler.exit()); } else if (this.typeToken.getReturnType().represents(double.class)) { this.methodVisitor.visitInsn(14); this.methodVisitor.visitVarInsn(57, this.argumentHandler.exit()); } else if (!this.typeToken.getReturnType().represents(void.class)) { this.methodVisitor.visitInsn(1); this.methodVisitor.visitVarInsn(58, this.argumentHandler.exit()); }  this.methodSizeHandler.requireStackSize(this.typeToken.getReturnType().getStackSize().getSize()); } protected boolean isExitAdvice() { return true; } } } @Enhance protected static abstract class ForMethodEnter extends Resolved implements Advice.Dispatcher.Resolved.ForMethodEnter { private final boolean prependLineNumber; @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected ForMethodEnter(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, Advice.Delegator delegator) { super(adviceMethod, postProcessor, CompoundList.of(Arrays.asList(new Advice.OffsetMapping.Factory[] { Advice.OffsetMapping.ForArgument.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForAllArguments.Factory.INSTANCE, Advice.OffsetMapping.ForThisReference.Factory.INSTANCE, Advice.OffsetMapping.ForField.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.ReaderFactory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.WriterFactory.INSTANCE, Advice.OffsetMapping.ForOrigin.Factory.INSTANCE, Advice.OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, Advice.OffsetMapping.ForHandle.Factory.INSTANCE, Advice.OffsetMapping.ForDynamicConstant.Factory.INSTANCE, Advice.OffsetMapping.ForUnusedValue.Factory.INSTANCE, Advice.OffsetMapping.ForStubValue.INSTANCE, Advice.OffsetMapping.ForExitValue.Factory.of(exitType), new Advice.OffsetMapping.Factory.Illegal<Advice.Thrown>(Advice.Thrown.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Enter>(Advice.Enter.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Local>(Advice.Local.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Return>(Advice.Return.class) }, ), userFactories), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SUPPRESS_ENTER).resolve(TypeDescription.class), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SKIP_ON).resolve(TypeDescription.class), ((Integer)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SKIP_ON_INDEX).resolve(Integer.class)).intValue(), delegator); this.prependLineNumber = ((Boolean)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.PREPEND_LINE_NUMBER).resolve(Boolean.class)).booleanValue(); } protected static Advice.Dispatcher.Resolved.ForMethodEnter of(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Advice.Delegator delegator, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, boolean methodExit) { return methodExit ? new WithRetainedEnterType(adviceMethod, postProcessor, userFactories, exitType, delegator) : new WithDiscardedEnterType(adviceMethod, postProcessor, userFactories, exitType, delegator); } public boolean isPrependLineNumber() { return this.prependLineNumber; } public TypeDefinition getActualAdviceType() { return (TypeDefinition)this.delegator.getTypeToken().getReturnType(); } protected Advice.Dispatcher.Bound resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) { return doResolve(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler.bindEnter(this.delegator.getTypeToken()), methodSizeHandler.bindEnter(this.delegator.getTypeToken()), stackMapFrameHandler.bindEnter(this.delegator.getTypeToken()), this.suppressionHandler.bind(exceptionHandler), this.relocationHandler.bind(instrumentedMethod, relocation), exceptionHandler); } protected Advice.Dispatcher.Bound doResolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { List<Advice.OffsetMapping.Target> offsetMappings = new ArrayList<Advice.OffsetMapping.Target>(this.offsetMappings.size()); for (Advice.OffsetMapping offsetMapping : this.offsetMappings.values()) offsetMappings.add(offsetMapping.resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, Advice.OffsetMapping.Sort.ENTER));  return new Advice.Dispatcher.Delegating.Resolved.AdviceMethodWriter.ForMethodEnter(this.delegator.getTypeToken(), instrumentedType, instrumentedMethod, assigner, this.postProcessor, offsetMappings, methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, suppressionHandler, relocationHandler, exceptionHandler, this.delegator); } public boolean equals(@MaybeNull Object param4Object) { return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!(this.prependLineNumber != ((ForMethodEnter)param4Object).prependLineNumber))))); } public int hashCode() { return super.hashCode() * 31 + this.prependLineNumber; } protected static class WithRetainedEnterType extends ForMethodEnter { protected WithRetainedEnterType(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, Advice.Delegator delegator) { super(adviceMethod, postProcessor, userFactories, exitType, delegator); } public TypeDefinition getAdviceType() { return (TypeDefinition)this.delegator.getTypeToken().getReturnType(); } } protected static class WithDiscardedEnterType extends ForMethodEnter { protected WithDiscardedEnterType(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, Advice.Delegator delegator) { super(adviceMethod, postProcessor, userFactories, exitType, delegator); } public TypeDefinition getAdviceType() { return (TypeDefinition)TypeDescription.ForLoadedType.of(void.class); } protected Advice.Dispatcher.Bound doResolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { methodSizeHandler.requireLocalVariableLengthPadding(this.delegator.getTypeToken().getReturnType().getStackSize().getSize()); return super.doResolve(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, suppressionHandler, relocationHandler, exceptionHandler); } } } @Enhance protected static abstract class ForMethodExit extends Resolved implements Advice.Dispatcher.Resolved.ForMethodExit { private final boolean backupArguments; @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected ForMethodExit(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition enterType, Advice.Delegator delegator) { super(adviceMethod, postProcessor, CompoundList.of(Arrays.asList(new Advice.OffsetMapping.Factory[] { Advice.OffsetMapping.ForArgument.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForAllArguments.Factory.INSTANCE, Advice.OffsetMapping.ForThisReference.Factory.INSTANCE, Advice.OffsetMapping.ForField.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.ReaderFactory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.WriterFactory.INSTANCE, Advice.OffsetMapping.ForOrigin.Factory.INSTANCE, Advice.OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, Advice.OffsetMapping.ForHandle.Factory.INSTANCE, Advice.OffsetMapping.ForDynamicConstant.Factory.INSTANCE, Advice.OffsetMapping.ForUnusedValue.Factory.INSTANCE, Advice.OffsetMapping.ForStubValue.INSTANCE, Advice.OffsetMapping.ForEnterValue.Factory.of(enterType), Advice.OffsetMapping.ForExitValue.Factory.of((TypeDefinition)adviceMethod.getReturnType()), new Advice.OffsetMapping.ForLocalValue.Factory(namedTypes), Advice.OffsetMapping.ForReturnValue.Factory.INSTANCE, Advice.OffsetMapping.ForThrowable.Factory.of(adviceMethod) }, ), userFactories), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.SUPPRESS_EXIT).resolve(TypeDescription.class), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.REPEAT_ON).resolve(TypeDescription.class), ((Integer)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.REPEAT_ON_INDEX).resolve(Integer.class)).intValue(), delegator); this.backupArguments = ((Boolean)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.BACKUP_ARGUMENTS).resolve(Boolean.class)).booleanValue(); } @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected static Advice.Dispatcher.Resolved.ForMethodExit of(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Advice.Delegator delegator, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition enterType) { TypeDescription throwable = (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.ON_THROWABLE).resolve(TypeDescription.class); return throwable.represents(Advice.NoExceptionHandler.class) ? new WithoutExceptionHandler(adviceMethod, postProcessor, namedTypes, userFactories, enterType, delegator) : new WithExceptionHandler(adviceMethod, postProcessor, namedTypes, userFactories, enterType, throwable, delegator); } protected Advice.Dispatcher.Bound resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) { return doResolve(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler.bindExit(this.delegator.getTypeToken(), getThrowable().represents(Advice.NoExceptionHandler.class)), methodSizeHandler.bindExit(this.delegator.getTypeToken()), stackMapFrameHandler.bindExit(this.delegator.getTypeToken()), this.suppressionHandler.bind(exceptionHandler), this.relocationHandler.bind(instrumentedMethod, relocation), exceptionHandler); } private Advice.Dispatcher.Bound doResolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { List<Advice.OffsetMapping.Target> offsetMappings = new ArrayList<Advice.OffsetMapping.Target>(this.offsetMappings.size()); for (Advice.OffsetMapping offsetMapping : this.offsetMappings.values()) offsetMappings.add(offsetMapping.resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, Advice.OffsetMapping.Sort.EXIT));  return new Advice.Dispatcher.Delegating.Resolved.AdviceMethodWriter.ForMethodExit(this.delegator.getTypeToken(), instrumentedType, instrumentedMethod, assigner, this.postProcessor, offsetMappings, methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, suppressionHandler, relocationHandler, exceptionHandler, this.delegator); } public Advice.ArgumentHandler.Factory getArgumentHandlerFactory() { return this.backupArguments ? Advice.ArgumentHandler.Factory.COPYING : Advice.ArgumentHandler.Factory.SIMPLE; } public TypeDefinition getAdviceType() { return (TypeDefinition)this.delegator.getTypeToken().getReturnType(); } public boolean equals(@MaybeNull Object param4Object) { return !super.equals(param4Object) ? false : ((this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!(this.backupArguments != ((ForMethodExit)param4Object).backupArguments))))); } public int hashCode() { return super.hashCode() * 31 + this.backupArguments; } @Enhance protected static class WithExceptionHandler extends ForMethodExit { private final TypeDescription throwable; protected WithExceptionHandler(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition enterType, TypeDescription throwable, Advice.Delegator delegator) { super(adviceMethod, postProcessor, namedTypes, userFactories, enterType, delegator); this.throwable = throwable; } public TypeDescription getThrowable() { return this.throwable; } public boolean equals(@MaybeNull Object param5Object) { return !super.equals(param5Object) ? false : ((this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.throwable.equals(((WithExceptionHandler)param5Object).throwable))))); } public int hashCode() { return super.hashCode() * 31 + this.throwable.hashCode(); } } protected static class WithoutExceptionHandler extends ForMethodExit { public TypeDescription getThrowable() { return Advice.NoExceptionHandler.DESCRIPTION; } protected WithoutExceptionHandler(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition enterType, Advice.Delegator delegator) { super(adviceMethod, postProcessor, namedTypes, userFactories, enterType, delegator); } } } } @Enhance protected static abstract class ForMethodEnter extends Resolved implements Advice.Dispatcher.Resolved.ForMethodEnter { private final boolean prependLineNumber; @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected ForMethodEnter(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, Advice.Delegator delegator) { super(adviceMethod, postProcessor, CompoundList.of(Arrays.asList(new Advice.OffsetMapping.Factory[] { Advice.OffsetMapping.ForArgument.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForAllArguments.Factory.INSTANCE, Advice.OffsetMapping.ForThisReference.Factory.INSTANCE, Advice.OffsetMapping.ForField.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.ReaderFactory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.WriterFactory.INSTANCE, Advice.OffsetMapping.ForOrigin.Factory.INSTANCE, Advice.OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, Advice.OffsetMapping.ForHandle.Factory.INSTANCE, Advice.OffsetMapping.ForDynamicConstant.Factory.INSTANCE, Advice.OffsetMapping.ForUnusedValue.Factory.INSTANCE, Advice.OffsetMapping.ForStubValue.INSTANCE, Advice.OffsetMapping.ForExitValue.Factory.of(exitType), new Advice.OffsetMapping.Factory.Illegal<Advice.Thrown>(Advice.Thrown.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Enter>(Advice.Enter.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Local>(Advice.Local.class), new Advice.OffsetMapping.Factory.Illegal<Advice.Return>(Advice.Return.class) }, ), userFactories), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SUPPRESS_ENTER).resolve(TypeDescription.class), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SKIP_ON).resolve(TypeDescription.class), ((Integer)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.SKIP_ON_INDEX).resolve(Integer.class)).intValue(), delegator); this.prependLineNumber = ((Boolean)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodEnter.class).getValue(Advice.PREPEND_LINE_NUMBER).resolve(Boolean.class)).booleanValue(); } protected static Advice.Dispatcher.Resolved.ForMethodEnter of(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Advice.Delegator delegator, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, boolean methodExit) { return methodExit ? new WithRetainedEnterType(adviceMethod, postProcessor, userFactories, exitType, delegator) : new WithDiscardedEnterType(adviceMethod, postProcessor, userFactories, exitType, delegator); } public boolean isPrependLineNumber() { return this.prependLineNumber; } public TypeDefinition getActualAdviceType() { return (TypeDefinition)this.delegator.getTypeToken().getReturnType(); } protected Advice.Dispatcher.Bound resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) { return doResolve(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler.bindEnter(this.delegator.getTypeToken()), methodSizeHandler.bindEnter(this.delegator.getTypeToken()), stackMapFrameHandler.bindEnter(this.delegator.getTypeToken()), this.suppressionHandler.bind(exceptionHandler), this.relocationHandler.bind(instrumentedMethod, relocation), exceptionHandler); } protected Advice.Dispatcher.Bound doResolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { List<Advice.OffsetMapping.Target> offsetMappings = new ArrayList<Advice.OffsetMapping.Target>(this.offsetMappings.size()); for (Advice.OffsetMapping offsetMapping : this.offsetMappings.values()) offsetMappings.add(offsetMapping.resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, Advice.OffsetMapping.Sort.ENTER));  return new Advice.Dispatcher.Delegating.Resolved.AdviceMethodWriter.ForMethodEnter(this.delegator.getTypeToken(), instrumentedType, instrumentedMethod, assigner, this.postProcessor, offsetMappings, methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, suppressionHandler, relocationHandler, exceptionHandler, this.delegator); } public boolean equals(@MaybeNull Object param3Object) { return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!(this.prependLineNumber != ((ForMethodEnter)param3Object).prependLineNumber))))); } public int hashCode() { return super.hashCode() * 31 + this.prependLineNumber; } protected static class WithRetainedEnterType extends ForMethodEnter { protected WithRetainedEnterType(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, Advice.Delegator delegator) { super(adviceMethod, postProcessor, userFactories, exitType, delegator); } public TypeDefinition getAdviceType() { return (TypeDefinition)this.delegator.getTypeToken().getReturnType(); } } protected static class WithDiscardedEnterType extends ForMethodEnter { protected WithDiscardedEnterType(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition exitType, Advice.Delegator delegator) { super(adviceMethod, postProcessor, userFactories, exitType, delegator); } public TypeDefinition getAdviceType() { return (TypeDefinition)TypeDescription.ForLoadedType.of(void.class); } protected Advice.Dispatcher.Bound doResolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { methodSizeHandler.requireLocalVariableLengthPadding(this.delegator.getTypeToken().getReturnType().getStackSize().getSize()); return super.doResolve(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler, methodSizeHandler, stackMapFrameHandler, suppressionHandler, relocationHandler, exceptionHandler); } } } @Enhance protected static abstract class ForMethodExit extends Resolved implements Advice.Dispatcher.Resolved.ForMethodExit { private final boolean backupArguments; @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected ForMethodExit(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition enterType, Advice.Delegator delegator) { super(adviceMethod, postProcessor, CompoundList.of(Arrays.asList(new Advice.OffsetMapping.Factory[] { Advice.OffsetMapping.ForArgument.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForAllArguments.Factory.INSTANCE, Advice.OffsetMapping.ForThisReference.Factory.INSTANCE, Advice.OffsetMapping.ForField.Unresolved.Factory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.ReaderFactory.INSTANCE, Advice.OffsetMapping.ForFieldHandle.Unresolved.WriterFactory.INSTANCE, Advice.OffsetMapping.ForOrigin.Factory.INSTANCE, Advice.OffsetMapping.ForSelfCallHandle.Factory.INSTANCE, Advice.OffsetMapping.ForHandle.Factory.INSTANCE, Advice.OffsetMapping.ForDynamicConstant.Factory.INSTANCE, Advice.OffsetMapping.ForUnusedValue.Factory.INSTANCE, Advice.OffsetMapping.ForStubValue.INSTANCE, Advice.OffsetMapping.ForEnterValue.Factory.of(enterType), Advice.OffsetMapping.ForExitValue.Factory.of((TypeDefinition)adviceMethod.getReturnType()), new Advice.OffsetMapping.ForLocalValue.Factory(namedTypes), Advice.OffsetMapping.ForReturnValue.Factory.INSTANCE, Advice.OffsetMapping.ForThrowable.Factory.of(adviceMethod) }, ), userFactories), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.SUPPRESS_EXIT).resolve(TypeDescription.class), (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.REPEAT_ON).resolve(TypeDescription.class), ((Integer)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.REPEAT_ON_INDEX).resolve(Integer.class)).intValue(), delegator); this.backupArguments = ((Boolean)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.BACKUP_ARGUMENTS).resolve(Boolean.class)).booleanValue(); } @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.") protected static Advice.Dispatcher.Resolved.ForMethodExit of(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Advice.Delegator delegator, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition enterType) { TypeDescription throwable = (TypeDescription)adviceMethod.getDeclaredAnnotations().ofType(Advice.OnMethodExit.class).getValue(Advice.ON_THROWABLE).resolve(TypeDescription.class); return throwable.represents(Advice.NoExceptionHandler.class) ? new WithoutExceptionHandler(adviceMethod, postProcessor, namedTypes, userFactories, enterType, delegator) : new WithExceptionHandler(adviceMethod, postProcessor, namedTypes, userFactories, enterType, throwable, delegator); } protected Advice.Dispatcher.Bound resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler, Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler, Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler, StackManipulation exceptionHandler, Advice.Dispatcher.RelocationHandler.Relocation relocation) { return doResolve(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, argumentHandler.bindExit(this.delegator.getTypeToken(), getThrowable().represents(Advice.NoExceptionHandler.class)), methodSizeHandler.bindExit(this.delegator.getTypeToken()), stackMapFrameHandler.bindExit(this.delegator.getTypeToken()), this.suppressionHandler.bind(exceptionHandler), this.relocationHandler.bind(instrumentedMethod, relocation), exceptionHandler); } private Advice.Dispatcher.Bound doResolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, Advice.ArgumentHandler.ForAdvice argumentHandler, Advice.MethodSizeHandler.ForAdvice methodSizeHandler, Advice.StackMapFrameHandler.ForAdvice stackMapFrameHandler, Advice.Dispatcher.SuppressionHandler.Bound suppressionHandler, Advice.Dispatcher.RelocationHandler.Bound relocationHandler, StackManipulation exceptionHandler) { List<Advice.OffsetMapping.Target> offsetMappings = new ArrayList<Advice.OffsetMapping.Target>(this.offsetMappings.size()); for (Advice.OffsetMapping offsetMapping : this.offsetMappings.values()) offsetMappings.add(offsetMapping.resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, Advice.OffsetMapping.Sort.EXIT));  return new Advice.Dispatcher.Delegating.Resolved.AdviceMethodWriter.ForMethodExit(this.delegator.getTypeToken(), instrumentedType, instrumentedMethod, assigner, this.postProcessor, offsetMappings, methodVisitor, implementationContext, argumentHandler, methodSizeHandler, stackMapFrameHandler, suppressionHandler, relocationHandler, exceptionHandler, this.delegator); } public Advice.ArgumentHandler.Factory getArgumentHandlerFactory() { return this.backupArguments ? Advice.ArgumentHandler.Factory.COPYING : Advice.ArgumentHandler.Factory.SIMPLE; } public TypeDefinition getAdviceType() { return (TypeDefinition)this.delegator.getTypeToken().getReturnType(); } public boolean equals(@MaybeNull Object param3Object) { return !super.equals(param3Object) ? false : ((this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : (!(this.backupArguments != ((ForMethodExit)param3Object).backupArguments))))); } public int hashCode() { return super.hashCode() * 31 + this.backupArguments; } @Enhance protected static class WithExceptionHandler extends ForMethodExit { private final TypeDescription throwable; protected WithExceptionHandler(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition enterType, TypeDescription throwable, Advice.Delegator delegator) { super(adviceMethod, postProcessor, namedTypes, userFactories, enterType, delegator); this.throwable = throwable; } public TypeDescription getThrowable() { return this.throwable; } public boolean equals(@MaybeNull Object param5Object) { return !super.equals(param5Object) ? false : ((this == param5Object) ? true : ((param5Object == null) ? false : ((getClass() != param5Object.getClass()) ? false : (!!this.throwable.equals(((WithExceptionHandler)param5Object).throwable))))); } public int hashCode() { return super.hashCode() * 31 + this.throwable.hashCode(); } } protected static class WithoutExceptionHandler extends ForMethodExit { protected WithoutExceptionHandler(MethodDescription.InDefinedShape adviceMethod, Advice.PostProcessor postProcessor, Map<String, TypeDefinition> namedTypes, List<? extends Advice.OffsetMapping.Factory<?>> userFactories, TypeDefinition enterType, Advice.Delegator delegator) { super(adviceMethod, postProcessor, namedTypes, userFactories, enterType, delegator); } public TypeDescription getThrowable() { return Advice.NoExceptionHandler.DESCRIPTION; }
/*       */          }
/*       */        }
/*       */      }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected static abstract class AdviceVisitor
/*       */     extends ExceptionTableSensitiveMethodVisitor
/*       */     implements Dispatcher.RelocationHandler.Relocation
/*       */   {
/*       */     private static final int THIS_VARIABLE_INDEX = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     private static final String THIS_VARIABLE_NAME = "this";
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected final MethodDescription instrumentedMethod;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     private final Label preparationStart;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     private final Advice.Dispatcher.Bound methodEnter;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected final Advice.Dispatcher.Bound methodExit;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected final Advice.ArgumentHandler.ForInstrumentedMethod argumentHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected final Advice.MethodSizeHandler.ForInstrumentedMethod methodSizeHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected final Advice.StackMapFrameHandler.ForInstrumentedMethod stackMapFrameHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @SuppressFBWarnings(value = {"MC_OVERRIDABLE_METHOD_CALL_IN_CONSTRUCTOR"}, justification = "Self reference is not used before constructor completion.")
/*       */     protected AdviceVisitor(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, StackManipulation exceptionHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.Resolved.ForMethodEnter methodEnter, Advice.Dispatcher.Resolved.ForMethodExit methodExit, List<? extends TypeDescription> postMethodTypes, int writerFlags, int readerFlags) {
/* 11853 */       super(OpenedClassReader.ASM_API, methodVisitor);
/* 11854 */       this.instrumentedMethod = instrumentedMethod;
/* 11855 */       this.preparationStart = new Label();
/* 11856 */       SortedMap<String, TypeDefinition> namedTypes = new TreeMap<String, TypeDefinition>();
/* 11857 */       namedTypes.putAll(methodEnter.getNamedTypes());
/* 11858 */       namedTypes.putAll(methodExit.getNamedTypes());
/* 11859 */       this.argumentHandler = methodExit.getArgumentHandlerFactory().resolve(instrumentedMethod, methodEnter
/* 11860 */           .getAdviceType(), methodExit
/* 11861 */           .getAdviceType(), namedTypes);
/*       */       
/* 11863 */       List<TypeDescription> initialTypes = CompoundList.of(methodExit.getAdviceType().represents(void.class) ? 
/* 11864 */           Collections.emptyList() : 
/* 11865 */           Collections.<TypeDescription>singletonList(methodExit.getAdviceType().asErasure()), this.argumentHandler.getNamedTypes());
/*       */ 
/*       */       
/* 11868 */       List<TypeDescription> latentTypes = methodEnter.getActualAdviceType().represents(void.class) ? Collections.<TypeDescription>emptyList() : Collections.<TypeDescription>singletonList(methodEnter.getActualAdviceType().asErasure());
/*       */ 
/*       */       
/* 11871 */       List<TypeDescription> preMethodTypes = methodEnter.getAdviceType().represents(void.class) ? Collections.<TypeDescription>emptyList() : Collections.<TypeDescription>singletonList(methodEnter.getAdviceType().asErasure());
/* 11872 */       this.methodSizeHandler = Advice.MethodSizeHandler.Default.of(instrumentedMethod, initialTypes, preMethodTypes, postMethodTypes, this.argumentHandler
/*       */ 
/*       */ 
/*       */           
/* 11876 */           .isCopyingArguments(), writerFlags);
/*       */       
/* 11878 */       this.stackMapFrameHandler = Advice.StackMapFrameHandler.Default.of(instrumentedType, instrumentedMethod, initialTypes, latentTypes, preMethodTypes, postMethodTypes, methodExit
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 11884 */           .isAlive(), this.argumentHandler
/* 11885 */           .isCopyingArguments(), implementationContext
/* 11886 */           .getClassFileVersion(), writerFlags, readerFlags);
/*       */ 
/*       */       
/* 11889 */       this.methodEnter = methodEnter.bind(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, this.argumentHandler, this.methodSizeHandler, this.stackMapFrameHandler, exceptionHandler, this);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 11899 */       this.methodExit = methodExit.bind(instrumentedType, instrumentedMethod, methodVisitor, implementationContext, assigner, this.argumentHandler, this.methodSizeHandler, this.stackMapFrameHandler, exceptionHandler, new Advice.Dispatcher.RelocationHandler.Relocation.ForLabel(this.preparationStart));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected void onAfterExceptionTable() {
/* 11913 */       this.methodEnter.prepare();
/* 11914 */       onUserPrepare();
/* 11915 */       this.methodExit.prepare();
/* 11916 */       this.methodEnter.initialize();
/* 11917 */       this.methodExit.initialize();
/* 11918 */       this.stackMapFrameHandler.injectInitializationFrame(this.mv);
/* 11919 */       this.methodEnter.apply();
/* 11920 */       this.mv.visitLabel(this.preparationStart);
/* 11921 */       this.methodSizeHandler.requireStackSize(this.argumentHandler.prepare(this.mv));
/* 11922 */       this.stackMapFrameHandler.injectStartFrame(this.mv);
/* 11923 */       this.mv.visitInsn(0);
/* 11924 */       onUserStart();
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected abstract void onUserPrepare();
/*       */ 
/*       */ 
/*       */     
/*       */     protected abstract void onUserStart();
/*       */ 
/*       */ 
/*       */     
/*       */     protected void onVisitVarInsn(int opcode, int offset) {
/* 11939 */       this.mv.visitVarInsn(opcode, this.argumentHandler.argument(offset));
/*       */     }
/*       */ 
/*       */     
/*       */     protected void onVisitIincInsn(int offset, int increment) {
/* 11944 */       this.mv.visitIincInsn(this.argumentHandler.argument(offset), increment);
/*       */     }
/*       */ 
/*       */     
/*       */     public void onVisitFrame(int type, int localVariableLength, @MaybeNull Object[] localVariable, int stackSize, @MaybeNull Object[] stack) {
/* 11949 */       this.stackMapFrameHandler.translateFrame(this.mv, type, localVariableLength, localVariable, stackSize, stack);
/*       */     }
/*       */ 
/*       */     
/*       */     public void visitMaxs(int stackSize, int localVariableLength) {
/* 11954 */       onUserEnd();
/* 11955 */       this.mv.visitMaxs(this.methodSizeHandler.compoundStackSize(stackSize), this.methodSizeHandler.compoundLocalVariableLength(localVariableLength));
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     public void visitLocalVariable(String name, String descriptor, String signature, Label start, Label end, int offset) {
/* 11961 */       this.mv.visitLocalVariable(name, descriptor, signature, start, end, (offset == 0 && "this".equals(name)) ? offset : this.argumentHandler
/*       */           
/* 11963 */           .argument(offset));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public AnnotationVisitor visitLocalVariableAnnotation(int typeReference, TypePath typePath, Label[] start, Label[] end, int[] offset, String descriptor, boolean visible) {
/* 11974 */       int[] translated = new int[offset.length];
/* 11975 */       for (int index = 0; index < offset.length; index++) {
/* 11976 */         translated[index] = this.argumentHandler.argument(offset[index]);
/*       */       }
/* 11978 */       return this.mv.visitLocalVariableAnnotation(typeReference, typePath, start, end, translated, descriptor, visible);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected abstract void onUserEnd();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected static class WithoutExitAdvice
/*       */       extends AdviceVisitor
/*       */     {
/*       */       protected WithoutExitAdvice(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, StackManipulation exceptionHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.Resolved.ForMethodEnter methodEnter, int writerFlags, int readerFlags) {
/* 12013 */         super(methodVisitor, implementationContext, assigner, exceptionHandler, instrumentedType, instrumentedMethod, methodEnter, Advice.Dispatcher.Inactive.INSTANCE, 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/* 12021 */             Collections.emptyList(), writerFlags, readerFlags);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void apply(MethodVisitor methodVisitor) {
/* 12030 */         if (this.instrumentedMethod.getReturnType().represents(boolean.class) || this.instrumentedMethod
/* 12031 */           .getReturnType().represents(byte.class) || this.instrumentedMethod
/* 12032 */           .getReturnType().represents(short.class) || this.instrumentedMethod
/* 12033 */           .getReturnType().represents(char.class) || this.instrumentedMethod
/* 12034 */           .getReturnType().represents(int.class)) {
/* 12035 */           methodVisitor.visitInsn(3);
/* 12036 */           methodVisitor.visitInsn(172);
/* 12037 */         } else if (this.instrumentedMethod.getReturnType().represents(long.class)) {
/* 12038 */           methodVisitor.visitInsn(9);
/* 12039 */           methodVisitor.visitInsn(173);
/* 12040 */         } else if (this.instrumentedMethod.getReturnType().represents(float.class)) {
/* 12041 */           methodVisitor.visitInsn(11);
/* 12042 */           methodVisitor.visitInsn(174);
/* 12043 */         } else if (this.instrumentedMethod.getReturnType().represents(double.class)) {
/* 12044 */           methodVisitor.visitInsn(14);
/* 12045 */           methodVisitor.visitInsn(175);
/* 12046 */         } else if (this.instrumentedMethod.getReturnType().represents(void.class)) {
/* 12047 */           methodVisitor.visitInsn(177);
/*       */         } else {
/* 12049 */           methodVisitor.visitInsn(1);
/* 12050 */           methodVisitor.visitInsn(176);
/*       */         } 
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected void onUserPrepare() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected void onUserStart() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected void onUserEnd() {}
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected static abstract class WithExitAdvice
/*       */       extends AdviceVisitor
/*       */     {
/*       */       protected final Label returnHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected WithExitAdvice(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, StackManipulation exceptionHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.Resolved.ForMethodEnter methodEnter, Advice.Dispatcher.Resolved.ForMethodExit methodExit, List<? extends TypeDescription> postMethodTypes, int writerFlags, int readerFlags) {
/* 12106 */         super(StackAwareMethodVisitor.of(methodVisitor, instrumentedMethod), implementationContext, assigner, exceptionHandler, instrumentedType, instrumentedMethod, methodEnter, methodExit, postMethodTypes, writerFlags, readerFlags);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 12117 */         this.returnHandler = new Label();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void apply(MethodVisitor methodVisitor) {
/* 12124 */         if (this.instrumentedMethod.getReturnType().represents(boolean.class) || this.instrumentedMethod
/* 12125 */           .getReturnType().represents(byte.class) || this.instrumentedMethod
/* 12126 */           .getReturnType().represents(short.class) || this.instrumentedMethod
/* 12127 */           .getReturnType().represents(char.class) || this.instrumentedMethod
/* 12128 */           .getReturnType().represents(int.class)) {
/* 12129 */           methodVisitor.visitInsn(3);
/* 12130 */         } else if (this.instrumentedMethod.getReturnType().represents(long.class)) {
/* 12131 */           methodVisitor.visitInsn(9);
/* 12132 */         } else if (this.instrumentedMethod.getReturnType().represents(float.class)) {
/* 12133 */           methodVisitor.visitInsn(11);
/* 12134 */         } else if (this.instrumentedMethod.getReturnType().represents(double.class)) {
/* 12135 */           methodVisitor.visitInsn(14);
/* 12136 */         } else if (!this.instrumentedMethod.getReturnType().represents(void.class)) {
/* 12137 */           methodVisitor.visitInsn(1);
/*       */         } 
/* 12139 */         methodVisitor.visitJumpInsn(167, this.returnHandler);
/*       */       }
/*       */ 
/*       */       
/*       */       protected void onVisitInsn(int opcode) {
/* 12144 */         switch (opcode) {
/*       */           case 177:
/* 12146 */             ((StackAwareMethodVisitor)this.mv).drainStack();
/*       */             break;
/*       */           case 172:
/* 12149 */             this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(54, 21, StackSize.SINGLE));
/*       */             break;
/*       */           case 174:
/* 12152 */             this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(56, 23, StackSize.SINGLE));
/*       */             break;
/*       */           case 175:
/* 12155 */             this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(57, 24, StackSize.DOUBLE));
/*       */             break;
/*       */           case 173:
/* 12158 */             this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(55, 22, StackSize.DOUBLE));
/*       */             break;
/*       */           case 176:
/* 12161 */             this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(58, 25, StackSize.SINGLE));
/*       */             break;
/*       */           default:
/* 12164 */             this.mv.visitInsn(opcode);
/*       */             return;
/*       */         } 
/* 12167 */         this.mv.visitJumpInsn(167, this.returnHandler);
/*       */       }
/*       */ 
/*       */       
/*       */       protected void onUserEnd() {
/* 12172 */         this.mv.visitLabel(this.returnHandler);
/* 12173 */         onUserReturn();
/* 12174 */         this.stackMapFrameHandler.injectCompletionFrame(this.mv);
/* 12175 */         this.methodExit.apply();
/* 12176 */         onExitAdviceReturn();
/* 12177 */         if (this.instrumentedMethod.getReturnType().represents(boolean.class) || this.instrumentedMethod
/* 12178 */           .getReturnType().represents(byte.class) || this.instrumentedMethod
/* 12179 */           .getReturnType().represents(short.class) || this.instrumentedMethod
/* 12180 */           .getReturnType().represents(char.class) || this.instrumentedMethod
/* 12181 */           .getReturnType().represents(int.class)) {
/* 12182 */           this.mv.visitVarInsn(21, this.argumentHandler.returned());
/* 12183 */           this.mv.visitInsn(172);
/* 12184 */         } else if (this.instrumentedMethod.getReturnType().represents(long.class)) {
/* 12185 */           this.mv.visitVarInsn(22, this.argumentHandler.returned());
/* 12186 */           this.mv.visitInsn(173);
/* 12187 */         } else if (this.instrumentedMethod.getReturnType().represents(float.class)) {
/* 12188 */           this.mv.visitVarInsn(23, this.argumentHandler.returned());
/* 12189 */           this.mv.visitInsn(174);
/* 12190 */         } else if (this.instrumentedMethod.getReturnType().represents(double.class)) {
/* 12191 */           this.mv.visitVarInsn(24, this.argumentHandler.returned());
/* 12192 */           this.mv.visitInsn(175);
/* 12193 */         } else if (!this.instrumentedMethod.getReturnType().represents(void.class)) {
/* 12194 */           this.mv.visitVarInsn(25, this.argumentHandler.returned());
/* 12195 */           this.mv.visitInsn(176);
/*       */         } else {
/* 12197 */           this.mv.visitInsn(177);
/*       */         } 
/* 12199 */         this.methodSizeHandler.requireStackSize(this.instrumentedMethod.getReturnType().getStackSize().getSize());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract void onUserReturn();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected abstract void onExitAdviceReturn();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static class WithoutExceptionHandling
/*       */         extends WithExitAdvice
/*       */       {
/*       */         protected WithoutExceptionHandling(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, StackManipulation exceptionHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.Resolved.ForMethodEnter methodEnter, Advice.Dispatcher.Resolved.ForMethodExit methodExit, int writerFlags, int readerFlags) {
/* 12241 */           super(methodVisitor, implementationContext, assigner, exceptionHandler, instrumentedType, instrumentedMethod, methodEnter, methodExit, 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */               
/* 12249 */               instrumentedMethod.getReturnType().represents(void.class) ? 
/* 12250 */               Collections.<TypeDescription>emptyList() : 
/* 12251 */               Collections.<TypeDescription>singletonList(instrumentedMethod.getReturnType().asErasure()), writerFlags, readerFlags);
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected void onUserPrepare() {}
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected void onUserStart() {}
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected void onUserReturn() {
/* 12268 */           if (this.instrumentedMethod.getReturnType().represents(boolean.class) || this.instrumentedMethod
/* 12269 */             .getReturnType().represents(byte.class) || this.instrumentedMethod
/* 12270 */             .getReturnType().represents(short.class) || this.instrumentedMethod
/* 12271 */             .getReturnType().represents(char.class) || this.instrumentedMethod
/* 12272 */             .getReturnType().represents(int.class)) {
/* 12273 */             this.stackMapFrameHandler.injectReturnFrame(this.mv);
/* 12274 */             this.mv.visitVarInsn(54, this.argumentHandler.returned());
/* 12275 */           } else if (this.instrumentedMethod.getReturnType().represents(long.class)) {
/* 12276 */             this.stackMapFrameHandler.injectReturnFrame(this.mv);
/* 12277 */             this.mv.visitVarInsn(55, this.argumentHandler.returned());
/* 12278 */           } else if (this.instrumentedMethod.getReturnType().represents(float.class)) {
/* 12279 */             this.stackMapFrameHandler.injectReturnFrame(this.mv);
/* 12280 */             this.mv.visitVarInsn(56, this.argumentHandler.returned());
/* 12281 */           } else if (this.instrumentedMethod.getReturnType().represents(double.class)) {
/* 12282 */             this.stackMapFrameHandler.injectReturnFrame(this.mv);
/* 12283 */             this.mv.visitVarInsn(57, this.argumentHandler.returned());
/* 12284 */           } else if (!this.instrumentedMethod.getReturnType().represents(void.class)) {
/* 12285 */             this.stackMapFrameHandler.injectReturnFrame(this.mv);
/* 12286 */             this.mv.visitVarInsn(58, this.argumentHandler.returned());
/*       */           } 
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected void onExitAdviceReturn() {}
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static class WithExceptionHandling
/*       */         extends WithExitAdvice
/*       */       {
/*       */         private final TypeDescription throwable;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final Label exceptionHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected final Label userStart;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected WithExceptionHandling(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, StackManipulation exceptionHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.Resolved.ForMethodEnter methodEnter, Advice.Dispatcher.Resolved.ForMethodExit methodExit, int writerFlags, int readerFlags, TypeDescription throwable) {
/* 12342 */           super(methodVisitor, implementationContext, assigner, exceptionHandler, instrumentedType, instrumentedMethod, methodEnter, methodExit, 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */               
/* 12350 */               instrumentedMethod.getReturnType().represents(void.class) ? 
/* 12351 */               Collections.<TypeDescription>singletonList(TypeDescription.ForLoadedType.of(Throwable.class)) : 
/* 12352 */               Arrays.<TypeDescription>asList(new TypeDescription[] { instrumentedMethod.getReturnType().asErasure(), TypeDescription.ForLoadedType.of(Throwable.class) }, ), writerFlags, readerFlags);
/*       */ 
/*       */           
/* 12355 */           this.throwable = throwable;
/* 12356 */           this.exceptionHandler = new Label();
/* 12357 */           this.userStart = new Label();
/*       */         }
/*       */ 
/*       */         
/*       */         protected void onUserPrepare() {
/* 12362 */           this.mv.visitTryCatchBlock(this.userStart, this.returnHandler, this.exceptionHandler, this.throwable.getInternalName());
/*       */         }
/*       */ 
/*       */         
/*       */         protected void onUserStart() {
/* 12367 */           this.mv.visitLabel(this.userStart);
/*       */         }
/*       */ 
/*       */         
/*       */         protected void onUserReturn() {
/* 12372 */           this.stackMapFrameHandler.injectReturnFrame(this.mv);
/* 12373 */           if (this.instrumentedMethod.getReturnType().represents(boolean.class) || this.instrumentedMethod
/* 12374 */             .getReturnType().represents(byte.class) || this.instrumentedMethod
/* 12375 */             .getReturnType().represents(short.class) || this.instrumentedMethod
/* 12376 */             .getReturnType().represents(char.class) || this.instrumentedMethod
/* 12377 */             .getReturnType().represents(int.class)) {
/* 12378 */             this.mv.visitVarInsn(54, this.argumentHandler.returned());
/* 12379 */           } else if (this.instrumentedMethod.getReturnType().represents(long.class)) {
/* 12380 */             this.mv.visitVarInsn(55, this.argumentHandler.returned());
/* 12381 */           } else if (this.instrumentedMethod.getReturnType().represents(float.class)) {
/* 12382 */             this.mv.visitVarInsn(56, this.argumentHandler.returned());
/* 12383 */           } else if (this.instrumentedMethod.getReturnType().represents(double.class)) {
/* 12384 */             this.mv.visitVarInsn(57, this.argumentHandler.returned());
/* 12385 */           } else if (!this.instrumentedMethod.getReturnType().represents(void.class)) {
/* 12386 */             this.mv.visitVarInsn(58, this.argumentHandler.returned());
/*       */           } 
/* 12388 */           this.mv.visitInsn(1);
/* 12389 */           this.mv.visitVarInsn(58, this.argumentHandler.thrown());
/* 12390 */           Label endOfHandler = new Label();
/* 12391 */           this.mv.visitJumpInsn(167, endOfHandler);
/* 12392 */           this.mv.visitLabel(this.exceptionHandler);
/* 12393 */           this.stackMapFrameHandler.injectExceptionFrame(this.mv);
/* 12394 */           this.mv.visitVarInsn(58, this.argumentHandler.thrown());
/* 12395 */           if (this.instrumentedMethod.getReturnType().represents(boolean.class) || this.instrumentedMethod
/* 12396 */             .getReturnType().represents(byte.class) || this.instrumentedMethod
/* 12397 */             .getReturnType().represents(short.class) || this.instrumentedMethod
/* 12398 */             .getReturnType().represents(char.class) || this.instrumentedMethod
/* 12399 */             .getReturnType().represents(int.class)) {
/* 12400 */             this.mv.visitInsn(3);
/* 12401 */             this.mv.visitVarInsn(54, this.argumentHandler.returned());
/* 12402 */           } else if (this.instrumentedMethod.getReturnType().represents(long.class)) {
/* 12403 */             this.mv.visitInsn(9);
/* 12404 */             this.mv.visitVarInsn(55, this.argumentHandler.returned());
/* 12405 */           } else if (this.instrumentedMethod.getReturnType().represents(float.class)) {
/* 12406 */             this.mv.visitInsn(11);
/* 12407 */             this.mv.visitVarInsn(56, this.argumentHandler.returned());
/* 12408 */           } else if (this.instrumentedMethod.getReturnType().represents(double.class)) {
/* 12409 */             this.mv.visitInsn(14);
/* 12410 */             this.mv.visitVarInsn(57, this.argumentHandler.returned());
/* 12411 */           } else if (!this.instrumentedMethod.getReturnType().represents(void.class)) {
/* 12412 */             this.mv.visitInsn(1);
/* 12413 */             this.mv.visitVarInsn(58, this.argumentHandler.returned());
/*       */           } 
/* 12415 */           this.mv.visitLabel(endOfHandler);
/* 12416 */           this.methodSizeHandler.requireStackSize(StackSize.SINGLE.getSize());
/*       */         }
/*       */         
/*       */         protected void onExitAdviceReturn()
/*       */         {
/* 12421 */           this.mv.visitVarInsn(25, this.argumentHandler.thrown());
/* 12422 */           Label endOfHandler = new Label();
/* 12423 */           this.mv.visitJumpInsn(198, endOfHandler);
/* 12424 */           this.mv.visitVarInsn(25, this.argumentHandler.thrown());
/* 12425 */           this.mv.visitInsn(191);
/* 12426 */           this.mv.visitLabel(endOfHandler);
/* 12427 */           this.stackMapFrameHandler.injectPostCompletionFrame(this.mv); } } } } protected static class WithoutExitAdvice extends AdviceVisitor { protected WithoutExitAdvice(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, StackManipulation exceptionHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.Resolved.ForMethodEnter methodEnter, int writerFlags, int readerFlags) { super(methodVisitor, implementationContext, assigner, exceptionHandler, instrumentedType, instrumentedMethod, methodEnter, Advice.Dispatcher.Inactive.INSTANCE, Collections.emptyList(), writerFlags, readerFlags); } public void apply(MethodVisitor methodVisitor) { if (this.instrumentedMethod.getReturnType().represents(boolean.class) || this.instrumentedMethod.getReturnType().represents(byte.class) || this.instrumentedMethod.getReturnType().represents(short.class) || this.instrumentedMethod.getReturnType().represents(char.class) || this.instrumentedMethod.getReturnType().represents(int.class)) { methodVisitor.visitInsn(3); methodVisitor.visitInsn(172); } else if (this.instrumentedMethod.getReturnType().represents(long.class)) { methodVisitor.visitInsn(9); methodVisitor.visitInsn(173); } else if (this.instrumentedMethod.getReturnType().represents(float.class)) { methodVisitor.visitInsn(11); methodVisitor.visitInsn(174); } else if (this.instrumentedMethod.getReturnType().represents(double.class)) { methodVisitor.visitInsn(14); methodVisitor.visitInsn(175); } else if (this.instrumentedMethod.getReturnType().represents(void.class)) { methodVisitor.visitInsn(177); } else { methodVisitor.visitInsn(1); methodVisitor.visitInsn(176); }  } protected void onUserPrepare() {} protected void onUserStart() {} protected void onUserEnd() {} } protected static abstract class WithExitAdvice extends AdviceVisitor { protected final Label returnHandler; protected WithExitAdvice(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, StackManipulation exceptionHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.Resolved.ForMethodEnter methodEnter, Advice.Dispatcher.Resolved.ForMethodExit methodExit, List<? extends TypeDescription> postMethodTypes, int writerFlags, int readerFlags) { super(StackAwareMethodVisitor.of(methodVisitor, instrumentedMethod), implementationContext, assigner, exceptionHandler, instrumentedType, instrumentedMethod, methodEnter, methodExit, postMethodTypes, writerFlags, readerFlags); this.returnHandler = new Label(); } public void apply(MethodVisitor methodVisitor) { if (this.instrumentedMethod.getReturnType().represents(boolean.class) || this.instrumentedMethod.getReturnType().represents(byte.class) || this.instrumentedMethod.getReturnType().represents(short.class) || this.instrumentedMethod.getReturnType().represents(char.class) || this.instrumentedMethod.getReturnType().represents(int.class)) { methodVisitor.visitInsn(3); } else if (this.instrumentedMethod.getReturnType().represents(long.class)) { methodVisitor.visitInsn(9); } else if (this.instrumentedMethod.getReturnType().represents(float.class)) { methodVisitor.visitInsn(11); } else if (this.instrumentedMethod.getReturnType().represents(double.class)) { methodVisitor.visitInsn(14); } else if (!this.instrumentedMethod.getReturnType().represents(void.class)) { methodVisitor.visitInsn(1); }  methodVisitor.visitJumpInsn(167, this.returnHandler); } protected void onVisitInsn(int opcode) { switch (opcode) { case 177: ((StackAwareMethodVisitor)this.mv).drainStack(); break;case 172: this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(54, 21, StackSize.SINGLE)); break;case 174: this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(56, 23, StackSize.SINGLE)); break;case 175: this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(57, 24, StackSize.DOUBLE)); break;case 173: this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(55, 22, StackSize.DOUBLE)); break;case 176: this.methodSizeHandler.requireLocalVariableLength(((StackAwareMethodVisitor)this.mv).drainStack(58, 25, StackSize.SINGLE)); break;default: this.mv.visitInsn(opcode); return; }  this.mv.visitJumpInsn(167, this.returnHandler); } protected void onUserEnd() { this.mv.visitLabel(this.returnHandler); onUserReturn(); this.stackMapFrameHandler.injectCompletionFrame(this.mv); this.methodExit.apply(); onExitAdviceReturn(); if (this.instrumentedMethod.getReturnType().represents(boolean.class) || this.instrumentedMethod.getReturnType().represents(byte.class) || this.instrumentedMethod.getReturnType().represents(short.class) || this.instrumentedMethod.getReturnType().represents(char.class) || this.instrumentedMethod.getReturnType().represents(int.class)) { this.mv.visitVarInsn(21, this.argumentHandler.returned()); this.mv.visitInsn(172); } else if (this.instrumentedMethod.getReturnType().represents(long.class)) { this.mv.visitVarInsn(22, this.argumentHandler.returned()); this.mv.visitInsn(173); } else if (this.instrumentedMethod.getReturnType().represents(float.class)) { this.mv.visitVarInsn(23, this.argumentHandler.returned()); this.mv.visitInsn(174); } else if (this.instrumentedMethod.getReturnType().represents(double.class)) { this.mv.visitVarInsn(24, this.argumentHandler.returned()); this.mv.visitInsn(175); } else if (!this.instrumentedMethod.getReturnType().represents(void.class)) { this.mv.visitVarInsn(25, this.argumentHandler.returned()); this.mv.visitInsn(176); } else { this.mv.visitInsn(177); }  this.methodSizeHandler.requireStackSize(this.instrumentedMethod.getReturnType().getStackSize().getSize()); } protected abstract void onUserReturn(); protected abstract void onExitAdviceReturn(); protected static class WithoutExceptionHandling extends WithExitAdvice { protected WithoutExceptionHandling(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, StackManipulation exceptionHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.Resolved.ForMethodEnter methodEnter, Advice.Dispatcher.Resolved.ForMethodExit methodExit, int writerFlags, int readerFlags) { super(methodVisitor, implementationContext, assigner, exceptionHandler, instrumentedType, instrumentedMethod, methodEnter, methodExit, instrumentedMethod.getReturnType().represents(void.class) ? Collections.<TypeDescription>emptyList() : Collections.<TypeDescription>singletonList(instrumentedMethod.getReturnType().asErasure()), writerFlags, readerFlags); } protected void onUserPrepare() {} protected void onUserStart() {} protected void onUserReturn() { if (this.instrumentedMethod.getReturnType().represents(boolean.class) || this.instrumentedMethod.getReturnType().represents(byte.class) || this.instrumentedMethod.getReturnType().represents(short.class) || this.instrumentedMethod.getReturnType().represents(char.class) || this.instrumentedMethod.getReturnType().represents(int.class)) { this.stackMapFrameHandler.injectReturnFrame(this.mv); this.mv.visitVarInsn(54, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(long.class)) { this.stackMapFrameHandler.injectReturnFrame(this.mv); this.mv.visitVarInsn(55, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(float.class)) { this.stackMapFrameHandler.injectReturnFrame(this.mv); this.mv.visitVarInsn(56, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(double.class)) { this.stackMapFrameHandler.injectReturnFrame(this.mv); this.mv.visitVarInsn(57, this.argumentHandler.returned()); } else if (!this.instrumentedMethod.getReturnType().represents(void.class)) { this.stackMapFrameHandler.injectReturnFrame(this.mv); this.mv.visitVarInsn(58, this.argumentHandler.returned()); }  } protected void onExitAdviceReturn() {} } protected static class WithExceptionHandling extends WithExitAdvice { private final TypeDescription throwable; private final Label exceptionHandler; protected final Label userStart; protected WithExceptionHandling(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, StackManipulation exceptionHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.Resolved.ForMethodEnter methodEnter, Advice.Dispatcher.Resolved.ForMethodExit methodExit, int writerFlags, int readerFlags, TypeDescription throwable) { super(methodVisitor, implementationContext, assigner, exceptionHandler, instrumentedType, instrumentedMethod, methodEnter, methodExit, instrumentedMethod.getReturnType().represents(void.class) ? Collections.<TypeDescription>singletonList(TypeDescription.ForLoadedType.of(Throwable.class)) : Arrays.<TypeDescription>asList(new TypeDescription[] { instrumentedMethod.getReturnType().asErasure(), TypeDescription.ForLoadedType.of(Throwable.class) }, ), writerFlags, readerFlags); this.throwable = throwable; this.exceptionHandler = new Label(); this.userStart = new Label(); } protected void onUserPrepare() { this.mv.visitTryCatchBlock(this.userStart, this.returnHandler, this.exceptionHandler, this.throwable.getInternalName()); } protected void onUserStart() { this.mv.visitLabel(this.userStart); } protected void onUserReturn() { this.stackMapFrameHandler.injectReturnFrame(this.mv); if (this.instrumentedMethod.getReturnType().represents(boolean.class) || this.instrumentedMethod.getReturnType().represents(byte.class) || this.instrumentedMethod.getReturnType().represents(short.class) || this.instrumentedMethod.getReturnType().represents(char.class) || this.instrumentedMethod.getReturnType().represents(int.class)) { this.mv.visitVarInsn(54, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(long.class)) { this.mv.visitVarInsn(55, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(float.class)) { this.mv.visitVarInsn(56, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(double.class)) { this.mv.visitVarInsn(57, this.argumentHandler.returned()); } else if (!this.instrumentedMethod.getReturnType().represents(void.class)) { this.mv.visitVarInsn(58, this.argumentHandler.returned()); }  this.mv.visitInsn(1); this.mv.visitVarInsn(58, this.argumentHandler.thrown()); Label endOfHandler = new Label(); this.mv.visitJumpInsn(167, endOfHandler); this.mv.visitLabel(this.exceptionHandler); this.stackMapFrameHandler.injectExceptionFrame(this.mv); this.mv.visitVarInsn(58, this.argumentHandler.thrown()); if (this.instrumentedMethod.getReturnType().represents(boolean.class) || this.instrumentedMethod.getReturnType().represents(byte.class) || this.instrumentedMethod.getReturnType().represents(short.class) || this.instrumentedMethod.getReturnType().represents(char.class) || this.instrumentedMethod.getReturnType().represents(int.class)) { this.mv.visitInsn(3); this.mv.visitVarInsn(54, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(long.class)) { this.mv.visitInsn(9); this.mv.visitVarInsn(55, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(float.class)) { this.mv.visitInsn(11); this.mv.visitVarInsn(56, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(double.class)) { this.mv.visitInsn(14); this.mv.visitVarInsn(57, this.argumentHandler.returned()); } else if (!this.instrumentedMethod.getReturnType().represents(void.class)) { this.mv.visitInsn(1); this.mv.visitVarInsn(58, this.argumentHandler.returned()); }  this.mv.visitLabel(endOfHandler); this.methodSizeHandler.requireStackSize(StackSize.SINGLE.getSize()); } protected void onExitAdviceReturn() { this.mv.visitVarInsn(25, this.argumentHandler.thrown()); Label endOfHandler = new Label(); this.mv.visitJumpInsn(198, endOfHandler); this.mv.visitVarInsn(25, this.argumentHandler.thrown()); this.mv.visitInsn(191); this.mv.visitLabel(endOfHandler); this.stackMapFrameHandler.injectPostCompletionFrame(this.mv); } } } protected static class WithoutExceptionHandling extends AdviceVisitor.WithExitAdvice { protected WithoutExceptionHandling(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, StackManipulation exceptionHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.Resolved.ForMethodEnter methodEnter, Advice.Dispatcher.Resolved.ForMethodExit methodExit, int writerFlags, int readerFlags) { super(methodVisitor, implementationContext, assigner, exceptionHandler, instrumentedType, instrumentedMethod, methodEnter, methodExit, instrumentedMethod.getReturnType().represents(void.class) ? Collections.<TypeDescription>emptyList() : Collections.<TypeDescription>singletonList(instrumentedMethod.getReturnType().asErasure()), writerFlags, readerFlags); } protected void onUserPrepare() {} protected void onUserStart() {} protected void onUserReturn() { if (this.instrumentedMethod.getReturnType().represents(boolean.class) || this.instrumentedMethod.getReturnType().represents(byte.class) || this.instrumentedMethod.getReturnType().represents(short.class) || this.instrumentedMethod.getReturnType().represents(char.class) || this.instrumentedMethod.getReturnType().represents(int.class)) { this.stackMapFrameHandler.injectReturnFrame(this.mv); this.mv.visitVarInsn(54, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(long.class)) { this.stackMapFrameHandler.injectReturnFrame(this.mv); this.mv.visitVarInsn(55, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(float.class)) { this.stackMapFrameHandler.injectReturnFrame(this.mv); this.mv.visitVarInsn(56, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(double.class)) { this.stackMapFrameHandler.injectReturnFrame(this.mv); this.mv.visitVarInsn(57, this.argumentHandler.returned()); } else if (!this.instrumentedMethod.getReturnType().represents(void.class)) { this.stackMapFrameHandler.injectReturnFrame(this.mv); this.mv.visitVarInsn(58, this.argumentHandler.returned()); }  } protected void onExitAdviceReturn() {} } protected static class WithExceptionHandling extends AdviceVisitor.WithExitAdvice { private final TypeDescription throwable; private final Label exceptionHandler; protected final Label userStart; protected WithExceptionHandling(MethodVisitor methodVisitor, Implementation.Context implementationContext, Assigner assigner, StackManipulation exceptionHandler, TypeDescription instrumentedType, MethodDescription instrumentedMethod, Advice.Dispatcher.Resolved.ForMethodEnter methodEnter, Advice.Dispatcher.Resolved.ForMethodExit methodExit, int writerFlags, int readerFlags, TypeDescription throwable) { super(methodVisitor, implementationContext, assigner, exceptionHandler, instrumentedType, instrumentedMethod, methodEnter, methodExit, instrumentedMethod.getReturnType().represents(void.class) ? Collections.<TypeDescription>singletonList(TypeDescription.ForLoadedType.of(Throwable.class)) : Arrays.<TypeDescription>asList(new TypeDescription[] { instrumentedMethod.getReturnType().asErasure(), TypeDescription.ForLoadedType.of(Throwable.class) }, ), writerFlags, readerFlags); this.throwable = throwable; this.exceptionHandler = new Label(); this.userStart = new Label(); } protected void onUserPrepare() { this.mv.visitTryCatchBlock(this.userStart, this.returnHandler, this.exceptionHandler, this.throwable.getInternalName()); } protected void onUserStart() { this.mv.visitLabel(this.userStart); } protected void onUserReturn() { this.stackMapFrameHandler.injectReturnFrame(this.mv); if (this.instrumentedMethod.getReturnType().represents(boolean.class) || this.instrumentedMethod.getReturnType().represents(byte.class) || this.instrumentedMethod.getReturnType().represents(short.class) || this.instrumentedMethod.getReturnType().represents(char.class) || this.instrumentedMethod.getReturnType().represents(int.class)) { this.mv.visitVarInsn(54, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(long.class)) { this.mv.visitVarInsn(55, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(float.class)) { this.mv.visitVarInsn(56, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(double.class)) { this.mv.visitVarInsn(57, this.argumentHandler.returned()); } else if (!this.instrumentedMethod.getReturnType().represents(void.class)) { this.mv.visitVarInsn(58, this.argumentHandler.returned()); }  this.mv.visitInsn(1); this.mv.visitVarInsn(58, this.argumentHandler.thrown()); Label endOfHandler = new Label(); this.mv.visitJumpInsn(167, endOfHandler); this.mv.visitLabel(this.exceptionHandler); this.stackMapFrameHandler.injectExceptionFrame(this.mv); this.mv.visitVarInsn(58, this.argumentHandler.thrown()); if (this.instrumentedMethod.getReturnType().represents(boolean.class) || this.instrumentedMethod.getReturnType().represents(byte.class) || this.instrumentedMethod.getReturnType().represents(short.class) || this.instrumentedMethod.getReturnType().represents(char.class) || this.instrumentedMethod.getReturnType().represents(int.class)) { this.mv.visitInsn(3); this.mv.visitVarInsn(54, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(long.class)) { this.mv.visitInsn(9); this.mv.visitVarInsn(55, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(float.class)) { this.mv.visitInsn(11); this.mv.visitVarInsn(56, this.argumentHandler.returned()); } else if (this.instrumentedMethod.getReturnType().represents(double.class)) { this.mv.visitInsn(14); this.mv.visitVarInsn(57, this.argumentHandler.returned()); } else if (!this.instrumentedMethod.getReturnType().represents(void.class)) { this.mv.visitInsn(1); this.mv.visitVarInsn(58, this.argumentHandler.returned()); }  this.mv.visitLabel(endOfHandler); this.methodSizeHandler.requireStackSize(StackSize.SINGLE.getSize()); } protected void onExitAdviceReturn() { this.mv.visitVarInsn(25, this.argumentHandler.thrown()); Label endOfHandler = new Label(); this.mv.visitJumpInsn(198, endOfHandler); this.mv.visitVarInsn(25, this.argumentHandler.thrown()); this.mv.visitInsn(191); this.mv.visitLabel(endOfHandler); this.stackMapFrameHandler.injectPostCompletionFrame(this.mv); }
/*       */      }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Enhance
/*       */   protected static class Appender
/*       */     implements ByteCodeAppender
/*       */   {
/*       */     private final Advice advice;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     private final Implementation.Target implementationTarget;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     private final ByteCodeAppender delegate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected Appender(Advice advice, Implementation.Target implementationTarget, ByteCodeAppender delegate) {
/* 12462 */       this.advice = advice;
/* 12463 */       this.implementationTarget = implementationTarget;
/* 12464 */       this.delegate = delegate;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/* 12471 */       EmulatingMethodVisitor emulatingMethodVisitor = new EmulatingMethodVisitor(methodVisitor, this.delegate);
/* 12472 */       methodVisitor = this.advice.doWrap(this.implementationTarget.getInstrumentedType(), instrumentedMethod, emulatingMethodVisitor, implementationContext, 0, 0);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 12478 */       return emulatingMethodVisitor.resolve(methodVisitor, implementationContext, instrumentedMethod);
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean equals(@MaybeNull Object param1Object) {
/*       */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.advice.equals(((Appender)param1Object).advice) ? false : (!this.implementationTarget.equals(((Appender)param1Object).implementationTarget) ? false : (!!this.delegate.equals(((Appender)param1Object).delegate))))));
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     public int hashCode() {
/*       */       return ((getClass().hashCode() * 31 + this.advice.hashCode()) * 31 + this.implementationTarget.hashCode()) * 31 + this.delegate.hashCode();
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     protected static class EmulatingMethodVisitor
/*       */       extends MethodVisitor
/*       */     {
/*       */       private final ByteCodeAppender delegate;
/*       */ 
/*       */       
/*       */       private int stackSize;
/*       */ 
/*       */       
/*       */       private int localVariableLength;
/*       */ 
/*       */ 
/*       */       
/*       */       protected EmulatingMethodVisitor(MethodVisitor methodVisitor, ByteCodeAppender delegate) {
/* 12509 */         super(OpenedClassReader.ASM_API, methodVisitor);
/* 12510 */         this.delegate = delegate;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected ByteCodeAppender.Size resolve(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/* 12524 */         methodVisitor.visitCode();
/* 12525 */         ByteCodeAppender.Size size = this.delegate.apply(methodVisitor, implementationContext, instrumentedMethod);
/* 12526 */         methodVisitor.visitMaxs(size.getOperandStackSize(), size.getLocalVariableSize());
/* 12527 */         methodVisitor.visitEnd();
/* 12528 */         return new ByteCodeAppender.Size(this.stackSize, this.localVariableLength);
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public void visitCode() {}
/*       */ 
/*       */ 
/*       */       
/*       */       public void visitMaxs(int stackSize, int localVariableLength) {
/* 12538 */         this.stackSize = stackSize;
/* 12539 */         this.localVariableLength = localVariableLength;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public void visitEnd() {}
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   @Enhance
/*       */   public static abstract class AssignReturned
/*       */     implements PostProcessor
/*       */   {
/*       */     public static final int NO_INDEX = -1;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected final TypeDescription typeDescription;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected final ExceptionHandler.Factory exceptionHandlerFactory;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected final boolean exit;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected final boolean skipOnDefaultValue;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected AssignReturned(TypeDescription typeDescription, ExceptionHandler.Factory exceptionHandlerFactory, boolean exit, boolean skipOnDefaultValue) {
/* 13547 */       this.typeDescription = typeDescription;
/* 13548 */       this.exceptionHandlerFactory = exceptionHandlerFactory;
/* 13549 */       this.exit = exit;
/* 13550 */       this.skipOnDefaultValue = skipOnDefaultValue;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public StackManipulation resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, Advice.StackMapFrameHandler.ForPostProcessor stackMapFrameHandler, StackManipulation exceptionHandler) {
/* 13562 */       List<StackManipulation> stackManipulations = new ArrayList<StackManipulation>(getHandlers().size());
/* 13563 */       for (Handler handler : getHandlers()) {
/* 13564 */         stackManipulations.add(handler.resolve(instrumentedType, instrumentedMethod, assigner, argumentHandler, 
/*       */ 
/*       */ 
/*       */               
/* 13568 */               getType(), 
/* 13569 */               toLoadInstruction(handler, this.exit ? argumentHandler.exit() : argumentHandler.enter())));
/*       */       }
/* 13571 */       StackManipulation stackManipulation = this.exceptionHandlerFactory.wrap((StackManipulation)new StackManipulation.Compound(stackManipulations), exceptionHandler, stackMapFrameHandler);
/*       */ 
/*       */       
/* 13574 */       return this.skipOnDefaultValue ? 
/* 13575 */         DefaultValueSkip.of(stackManipulation, stackMapFrameHandler, this.exit ? argumentHandler.exit() : argumentHandler.enter(), (TypeDefinition)this.typeDescription) : stackManipulation;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected abstract TypeDescription getType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected abstract Collection<Handler> getHandlers();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected abstract StackManipulation toLoadInstruction(Handler param1Handler, int param1Int);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public boolean equals(@MaybeNull Object param1Object) {
/*       */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : ((this.exit != ((AssignReturned)param1Object).exit) ? false : ((this.skipOnDefaultValue != ((AssignReturned)param1Object).skipOnDefaultValue) ? false : (!this.typeDescription.equals(((AssignReturned)param1Object).typeDescription) ? false : (!!this.exceptionHandlerFactory.equals(((AssignReturned)param1Object).exceptionHandlerFactory)))))));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public int hashCode() {
/*       */       return (((getClass().hashCode() * 31 + this.typeDescription.hashCode()) * 31 + this.exceptionHandlerFactory.hashCode()) * 31 + this.exit) * 31 + this.skipOnDefaultValue;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Documented
/*       */     @Retention(RetentionPolicy.RUNTIME)
/*       */     @Target({ElementType.METHOD})
/*       */     public static @interface ToArguments
/*       */     {
/*       */       ToArgument[] value();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Handler
/*       */         implements Advice.AssignReturned.Handler
/*       */       {
/*       */         private final int value;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final int index;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final Assigner.Typing typing;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Handler(int value, int index, Assigner.Typing typing) {
/* 13702 */           this.value = value;
/* 13703 */           this.index = index;
/* 13704 */           this.typing = typing;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int getIndex() {
/* 13711 */           return this.index;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public StackManipulation resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, TypeDescription type, StackManipulation value) {
/* 13723 */           if (instrumentedMethod.getParameters().size() < this.value) {
/* 13724 */             throw new IllegalStateException(instrumentedMethod + " declares less then " + this.value + " parameters");
/*       */           }
/* 13726 */           StackManipulation assignment = assigner.assign(type.asGenericType(), ((ParameterDescription)instrumentedMethod
/* 13727 */               .getParameters().get(this.value)).getType(), this.typing);
/*       */           
/* 13729 */           if (!assignment.isValid()) {
/* 13730 */             throw new IllegalStateException("Cannot assign " + type + " to " + ((ParameterDescription)instrumentedMethod.getParameters().get(this.value)).getType());
/*       */           }
/* 13732 */           return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { value, assignment, 
/*       */                 
/* 13734 */                 MethodVariableAccess.of((TypeDefinition)((ParameterDescription)instrumentedMethod.getParameters().get(this.value)).getType())
/* 13735 */                 .storeAt(argumentHandler.argument(((ParameterDescription)instrumentedMethod.getParameters().get(this.value)).getOffset())) });
/*       */         }
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.value != ((Handler)param3Object).value) ? false : ((this.index != ((Handler)param3Object).index) ? false : (!!this.typing.equals(((Handler)param3Object).typing))))));
/*       */         }
/*       */         
/*       */         public int hashCode() {
/*       */           return ((getClass().hashCode() * 31 + this.value) * 31 + this.index) * 31 + this.typing.hashCode();
/*       */         }
/*       */         
/* 13746 */         public enum Factory implements Advice.AssignReturned.Handler.Factory<Advice.AssignReturned.ToArguments> { INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape TO_ARGUMENT_TYPING;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape TO_ARGUMENT_INDEX;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape TO_ARGUMENT_VALUE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 13772 */           private static final MethodDescription.InDefinedShape TO_ARGUMENTS_VALUE = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(Advice.AssignReturned.ToArguments.class)
/* 13773 */             .getDeclaredMethods()
/* 13774 */             .filter((ElementMatcher)ElementMatchers.named("value")))
/* 13775 */             .getOnly(); static {
/* 13776 */             MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.AssignReturned.ToArguments.ToArgument.class).getDeclaredMethods();
/* 13777 */             TO_ARGUMENT_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly();
/* 13778 */             TO_ARGUMENT_INDEX = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("index"))).getOnly();
/* 13779 */             TO_ARGUMENT_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Class<Advice.AssignReturned.ToArguments> getAnnotationType() {
/* 13786 */             return Advice.AssignReturned.ToArguments.class;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public List<Advice.AssignReturned.Handler> make(TypeDescription returnType, boolean exit, AnnotationDescription.Loadable<? extends Advice.AssignReturned.ToArguments> annotation) {
/* 13795 */             List<Advice.AssignReturned.Handler> handlers = new ArrayList<Advice.AssignReturned.Handler>();
/* 13796 */             for (AnnotationDescription argument : (AnnotationDescription[])annotation.getValue(TO_ARGUMENTS_VALUE).resolve(AnnotationDescription[].class)) {
/* 13797 */               int value = ((Integer)argument.getValue(TO_ARGUMENT_VALUE).resolve(Integer.class)).intValue();
/* 13798 */               if (value < 0) {
/* 13799 */                 throw new IllegalStateException("An argument cannot have a negative index for " + returnType);
/*       */               }
/* 13801 */               handlers.add(new Advice.AssignReturned.ToArguments.Handler(value, ((Integer)argument
/* 13802 */                     .getValue(TO_ARGUMENT_INDEX).resolve(Integer.class)).intValue(), (Assigner.Typing)((EnumerationDescription)argument
/* 13803 */                     .getValue(TO_ARGUMENT_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class)));
/*       */             } 
/* 13805 */             return handlers;
/*       */           } }
/*       */       
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Target({})
/*       */       @Enhance(ToArguments.class)
/*       */       @Repeatable(ToArguments.class)
/*       */       public static @interface ToArgument
/*       */       {
/*       */         int value();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         int index() default -1;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         Assigner.Typing typing() default Assigner.Typing.STATIC;
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Documented
/*       */     @Retention(RetentionPolicy.RUNTIME)
/*       */     @Target({ElementType.METHOD})
/*       */     public static @interface ToAllArguments
/*       */     {
/*       */       int index() default -1;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Assigner.Typing typing() default Assigner.Typing.STATIC;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Handler
/*       */         implements Advice.AssignReturned.Handler
/*       */       {
/*       */         private final int index;
/*       */ 
/*       */ 
/*       */         
/*       */         private final Assigner.Typing typing;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Handler(int index, Assigner.Typing typing) {
/* 13869 */           this.index = index;
/* 13870 */           this.typing = typing;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int getIndex() {
/* 13877 */           return this.index;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */         public StackManipulation resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, TypeDescription type, StackManipulation value) {
/*       */           StackManipulation.Compound compound;
/* 13890 */           List<StackManipulation> stackManipulations = new ArrayList<StackManipulation>(instrumentedMethod.getParameters().size());
/* 13891 */           if (!type.isArray()) {
/* 13892 */             StackManipulation assignment = assigner.assign(type.asGenericType(), TypeDefinition.Sort.describe(Object[].class), this.typing);
/* 13893 */             if (!assignment.isValid()) {
/* 13894 */               throw new IllegalStateException("Cannot assign " + type + " to " + Object[].class);
/*       */             }
/* 13896 */             type = TypeDescription.ForLoadedType.of(Object[].class);
/* 13897 */             compound = new StackManipulation.Compound(new StackManipulation[] { value, assignment });
/*       */           } 
/* 13899 */           for (ParameterDescription parameterDescription : instrumentedMethod.getParameters()) {
/* 13900 */             StackManipulation assignment = assigner.assign(type.getComponentType().asGenericType(), parameterDescription.getType(), this.typing);
/* 13901 */             if (!assignment.isValid()) {
/* 13902 */               throw new IllegalStateException("Cannot assign " + type.getComponentType() + " to " + parameterDescription);
/*       */             }
/* 13904 */             stackManipulations.add(new StackManipulation.Compound(new StackManipulation[] { assignment, MethodVariableAccess.of((TypeDefinition)parameterDescription.getType())
/* 13905 */                     .storeAt(argumentHandler.argument(parameterDescription.getOffset())) }));
/*       */           } 
/* 13907 */           return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { (StackManipulation)compound, ArrayAccess.of((TypeDefinition)type.getComponentType()).forEach(stackManipulations), (StackManipulation)Removal.SINGLE });
/*       */         }
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.index != ((Handler)param3Object).index) ? false : (!!this.typing.equals(((Handler)param3Object).typing)))));
/*       */         }
/*       */         
/*       */         public int hashCode() {
/*       */           return (getClass().hashCode() * 31 + this.index) * 31 + this.typing.hashCode();
/*       */         }
/*       */         
/* 13918 */         public enum Factory implements Advice.AssignReturned.Handler.Factory<Advice.AssignReturned.ToAllArguments> { INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape TO_ALL_ARGUMENTS_TYPING;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape TO_ALL_ARGUMENTS_INDEX;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           static {
/* 13934 */             MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.AssignReturned.ToAllArguments.class).getDeclaredMethods();
/* 13935 */             TO_ALL_ARGUMENTS_INDEX = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("index"))).getOnly();
/* 13936 */             TO_ALL_ARGUMENTS_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Class<Advice.AssignReturned.ToAllArguments> getAnnotationType() {
/* 13943 */             return Advice.AssignReturned.ToAllArguments.class;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public List<Advice.AssignReturned.Handler> make(TypeDescription typeDescription, boolean exit, AnnotationDescription.Loadable<? extends Advice.AssignReturned.ToAllArguments> annotation) {
/* 13952 */             return Collections.singletonList(new Advice.AssignReturned.ToAllArguments.Handler(((Integer)annotation.getValue(TO_ALL_ARGUMENTS_INDEX).resolve(Integer.class)).intValue(), (Assigner.Typing)((EnumerationDescription)annotation
/* 13953 */                   .getValue(TO_ALL_ARGUMENTS_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class)));
/*       */           } }
/*       */       
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Documented
/*       */     @Retention(RetentionPolicy.RUNTIME)
/*       */     @Target({ElementType.METHOD})
/*       */     public static @interface ToThis
/*       */     {
/*       */       int index() default -1;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Assigner.Typing typing() default Assigner.Typing.STATIC;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Handler
/*       */         implements Advice.AssignReturned.Handler
/*       */       {
/*       */         private final int index;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final Assigner.Typing typing;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final boolean exit;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Handler(int index, Assigner.Typing typing, boolean exit) {
/* 14018 */           this.index = index;
/* 14019 */           this.typing = typing;
/* 14020 */           this.exit = exit;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int getIndex() {
/* 14027 */           return this.index;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public StackManipulation resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, TypeDescription type, StackManipulation value) {
/* 14039 */           if (instrumentedMethod.isStatic())
/* 14040 */             throw new IllegalStateException("Cannot assign this reference for static method " + instrumentedMethod); 
/* 14041 */           if (!this.exit && instrumentedMethod.isConstructor()) {
/* 14042 */             throw new IllegalStateException("Cannot assign this reference in constructor prior to initialization for " + instrumentedMethod);
/*       */           }
/* 14044 */           StackManipulation assignment = assigner.assign(type.asGenericType(), instrumentedType
/* 14045 */               .asGenericType(), this.typing);
/*       */           
/* 14047 */           if (!assignment.isValid()) {
/* 14048 */             throw new IllegalStateException("Cannot assign " + type + " to " + instrumentedType);
/*       */           }
/* 14050 */           return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { value, assignment, MethodVariableAccess.REFERENCE
/*       */                 
/* 14052 */                 .storeAt(argumentHandler.argument(0)) });
/*       */         }
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.index != ((Handler)param3Object).index) ? false : ((this.exit != ((Handler)param3Object).exit) ? false : (!!this.typing.equals(((Handler)param3Object).typing))))));
/*       */         }
/*       */         
/*       */         public int hashCode() {
/*       */           return ((getClass().hashCode() * 31 + this.index) * 31 + this.typing.hashCode()) * 31 + this.exit;
/*       */         }
/*       */         
/*       */         public enum Factory implements Advice.AssignReturned.Handler.Factory<Advice.AssignReturned.ToThis> {
/* 14064 */           INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape TO_THIS_TYPING;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape TO_THIS_INDEX;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           static {
/* 14080 */             MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.AssignReturned.ToThis.class).getDeclaredMethods();
/* 14081 */             TO_THIS_INDEX = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("index"))).getOnly();
/* 14082 */             TO_THIS_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Class<Advice.AssignReturned.ToThis> getAnnotationType() {
/* 14089 */             return Advice.AssignReturned.ToThis.class;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public List<Advice.AssignReturned.Handler> make(TypeDescription returnType, boolean exit, AnnotationDescription.Loadable<? extends Advice.AssignReturned.ToThis> annotation) {
/* 14098 */             return Collections.singletonList(new Advice.AssignReturned.ToThis.Handler(((Integer)annotation.getValue(TO_THIS_INDEX).resolve(Integer.class)).intValue(), (Assigner.Typing)((EnumerationDescription)annotation
/* 14099 */                   .getValue(TO_THIS_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class), exit));
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Documented
/*       */     @Retention(RetentionPolicy.RUNTIME)
/*       */     @Target({ElementType.METHOD})
/*       */     public static @interface ToFields
/*       */     {
/*       */       ToField[] value();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Handler
/*       */         implements Advice.AssignReturned.Handler
/*       */       {
/*       */         private final int index;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final String name;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final TypeDescription declaringType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final Assigner.Typing typing;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Handler(int index, String name, TypeDescription declaringType, Assigner.Typing typing) {
/* 14211 */           this.index = index;
/* 14212 */           this.name = name;
/* 14213 */           this.declaringType = declaringType;
/* 14214 */           this.typing = typing;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int getIndex() {
/* 14221 */           return this.index;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */         public StackManipulation resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, TypeDescription type, StackManipulation value) {
/*       */           StackManipulation stackManipulation;
/* 14234 */           FieldLocator locator = this.declaringType.represents(void.class) ? (FieldLocator)new FieldLocator.ForClassHierarchy(instrumentedType) : (FieldLocator)new FieldLocator.ForExactType(this.declaringType);
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 14239 */           FieldLocator.Resolution resolution = this.name.equals("") ? FieldLocator.Resolution.Simple.ofBeanAccessor(locator, instrumentedMethod) : locator.locate(this.name);
/*       */           
/* 14241 */           if (!resolution.isResolved())
/* 14242 */             throw new IllegalStateException("Cannot resolve field " + this.name + " for " + instrumentedType); 
/* 14243 */           if (!resolution.getField().isVisibleTo(instrumentedType))
/* 14244 */             throw new IllegalStateException(resolution.getField() + " is not visible to " + instrumentedType); 
/* 14245 */           if (resolution.getField().isStatic())
/* 14246 */           { StackManipulation.Trivial trivial = StackManipulation.Trivial.INSTANCE; }
/* 14247 */           else { if (instrumentedMethod.isStatic())
/* 14248 */               throw new IllegalStateException("Cannot access member field " + resolution.getField() + " from static " + instrumentedMethod); 
/* 14249 */             if (!instrumentedType.isAssignableTo(resolution.getField().getDeclaringType().asErasure())) {
/* 14250 */               throw new IllegalStateException(instrumentedType + " does not define " + resolution.getField());
/*       */             }
/* 14252 */             stackManipulation = MethodVariableAccess.loadThis(); }
/*       */           
/* 14254 */           StackManipulation assignment = assigner.assign(type.asGenericType(), resolution
/* 14255 */               .getField().getType(), this.typing);
/*       */           
/* 14257 */           if (!assignment.isValid()) {
/* 14258 */             throw new IllegalStateException("Cannot assign " + type + " to " + resolution.getField());
/*       */           }
/* 14260 */           return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { stackManipulation, value, assignment, 
/*       */ 
/*       */                 
/* 14263 */                 FieldAccess.forField(resolution.getField()).write() });
/*       */         }
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.index != ((Handler)param3Object).index) ? false : (!this.typing.equals(((Handler)param3Object).typing) ? false : (!this.name.equals(((Handler)param3Object).name) ? false : (!!this.declaringType.equals(((Handler)param3Object).declaringType)))))));
/*       */         }
/*       */         
/*       */         public int hashCode() {
/*       */           return (((getClass().hashCode() * 31 + this.index) * 31 + this.name.hashCode()) * 31 + this.declaringType.hashCode()) * 31 + this.typing.hashCode();
/*       */         }
/*       */         
/* 14274 */         public enum Factory implements Advice.AssignReturned.Handler.Factory<Advice.AssignReturned.ToFields> { INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape TO_FIELD_TYPING;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape TO_FIELD_DECLARING_TYPE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape TO_FIELD_INDEX;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape TO_FIELD_VALUE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 14305 */           private static final MethodDescription.InDefinedShape TO_FIELDS_VALUE = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(Advice.AssignReturned.ToFields.class)
/* 14306 */             .getDeclaredMethods()
/* 14307 */             .filter((ElementMatcher)ElementMatchers.named("value")))
/* 14308 */             .getOnly(); static {
/* 14309 */             MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.AssignReturned.ToFields.ToField.class).getDeclaredMethods();
/* 14310 */             TO_FIELD_VALUE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("value"))).getOnly();
/* 14311 */             TO_FIELD_INDEX = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("index"))).getOnly();
/* 14312 */             TO_FIELD_DECLARING_TYPE = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("declaringType"))).getOnly();
/* 14313 */             TO_FIELD_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Class<Advice.AssignReturned.ToFields> getAnnotationType() {
/* 14320 */             return Advice.AssignReturned.ToFields.class;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public List<Advice.AssignReturned.Handler> make(TypeDescription returnType, boolean exit, AnnotationDescription.Loadable<? extends Advice.AssignReturned.ToFields> annotation) {
/* 14329 */             List<Advice.AssignReturned.Handler> handlers = new ArrayList<Advice.AssignReturned.Handler>();
/* 14330 */             for (AnnotationDescription field : (AnnotationDescription[])annotation.getValue(TO_FIELDS_VALUE).resolve(AnnotationDescription[].class)) {
/* 14331 */               handlers.add(new Advice.AssignReturned.ToFields.Handler(((Integer)field.getValue(TO_FIELD_INDEX).resolve(Integer.class)).intValue(), (String)field
/* 14332 */                     .getValue(TO_FIELD_VALUE).resolve(String.class), (TypeDescription)field
/* 14333 */                     .getValue(TO_FIELD_DECLARING_TYPE).resolve(TypeDescription.class), (Assigner.Typing)((EnumerationDescription)field
/* 14334 */                     .getValue(TO_FIELD_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class)));
/*       */             }
/* 14336 */             return handlers;
/*       */           } }
/*       */       
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Target({})
/*       */       @Enhance(ToFields.class)
/*       */       @Repeatable(ToFields.class)
/*       */       public static @interface ToField
/*       */       {
/*       */         String value() default "";
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         Class<?> declaringType() default void.class;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         int index() default -1;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         Assigner.Typing typing() default Assigner.Typing.STATIC;
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Documented
/*       */     @Retention(RetentionPolicy.RUNTIME)
/*       */     @Target({ElementType.METHOD})
/*       */     public static @interface ToReturned
/*       */     {
/*       */       int index() default -1;
/*       */ 
/*       */ 
/*       */       
/*       */       Assigner.Typing typing() default Assigner.Typing.STATIC;
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Handler
/*       */         implements Advice.AssignReturned.Handler
/*       */       {
/*       */         private final int index;
/*       */ 
/*       */         
/*       */         private final Assigner.Typing typing;
/*       */ 
/*       */ 
/*       */         
/*       */         protected Handler(int index, Assigner.Typing typing) {
/* 14396 */           this.index = index;
/* 14397 */           this.typing = typing;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int getIndex() {
/* 14404 */           return this.index;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public StackManipulation resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, TypeDescription type, StackManipulation value) {
/* 14416 */           if (instrumentedMethod.getReturnType().represents(void.class)) {
/* 14417 */             return (StackManipulation)StackManipulation.Trivial.INSTANCE;
/*       */           }
/* 14419 */           StackManipulation assignment = assigner.assign(type.asGenericType(), instrumentedMethod.getReturnType(), this.typing);
/* 14420 */           if (!assignment.isValid()) {
/* 14421 */             throw new IllegalStateException("Cannot assign " + type + " to " + instrumentedMethod.getReturnType());
/*       */           }
/* 14423 */           return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { value, assignment, 
/*       */                 
/* 14425 */                 MethodVariableAccess.of((TypeDefinition)instrumentedMethod.getReturnType()).storeAt(argumentHandler.returned()) });
/*       */         }
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.index != ((Handler)param3Object).index) ? false : (!!this.typing.equals(((Handler)param3Object).typing)))));
/*       */         }
/*       */         
/*       */         public int hashCode() {
/*       */           return (getClass().hashCode() * 31 + this.index) * 31 + this.typing.hashCode();
/*       */         }
/*       */         
/* 14436 */         public enum Factory implements Advice.AssignReturned.Handler.Factory<Advice.AssignReturned.ToReturned> { INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape TO_RETURNED_TYPING;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape TO_RETURNED_INDEX;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           static {
/* 14452 */             MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.AssignReturned.ToReturned.class).getDeclaredMethods();
/* 14453 */             TO_RETURNED_INDEX = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("index"))).getOnly();
/* 14454 */             TO_RETURNED_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Class<Advice.AssignReturned.ToReturned> getAnnotationType() {
/* 14461 */             return Advice.AssignReturned.ToReturned.class;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public List<Advice.AssignReturned.Handler> make(TypeDescription returnType, boolean exit, AnnotationDescription.Loadable<? extends Advice.AssignReturned.ToReturned> annotation) {
/* 14470 */             if (!exit) {
/* 14471 */               throw new IllegalStateException("Cannot write returned value from enter advice for " + returnType);
/*       */             }
/* 14473 */             return Collections.singletonList(new Advice.AssignReturned.ToReturned.Handler(((Integer)annotation.getValue(TO_RETURNED_INDEX).resolve(Integer.class)).intValue(), (Assigner.Typing)((EnumerationDescription)annotation
/* 14474 */                   .getValue(TO_RETURNED_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class)));
/*       */           } }
/*       */       
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Documented
/*       */     @Retention(RetentionPolicy.RUNTIME)
/*       */     @Target({ElementType.METHOD})
/*       */     public static @interface ToThrown
/*       */     {
/*       */       int index() default -1;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       Assigner.Typing typing() default Assigner.Typing.STATIC;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       @Enhance
/*       */       public static class Handler
/*       */         implements Advice.AssignReturned.Handler
/*       */       {
/*       */         private final int index;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         private final Assigner.Typing typing;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected Handler(int index, Assigner.Typing typing) {
/* 14536 */           this.index = index;
/* 14537 */           this.typing = typing;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int getIndex() {
/* 14544 */           return this.index;
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public StackManipulation resolve(TypeDescription instrumentedType, MethodDescription instrumentedMethod, Assigner assigner, Advice.ArgumentHandler argumentHandler, TypeDescription type, StackManipulation value) {
/* 14556 */           StackManipulation assignment = assigner.assign(type.asGenericType(), TypeDefinition.Sort.describe(Throwable.class), this.typing);
/* 14557 */           if (!assignment.isValid()) {
/* 14558 */             throw new IllegalStateException("Cannot assign " + type + " to " + Throwable.class.getName());
/*       */           }
/* 14560 */           return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { value, assignment, MethodVariableAccess.REFERENCE
/*       */                 
/* 14562 */                 .storeAt(argumentHandler.thrown()) });
/*       */         }
/*       */         
/*       */         public boolean equals(@MaybeNull Object param3Object) {
/*       */           return (this == param3Object) ? true : ((param3Object == null) ? false : ((getClass() != param3Object.getClass()) ? false : ((this.index != ((Handler)param3Object).index) ? false : (!!this.typing.equals(((Handler)param3Object).typing)))));
/*       */         }
/*       */         
/*       */         public int hashCode() {
/*       */           return (getClass().hashCode() * 31 + this.index) * 31 + this.typing.hashCode();
/*       */         }
/*       */         
/* 14573 */         public enum Factory implements Advice.AssignReturned.Handler.Factory<Advice.AssignReturned.ToThrown> { INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape TO_THROWN_TYPING;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private static final MethodDescription.InDefinedShape TO_THROWN_INDEX;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           static {
/* 14589 */             MethodList<MethodDescription.InDefinedShape> methods = TypeDescription.ForLoadedType.of(Advice.AssignReturned.ToThrown.class).getDeclaredMethods();
/* 14590 */             TO_THROWN_INDEX = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("index"))).getOnly();
/* 14591 */             TO_THROWN_TYPING = (MethodDescription.InDefinedShape)((MethodList)methods.filter((ElementMatcher)ElementMatchers.named("typing"))).getOnly();
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Class<Advice.AssignReturned.ToThrown> getAnnotationType() {
/* 14598 */             return Advice.AssignReturned.ToThrown.class;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming annotation for exit advice.")
/*       */           public List<Advice.AssignReturned.Handler> make(TypeDescription returnType, boolean exit, AnnotationDescription.Loadable<? extends Advice.AssignReturned.ToThrown> annotation) {
/* 14608 */             if (!exit) {
/* 14609 */               throw new IllegalStateException("Cannot assign thrown value from enter advice for " + returnType);
/*       */             }
/* 14611 */             return Collections.singletonList(new Advice.AssignReturned.ToThrown.Handler(((Integer)annotation.getValue(TO_THROWN_INDEX).resolve(Integer.class)).intValue(), (Assigner.Typing)((EnumerationDescription)annotation
/* 14612 */                   .getValue(TO_THROWN_TYPING).resolve(EnumerationDescription.class)).load(Assigner.Typing.class)));
/*       */           } }
/*       */       
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     protected static class ForArray
/*       */       extends AssignReturned
/*       */     {
/*       */       private final Map<Advice.AssignReturned.Handler, Integer> handlers;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected ForArray(TypeDescription typeDescription, Advice.AssignReturned.ExceptionHandler.Factory exceptionHandlerFactory, boolean exit, Collection<List<Advice.AssignReturned.Handler>> handlers) {
/* 14641 */         super(typeDescription, exceptionHandlerFactory, exit, true);
/* 14642 */         this.handlers = new LinkedHashMap<Advice.AssignReturned.Handler, Integer>();
/* 14643 */         for (List<Advice.AssignReturned.Handler> collection : handlers) {
/* 14644 */           for (Advice.AssignReturned.Handler handler : collection) {
/* 14645 */             int index = handler.getIndex();
/* 14646 */             if (index <= -1) {
/* 14647 */               throw new IllegalStateException("Handler on array requires positive index for " + handler);
/*       */             }
/* 14649 */             this.handlers.put(handler, Integer.valueOf(index));
/*       */           } 
/*       */         } 
/*       */       }
/*       */ 
/*       */       
/*       */       @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */       protected TypeDescription getType() {
/* 14657 */         return this.typeDescription.getComponentType();
/*       */       }
/*       */ 
/*       */       
/*       */       protected Collection<Advice.AssignReturned.Handler> getHandlers() {
/* 14662 */         return this.handlers.keySet();
/*       */       }
/*       */ 
/*       */       
/*       */       @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming component type for array type.")
/*       */       protected StackManipulation toLoadInstruction(Advice.AssignReturned.Handler handler, int offset) {
/* 14668 */         return (StackManipulation)new StackManipulation.Compound(new StackManipulation[] { MethodVariableAccess.REFERENCE.loadFrom(offset), 
/* 14669 */               IntegerConstant.forValue(((Integer)this.handlers.get(handler)).intValue()), 
/* 14670 */               ArrayAccess.of((TypeDefinition)this.typeDescription.getComponentType()).load() });
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return !super.equals(param2Object) ? false : ((this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.handlers.equals(((ForArray)param2Object).handlers)))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return super.hashCode() * 31 + this.handlers.hashCode();
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     protected static class ForScalar
/*       */       extends AssignReturned
/*       */     {
/*       */       private final List<Advice.AssignReturned.Handler> handlers;
/*       */ 
/*       */ 
/*       */       
/*       */       protected ForScalar(TypeDescription typeDescription, Advice.AssignReturned.ExceptionHandler.Factory exceptionHandlerFactory, boolean exit, boolean skipOnDefaultValue, Collection<List<Advice.AssignReturned.Handler>> handlers) {
/* 14699 */         super(typeDescription, exceptionHandlerFactory, exit, skipOnDefaultValue);
/* 14700 */         this.handlers = new ArrayList<Advice.AssignReturned.Handler>();
/* 14701 */         for (List<Advice.AssignReturned.Handler> collection : handlers) {
/* 14702 */           for (Advice.AssignReturned.Handler handler : collection) {
/* 14703 */             int index = handler.getIndex();
/* 14704 */             if (index > -1) {
/* 14705 */               throw new IllegalStateException("Handler on array requires negative index for " + handler);
/*       */             }
/* 14707 */             this.handlers.add(handler);
/*       */           } 
/*       */         } 
/*       */       }
/*       */ 
/*       */       
/*       */       protected TypeDescription getType() {
/* 14714 */         return this.typeDescription;
/*       */       }
/*       */ 
/*       */       
/*       */       protected Collection<Advice.AssignReturned.Handler> getHandlers() {
/* 14719 */         return this.handlers;
/*       */       }
/*       */ 
/*       */       
/*       */       protected StackManipulation toLoadInstruction(Advice.AssignReturned.Handler handler, int offset) {
/* 14724 */         return MethodVariableAccess.of((TypeDefinition)this.typeDescription).loadFrom(offset);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return !super.equals(param2Object) ? false : ((this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!!this.handlers.equals(((ForScalar)param2Object).handlers)))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return super.hashCode() * 31 + this.handlers.hashCode();
/*       */       }
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     protected static class DefaultValueSkip
/*       */       implements StackManipulation
/*       */     {
/*       */       private final StackManipulation stackManipulation;
/*       */ 
/*       */ 
/*       */       
/*       */       private final Advice.StackMapFrameHandler.ForPostProcessor stackMapFrameHandler;
/*       */ 
/*       */ 
/*       */       
/*       */       private final int offset;
/*       */ 
/*       */ 
/*       */       
/*       */       private final Dispatcher dispatcher;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected DefaultValueSkip(StackManipulation stackManipulation, Advice.StackMapFrameHandler.ForPostProcessor stackMapFrameHandler, int offset, Dispatcher dispatcher) {
/* 14767 */         this.stackManipulation = stackManipulation;
/* 14768 */         this.stackMapFrameHandler = stackMapFrameHandler;
/* 14769 */         this.offset = offset;
/* 14770 */         this.dispatcher = dispatcher;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected static StackManipulation of(StackManipulation stackManipulation, Advice.StackMapFrameHandler.ForPostProcessor stackMapFrameHandler, int offset, TypeDefinition typeDefinition) {
/*       */         Dispatcher dispatcher;
/* 14787 */         if (typeDefinition.isPrimitive()) {
/* 14788 */           if (typeDefinition.represents(boolean.class) || typeDefinition
/* 14789 */             .represents(byte.class) || typeDefinition
/* 14790 */             .represents(short.class) || typeDefinition
/* 14791 */             .represents(char.class) || typeDefinition
/* 14792 */             .represents(int.class)) {
/* 14793 */             dispatcher = Dispatcher.INTEGER;
/* 14794 */           } else if (typeDefinition.represents(long.class)) {
/* 14795 */             dispatcher = Dispatcher.LONG;
/* 14796 */           } else if (typeDefinition.represents(float.class)) {
/* 14797 */             dispatcher = Dispatcher.FLOAT;
/* 14798 */           } else if (typeDefinition.represents(double.class)) {
/* 14799 */             dispatcher = Dispatcher.DOUBLE;
/*       */           } else {
/* 14801 */             throw new IllegalArgumentException("Cannot apply skip for " + typeDefinition);
/*       */           } 
/*       */         } else {
/* 14804 */           dispatcher = Dispatcher.REFERENCE;
/*       */         } 
/* 14806 */         return new DefaultValueSkip(stackManipulation, stackMapFrameHandler, offset, dispatcher);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isValid() {
/* 14813 */         return this.stackManipulation.isValid();
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 14820 */         Label label = new Label();
/* 14821 */         StackManipulation.Size size = this.dispatcher.apply(methodVisitor, this.offset, label).aggregate(this.stackManipulation.apply(methodVisitor, implementationContext));
/* 14822 */         methodVisitor.visitInsn(0);
/* 14823 */         methodVisitor.visitLabel(label);
/* 14824 */         this.stackMapFrameHandler.injectIntermediateFrame(methodVisitor, Collections.emptyList());
/* 14825 */         methodVisitor.visitInsn(0);
/* 14826 */         return size;
/*       */       }
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : ((this.offset != ((DefaultValueSkip)param2Object).offset) ? false : (!this.dispatcher.equals(((DefaultValueSkip)param2Object).dispatcher) ? false : (!this.stackManipulation.equals(((DefaultValueSkip)param2Object).stackManipulation) ? false : (!!this.stackMapFrameHandler.equals(((DefaultValueSkip)param2Object).stackMapFrameHandler)))))));
/*       */       }
/*       */       
/*       */       public int hashCode() {
/*       */         return (((getClass().hashCode() * 31 + this.stackManipulation.hashCode()) * 31 + this.stackMapFrameHandler.hashCode()) * 31 + this.offset) * 31 + this.dispatcher.hashCode();
/*       */       }
/*       */       
/* 14837 */       protected enum Dispatcher { INTEGER
/*       */         {
/*       */           protected StackManipulation.Size apply(MethodVisitor methodVisitor, int offset, Label label) {
/* 14840 */             methodVisitor.visitVarInsn(21, offset);
/* 14841 */             methodVisitor.visitJumpInsn(153, label);
/* 14842 */             return new StackManipulation.Size(0, 1);
/*       */           }
/*       */         },
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 14849 */         LONG
/*       */         {
/*       */           protected StackManipulation.Size apply(MethodVisitor methodVisitor, int offset, Label label) {
/* 14852 */             methodVisitor.visitVarInsn(22, offset);
/* 14853 */             methodVisitor.visitInsn(9);
/* 14854 */             methodVisitor.visitInsn(148);
/* 14855 */             methodVisitor.visitJumpInsn(153, label);
/* 14856 */             return new StackManipulation.Size(0, 4);
/*       */           }
/*       */         },
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 14863 */         FLOAT
/*       */         {
/*       */           protected StackManipulation.Size apply(MethodVisitor methodVisitor, int offset, Label label) {
/* 14866 */             methodVisitor.visitVarInsn(23, offset);
/* 14867 */             methodVisitor.visitInsn(11);
/* 14868 */             methodVisitor.visitInsn(149);
/* 14869 */             methodVisitor.visitJumpInsn(153, label);
/* 14870 */             return new StackManipulation.Size(0, 2);
/*       */           }
/*       */         },
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 14877 */         DOUBLE
/*       */         {
/*       */           protected StackManipulation.Size apply(MethodVisitor methodVisitor, int offset, Label label) {
/* 14880 */             methodVisitor.visitVarInsn(24, offset);
/* 14881 */             methodVisitor.visitInsn(14);
/* 14882 */             methodVisitor.visitInsn(151);
/* 14883 */             methodVisitor.visitJumpInsn(153, label);
/* 14884 */             return new StackManipulation.Size(0, 4);
/*       */           }
/*       */         },
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 14891 */         REFERENCE
/*       */         {
/*       */           protected StackManipulation.Size apply(MethodVisitor methodVisitor, int offset, Label label) {
/* 14894 */             methodVisitor.visitVarInsn(25, offset);
/* 14895 */             methodVisitor.visitJumpInsn(198, label);
/* 14896 */             return new StackManipulation.Size(0, 2);
/*       */           }
/*       */         };
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         protected abstract StackManipulation.Size apply(MethodVisitor param3MethodVisitor, int param3Int, Label param3Label); }
/*       */     
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     @Enhance
/*       */     protected static class ExceptionHandler
/*       */       implements StackManipulation
/*       */     {
/*       */       private final StackManipulation stackManipulation;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final StackManipulation exceptionHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final TypeDescription exceptionType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final Advice.StackMapFrameHandler.ForPostProcessor stackMapFrameHandler;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected ExceptionHandler(StackManipulation stackManipulation, StackManipulation exceptionHandler, TypeDescription exceptionType, Advice.StackMapFrameHandler.ForPostProcessor stackMapFrameHandler) {
/* 14950 */         this.stackManipulation = stackManipulation;
/* 14951 */         this.exceptionHandler = exceptionHandler;
/* 14952 */         this.exceptionType = exceptionType;
/* 14953 */         this.stackMapFrameHandler = stackMapFrameHandler;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean isValid() {
/* 14960 */         return (this.stackManipulation.isValid() && this.exceptionHandler.isValid());
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public StackManipulation.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext) {
/* 14967 */         Label start = new Label(), handler = new Label(), end = new Label();
/* 14968 */         methodVisitor.visitTryCatchBlock(start, handler, handler, this.exceptionType.getInternalName());
/* 14969 */         methodVisitor.visitLabel(start);
/* 14970 */         StackManipulation.Size size = this.stackManipulation.apply(methodVisitor, implementationContext);
/* 14971 */         methodVisitor.visitJumpInsn(167, end);
/* 14972 */         methodVisitor.visitLabel(handler);
/* 14973 */         this.stackMapFrameHandler.injectIntermediateFrame(methodVisitor, Collections.singletonList(this.exceptionType));
/* 14974 */         size = this.exceptionHandler.apply(methodVisitor, implementationContext).aggregate(size);
/* 14975 */         methodVisitor.visitLabel(end);
/* 14976 */         this.stackMapFrameHandler.injectIntermediateFrame(methodVisitor, Collections.emptyList());
/* 14977 */         return size;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.stackManipulation.equals(((ExceptionHandler)param2Object).stackManipulation) ? false : (!this.exceptionHandler.equals(((ExceptionHandler)param2Object).exceptionHandler) ? false : (!this.exceptionType.equals(((ExceptionHandler)param2Object).exceptionType) ? false : (!!this.stackMapFrameHandler.equals(((ExceptionHandler)param2Object).stackMapFrameHandler)))))));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return (((getClass().hashCode() * 31 + this.stackManipulation.hashCode()) * 31 + this.exceptionHandler.hashCode()) * 31 + this.exceptionType.hashCode()) * 31 + this.stackMapFrameHandler.hashCode();
/*       */       }
/*       */ 
/*       */ 
/*       */       
/*       */       public static interface Factory
/*       */       {
/*       */         StackManipulation wrap(StackManipulation param3StackManipulation1, StackManipulation param3StackManipulation2, Advice.StackMapFrameHandler.ForPostProcessor param3ForPostProcessor);
/*       */ 
/*       */ 
/*       */         
/*       */         public enum NoOp
/*       */           implements Factory
/*       */         {
/* 15005 */           INSTANCE;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public StackManipulation wrap(StackManipulation stackManipulation, StackManipulation exceptionHandler, Advice.StackMapFrameHandler.ForPostProcessor stackMapFrameHandler) {
/* 15013 */             return stackManipulation;
/*       */           }
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class Enabled
/*       */           implements Factory
/*       */         {
/*       */           private final TypeDescription exceptionType;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           protected Enabled(TypeDescription exceptionType) {
/* 15034 */             this.exceptionType = exceptionType;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public StackManipulation wrap(StackManipulation stackManipulation, StackManipulation exceptionHandler, Advice.StackMapFrameHandler.ForPostProcessor stackMapFrameHandler)
/*       */           {
/* 15043 */             return new Advice.AssignReturned.ExceptionHandler(stackManipulation, exceptionHandler, this.exceptionType, stackMapFrameHandler); } public boolean equals(@MaybeNull Object param4Object) { return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.exceptionType.equals(((Enabled)param4Object).exceptionType)))); } public int hashCode() { return getClass().hashCode() * 31 + this.exceptionType.hashCode(); } } } } public static interface Factory { StackManipulation wrap(StackManipulation param2StackManipulation1, StackManipulation param2StackManipulation2, Advice.StackMapFrameHandler.ForPostProcessor param2ForPostProcessor); public enum NoOp implements Factory { INSTANCE; public StackManipulation wrap(StackManipulation stackManipulation, StackManipulation exceptionHandler, Advice.StackMapFrameHandler.ForPostProcessor stackMapFrameHandler) { return stackManipulation; } } @Enhance public static class Enabled implements Factory { private final TypeDescription exceptionType; protected Enabled(TypeDescription exceptionType) { this.exceptionType = exceptionType; } public StackManipulation wrap(StackManipulation stackManipulation, StackManipulation exceptionHandler, Advice.StackMapFrameHandler.ForPostProcessor stackMapFrameHandler) { return new Advice.AssignReturned.ExceptionHandler(stackManipulation, exceptionHandler, this.exceptionType, stackMapFrameHandler); }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public boolean equals(@MaybeNull Object param4Object) {
/*       */           return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!!this.exceptionType.equals(((Enabled)param4Object).exceptionType))));
/*       */         }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         public int hashCode() {
/*       */           return getClass().hashCode() * 31 + this.exceptionType.hashCode();
/*       */         } }
/*       */        }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public static interface Handler
/*       */     {
/*       */       int getIndex();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       StackManipulation resolve(TypeDescription param2TypeDescription1, MethodDescription param2MethodDescription, Assigner param2Assigner, Advice.ArgumentHandler param2ArgumentHandler, TypeDescription param2TypeDescription2, StackManipulation param2StackManipulation);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public static interface Factory<T extends Annotation>
/*       */       {
/*       */         Class<T> getAnnotationType();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         List<Advice.AssignReturned.Handler> make(TypeDescription param3TypeDescription, boolean param3Boolean, AnnotationDescription.Loadable<? extends T> param3Loadable);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         @Enhance
/*       */         public static class Simple<S extends Annotation>
/*       */           implements Factory<S>
/*       */         {
/*       */           private final Class<S> type;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           private final List<Advice.AssignReturned.Handler> handlers;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Simple(Class<S> type, List<Advice.AssignReturned.Handler> handlers) {
/* 15133 */             this.type = type;
/* 15134 */             this.handlers = handlers;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public Class<S> getAnnotationType() {
/* 15141 */             return this.type;
/*       */           }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*       */           public List<Advice.AssignReturned.Handler> make(TypeDescription returnType, boolean exit, AnnotationDescription.Loadable<? extends S> annotation) {
/* 15150 */             return this.handlers;
/*       */           }
/*       */           
/*       */           public boolean equals(@MaybeNull Object param4Object) {
/*       */             return (this == param4Object) ? true : ((param4Object == null) ? false : ((getClass() != param4Object.getClass()) ? false : (!this.type.equals(((Simple)param4Object).type) ? false : (!!this.handlers.equals(((Simple)param4Object).handlers)))));
/*       */           }
/*       */           
/*       */           public int hashCode() {
/*       */             return (getClass().hashCode() * 31 + this.type.hashCode()) * 31 + this.handlers.hashCode();
/*       */           }
/*       */         }
/*       */       }
/*       */     }
/*       */     
/*       */     @Enhance
/*       */     public static class Factory implements Advice.PostProcessor.Factory {
/* 15166 */       private static final MethodDescription.InDefinedShape SKIP_ON_DEFAULT_VALUE = (MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(Advice.AssignReturned.AsScalar.class)
/* 15167 */         .getDeclaredMethods()
/* 15168 */         .filter((ElementMatcher)ElementMatchers.named("skipOnDefaultValue")))
/* 15169 */         .getOnly();
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final List<? extends Advice.AssignReturned.Handler.Factory<?>> factories;
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       private final Advice.AssignReturned.ExceptionHandler.Factory exceptionHandlerFactory;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Factory() {
/* 15186 */         this((List)Arrays.asList((Object[])new Enum[] { Advice.AssignReturned.ToArguments.Handler.Factory.INSTANCE, Advice.AssignReturned.ToAllArguments.Handler.Factory.INSTANCE, Advice.AssignReturned.ToThis.Handler.Factory.INSTANCE, Advice.AssignReturned.ToFields.Handler.Factory.INSTANCE, Advice.AssignReturned.ToReturned.Handler.Factory.INSTANCE, Advice.AssignReturned.ToThrown.Handler.Factory.INSTANCE }, ), Advice.AssignReturned.ExceptionHandler.Factory.NoOp.INSTANCE);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       protected Factory(List<? extends Advice.AssignReturned.Handler.Factory<?>> factories, Advice.AssignReturned.ExceptionHandler.Factory exceptionHandlerFactory) {
/* 15201 */         this.factories = factories;
/* 15202 */         this.exceptionHandlerFactory = exceptionHandlerFactory;
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Factory with(Class<? extends Annotation> type, Advice.AssignReturned.Handler... handler) {
/* 15213 */         return with(type, Arrays.asList(handler));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Factory with(Class<? extends Annotation> type, List<Advice.AssignReturned.Handler> handlers) {
/* 15225 */         return with(new Advice.AssignReturned.Handler.Factory.Simple(type, handlers));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Factory with(Advice.AssignReturned.Handler.Factory<?> factory) {
/* 15235 */         return new Factory(CompoundList.of(this.factories, factory), this.exceptionHandlerFactory);
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.PostProcessor.Factory withSuppressed(Class<? extends Throwable> exceptionType) {
/* 15245 */         return withSuppressed(TypeDescription.ForLoadedType.of(exceptionType));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.PostProcessor.Factory withSuppressed(TypeDescription exceptionType) {
/* 15255 */         if (!exceptionType.isAssignableTo(Throwable.class)) {
/* 15256 */           throw new IllegalArgumentException(exceptionType + " is not a throwable type");
/*       */         }
/* 15258 */         return new Factory(this.factories, new Advice.AssignReturned.ExceptionHandler.Factory.Enabled(exceptionType));
/*       */       }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*       */       public Advice.PostProcessor make(List<? extends AnnotationDescription> annotations, TypeDescription returnType, boolean exit) {
/* 15268 */         if (returnType.represents(void.class)) {
/* 15269 */           return Advice.PostProcessor.NoOp.INSTANCE;
/*       */         }
/* 15271 */         Map<String, Advice.AssignReturned.Handler.Factory<?>> factories = new HashMap<String, Advice.AssignReturned.Handler.Factory<?>>();
/* 15272 */         for (Advice.AssignReturned.Handler.Factory<?> factory : this.factories) {
/* 15273 */           if (factories.put(factory.getAnnotationType().getName(), factory) != null) {
/* 15274 */             throw new IllegalStateException("Duplicate registration of handler for " + factory.getAnnotationType());
/*       */           }
/*       */         } 
/* 15277 */         Map<Class<?>, List<Advice.AssignReturned.Handler>> handlers = new LinkedHashMap<Class<?>, List<Advice.AssignReturned.Handler>>();
/* 15278 */         boolean scalar = false, skipOnDefaultValue = true;
/* 15279 */         for (AnnotationDescription annotation : annotations) {
/* 15280 */           if (annotation.getAnnotationType().represents(Advice.AssignReturned.AsScalar.class)) {
/* 15281 */             scalar = true;
/* 15282 */             skipOnDefaultValue = ((Boolean)annotation.getValue(SKIP_ON_DEFAULT_VALUE).resolve(Boolean.class)).booleanValue();
/*       */             continue;
/*       */           } 
/* 15285 */           Advice.AssignReturned.Handler.Factory<?> factory = factories.get(annotation.getAnnotationType().getName());
/* 15286 */           if (factory != null && 
/* 15287 */             handlers.put(factory.getAnnotationType(), factory.make(returnType, exit, annotation
/*       */                 
/* 15289 */                 .prepare(factory.getAnnotationType()))) != null) {
/* 15290 */             throw new IllegalStateException("Duplicate handler registration for " + annotation.getAnnotationType());
/*       */           }
/*       */         } 
/*       */         
/* 15294 */         if (handlers.isEmpty()) {
/* 15295 */           return Advice.PostProcessor.NoOp.INSTANCE;
/*       */         }
/* 15297 */         return (!scalar && returnType.isArray()) ? new Advice.AssignReturned.ForArray(returnType, this.exceptionHandlerFactory, exit, handlers
/* 15298 */             .values()) : new Advice.AssignReturned.ForScalar(returnType, this.exceptionHandlerFactory, exit, skipOnDefaultValue, handlers
/* 15299 */             .values());
/*       */       }
/*       */ 
/*       */       
/*       */       public boolean equals(@MaybeNull Object param2Object) {
/*       */         return (this == param2Object) ? true : ((param2Object == null) ? false : ((getClass() != param2Object.getClass()) ? false : (!this.factories.equals(((Factory)param2Object).factories) ? false : (!!this.exceptionHandlerFactory.equals(((Factory)param2Object).exceptionHandlerFactory)))));
/*       */       }
/*       */ 
/*       */       
/*       */       public int hashCode() {
/*       */         return (getClass().hashCode() * 31 + this.factories.hashCode()) * 31 + this.exceptionHandlerFactory.hashCode();
/*       */       }
/*       */     }
/*       */ 
/*       */     
/*       */     @Documented
/*       */     @Retention(RetentionPolicy.RUNTIME)
/*       */     @Target({ElementType.METHOD})
/*       */     public static @interface AsScalar
/*       */     {
/*       */       boolean skipOnDefaultValue() default true;
/*       */     }
/*       */   }
/*       */ 
/*       */   
/*       */   @Enhance
/*       */   public static class WithCustomMapping
/*       */   {
/*       */     private final Advice.PostProcessor.Factory postProcessorFactory;
/*       */     
/*       */     private final Advice.Delegator.Factory delegatorFactory;
/*       */     
/*       */     private final AsmClassReader.Factory classReaderFactory;
/*       */     private final Map<Class<? extends Annotation>, Advice.OffsetMapping.Factory<?>> offsetMappings;
/*       */     
/*       */     protected WithCustomMapping() {
/* 15335 */       this(Advice.PostProcessor.NoOp.INSTANCE, 
/* 15336 */           Collections.emptyMap(), Advice.Delegator.ForRegularInvocation.Factory.INSTANCE, (AsmClassReader.Factory)AsmClassReader.Factory.Default.IMPLICIT);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     protected WithCustomMapping(Advice.PostProcessor.Factory postProcessorFactory, Map<Class<? extends Annotation>, Advice.OffsetMapping.Factory<?>> offsetMappings, Advice.Delegator.Factory delegatorFactory, AsmClassReader.Factory classReaderFactory) {
/* 15353 */       this.postProcessorFactory = postProcessorFactory;
/* 15354 */       this.offsetMappings = offsetMappings;
/* 15355 */       this.delegatorFactory = delegatorFactory;
/* 15356 */       this.classReaderFactory = classReaderFactory;
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bind(Class<T> type, @MaybeNull Object value) {
/* 15369 */       return bind(Advice.OffsetMapping.ForStackManipulation.Factory.of(type, value));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bind(Class<T> type, Field field) {
/* 15382 */       return bind(type, (FieldDescription)new FieldDescription.ForLoadedField(field));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bind(Class<T> type, FieldDescription fieldDescription) {
/* 15396 */       return bind(new Advice.OffsetMapping.ForField.Resolved.Factory(type, fieldDescription));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bind(Class<T> type, Method method, int index) {
/* 15409 */       if (index < 0)
/* 15410 */         throw new IllegalArgumentException("A parameter cannot be negative: " + index); 
/* 15411 */       if ((method.getParameterTypes()).length <= index) {
/* 15412 */         throw new IllegalArgumentException(method + " does not declare a parameter with index " + index);
/*       */       }
/* 15414 */       return bind(type, (ParameterDescription)(new MethodDescription.ForLoadedMethod(method)).getParameters().get(index));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bind(Class<T> type, Constructor<?> constructor, int index) {
/* 15427 */       if (index < 0)
/* 15428 */         throw new IllegalArgumentException("A parameter cannot be negative: " + index); 
/* 15429 */       if ((constructor.getParameterTypes()).length <= index) {
/* 15430 */         throw new IllegalArgumentException(constructor + " does not declare a parameter with index " + index);
/*       */       }
/* 15432 */       return bind(type, (ParameterDescription)(new MethodDescription.ForLoadedConstructor(constructor)).getParameters().get(index));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bind(Class<T> type, ParameterDescription parameterDescription) {
/* 15445 */       return bind(new Advice.OffsetMapping.ForArgument.Resolved.Factory(type, parameterDescription));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bind(Class<T> type, Class<?> value) {
/* 15457 */       return bind(type, TypeDescription.ForLoadedType.of(value));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bind(Class<T> type, TypeDescription value) {
/* 15469 */       return bind(new Advice.OffsetMapping.ForStackManipulation.Factory(type, value));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bind(Class<T> type, Enum<?> value) {
/* 15481 */       return bind(type, (EnumerationDescription)new EnumerationDescription.ForLoadedEnumeration(value));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bind(Class<T> type, EnumerationDescription value) {
/* 15493 */       return bind(new Advice.OffsetMapping.ForStackManipulation.Factory(type, value));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bindSerialized(Class<T> type, Serializable value) {
/* 15506 */       return bindSerialized(type, value, value.getClass());
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation, S extends Serializable> WithCustomMapping bindSerialized(Class<T> type, S value, Class<? super S> targetType) {
/* 15520 */       return bind(Advice.OffsetMapping.ForSerializedValue.Factory.of(type, (Serializable)value, targetType));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bindProperty(Class<T> type, String property) {
/* 15532 */       return bind(Advice.OffsetMapping.ForStackManipulation.OfAnnotationProperty.of(type, property));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bind(Class<T> type, JavaConstant constant) {
/* 15544 */       return bind(type, (ConstantValue)constant);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bind(Class<T> type, ConstantValue constant) {
/* 15556 */       return bind(new Advice.OffsetMapping.ForStackManipulation.Factory(type, constant.toStackManipulation(), constant.getTypeDescription().asGenericType()));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bind(Class<T> type, StackManipulation stackManipulation, Type targetType) {
/* 15569 */       return bind(type, stackManipulation, TypeDefinition.Sort.describe(targetType));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bind(Class<T> type, StackManipulation stackManipulation, TypeDescription.Generic targetType) {
/* 15582 */       return bind(new Advice.OffsetMapping.ForStackManipulation.Factory(type, stackManipulation, targetType));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bindLambda(Class<T> type, Constructor<?> constructor, Class<?> functionalInterface) {
/* 15597 */       return bindLambda(type, (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(constructor), 
/*       */           
/* 15599 */           TypeDescription.ForLoadedType.of(functionalInterface));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bindLambda(Class<T> type, Constructor<?> constructor, Class<?> functionalInterface, MethodGraph.Compiler methodGraphCompiler) {
/* 15616 */       return bindLambda(type, (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(constructor), 
/*       */           
/* 15618 */           TypeDescription.ForLoadedType.of(functionalInterface), methodGraphCompiler);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bindLambda(Class<T> type, Method method, Class<?> functionalInterface) {
/* 15634 */       return bindLambda(type, (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method), 
/*       */           
/* 15636 */           TypeDescription.ForLoadedType.of(functionalInterface));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bindLambda(Class<T> type, Method method, Class<?> functionalInterface, MethodGraph.Compiler methodGraphCompiler) {
/* 15653 */       return bindLambda(type, (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method), 
/*       */           
/* 15655 */           TypeDescription.ForLoadedType.of(functionalInterface), methodGraphCompiler);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bindLambda(Class<T> type, MethodDescription.InDefinedShape methodDescription, TypeDescription functionalInterface) {
/* 15671 */       return bindLambda(type, methodDescription, functionalInterface, MethodGraph.Compiler.DEFAULT);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bindLambda(Class<T> type, MethodDescription.InDefinedShape methodDescription, TypeDescription functionalInterface, MethodGraph.Compiler methodGraphCompiler) {
/* 15688 */       if (!functionalInterface.isInterface()) {
/* 15689 */         throw new IllegalArgumentException(functionalInterface + " is not an interface type");
/*       */       }
/*       */ 
/*       */ 
/*       */       
/* 15694 */       MethodList<?> methods = (MethodList)methodGraphCompiler.compile((TypeDefinition)functionalInterface).listNodes().asMethodList().filter((ElementMatcher)ElementMatchers.isAbstract());
/* 15695 */       if (methods.size() != 1) {
/* 15696 */         throw new IllegalArgumentException(functionalInterface + " does not define exactly one abstract method: " + methods);
/*       */       }
/* 15698 */       return bindDynamic(type, (MethodDescription.InDefinedShape)new MethodDescription.Latent((TypeDescription)new TypeDescription.Latent("java.lang.invoke.LambdaMetafactory", 1, 
/*       */               
/* 15700 */               TypeDescription.Generic.OfNonGenericType.ForLoadedType.of(Object.class), new TypeDescription.Generic[0]), "metafactory", 9, 
/*       */ 
/*       */             
/* 15703 */             Collections.emptyList(), JavaType.CALL_SITE
/* 15704 */             .getTypeStub().asGenericType(), 
/* 15705 */             Arrays.asList(new ParameterDescription.Token[] { new ParameterDescription.Token(JavaType.METHOD_HANDLES_LOOKUP.getTypeStub().asGenericType()), new ParameterDescription.Token(
/* 15706 */                   TypeDescription.ForLoadedType.of(String.class).asGenericType()), new ParameterDescription.Token(JavaType.METHOD_TYPE
/* 15707 */                   .getTypeStub().asGenericType()), new ParameterDescription.Token(JavaType.METHOD_TYPE
/* 15708 */                   .getTypeStub().asGenericType()), new ParameterDescription.Token(JavaType.METHOD_HANDLE
/* 15709 */                   .getTypeStub().asGenericType()), new ParameterDescription.Token(JavaType.METHOD_TYPE
/* 15710 */                   .getTypeStub().asGenericType())
/* 15711 */               }, ), Collections.emptyList(), 
/* 15712 */             Collections.emptyList(), AnnotationValue.UNDEFINED, TypeDescription.Generic.UNDEFINED), new Object[] {
/*       */ 
/*       */             
/* 15715 */             JavaConstant.MethodType.ofSignature((MethodDescription)methods.asDefined().getOnly()), 
/* 15716 */             JavaConstant.MethodHandle.of(methodDescription), 
/* 15717 */             JavaConstant.MethodType.ofSignature((MethodDescription)methods.asDefined().getOnly())
/*       */           });
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bindDynamic(Class<T> type, Method bootstrapMethod, Object... constant) {
/* 15730 */       return bindDynamic(type, bootstrapMethod, Arrays.asList(constant));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bindDynamic(Class<T> type, Method bootstrapMethod, List<?> constants) {
/* 15743 */       return bindDynamic(type, (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(bootstrapMethod), constants);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bindDynamic(Class<T> type, Constructor<?> bootstrapMethod, Object... constant) {
/* 15756 */       return bindDynamic(type, bootstrapMethod, Arrays.asList(constant));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bindDynamic(Class<T> type, Constructor<?> bootstrapMethod, List<?> constants) {
/* 15769 */       return bindDynamic(type, (MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(bootstrapMethod), constants);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bindDynamic(Class<T> type, MethodDescription.InDefinedShape bootstrapMethod, Object... constant) {
/* 15782 */       return bindDynamic(type, bootstrapMethod, Arrays.asList(constant));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bindDynamic(Class<T> type, MethodDescription.InDefinedShape bootstrapMethod, List<?> constants) {
/* 15795 */       List<JavaConstant> arguments = JavaConstant.Simple.wrap(constants);
/* 15796 */       if (!bootstrapMethod.isInvokeBootstrap((List)TypeList.Explicit.of(arguments))) {
/* 15797 */         throw new IllegalArgumentException("Not a valid bootstrap method " + bootstrapMethod + " for " + arguments);
/*       */       }
/* 15799 */       return bind(new Advice.OffsetMapping.ForStackManipulation.OfDynamicInvocation(type, bootstrapMethod, arguments));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public <T extends Annotation> WithCustomMapping bind(Class<T> type, Advice.OffsetMapping offsetMapping) {
/* 15811 */       return bind(new Advice.OffsetMapping.Factory.Simple(type, offsetMapping));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public WithCustomMapping bind(Advice.OffsetMapping.Factory<?> offsetMapping) {
/* 15822 */       Map<Class<? extends Annotation>, Advice.OffsetMapping.Factory<?>> offsetMappings = new LinkedHashMap<Class<? extends Annotation>, Advice.OffsetMapping.Factory<?>>(this.offsetMappings);
/* 15823 */       if (!offsetMapping.getAnnotationType().isAnnotation())
/* 15824 */         throw new IllegalArgumentException("Not an annotation type: " + offsetMapping.getAnnotationType()); 
/* 15825 */       if (offsetMappings.put((Class)offsetMapping.getAnnotationType(), offsetMapping) != null) {
/* 15826 */         throw new IllegalArgumentException("Annotation type already mapped: " + offsetMapping.getAnnotationType());
/*       */       }
/* 15828 */       return new WithCustomMapping(this.postProcessorFactory, offsetMappings, this.delegatorFactory, this.classReaderFactory);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public WithCustomMapping bootstrap(Constructor<?> constructor) {
/* 15849 */       return bootstrap((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(constructor));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public WithCustomMapping bootstrap(Constructor<?> constructor, Advice.BootstrapArgumentResolver.Factory resolverFactory) {
/* 15861 */       return bootstrap((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedConstructor(constructor), resolverFactory);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public WithCustomMapping bootstrap(Method method) {
/* 15882 */       return bootstrap((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public WithCustomMapping bootstrap(Method method, Advice.BootstrapArgumentResolver.Factory resolver) {
/* 15894 */       return bootstrap((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method), resolver);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public WithCustomMapping bootstrap(Method method, Advice.BootstrapArgumentResolver.Factory resolver, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/* 15913 */       return bootstrap((MethodDescription.InDefinedShape)new MethodDescription.ForLoadedMethod(method), resolver, visitor);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public WithCustomMapping bootstrap(MethodDescription.InDefinedShape bootstrap) {
/* 15934 */       return bootstrap(bootstrap, Advice.BootstrapArgumentResolver.ForDefaultValues.Factory.INSTANCE);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public WithCustomMapping bootstrap(MethodDescription.InDefinedShape bootstrap, Advice.BootstrapArgumentResolver.Factory resolverFactory) {
/* 15946 */       return bootstrap(bootstrap, resolverFactory, (TypeDescription.Generic.Visitor<? extends TypeDescription.Generic>)TypeDescription.Generic.Visitor.NoOp.INSTANCE);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public WithCustomMapping bootstrap(MethodDescription.InDefinedShape bootstrap, Advice.BootstrapArgumentResolver.Factory resolverFactory, TypeDescription.Generic.Visitor<? extends TypeDescription.Generic> visitor) {
/* 15965 */       return new WithCustomMapping(this.postProcessorFactory, this.offsetMappings, 
/*       */           
/* 15967 */           Advice.Delegator.ForDynamicInvocation.of(bootstrap, resolverFactory, visitor), this.classReaderFactory);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public WithCustomMapping with(Advice.PostProcessor.Factory postProcessorFactory) {
/* 15978 */       return new WithCustomMapping(new Advice.PostProcessor.Factory.Compound(new Advice.PostProcessor.Factory[] { this.postProcessorFactory, postProcessorFactory }, ), this.offsetMappings, this.delegatorFactory, this.classReaderFactory);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public WithCustomMapping with(AsmClassReader.Factory classReaderFactory) {
/* 15991 */       return new WithCustomMapping(this.postProcessorFactory, this.offsetMappings, this.delegatorFactory, classReaderFactory);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public Advice to(Class<?> advice) {
/* 16002 */       return to(advice, ClassFileLocator.ForClassLoader.of(advice.getClassLoader()));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public Advice to(Class<?> advice, ClassFileLocator classFileLocator) {
/* 16013 */       return to(TypeDescription.ForLoadedType.of(advice), classFileLocator);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public Advice to(TypeDescription advice, ClassFileLocator classFileLocator) {
/* 16024 */       return Advice.to(advice, this.postProcessorFactory, classFileLocator, new ArrayList<Advice.OffsetMapping.Factory<?>>(this.offsetMappings
/*       */ 
/*       */             
/* 16027 */             .values()), this.delegatorFactory, this.classReaderFactory);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public Advice to(Class<?> enterAdvice, Class<?> exitAdvice) {
/* 16041 */       ClassLoader enterLoader = enterAdvice.getClassLoader(), exitLoader = exitAdvice.getClassLoader();
/* 16042 */       return to(enterAdvice, exitAdvice, (enterLoader == exitLoader) ? 
/* 16043 */           ClassFileLocator.ForClassLoader.of(enterLoader) : (ClassFileLocator)new ClassFileLocator.Compound(new ClassFileLocator[] {
/* 16044 */               ClassFileLocator.ForClassLoader.of(enterLoader), ClassFileLocator.ForClassLoader.of(exitLoader)
/*       */             }));
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public Advice to(Class<?> enterAdvice, Class<?> exitAdvice, ClassFileLocator classFileLocator) {
/* 16056 */       return to(TypeDescription.ForLoadedType.of(enterAdvice), TypeDescription.ForLoadedType.of(exitAdvice), classFileLocator);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public Advice to(TypeDescription enterAdvice, TypeDescription exitAdvice) {
/* 16069 */       return to(enterAdvice, exitAdvice, (ClassFileLocator)ClassFileLocator.NoOp.INSTANCE);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     public Advice to(TypeDescription enterAdvice, TypeDescription exitAdvice, ClassFileLocator classFileLocator) {
/* 16081 */       return Advice.to(enterAdvice, exitAdvice, this.postProcessorFactory, classFileLocator, new ArrayList<Advice.OffsetMapping.Factory<?>>(this.offsetMappings
/*       */ 
/*       */ 
/*       */             
/* 16085 */             .values()), this.delegatorFactory, this.classReaderFactory);
/*       */     }
/*       */ 
/*       */     
/*       */     public boolean equals(@MaybeNull Object param1Object) {
/*       */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.postProcessorFactory.equals(((WithCustomMapping)param1Object).postProcessorFactory) ? false : (!this.delegatorFactory.equals(((WithCustomMapping)param1Object).delegatorFactory) ? false : (!this.classReaderFactory.equals(((WithCustomMapping)param1Object).classReaderFactory) ? false : (!!this.offsetMappings.equals(((WithCustomMapping)param1Object).offsetMappings)))))));
/*       */     }
/*       */ 
/*       */     
/*       */     public int hashCode() {
/*       */       return (((getClass().hashCode() * 31 + this.postProcessorFactory.hashCode()) * 31 + this.delegatorFactory.hashCode()) * 31 + this.classReaderFactory.hashCode()) * 31 + this.offsetMappings.hashCode();
/*       */     }
/*       */   }
/*       */ 
/*       */   
/*       */   private static class NoExceptionHandler
/*       */     extends Throwable
/*       */   {
/*       */     private static final long serialVersionUID = 1L;
/* 16104 */     private static final TypeDescription DESCRIPTION = TypeDescription.ForLoadedType.of(NoExceptionHandler.class);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     private NoExceptionHandler() {
/* 16110 */       throw new UnsupportedOperationException("This class only serves as a marker type and should not be instantiated");
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static final class OnDefaultValue
/*       */   {
/*       */     private OnDefaultValue() {
/* 16127 */       throw new UnsupportedOperationException("This class only serves as a marker type and should not be instantiated");
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public static final class OnNonDefaultValue
/*       */   {
/*       */     private OnNonDefaultValue() {
/* 16144 */       throw new UnsupportedOperationException("This class only serves as a marker type and should not be instantiated");
/*       */     }
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface Unused {}
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface StubValue {}
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface Local {
/*       */     String value();
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface Exit {
/*       */     boolean readOnly() default true;
/*       */     
/*       */     Assigner.Typing typing() default Assigner.Typing.STATIC;
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface Enter {
/*       */     boolean readOnly() default true;
/*       */     
/*       */     Assigner.Typing typing() default Assigner.Typing.STATIC;
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface Origin {
/*       */     public static final String DEFAULT = "";
/*       */     
/*       */     String value() default "";
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface FieldSetterHandle {
/*       */     String value() default "";
/*       */     
/*       */     Class<?> declaringType() default void.class;
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface FieldGetterHandle {
/*       */     String value() default "";
/*       */     
/*       */     Class<?> declaringType() default void.class;
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface FieldValue {
/*       */     String value() default "";
/*       */     
/*       */     Class<?> declaringType() default void.class;
/*       */     
/*       */     boolean readOnly() default true;
/*       */     
/*       */     Assigner.Typing typing() default Assigner.Typing.STATIC;
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface DynamicConstant {
/*       */     String name() default "_";
/*       */     
/*       */     JavaConstant.MethodHandle.HandleType bootstrapType();
/*       */     
/*       */     Class<?> bootstrapOwner() default void.class;
/*       */     
/*       */     String bootstrapName();
/*       */     
/*       */     Class<?> bootstrapReturnType();
/*       */     
/*       */     Class<?>[] bootstrapParameterTypes();
/*       */     
/*       */     boolean invokedynamic() default false;
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface Handle {
/*       */     JavaConstant.MethodHandle.HandleType type();
/*       */     
/*       */     Class<?> owner() default void.class;
/*       */     
/*       */     String name();
/*       */     
/*       */     Class<?> returnType();
/*       */     
/*       */     Class<?>[] parameterTypes();
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface SelfCallHandle {
/*       */     boolean bound() default true;
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface Thrown {
/*       */     boolean readOnly() default true;
/*       */     
/*       */     Assigner.Typing typing() default Assigner.Typing.DYNAMIC;
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface Return {
/*       */     boolean readOnly() default true;
/*       */     
/*       */     Assigner.Typing typing() default Assigner.Typing.STATIC;
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface AllArguments {
/*       */     boolean readOnly() default true;
/*       */     
/*       */     Assigner.Typing typing() default Assigner.Typing.STATIC;
/*       */     
/*       */     boolean includeSelf() default false;
/*       */     
/*       */     boolean nullIfEmpty() default false;
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface Argument {
/*       */     int value();
/*       */     
/*       */     boolean readOnly() default true;
/*       */     
/*       */     Assigner.Typing typing() default Assigner.Typing.STATIC;
/*       */     
/*       */     boolean optional() default false;
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.PARAMETER})
/*       */   public static @interface This {
/*       */     boolean readOnly() default true;
/*       */     
/*       */     Assigner.Typing typing() default Assigner.Typing.STATIC;
/*       */     
/*       */     boolean optional() default false;
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.METHOD})
/*       */   public static @interface OnMethodExit {
/*       */     Class<?> repeatOn() default void.class;
/*       */     
/*       */     int repeatOnIndex() default -1;
/*       */     
/*       */     Class<? extends Throwable> onThrowable() default Advice.NoExceptionHandler.class;
/*       */     
/*       */     boolean backupArguments() default true;
/*       */     
/*       */     boolean inline() default true;
/*       */     
/*       */     Class<? extends Throwable> suppress() default Advice.NoExceptionHandler.class;
/*       */   }
/*       */   
/*       */   @Documented
/*       */   @Retention(RetentionPolicy.RUNTIME)
/*       */   @Target({ElementType.METHOD})
/*       */   public static @interface OnMethodEnter {
/*       */     Class<?> skipOn() default void.class;
/*       */     
/*       */     int skipOnIndex() default -1;
/*       */     
/*       */     boolean prependLineNumber() default true;
/*       */     
/*       */     boolean inline() default true;
/*       */     
/*       */     Class<? extends Throwable> suppress() default Advice.NoExceptionHandler.class;
/*       */   }
/*       */   
/*       */   public static interface ForMethodEnter extends Dispatcher.Resolved {
/*       */     boolean isPrependLineNumber();
/*       */     
/*       */     TypeDefinition getActualAdviceType();
/*       */   }
/*       */   
/*       */   public static interface ForMethodExit extends Dispatcher.Resolved {
/*       */     TypeDescription getThrowable();
/*       */     
/*       */     Advice.ArgumentHandler.Factory getArgumentHandlerFactory();
/*       */   }
/*       */   
/*       */   public static interface Factory {
/*       */     Advice.Delegator make(MethodDescription.InDefinedShape param1InDefinedShape, boolean param1Boolean);
/*       */   }
/*       */   
/*       */   public static interface Unresolved extends Dispatcher {
/*       */     boolean isBinary();
/*       */     
/*       */     Map<String, TypeDefinition> getNamedTypes();
/*       */     
/*       */     Advice.Dispatcher.Resolved.ForMethodEnter asMethodEnter(List<? extends Advice.OffsetMapping.Factory<?>> param1List, @MaybeNull AsmClassReader param1AsmClassReader, Unresolved param1Unresolved, Advice.PostProcessor.Factory param1Factory);
/*       */     
/*       */     Advice.Dispatcher.Resolved.ForMethodExit asMethodExit(List<? extends Advice.OffsetMapping.Factory<?>> param1List, @MaybeNull AsmClassReader param1AsmClassReader, Unresolved param1Unresolved, Advice.PostProcessor.Factory param1Factory);
/*       */   }
/*       */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\asm\Advice.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */