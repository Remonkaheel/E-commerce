/*     */ package net.bytebuddy.asm;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.field.FieldList;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.jar.asm.AnnotationVisitor;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.jar.asm.ConstantDynamic;
/*     */ import net.bytebuddy.jar.asm.FieldVisitor;
/*     */ import net.bytebuddy.jar.asm.Handle;
/*     */ import net.bytebuddy.jar.asm.Label;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.jar.asm.RecordComponentVisitor;
/*     */ import net.bytebuddy.jar.asm.Type;
/*     */ import net.bytebuddy.jar.asm.TypePath;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.pool.TypePool;
/*     */ import net.bytebuddy.utility.OpenedClassReader;
/*     */ import net.bytebuddy.utility.nullability.AlwaysNull;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class TypeReferenceAdjustment
/*     */   extends AsmVisitorWrapper.AbstractBase
/*     */ {
/*     */   private final boolean strict;
/*     */   private final ElementMatcher.Junction<? super TypeDescription> filter;
/*     */   
/*     */   protected TypeReferenceAdjustment(boolean strict, ElementMatcher.Junction<? super TypeDescription> filter) {
/*  64 */     this.strict = strict;
/*  65 */     this.filter = filter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeReferenceAdjustment strict() {
/*  75 */     return new TypeReferenceAdjustment(true, ElementMatchers.none());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeReferenceAdjustment relaxed() {
/*  85 */     return new TypeReferenceAdjustment(false, ElementMatchers.none());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeReferenceAdjustment filter(ElementMatcher<? super TypeDescription> filter) {
/*  95 */     return new TypeReferenceAdjustment(this.strict, this.filter.or(filter));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassVisitor wrap(TypeDescription instrumentedType, ClassVisitor classVisitor, Implementation.Context implementationContext, TypePool typePool, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, int writerFlags, int readerFlags) {
/* 109 */     return new TypeReferenceClassVisitor(classVisitor, this.strict, (ElementMatcher<? super TypeDescription>)this.filter, typePool);
/*     */   }
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : ((this.strict != ((TypeReferenceAdjustment)paramObject).strict) ? false : (!!this.filter.equals(((TypeReferenceAdjustment)paramObject).filter)))));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*     */     return (getClass().hashCode() * 31 + this.strict) * 31 + this.filter.hashCode();
/*     */   }
/*     */   
/*     */   protected static class TypeReferenceClassVisitor extends ClassVisitor { @AlwaysNull
/* 121 */     private static final AnnotationVisitor IGNORE_ANNOTATION = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @AlwaysNull
/* 127 */     private static final FieldVisitor IGNORE_FIELD = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @AlwaysNull
/* 133 */     private static final MethodVisitor IGNORE_METHOD = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final boolean strict;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final ElementMatcher<? super TypeDescription> filter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final TypePool typePool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Set<String> observedTypes;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Set<String> visitedInnerTypes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected TypeReferenceClassVisitor(ClassVisitor classVisitor, boolean strict, ElementMatcher<? super TypeDescription> filter, TypePool typePool) {
/* 169 */       super(OpenedClassReader.ASM_API, classVisitor);
/* 170 */       this.typePool = typePool;
/* 171 */       this.strict = strict;
/* 172 */       this.filter = filter;
/* 173 */       this.observedTypes = new HashSet<String>();
/* 174 */       this.visitedInnerTypes = new HashSet<String>();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void visit(int version, int modifiers, String internalName, @MaybeNull String genericSignature, @MaybeNull String superClassInternalName, @MaybeNull String[] interfaceInternalName) {
/* 184 */       if (superClassInternalName != null) {
/* 185 */         this.observedTypes.add(superClassInternalName);
/*     */       }
/* 187 */       if (interfaceInternalName != null) {
/* 188 */         this.observedTypes.addAll(Arrays.asList(interfaceInternalName));
/*     */       }
/* 190 */       super.visit(version, modifiers, internalName, genericSignature, superClassInternalName, interfaceInternalName);
/*     */     }
/*     */ 
/*     */     
/*     */     public void visitNestHost(String nestHost) {
/* 195 */       this.observedTypes.add(nestHost);
/* 196 */       super.visitNestHost(nestHost);
/*     */     }
/*     */ 
/*     */     
/*     */     public void visitOuterClass(String ownerTypeInternalName, String methodName, String methodDescriptor) {
/* 201 */       this.observedTypes.add(ownerTypeInternalName);
/* 202 */       super.visitOuterClass(ownerTypeInternalName, methodName, methodDescriptor);
/*     */     }
/*     */ 
/*     */     
/*     */     public void visitNestMember(String nestMember) {
/* 207 */       this.observedTypes.add(nestMember);
/* 208 */       super.visitNestMember(nestMember);
/*     */     }
/*     */ 
/*     */     
/*     */     public void visitInnerClass(String internalName, String outerName, String innerName, int modifiers) {
/* 213 */       this.visitedInnerTypes.add(internalName);
/* 214 */       super.visitInnerClass(internalName, outerName, innerName, modifiers);
/*     */     }
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public RecordComponentVisitor visitRecordComponent(String name, String descriptor, @MaybeNull String signature) {
/* 220 */       this.observedTypes.add(Type.getType(descriptor).getInternalName());
/* 221 */       return super.visitRecordComponent(name, descriptor, signature);
/*     */     }
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/* 227 */       this.observedTypes.add(Type.getType(descriptor).getInternalName());
/* 228 */       AnnotationVisitor annotationVisitor = super.visitAnnotation(descriptor, visible);
/* 229 */       if (annotationVisitor != null) {
/* 230 */         return new TypeReferenceAnnotationVisitor(annotationVisitor);
/*     */       }
/* 232 */       return IGNORE_ANNOTATION;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public AnnotationVisitor visitTypeAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) {
/* 239 */       this.observedTypes.add(Type.getType(descriptor).getInternalName());
/* 240 */       AnnotationVisitor annotationVisitor = super.visitTypeAnnotation(typeReference, typePath, descriptor, visible);
/* 241 */       if (annotationVisitor != null) {
/* 242 */         return new TypeReferenceAnnotationVisitor(annotationVisitor);
/*     */       }
/* 244 */       return IGNORE_ANNOTATION;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public FieldVisitor visitField(int modifiers, String name, String descriptor, @MaybeNull String signature, @MaybeNull Object value) {
/* 251 */       FieldVisitor fieldVisitor = super.visitField(modifiers, name, descriptor, signature, value);
/* 252 */       if (fieldVisitor != null) {
/* 253 */         resolve(Type.getType(descriptor));
/* 254 */         return new TypeReferenceFieldVisitor(fieldVisitor);
/*     */       } 
/* 256 */       return IGNORE_FIELD;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public MethodVisitor visitMethod(int modifiers, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull String[] exceptionInternalName) {
/* 263 */       MethodVisitor methodVisitor = super.visitMethod(modifiers, internalName, descriptor, signature, exceptionInternalName);
/* 264 */       if (methodVisitor != null) {
/* 265 */         resolve(Type.getType(descriptor));
/* 266 */         if (exceptionInternalName != null) {
/* 267 */           this.observedTypes.addAll(Arrays.asList(exceptionInternalName));
/*     */         }
/* 269 */         return new TypeReferenceMethodVisitor(methodVisitor);
/*     */       } 
/* 271 */       return IGNORE_METHOD;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @SuppressFBWarnings(value = {"NP_NULL_ON_SOME_PATH_FROM_RETURN_VALUE"}, justification = "Assuming declaring type for type member.")
/*     */     public void visitEnd() {
/* 278 */       for (String observedType : this.observedTypes) {
/* 279 */         if (this.visitedInnerTypes.add(observedType)) {
/* 280 */           TypePool.Resolution resolution = this.typePool.describe(observedType.replace('/', '.'));
/* 281 */           if (resolution.isResolved()) {
/* 282 */             TypeDescription typeDescription = resolution.resolve();
/* 283 */             if (!this.filter.matches(typeDescription)) {
/* 284 */               label37: while (typeDescription != null && typeDescription.isNestedClass()) {
/* 285 */                 super.visitInnerClass(typeDescription.getInternalName(), 
/* 286 */                     typeDescription.isMemberType() ? typeDescription
/* 287 */                     .getDeclaringType().getInternalName() : null, 
/*     */                     
/* 289 */                     typeDescription.isAnonymousType() ? null : typeDescription
/*     */                     
/* 291 */                     .getSimpleName(), typeDescription
/* 292 */                     .getModifiers());
/*     */                 
/*     */                 try { while (true)
/* 295 */                   { typeDescription = typeDescription.getEnclosingType();
/* 296 */                     if (typeDescription != null) { if (this.visitedInnerTypes.add(typeDescription.getInternalName()))
/* 297 */                         continue label37;  continue; }  continue label37; }  } catch (RuntimeException exception)
/* 298 */                 { if (this.strict) {
/* 299 */                     throw exception;
/*     */                   } }
/*     */               
/*     */               } 
/*     */             }
/*     */             continue;
/*     */           } 
/* 306 */           if (this.strict) {
/* 307 */             throw new IllegalStateException("Could not locate type for: " + observedType.replace('/', '.'));
/*     */           }
/*     */         } 
/*     */       } 
/* 311 */       super.visitEnd();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void resolve(Type type) {
/* 320 */       if (type.getSort() == 11) {
/* 321 */         resolve(type.getReturnType());
/* 322 */         for (Type argumentType : type.getArgumentTypes()) {
/* 323 */           resolve(argumentType);
/*     */         }
/*     */       } else {
/* 326 */         while (type.getSort() == 9) {
/* 327 */           type = type.getElementType();
/*     */         }
/* 329 */         if (type.getSort() == 10) {
/* 330 */           this.observedTypes.add(type.getInternalName());
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void resolve(Handle handle) {
/* 341 */       this.observedTypes.add(handle.getOwner());
/* 342 */       Type methodType = Type.getType(handle.getDesc());
/* 343 */       resolve(methodType.getReturnType());
/* 344 */       for (Type type : methodType.getArgumentTypes()) {
/* 345 */         resolve(type);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void resolve(ConstantDynamic constant) {
/* 355 */       Type methodType = Type.getType(constant.getDescriptor());
/* 356 */       resolve(methodType.getReturnType());
/* 357 */       for (Type type : methodType.getArgumentTypes()) {
/* 358 */         resolve(type);
/*     */       }
/* 360 */       resolve(constant.getBootstrapMethod());
/* 361 */       for (int index = 0; index < constant.getBootstrapMethodArgumentCount(); index++) {
/* 362 */         resolve(constant.getBootstrapMethodArgument(index));
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void observeInternalName(String internalName) {
/* 372 */       int index = internalName.lastIndexOf('[');
/* 373 */       if (index != -1) {
/* 374 */         internalName = internalName.substring(index + 2, internalName.length() - 1);
/*     */       }
/* 376 */       this.observedTypes.add(internalName);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void resolve(Object value) {
/* 385 */       if (value instanceof Type) {
/* 386 */         resolve((Type)value);
/* 387 */       } else if (value instanceof Handle) {
/* 388 */         resolve((Handle)value);
/* 389 */       } else if (value instanceof ConstantDynamic) {
/* 390 */         resolve((ConstantDynamic)value);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected class TypeReferenceAnnotationVisitor
/*     */       extends AnnotationVisitor
/*     */     {
/*     */       protected TypeReferenceAnnotationVisitor(AnnotationVisitor annotationVisitor) {
/* 405 */         super(OpenedClassReader.ASM_API, annotationVisitor);
/*     */       }
/*     */ 
/*     */       
/*     */       public void visit(String name, Object value) {
/* 410 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.resolve(value);
/* 411 */         super.visit(name, value);
/*     */       }
/*     */ 
/*     */       
/*     */       public void visitEnum(String name, String descriptor, String value) {
/* 416 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.observedTypes.add(Type.getType(descriptor).getInternalName());
/* 417 */         super.visitEnum(name, descriptor, value);
/*     */       }
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visitAnnotation(String name, String descriptor) {
/* 423 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.observedTypes.add(Type.getType(descriptor).getInternalName());
/* 424 */         AnnotationVisitor annotationVisitor = super.visitAnnotation(name, descriptor);
/* 425 */         if (annotationVisitor != null) {
/* 426 */           return new TypeReferenceAnnotationVisitor(annotationVisitor);
/*     */         }
/* 428 */         return TypeReferenceAdjustment.TypeReferenceClassVisitor.IGNORE_ANNOTATION;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visitArray(String name) {
/* 435 */         AnnotationVisitor annotationVisitor = super.visitArray(name);
/* 436 */         if (annotationVisitor != null) {
/* 437 */           return new TypeReferenceAnnotationVisitor(annotationVisitor);
/*     */         }
/* 439 */         return TypeReferenceAdjustment.TypeReferenceClassVisitor.IGNORE_ANNOTATION;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected class TypeReferenceFieldVisitor
/*     */       extends FieldVisitor
/*     */     {
/*     */       protected TypeReferenceFieldVisitor(FieldVisitor fieldVisitor) {
/* 455 */         super(OpenedClassReader.ASM_API, fieldVisitor);
/*     */       }
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/* 461 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.observedTypes.add(Type.getType(descriptor).getInternalName());
/* 462 */         AnnotationVisitor annotationVisitor = super.visitAnnotation(descriptor, visible);
/* 463 */         if (annotationVisitor != null) {
/* 464 */           return new TypeReferenceAdjustment.TypeReferenceClassVisitor.TypeReferenceAnnotationVisitor(annotationVisitor);
/*     */         }
/* 466 */         return TypeReferenceAdjustment.TypeReferenceClassVisitor.IGNORE_ANNOTATION;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected class TypeReferenceMethodVisitor
/*     */       extends MethodVisitor
/*     */     {
/*     */       protected TypeReferenceMethodVisitor(MethodVisitor methodVisitor) {
/* 482 */         super(OpenedClassReader.ASM_API, methodVisitor);
/*     */       }
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visitAnnotationDefault() {
/* 488 */         AnnotationVisitor annotationVisitor = super.visitAnnotationDefault();
/* 489 */         if (annotationVisitor != null) {
/* 490 */           return new TypeReferenceAdjustment.TypeReferenceClassVisitor.TypeReferenceAnnotationVisitor(annotationVisitor);
/*     */         }
/* 492 */         return TypeReferenceAdjustment.TypeReferenceClassVisitor.IGNORE_ANNOTATION;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/* 499 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.observedTypes.add(Type.getType(descriptor).getInternalName());
/* 500 */         AnnotationVisitor annotationVisitor = super.visitAnnotation(descriptor, visible);
/* 501 */         if (annotationVisitor != null) {
/* 502 */           return new TypeReferenceAdjustment.TypeReferenceClassVisitor.TypeReferenceAnnotationVisitor(annotationVisitor);
/*     */         }
/* 504 */         return TypeReferenceAdjustment.TypeReferenceClassVisitor.IGNORE_ANNOTATION;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visitTypeAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) {
/* 511 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.observedTypes.add(Type.getType(descriptor).getInternalName());
/* 512 */         AnnotationVisitor annotationVisitor = super.visitTypeAnnotation(typeReference, typePath, descriptor, visible);
/* 513 */         if (annotationVisitor != null) {
/* 514 */           return new TypeReferenceAdjustment.TypeReferenceClassVisitor.TypeReferenceAnnotationVisitor(annotationVisitor);
/*     */         }
/* 516 */         return TypeReferenceAdjustment.TypeReferenceClassVisitor.IGNORE_ANNOTATION;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visitParameterAnnotation(int index, String descriptor, boolean visible) {
/* 523 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.observedTypes.add(Type.getType(descriptor).getInternalName());
/* 524 */         AnnotationVisitor annotationVisitor = super.visitParameterAnnotation(index, descriptor, visible);
/* 525 */         if (annotationVisitor != null) {
/* 526 */           return new TypeReferenceAdjustment.TypeReferenceClassVisitor.TypeReferenceAnnotationVisitor(annotationVisitor);
/*     */         }
/* 528 */         return TypeReferenceAdjustment.TypeReferenceClassVisitor.IGNORE_ANNOTATION;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visitInsnAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) {
/* 535 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.observedTypes.add(Type.getType(descriptor).getInternalName());
/* 536 */         AnnotationVisitor annotationVisitor = super.visitInsnAnnotation(typeReference, typePath, descriptor, visible);
/* 537 */         if (annotationVisitor != null) {
/* 538 */           return new TypeReferenceAdjustment.TypeReferenceClassVisitor.TypeReferenceAnnotationVisitor(annotationVisitor);
/*     */         }
/* 540 */         return TypeReferenceAdjustment.TypeReferenceClassVisitor.IGNORE_ANNOTATION;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visitTryCatchAnnotation(int typeReference, @MaybeNull TypePath typePath, String descriptor, boolean visible) {
/* 547 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.observedTypes.add(Type.getType(descriptor).getInternalName());
/* 548 */         AnnotationVisitor annotationVisitor = super.visitTryCatchAnnotation(typeReference, typePath, descriptor, visible);
/* 549 */         if (annotationVisitor != null) {
/* 550 */           return new TypeReferenceAdjustment.TypeReferenceClassVisitor.TypeReferenceAnnotationVisitor(annotationVisitor);
/*     */         }
/* 552 */         return TypeReferenceAdjustment.TypeReferenceClassVisitor.IGNORE_ANNOTATION;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       @MaybeNull
/*     */       public AnnotationVisitor visitLocalVariableAnnotation(int typeReference, @MaybeNull TypePath typePath, Label[] start, Label[] end, int[] offset, String descriptor, boolean visible) {
/* 565 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.observedTypes.add(Type.getType(descriptor).getInternalName());
/* 566 */         AnnotationVisitor annotationVisitor = super.visitLocalVariableAnnotation(typeReference, typePath, start, end, offset, descriptor, visible);
/* 567 */         if (annotationVisitor != null) {
/* 568 */           return new TypeReferenceAdjustment.TypeReferenceClassVisitor.TypeReferenceAnnotationVisitor(annotationVisitor);
/*     */         }
/* 570 */         return TypeReferenceAdjustment.TypeReferenceClassVisitor.IGNORE_ANNOTATION;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public void visitTypeInsn(int opcode, String internalName) {
/* 576 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.observeInternalName(internalName);
/* 577 */         super.visitTypeInsn(opcode, internalName);
/*     */       }
/*     */ 
/*     */       
/*     */       public void visitFieldInsn(int opcode, String ownerInternalName, String name, String descriptor) {
/* 582 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.observeInternalName(ownerInternalName);
/* 583 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.resolve(Type.getType(descriptor));
/* 584 */         super.visitFieldInsn(opcode, ownerInternalName, name, descriptor);
/*     */       }
/*     */ 
/*     */       
/*     */       public void visitMethodInsn(int opcode, String ownerInternalName, String name, String descriptor, boolean isInterface) {
/* 589 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.observeInternalName(ownerInternalName);
/* 590 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.resolve(Type.getType(descriptor));
/* 591 */         super.visitMethodInsn(opcode, ownerInternalName, name, descriptor, isInterface);
/*     */       }
/*     */ 
/*     */       
/*     */       public void visitInvokeDynamicInsn(String name, String descriptor, Handle handle, Object... argument) {
/* 596 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.resolve(Type.getType(descriptor));
/* 597 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.resolve(handle);
/* 598 */         for (Object anArgument : argument) {
/* 599 */           TypeReferenceAdjustment.TypeReferenceClassVisitor.this.resolve(anArgument);
/*     */         }
/* 601 */         super.visitInvokeDynamicInsn(name, descriptor, handle, argument);
/*     */       }
/*     */ 
/*     */       
/*     */       public void visitLdcInsn(Object value) {
/* 606 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.resolve(value);
/* 607 */         super.visitLdcInsn(value);
/*     */       }
/*     */ 
/*     */       
/*     */       public void visitMultiANewArrayInsn(String descriptor, int dimension) {
/* 612 */         TypeReferenceAdjustment.TypeReferenceClassVisitor.this.resolve(Type.getType(descriptor));
/* 613 */         super.visitMultiANewArrayInsn(descriptor, dimension);
/*     */       }
/*     */ 
/*     */       
/*     */       public void visitTryCatchBlock(Label start, Label end, Label handler, @MaybeNull String typeInternalName) {
/* 618 */         if (typeInternalName != null) {
/* 619 */           TypeReferenceAdjustment.TypeReferenceClassVisitor.this.observedTypes.add(typeInternalName);
/*     */         }
/* 621 */         super.visitTryCatchBlock(start, end, handler, typeInternalName);
/*     */       }
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\asm\TypeReferenceAdjustment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */