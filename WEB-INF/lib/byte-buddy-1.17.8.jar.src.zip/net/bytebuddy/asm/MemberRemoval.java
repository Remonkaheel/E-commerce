/*     */ package net.bytebuddy.asm;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.field.FieldList;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.jar.asm.FieldVisitor;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.pool.TypePool;
/*     */ import net.bytebuddy.utility.CompoundList;
/*     */ import net.bytebuddy.utility.OpenedClassReader;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class MemberRemoval
/*     */   extends AsmVisitorWrapper.AbstractBase
/*     */ {
/*     */   private final ElementMatcher.Junction<FieldDescription.InDefinedShape> fieldMatcher;
/*     */   private final ElementMatcher.Junction<MethodDescription> methodMatcher;
/*     */   
/*     */   public MemberRemoval() {
/*  72 */     this(ElementMatchers.none(), ElementMatchers.none());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MemberRemoval(ElementMatcher.Junction<FieldDescription.InDefinedShape> fieldMatcher, ElementMatcher.Junction<MethodDescription> methodMatcher) {
/*  83 */     this.fieldMatcher = fieldMatcher;
/*  84 */     this.methodMatcher = methodMatcher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MemberRemoval stripFields(ElementMatcher<? super FieldDescription.InDefinedShape> matcher) {
/*  94 */     return new MemberRemoval(this.fieldMatcher.or(matcher), this.methodMatcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MemberRemoval stripMethods(ElementMatcher<? super MethodDescription> matcher) {
/* 105 */     return stripInvokables((ElementMatcher<? super MethodDescription>)ElementMatchers.isMethod().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MemberRemoval stripConstructors(ElementMatcher<? super MethodDescription> matcher) {
/* 115 */     return stripInvokables((ElementMatcher<? super MethodDescription>)ElementMatchers.isConstructor().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MemberRemoval stripInvokables(ElementMatcher<? super MethodDescription> matcher) {
/* 126 */     return new MemberRemoval(this.fieldMatcher, this.methodMatcher.or(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassVisitor wrap(TypeDescription instrumentedType, ClassVisitor classVisitor, Implementation.Context implementationContext, TypePool typePool, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, int writerFlags, int readerFlags) {
/* 140 */     Map<String, FieldDescription.InDefinedShape> mappedFields = new HashMap<String, FieldDescription.InDefinedShape>();
/* 141 */     for (FieldDescription.InDefinedShape fieldDescription : fields) {
/* 142 */       mappedFields.put(fieldDescription.getInternalName() + fieldDescription.getDescriptor(), fieldDescription);
/*     */     }
/* 144 */     Map<String, MethodDescription> mappedMethods = new HashMap<String, MethodDescription>();
/* 145 */     for (MethodDescription methodDescription : CompoundList.of((List)methods, new MethodDescription.Latent.TypeInitializer(instrumentedType))) {
/* 146 */       mappedMethods.put(methodDescription.getInternalName() + methodDescription.getDescriptor(), methodDescription);
/*     */     }
/* 148 */     return new MemberRemovingClassVisitor(classVisitor, this.fieldMatcher, this.methodMatcher, mappedFields, mappedMethods);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.fieldMatcher.equals(((MemberRemoval)paramObject).fieldMatcher) ? false : (!!this.methodMatcher.equals(((MemberRemoval)paramObject).methodMatcher)))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*     */     return (getClass().hashCode() * 31 + this.fieldMatcher.hashCode()) * 31 + this.methodMatcher.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MemberRemovingClassVisitor
/*     */     extends ClassVisitor
/*     */   {
/*     */     private final ElementMatcher.Junction<FieldDescription.InDefinedShape> fieldMatcher;
/*     */ 
/*     */ 
/*     */     
/*     */     private final ElementMatcher.Junction<MethodDescription> methodMatcher;
/*     */ 
/*     */ 
/*     */     
/*     */     private final Map<String, FieldDescription.InDefinedShape> fields;
/*     */ 
/*     */ 
/*     */     
/*     */     private final Map<String, MethodDescription> methods;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MemberRemovingClassVisitor(ClassVisitor classVisitor, ElementMatcher.Junction<FieldDescription.InDefinedShape> fieldMatcher, ElementMatcher.Junction<MethodDescription> methodMatcher, Map<String, FieldDescription.InDefinedShape> fields, Map<String, MethodDescription> methods) {
/* 190 */       super(OpenedClassReader.ASM_API, classVisitor);
/* 191 */       this.fieldMatcher = fieldMatcher;
/* 192 */       this.methodMatcher = methodMatcher;
/* 193 */       this.fields = fields;
/* 194 */       this.methods = methods;
/*     */     }
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public FieldVisitor visitField(int modifiers, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull Object value) {
/* 200 */       FieldDescription.InDefinedShape fieldDescription = this.fields.get(internalName + descriptor);
/* 201 */       return (fieldDescription != null && this.fieldMatcher.matches(fieldDescription)) ? null : super
/*     */         
/* 203 */         .visitField(modifiers, internalName, descriptor, signature, value);
/*     */     }
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public MethodVisitor visitMethod(int modifiers, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull String[] exception) {
/* 209 */       MethodDescription methodDescription = this.methods.get(internalName + descriptor);
/* 210 */       return (methodDescription != null && this.methodMatcher.matches(methodDescription)) ? null : super
/*     */         
/* 212 */         .visitMethod(modifiers, internalName, descriptor, signature, exception);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\asm\MemberRemoval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */