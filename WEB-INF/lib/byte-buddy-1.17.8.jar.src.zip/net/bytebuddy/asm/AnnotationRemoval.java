/*     */ package net.bytebuddy.asm;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.annotation.AnnotationDescription;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.field.FieldList;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.description.method.ParameterDescription;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.jar.asm.AnnotationVisitor;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.jar.asm.FieldVisitor;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.pool.TypePool;
/*     */ import net.bytebuddy.utility.CompoundList;
/*     */ import net.bytebuddy.utility.OpenedClassReader;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class AnnotationRemoval
/*     */   extends AsmVisitorWrapper.AbstractBase
/*     */ {
/*     */   private static final int METHOD_NONE = -4;
/*     */   private static final int METHOD_ALL = -3;
/*     */   private static final int METHOD_ONLY = -2;
/*     */   private static final int METHOD_PARAMETERS = -1;
/*     */   private final boolean type;
/*     */   private final ElementMatcher<? super FieldDescription.InDefinedShape> fieldMatcher;
/*     */   private final ElementMatcher<? super MethodDescription> methodMatcher;
/*     */   private final ElementMatcher<? super AnnotationDescription> annotationMatcher;
/*     */   private final int parameters;
/*     */   
/*     */   protected AnnotationRemoval(boolean type, ElementMatcher<? super FieldDescription.InDefinedShape> fieldMatcher, ElementMatcher<? super MethodDescription> methodMatcher, ElementMatcher<? super AnnotationDescription> annotationMatcher, int parameters) {
/* 109 */     this.type = type;
/* 110 */     this.fieldMatcher = fieldMatcher;
/* 111 */     this.methodMatcher = methodMatcher;
/* 112 */     this.annotationMatcher = annotationMatcher;
/* 113 */     this.parameters = parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotationRemoval strip(ElementMatcher<? super AnnotationDescription> matcher) {
/* 123 */     return new AnnotationRemoval(true, (ElementMatcher<? super FieldDescription.InDefinedShape>)ElementMatchers.any(), (ElementMatcher<? super MethodDescription>)ElementMatchers.any(), matcher, -3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onType() {
/* 132 */     return new AnnotationRemoval(true, (ElementMatcher<? super FieldDescription.InDefinedShape>)ElementMatchers.none(), (ElementMatcher<? super MethodDescription>)ElementMatchers.none(), this.annotationMatcher, -4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onFields(ElementMatcher<? super FieldDescription> matcher) {
/* 142 */     return new AnnotationRemoval(false, (ElementMatcher)matcher, (ElementMatcher<? super MethodDescription>)ElementMatchers.none(), this.annotationMatcher, -4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onMethods(ElementMatcher<? super MethodDescription> matcher) {
/* 152 */     return onInvokables((ElementMatcher<? super MethodDescription>)ElementMatchers.isMethod().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onMethodsAndParameters(ElementMatcher<? super MethodDescription> matcher) {
/* 162 */     return onInvokablesAndParameters((ElementMatcher<? super MethodDescription>)ElementMatchers.isMethod().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onMethodParameters(ElementMatcher<? super MethodDescription> matcher) {
/* 172 */     return onInvokableParameters((ElementMatcher<? super MethodDescription>)ElementMatchers.isMethod().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onMethodParameter(ElementMatcher<? super MethodDescription> matcher, int parameter) {
/* 184 */     return onInvokableParameter((ElementMatcher<? super MethodDescription>)ElementMatchers.isMethod().and(matcher), parameter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onConstructors(ElementMatcher<? super MethodDescription> matcher) {
/* 194 */     return onInvokables((ElementMatcher<? super MethodDescription>)ElementMatchers.isConstructor().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onConstructorsAndParameters(ElementMatcher<? super MethodDescription> matcher) {
/* 204 */     return onInvokablesAndParameters((ElementMatcher<? super MethodDescription>)ElementMatchers.isConstructor().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onConstructorParameters(ElementMatcher<? super MethodDescription> matcher) {
/* 214 */     return onInvokableParameters((ElementMatcher<? super MethodDescription>)ElementMatchers.isConstructor().and(matcher));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onConstructorParameter(ElementMatcher<? super MethodDescription> matcher, int parameter) {
/* 226 */     return onInvokableParameter((ElementMatcher<? super MethodDescription>)ElementMatchers.isConstructor().and(matcher), parameter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onInvokables(ElementMatcher<? super MethodDescription> matcher) {
/* 236 */     return new AnnotationRemoval(false, (ElementMatcher<? super FieldDescription.InDefinedShape>)ElementMatchers.none(), matcher, this.annotationMatcher, -2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onInvokablesAndParameters(ElementMatcher<? super MethodDescription> matcher) {
/* 247 */     return new AnnotationRemoval(false, (ElementMatcher<? super FieldDescription.InDefinedShape>)ElementMatchers.none(), matcher, this.annotationMatcher, -3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onInvokableParameters(ElementMatcher<? super MethodDescription> matcher) {
/* 258 */     return new AnnotationRemoval(false, (ElementMatcher<? super FieldDescription.InDefinedShape>)ElementMatchers.none(), matcher, this.annotationMatcher, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsmVisitorWrapper onInvokableParameter(ElementMatcher<? super MethodDescription> matcher, int parameter) {
/* 270 */     if (parameter < 0) {
/* 271 */       throw new IllegalArgumentException("Parameter index cannot be negative: " + parameter);
/*     */     }
/* 273 */     return new AnnotationRemoval(false, (ElementMatcher<? super FieldDescription.InDefinedShape>)ElementMatchers.none(), matcher, this.annotationMatcher, parameter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassVisitor wrap(TypeDescription instrumentedType, ClassVisitor classVisitor, Implementation.Context implementationContext, TypePool typePool, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, int writerFlags, int readerFlags) {
/* 287 */     Map<String, AnnotationDescription> mappedAnnotations = new HashMap<String, AnnotationDescription>();
/* 288 */     if (this.type) {
/* 289 */       for (AnnotationDescription annotation : instrumentedType.getDeclaredAnnotations()) {
/* 290 */         mappedAnnotations.put(annotation.getAnnotationType().getDescriptor(), annotation);
/*     */       }
/*     */     }
/* 293 */     Map<String, FieldDescription.InDefinedShape> mappedFields = new HashMap<String, FieldDescription.InDefinedShape>();
/* 294 */     for (FieldDescription.InDefinedShape fieldDescription : fields) {
/* 295 */       mappedFields.put(fieldDescription.getInternalName() + fieldDescription.getDescriptor(), fieldDescription);
/*     */     }
/* 297 */     Map<String, MethodDescription> mappedMethods = new HashMap<String, MethodDescription>();
/* 298 */     for (MethodDescription methodDescription : CompoundList.of((List)methods, new MethodDescription.Latent.TypeInitializer(instrumentedType))) {
/* 299 */       mappedMethods.put(methodDescription.getInternalName() + methodDescription.getDescriptor(), methodDescription);
/*     */     }
/* 301 */     return new AnnotationRemovingClassVisitor(classVisitor, this.fieldMatcher, this.methodMatcher, this.annotationMatcher, this.parameters, mappedFields, mappedMethods, mappedAnnotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : ((this.type != ((AnnotationRemoval)paramObject).type) ? false : ((this.parameters != ((AnnotationRemoval)paramObject).parameters) ? false : (!this.fieldMatcher.equals(((AnnotationRemoval)paramObject).fieldMatcher) ? false : (!this.methodMatcher.equals(((AnnotationRemoval)paramObject).methodMatcher) ? false : (!!this.annotationMatcher.equals(((AnnotationRemoval)paramObject).annotationMatcher))))))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*     */     return ((((getClass().hashCode() * 31 + this.type) * 31 + this.fieldMatcher.hashCode()) * 31 + this.methodMatcher.hashCode()) * 31 + this.annotationMatcher.hashCode()) * 31 + this.parameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AnnotationRemovingClassVisitor
/*     */     extends ClassVisitor
/*     */   {
/*     */     private final ElementMatcher<? super FieldDescription.InDefinedShape> fieldMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final ElementMatcher<? super MethodDescription> methodMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final ElementMatcher<? super AnnotationDescription> annotationMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int parameters;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Map<String, FieldDescription.InDefinedShape> fields;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Map<String, MethodDescription> methods;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Map<String, AnnotationDescription> annotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private AnnotationRemovingClassVisitor(ClassVisitor classVisitor, ElementMatcher<? super FieldDescription.InDefinedShape> fieldMatcher, ElementMatcher<? super MethodDescription> methodMatcher, ElementMatcher<? super AnnotationDescription> annotationMatcher, int parameters, Map<String, FieldDescription.InDefinedShape> fields, Map<String, MethodDescription> methods, Map<String, AnnotationDescription> annotations) {
/* 366 */       super(OpenedClassReader.ASM_API, classVisitor);
/* 367 */       this.fieldMatcher = fieldMatcher;
/* 368 */       this.methodMatcher = methodMatcher;
/* 369 */       this.annotationMatcher = annotationMatcher;
/* 370 */       this.parameters = parameters;
/* 371 */       this.fields = fields;
/* 372 */       this.methods = methods;
/* 373 */       this.annotations = annotations;
/*     */     }
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/* 379 */       AnnotationDescription annotation = this.annotations.get(descriptor);
/* 380 */       return (annotation != null && this.annotationMatcher.matches(annotation)) ? null : super
/*     */         
/* 382 */         .visitAnnotation(descriptor, visible);
/*     */     }
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public FieldVisitor visitField(int modifiers, String internalName, String descriptor, String signature, Object value) {
/* 388 */       FieldVisitor fieldVisitor = super.visitField(modifiers, internalName, descriptor, signature, value);
/* 389 */       if (fieldVisitor == null) {
/* 390 */         return null;
/*     */       }
/* 392 */       FieldDescription.InDefinedShape fieldDescription = this.fields.get(internalName + descriptor);
/* 393 */       if (fieldDescription != null && this.fieldMatcher.matches(fieldDescription)) {
/* 394 */         Map<String, AnnotationDescription> mappedAnnotations = new HashMap<String, AnnotationDescription>();
/* 395 */         for (AnnotationDescription annotation : fieldDescription.getDeclaredAnnotations()) {
/* 396 */           mappedAnnotations.put(annotation.getAnnotationType().getDescriptor(), annotation);
/*     */         }
/* 398 */         return new AnnotationRemoval.AnnotationRemovingFieldVisitor(fieldVisitor, this.annotationMatcher, mappedAnnotations);
/*     */       } 
/* 400 */       return fieldVisitor;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public MethodVisitor visitMethod(int modifiers, String internalName, String descriptor, String signature, String[] exception) {
/* 407 */       MethodVisitor methodVisitor = super.visitMethod(modifiers, internalName, descriptor, signature, exception);
/* 408 */       if (methodVisitor == null) {
/* 409 */         return null;
/*     */       }
/* 411 */       MethodDescription methodDescription = this.methods.get(internalName + descriptor);
/* 412 */       if (methodDescription != null && this.methodMatcher.matches(methodDescription)) {
/* 413 */         Map<Integer, Map<String, AnnotationDescription>> mappedParameterAnnotations = new HashMap<Integer, Map<String, AnnotationDescription>>();
/* 414 */         if (this.parameters >= 0 || this.parameters == -1 || this.parameters == -3) {
/* 415 */           for (ParameterDescription parameter : methodDescription.getParameters()) {
/* 416 */             Map<String, AnnotationDescription> map = new HashMap<String, AnnotationDescription>();
/* 417 */             if (parameter.getIndex() == this.parameters || this.parameters < 0) {
/* 418 */               for (AnnotationDescription annotation : parameter.getDeclaredAnnotations()) {
/* 419 */                 map.put(annotation.getAnnotationType().getDescriptor(), annotation);
/*     */               }
/*     */             }
/* 422 */             mappedParameterAnnotations.put(Integer.valueOf(parameter.getIndex()), map);
/*     */           } 
/*     */         }
/* 425 */         Map<String, AnnotationDescription> mappedAnnotations = new HashMap<String, AnnotationDescription>();
/* 426 */         if (this.parameters == -2 || this.parameters == -3) {
/* 427 */           for (AnnotationDescription annotation : methodDescription.getDeclaredAnnotations()) {
/* 428 */             mappedAnnotations.put(annotation.getAnnotationType().getDescriptor(), annotation);
/*     */           }
/*     */         }
/* 431 */         return new AnnotationRemoval.AnnotationRemovingMethodVisitor(methodVisitor, this.annotationMatcher, mappedParameterAnnotations, mappedAnnotations);
/*     */       } 
/* 433 */       return methodVisitor;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AnnotationRemovingFieldVisitor
/*     */     extends FieldVisitor
/*     */   {
/*     */     private final ElementMatcher<? super AnnotationDescription> annotationMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Map<String, AnnotationDescription> annotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private AnnotationRemovingFieldVisitor(FieldVisitor fieldVisitor, ElementMatcher<? super AnnotationDescription> annotationMatcher, Map<String, AnnotationDescription> annotations) {
/* 463 */       super(OpenedClassReader.ASM_API, fieldVisitor);
/* 464 */       this.annotationMatcher = annotationMatcher;
/* 465 */       this.annotations = annotations;
/*     */     }
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/* 471 */       AnnotationDescription annotation = this.annotations.get(descriptor);
/* 472 */       return (annotation != null && this.annotationMatcher.matches(annotation)) ? null : super
/*     */         
/* 474 */         .visitAnnotation(descriptor, visible);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AnnotationRemovingMethodVisitor
/*     */     extends MethodVisitor
/*     */   {
/*     */     private final ElementMatcher<? super AnnotationDescription> annotationMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Map<Integer, Map<String, AnnotationDescription>> parameterAnnotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Map<String, AnnotationDescription> annotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private AnnotationRemovingMethodVisitor(MethodVisitor methodVisitor, ElementMatcher<? super AnnotationDescription> annotationMatcher, Map<Integer, Map<String, AnnotationDescription>> parameterAnnotations, Map<String, AnnotationDescription> annotations) {
/* 512 */       super(OpenedClassReader.ASM_API, methodVisitor);
/* 513 */       this.annotationMatcher = annotationMatcher;
/* 514 */       this.parameterAnnotations = parameterAnnotations;
/* 515 */       this.annotations = annotations;
/*     */     }
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public AnnotationVisitor visitParameterAnnotation(int parameter, String descriptor, boolean visible) {
/* 521 */       Map<String, AnnotationDescription> annotations = this.parameterAnnotations.get(Integer.valueOf(parameter));
/* 522 */       if (annotations != null) {
/* 523 */         AnnotationDescription annotation = annotations.get(descriptor);
/* 524 */         return (annotation != null && this.annotationMatcher.matches(annotation)) ? null : super
/*     */           
/* 526 */           .visitParameterAnnotation(parameter, descriptor, visible);
/*     */       } 
/* 528 */       return super.visitParameterAnnotation(parameter, descriptor, visible);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public AnnotationVisitor visitAnnotation(String descriptor, boolean visible) {
/* 535 */       AnnotationDescription annotation = this.annotations.get(descriptor);
/* 536 */       return (annotation != null && this.annotationMatcher.matches(annotation)) ? null : super
/*     */         
/* 538 */         .visitAnnotation(descriptor, visible);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\asm\AnnotationRemoval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */