/*     */ package net.bytebuddy.asm;
/*     */ 
/*     */ import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
/*     */ import net.bytebuddy.ClassFileVersion;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.field.FieldList;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.jar.asm.Type;
/*     */ import net.bytebuddy.pool.TypePool;
/*     */ import net.bytebuddy.utility.OpenedClassReader;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum TypeConstantAdjustment
/*     */   implements AsmVisitorWrapper
/*     */ {
/*  48 */   INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int mergeWriter(int flags) {
/*  54 */     return flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int mergeReader(int flags) {
/*  61 */     return flags;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassVisitor wrap(TypeDescription instrumentedType, ClassVisitor classVisitor, Implementation.Context implementationContext, TypePool typePool, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, int writerFlags, int readerFlags) {
/*  75 */     return new TypeConstantDissolvingClassVisitor(classVisitor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class TypeConstantDissolvingClassVisitor
/*     */     extends ClassVisitor
/*     */   {
/*     */     private boolean supportsTypeConstants;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected TypeConstantDissolvingClassVisitor(ClassVisitor classVisitor) {
/*  95 */       super(OpenedClassReader.ASM_API, classVisitor);
/*     */     }
/*     */ 
/*     */     
/*     */     public void visit(int version, int modifiers, String name, @MaybeNull String signature, @MaybeNull String superClassName, @MaybeNull String[] interfaceName) {
/* 100 */       this.supportsTypeConstants = ClassFileVersion.ofMinorMajor(version).isAtLeast(ClassFileVersion.JAVA_V5);
/* 101 */       super.visit(version, modifiers, name, signature, superClassName, interfaceName);
/*     */     }
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public MethodVisitor visitMethod(int modifiers, String name, String descriptor, @MaybeNull String signature, @MaybeNull String[] exception) {
/* 107 */       MethodVisitor methodVisitor = super.visitMethod(modifiers, name, descriptor, signature, exception);
/* 108 */       return (this.supportsTypeConstants || methodVisitor == null) ? methodVisitor : new TypeConstantDissolvingMethodVisitor(methodVisitor);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static class TypeConstantDissolvingMethodVisitor
/*     */       extends MethodVisitor
/*     */     {
/*     */       private static final String JAVA_LANG_CLASS = "java/lang/Class";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private static final String FOR_NAME = "forName";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private static final String DESCRIPTOR = "(Ljava/lang/String;)Ljava/lang/Class;";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       protected TypeConstantDissolvingMethodVisitor(MethodVisitor methodVisitor) {
/* 139 */         super(OpenedClassReader.ASM_API, methodVisitor);
/*     */       }
/*     */ 
/*     */       
/*     */       @SuppressFBWarnings(value = {"SF_SWITCH_NO_DEFAULT"}, justification = "Fall through to default case is intentional.")
/*     */       public void visitLdcInsn(Object value) {
/* 145 */         if (value instanceof Type) {
/* 146 */           Type type = (Type)value;
/* 147 */           switch (type.getSort()) {
/*     */             case 9:
/*     */             case 10:
/* 150 */               super.visitLdcInsn(type.getInternalName().replace('/', '.'));
/* 151 */               visitMethodInsn(184, "java/lang/Class", "forName", "(Ljava/lang/String;)Ljava/lang/Class;", false);
/*     */               return;
/*     */           } 
/*     */         } 
/* 155 */         super.visitLdcInsn(value);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\asm\TypeConstantAdjustment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */