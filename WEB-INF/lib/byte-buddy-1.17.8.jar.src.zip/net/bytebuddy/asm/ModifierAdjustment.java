/*     */ package net.bytebuddy.asm;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*     */ import net.bytebuddy.description.field.FieldDescription;
/*     */ import net.bytebuddy.description.field.FieldList;
/*     */ import net.bytebuddy.description.method.MethodDescription;
/*     */ import net.bytebuddy.description.method.MethodList;
/*     */ import net.bytebuddy.description.modifier.ModifierContributor;
/*     */ import net.bytebuddy.description.type.TypeDescription;
/*     */ import net.bytebuddy.implementation.Implementation;
/*     */ import net.bytebuddy.jar.asm.ClassVisitor;
/*     */ import net.bytebuddy.jar.asm.FieldVisitor;
/*     */ import net.bytebuddy.jar.asm.MethodVisitor;
/*     */ import net.bytebuddy.matcher.ElementMatcher;
/*     */ import net.bytebuddy.matcher.ElementMatchers;
/*     */ import net.bytebuddy.pool.TypePool;
/*     */ import net.bytebuddy.utility.CompoundList;
/*     */ import net.bytebuddy.utility.OpenedClassReader;
/*     */ import net.bytebuddy.utility.nullability.MaybeNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Enhance
/*     */ public class ModifierAdjustment
/*     */   extends AsmVisitorWrapper.AbstractBase
/*     */ {
/*     */   private final List<Adjustment<TypeDescription>> typeAdjustments;
/*     */   private final List<Adjustment<FieldDescription.InDefinedShape>> fieldAdjustments;
/*     */   private final List<Adjustment<MethodDescription>> methodAdjustments;
/*     */   
/*     */   public ModifierAdjustment() {
/*  73 */     this(Collections.emptyList(), 
/*  74 */         Collections.emptyList(), 
/*  75 */         Collections.emptyList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ModifierAdjustment(List<Adjustment<TypeDescription>> typeAdjustments, List<Adjustment<FieldDescription.InDefinedShape>> fieldAdjustments, List<Adjustment<MethodDescription>> methodAdjustments) {
/*  88 */     this.typeAdjustments = typeAdjustments;
/*  89 */     this.fieldAdjustments = fieldAdjustments;
/*  90 */     this.methodAdjustments = methodAdjustments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withTypeModifiers(ModifierContributor.ForType... modifierContributor) {
/* 100 */     return withTypeModifiers(Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withTypeModifiers(List<? extends ModifierContributor.ForType> modifierContributors) {
/* 110 */     return withTypeModifiers((ElementMatcher<? super TypeDescription>)ElementMatchers.any(), modifierContributors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withTypeModifiers(ElementMatcher<? super TypeDescription> matcher, ModifierContributor.ForType... modifierContributor) {
/* 122 */     return withTypeModifiers(matcher, Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withTypeModifiers(ElementMatcher<? super TypeDescription> matcher, List<? extends ModifierContributor.ForType> modifierContributors) {
/* 134 */     return new ModifierAdjustment(CompoundList.of(new Adjustment<TypeDescription>(matcher, 
/* 135 */             ModifierContributor.Resolver.of(modifierContributors)), this.typeAdjustments), this.fieldAdjustments, this.methodAdjustments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withFieldModifiers(ModifierContributor.ForField... modifierContributor) {
/* 145 */     return withFieldModifiers(Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withFieldModifiers(List<? extends ModifierContributor.ForField> modifierContributors) {
/* 155 */     return withFieldModifiers((ElementMatcher<? super FieldDescription.InDefinedShape>)ElementMatchers.any(), modifierContributors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withFieldModifiers(ElementMatcher<? super FieldDescription.InDefinedShape> matcher, ModifierContributor.ForField... modifierContributor) {
/* 167 */     return withFieldModifiers(matcher, Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withFieldModifiers(ElementMatcher<? super FieldDescription.InDefinedShape> matcher, List<? extends ModifierContributor.ForField> modifierContributors) {
/* 179 */     return new ModifierAdjustment(this.typeAdjustments, CompoundList.of(new Adjustment<FieldDescription.InDefinedShape>(matcher, 
/* 180 */             ModifierContributor.Resolver.of(modifierContributors)), this.fieldAdjustments), this.methodAdjustments);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withMethodModifiers(ModifierContributor.ForMethod... modifierContributor) {
/* 190 */     return withMethodModifiers(Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withMethodModifiers(List<? extends ModifierContributor.ForMethod> modifierContributors) {
/* 200 */     return withMethodModifiers((ElementMatcher<? super MethodDescription>)ElementMatchers.any(), modifierContributors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withMethodModifiers(ElementMatcher<? super MethodDescription> matcher, ModifierContributor.ForMethod... modifierContributor) {
/* 212 */     return withMethodModifiers(matcher, Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withMethodModifiers(ElementMatcher<? super MethodDescription> matcher, List<? extends ModifierContributor.ForMethod> modifierContributors) {
/* 224 */     return withInvokableModifiers((ElementMatcher<? super MethodDescription>)ElementMatchers.isMethod().and(matcher), modifierContributors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withConstructorModifiers(ModifierContributor.ForMethod... modifierContributor) {
/* 234 */     return withConstructorModifiers(Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withConstructorModifiers(List<? extends ModifierContributor.ForMethod> modifierContributors) {
/* 244 */     return withConstructorModifiers((ElementMatcher<? super MethodDescription>)ElementMatchers.any(), modifierContributors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withConstructorModifiers(ElementMatcher<? super MethodDescription> matcher, ModifierContributor.ForMethod... modifierContributor) {
/* 256 */     return withConstructorModifiers(matcher, Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withConstructorModifiers(ElementMatcher<? super MethodDescription> matcher, List<? extends ModifierContributor.ForMethod> modifierContributors) {
/* 268 */     return withInvokableModifiers((ElementMatcher<? super MethodDescription>)ElementMatchers.isConstructor().and(matcher), modifierContributors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withInvokableModifiers(ModifierContributor.ForMethod... modifierContributor) {
/* 278 */     return withInvokableModifiers(Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withInvokableModifiers(List<? extends ModifierContributor.ForMethod> modifierContributors) {
/* 288 */     return withInvokableModifiers((ElementMatcher<? super MethodDescription>)ElementMatchers.any(), modifierContributors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withInvokableModifiers(ElementMatcher<? super MethodDescription> matcher, ModifierContributor.ForMethod... modifierContributor) {
/* 300 */     return withInvokableModifiers(matcher, Arrays.asList(modifierContributor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustment withInvokableModifiers(ElementMatcher<? super MethodDescription> matcher, List<? extends ModifierContributor.ForMethod> modifierContributors) {
/* 312 */     return new ModifierAdjustment(this.typeAdjustments, this.fieldAdjustments, CompoundList.of(new Adjustment<MethodDescription>(matcher, 
/* 313 */             ModifierContributor.Resolver.of(modifierContributors)), this.methodAdjustments));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ModifierAdjustingClassVisitor wrap(TypeDescription instrumentedType, ClassVisitor classVisitor, Implementation.Context implementationContext, TypePool typePool, FieldList<FieldDescription.InDefinedShape> fields, MethodList<?> methods, int writerFlags, int readerFlags) {
/* 327 */     Map<String, FieldDescription.InDefinedShape> mappedFields = new HashMap<String, FieldDescription.InDefinedShape>();
/* 328 */     for (FieldDescription.InDefinedShape fieldDescription : fields) {
/* 329 */       mappedFields.put(fieldDescription.getInternalName() + fieldDescription.getDescriptor(), fieldDescription);
/*     */     }
/* 331 */     Map<String, MethodDescription> mappedMethods = new HashMap<String, MethodDescription>();
/* 332 */     for (MethodDescription methodDescription : CompoundList.of((List)methods, new MethodDescription.Latent.TypeInitializer(instrumentedType))) {
/* 333 */       mappedMethods.put(methodDescription.getInternalName() + methodDescription.getDescriptor(), methodDescription);
/*     */     }
/* 335 */     return new ModifierAdjustingClassVisitor(classVisitor, this.typeAdjustments, this.fieldAdjustments, this.methodAdjustments, instrumentedType, mappedFields, mappedMethods);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(@MaybeNull Object paramObject) {
/*     */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!this.typeAdjustments.equals(((ModifierAdjustment)paramObject).typeAdjustments) ? false : (!this.fieldAdjustments.equals(((ModifierAdjustment)paramObject).fieldAdjustments) ? false : (!!this.methodAdjustments.equals(((ModifierAdjustment)paramObject).methodAdjustments))))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*     */     return ((getClass().hashCode() * 31 + this.typeAdjustments.hashCode()) * 31 + this.fieldAdjustments.hashCode()) * 31 + this.methodAdjustments.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Enhance
/*     */   protected static class Adjustment<T>
/*     */     implements ElementMatcher<T>
/*     */   {
/*     */     private final ElementMatcher<? super T> matcher;
/*     */ 
/*     */ 
/*     */     
/*     */     private final ModifierContributor.Resolver<?> resolver;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Adjustment(ElementMatcher<? super T> matcher, ModifierContributor.Resolver<?> resolver) {
/* 369 */       this.matcher = matcher;
/* 370 */       this.resolver = resolver;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean matches(@MaybeNull T target) {
/* 377 */       return this.matcher.matches(target);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected int resolve(int modifiers) {
/* 387 */       return this.resolver.resolve(modifiers);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(@MaybeNull Object param1Object) {
/*     */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.matcher.equals(((Adjustment)param1Object).matcher) ? false : (!!this.resolver.equals(((Adjustment)param1Object).resolver)))));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*     */       return (getClass().hashCode() * 31 + this.matcher.hashCode()) * 31 + this.resolver.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class ModifierAdjustingClassVisitor
/*     */     extends ClassVisitor
/*     */   {
/*     */     private final List<ModifierAdjustment.Adjustment<TypeDescription>> typeAdjustments;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<ModifierAdjustment.Adjustment<FieldDescription.InDefinedShape>> fieldAdjustments;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final List<ModifierAdjustment.Adjustment<MethodDescription>> methodAdjustments;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final TypeDescription instrumentedType;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Map<String, FieldDescription.InDefinedShape> fields;
/*     */ 
/*     */ 
/*     */     
/*     */     private final Map<String, MethodDescription> methods;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected ModifierAdjustingClassVisitor(ClassVisitor classVisitor, List<ModifierAdjustment.Adjustment<TypeDescription>> typeAdjustments, List<ModifierAdjustment.Adjustment<FieldDescription.InDefinedShape>> fieldAdjustments, List<ModifierAdjustment.Adjustment<MethodDescription>> methodAdjustments, TypeDescription instrumentedType, Map<String, FieldDescription.InDefinedShape> fields, Map<String, MethodDescription> methods) {
/* 444 */       super(OpenedClassReader.ASM_API, classVisitor);
/* 445 */       this.typeAdjustments = typeAdjustments;
/* 446 */       this.fieldAdjustments = fieldAdjustments;
/* 447 */       this.methodAdjustments = methodAdjustments;
/* 448 */       this.instrumentedType = instrumentedType;
/* 449 */       this.fields = fields;
/* 450 */       this.methods = methods;
/*     */     }
/*     */ 
/*     */     
/*     */     public void visit(int version, int modifiers, String internalName, @MaybeNull String signature, @MaybeNull String superClassName, @MaybeNull String[] interfaceName) {
/* 455 */       for (ModifierAdjustment.Adjustment<TypeDescription> adjustment : this.typeAdjustments) {
/* 456 */         if (adjustment.matches(this.instrumentedType)) {
/* 457 */           modifiers = adjustment.resolve(modifiers);
/*     */           break;
/*     */         } 
/*     */       } 
/* 461 */       super.visit(version, modifiers, internalName, signature, superClassName, interfaceName);
/*     */     }
/*     */ 
/*     */     
/*     */     public void visitInnerClass(String internalName, @MaybeNull String outerName, @MaybeNull String innerName, int modifiers) {
/* 466 */       if (this.instrumentedType.getInternalName().equals(internalName)) {
/* 467 */         for (ModifierAdjustment.Adjustment<TypeDescription> adjustment : this.typeAdjustments) {
/* 468 */           if (adjustment.matches(this.instrumentedType)) {
/* 469 */             modifiers = adjustment.resolve(modifiers);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 474 */       super.visitInnerClass(internalName, outerName, innerName, modifiers);
/*     */     }
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public FieldVisitor visitField(int modifiers, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull Object value) {
/* 480 */       FieldDescription.InDefinedShape fieldDescription = this.fields.get(internalName + descriptor);
/* 481 */       if (fieldDescription != null) {
/* 482 */         for (ModifierAdjustment.Adjustment<FieldDescription.InDefinedShape> adjustment : this.fieldAdjustments) {
/* 483 */           if (adjustment.matches(fieldDescription)) {
/* 484 */             modifiers = adjustment.resolve(modifiers);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 489 */       return super.visitField(modifiers, internalName, descriptor, signature, value);
/*     */     }
/*     */ 
/*     */     
/*     */     @MaybeNull
/*     */     public MethodVisitor visitMethod(int modifiers, String internalName, String descriptor, @MaybeNull String signature, @MaybeNull String[] exception) {
/* 495 */       MethodDescription methodDescription = this.methods.get(internalName + descriptor);
/* 496 */       if (methodDescription != null) {
/* 497 */         for (ModifierAdjustment.Adjustment<MethodDescription> adjustment : this.methodAdjustments) {
/* 498 */           if (adjustment.matches(methodDescription)) {
/* 499 */             modifiers = adjustment.resolve(modifiers);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/* 504 */       return super.visitMethod(modifiers, internalName, descriptor, signature, exception);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\asm\ModifierAdjustment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */