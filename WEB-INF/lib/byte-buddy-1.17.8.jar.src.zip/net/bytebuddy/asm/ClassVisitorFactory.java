/*      */ package net.bytebuddy.asm;
/*      */ 
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Type;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import net.bytebuddy.ByteBuddy;
/*      */ import net.bytebuddy.build.AccessControllerPlugin.Enhance;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.Enhance;
/*      */ import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling;
/*      */ import net.bytebuddy.description.field.FieldDescription;
/*      */ import net.bytebuddy.description.method.MethodDescription;
/*      */ import net.bytebuddy.description.method.MethodList;
/*      */ import net.bytebuddy.description.modifier.FieldManifestation;
/*      */ import net.bytebuddy.description.modifier.ModifierContributor;
/*      */ import net.bytebuddy.description.modifier.Ownership;
/*      */ import net.bytebuddy.description.modifier.Visibility;
/*      */ import net.bytebuddy.description.type.TypeDefinition;
/*      */ import net.bytebuddy.description.type.TypeDescription;
/*      */ import net.bytebuddy.dynamic.DynamicType;
/*      */ import net.bytebuddy.dynamic.loading.MultipleParentClassLoader;
/*      */ import net.bytebuddy.dynamic.scaffold.TypeValidation;
/*      */ import net.bytebuddy.dynamic.scaffold.subclass.ConstructorStrategy;
/*      */ import net.bytebuddy.implementation.ExceptionMethod;
/*      */ import net.bytebuddy.implementation.FieldAccessor;
/*      */ import net.bytebuddy.implementation.Implementation;
/*      */ import net.bytebuddy.implementation.MethodCall;
/*      */ import net.bytebuddy.implementation.bytecode.ByteCodeAppender;
/*      */ import net.bytebuddy.implementation.bytecode.Duplication;
/*      */ import net.bytebuddy.implementation.bytecode.StackManipulation;
/*      */ import net.bytebuddy.implementation.bytecode.TypeCreation;
/*      */ import net.bytebuddy.implementation.bytecode.assign.Assigner;
/*      */ import net.bytebuddy.implementation.bytecode.member.FieldAccess;
/*      */ import net.bytebuddy.implementation.bytecode.member.MethodInvocation;
/*      */ import net.bytebuddy.implementation.bytecode.member.MethodReturn;
/*      */ import net.bytebuddy.implementation.bytecode.member.MethodVariableAccess;
/*      */ import net.bytebuddy.jar.asm.AnnotationVisitor;
/*      */ import net.bytebuddy.jar.asm.Attribute;
/*      */ import net.bytebuddy.jar.asm.ClassVisitor;
/*      */ import net.bytebuddy.jar.asm.ConstantDynamic;
/*      */ import net.bytebuddy.jar.asm.FieldVisitor;
/*      */ import net.bytebuddy.jar.asm.Handle;
/*      */ import net.bytebuddy.jar.asm.Label;
/*      */ import net.bytebuddy.jar.asm.MethodVisitor;
/*      */ import net.bytebuddy.jar.asm.ModuleVisitor;
/*      */ import net.bytebuddy.jar.asm.RecordComponentVisitor;
/*      */ import net.bytebuddy.jar.asm.Type;
/*      */ import net.bytebuddy.jar.asm.TypePath;
/*      */ import net.bytebuddy.matcher.ElementMatcher;
/*      */ import net.bytebuddy.matcher.ElementMatchers;
/*      */ import net.bytebuddy.utility.CompoundList;
/*      */ import net.bytebuddy.utility.OpenedClassReader;
/*      */ import net.bytebuddy.utility.nullability.MaybeNull;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @Enhance
/*      */ public abstract class ClassVisitorFactory<T>
/*      */ {
/*      */   private static final String DELEGATE = "delegate";
/*      */   private static final String LABELS = "labels";
/*      */   private static final String WRAP = "wrap";
/*      */   private final Class<?> type;
/*      */   private static final boolean ACCESS_CONTROLLER;
/*      */   
/*      */   protected ClassVisitorFactory(Class<?> type) {
/*   95 */     this.type = type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?> getType() {
/*  104 */     return this.type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <S> ClassVisitorFactory<S> of(Class<S> classVisitor) {
/*  115 */     return of(classVisitor, (new ByteBuddy()).with(TypeValidation.DISABLED));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <S> ClassVisitorFactory<S> of(Class<S> classVisitor, ByteBuddy byteBuddy) {
/*  127 */     return doPrivileged(new CreateClassVisitorFactory<S>(classVisitor, byteBuddy));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   private static <T> T doPrivileged(PrivilegedAction<T> action) {
/*  139 */     return ACCESS_CONTROLLER ? AccessController.doPrivileged((PrivilegedAction<T>)SYNTHETIC_LOCAL_VARIABLE_0) : SYNTHETIC_LOCAL_VARIABLE_0.run();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static DynamicType.Builder<?> toVisitorBuilder(ByteBuddy byteBuddy, Class<?> sourceVisitor, Class<?> targetVisitor, @MaybeNull Class<?> sourceTypePath, @MaybeNull Class<?> targetTypePath, Implementation appendix) throws Exception {
/*  170 */     DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition receiverTypeDefinition = byteBuddy.subclass(sourceVisitor, (ConstructorStrategy)ConstructorStrategy.Default.NO_CONSTRUCTORS).defineField("delegate", targetVisitor, new ModifierContributor.ForField[] { (ModifierContributor.ForField)Visibility.PRIVATE, (ModifierContributor.ForField)FieldManifestation.FINAL }).defineConstructor(new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC }).withParameters(new Type[] { targetVisitor }).intercept(MethodCall.invoke(sourceVisitor.getDeclaredConstructor(new Class[] { int.class })).with(new Object[] { Integer.valueOf(OpenedClassReader.ASM_API) }).andThen(FieldAccessor.ofField("delegate").setsArgumentAt(0)).andThen(appendix)).defineMethod("wrap", sourceVisitor, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC, (ModifierContributor.ForMethod)Ownership.STATIC }).withParameters(new Type[] { targetVisitor }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { new NullCheckedConstruction(targetVisitor) }));
/*  171 */     if (sourceTypePath == null || targetTypePath == null) {
/*  172 */       return (DynamicType.Builder<?>)receiverTypeDefinition;
/*      */     }
/*  174 */     return (DynamicType.Builder<?>)receiverTypeDefinition
/*  175 */       .defineMethod("typePath", targetTypePath, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE, (ModifierContributor.ForMethod)Ownership.STATIC
/*  176 */         }).withParameters(new Type[] { sourceTypePath
/*  177 */         }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { new TypePathTranslator(sourceTypePath, targetTypePath) }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static DynamicType.Builder<?> toMethodVisitorBuilder(ByteBuddy byteBuddy, Class<?> sourceVisitor, Class<?> targetVisitor, @MaybeNull Class<?> sourceTypePath, @MaybeNull Class<?> targetTypePath, @MaybeNull Class<?> sourceLabel, @MaybeNull Class<?> targetLabel, @MaybeNull Class<?> sourceType, @MaybeNull Class<?> targetType, @MaybeNull Class<?> sourceHandle, @MaybeNull Class<?> targetHandle, @MaybeNull Class<?> sourceConstantDynamic, @MaybeNull Class<?> targetConstantDynamic) throws Exception {
/*      */     DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition receiverTypeDefinition;
/*  213 */     DynamicType.Builder<?> builder = toVisitorBuilder(byteBuddy, sourceVisitor, targetVisitor, sourceTypePath, targetTypePath, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  218 */         (Implementation)FieldAccessor.ofField("labels").setsValue((StackManipulation)new StackManipulation.Compound(new StackManipulation[] { TypeCreation.of(TypeDescription.ForLoadedType.of(HashMap.class)), (StackManipulation)Duplication.SINGLE, 
/*      */               
/*  220 */               (StackManipulation)MethodInvocation.invoke((MethodDescription.InDefinedShape)((MethodList)TypeDescription.ForLoadedType.of(HashMap.class)
/*  221 */                 .getDeclaredMethods()
/*  222 */                 .filter((ElementMatcher)ElementMatchers.isConstructor().and((ElementMatcher)ElementMatchers.takesArguments(0))))
/*  223 */                 .getOnly()) }, ), Map.class));
/*  224 */     if (sourceLabel != null && targetLabel != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  235 */       receiverTypeDefinition = builder.defineField("labels", Map.class, new ModifierContributor.ForField[] { (ModifierContributor.ForField)Visibility.PRIVATE, (ModifierContributor.ForField)FieldManifestation.FINAL }).defineMethod("label", targetLabel, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE }).withParameters(new Type[] { sourceLabel }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { new LabelTranslator(targetLabel) })).defineMethod("labels", (TypeDefinition)TypeDescription.ArrayProjection.of(TypeDescription.ForLoadedType.of(targetLabel)), new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE }).withParameters(new TypeDefinition[] { (TypeDefinition)TypeDescription.ArrayProjection.of(TypeDescription.ForLoadedType.of(sourceLabel)) }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { new LabelArrayTranslator(sourceLabel, targetLabel) })).defineMethod("frames", Object[].class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE }).withParameters(new Type[] { Object[].class }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { new FrameTranslator(sourceLabel, targetLabel) }));
/*      */     }
/*  237 */     if (sourceHandle != null && targetHandle != null)
/*      */     {
/*      */ 
/*      */       
/*  241 */       receiverTypeDefinition = receiverTypeDefinition.defineMethod("handle", targetHandle, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE, (ModifierContributor.ForMethod)Ownership.STATIC }).withParameters(new Type[] { sourceHandle }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { new HandleTranslator(sourceHandle, targetHandle) }));
/*      */     }
/*  243 */     if (sourceConstantDynamic != null && targetConstantDynamic != null && sourceHandle != null && targetHandle != null)
/*      */     {
/*      */ 
/*      */       
/*  247 */       receiverTypeDefinition = receiverTypeDefinition.defineMethod("constantDyanmic", targetConstantDynamic, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE, (ModifierContributor.ForMethod)Ownership.STATIC }).withParameters(new Type[] { sourceConstantDynamic }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { new ConstantDynamicTranslator(sourceConstantDynamic, targetConstantDynamic, sourceHandle, targetHandle) }));
/*      */     }
/*  249 */     return (DynamicType.Builder<?>)receiverTypeDefinition
/*  250 */       .defineMethod("constant", Object.class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE, (ModifierContributor.ForMethod)Ownership.STATIC
/*  251 */         }).withParameters(new Type[] { Object.class
/*  252 */         }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { new ConstantTranslator(sourceHandle, targetHandle, sourceType, targetType, sourceConstantDynamic, targetConstantDynamic)
/*  253 */           })).defineMethod("constants", Object[].class, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PRIVATE, (ModifierContributor.ForMethod)Ownership.STATIC
/*  254 */         }).withParameters(new Type[] { Object[].class
/*  255 */         }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { new ConstantArrayTranslator() }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static MethodCall.ArgumentLoader.Factory toConvertedParameter(TypeDescription source, Class<?> target, String method, int offset, boolean virtual) {
/*  269 */     return (MethodCall.ArgumentLoader.Factory)new MethodCall.ArgumentLoader.ForStackManipulation((StackManipulation)new StackManipulation.Compound(new StackManipulation[] { virtual ? MethodVariableAccess.loadThis() : (StackManipulation)StackManipulation.Trivial.INSTANCE, MethodVariableAccess.REFERENCE
/*  270 */             .loadFrom(offset), 
/*  271 */             (StackManipulation)MethodInvocation.invoke((MethodDescription.InDefinedShape)((MethodList)source.getDeclaredMethods().filter((ElementMatcher)ElementMatchers.named(method))).getOnly()) }, ), target);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static DynamicType toAttributeWrapper(DynamicType.Builder<?> builder, Class<?> source, Class<?> target, TypeDescription sourceWrapper, TypeDescription targetWrapper) throws Exception {
/*  286 */     return (DynamicType)builder
/*  287 */       .defineField("delegate", target, new ModifierContributor.ForField[] { (ModifierContributor.ForField)Visibility.PUBLIC, (ModifierContributor.ForField)FieldManifestation.FINAL
/*  288 */         }).defineConstructor(new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC
/*  289 */         }).withParameters(new Type[] { target
/*  290 */         }).intercept((Implementation)MethodCall.invoke(source.getDeclaredConstructor(new Class[] { String.class
/*  291 */             })).onSuper()
/*  292 */         .with((StackManipulation)new StackManipulation.Compound(new StackManipulation[] {
/*  293 */               MethodVariableAccess.REFERENCE.loadFrom(1), 
/*  294 */               FieldAccess.forField((FieldDescription.InDefinedShape)new FieldDescription.ForLoadedField(target.getField("type"))).read() }, ), String.class)
/*  295 */         .andThen(FieldAccessor.ofField("delegate").setsArgumentAt(0)))
/*  296 */       .defineMethod("attribute", source, new ModifierContributor.ForMethod[] { (ModifierContributor.ForMethod)Visibility.PUBLIC, (ModifierContributor.ForMethod)Ownership.STATIC
/*  297 */         }).withParameters(new Type[] { target
/*  298 */         }).intercept((Implementation)new Implementation.Simple(new ByteCodeAppender[] { new AttributeTranslator(source, target, sourceWrapper, targetWrapper)
/*  299 */           })).method((ElementMatcher)ElementMatchers.isProtected())
/*  300 */       .intercept(ExceptionMethod.throwing(UnsupportedOperationException.class))
/*  301 */       .method((ElementMatcher)ElementMatchers.named("isUnknown"))
/*  302 */       .intercept((Implementation)MethodCall.invoke(target.getMethod("isUnknown", new Class[0])).onField("delegate"))
/*  303 */       .method((ElementMatcher)ElementMatchers.named("isCodeAttribute"))
/*  304 */       .intercept((Implementation)MethodCall.invoke(target.getMethod("isCodeAttribute", new Class[0])).onField("delegate"))
/*  305 */       .make();
/*      */   }
/*      */ 
/*      */   
/*      */   public abstract T wrap(ClassVisitor paramClassVisitor);
/*      */ 
/*      */   
/*      */   public abstract ClassVisitor unwrap(T paramT);
/*      */ 
/*      */   
/*      */   public boolean equals(@MaybeNull Object paramObject) {
/*      */     return (this == paramObject) ? true : ((paramObject == null) ? false : ((getClass() != paramObject.getClass()) ? false : (!!this.type.equals(((ClassVisitorFactory)paramObject).type))));
/*      */   }
/*      */   
/*      */   public int hashCode() {
/*      */     return getClass().hashCode() * 31 + this.type.hashCode();
/*      */   }
/*      */   
/*      */   static {
/*      */     try {
/*      */       Class.forName("java.security.AccessController", false, (ClassLoader)null);
/*      */       ACCESS_CONTROLLER = Boolean.parseBoolean(System.getProperty("net.bytebuddy.securitymanager", "true"));
/*      */     } catch (ClassNotFoundException classNotFoundException) {
/*      */       ACCESS_CONTROLLER = false;
/*      */     } catch (SecurityException securityException) {
/*      */       ACCESS_CONTROLLER = true;
/*      */     } 
/*      */   }
/*      */   
/*      */   @Enhance
/*      */   protected static class NullCheckedConstruction
/*      */     implements ByteCodeAppender
/*      */   {
/*      */     private final Class<?> type;
/*      */     
/*      */     protected NullCheckedConstruction(Class<?> type) {
/*  341 */       this.type = type;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/*  350 */       methodVisitor.visitVarInsn(25, 0);
/*  351 */       Label label = new Label();
/*  352 */       methodVisitor.visitJumpInsn(198, label);
/*  353 */       methodVisitor.visitTypeInsn(187, implementationContext.getInstrumentedType().getInternalName());
/*  354 */       methodVisitor.visitInsn(89);
/*  355 */       methodVisitor.visitVarInsn(25, 0);
/*  356 */       methodVisitor.visitMethodInsn(183, implementationContext
/*  357 */           .getInstrumentedType().getInternalName(), "<init>", 
/*      */           
/*  359 */           Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { Type.getType(this.type) }), false);
/*      */       
/*  361 */       methodVisitor.visitInsn(176);
/*  362 */       methodVisitor.visitLabel(label);
/*  363 */       implementationContext.getFrameGeneration().same(methodVisitor, (List)instrumentedMethod.getParameters().asTypeList());
/*  364 */       methodVisitor.visitInsn(1);
/*  365 */       methodVisitor.visitInsn(176);
/*  366 */       return new ByteCodeAppender.Size(3, 1);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.type.equals(((NullCheckedConstruction)param1Object).type))));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return getClass().hashCode() * 31 + this.type.hashCode();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   protected static class LabelTranslator
/*      */     implements ByteCodeAppender
/*      */   {
/*      */     protected static final String NAME = "label";
/*      */     
/*      */     private final Class<?> target;
/*      */ 
/*      */     
/*      */     protected LabelTranslator(Class<?> target) {
/*  392 */       this.target = target;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/*  399 */       Label nullCheck = new Label(), end = new Label();
/*  400 */       methodVisitor.visitVarInsn(25, 1);
/*  401 */       methodVisitor.visitJumpInsn(199, nullCheck);
/*  402 */       methodVisitor.visitInsn(1);
/*  403 */       methodVisitor.visitInsn(176);
/*  404 */       methodVisitor.visitLabel(nullCheck);
/*  405 */       implementationContext.getFrameGeneration().same(methodVisitor, CompoundList.of(implementationContext
/*  406 */             .getInstrumentedType(), (List)instrumentedMethod
/*  407 */             .getParameters().asTypeList()));
/*  408 */       methodVisitor.visitVarInsn(25, 0);
/*  409 */       methodVisitor.visitFieldInsn(180, implementationContext
/*  410 */           .getInstrumentedType().getInternalName(), "labels", 
/*      */           
/*  412 */           Type.getDescriptor(Map.class));
/*  413 */       methodVisitor.visitVarInsn(25, 1);
/*  414 */       methodVisitor.visitMethodInsn(185, Type.getInternalName(Map.class), "get", 
/*      */           
/*  416 */           Type.getMethodDescriptor(Type.getType(Object.class), new Type[] { Type.getType(Object.class) }), true);
/*      */       
/*  418 */       methodVisitor.visitTypeInsn(192, Type.getInternalName(this.target));
/*  419 */       methodVisitor.visitVarInsn(58, 2);
/*  420 */       methodVisitor.visitVarInsn(25, 2);
/*  421 */       methodVisitor.visitJumpInsn(199, end);
/*  422 */       methodVisitor.visitTypeInsn(187, Type.getInternalName(this.target));
/*  423 */       methodVisitor.visitInsn(89);
/*  424 */       methodVisitor.visitMethodInsn(183, 
/*  425 */           Type.getInternalName(this.target), "<init>", "()V", false);
/*      */ 
/*      */ 
/*      */       
/*  429 */       methodVisitor.visitVarInsn(58, 2);
/*  430 */       methodVisitor.visitVarInsn(25, 0);
/*  431 */       methodVisitor.visitFieldInsn(180, implementationContext
/*  432 */           .getInstrumentedType().getInternalName(), "labels", 
/*      */           
/*  434 */           Type.getDescriptor(Map.class));
/*  435 */       methodVisitor.visitVarInsn(25, 1);
/*  436 */       methodVisitor.visitVarInsn(25, 2);
/*  437 */       methodVisitor.visitMethodInsn(185, 
/*  438 */           Type.getInternalName(Map.class), "put", 
/*      */           
/*  440 */           Type.getMethodDescriptor(Type.getType(Object.class), new Type[] { Type.getType(Object.class), Type.getType(Object.class) }), true);
/*      */       
/*  442 */       methodVisitor.visitInsn(87);
/*  443 */       methodVisitor.visitLabel(end);
/*  444 */       implementationContext.getFrameGeneration().append(methodVisitor, 
/*  445 */           Collections.singletonList(TypeDescription.ForLoadedType.of(this.target)), 
/*  446 */           CompoundList.of(implementationContext.getInstrumentedType(), (List)instrumentedMethod.getParameters().asTypeList()));
/*  447 */       methodVisitor.visitVarInsn(25, 2);
/*  448 */       methodVisitor.visitInsn(176);
/*  449 */       return new ByteCodeAppender.Size(3, 3);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!!this.target.equals(((LabelTranslator)param1Object).target))));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return getClass().hashCode() * 31 + this.target.hashCode();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   protected static class LabelArrayTranslator
/*      */     implements ByteCodeAppender
/*      */   {
/*      */     protected static final String NAME = "labels";
/*      */ 
/*      */     
/*      */     private final Class<?> sourceLabel;
/*      */ 
/*      */     
/*      */     private final Class<?> targetLabel;
/*      */ 
/*      */     
/*      */     protected LabelArrayTranslator(Class<?> sourceLabel, Class<?> targetLabel) {
/*  481 */       this.sourceLabel = sourceLabel;
/*  482 */       this.targetLabel = targetLabel;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/*  489 */       Label nullCheck = new Label(), loop = new Label(), end = new Label();
/*  490 */       methodVisitor.visitVarInsn(25, 1);
/*  491 */       methodVisitor.visitJumpInsn(199, nullCheck);
/*  492 */       methodVisitor.visitInsn(1);
/*  493 */       methodVisitor.visitInsn(176);
/*  494 */       methodVisitor.visitLabel(nullCheck);
/*  495 */       implementationContext.getFrameGeneration().same(methodVisitor, CompoundList.of(implementationContext
/*  496 */             .getInstrumentedType(), (List)instrumentedMethod
/*  497 */             .getParameters().asTypeList()));
/*  498 */       methodVisitor.visitVarInsn(25, 1);
/*  499 */       methodVisitor.visitInsn(190);
/*  500 */       methodVisitor.visitTypeInsn(189, Type.getInternalName(this.targetLabel));
/*  501 */       methodVisitor.visitVarInsn(58, 2);
/*  502 */       methodVisitor.visitInsn(3);
/*  503 */       methodVisitor.visitVarInsn(54, 3);
/*  504 */       methodVisitor.visitLabel(loop);
/*  505 */       implementationContext.getFrameGeneration().append(methodVisitor, 
/*  506 */           Arrays.asList(new TypeDescription[] { TypeDescription.ArrayProjection.of(TypeDescription.ForLoadedType.of(this.targetLabel)), TypeDescription.ForLoadedType.of(int.class)
/*  507 */             }, ), CompoundList.of(implementationContext.getInstrumentedType(), (List)instrumentedMethod.getParameters().asTypeList()));
/*  508 */       methodVisitor.visitVarInsn(21, 3);
/*  509 */       methodVisitor.visitVarInsn(25, 1);
/*  510 */       methodVisitor.visitInsn(190);
/*  511 */       methodVisitor.visitJumpInsn(162, end);
/*  512 */       methodVisitor.visitVarInsn(25, 2);
/*  513 */       methodVisitor.visitVarInsn(21, 3);
/*  514 */       methodVisitor.visitVarInsn(25, 0);
/*  515 */       methodVisitor.visitVarInsn(25, 1);
/*  516 */       methodVisitor.visitVarInsn(21, 3);
/*  517 */       methodVisitor.visitInsn(50);
/*  518 */       methodVisitor.visitMethodInsn(183, implementationContext
/*  519 */           .getInstrumentedType().getInternalName(), "label", 
/*      */           
/*  521 */           Type.getMethodDescriptor(Type.getType(this.targetLabel), new Type[] { Type.getType(this.sourceLabel) }), false);
/*      */       
/*  523 */       methodVisitor.visitInsn(83);
/*  524 */       methodVisitor.visitIincInsn(3, 1);
/*  525 */       methodVisitor.visitJumpInsn(167, loop);
/*  526 */       methodVisitor.visitLabel(end);
/*  527 */       implementationContext.getFrameGeneration().chop(methodVisitor, 1, CompoundList.of(
/*  528 */             Collections.singletonList(implementationContext.getInstrumentedType()), (List)instrumentedMethod
/*  529 */             .getParameters().asTypeList(), 
/*  530 */             Collections.singletonList(TypeDescription.ArrayProjection.of(TypeDescription.ForLoadedType.of(this.targetLabel)))));
/*  531 */       methodVisitor.visitVarInsn(25, 2);
/*  532 */       methodVisitor.visitInsn(176);
/*  533 */       return new ByteCodeAppender.Size(5, 4);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.sourceLabel.equals(((LabelArrayTranslator)param1Object).sourceLabel) ? false : (!!this.targetLabel.equals(((LabelArrayTranslator)param1Object).targetLabel)))));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return (getClass().hashCode() * 31 + this.sourceLabel.hashCode()) * 31 + this.targetLabel.hashCode();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   protected static class HandleTranslator
/*      */     implements ByteCodeAppender
/*      */   {
/*      */     protected static final String NAME = "handle";
/*      */ 
/*      */     
/*      */     private final Class<?> sourceHandle;
/*      */ 
/*      */     
/*      */     private final Class<?> targetHandle;
/*      */ 
/*      */     
/*      */     protected HandleTranslator(Class<?> sourceHandle, Class<?> targetHandle) {
/*  565 */       this.sourceHandle = sourceHandle;
/*  566 */       this.targetHandle = targetHandle;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/*  573 */       Label nullCheck = new Label();
/*  574 */       methodVisitor.visitVarInsn(25, 0);
/*  575 */       methodVisitor.visitJumpInsn(199, nullCheck);
/*  576 */       methodVisitor.visitInsn(1);
/*  577 */       methodVisitor.visitInsn(176);
/*  578 */       methodVisitor.visitLabel(nullCheck);
/*  579 */       implementationContext.getFrameGeneration().same(methodVisitor, (List)instrumentedMethod.getParameters().asTypeList());
/*  580 */       methodVisitor.visitTypeInsn(187, Type.getInternalName(this.targetHandle));
/*  581 */       methodVisitor.visitInsn(89);
/*  582 */       methodVisitor.visitVarInsn(25, 0);
/*  583 */       methodVisitor.visitMethodInsn(182, 
/*  584 */           Type.getInternalName(this.sourceHandle), "getTag", 
/*      */           
/*  586 */           Type.getMethodDescriptor(Type.INT_TYPE, new Type[0]), false);
/*      */       
/*  588 */       methodVisitor.visitVarInsn(25, 0);
/*  589 */       methodVisitor.visitMethodInsn(182, 
/*  590 */           Type.getInternalName(this.sourceHandle), "getOwner", 
/*      */           
/*  592 */           Type.getMethodDescriptor(Type.getType(String.class), new Type[0]), false);
/*      */       
/*  594 */       methodVisitor.visitVarInsn(25, 0);
/*  595 */       methodVisitor.visitMethodInsn(182, 
/*  596 */           Type.getInternalName(this.sourceHandle), "getName", 
/*      */           
/*  598 */           Type.getMethodDescriptor(Type.getType(String.class), new Type[0]), false);
/*      */       
/*  600 */       methodVisitor.visitVarInsn(25, 0);
/*  601 */       methodVisitor.visitMethodInsn(182, Type.getInternalName(this.sourceHandle), "getDesc", 
/*      */           
/*  603 */           Type.getMethodDescriptor(Type.getType(String.class), new Type[0]), false);
/*      */       
/*  605 */       methodVisitor.visitVarInsn(25, 0);
/*  606 */       methodVisitor.visitMethodInsn(182, 
/*  607 */           Type.getInternalName(this.sourceHandle), "isInterface", 
/*      */           
/*  609 */           Type.getMethodDescriptor(Type.BOOLEAN_TYPE, new Type[0]), false);
/*      */       
/*  611 */       methodVisitor.visitMethodInsn(183, 
/*  612 */           Type.getInternalName(this.targetHandle), "<init>", 
/*      */           
/*  614 */           Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { Type.INT_TYPE, Type.getType(String.class), Type.getType(String.class), Type.getType(String.class), Type.BOOLEAN_TYPE }), false);
/*      */       
/*  616 */       methodVisitor.visitInsn(176);
/*  617 */       return new ByteCodeAppender.Size(7, 1);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.sourceHandle.equals(((HandleTranslator)param1Object).sourceHandle) ? false : (!!this.targetHandle.equals(((HandleTranslator)param1Object).targetHandle)))));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return (getClass().hashCode() * 31 + this.sourceHandle.hashCode()) * 31 + this.targetHandle.hashCode();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   protected static class ConstantDynamicTranslator
/*      */     implements ByteCodeAppender
/*      */   {
/*      */     protected static final String NAME = "constantDyanmic";
/*      */ 
/*      */ 
/*      */     
/*      */     private final Class<?> sourceConstantDynamic;
/*      */ 
/*      */ 
/*      */     
/*      */     private final Class<?> targetConstantDynamic;
/*      */ 
/*      */     
/*      */     private final Class<?> sourceHandle;
/*      */ 
/*      */     
/*      */     private final Class<?> targetHandle;
/*      */ 
/*      */ 
/*      */     
/*      */     protected ConstantDynamicTranslator(Class<?> sourceConstantDynamic, Class<?> targetConstantDynamic, Class<?> sourceHandle, Class<?> targetHandle) {
/*  661 */       this.sourceConstantDynamic = sourceConstantDynamic;
/*  662 */       this.targetConstantDynamic = targetConstantDynamic;
/*  663 */       this.sourceHandle = sourceHandle;
/*  664 */       this.targetHandle = targetHandle;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/*  671 */       Label loop = new Label(), end = new Label();
/*  672 */       methodVisitor.visitVarInsn(25, 0);
/*  673 */       methodVisitor.visitMethodInsn(182, 
/*  674 */           Type.getInternalName(this.sourceConstantDynamic), "getBootstrapMethodArgumentCount", 
/*      */           
/*  676 */           Type.getMethodDescriptor(Type.INT_TYPE, new Type[0]), false);
/*      */       
/*  678 */       methodVisitor.visitTypeInsn(189, Type.getInternalName(Object.class));
/*  679 */       methodVisitor.visitVarInsn(58, 1);
/*  680 */       methodVisitor.visitInsn(3);
/*  681 */       methodVisitor.visitVarInsn(54, 2);
/*  682 */       methodVisitor.visitLabel(loop);
/*  683 */       implementationContext.getFrameGeneration().append(methodVisitor, 
/*  684 */           Arrays.asList(new TypeDescription[] { TypeDescription.ForLoadedType.of(Object[].class), TypeDescription.ForLoadedType.of(int.class) }, ), (List)instrumentedMethod
/*  685 */           .getParameters().asTypeList());
/*  686 */       methodVisitor.visitVarInsn(21, 2);
/*  687 */       methodVisitor.visitVarInsn(25, 1);
/*  688 */       methodVisitor.visitInsn(190);
/*  689 */       methodVisitor.visitJumpInsn(162, end);
/*  690 */       methodVisitor.visitVarInsn(25, 1);
/*  691 */       methodVisitor.visitVarInsn(21, 2);
/*  692 */       methodVisitor.visitVarInsn(25, 0);
/*  693 */       methodVisitor.visitVarInsn(21, 2);
/*  694 */       methodVisitor.visitMethodInsn(182, 
/*  695 */           Type.getInternalName(this.sourceConstantDynamic), "getBootstrapMethodArgument", 
/*      */           
/*  697 */           Type.getMethodDescriptor(Type.getType(Object.class), new Type[] { Type.INT_TYPE }), false);
/*      */       
/*  699 */       methodVisitor.visitMethodInsn(184, implementationContext
/*  700 */           .getInstrumentedType().getInternalName(), "ldc", 
/*      */           
/*  702 */           Type.getMethodDescriptor(Type.getType(Object.class), new Type[] { Type.getType(Object.class) }), false);
/*      */       
/*  704 */       methodVisitor.visitInsn(83);
/*  705 */       methodVisitor.visitIincInsn(2, 1);
/*  706 */       methodVisitor.visitJumpInsn(167, loop);
/*  707 */       methodVisitor.visitLabel(end);
/*  708 */       implementationContext.getFrameGeneration().chop(methodVisitor, 1, CompoundList.of((List)instrumentedMethod
/*  709 */             .getParameters().asTypeList(), 
/*  710 */             TypeDescription.ForLoadedType.of(Object[].class)));
/*  711 */       methodVisitor.visitTypeInsn(187, Type.getInternalName(this.targetConstantDynamic));
/*  712 */       methodVisitor.visitInsn(89);
/*  713 */       methodVisitor.visitVarInsn(25, 0);
/*  714 */       methodVisitor.visitMethodInsn(182, 
/*  715 */           Type.getInternalName(this.sourceConstantDynamic), "getName", 
/*      */           
/*  717 */           Type.getMethodDescriptor(Type.getType(String.class), new Type[0]), false);
/*      */       
/*  719 */       methodVisitor.visitVarInsn(25, 0);
/*  720 */       methodVisitor.visitMethodInsn(182, 
/*  721 */           Type.getInternalName(this.sourceConstantDynamic), "getDescriptor", 
/*      */           
/*  723 */           Type.getMethodDescriptor(Type.getType(String.class), new Type[0]), false);
/*      */       
/*  725 */       methodVisitor.visitVarInsn(25, 0);
/*  726 */       methodVisitor.visitMethodInsn(182, 
/*  727 */           Type.getInternalName(this.sourceConstantDynamic), "getBootstrapMethod", 
/*      */           
/*  729 */           Type.getMethodDescriptor(Type.getType(this.sourceHandle), new Type[0]), false);
/*      */       
/*  731 */       methodVisitor.visitMethodInsn(184, implementationContext
/*  732 */           .getInstrumentedType().getInternalName(), "handle", 
/*      */           
/*  734 */           Type.getMethodDescriptor(Type.getType(this.targetHandle), new Type[] { Type.getType(this.sourceHandle) }), false);
/*      */       
/*  736 */       methodVisitor.visitVarInsn(25, 1);
/*  737 */       methodVisitor.visitMethodInsn(183, 
/*  738 */           Type.getInternalName(this.targetConstantDynamic), "<init>", 
/*      */           
/*  740 */           Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { Type.getType(String.class), Type.getType(String.class), Type.getType(this.targetHandle), Type.getType(Object[].class) }), false);
/*      */       
/*  742 */       methodVisitor.visitInsn(176);
/*  743 */       methodVisitor.visitMaxs(6, 3);
/*  744 */       return new ByteCodeAppender.Size(6, 3);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.sourceConstantDynamic.equals(((ConstantDynamicTranslator)param1Object).sourceConstantDynamic) ? false : (!this.targetConstantDynamic.equals(((ConstantDynamicTranslator)param1Object).targetConstantDynamic) ? false : (!this.sourceHandle.equals(((ConstantDynamicTranslator)param1Object).sourceHandle) ? false : (!!this.targetHandle.equals(((ConstantDynamicTranslator)param1Object).targetHandle)))))));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return (((getClass().hashCode() * 31 + this.sourceConstantDynamic.hashCode()) * 31 + this.targetConstantDynamic.hashCode()) * 31 + this.sourceHandle.hashCode()) * 31 + this.targetHandle.hashCode();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   protected static class ConstantTranslator
/*      */     implements ByteCodeAppender
/*      */   {
/*      */     protected static final String NAME = "constant";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*      */     private final Class<?> sourceHandle;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*      */     private final Class<?> targetHandle;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @MaybeNull
/*      */     @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY)
/*      */     private final Class<?> sourceType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected ConstantTranslator(@MaybeNull Class<?> sourceHandle, @MaybeNull Class<?> targetHandle, @MaybeNull Class<?> sourceType, @MaybeNull Class<?> targetType, @MaybeNull Class<?> sourceConstantDynamic, @MaybeNull Class<?> targetConstantDynamic) {
/*  817 */       this.sourceHandle = sourceHandle;
/*  818 */       this.targetHandle = targetHandle;
/*  819 */       this.sourceType = sourceType;
/*  820 */       this.targetType = targetType;
/*  821 */       this.sourceConstantDynamic = sourceConstantDynamic;
/*  822 */       this.targetConstantDynamic = targetConstantDynamic;
/*      */     } @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) private final Class<?> targetType; @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) private final Class<?> sourceConstantDynamic; @MaybeNull @ValueHandling(HashCodeAndEqualsPlugin.ValueHandling.Sort.REVERSE_NULLABILITY) private final Class<?> targetConstantDynamic; public boolean equals(@MaybeNull Object param1Object) { if (this == param1Object) return true;  if (param1Object == null) return false;  if (getClass() != param1Object.getClass()) return false;  Class<?> clazz1 = ((ConstantTranslator)param1Object).sourceHandle; Class<?> clazz2 = this.sourceHandle; if (clazz1 != null) { if (clazz2 != null) { if (!clazz2.equals(clazz1))
/*      */             return false;  } else { return false; }  } else if (clazz2 != null) { return false; }  clazz1 = ((ConstantTranslator)param1Object).targetHandle; clazz2 = this.targetHandle; if (clazz1 != null) { if (clazz2 != null) { if (!clazz2.equals(clazz1))
/*      */             return false;  } else { return false; }  } else if (clazz2 != null) { return false; }  clazz1 = ((ConstantTranslator)param1Object).sourceType; clazz2 = this.sourceType; if (clazz1 != null) { if (clazz2 != null) { if (!clazz2.equals(clazz1))
/*      */             return false;  } else { return false; }  } else if (clazz2 != null) { return false; }  clazz1 = ((ConstantTranslator)param1Object).targetType; clazz2 = this.targetType; if (clazz1 != null) { if (clazz2 != null) { if (!clazz2.equals(clazz1))
/*      */             return false;  } else { return false; }  } else if (clazz2 != null) { return false; }  clazz1 = ((ConstantTranslator)param1Object).sourceConstantDynamic; clazz2 = this.sourceConstantDynamic; if (clazz1 != null) { if (clazz2 != null) { if (!clazz2.equals(clazz1))
/*      */             return false;  } else { return false; }  } else if (clazz2 != null) { return false; }  clazz1 = ((ConstantTranslator)param1Object).targetConstantDynamic; clazz2 = this.targetConstantDynamic; if (clazz1 != null) { if (clazz2 != null) { if (!clazz2.equals(clazz1))
/*  829 */             return false;  } else { return false; }  } else if (clazz2 != null) { return false; }  return true; } public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) { Label noType = new Label(), noHandle = new Label(), noConstantDynamic = new Label();
/*  830 */       if (this.sourceType != null && this.targetType != null) {
/*  831 */         methodVisitor.visitVarInsn(25, 0);
/*  832 */         methodVisitor.visitTypeInsn(193, Type.getInternalName(this.sourceType));
/*  833 */         methodVisitor.visitJumpInsn(153, noType);
/*  834 */         methodVisitor.visitVarInsn(25, 0);
/*  835 */         methodVisitor.visitTypeInsn(192, Type.getInternalName(this.sourceType));
/*  836 */         methodVisitor.visitMethodInsn(182, 
/*  837 */             Type.getInternalName(this.sourceType), "getDescriptor", 
/*      */             
/*  839 */             Type.getMethodDescriptor(Type.getType(String.class), new Type[0]), false);
/*      */         
/*  841 */         methodVisitor.visitMethodInsn(184, 
/*  842 */             Type.getInternalName(this.targetType), "getType", 
/*      */             
/*  844 */             Type.getMethodDescriptor(Type.getType(this.targetType), new Type[] { Type.getType(String.class) }), false);
/*      */         
/*  846 */         methodVisitor.visitInsn(176);
/*  847 */         methodVisitor.visitLabel(noType);
/*  848 */         implementationContext.getFrameGeneration().same(methodVisitor, (List)instrumentedMethod.getParameters().asTypeList());
/*      */       } 
/*  850 */       if (this.sourceHandle != null && this.targetHandle != null) {
/*  851 */         methodVisitor.visitVarInsn(25, 0);
/*  852 */         methodVisitor.visitTypeInsn(193, Type.getInternalName(this.sourceHandle));
/*  853 */         methodVisitor.visitJumpInsn(153, noHandle);
/*  854 */         methodVisitor.visitVarInsn(25, 0);
/*  855 */         methodVisitor.visitTypeInsn(192, Type.getInternalName(this.sourceHandle));
/*  856 */         methodVisitor.visitMethodInsn(184, implementationContext
/*  857 */             .getInstrumentedType().getInternalName(), "handle", 
/*      */             
/*  859 */             Type.getMethodDescriptor(Type.getType(this.targetHandle), new Type[] { Type.getType(this.sourceHandle) }), false);
/*      */         
/*  861 */         methodVisitor.visitInsn(176);
/*  862 */         methodVisitor.visitLabel(noHandle);
/*  863 */         implementationContext.getFrameGeneration().same(methodVisitor, (List)instrumentedMethod.getParameters().asTypeList());
/*      */       } 
/*  865 */       if (this.sourceConstantDynamic != null && this.targetConstantDynamic != null) {
/*  866 */         methodVisitor.visitVarInsn(25, 0);
/*  867 */         methodVisitor.visitTypeInsn(193, Type.getInternalName(this.sourceConstantDynamic));
/*  868 */         methodVisitor.visitJumpInsn(153, noConstantDynamic);
/*  869 */         methodVisitor.visitVarInsn(25, 0);
/*  870 */         methodVisitor.visitTypeInsn(192, Type.getInternalName(this.sourceConstantDynamic));
/*  871 */         methodVisitor.visitMethodInsn(184, implementationContext
/*  872 */             .getInstrumentedType().getInternalName(), "constantDyanmic", 
/*      */             
/*  874 */             Type.getMethodDescriptor(Type.getType(this.targetConstantDynamic), new Type[] { Type.getType(this.sourceConstantDynamic) }), false);
/*      */         
/*  876 */         methodVisitor.visitInsn(176);
/*  877 */         methodVisitor.visitLabel(noConstantDynamic);
/*  878 */         implementationContext.getFrameGeneration().same(methodVisitor, (List)instrumentedMethod.getParameters().asTypeList());
/*      */       } 
/*  880 */       methodVisitor.visitVarInsn(25, 0);
/*  881 */       methodVisitor.visitInsn(176);
/*  882 */       return new ByteCodeAppender.Size(1, 1); }
/*      */     
/*      */     public int hashCode() {
/*      */       Class<?> clazz = this.sourceHandle;
/*      */       if (clazz != null);
/*      */       clazz = this.targetHandle;
/*      */       if (clazz != null);
/*      */       clazz = this.sourceType;
/*      */       if (clazz != null);
/*      */       clazz = this.targetType;
/*      */       if (clazz != null);
/*      */       clazz = this.sourceConstantDynamic;
/*      */       if (clazz != null);
/*      */       clazz = this.targetConstantDynamic;
/*      */       if (clazz != null);
/*      */       return (((((getClass().hashCode() * 31 + clazz.hashCode()) * 31 + clazz.hashCode()) * 31 + clazz.hashCode()) * 31 + clazz.hashCode()) * 31 + clazz.hashCode()) * 31 + clazz.hashCode();
/*      */     } }
/*      */   @Enhance
/*      */   protected static class ConstantArrayTranslator implements ByteCodeAppender { public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/*  901 */       Label nullCheck = new Label(), loop = new Label(), end = new Label();
/*  902 */       methodVisitor.visitVarInsn(25, 0);
/*  903 */       methodVisitor.visitJumpInsn(199, nullCheck);
/*  904 */       methodVisitor.visitInsn(1);
/*  905 */       methodVisitor.visitInsn(176);
/*  906 */       methodVisitor.visitLabel(nullCheck);
/*  907 */       implementationContext.getFrameGeneration().same(methodVisitor, (List)instrumentedMethod.getParameters().asTypeList());
/*  908 */       methodVisitor.visitVarInsn(25, 0);
/*  909 */       methodVisitor.visitInsn(190);
/*  910 */       methodVisitor.visitTypeInsn(189, Type.getInternalName(Object.class));
/*  911 */       methodVisitor.visitVarInsn(58, 1);
/*  912 */       methodVisitor.visitInsn(3);
/*  913 */       methodVisitor.visitVarInsn(54, 2);
/*  914 */       methodVisitor.visitLabel(loop);
/*  915 */       implementationContext.getFrameGeneration().append(methodVisitor, 
/*  916 */           Arrays.asList(new TypeDescription[] { TypeDescription.ForLoadedType.of(Object[].class), TypeDescription.ForLoadedType.of(int.class) }, ), (List)instrumentedMethod
/*  917 */           .getParameters().asTypeList());
/*  918 */       methodVisitor.visitVarInsn(21, 2);
/*  919 */       methodVisitor.visitVarInsn(25, 1);
/*  920 */       methodVisitor.visitInsn(190);
/*  921 */       methodVisitor.visitJumpInsn(162, end);
/*  922 */       methodVisitor.visitVarInsn(25, 1);
/*  923 */       methodVisitor.visitVarInsn(21, 2);
/*  924 */       methodVisitor.visitVarInsn(25, 0);
/*  925 */       methodVisitor.visitVarInsn(21, 2);
/*  926 */       methodVisitor.visitInsn(50);
/*  927 */       methodVisitor.visitMethodInsn(184, implementationContext
/*  928 */           .getInstrumentedType().getInternalName(), "constant", 
/*      */           
/*  930 */           Type.getMethodDescriptor(Type.getType(Object.class), new Type[] { Type.getType(Object.class) }), false);
/*      */       
/*  932 */       methodVisitor.visitInsn(83);
/*  933 */       methodVisitor.visitIincInsn(2, 1);
/*  934 */       methodVisitor.visitJumpInsn(167, loop);
/*  935 */       methodVisitor.visitLabel(end);
/*  936 */       implementationContext.getFrameGeneration().chop(methodVisitor, 1, CompoundList.of((List)instrumentedMethod
/*  937 */             .getParameters().asTypeList(), 
/*  938 */             TypeDescription.ForLoadedType.of(Object[].class)));
/*  939 */       methodVisitor.visitVarInsn(25, 1);
/*  940 */       methodVisitor.visitInsn(176);
/*  941 */       return new ByteCodeAppender.Size(4, 3);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     protected static final String NAME = "constants";
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : (!(getClass() != param1Object.getClass())));
/*      */     }
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return getClass().hashCode();
/*      */     } }
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   protected static class FrameTranslator
/*      */     implements ByteCodeAppender
/*      */   {
/*      */     protected static final String NAME = "frames";
/*      */     
/*      */     private final Class<?> sourceLabel;
/*      */     
/*      */     private final Class<?> targetLabel;
/*      */ 
/*      */     
/*      */     protected FrameTranslator(Class<?> sourceLabel, Class<?> targetLabel) {
/*  973 */       this.sourceLabel = sourceLabel;
/*  974 */       this.targetLabel = targetLabel;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/*  981 */       Label nullCheck = new Label(), loop = new Label(), store = new Label(), end = new Label(), label = new Label();
/*  982 */       methodVisitor.visitVarInsn(25, 1);
/*  983 */       methodVisitor.visitJumpInsn(199, nullCheck);
/*  984 */       methodVisitor.visitInsn(1);
/*  985 */       methodVisitor.visitInsn(176);
/*  986 */       methodVisitor.visitLabel(nullCheck);
/*  987 */       implementationContext.getFrameGeneration().same(methodVisitor, CompoundList.of(implementationContext
/*  988 */             .getInstrumentedType(), (List)instrumentedMethod
/*  989 */             .getParameters().asTypeList()));
/*  990 */       methodVisitor.visitVarInsn(25, 1);
/*  991 */       methodVisitor.visitInsn(190);
/*  992 */       methodVisitor.visitTypeInsn(189, Type.getInternalName(Object.class));
/*  993 */       methodVisitor.visitVarInsn(58, 2);
/*  994 */       methodVisitor.visitInsn(3);
/*  995 */       methodVisitor.visitVarInsn(54, 3);
/*  996 */       methodVisitor.visitLabel(loop);
/*  997 */       implementationContext.getFrameGeneration().append(methodVisitor, 
/*  998 */           Arrays.asList(new TypeDescription[] { TypeDescription.ForLoadedType.of(Object[].class), TypeDescription.ForLoadedType.of(int.class)
/*  999 */             }, ), CompoundList.of(implementationContext.getInstrumentedType(), (List)instrumentedMethod.getParameters().asTypeList()));
/* 1000 */       methodVisitor.visitVarInsn(21, 3);
/* 1001 */       methodVisitor.visitVarInsn(25, 1);
/* 1002 */       methodVisitor.visitInsn(190);
/* 1003 */       methodVisitor.visitJumpInsn(162, end);
/* 1004 */       methodVisitor.visitVarInsn(25, 2);
/* 1005 */       methodVisitor.visitVarInsn(21, 3);
/* 1006 */       methodVisitor.visitVarInsn(25, 1);
/* 1007 */       methodVisitor.visitVarInsn(21, 3);
/* 1008 */       methodVisitor.visitInsn(50);
/* 1009 */       methodVisitor.visitTypeInsn(193, Type.getInternalName(this.sourceLabel));
/* 1010 */       methodVisitor.visitJumpInsn(153, label);
/* 1011 */       methodVisitor.visitVarInsn(25, 0);
/* 1012 */       methodVisitor.visitVarInsn(25, 1);
/* 1013 */       methodVisitor.visitVarInsn(21, 3);
/* 1014 */       methodVisitor.visitInsn(50);
/* 1015 */       methodVisitor.visitTypeInsn(192, Type.getInternalName(this.sourceLabel));
/* 1016 */       methodVisitor.visitMethodInsn(183, implementationContext
/* 1017 */           .getInstrumentedType().getInternalName(), "label", 
/*      */           
/* 1019 */           Type.getMethodDescriptor(Type.getType(this.targetLabel), new Type[] { Type.getType(this.sourceLabel) }), false);
/*      */       
/* 1021 */       methodVisitor.visitJumpInsn(167, store);
/* 1022 */       methodVisitor.visitLabel(label);
/* 1023 */       implementationContext.getFrameGeneration().full(methodVisitor, 
/* 1024 */           Arrays.asList(new TypeDescription[] { TypeDescription.ForLoadedType.of(Object[].class), TypeDescription.ForLoadedType.of(int.class)
/* 1025 */             }, ), CompoundList.of(
/* 1026 */             Collections.singletonList(implementationContext.getInstrumentedType()), (List)instrumentedMethod
/* 1027 */             .getParameters().asTypeList(), 
/* 1028 */             Arrays.asList(new TypeDescription[] { TypeDescription.ForLoadedType.of(Object[].class), TypeDescription.ForLoadedType.of(int.class) })));
/* 1029 */       methodVisitor.visitVarInsn(25, 1);
/* 1030 */       methodVisitor.visitVarInsn(21, 3);
/* 1031 */       methodVisitor.visitInsn(50);
/* 1032 */       methodVisitor.visitLabel(store);
/* 1033 */       implementationContext.getFrameGeneration().full(methodVisitor, 
/* 1034 */           Arrays.asList(new TypeDescription[] { TypeDescription.ForLoadedType.of(Object[].class), TypeDescription.ForLoadedType.of(int.class), TypeDescription.ForLoadedType.of(Object.class)
/* 1035 */             }, ), CompoundList.of(
/* 1036 */             Collections.singletonList(implementationContext.getInstrumentedType()), (List)instrumentedMethod
/* 1037 */             .getParameters().asTypeList(), 
/* 1038 */             Arrays.asList(new TypeDescription[] { TypeDescription.ForLoadedType.of(Object[].class), TypeDescription.ForLoadedType.of(int.class) })));
/* 1039 */       methodVisitor.visitInsn(83);
/* 1040 */       methodVisitor.visitIincInsn(3, 1);
/* 1041 */       methodVisitor.visitJumpInsn(167, loop);
/* 1042 */       methodVisitor.visitLabel(end);
/* 1043 */       implementationContext.getFrameGeneration().chop(methodVisitor, 1, CompoundList.of(
/* 1044 */             Collections.singletonList(implementationContext.getInstrumentedType()), (List)instrumentedMethod
/* 1045 */             .getParameters().asTypeList(), 
/* 1046 */             Collections.singletonList(TypeDescription.ForLoadedType.of(Object[].class))));
/* 1047 */       methodVisitor.visitVarInsn(25, 2);
/* 1048 */       methodVisitor.visitInsn(176);
/* 1049 */       return new ByteCodeAppender.Size(5, 4);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.sourceLabel.equals(((FrameTranslator)param1Object).sourceLabel) ? false : (!!this.targetLabel.equals(((FrameTranslator)param1Object).targetLabel)))));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return (getClass().hashCode() * 31 + this.sourceLabel.hashCode()) * 31 + this.targetLabel.hashCode();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   protected static class TypePathTranslator
/*      */     implements ByteCodeAppender
/*      */   {
/*      */     protected static final String NAME = "typePath";
/*      */ 
/*      */     
/*      */     private final Class<?> sourceTypePath;
/*      */ 
/*      */     
/*      */     private final Class<?> targetTypePath;
/*      */ 
/*      */     
/*      */     protected TypePathTranslator(Class<?> sourceTypePath, Class<?> targetTypePath) {
/* 1081 */       this.sourceTypePath = sourceTypePath;
/* 1082 */       this.targetTypePath = targetTypePath;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/* 1089 */       Label nullCheck = new Label(), end = new Label();
/* 1090 */       methodVisitor.visitVarInsn(25, 0);
/* 1091 */       methodVisitor.visitJumpInsn(199, nullCheck);
/* 1092 */       methodVisitor.visitInsn(1);
/* 1093 */       methodVisitor.visitJumpInsn(167, end);
/* 1094 */       implementationContext.getFrameGeneration().same(methodVisitor, (List)instrumentedMethod.getParameters().asTypeList());
/* 1095 */       methodVisitor.visitLabel(nullCheck);
/* 1096 */       methodVisitor.visitVarInsn(25, 0);
/* 1097 */       methodVisitor.visitMethodInsn(182, 
/* 1098 */           Type.getInternalName(this.sourceTypePath), "toString", 
/*      */           
/* 1100 */           Type.getMethodDescriptor(Type.getType(String.class), new Type[0]), false);
/*      */       
/* 1102 */       methodVisitor.visitMethodInsn(184, 
/* 1103 */           Type.getInternalName(this.targetTypePath), "fromString", 
/*      */           
/* 1105 */           Type.getMethodDescriptor(Type.getType(this.targetTypePath), new Type[] { Type.getType(String.class) }), false);
/*      */       
/* 1107 */       methodVisitor.visitLabel(end);
/* 1108 */       implementationContext.getFrameGeneration().same1(methodVisitor, 
/* 1109 */           (TypeDefinition)TypeDescription.ForLoadedType.of(this.targetTypePath), (List)instrumentedMethod
/* 1110 */           .getParameters().asTypeList());
/* 1111 */       methodVisitor.visitInsn(176);
/* 1112 */       return new ByteCodeAppender.Size(1, 2);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.sourceTypePath.equals(((TypePathTranslator)param1Object).sourceTypePath) ? false : (!!this.targetTypePath.equals(((TypePathTranslator)param1Object).targetTypePath)))));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return (getClass().hashCode() * 31 + this.sourceTypePath.hashCode()) * 31 + this.targetTypePath.hashCode();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   protected static class AttributeTranslator
/*      */     implements ByteCodeAppender
/*      */   {
/*      */     protected static final String NAME = "attribute";
/*      */ 
/*      */ 
/*      */     
/*      */     private final Class<?> sourceAttribute;
/*      */ 
/*      */ 
/*      */     
/*      */     private final Class<?> targetAttribute;
/*      */ 
/*      */     
/*      */     private final TypeDescription sourceWrapper;
/*      */ 
/*      */     
/*      */     private final TypeDescription targetWrapper;
/*      */ 
/*      */ 
/*      */     
/*      */     protected AttributeTranslator(Class<?> sourceAttribute, Class<?> targetAttribute, TypeDescription sourceWrapper, TypeDescription targetWrapper) {
/* 1156 */       this.sourceAttribute = sourceAttribute;
/* 1157 */       this.targetAttribute = targetAttribute;
/* 1158 */       this.sourceWrapper = sourceWrapper;
/* 1159 */       this.targetWrapper = targetWrapper;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ByteCodeAppender.Size apply(MethodVisitor methodVisitor, Implementation.Context implementationContext, MethodDescription instrumentedMethod) {
/* 1166 */       Label nullCheck = new Label(), wrapperCheck = new Label();
/* 1167 */       methodVisitor.visitVarInsn(25, 0);
/* 1168 */       methodVisitor.visitJumpInsn(199, nullCheck);
/* 1169 */       methodVisitor.visitInsn(1);
/* 1170 */       methodVisitor.visitInsn(176);
/* 1171 */       methodVisitor.visitLabel(nullCheck);
/* 1172 */       implementationContext.getFrameGeneration().same(methodVisitor, (List)instrumentedMethod.getParameters().asTypeList());
/* 1173 */       methodVisitor.visitVarInsn(25, 0);
/* 1174 */       methodVisitor.visitTypeInsn(193, this.targetWrapper.getInternalName());
/* 1175 */       methodVisitor.visitJumpInsn(153, wrapperCheck);
/* 1176 */       methodVisitor.visitVarInsn(25, 0);
/* 1177 */       methodVisitor.visitTypeInsn(192, this.targetWrapper.getInternalName());
/* 1178 */       methodVisitor.visitFieldInsn(180, this.targetWrapper.getInternalName(), "delegate", Type.getDescriptor(this.sourceAttribute));
/* 1179 */       methodVisitor.visitInsn(176);
/* 1180 */       methodVisitor.visitLabel(wrapperCheck);
/* 1181 */       implementationContext.getFrameGeneration().same(methodVisitor, (List)instrumentedMethod.getParameters().asTypeList());
/* 1182 */       methodVisitor.visitTypeInsn(187, this.sourceWrapper.getInternalName());
/* 1183 */       methodVisitor.visitInsn(89);
/* 1184 */       methodVisitor.visitVarInsn(25, 0);
/* 1185 */       methodVisitor.visitMethodInsn(183, this.sourceWrapper
/* 1186 */           .getInternalName(), "<init>", 
/*      */           
/* 1188 */           Type.getMethodDescriptor(Type.VOID_TYPE, new Type[] { Type.getType(this.targetAttribute) }), false);
/*      */       
/* 1190 */       methodVisitor.visitInsn(176);
/* 1191 */       return new ByteCodeAppender.Size(3, 1);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.sourceAttribute.equals(((AttributeTranslator)param1Object).sourceAttribute) ? false : (!this.targetAttribute.equals(((AttributeTranslator)param1Object).targetAttribute) ? false : (!this.sourceWrapper.equals(((AttributeTranslator)param1Object).sourceWrapper) ? false : (!!this.targetWrapper.equals(((AttributeTranslator)param1Object).targetWrapper)))))));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int hashCode() {
/*      */       return (((getClass().hashCode() * 31 + this.sourceAttribute.hashCode()) * 31 + this.targetAttribute.hashCode()) * 31 + this.sourceWrapper.hashCode()) * 31 + this.targetWrapper.hashCode();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Enhance
/*      */   protected static class CreateClassVisitorFactory<S>
/*      */     implements PrivilegedAction<ClassVisitorFactory<S>>
/*      */   {
/*      */     private final Class<S> classVisitor;
/*      */ 
/*      */     
/*      */     private final ByteBuddy byteBuddy;
/*      */ 
/*      */     
/*      */     protected CreateClassVisitorFactory(Class<S> classVisitor, ByteBuddy byteBuddy) {
/* 1220 */       this.classVisitor = classVisitor;
/* 1221 */       this.byteBuddy = byteBuddy;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ClassVisitorFactory<S> run() {
/* 1228 */       if (!ClassVisitor.class.getSimpleName().equals(this.classVisitor.getSimpleName()))
/* 1229 */         throw new IllegalArgumentException("Expected a class named " + ClassVisitor.class.getSimpleName() + ": " + this.classVisitor); 
/*      */       try {
/*      */         DynamicType sourceAttribute, targetAttribute;
/* 1232 */         String prefix = this.classVisitor.getPackage().getName();
/* 1233 */         Map<Class<?>, Class<?>> utilities = new HashMap<Class<?>, Class<?>>();
/* 1234 */         for (Class<?> type : Arrays.<Class<?>[]>asList((Class<?>[][])new Class[] { Attribute.class, Label.class, Type.class, TypePath.class, Handle.class, ConstantDynamic.class })) {
/*      */           Class<?> utility;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           try {
/* 1244 */             utility = Class.forName(prefix + "." + type.getSimpleName(), false, this.classVisitor.getClassLoader());
/* 1245 */           } catch (ClassNotFoundException ignored) {
/*      */             continue;
/*      */           } 
/* 1248 */           utilities.put(type, utility);
/*      */         } 
/* 1250 */         if (utilities.containsKey(Label.class)) {
/* 1251 */           utilities.put(Label[].class, Class.forName("[L" + ((Class)utilities.get(Label.class)).getName() + ";", false, this.classVisitor.getClassLoader()));
/*      */         }
/* 1253 */         Map<Class<?>, Class<?>> equivalents = new HashMap<Class<?>, Class<?>>();
/* 1254 */         Map<Class<?>, DynamicType.Builder<?>> builders = new HashMap<Class<?>, DynamicType.Builder<?>>();
/* 1255 */         for (Class<?> type : Arrays.<Class<?>[]>asList((Class<?>[][])new Class[] { ClassVisitor.class, AnnotationVisitor.class, ModuleVisitor.class, RecordComponentVisitor.class, FieldVisitor.class, MethodVisitor.class })) {
/*      */           Class<?> equivalent;
/*      */ 
/*      */ 
/*      */           
/*      */           DynamicType.Builder<?> wrapper, unwrapper;
/*      */ 
/*      */ 
/*      */           
/*      */           try {
/* 1265 */             equivalent = Class.forName(prefix + "." + type.getSimpleName(), false, this.classVisitor.getClassLoader());
/* 1266 */           } catch (ClassNotFoundException ignored) {
/*      */             continue;
/*      */           } 
/*      */           
/* 1270 */           if (type == MethodVisitor.class) {
/* 1271 */             wrapper = ClassVisitorFactory.toMethodVisitorBuilder(this.byteBuddy, type, equivalent, TypePath.class, utilities
/*      */                 
/* 1273 */                 .get(TypePath.class), Label.class, utilities
/* 1274 */                 .get(Label.class), Type.class, utilities
/* 1275 */                 .get(Type.class), Handle.class, utilities
/* 1276 */                 .get(Handle.class), ConstantDynamic.class, utilities
/* 1277 */                 .get(ConstantDynamic.class));
/* 1278 */             unwrapper = ClassVisitorFactory.toMethodVisitorBuilder(this.byteBuddy, equivalent, type, utilities
/*      */                 
/* 1280 */                 .get(TypePath.class), TypePath.class, utilities
/* 1281 */                 .get(Label.class), Label.class, utilities
/* 1282 */                 .get(Type.class), Type.class, utilities
/* 1283 */                 .get(Handle.class), Handle.class, utilities
/* 1284 */                 .get(ConstantDynamic.class), ConstantDynamic.class);
/*      */           } else {
/* 1286 */             wrapper = ClassVisitorFactory.toVisitorBuilder(this.byteBuddy, type, equivalent, TypePath.class, utilities
/*      */                 
/* 1288 */                 .get(TypePath.class), (Implementation)new Implementation.Simple(new StackManipulation[] { (StackManipulation)MethodReturn.VOID }));
/*      */             
/* 1290 */             unwrapper = ClassVisitorFactory.toVisitorBuilder(this.byteBuddy, equivalent, type, utilities
/*      */                 
/* 1292 */                 .get(TypePath.class), TypePath.class, (Implementation)new Implementation.Simple(new StackManipulation[] { (StackManipulation)MethodReturn.VOID }));
/*      */           } 
/*      */           
/* 1295 */           equivalents.put(type, equivalent);
/* 1296 */           builders.put(type, wrapper);
/* 1297 */           builders.put(equivalent, unwrapper);
/*      */         } 
/* 1299 */         List<DynamicType> dynamicTypes = new ArrayList<DynamicType>();
/* 1300 */         Map<Class<?>, TypeDescription> generated = new HashMap<Class<?>, TypeDescription>();
/*      */         
/* 1302 */         if (utilities.containsKey(Attribute.class)) {
/* 1303 */           DynamicType.Builder<?> source = this.byteBuddy.subclass(Attribute.class, (ConstructorStrategy)ConstructorStrategy.Default.NO_CONSTRUCTORS);
/* 1304 */           DynamicType.Builder<?> target = this.byteBuddy.subclass(utilities.get(Attribute.class), (ConstructorStrategy)ConstructorStrategy.Default.NO_CONSTRUCTORS);
/* 1305 */           sourceAttribute = ClassVisitorFactory.toAttributeWrapper(source, Attribute.class, utilities.get(Attribute.class), source.toTypeDescription(), target.toTypeDescription());
/* 1306 */           dynamicTypes.add(sourceAttribute);
/* 1307 */           targetAttribute = ClassVisitorFactory.toAttributeWrapper(target, utilities.get(Attribute.class), Attribute.class, target.toTypeDescription(), source.toTypeDescription());
/* 1308 */           dynamicTypes.add(targetAttribute);
/*      */         } else {
/* 1310 */           sourceAttribute = null;
/* 1311 */           targetAttribute = null;
/*      */         } 
/* 1313 */         for (Map.Entry<Class<?>, Class<?>> entry : equivalents.entrySet()) {
/* 1314 */           DynamicType.Builder.MethodDefinition.ReceiverTypeDefinition receiverTypeDefinition1, receiverTypeDefinition2; DynamicType.Builder<?> wrapper = builders.get(entry.getKey()), unwrapper = builders.get(entry.getValue());
/* 1315 */           for (Method method : ((Class)entry.getKey()).getMethods()) {
/* 1316 */             if (method.getDeclaringClass() != Object.class) {
/*      */               Method target;
/*      */               
/* 1319 */               Class<?>[] parameter = method.getParameterTypes(), match = new Class[parameter.length];
/* 1320 */               List<MethodCall.ArgumentLoader.Factory> left = new ArrayList<MethodCall.ArgumentLoader.Factory>(parameter.length);
/* 1321 */               List<MethodCall.ArgumentLoader.Factory> right = new ArrayList<MethodCall.ArgumentLoader.Factory>(match.length);
/* 1322 */               boolean unsupported = false, unresolved = false;
/* 1323 */               int offset = 1;
/* 1324 */               for (int index = 0; index < parameter.length; index++) {
/* 1325 */                 if (entry.getKey() == MethodVisitor.class && parameter[index] == Label.class) {
/* 1326 */                   match[index] = utilities.get(Label.class);
/* 1327 */                   left.add(ClassVisitorFactory.toConvertedParameter(((DynamicType.Builder)builders.get(entry.getKey())).toTypeDescription(), match[index], "label", offset, true));
/* 1328 */                   right.add(ClassVisitorFactory.toConvertedParameter(((DynamicType.Builder)builders.get(entry.getValue())).toTypeDescription(), parameter[index], "label", offset, true));
/* 1329 */                 } else if (entry.getKey() == MethodVisitor.class && parameter[index] == Label[].class) {
/* 1330 */                   match[index] = utilities.get(Label[].class);
/* 1331 */                   left.add(ClassVisitorFactory.toConvertedParameter(((DynamicType.Builder)builders.get(entry.getKey())).toTypeDescription(), match[index], "labels", offset, true));
/* 1332 */                   right.add(ClassVisitorFactory.toConvertedParameter(((DynamicType.Builder)builders.get(entry.getValue())).toTypeDescription(), parameter[index], "labels", offset, true));
/* 1333 */                 } else if (parameter[index] == TypePath.class) {
/* 1334 */                   match[index] = utilities.get(TypePath.class);
/* 1335 */                   left.add(ClassVisitorFactory.toConvertedParameter(((DynamicType.Builder)builders.get(entry.getKey())).toTypeDescription(), match[index], "typePath", offset, false));
/* 1336 */                   right.add(ClassVisitorFactory.toConvertedParameter(((DynamicType.Builder)builders.get(entry.getValue())).toTypeDescription(), parameter[index], "typePath", offset, false));
/* 1337 */                 } else if (entry.getKey() == MethodVisitor.class && parameter[index] == Handle.class) {
/* 1338 */                   match[index] = utilities.get(Handle.class);
/* 1339 */                   left.add(ClassVisitorFactory.toConvertedParameter(((DynamicType.Builder)builders.get(entry.getKey())).toTypeDescription(), match[index], "handle", offset, false));
/* 1340 */                   right.add(ClassVisitorFactory.toConvertedParameter(((DynamicType.Builder)builders.get(entry.getValue())).toTypeDescription(), parameter[index], "handle", offset, false));
/* 1341 */                 } else if (entry.getKey() == MethodVisitor.class && parameter[index] == Object.class) {
/* 1342 */                   match[index] = Object.class;
/* 1343 */                   left.add(ClassVisitorFactory.toConvertedParameter(((DynamicType.Builder)builders.get(entry.getKey())).toTypeDescription(), Object.class, "constant", offset, false));
/* 1344 */                   right.add(ClassVisitorFactory.toConvertedParameter(((DynamicType.Builder)builders.get(entry.getValue())).toTypeDescription(), Object.class, "constant", offset, false));
/* 1345 */                 } else if (entry.getKey() == MethodVisitor.class && parameter[index] == Object[].class) {
/* 1346 */                   match[index] = Object[].class;
/* 1347 */                   if (method.getName().equals("visitFrame")) {
/* 1348 */                     left.add(ClassVisitorFactory.toConvertedParameter(((DynamicType.Builder)builders.get(entry.getKey())).toTypeDescription(), Object[].class, "frames", offset, true));
/* 1349 */                     right.add(ClassVisitorFactory.toConvertedParameter(((DynamicType.Builder)builders.get(entry.getValue())).toTypeDescription(), Object[].class, "frames", offset, true));
/*      */                   } else {
/* 1351 */                     left.add(ClassVisitorFactory.toConvertedParameter(((DynamicType.Builder)builders.get(entry.getKey())).toTypeDescription(), Object[].class, "constants", offset, false));
/* 1352 */                     right.add(ClassVisitorFactory.toConvertedParameter(((DynamicType.Builder)builders.get(entry.getValue())).toTypeDescription(), Object[].class, "constants", offset, false));
/*      */                   } 
/* 1354 */                 } else if (parameter[index] == Attribute.class) {
/* 1355 */                   match[index] = utilities.get(Attribute.class);
/* 1356 */                   if (sourceAttribute != null && targetAttribute != null) {
/* 1357 */                     left.add(ClassVisitorFactory.toConvertedParameter(targetAttribute.getTypeDescription(), utilities.get(Attribute.class), "attribute", offset, false));
/* 1358 */                     right.add(ClassVisitorFactory.toConvertedParameter(sourceAttribute.getTypeDescription(), Attribute.class, "attribute", offset, false));
/*      */                   } else {
/* 1360 */                     unsupported = true;
/*      */                   } 
/*      */                 } else {
/* 1363 */                   match[index] = parameter[index];
/* 1364 */                   left.add(new MethodCall.ArgumentLoader.ForMethodParameter.Factory(index));
/* 1365 */                   right.add(new MethodCall.ArgumentLoader.ForMethodParameter.Factory(index));
/*      */                 } 
/* 1367 */                 if (match[index] == null) {
/* 1368 */                   unresolved = true;
/*      */                   break;
/*      */                 } 
/* 1371 */                 offset += (parameter[index] == long.class || parameter[index] == double.class) ? 2 : 1;
/*      */               } 
/*      */               
/* 1374 */               if (unresolved) {
/* 1375 */                 target = null;
/* 1376 */                 unsupported = true;
/*      */               } else {
/*      */                 try {
/* 1379 */                   target = ((Class)entry.getValue()).getMethod(method.getName(), match);
/* 1380 */                 } catch (NoSuchMethodException ignored) {
/* 1381 */                   target = null;
/* 1382 */                   unsupported = true;
/*      */                 } 
/*      */               } 
/* 1385 */               if (unsupported) {
/* 1386 */                 receiverTypeDefinition1 = wrapper.method((ElementMatcher)ElementMatchers.is(method)).intercept(ExceptionMethod.throwing(UnsupportedOperationException.class));
/* 1387 */                 if (target != null) {
/* 1388 */                   receiverTypeDefinition2 = unwrapper.method((ElementMatcher)ElementMatchers.is(target)).intercept(ExceptionMethod.throwing(UnsupportedOperationException.class));
/*      */                 }
/*      */               } else {
/* 1391 */                 MethodCall wrapping = MethodCall.invoke(target).onField("delegate").with(left);
/* 1392 */                 MethodCall unwrapping = MethodCall.invoke(method).onField("delegate").with(right);
/* 1393 */                 Class<?> returned = equivalents.get(method.getReturnType());
/* 1394 */                 if (returned != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/* 1399 */                   wrapping = MethodCall.invoke((MethodDescription)((MethodList)((DynamicType.Builder)builders.get(method.getReturnType())).toTypeDescription().getDeclaredMethods().filter((ElementMatcher)ElementMatchers.named("wrap"))).getOnly()).withMethodCall(wrapping);
/*      */ 
/*      */ 
/*      */                   
/* 1403 */                   unwrapping = MethodCall.invoke((MethodDescription)((MethodList)((DynamicType.Builder)builders.get(returned)).toTypeDescription().getDeclaredMethods().filter((ElementMatcher)ElementMatchers.named("wrap"))).getOnly()).withMethodCall(unwrapping);
/*      */                 } 
/* 1405 */                 receiverTypeDefinition1 = receiverTypeDefinition1.method((ElementMatcher)ElementMatchers.is(method)).intercept((Implementation)wrapping);
/* 1406 */                 receiverTypeDefinition2 = receiverTypeDefinition2.method((ElementMatcher)ElementMatchers.is(target)).intercept((Implementation)unwrapping);
/*      */               } 
/*      */             } 
/* 1409 */           }  DynamicType.Unloaded unloaded1 = receiverTypeDefinition1.make(), unloaded2 = receiverTypeDefinition2.make();
/* 1410 */           generated.put(entry.getKey(), unloaded1.getTypeDescription());
/* 1411 */           generated.put(entry.getValue(), unloaded2.getTypeDescription());
/* 1412 */           dynamicTypes.add(unloaded1);
/* 1413 */           dynamicTypes.add(unloaded2);
/*      */         } 
/*      */ 
/*      */         
/* 1417 */         ClassLoader classLoader = (new MultipleParentClassLoader.Builder(false)).appendMostSpecific(new Class[] { ClassVisitor.class, this.classVisitor }).build();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1433 */         ClassVisitorFactory<S> factory = this.byteBuddy.subclass(ClassVisitorFactory.class, (ConstructorStrategy)ConstructorStrategy.Default.IMITATE_SUPER_CLASS_OPENING).method((ElementMatcher)ElementMatchers.named("wrap")).intercept((Implementation)MethodCall.construct((MethodDescription)((MethodList)((TypeDescription)generated.get(this.classVisitor)).getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isConstructor())).getOnly()).withArgument(new int[] { 0 })).method((ElementMatcher)ElementMatchers.named("unwrap")).intercept((Implementation)MethodCall.construct((MethodDescription)((MethodList)((TypeDescription)generated.get(ClassVisitor.class)).getDeclaredMethods().filter((ElementMatcher)ElementMatchers.isConstructor())).getOnly()).withArgument(new int[] { 0 }).withAssigner(Assigner.DEFAULT, Assigner.Typing.DYNAMIC)).make().include(dynamicTypes).load(classLoader).getLoaded().getConstructor(new Class[] { Class.class }).newInstance(new Object[] { this.classVisitor });
/* 1434 */         if (classLoader instanceof MultipleParentClassLoader && classLoader != ClassVisitor.class
/* 1435 */           .getClassLoader() && classLoader != this.classVisitor
/* 1436 */           .getClassLoader() && 
/* 1437 */           !((MultipleParentClassLoader)classLoader).seal()) {
/* 1438 */           throw new IllegalStateException("Failed to seal multiple parent class loader: " + classLoader);
/*      */         }
/* 1440 */         return factory;
/* 1441 */       } catch (Exception exception) {
/* 1442 */         throw new IllegalArgumentException("Failed to generate factory for " + this.classVisitor.getName(), exception);
/*      */       } 
/*      */     }
/*      */     
/*      */     public boolean equals(@MaybeNull Object param1Object) {
/*      */       return (this == param1Object) ? true : ((param1Object == null) ? false : ((getClass() != param1Object.getClass()) ? false : (!this.classVisitor.equals(((CreateClassVisitorFactory)param1Object).classVisitor) ? false : (!!this.byteBuddy.equals(((CreateClassVisitorFactory)param1Object).byteBuddy)))));
/*      */     }
/*      */     
/*      */     public int hashCode() {
/*      */       return (getClass().hashCode() * 31 + this.classVisitor.hashCode()) * 31 + this.byteBuddy.hashCode();
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\byte-buddy-1.17.8.jar!\net\bytebuddy\asm\ClassVisitorFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */