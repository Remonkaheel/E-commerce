module com.sun.istack.runtime {
  requires java.base;
  requires transitive java.logging;
  requires transitive java.xml;
  requires transitive jakarta.activation;
  
  exports com.sun.istack;
  exports com.sun.istack.localization;
  exports com.sun.istack.logging;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\module-info.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */