/*    */ package com.sun.istack;
/*    */ 
/*    */ import org.xml.sax.ContentHandler;
/*    */ import org.xml.sax.SAXException;
/*    */ import org.xml.sax.XMLReader;
/*    */ import org.xml.sax.helpers.XMLFilterImpl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FragmentContentHandler
/*    */   extends XMLFilterImpl
/*    */ {
/*    */   public FragmentContentHandler() {}
/*    */   
/*    */   public FragmentContentHandler(XMLReader parent) {
/* 27 */     super(parent);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public FragmentContentHandler(ContentHandler handler) {
/* 33 */     setContentHandler(handler);
/*    */   }
/*    */   
/*    */   public void startDocument() throws SAXException {}
/*    */   
/*    */   public void endDocument() throws SAXException {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\com\sun\istack\FragmentContentHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */