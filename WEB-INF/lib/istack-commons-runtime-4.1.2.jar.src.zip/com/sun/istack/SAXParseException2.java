/*    */ package com.sun.istack;
/*    */ 
/*    */ import org.xml.sax.Locator;
/*    */ import org.xml.sax.SAXParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SAXParseException2
/*    */   extends SAXParseException
/*    */ {
/*    */   private static final long serialVersionUID = 1304853690034671001L;
/*    */   
/*    */   public SAXParseException2(String message, Locator locator) {
/* 27 */     super(message, locator);
/*    */   }
/*    */   
/*    */   public SAXParseException2(String message, Locator locator, Exception e) {
/* 31 */     super(message, locator, e);
/*    */   }
/*    */   
/*    */   public SAXParseException2(String message, String publicId, String systemId, int lineNumber, int columnNumber) {
/* 35 */     super(message, publicId, systemId, lineNumber, columnNumber);
/*    */   }
/*    */   
/*    */   public SAXParseException2(String message, String publicId, String systemId, int lineNumber, int columnNumber, Exception e) {
/* 39 */     super(message, publicId, systemId, lineNumber, columnNumber, e);
/*    */   }
/*    */ 
/*    */   
/*    */   public Throwable getCause() {
/* 44 */     return getException();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\com\sun\istack\SAXParseException2.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */