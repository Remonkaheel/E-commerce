/*    */ package com.sun.istack;
/*    */ 
/*    */ import jakarta.activation.DataSource;
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ByteArrayDataSource
/*    */   implements DataSource
/*    */ {
/*    */   private final String contentType;
/*    */   private final byte[] buf;
/*    */   private final int len;
/*    */   
/*    */   public ByteArrayDataSource(byte[] buf, String contentType) {
/* 34 */     this(buf, buf.length, contentType);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ByteArrayDataSource(byte[] buf, int length, String contentType) {
/* 43 */     this.buf = buf;
/* 44 */     this.len = length;
/* 45 */     this.contentType = contentType;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getContentType() {
/* 50 */     if (this.contentType == null)
/* 51 */       return "application/octet-stream"; 
/* 52 */     return this.contentType;
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream getInputStream() {
/* 57 */     return new ByteArrayInputStream(this.buf, 0, this.len);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 62 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public OutputStream getOutputStream() {
/* 67 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\com\sun\istack\ByteArrayDataSource.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */