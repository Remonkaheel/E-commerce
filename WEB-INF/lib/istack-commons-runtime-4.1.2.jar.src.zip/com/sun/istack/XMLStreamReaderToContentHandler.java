/*     */ package com.sun.istack;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamReader;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.AttributesImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLStreamReaderToContentHandler
/*     */ {
/*     */   private final XMLStreamReader staxStreamReader;
/*     */   private final ContentHandler saxHandler;
/*     */   private final boolean eagerQuit;
/*     */   private final boolean fragment;
/*     */   private final String[] inscopeNamespaces;
/*     */   
/*     */   public XMLStreamReaderToContentHandler(XMLStreamReader staxCore, ContentHandler saxCore, boolean eagerQuit, boolean fragment) {
/*  61 */     this(staxCore, saxCore, eagerQuit, fragment, new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XMLStreamReaderToContentHandler(XMLStreamReader staxCore, ContentHandler saxCore, boolean eagerQuit, boolean fragment, String[] inscopeNamespaces) {
/*  77 */     this.staxStreamReader = staxCore;
/*  78 */     this.saxHandler = saxCore;
/*  79 */     this.eagerQuit = eagerQuit;
/*  80 */     this.fragment = fragment;
/*  81 */     this.inscopeNamespaces = (String[])inscopeNamespaces.clone();
/*  82 */     assert inscopeNamespaces.length % 2 == 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bridge() throws XMLStreamException {
/*     */     try {
/*  93 */       int depth = 0;
/*     */ 
/*     */       
/*  96 */       int event = this.staxStreamReader.getEventType();
/*  97 */       if (event == 7)
/*     */       {
/*  99 */         while (!this.staxStreamReader.isStartElement()) {
/* 100 */           event = this.staxStreamReader.next();
/*     */         }
/*     */       }
/*     */       
/* 104 */       if (event != 1) {
/* 105 */         throw new IllegalStateException("The current event is not START_ELEMENT\n but " + event);
/*     */       }
/* 107 */       handleStartDocument();
/*     */       int i;
/* 109 */       for (i = 0; i < this.inscopeNamespaces.length; i += 2) {
/* 110 */         this.saxHandler.startPrefixMapping(this.inscopeNamespaces[i], this.inscopeNamespaces[i + 1]);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       do {
/* 118 */         switch (event) {
/*     */           case 1:
/* 120 */             depth++;
/* 121 */             handleStartElement();
/*     */             break;
/*     */           case 2:
/* 124 */             handleEndElement();
/* 125 */             depth--;
/* 126 */             if (depth == 0 && this.eagerQuit)
/*     */               break; 
/*     */             break;
/*     */           case 4:
/* 130 */             handleCharacters();
/*     */             break;
/*     */           case 9:
/* 133 */             handleEntityReference();
/*     */             break;
/*     */           case 3:
/* 136 */             handlePI();
/*     */             break;
/*     */           case 5:
/* 139 */             handleComment();
/*     */             break;
/*     */           case 11:
/* 142 */             handleDTD();
/*     */             break;
/*     */           case 10:
/* 145 */             handleAttribute();
/*     */             break;
/*     */           case 13:
/* 148 */             handleNamespace();
/*     */             break;
/*     */           case 12:
/* 151 */             handleCDATA();
/*     */             break;
/*     */           case 15:
/* 154 */             handleEntityDecl();
/*     */             break;
/*     */           case 14:
/* 157 */             handleNotationDecl();
/*     */             break;
/*     */           case 6:
/* 160 */             handleSpace();
/*     */             break;
/*     */           default:
/* 163 */             throw new InternalError("processing event: " + event);
/*     */         } 
/*     */         
/* 166 */         event = this.staxStreamReader.next();
/* 167 */       } while (depth != 0);
/*     */       
/* 169 */       for (i = 0; i < this.inscopeNamespaces.length; i += 2) {
/* 170 */         this.saxHandler.endPrefixMapping(this.inscopeNamespaces[i]);
/*     */       }
/*     */       
/* 173 */       handleEndDocument();
/* 174 */     } catch (SAXException e) {
/* 175 */       throw new XMLStreamException2(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleEndDocument() throws SAXException {
/* 180 */     if (this.fragment) {
/*     */       return;
/*     */     }
/* 183 */     this.saxHandler.endDocument();
/*     */   }
/*     */   
/*     */   private void handleStartDocument() throws SAXException {
/* 187 */     if (this.fragment) {
/*     */       return;
/*     */     }
/* 190 */     this.saxHandler.setDocumentLocator(new Locator()
/*     */         {
/*     */           public int getColumnNumber() {
/* 193 */             return XMLStreamReaderToContentHandler.this.staxStreamReader.getLocation().getColumnNumber();
/*     */           }
/*     */           
/*     */           public int getLineNumber() {
/* 197 */             return XMLStreamReaderToContentHandler.this.staxStreamReader.getLocation().getLineNumber();
/*     */           }
/*     */           
/*     */           public String getPublicId() {
/* 201 */             return XMLStreamReaderToContentHandler.this.staxStreamReader.getLocation().getPublicId();
/*     */           }
/*     */           
/*     */           public String getSystemId() {
/* 205 */             return XMLStreamReaderToContentHandler.this.staxStreamReader.getLocation().getSystemId();
/*     */           }
/*     */         });
/* 208 */     this.saxHandler.startDocument();
/*     */   }
/*     */   
/*     */   private void handlePI() throws XMLStreamException {
/*     */     try {
/* 213 */       this.saxHandler.processingInstruction(this.staxStreamReader
/* 214 */           .getPITarget(), this.staxStreamReader
/* 215 */           .getPIData());
/* 216 */     } catch (SAXException e) {
/* 217 */       throw new XMLStreamException2(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleCharacters() throws XMLStreamException {
/*     */     try {
/* 223 */       this.saxHandler.characters(this.staxStreamReader
/* 224 */           .getTextCharacters(), this.staxStreamReader
/* 225 */           .getTextStart(), this.staxStreamReader
/* 226 */           .getTextLength());
/* 227 */     } catch (SAXException e) {
/* 228 */       throw new XMLStreamException2(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleEndElement() throws XMLStreamException {
/* 233 */     QName qName = this.staxStreamReader.getName();
/*     */     
/*     */     try {
/* 236 */       String pfix = qName.getPrefix();
/*     */ 
/*     */       
/* 239 */       String rawname = (pfix == null || pfix.length() == 0) ? qName.getLocalPart() : (pfix + ":" + pfix);
/*     */       
/* 241 */       this.saxHandler.endElement(qName
/* 242 */           .getNamespaceURI(), qName
/* 243 */           .getLocalPart(), rawname);
/*     */ 
/*     */ 
/*     */       
/* 247 */       int nsCount = this.staxStreamReader.getNamespaceCount();
/* 248 */       for (int i = nsCount - 1; i >= 0; i--) {
/* 249 */         String prefix = this.staxStreamReader.getNamespacePrefix(i);
/* 250 */         if (prefix == null) {
/* 251 */           prefix = "";
/*     */         }
/* 253 */         this.saxHandler.endPrefixMapping(prefix);
/*     */       } 
/* 255 */     } catch (SAXException e) {
/* 256 */       throw new XMLStreamException2(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void handleStartElement() throws XMLStreamException {
/*     */     try {
/*     */       String rawname;
/* 264 */       int nsCount = this.staxStreamReader.getNamespaceCount();
/* 265 */       for (int i = 0; i < nsCount; i++) {
/* 266 */         this.saxHandler.startPrefixMapping(
/* 267 */             fixNull(this.staxStreamReader.getNamespacePrefix(i)), 
/* 268 */             fixNull(this.staxStreamReader.getNamespaceURI(i)));
/*     */       }
/*     */ 
/*     */       
/* 272 */       QName qName = this.staxStreamReader.getName();
/* 273 */       String prefix = qName.getPrefix();
/*     */       
/* 275 */       if (prefix == null || prefix.length() == 0) {
/* 276 */         rawname = qName.getLocalPart();
/*     */       } else {
/* 278 */         rawname = prefix + ":" + prefix;
/* 279 */       }  Attributes attrs = getAttributes();
/* 280 */       this.saxHandler.startElement(qName
/* 281 */           .getNamespaceURI(), qName
/* 282 */           .getLocalPart(), rawname, attrs);
/*     */     
/*     */     }
/* 285 */     catch (SAXException e) {
/* 286 */       throw new XMLStreamException2(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String fixNull(String s) {
/* 291 */     if (s == null) return ""; 
/* 292 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Attributes getAttributes() {
/* 302 */     AttributesImpl attrs = new AttributesImpl();
/*     */     
/* 304 */     int eventType = this.staxStreamReader.getEventType();
/* 305 */     if (eventType != 10 && eventType != 1)
/*     */     {
/* 307 */       throw new InternalError("getAttributes() attempting to process: " + eventType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 316 */     for (int i = 0; i < this.staxStreamReader.getAttributeCount(); i++) {
/* 317 */       String qName, uri = this.staxStreamReader.getAttributeNamespace(i);
/* 318 */       if (uri == null) uri = ""; 
/* 319 */       String localName = this.staxStreamReader.getAttributeLocalName(i);
/* 320 */       String prefix = this.staxStreamReader.getAttributePrefix(i);
/*     */       
/* 322 */       if (prefix == null || prefix.length() == 0) {
/* 323 */         qName = localName;
/*     */       } else {
/* 325 */         qName = prefix + ":" + prefix;
/* 326 */       }  String type = this.staxStreamReader.getAttributeType(i);
/* 327 */       String value = this.staxStreamReader.getAttributeValue(i);
/*     */       
/* 329 */       attrs.addAttribute(uri, localName, qName, type, value);
/*     */     } 
/*     */     
/* 332 */     return attrs;
/*     */   }
/*     */   
/*     */   private void handleNamespace() {}
/*     */   
/*     */   private void handleAttribute() {}
/*     */   
/*     */   private void handleDTD() {}
/*     */   
/*     */   private void handleComment() {}
/*     */   
/*     */   private void handleEntityReference() {}
/*     */   
/*     */   private void handleSpace() {}
/*     */   
/*     */   private void handleNotationDecl() {}
/*     */   
/*     */   private void handleEntityDecl() {}
/*     */   
/*     */   private void handleCDATA() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\com\sun\istack\XMLStreamReaderToContentHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */