/*    */ package com.sun.istack;
/*    */ 
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SAXException2
/*    */   extends SAXException
/*    */ {
/*    */   private static final long serialVersionUID = -707119042406163844L;
/*    */   
/*    */   public SAXException2(String message) {
/* 26 */     super(message);
/*    */   }
/*    */   
/*    */   public SAXException2(Exception e) {
/* 30 */     super(e);
/*    */   }
/*    */   
/*    */   public SAXException2(String message, Exception e) {
/* 34 */     super(message, e);
/*    */   }
/*    */ 
/*    */   
/*    */   public Throwable getCause() {
/* 39 */     return getException();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\com\sun\istack\SAXException2.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */