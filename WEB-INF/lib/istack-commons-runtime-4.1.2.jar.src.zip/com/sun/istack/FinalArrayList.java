/*    */ package com.sun.istack;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class FinalArrayList<T>
/*    */   extends ArrayList<T>
/*    */ {
/*    */   private static final long serialVersionUID = -540534530037816397L;
/*    */   
/*    */   public FinalArrayList(int initialCapacity) {
/* 30 */     super(initialCapacity);
/*    */   }
/*    */ 
/*    */   
/*    */   public FinalArrayList() {}
/*    */   
/*    */   public FinalArrayList(Collection<? extends T> ts) {
/* 37 */     super(ts);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\com\sun\istack\FinalArrayList.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */