/*    */ package com.sun.istack;
/*    */ 
/*    */ import javax.xml.stream.Location;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XMLStreamException2
/*    */   extends XMLStreamException
/*    */ {
/*    */   private static final long serialVersionUID = 1409033131880742500L;
/*    */   
/*    */   public XMLStreamException2(String msg) {
/* 26 */     super(msg);
/*    */   }
/*    */   
/*    */   public XMLStreamException2(Throwable th) {
/* 30 */     super(th);
/*    */   }
/*    */   
/*    */   public XMLStreamException2(String msg, Throwable th) {
/* 34 */     super(msg, th);
/*    */   }
/*    */   
/*    */   public XMLStreamException2(String msg, Location location) {
/* 38 */     super(msg, location);
/*    */   }
/*    */   
/*    */   public XMLStreamException2(String msg, Location location, Throwable th) {
/* 42 */     super(msg, location, th);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Throwable getCause() {
/* 50 */     return getNestedException();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\com\sun\istack\XMLStreamException2.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */