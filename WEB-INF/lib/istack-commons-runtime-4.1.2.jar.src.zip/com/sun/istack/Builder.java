package com.sun.istack;

public interface Builder<T> {
  T build();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\com\sun\istack\Builder.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */