/*    */ package com.sun.istack.logging;
/*    */ 
/*    */ import java.util.stream.Stream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StackHelper
/*    */ {
/*    */   static String getCallerMethodName() {
/* 27 */     return StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE)
/* 28 */       .<String>walk(frames -> (String)frames.dropWhile(()).dropWhile(()).findFirst().map(StackWalker.StackFrame::getMethodName).orElse("UNKNOWN METHOD"));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\com\sun\istack\logging\StackHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */