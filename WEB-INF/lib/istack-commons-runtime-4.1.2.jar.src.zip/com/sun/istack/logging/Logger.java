/*     */ package com.sun.istack.logging;
/*     */ 
/*     */ import com.sun.istack.NotNull;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.logging.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Logger
/*     */ {
/*     */   private static final String WS_LOGGING_SUBSYSTEM_NAME_ROOT = "com.sun.metro";
/*     */   private static final String ROOT_WS_PACKAGE = "com.sun.xml.ws.";
/*  33 */   private static final Level METHOD_CALL_LEVEL_VALUE = Level.FINEST;
/*     */ 
/*     */   
/*     */   private final String componentClassName;
/*     */ 
/*     */   
/*     */   private final java.util.logging.Logger logger;
/*     */ 
/*     */ 
/*     */   
/*     */   protected Logger(String systemLoggerName, String componentName) {
/*  44 */     this.componentClassName = "[" + componentName + "] ";
/*  45 */     this.logger = java.util.logging.Logger.getLogger(systemLoggerName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static Logger getLogger(@NotNull Class<?> componentClass) {
/*  64 */     return new Logger(getSystemLoggerName(componentClass), componentClass.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public static Logger getLogger(@NotNull String customLoggerName, @NotNull Class<?> componentClass) {
/*  84 */     return new Logger(customLoggerName, componentClass.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String getSystemLoggerName(@NotNull Class<?> componentClass) {
/*  93 */     StringBuilder sb = new StringBuilder(componentClass.getPackage().getName());
/*  94 */     int lastIndexOfWsPackage = sb.lastIndexOf("com.sun.xml.ws.");
/*  95 */     if (lastIndexOfWsPackage > -1) {
/*  96 */       sb.replace(0, lastIndexOfWsPackage + "com.sun.xml.ws.".length(), "");
/*     */       
/*  98 */       StringTokenizer st = new StringTokenizer(sb.toString(), ".");
/*  99 */       sb = (new StringBuilder("com.sun.metro")).append(".");
/* 100 */       if (st.hasMoreTokens()) {
/* 101 */         String token = st.nextToken();
/* 102 */         if ("api".equals(token)) {
/* 103 */           token = st.nextToken();
/*     */         }
/* 105 */         sb.append(token);
/*     */       } 
/*     */     } 
/*     */     
/* 109 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public void log(Level level, String message) {
/* 113 */     if (!this.logger.isLoggable(level)) {
/*     */       return;
/*     */     }
/* 116 */     this.logger.logp(level, this.componentClassName, StackHelper.getCallerMethodName(), message);
/*     */   }
/*     */   
/*     */   public void log(Level level, String message, Object param1) {
/* 120 */     if (!this.logger.isLoggable(level)) {
/*     */       return;
/*     */     }
/* 123 */     this.logger.logp(level, this.componentClassName, StackHelper.getCallerMethodName(), message, param1);
/*     */   }
/*     */   
/*     */   public void log(Level level, String message, Object[] params) {
/* 127 */     if (!this.logger.isLoggable(level)) {
/*     */       return;
/*     */     }
/* 130 */     this.logger.logp(level, this.componentClassName, StackHelper.getCallerMethodName(), message, params);
/*     */   }
/*     */   
/*     */   public void log(Level level, String message, Throwable thrown) {
/* 134 */     if (!this.logger.isLoggable(level)) {
/*     */       return;
/*     */     }
/* 137 */     this.logger.logp(level, this.componentClassName, StackHelper.getCallerMethodName(), message, thrown);
/*     */   }
/*     */   
/*     */   public void finest(String message) {
/* 141 */     if (!this.logger.isLoggable(Level.FINEST)) {
/*     */       return;
/*     */     }
/* 144 */     this.logger.logp(Level.FINEST, this.componentClassName, StackHelper.getCallerMethodName(), message);
/*     */   }
/*     */   
/*     */   public void finest(String message, Object[] params) {
/* 148 */     if (!this.logger.isLoggable(Level.FINEST)) {
/*     */       return;
/*     */     }
/* 151 */     this.logger.logp(Level.FINEST, this.componentClassName, StackHelper.getCallerMethodName(), message, params);
/*     */   }
/*     */   
/*     */   public void finest(String message, Throwable thrown) {
/* 155 */     if (!this.logger.isLoggable(Level.FINEST)) {
/*     */       return;
/*     */     }
/* 158 */     this.logger.logp(Level.FINEST, this.componentClassName, StackHelper.getCallerMethodName(), message, thrown);
/*     */   }
/*     */   
/*     */   public void finer(String message) {
/* 162 */     if (!this.logger.isLoggable(Level.FINER)) {
/*     */       return;
/*     */     }
/* 165 */     this.logger.logp(Level.FINER, this.componentClassName, StackHelper.getCallerMethodName(), message);
/*     */   }
/*     */   
/*     */   public void finer(String message, Object[] params) {
/* 169 */     if (!this.logger.isLoggable(Level.FINER)) {
/*     */       return;
/*     */     }
/* 172 */     this.logger.logp(Level.FINER, this.componentClassName, StackHelper.getCallerMethodName(), message, params);
/*     */   }
/*     */   
/*     */   public void finer(String message, Throwable thrown) {
/* 176 */     if (!this.logger.isLoggable(Level.FINER)) {
/*     */       return;
/*     */     }
/* 179 */     this.logger.logp(Level.FINER, this.componentClassName, StackHelper.getCallerMethodName(), message, thrown);
/*     */   }
/*     */   
/*     */   public void fine(String message) {
/* 183 */     if (!this.logger.isLoggable(Level.FINE)) {
/*     */       return;
/*     */     }
/* 186 */     this.logger.logp(Level.FINE, this.componentClassName, StackHelper.getCallerMethodName(), message);
/*     */   }
/*     */   
/*     */   public void fine(String message, Throwable thrown) {
/* 190 */     if (!this.logger.isLoggable(Level.FINE)) {
/*     */       return;
/*     */     }
/* 193 */     this.logger.logp(Level.FINE, this.componentClassName, StackHelper.getCallerMethodName(), message, thrown);
/*     */   }
/*     */   
/*     */   public void info(String message) {
/* 197 */     if (!this.logger.isLoggable(Level.INFO)) {
/*     */       return;
/*     */     }
/* 200 */     this.logger.logp(Level.INFO, this.componentClassName, StackHelper.getCallerMethodName(), message);
/*     */   }
/*     */   
/*     */   public void info(String message, Object[] params) {
/* 204 */     if (!this.logger.isLoggable(Level.INFO)) {
/*     */       return;
/*     */     }
/* 207 */     this.logger.logp(Level.INFO, this.componentClassName, StackHelper.getCallerMethodName(), message, params);
/*     */   }
/*     */   
/*     */   public void info(String message, Throwable thrown) {
/* 211 */     if (!this.logger.isLoggable(Level.INFO)) {
/*     */       return;
/*     */     }
/* 214 */     this.logger.logp(Level.INFO, this.componentClassName, StackHelper.getCallerMethodName(), message, thrown);
/*     */   }
/*     */   
/*     */   public void config(String message) {
/* 218 */     if (!this.logger.isLoggable(Level.CONFIG)) {
/*     */       return;
/*     */     }
/* 221 */     this.logger.logp(Level.CONFIG, this.componentClassName, StackHelper.getCallerMethodName(), message);
/*     */   }
/*     */   
/*     */   public void config(String message, Object[] params) {
/* 225 */     if (!this.logger.isLoggable(Level.CONFIG)) {
/*     */       return;
/*     */     }
/* 228 */     this.logger.logp(Level.CONFIG, this.componentClassName, StackHelper.getCallerMethodName(), message, params);
/*     */   }
/*     */   
/*     */   public void config(String message, Throwable thrown) {
/* 232 */     if (!this.logger.isLoggable(Level.CONFIG)) {
/*     */       return;
/*     */     }
/* 235 */     this.logger.logp(Level.CONFIG, this.componentClassName, StackHelper.getCallerMethodName(), message, thrown);
/*     */   }
/*     */   
/*     */   public void warning(String message) {
/* 239 */     if (!this.logger.isLoggable(Level.WARNING)) {
/*     */       return;
/*     */     }
/* 242 */     this.logger.logp(Level.WARNING, this.componentClassName, StackHelper.getCallerMethodName(), message);
/*     */   }
/*     */   
/*     */   public void warning(String message, Object[] params) {
/* 246 */     if (!this.logger.isLoggable(Level.WARNING)) {
/*     */       return;
/*     */     }
/* 249 */     this.logger.logp(Level.WARNING, this.componentClassName, StackHelper.getCallerMethodName(), message, params);
/*     */   }
/*     */   
/*     */   public void warning(String message, Throwable thrown) {
/* 253 */     if (!this.logger.isLoggable(Level.WARNING)) {
/*     */       return;
/*     */     }
/* 256 */     this.logger.logp(Level.WARNING, this.componentClassName, StackHelper.getCallerMethodName(), message, thrown);
/*     */   }
/*     */   
/*     */   public void severe(String message) {
/* 260 */     if (!this.logger.isLoggable(Level.SEVERE)) {
/*     */       return;
/*     */     }
/* 263 */     this.logger.logp(Level.SEVERE, this.componentClassName, StackHelper.getCallerMethodName(), message);
/*     */   }
/*     */   
/*     */   public void severe(String message, Object[] params) {
/* 267 */     if (!this.logger.isLoggable(Level.SEVERE)) {
/*     */       return;
/*     */     }
/* 270 */     this.logger.logp(Level.SEVERE, this.componentClassName, StackHelper.getCallerMethodName(), message, params);
/*     */   }
/*     */   
/*     */   public void severe(String message, Throwable thrown) {
/* 274 */     if (!this.logger.isLoggable(Level.SEVERE)) {
/*     */       return;
/*     */     }
/* 277 */     this.logger.logp(Level.SEVERE, this.componentClassName, StackHelper.getCallerMethodName(), message, thrown);
/*     */   }
/*     */   
/*     */   public boolean isMethodCallLoggable() {
/* 281 */     return this.logger.isLoggable(METHOD_CALL_LEVEL_VALUE);
/*     */   }
/*     */   
/*     */   public boolean isLoggable(Level level) {
/* 285 */     return this.logger.isLoggable(level);
/*     */   }
/*     */   
/*     */   public void setLevel(Level level) {
/* 289 */     this.logger.setLevel(level);
/*     */   }
/*     */   
/*     */   public void entering() {
/* 293 */     if (!this.logger.isLoggable(METHOD_CALL_LEVEL_VALUE)) {
/*     */       return;
/*     */     }
/*     */     
/* 297 */     this.logger.entering(this.componentClassName, StackHelper.getCallerMethodName());
/*     */   }
/*     */   
/*     */   public void entering(Object... parameters) {
/* 301 */     if (!this.logger.isLoggable(METHOD_CALL_LEVEL_VALUE)) {
/*     */       return;
/*     */     }
/*     */     
/* 305 */     this.logger.entering(this.componentClassName, StackHelper.getCallerMethodName(), parameters);
/*     */   }
/*     */   
/*     */   public void exiting() {
/* 309 */     if (!this.logger.isLoggable(METHOD_CALL_LEVEL_VALUE)) {
/*     */       return;
/*     */     }
/* 312 */     this.logger.exiting(this.componentClassName, StackHelper.getCallerMethodName());
/*     */   }
/*     */   
/*     */   public void exiting(Object result) {
/* 316 */     if (!this.logger.isLoggable(METHOD_CALL_LEVEL_VALUE)) {
/*     */       return;
/*     */     }
/* 319 */     this.logger.exiting(this.componentClassName, StackHelper.getCallerMethodName(), result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Throwable> T logSevereException(T exception, Throwable cause) {
/* 339 */     if (this.logger.isLoggable(Level.SEVERE)) {
/* 340 */       if (cause == null) {
/* 341 */         this.logger.logp(Level.SEVERE, this.componentClassName, StackHelper.getCallerMethodName(), exception.getMessage());
/*     */       } else {
/* 343 */         exception.initCause(cause);
/* 344 */         this.logger.logp(Level.SEVERE, this.componentClassName, StackHelper.getCallerMethodName(), exception.getMessage(), cause);
/*     */       } 
/*     */     }
/*     */     
/* 348 */     return exception;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Throwable> T logSevereException(T exception, boolean logCause) {
/* 371 */     if (this.logger.isLoggable(Level.SEVERE)) {
/* 372 */       if (logCause && exception.getCause() != null) {
/* 373 */         this.logger.logp(Level.SEVERE, this.componentClassName, StackHelper.getCallerMethodName(), exception.getMessage(), exception.getCause());
/*     */       } else {
/* 375 */         this.logger.logp(Level.SEVERE, this.componentClassName, StackHelper.getCallerMethodName(), exception.getMessage());
/*     */       } 
/*     */     }
/*     */     
/* 379 */     return exception;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Throwable> T logSevereException(T exception) {
/* 391 */     if (this.logger.isLoggable(Level.SEVERE)) {
/* 392 */       if (exception.getCause() == null) {
/* 393 */         this.logger.logp(Level.SEVERE, this.componentClassName, StackHelper.getCallerMethodName(), exception.getMessage());
/*     */       } else {
/* 395 */         this.logger.logp(Level.SEVERE, this.componentClassName, StackHelper.getCallerMethodName(), exception.getMessage(), exception.getCause());
/*     */       } 
/*     */     }
/*     */     
/* 399 */     return exception;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Throwable> T logException(T exception, Throwable cause, Level level) {
/* 420 */     if (this.logger.isLoggable(level)) {
/* 421 */       if (cause == null) {
/* 422 */         this.logger.logp(level, this.componentClassName, StackHelper.getCallerMethodName(), exception.getMessage());
/*     */       } else {
/* 424 */         exception.initCause(cause);
/* 425 */         this.logger.logp(level, this.componentClassName, StackHelper.getCallerMethodName(), exception.getMessage(), cause);
/*     */       } 
/*     */     }
/*     */     
/* 429 */     return exception;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Throwable> T logException(T exception, boolean logCause, Level level) {
/* 453 */     if (this.logger.isLoggable(level)) {
/* 454 */       if (logCause && exception.getCause() != null) {
/* 455 */         this.logger.logp(level, this.componentClassName, StackHelper.getCallerMethodName(), exception.getMessage(), exception.getCause());
/*     */       } else {
/* 457 */         this.logger.logp(level, this.componentClassName, StackHelper.getCallerMethodName(), exception.getMessage());
/*     */       } 
/*     */     }
/*     */     
/* 461 */     return exception;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Throwable> T logException(T exception, Level level) {
/* 475 */     if (this.logger.isLoggable(level)) {
/* 476 */       if (exception.getCause() == null) {
/* 477 */         this.logger.logp(level, this.componentClassName, StackHelper.getCallerMethodName(), exception.getMessage());
/*     */       } else {
/* 479 */         this.logger.logp(level, this.componentClassName, StackHelper.getCallerMethodName(), exception.getMessage(), exception.getCause());
/*     */       } 
/*     */     }
/*     */     
/* 483 */     return exception;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\com\sun\istack\logging\Logger.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */