/*    */ package com.sun.istack;
/*    */ 
/*    */ import java.lang.ref.WeakReference;
/*    */ import java.util.concurrent.ConcurrentLinkedQueue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Pool<T>
/*    */ {
/*    */   @NotNull
/*    */   T take();
/*    */   
/*    */   void recycle(@NotNull T paramT);
/*    */   
/*    */   public static abstract class Impl<T>
/*    */     implements Pool<T>
/*    */   {
/*    */     private volatile WeakReference<ConcurrentLinkedQueue<T>> queue;
/*    */     
/*    */     @NotNull
/*    */     public final T take() {
/* 70 */       T t = getQueue().poll();
/* 71 */       if (t == null) {
/* 72 */         return create();
/*    */       }
/* 74 */       return t;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public final void recycle(T t) {
/* 83 */       getQueue().offer(t);
/*    */     }
/*    */     
/*    */     private ConcurrentLinkedQueue<T> getQueue() {
/* 87 */       WeakReference<ConcurrentLinkedQueue<T>> q = this.queue;
/* 88 */       if (q != null) {
/* 89 */         ConcurrentLinkedQueue<T> concurrentLinkedQueue = q.get();
/* 90 */         if (concurrentLinkedQueue != null) {
/* 91 */           return concurrentLinkedQueue;
/*    */         }
/*    */       } 
/*    */       
/* 95 */       ConcurrentLinkedQueue<T> d = new ConcurrentLinkedQueue<>();
/* 96 */       this.queue = new WeakReference<>(d);
/*    */       
/* 98 */       return d;
/*    */     }
/*    */     
/*    */     @NotNull
/*    */     protected abstract T create();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\com\sun\istack\Pool.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */