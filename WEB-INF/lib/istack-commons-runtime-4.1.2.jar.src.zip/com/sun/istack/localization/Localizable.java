package com.sun.istack.localization;

import java.util.Locale;
import java.util.ResourceBundle;

public interface Localizable {
  public static final String NOT_LOCALIZABLE = "\000";
  
  String getKey();
  
  Object[] getArguments();
  
  String getResourceBundleName();
  
  ResourceBundle getResourceBundle(Locale paramLocale);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\com\sun\istack\localization\Localizable.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */