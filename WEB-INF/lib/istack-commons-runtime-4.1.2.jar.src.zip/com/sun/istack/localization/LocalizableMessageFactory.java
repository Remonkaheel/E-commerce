/*    */ package com.sun.istack.localization;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LocalizableMessageFactory
/*    */ {
/*    */   private final String _bundlename;
/*    */   private final ResourceBundleSupplier _rbSupplier;
/*    */   
/*    */   @Deprecated
/*    */   public LocalizableMessageFactory(String bundlename) {
/* 26 */     this._bundlename = bundlename;
/* 27 */     this._rbSupplier = null;
/*    */   }
/*    */   
/*    */   public LocalizableMessageFactory(String bundlename, ResourceBundleSupplier rbSupplier) {
/* 31 */     this._bundlename = bundlename;
/* 32 */     this._rbSupplier = rbSupplier;
/*    */   }
/*    */   
/*    */   public Localizable getMessage(String key, Object... args) {
/* 36 */     return new LocalizableMessage(this._bundlename, this._rbSupplier, key, args);
/*    */   }
/*    */   
/*    */   public static interface ResourceBundleSupplier {
/*    */     ResourceBundle getResourceBundle(Locale param1Locale);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\com\sun\istack\localization\LocalizableMessageFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */