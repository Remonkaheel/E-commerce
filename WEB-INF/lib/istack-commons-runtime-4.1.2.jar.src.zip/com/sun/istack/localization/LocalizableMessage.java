/*    */ package com.sun.istack.localization;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Locale;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LocalizableMessage
/*    */   implements Localizable
/*    */ {
/*    */   private final String _bundlename;
/*    */   private final LocalizableMessageFactory.ResourceBundleSupplier _rbSupplier;
/*    */   private final String _key;
/*    */   private final Object[] _args;
/*    */   
/*    */   @Deprecated
/*    */   public LocalizableMessage(String bundlename, String key, Object... args) {
/* 33 */     this(bundlename, null, key, args);
/*    */   }
/*    */ 
/*    */   
/*    */   public LocalizableMessage(String bundlename, LocalizableMessageFactory.ResourceBundleSupplier rbSupplier, String key, Object... args) {
/* 38 */     this._bundlename = bundlename;
/* 39 */     this._rbSupplier = rbSupplier;
/* 40 */     this._key = key;
/* 41 */     if (args == null)
/* 42 */       args = new Object[0]; 
/* 43 */     this._args = args;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getKey() {
/* 48 */     return this._key;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object[] getArguments() {
/* 53 */     return Arrays.copyOf(this._args, this._args.length);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getResourceBundleName() {
/* 58 */     return this._bundlename;
/*    */   }
/*    */ 
/*    */   
/*    */   public ResourceBundle getResourceBundle(Locale locale) {
/* 63 */     if (this._rbSupplier == null) {
/* 64 */       return null;
/*    */     }
/* 66 */     return this._rbSupplier.getResourceBundle(locale);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\com\sun\istack\localization\LocalizableMessage.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */