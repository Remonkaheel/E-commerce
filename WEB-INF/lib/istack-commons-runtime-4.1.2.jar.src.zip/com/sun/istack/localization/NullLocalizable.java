/*    */ package com.sun.istack.localization;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class NullLocalizable
/*    */   implements Localizable
/*    */ {
/*    */   private final String msg;
/*    */   
/*    */   public NullLocalizable(String msg) {
/* 25 */     if (msg == null)
/* 26 */       throw new IllegalArgumentException(); 
/* 27 */     this.msg = msg;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getKey() {
/* 32 */     return "\000";
/*    */   }
/*    */   
/*    */   public Object[] getArguments() {
/* 36 */     return new Object[] { this.msg };
/*    */   }
/*    */   
/*    */   public String getResourceBundleName() {
/* 40 */     return "";
/*    */   }
/*    */   
/*    */   public ResourceBundle getResourceBundle(Locale locale) {
/* 44 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\com\sun\istack\localization\NullLocalizable.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */