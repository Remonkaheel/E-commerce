/*     */ package com.sun.istack.localization;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Localizer
/*     */ {
/*     */   private final Locale _locale;
/*     */   private final HashMap<String, ResourceBundle> _resourceBundles;
/*     */   
/*     */   public Localizer() {
/*  31 */     this(Locale.getDefault());
/*     */   }
/*     */   
/*     */   public Localizer(Locale l) {
/*  35 */     this._locale = l;
/*  36 */     this._resourceBundles = new HashMap<>();
/*     */   }
/*     */   
/*     */   public Locale getLocale() {
/*  40 */     return this._locale;
/*     */   }
/*     */   
/*     */   public String localize(Localizable l) {
/*  44 */     String key = l.getKey();
/*  45 */     if (key == "\000")
/*     */     {
/*  47 */       return (String)l.getArguments()[0];
/*     */     }
/*     */     
/*  50 */     String bundlename = l.getResourceBundleName();
/*     */     
/*     */     try {
/*     */       String msg;
/*  54 */       ResourceBundle bundle = this._resourceBundles.get(bundlename);
/*     */       
/*  56 */       if (bundle == null) {
/*  57 */         bundle = l.getResourceBundle(this._locale);
/*  58 */         if (bundle != null) {
/*  59 */           this._resourceBundles.put(bundlename, bundle);
/*     */         }
/*     */       } 
/*     */       
/*  63 */       if (bundle == null) {
/*     */         try {
/*  65 */           bundle = ResourceBundle.getBundle(bundlename, this._locale);
/*  66 */         } catch (MissingResourceException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  74 */           int j = bundlename.lastIndexOf('.');
/*  75 */           if (j != -1) {
/*     */             
/*  77 */             String alternateBundleName = bundlename.substring(j + 1);
/*     */             
/*     */             try {
/*  80 */               bundle = ResourceBundle.getBundle(alternateBundleName, this._locale);
/*     */             
/*     */             }
/*  83 */             catch (MissingResourceException e2) {
/*     */               
/*     */               try {
/*  86 */                 bundle = ResourceBundle.getBundle(bundlename, this._locale, Thread.currentThread().getContextClassLoader());
/*  87 */               } catch (MissingResourceException e3) {
/*     */                 
/*  89 */                 return getDefaultMessage(l);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/*  96 */         this._resourceBundles.put(bundlename, bundle);
/*     */       } 
/*     */       
/*  99 */       if (bundle == null) {
/* 100 */         return getDefaultMessage(l);
/*     */       }
/*     */       
/* 103 */       if (key == null) {
/* 104 */         key = "undefined";
/*     */       }
/*     */       
/*     */       try {
/* 108 */         msg = bundle.getString(key);
/* 109 */       } catch (MissingResourceException e) {
/*     */         
/* 111 */         msg = bundle.getString("undefined");
/*     */       } 
/*     */ 
/*     */       
/* 115 */       Object[] args = l.getArguments();
/* 116 */       for (int i = 0; i < args.length; i++) {
/* 117 */         if (args[i] instanceof Localizable) {
/* 118 */           args[i] = localize((Localizable)args[i]);
/*     */         }
/*     */       } 
/* 121 */       return MessageFormat.format(msg, args);
/*     */     }
/* 123 */     catch (MissingResourceException e) {
/* 124 */       return getDefaultMessage(l);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String getDefaultMessage(Localizable l) {
/* 130 */     String key = l.getKey();
/* 131 */     Object[] args = l.getArguments();
/* 132 */     StringBuilder sb = new StringBuilder();
/* 133 */     sb.append("[failed to localize] ");
/* 134 */     sb.append(key);
/* 135 */     if (args != null) {
/* 136 */       sb.append('(');
/* 137 */       for (int i = 0; i < args.length; i++) {
/* 138 */         if (i != 0)
/* 139 */           sb.append(", "); 
/* 140 */         sb.append(String.valueOf(args[i]));
/*     */       } 
/* 142 */       sb.append(')');
/*     */     } 
/* 144 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\istack-commons-runtime-4.1.2.jar!\com\sun\istack\localization\Localizer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */