package org.attoparser;

public interface ICommentHandler {
  void handleComment(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) throws ParseException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\ICommentHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */