package org.attoparser;

import org.attoparser.config.ParseConfiguration;
import org.attoparser.select.ParseSelection;

public interface IMarkupHandler extends IDocumentHandler, IXMLDeclarationHandler, IDocTypeHandler, ICDATASectionHandler, ICommentHandler, ITextHandler, IElementHandler, IProcessingInstructionHandler {
  void setParseConfiguration(ParseConfiguration paramParseConfiguration);
  
  void setParseStatus(ParseStatus paramParseStatus);
  
  void setParseSelection(ParseSelection paramParseSelection);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\IMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */