package org.attoparser;

public interface IElementHandler extends IAttributeSequenceHandler {
  void handleStandaloneElementStart(char[] paramArrayOfchar, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4) throws ParseException;
  
  void handleStandaloneElementEnd(char[] paramArrayOfchar, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4) throws ParseException;
  
  void handleOpenElementStart(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws ParseException;
  
  void handleOpenElementEnd(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws ParseException;
  
  void handleAutoOpenElementStart(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws ParseException;
  
  void handleAutoOpenElementEnd(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws ParseException;
  
  void handleCloseElementStart(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws ParseException;
  
  void handleCloseElementEnd(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws ParseException;
  
  void handleAutoCloseElementStart(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws ParseException;
  
  void handleAutoCloseElementEnd(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws ParseException;
  
  void handleUnmatchedCloseElementStart(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws ParseException;
  
  void handleUnmatchedCloseElementEnd(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws ParseException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\IElementHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */