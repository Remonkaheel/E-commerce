/*    */ package org.attoparser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HtmlVoidHeadElement
/*    */   extends HtmlVoidAutoOpenElement
/*    */ {
/* 32 */   private static final String[] ARRAY_HTML_HEAD = new String[] { "html", "head" };
/*    */   
/*    */   HtmlVoidHeadElement(String name) {
/* 35 */     super(name, ARRAY_HTML_HEAD, null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\HtmlVoidHeadElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */