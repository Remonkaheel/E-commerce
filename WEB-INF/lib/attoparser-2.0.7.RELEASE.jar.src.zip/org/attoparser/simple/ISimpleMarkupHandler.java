package org.attoparser.simple;

import java.util.Map;
import org.attoparser.ParseException;

public interface ISimpleMarkupHandler {
  void handleDocumentStart(long paramLong, int paramInt1, int paramInt2) throws ParseException;
  
  void handleDocumentEnd(long paramLong1, long paramLong2, int paramInt1, int paramInt2) throws ParseException;
  
  void handleXmlDeclaration(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2) throws ParseException;
  
  void handleDocType(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt1, int paramInt2) throws ParseException;
  
  void handleCDATASection(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws ParseException;
  
  void handleComment(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws ParseException;
  
  void handleText(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws ParseException;
  
  void handleStandaloneElement(String paramString, Map<String, String> paramMap, boolean paramBoolean, int paramInt1, int paramInt2) throws ParseException;
  
  void handleOpenElement(String paramString, Map<String, String> paramMap, int paramInt1, int paramInt2) throws ParseException;
  
  void handleAutoOpenElement(String paramString, Map<String, String> paramMap, int paramInt1, int paramInt2) throws ParseException;
  
  void handleCloseElement(String paramString, int paramInt1, int paramInt2) throws ParseException;
  
  void handleAutoCloseElement(String paramString, int paramInt1, int paramInt2) throws ParseException;
  
  void handleUnmatchedCloseElement(String paramString, int paramInt1, int paramInt2) throws ParseException;
  
  void handleProcessingInstruction(String paramString1, String paramString2, int paramInt1, int paramInt2) throws ParseException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\simple\ISimpleMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */