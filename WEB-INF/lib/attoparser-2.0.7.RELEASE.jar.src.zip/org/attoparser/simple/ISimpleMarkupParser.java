package org.attoparser.simple;

import java.io.Reader;
import org.attoparser.ParseException;

public interface ISimpleMarkupParser {
  void parse(String paramString, ISimpleMarkupHandler paramISimpleMarkupHandler) throws ParseException;
  
  void parse(char[] paramArrayOfchar, ISimpleMarkupHandler paramISimpleMarkupHandler) throws ParseException;
  
  void parse(char[] paramArrayOfchar, int paramInt1, int paramInt2, ISimpleMarkupHandler paramISimpleMarkupHandler) throws ParseException;
  
  void parse(Reader paramReader, ISimpleMarkupHandler paramISimpleMarkupHandler) throws ParseException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\simple\ISimpleMarkupParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */