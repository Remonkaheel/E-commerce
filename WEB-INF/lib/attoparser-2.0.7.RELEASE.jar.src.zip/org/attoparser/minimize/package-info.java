package org.attoparser.minimize;


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\minimize\package-info.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */