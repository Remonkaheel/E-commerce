package org.attoparser;

import java.io.Reader;

public interface IMarkupParser {
  void parse(String paramString, IMarkupHandler paramIMarkupHandler) throws ParseException;
  
  void parse(char[] paramArrayOfchar, IMarkupHandler paramIMarkupHandler) throws ParseException;
  
  void parse(char[] paramArrayOfchar, int paramInt1, int paramInt2, IMarkupHandler paramIMarkupHandler) throws ParseException;
  
  void parse(Reader paramReader, IMarkupHandler paramIMarkupHandler) throws ParseException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\IMarkupParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */