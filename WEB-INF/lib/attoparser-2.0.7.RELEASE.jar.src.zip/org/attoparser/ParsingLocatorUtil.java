/*    */ package org.attoparser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ParsingLocatorUtil
/*    */ {
/*    */   public static void countChar(int[] locator, char c) {
/* 33 */     if (c == '\n') {
/* 34 */       locator[0] = locator[0] + 1;
/* 35 */       locator[1] = 1;
/*    */       return;
/*    */     } 
/* 38 */     locator[1] = locator[1] + 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\ParsingLocatorUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */