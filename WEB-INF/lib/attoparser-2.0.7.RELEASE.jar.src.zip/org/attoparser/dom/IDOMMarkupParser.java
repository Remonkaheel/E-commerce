package org.attoparser.dom;

import java.io.Reader;
import org.attoparser.ParseException;

public interface IDOMMarkupParser {
  Document parse(String paramString) throws ParseException;
  
  Document parse(char[] paramArrayOfchar) throws ParseException;
  
  Document parse(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws ParseException;
  
  Document parse(Reader paramReader) throws ParseException;
  
  Document parse(String paramString1, String paramString2) throws ParseException;
  
  Document parse(String paramString, char[] paramArrayOfchar) throws ParseException;
  
  Document parse(String paramString, char[] paramArrayOfchar, int paramInt1, int paramInt2) throws ParseException;
  
  Document parse(String paramString, Reader paramReader) throws ParseException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\dom\IDOMMarkupParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */