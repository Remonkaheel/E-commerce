package org.attoparser.dom;

import java.util.List;

public interface INestableNode extends INode {
  boolean hasChildren();
  
  int numChildren();
  
  List<INode> getChildren();
  
  <T extends INode> List<T> getChildrenOfType(Class<T> paramClass);
  
  INode getFirstChild();
  
  <T extends INode> T getFirstChildOfType(Class<T> paramClass);
  
  void addChild(INode paramINode);
  
  void insertChild(int paramInt, INode paramINode);
  
  void insertChildBefore(INode paramINode1, INode paramINode2);
  
  void insertChildAfter(INode paramINode1, INode paramINode2);
  
  void removeChild(INode paramINode);
  
  void clearChildren();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\dom\INestableNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */