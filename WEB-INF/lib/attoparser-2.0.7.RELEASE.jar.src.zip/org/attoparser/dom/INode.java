package org.attoparser.dom;

public interface INode {
  boolean hasLine();
  
  Integer getLine();
  
  void setLine(Integer paramInteger);
  
  boolean hasCol();
  
  Integer getCol();
  
  void setCol(Integer paramInteger);
  
  boolean hasParent();
  
  INestableNode getParent();
  
  void setParent(INestableNode paramINestableNode);
  
  INode cloneNode(INestableNode paramINestableNode);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\dom\INode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */