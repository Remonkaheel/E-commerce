/*    */ package org.attoparser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HtmlVoidBodyBlockElement
/*    */   extends HtmlVoidAutoOpenCloseElement
/*    */ {
/* 33 */   private static final String[] ARRAY_HTML_BODY = new String[] { "html", "body" };
/* 34 */   private static final String[] ARRAY_P_HEAD = new String[] { "p", "head" };
/* 35 */   private static final String[] AUTO_CLOSE_LIMITS = new String[] { "script", "template", "element", "decorator", "content", "shadow" };
/*    */   
/*    */   HtmlVoidBodyBlockElement(String name) {
/* 38 */     super(name, ARRAY_HTML_BODY, null, ARRAY_P_HEAD, AUTO_CLOSE_LIMITS);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\HtmlVoidBodyBlockElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */