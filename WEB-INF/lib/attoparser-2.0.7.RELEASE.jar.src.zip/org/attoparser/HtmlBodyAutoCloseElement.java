/*    */ package org.attoparser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HtmlBodyAutoCloseElement
/*    */   extends HtmlAutoOpenCloseElement
/*    */ {
/* 34 */   private static final String[] ARRAY_HTML_BODY = new String[] { "html", "body" };
/*    */   
/*    */   HtmlBodyAutoCloseElement(String name, String[] autoCloseElements, String[] autoCloseLimits) {
/* 37 */     super(name, ARRAY_HTML_BODY, null, autoCloseElements, autoCloseLimits);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\HtmlBodyAutoCloseElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */