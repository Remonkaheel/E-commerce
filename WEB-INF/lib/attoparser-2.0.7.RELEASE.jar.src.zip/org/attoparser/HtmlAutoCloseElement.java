/*     */ package org.attoparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HtmlAutoCloseElement
/*     */   extends HtmlElement
/*     */ {
/*     */   protected final char[][] autoCloseRequired;
/*     */   protected final char[][] autoCloseLimits;
/*     */   
/*     */   HtmlAutoCloseElement(String name, String[] autoCloseElements, String[] autoCloseLimits) {
/*  41 */     super(name);
/*     */     char[][] autoCloseLimitsCharArray;
/*  43 */     if (autoCloseElements == null) {
/*  44 */       throw new IllegalArgumentException("The array of auto-close elements cannot be null");
/*     */     }
/*     */     
/*  47 */     char[][] autoCloseElementsCharArray = new char[autoCloseElements.length][];
/*  48 */     for (int i = 0; i < autoCloseElementsCharArray.length; i++) {
/*  49 */       autoCloseElementsCharArray[i] = autoCloseElements[i].toCharArray();
/*     */     }
/*     */ 
/*     */     
/*  53 */     if (autoCloseLimits != null) {
/*  54 */       autoCloseLimitsCharArray = new char[autoCloseLimits.length][];
/*  55 */       for (int j = 0; j < autoCloseLimitsCharArray.length; j++) {
/*  56 */         autoCloseLimitsCharArray[j] = autoCloseLimits[j].toCharArray();
/*     */       }
/*     */     } else {
/*  59 */       autoCloseLimitsCharArray = (char[][])null;
/*     */     } 
/*     */     
/*  62 */     this.autoCloseRequired = autoCloseElementsCharArray;
/*  63 */     this.autoCloseLimits = autoCloseLimitsCharArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled) throws ParseException {
/*  78 */     if (autoCloseEnabled && !status.isAutoOpenCloseDone()) {
/*  79 */       status.setAutoCloseRequired(this.autoCloseRequired, this.autoCloseLimits);
/*     */       
/*     */       return;
/*     */     } 
/*  83 */     handler.handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled) throws ParseException {
/* 100 */     if (autoCloseEnabled && !status.isAutoOpenCloseDone()) {
/* 101 */       status.setAutoCloseRequired(this.autoCloseRequired, this.autoCloseLimits);
/*     */       
/*     */       return;
/*     */     } 
/* 105 */     handler.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\HtmlAutoCloseElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */