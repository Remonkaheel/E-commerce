package org.attoparser;

public interface IAttributeSequenceHandler {
  void handleAttribute(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, int paramInt14) throws ParseException;
  
  void handleInnerWhiteSpace(char[] paramArrayOfchar, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws ParseException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\IAttributeSequenceHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */