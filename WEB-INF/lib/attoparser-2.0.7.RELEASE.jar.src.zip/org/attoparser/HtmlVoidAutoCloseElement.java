/*     */ package org.attoparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HtmlVoidAutoCloseElement
/*     */   extends HtmlVoidElement
/*     */ {
/*     */   protected final char[][] autoCloseRequired;
/*     */   protected final char[][] autoCloseLimits;
/*     */   
/*     */   HtmlVoidAutoCloseElement(String name, String[] autoCloseElements, String[] autoCloseLimits) {
/*  42 */     super(name);
/*     */     char[][] autoCloseLimitsCharArray;
/*  44 */     if (autoCloseElements == null) {
/*  45 */       throw new IllegalArgumentException("The array of auto-close elements cannot be null");
/*     */     }
/*     */     
/*  48 */     char[][] autoCloseElementsCharArray = new char[autoCloseElements.length][];
/*  49 */     for (int i = 0; i < autoCloseElementsCharArray.length; i++) {
/*  50 */       autoCloseElementsCharArray[i] = autoCloseElements[i].toCharArray();
/*     */     }
/*     */ 
/*     */     
/*  54 */     if (autoCloseLimits != null) {
/*  55 */       autoCloseLimitsCharArray = new char[autoCloseLimits.length][];
/*  56 */       for (int j = 0; j < autoCloseLimitsCharArray.length; j++) {
/*  57 */         autoCloseLimitsCharArray[j] = autoCloseLimits[j].toCharArray();
/*     */       }
/*     */     } else {
/*  60 */       autoCloseLimitsCharArray = (char[][])null;
/*     */     } 
/*     */     
/*  63 */     this.autoCloseRequired = autoCloseElementsCharArray;
/*  64 */     this.autoCloseLimits = autoCloseLimitsCharArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled) throws ParseException {
/*  81 */     status.setAvoidStacking(true);
/*     */     
/*  83 */     if (autoCloseEnabled && !status.isAutoOpenCloseDone()) {
/*  84 */       status.setAutoCloseRequired(this.autoCloseRequired, this.autoCloseLimits);
/*     */       
/*     */       return;
/*     */     } 
/*  88 */     handler.handleStandaloneElementStart(buffer, nameOffset, nameLen, false, line, col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled) throws ParseException {
/* 105 */     status.setAvoidStacking(true);
/*     */     
/* 107 */     if (autoCloseEnabled && !status.isAutoOpenCloseDone()) {
/* 108 */       status.setAutoCloseRequired(this.autoCloseRequired, this.autoCloseLimits);
/*     */       
/*     */       return;
/*     */     } 
/* 112 */     handler.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\HtmlVoidAutoCloseElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */