package org.attoparser.discard;

import org.attoparser.AbstractMarkupHandler;

public final class DiscardMarkupHandler extends AbstractMarkupHandler {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\discard\DiscardMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */