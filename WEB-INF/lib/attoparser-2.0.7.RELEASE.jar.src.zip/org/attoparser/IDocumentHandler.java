package org.attoparser;

public interface IDocumentHandler {
  void handleDocumentStart(long paramLong, int paramInt1, int paramInt2) throws ParseException;
  
  void handleDocumentEnd(long paramLong1, long paramLong2, int paramInt1, int paramInt2) throws ParseException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\IDocumentHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */