/*     */ package org.attoparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ParsingAttributeSequenceUtil
/*     */ {
/*     */   public static void parseAttributeSequence(char[] buffer, int offset, int len, int line, int col, IAttributeSequenceHandler handler) throws ParseException {
/*  54 */     int maxi = offset + len;
/*     */     
/*  56 */     int[] locator = { line, col };
/*     */     
/*  58 */     int i = offset;
/*  59 */     int current = i;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     while (i < maxi) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  70 */       int currentArtifactLine = locator[0];
/*  71 */       int currentArtifactCol = locator[1];
/*     */ 
/*     */       
/*  74 */       int wsEnd = ParsingMarkupUtil.findNextNonWhitespaceCharWildcard(buffer, i, maxi, locator);
/*     */       
/*  76 */       if (wsEnd == -1) {
/*     */ 
/*     */         
/*  79 */         handler.handleInnerWhiteSpace(buffer, current, maxi - current, currentArtifactLine, currentArtifactCol);
/*     */         
/*  81 */         i = maxi;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/*  86 */       if (wsEnd > current) {
/*     */         
/*  88 */         int wsOffset = current;
/*  89 */         int wsLen = wsEnd - current;
/*     */         
/*  91 */         handler.handleInnerWhiteSpace(buffer, wsOffset, wsLen, currentArtifactLine, currentArtifactCol);
/*     */         
/*  93 */         i = wsEnd;
/*  94 */         current = i;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 104 */       currentArtifactLine = locator[0];
/* 105 */       currentArtifactCol = locator[1];
/*     */ 
/*     */       
/* 108 */       int attributeNameEnd = ParsingMarkupUtil.findNextOperatorCharWildcard(buffer, i, maxi, locator);
/*     */       
/* 110 */       if (attributeNameEnd == -1) {
/*     */ 
/*     */         
/* 113 */         handler.handleAttribute(buffer, current, maxi - current, currentArtifactLine, currentArtifactCol, 0, 0, locator[0], locator[1], 0, 0, 0, 0, locator[0], locator[1]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 122 */         i = maxi;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 127 */       if (attributeNameEnd <= current)
/*     */       {
/* 129 */         throw new ParseException("Bad attribute name in sequence \"" + new String(buffer, offset, len) + "\": attribute names cannot start with an equals sign", currentArtifactLine, currentArtifactCol);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 135 */       int attributeNameOffset = current;
/* 136 */       int attributeNameLen = attributeNameEnd - current;
/* 137 */       int attributeNameLine = currentArtifactLine;
/* 138 */       int attributeNameCol = currentArtifactCol;
/* 139 */       i = attributeNameEnd;
/* 140 */       current = i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 149 */       currentArtifactLine = locator[0];
/* 150 */       currentArtifactCol = locator[1];
/*     */ 
/*     */       
/* 153 */       int operatorEnd = ParsingMarkupUtil.findNextNonOperatorCharWildcard(buffer, i, maxi, locator);
/*     */       
/* 155 */       if (operatorEnd == -1) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 160 */         boolean bool = false;
/* 161 */         for (int k = i; k < maxi; k++) {
/* 162 */           if (buffer[k] == '=') {
/* 163 */             bool = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 168 */         if (bool) {
/*     */ 
/*     */ 
/*     */           
/* 172 */           handler.handleAttribute(buffer, attributeNameOffset, attributeNameLen, attributeNameLine, attributeNameCol, current, maxi - current, currentArtifactLine, currentArtifactCol, 0, 0, 0, 0, locator[0], locator[1]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 185 */           handler.handleAttribute(buffer, attributeNameOffset, attributeNameLen, attributeNameLine, attributeNameCol, 0, 0, currentArtifactLine, currentArtifactCol, 0, 0, 0, 0, currentArtifactLine, currentArtifactCol);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 194 */           handler.handleInnerWhiteSpace(buffer, current, maxi - current, currentArtifactLine, currentArtifactCol);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 201 */         i = maxi;
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */       
/* 208 */       boolean equalsPresent = false;
/* 209 */       for (int j = current; j < operatorEnd; j++) {
/* 210 */         if (buffer[j] == '=') {
/* 211 */           equalsPresent = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 216 */       if (!equalsPresent) {
/*     */ 
/*     */ 
/*     */         
/* 220 */         handler.handleAttribute(buffer, attributeNameOffset, attributeNameLen, attributeNameLine, attributeNameCol, 0, 0, currentArtifactLine, currentArtifactCol, 0, 0, 0, 0, currentArtifactLine, currentArtifactCol);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 229 */         handler.handleInnerWhiteSpace(buffer, current, operatorEnd - current, currentArtifactLine, currentArtifactCol);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 234 */         i = operatorEnd;
/* 235 */         current = i;
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 241 */       int operatorOffset = current;
/* 242 */       int operatorLen = operatorEnd - current;
/* 243 */       int operatorLine = currentArtifactLine;
/* 244 */       int operatorCol = currentArtifactCol;
/* 245 */       i = operatorEnd;
/* 246 */       current = i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 255 */       currentArtifactLine = locator[0];
/* 256 */       currentArtifactCol = locator[1];
/*     */       
/* 258 */       boolean attributeEndsWithQuotes = (i < maxi && (buffer[current] == '"' || buffer[current] == '\''));
/*     */ 
/*     */ 
/*     */       
/* 262 */       int valueEnd = attributeEndsWithQuotes ? ParsingMarkupUtil.findNextAnyCharAvoidQuotesWildcard(buffer, i, maxi, locator) : ParsingMarkupUtil.findNextWhitespaceCharWildcard(buffer, i, maxi, false, locator);
/*     */       
/* 264 */       if (valueEnd == -1) {
/*     */ 
/*     */         
/* 267 */         int k = current;
/* 268 */         int m = maxi - current;
/*     */         
/* 270 */         if (isValueSurroundedByCommas(buffer, current, maxi - current)) {
/* 271 */           k++;
/* 272 */           m -= 2;
/*     */         } 
/*     */         
/* 275 */         handler.handleAttribute(buffer, attributeNameOffset, attributeNameLen, attributeNameLine, attributeNameCol, operatorOffset, operatorLen, operatorLine, operatorCol, k, m, current, maxi - current, currentArtifactLine, currentArtifactCol);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 284 */         i = maxi;
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 290 */       int valueOuterOffset = current;
/* 291 */       int valueOuterLen = valueEnd - current;
/* 292 */       int valueContentOffset = valueOuterOffset;
/* 293 */       int valueContentLen = valueOuterLen;
/*     */       
/* 295 */       if (isValueSurroundedByCommas(buffer, valueOuterOffset, valueOuterLen)) {
/* 296 */         valueContentOffset = valueOuterOffset + 1;
/* 297 */         valueContentLen = valueOuterLen - 2;
/*     */       } 
/*     */       
/* 300 */       handler.handleAttribute(buffer, attributeNameOffset, attributeNameLen, attributeNameLine, attributeNameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, currentArtifactLine, currentArtifactCol);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 309 */       i = valueEnd;
/* 310 */       current = i;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isValueSurroundedByCommas(char[] buffer, int offset, int len) {
/* 320 */     return (len >= 2 && ((buffer[offset] == '"' && buffer[offset + len - 1] == '"') || (buffer[offset] == '\'' && buffer[offset + len - 1] == '\'')));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\ParsingAttributeSequenceUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */