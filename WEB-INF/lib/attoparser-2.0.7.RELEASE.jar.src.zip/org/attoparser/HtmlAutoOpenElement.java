/*     */ package org.attoparser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HtmlAutoOpenElement
/*     */   extends HtmlElement
/*     */ {
/*     */   private final char[][] autoOpenParents;
/*     */   private final char[][] autoOpenLimits;
/*     */   
/*     */   HtmlAutoOpenElement(String name, String[] autoOpenParents, String[] autoOpenLimits) {
/*  41 */     super(name);
/*     */     char[][] autoOpenLimitsCharArray;
/*  43 */     if (autoOpenParents == null) {
/*  44 */       throw new IllegalArgumentException("The array of auto-open parents cannot be null");
/*     */     }
/*     */     
/*  47 */     char[][] autoOpenParentsCharArray = new char[autoOpenParents.length][];
/*  48 */     for (int i = 0; i < autoOpenParentsCharArray.length; i++) {
/*  49 */       autoOpenParentsCharArray[i] = autoOpenParents[i].toCharArray();
/*     */     }
/*     */ 
/*     */     
/*  53 */     if (autoOpenLimits != null) {
/*  54 */       autoOpenLimitsCharArray = new char[autoOpenLimits.length][];
/*  55 */       for (int j = 0; j < autoOpenLimitsCharArray.length; j++) {
/*  56 */         autoOpenLimitsCharArray[j] = autoOpenLimits[j].toCharArray();
/*     */       }
/*     */     } else {
/*  59 */       autoOpenLimitsCharArray = (char[][])null;
/*     */     } 
/*     */     
/*  62 */     this.autoOpenParents = autoOpenParentsCharArray;
/*  63 */     this.autoOpenLimits = autoOpenLimitsCharArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled) throws ParseException {
/*  78 */     if (autoOpenEnabled && !status.isAutoOpenCloseDone()) {
/*  79 */       status.setAutoOpenRequired(this.autoOpenParents, this.autoOpenLimits);
/*     */       
/*     */       return;
/*     */     } 
/*  83 */     handler.handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled) throws ParseException {
/* 100 */     if (autoOpenEnabled && !status.isAutoOpenCloseDone()) {
/* 101 */       status.setAutoOpenRequired(this.autoOpenParents, this.autoOpenLimits);
/*     */       
/*     */       return;
/*     */     } 
/* 105 */     handler.handleStandaloneElementStart(buffer, nameOffset, nameLen, minimized, line, col);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\HtmlAutoOpenElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */