/*     */ package org.attoparser;
/*     */ 
/*     */ import org.attoparser.util.TextUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HtmlCDATAContentElement
/*     */   extends HtmlElement
/*     */ {
/*  38 */   private static final char[] ELEMENT_SCRIPT_NAME = "script".toCharArray();
/*  39 */   private static final char[] ATTRIBUTE_TYPE_NAME = "type".toCharArray();
/*     */ 
/*     */ 
/*     */   
/*  43 */   private static final char[] ATTRIBUTE_TYPE_JAVASCRIPT_VALUE = "javascript".toCharArray();
/*  44 */   private static final char[] ATTRIBUTE_TYPE_ECMASCRIPT_VALUE = "ecmascript".toCharArray();
/*  45 */   private static final char[] ATTRIBUTE_TYPE_TEXT_JAVASCRIPT_VALUE = "text/javascript".toCharArray();
/*  46 */   private static final char[] ATTRIBUTE_TYPE_TEXT_ECMASCRIPT_VALUE = "text/ecmascript".toCharArray();
/*  47 */   private static final char[] ATTRIBUTE_TYPE_APPLICATION_JAVASCRIPT_VALUE = "application/javascript".toCharArray();
/*  48 */   private static final char[] ATTRIBUTE_TYPE_APPLICATION_ECMASCRIPT_VALUE = "application/ecmascript".toCharArray();
/*  49 */   private static final char[] ATTRIBUTE_TYPE_MODULE_VALUE = "module".toCharArray();
/*     */   
/*     */   private final char[] nameLower;
/*     */   
/*     */   private final char[] nameUpper;
/*     */   
/*     */   private final char[] limitSequenceLower;
/*     */   private final char[] limitSequenceUpper;
/*     */   
/*     */   public HtmlCDATAContentElement(String name) {
/*  59 */     super(name);
/*     */ 
/*     */     
/*  62 */     String nameLower = name.toLowerCase();
/*  63 */     String nameUppoer = name.toUpperCase();
/*     */     
/*  65 */     this.nameLower = nameLower.toCharArray();
/*  66 */     this.nameUpper = nameUppoer.toCharArray();
/*     */     
/*  68 */     this.limitSequenceLower = ("</" + nameLower + ">").toCharArray();
/*  69 */     this.limitSequenceUpper = ("</" + nameUppoer + ">").toCharArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled) throws ParseException {
/*  86 */     status.shouldDisableParsing = true;
/*     */     
/*  88 */     handler.handleOpenElementStart(buffer, nameOffset, nameLen, line, col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled) throws ParseException {
/* 105 */     handler.handleOpenElementEnd(buffer, nameOffset, nameLen, line, col);
/*     */     
/* 107 */     if (status.shouldDisableParsing) {
/*     */       
/* 109 */       status.setParsingDisabled(computeLimitSequence(buffer, nameOffset, nameLen));
/*     */       
/* 111 */       status.shouldDisableParsing = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol, IMarkupHandler handler, ParseStatus status, boolean autoOpenEnabled, boolean autoCloseEnabled) throws ParseException {
/* 133 */     if (TextUtil.equals(false, buffer, nameOffset, nameLen, ATTRIBUTE_TYPE_NAME, 0, ATTRIBUTE_TYPE_NAME.length))
/*     */     {
/* 135 */       if (TextUtil.equals(true, this.nameLower, 0, this.nameLower.length, ELEMENT_SCRIPT_NAME, 0, ELEMENT_SCRIPT_NAME.length)) {
/*     */ 
/*     */ 
/*     */         
/* 139 */         status.shouldDisableParsing = false;
/*     */         
/* 141 */         if (TextUtil.endsWith(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_JAVASCRIPT_VALUE, 0, ATTRIBUTE_TYPE_JAVASCRIPT_VALUE.length) || 
/* 142 */           TextUtil.endsWith(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_ECMASCRIPT_VALUE, 0, ATTRIBUTE_TYPE_ECMASCRIPT_VALUE.length) || 
/* 143 */           TextUtil.endsWith(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_MODULE_VALUE, 0, ATTRIBUTE_TYPE_MODULE_VALUE.length))
/*     */         {
/*     */           
/* 146 */           if (TextUtil.equals(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_JAVASCRIPT_VALUE, 0, ATTRIBUTE_TYPE_JAVASCRIPT_VALUE.length) || 
/* 147 */             TextUtil.equals(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_ECMASCRIPT_VALUE, 0, ATTRIBUTE_TYPE_ECMASCRIPT_VALUE.length)) {
/*     */             
/* 149 */             status.shouldDisableParsing = true;
/*     */           }
/* 151 */           else if (TextUtil.equals(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_TEXT_JAVASCRIPT_VALUE, 0, ATTRIBUTE_TYPE_TEXT_JAVASCRIPT_VALUE.length) || 
/* 152 */             TextUtil.equals(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_TEXT_ECMASCRIPT_VALUE, 0, ATTRIBUTE_TYPE_TEXT_ECMASCRIPT_VALUE.length)) {
/*     */             
/* 154 */             status.shouldDisableParsing = true;
/*     */           }
/* 156 */           else if (TextUtil.equals(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_APPLICATION_JAVASCRIPT_VALUE, 0, ATTRIBUTE_TYPE_APPLICATION_JAVASCRIPT_VALUE.length) || 
/* 157 */             TextUtil.equals(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_APPLICATION_ECMASCRIPT_VALUE, 0, ATTRIBUTE_TYPE_APPLICATION_ECMASCRIPT_VALUE.length)) {
/*     */             
/* 159 */             status.shouldDisableParsing = true;
/*     */           }
/* 161 */           else if (TextUtil.equals(false, buffer, valueContentOffset, valueContentLen, ATTRIBUTE_TYPE_MODULE_VALUE, 0, ATTRIBUTE_TYPE_MODULE_VALUE.length)) {
/*     */             
/* 163 */             status.shouldDisableParsing = true;
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 171 */     handler.handleAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private char[] computeLimitSequence(char[] buffer, int nameOffset, int nameLen) {
/* 183 */     if (TextUtil.equals(true, this.nameLower, 0, this.nameLower.length, buffer, nameOffset, nameLen)) {
/* 184 */       return this.limitSequenceLower;
/*     */     }
/*     */     
/* 187 */     if (TextUtil.equals(true, this.nameUpper, 0, this.nameUpper.length, buffer, nameOffset, nameLen)) {
/* 188 */       return this.limitSequenceUpper;
/*     */     }
/*     */     
/* 191 */     char[] limitSeq = new char[nameLen + 3];
/* 192 */     limitSeq[0] = '<';
/* 193 */     limitSeq[1] = '/';
/* 194 */     System.arraycopy(buffer, nameOffset, limitSeq, 2, nameLen);
/* 195 */     limitSeq[nameLen + 2] = '>';
/* 196 */     return limitSeq;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\HtmlCDATAContentElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */