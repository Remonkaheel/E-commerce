/*    */ package org.attoparser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class HtmlBodyElement
/*    */   extends HtmlAutoOpenCloseElement
/*    */ {
/* 32 */   private static final String[] ARRAY_HTML_BODY = new String[] { "html", "body" };
/* 33 */   private static final String[] ARRAY_HEAD = new String[] { "head" };
/* 34 */   private static final String[] AUTO_CLOSE_LIMITS = new String[] { "script", "template", "element", "decorator", "content", "shadow" };
/*    */   
/*    */   HtmlBodyElement(String name) {
/* 37 */     super(name, ARRAY_HTML_BODY, null, ARRAY_HEAD, AUTO_CLOSE_LIMITS);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\HtmlBodyElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */