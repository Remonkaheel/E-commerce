/*    */ package org.attoparser.select;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MarkupSelectorAndItem
/*    */   implements IMarkupSelectorItem
/*    */ {
/*    */   final IMarkupSelectorItem left;
/*    */   final IMarkupSelectorItem right;
/*    */   
/*    */   MarkupSelectorAndItem(IMarkupSelectorItem left, IMarkupSelectorItem right) {
/* 35 */     if ((right.anyLevel() && !left.anyLevel()) || (!right.anyLevel() && left.anyLevel())) {
/* 36 */       throw new IllegalArgumentException("Left and right items must have the same value for ''anyLevel': " + left.toString() + " && " + right.toString());
/*    */     }
/* 38 */     this.left = left;
/* 39 */     this.right = right;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean anyLevel() {
/* 44 */     return this.left.anyLevel();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean matchesText(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter) {
/* 50 */     return (this.left.matchesText(markupBlockIndex, markupBlockMatchingCounter) && this.right
/* 51 */       .matchesText(markupBlockIndex, markupBlockMatchingCounter));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matchesComment(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter) {
/* 56 */     return (this.left.matchesComment(markupBlockIndex, markupBlockMatchingCounter) && this.right
/* 57 */       .matchesComment(markupBlockIndex, markupBlockMatchingCounter));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matchesCDATASection(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter) {
/* 62 */     return (this.left.matchesCDATASection(markupBlockIndex, markupBlockMatchingCounter) && this.right
/* 63 */       .matchesCDATASection(markupBlockIndex, markupBlockMatchingCounter));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matchesDocTypeClause(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter) {
/* 68 */     return (this.left.matchesDocTypeClause(markupBlockIndex, markupBlockMatchingCounter) && this.right
/* 69 */       .matchesDocTypeClause(markupBlockIndex, markupBlockMatchingCounter));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matchesXmlDeclaration(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter) {
/* 74 */     return (this.left.matchesXmlDeclaration(markupBlockIndex, markupBlockMatchingCounter) && this.right
/* 75 */       .matchesXmlDeclaration(markupBlockIndex, markupBlockMatchingCounter));
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean matchesProcessingInstruction(int markupBlockIndex, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter) {
/* 80 */     return (this.left.matchesProcessingInstruction(markupBlockIndex, markupBlockMatchingCounter) && this.right
/* 81 */       .matchesProcessingInstruction(markupBlockIndex, markupBlockMatchingCounter));
/*    */   }
/*    */   
/*    */   public boolean matchesElement(int markupBlockIndex, SelectorElementBuffer elementBuffer, MarkupSelectorFilter.MarkupBlockMatchingCounter markupBlockMatchingCounter) {
/* 85 */     return (this.left.matchesElement(markupBlockIndex, elementBuffer, markupBlockMatchingCounter) && this.right
/* 86 */       .matchesElement(markupBlockIndex, elementBuffer, markupBlockMatchingCounter));
/*    */   }
/*    */   
/*    */   public String toString() {
/* 90 */     return "(" + this.left.toString() + " && " + this.right + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\select\MarkupSelectorAndItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */