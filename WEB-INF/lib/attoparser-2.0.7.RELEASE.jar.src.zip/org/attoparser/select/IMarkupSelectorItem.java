package org.attoparser.select;

interface IMarkupSelectorItem {
  boolean anyLevel();
  
  boolean matchesText(int paramInt, MarkupSelectorFilter.MarkupBlockMatchingCounter paramMarkupBlockMatchingCounter);
  
  boolean matchesComment(int paramInt, MarkupSelectorFilter.MarkupBlockMatchingCounter paramMarkupBlockMatchingCounter);
  
  boolean matchesCDATASection(int paramInt, MarkupSelectorFilter.MarkupBlockMatchingCounter paramMarkupBlockMatchingCounter);
  
  boolean matchesDocTypeClause(int paramInt, MarkupSelectorFilter.MarkupBlockMatchingCounter paramMarkupBlockMatchingCounter);
  
  boolean matchesXmlDeclaration(int paramInt, MarkupSelectorFilter.MarkupBlockMatchingCounter paramMarkupBlockMatchingCounter);
  
  boolean matchesProcessingInstruction(int paramInt, MarkupSelectorFilter.MarkupBlockMatchingCounter paramMarkupBlockMatchingCounter);
  
  boolean matchesElement(int paramInt, SelectorElementBuffer paramSelectorElementBuffer, MarkupSelectorFilter.MarkupBlockMatchingCounter paramMarkupBlockMatchingCounter);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\select\IMarkupSelectorItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */