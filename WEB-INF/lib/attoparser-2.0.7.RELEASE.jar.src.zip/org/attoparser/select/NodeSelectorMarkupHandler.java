/*      */ package org.attoparser.select;
/*      */ 
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import org.attoparser.AbstractMarkupHandler;
/*      */ import org.attoparser.IMarkupHandler;
/*      */ import org.attoparser.ParseException;
/*      */ import org.attoparser.ParseStatus;
/*      */ import org.attoparser.config.ParseConfiguration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class NodeSelectorMarkupHandler
/*      */   extends AbstractMarkupHandler
/*      */ {
/*      */   private final IMarkupHandler selectedHandler;
/*      */   private final IMarkupHandler nonSelectedHandler;
/*      */   private ParseSelection selection;
/*  129 */   private int selectionIndex = -1;
/*      */ 
/*      */   
/*      */   private final IMarkupSelectorReferenceResolver referenceResolver;
/*      */ 
/*      */   
/*      */   private final SelectorElementBuffer elementBuffer;
/*      */ 
/*      */   
/*      */   private IMarkupHandler documentStartEndHandler;
/*      */ 
/*      */   
/*      */   private final int selectorsLen;
/*      */ 
/*      */   
/*      */   private final String[] selectors;
/*      */ 
/*      */   
/*      */   private final boolean[] selectorMatches;
/*      */ 
/*      */   
/*      */   private final MarkupSelectorFilter[] selectorFilters;
/*      */ 
/*      */   
/*      */   private final int[][] matchingMarkupLevelsPerSelector;
/*      */ 
/*      */   
/*      */   private boolean someSelectorsMatch;
/*      */ 
/*      */   
/*      */   private int markupLevel;
/*      */ 
/*      */   
/*      */   private static final int MARKUP_BLOCKS_LEN = 10;
/*      */ 
/*      */   
/*      */   private int[] markupBlocks;
/*      */   
/*      */   private int markupBlockIndex;
/*      */ 
/*      */   
/*      */   public NodeSelectorMarkupHandler(IMarkupHandler selectedHandler, IMarkupHandler nonSelectedHandler, String selector) {
/*  171 */     this(selectedHandler, nonSelectedHandler, new String[] { selector }, (IMarkupSelectorReferenceResolver)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NodeSelectorMarkupHandler(IMarkupHandler selectedHandler, IMarkupHandler nonSelectedHandler, String selector, IMarkupSelectorReferenceResolver referenceResolver) {
/*  191 */     this(selectedHandler, nonSelectedHandler, new String[] { selector }, referenceResolver);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NodeSelectorMarkupHandler(IMarkupHandler selectedHandler, IMarkupHandler nonSelectedHandler, String[] selectors) {
/*  209 */     this(selectedHandler, nonSelectedHandler, selectors, (IMarkupSelectorReferenceResolver)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NodeSelectorMarkupHandler(IMarkupHandler selectedHandler, IMarkupHandler nonSelectedHandler, String[] selectors, IMarkupSelectorReferenceResolver referenceResolver) {
/*  234 */     if (selectors == null || selectors.length == 0) {
/*  235 */       throw new IllegalArgumentException("Selector array cannot be null or empty");
/*      */     }
/*  237 */     for (String selector : selectors) {
/*  238 */       if (selector == null || selector.trim().length() == 0) {
/*  239 */         throw new IllegalArgumentException("Selector array contains at least one null or empty item, which is forbidden");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  244 */     this.selectedHandler = selectedHandler;
/*  245 */     this.nonSelectedHandler = nonSelectedHandler;
/*      */ 
/*      */     
/*  248 */     this.documentStartEndHandler = this.selectedHandler;
/*      */     
/*  250 */     this.referenceResolver = referenceResolver;
/*      */     
/*  252 */     this.selectors = selectors;
/*  253 */     this.selectorsLen = selectors.length;
/*      */ 
/*      */     
/*  256 */     this.selectorMatches = new boolean[this.selectors.length];
/*  257 */     Arrays.fill(this.selectorMatches, false);
/*      */ 
/*      */     
/*  260 */     this.someSelectorsMatch = false;
/*      */     
/*  262 */     this.selectorFilters = new MarkupSelectorFilter[this.selectorsLen];
/*      */ 
/*      */     
/*  265 */     this.elementBuffer = new SelectorElementBuffer();
/*      */     
/*  267 */     this.matchingMarkupLevelsPerSelector = new int[this.selectorsLen][];
/*  268 */     Arrays.fill((Object[])this.matchingMarkupLevelsPerSelector, (Object)null);
/*      */     
/*  270 */     this.markupLevel = 0;
/*      */     
/*  272 */     this.markupBlockIndex = 0;
/*  273 */     this.markupBlocks = new int[10];
/*  274 */     this.markupBlocks[this.markupLevel] = this.markupBlockIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDocumentStartEndHandler(IMarkupHandler documentStartEndHandler) {
/*  298 */     if (documentStartEndHandler == null) {
/*  299 */       throw new IllegalArgumentException("Handler cannot be null");
/*      */     }
/*  301 */     this.documentStartEndHandler = documentStartEndHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParseConfiguration(ParseConfiguration parseConfiguration) {
/*  318 */     boolean html = ParseConfiguration.ParsingMode.HTML.equals(parseConfiguration.getMode());
/*      */     
/*  320 */     for (int i = 0; i < this.selectorsLen; i++) {
/*      */ 
/*      */       
/*  323 */       List<IMarkupSelectorItem> selectorItems = MarkupSelectorItems.forSelector(html, this.selectors[i], this.referenceResolver);
/*      */       
/*  325 */       this.selectorFilters[i] = new MarkupSelectorFilter(null, selectorItems.get(0));
/*  326 */       MarkupSelectorFilter last = this.selectorFilters[i];
/*  327 */       for (int j = 1; j < selectorItems.size(); j++) {
/*  328 */         last = new MarkupSelectorFilter(last, selectorItems.get(j));
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  338 */     this.selectedHandler.setParseConfiguration(parseConfiguration);
/*  339 */     if (this.nonSelectedHandler != this.selectedHandler) {
/*  340 */       this.nonSelectedHandler.setParseConfiguration(parseConfiguration);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParseStatus(ParseStatus status) {
/*  350 */     this.selectedHandler.setParseStatus(status);
/*  351 */     if (this.nonSelectedHandler != this.selectedHandler) {
/*  352 */       this.nonSelectedHandler.setParseStatus(status);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setParseSelection(ParseSelection selection) {
/*  361 */     if (this.selection == null) {
/*  362 */       this.selection = selection;
/*      */     }
/*  364 */     if (this.selectionIndex == -1) {
/*  365 */       this.selectionIndex = this.selection.subscribeLevel();
/*      */     }
/*  367 */     this.selectedHandler.setParseSelection(selection);
/*  368 */     if (this.nonSelectedHandler != this.selectedHandler) {
/*  369 */       this.nonSelectedHandler.setParseSelection(selection);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleDocumentStart(long startTimeNanos, int line, int col) throws ParseException {
/*  387 */     (this.selection.levels[this.selectionIndex]).selectors = this.selectors;
/*      */     
/*  389 */     this.documentStartEndHandler.handleDocumentStart(startTimeNanos, line, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleDocumentEnd(long endTimeNanos, long totalTimeNanos, int line, int col) throws ParseException {
/*  399 */     this.documentStartEndHandler.handleDocumentEnd(endTimeNanos, totalTimeNanos, line, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleXmlDeclaration(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int versionOffset, int versionLen, int versionLine, int versionCol, int encodingOffset, int encodingLen, int encodingLine, int encodingCol, int standaloneOffset, int standaloneLen, int standaloneLine, int standaloneCol, int outerOffset, int outerLen, int line, int col) throws ParseException {
/*  422 */     this.someSelectorsMatch = false;
/*  423 */     for (int i = 0; i < this.selectorsLen; i++) {
/*      */       
/*  425 */       this.selectorMatches[i] = this.selectorFilters[i]
/*  426 */         .matchXmlDeclaration(false, this.markupLevel, this.markupBlocks[this.markupLevel]);
/*  427 */       if (this.selectorMatches[i]) {
/*  428 */         this.someSelectorsMatch = true;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  433 */     if (this.someSelectorsMatch) {
/*  434 */       markCurrentSelection();
/*  435 */       this.selectedHandler.handleXmlDeclaration(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, versionOffset, versionLen, versionLine, versionCol, encodingOffset, encodingLen, encodingLine, encodingCol, standaloneOffset, standaloneLen, standaloneLine, standaloneCol, outerOffset, outerLen, line, col);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  442 */       unmarkCurrentSelection();
/*      */       
/*      */       return;
/*      */     } 
/*  446 */     unmarkCurrentSelection();
/*  447 */     this.nonSelectedHandler.handleXmlDeclaration(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, versionOffset, versionLen, versionLine, versionCol, encodingOffset, encodingLen, encodingLine, encodingCol, standaloneOffset, standaloneLen, standaloneLine, standaloneCol, outerOffset, outerLen, line, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleDocType(char[] buffer, int keywordOffset, int keywordLen, int keywordLine, int keywordCol, int elementNameOffset, int elementNameLen, int elementNameLine, int elementNameCol, int typeOffset, int typeLen, int typeLine, int typeCol, int publicIdOffset, int publicIdLen, int publicIdLine, int publicIdCol, int systemIdOffset, int systemIdLen, int systemIdLine, int systemIdCol, int internalSubsetOffset, int internalSubsetLen, int internalSubsetLine, int internalSubsetCol, int outerOffset, int outerLen, int outerLine, int outerCol) throws ParseException {
/*  479 */     this.someSelectorsMatch = false;
/*  480 */     for (int i = 0; i < this.selectorsLen; i++) {
/*      */       
/*  482 */       this.selectorMatches[i] = this.selectorFilters[i]
/*  483 */         .matchDocTypeClause(false, this.markupLevel, this.markupBlocks[this.markupLevel]);
/*  484 */       if (this.selectorMatches[i]) {
/*  485 */         this.someSelectorsMatch = true;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  490 */     if (this.someSelectorsMatch) {
/*  491 */       markCurrentSelection();
/*  492 */       this.selectedHandler.handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, elementNameOffset, elementNameLen, elementNameLine, elementNameCol, typeOffset, typeLen, typeLine, typeCol, publicIdOffset, publicIdLen, publicIdLine, publicIdCol, systemIdOffset, systemIdLen, systemIdLine, systemIdCol, internalSubsetOffset, internalSubsetLen, internalSubsetLine, internalSubsetCol, outerOffset, outerLen, outerLine, outerCol);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  501 */       unmarkCurrentSelection();
/*      */       
/*      */       return;
/*      */     } 
/*  505 */     unmarkCurrentSelection();
/*  506 */     this.nonSelectedHandler.handleDocType(buffer, keywordOffset, keywordLen, keywordLine, keywordCol, elementNameOffset, elementNameLen, elementNameLine, elementNameCol, typeOffset, typeLen, typeLine, typeCol, publicIdOffset, publicIdLen, publicIdLine, publicIdCol, systemIdOffset, systemIdLen, systemIdLine, systemIdCol, internalSubsetOffset, internalSubsetLen, internalSubsetLine, internalSubsetCol, outerOffset, outerLen, outerLine, outerCol);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleCDATASection(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col) throws ParseException {
/*  535 */     this.someSelectorsMatch = false;
/*  536 */     for (int i = 0; i < this.selectorsLen; i++) {
/*      */       
/*  538 */       this.selectorMatches[i] = this.selectorFilters[i]
/*  539 */         .matchCDATASection(false, this.markupLevel, this.markupBlocks[this.markupLevel]);
/*  540 */       if (this.selectorMatches[i]) {
/*  541 */         this.someSelectorsMatch = true;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  546 */     if (this.someSelectorsMatch) {
/*  547 */       markCurrentSelection();
/*  548 */       this.selectedHandler.handleCDATASection(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*      */       
/*  550 */       unmarkCurrentSelection();
/*      */       
/*      */       return;
/*      */     } 
/*  554 */     unmarkCurrentSelection();
/*  555 */     this.nonSelectedHandler.handleCDATASection(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleText(char[] buffer, int offset, int len, int line, int col) throws ParseException {
/*  576 */     this.someSelectorsMatch = false;
/*  577 */     for (int i = 0; i < this.selectorsLen; i++) {
/*      */       
/*  579 */       this.selectorMatches[i] = this.selectorFilters[i]
/*  580 */         .matchText(false, this.markupLevel, this.markupBlocks[this.markupLevel]);
/*  581 */       if (this.selectorMatches[i]) {
/*  582 */         this.someSelectorsMatch = true;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  587 */     if (this.someSelectorsMatch) {
/*  588 */       markCurrentSelection();
/*  589 */       this.selectedHandler.handleText(buffer, offset, len, line, col);
/*  590 */       unmarkCurrentSelection();
/*      */       
/*      */       return;
/*      */     } 
/*  594 */     unmarkCurrentSelection();
/*  595 */     this.nonSelectedHandler.handleText(buffer, offset, len, line, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleComment(char[] buffer, int contentOffset, int contentLen, int outerOffset, int outerLen, int line, int col) throws ParseException {
/*  617 */     this.someSelectorsMatch = false;
/*  618 */     for (int i = 0; i < this.selectorsLen; i++) {
/*      */       
/*  620 */       this.selectorMatches[i] = this.selectorFilters[i]
/*  621 */         .matchComment(false, this.markupLevel, this.markupBlocks[this.markupLevel]);
/*  622 */       if (this.selectorMatches[i]) {
/*  623 */         this.someSelectorsMatch = true;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  628 */     if (this.someSelectorsMatch) {
/*  629 */       markCurrentSelection();
/*  630 */       this.selectedHandler.handleComment(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*      */       
/*  632 */       unmarkCurrentSelection();
/*      */       
/*      */       return;
/*      */     } 
/*  636 */     unmarkCurrentSelection();
/*  637 */     this.nonSelectedHandler.handleComment(buffer, contentOffset, contentLen, outerOffset, outerLen, line, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleAttribute(char[] buffer, int nameOffset, int nameLen, int nameLine, int nameCol, int operatorOffset, int operatorLen, int operatorLine, int operatorCol, int valueContentOffset, int valueContentLen, int valueOuterOffset, int valueOuterLen, int valueLine, int valueCol) throws ParseException {
/*  663 */     this.elementBuffer.bufferAttribute(buffer, nameOffset, nameLen, nameLine, nameCol, operatorOffset, operatorLen, operatorLine, operatorCol, valueContentOffset, valueContentLen, valueOuterOffset, valueOuterLen, valueLine, valueCol);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleStandaloneElementStart(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col) throws ParseException {
/*  681 */     this.elementBuffer.bufferElementStart(buffer, nameOffset, nameLen, line, col, true, minimized);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleStandaloneElementEnd(char[] buffer, int nameOffset, int nameLen, boolean minimized, int line, int col) throws ParseException {
/*  695 */     this.elementBuffer.bufferElementEnd(buffer, nameOffset, nameLen, line, col);
/*      */     
/*  697 */     this.someSelectorsMatch = false;
/*  698 */     for (int i = 0; i < this.selectorsLen; i++) {
/*      */       
/*  700 */       this.selectorMatches[i] = this.selectorFilters[i]
/*  701 */         .matchStandaloneElement(false, this.markupLevel, this.markupBlocks[this.markupLevel], this.elementBuffer);
/*  702 */       if (this.selectorMatches[i]) {
/*  703 */         this.someSelectorsMatch = true;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  708 */     if (this.someSelectorsMatch) {
/*  709 */       markCurrentSelection();
/*  710 */       this.elementBuffer.flushBuffer(this.selectedHandler, false);
/*  711 */       unmarkCurrentSelection();
/*      */       
/*      */       return;
/*      */     } 
/*  715 */     unmarkCurrentSelection();
/*  716 */     this.elementBuffer.flushBuffer(this.nonSelectedHandler, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col) throws ParseException {
/*  729 */     this.elementBuffer.bufferElementStart(buffer, nameOffset, nameLen, line, col, false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col) throws ParseException {
/*  742 */     this.elementBuffer.bufferElementEnd(buffer, nameOffset, nameLen, line, col);
/*      */     
/*  744 */     this.someSelectorsMatch = false;
/*  745 */     for (int i = 0; i < this.selectorsLen; i++) {
/*  746 */       this.selectorMatches[i] = this.selectorFilters[i]
/*  747 */         .matchOpenElement(false, this.markupLevel, this.markupBlocks[this.markupLevel], this.elementBuffer);
/*  748 */       if (this.selectorMatches[i]) {
/*  749 */         this.someSelectorsMatch = true;
/*  750 */         addMatchingMarkupLevel(i, this.markupLevel);
/*      */       } 
/*      */     } 
/*      */     
/*  754 */     this.markupLevel++;
/*      */     
/*  756 */     checkSizeOfMarkupBlocksStructure(this.markupLevel);
/*  757 */     this.markupBlocks[this.markupLevel] = ++this.markupBlockIndex;
/*      */     
/*  759 */     if (this.someSelectorsMatch) {
/*  760 */       markCurrentSelection();
/*  761 */       this.elementBuffer.flushBuffer(this.selectedHandler, false);
/*  762 */       unmarkCurrentSelection();
/*      */       
/*      */       return;
/*      */     } 
/*  766 */     unmarkCurrentSelection();
/*  767 */     this.elementBuffer.flushBuffer(this.nonSelectedHandler, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleAutoOpenElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col) throws ParseException {
/*  780 */     this.elementBuffer.bufferElementStart(buffer, nameOffset, nameLen, line, col, false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleAutoOpenElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col) throws ParseException {
/*  793 */     this.elementBuffer.bufferElementEnd(buffer, nameOffset, nameLen, line, col);
/*      */     
/*  795 */     this.someSelectorsMatch = false;
/*  796 */     for (int i = 0; i < this.selectorsLen; i++) {
/*  797 */       this.selectorMatches[i] = this.selectorFilters[i]
/*  798 */         .matchOpenElement(false, this.markupLevel, this.markupBlocks[this.markupLevel], this.elementBuffer);
/*  799 */       if (this.selectorMatches[i]) {
/*  800 */         this.someSelectorsMatch = true;
/*  801 */         addMatchingMarkupLevel(i, this.markupLevel);
/*      */       } 
/*      */     } 
/*      */     
/*  805 */     this.markupLevel++;
/*      */     
/*  807 */     checkSizeOfMarkupBlocksStructure(this.markupLevel);
/*  808 */     this.markupBlocks[this.markupLevel] = ++this.markupBlockIndex;
/*      */     
/*  810 */     if (this.someSelectorsMatch) {
/*  811 */       markCurrentSelection();
/*  812 */       this.elementBuffer.flushBuffer(this.selectedHandler, true);
/*  813 */       unmarkCurrentSelection();
/*      */       
/*      */       return;
/*      */     } 
/*  817 */     unmarkCurrentSelection();
/*  818 */     this.elementBuffer.flushBuffer(this.nonSelectedHandler, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col) throws ParseException {
/*  831 */     this.markupLevel--; int i;
/*  832 */     for (i = 0; i < this.selectorsLen; i++) {
/*  833 */       this.selectorFilters[i].removeMatchesForLevel(this.markupLevel);
/*      */     }
/*      */     
/*  836 */     this.someSelectorsMatch = false;
/*  837 */     for (i = 0; i < this.selectorsLen; i++) {
/*      */       
/*  839 */       this.selectorMatches[i] = isMatchingMarkupLevel(i, this.markupLevel);
/*  840 */       if (this.selectorMatches[i]) {
/*  841 */         this.someSelectorsMatch = true;
/*      */       }
/*      */     } 
/*      */     
/*  845 */     if (this.someSelectorsMatch) {
/*  846 */       markCurrentSelection();
/*  847 */       this.selectedHandler.handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*      */       
/*      */       return;
/*      */     } 
/*  851 */     unmarkCurrentSelection();
/*  852 */     this.nonSelectedHandler.handleCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col) throws ParseException {
/*  865 */     this.someSelectorsMatch = false;
/*  866 */     for (int i = 0; i < this.selectorsLen; i++) {
/*      */       
/*  868 */       this.selectorMatches[i] = isMatchingMarkupLevel(i, this.markupLevel);
/*  869 */       if (this.selectorMatches[i]) {
/*  870 */         this.someSelectorsMatch = true;
/*  871 */         removeMatchingMarkupLevel(i, this.markupLevel);
/*      */       } 
/*      */     } 
/*      */     
/*  875 */     if (this.someSelectorsMatch) {
/*  876 */       this.selectedHandler.handleCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*  877 */       unmarkCurrentSelection();
/*      */       
/*      */       return;
/*      */     } 
/*  881 */     unmarkCurrentSelection();
/*  882 */     this.nonSelectedHandler.handleCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleAutoCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col) throws ParseException {
/*  895 */     this.markupLevel--; int i;
/*  896 */     for (i = 0; i < this.selectorsLen; i++) {
/*  897 */       this.selectorFilters[i].removeMatchesForLevel(this.markupLevel);
/*      */     }
/*      */     
/*  900 */     this.someSelectorsMatch = false;
/*  901 */     for (i = 0; i < this.selectorsLen; i++) {
/*      */       
/*  903 */       this.selectorMatches[i] = isMatchingMarkupLevel(i, this.markupLevel);
/*  904 */       if (this.selectorMatches[i]) {
/*  905 */         this.someSelectorsMatch = true;
/*      */       }
/*      */     } 
/*      */     
/*  909 */     if (this.someSelectorsMatch) {
/*  910 */       markCurrentSelection();
/*  911 */       this.selectedHandler.handleAutoCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*      */       
/*      */       return;
/*      */     } 
/*  915 */     unmarkCurrentSelection();
/*  916 */     this.nonSelectedHandler.handleAutoCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleAutoCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col) throws ParseException {
/*  929 */     this.someSelectorsMatch = false;
/*  930 */     for (int i = 0; i < this.selectorsLen; i++) {
/*      */       
/*  932 */       this.selectorMatches[i] = isMatchingMarkupLevel(i, this.markupLevel);
/*  933 */       if (this.selectorMatches[i]) {
/*  934 */         this.someSelectorsMatch = true;
/*  935 */         removeMatchingMarkupLevel(i, this.markupLevel);
/*      */       } 
/*      */     } 
/*      */     
/*  939 */     if (this.someSelectorsMatch) {
/*  940 */       this.selectedHandler.handleAutoCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*  941 */       unmarkCurrentSelection();
/*      */       
/*      */       return;
/*      */     } 
/*  945 */     unmarkCurrentSelection();
/*  946 */     this.nonSelectedHandler.handleAutoCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleUnmatchedCloseElementStart(char[] buffer, int nameOffset, int nameLen, int line, int col) throws ParseException {
/*  959 */     this.someSelectorsMatch = false;
/*  960 */     for (int i = 0; i < this.selectorsLen; i++) {
/*      */       
/*  962 */       this.selectorMatches[i] = isMatchingMarkupLevel(i, this.markupLevel);
/*  963 */       if (this.selectorMatches[i]) {
/*  964 */         this.someSelectorsMatch = true;
/*      */       }
/*      */     } 
/*      */     
/*  968 */     if (this.someSelectorsMatch) {
/*  969 */       markCurrentSelection();
/*  970 */       this.selectedHandler.handleUnmatchedCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*      */       
/*      */       return;
/*      */     } 
/*  974 */     unmarkCurrentSelection();
/*  975 */     this.nonSelectedHandler.handleUnmatchedCloseElementStart(buffer, nameOffset, nameLen, line, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleUnmatchedCloseElementEnd(char[] buffer, int nameOffset, int nameLen, int line, int col) throws ParseException {
/*  988 */     this.someSelectorsMatch = false;
/*  989 */     for (int i = 0; i < this.selectorsLen; i++) {
/*      */       
/*  991 */       this.selectorMatches[i] = isMatchingMarkupLevel(i, this.markupLevel);
/*  992 */       if (this.selectorMatches[i]) {
/*  993 */         this.someSelectorsMatch = true;
/*      */       }
/*      */     } 
/*      */     
/*  997 */     if (this.someSelectorsMatch) {
/*  998 */       this.selectedHandler.handleUnmatchedCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*  999 */       unmarkCurrentSelection();
/*      */       
/*      */       return;
/*      */     } 
/* 1003 */     unmarkCurrentSelection();
/* 1004 */     this.nonSelectedHandler.handleUnmatchedCloseElementEnd(buffer, nameOffset, nameLen, line, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleInnerWhiteSpace(char[] buffer, int offset, int len, int line, int col) throws ParseException {
/* 1017 */     this.elementBuffer.bufferElementInnerWhiteSpace(buffer, offset, len, line, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleProcessingInstruction(char[] buffer, int targetOffset, int targetLen, int targetLine, int targetCol, int contentOffset, int contentLen, int contentLine, int contentCol, int outerOffset, int outerLen, int line, int col) throws ParseException {
/* 1039 */     this.someSelectorsMatch = false;
/* 1040 */     for (int i = 0; i < this.selectorsLen; i++) {
/*      */       
/* 1042 */       this.selectorMatches[i] = this.selectorFilters[i]
/* 1043 */         .matchProcessingInstruction(false, this.markupLevel, this.markupBlocks[this.markupLevel]);
/* 1044 */       if (this.selectorMatches[i]) {
/* 1045 */         this.someSelectorsMatch = true;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1050 */     if (this.someSelectorsMatch) {
/* 1051 */       markCurrentSelection();
/* 1052 */       this.selectedHandler.handleProcessingInstruction(buffer, targetOffset, targetLen, targetLine, targetCol, contentOffset, contentLen, contentLine, contentCol, outerOffset, outerLen, line, col);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1057 */       unmarkCurrentSelection();
/*      */       
/*      */       return;
/*      */     } 
/* 1061 */     unmarkCurrentSelection();
/* 1062 */     this.nonSelectedHandler.handleProcessingInstruction(buffer, targetOffset, targetLen, targetLine, targetCol, contentOffset, contentLen, contentLine, contentCol, outerOffset, outerLen, line, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void markCurrentSelection() {
/* 1079 */     (this.selection.levels[this.selectionIndex]).selection = this.selectorMatches;
/*      */   }
/*      */   
/*      */   private void unmarkCurrentSelection() {
/* 1083 */     (this.selection.levels[this.selectionIndex]).selection = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkSizeOfMarkupBlocksStructure(int markupLevel) {
/* 1094 */     if (markupLevel >= this.markupBlocks.length) {
/* 1095 */       int newLen = Math.max(markupLevel + 1, this.markupBlocks.length + 10);
/* 1096 */       int[] newMarkupBlocks = new int[newLen];
/* 1097 */       Arrays.fill(newMarkupBlocks, 0);
/* 1098 */       System.arraycopy(this.markupBlocks, 0, newMarkupBlocks, 0, this.markupBlocks.length);
/* 1099 */       this.markupBlocks = newMarkupBlocks;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void addMatchingMarkupLevel(int selector, int markupLevel) {
/* 1106 */     if (this.matchingMarkupLevelsPerSelector[selector] == null) {
/*      */       
/* 1108 */       this.matchingMarkupLevelsPerSelector[selector] = new int[2];
/* 1109 */       Arrays.fill(this.matchingMarkupLevelsPerSelector[selector], 2147483647);
/*      */     } 
/*      */     
/* 1112 */     for (int i = 0; i < (this.matchingMarkupLevelsPerSelector[selector]).length; i++) {
/* 1113 */       if (this.matchingMarkupLevelsPerSelector[selector][i] == Integer.MAX_VALUE) {
/* 1114 */         this.matchingMarkupLevelsPerSelector[selector][i] = markupLevel;
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/* 1120 */     int[] newMatchingMarkupLevelsPerSelector = new int[(this.matchingMarkupLevelsPerSelector[selector]).length + 2];
/* 1121 */     Arrays.fill(newMatchingMarkupLevelsPerSelector, 2147483647);
/* 1122 */     System.arraycopy(this.matchingMarkupLevelsPerSelector[selector], 0, newMatchingMarkupLevelsPerSelector, 0, (this.matchingMarkupLevelsPerSelector[selector]).length);
/*      */     
/* 1124 */     newMatchingMarkupLevelsPerSelector[(this.matchingMarkupLevelsPerSelector[selector]).length] = markupLevel;
/* 1125 */     this.matchingMarkupLevelsPerSelector[selector] = newMatchingMarkupLevelsPerSelector;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isMatchingMarkupLevel(int selector, int markupLevel) {
/* 1131 */     if (this.matchingMarkupLevelsPerSelector[selector] == null) {
/* 1132 */       return false;
/*      */     }
/* 1134 */     for (int i = 0; i < (this.matchingMarkupLevelsPerSelector[selector]).length; i++) {
/* 1135 */       if (this.matchingMarkupLevelsPerSelector[selector][i] == markupLevel) {
/* 1136 */         return true;
/*      */       }
/*      */     } 
/* 1139 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private void removeMatchingMarkupLevel(int selector, int markupLevel) {
/* 1144 */     for (int i = 0; i < (this.matchingMarkupLevelsPerSelector[selector]).length; i++) {
/* 1145 */       if (this.matchingMarkupLevelsPerSelector[selector][i] == markupLevel) {
/* 1146 */         this.matchingMarkupLevelsPerSelector[selector][i] = Integer.MAX_VALUE;
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\select\NodeSelectorMarkupHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */