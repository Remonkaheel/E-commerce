/*     */ package org.attoparser.select;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MarkupSelectorItems
/*     */ {
/*  37 */   private static final SelectorRepository NO_REFERENCE_RESOLVER_REPOSITORY = new SelectorRepository();
/*  38 */   private static final ConcurrentHashMap<IMarkupSelectorReferenceResolver, SelectorRepository> REPOSITORIES_BY_REFERENCE_RESOLVER = new ConcurrentHashMap<IMarkupSelectorReferenceResolver, SelectorRepository>(20);
/*     */ 
/*     */   
/*     */   private static final String selectorPatternStr = "^(/{1,2})([^/\\s]*?)(\\[(?:.*)\\])?$";
/*     */ 
/*     */   
/*  44 */   private static final Pattern selectorPattern = Pattern.compile("^(/{1,2})([^/\\s]*?)(\\[(?:.*)\\])?$");
/*     */   private static final String modifiersPatternStr = "^(?:\\[(.*?)\\])(\\[(?:.*)\\])?$";
/*  46 */   private static final Pattern modifiersPattern = Pattern.compile("^(?:\\[(.*?)\\])(\\[(?:.*)\\])?$");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static List<IMarkupSelectorItem> forSelector(boolean html, String selector, IMarkupSelectorReferenceResolver referenceResolver) {
/*     */     ConcurrentHashMap<String, List<IMarkupSelectorItem>> map;
/*  54 */     if (isEmptyOrWhitespace(selector)) {
/*  55 */       throw new IllegalArgumentException("Selector cannot be null");
/*     */     }
/*     */ 
/*     */     
/*  59 */     if (referenceResolver == null) {
/*  60 */       map = NO_REFERENCE_RESOLVER_REPOSITORY.getMap(html);
/*     */     } else {
/*  62 */       if (!REPOSITORIES_BY_REFERENCE_RESOLVER.containsKey(referenceResolver) && 
/*  63 */         REPOSITORIES_BY_REFERENCE_RESOLVER.size() < 1000)
/*     */       {
/*  65 */         REPOSITORIES_BY_REFERENCE_RESOLVER.putIfAbsent(referenceResolver, new SelectorRepository());
/*     */       }
/*     */       
/*  68 */       map = ((SelectorRepository)REPOSITORIES_BY_REFERENCE_RESOLVER.get(referenceResolver)).getMap(html);
/*     */     } 
/*     */     
/*  71 */     List<IMarkupSelectorItem> items = map.get(selector);
/*  72 */     if (items != null) {
/*  73 */       return items;
/*     */     }
/*     */     
/*  76 */     items = Collections.unmodifiableList(parseSelector(html, selector, referenceResolver));
/*     */     
/*  78 */     if (map.size() < 1000) {
/*  79 */       map.putIfAbsent(selector, items);
/*     */     }
/*     */     
/*  82 */     return items;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class SelectorRepository
/*     */   {
/*     */     private static final int SELECTOR_ITEMS_MAX_SIZE = 1000;
/*     */     
/*  91 */     private final ConcurrentHashMap<String, List<IMarkupSelectorItem>> CASE_INSENSITIVE_SELECTOR_ITEMS = new ConcurrentHashMap<String, List<IMarkupSelectorItem>>(20);
/*     */     
/*  93 */     private final ConcurrentHashMap<String, List<IMarkupSelectorItem>> CASE_SENSITIVE_SELECTOR_ITEMS = new ConcurrentHashMap<String, List<IMarkupSelectorItem>>(20);
/*     */ 
/*     */ 
/*     */     
/*     */     ConcurrentHashMap<String, List<IMarkupSelectorItem>> getMap(boolean html) {
/*  98 */       return html ? this.CASE_INSENSITIVE_SELECTOR_ITEMS : this.CASE_SENSITIVE_SELECTOR_ITEMS;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static List<IMarkupSelectorItem> parseSelector(boolean html, String selector, IMarkupSelectorReferenceResolver referenceResolver) {
/* 111 */     return parseSelector(html, selector, null, null, referenceResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<IMarkupSelectorItem> parseSelector(boolean html, String selector, MarkupSelectorItem.IAttributeCondition initialAttributeCondition, MarkupSelectorItem.IndexCondition initialIndexCondition, IMarkupSelectorReferenceResolver referenceResolver) {
/*     */     List<IMarkupSelectorItem> result;
/*     */     boolean anyLevel;
/* 127 */     String selectorSpecStr = selector.trim();
/* 128 */     if (!selectorSpecStr.startsWith("/"))
/*     */     {
/* 130 */       selectorSpecStr = "//" + selectorSpecStr;
/*     */     }
/*     */     
/* 133 */     int selectorSpecStrLen = selectorSpecStr.length();
/* 134 */     int firstNonSlash = 0;
/* 135 */     while (firstNonSlash < selectorSpecStrLen && selectorSpecStr.charAt(firstNonSlash) == '/') {
/* 136 */       firstNonSlash++;
/*     */     }
/*     */     
/* 139 */     if (firstNonSlash >= selectorSpecStrLen) {
/* 140 */       throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": '/' should be followed by further selector specification");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     int selEnd = selectorSpecStr.substring(firstNonSlash).indexOf('/');
/* 147 */     if (selEnd != -1) {
/* 148 */       String tail = selectorSpecStr.substring(firstNonSlash).substring(selEnd);
/* 149 */       selectorSpecStr = selectorSpecStr.substring(0, firstNonSlash + selEnd);
/* 150 */       result = parseSelector(html, tail, referenceResolver);
/*     */     } else {
/* 152 */       result = new ArrayList<IMarkupSelectorItem>(3);
/*     */     } 
/*     */     
/* 155 */     Matcher matcher = selectorPattern.matcher(selectorSpecStr);
/* 156 */     if (!matcher.matches()) {
/* 157 */       throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": selector does not match selector syntax: ((/|//)?selector)?([@attrib=\"value\" ((and|or) @attrib2=\"value\")?])?([index])?");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 162 */     String rootGroup = matcher.group(1);
/* 163 */     String selectorNameGroup = matcher.group(2);
/* 164 */     String modifiersGroup = matcher.group(3);
/*     */     
/* 166 */     if (rootGroup == null) {
/* 167 */       throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": selector does not match selector syntax: ((/|//)?selector)?([@attrib=\"value\" ((and|or) @attrib2=\"value\")?])?([index])?");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 173 */     if ("//".equals(rootGroup)) {
/* 174 */       anyLevel = true;
/* 175 */     } else if ("/".equals(rootGroup)) {
/* 176 */       anyLevel = false;
/*     */     } else {
/* 178 */       throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": selector does not match selector syntax: ((/|//)?selector)?([@attrib=\"value\" ((and|or) @attrib2=\"value\")?])?([index])?");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 183 */     if (selectorNameGroup == null) {
/* 184 */       throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": selector does not match selector syntax: ((/|//)?selector)?([@attrib=\"value\" ((and|or) @attrib2=\"value\")?])?([index])?");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 196 */     String path = selectorNameGroup;
/*     */ 
/*     */     
/* 199 */     MarkupSelectorItem.IndexCondition index = initialIndexCondition;
/* 200 */     MarkupSelectorItem.IAttributeCondition attributeCondition = initialAttributeCondition;
/*     */ 
/*     */ 
/*     */     
/* 204 */     int idModifierPos = html ? path.indexOf("#") : -1;
/*     */     
/* 206 */     int classModifierPos = html ? path.indexOf(".") : -1;
/* 207 */     int referenceModifierPos = path.indexOf("%");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 214 */     if (idModifierPos != -1) {
/* 215 */       if (classModifierPos != -1 || referenceModifierPos != -1) {
/* 216 */         throw new IllegalArgumentException("More than one modifier (id, class, reference) have been specified at selector expression \"" + selector + "\", which is forbidden.");
/*     */       }
/*     */ 
/*     */       
/* 220 */       String selectorPathIdModifier = path.substring(idModifierPos + "#".length());
/* 221 */       path = path.substring(0, idModifierPos);
/* 222 */       if (isEmptyOrWhitespace(selectorPathIdModifier)) {
/* 223 */         throw new IllegalArgumentException("Empty id modifier in selector expression \"" + selector + "\", which is forbidden.");
/*     */       }
/*     */ 
/*     */       
/* 227 */       MarkupSelectorItem.AttributeCondition newAttributeCondition = new MarkupSelectorItem.AttributeCondition("id", MarkupSelectorItem.AttributeCondition.Operator.EQUALS, selectorPathIdModifier);
/*     */ 
/*     */       
/* 230 */       if (attributeCondition == null) {
/* 231 */         attributeCondition = newAttributeCondition;
/*     */       } else {
/* 233 */         attributeCondition = new MarkupSelectorItem.AttributeConditionRelation(MarkupSelectorItem.AttributeConditionRelation.Type.AND, attributeCondition, newAttributeCondition);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     if (classModifierPos != -1) {
/* 244 */       if (idModifierPos != -1 || referenceModifierPos != -1) {
/* 245 */         throw new IllegalArgumentException("More than one modifier (id, class, reference) have been specified at selector expression \"" + selector + "\", which is forbidden.");
/*     */       }
/*     */ 
/*     */       
/* 249 */       String selectorPathClassModifier = path.substring(classModifierPos + ".".length());
/* 250 */       path = path.substring(0, classModifierPos);
/* 251 */       if (isEmptyOrWhitespace(selectorPathClassModifier)) {
/* 252 */         throw new IllegalArgumentException("Empty id modifier in selector expression \"" + selector + "\", which is forbidden.");
/*     */       }
/*     */ 
/*     */       
/* 256 */       MarkupSelectorItem.AttributeCondition newAttributeCondition = new MarkupSelectorItem.AttributeCondition("class", MarkupSelectorItem.AttributeCondition.Operator.EQUALS, selectorPathClassModifier);
/*     */ 
/*     */       
/* 259 */       if (attributeCondition == null) {
/* 260 */         attributeCondition = newAttributeCondition;
/*     */       } else {
/* 262 */         attributeCondition = new MarkupSelectorItem.AttributeConditionRelation(MarkupSelectorItem.AttributeConditionRelation.Type.AND, attributeCondition, newAttributeCondition);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 272 */     String selectorPathReferenceModifier = null;
/* 273 */     if (referenceModifierPos != -1) {
/* 274 */       if (idModifierPos != -1 || classModifierPos != -1) {
/* 275 */         throw new IllegalArgumentException("More than one modifier (id, class, reference) have been specified at selector expression \"" + selector + "\", which is forbidden.");
/*     */       }
/*     */ 
/*     */       
/* 279 */       selectorPathReferenceModifier = path.substring(referenceModifierPos + "%".length());
/* 280 */       path = path.substring(0, referenceModifierPos);
/* 281 */       if (isEmptyOrWhitespace(selectorPathReferenceModifier)) {
/* 282 */         throw new IllegalArgumentException("Empty id modifier in selector expression \"" + selector + "\", which is forbidden.");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 295 */     boolean contentSelector = "content()".equals(path);
/* 296 */     boolean textSelector = "text()".equals(path);
/* 297 */     boolean commentSelector = "comment()".equals(path);
/* 298 */     boolean cdataSectionSelector = "cdata()".equals(path);
/* 299 */     boolean docTypeClauseSelector = "doctype()".equals(path);
/* 300 */     boolean xmlDeclarationSelector = "xmldecl()".equals(path);
/* 301 */     boolean processingInstructionSelector = "procinstr()".equals(path);
/*     */     
/* 303 */     boolean isNonElementSelector = (contentSelector || textSelector || commentSelector || cdataSectionSelector || docTypeClauseSelector || xmlDeclarationSelector || processingInstructionSelector);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 312 */     String caseSensitiveSelectorPath = isNonElementSelector ? null : (isEmptyOrWhitespace(path) ? null : path);
/*     */ 
/*     */ 
/*     */     
/* 316 */     String selectorPath = (caseSensitiveSelectorPath == null) ? null : (html ? caseSensitiveSelectorPath.toLowerCase() : caseSensitiveSelectorPath);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 323 */     if (modifiersGroup != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 331 */       String remainingModifiers = modifiersGroup;
/*     */       
/* 333 */       while (remainingModifiers != null) {
/*     */ 
/*     */         
/* 336 */         Matcher modifiersMatcher = modifiersPattern.matcher(remainingModifiers);
/* 337 */         if (!modifiersMatcher.matches()) {
/* 338 */           throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": selector does not match selector syntax: ((/|//)?selector)?([@attrib=\"value\" ((and|or) @attrib2=\"value\")?])?([index])?");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 343 */         String currentModifier = modifiersMatcher.group(1);
/* 344 */         remainingModifiers = modifiersMatcher.group(2);
/*     */         
/* 346 */         MarkupSelectorItem.IndexCondition newIndex = parseIndex(currentModifier);
/*     */         
/* 348 */         if (newIndex != null) {
/*     */           
/* 350 */           if (remainingModifiers != null)
/*     */           {
/* 352 */             throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": selector does not match selector syntax: ((/|//)?selector)?([@attrib=\"value\" ((and|or) @attrib2=\"value\")?])?([index])?");
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 357 */           if (index != null)
/*     */           {
/* 359 */             throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": cannot combine two different index modifiers (probably one was specified in the expression itself, and the other one comes from a reference resolver).");
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 365 */           index = newIndex;
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 371 */         MarkupSelectorItem.IAttributeCondition newAttributeCondition = parseAttributeCondition(html, selector, currentModifier);
/* 372 */         if (newAttributeCondition == null) {
/* 373 */           throw new IllegalArgumentException("Invalid syntax in selector \"" + selector + "\": selector does not match selector syntax: (/|//)(selector)([@attrib=\"value\" ((and|or) @attrib2=\"value\")?])?([index])?");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 378 */         if (attributeCondition == null) {
/* 379 */           attributeCondition = newAttributeCondition; continue;
/*     */         } 
/* 381 */         attributeCondition = new MarkupSelectorItem.AttributeConditionRelation(MarkupSelectorItem.AttributeConditionRelation.Type.AND, attributeCondition, newAttributeCondition);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 392 */     IMarkupSelectorItem thisItem = new MarkupSelectorItem(html, anyLevel, contentSelector, textSelector, commentSelector, cdataSectionSelector, docTypeClauseSelector, xmlDeclarationSelector, processingInstructionSelector, selectorPath, index, attributeCondition);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 398 */     if (referenceResolver != null && (selectorPathReferenceModifier != null || selectorPath != null))
/*     */     {
/* 400 */       if (selectorPathReferenceModifier != null) {
/*     */ 
/*     */         
/* 403 */         String resolvedSelector = referenceResolver.resolveSelectorFromReference(selectorPathReferenceModifier);
/*     */         
/* 405 */         if (resolvedSelector != null)
/*     */         {
/* 407 */           if (resolvedSelector.startsWith("//")) {
/* 408 */             if (!anyLevel) {
/* 409 */               resolvedSelector = resolvedSelector.substring(1);
/*     */             }
/* 411 */           } else if (resolvedSelector.startsWith("/")) {
/* 412 */             if (anyLevel) {
/* 413 */               resolvedSelector = "/" + resolvedSelector;
/*     */             }
/* 415 */           } else if (!anyLevel) {
/* 416 */             resolvedSelector = "/" + resolvedSelector;
/*     */           } 
/*     */ 
/*     */           
/* 420 */           List<IMarkupSelectorItem> parsedReference = parseSelector(html, resolvedSelector, null);
/* 421 */           if (parsedReference != null && parsedReference.size() > 1) {
/* 422 */             throw new IllegalArgumentException("Invalid selector resolved by reference resolver of class " + referenceResolver
/* 423 */                 .getClass().getName() + "  for selector " + selectorPath + ": resolved selector has more than one level, which is forbidden.");
/*     */           }
/*     */           
/* 426 */           if (parsedReference != null && parsedReference.size() == 1) {
/* 427 */             thisItem = new MarkupSelectorAndItem(thisItem, parsedReference.get(0));
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 436 */         String resolvedSelector = referenceResolver.resolveSelectorFromReference(caseSensitiveSelectorPath);
/*     */         
/* 438 */         if (resolvedSelector != null) {
/*     */           
/* 440 */           if (resolvedSelector.startsWith("//")) {
/* 441 */             if (!anyLevel) {
/* 442 */               resolvedSelector = resolvedSelector.substring(1);
/*     */             }
/* 444 */           } else if (resolvedSelector.startsWith("/")) {
/* 445 */             if (anyLevel) {
/* 446 */               resolvedSelector = "/" + resolvedSelector;
/*     */             }
/* 448 */           } else if (!anyLevel) {
/* 449 */             resolvedSelector = "/" + resolvedSelector;
/*     */           } 
/*     */ 
/*     */           
/* 453 */           List<IMarkupSelectorItem> parsedReference = parseSelector(html, resolvedSelector, attributeCondition, index, null);
/* 454 */           if (parsedReference != null && parsedReference.size() > 1) {
/* 455 */             throw new IllegalArgumentException("Invalid selector resolved by reference resolver of class " + referenceResolver
/* 456 */                 .getClass().getName() + "  for selector " + selectorPath + ": resolved selector has more than one level, which is forbidden.");
/*     */           }
/*     */           
/* 459 */           if (parsedReference != null && parsedReference.size() == 1) {
/* 460 */             thisItem = new MarkupSelectorOrItem(thisItem, parsedReference.get(0));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 469 */     result.add(0, thisItem);
/*     */     
/* 471 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MarkupSelectorItem.IndexCondition parseIndex(String indexGroup) {
/* 480 */     if ("odd()".equals(indexGroup.toLowerCase())) {
/* 481 */       return MarkupSelectorItem.IndexCondition.INDEX_CONDITION_ODD;
/*     */     }
/* 483 */     if ("even()".equals(indexGroup.toLowerCase())) {
/* 484 */       return MarkupSelectorItem.IndexCondition.INDEX_CONDITION_EVEN;
/*     */     }
/*     */     
/* 487 */     if (indexGroup.charAt(0) == '>') {
/*     */       
/*     */       try {
/* 490 */         return new MarkupSelectorItem.IndexCondition(MarkupSelectorItem.IndexCondition.IndexConditionType.MORE_THAN, Integer.valueOf(indexGroup.substring(1).trim()).intValue());
/* 491 */       } catch (Exception ignored) {
/* 492 */         return null;
/*     */       } 
/*     */     }
/* 495 */     if (indexGroup.charAt(0) == '<') {
/*     */       
/*     */       try {
/* 498 */         return new MarkupSelectorItem.IndexCondition(MarkupSelectorItem.IndexCondition.IndexConditionType.LESS_THAN, Integer.valueOf(indexGroup.substring(1).trim()).intValue());
/* 499 */       } catch (Exception ignored) {
/* 500 */         return null;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 506 */       return new MarkupSelectorItem.IndexCondition(MarkupSelectorItem.IndexCondition.IndexConditionType.VALUE, Integer.valueOf(indexGroup.trim()).intValue());
/* 507 */     } catch (Exception ignored) {
/* 508 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MarkupSelectorItem.IAttributeCondition parseAttributeCondition(boolean html, String selectorSpec, String attrGroup) {
/* 518 */     String text = removeEnvelopingParentheses((attrGroup != null) ? attrGroup.trim() : null);
/* 519 */     if (isEmptyOrWhitespace(text)) {
/* 520 */       throw new IllegalArgumentException("Invalid syntax in selector: \"" + selectorSpec + "\"");
/*     */     }
/*     */ 
/*     */     
/* 524 */     boolean inDoubleLiteral = false;
/* 525 */     boolean inSimpleLiteral = false;
/* 526 */     int nestingLevel = 0;
/* 527 */     int i = 0;
/* 528 */     int textLen = text.length();
/* 529 */     while (i < textLen) {
/*     */       
/* 531 */       char c = text.charAt(i);
/* 532 */       if (c == '\'' && !inDoubleLiteral) {
/* 533 */         inSimpleLiteral = !inSimpleLiteral;
/* 534 */         i++;
/*     */         continue;
/*     */       } 
/* 537 */       if (c == '"' && !inSimpleLiteral) {
/* 538 */         inDoubleLiteral = !inDoubleLiteral;
/* 539 */         i++;
/*     */         continue;
/*     */       } 
/* 542 */       if (!inSimpleLiteral && !inDoubleLiteral) {
/* 543 */         if (c == '(') {
/* 544 */           nestingLevel++;
/* 545 */           i++;
/*     */           continue;
/*     */         } 
/* 548 */         if (c == ')') {
/* 549 */           nestingLevel--;
/* 550 */           i++;
/*     */           continue;
/*     */         } 
/* 553 */         if (nestingLevel == 0 && i + 4 < textLen && 
/* 554 */           Character.isWhitespace(c) && (text
/* 555 */           .charAt(i + 1) == 'a' || text.charAt(i + 1) == 'A') && (text
/* 556 */           .charAt(i + 2) == 'n' || text.charAt(i + 2) == 'N') && (text
/* 557 */           .charAt(i + 3) == 'd' || text.charAt(i + 3) == 'D') && 
/* 558 */           Character.isWhitespace(text.charAt(i + 4))) {
/*     */ 
/*     */           
/* 561 */           MarkupSelectorItem.IAttributeCondition left = parseAttributeCondition(html, selectorSpec, text.substring(0, i));
/*     */           
/* 563 */           MarkupSelectorItem.IAttributeCondition right = parseAttributeCondition(html, selectorSpec, text.substring(i + 5, textLen));
/* 564 */           return new MarkupSelectorItem.AttributeConditionRelation(MarkupSelectorItem.AttributeConditionRelation.Type.AND, left, right);
/*     */         } 
/*     */ 
/*     */         
/* 568 */         if (nestingLevel == 0 && i + 3 < textLen && 
/* 569 */           Character.isWhitespace(c) && (text
/* 570 */           .charAt(i + 1) == 'o' || text.charAt(i + 1) == 'O') && (text
/* 571 */           .charAt(i + 2) == 'r' || text.charAt(i + 2) == 'R') && 
/* 572 */           Character.isWhitespace(text.charAt(i + 3))) {
/*     */ 
/*     */           
/* 575 */           MarkupSelectorItem.IAttributeCondition left = parseAttributeCondition(html, selectorSpec, text.substring(0, i));
/*     */           
/* 577 */           MarkupSelectorItem.IAttributeCondition right = parseAttributeCondition(html, selectorSpec, text.substring(i + 4, textLen));
/* 578 */           return new MarkupSelectorItem.AttributeConditionRelation(MarkupSelectorItem.AttributeConditionRelation.Type.OR, left, right);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 584 */       i++;
/*     */     } 
/*     */ 
/*     */     
/* 588 */     return parseSimpleAttributeCondition(html, selectorSpec, text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String removeEnvelopingParentheses(String target) {
/* 595 */     if (target == null) {
/* 596 */       return null;
/*     */     }
/*     */     
/* 599 */     String text = target.trim();
/* 600 */     int textLen = text.length();
/*     */     
/* 602 */     if (textLen > 1 && text.charAt(0) == '(' && text.charAt(textLen - 1) == ')') {
/* 603 */       boolean inDoubleLiteral = false;
/* 604 */       boolean inSimpleLiteral = false;
/* 605 */       int nestingLevel = 1;
/* 606 */       int i = 1;
/*     */       
/* 608 */       while (i < textLen) {
/* 609 */         if (nestingLevel == 0)
/*     */         {
/*     */           
/* 612 */           return text;
/*     */         }
/* 614 */         char c = text.charAt(i++);
/* 615 */         if (c == '\'' && !inDoubleLiteral) {
/* 616 */           inSimpleLiteral = !inSimpleLiteral; continue;
/* 617 */         }  if (c == '"' && !inSimpleLiteral) {
/* 618 */           inDoubleLiteral = !inDoubleLiteral; continue;
/* 619 */         }  if (!inSimpleLiteral && !inDoubleLiteral) {
/* 620 */           if (c == '(') {
/* 621 */             nestingLevel++; continue;
/* 622 */           }  if (c == ')') {
/* 623 */             nestingLevel--;
/*     */           }
/*     */         } 
/*     */       } 
/* 627 */       if (nestingLevel > 0)
/*     */       {
/* 629 */         return text;
/*     */       }
/*     */       
/* 632 */       return removeEnvelopingParentheses(text.substring(1, textLen - 1));
/*     */     } 
/*     */     
/* 635 */     return text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MarkupSelectorItem.AttributeCondition parseSimpleAttributeCondition(boolean html, String selectorSpec, String attributeSpec) {
/* 645 */     String[] fragments = tokenizeAttributeSpec(attributeSpec);
/*     */     
/* 647 */     String attrName = fragments[0];
/* 648 */     if (attrName.startsWith("@")) {
/* 649 */       attrName = attrName.substring(1);
/*     */     }
/* 651 */     attrName = html ? attrName.toLowerCase() : attrName;
/*     */     
/* 653 */     MarkupSelectorItem.AttributeCondition.Operator operator = parseAttributeOperator(fragments[1]);
/*     */     
/* 655 */     String attrValue = fragments[2];
/* 656 */     if (attrValue != null) {
/* 657 */       if ((!attrValue.startsWith("\"") || !attrValue.endsWith("\"")) && (!attrValue.startsWith("'") || !attrValue.endsWith("'"))) {
/* 658 */         throw new IllegalArgumentException("Invalid syntax in selector: \"" + selectorSpec + "\"");
/*     */       }
/*     */       
/* 661 */       return new MarkupSelectorItem.AttributeCondition(attrName, operator, attrValue.substring(1, attrValue.length() - 1));
/*     */     } 
/* 663 */     return new MarkupSelectorItem.AttributeCondition(attrName, operator, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] tokenizeAttributeSpec(String specification) {
/* 670 */     int equalsPos = specification.indexOf('=');
/* 671 */     if (equalsPos == -1) {
/* 672 */       if (specification.charAt(0) == '!') {
/* 673 */         return new String[] { specification.substring(1).trim(), "!", null };
/*     */       }
/* 675 */       return new String[] { specification.trim(), "", null };
/*     */     } 
/* 677 */     char cprev = specification.charAt(equalsPos - 1);
/* 678 */     switch (cprev) {
/*     */       case '!':
/* 680 */         return new String[] { specification
/* 681 */             .substring(0, equalsPos - 1).trim(), "!=", specification
/* 682 */             .substring(equalsPos + 1).trim() };
/*     */       case '^':
/* 684 */         return new String[] { specification
/* 685 */             .substring(0, equalsPos - 1).trim(), "^=", specification
/* 686 */             .substring(equalsPos + 1).trim() };
/*     */       case '$':
/* 688 */         return new String[] { specification
/* 689 */             .substring(0, equalsPos - 1).trim(), "$=", specification
/* 690 */             .substring(equalsPos + 1).trim() };
/*     */       case '*':
/* 692 */         return new String[] { specification
/* 693 */             .substring(0, equalsPos - 1).trim(), "*=", specification
/* 694 */             .substring(equalsPos + 1).trim() };
/*     */     } 
/* 696 */     return new String[] { specification
/* 697 */         .substring(0, equalsPos).trim(), "=", specification
/* 698 */         .substring(equalsPos + 1).trim() };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static MarkupSelectorItem.AttributeCondition.Operator parseAttributeOperator(String operatorStr) {
/* 704 */     if (operatorStr == null) {
/* 705 */       return null;
/*     */     }
/* 707 */     if ("=".equals(operatorStr)) {
/* 708 */       return MarkupSelectorItem.AttributeCondition.Operator.EQUALS;
/*     */     }
/* 710 */     if ("!=".equals(operatorStr)) {
/* 711 */       return MarkupSelectorItem.AttributeCondition.Operator.NOT_EQUALS;
/*     */     }
/* 713 */     if ("^=".equals(operatorStr)) {
/* 714 */       return MarkupSelectorItem.AttributeCondition.Operator.STARTS_WITH;
/*     */     }
/* 716 */     if ("$=".equals(operatorStr)) {
/* 717 */       return MarkupSelectorItem.AttributeCondition.Operator.ENDS_WITH;
/*     */     }
/* 719 */     if ("*=".equals(operatorStr)) {
/* 720 */       return MarkupSelectorItem.AttributeCondition.Operator.CONTAINS;
/*     */     }
/* 722 */     if ("!".equals(operatorStr)) {
/* 723 */       return MarkupSelectorItem.AttributeCondition.Operator.NOT_EXISTS;
/*     */     }
/* 725 */     if ("".equals(operatorStr)) {
/* 726 */       return MarkupSelectorItem.AttributeCondition.Operator.EXISTS;
/*     */     }
/* 728 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isEmptyOrWhitespace(String target) {
/* 736 */     if (target == null) {
/* 737 */       return true;
/*     */     }
/* 739 */     int targetLen = target.length();
/* 740 */     if (targetLen == 0) {
/* 741 */       return true;
/*     */     }
/* 743 */     char c0 = target.charAt(0);
/* 744 */     if ((c0 >= 'a' && c0 <= 'z') || (c0 >= 'A' && c0 <= 'Z'))
/*     */     {
/* 746 */       return false;
/*     */     }
/* 748 */     for (int i = 0; i < targetLen; i++) {
/* 749 */       char c = target.charAt(i);
/* 750 */       if (c != ' ' && !Character.isWhitespace(c)) {
/* 751 */         return false;
/*     */       }
/*     */     } 
/* 754 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\attoparser-2.0.7.RELEASE.jar!\org\attoparser\select\MarkupSelectorItems.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */