/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MissingNode
/*     */   extends ValueNode
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  28 */   private static final MissingNode instance = new MissingNode();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object readResolve() {
/*  39 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMissingNode() {
/*  44 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends JsonNode> T deepCopy() {
/*  50 */     return (T)this;
/*     */   } public static MissingNode getInstance() {
/*  52 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonNodeType getNodeType() {
/*  57 */     return JsonNodeType.MISSING;
/*     */   }
/*     */   public JsonToken asToken() {
/*  60 */     return JsonToken.NOT_AVAILABLE;
/*     */   } public String asText() {
/*  62 */     return "";
/*     */   } public String asText(String defaultValue) {
/*  64 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Optional<JsonNode> asOptional() {
/*  77 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void serialize(JsonGenerator g, SerializerProvider provider) throws IOException {
/*  96 */     g.writeNull();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeWithType(JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/* 104 */     g.writeNull();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonNode require() {
/* 116 */     return (JsonNode)_reportRequiredViolation("require() called on `MissingNode`", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonNode requireNonNull() {
/* 122 */     return (JsonNode)_reportRequiredViolation("requireNonNull() called on `MissingNode`", new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 127 */     return JsonNodeType.MISSING.ordinal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 140 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public String toPrettyString() {
/* 145 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 157 */     return (o == this);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\node\MissingNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */