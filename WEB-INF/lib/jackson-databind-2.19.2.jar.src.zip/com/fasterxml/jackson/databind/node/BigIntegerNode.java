/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BigIntegerNode
/*     */   extends NumericNode
/*     */ {
/*  18 */   private static final BigInteger MIN_INTEGER = BigInteger.valueOf(-2147483648L);
/*  19 */   private static final BigInteger MAX_INTEGER = BigInteger.valueOf(2147483647L);
/*  20 */   private static final BigInteger MIN_LONG = BigInteger.valueOf(Long.MIN_VALUE);
/*  21 */   private static final BigInteger MAX_LONG = BigInteger.valueOf(Long.MAX_VALUE);
/*     */ 
/*     */ 
/*     */   
/*     */   protected final BigInteger _value;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BigIntegerNode(BigInteger v) {
/*  31 */     this._value = v;
/*     */   } public static BigIntegerNode valueOf(BigInteger v) {
/*  33 */     return new BigIntegerNode(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonToken asToken() {
/*  42 */     return JsonToken.VALUE_NUMBER_INT;
/*     */   }
/*     */   public JsonParser.NumberType numberType() {
/*  45 */     return JsonParser.NumberType.BIG_INTEGER;
/*     */   }
/*     */   public boolean isIntegralNumber() {
/*  48 */     return true;
/*     */   }
/*     */   public boolean isBigInteger() {
/*  51 */     return true;
/*     */   }
/*     */   public boolean canConvertToInt() {
/*  54 */     return (this._value.compareTo(MIN_INTEGER) >= 0 && this._value.compareTo(MAX_INTEGER) <= 0);
/*     */   }
/*     */   public boolean canConvertToLong() {
/*  57 */     return (this._value.compareTo(MIN_LONG) >= 0 && this._value.compareTo(MAX_LONG) <= 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public Number numberValue() {
/*  62 */     return this._value;
/*     */   }
/*     */   
/*     */   public short shortValue() {
/*  66 */     return this._value.shortValue();
/*     */   }
/*     */   public int intValue() {
/*  69 */     return this._value.intValue();
/*     */   }
/*     */   public long longValue() {
/*  72 */     return this._value.longValue();
/*     */   }
/*     */   public BigInteger bigIntegerValue() {
/*  75 */     return this._value;
/*     */   }
/*     */   public float floatValue() {
/*  78 */     return this._value.floatValue();
/*     */   }
/*     */   public double doubleValue() {
/*  81 */     return this._value.doubleValue();
/*     */   }
/*     */   public BigDecimal decimalValue() {
/*  84 */     return new BigDecimal(this._value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String asText() {
/*  94 */     return this._value.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean asBoolean(boolean defaultValue) {
/*  99 */     return !BigInteger.ZERO.equals(this._value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void serialize(JsonGenerator g, SerializerProvider provider) throws IOException {
/* 106 */     g.writeNumber(this._value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 112 */     if (o == this) return true; 
/* 113 */     if (o == null) return false; 
/* 114 */     if (o instanceof BigIntegerNode) {
/* 115 */       BigIntegerNode otherNode = (BigIntegerNode)o;
/* 116 */       return Objects.equals(otherNode._value, this._value);
/*     */     } 
/* 118 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 123 */     return Objects.hashCode(this._value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\node\BigIntegerNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */