/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.JsonSerializable;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import java.io.IOException;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class POJONode
/*     */   extends ValueNode
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   protected final Object _value;
/*     */   
/*     */   public POJONode(Object v) {
/*  22 */     this._value = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonNodeType getNodeType() {
/*  32 */     return JsonNodeType.POJO;
/*     */   }
/*     */   public JsonToken asToken() {
/*  35 */     return JsonToken.VALUE_EMBEDDED_OBJECT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] binaryValue() throws IOException {
/*  45 */     if (this._value instanceof byte[]) {
/*  46 */       return (byte[])this._value;
/*     */     }
/*  48 */     return super.binaryValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String asText() {
/*  58 */     return (this._value == null) ? "null" : this._value.toString();
/*     */   }
/*     */   
/*     */   public String asText(String defaultValue) {
/*  62 */     return (this._value == null) ? defaultValue : this._value.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean asBoolean(boolean defaultValue) {
/*  68 */     if (this._value != null && this._value instanceof Boolean) {
/*  69 */       return ((Boolean)this._value).booleanValue();
/*     */     }
/*  71 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int asInt(int defaultValue) {
/*  77 */     if (this._value instanceof Number) {
/*  78 */       return ((Number)this._value).intValue();
/*     */     }
/*  80 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long asLong(long defaultValue) {
/*  86 */     if (this._value instanceof Number) {
/*  87 */       return ((Number)this._value).longValue();
/*     */     }
/*  89 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double asDouble(double defaultValue) {
/*  95 */     if (this._value instanceof Number) {
/*  96 */       return ((Number)this._value).doubleValue();
/*     */     }
/*  98 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void serialize(JsonGenerator gen, SerializerProvider ctxt) throws IOException {
/* 110 */     if (this._value == null) {
/* 111 */       ctxt.defaultSerializeNull(gen);
/* 112 */     } else if (this._value instanceof JsonSerializable) {
/* 113 */       ((JsonSerializable)this._value).serialize(gen, ctxt);
/*     */     }
/*     */     else {
/*     */       
/* 117 */       ctxt.defaultSerializeValue(this._value, gen);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getPojo() {
/* 130 */     return this._value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 141 */     if (o == this) return true; 
/* 142 */     if (o == null) return false; 
/* 143 */     if (o instanceof POJONode) {
/* 144 */       return _pojoEquals((POJONode)o);
/*     */     }
/* 146 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _pojoEquals(POJONode other) {
/* 154 */     if (this._value == null) {
/* 155 */       return (other._value == null);
/*     */     }
/* 157 */     return this._value.equals(other._value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 162 */     return Objects.hashCode(this._value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\node\POJONode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */