/*      */ package com.fasterxml.jackson.databind.node;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonPointer;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.TreeNode;
/*      */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*      */ import com.fasterxml.jackson.databind.JsonNode;
/*      */ import com.fasterxml.jackson.databind.SerializerProvider;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*      */ import com.fasterxml.jackson.databind.util.RawValue;
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.stream.Stream;
/*      */ 
/*      */ public class ArrayNode extends ContainerNode<ArrayNode> implements Serializable {
/*      */   private static final long serialVersionUID = 1L;
/*      */   private final List<JsonNode> _children;
/*      */   
/*      */   public ArrayNode(JsonNodeFactory nf) {
/*   31 */     super(nf);
/*   32 */     this._children = new ArrayList<>();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode(JsonNodeFactory nf, int capacity) {
/*   39 */     super(nf);
/*   40 */     this._children = new ArrayList<>(capacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode(JsonNodeFactory nf, List<JsonNode> children) {
/*   47 */     super(nf);
/*   48 */     this._children = Objects.<List<JsonNode>>requireNonNull(children, "Must not pass `null` for 'children' argument");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonNode _at(JsonPointer ptr) {
/*   54 */     return get(ptr.getMatchingIndex());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode deepCopy() {
/*   62 */     ArrayNode ret = arrayNode(this._children.size());
/*   63 */     for (JsonNode element : this._children) {
/*   64 */       ret._children.add(element.deepCopy());
/*      */     }
/*   66 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectNode with(String exprOrProperty) {
/*   79 */     JsonPointer ptr = _jsonPointerIfValid(exprOrProperty);
/*   80 */     if (ptr != null) {
/*   81 */       return withObject(ptr);
/*      */     }
/*   83 */     return (ObjectNode)super.with(exprOrProperty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode withArray(String exprOrProperty) {
/*   90 */     JsonPointer ptr = _jsonPointerIfValid(exprOrProperty);
/*   91 */     if (ptr != null) {
/*   92 */       return withArray(ptr);
/*      */     }
/*   94 */     return (ArrayNode)super.withArray(exprOrProperty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectNode _withObject(JsonPointer origPtr, JsonPointer currentPtr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex) {
/*  102 */     if (currentPtr.matches())
/*      */     {
/*  104 */       return null;
/*      */     }
/*  106 */     JsonNode n = _at(currentPtr);
/*      */     
/*  108 */     if (n != null && n instanceof BaseJsonNode) {
/*  109 */       ObjectNode found = ((BaseJsonNode)n)._withObject(origPtr, currentPtr.tail(), overwriteMode, preferIndex);
/*      */       
/*  111 */       if (found != null) {
/*  112 */         return found;
/*      */       }
/*      */       
/*  115 */       _withXxxVerifyReplace(origPtr, currentPtr, overwriteMode, preferIndex, n);
/*      */     } 
/*      */     
/*  118 */     return _withObjectAddTailElement(currentPtr, preferIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ArrayNode _withArray(JsonPointer origPtr, JsonPointer currentPtr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex) {
/*  126 */     if (currentPtr.matches()) {
/*  127 */       return this;
/*      */     }
/*  129 */     JsonNode n = _at(currentPtr);
/*      */     
/*  131 */     if (n != null && n instanceof BaseJsonNode) {
/*  132 */       ArrayNode found = ((BaseJsonNode)n)._withArray(origPtr, currentPtr.tail(), overwriteMode, preferIndex);
/*      */       
/*  134 */       if (found != null) {
/*  135 */         return found;
/*      */       }
/*      */       
/*  138 */       _withXxxVerifyReplace(origPtr, currentPtr, overwriteMode, preferIndex, n);
/*      */     } 
/*      */     
/*  141 */     return _withArrayAddTailElement(currentPtr, preferIndex);
/*      */   }
/*      */ 
/*      */   
/*      */   protected ObjectNode _withObjectAddTailElement(JsonPointer tail, boolean preferIndex) {
/*  146 */     int index = tail.getMatchingIndex();
/*  147 */     if (index < 0) {
/*  148 */       return null;
/*      */     }
/*      */     
/*  151 */     tail = tail.tail();
/*      */ 
/*      */     
/*  154 */     if (tail.matches()) {
/*  155 */       ObjectNode result = objectNode();
/*  156 */       _withXxxSetArrayElement(index, result);
/*  157 */       return result;
/*      */     } 
/*      */ 
/*      */     
/*  161 */     if (preferIndex && tail.mayMatchElement()) {
/*  162 */       ArrayNode arrayNode = arrayNode();
/*  163 */       _withXxxSetArrayElement(index, arrayNode);
/*  164 */       return arrayNode._withObjectAddTailElement(tail, preferIndex);
/*      */     } 
/*  166 */     ObjectNode next = objectNode();
/*  167 */     _withXxxSetArrayElement(index, next);
/*  168 */     return next._withObjectAddTailProperty(tail, preferIndex);
/*      */   }
/*      */ 
/*      */   
/*      */   protected ArrayNode _withArrayAddTailElement(JsonPointer tail, boolean preferIndex) {
/*  173 */     int index = tail.getMatchingIndex();
/*  174 */     if (index < 0) {
/*  175 */       return null;
/*      */     }
/*  177 */     tail = tail.tail();
/*      */ 
/*      */     
/*  180 */     if (tail.matches()) {
/*  181 */       ArrayNode result = arrayNode();
/*  182 */       _withXxxSetArrayElement(index, result);
/*  183 */       return result;
/*      */     } 
/*      */ 
/*      */     
/*  187 */     if (preferIndex && tail.mayMatchElement()) {
/*  188 */       ArrayNode arrayNode = arrayNode();
/*  189 */       _withXxxSetArrayElement(index, arrayNode);
/*  190 */       return arrayNode._withArrayAddTailElement(tail, preferIndex);
/*      */     } 
/*  192 */     ObjectNode next = objectNode();
/*  193 */     _withXxxSetArrayElement(index, next);
/*  194 */     return next._withArrayAddTailProperty(tail, preferIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _withXxxSetArrayElement(int index, JsonNode value) {
/*  200 */     if (index >= size()) {
/*  201 */       int max = this._nodeFactory.getMaxElementIndexForInsert();
/*  202 */       if (index > max)
/*  203 */         _reportWrongNodeOperation("Too big Array index (%d; max %d) to use for insert with `JsonPointer`", new Object[] {
/*  204 */               Integer.valueOf(index), Integer.valueOf(max)
/*      */             }); 
/*  206 */       while (index >= size()) {
/*  207 */         addNull();
/*      */       }
/*      */     } 
/*  210 */     set(index, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty(SerializerProvider serializers) {
/*  221 */     return this._children.isEmpty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNodeType getNodeType() {
/*  232 */     return JsonNodeType.ARRAY;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isArray() {
/*  237 */     return true;
/*      */   }
/*      */   public JsonToken asToken() {
/*  240 */     return JsonToken.START_ARRAY;
/*      */   }
/*      */   
/*      */   public int size() {
/*  244 */     return this._children.size();
/*      */   }
/*      */   
/*      */   public boolean isEmpty() {
/*  248 */     return this._children.isEmpty();
/*      */   }
/*      */   
/*      */   public Iterator<JsonNode> elements() {
/*  252 */     return this._children.listIterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterator<JsonNode> values() {
/*  264 */     return this._children.listIterator();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode get(int index) {
/*  269 */     if (index >= 0 && index < this._children.size()) {
/*  270 */       return this._children.get(index);
/*      */     }
/*  272 */     return null;
/*      */   }
/*      */   
/*      */   public JsonNode get(String fieldName) {
/*  276 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<JsonNode> optional(int index) {
/*  283 */     return Optional.ofNullable(get(index));
/*      */   }
/*      */   
/*      */   public JsonNode path(String fieldName) {
/*  287 */     return MissingNode.getInstance();
/*      */   }
/*      */   
/*      */   public JsonNode path(int index) {
/*  291 */     if (index >= 0 && index < this._children.size()) {
/*  292 */       return this._children.get(index);
/*      */     }
/*  294 */     return MissingNode.getInstance();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode required(int index) {
/*  299 */     if (index >= 0 && index < this._children.size()) {
/*  300 */       return this._children.get(index);
/*      */     }
/*  302 */     return (JsonNode)_reportRequiredViolation("No value at index #%d [0, %d) of `ArrayNode`", new Object[] {
/*  303 */           Integer.valueOf(index), Integer.valueOf(this._children.size())
/*      */         });
/*      */   }
/*      */   
/*      */   public Stream<JsonNode> valueStream() {
/*  308 */     return this._children.stream();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Comparator<JsonNode> comparator, JsonNode o) {
/*  314 */     if (!(o instanceof ArrayNode)) {
/*  315 */       return false;
/*      */     }
/*  317 */     ArrayNode other = (ArrayNode)o;
/*  318 */     int len = this._children.size();
/*  319 */     if (other.size() != len) {
/*  320 */       return false;
/*      */     }
/*  322 */     List<JsonNode> l1 = this._children;
/*  323 */     List<JsonNode> l2 = other._children;
/*  324 */     for (int i = 0; i < len; i++) {
/*  325 */       if (!((JsonNode)l1.get(i)).equals(comparator, l2.get(i))) {
/*  326 */         return false;
/*      */       }
/*      */     } 
/*  329 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serialize(JsonGenerator g, SerializerProvider provider) throws IOException {
/*  341 */     List<JsonNode> c = this._children;
/*  342 */     int size = c.size();
/*  343 */     g.writeStartArray(this, size);
/*  344 */     for (int i = 0; i < size; i++) {
/*  345 */       JsonNode value = c.get(i);
/*  346 */       value.serialize(g, provider);
/*      */     } 
/*  348 */     g.writeEndArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serializeWithType(JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/*  355 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/*  356 */         .typeId(this, JsonToken.START_ARRAY));
/*  357 */     for (JsonNode n : this._children) {
/*  358 */       ((BaseJsonNode)n).serialize(g, provider);
/*      */     }
/*  360 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode findValue(String fieldName) {
/*  372 */     for (JsonNode node : this._children) {
/*  373 */       JsonNode value = node.findValue(fieldName);
/*  374 */       if (value != null) {
/*  375 */         return value;
/*      */       }
/*      */     } 
/*  378 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JsonNode> findValues(String fieldName, List<JsonNode> foundSoFar) {
/*  384 */     for (JsonNode node : this._children) {
/*  385 */       foundSoFar = node.findValues(fieldName, foundSoFar);
/*      */     }
/*  387 */     return foundSoFar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> findValuesAsText(String fieldName, List<String> foundSoFar) {
/*  393 */     for (JsonNode node : this._children) {
/*  394 */       foundSoFar = node.findValuesAsText(fieldName, foundSoFar);
/*      */     }
/*  396 */     return foundSoFar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode findParent(String fieldName) {
/*  402 */     for (JsonNode node : this._children) {
/*  403 */       JsonNode parent = node.findParent(fieldName);
/*  404 */       if (parent != null) {
/*  405 */         return (ObjectNode)parent;
/*      */       }
/*      */     } 
/*  408 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JsonNode> findParents(String fieldName, List<JsonNode> foundSoFar) {
/*  414 */     for (JsonNode node : this._children) {
/*  415 */       foundSoFar = node.findParents(fieldName, foundSoFar);
/*      */     }
/*  417 */     return foundSoFar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode set(int index, JsonNode value) {
/*  439 */     if (value == null) {
/*  440 */       value = nullNode();
/*      */     }
/*  442 */     if (index < 0 || index >= this._children.size()) {
/*  443 */       throw new IndexOutOfBoundsException("Illegal index " + index + ", array size " + size());
/*      */     }
/*  445 */     return this._children.set(index, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(JsonNode value) {
/*  455 */     if (value == null) {
/*  456 */       value = nullNode();
/*      */     }
/*  458 */     _add(value);
/*  459 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode addAll(ArrayNode other) {
/*  472 */     this._children.addAll(other._children);
/*  473 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode addAll(Collection<? extends JsonNode> nodes) {
/*  485 */     for (JsonNode node : nodes) {
/*  486 */       add(node);
/*      */     }
/*  488 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, JsonNode value) {
/*  502 */     if (value == null) {
/*  503 */       value = nullNode();
/*      */     }
/*  505 */     _insert(index, value);
/*  506 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode remove(int index) {
/*  518 */     if (index >= 0 && index < this._children.size()) {
/*  519 */       return this._children.remove(index);
/*      */     }
/*  521 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode removeAll() {
/*  533 */     this._children.clear();
/*  534 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ArrayNode removeIf(Predicate<? super JsonNode> predicate) {
/*  539 */     this._children.removeIf(predicate);
/*  540 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode addArray() {
/*  557 */     ArrayNode n = arrayNode();
/*  558 */     _add(n);
/*  559 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode addObject() {
/*  570 */     ObjectNode n = objectNode();
/*  571 */     _add(n);
/*  572 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode addPOJO(Object pojo) {
/*  582 */     return _add((pojo == null) ? nullNode() : pojoNode(pojo));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode addRawValue(RawValue raw) {
/*  591 */     return _add((raw == null) ? nullNode() : rawValueNode(raw));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode addNull() {
/*  600 */     return _add(nullNode());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(short v) {
/*  611 */     return _add(numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(Short v) {
/*  623 */     return _add((v == null) ? nullNode() : numberNode(v.shortValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(int v) {
/*  632 */     return _add(numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(Integer v) {
/*  642 */     return _add((v == null) ? nullNode() : numberNode(v.intValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(long v) {
/*  650 */     return _add(numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(Long v) {
/*  659 */     return _add((v == null) ? nullNode() : numberNode(v.longValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(float v) {
/*  668 */     return _add(numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(Float v) {
/*  678 */     return _add((v == null) ? nullNode() : numberNode(v.floatValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(double v) {
/*  687 */     return _add(numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(Double v) {
/*  697 */     return _add((v == null) ? nullNode() : numberNode(v.doubleValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(BigDecimal v) {
/*  706 */     return _add((v == null) ? nullNode() : numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(BigInteger v) {
/*  717 */     return _add((v == null) ? nullNode() : numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(String v) {
/*  726 */     return _add((v == null) ? nullNode() : textNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(boolean v) {
/*  735 */     return _add(booleanNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(Boolean v) {
/*  745 */     return _add((v == null) ? nullNode() : booleanNode(v.booleanValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode add(byte[] v) {
/*  755 */     return _add((v == null) ? nullNode() : binaryNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insertArray(int index) {
/*  768 */     ArrayNode n = arrayNode();
/*  769 */     _insert(index, n);
/*  770 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode insertObject(int index) {
/*  782 */     ObjectNode n = objectNode();
/*  783 */     _insert(index, n);
/*  784 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insertNull(int index) {
/*  794 */     return _insert(index, nullNode());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insertPOJO(int index, Object pojo) {
/*  804 */     return _insert(index, (pojo == null) ? nullNode() : pojoNode(pojo));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insertRawValue(int index, RawValue raw) {
/*  813 */     return _insert(index, (raw == null) ? nullNode() : rawValueNode(raw));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, short v) {
/*  825 */     return _insert(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, Short value) {
/*  837 */     return _insert(index, (value == null) ? nullNode() : numberNode(value.shortValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, int v) {
/*  847 */     return _insert(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, Integer v) {
/*  857 */     return _insert(index, (v == null) ? nullNode() : numberNode(v.intValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, long v) {
/*  867 */     return _insert(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, Long v) {
/*  877 */     return _insert(index, (v == null) ? nullNode() : numberNode(v.longValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, float v) {
/*  887 */     return _insert(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, Float v) {
/*  897 */     return _insert(index, (v == null) ? nullNode() : numberNode(v.floatValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, double v) {
/*  907 */     return _insert(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, Double v) {
/*  917 */     return _insert(index, (v == null) ? nullNode() : numberNode(v.doubleValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, BigDecimal v) {
/*  927 */     return _insert(index, (v == null) ? nullNode() : numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, BigInteger v) {
/*  939 */     return _insert(index, (v == null) ? nullNode() : numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, String v) {
/*  949 */     return _insert(index, (v == null) ? nullNode() : textNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, boolean v) {
/*  959 */     return _insert(index, booleanNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, Boolean value) {
/*  969 */     if (value == null) {
/*  970 */       return insertNull(index);
/*      */     }
/*  972 */     return _insert(index, booleanNode(value.booleanValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode insert(int index, byte[] v) {
/*  983 */     if (v == null) {
/*  984 */       return insertNull(index);
/*      */     }
/*  986 */     return _insert(index, binaryNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode setNull(int index) {
/*  995 */     return _set(index, nullNode());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode setPOJO(int index, Object pojo) {
/* 1004 */     return _set(index, (pojo == null) ? nullNode() : pojoNode(pojo));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode setRawValue(int index, RawValue raw) {
/* 1013 */     return _set(index, (raw == null) ? nullNode() : rawValueNode(raw));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, short v) {
/* 1022 */     return _set(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, Short v) {
/* 1034 */     return _set(index, (v == null) ? nullNode() : numberNode(v.shortValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, int v) {
/* 1043 */     return _set(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, Integer v) {
/* 1055 */     return _set(index, (v == null) ? nullNode() : numberNode(v.intValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, long v) {
/* 1064 */     return _set(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, Long v) {
/* 1073 */     return _set(index, (v == null) ? nullNode() : numberNode(v.longValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, float v) {
/* 1084 */     return _set(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, Float v) {
/* 1096 */     return _set(index, (v == null) ? nullNode() : numberNode(v.floatValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, double v) {
/* 1107 */     return _set(index, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, Double v) {
/* 1119 */     return _set(index, (v == null) ? nullNode() : numberNode(v.doubleValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, BigDecimal v) {
/* 1130 */     return _set(index, (v == null) ? nullNode() : numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, BigInteger v) {
/* 1141 */     return _set(index, (v == null) ? nullNode() : numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, String v) {
/* 1152 */     return _set(index, (v == null) ? nullNode() : textNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, boolean v) {
/* 1163 */     return _set(index, booleanNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, Boolean v) {
/* 1175 */     return _set(index, (v == null) ? nullNode() : booleanNode(v.booleanValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode set(int index, byte[] v) {
/* 1186 */     return _set(index, (v == null) ? nullNode() : binaryNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object o) {
/* 1198 */     if (o == this) return true; 
/* 1199 */     if (o == null) return false; 
/* 1200 */     if (o instanceof ArrayNode) {
/* 1201 */       return this._children.equals(((ArrayNode)o)._children);
/*      */     }
/* 1203 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _childrenEqual(ArrayNode other) {
/* 1210 */     return this._children.equals(other._children);
/*      */   }
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1215 */     return this._children.hashCode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ArrayNode _set(int index, JsonNode node) {
/* 1225 */     if (index < 0 || index >= this._children.size()) {
/* 1226 */       throw new IndexOutOfBoundsException("Illegal index " + index + ", array size " + size());
/*      */     }
/* 1228 */     this._children.set(index, node);
/* 1229 */     return this;
/*      */   }
/*      */   
/*      */   protected ArrayNode _add(JsonNode node) {
/* 1233 */     this._children.add(node);
/* 1234 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   protected ArrayNode _insert(int index, JsonNode node) {
/* 1239 */     if (index < 0) {
/* 1240 */       this._children.add(0, node);
/* 1241 */     } else if (index >= this._children.size()) {
/* 1242 */       this._children.add(node);
/*      */     } else {
/* 1244 */       this._children.add(index, node);
/*      */     } 
/* 1246 */     return this;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\node\ArrayNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */