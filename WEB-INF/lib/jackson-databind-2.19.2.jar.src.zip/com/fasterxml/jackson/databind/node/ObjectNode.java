/*      */ package com.fasterxml.jackson.databind.node;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonPointer;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.TreeNode;
/*      */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*      */ import com.fasterxml.jackson.databind.JsonNode;
/*      */ import com.fasterxml.jackson.databind.SerializationFeature;
/*      */ import com.fasterxml.jackson.databind.SerializerProvider;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*      */ import com.fasterxml.jackson.databind.cfg.JsonNodeFeature;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*      */ import com.fasterxml.jackson.databind.util.RawValue;
/*      */ import java.io.IOException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Optional;
/*      */ import java.util.Set;
/*      */ import java.util.function.BiConsumer;
/*      */ import java.util.function.Predicate;
/*      */ import java.util.stream.Stream;
/*      */ 
/*      */ public class ObjectNode extends ContainerNode<ObjectNode> implements Serializable {
/*      */   public ObjectNode(JsonNodeFactory nc) {
/*   33 */     super(nc);
/*   34 */     this._children = new LinkedHashMap<>();
/*      */   }
/*      */   
/*      */   private static final long serialVersionUID = 1L;
/*      */   protected final Map<String, JsonNode> _children;
/*      */   
/*      */   public ObjectNode(JsonNodeFactory nc, Map<String, JsonNode> children) {
/*   41 */     super(nc);
/*   42 */     this._children = Objects.<Map<String, JsonNode>>requireNonNull(children, "Must not pass `null` for 'children' argument");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonNode _at(JsonPointer ptr) {
/*   48 */     return get(ptr.getMatchingProperty());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode deepCopy() {
/*   59 */     ObjectNode ret = objectNode();
/*   60 */     for (Map.Entry<String, JsonNode> entry : this._children.entrySet()) {
/*   61 */       ret._children.put(entry.getKey(), ((JsonNode)entry.getValue()).deepCopy());
/*      */     }
/*   63 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectNode with(String exprOrProperty) {
/*   76 */     JsonPointer ptr = _jsonPointerIfValid(exprOrProperty);
/*   77 */     if (ptr != null) {
/*   78 */       return withObject(ptr);
/*      */     }
/*   80 */     JsonNode n = this._children.get(exprOrProperty);
/*   81 */     if (n != null) {
/*   82 */       if (n instanceof ObjectNode) {
/*   83 */         return (ObjectNode)n;
/*      */       }
/*   85 */       throw new UnsupportedOperationException("Property '" + exprOrProperty + "' has value that is not of type `ObjectNode` (but `" + n
/*      */           
/*   87 */           .getClass().getName() + "`)");
/*      */     } 
/*   89 */     ObjectNode result = objectNode();
/*   90 */     _put(exprOrProperty, result);
/*   91 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public ObjectNode withObject(String exprOrProperty) {
/*   96 */     JsonPointer ptr = _jsonPointerIfValid(exprOrProperty);
/*   97 */     if (ptr != null) {
/*   98 */       return withObject(ptr);
/*      */     }
/*  100 */     return withObjectProperty(exprOrProperty);
/*      */   }
/*      */ 
/*      */   
/*      */   public ObjectNode withObjectProperty(String propName) {
/*  105 */     JsonNode child = this._children.get(propName);
/*  106 */     if (child == null || child.isNull()) {
/*  107 */       return putObject(propName);
/*      */     }
/*  109 */     if (child.isObject()) {
/*  110 */       return (ObjectNode)child;
/*      */     }
/*  112 */     return _reportWrongNodeType("Cannot replace `JsonNode` of type `%s` with `ObjectNode` for property \"%s\" (default mode `OverwriteMode.%s`)", new Object[] { child
/*      */           
/*  114 */           .getClass().getName(), propName, JsonNode.OverwriteMode.NULLS });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode withArray(String exprOrProperty) {
/*  121 */     JsonPointer ptr = _jsonPointerIfValid(exprOrProperty);
/*  122 */     if (ptr != null) {
/*  123 */       return withArray(ptr);
/*      */     }
/*  125 */     JsonNode n = this._children.get(exprOrProperty);
/*  126 */     if (n != null) {
/*  127 */       if (n instanceof ArrayNode) {
/*  128 */         return (ArrayNode)n;
/*      */       }
/*  130 */       throw new UnsupportedOperationException("Property '" + exprOrProperty + "' has value that is not of type `ArrayNode` (but `" + n
/*      */           
/*  132 */           .getClass().getName() + "`)");
/*      */     } 
/*  134 */     ArrayNode result = arrayNode();
/*  135 */     _put(exprOrProperty, result);
/*  136 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public ArrayNode withArrayProperty(String propName) {
/*  141 */     JsonNode child = this._children.get(propName);
/*  142 */     if (child == null || child.isNull()) {
/*  143 */       return putArray(propName);
/*      */     }
/*  145 */     if (child.isArray()) {
/*  146 */       return (ArrayNode)child;
/*      */     }
/*  148 */     return (ArrayNode)_reportWrongNodeType("Cannot replace `JsonNode` of type `%s` with `ArrayNode` for property \"%s\" with (default mode `OverwriteMode.%s`)", new Object[] { child
/*      */           
/*  150 */           .getClass().getName(), propName, JsonNode.OverwriteMode.NULLS });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectNode _withObject(JsonPointer origPtr, JsonPointer currentPtr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex) {
/*  158 */     if (currentPtr.matches()) {
/*  159 */       return this;
/*      */     }
/*      */     
/*  162 */     JsonNode n = _at(currentPtr);
/*      */     
/*  164 */     if (n != null && n instanceof BaseJsonNode) {
/*  165 */       ObjectNode found = ((BaseJsonNode)n)._withObject(origPtr, currentPtr.tail(), overwriteMode, preferIndex);
/*      */       
/*  167 */       if (found != null) {
/*  168 */         return found;
/*      */       }
/*      */       
/*  171 */       _withXxxVerifyReplace(origPtr, currentPtr, overwriteMode, preferIndex, n);
/*      */     } 
/*      */     
/*  174 */     return _withObjectAddTailProperty(currentPtr, preferIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ArrayNode _withArray(JsonPointer origPtr, JsonPointer currentPtr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex) {
/*  182 */     if (currentPtr.matches())
/*      */     {
/*  184 */       return null;
/*      */     }
/*      */     
/*  187 */     JsonNode n = _at(currentPtr);
/*      */     
/*  189 */     if (n != null && n instanceof BaseJsonNode) {
/*  190 */       ArrayNode found = ((BaseJsonNode)n)._withArray(origPtr, currentPtr.tail(), overwriteMode, preferIndex);
/*      */       
/*  192 */       if (found != null) {
/*  193 */         return found;
/*      */       }
/*      */       
/*  196 */       _withXxxVerifyReplace(origPtr, currentPtr, overwriteMode, preferIndex, n);
/*      */     } 
/*      */     
/*  199 */     return _withArrayAddTailProperty(currentPtr, preferIndex);
/*      */   }
/*      */ 
/*      */   
/*      */   protected ObjectNode _withObjectAddTailProperty(JsonPointer tail, boolean preferIndex) {
/*  204 */     String propName = tail.getMatchingProperty();
/*  205 */     tail = tail.tail();
/*      */ 
/*      */     
/*  208 */     if (tail.matches()) {
/*  209 */       return putObject(propName);
/*      */     }
/*      */ 
/*      */     
/*  213 */     if (preferIndex && tail.mayMatchElement()) {
/*  214 */       return putArray(propName)._withObjectAddTailElement(tail, preferIndex);
/*      */     }
/*  216 */     return putObject(propName)._withObjectAddTailProperty(tail, preferIndex);
/*      */   }
/*      */ 
/*      */   
/*      */   protected ArrayNode _withArrayAddTailProperty(JsonPointer tail, boolean preferIndex) {
/*  221 */     String propName = tail.getMatchingProperty();
/*  222 */     tail = tail.tail();
/*      */ 
/*      */     
/*  225 */     if (tail.matches()) {
/*  226 */       return putArray(propName);
/*      */     }
/*      */ 
/*      */     
/*  230 */     if (preferIndex && tail.mayMatchElement()) {
/*  231 */       return putArray(propName)._withArrayAddTailElement(tail, preferIndex);
/*      */     }
/*  233 */     return putObject(propName)._withArrayAddTailProperty(tail, preferIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty(SerializerProvider serializers) {
/*  245 */     return this._children.isEmpty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNodeType getNodeType() {
/*  256 */     return JsonNodeType.OBJECT;
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isObject() {
/*  261 */     return true;
/*      */   }
/*      */   public JsonToken asToken() {
/*  264 */     return JsonToken.START_OBJECT;
/*      */   }
/*      */   
/*      */   public int size() {
/*  268 */     return this._children.size();
/*      */   }
/*      */   
/*      */   public boolean isEmpty() {
/*  272 */     return this._children.isEmpty();
/*      */   }
/*      */   
/*      */   public Iterator<JsonNode> elements() {
/*  276 */     return this._children.values().iterator();
/*      */   }
/*      */ 
/*      */   
/*      */   public Iterator<JsonNode> values() {
/*  281 */     return this._children.values().iterator();
/*      */   }
/*      */   
/*      */   public JsonNode get(int index) {
/*  285 */     return null;
/*      */   }
/*      */   
/*      */   public JsonNode get(String propertyName) {
/*  289 */     return this._children.get(propertyName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Optional<JsonNode> optional(String propertyName) {
/*  297 */     return Optional.ofNullable(get(propertyName));
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode path(int index) {
/*  302 */     return MissingNode.getInstance();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode path(String propertyName) {
/*  308 */     JsonNode n = this._children.get(propertyName);
/*  309 */     if (n != null) {
/*  310 */       return n;
/*      */     }
/*  312 */     return MissingNode.getInstance();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode required(String propertyName) {
/*  317 */     JsonNode n = this._children.get(propertyName);
/*  318 */     if (n != null) {
/*  319 */       return n;
/*      */     }
/*  321 */     return (JsonNode)_reportRequiredViolation("No value for property '%s' of `ObjectNode`", new Object[] { propertyName });
/*      */   }
/*      */ 
/*      */   
/*      */   public Iterator<String> fieldNames() {
/*  326 */     return this._children.keySet().iterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Iterator<Map.Entry<String, JsonNode>> fields() {
/*  338 */     return this._children.entrySet().iterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Map.Entry<String, JsonNode>> properties() {
/*  349 */     return this._children.entrySet();
/*      */   }
/*      */ 
/*      */   
/*      */   public Stream<JsonNode> valueStream() {
/*  354 */     return this._children.values().stream();
/*      */   }
/*      */ 
/*      */   
/*      */   public Stream<Map.Entry<String, JsonNode>> propertyStream() {
/*  359 */     return this._children.entrySet().stream();
/*      */   }
/*      */ 
/*      */   
/*      */   public void forEachEntry(BiConsumer<? super String, ? super JsonNode> action) {
/*  364 */     this._children.forEach(action);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Comparator<JsonNode> comparator, JsonNode o) {
/*  370 */     if (!(o instanceof ObjectNode)) {
/*  371 */       return false;
/*      */     }
/*  373 */     ObjectNode other = (ObjectNode)o;
/*  374 */     Map<String, JsonNode> m1 = this._children;
/*  375 */     Map<String, JsonNode> m2 = other._children;
/*      */     
/*  377 */     int len = m1.size();
/*  378 */     if (m2.size() != len) {
/*  379 */       return false;
/*      */     }
/*      */     
/*  382 */     for (Map.Entry<String, JsonNode> entry : m1.entrySet()) {
/*  383 */       JsonNode v2 = m2.get(entry.getKey());
/*  384 */       if (v2 == null || !((JsonNode)entry.getValue()).equals(comparator, v2)) {
/*  385 */         return false;
/*      */       }
/*      */     } 
/*  388 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode findValue(String propertyName) {
/*  400 */     JsonNode jsonNode = this._children.get(propertyName);
/*  401 */     if (jsonNode != null) {
/*  402 */       return jsonNode;
/*      */     }
/*      */     
/*  405 */     for (JsonNode child : this._children.values()) {
/*  406 */       JsonNode value = child.findValue(propertyName);
/*  407 */       if (value != null) {
/*  408 */         return value;
/*      */       }
/*      */     } 
/*  411 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JsonNode> findValues(String propertyName, List<JsonNode> foundSoFar) {
/*  417 */     for (Map.Entry<String, JsonNode> entry : this._children.entrySet()) {
/*  418 */       if (propertyName.equals(entry.getKey())) {
/*  419 */         if (foundSoFar == null) {
/*  420 */           foundSoFar = new ArrayList<>();
/*      */         }
/*  422 */         foundSoFar.add(entry.getValue()); continue;
/*      */       } 
/*  424 */       foundSoFar = ((JsonNode)entry.getValue()).findValues(propertyName, foundSoFar);
/*      */     } 
/*      */     
/*  427 */     return foundSoFar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> findValuesAsText(String propertyName, List<String> foundSoFar) {
/*  433 */     for (Map.Entry<String, JsonNode> entry : this._children.entrySet()) {
/*  434 */       if (propertyName.equals(entry.getKey())) {
/*  435 */         if (foundSoFar == null) {
/*  436 */           foundSoFar = new ArrayList<>();
/*      */         }
/*  438 */         foundSoFar.add(((JsonNode)entry.getValue()).asText()); continue;
/*      */       } 
/*  440 */       foundSoFar = ((JsonNode)entry.getValue()).findValuesAsText(propertyName, foundSoFar);
/*      */     } 
/*      */ 
/*      */     
/*  444 */     return foundSoFar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode findParent(String propertyName) {
/*  450 */     JsonNode jsonNode = this._children.get(propertyName);
/*  451 */     if (jsonNode != null) {
/*  452 */       return this;
/*      */     }
/*  454 */     for (JsonNode child : this._children.values()) {
/*  455 */       JsonNode value = child.findParent(propertyName);
/*  456 */       if (value != null) {
/*  457 */         return (ObjectNode)value;
/*      */       }
/*      */     } 
/*  460 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<JsonNode> findParents(String propertyName, List<JsonNode> foundSoFar) {
/*  466 */     for (Map.Entry<String, JsonNode> entry : this._children.entrySet()) {
/*  467 */       if (propertyName.equals(entry.getKey())) {
/*  468 */         if (foundSoFar == null) {
/*  469 */           foundSoFar = new ArrayList<>();
/*      */         }
/*  471 */         foundSoFar.add(this);
/*      */         continue;
/*      */       } 
/*  474 */       foundSoFar = ((JsonNode)entry.getValue()).findParents(propertyName, foundSoFar);
/*      */     } 
/*      */     
/*  477 */     return foundSoFar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serialize(JsonGenerator g, SerializerProvider provider) throws IOException {
/*  495 */     if (provider != null) {
/*  496 */       boolean trimEmptyArray = !provider.isEnabled(SerializationFeature.WRITE_EMPTY_JSON_ARRAYS);
/*  497 */       boolean skipNulls = !provider.isEnabled((DatatypeFeature)JsonNodeFeature.WRITE_NULL_PROPERTIES);
/*  498 */       if (trimEmptyArray || skipNulls) {
/*  499 */         g.writeStartObject(this);
/*  500 */         serializeFilteredContents(g, provider, trimEmptyArray, skipNulls);
/*  501 */         g.writeEndObject();
/*      */         return;
/*      */       } 
/*      */     } 
/*  505 */     g.writeStartObject(this);
/*  506 */     for (Map.Entry<String, JsonNode> en : _contentsToSerialize(provider).entrySet()) {
/*  507 */       JsonNode value = en.getValue();
/*  508 */       g.writeFieldName(en.getKey());
/*  509 */       value.serialize(g, provider);
/*      */     } 
/*  511 */     g.writeEndObject();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serializeWithType(JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/*  520 */     boolean trimEmptyArray = false;
/*  521 */     boolean skipNulls = false;
/*  522 */     if (provider != null) {
/*  523 */       trimEmptyArray = !provider.isEnabled(SerializationFeature.WRITE_EMPTY_JSON_ARRAYS);
/*  524 */       skipNulls = !provider.isEnabled((DatatypeFeature)JsonNodeFeature.WRITE_NULL_PROPERTIES);
/*      */     } 
/*      */     
/*  527 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/*  528 */         .typeId(this, JsonToken.START_OBJECT));
/*      */     
/*  530 */     if (trimEmptyArray || skipNulls) {
/*  531 */       serializeFilteredContents(g, provider, trimEmptyArray, skipNulls);
/*      */     } else {
/*  533 */       for (Map.Entry<String, JsonNode> en : _contentsToSerialize(provider).entrySet()) {
/*  534 */         JsonNode value = en.getValue();
/*  535 */         g.writeFieldName(en.getKey());
/*  536 */         value.serialize(g, provider);
/*      */       } 
/*      */     } 
/*  539 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void serializeFilteredContents(JsonGenerator g, SerializerProvider ctxt, boolean trimEmptyArray, boolean skipNulls) throws IOException {
/*  552 */     for (Map.Entry<String, JsonNode> en : _contentsToSerialize(ctxt).entrySet()) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  557 */       JsonNode value = en.getValue();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  562 */       if (trimEmptyArray && value.isArray() && value.isEmpty(ctxt)) {
/*      */         continue;
/*      */       }
/*  565 */       if (skipNulls && value.isNull()) {
/*      */         continue;
/*      */       }
/*  568 */       g.writeFieldName(en.getKey());
/*  569 */       value.serialize(g, ctxt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<String, JsonNode> _contentsToSerialize(SerializerProvider ctxt) {
/*  580 */     if (ctxt.isEnabled((DatatypeFeature)JsonNodeFeature.WRITE_PROPERTIES_SORTED) && 
/*  581 */       !this._children.isEmpty() && !(this._children instanceof TreeMap))
/*      */     {
/*      */       
/*  584 */       return new TreeMap<>(this._children);
/*      */     }
/*      */     
/*  587 */     return this._children;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends JsonNode> T set(String propertyName, JsonNode value) {
/*  618 */     if (value == null) {
/*  619 */       value = nullNode();
/*      */     }
/*  621 */     return (T)_put(propertyName, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends JsonNode> T setAll(Map<String, ? extends JsonNode> properties) {
/*  642 */     for (Map.Entry<String, ? extends JsonNode> en : properties.entrySet()) {
/*  643 */       JsonNode n = en.getValue();
/*  644 */       if (n == null) {
/*  645 */         n = nullNode();
/*      */       }
/*  647 */       _put(en.getKey(), n);
/*      */     } 
/*  649 */     return (T)this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends JsonNode> T setAll(ObjectNode other) {
/*  667 */     this._children.putAll(other._children);
/*  668 */     return (T)this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode replace(String propertyName, JsonNode value) {
/*  685 */     if (value == null) {
/*  686 */       value = nullNode();
/*      */     }
/*  688 */     return this._children.put(Objects.requireNonNull(propertyName), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends JsonNode> T without(String propertyName) {
/*  704 */     this._children.remove(propertyName);
/*  705 */     return (T)this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends JsonNode> T without(Collection<String> propertyNames) {
/*  723 */     this._children.keySet().removeAll(propertyNames);
/*  724 */     return (T)this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonNode put(String propertyName, JsonNode value) {
/*  749 */     if (value == null) {
/*  750 */       value = nullNode();
/*      */     }
/*  752 */     return this._children.put(Objects.requireNonNull(propertyName), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode putIfAbsent(String propertyName, JsonNode value) {
/*  780 */     if (value == null) {
/*  781 */       value = nullNode();
/*      */     }
/*  783 */     return this._children.putIfAbsent(Objects.requireNonNull(propertyName), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode remove(String propertyName) {
/*  794 */     return this._children.remove(propertyName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode remove(Collection<String> propertyNames) {
/*  807 */     this._children.keySet().removeAll(propertyNames);
/*  808 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode removeAll() {
/*  820 */     this._children.clear();
/*  821 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public ObjectNode removeIf(Predicate<? super JsonNode> predicate) {
/*  826 */     this._children.values().removeIf(predicate);
/*  827 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonNode putAll(Map<String, ? extends JsonNode> properties) {
/*  842 */     return setAll(properties);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonNode putAll(ObjectNode other) {
/*  857 */     return setAll(other);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode retain(Collection<String> propertyNames) {
/*  870 */     this._children.keySet().retainAll(propertyNames);
/*  871 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode retain(String... propertyNames) {
/*  883 */     return retain(Arrays.asList(propertyNames));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode putArray(String propertyName) {
/*  905 */     ArrayNode n = arrayNode();
/*  906 */     _put(propertyName, n);
/*  907 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode putObject(String propertyName) {
/*  923 */     ObjectNode n = objectNode();
/*  924 */     _put(propertyName, n);
/*  925 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode putPOJO(String propertyName, Object pojo) {
/*  947 */     return _put(propertyName, pojoNode(pojo));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode putRawValue(String propertyName, RawValue raw) {
/*  954 */     return _put(propertyName, rawValueNode(raw));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode putNull(String propertyName) {
/*  966 */     return _put(propertyName, nullNode());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, short v) {
/*  975 */     return _put(propertyName, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, Short v) {
/*  985 */     return _put(propertyName, (v == null) ? nullNode() : 
/*  986 */         numberNode(v.shortValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, int v) {
/*  999 */     return _put(propertyName, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, Integer v) {
/* 1009 */     return _put(propertyName, (v == null) ? nullNode() : 
/* 1010 */         numberNode(v.intValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, long v) {
/* 1023 */     return _put(propertyName, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, Long v) {
/* 1039 */     return _put(propertyName, (v == null) ? nullNode() : 
/* 1040 */         numberNode(v.longValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, float v) {
/* 1049 */     return _put(propertyName, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, Float v) {
/* 1059 */     return _put(propertyName, (v == null) ? nullNode() : 
/* 1060 */         numberNode(v.floatValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, double v) {
/* 1069 */     return _put(propertyName, numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, Double v) {
/* 1079 */     return _put(propertyName, (v == null) ? nullNode() : 
/* 1080 */         numberNode(v.doubleValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, BigDecimal v) {
/* 1089 */     return _put(propertyName, (v == null) ? nullNode() : 
/* 1090 */         numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, BigInteger v) {
/* 1101 */     return _put(propertyName, (v == null) ? nullNode() : 
/* 1102 */         numberNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, String v) {
/* 1111 */     return _put(propertyName, (v == null) ? nullNode() : 
/* 1112 */         textNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, boolean v) {
/* 1121 */     return _put(propertyName, booleanNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, Boolean v) {
/* 1131 */     return _put(propertyName, (v == null) ? nullNode() : 
/* 1132 */         booleanNode(v.booleanValue()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode put(String propertyName, byte[] v) {
/* 1141 */     return _put(propertyName, (v == null) ? nullNode() : 
/* 1142 */         binaryNode(v));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object o) {
/* 1154 */     if (o == this) return true; 
/* 1155 */     if (o == null) return false; 
/* 1156 */     if (o instanceof ObjectNode) {
/* 1157 */       return _childrenEqual((ObjectNode)o);
/*      */     }
/* 1159 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _childrenEqual(ObjectNode other) {
/* 1167 */     return this._children.equals(other._children);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1173 */     return this._children.hashCode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectNode _put(String propertyName, JsonNode value) {
/* 1185 */     this._children.put(Objects.requireNonNull(propertyName), value);
/* 1186 */     return this;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\node\ObjectNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */