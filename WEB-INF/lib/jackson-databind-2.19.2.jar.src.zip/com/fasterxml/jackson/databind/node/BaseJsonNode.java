/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonPointer;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.core.StreamReadConstraints;
/*     */ import com.fasterxml.jackson.core.exc.StreamConstraintsException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.util.ExceptionUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseJsonNode
/*     */   extends JsonNode
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   Object writeReplace() {
/*  32 */     return NodeSerialization.from(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final JsonNode findPath(String fieldName) {
/*  46 */     JsonNode value = findValue(fieldName);
/*  47 */     if (value == null) {
/*  48 */       return MissingNode.getInstance();
/*     */     }
/*  50 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int hashCode();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonNode required(String fieldName) {
/*  64 */     return (JsonNode)_reportRequiredViolation("Node of type `%s` has no fields", new Object[] {
/*  65 */           getClass().getSimpleName()
/*     */         });
/*     */   }
/*     */   
/*     */   public JsonNode required(int index) {
/*  70 */     return (JsonNode)_reportRequiredViolation("Node of type `%s` has no indexed values", new Object[] {
/*  71 */           getClass().getSimpleName()
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParser traverse() {
/*  82 */     return (JsonParser)new TreeTraversingParser(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParser traverse(ObjectCodec codec) {
/*  87 */     return (JsonParser)new TreeTraversingParser(this, codec);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonToken asToken();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParser.NumberType numberType() {
/* 107 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectNode withObject(JsonPointer ptr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex) {
/* 121 */     if (ptr.matches()) {
/* 122 */       if (this instanceof ObjectNode) {
/* 123 */         return (ObjectNode)this;
/*     */       }
/* 125 */       _reportWrongNodeType("Can only call `withObject()` with empty JSON Pointer on `ObjectNode`, not `%s`", new Object[] {
/* 126 */             getClass().getName()
/*     */           });
/*     */     } 
/* 129 */     ObjectNode n = _withObject(ptr, ptr, overwriteMode, preferIndex);
/* 130 */     if (n == null)
/* 131 */       _reportWrongNodeType("Cannot replace context node (of type `%s`) using `withObject()` with  JSON Pointer '%s'", new Object[] {
/* 132 */             getClass().getName(), ptr
/*     */           }); 
/* 134 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectNode _withObject(JsonPointer origPtr, JsonPointer currentPtr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex) {
/* 152 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _withXxxVerifyReplace(JsonPointer origPtr, JsonPointer currentPtr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex, JsonNode toReplace) {
/* 160 */     if (!_withXxxMayReplace(toReplace, overwriteMode)) {
/* 161 */       _reportWrongNodeType("Cannot replace `JsonNode` of type `%s` for property \"%s\" in JSON Pointer \"%s\" (mode `OverwriteMode.%s`)", new Object[] { toReplace
/*     */             
/* 163 */             .getClass().getName(), currentPtr.getMatchingProperty(), origPtr, overwriteMode });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _withXxxMayReplace(JsonNode node, JsonNode.OverwriteMode overwriteMode) {
/* 169 */     switch (overwriteMode) {
/*     */       case NONE:
/* 171 */         return false;
/*     */       case NULLS:
/* 173 */         return node.isNull();
/*     */       case SCALARS:
/* 175 */         return !node.isContainerNode();
/*     */     } 
/*     */     
/* 178 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayNode withArray(JsonPointer ptr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex) {
/* 187 */     if (ptr.matches()) {
/* 188 */       if (this instanceof ArrayNode) {
/* 189 */         return (ArrayNode)this;
/*     */       }
/* 191 */       _reportWrongNodeType("Can only call `withArray()` with empty JSON Pointer on `ArrayNode`, not `%s`", new Object[] {
/* 192 */             getClass().getName()
/*     */           });
/*     */     } 
/* 195 */     ArrayNode n = _withArray(ptr, ptr, overwriteMode, preferIndex);
/* 196 */     if (n == null)
/* 197 */       _reportWrongNodeType("Cannot replace context node (of type `%s`) using `withArray()` with  JSON Pointer '%s'", new Object[] {
/* 198 */             getClass().getName(), ptr
/*     */           }); 
/* 200 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ArrayNode _withArray(JsonPointer origPtr, JsonPointer currentPtr, JsonNode.OverwriteMode overwriteMode, boolean preferIndex) {
/* 209 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void serialize(JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void serializeWithType(JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider, TypeSerializer paramTypeSerializer) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 242 */     return InternalNodeMapper.nodeToString(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toPrettyString() {
/* 247 */     return InternalNodeMapper.nodeToPrettyString(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> T _reportWrongNodeType(String msgTemplate, Object... args) {
/* 261 */     throw new UnsupportedOperationException(String.format(msgTemplate, args));
/*     */   }
/*     */   
/*     */   protected <T> T _reportWrongNodeOperation(String msgTemplate, Object... args) {
/* 265 */     throw new UnsupportedOperationException(String.format(msgTemplate, args));
/*     */   }
/*     */ 
/*     */   
/*     */   protected JsonPointer _jsonPointerIfValid(String exprOrProperty) {
/* 270 */     if (exprOrProperty.isEmpty() || exprOrProperty.charAt(0) == '/') {
/* 271 */       return JsonPointer.compile(exprOrProperty);
/*     */     }
/* 273 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected BigInteger _bigIntFromBigDec(BigDecimal value) {
/*     */     try {
/* 279 */       StreamReadConstraints.defaults().validateBigIntegerScale(value.scale());
/* 280 */     } catch (StreamConstraintsException e) {
/*     */ 
/*     */ 
/*     */       
/* 284 */       ExceptionUtil.throwSneaky((IOException)e);
/*     */     } 
/* 286 */     return value.toBigInteger();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\node\BaseJsonNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */