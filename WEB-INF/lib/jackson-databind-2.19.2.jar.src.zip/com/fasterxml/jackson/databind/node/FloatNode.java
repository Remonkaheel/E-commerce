/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.io.NumberOutput;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FloatNode
/*     */   extends NumericNode
/*     */ {
/*     */   protected final float _value;
/*     */   
/*     */   public FloatNode(float v) {
/*  30 */     this._value = v;
/*     */   } public static FloatNode valueOf(float v) {
/*  32 */     return new FloatNode(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonToken asToken() {
/*  40 */     return JsonToken.VALUE_NUMBER_FLOAT;
/*     */   }
/*     */   public JsonParser.NumberType numberType() {
/*  43 */     return JsonParser.NumberType.FLOAT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFloatingPointNumber() {
/*  52 */     return true;
/*     */   }
/*     */   public boolean isFloat() {
/*  55 */     return true;
/*     */   }
/*     */   public boolean canConvertToInt() {
/*  58 */     return (this._value >= -2.1474836E9F && this._value <= 2.1474836E9F);
/*     */   }
/*     */   
/*     */   public boolean canConvertToLong() {
/*  62 */     return (this._value >= -9.223372E18F && this._value <= 9.223372E18F);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canConvertToExactIntegral() {
/*  67 */     return (!Float.isNaN(this._value) && !Float.isInfinite(this._value) && this._value == 
/*  68 */       Math.round(this._value));
/*     */   }
/*     */ 
/*     */   
/*     */   public Number numberValue() {
/*  73 */     return Float.valueOf(this._value);
/*     */   }
/*     */   
/*     */   public short shortValue() {
/*  77 */     return (short)(int)this._value;
/*     */   }
/*     */   public int intValue() {
/*  80 */     return (int)this._value;
/*     */   }
/*     */   public long longValue() {
/*  83 */     return (long)this._value;
/*     */   }
/*     */   public float floatValue() {
/*  86 */     return this._value;
/*     */   }
/*     */   public double doubleValue() {
/*  89 */     return this._value;
/*     */   }
/*     */   public BigDecimal decimalValue() {
/*  92 */     return BigDecimal.valueOf(this._value);
/*     */   }
/*     */   
/*     */   public BigInteger bigIntegerValue() {
/*  96 */     return decimalValue().toBigInteger();
/*     */   }
/*     */ 
/*     */   
/*     */   public String asText() {
/* 101 */     return NumberOutput.toString(this._value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNaN() {
/* 108 */     return (Float.isNaN(this._value) || Float.isInfinite(this._value));
/*     */   }
/*     */ 
/*     */   
/*     */   public final void serialize(JsonGenerator g, SerializerProvider provider) throws IOException {
/* 113 */     g.writeNumber(this._value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 119 */     if (o == this) return true; 
/* 120 */     if (o == null) return false; 
/* 121 */     if (o instanceof FloatNode) {
/*     */ 
/*     */       
/* 124 */       float otherValue = ((FloatNode)o)._value;
/* 125 */       return (Float.compare(this._value, otherValue) == 0);
/*     */     } 
/* 127 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 132 */     return Float.floatToIntBits(this._value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\node\FloatNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */