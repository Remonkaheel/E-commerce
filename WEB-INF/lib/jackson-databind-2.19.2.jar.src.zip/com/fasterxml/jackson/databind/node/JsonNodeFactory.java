/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.util.RawValue;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonNodeFactory
/*     */   implements Serializable, JsonNodeCreator
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected static final int MAX_ELEMENT_INDEX_FOR_INSERT = 9999;
/*     */   @Deprecated
/*     */   private final boolean _cfgBigDecimalExact;
/*  60 */   public static final JsonNodeFactory instance = new JsonNodeFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonNodeFactory(boolean bigDecimalExact) {
/*  69 */     this._cfgBigDecimalExact = bigDecimalExact;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonNodeFactory() {
/*  79 */     this(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static JsonNodeFactory withExactBigDecimals(boolean bigDecimalExact) {
/*  96 */     return new JsonNodeFactory(bigDecimalExact);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxElementIndexForInsert() {
/* 109 */     return 9999;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean willStripTrailingBigDecimalZeroes() {
/* 118 */     return !this._cfgBigDecimalExact;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BooleanNode booleanNode(boolean v) {
/* 133 */     return v ? BooleanNode.getTrue() : BooleanNode.getFalse();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NullNode nullNode() {
/* 141 */     return NullNode.getInstance();
/*     */   }
/*     */   public JsonNode missingNode() {
/* 144 */     return MissingNode.getInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericNode numberNode(byte v) {
/* 158 */     return IntNode.valueOf(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode numberNode(Byte value) {
/* 168 */     return (value == null) ? nullNode() : IntNode.valueOf(value.intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericNode numberNode(short v) {
/* 176 */     return ShortNode.valueOf(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode numberNode(Short value) {
/* 186 */     return (value == null) ? nullNode() : ShortNode.valueOf(value.shortValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericNode numberNode(int v) {
/* 194 */     return IntNode.valueOf(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode numberNode(Integer value) {
/* 204 */     return (value == null) ? nullNode() : IntNode.valueOf(value.intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericNode numberNode(long v) {
/* 213 */     return LongNode.valueOf(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode numberNode(Long v) {
/* 223 */     if (v == null) {
/* 224 */       return nullNode();
/*     */     }
/* 226 */     return LongNode.valueOf(v.longValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode numberNode(BigInteger v) {
/* 235 */     if (v == null) {
/* 236 */       return nullNode();
/*     */     }
/* 238 */     return BigIntegerNode.valueOf(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericNode numberNode(float v) {
/* 246 */     return FloatNode.valueOf(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode numberNode(Float value) {
/* 256 */     return (value == null) ? nullNode() : FloatNode.valueOf(value.floatValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumericNode numberNode(double v) {
/* 264 */     return DoubleNode.valueOf(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode numberNode(Double value) {
/* 274 */     return (value == null) ? nullNode() : DoubleNode.valueOf(value.doubleValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode numberNode(BigDecimal v) {
/* 290 */     if (v == null) {
/* 291 */       return nullNode();
/*     */     }
/*     */ 
/*     */     
/* 295 */     return DecimalNode.valueOf(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextNode textNode(String text) {
/* 309 */     return TextNode.valueOf(text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BinaryNode binaryNode(byte[] data) {
/* 317 */     return BinaryNode.valueOf(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BinaryNode binaryNode(byte[] data, int offset, int length) {
/* 326 */     return BinaryNode.valueOf(data, offset, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayNode arrayNode() {
/* 339 */     return new ArrayNode(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayNode arrayNode(int capacity) {
/* 347 */     return new ArrayNode(this, capacity);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectNode objectNode() {
/* 353 */     return new ObjectNode(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueNode pojoNode(Object pojo) {
/* 362 */     return new POJONode(pojo);
/*     */   }
/*     */   
/*     */   public ValueNode rawValueNode(RawValue value) {
/* 366 */     return new POJONode(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _inIntRange(long l) {
/* 377 */     int i = (int)l;
/* 378 */     long l2 = i;
/* 379 */     return (l2 == l);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\node\JsonNodeFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */