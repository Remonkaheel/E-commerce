/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Base64Variants;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BinaryNode
/*     */   extends ValueNode
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*  19 */   static final BinaryNode EMPTY_BINARY_NODE = new BinaryNode(new byte[0]);
/*     */   
/*     */   protected final byte[] _data;
/*     */ 
/*     */   
/*     */   public BinaryNode(byte[] data) {
/*  25 */     this._data = data;
/*     */   }
/*     */ 
/*     */   
/*     */   public BinaryNode(byte[] data, int offset, int length) {
/*  30 */     if (offset == 0 && length == data.length) {
/*  31 */       this._data = data;
/*     */     } else {
/*  33 */       this._data = new byte[length];
/*  34 */       System.arraycopy(data, offset, this._data, 0, length);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static BinaryNode valueOf(byte[] data) {
/*  40 */     if (data == null) {
/*  41 */       return null;
/*     */     }
/*  43 */     if (data.length == 0) {
/*  44 */       return EMPTY_BINARY_NODE;
/*     */     }
/*  46 */     return new BinaryNode(data);
/*     */   }
/*     */ 
/*     */   
/*     */   public static BinaryNode valueOf(byte[] data, int offset, int length) {
/*  51 */     if (data == null) {
/*  52 */       return null;
/*     */     }
/*  54 */     if (length == 0) {
/*  55 */       return EMPTY_BINARY_NODE;
/*     */     }
/*  57 */     return new BinaryNode(data, offset, length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonNodeType getNodeType() {
/*  63 */     return JsonNodeType.BINARY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonToken asToken() {
/*  72 */     return JsonToken.VALUE_EMBEDDED_OBJECT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] binaryValue() {
/*  81 */     return this._data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String asText() {
/*  89 */     return Base64Variants.getDefaultVariant().encode(this._data, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void serialize(JsonGenerator g, SerializerProvider provider) throws IOException {
/*  96 */     if (this._data == null) {
/*  97 */       g.writeNull();
/*     */       return;
/*     */     } 
/* 100 */     g.writeBinary(provider.getConfig().getBase64Variant(), this._data, 0, this._data.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 107 */     if (o == this) return true; 
/* 108 */     if (o == null) return false; 
/* 109 */     if (o instanceof BinaryNode) {
/* 110 */       byte[] otherData = ((BinaryNode)o)._data;
/* 111 */       if (this._data == otherData) {
/* 112 */         return true;
/*     */       }
/* 114 */       if (this._data == null || otherData == null) {
/* 115 */         return false;
/*     */       }
/* 117 */       return Arrays.equals(this._data, otherData);
/*     */     } 
/* 119 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 124 */     return (this._data == null) ? -1 : this._data.length;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\node\BinaryNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */