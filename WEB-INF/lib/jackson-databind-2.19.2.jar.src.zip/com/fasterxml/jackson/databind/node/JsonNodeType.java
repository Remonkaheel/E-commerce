/*    */ package com.fasterxml.jackson.databind.node;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum JsonNodeType
/*    */ {
/* 19 */   ARRAY,
/* 20 */   BINARY,
/* 21 */   BOOLEAN,
/* 22 */   MISSING,
/* 23 */   NULL,
/* 24 */   NUMBER,
/* 25 */   OBJECT,
/* 26 */   POJO,
/* 27 */   STRING;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\node\JsonNodeType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */