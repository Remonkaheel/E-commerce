/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.core.StreamReadConstraints;
/*     */ import com.fasterxml.jackson.core.Version;
/*     */ import com.fasterxml.jackson.core.base.ParserMinimalBase;
/*     */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.cfg.PackageVersion;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeTraversingParser
/*     */   extends ParserMinimalBase
/*     */ {
/*     */   protected ObjectCodec _objectCodec;
/*     */   protected NodeCursor _nodeCursor;
/*     */   protected boolean _closed;
/*     */   
/*     */   public TreeTraversingParser(JsonNode n) {
/*  53 */     this(n, (ObjectCodec)null);
/*     */   }
/*     */   
/*     */   public TreeTraversingParser(JsonNode n, ObjectCodec codec) {
/*  57 */     super(StreamReadConstraints.defaults());
/*  58 */     this._objectCodec = codec;
/*  59 */     this._nodeCursor = new NodeCursor.RootCursor(n, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCodec(ObjectCodec c) {
/*  64 */     this._objectCodec = c;
/*     */   }
/*     */ 
/*     */   
/*     */   public ObjectCodec getCodec() {
/*  69 */     return this._objectCodec;
/*     */   }
/*     */ 
/*     */   
/*     */   public Version version() {
/*  74 */     return PackageVersion.VERSION;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JacksonFeatureSet<StreamReadCapability> getReadCapabilities() {
/*  80 */     return DEFAULT_READ_CAPABILITIES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  92 */     if (!this._closed) {
/*  93 */       this._closed = true;
/*  94 */       this._nodeCursor = null;
/*  95 */       _updateTokenToNull();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonToken nextToken() throws IOException {
/* 108 */     _nullSafeUpdateToken(this._nodeCursor.nextToken());
/* 109 */     if (this._currToken == null) {
/* 110 */       this._closed = true;
/* 111 */       return null;
/*     */     } 
/* 113 */     switch (this._currToken) {
/*     */       case START_OBJECT:
/* 115 */         this._nodeCursor = this._nodeCursor.startObject();
/*     */         break;
/*     */       case START_ARRAY:
/* 118 */         this._nodeCursor = this._nodeCursor.startArray();
/*     */         break;
/*     */       case END_OBJECT:
/*     */       case END_ARRAY:
/* 122 */         this._nodeCursor = this._nodeCursor.getParent();
/*     */         break;
/*     */     } 
/* 125 */     return this._currToken;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParser skipChildren() throws IOException {
/* 134 */     if (this._currToken == JsonToken.START_OBJECT) {
/* 135 */       this._nodeCursor = this._nodeCursor.getParent();
/* 136 */       _updateToken(JsonToken.END_OBJECT);
/* 137 */     } else if (this._currToken == JsonToken.START_ARRAY) {
/* 138 */       this._nodeCursor = this._nodeCursor.getParent();
/* 139 */       _updateToken(JsonToken.END_ARRAY);
/*     */     } 
/* 141 */     return (JsonParser)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 146 */     return this._closed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String currentName() {
/* 157 */     NodeCursor crsr = this._nodeCursor;
/* 158 */     if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/* 159 */       crsr = crsr.getParent();
/*     */     }
/* 161 */     return (crsr == null) ? null : crsr.getCurrentName();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public String getCurrentName() {
/* 166 */     return currentName();
/*     */   }
/*     */   public void overrideCurrentName(String name) {
/* 169 */     NodeCursor crsr = this._nodeCursor;
/* 170 */     if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/* 171 */       crsr = crsr.getParent();
/*     */     }
/* 173 */     if (crsr != null) {
/* 174 */       crsr.overrideCurrentName(name);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonStreamContext getParsingContext() {
/* 180 */     return this._nodeCursor;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonLocation currentLocation() {
/* 185 */     return JsonLocation.NA;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonLocation currentTokenLocation() {
/* 190 */     return JsonLocation.NA;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public JsonLocation getTokenLocation() {
/* 195 */     return currentTokenLocation();
/*     */   }
/*     */   @Deprecated
/*     */   public JsonLocation getCurrentLocation() {
/* 199 */     return currentLocation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/*     */     JsonNode n;
/* 210 */     if (this._currToken == null) {
/* 211 */       return null;
/*     */     }
/*     */     
/* 214 */     switch (this._currToken) {
/*     */       case FIELD_NAME:
/* 216 */         return this._nodeCursor.getCurrentName();
/*     */       case VALUE_STRING:
/* 218 */         return currentNode().textValue();
/*     */       case VALUE_NUMBER_INT:
/*     */       case VALUE_NUMBER_FLOAT:
/* 221 */         return String.valueOf(currentNode().numberValue());
/*     */       case VALUE_EMBEDDED_OBJECT:
/* 223 */         n = currentNode();
/* 224 */         if (n != null && n.isBinary())
/*     */         {
/* 226 */           return n.asText(); } 
/*     */         break;
/*     */     } 
/* 229 */     return this._currToken.asString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] getTextCharacters() throws IOException {
/* 235 */     return getText().toCharArray();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTextLength() throws IOException {
/* 240 */     return getText().length();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTextOffset() throws IOException {
/* 245 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasTextCharacters() {
/* 251 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParser.NumberType getNumberType() throws IOException {
/* 264 */     JsonNode n = currentNumericNode();
/* 265 */     return (n == null) ? null : n.numberType();
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParser.NumberTypeFP getNumberTypeFP() throws IOException {
/* 270 */     JsonParser.NumberType nt = getNumberType();
/* 271 */     if (nt == JsonParser.NumberType.BIG_DECIMAL) {
/* 272 */       return JsonParser.NumberTypeFP.BIG_DECIMAL;
/*     */     }
/* 274 */     if (nt == JsonParser.NumberType.DOUBLE) {
/* 275 */       return JsonParser.NumberTypeFP.DOUBLE64;
/*     */     }
/* 277 */     if (nt == JsonParser.NumberType.FLOAT) {
/* 278 */       return JsonParser.NumberTypeFP.FLOAT32;
/*     */     }
/* 280 */     return JsonParser.NumberTypeFP.UNKNOWN;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BigInteger getBigIntegerValue() throws IOException {
/* 286 */     return currentNumericNode().bigIntegerValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public BigDecimal getDecimalValue() throws IOException {
/* 291 */     return currentNumericNode().decimalValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public double getDoubleValue() throws IOException {
/* 296 */     return currentNumericNode().doubleValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFloatValue() throws IOException {
/* 301 */     return (float)currentNumericNode().doubleValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIntValue() throws IOException {
/* 306 */     NumericNode node = (NumericNode)currentNumericNode();
/* 307 */     if (!node.canConvertToInt()) {
/* 308 */       reportOverflowInt();
/*     */     }
/* 310 */     return node.intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLongValue() throws IOException {
/* 315 */     NumericNode node = (NumericNode)currentNumericNode();
/* 316 */     if (!node.canConvertToLong()) {
/* 317 */       reportOverflowLong();
/*     */     }
/* 319 */     return node.longValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public Number getNumberValue() throws IOException {
/* 324 */     return currentNumericNode().numberValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getEmbeddedObject() {
/* 330 */     if (!this._closed) {
/* 331 */       JsonNode n = currentNode();
/* 332 */       if (n != null) {
/* 333 */         if (n.isPojo()) {
/* 334 */           return ((POJONode)n).getPojo();
/*     */         }
/* 336 */         if (n.isBinary()) {
/* 337 */           return ((BinaryNode)n).binaryValue();
/*     */         }
/*     */       } 
/*     */     } 
/* 341 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNaN() {
/* 346 */     if (!this._closed) {
/* 347 */       JsonNode n = currentNode();
/* 348 */       if (n instanceof NumericNode) {
/* 349 */         return ((NumericNode)n).isNaN();
/*     */       }
/*     */     } 
/* 352 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBinaryValue(Base64Variant b64variant) throws IOException {
/* 366 */     JsonNode n = currentNode();
/* 367 */     if (n != null) {
/*     */ 
/*     */       
/* 370 */       if (n instanceof TextNode) {
/* 371 */         return ((TextNode)n).getBinaryValue(b64variant);
/*     */       }
/* 373 */       return n.binaryValue();
/*     */     } 
/*     */     
/* 376 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/* 384 */     byte[] data = getBinaryValue(b64variant);
/* 385 */     if (data != null) {
/* 386 */       out.write(data, 0, data.length);
/* 387 */       return data.length;
/*     */     } 
/* 389 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonNode currentNode() {
/* 399 */     if (this._closed || this._nodeCursor == null) {
/* 400 */       return null;
/*     */     }
/* 402 */     return this._nodeCursor.currentNode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonNode currentNumericNode() throws JacksonException {
/* 408 */     JsonNode n = currentNode();
/* 409 */     if (n == null || !n.isNumber()) {
/* 410 */       JsonToken t = (n == null) ? null : n.asToken();
/* 411 */       throw _constructError("Current token (" + t + ") not numeric, cannot use numeric value accessors");
/*     */     } 
/* 413 */     return n;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _handleEOF() {
/* 418 */     _throwInternal();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\node\TreeTraversingParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */