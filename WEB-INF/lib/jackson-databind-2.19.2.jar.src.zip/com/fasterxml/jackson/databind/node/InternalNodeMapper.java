/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializable;
/*     */ import com.fasterxml.jackson.databind.ObjectReader;
/*     */ import com.fasterxml.jackson.databind.ObjectWriter;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.json.JsonMapper;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class InternalNodeMapper
/*     */ {
/*  21 */   private static final JsonMapper JSON_MAPPER = new JsonMapper();
/*     */   
/*  23 */   private static final ObjectWriter STD_WRITER = JSON_MAPPER.writer();
/*  24 */   private static final ObjectWriter PRETTY_WRITER = JSON_MAPPER.writer()
/*  25 */     .withDefaultPrettyPrinter();
/*     */   
/*  27 */   private static final ObjectReader NODE_READER = JSON_MAPPER.readerFor(JsonNode.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public static String nodeToString(BaseJsonNode n) {
/*     */     try {
/*  33 */       return STD_WRITER.writeValueAsString(_wrapper(n));
/*  34 */     } catch (IOException e) {
/*  35 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String nodeToPrettyString(BaseJsonNode n) {
/*     */     try {
/*  41 */       return PRETTY_WRITER.writeValueAsString(_wrapper(n));
/*  42 */     } catch (IOException e) {
/*  43 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] valueToBytes(Object value) throws IOException {
/*  50 */     return JSON_MAPPER.writeValueAsBytes(value);
/*     */   }
/*     */   
/*     */   public static JsonNode bytesToNode(byte[] json) throws IOException {
/*  54 */     return (JsonNode)NODE_READER.readValue(json);
/*     */   }
/*     */   
/*     */   private static JsonSerializable _wrapper(BaseJsonNode root) {
/*  58 */     return (JsonSerializable)new WrapperForSerializer(root);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class WrapperForSerializer
/*     */     extends JsonSerializable.Base
/*     */   {
/*     */     protected final BaseJsonNode _root;
/*     */ 
/*     */ 
/*     */     
/*     */     protected SerializerProvider _context;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WrapperForSerializer(BaseJsonNode root) {
/*  78 */       this._root = root;
/*     */     }
/*     */ 
/*     */     
/*     */     public void serialize(JsonGenerator g, SerializerProvider ctxt) throws IOException {
/*  83 */       this._context = ctxt;
/*  84 */       _serializeNonRecursive(g, this._root);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void serializeWithType(JsonGenerator g, SerializerProvider ctxt, TypeSerializer typeSer) throws IOException {
/*  92 */       serialize(g, ctxt);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void _serializeNonRecursive(JsonGenerator g, JsonNode node) throws IOException {
/*  97 */       if (node instanceof ObjectNode) {
/*  98 */         g.writeStartObject(this, node.size());
/*  99 */         _serializeNonRecursive(g, new InternalNodeMapper.IteratorStack(), node.properties().iterator());
/* 100 */       } else if (node instanceof ArrayNode) {
/* 101 */         g.writeStartArray(this, node.size());
/* 102 */         _serializeNonRecursive(g, new InternalNodeMapper.IteratorStack(), node.elements());
/*     */       } else {
/* 104 */         node.serialize(g, this._context);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void _serializeNonRecursive(JsonGenerator g, InternalNodeMapper.IteratorStack stack, Iterator<?> rootIterator) throws IOException {
/* 112 */       Iterator<?> currIt = rootIterator;
/*     */       
/*     */       do {
/* 115 */         while (currIt.hasNext()) {
/*     */           JsonNode value;
/*     */ 
/*     */           
/* 119 */           Object elem = currIt.next();
/* 120 */           if (elem instanceof Map.Entry) {
/*     */             
/* 122 */             Map.Entry<String, JsonNode> en = (Map.Entry<String, JsonNode>)elem;
/* 123 */             g.writeFieldName(en.getKey());
/* 124 */             value = en.getValue();
/*     */           } else {
/* 126 */             value = (JsonNode)elem;
/*     */           } 
/* 128 */           if (value instanceof ObjectNode) {
/* 129 */             stack.push(currIt);
/* 130 */             currIt = value.properties().iterator();
/* 131 */             g.writeStartObject(value, value.size()); continue;
/* 132 */           }  if (value instanceof ArrayNode) {
/* 133 */             stack.push(currIt);
/* 134 */             currIt = value.elements();
/* 135 */             g.writeStartArray(value, value.size()); continue;
/* 136 */           }  if (value instanceof POJONode) {
/*     */             
/*     */             try {
/* 139 */               value.serialize(g, this._context);
/* 140 */             } catch (IOException|RuntimeException e) {
/* 141 */               g.writeString(String.format("[ERROR: (%s) %s]", new Object[] { e
/* 142 */                       .getClass().getName(), e.getMessage() }));
/*     */             }  continue;
/*     */           } 
/* 145 */           value.serialize(g, this._context);
/*     */         } 
/*     */         
/* 148 */         if (g.getOutputContext().inArray()) {
/* 149 */           g.writeEndArray();
/*     */         } else {
/* 151 */           g.writeEndObject();
/*     */         } 
/* 153 */         currIt = stack.popOrNull();
/* 154 */       } while (currIt != null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class IteratorStack
/*     */   {
/*     */     private Iterator<?>[] _stack;
/*     */ 
/*     */ 
/*     */     
/*     */     private int _top;
/*     */ 
/*     */     
/*     */     private int _end;
/*     */ 
/*     */ 
/*     */     
/*     */     public void push(Iterator<?> it) {
/* 175 */       if (this._top < this._end) {
/* 176 */         this._stack[this._top++] = it;
/*     */         return;
/*     */       } 
/* 179 */       if (this._stack == null) {
/* 180 */         this._end = 10;
/* 181 */         this._stack = (Iterator<?>[])new Iterator[this._end];
/*     */       } else {
/*     */         
/* 184 */         this._end += Math.min(4000, Math.max(20, this._end >> 1));
/* 185 */         this._stack = (Iterator<?>[])Arrays.<Iterator>copyOf((Iterator[])this._stack, this._end);
/*     */       } 
/* 187 */       this._stack[this._top++] = it;
/*     */     }
/*     */     
/*     */     public Iterator<?> popOrNull() {
/* 191 */       if (this._top == 0) {
/* 192 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 196 */       return this._stack[--this._top];
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\node\InternalNodeMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */