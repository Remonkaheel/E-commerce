/*     */ package com.fasterxml.jackson.databind.node;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonPointer;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.TreeNode;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.util.RawValue;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Stream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ContainerNode<T extends ContainerNode<T>>
/*     */   extends BaseJsonNode
/*     */   implements JsonNodeCreator
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JsonNodeFactory _nodeFactory;
/*     */   
/*     */   protected ContainerNode(JsonNodeFactory nc) {
/*  30 */     this._nodeFactory = nc;
/*     */   }
/*     */   protected ContainerNode() {
/*  33 */     this._nodeFactory = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String asText() {
/*  42 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BooleanNode booleanNode(boolean v) {
/*  75 */     return this._nodeFactory.booleanNode(v);
/*     */   }
/*     */   public JsonNode missingNode() {
/*  78 */     return this._nodeFactory.missingNode();
/*     */   }
/*     */   
/*     */   public final NullNode nullNode() {
/*  82 */     return this._nodeFactory.nullNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ArrayNode arrayNode() {
/*  95 */     return this._nodeFactory.arrayNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ArrayNode arrayNode(int capacity) {
/* 103 */     return this._nodeFactory.arrayNode(capacity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ObjectNode objectNode() {
/* 110 */     return this._nodeFactory.objectNode();
/*     */   }
/*     */   public final NumericNode numberNode(byte v) {
/* 113 */     return this._nodeFactory.numberNode(v);
/*     */   } public final NumericNode numberNode(short v) {
/* 115 */     return this._nodeFactory.numberNode(v);
/*     */   } public final NumericNode numberNode(int v) {
/* 117 */     return this._nodeFactory.numberNode(v);
/*     */   }
/*     */   public final NumericNode numberNode(long v) {
/* 120 */     return this._nodeFactory.numberNode(v);
/*     */   }
/*     */   
/*     */   public final NumericNode numberNode(float v) {
/* 124 */     return this._nodeFactory.numberNode(v);
/*     */   } public final NumericNode numberNode(double v) {
/* 126 */     return this._nodeFactory.numberNode(v);
/*     */   }
/*     */   public final ValueNode numberNode(BigInteger v) {
/* 129 */     return this._nodeFactory.numberNode(v);
/*     */   } public final ValueNode numberNode(BigDecimal v) {
/* 131 */     return this._nodeFactory.numberNode(v);
/*     */   }
/*     */   public final ValueNode numberNode(Byte v) {
/* 134 */     return this._nodeFactory.numberNode(v);
/*     */   } public final ValueNode numberNode(Short v) {
/* 136 */     return this._nodeFactory.numberNode(v);
/*     */   } public final ValueNode numberNode(Integer v) {
/* 138 */     return this._nodeFactory.numberNode(v);
/*     */   } public final ValueNode numberNode(Long v) {
/* 140 */     return this._nodeFactory.numberNode(v);
/*     */   }
/*     */   public final ValueNode numberNode(Float v) {
/* 143 */     return this._nodeFactory.numberNode(v);
/*     */   } public final ValueNode numberNode(Double v) {
/* 145 */     return this._nodeFactory.numberNode(v);
/*     */   }
/*     */   public final TextNode textNode(String text) {
/* 148 */     return this._nodeFactory.textNode(text);
/*     */   }
/*     */   public final BinaryNode binaryNode(byte[] data) {
/* 151 */     return this._nodeFactory.binaryNode(data);
/*     */   } public final BinaryNode binaryNode(byte[] data, int offset, int length) {
/* 153 */     return this._nodeFactory.binaryNode(data, offset, length);
/*     */   }
/*     */   public final ValueNode pojoNode(Object pojo) {
/* 156 */     return this._nodeFactory.pojoNode(pojo);
/*     */   }
/*     */   public final ValueNode rawValueNode(RawValue value) {
/* 159 */     return this._nodeFactory.rawValueNode(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T removeNulls() {
/* 199 */     return removeIf(JsonNode::isNull);
/*     */   }
/*     */   
/*     */   public abstract JsonToken asToken();
/*     */   
/*     */   public abstract int size();
/*     */   
/*     */   public abstract JsonNode get(int paramInt);
/*     */   
/*     */   public abstract JsonNode get(String paramString);
/*     */   
/*     */   public abstract Stream<JsonNode> valueStream();
/*     */   
/*     */   protected abstract ObjectNode _withObject(JsonPointer paramJsonPointer1, JsonPointer paramJsonPointer2, JsonNode.OverwriteMode paramOverwriteMode, boolean paramBoolean);
/*     */   
/*     */   public abstract T removeAll();
/*     */   
/*     */   public abstract T removeIf(Predicate<? super JsonNode> paramPredicate);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\node\ContainerNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */