/*     */ package com.fasterxml.jackson.databind;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.Nulls;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyMetadata
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -1L;
/*  20 */   public static final PropertyMetadata STD_REQUIRED = new PropertyMetadata(Boolean.TRUE, null, null, null, null, null, null);
/*     */ 
/*     */   
/*  23 */   public static final PropertyMetadata STD_OPTIONAL = new PropertyMetadata(Boolean.FALSE, null, null, null, null, null, null);
/*     */ 
/*     */   
/*  26 */   public static final PropertyMetadata STD_REQUIRED_OR_OPTIONAL = new PropertyMetadata(null, null, null, null, null, null, null);
/*     */   
/*     */   protected final Boolean _required;
/*     */   
/*     */   protected final String _description;
/*     */   
/*     */   protected final Integer _index;
/*     */   
/*     */   protected final String _defaultValue;
/*     */   
/*     */   protected final transient MergeInfo _mergeInfo;
/*     */   
/*     */   protected Nulls _valueNulls;
/*     */   
/*     */   protected Nulls _contentNulls;
/*     */   
/*     */   public static final class MergeInfo
/*     */   {
/*     */     public final AnnotatedMember getter;
/*     */     public final boolean fromDefaults;
/*     */     
/*     */     protected MergeInfo(AnnotatedMember getter, boolean fromDefaults) {
/*  48 */       this.getter = getter;
/*  49 */       this.fromDefaults = fromDefaults;
/*     */     }
/*     */     
/*     */     public static MergeInfo createForDefaults(AnnotatedMember getter) {
/*  53 */       return new MergeInfo(getter, true);
/*     */     }
/*     */     
/*     */     public static MergeInfo createForTypeOverride(AnnotatedMember getter) {
/*  57 */       return new MergeInfo(getter, false);
/*     */     }
/*     */     
/*     */     public static MergeInfo createForPropertyOverride(AnnotatedMember getter) {
/*  61 */       return new MergeInfo(getter, false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PropertyMetadata(Boolean req, String desc, Integer index, String def, MergeInfo mergeInfo, Nulls valueNulls, Nulls contentNulls) {
/* 124 */     this._required = req;
/* 125 */     this._description = desc;
/* 126 */     this._index = index;
/* 127 */     this._defaultValue = (def == null || def.isEmpty()) ? null : def;
/* 128 */     this._mergeInfo = mergeInfo;
/* 129 */     this._valueNulls = valueNulls;
/* 130 */     this._contentNulls = contentNulls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyMetadata construct(Boolean req, String desc, Integer index, String defaultValue) {
/* 138 */     if (desc != null || index != null || defaultValue != null) {
/* 139 */       return new PropertyMetadata(req, desc, index, defaultValue, null, null, null);
/*     */     }
/*     */     
/* 142 */     if (req == null) {
/* 143 */       return STD_REQUIRED_OR_OPTIONAL;
/*     */     }
/* 145 */     return req.booleanValue() ? STD_REQUIRED : STD_OPTIONAL;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static PropertyMetadata construct(boolean req, String desc, Integer index, String defaultValue) {
/* 151 */     if (desc != null || index != null || defaultValue != null) {
/* 152 */       return new PropertyMetadata(Boolean.valueOf(req), desc, index, defaultValue, null, null, null);
/*     */     }
/*     */     
/* 155 */     return req ? STD_REQUIRED : STD_OPTIONAL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object readResolve() {
/* 164 */     if (this._description == null && this._index == null && this._defaultValue == null && this._mergeInfo == null && this._valueNulls == null && this._contentNulls == null) {
/*     */ 
/*     */       
/* 167 */       if (this._required == null) {
/* 168 */         return STD_REQUIRED_OR_OPTIONAL;
/*     */       }
/* 170 */       return this._required.booleanValue() ? STD_REQUIRED : STD_OPTIONAL;
/*     */     } 
/* 172 */     return this;
/*     */   }
/*     */   
/*     */   public PropertyMetadata withDescription(String desc) {
/* 176 */     return new PropertyMetadata(this._required, desc, this._index, this._defaultValue, this._mergeInfo, this._valueNulls, this._contentNulls);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyMetadata withMergeInfo(MergeInfo mergeInfo) {
/* 184 */     return new PropertyMetadata(this._required, this._description, this._index, this._defaultValue, mergeInfo, this._valueNulls, this._contentNulls);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyMetadata withNulls(Nulls valueNulls, Nulls contentNulls) {
/* 193 */     return new PropertyMetadata(this._required, this._description, this._index, this._defaultValue, this._mergeInfo, valueNulls, contentNulls);
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyMetadata withDefaultValue(String def) {
/* 198 */     if (def == null || def.isEmpty()) {
/* 199 */       if (this._defaultValue == null) {
/* 200 */         return this;
/*     */       }
/* 202 */       def = null;
/* 203 */     } else if (def.equals(this._defaultValue)) {
/* 204 */       return this;
/*     */     } 
/* 206 */     return new PropertyMetadata(this._required, this._description, this._index, def, this._mergeInfo, this._valueNulls, this._contentNulls);
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyMetadata withIndex(Integer index) {
/* 211 */     return new PropertyMetadata(this._required, this._description, index, this._defaultValue, this._mergeInfo, this._valueNulls, this._contentNulls);
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyMetadata withRequired(Boolean b) {
/* 216 */     if (b == null) {
/* 217 */       if (this._required == null) {
/* 218 */         return this;
/*     */       }
/* 220 */     } else if (b.equals(this._required)) {
/* 221 */       return this;
/*     */     } 
/* 223 */     return new PropertyMetadata(b, this._description, this._index, this._defaultValue, this._mergeInfo, this._valueNulls, this._contentNulls);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 233 */     return this._description;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDefaultValue() {
/* 238 */     return this._defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDefaultValue() {
/* 246 */     return (this._defaultValue != null);
/*     */   } public boolean isRequired() {
/* 248 */     return (this._required != null && this._required.booleanValue());
/*     */   } public Boolean getRequired() {
/* 250 */     return this._required;
/*     */   }
/*     */ 
/*     */   
/*     */   public Integer getIndex() {
/* 255 */     return this._index;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasIndex() {
/* 260 */     return (this._index != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public MergeInfo getMergeInfo() {
/* 265 */     return this._mergeInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public Nulls getValueNulls() {
/* 270 */     return this._valueNulls;
/*     */   }
/*     */ 
/*     */   
/*     */   public Nulls getContentNulls() {
/* 275 */     return this._contentNulls;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\PropertyMetadata.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */