/*     */ package com.fasterxml.jackson.databind;
/*     */ 
/*     */ import com.fasterxml.jackson.core.FormatSchema;
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public class MappingIterator<T> implements Iterator<T>, Closeable {
/*  16 */   protected static final MappingIterator<?> EMPTY_ITERATOR = new MappingIterator(null, null, null, null, false, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int STATE_CLOSED = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int STATE_NEED_RESYNC = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int STATE_MAY_HAVE_VALUE = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int STATE_HAS_VALUE = 3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JavaType _type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final DeserializationContext _context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonDeserializer<T> _deserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonParser _parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonStreamContext _seqContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final T _updatedValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _closeParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _state;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MappingIterator(JavaType type, JsonParser p, DeserializationContext ctxt, JsonDeserializer<?> deser, boolean managedParser, Object valueToUpdate) {
/* 122 */     this._type = type;
/* 123 */     this._parser = p;
/* 124 */     this._context = ctxt;
/* 125 */     this._deserializer = (JsonDeserializer)deser;
/* 126 */     this._closeParser = managedParser;
/* 127 */     if (valueToUpdate == null) {
/* 128 */       this._updatedValue = null;
/*     */     } else {
/* 130 */       this._updatedValue = (T)valueToUpdate;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 143 */     if (p == null) {
/* 144 */       this._seqContext = null;
/* 145 */       this._state = 0;
/*     */     } else {
/* 147 */       JsonStreamContext sctxt = p.getParsingContext();
/* 148 */       if (managedParser && p.isExpectedStartArrayToken()) {
/*     */         
/* 150 */         p.clearCurrentToken();
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 155 */         JsonToken t = p.currentToken();
/* 156 */         if (t == JsonToken.START_OBJECT || t == JsonToken.START_ARRAY) {
/* 157 */           sctxt = sctxt.getParent();
/*     */         }
/*     */       } 
/* 160 */       this._seqContext = sctxt;
/* 161 */       this._state = 2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MappingIterator(MappingIterator<T> src) {
/* 172 */     this(src._type, src._parser, src._context, src._deserializer, src._closeParser, src._updatedValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> MappingIterator<T> emptyIterator() {
/* 183 */     return (MappingIterator)EMPTY_ITERATOR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/*     */     try {
/* 196 */       return hasNextValue();
/* 197 */     } catch (JsonMappingException e) {
/* 198 */       return ((Boolean)_handleMappingException(e)).booleanValue();
/* 199 */     } catch (IOException e) {
/* 200 */       return ((Boolean)_handleIOException(e)).booleanValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T next() {
/*     */     try {
/* 209 */       return nextValue();
/* 210 */     } catch (JsonMappingException e) {
/* 211 */       return _handleMappingException(e);
/* 212 */     } catch (IOException e) {
/* 213 */       return _handleIOException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove() {
/* 219 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 224 */     if (this._state != 0) {
/* 225 */       this._state = 0;
/* 226 */       if (this._parser != null) {
/* 227 */         this._parser.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNextValue() throws IOException {
/*     */     JsonToken t;
/* 244 */     switch (this._state) {
/*     */       case 0:
/* 246 */         return false;
/*     */       case 1:
/* 248 */         _resync();
/*     */       
/*     */       case 2:
/* 251 */         if (this._parser == null) {
/* 252 */           return false;
/*     */         }
/* 254 */         t = this._parser.currentToken();
/* 255 */         if (t == null) {
/* 256 */           t = this._parser.nextToken();
/*     */           
/* 258 */           if (t == null || t == JsonToken.END_ARRAY) {
/* 259 */             this._state = 0;
/* 260 */             if (this._closeParser) {
/* 261 */               this._parser.close();
/*     */             }
/* 263 */             return false;
/*     */           } 
/*     */         } 
/* 266 */         this._state = 3;
/* 267 */         return true;
/*     */     } 
/*     */ 
/*     */     
/* 271 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public T nextValue() throws IOException {
/* 276 */     switch (this._state) {
/*     */       case 0:
/* 278 */         return _throwNoSuchElement();
/*     */       case 1:
/*     */       case 2:
/* 281 */         if (!hasNextValue()) {
/* 282 */           return _throwNoSuchElement();
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 289 */     int nextState = 1;
/*     */     try {
/*     */       T value;
/* 292 */       if (this._updatedValue == null) {
/* 293 */         value = this._deserializer.deserialize(this._parser, this._context);
/*     */       } else {
/* 295 */         this._deserializer.deserialize(this._parser, this._context, this._updatedValue);
/* 296 */         value = this._updatedValue;
/*     */       } 
/* 298 */       nextState = 2;
/* 299 */       return value;
/*     */     } finally {
/* 301 */       this._state = nextState;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 306 */       this._parser.clearCurrentToken();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<T> readAll() throws IOException {
/* 319 */     return readAll(new ArrayList<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <L extends List<? super T>> L readAll(L resultList) throws IOException {
/* 332 */     while (hasNextValue()) {
/* 333 */       resultList.add(nextValue());
/*     */     }
/* 335 */     return resultList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <C extends java.util.Collection<? super T>> C readAll(C results) throws IOException {
/* 346 */     while (hasNextValue()) {
/* 347 */       results.add(nextValue());
/*     */     }
/* 349 */     return results;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParser getParser() {
/* 364 */     return this._parser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormatSchema getParserSchema() {
/* 375 */     return this._parser.getSchema();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonLocation getCurrentLocation() {
/* 389 */     return this._parser.currentLocation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _resync() throws IOException {
/* 400 */     JsonParser p = this._parser;
/*     */     
/* 402 */     if (p.getParsingContext() == this._seqContext) {
/*     */       return;
/*     */     }
/*     */     
/*     */     while (true) {
/* 407 */       JsonToken t = p.nextToken();
/* 408 */       if (t == JsonToken.END_ARRAY || t == JsonToken.END_OBJECT) {
/* 409 */         if (p.getParsingContext() == this._seqContext) {
/* 410 */           p.clearCurrentToken(); return;
/*     */         }  continue;
/*     */       } 
/* 413 */       if (t == JsonToken.START_ARRAY || t == JsonToken.START_OBJECT) {
/* 414 */         p.skipChildren(); continue;
/* 415 */       }  if (t == null) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected <R> R _throwNoSuchElement() {
/* 422 */     throw new NoSuchElementException();
/*     */   }
/*     */   
/*     */   protected <R> R _handleMappingException(JsonMappingException e) {
/* 426 */     throw new RuntimeJsonMappingException(e.getMessage(), e);
/*     */   }
/*     */   
/*     */   protected <R> R _handleIOException(IOException e) {
/* 430 */     throw new RuntimeException(e.getMessage(), e);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\MappingIterator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */