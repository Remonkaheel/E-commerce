/*      */ package com.fasterxml.jackson.databind;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonFormat;
/*      */ import com.fasterxml.jackson.annotation.JsonInclude;
/*      */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeatures;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.exc.InvalidDefinitionException;
/*      */ import com.fasterxml.jackson.databind.exc.InvalidTypeIdException;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*      */ import com.fasterxml.jackson.databind.ser.ResolvableSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.SerializerCache;
/*      */ import com.fasterxml.jackson.databind.ser.SerializerFactory;
/*      */ import com.fasterxml.jackson.databind.ser.impl.FailingSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.ReadOnlyClassToSerializerMap;
/*      */ import com.fasterxml.jackson.databind.ser.impl.TypeWrappedSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.UnknownSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.WritableObjectId;
/*      */ import com.fasterxml.jackson.databind.ser.std.NullSerializer;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*      */ import java.io.IOException;
/*      */ import java.text.DateFormat;
/*      */ import java.util.Date;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class SerializerProvider
/*      */   extends DatabindContext
/*      */ {
/*      */   protected static final boolean CACHE_UNKNOWN_MAPPINGS = false;
/*   66 */   public static final JsonSerializer<Object> DEFAULT_NULL_KEY_SERIALIZER = (JsonSerializer<Object>)new FailingSerializer("Null key for a Map not allowed in JSON (use a converting NullKeySerializer?)");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   78 */   protected static final JsonSerializer<Object> DEFAULT_UNKNOWN_SERIALIZER = (JsonSerializer<Object>)new UnknownSerializer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final SerializationConfig _config;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Class<?> _serializationView;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final SerializerFactory _serializerFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final SerializerCache _serializerCache;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected transient ContextAttributes _attributes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  140 */   protected JsonSerializer<Object> _unknownTypeSerializer = DEFAULT_UNKNOWN_SERIALIZER;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _keySerializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  153 */   protected JsonSerializer<Object> _nullValueSerializer = (JsonSerializer<Object>)NullSerializer.instance;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  162 */   protected JsonSerializer<Object> _nullKeySerializer = DEFAULT_NULL_KEY_SERIALIZER;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ReadOnlyClassToSerializerMap _knownSerializers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DateFormat _dateFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _stdNullValueSerializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SerializerProvider() {
/*  203 */     this._config = null;
/*  204 */     this._serializerFactory = null;
/*  205 */     this._serializerCache = new SerializerCache();
/*      */     
/*  207 */     this._knownSerializers = null;
/*      */     
/*  209 */     this._serializationView = null;
/*  210 */     this._attributes = null;
/*      */ 
/*      */     
/*  213 */     this._stdNullValueSerializer = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SerializerProvider(SerializerProvider src, SerializationConfig config, SerializerFactory f) {
/*  225 */     this._serializerFactory = f;
/*  226 */     this._config = config;
/*      */     
/*  228 */     this._serializerCache = src._serializerCache;
/*  229 */     this._unknownTypeSerializer = src._unknownTypeSerializer;
/*  230 */     this._keySerializer = src._keySerializer;
/*  231 */     this._nullValueSerializer = src._nullValueSerializer;
/*  232 */     this._nullKeySerializer = src._nullKeySerializer;
/*      */     
/*  234 */     this._stdNullValueSerializer = (this._nullValueSerializer == DEFAULT_NULL_KEY_SERIALIZER);
/*      */     
/*  236 */     this._serializationView = config.getActiveView();
/*  237 */     this._attributes = config.getAttributes();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  242 */     this._knownSerializers = this._serializerCache.getReadOnlyLookupMap();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SerializerProvider(SerializerProvider src) {
/*  253 */     this._config = null;
/*  254 */     this._serializationView = null;
/*  255 */     this._serializerFactory = null;
/*  256 */     this._knownSerializers = null;
/*      */ 
/*      */     
/*  259 */     this._serializerCache = new SerializerCache();
/*      */     
/*  261 */     this._unknownTypeSerializer = src._unknownTypeSerializer;
/*  262 */     this._keySerializer = src._keySerializer;
/*  263 */     this._nullValueSerializer = src._nullValueSerializer;
/*  264 */     this._nullKeySerializer = src._nullKeySerializer;
/*      */     
/*  266 */     this._stdNullValueSerializer = src._stdNullValueSerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SerializerProvider(SerializerProvider src, SerializerCache serializerCache) {
/*  275 */     this._serializerCache = serializerCache;
/*      */     
/*  277 */     this._config = src._config;
/*  278 */     this._serializationView = src._serializationView;
/*  279 */     this._serializerFactory = src._serializerFactory;
/*  280 */     this._attributes = src._attributes;
/*      */     
/*  282 */     this._knownSerializers = src._knownSerializers;
/*  283 */     this._unknownTypeSerializer = src._unknownTypeSerializer;
/*      */     
/*  285 */     this._nullValueSerializer = src._nullValueSerializer;
/*  286 */     this._nullKeySerializer = src._nullKeySerializer;
/*  287 */     this._keySerializer = src._keySerializer;
/*  288 */     this._stdNullValueSerializer = src._stdNullValueSerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultKeySerializer(JsonSerializer<Object> ks) {
/*  308 */     if (ks == null) {
/*  309 */       throw new IllegalArgumentException("Cannot pass null JsonSerializer");
/*      */     }
/*  311 */     this._keySerializer = ks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNullValueSerializer(JsonSerializer<Object> nvs) {
/*  325 */     if (nvs == null) {
/*  326 */       throw new IllegalArgumentException("Cannot pass null JsonSerializer");
/*      */     }
/*  328 */     this._nullValueSerializer = nvs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNullKeySerializer(JsonSerializer<Object> nks) {
/*  338 */     if (nks == null) {
/*  339 */       throw new IllegalArgumentException("Cannot pass null JsonSerializer");
/*      */     }
/*  341 */     this._nullKeySerializer = nks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SerializationConfig getConfig() {
/*  354 */     return this._config;
/*      */   }
/*      */   
/*      */   public final AnnotationIntrospector getAnnotationIntrospector() {
/*  358 */     return this._config.getAnnotationIntrospector();
/*      */   }
/*      */ 
/*      */   
/*      */   public final TypeFactory getTypeFactory() {
/*  363 */     return this._config.getTypeFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructSpecializedType(JavaType baseType, Class<?> subclass) throws IllegalArgumentException {
/*  370 */     if (baseType.hasRawClass(subclass)) {
/*  371 */       return baseType;
/*      */     }
/*      */ 
/*      */     
/*  375 */     return getConfig().getTypeFactory().constructSpecializedType(baseType, subclass, true);
/*      */   }
/*      */   
/*      */   public final Class<?> getActiveView() {
/*  379 */     return this._serializationView;
/*      */   }
/*      */   
/*      */   public final boolean canOverrideAccessModifiers() {
/*  383 */     return this._config.canOverrideAccessModifiers();
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(MapperFeature feature) {
/*  388 */     return this._config.isEnabled(feature);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(DatatypeFeature feature) {
/*  393 */     return this._config.isEnabled(feature);
/*      */   }
/*      */ 
/*      */   
/*      */   public final DatatypeFeatures getDatatypeFeatures() {
/*  398 */     return this._config.getDatatypeFeatures();
/*      */   }
/*      */ 
/*      */   
/*      */   public final JsonFormat.Value getDefaultPropertyFormat(Class<?> baseType) {
/*  403 */     return this._config.getDefaultPropertyFormat(baseType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonInclude.Value getDefaultPropertyInclusion(Class<?> baseType) {
/*  410 */     return this._config.getDefaultPropertyInclusion(baseType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Locale getLocale() {
/*  421 */     return this._config.getLocale();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TimeZone getTimeZone() {
/*  432 */     return this._config.getTimeZone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getAttribute(Object key) {
/*  443 */     return this._attributes.getAttribute(key);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public SerializerProvider setAttribute(Object key, Object value) {
/*  449 */     this._attributes = this._attributes.withPerCallAttribute(key, value);
/*  450 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(SerializationFeature feature) {
/*  468 */     return this._config.isEnabled(feature);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean hasSerializationFeatures(int featureMask) {
/*  478 */     return this._config.hasSerializationFeatures(featureMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final FilterProvider getFilterProvider() {
/*  489 */     return this._config.getFilterProvider();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator getGenerator() {
/*  500 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer bufferForValueConversion(ObjectCodec oc) {
/*  518 */     return new TokenBuffer(oc, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final TokenBuffer bufferForValueConversion() {
/*  528 */     return bufferForValueConversion((ObjectCodec)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findValueSerializer(Class<?> valueType, BeanProperty property) throws JsonMappingException {
/*  577 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  578 */     if (ser == null) {
/*      */       
/*  580 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  581 */       if (ser == null) {
/*      */         
/*  583 */         ser = this._serializerCache.untypedValueSerializer(this._config.constructType(valueType));
/*  584 */         if (ser == null) {
/*      */           
/*  586 */           ser = _createAndCacheUntypedSerializer(valueType);
/*      */           
/*  588 */           if (ser == null) {
/*  589 */             ser = getUnknownTypeSerializer(valueType);
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  594 */             return ser;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  600 */     return (JsonSerializer)handleSecondaryContextualization(ser, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findValueSerializer(JavaType valueType, BeanProperty property) throws JsonMappingException {
/*  620 */     if (valueType == null) {
/*  621 */       reportMappingProblem("Null passed for `valueType` of `findValueSerializer()`", new Object[0]);
/*      */     }
/*      */     
/*  624 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  625 */     if (ser == null) {
/*  626 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  627 */       if (ser == null) {
/*  628 */         ser = _createAndCacheUntypedSerializer(valueType);
/*  629 */         if (ser == null) {
/*  630 */           ser = getUnknownTypeSerializer(valueType.getRawClass());
/*      */ 
/*      */ 
/*      */           
/*  634 */           return ser;
/*      */         } 
/*      */       } 
/*      */     } 
/*  638 */     return (JsonSerializer)handleSecondaryContextualization(ser, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findValueSerializer(Class<?> valueType) throws JsonMappingException {
/*  652 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  653 */     if (ser == null) {
/*  654 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  655 */       if (ser == null) {
/*  656 */         ser = this._serializerCache.untypedValueSerializer(this._config.constructType(valueType));
/*  657 */         if (ser == null) {
/*  658 */           ser = _createAndCacheUntypedSerializer(valueType);
/*  659 */           if (ser == null) {
/*  660 */             ser = getUnknownTypeSerializer(valueType);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  668 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findValueSerializer(JavaType valueType) throws JsonMappingException {
/*  683 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  684 */     if (ser == null) {
/*  685 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  686 */       if (ser == null) {
/*  687 */         ser = _createAndCacheUntypedSerializer(valueType);
/*  688 */         if (ser == null) {
/*  689 */           ser = getUnknownTypeSerializer(valueType.getRawClass());
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  696 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findPrimaryPropertySerializer(JavaType valueType, BeanProperty property) throws JsonMappingException {
/*  718 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  719 */     if (ser == null) {
/*  720 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  721 */       if (ser == null) {
/*  722 */         ser = _createAndCacheUntypedSerializer(valueType);
/*  723 */         if (ser == null) {
/*  724 */           ser = getUnknownTypeSerializer(valueType.getRawClass());
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  729 */           return ser;
/*      */         } 
/*      */       } 
/*      */     } 
/*  733 */     return (JsonSerializer)handlePrimaryContextualization(ser, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findPrimaryPropertySerializer(Class<?> valueType, BeanProperty property) throws JsonMappingException {
/*  746 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  747 */     if (ser == null) {
/*  748 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  749 */       if (ser == null) {
/*  750 */         ser = this._serializerCache.untypedValueSerializer(this._config.constructType(valueType));
/*  751 */         if (ser == null) {
/*  752 */           ser = _createAndCacheUntypedSerializer(valueType);
/*  753 */           if (ser == null) {
/*  754 */             ser = getUnknownTypeSerializer(valueType);
/*      */ 
/*      */ 
/*      */             
/*  758 */             return ser;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  763 */     return (JsonSerializer)handlePrimaryContextualization(ser, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findContentValueSerializer(JavaType valueType, BeanProperty property) throws JsonMappingException {
/*  790 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  791 */     if (ser == null) {
/*  792 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  793 */       if (ser == null) {
/*  794 */         ser = _createAndCacheUntypedSerializer(valueType);
/*  795 */         if (ser == null) {
/*  796 */           ser = getUnknownTypeSerializer(valueType.getRawClass());
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  801 */           return ser;
/*      */         } 
/*      */       } 
/*      */     } 
/*  805 */     return (JsonSerializer)handleSecondaryContextualization(ser, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findContentValueSerializer(Class<?> valueType, BeanProperty property) throws JsonMappingException {
/*  818 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(valueType);
/*  819 */     if (ser == null) {
/*  820 */       ser = this._serializerCache.untypedValueSerializer(valueType);
/*  821 */       if (ser == null) {
/*  822 */         ser = this._serializerCache.untypedValueSerializer(this._config.constructType(valueType));
/*  823 */         if (ser == null) {
/*  824 */           ser = _createAndCacheUntypedSerializer(valueType);
/*  825 */           if (ser == null) {
/*  826 */             ser = getUnknownTypeSerializer(valueType);
/*      */ 
/*      */ 
/*      */             
/*  830 */             return ser;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  835 */     return (JsonSerializer)handleSecondaryContextualization(ser, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findTypedValueSerializer(Class<?> valueType, boolean cache, BeanProperty property) throws JsonMappingException {
/*      */     TypeWrappedSerializer typeWrappedSerializer;
/*  858 */     JsonSerializer<Object> ser = this._knownSerializers.typedValueSerializer(valueType);
/*  859 */     if (ser != null) {
/*  860 */       return ser;
/*      */     }
/*      */     
/*  863 */     ser = this._serializerCache.typedValueSerializer(valueType);
/*  864 */     if (ser != null) {
/*  865 */       return ser;
/*      */     }
/*      */ 
/*      */     
/*  869 */     ser = findValueSerializer(valueType, property);
/*  870 */     TypeSerializer typeSer = this._serializerFactory.createTypeSerializer(this._config, this._config
/*  871 */         .constructType(valueType));
/*  872 */     if (typeSer != null) {
/*  873 */       typeSer = typeSer.forProperty(property);
/*  874 */       typeWrappedSerializer = new TypeWrappedSerializer(typeSer, ser);
/*      */     } 
/*  876 */     if (cache) {
/*  877 */       this._serializerCache.addTypedSerializer(valueType, (JsonSerializer)typeWrappedSerializer);
/*      */     }
/*  879 */     return (JsonSerializer<Object>)typeWrappedSerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findTypedValueSerializer(JavaType valueType, boolean cache, BeanProperty property) throws JsonMappingException {
/*      */     TypeWrappedSerializer typeWrappedSerializer;
/*  903 */     JsonSerializer<Object> ser = this._knownSerializers.typedValueSerializer(valueType);
/*  904 */     if (ser != null) {
/*  905 */       return ser;
/*      */     }
/*      */     
/*  908 */     ser = this._serializerCache.typedValueSerializer(valueType);
/*  909 */     if (ser != null) {
/*  910 */       return ser;
/*      */     }
/*      */ 
/*      */     
/*  914 */     ser = findValueSerializer(valueType, property);
/*  915 */     TypeSerializer typeSer = this._serializerFactory.createTypeSerializer(this._config, valueType);
/*  916 */     if (typeSer != null) {
/*  917 */       typeSer = typeSer.forProperty(property);
/*  918 */       typeWrappedSerializer = new TypeWrappedSerializer(typeSer, ser);
/*      */     } 
/*  920 */     if (cache) {
/*  921 */       this._serializerCache.addTypedSerializer(valueType, (JsonSerializer)typeWrappedSerializer);
/*      */     }
/*  923 */     return (JsonSerializer<Object>)typeWrappedSerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeSerializer findTypeSerializer(JavaType javaType) throws JsonMappingException {
/*  934 */     return this._serializerFactory.createTypeSerializer(this._config, javaType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findKeySerializer(JavaType keyType, BeanProperty property) throws JsonMappingException {
/*  950 */     JsonSerializer<Object> ser = this._serializerFactory.createKeySerializer(this, keyType, this._keySerializer);
/*      */     
/*  952 */     return _handleContextualResolvable(ser, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findKeySerializer(Class<?> rawKeyType, BeanProperty property) throws JsonMappingException {
/*  961 */     return findKeySerializer(this._config.constructType(rawKeyType), property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> getDefaultNullKeySerializer() {
/*  974 */     return this._nullKeySerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> getDefaultNullValueSerializer() {
/*  981 */     return this._nullValueSerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findNullKeySerializer(JavaType serializationType, BeanProperty property) throws JsonMappingException {
/* 1001 */     return this._nullKeySerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> findNullValueSerializer(BeanProperty property) throws JsonMappingException {
/* 1017 */     return this._nullValueSerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> getUnknownTypeSerializer(Class<?> unknownType) {
/* 1034 */     if (unknownType == Object.class) {
/* 1035 */       return this._unknownTypeSerializer;
/*      */     }
/*      */     
/* 1038 */     return (JsonSerializer<Object>)new UnknownSerializer(unknownType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUnknownTypeSerializer(JsonSerializer<?> ser) {
/* 1049 */     if (ser == this._unknownTypeSerializer || ser == null) {
/* 1050 */       return true;
/*      */     }
/*      */ 
/*      */     
/* 1054 */     if (isEnabled(SerializationFeature.FAIL_ON_EMPTY_BEANS) && 
/* 1055 */       ser.getClass() == UnknownSerializer.class) {
/* 1056 */       return true;
/*      */     }
/*      */     
/* 1059 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<?> handlePrimaryContextualization(JsonSerializer<?> ser, BeanProperty property) throws JsonMappingException {
/* 1126 */     if (ser != null && 
/* 1127 */       ser instanceof ContextualSerializer) {
/* 1128 */       ser = ((ContextualSerializer)ser).createContextual(this, property);
/*      */     }
/*      */     
/* 1131 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<?> handleSecondaryContextualization(JsonSerializer<?> ser, BeanProperty property) throws JsonMappingException {
/* 1154 */     if (ser != null && 
/* 1155 */       ser instanceof ContextualSerializer) {
/* 1156 */       ser = ((ContextualSerializer)ser).createContextual(this, property);
/*      */     }
/*      */     
/* 1159 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void defaultSerializeValue(Object value, JsonGenerator gen) throws IOException {
/* 1177 */     if (value == null) {
/* 1178 */       if (this._stdNullValueSerializer) {
/* 1179 */         gen.writeNull();
/*      */       } else {
/* 1181 */         this._nullValueSerializer.serialize(null, gen, this);
/*      */       } 
/*      */     } else {
/* 1184 */       Class<?> cls = value.getClass();
/* 1185 */       findTypedValueSerializer(cls, true, (BeanProperty)null).serialize(value, gen, this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void defaultSerializeField(String fieldName, Object value, JsonGenerator gen) throws IOException {
/* 1197 */     gen.writeFieldName(fieldName);
/* 1198 */     if (value == null) {
/*      */ 
/*      */ 
/*      */       
/* 1202 */       if (this._stdNullValueSerializer) {
/* 1203 */         gen.writeNull();
/*      */       } else {
/* 1205 */         this._nullValueSerializer.serialize(null, gen, this);
/*      */       } 
/*      */     } else {
/* 1208 */       Class<?> cls = value.getClass();
/* 1209 */       findTypedValueSerializer(cls, true, (BeanProperty)null).serialize(value, gen, this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void defaultSerializeDateValue(long timestamp, JsonGenerator gen) throws IOException {
/* 1223 */     if (isEnabled(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)) {
/* 1224 */       gen.writeNumber(timestamp);
/*      */     } else {
/* 1226 */       gen.writeString(_dateFormat().format(new Date(timestamp)));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void defaultSerializeDateValue(Date date, JsonGenerator gen) throws IOException {
/* 1239 */     if (isEnabled(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)) {
/* 1240 */       gen.writeNumber(date.getTime());
/*      */     } else {
/* 1242 */       gen.writeString(_dateFormat().format(date));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defaultSerializeDateKey(long timestamp, JsonGenerator gen) throws IOException {
/* 1253 */     if (isEnabled(SerializationFeature.WRITE_DATE_KEYS_AS_TIMESTAMPS)) {
/* 1254 */       gen.writeFieldName(String.valueOf(timestamp));
/*      */     } else {
/* 1256 */       gen.writeFieldName(_dateFormat().format(new Date(timestamp)));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defaultSerializeDateKey(Date date, JsonGenerator gen) throws IOException {
/* 1267 */     if (isEnabled(SerializationFeature.WRITE_DATE_KEYS_AS_TIMESTAMPS)) {
/* 1268 */       gen.writeFieldName(String.valueOf(date.getTime()));
/*      */     } else {
/* 1270 */       gen.writeFieldName(_dateFormat().format(date));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void defaultSerializeNull(JsonGenerator gen) throws IOException {
/* 1276 */     if (this._stdNullValueSerializer) {
/* 1277 */       gen.writeNull();
/*      */     } else {
/* 1279 */       this._nullValueSerializer.serialize(null, gen, this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void flushCachedSerializers() {
/* 1298 */     this._serializerCache.flush();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reportMappingProblem(String message, Object... args) throws JsonMappingException {
/* 1315 */     throw mappingException(message, args);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportBadTypeDefinition(BeanDescription bean, String msg, Object... msgArgs) throws JsonMappingException {
/* 1328 */     String beanDesc = (bean == null) ? "N/A" : ClassUtil.nameOf(bean.getBeanClass());
/* 1329 */     msg = String.format("Invalid type definition for type %s: %s", new Object[] { beanDesc, 
/* 1330 */           _format(msg, msgArgs) });
/* 1331 */     throw InvalidDefinitionException.from(getGenerator(), msg, bean, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportBadPropertyDefinition(BeanDescription bean, BeanPropertyDefinition prop, String message, Object... msgArgs) throws JsonMappingException {
/* 1343 */     message = _format(message, msgArgs);
/* 1344 */     String propName = "N/A";
/* 1345 */     if (prop != null) {
/* 1346 */       propName = _quotedString(prop.getName());
/*      */     }
/* 1348 */     String beanDesc = "N/A";
/* 1349 */     if (bean != null) {
/* 1350 */       beanDesc = ClassUtil.nameOf(bean.getBeanClass());
/*      */     }
/* 1352 */     message = String.format("Invalid definition for property %s (of type %s): %s", new Object[] { propName, beanDesc, message });
/*      */     
/* 1354 */     throw InvalidDefinitionException.from(getGenerator(), message, bean, prop);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T reportBadDefinition(JavaType type, String msg) throws JsonMappingException {
/* 1359 */     throw InvalidDefinitionException.from(getGenerator(), msg, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportBadDefinition(JavaType type, String msg, Throwable cause) throws JsonMappingException {
/* 1367 */     throw InvalidDefinitionException.from(getGenerator(), msg, type)
/* 1368 */       .withCause(cause);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportBadDefinition(Class<?> raw, String msg, Throwable cause) throws JsonMappingException {
/* 1376 */     throw InvalidDefinitionException.from(getGenerator(), msg, constructType(raw))
/* 1377 */       .withCause(cause);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reportMappingProblem(Throwable t, String message, Object... msgArgs) throws JsonMappingException {
/* 1388 */     message = _format(message, msgArgs);
/* 1389 */     throw JsonMappingException.from(getGenerator(), message, t);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException invalidTypeIdException(JavaType baseType, String typeId, String extraDesc) {
/* 1395 */     String msg = String.format("Could not resolve type id '%s' as a subtype of %s", new Object[] { typeId, 
/* 1396 */           ClassUtil.getTypeDescription(baseType) });
/* 1397 */     return (JsonMappingException)InvalidTypeIdException.from(null, _colonConcat(msg, extraDesc), baseType, typeId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonMappingException mappingException(String message, Object... msgArgs) {
/* 1417 */     return JsonMappingException.from(getGenerator(), _format(message, msgArgs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected JsonMappingException mappingException(Throwable t, String message, Object... msgArgs) {
/* 1431 */     return JsonMappingException.from(getGenerator(), _format(message, msgArgs), t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportIncompatibleRootType(Object value, JavaType rootType) throws IOException {
/* 1443 */     if (rootType.isPrimitive()) {
/* 1444 */       Class<?> wrapperType = ClassUtil.wrapperType(rootType.getRawClass());
/*      */       
/* 1446 */       if (wrapperType.isAssignableFrom(value.getClass())) {
/*      */         return;
/*      */       }
/*      */     } 
/* 1450 */     reportBadDefinition(rootType, String.format("Incompatible types: declared root type (%s) vs %s", new Object[] { rootType, 
/*      */             
/* 1452 */             ClassUtil.classNameOf(value) }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _findExplicitUntypedSerializer(Class<?> runtimeType) throws JsonMappingException {
/* 1466 */     JsonSerializer<Object> ser = this._knownSerializers.untypedValueSerializer(runtimeType);
/* 1467 */     if (ser == null) {
/*      */       
/* 1469 */       ser = this._serializerCache.untypedValueSerializer(runtimeType);
/* 1470 */       if (ser == null) {
/* 1471 */         ser = _createAndCacheUntypedSerializer(runtimeType);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1479 */     if (isUnknownTypeSerializer(ser)) {
/* 1480 */       return null;
/*      */     }
/* 1482 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _createAndCacheUntypedSerializer(Class<?> rawType) throws JsonMappingException {
/*      */     JsonSerializer<Object> ser;
/* 1499 */     JavaType fullType = this._config.constructType(rawType);
/*      */     
/*      */     try {
/* 1502 */       ser = _createUntypedSerializer(fullType);
/* 1503 */     } catch (IllegalArgumentException iae) {
/*      */ 
/*      */       
/* 1506 */       reportBadDefinition(fullType, ClassUtil.exceptionMessage(iae));
/* 1507 */       ser = null;
/*      */     } 
/*      */     
/* 1510 */     if (ser != null)
/*      */     {
/* 1512 */       this._serializerCache.addAndResolveNonTypedSerializer(rawType, fullType, ser, this);
/*      */     }
/* 1514 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _createAndCacheUntypedSerializer(JavaType type) throws JsonMappingException {
/*      */     JsonSerializer<Object> ser;
/*      */     try {
/* 1522 */       ser = _createUntypedSerializer(type);
/* 1523 */     } catch (IllegalArgumentException iae) {
/*      */ 
/*      */       
/* 1526 */       ser = null;
/* 1527 */       reportMappingProblem(iae, ClassUtil.exceptionMessage(iae), new Object[0]);
/*      */     } 
/*      */     
/* 1530 */     if (ser != null)
/*      */     {
/* 1532 */       this._serializerCache.addAndResolveNonTypedSerializer(type, ser, this);
/*      */     }
/* 1534 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _createUntypedSerializer(JavaType type) throws JsonMappingException {
/* 1554 */     return this._serializerFactory.createSerializer(this, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _handleContextualResolvable(JsonSerializer<?> ser, BeanProperty property) throws JsonMappingException {
/* 1567 */     if (ser instanceof ResolvableSerializer) {
/* 1568 */       ((ResolvableSerializer)ser).resolve(this);
/*      */     }
/* 1570 */     return (JsonSerializer)handleSecondaryContextualization(ser, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _handleResolvable(JsonSerializer<?> ser) throws JsonMappingException {
/* 1577 */     if (ser instanceof ResolvableSerializer) {
/* 1578 */       ((ResolvableSerializer)ser).resolve(this);
/*      */     }
/* 1580 */     return (JsonSerializer)ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final DateFormat _dateFormat() {
/* 1591 */     if (this._dateFormat != null) {
/* 1592 */       return this._dateFormat;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1598 */     DateFormat df = this._config.getDateFormat();
/* 1599 */     this._dateFormat = df = (DateFormat)df.clone();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1608 */     return df;
/*      */   }
/*      */   
/*      */   public abstract WritableObjectId findObjectId(Object paramObject, ObjectIdGenerator<?> paramObjectIdGenerator);
/*      */   
/*      */   public abstract JsonSerializer<Object> serializerInstance(Annotated paramAnnotated, Object paramObject) throws JsonMappingException;
/*      */   
/*      */   public abstract Object includeFilterInstance(BeanPropertyDefinition paramBeanPropertyDefinition, Class<?> paramClass) throws JsonMappingException;
/*      */   
/*      */   public abstract boolean includeFilterSuppressNulls(Object paramObject) throws JsonMappingException;
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\SerializerProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */