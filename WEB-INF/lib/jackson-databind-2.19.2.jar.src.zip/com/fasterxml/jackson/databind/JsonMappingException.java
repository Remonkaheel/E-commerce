/*     */ package com.fasterxml.jackson.databind;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonIgnore;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonMappingException
/*     */   extends DatabindException
/*     */ {
/*     */   private static final long serialVersionUID = 3L;
/*     */   static final int MAX_REFS_TO_LIST = 1000;
/*     */   protected LinkedList<Reference> _path;
/*     */   protected transient Closeable _processor;
/*     */   
/*     */   public static class Reference
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     protected transient Object _from;
/*     */     protected String _fieldName;
/*  68 */     protected int _index = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected String _desc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Reference() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Reference(Object from) {
/*  85 */       this._from = from;
/*     */     }
/*     */     public Reference(Object from, String fieldName) {
/*  88 */       this._from = from;
/*  89 */       if (fieldName == null) {
/*  90 */         throw new NullPointerException("Cannot pass null fieldName");
/*     */       }
/*  92 */       this._fieldName = fieldName;
/*     */     }
/*     */     
/*     */     public Reference(Object from, int index) {
/*  96 */       this._from = from;
/*  97 */       this._index = index;
/*     */     }
/*     */     
/*     */     void setFieldName(String n) {
/* 101 */       this._fieldName = n;
/* 102 */     } void setIndex(int ix) { this._index = ix; } void setDescription(String d) {
/* 103 */       this._desc = d;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @JsonIgnore
/*     */     public Object getFrom() {
/* 116 */       return this._from;
/*     */     }
/* 118 */     public String getFieldName() { return this._fieldName; } public int getIndex() {
/* 119 */       return this._index;
/*     */     } public String getDescription() {
/* 121 */       if (this._desc == null) {
/* 122 */         StringBuilder sb = new StringBuilder();
/*     */         
/* 124 */         if (this._from == null) {
/* 125 */           sb.append("UNKNOWN");
/*     */         } else {
/* 127 */           Class<?> cls = (this._from instanceof Class) ? (Class)this._from : this._from.getClass();
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 132 */           int arrays = 0;
/* 133 */           while (cls.isArray()) {
/* 134 */             cls = cls.getComponentType();
/* 135 */             arrays++;
/*     */           } 
/* 137 */           sb.append(cls.getName());
/* 138 */           while (--arrays >= 0) {
/* 139 */             sb.append("[]");
/*     */           }
/*     */         } 
/* 142 */         sb.append('[');
/* 143 */         if (this._fieldName != null) {
/* 144 */           sb.append('"');
/* 145 */           sb.append(this._fieldName);
/* 146 */           sb.append('"');
/* 147 */         } else if (this._index >= 0) {
/* 148 */           sb.append(this._index);
/*     */         } else {
/* 150 */           sb.append('?');
/*     */         } 
/* 152 */         sb.append(']');
/* 153 */         this._desc = sb.toString();
/*     */       } 
/* 155 */       return this._desc;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 160 */       return getDescription();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Object writeReplace() {
/* 171 */       getDescription();
/* 172 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonMappingException(String msg) {
/* 208 */     super(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonMappingException(String msg, Throwable rootCause) {
/* 214 */     super(msg, rootCause);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonMappingException(String msg, JsonLocation loc) {
/* 220 */     super(msg, loc);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonMappingException(String msg, JsonLocation loc, Throwable rootCause) {
/* 226 */     super(msg, loc, rootCause);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonMappingException(Closeable processor, String msg) {
/* 232 */     super(msg);
/* 233 */     this._processor = processor;
/* 234 */     if (processor instanceof JsonParser)
/*     */     {
/*     */ 
/*     */       
/* 238 */       this._location = ((JsonParser)processor).currentTokenLocation();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonMappingException(Closeable processor, String msg, Throwable problem) {
/* 246 */     super(msg, problem);
/* 247 */     this._processor = processor;
/*     */     
/* 249 */     if (problem instanceof JacksonException) {
/* 250 */       this._location = ((JacksonException)problem).getLocation();
/* 251 */     } else if (processor instanceof JsonParser) {
/* 252 */       this._location = ((JsonParser)processor).currentTokenLocation();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonMappingException(Closeable processor, String msg, JsonLocation loc) {
/* 260 */     super(msg, loc);
/* 261 */     this._processor = processor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonMappingException from(JsonParser p, String msg) {
/* 268 */     return new JsonMappingException((Closeable)p, msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonMappingException from(JsonParser p, String msg, Throwable problem) {
/* 275 */     return new JsonMappingException((Closeable)p, msg, problem);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonMappingException from(JsonGenerator g, String msg) {
/* 282 */     return new JsonMappingException((Closeable)g, msg, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonMappingException from(JsonGenerator g, String msg, Throwable problem) {
/* 289 */     return new JsonMappingException((Closeable)g, msg, problem);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonMappingException from(DeserializationContext ctxt, String msg) {
/* 296 */     return new JsonMappingException((Closeable)_parser(ctxt), msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonMappingException from(DeserializationContext ctxt, String msg, Throwable t) {
/* 303 */     return new JsonMappingException((Closeable)_parser(ctxt), msg, t);
/*     */   }
/*     */ 
/*     */   
/*     */   private static JsonParser _parser(DeserializationContext ctxt) {
/* 308 */     return (ctxt == null) ? null : ctxt.getParser();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonMappingException from(SerializerProvider ctxt, String msg) {
/* 315 */     return new JsonMappingException((Closeable)_generator(ctxt), msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonMappingException from(SerializerProvider ctxt, String msg, Throwable problem) {
/* 324 */     return new JsonMappingException((Closeable)_generator(ctxt), msg, problem);
/*     */   }
/*     */ 
/*     */   
/*     */   private static JsonGenerator _generator(SerializerProvider ctxt) {
/* 329 */     return (ctxt == null) ? null : ctxt.getGenerator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonMappingException fromUnexpectedIOE(IOException src) {
/* 343 */     return new JsonMappingException(null, 
/* 344 */         String.format("Unexpected IOException (of type %s): %s", new Object[] {
/* 345 */             src.getClass().getName(), 
/* 346 */             ClassUtil.exceptionMessage(src)
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonMappingException wrapWithPath(Throwable src, Object refFrom, String refFieldName) {
/* 359 */     return wrapWithPath(src, new Reference(refFrom, refFieldName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonMappingException wrapWithPath(Throwable src, Object refFrom, int index) {
/* 371 */     return wrapWithPath(src, new Reference(refFrom, index));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonMappingException wrapWithPath(Throwable src, Reference ref) {
/*     */     JsonMappingException jme;
/* 383 */     if (src instanceof JsonMappingException) {
/* 384 */       jme = (JsonMappingException)src;
/*     */     } else {
/*     */       
/* 387 */       String msg = ClassUtil.exceptionMessage(src);
/*     */       
/* 389 */       if (msg == null || msg.isEmpty()) {
/* 390 */         msg = "(was " + src.getClass().getName() + ")";
/*     */       }
/*     */       
/* 393 */       Closeable proc = null;
/* 394 */       if (src instanceof JacksonException) {
/* 395 */         Object proc0 = ((JacksonException)src).getProcessor();
/* 396 */         if (proc0 instanceof Closeable) {
/* 397 */           proc = (Closeable)proc0;
/*     */         }
/*     */       } 
/* 400 */       jme = new JsonMappingException(proc, msg, src);
/*     */     } 
/* 402 */     jme.prependPath(ref);
/* 403 */     return jme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonMappingException withCause(Throwable cause) {
/* 410 */     initCause(cause);
/* 411 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Reference> getPath() {
/* 426 */     if (this._path == null) {
/* 427 */       return Collections.emptyList();
/*     */     }
/* 429 */     return Collections.unmodifiableList(this._path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPathReference() {
/* 438 */     return getPathReference(new StringBuilder()).toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder getPathReference(StringBuilder sb) {
/* 443 */     _appendPathDesc(sb);
/* 444 */     return sb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void prependPath(Object referrer, String fieldName) {
/* 453 */     prependPath(new Reference(referrer, fieldName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void prependPath(Object referrer, int index) {
/* 462 */     prependPath(new Reference(referrer, index));
/*     */   }
/*     */ 
/*     */   
/*     */   public void prependPath(Reference r) {
/* 467 */     if (this._path == null) {
/* 468 */       this._path = new LinkedList<>();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 474 */     if (this._path.size() < 1000) {
/* 475 */       this._path.addFirst(r);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JsonIgnore
/*     */   public Object getProcessor() {
/* 487 */     return this._processor;
/*     */   }
/*     */   
/*     */   public String getLocalizedMessage() {
/* 491 */     return _buildMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 500 */     return _buildMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String _buildMessage() {
/* 506 */     String msg = super.getMessage();
/* 507 */     if (this._path == null) {
/* 508 */       return msg;
/*     */     }
/* 510 */     StringBuilder sb = (msg == null) ? new StringBuilder() : new StringBuilder(msg);
/* 511 */     return _appendReferenceChain(sb).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 517 */     return getClass().getName() + ": " + getMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StringBuilder _appendReferenceChain(StringBuilder sb) {
/* 540 */     sb.append(" (through reference chain: ");
/* 541 */     sb = getPathReference(sb);
/* 542 */     sb.append(')');
/* 543 */     return sb;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _appendPathDesc(StringBuilder sb) {
/* 548 */     if (this._path == null) {
/*     */       return;
/*     */     }
/* 551 */     Iterator<Reference> it = this._path.iterator();
/* 552 */     while (it.hasNext()) {
/* 553 */       sb.append(((Reference)it.next()).toString());
/* 554 */       if (it.hasNext())
/* 555 */         sb.append("->"); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\JsonMappingException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */