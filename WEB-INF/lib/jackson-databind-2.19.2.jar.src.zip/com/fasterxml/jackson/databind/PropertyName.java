/*     */ package com.fasterxml.jackson.databind;
/*     */ 
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import com.fasterxml.jackson.core.io.SerializedString;
/*     */ import com.fasterxml.jackson.core.util.InternCache;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyName
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String _USE_DEFAULT = "";
/*     */   private static final String _NO_NAME = "";
/*  31 */   public static final PropertyName USE_DEFAULT = new PropertyName("", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   public static final PropertyName NO_NAME = new PropertyName(new String(""), null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _simpleName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _namespace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializableString _encodedSimple;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyName(String simpleName) {
/*  63 */     this(simpleName, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyName(String simpleName, String namespace) {
/*  68 */     this._simpleName = ClassUtil.nonNullString(simpleName);
/*  69 */     this._namespace = namespace;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object readResolve() {
/*  74 */     if (this._namespace == null && (
/*  75 */       this._simpleName == null || "".equals(this._simpleName))) {
/*  76 */       return USE_DEFAULT;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyName construct(String simpleName) {
/*  97 */     if (simpleName == null || simpleName.isEmpty()) {
/*  98 */       return USE_DEFAULT;
/*     */     }
/* 100 */     return new PropertyName(InternCache.instance.intern(simpleName), null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static PropertyName construct(String simpleName, String ns) {
/* 105 */     if (simpleName == null) {
/* 106 */       simpleName = "";
/*     */     }
/* 108 */     if (ns == null && simpleName.isEmpty()) {
/* 109 */       return USE_DEFAULT;
/*     */     }
/* 111 */     return new PropertyName(InternCache.instance.intern(simpleName), ns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyName merge(PropertyName name1, PropertyName name2) {
/* 127 */     if (name1 == null) {
/* 128 */       return name2;
/*     */     }
/* 130 */     if (name2 == null) {
/* 131 */       return name1;
/*     */     }
/*     */     
/* 134 */     if (name1 == NO_NAME) {
/* 135 */       return name1;
/*     */     }
/* 137 */     String ns = _nonEmpty(name1._namespace, name2._namespace);
/* 138 */     String simple = _nonEmpty(name1._simpleName, name2._simpleName);
/*     */ 
/*     */     
/* 141 */     if (ns == name1._namespace && simple == name1._simpleName) {
/* 142 */       return name1;
/*     */     }
/* 144 */     if (ns == name2._namespace && simple == name2._simpleName) {
/* 145 */       return name2;
/*     */     }
/* 147 */     return construct(simple, ns);
/*     */   }
/*     */   
/*     */   private static String _nonEmpty(String str1, String str2) {
/* 151 */     if (str1 == null) {
/* 152 */       return str2;
/*     */     }
/* 154 */     if (str2 == null) {
/* 155 */       return str1;
/*     */     }
/* 157 */     if (str1.isEmpty()) {
/* 158 */       return str2;
/*     */     }
/* 160 */     return str1;
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyName internSimpleName() {
/* 165 */     if (this._simpleName.isEmpty()) {
/* 166 */       return this;
/*     */     }
/* 168 */     String interned = InternCache.instance.intern(this._simpleName);
/* 169 */     if (interned == this._simpleName) {
/* 170 */       return this;
/*     */     }
/* 172 */     return new PropertyName(interned, this._namespace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyName withSimpleName(String simpleName) {
/* 181 */     if (simpleName == null) {
/* 182 */       simpleName = "";
/*     */     }
/* 184 */     if (simpleName.equals(this._simpleName)) {
/* 185 */       return this;
/*     */     }
/* 187 */     return new PropertyName(simpleName, this._namespace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyName withNamespace(String ns) {
/* 195 */     if (ns == null) {
/* 196 */       if (this._namespace == null) {
/* 197 */         return this;
/*     */       }
/* 199 */     } else if (ns.equals(this._namespace)) {
/* 200 */       return this;
/*     */     } 
/* 202 */     return new PropertyName(this._simpleName, ns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSimpleName() {
/* 212 */     return this._simpleName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializableString simpleAsEncoded(MapperConfig<?> config) {
/* 222 */     SerializableString sstr = this._encodedSimple;
/* 223 */     if (sstr == null) {
/* 224 */       if (config == null) {
/* 225 */         SerializedString serializedString = new SerializedString(this._simpleName);
/*     */       } else {
/* 227 */         sstr = config.compileString(this._simpleName);
/*     */       } 
/* 229 */       this._encodedSimple = sstr;
/*     */     } 
/* 231 */     return sstr;
/*     */   }
/*     */   
/*     */   public String getNamespace() {
/* 235 */     return this._namespace;
/*     */   }
/*     */   
/*     */   public boolean hasSimpleName() {
/* 239 */     return !this._simpleName.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasSimpleName(String str) {
/* 247 */     return this._simpleName.equals(str);
/*     */   }
/*     */   
/*     */   public boolean hasNamespace() {
/* 251 */     return (this._namespace != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 263 */     return (this._namespace == null && this._simpleName.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 275 */     if (o == this) return true; 
/* 276 */     if (o == null) return false;
/*     */ 
/*     */     
/* 279 */     if (o.getClass() != getClass()) return false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 284 */     PropertyName other = (PropertyName)o;
/* 285 */     if (this._simpleName == null) {
/* 286 */       if (other._simpleName != null) return false; 
/* 287 */     } else if (!this._simpleName.equals(other._simpleName)) {
/* 288 */       return false;
/*     */     } 
/* 290 */     if (this._namespace == null) {
/* 291 */       return (null == other._namespace);
/*     */     }
/* 293 */     return this._namespace.equals(other._namespace);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 298 */     return Objects.hashCode(this._simpleName) * 31 + 
/* 299 */       Objects.hashCode(this._namespace);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 304 */     if (this._namespace == null) {
/* 305 */       return this._simpleName;
/*     */     }
/* 307 */     return "{" + this._namespace + "}" + this._simpleName;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\PropertyName.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */