/*      */ package com.fasterxml.jackson.databind;
/*      */ import com.fasterxml.jackson.core.FormatFeature;
/*      */ import com.fasterxml.jackson.core.FormatSchema;
/*      */ import com.fasterxml.jackson.core.JsonFactory;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.json.JsonReadFeature;
/*      */ import com.fasterxml.jackson.databind.cfg.BaseSettings;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionConfigs;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*      */ import com.fasterxml.jackson.databind.cfg.ConfigOverrides;
/*      */ import com.fasterxml.jackson.databind.cfg.ConstructorDetector;
/*      */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeatures;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfigBase;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*      */ import com.fasterxml.jackson.databind.introspect.ClassIntrospector;
/*      */ import com.fasterxml.jackson.databind.introspect.SimpleMixInResolver;
/*      */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*      */ import com.fasterxml.jackson.databind.jsontype.SubtypeResolver;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*      */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*      */ import com.fasterxml.jackson.databind.type.LogicalType;
/*      */ import com.fasterxml.jackson.databind.util.LinkedNode;
/*      */ import com.fasterxml.jackson.databind.util.RootNameLookup;
/*      */ import java.util.Collection;
/*      */ 
/*      */ public final class DeserializationConfig extends MapperConfigBase<DeserializationFeature, DeserializationConfig> implements Serializable {
/*   33 */   private static final int DESER_FEATURE_DEFAULTS = collectFeatureDefaults(DeserializationFeature.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final long serialVersionUID = 2L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final LinkedNode<DeserializationProblemHandler> _problemHandlers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonNodeFactory _nodeFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final CoercionConfigs _coercionConfigs;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ConstructorDetector _ctorDetector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _deserFeatures;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _parserFeatures;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _parserFeaturesToChange;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _formatReadFeatures;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _formatReadFeaturesToChange;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig(BaseSettings base, SubtypeResolver str, SimpleMixInResolver mixins, RootNameLookup rootNames, ConfigOverrides configOverrides, CoercionConfigs coercionConfigs, DatatypeFeatures datatypeFeatures) {
/*  120 */     super(base, str, mixins, rootNames, configOverrides, datatypeFeatures);
/*  121 */     this._deserFeatures = DESER_FEATURE_DEFAULTS;
/*  122 */     this._problemHandlers = null;
/*  123 */     this._nodeFactory = JsonNodeFactory.instance;
/*  124 */     this._ctorDetector = null;
/*  125 */     this._coercionConfigs = coercionConfigs;
/*  126 */     this._parserFeatures = 0;
/*  127 */     this._parserFeaturesToChange = 0;
/*  128 */     this._formatReadFeatures = 0;
/*  129 */     this._formatReadFeaturesToChange = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeserializationConfig(DeserializationConfig src, SubtypeResolver str, SimpleMixInResolver mixins, RootNameLookup rootNames, ConfigOverrides configOverrides, CoercionConfigs coercionConfigs) {
/*  142 */     super(src, str, mixins, rootNames, configOverrides);
/*  143 */     this._deserFeatures = src._deserFeatures;
/*  144 */     this._problemHandlers = src._problemHandlers;
/*  145 */     this._nodeFactory = src._nodeFactory;
/*  146 */     this._ctorDetector = src._ctorDetector;
/*  147 */     this._coercionConfigs = coercionConfigs;
/*  148 */     this._parserFeatures = src._parserFeatures;
/*  149 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  150 */     this._formatReadFeatures = src._formatReadFeatures;
/*  151 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DeserializationConfig(DeserializationConfig src, long mapperFeatures, int deserFeatures, int parserFeatures, int parserFeatureMask, int formatFeatures, int formatFeatureMask) {
/*  166 */     super(src, mapperFeatures);
/*  167 */     this._deserFeatures = deserFeatures;
/*  168 */     this._problemHandlers = src._problemHandlers;
/*  169 */     this._nodeFactory = src._nodeFactory;
/*  170 */     this._coercionConfigs = src._coercionConfigs;
/*  171 */     this._ctorDetector = src._ctorDetector;
/*  172 */     this._parserFeatures = parserFeatures;
/*  173 */     this._parserFeaturesToChange = parserFeatureMask;
/*  174 */     this._formatReadFeatures = formatFeatures;
/*  175 */     this._formatReadFeaturesToChange = formatFeatureMask;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DeserializationConfig(DeserializationConfig src, SubtypeResolver str) {
/*  184 */     super(src, str);
/*  185 */     this._deserFeatures = src._deserFeatures;
/*  186 */     this._problemHandlers = src._problemHandlers;
/*  187 */     this._nodeFactory = src._nodeFactory;
/*  188 */     this._coercionConfigs = src._coercionConfigs;
/*  189 */     this._ctorDetector = src._ctorDetector;
/*  190 */     this._parserFeatures = src._parserFeatures;
/*  191 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  192 */     this._formatReadFeatures = src._formatReadFeatures;
/*  193 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */   
/*      */   private DeserializationConfig(DeserializationConfig src, BaseSettings base) {
/*  198 */     super(src, base);
/*  199 */     this._deserFeatures = src._deserFeatures;
/*  200 */     this._problemHandlers = src._problemHandlers;
/*  201 */     this._nodeFactory = src._nodeFactory;
/*  202 */     this._coercionConfigs = src._coercionConfigs;
/*  203 */     this._ctorDetector = src._ctorDetector;
/*  204 */     this._parserFeatures = src._parserFeatures;
/*  205 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  206 */     this._formatReadFeatures = src._formatReadFeatures;
/*  207 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */   
/*      */   private DeserializationConfig(DeserializationConfig src, JsonNodeFactory f) {
/*  212 */     super(src);
/*  213 */     this._deserFeatures = src._deserFeatures;
/*  214 */     this._problemHandlers = src._problemHandlers;
/*  215 */     this._nodeFactory = f;
/*  216 */     this._coercionConfigs = src._coercionConfigs;
/*  217 */     this._ctorDetector = src._ctorDetector;
/*  218 */     this._parserFeatures = src._parserFeatures;
/*  219 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  220 */     this._formatReadFeatures = src._formatReadFeatures;
/*  221 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private DeserializationConfig(DeserializationConfig src, ConstructorDetector ctorDetector) {
/*  227 */     super(src);
/*  228 */     this._deserFeatures = src._deserFeatures;
/*  229 */     this._problemHandlers = src._problemHandlers;
/*  230 */     this._nodeFactory = src._nodeFactory;
/*  231 */     this._coercionConfigs = src._coercionConfigs;
/*  232 */     this._ctorDetector = ctorDetector;
/*  233 */     this._parserFeatures = src._parserFeatures;
/*  234 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  235 */     this._formatReadFeatures = src._formatReadFeatures;
/*  236 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private DeserializationConfig(DeserializationConfig src, LinkedNode<DeserializationProblemHandler> problemHandlers) {
/*  242 */     super(src);
/*  243 */     this._deserFeatures = src._deserFeatures;
/*  244 */     this._problemHandlers = problemHandlers;
/*  245 */     this._nodeFactory = src._nodeFactory;
/*  246 */     this._coercionConfigs = src._coercionConfigs;
/*  247 */     this._ctorDetector = src._ctorDetector;
/*  248 */     this._parserFeatures = src._parserFeatures;
/*  249 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  250 */     this._formatReadFeatures = src._formatReadFeatures;
/*  251 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */   
/*      */   private DeserializationConfig(DeserializationConfig src, PropertyName rootName) {
/*  256 */     super(src, rootName);
/*  257 */     this._deserFeatures = src._deserFeatures;
/*  258 */     this._problemHandlers = src._problemHandlers;
/*  259 */     this._nodeFactory = src._nodeFactory;
/*  260 */     this._coercionConfigs = src._coercionConfigs;
/*  261 */     this._ctorDetector = src._ctorDetector;
/*  262 */     this._parserFeatures = src._parserFeatures;
/*  263 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  264 */     this._formatReadFeatures = src._formatReadFeatures;
/*  265 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */   
/*      */   private DeserializationConfig(DeserializationConfig src, Class<?> view) {
/*  270 */     super(src, view);
/*  271 */     this._deserFeatures = src._deserFeatures;
/*  272 */     this._problemHandlers = src._problemHandlers;
/*  273 */     this._nodeFactory = src._nodeFactory;
/*  274 */     this._coercionConfigs = src._coercionConfigs;
/*  275 */     this._ctorDetector = src._ctorDetector;
/*  276 */     this._parserFeatures = src._parserFeatures;
/*  277 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  278 */     this._formatReadFeatures = src._formatReadFeatures;
/*  279 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */   
/*      */   protected DeserializationConfig(DeserializationConfig src, ContextAttributes attrs) {
/*  284 */     super(src, attrs);
/*  285 */     this._deserFeatures = src._deserFeatures;
/*  286 */     this._problemHandlers = src._problemHandlers;
/*  287 */     this._nodeFactory = src._nodeFactory;
/*  288 */     this._coercionConfigs = src._coercionConfigs;
/*  289 */     this._ctorDetector = src._ctorDetector;
/*  290 */     this._parserFeatures = src._parserFeatures;
/*  291 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  292 */     this._formatReadFeatures = src._formatReadFeatures;
/*  293 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */   
/*      */   protected DeserializationConfig(DeserializationConfig src, SimpleMixInResolver mixins) {
/*  298 */     super(src, mixins);
/*  299 */     this._deserFeatures = src._deserFeatures;
/*  300 */     this._problemHandlers = src._problemHandlers;
/*  301 */     this._nodeFactory = src._nodeFactory;
/*  302 */     this._coercionConfigs = src._coercionConfigs;
/*  303 */     this._ctorDetector = src._ctorDetector;
/*  304 */     this._parserFeatures = src._parserFeatures;
/*  305 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  306 */     this._formatReadFeatures = src._formatReadFeatures;
/*  307 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeserializationConfig(DeserializationConfig src, DatatypeFeatures datatypeFeatures) {
/*  316 */     super(src, datatypeFeatures);
/*  317 */     this._deserFeatures = src._deserFeatures;
/*  318 */     this._problemHandlers = src._problemHandlers;
/*  319 */     this._nodeFactory = src._nodeFactory;
/*  320 */     this._coercionConfigs = src._coercionConfigs;
/*  321 */     this._ctorDetector = src._ctorDetector;
/*  322 */     this._parserFeatures = src._parserFeatures;
/*  323 */     this._parserFeaturesToChange = src._parserFeaturesToChange;
/*  324 */     this._formatReadFeatures = src._formatReadFeatures;
/*  325 */     this._formatReadFeaturesToChange = src._formatReadFeaturesToChange;
/*      */   }
/*      */   protected BaseSettings getBaseSettings() {
/*  328 */     return this._base;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final DeserializationConfig _withBase(BaseSettings newBase) {
/*  338 */     return (this._base == newBase) ? this : new DeserializationConfig(this, newBase);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final DeserializationConfig _withMapperFeatures(long mapperFeatures) {
/*  343 */     return new DeserializationConfig(this, mapperFeatures, this._deserFeatures, this._parserFeatures, this._parserFeaturesToChange, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final DeserializationConfig _with(DatatypeFeatures dtFeatures) {
/*  350 */     return new DeserializationConfig(this, dtFeatures);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig with(SubtypeResolver str) {
/*  361 */     return (this._subtypeResolver == str) ? this : new DeserializationConfig(this, str);
/*      */   }
/*      */ 
/*      */   
/*      */   public DeserializationConfig withRootName(PropertyName rootName) {
/*  366 */     if (rootName == null) {
/*  367 */       if (this._rootName == null) {
/*  368 */         return this;
/*      */       }
/*  370 */     } else if (rootName.equals(this._rootName)) {
/*  371 */       return this;
/*      */     } 
/*  373 */     return new DeserializationConfig(this, rootName);
/*      */   }
/*      */ 
/*      */   
/*      */   public DeserializationConfig withView(Class<?> view) {
/*  378 */     return (this._view == view) ? this : new DeserializationConfig(this, view);
/*      */   }
/*      */ 
/*      */   
/*      */   public DeserializationConfig with(ContextAttributes attrs) {
/*  383 */     return (attrs == this._attributes) ? this : new DeserializationConfig(this, attrs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig with(DeserializationFeature feature) {
/*  398 */     int newDeserFeatures = this._deserFeatures | feature.getMask();
/*  399 */     return (newDeserFeatures == this._deserFeatures) ? this : new DeserializationConfig(this, this._mapperFeatures, newDeserFeatures, this._parserFeatures, this._parserFeaturesToChange, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig with(DeserializationFeature first, DeserializationFeature... features) {
/*  412 */     int newDeserFeatures = this._deserFeatures | first.getMask();
/*  413 */     for (DeserializationFeature f : features) {
/*  414 */       newDeserFeatures |= f.getMask();
/*      */     }
/*  416 */     return (newDeserFeatures == this._deserFeatures) ? this : new DeserializationConfig(this, this._mapperFeatures, newDeserFeatures, this._parserFeatures, this._parserFeaturesToChange, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig withFeatures(DeserializationFeature... features) {
/*  428 */     int newDeserFeatures = this._deserFeatures;
/*  429 */     for (DeserializationFeature f : features) {
/*  430 */       newDeserFeatures |= f.getMask();
/*      */     }
/*  432 */     return (newDeserFeatures == this._deserFeatures) ? this : new DeserializationConfig(this, this._mapperFeatures, newDeserFeatures, this._parserFeatures, this._parserFeaturesToChange, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig without(DeserializationFeature feature) {
/*  444 */     int newDeserFeatures = this._deserFeatures & (feature.getMask() ^ 0xFFFFFFFF);
/*  445 */     return (newDeserFeatures == this._deserFeatures) ? this : new DeserializationConfig(this, this._mapperFeatures, newDeserFeatures, this._parserFeatures, this._parserFeaturesToChange, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig without(DeserializationFeature first, DeserializationFeature... features) {
/*  458 */     int newDeserFeatures = this._deserFeatures & (first.getMask() ^ 0xFFFFFFFF);
/*  459 */     for (DeserializationFeature f : features) {
/*  460 */       newDeserFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*      */     }
/*  462 */     return (newDeserFeatures == this._deserFeatures) ? this : new DeserializationConfig(this, this._mapperFeatures, newDeserFeatures, this._parserFeatures, this._parserFeaturesToChange, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig withoutFeatures(DeserializationFeature... features) {
/*  474 */     int newDeserFeatures = this._deserFeatures;
/*  475 */     for (DeserializationFeature f : features) {
/*  476 */       newDeserFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*      */     }
/*  478 */     return (newDeserFeatures == this._deserFeatures) ? this : new DeserializationConfig(this, this._mapperFeatures, newDeserFeatures, this._parserFeatures, this._parserFeaturesToChange, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig with(JsonParser.Feature feature) {
/*  498 */     int newSet = this._parserFeatures | feature.getMask();
/*  499 */     int newMask = this._parserFeaturesToChange | feature.getMask();
/*  500 */     return (this._parserFeatures == newSet && this._parserFeaturesToChange == newMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, newSet, newMask, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig withFeatures(JsonParser.Feature... features) {
/*  514 */     int newSet = this._parserFeatures;
/*  515 */     int newMask = this._parserFeaturesToChange;
/*  516 */     for (JsonParser.Feature f : features) {
/*  517 */       int mask = f.getMask();
/*  518 */       newSet |= mask;
/*  519 */       newMask |= mask;
/*      */     } 
/*  521 */     return (this._parserFeatures == newSet && this._parserFeaturesToChange == newMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, newSet, newMask, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig without(JsonParser.Feature feature) {
/*  535 */     int newSet = this._parserFeatures & (feature.getMask() ^ 0xFFFFFFFF);
/*  536 */     int newMask = this._parserFeaturesToChange | feature.getMask();
/*  537 */     return (this._parserFeatures == newSet && this._parserFeaturesToChange == newMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, newSet, newMask, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig withoutFeatures(JsonParser.Feature... features) {
/*  551 */     int newSet = this._parserFeatures;
/*  552 */     int newMask = this._parserFeaturesToChange;
/*  553 */     for (JsonParser.Feature f : features) {
/*  554 */       int mask = f.getMask();
/*  555 */       newSet &= mask ^ 0xFFFFFFFF;
/*  556 */       newMask |= mask;
/*      */     } 
/*  558 */     return (this._parserFeatures == newSet && this._parserFeaturesToChange == newMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, newSet, newMask, this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig with(FormatFeature feature) {
/*  579 */     if (feature instanceof JsonReadFeature) {
/*  580 */       return _withJsonReadFeatures(new FormatFeature[] { feature });
/*      */     }
/*  582 */     int newSet = this._formatReadFeatures | feature.getMask();
/*  583 */     int newMask = this._formatReadFeaturesToChange | feature.getMask();
/*  584 */     return (this._formatReadFeatures == newSet && this._formatReadFeaturesToChange == newMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, this._parserFeatures, this._parserFeaturesToChange, newSet, newMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig withFeatures(FormatFeature... features) {
/*  599 */     if (features.length > 0 && features[0] instanceof JsonReadFeature) {
/*  600 */       return _withJsonReadFeatures(features);
/*      */     }
/*  602 */     int newSet = this._formatReadFeatures;
/*  603 */     int newMask = this._formatReadFeaturesToChange;
/*  604 */     for (FormatFeature f : features) {
/*  605 */       int mask = f.getMask();
/*  606 */       newSet |= mask;
/*  607 */       newMask |= mask;
/*      */     } 
/*  609 */     return (this._formatReadFeatures == newSet && this._formatReadFeaturesToChange == newMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, this._parserFeatures, this._parserFeaturesToChange, newSet, newMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig without(FormatFeature feature) {
/*  624 */     if (feature instanceof JsonReadFeature) {
/*  625 */       return _withoutJsonReadFeatures(new FormatFeature[] { feature });
/*      */     }
/*  627 */     int newSet = this._formatReadFeatures & (feature.getMask() ^ 0xFFFFFFFF);
/*  628 */     int newMask = this._formatReadFeaturesToChange | feature.getMask();
/*  629 */     return (this._formatReadFeatures == newSet && this._formatReadFeaturesToChange == newMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, this._parserFeatures, this._parserFeaturesToChange, newSet, newMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig withoutFeatures(FormatFeature... features) {
/*  644 */     if (features.length > 0 && features[0] instanceof JsonReadFeature) {
/*  645 */       return _withoutJsonReadFeatures(features);
/*      */     }
/*  647 */     int newSet = this._formatReadFeatures;
/*  648 */     int newMask = this._formatReadFeaturesToChange;
/*  649 */     for (FormatFeature f : features) {
/*  650 */       int mask = f.getMask();
/*  651 */       newSet &= mask ^ 0xFFFFFFFF;
/*  652 */       newMask |= mask;
/*      */     } 
/*  654 */     return (this._formatReadFeatures == newSet && this._formatReadFeaturesToChange == newMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, this._parserFeatures, this._parserFeaturesToChange, newSet, newMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DeserializationConfig _withJsonReadFeatures(FormatFeature... features) {
/*  662 */     int parserSet = this._parserFeatures;
/*  663 */     int parserMask = this._parserFeaturesToChange;
/*  664 */     int newSet = this._formatReadFeatures;
/*  665 */     int newMask = this._formatReadFeaturesToChange;
/*  666 */     for (FormatFeature f : features) {
/*  667 */       int mask = f.getMask();
/*  668 */       newSet |= mask;
/*  669 */       newMask |= mask;
/*      */       
/*  671 */       if (f instanceof JsonReadFeature) {
/*  672 */         JsonParser.Feature oldF = ((JsonReadFeature)f).mappedFeature();
/*  673 */         if (oldF != null) {
/*  674 */           int pmask = oldF.getMask();
/*  675 */           parserSet |= pmask;
/*  676 */           parserMask |= pmask;
/*      */         } 
/*      */       } 
/*      */     } 
/*  680 */     return (this._formatReadFeatures == newSet && this._formatReadFeaturesToChange == newMask && this._parserFeatures == parserSet && this._parserFeaturesToChange == parserMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, parserSet, parserMask, newSet, newMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DeserializationConfig _withoutJsonReadFeatures(FormatFeature... features) {
/*  689 */     int parserSet = this._parserFeatures;
/*  690 */     int parserMask = this._parserFeaturesToChange;
/*  691 */     int newSet = this._formatReadFeatures;
/*  692 */     int newMask = this._formatReadFeaturesToChange;
/*  693 */     for (FormatFeature f : features) {
/*  694 */       int mask = f.getMask();
/*  695 */       newSet &= mask ^ 0xFFFFFFFF;
/*  696 */       newMask |= mask;
/*      */       
/*  698 */       if (f instanceof JsonReadFeature) {
/*  699 */         JsonParser.Feature oldF = ((JsonReadFeature)f).mappedFeature();
/*  700 */         if (oldF != null) {
/*  701 */           int pmask = oldF.getMask();
/*  702 */           parserSet &= pmask ^ 0xFFFFFFFF;
/*  703 */           parserMask |= pmask;
/*      */         } 
/*      */       } 
/*      */     } 
/*  707 */     return (this._formatReadFeatures == newSet && this._formatReadFeaturesToChange == newMask && this._parserFeatures == parserSet && this._parserFeaturesToChange == parserMask) ? this : new DeserializationConfig(this, this._mapperFeatures, this._deserFeatures, parserSet, parserMask, newSet, newMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig with(JsonNodeFactory f) {
/*  725 */     if (this._nodeFactory == f) {
/*  726 */       return this;
/*      */     }
/*  728 */     return new DeserializationConfig(this, f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig with(ConstructorDetector ctorDetector) {
/*  735 */     if (this._ctorDetector == ctorDetector) {
/*  736 */       return this;
/*      */     }
/*  738 */     return new DeserializationConfig(this, ctorDetector);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig withHandler(DeserializationProblemHandler h) {
/*  748 */     if (LinkedNode.contains(this._problemHandlers, h)) {
/*  749 */       return this;
/*      */     }
/*  751 */     return new DeserializationConfig(this, new LinkedNode(h, this._problemHandlers));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig withNoProblemHandlers() {
/*  760 */     if (this._problemHandlers == null) {
/*  761 */       return this;
/*      */     }
/*  763 */     return new DeserializationConfig(this, (LinkedNode<DeserializationProblemHandler>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser initialize(JsonParser p) {
/*  781 */     if (this._parserFeaturesToChange != 0) {
/*  782 */       p.overrideStdFeatures(this._parserFeatures, this._parserFeaturesToChange);
/*      */     }
/*  784 */     if (this._formatReadFeaturesToChange != 0) {
/*  785 */       p.overrideFormatFeatures(this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */     }
/*  787 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser initialize(JsonParser p, FormatSchema schema) {
/*  794 */     if (this._parserFeaturesToChange != 0) {
/*  795 */       p.overrideStdFeatures(this._parserFeatures, this._parserFeaturesToChange);
/*      */     }
/*  797 */     if (this._formatReadFeaturesToChange != 0) {
/*  798 */       p.overrideFormatFeatures(this._formatReadFeatures, this._formatReadFeaturesToChange);
/*      */     }
/*  800 */     if (schema != null) {
/*  801 */       p.setSchema(schema);
/*      */     }
/*  803 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean useRootWrapping() {
/*  815 */     if (this._rootName != null) {
/*  816 */       return !this._rootName.isEmpty();
/*      */     }
/*  818 */     return isEnabled(DeserializationFeature.UNWRAP_ROOT_VALUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(DeserializationFeature feature) {
/*  830 */     return ((this._deserFeatures & feature.getMask()) != 0);
/*      */   }
/*      */   
/*      */   public final boolean isEnabled(JsonParser.Feature f, JsonFactory factory) {
/*  834 */     int mask = f.getMask();
/*  835 */     if ((this._parserFeaturesToChange & mask) != 0) {
/*  836 */       return ((this._parserFeatures & f.getMask()) != 0);
/*      */     }
/*  838 */     return factory.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean hasDeserializationFeatures(int featureMask) {
/*  848 */     return ((this._deserFeatures & featureMask) == featureMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean hasSomeOfFeatures(int featureMask) {
/*  858 */     return ((this._deserFeatures & featureMask) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getDeserializationFeatures() {
/*  866 */     return this._deserFeatures;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean requiresFullValue() {
/*  878 */     return DeserializationFeature.FAIL_ON_TRAILING_TOKENS.enabledIn(this._deserFeatures);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(DatatypeFeature feature) {
/*  893 */     return this._datatypeFeatures.isEnabled(feature);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LinkedNode<DeserializationProblemHandler> getProblemHandlers() {
/*  907 */     return this._problemHandlers;
/*      */   }
/*      */   
/*      */   public final JsonNodeFactory getNodeFactory() {
/*  911 */     return this._nodeFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConstructorDetector getConstructorDetector() {
/*  919 */     if (this._ctorDetector == null) {
/*  920 */       return ConstructorDetector.DEFAULT;
/*      */     }
/*  922 */     return this._ctorDetector;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDescription introspect(JavaType type) {
/*  938 */     return getClassIntrospector().forDeserialization(this, type, (ClassIntrospector.MixInResolver)this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDescription introspectForCreation(JavaType type) {
/*  946 */     return getClassIntrospector().forCreation(this, type, (ClassIntrospector.MixInResolver)this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDescription introspectForBuilder(JavaType builderType, BeanDescription valueTypeDesc) {
/*  953 */     return getClassIntrospector().forDeserializationWithBuilder(this, builderType, (ClassIntrospector.MixInResolver)this, valueTypeDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeDeserializer findTypeDeserializer(JavaType baseType) throws JsonMappingException {
/*  973 */     BeanDescription bean = introspectClassAnnotations(baseType.getRawClass());
/*  974 */     AnnotatedClass ac = bean.getClassInfo();
/*  975 */     TypeResolverBuilder<?> b = getAnnotationIntrospector().findTypeResolver((MapperConfig<?>)this, ac, baseType);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  980 */     Collection<NamedType> subtypes = null;
/*  981 */     if (b == null) {
/*  982 */       b = getDefaultTyper(baseType);
/*  983 */       if (b == null) {
/*  984 */         return null;
/*      */       }
/*      */     } else {
/*  987 */       subtypes = getSubtypeResolver().collectAndResolveSubtypesByTypeId((MapperConfig)this, ac);
/*      */     } 
/*  989 */     return b.buildTypeDeserializer(this, baseType, subtypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CoercionAction findCoercionAction(LogicalType targetType, Class<?> targetClass, CoercionInputShape inputShape) {
/* 1013 */     return this._coercionConfigs.findCoercion(this, targetType, targetClass, inputShape);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CoercionAction findCoercionFromBlankString(LogicalType targetType, Class<?> targetClass, CoercionAction actionIfBlankNotAllowed) {
/* 1037 */     return this._coercionConfigs.findCoercionFromBlankString(this, targetType, targetClass, actionIfBlankNotAllowed);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\DeserializationConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */