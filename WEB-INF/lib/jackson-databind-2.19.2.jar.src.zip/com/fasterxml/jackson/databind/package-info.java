package com.fasterxml.jackson.databind;


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */