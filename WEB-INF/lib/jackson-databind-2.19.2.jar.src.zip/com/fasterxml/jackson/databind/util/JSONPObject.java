/*     */ package com.fasterxml.jackson.databind.util;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonpCharacterEscapes;
/*     */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonSerializable;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONPObject
/*     */   implements JsonSerializable
/*     */ {
/*     */   protected final String _function;
/*     */   protected final Object _value;
/*     */   protected final JavaType _serializationType;
/*     */   
/*     */   public JSONPObject(String function, Object value) {
/*  38 */     this(function, value, (JavaType)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public JSONPObject(String function, Object value, JavaType asType) {
/*  43 */     this._function = function;
/*  44 */     this._value = value;
/*  45 */     this._serializationType = asType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeWithType(JsonGenerator gen, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/*  59 */     serialize(gen, provider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(JsonGenerator gen, SerializerProvider provider) throws IOException {
/*  67 */     gen.writeRaw(this._function);
/*  68 */     gen.writeRaw('(');
/*     */     
/*  70 */     if (this._value == null) {
/*  71 */       provider.defaultSerializeNull(gen);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  76 */       boolean override = (gen.getCharacterEscapes() == null);
/*  77 */       if (override) {
/*  78 */         gen.setCharacterEscapes((CharacterEscapes)JsonpCharacterEscapes.instance());
/*     */       }
/*     */       
/*     */       try {
/*  82 */         if (this._serializationType != null) {
/*  83 */           provider.findTypedValueSerializer(this._serializationType, true, null).serialize(this._value, gen, provider);
/*     */         } else {
/*  85 */           provider.findTypedValueSerializer(this._value.getClass(), true, null).serialize(this._value, gen, provider);
/*     */         } 
/*     */       } finally {
/*  88 */         if (override) {
/*  89 */           gen.setCharacterEscapes(null);
/*     */         }
/*     */       } 
/*     */     } 
/*  93 */     gen.writeRaw(')');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFunction() {
/* 102 */     return this._function;
/* 103 */   } public Object getValue() { return this._value; } public JavaType getSerializationType() {
/* 104 */     return this._serializationType;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\JSONPObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */