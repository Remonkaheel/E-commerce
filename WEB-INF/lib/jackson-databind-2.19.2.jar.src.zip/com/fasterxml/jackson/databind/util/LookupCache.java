/*    */ package com.fasterxml.jackson.databind.util;
/*    */ 
/*    */ import java.util.function.BiConsumer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface LookupCache<K, V>
/*    */ {
/*    */   default void contents(BiConsumer<K, V> consumer) {
/* 29 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default LookupCache<K, V> emptyCopy() {
/* 43 */     throw new UnsupportedOperationException("LookupCache implementation " + 
/* 44 */         getClass().getName() + " does not implement `emptyCopy()`");
/*    */   }
/*    */   
/*    */   int size();
/*    */   
/*    */   V get(Object paramObject);
/*    */   
/*    */   V put(K paramK, V paramV);
/*    */   
/*    */   V putIfAbsent(K paramK, V paramV);
/*    */   
/*    */   void clear();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\LookupCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */