/*      */ package com.fasterxml.jackson.databind.util;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import java.io.Closeable;
/*      */ import java.io.IOException;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.lang.reflect.AccessibleObject;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Member;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.EnumMap;
/*      */ import java.util.EnumSet;
/*      */ import java.util.List;
/*      */ 
/*      */ public final class ClassUtil {
/*   20 */   private static final Class<?> CLS_OBJECT = Object.class;
/*      */   
/*   22 */   private static final Annotation[] NO_ANNOTATIONS = new Annotation[0];
/*   23 */   private static final Ctor[] NO_CTORS = new Ctor[0];
/*      */   
/*   25 */   private static final Iterator<Object> EMPTY_ITERATOR = Collections.emptyIterator();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Iterator<T> emptyIterator() {
/*   38 */     return (Iterator)EMPTY_ITERATOR;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Stream<T> emptyStream() {
/*   48 */     return Stream.empty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<JavaType> findSuperTypes(JavaType type, Class<?> endBefore, boolean addClassItself) {
/*   73 */     if (type == null || type.hasRawClass(endBefore) || type.hasRawClass(Object.class)) {
/*   74 */       return Collections.emptyList();
/*      */     }
/*   76 */     List<JavaType> result = new ArrayList<>(8);
/*   77 */     _addSuperTypes(type, endBefore, result, addClassItself);
/*   78 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Class<?>> findRawSuperTypes(Class<?> cls, Class<?> endBefore, boolean addClassItself) {
/*   85 */     if (cls == null || cls == endBefore || cls == Object.class) {
/*   86 */       return Collections.emptyList();
/*      */     }
/*   88 */     List<Class<?>> result = new ArrayList<>(8);
/*   89 */     _addRawSuperTypes(cls, endBefore, result, addClassItself);
/*   90 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Class<?>> findSuperClasses(Class<?> cls, Class<?> endBefore, boolean addClassItself) {
/*  105 */     List<Class<?>> result = new ArrayList<>(8);
/*  106 */     if (cls != null && cls != endBefore) {
/*  107 */       if (addClassItself) {
/*  108 */         result.add(cls);
/*      */       }
/*  110 */       while ((cls = cls.getSuperclass()) != null && 
/*  111 */         cls != endBefore)
/*      */       {
/*      */         
/*  114 */         result.add(cls);
/*      */       }
/*      */     } 
/*  117 */     return result;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static List<Class<?>> findSuperTypes(Class<?> cls, Class<?> endBefore) {
/*  122 */     return findSuperTypes(cls, endBefore, new ArrayList<>(8));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public static List<Class<?>> findSuperTypes(Class<?> cls, Class<?> endBefore, List<Class<?>> result) {
/*  127 */     _addRawSuperTypes(cls, endBefore, result, false);
/*  128 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void _addSuperTypes(JavaType type, Class<?> endBefore, Collection<JavaType> result, boolean addClassItself) {
/*  134 */     if (type == null) {
/*      */       return;
/*      */     }
/*  137 */     Class<?> cls = type.getRawClass();
/*  138 */     if (cls == endBefore || cls == Object.class)
/*  139 */       return;  if (addClassItself) {
/*  140 */       if (result.contains(type)) {
/*      */         return;
/*      */       }
/*  143 */       result.add(type);
/*      */     } 
/*  145 */     for (JavaType intCls : type.getInterfaces()) {
/*  146 */       _addSuperTypes(intCls, endBefore, result, true);
/*      */     }
/*  148 */     _addSuperTypes(type.getSuperClass(), endBefore, result, true);
/*      */   }
/*      */   
/*      */   private static void _addRawSuperTypes(Class<?> cls, Class<?> endBefore, Collection<Class<?>> result, boolean addClassItself) {
/*  152 */     if (cls == endBefore || cls == null || cls == Object.class)
/*  153 */       return;  if (addClassItself) {
/*  154 */       if (result.contains(cls)) {
/*      */         return;
/*      */       }
/*  157 */       result.add(cls);
/*      */     } 
/*  159 */     for (Class<?> intCls : _interfaces(cls)) {
/*  160 */       _addRawSuperTypes(intCls, endBefore, result, true);
/*      */     }
/*  162 */     _addRawSuperTypes(cls.getSuperclass(), endBefore, result, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String canBeABeanType(Class<?> type) {
/*  178 */     if (type.isAnnotation()) {
/*  179 */       return "annotation";
/*      */     }
/*  181 */     if (type.isArray()) {
/*  182 */       return "array";
/*      */     }
/*  184 */     if (Enum.class.isAssignableFrom(type)) {
/*  185 */       return "enum";
/*      */     }
/*  187 */     if (type.isPrimitive()) {
/*  188 */       return "primitive";
/*      */     }
/*      */ 
/*      */     
/*  192 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String isLocalType(Class<?> type, boolean allowNonStatic) {
/*      */     
/*  202 */     try { boolean isStatic = Modifier.isStatic(type.getModifiers());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  207 */       if (!isStatic && hasEnclosingMethod(type)) {
/*  208 */         return "local/anonymous";
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  214 */       if (!allowNonStatic && 
/*  215 */         !isStatic && getEnclosingClass(type) != null) {
/*  216 */         return "non-static member class";
/*      */       
/*      */       } }
/*      */     
/*  220 */     catch (SecurityException securityException) {  }
/*  221 */     catch (NullPointerException nullPointerException) {}
/*  222 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> getOuterClass(Class<?> type) {
/*  231 */     if (!Modifier.isStatic(type.getModifiers())) {
/*      */       
/*      */       try {
/*  234 */         if (hasEnclosingMethod(type)) {
/*  235 */           return null;
/*      */         }
/*  237 */         return getEnclosingClass(type);
/*  238 */       } catch (SecurityException securityException) {}
/*      */     }
/*  240 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isProxyType(Class<?> type) {
/*  257 */     String name = type.getName();
/*      */     
/*  259 */     if (name.startsWith("net.sf.cglib.proxy.") || name
/*  260 */       .startsWith("org.hibernate.proxy.")) {
/*  261 */       return true;
/*      */     }
/*      */     
/*  264 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isConcrete(Class<?> type) {
/*  273 */     int mod = type.getModifiers();
/*  274 */     return ((mod & 0x600) == 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean isConcrete(Member member) {
/*  279 */     int mod = member.getModifiers();
/*  280 */     return ((mod & 0x600) == 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean isCollectionMapOrArray(Class<?> type) {
/*  285 */     if (type.isArray()) return true; 
/*  286 */     if (Collection.class.isAssignableFrom(type)) return true; 
/*  287 */     if (Map.class.isAssignableFrom(type)) return true; 
/*  288 */     return false;
/*      */   }
/*      */   
/*      */   public static boolean isBogusClass(Class<?> cls) {
/*  292 */     return (cls == Void.class || cls == void.class || cls == NoClass.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isRecordType(Class<?> cls) {
/*  302 */     Class<?> parent = cls.getSuperclass();
/*  303 */     return (parent != null && "java.lang.Record".equals(parent.getName()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isObjectOrPrimitive(Class<?> cls) {
/*  310 */     return (cls == CLS_OBJECT || cls.isPrimitive());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean hasClass(Object inst, Class<?> raw) {
/*  319 */     return (inst != null && inst.getClass() == raw);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void verifyMustOverride(Class<?> expType, Object instance, String method) {
/*  328 */     if (instance.getClass() != expType) {
/*  329 */       throw new IllegalStateException(String.format("Sub-class %s (of class %s) must override method '%s'", new Object[] { instance
/*      */               
/*  331 */               .getClass().getName(), expType.getName(), method }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static boolean hasGetterSignature(Method m) {
/*  348 */     if (Modifier.isStatic(m.getModifiers())) {
/*  349 */       return false;
/*      */     }
/*      */     
/*  352 */     if ((m.getParameterTypes()).length != 0) {
/*  353 */       return false;
/*      */     }
/*      */     
/*  356 */     if (void.class == m.getReturnType()) {
/*  357 */       return false;
/*      */     }
/*      */     
/*  360 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable throwIfError(Throwable t) {
/*  376 */     if (t instanceof Error) {
/*  377 */       throw (Error)t;
/*      */     }
/*  379 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable throwIfRTE(Throwable t) {
/*  389 */     if (t instanceof RuntimeException) {
/*  390 */       throw (RuntimeException)t;
/*      */     }
/*  392 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable throwIfIOE(Throwable t) throws IOException {
/*  402 */     if (t instanceof IOException) {
/*  403 */       throw (IOException)t;
/*      */     }
/*  405 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable getRootCause(Throwable t) {
/*  420 */     while (t.getCause() != null) {
/*  421 */       t = t.getCause();
/*      */     }
/*  423 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Throwable throwRootCauseIfIOE(Throwable t) throws IOException {
/*  434 */     return throwIfIOE(getRootCause(t));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void throwAsIAE(Throwable t) {
/*  442 */     throwAsIAE(t, t.getMessage());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void throwAsIAE(Throwable t, String msg) {
/*  452 */     throwIfRTE(t);
/*  453 */     throwIfError(t);
/*  454 */     throw new IllegalArgumentException(msg, t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T throwAsMappingException(DeserializationContext ctxt, IOException e0) throws JsonMappingException {
/*  462 */     if (e0 instanceof JsonMappingException) {
/*  463 */       throw (JsonMappingException)e0;
/*      */     }
/*  465 */     throw JsonMappingException.from(ctxt, e0.getMessage())
/*  466 */       .withCause(e0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void unwrapAndThrowAsIAE(Throwable t) {
/*  476 */     throwAsIAE(getRootCause(t));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void unwrapAndThrowAsIAE(Throwable t, String msg) {
/*  486 */     throwAsIAE(getRootCause(t), msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeOnFailAndThrowAsIOE(JsonGenerator g, Exception fail) throws IOException {
/*  503 */     g.disable(JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT);
/*      */     try {
/*  505 */       g.close();
/*  506 */     } catch (Exception e) {
/*  507 */       fail.addSuppressed(e);
/*      */     } 
/*  509 */     throwIfIOE(fail);
/*  510 */     throwIfRTE(fail);
/*  511 */     throw new RuntimeException(fail);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void closeOnFailAndThrowAsIOE(JsonGenerator g, Closeable toClose, Exception fail) throws IOException {
/*  527 */     if (g != null) {
/*  528 */       g.disable(JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT);
/*      */       try {
/*  530 */         g.close();
/*  531 */       } catch (Exception e) {
/*  532 */         fail.addSuppressed(e);
/*      */       } 
/*      */     } 
/*  535 */     if (toClose != null) {
/*      */       try {
/*  537 */         toClose.close();
/*  538 */       } catch (Exception e) {
/*  539 */         fail.addSuppressed(e);
/*      */       } 
/*      */     }
/*  542 */     throwIfIOE(fail);
/*  543 */     throwIfRTE(fail);
/*  544 */     throw new RuntimeException(fail);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T createInstance(Class<T> cls, boolean canFixAccess) throws IllegalArgumentException {
/*  569 */     Constructor<T> ctor = findConstructor(cls, canFixAccess);
/*  570 */     if (ctor == null) {
/*  571 */       throw new IllegalArgumentException("Class " + cls.getName() + " has no default (no arg) constructor");
/*      */     }
/*      */     try {
/*  574 */       return ctor.newInstance(new Object[0]);
/*  575 */     } catch (Exception e) {
/*  576 */       unwrapAndThrowAsIAE(e, "Failed to instantiate class " + cls.getName() + ", problem: " + e.getMessage());
/*  577 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> Constructor<T> findConstructor(Class<T> cls, boolean forceAccess) throws IllegalArgumentException {
/*      */     try {
/*  585 */       Constructor<T> ctor = cls.getDeclaredConstructor(new Class[0]);
/*  586 */       if (forceAccess) {
/*  587 */         checkAndFixAccess(ctor, forceAccess);
/*      */       
/*      */       }
/*  590 */       else if (!Modifier.isPublic(ctor.getModifiers())) {
/*  591 */         throw new IllegalArgumentException("Default constructor for " + cls.getName() + " is not accessible (non-public?): not allowed to try modify access via Reflection: cannot instantiate type");
/*      */       } 
/*      */       
/*  594 */       return ctor;
/*  595 */     } catch (NoSuchMethodException e) {
/*  596 */       return null;
/*  597 */     } catch (Exception e) {
/*  598 */       unwrapAndThrowAsIAE(e, "Failed to find default constructor of class " + cls.getName() + ", problem: " + e.getMessage());
/*      */       
/*  600 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> classOf(Object inst) {
/*  613 */     if (inst == null) {
/*  614 */       return null;
/*      */     }
/*  616 */     return inst.getClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> rawClass(JavaType t) {
/*  623 */     if (t == null) {
/*  624 */       return null;
/*      */     }
/*  626 */     return t.getRawClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T nonNull(T valueOrNull, T defaultValue) {
/*  633 */     return (valueOrNull == null) ? defaultValue : valueOrNull;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String nullOrToString(Object value) {
/*  640 */     if (value == null) {
/*  641 */       return null;
/*      */     }
/*  643 */     return value.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String nonNullString(String str) {
/*  650 */     if (str == null) {
/*  651 */       return "";
/*      */     }
/*  653 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String quotedOr(Object str, String forNull) {
/*  663 */     if (str == null) {
/*  664 */       return forNull;
/*      */     }
/*  666 */     return String.format("\"%s\"", new Object[] { str });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getClassDescription(Object classOrInstance) {
/*  682 */     if (classOrInstance == null) {
/*  683 */       return "unknown";
/*      */     }
/*      */     
/*  686 */     Class<?> cls = (classOrInstance instanceof Class) ? (Class)classOrInstance : classOrInstance.getClass();
/*  687 */     return nameOf(cls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getTypeDescription(JavaType fullType) {
/*  703 */     if (fullType == null) {
/*  704 */       return "[null]";
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  709 */     int arrays = 0;
/*  710 */     while (fullType.isArrayType()) {
/*  711 */       arrays++;
/*  712 */       fullType = fullType.getContentType();
/*      */     } 
/*  714 */     StringBuilder sb = (new StringBuilder(80)).append('`');
/*  715 */     sb.append(fullType.toCanonical());
/*  716 */     while (arrays-- > 0) {
/*  717 */       sb.append("[]");
/*      */     }
/*  719 */     return sb.append('`').toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String classNameOf(Object inst) {
/*  730 */     if (inst == null) {
/*  731 */       return "[null]";
/*      */     }
/*  733 */     Class<?> raw = (inst instanceof Class) ? (Class)inst : inst.getClass();
/*  734 */     return nameOf(raw);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String nameOf(Class<?> cls) {
/*  744 */     if (cls == null) {
/*  745 */       return "[null]";
/*      */     }
/*  747 */     int index = 0;
/*  748 */     while (cls.isArray()) {
/*  749 */       index++;
/*  750 */       cls = cls.getComponentType();
/*      */     } 
/*  752 */     String base = cls.isPrimitive() ? cls.getSimpleName() : cls.getName();
/*  753 */     if (index > 0) {
/*  754 */       StringBuilder sb = new StringBuilder(base);
/*      */       while (true) {
/*  756 */         sb.append("[]");
/*  757 */         if (--index <= 0)
/*  758 */         { base = sb.toString(); break; } 
/*      */       } 
/*  760 */     }  return backticked(base);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String nameOf(Named named) {
/*  773 */     if (named == null) {
/*  774 */       return "[null]";
/*      */     }
/*  776 */     return apostrophed(named.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String name(String name) {
/*  786 */     if (name == null) {
/*  787 */       return "[null]";
/*      */     }
/*  789 */     return apostrophed(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String name(PropertyName name) {
/*  799 */     if (name == null) {
/*  800 */       return "[null]";
/*      */     }
/*      */     
/*  803 */     return apostrophed(name.getSimpleName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String backticked(String text) {
/*  818 */     if (text == null) {
/*  819 */       return "[null]";
/*      */     }
/*  821 */     return (new StringBuilder(text.length() + 2)).append('`').append(text).append('`').toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String apostrophed(String text) {
/*  830 */     if (text == null) {
/*  831 */       return "[null]";
/*      */     }
/*  833 */     return (new StringBuilder(text.length() + 2)).append('\'').append(text).append('\'').toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String exceptionMessage(Throwable t) {
/*  847 */     if (t instanceof JacksonException) {
/*  848 */       return ((JacksonException)t).getOriginalMessage();
/*      */     }
/*  850 */     if (t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null) {
/*  851 */       return t.getCause().getMessage();
/*      */     }
/*  853 */     return t.getMessage();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object defaultValue(Class<?> cls) {
/*  868 */     if (cls == int.class) {
/*  869 */       return Integer.valueOf(0);
/*      */     }
/*  871 */     if (cls == long.class) {
/*  872 */       return Long.valueOf(0L);
/*      */     }
/*  874 */     if (cls == boolean.class) {
/*  875 */       return Boolean.FALSE;
/*      */     }
/*  877 */     if (cls == double.class) {
/*  878 */       return Double.valueOf(0.0D);
/*      */     }
/*  880 */     if (cls == float.class) {
/*  881 */       return Float.valueOf(0.0F);
/*      */     }
/*  883 */     if (cls == byte.class) {
/*  884 */       return Byte.valueOf((byte)0);
/*      */     }
/*  886 */     if (cls == short.class) {
/*  887 */       return Short.valueOf((short)0);
/*      */     }
/*  889 */     if (cls == char.class) {
/*  890 */       return Character.valueOf(false);
/*      */     }
/*  892 */     throw new IllegalArgumentException("Class " + cls.getName() + " is not a primitive type");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> wrapperType(Class<?> primitiveType) {
/*  903 */     if (primitiveType == int.class) {
/*  904 */       return Integer.class;
/*      */     }
/*  906 */     if (primitiveType == long.class) {
/*  907 */       return Long.class;
/*      */     }
/*  909 */     if (primitiveType == boolean.class) {
/*  910 */       return Boolean.class;
/*      */     }
/*  912 */     if (primitiveType == double.class) {
/*  913 */       return Double.class;
/*      */     }
/*  915 */     if (primitiveType == float.class) {
/*  916 */       return Float.class;
/*      */     }
/*  918 */     if (primitiveType == byte.class) {
/*  919 */       return Byte.class;
/*      */     }
/*  921 */     if (primitiveType == short.class) {
/*  922 */       return Short.class;
/*      */     }
/*  924 */     if (primitiveType == char.class) {
/*  925 */       return Character.class;
/*      */     }
/*  927 */     throw new IllegalArgumentException("Class " + primitiveType.getName() + " is not a primitive type");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> primitiveType(Class<?> type) {
/*  938 */     if (type.isPrimitive()) {
/*  939 */       return type;
/*      */     }
/*      */     
/*  942 */     if (type == Integer.class) {
/*  943 */       return int.class;
/*      */     }
/*  945 */     if (type == Long.class) {
/*  946 */       return long.class;
/*      */     }
/*  948 */     if (type == Boolean.class) {
/*  949 */       return boolean.class;
/*      */     }
/*  951 */     if (type == Double.class) {
/*  952 */       return double.class;
/*      */     }
/*  954 */     if (type == Float.class) {
/*  955 */       return float.class;
/*      */     }
/*  957 */     if (type == Byte.class) {
/*  958 */       return byte.class;
/*      */     }
/*  960 */     if (type == Short.class) {
/*  961 */       return short.class;
/*      */     }
/*  963 */     if (type == Character.class) {
/*  964 */       return char.class;
/*      */     }
/*  966 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void checkAndFixAccess(Member member) {
/*  985 */     checkAndFixAccess(member, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkAndFixAccess(Member member, boolean evenIfAlreadyPublic) {
/* 1003 */     AccessibleObject ao = (AccessibleObject)member;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1011 */       Class<?> declaringClass = member.getDeclaringClass();
/*      */       
/* 1013 */       boolean isPublic = (Modifier.isPublic(member.getModifiers()) && Modifier.isPublic(declaringClass.getModifiers()));
/* 1014 */       if (!isPublic || (evenIfAlreadyPublic && !isJDKClass(declaringClass))) {
/* 1015 */         ao.setAccessible(true);
/*      */       }
/* 1017 */     } catch (SecurityException se) {
/*      */ 
/*      */       
/* 1020 */       if (!ao.isAccessible()) {
/* 1021 */         Class<?> declClass = member.getDeclaringClass();
/* 1022 */         throw new IllegalArgumentException("Cannot access " + member + " (from class " + declClass.getName() + "; failed to set access: " + se.getMessage());
/*      */       }
/*      */     
/*      */     }
/* 1026 */     catch (RuntimeException se) {
/* 1027 */       if ("InaccessibleObjectException".equals(se.getClass().getSimpleName())) {
/* 1028 */         throw new IllegalArgumentException(String.format("Failed to call `setAccess()` on %s '%s' (of class %s) due to `%s`, problem: %s", new Object[] { member
/*      */                 
/* 1030 */                 .getClass().getSimpleName(), member.getName(), 
/* 1031 */                 nameOf(member.getDeclaringClass()), se
/* 1032 */                 .getClass().getName(), se.getMessage() }), se);
/*      */       }
/*      */       
/* 1035 */       throw se;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isEnumType(Class<?> rawType) {
/* 1052 */     return Enum.class.isAssignableFrom(rawType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<? extends Enum<?>> findEnumType(EnumSet<?> s) {
/* 1064 */     if (!s.isEmpty()) {
/* 1065 */       return findEnumType(s.iterator().next());
/*      */     }
/*      */     
/* 1068 */     return EnumTypeLocator.instance.enumTypeFor(s);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<? extends Enum<?>> findEnumType(EnumMap<?, ?> m) {
/* 1079 */     if (!m.isEmpty()) {
/* 1080 */       return findEnumType(m.keySet().iterator().next());
/*      */     }
/*      */     
/* 1083 */     return EnumTypeLocator.instance.enumTypeFor(m);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<? extends Enum<?>> findEnumType(Enum<?> en) {
/* 1095 */     return (Class)en.getDeclaringClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<? extends Enum<?>> findEnumType(Class<?> cls) {
/* 1108 */     if (cls.getSuperclass() != Enum.class) {
/* 1109 */       cls = cls.getSuperclass();
/*      */     }
/* 1111 */     return (Class)cls;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends Annotation> Enum<?> findFirstAnnotatedEnumValue(Class<Enum<?>> enumClass, Class<T> annotationClass) {
/* 1127 */     Field[] fields = enumClass.getDeclaredFields();
/* 1128 */     for (Field field : fields) {
/* 1129 */       if (field.isEnumConstant()) {
/* 1130 */         Annotation defaultValueAnnotation = field.getAnnotation(annotationClass);
/* 1131 */         if (defaultValueAnnotation != null) {
/* 1132 */           String name = field.getName();
/* 1133 */           for (Enum<?> enumValue : (Enum[])enumClass.getEnumConstants()) {
/* 1134 */             if (name.equals(enumValue.name())) {
/* 1135 */               return enumValue;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1141 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isJacksonStdImpl(Object impl) {
/* 1161 */     return (impl == null || isJacksonStdImpl(impl.getClass()));
/*      */   }
/*      */   
/*      */   public static boolean isJacksonStdImpl(Class<?> implClass) {
/* 1165 */     return (implClass.getAnnotation(JacksonStdImpl.class) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isJDKClass(Class<?> rawType) {
/* 1183 */     String clsName = rawType.getName();
/* 1184 */     return (clsName.startsWith("java.") || clsName
/* 1185 */       .startsWith("javax.") || clsName
/* 1186 */       .startsWith("sun."));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isJDK17OrAbove() {
/*      */     try {
/* 1205 */       return (getJDKMajorVersion() >= 17);
/* 1206 */     } catch (Throwable t) {
/* 1207 */       ExceptionUtil.rethrowIfFatal(t);
/* 1208 */       System.err.println("Failed to determine JDK major version, assuming pre-JDK-17; problem: " + t);
/* 1209 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getJDKMajorVersion() {
/*      */     String version;
/*      */     try {
/* 1224 */       version = System.getProperty("java.version");
/* 1225 */     } catch (SecurityException e) {
/* 1226 */       throw new IllegalStateException("Could not access 'java.version': cannot determine JDK major version");
/*      */     } 
/* 1228 */     if (version.startsWith("1."))
/*      */     {
/*      */       
/* 1231 */       return 8;
/*      */     }
/* 1233 */     int dotIndex = version.indexOf(".");
/* 1234 */     String cleaned = (dotIndex < 0) ? version : version.substring(0, dotIndex);
/*      */     try {
/* 1236 */       return Integer.parseInt(cleaned);
/* 1237 */     } catch (NumberFormatException e) {
/* 1238 */       throw new IllegalStateException("Invalid JDK version String '" + version + "' cannot determine JDK major version");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNonStaticInnerClass(Class<?> cls) {
/* 1252 */     return (!Modifier.isStatic(cls.getModifiers()) && 
/* 1253 */       getEnclosingClass(cls) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static String getPackageName(Class<?> cls) {
/* 1263 */     Package pkg = cls.getPackage();
/* 1264 */     return (pkg == null) ? null : pkg.getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean hasEnclosingMethod(Class<?> cls) {
/* 1271 */     return (!isObjectOrPrimitive(cls) && cls.getEnclosingMethod() != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Field[] getDeclaredFields(Class<?> cls) {
/* 1279 */     return cls.getDeclaredFields();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static Method[] getDeclaredMethods(Class<?> cls) {
/* 1287 */     return cls.getDeclaredMethods();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Annotation[] findClassAnnotations(Class<?> cls) {
/* 1294 */     if (isObjectOrPrimitive(cls)) {
/* 1295 */       return NO_ANNOTATIONS;
/*      */     }
/* 1297 */     return cls.getDeclaredAnnotations();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method[] getClassMethods(Class<?> cls) {
/*      */     try {
/* 1310 */       return cls.getDeclaredMethods();
/* 1311 */     } catch (NoClassDefFoundError ex) {
/*      */       Class<?> contextClass;
/*      */       
/* 1314 */       ClassLoader loader = Thread.currentThread().getContextClassLoader();
/* 1315 */       if (loader == null)
/*      */       {
/* 1317 */         return _failGetClassMethods(cls, ex);
/*      */       }
/*      */       
/*      */       try {
/* 1321 */         contextClass = loader.loadClass(cls.getName());
/* 1322 */       } catch (ClassNotFoundException e) {
/* 1323 */         ex.addSuppressed(e);
/* 1324 */         return _failGetClassMethods(cls, ex);
/*      */       } 
/*      */       try {
/* 1327 */         return contextClass.getDeclaredMethods();
/* 1328 */       } catch (Exception t) {
/* 1329 */         return _failGetClassMethods(cls, t);
/*      */       } 
/* 1331 */     } catch (Exception t) {
/* 1332 */       return _failGetClassMethods(cls, t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Method[] _failGetClassMethods(Class<?> cls, Throwable rootCause) throws IllegalArgumentException {
/* 1340 */     throw new IllegalArgumentException(String.format("Failed on call to `getDeclaredMethods()` on class `%s`, problem: (%s) %s", new Object[] { cls
/*      */             
/* 1342 */             .getName(), rootCause.getClass().getName(), rootCause.getMessage() }), rootCause);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Ctor[] getConstructors(Class<?> cls) {
/* 1352 */     if (cls.isInterface() || isObjectOrPrimitive(cls)) {
/* 1353 */       return NO_CTORS;
/*      */     }
/* 1355 */     Constructor[] arrayOfConstructor = (Constructor[])cls.getDeclaredConstructors();
/* 1356 */     int len = arrayOfConstructor.length;
/* 1357 */     Ctor[] result = new Ctor[len];
/* 1358 */     for (int i = 0; i < len; i++) {
/* 1359 */       result[i] = new Ctor(arrayOfConstructor[i]);
/*      */     }
/* 1361 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> getDeclaringClass(Class<?> cls) {
/* 1371 */     return isObjectOrPrimitive(cls) ? null : cls.getDeclaringClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Type getGenericSuperclass(Class<?> cls) {
/* 1378 */     return cls.getGenericSuperclass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Type[] getGenericInterfaces(Class<?> cls) {
/* 1385 */     return cls.getGenericInterfaces();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> getEnclosingClass(Class<?> cls) {
/* 1393 */     return isObjectOrPrimitive(cls) ? null : cls.getEnclosingClass();
/*      */   }
/*      */   
/*      */   private static Class<?>[] _interfaces(Class<?> cls) {
/* 1397 */     return cls.getInterfaces();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class EnumTypeLocator
/*      */   {
/* 1412 */     static final EnumTypeLocator instance = new EnumTypeLocator();
/*      */     
/*      */     private final Field enumSetTypeField;
/*      */     
/*      */     private final Field enumMapTypeField;
/*      */     
/*      */     private final String failForEnumSet;
/*      */     
/*      */     private final String failForEnumMap;
/*      */ 
/*      */     
/*      */     private EnumTypeLocator() {
/* 1424 */       Field f = null;
/* 1425 */       String msg = null;
/*      */       
/*      */       try {
/* 1428 */         f = locateField(EnumSet.class, "elementType", Class.class);
/* 1429 */       } catch (Exception e) {
/* 1430 */         msg = e.toString();
/*      */       } 
/* 1432 */       this.enumSetTypeField = f;
/* 1433 */       this.failForEnumSet = msg;
/*      */       
/* 1435 */       f = null;
/* 1436 */       msg = null;
/*      */       try {
/* 1438 */         f = locateField(EnumMap.class, "keyType", Class.class);
/* 1439 */       } catch (Exception e) {
/* 1440 */         msg = e.toString();
/*      */       } 
/* 1442 */       this.enumMapTypeField = f;
/* 1443 */       this.failForEnumMap = msg;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Class<? extends Enum<?>> enumTypeFor(EnumSet<?> set) {
/* 1449 */       if (this.enumSetTypeField != null) {
/* 1450 */         return (Class<? extends Enum<?>>)get(set, this.enumSetTypeField);
/*      */       }
/* 1452 */       throw new IllegalStateException("Cannot figure out type parameter for `EnumSet` (odd JDK platform?), problem: " + this.failForEnumSet);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Class<? extends Enum<?>> enumTypeFor(EnumMap<?, ?> set) {
/* 1459 */       if (this.enumMapTypeField != null) {
/* 1460 */         return (Class<? extends Enum<?>>)get(set, this.enumMapTypeField);
/*      */       }
/* 1462 */       throw new IllegalStateException("Cannot figure out type parameter for `EnumMap` (odd JDK platform?), problem: " + this.failForEnumMap);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private Object get(Object bean, Field field) {
/*      */       try {
/* 1469 */         return field.get(bean);
/* 1470 */       } catch (Exception e) {
/* 1471 */         throw new IllegalArgumentException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static Field locateField(Class<?> fromClass, String expectedName, Class<?> type) throws Exception {
/* 1479 */       Field[] fields = fromClass.getDeclaredFields(); Field[] arrayOfField1; int i; byte b;
/* 1480 */       for (arrayOfField1 = fields, i = arrayOfField1.length, b = 0; b < i; ) { Field f = arrayOfField1[b];
/* 1481 */         if (!expectedName.equals(f.getName()) || f.getType() != type) {
/*      */           b++; continue;
/*      */         } 
/* 1484 */         f.setAccessible(true);
/* 1485 */         return f; }
/*      */ 
/*      */       
/* 1488 */       throw new IllegalStateException(String.format("No field named '%s' in class '%s'", new Object[] { expectedName, fromClass
/* 1489 */               .getName() }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class Ctor
/*      */   {
/*      */     public final Constructor<?> _ctor;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private transient Annotation[] _annotations;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private transient Annotation[][] _paramAnnotations;
/*      */ 
/*      */ 
/*      */     
/* 1513 */     private int _paramCount = -1;
/*      */     
/*      */     public Ctor(Constructor<?> ctor) {
/* 1516 */       this._ctor = ctor;
/*      */     }
/*      */     
/*      */     public Constructor<?> getConstructor() {
/* 1520 */       return this._ctor;
/*      */     }
/*      */     
/*      */     public int getParamCount() {
/* 1524 */       int c = this._paramCount;
/* 1525 */       if (c < 0) {
/* 1526 */         c = this._ctor.getParameterCount();
/* 1527 */         this._paramCount = c;
/*      */       } 
/* 1529 */       return c;
/*      */     }
/*      */     
/*      */     public Class<?> getDeclaringClass() {
/* 1533 */       return this._ctor.getDeclaringClass();
/*      */     }
/*      */     
/*      */     public Annotation[] getDeclaredAnnotations() {
/* 1537 */       Annotation[] result = this._annotations;
/* 1538 */       if (result == null) {
/* 1539 */         result = this._ctor.getDeclaredAnnotations();
/* 1540 */         this._annotations = result;
/*      */       } 
/* 1542 */       return result;
/*      */     }
/*      */     
/*      */     public Annotation[][] getParameterAnnotations() {
/* 1546 */       Annotation[][] result = this._paramAnnotations;
/* 1547 */       if (result == null) {
/* 1548 */         result = this._ctor.getParameterAnnotations();
/* 1549 */         this._paramAnnotations = result;
/*      */       } 
/* 1551 */       return result;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\ClassUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */