/*     */ package com.fasterxml.jackson.databind.util;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanUtil
/*     */ {
/*     */   @Deprecated
/*     */   public static String okNameForGetter(AnnotatedMethod am, boolean stdNaming) {
/*  33 */     String name = am.getName();
/*  34 */     String str = okNameForIsGetter(am, name, stdNaming);
/*  35 */     if (str == null) {
/*  36 */       str = okNameForRegularGetter(am, name, stdNaming);
/*     */     }
/*  38 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static String okNameForRegularGetter(AnnotatedMethod am, String name, boolean stdNaming) {
/*  50 */     if (name.startsWith("get")) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  58 */       if ("getCallbacks".equals(name)) {
/*  59 */         if (isCglibGetCallbacks(am)) {
/*  60 */           return null;
/*     */         }
/*  62 */       } else if ("getMetaClass".equals(name)) {
/*     */         
/*  64 */         if (isGroovyMetaClassGetter(am)) {
/*  65 */           return null;
/*     */         }
/*     */       } 
/*  68 */       return stdNaming ? 
/*  69 */         stdManglePropertyName(name, 3) : 
/*  70 */         legacyManglePropertyName(name, 3);
/*     */     } 
/*  72 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static String okNameForIsGetter(AnnotatedMethod am, String name, boolean stdNaming) {
/*  84 */     if (name.startsWith("is")) {
/*  85 */       Class<?> rt = am.getRawType();
/*  86 */       if (rt == Boolean.class || rt == boolean.class) {
/*  87 */         return stdNaming ? 
/*  88 */           stdManglePropertyName(name, 2) : 
/*  89 */           legacyManglePropertyName(name, 2);
/*     */       }
/*     */     } 
/*  92 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static String okNameForSetter(AnnotatedMethod am, boolean stdNaming) {
/*  99 */     return okNameForMutator(am, "set", stdNaming);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static String okNameForMutator(AnnotatedMethod am, String prefix, boolean stdNaming) {
/* 110 */     String name = am.getName();
/* 111 */     if (name.startsWith(prefix)) {
/* 112 */       return stdNaming ? 
/* 113 */         stdManglePropertyName(name, prefix.length()) : 
/* 114 */         legacyManglePropertyName(name, prefix.length());
/*     */     }
/* 116 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getDefaultValue(JavaType type) {
/* 142 */     Class<?> cls = type.getRawClass();
/*     */ 
/*     */ 
/*     */     
/* 146 */     Class<?> prim = ClassUtil.primitiveType(cls);
/* 147 */     if (prim != null) {
/* 148 */       return ClassUtil.defaultValue(prim);
/*     */     }
/* 150 */     if (type.isContainerType() || type.isReferenceType()) {
/* 151 */       return JsonInclude.Include.NON_EMPTY;
/*     */     }
/* 153 */     if (cls == String.class) {
/* 154 */       return "";
/*     */     }
/*     */ 
/*     */     
/* 158 */     if (type.isTypeOrSubTypeOf(Date.class)) {
/* 159 */       return new Date(0L);
/*     */     }
/* 161 */     if (type.isTypeOrSubTypeOf(Calendar.class)) {
/* 162 */       Calendar c = new GregorianCalendar();
/* 163 */       c.setTimeInMillis(0L);
/* 164 */       return c;
/*     */     } 
/* 166 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean isCglibGetCallbacks(AnnotatedMethod am) {
/* 185 */     Class<?> rt = am.getRawType();
/*     */     
/* 187 */     if (rt.isArray()) {
/*     */ 
/*     */ 
/*     */       
/* 191 */       Class<?> compType = rt.getComponentType();
/*     */       
/* 193 */       String className = compType.getName();
/* 194 */       if (className.contains(".cglib")) {
/* 195 */         return (className.startsWith("net.sf.cglib") || className
/*     */           
/* 197 */           .startsWith("org.hibernate.repackage.cglib") || className
/*     */           
/* 199 */           .startsWith("org.springframework.cglib"));
/*     */       }
/*     */     } 
/* 202 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean isGroovyMetaClassGetter(AnnotatedMethod am) {
/* 209 */     return am.getRawType().getName().startsWith("groovy.lang");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String legacyManglePropertyName(String basename, int offset) {
/* 227 */     int end = basename.length();
/* 228 */     if (end == offset) {
/* 229 */       return null;
/*     */     }
/*     */     
/* 232 */     char c = basename.charAt(offset);
/* 233 */     char d = Character.toLowerCase(c);
/*     */     
/* 235 */     if (c == d) {
/* 236 */       return basename.substring(offset);
/*     */     }
/*     */     
/* 239 */     StringBuilder sb = new StringBuilder(end - offset);
/* 240 */     sb.append(d);
/* 241 */     int i = offset + 1;
/* 242 */     for (; i < end; i++) {
/* 243 */       c = basename.charAt(i);
/* 244 */       d = Character.toLowerCase(c);
/* 245 */       if (c == d) {
/* 246 */         sb.append(basename, i, end);
/*     */         break;
/*     */       } 
/* 249 */       sb.append(d);
/*     */     } 
/* 251 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String stdManglePropertyName(String basename, int offset) {
/* 261 */     int end = basename.length();
/* 262 */     if (end == offset) {
/* 263 */       return null;
/*     */     }
/*     */     
/* 266 */     char c0 = basename.charAt(offset);
/* 267 */     char c1 = Character.toLowerCase(c0);
/* 268 */     if (c0 == c1) {
/* 269 */       return basename.substring(offset);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 274 */     if (offset + 1 < end && 
/* 275 */       Character.isUpperCase(basename.charAt(offset + 1))) {
/* 276 */       return basename.substring(offset);
/*     */     }
/*     */     
/* 279 */     StringBuilder sb = new StringBuilder(end - offset);
/* 280 */     sb.append(c1);
/* 281 */     sb.append(basename, offset + 1, end);
/* 282 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String checkUnsupportedType(MapperConfig<?> config, JavaType type) {
/* 303 */     String typeName, moduleName, className = type.getRawClass().getName();
/*     */     
/* 305 */     MapperFeature failFeature = null;
/*     */     
/* 307 */     if (isJava8TimeClass(className)) {
/*     */ 
/*     */       
/* 310 */       if (className.indexOf('.', 10) >= 0) {
/* 311 */         return null;
/*     */       }
/*     */       
/* 314 */       if (type.isTypeOrSubTypeOf(Throwable.class)) {
/* 315 */         return null;
/*     */       }
/* 317 */       failFeature = MapperFeature.REQUIRE_HANDLERS_FOR_JAVA8_TIMES;
/* 318 */       boolean fail = (config == null || config.isEnabled(failFeature));
/* 319 */       if (!fail) {
/* 320 */         return null;
/*     */       }
/* 322 */       typeName = "Java 8 date/time";
/* 323 */       moduleName = "com.fasterxml.jackson.datatype:jackson-datatype-jsr310";
/* 324 */     } else if (isJodaTimeClass(className)) {
/* 325 */       typeName = "Joda date/time";
/* 326 */       moduleName = "com.fasterxml.jackson.datatype:jackson-datatype-joda";
/* 327 */     } else if (isJava8OptionalClass(className)) {
/* 328 */       failFeature = MapperFeature.REQUIRE_HANDLERS_FOR_JAVA8_OPTIONALS;
/* 329 */       boolean fail = (config == null || config.isEnabled(failFeature));
/* 330 */       if (!fail) {
/* 331 */         return null;
/*     */       }
/* 333 */       typeName = "Java 8 optional";
/* 334 */       moduleName = "com.fasterxml.jackson.datatype:jackson-datatype-jdk8";
/*     */     } else {
/* 336 */       return null;
/*     */     } 
/* 338 */     String str = String.format("%s type %s not supported by default: add Module \"%s\" to enable handling", new Object[] { typeName, 
/* 339 */           ClassUtil.getTypeDescription(type), moduleName });
/* 340 */     if (failFeature != null) {
/* 341 */       str = String.format("%s (or disable `MapperFeature.%s`)", new Object[] { str, failFeature
/* 342 */             .name() });
/*     */     }
/* 344 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static String checkUnsupportedType(JavaType type) {
/* 353 */     return checkUnsupportedType(null, type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isJava8TimeClass(Class<?> rawType) {
/* 360 */     return isJava8TimeClass(rawType.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isJava8TimeClass(String className) {
/* 365 */     return className.startsWith("java.time.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isJava8OptionalClass(Class<?> rawType) {
/* 372 */     return isJava8OptionalClass(rawType.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isJava8OptionalClass(String className) {
/* 377 */     return className.startsWith("java.util.Optional");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isJodaTimeClass(Class<?> rawType) {
/* 384 */     return isJodaTimeClass(rawType.getName());
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isJodaTimeClass(String className) {
/* 389 */     return className.startsWith("org.joda.time.");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\BeanUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */