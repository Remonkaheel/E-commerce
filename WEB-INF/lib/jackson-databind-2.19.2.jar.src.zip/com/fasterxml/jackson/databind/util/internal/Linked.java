package com.fasterxml.jackson.databind.util.internal;

interface Linked<T extends Linked<T>> {
  T getPrevious();
  
  void setPrevious(T paramT);
  
  T getNext();
  
  void setNext(T paramT);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\internal\Linked.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */