/*    */ package com.fasterxml.jackson.databind.util;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Converter<IN, OUT>
/*    */ {
/*    */   OUT convert(IN paramIN);
/*    */   
/*    */   default OUT convert(DeserializationContext ctxt, IN value) {
/* 36 */     return convert(value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default OUT convert(SerializerProvider provider, IN value) {
/* 46 */     return convert(value);
/*    */   }
/*    */   
/*    */   JavaType getInputType(TypeFactory paramTypeFactory);
/*    */   
/*    */   JavaType getOutputType(TypeFactory paramTypeFactory);
/*    */   
/*    */   public static abstract class None implements Converter<Object, Object> {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\Converter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */