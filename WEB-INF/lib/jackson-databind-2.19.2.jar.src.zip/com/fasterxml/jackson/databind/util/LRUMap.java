/*    */ package com.fasterxml.jackson.databind.util;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.util.internal.PrivateMaxEntriesMap;
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ import java.util.function.BiConsumer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LRUMap<K, V>
/*    */   implements LookupCache<K, V>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 2L;
/*    */   protected final int _initialEntries;
/*    */   protected final int _maxEntries;
/*    */   protected final transient PrivateMaxEntriesMap<K, V> _map;
/*    */   
/*    */   public LRUMap(int initialEntries, int maxEntries) {
/* 38 */     this._initialEntries = initialEntries;
/* 39 */     this._maxEntries = maxEntries;
/*    */     
/* 41 */     this
/*    */ 
/*    */ 
/*    */       
/* 45 */       ._map = (new PrivateMaxEntriesMap.Builder()).initialCapacity(initialEntries).maximumCapacity(maxEntries).concurrencyLevel(4).build();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public LookupCache<K, V> emptyCopy() {
/* 51 */     return new LRUMap(this._initialEntries, this._maxEntries);
/*    */   }
/*    */ 
/*    */   
/*    */   public V put(K key, V value) {
/* 56 */     return (V)this._map.put(key, value);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public V putIfAbsent(K key, V value) {
/* 64 */     return (V)this._map.putIfAbsent(key, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public V get(Object key) {
/* 69 */     return (V)this._map.get(key);
/*    */   }
/*    */   public void clear() {
/* 72 */     this._map.clear();
/*    */   }
/*    */   public int size() {
/* 75 */     return this._map.size();
/*    */   }
/*    */   
/*    */   public void contents(BiConsumer<K, V> consumer) {
/* 79 */     for (Map.Entry<K, V> entry : (Iterable<Map.Entry<K, V>>)this._map.entrySet()) {
/* 80 */       consumer.accept(entry.getKey(), entry.getValue());
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object readResolve() {
/* 91 */     return new LRUMap(this._initialEntries, this._maxEntries);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\LRUMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */