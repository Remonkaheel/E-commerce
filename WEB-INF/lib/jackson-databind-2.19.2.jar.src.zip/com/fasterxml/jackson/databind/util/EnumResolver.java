/*     */ package com.fasterxml.jackson.databind.util;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.EnumNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnumResolver
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final Class<Enum<?>> _enumClass;
/*     */   protected final Enum<?>[] _enums;
/*     */   protected final HashMap<String, Enum<?>> _enumsById;
/*     */   protected final Enum<?> _defaultValue;
/*     */   protected final boolean _isIgnoreCase;
/*     */   protected final boolean _isFromIntValue;
/*     */   
/*     */   protected EnumResolver(Class<Enum<?>> enumClass, Enum<?>[] enums, HashMap<String, Enum<?>> map, Enum<?> defaultValue, boolean isIgnoreCase, boolean isFromIntValue) {
/*  61 */     this._enumClass = enumClass;
/*  62 */     this._enums = enums;
/*  63 */     this._enumsById = map;
/*  64 */     this._defaultValue = defaultValue;
/*  65 */     this._isIgnoreCase = isIgnoreCase;
/*  66 */     this._isFromIntValue = isFromIntValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnumResolver constructFor(DeserializationConfig config, AnnotatedClass annotatedClass) {
/*  89 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/*  90 */     boolean isIgnoreCase = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
/*  91 */     Class<?> enumCls0 = annotatedClass.getRawType();
/*  92 */     Class<Enum<?>> enumCls = _enumClass(enumCls0);
/*  93 */     Enum[] arrayOfEnum = (Enum[])_enumConstants(enumCls0);
/*     */ 
/*     */     
/*  96 */     String[] names = ai.findEnumValues((MapperConfig)config, annotatedClass, arrayOfEnum, new String[arrayOfEnum.length]);
/*     */     
/*  98 */     String[][] allAliases = new String[names.length][];
/*  99 */     ai.findEnumAliases((MapperConfig)config, annotatedClass, arrayOfEnum, allAliases);
/*     */ 
/*     */     
/* 102 */     HashMap<String, Enum<?>> map = new HashMap<>();
/* 103 */     for (int i = 0, len = arrayOfEnum.length; i < len; i++) {
/* 104 */       Enum<?> enumValue = arrayOfEnum[i];
/* 105 */       String name = names[i];
/* 106 */       if (name == null) {
/* 107 */         name = enumValue.name();
/*     */       }
/* 109 */       map.put(name, enumValue);
/* 110 */       String[] aliases = allAliases[i];
/* 111 */       if (aliases != null) {
/* 112 */         for (String alias : aliases)
/*     */         {
/* 114 */           map.putIfAbsent(alias, enumValue);
/*     */         }
/*     */       }
/*     */     } 
/* 118 */     return new EnumResolver(enumCls, (Enum<?>[])arrayOfEnum, map, 
/* 119 */         _enumDefault(ai, annotatedClass, (Enum<?>[])arrayOfEnum), isIgnoreCase, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static EnumResolver constructFor(DeserializationConfig config, Class<?> enumCls0) {
/* 134 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 135 */     boolean isIgnoreCase = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
/* 136 */     Class<Enum<?>> enumCls = _enumClass(enumCls0);
/* 137 */     Enum[] arrayOfEnum = (Enum[])_enumConstants(enumCls0);
/* 138 */     String[] names = ai.findEnumValues(enumCls, arrayOfEnum, new String[arrayOfEnum.length]);
/* 139 */     String[][] allAliases = new String[names.length][];
/* 140 */     ai.findEnumAliases(enumCls, arrayOfEnum, allAliases);
/* 141 */     HashMap<String, Enum<?>> map = new HashMap<>();
/* 142 */     for (int i = 0, len = arrayOfEnum.length; i < len; i++) {
/* 143 */       Enum<?> enumValue = arrayOfEnum[i];
/* 144 */       String name = names[i];
/* 145 */       if (name == null) {
/* 146 */         name = enumValue.name();
/*     */       }
/* 148 */       map.put(name, enumValue);
/* 149 */       String[] aliases = allAliases[i];
/* 150 */       if (aliases != null) {
/* 151 */         for (String alias : aliases)
/*     */         {
/* 153 */           map.putIfAbsent(alias, enumValue);
/*     */         }
/*     */       }
/*     */     } 
/* 157 */     return new EnumResolver(enumCls, (Enum<?>[])arrayOfEnum, map, 
/* 158 */         _enumDefault(ai, enumCls), isIgnoreCase, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnumResolver constructUsingToString(DeserializationConfig config, AnnotatedClass annotatedClass) {
/* 172 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 173 */     boolean isIgnoreCase = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
/* 174 */     Class<?> enumCls0 = annotatedClass.getRawType();
/* 175 */     Class<Enum<?>> enumCls = _enumClass(enumCls0);
/* 176 */     Enum[] arrayOfEnum = (Enum[])_enumConstants(enumCls0);
/*     */ 
/*     */     
/* 179 */     String[] names = new String[arrayOfEnum.length];
/* 180 */     String[][] allAliases = new String[arrayOfEnum.length][];
/* 181 */     if (ai != null) {
/* 182 */       ai.findEnumValues((MapperConfig)config, annotatedClass, arrayOfEnum, names);
/* 183 */       ai.findEnumAliases((MapperConfig)config, annotatedClass, arrayOfEnum, allAliases);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 188 */     HashMap<String, Enum<?>> map = new HashMap<>();
/* 189 */     for (int i = arrayOfEnum.length; --i >= 0; ) {
/* 190 */       Enum<?> enumValue = arrayOfEnum[i];
/* 191 */       String name = names[i];
/* 192 */       if (name == null) {
/* 193 */         name = enumValue.toString();
/*     */       }
/* 195 */       map.put(name, enumValue);
/* 196 */       String[] aliases = allAliases[i];
/* 197 */       if (aliases != null) {
/* 198 */         for (String alias : aliases)
/*     */         {
/* 200 */           map.putIfAbsent(alias, enumValue);
/*     */         }
/*     */       }
/*     */     } 
/* 204 */     return new EnumResolver(enumCls, (Enum<?>[])arrayOfEnum, map, 
/* 205 */         _enumDefault(ai, annotatedClass, (Enum<?>[])arrayOfEnum), isIgnoreCase, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static EnumResolver constructUsingToString(DeserializationConfig config, Class<?> enumCls0) {
/* 220 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 221 */     boolean isIgnoreCase = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
/* 222 */     Class<Enum<?>> enumCls = _enumClass(enumCls0);
/* 223 */     Enum[] arrayOfEnum = (Enum[])_enumConstants(enumCls0);
/* 224 */     HashMap<String, Enum<?>> map = new HashMap<>();
/* 225 */     String[][] allAliases = new String[arrayOfEnum.length][];
/* 226 */     if (ai != null) {
/* 227 */       ai.findEnumAliases(enumCls, arrayOfEnum, allAliases);
/*     */     }
/*     */ 
/*     */     
/* 231 */     for (int i = arrayOfEnum.length; --i >= 0; ) {
/* 232 */       Enum<?> enumValue = arrayOfEnum[i];
/* 233 */       map.put(enumValue.toString(), enumValue);
/* 234 */       String[] aliases = allAliases[i];
/* 235 */       if (aliases != null) {
/* 236 */         for (String alias : aliases)
/*     */         {
/* 238 */           map.putIfAbsent(alias, enumValue);
/*     */         }
/*     */       }
/*     */     } 
/* 242 */     return new EnumResolver(enumCls, (Enum<?>[])arrayOfEnum, map, 
/* 243 */         _enumDefault(ai, enumCls), isIgnoreCase, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnumResolver constructUsingIndex(DeserializationConfig config, AnnotatedClass annotatedClass) {
/* 257 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 258 */     boolean isIgnoreCase = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
/* 259 */     Class<?> enumCls0 = annotatedClass.getRawType();
/* 260 */     Class<Enum<?>> enumCls = _enumClass(enumCls0);
/* 261 */     Enum[] arrayOfEnum = (Enum[])_enumConstants(enumCls0);
/*     */ 
/*     */ 
/*     */     
/* 265 */     HashMap<String, Enum<?>> map = new HashMap<>();
/* 266 */     for (int i = arrayOfEnum.length; --i >= 0; ) {
/* 267 */       Enum<?> enumValue = arrayOfEnum[i];
/* 268 */       map.put(String.valueOf(i), enumValue);
/*     */     } 
/* 270 */     return new EnumResolver(enumCls, (Enum<?>[])arrayOfEnum, map, 
/* 271 */         _enumDefault(ai, annotatedClass, (Enum<?>[])arrayOfEnum), isIgnoreCase, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static EnumResolver constructUsingIndex(DeserializationConfig config, Class<Enum<?>> enumCls0) {
/* 286 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 287 */     boolean isIgnoreCase = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
/* 288 */     Class<Enum<?>> enumCls = _enumClass(enumCls0);
/* 289 */     Enum[] arrayOfEnum = (Enum[])_enumConstants(enumCls0);
/* 290 */     HashMap<String, Enum<?>> map = new HashMap<>();
/*     */ 
/*     */     
/* 293 */     for (int i = arrayOfEnum.length; --i >= 0; ) {
/* 294 */       Enum<?> enumValue = arrayOfEnum[i];
/* 295 */       map.put(String.valueOf(i), enumValue);
/*     */     } 
/* 297 */     return new EnumResolver(enumCls, (Enum<?>[])arrayOfEnum, map, 
/* 298 */         _enumDefault(ai, enumCls), isIgnoreCase, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static EnumResolver constructUsingEnumNamingStrategy(DeserializationConfig config, Class<?> enumCls0, EnumNamingStrategy enumNamingStrategy) {
/* 316 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 317 */     boolean isIgnoreCase = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
/* 318 */     Class<Enum<?>> enumCls = _enumClass(enumCls0);
/* 319 */     Enum[] arrayOfEnum = (Enum[])_enumConstants(enumCls0);
/* 320 */     HashMap<String, Enum<?>> map = new HashMap<>();
/*     */ 
/*     */     
/* 323 */     String[] names = new String[arrayOfEnum.length];
/* 324 */     String[][] allAliases = new String[arrayOfEnum.length][];
/* 325 */     if (ai != null) {
/* 326 */       ai.findEnumValues(enumCls, arrayOfEnum, names);
/* 327 */       ai.findEnumAliases(enumCls, arrayOfEnum, allAliases);
/*     */     } 
/*     */ 
/*     */     
/* 331 */     for (int i = arrayOfEnum.length; --i >= 0; ) {
/* 332 */       Enum<?> anEnum = arrayOfEnum[i];
/* 333 */       String name = names[i];
/* 334 */       if (name == null) {
/* 335 */         name = enumNamingStrategy.convertEnumToExternalName(anEnum.name());
/*     */       }
/* 337 */       map.put(name, anEnum);
/* 338 */       String[] aliases = allAliases[i];
/* 339 */       if (aliases != null) {
/* 340 */         for (String alias : aliases)
/*     */         {
/* 342 */           map.putIfAbsent(alias, anEnum);
/*     */         }
/*     */       }
/*     */     } 
/*     */     
/* 347 */     return new EnumResolver(enumCls, (Enum<?>[])arrayOfEnum, map, 
/* 348 */         _enumDefault(ai, enumCls), isIgnoreCase, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnumResolver constructUsingEnumNamingStrategy(DeserializationConfig config, AnnotatedClass annotatedClass, EnumNamingStrategy enumNamingStrategy) {
/* 361 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 362 */     boolean isIgnoreCase = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
/* 363 */     Class<?> enumCls0 = annotatedClass.getRawType();
/* 364 */     Class<Enum<?>> enumCls = _enumClass(enumCls0);
/* 365 */     Enum[] arrayOfEnum = (Enum[])_enumConstants(enumCls0);
/*     */ 
/*     */     
/* 368 */     String[] names = new String[arrayOfEnum.length];
/* 369 */     String[][] allAliases = new String[arrayOfEnum.length][];
/* 370 */     if (ai != null) {
/* 371 */       ai.findEnumValues((MapperConfig)config, annotatedClass, arrayOfEnum, names);
/* 372 */       ai.findEnumAliases((MapperConfig)config, annotatedClass, arrayOfEnum, allAliases);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 377 */     HashMap<String, Enum<?>> map = new HashMap<>();
/* 378 */     for (int i = arrayOfEnum.length; --i >= 0; ) {
/* 379 */       Enum<?> anEnum = arrayOfEnum[i];
/* 380 */       String name = names[i];
/* 381 */       if (name == null) {
/* 382 */         name = enumNamingStrategy.convertEnumToExternalName(anEnum.name());
/*     */       }
/* 384 */       map.put(name, anEnum);
/* 385 */       String[] aliases = allAliases[i];
/* 386 */       if (aliases != null) {
/* 387 */         for (String alias : aliases)
/*     */         {
/* 389 */           map.putIfAbsent(alias, anEnum);
/*     */         }
/*     */       }
/*     */     } 
/*     */     
/* 394 */     return new EnumResolver(enumCls, (Enum<?>[])arrayOfEnum, map, 
/* 395 */         _enumDefault(ai, annotatedClass, (Enum<?>[])arrayOfEnum), isIgnoreCase, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static EnumResolver constructUsingMethod(DeserializationConfig config, Class<?> enumCls0, AnnotatedMember accessor) {
/* 411 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 412 */     boolean isIgnoreCase = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
/* 413 */     Class<Enum<?>> enumCls = _enumClass(enumCls0);
/* 414 */     Enum[] arrayOfEnum = (Enum[])_enumConstants(enumCls0);
/* 415 */     HashMap<String, Enum<?>> map = new HashMap<>();
/*     */     
/* 417 */     for (int i = arrayOfEnum.length; --i >= 0; ) {
/* 418 */       Enum<?> en = arrayOfEnum[i];
/*     */       try {
/* 420 */         Object o = accessor.getValue(en);
/* 421 */         if (o != null) {
/* 422 */           map.put(o.toString(), en);
/*     */         }
/* 424 */       } catch (Exception e) {
/* 425 */         throw new IllegalArgumentException("Failed to access @JsonValue of Enum value " + en + ": " + e.getMessage());
/*     */       } 
/*     */     } 
/* 428 */     return new EnumResolver(enumCls, (Enum<?>[])arrayOfEnum, map, 
/* 429 */         _enumDefault(ai, enumCls), isIgnoreCase, 
/*     */ 
/*     */         
/* 432 */         _isIntType(accessor.getRawType()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnumResolver constructUsingMethod(DeserializationConfig config, AnnotatedClass annotatedClass, AnnotatedMember accessor) {
/* 446 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 447 */     boolean isIgnoreCase = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS);
/* 448 */     Class<?> enumCls0 = annotatedClass.getRawType();
/* 449 */     Class<Enum<?>> enumCls = _enumClass(enumCls0);
/* 450 */     Enum[] arrayOfEnum = (Enum[])_enumConstants(enumCls0);
/*     */ 
/*     */     
/* 453 */     HashMap<String, Enum<?>> map = new HashMap<>();
/*     */     
/* 455 */     for (int i = arrayOfEnum.length; --i >= 0; ) {
/* 456 */       Enum<?> en = arrayOfEnum[i];
/*     */       try {
/* 458 */         Object o = accessor.getValue(en);
/* 459 */         if (o != null) {
/* 460 */           map.put(o.toString(), en);
/*     */         }
/* 462 */       } catch (Exception e) {
/* 463 */         throw new IllegalArgumentException("Failed to access @JsonValue of Enum value " + en + ": " + e.getMessage());
/*     */       } 
/*     */     } 
/* 466 */     return new EnumResolver(enumCls, (Enum<?>[])arrayOfEnum, map, 
/* 467 */         _enumDefault(ai, annotatedClass, (Enum<?>[])arrayOfEnum), isIgnoreCase, 
/*     */ 
/*     */         
/* 470 */         _isIntType(accessor.getRawType()));
/*     */   }
/*     */ 
/*     */   
/*     */   public CompactStringObjectMap constructLookup() {
/* 475 */     return CompactStringObjectMap.construct(this._enumsById);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static Class<Enum<?>> _enumClass(Class<?> enumCls0) {
/* 480 */     return (Class)enumCls0;
/*     */   }
/*     */   
/*     */   protected static Enum<?>[] _enumConstants(Class<?> enumCls) {
/* 484 */     Enum[] arrayOfEnum = (Enum[])_enumClass(enumCls).getEnumConstants();
/* 485 */     if (arrayOfEnum == null) {
/* 486 */       throw new IllegalArgumentException("No enum constants for class " + enumCls.getName());
/*     */     }
/* 488 */     return (Enum<?>[])arrayOfEnum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Enum<?> _enumDefault(AnnotationIntrospector intr, AnnotatedClass annotatedClass, Enum<?>[] enums) {
/* 498 */     return (intr != null) ? intr.findDefaultEnumValue(annotatedClass, (Enum[])enums) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected static Enum<?> _enumDefault(AnnotationIntrospector intr, Class<?> enumCls) {
/* 506 */     return (intr != null) ? intr.findDefaultEnumValue(_enumClass(enumCls)) : null;
/*     */   }
/*     */   
/*     */   protected static boolean _isIntType(Class<?> erasedType) {
/* 510 */     if (erasedType.isPrimitive()) {
/* 511 */       erasedType = ClassUtil.wrapperType(erasedType);
/*     */     }
/* 513 */     return (erasedType == Long.class || erasedType == Integer.class || erasedType == Short.class || erasedType == Byte.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Enum<?> findEnum(String key) {
/* 527 */     Enum<?> en = this._enumsById.get(key);
/* 528 */     if (en == null && 
/* 529 */       this._isIgnoreCase) {
/* 530 */       return _findEnumCaseInsensitive(key);
/*     */     }
/*     */     
/* 533 */     return en;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Enum<?> _findEnumCaseInsensitive(String key) {
/* 538 */     for (Map.Entry<String, Enum<?>> entry : this._enumsById.entrySet()) {
/* 539 */       if (key.equalsIgnoreCase(entry.getKey())) {
/* 540 */         return entry.getValue();
/*     */       }
/*     */     } 
/* 543 */     return null;
/*     */   }
/*     */   
/*     */   public Enum<?> getEnum(int index) {
/* 547 */     if (index < 0 || index >= this._enums.length) {
/* 548 */       return null;
/*     */     }
/* 550 */     return this._enums[index];
/*     */   }
/*     */   
/*     */   public Enum<?> getDefaultValue() {
/* 554 */     return this._defaultValue;
/*     */   }
/*     */   
/*     */   public Enum<?>[] getRawEnums() {
/* 558 */     return this._enums;
/*     */   }
/*     */   
/*     */   public List<Enum<?>> getEnums() {
/* 562 */     ArrayList<Enum<?>> enums = new ArrayList<>(this._enums.length);
/* 563 */     for (Enum<?> e : this._enums) {
/* 564 */       enums.add(e);
/*     */     }
/* 566 */     return enums;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getEnumIds() {
/* 573 */     return this._enumsById.keySet();
/*     */   }
/*     */   public Class<Enum<?>> getEnumClass() {
/* 576 */     return this._enumClass;
/*     */   } public int lastValidIndex() {
/* 578 */     return this._enums.length - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFromIntValue() {
/* 589 */     return this._isFromIntValue;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\EnumResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */