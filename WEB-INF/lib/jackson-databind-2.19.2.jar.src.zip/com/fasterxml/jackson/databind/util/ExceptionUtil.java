/*    */ package com.fasterxml.jackson.databind.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExceptionUtil
/*    */ {
/*    */   public static void rethrowIfFatal(Throwable throwable) throws Error, RuntimeException {
/* 31 */     if (isFatal(throwable)) {
/* 32 */       if (throwable instanceof Error) {
/* 33 */         throw (Error)throwable;
/*    */       }
/* 35 */       if (throwable instanceof RuntimeException) {
/* 36 */         throw (RuntimeException)throwable;
/*    */       }
/* 38 */       throw new RuntimeException(throwable);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static boolean isFatal(Throwable throwable) {
/* 51 */     return (throwable instanceof VirtualMachineError || throwable instanceof ThreadDeath || throwable instanceof InterruptedException || throwable instanceof ClassCircularityError || throwable instanceof ClassFormatError || throwable instanceof IncompatibleClassChangeError || throwable instanceof BootstrapMethodError || throwable instanceof VerifyError);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> T throwSneaky(IOException e) {
/* 63 */     _sneaky(e);
/* 64 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   private static <E extends Throwable> void _sneaky(Throwable e) throws E {
/* 69 */     throw (E)e;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\ExceptionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */