/*     */ package com.fasterxml.jackson.databind.util;
/*     */ 
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.EnumNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*     */ import com.fasterxml.jackson.databind.cfg.EnumFeature;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.EnumMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public final class EnumValues implements Serializable {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final Class<Enum<?>> _enumClass;
/*     */   private final Enum<?>[] _values;
/*     */   private final SerializableString[] _textual;
/*     */   private transient EnumMap<?, SerializableString> _asMap;
/*     */   
/*     */   private EnumValues(Class<Enum<?>> enumClass, SerializableString[] textual) {
/*  29 */     this._enumClass = enumClass;
/*  30 */     this._values = enumClass.getEnumConstants();
/*  31 */     this._textual = textual;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnumValues construct(SerializationConfig config, AnnotatedClass annotatedClass) {
/*  41 */     if (config.isEnabled(SerializationFeature.WRITE_ENUMS_USING_TO_STRING)) {
/*  42 */       return constructFromToString((MapperConfig<?>)config, annotatedClass);
/*     */     }
/*  44 */     return constructFromName((MapperConfig<?>)config, annotatedClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static EnumValues constructFromName(MapperConfig<?> config, Class<Enum<?>> enumClass) {
/*  54 */     Class<? extends Enum<?>> enumCls = ClassUtil.findEnumType(enumClass);
/*  55 */     boolean useLowerCase = config.isEnabled((DatatypeFeature)EnumFeature.WRITE_ENUMS_TO_LOWERCASE);
/*  56 */     Enum[] arrayOfEnum = (Enum[])enumCls.getEnumConstants();
/*  57 */     if (arrayOfEnum == null) {
/*  58 */       throw new IllegalArgumentException("Cannot determine enum constants for Class " + enumClass.getName());
/*     */     }
/*  60 */     String[] names = config.getAnnotationIntrospector().findEnumValues(enumCls, arrayOfEnum, new String[arrayOfEnum.length]);
/*  61 */     SerializableString[] textual = new SerializableString[arrayOfEnum.length];
/*  62 */     for (int i = 0, len = arrayOfEnum.length; i < len; i++) {
/*  63 */       Enum<?> en = arrayOfEnum[i];
/*  64 */       String name = _findNameToUse(names[i], arrayOfEnum[i].name(), useLowerCase);
/*  65 */       textual[en.ordinal()] = config.compileString(name);
/*     */     } 
/*  67 */     return construct(enumClass, textual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnumValues constructFromName(MapperConfig<?> config, AnnotatedClass annotatedClass) {
/*  76 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/*  77 */     boolean useLowerCase = config.isEnabled((DatatypeFeature)EnumFeature.WRITE_ENUMS_TO_LOWERCASE);
/*  78 */     Class<?> enumCls0 = annotatedClass.getRawType();
/*  79 */     Class<Enum<?>> enumCls = _enumClass(enumCls0);
/*  80 */     Enum[] arrayOfEnum = (Enum[])_enumConstants(enumCls0);
/*     */ 
/*     */     
/*  83 */     String[] names = ai.findEnumValues(config, annotatedClass, arrayOfEnum, new String[arrayOfEnum.length]);
/*     */ 
/*     */ 
/*     */     
/*  87 */     SerializableString[] textual = new SerializableString[arrayOfEnum.length];
/*  88 */     for (int i = 0, len = arrayOfEnum.length; i < len; i++) {
/*  89 */       Enum<?> enumValue = arrayOfEnum[i];
/*  90 */       String name = _findNameToUse(names[i], enumValue.name(), useLowerCase);
/*  91 */       textual[enumValue.ordinal()] = config.compileString(name);
/*     */     } 
/*  93 */     return construct(enumCls, textual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnumValues constructFromToString(MapperConfig<?> config, AnnotatedClass annotatedClass) {
/* 102 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 103 */     boolean useLowerCase = config.isEnabled((DatatypeFeature)EnumFeature.WRITE_ENUMS_TO_LOWERCASE);
/* 104 */     Class<?> enumCls0 = annotatedClass.getRawType();
/* 105 */     Class<Enum<?>> enumCls = _enumClass(enumCls0);
/* 106 */     Enum[] arrayOfEnum = (Enum[])_enumConstants(enumCls0);
/*     */ 
/*     */     
/* 109 */     String[] names = new String[arrayOfEnum.length];
/* 110 */     if (ai != null) {
/* 111 */       ai.findEnumValues(config, annotatedClass, arrayOfEnum, names);
/*     */     }
/*     */ 
/*     */     
/* 115 */     SerializableString[] textual = new SerializableString[arrayOfEnum.length];
/* 116 */     for (int i = 0; i < arrayOfEnum.length; i++) {
/* 117 */       String enumToString = arrayOfEnum[i].toString();
/*     */ 
/*     */       
/* 120 */       enumToString = (enumToString == null) ? "" : enumToString;
/* 121 */       String name = _findNameToUse(names[i], enumToString, useLowerCase);
/* 122 */       textual[i] = config.compileString(name);
/*     */     } 
/* 124 */     return construct(enumCls, textual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static EnumValues constructFromToString(MapperConfig<?> config, Class<Enum<?>> enumClass) {
/* 133 */     Class<? extends Enum<?>> cls = ClassUtil.findEnumType(enumClass);
/* 134 */     Enum[] arrayOfEnum = (Enum[])cls.getEnumConstants();
/* 135 */     if (arrayOfEnum == null) {
/* 136 */       throw new IllegalArgumentException("Cannot determine enum constants for Class " + enumClass.getName());
/*     */     }
/* 138 */     ArrayList<String> external = new ArrayList<>(arrayOfEnum.length);
/* 139 */     for (Enum<?> en : arrayOfEnum) {
/* 140 */       external.add(en.toString());
/*     */     }
/* 142 */     return construct(config, enumClass, external);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnumValues constructUsingEnumNamingStrategy(MapperConfig<?> config, AnnotatedClass annotatedClass, EnumNamingStrategy namingStrategy) {
/* 157 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 158 */     boolean useLowerCase = config.isEnabled((DatatypeFeature)EnumFeature.WRITE_ENUMS_TO_LOWERCASE);
/* 159 */     Class<?> enumCls0 = annotatedClass.getRawType();
/* 160 */     Class<Enum<?>> enumCls = _enumClass(enumCls0);
/* 161 */     Enum[] arrayOfEnum = (Enum[])_enumConstants(enumCls0);
/*     */ 
/*     */     
/* 164 */     String[] names = new String[arrayOfEnum.length];
/* 165 */     if (ai != null) {
/* 166 */       ai.findEnumValues(config, annotatedClass, arrayOfEnum, names);
/*     */     }
/*     */ 
/*     */     
/* 170 */     SerializableString[] textual = new SerializableString[arrayOfEnum.length];
/* 171 */     for (int i = 0, len = arrayOfEnum.length; i < len; i++) {
/* 172 */       Enum<?> enumValue = arrayOfEnum[i];
/* 173 */       String name = _findNameToUse(names[i], namingStrategy.convertEnumToExternalName(enumValue.name()), useLowerCase);
/* 174 */       textual[i] = config.compileString(name);
/*     */     } 
/* 176 */     return construct(enumCls, textual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static EnumValues constructUsingEnumNamingStrategy(MapperConfig<?> config, Class<Enum<?>> enumClass, EnumNamingStrategy namingStrategy) {
/* 190 */     Class<? extends Enum<?>> cls = ClassUtil.findEnumType(enumClass);
/* 191 */     Enum[] arrayOfEnum = (Enum[])cls.getEnumConstants();
/* 192 */     if (arrayOfEnum == null) {
/* 193 */       throw new IllegalArgumentException("Cannot determine enum constants for Class " + enumClass.getName());
/*     */     }
/* 195 */     ArrayList<String> external = new ArrayList<>(arrayOfEnum.length);
/* 196 */     for (Enum<?> en : arrayOfEnum) {
/* 197 */       external.add(namingStrategy.convertEnumToExternalName(en.name()));
/*     */     }
/* 199 */     return construct(config, enumClass, external);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnumValues construct(MapperConfig<?> config, Class<Enum<?>> enumClass, List<String> externalValues) {
/* 207 */     int len = externalValues.size();
/* 208 */     SerializableString[] textual = new SerializableString[len];
/* 209 */     for (int i = 0; i < len; i++) {
/* 210 */       textual[i] = config.compileString(externalValues.get(i));
/*     */     }
/* 212 */     return construct(enumClass, textual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnumValues construct(Class<Enum<?>> enumClass, SerializableString[] externalValues) {
/* 220 */     return new EnumValues(enumClass, externalValues);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Class<Enum<?>> _enumClass(Class<?> enumCls0) {
/* 231 */     return (Class)enumCls0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Enum<?>[] _enumConstants(Class<?> enumCls) {
/* 239 */     Enum[] arrayOfEnum = (Enum[])ClassUtil.findEnumType(enumCls).getEnumConstants();
/* 240 */     if (arrayOfEnum == null) {
/* 241 */       throw new IllegalArgumentException("No enum constants for class " + enumCls.getName());
/*     */     }
/* 243 */     return (Enum<?>[])arrayOfEnum;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static String _findNameToUse(String explicitName, String otherName, boolean toLowerCase) {
/* 248 */     if (explicitName != null) {
/* 249 */       return explicitName;
/*     */     }
/*     */ 
/*     */     
/* 253 */     if (toLowerCase) {
/* 254 */       return otherName.toLowerCase();
/*     */     }
/* 256 */     return otherName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializableString serializedValueFor(Enum<?> key) {
/* 266 */     return this._textual[key.ordinal()];
/*     */   }
/*     */   
/*     */   public Collection<SerializableString> values() {
/* 270 */     return Arrays.asList(this._textual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Enum<?>> enums() {
/* 279 */     return Arrays.asList(this._values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumMap<?, SerializableString> internalMap() {
/* 287 */     EnumMap<?, SerializableString> result = this._asMap;
/* 288 */     if (result == null) {
/*     */       
/* 290 */       Map<Enum<?>, SerializableString> map = new LinkedHashMap<>();
/* 291 */       for (Enum<?> en : this._values) {
/* 292 */         map.put(en, this._textual[en.ordinal()]);
/*     */       }
/* 294 */       this._asMap = result = new EnumMap<>(map);
/*     */     } 
/* 296 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<Enum<?>> getEnumClass() {
/* 302 */     return this._enumClass;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\EnumValues.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */