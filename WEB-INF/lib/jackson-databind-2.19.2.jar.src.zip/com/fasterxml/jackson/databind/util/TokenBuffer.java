/*      */ package com.fasterxml.jackson.databind.util;
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.StreamReadConstraints;
/*      */ import com.fasterxml.jackson.core.StreamReadFeature;
/*      */ import com.fasterxml.jackson.core.StreamWriteCapability;
/*      */ import com.fasterxml.jackson.core.TreeNode;
/*      */ import com.fasterxml.jackson.core.Version;
/*      */ import com.fasterxml.jackson.core.io.NumberInput;
/*      */ import com.fasterxml.jackson.core.json.JsonWriteContext;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.cfg.PackageVersion;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ public class TokenBuffer extends JsonGenerator {
/*   30 */   protected static final int DEFAULT_GENERATOR_FEATURES = JsonGenerator.Feature.collectDefaults();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectCodec _objectCodec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonStreamContext _parentContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _generatorFeatures;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   65 */   protected StreamReadConstraints _streamReadConstraints = StreamReadConstraints.defaults();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _closed;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _hasNativeTypeIds;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _hasNativeObjectIds;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _mayHaveNativeIds;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _forceBigDecimal;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Segment _first;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Segment _last;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _appendAt;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _typeId;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _objectId;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _hasNativeId = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonWriteContext _writeContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer(ObjectCodec codec, boolean hasNativeIds) {
/*  154 */     this._objectCodec = codec;
/*  155 */     this._generatorFeatures = DEFAULT_GENERATOR_FEATURES;
/*  156 */     this._writeContext = JsonWriteContext.createRootContext(null);
/*      */     
/*  158 */     this._first = this._last = new Segment();
/*  159 */     this._appendAt = 0;
/*  160 */     this._hasNativeTypeIds = hasNativeIds;
/*  161 */     this._hasNativeObjectIds = hasNativeIds;
/*      */     
/*  163 */     this._mayHaveNativeIds = (this._hasNativeTypeIds || this._hasNativeObjectIds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer(JsonParser p) {
/*  170 */     this(p, (DeserializationContext)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer(JsonParser p, DeserializationContext ctxt) {
/*  178 */     this._objectCodec = p.getCodec();
/*  179 */     this._streamReadConstraints = p.streamReadConstraints();
/*  180 */     this._parentContext = p.getParsingContext();
/*  181 */     this._generatorFeatures = DEFAULT_GENERATOR_FEATURES;
/*  182 */     this._writeContext = JsonWriteContext.createRootContext(null);
/*      */     
/*  184 */     this._first = this._last = new Segment();
/*  185 */     this._appendAt = 0;
/*  186 */     this._hasNativeTypeIds = p.canReadTypeId();
/*  187 */     this._hasNativeObjectIds = p.canReadObjectId();
/*  188 */     this._mayHaveNativeIds = (this._hasNativeTypeIds || this._hasNativeObjectIds);
/*  189 */     this
/*  190 */       ._forceBigDecimal = (ctxt == null) ? false : ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static TokenBuffer asCopyOfValue(JsonParser p) throws IOException {
/*  207 */     TokenBuffer b = new TokenBuffer(p);
/*  208 */     b.copyCurrentStructure(p);
/*  209 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer overrideParentContext(JsonStreamContext ctxt) {
/*  221 */     this._parentContext = ctxt;
/*  222 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer forceUseOfBigDecimal(boolean b) {
/*  229 */     this._forceBigDecimal = b;
/*  230 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public Version version() {
/*  235 */     return PackageVersion.VERSION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser asParser() {
/*  249 */     return asParser(this._objectCodec);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser asParserOnFirstToken() throws IOException {
/*  263 */     JsonParser p = asParser(this._objectCodec);
/*  264 */     p.nextToken();
/*  265 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser asParser(ObjectCodec codec) {
/*  283 */     return (JsonParser)new Parser(this._first, codec, this._hasNativeTypeIds, this._hasNativeObjectIds, this._parentContext, this._streamReadConstraints);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser asParser(StreamReadConstraints streamReadConstraints) {
/*  292 */     return (JsonParser)new Parser(this._first, this._objectCodec, this._hasNativeTypeIds, this._hasNativeObjectIds, this._parentContext, streamReadConstraints);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser asParser(JsonParser src) {
/*  302 */     Parser p = new Parser(this._first, src.getCodec(), this._hasNativeTypeIds, this._hasNativeObjectIds, this._parentContext, src.streamReadConstraints());
/*  303 */     p.setLocation(src.currentTokenLocation());
/*  304 */     return (JsonParser)p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken firstToken() {
/*  315 */     return this._first.type(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/*  327 */     return (this._appendAt == 0 && this._first == this._last);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer append(TokenBuffer other) throws IOException {
/*  346 */     if (!this._hasNativeTypeIds) {
/*  347 */       this._hasNativeTypeIds = other.canWriteTypeId();
/*      */     }
/*  349 */     if (!this._hasNativeObjectIds) {
/*  350 */       this._hasNativeObjectIds = other.canWriteObjectId();
/*      */     }
/*  352 */     this._mayHaveNativeIds = (this._hasNativeTypeIds || this._hasNativeObjectIds);
/*      */     
/*  354 */     JsonParser p = other.asParser();
/*  355 */     while (p.nextToken() != null) {
/*  356 */       copyCurrentStructure(p);
/*      */     }
/*  358 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serialize(JsonGenerator gen) throws IOException {
/*  373 */     Segment segment = this._first;
/*  374 */     int ptr = -1;
/*      */     
/*  376 */     boolean checkIds = this._mayHaveNativeIds;
/*  377 */     boolean hasIds = (checkIds && segment.hasIds());
/*      */     while (true) {
/*      */       Object ob, n, value;
/*  380 */       if (++ptr >= 16) {
/*  381 */         ptr = 0;
/*  382 */         segment = segment.next();
/*  383 */         if (segment == null)
/*  384 */           break;  hasIds = (checkIds && segment.hasIds());
/*      */       } 
/*  386 */       JsonToken t = segment.type(ptr);
/*  387 */       if (t == null)
/*      */         break; 
/*  389 */       if (hasIds) {
/*  390 */         Object id = segment.findObjectId(ptr);
/*  391 */         if (id != null) {
/*  392 */           gen.writeObjectId(id);
/*      */         }
/*  394 */         id = segment.findTypeId(ptr);
/*  395 */         if (id != null) {
/*  396 */           gen.writeTypeId(id);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  401 */       switch (t) {
/*      */         case INT:
/*  403 */           gen.writeStartObject();
/*      */           continue;
/*      */         case BIG_INTEGER:
/*  406 */           gen.writeEndObject();
/*      */           continue;
/*      */         case null:
/*  409 */           gen.writeStartArray();
/*      */           continue;
/*      */         case null:
/*  412 */           gen.writeEndArray();
/*      */           continue;
/*      */ 
/*      */         
/*      */         case null:
/*  417 */           ob = segment.get(ptr);
/*  418 */           if (ob instanceof SerializableString) {
/*  419 */             gen.writeFieldName((SerializableString)ob); continue;
/*      */           } 
/*  421 */           gen.writeFieldName((String)ob);
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case null:
/*  427 */           ob = segment.get(ptr);
/*  428 */           if (ob instanceof SerializableString) {
/*  429 */             gen.writeString((SerializableString)ob); continue;
/*      */           } 
/*  431 */           gen.writeString((String)ob);
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case null:
/*  437 */           n = segment.get(ptr);
/*  438 */           if (n instanceof Integer) {
/*  439 */             gen.writeNumber(((Integer)n).intValue()); continue;
/*  440 */           }  if (n instanceof BigInteger) {
/*  441 */             gen.writeNumber((BigInteger)n); continue;
/*  442 */           }  if (n instanceof Long) {
/*  443 */             gen.writeNumber(((Long)n).longValue()); continue;
/*  444 */           }  if (n instanceof Short) {
/*  445 */             gen.writeNumber(((Short)n).shortValue()); continue;
/*      */           } 
/*  447 */           gen.writeNumber(((Number)n).intValue());
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case null:
/*  453 */           n = segment.get(ptr);
/*  454 */           if (n instanceof Double) {
/*  455 */             gen.writeNumber(((Double)n).doubleValue()); continue;
/*  456 */           }  if (n instanceof BigDecimal) {
/*  457 */             gen.writeNumber((BigDecimal)n); continue;
/*  458 */           }  if (n instanceof Float) {
/*  459 */             gen.writeNumber(((Float)n).floatValue()); continue;
/*  460 */           }  if (n == null) {
/*  461 */             gen.writeNull(); continue;
/*  462 */           }  if (n instanceof String) {
/*  463 */             gen.writeNumber((String)n); continue;
/*      */           } 
/*  465 */           _reportError(String.format("Unrecognized value type for VALUE_NUMBER_FLOAT: %s, cannot serialize", new Object[] { n
/*      */                   
/*  467 */                   .getClass().getName() }));
/*      */           continue;
/*      */ 
/*      */         
/*      */         case null:
/*  472 */           gen.writeBoolean(true);
/*      */           continue;
/*      */         case null:
/*  475 */           gen.writeBoolean(false);
/*      */           continue;
/*      */         case null:
/*  478 */           gen.writeNull();
/*      */           continue;
/*      */         
/*      */         case null:
/*  482 */           value = segment.get(ptr);
/*      */ 
/*      */ 
/*      */           
/*  486 */           if (value instanceof RawValue) {
/*  487 */             ((RawValue)value).serialize(gen); continue;
/*  488 */           }  if (value instanceof com.fasterxml.jackson.databind.JsonSerializable) {
/*  489 */             gen.writeObject(value); continue;
/*      */           } 
/*  491 */           gen.writeEmbeddedObject(value);
/*      */           continue;
/*      */       } 
/*      */ 
/*      */       
/*  496 */       throw new RuntimeException("Internal error: should never end up through this code path");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  508 */     if (!p.hasToken(JsonToken.FIELD_NAME)) {
/*  509 */       copyCurrentStructure(p);
/*  510 */       return this;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  516 */     writeStartObject(); JsonToken t;
/*      */     do {
/*  518 */       copyCurrentStructure(p);
/*  519 */     } while ((t = p.nextToken()) == JsonToken.FIELD_NAME);
/*  520 */     if (t != JsonToken.END_OBJECT) {
/*  521 */       ctxt.reportWrongTokenException(TokenBuffer.class, JsonToken.END_OBJECT, "Expected END_OBJECT after copying contents of a JsonParser into TokenBuffer, got " + t, new Object[0]);
/*      */     }
/*      */ 
/*      */     
/*  525 */     writeEndObject();
/*  526 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  534 */     int MAX_COUNT = 100;
/*      */     
/*  536 */     StringBuilder sb = new StringBuilder();
/*  537 */     sb.append("[TokenBuffer: ");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  544 */     JsonParser jp = asParser();
/*  545 */     int count = 0;
/*  546 */     boolean hasNativeIds = (this._hasNativeTypeIds || this._hasNativeObjectIds);
/*      */ 
/*      */     
/*      */     while (true) {
/*      */       try {
/*  551 */         JsonToken t = jp.nextToken();
/*  552 */         if (t == null)
/*      */           break; 
/*  554 */         if (hasNativeIds) {
/*  555 */           _appendNativeIds(sb);
/*      */         }
/*      */         
/*  558 */         if (count < 100) {
/*  559 */           if (count > 0) {
/*  560 */             sb.append(", ");
/*      */           }
/*  562 */           sb.append(t.toString());
/*  563 */           if (t == JsonToken.FIELD_NAME) {
/*  564 */             sb.append('(');
/*  565 */             sb.append(jp.currentName());
/*  566 */             sb.append(')');
/*      */           } 
/*      */         } 
/*  569 */       } catch (IOException ioe) {
/*  570 */         throw new IllegalStateException(ioe);
/*      */       } 
/*  572 */       count++;
/*      */     } 
/*      */     
/*  575 */     if (count >= 100) {
/*  576 */       sb.append(" ... (truncated ").append(count - 100).append(" entries)");
/*      */     }
/*  578 */     sb.append(']');
/*  579 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _appendNativeIds(StringBuilder sb) {
/*  584 */     Object objectId = this._last.findObjectId(this._appendAt - 1);
/*  585 */     if (objectId != null) {
/*  586 */       sb.append("[objectId=").append(String.valueOf(objectId)).append(']');
/*      */     }
/*  588 */     Object typeId = this._last.findTypeId(this._appendAt - 1);
/*  589 */     if (typeId != null) {
/*  590 */       sb.append("[typeId=").append(String.valueOf(typeId)).append(']');
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator enable(JsonGenerator.Feature f) {
/*  602 */     this._generatorFeatures |= f.getMask();
/*  603 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonGenerator disable(JsonGenerator.Feature f) {
/*  608 */     this._generatorFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*  609 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(JsonGenerator.Feature f) {
/*  616 */     return ((this._generatorFeatures & f.getMask()) != 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getFeatureMask() {
/*  621 */     return this._generatorFeatures;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonGenerator setFeatureMask(int mask) {
/*  628 */     this._generatorFeatures = mask;
/*  629 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonGenerator overrideStdFeatures(int values, int mask) {
/*  634 */     int oldState = getFeatureMask();
/*  635 */     this._generatorFeatures = oldState & (mask ^ 0xFFFFFFFF) | values & mask;
/*  636 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator useDefaultPrettyPrinter() {
/*  642 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonGenerator setCodec(ObjectCodec oc) {
/*  647 */     this._objectCodec = oc;
/*  648 */     return this;
/*      */   }
/*      */   
/*      */   public ObjectCodec getCodec() {
/*  652 */     return this._objectCodec;
/*      */   }
/*      */   public final JsonWriteContext getOutputContext() {
/*  655 */     return this._writeContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canWriteBinaryNatively() {
/*  668 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JacksonFeatureSet<StreamWriteCapability> getWriteCapabilities() {
/*  677 */     return DEFAULT_WRITE_CAPABILITIES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void flush() throws IOException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws IOException {
/*  691 */     this._closed = true;
/*      */   }
/*      */   
/*      */   public boolean isClosed() {
/*  695 */     return this._closed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeStartArray() throws IOException {
/*  706 */     this._writeContext.writeValue();
/*  707 */     _appendStartMarker(JsonToken.START_ARRAY);
/*  708 */     this._writeContext = this._writeContext.createChildArrayContext();
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object forValue) throws IOException {
/*  713 */     this._writeContext.writeValue();
/*  714 */     _appendStartMarker(JsonToken.START_ARRAY);
/*  715 */     this._writeContext = this._writeContext.createChildArrayContext(forValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object forValue, int size) throws IOException {
/*  720 */     this._writeContext.writeValue();
/*  721 */     _appendStartMarker(JsonToken.START_ARRAY);
/*  722 */     this._writeContext = this._writeContext.createChildArrayContext(forValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeEndArray() throws IOException {
/*  728 */     _appendEndMarker(JsonToken.END_ARRAY);
/*      */     
/*  730 */     JsonWriteContext c = this._writeContext.getParent();
/*  731 */     if (c != null) {
/*  732 */       this._writeContext = c;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeStartObject() throws IOException {
/*  739 */     this._writeContext.writeValue();
/*  740 */     _appendStartMarker(JsonToken.START_OBJECT);
/*  741 */     this._writeContext = this._writeContext.createChildObjectContext();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue) throws IOException {
/*  747 */     this._writeContext.writeValue();
/*  748 */     _appendStartMarker(JsonToken.START_OBJECT);
/*  749 */     this._writeContext = this._writeContext.createChildObjectContext(forValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue, int size) throws IOException {
/*  755 */     this._writeContext.writeValue();
/*  756 */     _appendStartMarker(JsonToken.START_OBJECT);
/*  757 */     this._writeContext = this._writeContext.createChildObjectContext(forValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeEndObject() throws IOException {
/*  763 */     _appendEndMarker(JsonToken.END_OBJECT);
/*      */     
/*  765 */     JsonWriteContext c = this._writeContext.getParent();
/*  766 */     if (c != null) {
/*  767 */       this._writeContext = c;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeFieldName(String name) throws IOException {
/*  774 */     this._writeContext.writeFieldName(name);
/*  775 */     _appendFieldName(name);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldName(SerializableString name) throws IOException {
/*  781 */     this._writeContext.writeFieldName(name.getValue());
/*  782 */     _appendFieldName(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(String text) throws IOException {
/*  793 */     if (text == null) {
/*  794 */       writeNull();
/*      */     } else {
/*  796 */       _appendValue(JsonToken.VALUE_STRING, text);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeString(char[] text, int offset, int len) throws IOException {
/*  802 */     writeString(new String(text, offset, len));
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeString(SerializableString text) throws IOException {
/*  807 */     if (text == null) {
/*  808 */       writeNull();
/*      */     } else {
/*  810 */       _appendValue(JsonToken.VALUE_STRING, text);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(Reader reader, int len) throws IOException {
/*  818 */     if (reader == null) {
/*  819 */       _reportError("null reader");
/*      */     }
/*  821 */     int toRead = (len >= 0) ? len : Integer.MAX_VALUE;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  826 */     char[] buf = new char[1000];
/*  827 */     StringBuilder sb = new StringBuilder(1000);
/*  828 */     while (toRead > 0) {
/*  829 */       int toReadNow = Math.min(toRead, buf.length);
/*  830 */       int numRead = reader.read(buf, 0, toReadNow);
/*  831 */       if (numRead <= 0) {
/*      */         break;
/*      */       }
/*  834 */       sb.append(buf, 0, numRead);
/*  835 */       toRead -= numRead;
/*      */     } 
/*  837 */     if (toRead > 0 && len >= 0) {
/*  838 */       _reportError("Was not able to read enough from reader");
/*      */     }
/*  840 */     _appendValue(JsonToken.VALUE_STRING, sb.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawUTF8String(byte[] text, int offset, int length) throws IOException {
/*  847 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeUTF8String(byte[] text, int offset, int length) throws IOException {
/*  854 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeRaw(String text) throws IOException {
/*  859 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeRaw(String text, int offset, int len) throws IOException {
/*  864 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeRaw(SerializableString text) throws IOException {
/*  869 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeRaw(char[] text, int offset, int len) throws IOException {
/*  874 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeRaw(char c) throws IOException {
/*  879 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeRawValue(String text) throws IOException {
/*  884 */     _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, new RawValue(text));
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeRawValue(String text, int offset, int len) throws IOException {
/*  889 */     if (offset > 0 || len != text.length()) {
/*  890 */       text = text.substring(offset, offset + len);
/*      */     }
/*  892 */     _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, new RawValue(text));
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeRawValue(char[] text, int offset, int len) throws IOException {
/*  897 */     _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, new String(text, offset, len));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(short i) throws IOException {
/*  908 */     _appendValue(JsonToken.VALUE_NUMBER_INT, Short.valueOf(i));
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNumber(int i) throws IOException {
/*  913 */     _appendValue(JsonToken.VALUE_NUMBER_INT, Integer.valueOf(i));
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNumber(long l) throws IOException {
/*  918 */     _appendValue(JsonToken.VALUE_NUMBER_INT, Long.valueOf(l));
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNumber(double d) throws IOException {
/*  923 */     _appendValue(JsonToken.VALUE_NUMBER_FLOAT, Double.valueOf(d));
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNumber(float f) throws IOException {
/*  928 */     _appendValue(JsonToken.VALUE_NUMBER_FLOAT, Float.valueOf(f));
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNumber(BigDecimal dec) throws IOException {
/*  933 */     if (dec == null) {
/*  934 */       writeNull();
/*      */     } else {
/*  936 */       _appendValue(JsonToken.VALUE_NUMBER_FLOAT, dec);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNumber(BigInteger v) throws IOException {
/*  942 */     if (v == null) {
/*  943 */       writeNull();
/*      */     } else {
/*  945 */       _appendValue(JsonToken.VALUE_NUMBER_INT, v);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(String encodedValue) throws IOException {
/*  954 */     _appendValue(JsonToken.VALUE_NUMBER_FLOAT, encodedValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(String encodedValue, boolean isInteger) throws IOException {
/*  973 */     _appendValue(isInteger ? JsonToken.VALUE_NUMBER_INT : JsonToken.VALUE_NUMBER_FLOAT, encodedValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeLazyInteger(Object encodedValue) throws IOException {
/*  979 */     _appendValue(JsonToken.VALUE_NUMBER_INT, encodedValue);
/*      */   }
/*      */   
/*      */   private void writeLazyDecimal(Object encodedValue) throws IOException {
/*  983 */     _appendValue(JsonToken.VALUE_NUMBER_FLOAT, encodedValue);
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeBoolean(boolean state) throws IOException {
/*  988 */     _appendValue(state ? JsonToken.VALUE_TRUE : JsonToken.VALUE_FALSE);
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNull() throws IOException {
/*  993 */     _appendValue(JsonToken.VALUE_NULL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeObject(Object value) throws IOException {
/* 1005 */     if (value == null) {
/* 1006 */       writeNull();
/*      */       return;
/*      */     } 
/* 1009 */     Class<?> raw = value.getClass();
/* 1010 */     if (raw == byte[].class || value instanceof RawValue) {
/* 1011 */       _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, value);
/*      */       return;
/*      */     } 
/* 1014 */     if (this._objectCodec == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1019 */       _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, value);
/*      */     } else {
/* 1021 */       this._objectCodec.writeValue(this, value);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeTree(TreeNode node) throws IOException {
/* 1028 */     if (node == null) {
/* 1029 */       writeNull();
/*      */       
/*      */       return;
/*      */     } 
/* 1033 */     if (this._objectCodec == null) {
/*      */       
/* 1035 */       _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, node);
/*      */     } else {
/* 1037 */       this._objectCodec.writeTree(this, node);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBinary(Base64Variant b64variant, byte[] data, int offset, int len) throws IOException {
/* 1056 */     byte[] copy = new byte[len];
/* 1057 */     System.arraycopy(data, offset, copy, 0, len);
/* 1058 */     writeObject(copy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int writeBinary(Base64Variant b64variant, InputStream data, int dataLength) {
/* 1069 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canWriteTypeId() {
/* 1080 */     return this._hasNativeTypeIds;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean canWriteObjectId() {
/* 1085 */     return this._hasNativeObjectIds;
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeTypeId(Object id) {
/* 1090 */     this._typeId = id;
/* 1091 */     this._hasNativeId = true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeObjectId(Object id) {
/* 1096 */     this._objectId = id;
/* 1097 */     this._hasNativeId = true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeEmbeddedObject(Object object) throws IOException {
/* 1102 */     _appendValue(JsonToken.VALUE_EMBEDDED_OBJECT, object);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyCurrentEvent(JsonParser p) throws IOException {
/* 1114 */     if (this._mayHaveNativeIds) {
/* 1115 */       _checkNativeIds(p);
/*      */     }
/* 1117 */     switch (p.currentToken()) {
/*      */       case INT:
/* 1119 */         writeStartObject();
/*      */         return;
/*      */       case BIG_INTEGER:
/* 1122 */         writeEndObject();
/*      */         return;
/*      */       case null:
/* 1125 */         writeStartArray();
/*      */         return;
/*      */       case null:
/* 1128 */         writeEndArray();
/*      */         return;
/*      */       case null:
/* 1131 */         writeFieldName(p.currentName());
/*      */         return;
/*      */       case null:
/* 1134 */         if (p.hasTextCharacters()) {
/* 1135 */           writeString(p.getTextCharacters(), p.getTextOffset(), p.getTextLength());
/*      */         } else {
/* 1137 */           writeString(p.getText());
/*      */         } 
/*      */         return;
/*      */       case null:
/* 1141 */         switch (p.getNumberType()) {
/*      */           case INT:
/* 1143 */             writeNumber(p.getIntValue());
/*      */             return;
/*      */           case BIG_INTEGER:
/* 1146 */             writeLazyInteger(p.getNumberValueDeferred());
/*      */             return;
/*      */         } 
/* 1149 */         writeNumber(p.getLongValue());
/*      */         return;
/*      */       
/*      */       case null:
/* 1153 */         writeLazyDecimal(p.getNumberValueDeferred());
/*      */         return;
/*      */       case null:
/* 1156 */         writeBoolean(true);
/*      */         return;
/*      */       case null:
/* 1159 */         writeBoolean(false);
/*      */         return;
/*      */       case null:
/* 1162 */         writeNull();
/*      */         return;
/*      */       case null:
/* 1165 */         writeObject(p.getEmbeddedObject());
/*      */         return;
/*      */     } 
/* 1168 */     throw new RuntimeException("Internal error: unexpected token: " + p.currentToken());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyCurrentStructure(JsonParser p) throws IOException {
/* 1175 */     JsonToken t = p.currentToken();
/*      */ 
/*      */     
/* 1178 */     if (t == JsonToken.FIELD_NAME) {
/* 1179 */       if (this._mayHaveNativeIds) {
/* 1180 */         _checkNativeIds(p);
/*      */       }
/* 1182 */       writeFieldName(p.currentName());
/* 1183 */       t = p.nextToken();
/*      */     }
/* 1185 */     else if (t == null) {
/*      */       
/* 1187 */       throw new JsonEOFException(p, null, "Unexpected end-of-input");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1193 */     switch (t) {
/*      */       case null:
/* 1195 */         if (this._mayHaveNativeIds) {
/* 1196 */           _checkNativeIds(p);
/*      */         }
/* 1198 */         writeStartArray();
/* 1199 */         _copyBufferContents(p);
/*      */         return;
/*      */       case INT:
/* 1202 */         if (this._mayHaveNativeIds) {
/* 1203 */           _checkNativeIds(p);
/*      */         }
/* 1205 */         writeStartObject();
/* 1206 */         _copyBufferContents(p);
/*      */         return;
/*      */       case null:
/* 1209 */         writeEndArray();
/*      */         return;
/*      */       case BIG_INTEGER:
/* 1212 */         writeEndObject();
/*      */         return;
/*      */     } 
/* 1215 */     _copyBufferValue(p, t);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _copyBufferContents(JsonParser p) throws IOException {
/* 1221 */     int depth = 1;
/*      */     
/*      */     JsonToken t;
/* 1224 */     while ((t = p.nextToken()) != null) {
/* 1225 */       switch (t) {
/*      */         case null:
/* 1227 */           if (this._mayHaveNativeIds) {
/* 1228 */             _checkNativeIds(p);
/*      */           }
/* 1230 */           writeFieldName(p.currentName());
/*      */           continue;
/*      */         
/*      */         case null:
/* 1234 */           if (this._mayHaveNativeIds) {
/* 1235 */             _checkNativeIds(p);
/*      */           }
/* 1237 */           writeStartArray();
/* 1238 */           depth++;
/*      */           continue;
/*      */         
/*      */         case INT:
/* 1242 */           if (this._mayHaveNativeIds) {
/* 1243 */             _checkNativeIds(p);
/*      */           }
/* 1245 */           writeStartObject();
/* 1246 */           depth++;
/*      */           continue;
/*      */         
/*      */         case null:
/* 1250 */           writeEndArray();
/* 1251 */           if (--depth == 0) {
/*      */             return;
/*      */           }
/*      */           continue;
/*      */         case BIG_INTEGER:
/* 1256 */           writeEndObject();
/* 1257 */           if (--depth == 0) {
/*      */             return;
/*      */           }
/*      */           continue;
/*      */       } 
/*      */       
/* 1263 */       _copyBufferValue(p, t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _copyBufferValue(JsonParser p, JsonToken t) throws IOException {
/* 1271 */     if (this._mayHaveNativeIds) {
/* 1272 */       _checkNativeIds(p);
/*      */     }
/* 1274 */     switch (t) {
/*      */       case null:
/* 1276 */         if (p.hasTextCharacters()) {
/* 1277 */           writeString(p.getTextCharacters(), p.getTextOffset(), p.getTextLength());
/*      */         } else {
/* 1279 */           writeString(p.getText());
/*      */         } 
/*      */         return;
/*      */       case null:
/* 1283 */         switch (p.getNumberType()) {
/*      */           case INT:
/* 1285 */             writeNumber(p.getIntValue());
/*      */             return;
/*      */           case BIG_INTEGER:
/* 1288 */             writeLazyInteger(p.getNumberValueDeferred());
/*      */             return;
/*      */         } 
/* 1291 */         writeNumber(p.getLongValue());
/*      */         return;
/*      */       
/*      */       case null:
/* 1295 */         writeLazyDecimal(p.getNumberValueDeferred());
/*      */         return;
/*      */       case null:
/* 1298 */         writeBoolean(true);
/*      */         return;
/*      */       case null:
/* 1301 */         writeBoolean(false);
/*      */         return;
/*      */       case null:
/* 1304 */         writeNull();
/*      */         return;
/*      */       case null:
/* 1307 */         writeObject(p.getEmbeddedObject());
/*      */         return;
/*      */     } 
/* 1310 */     throw new RuntimeException("Internal error: unexpected token: " + t);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _checkNativeIds(JsonParser p) throws IOException {
/* 1316 */     if ((this._typeId = p.getTypeId()) != null) {
/* 1317 */       this._hasNativeId = true;
/*      */     }
/* 1319 */     if ((this._objectId = p.getObjectId()) != null) {
/* 1320 */       this._hasNativeId = true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _appendValue(JsonToken type) {
/*      */     Segment next;
/* 1373 */     this._writeContext.writeValue();
/*      */     
/* 1375 */     if (this._hasNativeId) {
/* 1376 */       next = this._last.append(this._appendAt, type, this._objectId, this._typeId);
/*      */     } else {
/* 1378 */       next = this._last.append(this._appendAt, type);
/*      */     } 
/* 1380 */     if (next == null) {
/* 1381 */       this._appendAt++;
/*      */     } else {
/* 1383 */       this._last = next;
/* 1384 */       this._appendAt = 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _appendValue(JsonToken type, Object value) {
/*      */     Segment next;
/* 1396 */     this._writeContext.writeValue();
/*      */     
/* 1398 */     if (this._hasNativeId) {
/* 1399 */       next = this._last.append(this._appendAt, type, value, this._objectId, this._typeId);
/*      */     } else {
/* 1401 */       next = this._last.append(this._appendAt, type, value);
/*      */     } 
/* 1403 */     if (next == null) {
/* 1404 */       this._appendAt++;
/*      */     } else {
/* 1406 */       this._last = next;
/* 1407 */       this._appendAt = 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _appendFieldName(Object value) {
/*      */     Segment next;
/* 1421 */     if (this._hasNativeId) {
/* 1422 */       next = this._last.append(this._appendAt, JsonToken.FIELD_NAME, value, this._objectId, this._typeId);
/*      */     } else {
/* 1424 */       next = this._last.append(this._appendAt, JsonToken.FIELD_NAME, value);
/*      */     } 
/* 1426 */     if (next == null) {
/* 1427 */       this._appendAt++;
/*      */     } else {
/* 1429 */       this._last = next;
/* 1430 */       this._appendAt = 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _appendStartMarker(JsonToken type) {
/*      */     Segment next;
/* 1442 */     if (this._hasNativeId) {
/* 1443 */       next = this._last.append(this._appendAt, type, this._objectId, this._typeId);
/*      */     } else {
/* 1445 */       next = this._last.append(this._appendAt, type);
/*      */     } 
/* 1447 */     if (next == null) {
/* 1448 */       this._appendAt++;
/*      */     } else {
/* 1450 */       this._last = next;
/* 1451 */       this._appendAt = 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _appendEndMarker(JsonToken type) {
/* 1463 */     Segment next = this._last.append(this._appendAt, type);
/* 1464 */     if (next == null) {
/* 1465 */       this._appendAt++;
/*      */     } else {
/* 1467 */       this._last = next;
/* 1468 */       this._appendAt = 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _reportUnsupportedOperation() {
/* 1474 */     throw new UnsupportedOperationException("Called operation not supported for TokenBuffer");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final class Parser
/*      */     extends ParserMinimalBase
/*      */   {
/*      */     protected ObjectCodec _codec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final boolean _hasNativeTypeIds;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final boolean _hasNativeObjectIds;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final boolean _hasNativeIds;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected TokenBuffer.Segment _segment;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected int _segmentPtr;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected TokenBufferReadContext _parsingContext;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected boolean _closed;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected transient ByteArrayBuilder _byteBuilder;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1532 */     protected JsonLocation _location = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public Parser(TokenBuffer.Segment firstSeg, ObjectCodec codec, boolean hasNativeTypeIds, boolean hasNativeObjectIds) {
/* 1544 */       this(firstSeg, codec, hasNativeTypeIds, hasNativeObjectIds, (JsonStreamContext)null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public Parser(TokenBuffer.Segment firstSeg, ObjectCodec codec, boolean hasNativeTypeIds, boolean hasNativeObjectIds, JsonStreamContext parentContext) {
/* 1552 */       this(firstSeg, codec, hasNativeTypeIds, hasNativeObjectIds, parentContext, StreamReadConstraints.defaults());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Parser(TokenBuffer.Segment firstSeg, ObjectCodec codec, boolean hasNativeTypeIds, boolean hasNativeObjectIds, JsonStreamContext parentContext, StreamReadConstraints streamReadConstraints) {
/* 1562 */       super(streamReadConstraints);
/* 1563 */       this._segment = firstSeg;
/* 1564 */       this._segmentPtr = -1;
/* 1565 */       this._codec = codec;
/* 1566 */       this._parsingContext = TokenBufferReadContext.createRootContext(parentContext);
/* 1567 */       this._hasNativeTypeIds = hasNativeTypeIds;
/* 1568 */       this._hasNativeObjectIds = hasNativeObjectIds;
/* 1569 */       this._hasNativeIds = (hasNativeTypeIds || hasNativeObjectIds);
/*      */     }
/*      */     
/*      */     public void setLocation(JsonLocation l) {
/* 1573 */       this._location = l;
/*      */     }
/*      */     
/*      */     public ObjectCodec getCodec() {
/* 1577 */       return this._codec;
/*      */     }
/*      */     public void setCodec(ObjectCodec c) {
/* 1580 */       this._codec = c;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Version version() {
/* 1590 */       return PackageVersion.VERSION;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public JacksonFeatureSet<StreamReadCapability> getReadCapabilities() {
/* 1599 */       return DEFAULT_READ_CAPABILITIES;
/*      */     }
/*      */ 
/*      */     
/*      */     public StreamReadConstraints streamReadConstraints() {
/* 1604 */       return this._streamReadConstraints;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public JsonToken peekNextToken() throws IOException {
/* 1616 */       if (this._closed) return null; 
/* 1617 */       TokenBuffer.Segment seg = this._segment;
/* 1618 */       int ptr = this._segmentPtr + 1;
/* 1619 */       if (ptr >= 16) {
/* 1620 */         ptr = 0;
/* 1621 */         seg = (seg == null) ? null : seg.next();
/*      */       } 
/* 1623 */       return (seg == null) ? null : seg.type(ptr);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() throws IOException {
/* 1634 */       if (!this._closed) {
/* 1635 */         this._closed = true;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public JsonToken nextToken() throws IOException {
/* 1649 */       if (this._closed || this._segment == null) return null;
/*      */ 
/*      */       
/* 1652 */       if (++this._segmentPtr >= 16) {
/* 1653 */         this._segmentPtr = 0;
/* 1654 */         this._segment = this._segment.next();
/* 1655 */         if (this._segment == null) {
/* 1656 */           return null;
/*      */         }
/*      */       } 
/* 1659 */       _updateToken(this._segment.type(this._segmentPtr));
/*      */       
/* 1661 */       if (this._currToken == JsonToken.FIELD_NAME) {
/* 1662 */         Object ob = _currentObject();
/* 1663 */         String name = (ob instanceof String) ? (String)ob : ob.toString();
/* 1664 */         this._parsingContext.setCurrentName(name);
/* 1665 */       } else if (this._currToken == JsonToken.START_OBJECT) {
/* 1666 */         this._parsingContext = this._parsingContext.createChildObjectContext();
/* 1667 */       } else if (this._currToken == JsonToken.START_ARRAY) {
/* 1668 */         this._parsingContext = this._parsingContext.createChildArrayContext();
/* 1669 */       } else if (this._currToken == JsonToken.END_OBJECT || this._currToken == JsonToken.END_ARRAY) {
/*      */ 
/*      */         
/* 1672 */         this._parsingContext = this._parsingContext.parentOrCopy();
/*      */       } else {
/* 1674 */         this._parsingContext.updateForValue();
/*      */       } 
/* 1676 */       return this._currToken;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String nextFieldName() throws IOException {
/* 1683 */       if (this._closed || this._segment == null) {
/* 1684 */         return null;
/*      */       }
/*      */       
/* 1687 */       int ptr = this._segmentPtr + 1;
/* 1688 */       if (ptr < 16 && this._segment.type(ptr) == JsonToken.FIELD_NAME) {
/* 1689 */         this._segmentPtr = ptr;
/* 1690 */         _updateToken(JsonToken.FIELD_NAME);
/* 1691 */         Object ob = this._segment.get(ptr);
/* 1692 */         String name = (ob instanceof String) ? (String)ob : ob.toString();
/* 1693 */         this._parsingContext.setCurrentName(name);
/* 1694 */         return name;
/*      */       } 
/* 1696 */       return (nextToken() == JsonToken.FIELD_NAME) ? currentName() : null;
/*      */     }
/*      */     
/*      */     public boolean isClosed() {
/* 1700 */       return this._closed;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public JsonStreamContext getParsingContext() {
/* 1709 */       return this._parsingContext;
/*      */     }
/*      */     
/*      */     public JsonLocation currentLocation() {
/* 1713 */       return (this._location == null) ? JsonLocation.NA : this._location;
/*      */     }
/*      */     
/*      */     public JsonLocation currentTokenLocation() {
/* 1717 */       return currentLocation();
/*      */     }
/*      */     @Deprecated
/*      */     public JsonLocation getTokenLocation() {
/* 1721 */       return currentTokenLocation();
/*      */     }
/*      */     @Deprecated
/*      */     public JsonLocation getCurrentLocation() {
/* 1725 */       return currentLocation();
/*      */     }
/*      */ 
/*      */     
/*      */     public String currentName() {
/* 1730 */       if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/* 1731 */         JsonStreamContext parent = this._parsingContext.getParent();
/* 1732 */         return parent.getCurrentName();
/*      */       } 
/* 1734 */       return this._parsingContext.getCurrentName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void overrideCurrentName(String name) {
/* 1741 */       JsonStreamContext ctxt = this._parsingContext;
/* 1742 */       if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/* 1743 */         ctxt = ctxt.getParent();
/*      */       }
/* 1745 */       if (ctxt instanceof TokenBufferReadContext) {
/*      */         try {
/* 1747 */           ((TokenBufferReadContext)ctxt).setCurrentName(name);
/* 1748 */         } catch (IOException e) {
/* 1749 */           throw new RuntimeException(e);
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*      */     @Deprecated
/*      */     public String getCurrentName() {
/* 1756 */       return currentName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getText() {
/* 1768 */       if (this._currToken == JsonToken.VALUE_STRING || this._currToken == JsonToken.FIELD_NAME) {
/*      */         
/* 1770 */         Object ob = _currentObject();
/* 1771 */         if (ob instanceof String) {
/* 1772 */           return (String)ob;
/*      */         }
/* 1774 */         return ClassUtil.nullOrToString(ob);
/*      */       } 
/* 1776 */       if (this._currToken == null) {
/* 1777 */         return null;
/*      */       }
/* 1779 */       switch (this._currToken) {
/*      */         case null:
/*      */         case null:
/* 1782 */           return ClassUtil.nullOrToString(_currentObject());
/*      */       } 
/* 1784 */       return this._currToken.asString();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public char[] getTextCharacters() {
/* 1790 */       String str = getText();
/* 1791 */       return (str == null) ? null : str.toCharArray();
/*      */     }
/*      */ 
/*      */     
/*      */     public int getTextLength() {
/* 1796 */       String str = getText();
/* 1797 */       return (str == null) ? 0 : str.length();
/*      */     }
/*      */     
/*      */     public int getTextOffset() {
/* 1801 */       return 0;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean hasTextCharacters() {
/* 1806 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isNaN() {
/* 1818 */       if (this._currToken == JsonToken.VALUE_NUMBER_FLOAT) {
/* 1819 */         Object value = _currentObject();
/* 1820 */         if (value instanceof Double) {
/* 1821 */           double v = ((Double)value).doubleValue();
/* 1822 */           return !Double.isFinite(v);
/*      */         } 
/* 1824 */         if (value instanceof Float) {
/* 1825 */           float v = ((Float)value).floatValue();
/* 1826 */           return !Double.isFinite(v);
/*      */         } 
/*      */       } 
/* 1829 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public BigInteger getBigIntegerValue() throws IOException {
/* 1835 */       Number n = getNumberValue(true);
/* 1836 */       if (n instanceof BigInteger)
/* 1837 */         return (BigInteger)n; 
/* 1838 */       if (n instanceof BigDecimal) {
/* 1839 */         BigDecimal bd = (BigDecimal)n;
/* 1840 */         streamReadConstraints().validateBigIntegerScale(bd.scale());
/* 1841 */         return bd.toBigInteger();
/*      */       } 
/*      */       
/* 1844 */       return BigInteger.valueOf(n.longValue());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public BigDecimal getDecimalValue() throws IOException {
/* 1850 */       Number n = getNumberValue(true);
/* 1851 */       if (n instanceof BigDecimal)
/* 1852 */         return (BigDecimal)n; 
/* 1853 */       if (n instanceof Integer)
/* 1854 */         return BigDecimal.valueOf(n.intValue()); 
/* 1855 */       if (n instanceof Long)
/* 1856 */         return BigDecimal.valueOf(n.longValue()); 
/* 1857 */       if (n instanceof BigInteger) {
/* 1858 */         return new BigDecimal((BigInteger)n);
/*      */       }
/*      */       
/* 1861 */       return BigDecimal.valueOf(n.doubleValue());
/*      */     }
/*      */ 
/*      */     
/*      */     public double getDoubleValue() throws IOException {
/* 1866 */       return getNumberValue().doubleValue();
/*      */     }
/*      */ 
/*      */     
/*      */     public float getFloatValue() throws IOException {
/* 1871 */       return getNumberValue().floatValue();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int getIntValue() throws IOException {
/* 1877 */       Number n = getNumberValue(false);
/* 1878 */       if (n instanceof Integer || _smallerThanInt(n)) {
/* 1879 */         return n.intValue();
/*      */       }
/* 1881 */       return _convertNumberToInt(n);
/*      */     }
/*      */ 
/*      */     
/*      */     public long getLongValue() throws IOException {
/* 1886 */       Number n = getNumberValue(false);
/* 1887 */       if (n instanceof Long || _smallerThanLong(n)) {
/* 1888 */         return n.longValue();
/*      */       }
/* 1890 */       return _convertNumberToLong(n);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public JsonParser.NumberType getNumberType() throws IOException {
/* 1896 */       Object n = getNumberValueDeferred();
/* 1897 */       if (n instanceof Integer) return JsonParser.NumberType.INT; 
/* 1898 */       if (n instanceof Long) return JsonParser.NumberType.LONG; 
/* 1899 */       if (n instanceof Double) return JsonParser.NumberType.DOUBLE; 
/* 1900 */       if (n instanceof BigDecimal) return JsonParser.NumberType.BIG_DECIMAL; 
/* 1901 */       if (n instanceof BigInteger) return JsonParser.NumberType.BIG_INTEGER; 
/* 1902 */       if (n instanceof Float) return JsonParser.NumberType.FLOAT; 
/* 1903 */       if (n instanceof Short) return JsonParser.NumberType.INT; 
/* 1904 */       if (n instanceof String) {
/* 1905 */         return (this._currToken == JsonToken.VALUE_NUMBER_FLOAT) ? JsonParser.NumberType.BIG_DECIMAL : JsonParser.NumberType.BIG_INTEGER;
/*      */       }
/*      */       
/* 1908 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public JsonParser.NumberTypeFP getNumberTypeFP() throws IOException {
/* 1914 */       if (this._currToken == JsonToken.VALUE_NUMBER_FLOAT) {
/* 1915 */         Object n = _currentObject();
/* 1916 */         if (n instanceof Double) return JsonParser.NumberTypeFP.DOUBLE64; 
/* 1917 */         if (n instanceof BigDecimal) return JsonParser.NumberTypeFP.BIG_DECIMAL; 
/* 1918 */         if (n instanceof Float) return JsonParser.NumberTypeFP.FLOAT32; 
/*      */       } 
/* 1920 */       return JsonParser.NumberTypeFP.UNKNOWN;
/*      */     }
/*      */ 
/*      */     
/*      */     public final Number getNumberValue() throws IOException {
/* 1925 */       return getNumberValue(false);
/*      */     }
/*      */ 
/*      */     
/*      */     public Object getNumberValueDeferred() throws IOException {
/* 1930 */       _checkIsNumber();
/* 1931 */       return _currentObject();
/*      */     }
/*      */     
/*      */     private Number getNumberValue(boolean preferBigNumbers) throws IOException {
/* 1935 */       _checkIsNumber();
/* 1936 */       Object value = _currentObject();
/* 1937 */       if (value instanceof Number) {
/* 1938 */         return (Number)value;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1943 */       if (value instanceof String) {
/* 1944 */         String str = (String)value;
/* 1945 */         int len = str.length();
/* 1946 */         if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*      */ 
/*      */           
/* 1949 */           if (preferBigNumbers || len >= 19)
/*      */           {
/*      */ 
/*      */ 
/*      */             
/* 1954 */             return NumberInput.parseBigInteger(str, isEnabled(StreamReadFeature.USE_FAST_BIG_NUMBER_PARSER));
/*      */           }
/*      */ 
/*      */           
/* 1958 */           if (len >= 10) {
/* 1959 */             return Long.valueOf(NumberInput.parseLong(str));
/*      */           }
/* 1961 */           return Integer.valueOf(NumberInput.parseInt(str));
/*      */         } 
/* 1963 */         if (preferBigNumbers) {
/* 1964 */           BigDecimal dec = NumberInput.parseBigDecimal(str, 
/* 1965 */               isEnabled(StreamReadFeature.USE_FAST_BIG_NUMBER_PARSER));
/*      */           
/* 1967 */           if (dec == null) {
/* 1968 */             throw new IllegalStateException("Internal error: failed to parse number '" + str + "'");
/*      */           }
/* 1970 */           return dec;
/*      */         } 
/* 1972 */         return Double.valueOf(NumberInput.parseDouble(str, isEnabled(StreamReadFeature.USE_FAST_DOUBLE_PARSER)));
/*      */       } 
/* 1974 */       throw new IllegalStateException("Internal error: entry should be a Number, but is of type " + 
/* 1975 */           ClassUtil.classNameOf(value));
/*      */     }
/*      */     
/*      */     private final boolean _smallerThanInt(Number n) {
/* 1979 */       return (n instanceof Short || n instanceof Byte);
/*      */     }
/*      */     
/*      */     private final boolean _smallerThanLong(Number n) {
/* 1983 */       return (n instanceof Integer || n instanceof Short || n instanceof Byte);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected int _convertNumberToInt(Number n) throws IOException {
/* 1990 */       if (n instanceof Long) {
/* 1991 */         long l = n.longValue();
/* 1992 */         int result = (int)l;
/* 1993 */         if (result != l) {
/* 1994 */           reportOverflowInt();
/*      */         }
/* 1996 */         return result;
/*      */       } 
/* 1998 */       if (n instanceof BigInteger) {
/* 1999 */         BigInteger big = (BigInteger)n;
/* 2000 */         if (BI_MIN_INT.compareTo(big) > 0 || BI_MAX_INT
/* 2001 */           .compareTo(big) < 0)
/* 2002 */           reportOverflowInt(); 
/*      */       } else {
/* 2004 */         if (n instanceof Double || n instanceof Float) {
/* 2005 */           double d = n.doubleValue();
/*      */           
/* 2007 */           if (d < -2.147483648E9D || d > 2.147483647E9D) {
/* 2008 */             reportOverflowInt();
/*      */           }
/* 2010 */           return (int)d;
/* 2011 */         }  if (n instanceof BigDecimal) {
/* 2012 */           BigDecimal big = (BigDecimal)n;
/* 2013 */           if (BD_MIN_INT.compareTo(big) > 0 || BD_MAX_INT
/* 2014 */             .compareTo(big) < 0) {
/* 2015 */             reportOverflowInt();
/*      */           }
/*      */         } else {
/* 2018 */           _throwInternal();
/*      */         } 
/* 2020 */       }  return n.intValue();
/*      */     }
/*      */ 
/*      */     
/*      */     protected long _convertNumberToLong(Number n) throws IOException {
/* 2025 */       if (n instanceof BigInteger) {
/* 2026 */         BigInteger big = (BigInteger)n;
/* 2027 */         if (BI_MIN_LONG.compareTo(big) > 0 || BI_MAX_LONG
/* 2028 */           .compareTo(big) < 0)
/* 2029 */           reportOverflowLong(); 
/*      */       } else {
/* 2031 */         if (n instanceof Double || n instanceof Float) {
/* 2032 */           double d = n.doubleValue();
/*      */           
/* 2034 */           if (d < -9.223372036854776E18D || d > 9.223372036854776E18D) {
/* 2035 */             reportOverflowLong();
/*      */           }
/* 2037 */           return (long)d;
/* 2038 */         }  if (n instanceof BigDecimal) {
/* 2039 */           BigDecimal big = (BigDecimal)n;
/* 2040 */           if (BD_MIN_LONG.compareTo(big) > 0 || BD_MAX_LONG
/* 2041 */             .compareTo(big) < 0) {
/* 2042 */             reportOverflowLong();
/*      */           }
/*      */         } else {
/* 2045 */           _throwInternal();
/*      */         } 
/* 2047 */       }  return n.longValue();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Object getEmbeddedObject() {
/* 2059 */       if (this._currToken == JsonToken.VALUE_EMBEDDED_OBJECT) {
/* 2060 */         return _currentObject();
/*      */       }
/* 2062 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public byte[] getBinaryValue(Base64Variant b64variant) throws IOException {
/* 2070 */       if (this._currToken == JsonToken.VALUE_EMBEDDED_OBJECT) {
/*      */         
/* 2072 */         Object ob = _currentObject();
/* 2073 */         if (ob instanceof byte[]) {
/* 2074 */           return (byte[])ob;
/*      */         }
/*      */       } 
/*      */       
/* 2078 */       if (this._currToken != JsonToken.VALUE_STRING) {
/* 2079 */         throw _constructError("Current token (" + this._currToken + ") not VALUE_STRING (or VALUE_EMBEDDED_OBJECT with byte[]), cannot access as binary");
/*      */       }
/* 2081 */       String str = getText();
/* 2082 */       if (str == null) {
/* 2083 */         return null;
/*      */       }
/* 2085 */       ByteArrayBuilder builder = this._byteBuilder;
/* 2086 */       if (builder == null) {
/* 2087 */         this._byteBuilder = builder = new ByteArrayBuilder(100);
/*      */       } else {
/* 2089 */         this._byteBuilder.reset();
/*      */       } 
/* 2091 */       _decodeBase64(str, builder, b64variant);
/* 2092 */       return builder.toByteArray();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/* 2098 */       byte[] data = getBinaryValue(b64variant);
/* 2099 */       if (data != null) {
/* 2100 */         out.write(data, 0, data.length);
/* 2101 */         return data.length;
/*      */       } 
/* 2103 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean canReadObjectId() {
/* 2114 */       return this._hasNativeObjectIds;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean canReadTypeId() {
/* 2119 */       return this._hasNativeTypeIds;
/*      */     }
/*      */ 
/*      */     
/*      */     public Object getTypeId() {
/* 2124 */       return this._segment.findTypeId(this._segmentPtr);
/*      */     }
/*      */ 
/*      */     
/*      */     public Object getObjectId() {
/* 2129 */       return this._segment.findObjectId(this._segmentPtr);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final Object _currentObject() {
/* 2139 */       return this._segment.get(this._segmentPtr);
/*      */     }
/*      */ 
/*      */     
/*      */     protected final void _checkIsNumber() throws JacksonException {
/* 2144 */       if (this._currToken == null || !this._currToken.isNumeric()) {
/* 2145 */         throw _constructError("Current token (" + this._currToken + ") not numeric, cannot use numeric value accessors");
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     protected void _handleEOF() {
/* 2151 */       _throwInternal();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final class Segment
/*      */   {
/*      */     public static final int TOKENS_PER_SEGMENT = 16;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2173 */     private static final JsonToken[] TOKEN_TYPES_BY_INDEX = new JsonToken[16]; protected Segment _next; protected long _tokenTypes; static {
/* 2174 */       JsonToken[] t = JsonToken.values();
/*      */       
/* 2176 */       System.arraycopy(t, 1, TOKEN_TYPES_BY_INDEX, 1, Math.min(15, t.length - 1));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2194 */     protected final Object[] _tokens = new Object[16];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected TreeMap<Integer, Object> _nativeIds;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public JsonToken type(int index) {
/* 2207 */       long l = this._tokenTypes;
/* 2208 */       if (index > 0) {
/* 2209 */         l >>= index << 2;
/*      */       }
/* 2211 */       int ix = (int)l & 0xF;
/* 2212 */       return TOKEN_TYPES_BY_INDEX[ix];
/*      */     }
/*      */ 
/*      */     
/*      */     public int rawType(int index) {
/* 2217 */       long l = this._tokenTypes;
/* 2218 */       if (index > 0) {
/* 2219 */         l >>= index << 2;
/*      */       }
/* 2221 */       return (int)l & 0xF;
/*      */     }
/*      */     
/*      */     public Object get(int index) {
/* 2225 */       return this._tokens[index];
/*      */     }
/*      */     public Segment next() {
/* 2228 */       return this._next;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasIds() {
/* 2235 */       return (this._nativeIds != null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Segment append(int index, JsonToken tokenType) {
/* 2242 */       if (index < 16) {
/* 2243 */         set(index, tokenType);
/* 2244 */         return null;
/*      */       } 
/* 2246 */       this._next = new Segment();
/* 2247 */       this._next.set(0, tokenType);
/* 2248 */       return this._next;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Segment append(int index, JsonToken tokenType, Object objectId, Object typeId) {
/* 2254 */       if (index < 16) {
/* 2255 */         set(index, tokenType, objectId, typeId);
/* 2256 */         return null;
/*      */       } 
/* 2258 */       this._next = new Segment();
/* 2259 */       this._next.set(0, tokenType, objectId, typeId);
/* 2260 */       return this._next;
/*      */     }
/*      */ 
/*      */     
/*      */     public Segment append(int index, JsonToken tokenType, Object value) {
/* 2265 */       if (index < 16) {
/* 2266 */         set(index, tokenType, value);
/* 2267 */         return null;
/*      */       } 
/* 2269 */       this._next = new Segment();
/* 2270 */       this._next.set(0, tokenType, value);
/* 2271 */       return this._next;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Segment append(int index, JsonToken tokenType, Object value, Object objectId, Object typeId) {
/* 2277 */       if (index < 16) {
/* 2278 */         set(index, tokenType, value, objectId, typeId);
/* 2279 */         return null;
/*      */       } 
/* 2281 */       this._next = new Segment();
/* 2282 */       this._next.set(0, tokenType, value, objectId, typeId);
/* 2283 */       return this._next;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void set(int index, JsonToken tokenType) {
/* 2337 */       long typeCode = tokenType.ordinal();
/* 2338 */       if (index > 0) {
/* 2339 */         typeCode <<= index << 2;
/*      */       }
/* 2341 */       this._tokenTypes |= typeCode;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void set(int index, JsonToken tokenType, Object objectId, Object typeId) {
/* 2347 */       long typeCode = tokenType.ordinal();
/* 2348 */       if (index > 0) {
/* 2349 */         typeCode <<= index << 2;
/*      */       }
/* 2351 */       this._tokenTypes |= typeCode;
/* 2352 */       assignNativeIds(index, objectId, typeId);
/*      */     }
/*      */ 
/*      */     
/*      */     private void set(int index, JsonToken tokenType, Object value) {
/* 2357 */       this._tokens[index] = value;
/* 2358 */       long typeCode = tokenType.ordinal();
/* 2359 */       if (index > 0) {
/* 2360 */         typeCode <<= index << 2;
/*      */       }
/* 2362 */       this._tokenTypes |= typeCode;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void set(int index, JsonToken tokenType, Object value, Object objectId, Object typeId) {
/* 2368 */       this._tokens[index] = value;
/* 2369 */       long typeCode = tokenType.ordinal();
/* 2370 */       if (index > 0) {
/* 2371 */         typeCode <<= index << 2;
/*      */       }
/* 2373 */       this._tokenTypes |= typeCode;
/* 2374 */       assignNativeIds(index, objectId, typeId);
/*      */     }
/*      */ 
/*      */     
/*      */     private final void assignNativeIds(int index, Object objectId, Object typeId) {
/* 2379 */       if (this._nativeIds == null) {
/* 2380 */         this._nativeIds = new TreeMap<>();
/*      */       }
/* 2382 */       if (objectId != null) {
/* 2383 */         this._nativeIds.put(Integer.valueOf(_objectIdIndex(index)), objectId);
/*      */       }
/* 2385 */       if (typeId != null) {
/* 2386 */         this._nativeIds.put(Integer.valueOf(_typeIdIndex(index)), typeId);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Object findObjectId(int index) {
/* 2394 */       return (this._nativeIds == null) ? null : this._nativeIds.get(Integer.valueOf(_objectIdIndex(index)));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Object findTypeId(int index) {
/* 2401 */       return (this._nativeIds == null) ? null : this._nativeIds.get(Integer.valueOf(_typeIdIndex(index)));
/*      */     }
/*      */     
/* 2404 */     private final int _typeIdIndex(int i) { return i + i; } private final int _objectIdIndex(int i) {
/* 2405 */       return i + i + 1;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\TokenBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */