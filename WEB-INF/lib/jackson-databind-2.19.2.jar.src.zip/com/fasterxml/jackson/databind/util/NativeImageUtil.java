/*    */ package com.fasterxml.jackson.databind.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeImageUtil
/*    */ {
/* 13 */   private static final boolean RUNNING_IN_SVM = (System.getProperty("org.graalvm.nativeimage.imagecode") != null);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isInNativeImageAndIsAtRuntime() {
/* 27 */     return (RUNNING_IN_SVM && "runtime".equals(System.getProperty("org.graalvm.nativeimage.imagecode")));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isInNativeImage() {
/* 38 */     return RUNNING_IN_SVM;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isUnsupportedFeatureError(Throwable e) {
/* 45 */     if (!isInNativeImageAndIsAtRuntime()) {
/* 46 */       return false;
/*    */     }
/* 48 */     if (e instanceof java.lang.reflect.InvocationTargetException) {
/* 49 */       e = e.getCause();
/*    */     }
/* 51 */     return e.getClass().getName().equals("com.oracle.svm.core.jdk.UnsupportedFeatureError");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean needsReflectionConfiguration(Class<?> cl) {
/* 59 */     if (!isInNativeImageAndIsAtRuntime()) {
/* 60 */       return false;
/*    */     }
/*    */     
/* 63 */     return (((cl.getDeclaredFields()).length == 0 || ClassUtil.isRecordType(cl)) && (cl
/* 64 */       .getDeclaredMethods()).length == 0 && (cl
/* 65 */       .getDeclaredConstructors()).length == 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\NativeImageUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */