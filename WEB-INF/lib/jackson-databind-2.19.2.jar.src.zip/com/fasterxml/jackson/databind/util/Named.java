package com.fasterxml.jackson.databind.util;

public interface Named {
  String getName();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\Named.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */