/*     */ package com.fasterxml.jackson.databind.util;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedField;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedParameter;
/*     */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleBeanPropertyDefinition
/*     */   extends BeanPropertyDefinition
/*     */ {
/*     */   protected final AnnotationIntrospector _annotationIntrospector;
/*     */   protected final AnnotatedMember _member;
/*     */   protected final PropertyMetadata _metadata;
/*     */   protected final PropertyName _fullName;
/*     */   protected final JsonInclude.Value _inclusion;
/*     */   
/*     */   protected SimpleBeanPropertyDefinition(AnnotationIntrospector intr, AnnotatedMember member, PropertyName fullName, PropertyMetadata metadata, JsonInclude.Value inclusion) {
/*  62 */     this._annotationIntrospector = intr;
/*  63 */     this._member = member;
/*  64 */     this._fullName = fullName;
/*  65 */     this._metadata = (metadata == null) ? PropertyMetadata.STD_OPTIONAL : metadata;
/*  66 */     this._inclusion = inclusion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SimpleBeanPropertyDefinition construct(MapperConfig<?> config, AnnotatedMember member) {
/*  75 */     return new SimpleBeanPropertyDefinition(config.getAnnotationIntrospector(), member, 
/*  76 */         PropertyName.construct(member.getName()), null, EMPTY_INCLUDE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SimpleBeanPropertyDefinition construct(MapperConfig<?> config, AnnotatedMember member, PropertyName name) {
/*  84 */     return construct(config, member, name, (PropertyMetadata)null, EMPTY_INCLUDE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SimpleBeanPropertyDefinition construct(MapperConfig<?> config, AnnotatedMember member, PropertyName name, PropertyMetadata metadata, JsonInclude.Include inclusion) {
/*  98 */     JsonInclude.Value inclValue = (inclusion == null || inclusion == JsonInclude.Include.USE_DEFAULTS) ? EMPTY_INCLUDE : JsonInclude.Value.construct(inclusion, null);
/*  99 */     return new SimpleBeanPropertyDefinition(config.getAnnotationIntrospector(), member, name, metadata, inclValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SimpleBeanPropertyDefinition construct(MapperConfig<?> config, AnnotatedMember member, PropertyName name, PropertyMetadata metadata, JsonInclude.Value inclusion) {
/* 109 */     return new SimpleBeanPropertyDefinition(config.getAnnotationIntrospector(), member, name, metadata, inclusion);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyDefinition withSimpleName(String newName) {
/* 121 */     if (this._fullName.hasSimpleName(newName) && !this._fullName.hasNamespace()) {
/* 122 */       return this;
/*     */     }
/* 124 */     return new SimpleBeanPropertyDefinition(this._annotationIntrospector, this._member, new PropertyName(newName), this._metadata, this._inclusion);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyDefinition withName(PropertyName newName) {
/* 130 */     if (this._fullName.equals(newName)) {
/* 131 */       return this;
/*     */     }
/* 133 */     return new SimpleBeanPropertyDefinition(this._annotationIntrospector, this._member, newName, this._metadata, this._inclusion);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyDefinition withMetadata(PropertyMetadata metadata) {
/* 141 */     if (metadata.equals(this._metadata)) {
/* 142 */       return this;
/*     */     }
/* 144 */     return new SimpleBeanPropertyDefinition(this._annotationIntrospector, this._member, this._fullName, metadata, this._inclusion);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyDefinition withInclusion(JsonInclude.Value inclusion) {
/* 152 */     if (this._inclusion == inclusion) {
/* 153 */       return this;
/*     */     }
/* 155 */     return new SimpleBeanPropertyDefinition(this._annotationIntrospector, this._member, this._fullName, this._metadata, inclusion);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 166 */     return this._fullName.getSimpleName();
/*     */   }
/*     */   public PropertyName getFullName() {
/* 169 */     return this._fullName;
/*     */   }
/*     */   
/*     */   public boolean hasName(PropertyName name) {
/* 173 */     return this._fullName.equals(name);
/*     */   }
/*     */   
/*     */   public String getInternalName() {
/* 177 */     return getName();
/*     */   }
/*     */   
/*     */   public PropertyName getWrapperName() {
/* 181 */     if (this._annotationIntrospector == null || this._member == null) {
/* 182 */       return null;
/*     */     }
/* 184 */     return this._annotationIntrospector.findWrapperName((Annotated)this._member);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isExplicitlyIncluded() {
/* 189 */     return false; } public boolean isExplicitlyNamed() {
/* 190 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyMetadata getMetadata() {
/* 198 */     return this._metadata;
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType getPrimaryType() {
/* 203 */     if (this._member == null) {
/* 204 */       return TypeFactory.unknownType();
/*     */     }
/* 206 */     return this._member.getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getRawPrimaryType() {
/* 211 */     if (this._member == null) {
/* 212 */       return Object.class;
/*     */     }
/* 214 */     return this._member.getRawType();
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonInclude.Value findInclusion() {
/* 219 */     return this._inclusion;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<PropertyName> findAliases() {
/* 224 */     AnnotatedMember ann = getPrimaryMember();
/* 225 */     if (ann != null) {
/* 226 */       List<PropertyName> propertyNames = this._annotationIntrospector.findPropertyAliases((Annotated)ann);
/* 227 */       if (propertyNames != null) {
/* 228 */         return propertyNames;
/*     */       }
/*     */     } 
/* 231 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasGetter() {
/* 241 */     return (getGetter() != null);
/*     */   }
/*     */   public boolean hasSetter() {
/* 244 */     return (getSetter() != null);
/*     */   }
/*     */   public boolean hasField() {
/* 247 */     return this._member instanceof AnnotatedField;
/*     */   }
/*     */   public boolean hasConstructorParameter() {
/* 250 */     return this._member instanceof AnnotatedParameter;
/*     */   }
/*     */   
/*     */   public AnnotatedMethod getGetter() {
/* 254 */     if (this._member instanceof AnnotatedMethod && ((AnnotatedMethod)this._member)
/* 255 */       .getParameterCount() == 0) {
/* 256 */       return (AnnotatedMethod)this._member;
/*     */     }
/* 258 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedMethod getSetter() {
/* 263 */     if (this._member instanceof AnnotatedMethod && ((AnnotatedMethod)this._member)
/* 264 */       .getParameterCount() == 1) {
/* 265 */       return (AnnotatedMethod)this._member;
/*     */     }
/* 267 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedField getField() {
/* 272 */     return (this._member instanceof AnnotatedField) ? (AnnotatedField)this._member : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedParameter getConstructorParameter() {
/* 277 */     return (this._member instanceof AnnotatedParameter) ? (AnnotatedParameter)this._member : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<AnnotatedParameter> getConstructorParameters() {
/* 282 */     AnnotatedParameter param = getConstructorParameter();
/* 283 */     if (param == null) {
/* 284 */       return ClassUtil.emptyIterator();
/*     */     }
/* 286 */     return Collections.<AnnotatedParameter>singleton(param).iterator();
/*     */   }
/*     */   
/*     */   public AnnotatedMember getPrimaryMember() {
/* 290 */     return this._member;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\SimpleBeanPropertyDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */