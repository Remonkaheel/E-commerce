/*     */ package com.fasterxml.jackson.databind.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum NamingStrategyImpls
/*     */ {
/*  12 */   LOWER_CAMEL_CASE
/*     */   {
/*     */     public String translate(String beanName) {
/*  15 */       return beanName;
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  22 */   UPPER_CAMEL_CASE
/*     */   {
/*     */     public String translate(String beanName) {
/*  25 */       if (beanName == null || beanName.isEmpty()) {
/*  26 */         return beanName;
/*     */       }
/*     */       
/*  29 */       char c = beanName.charAt(0);
/*  30 */       char uc = Character.toUpperCase(c);
/*  31 */       if (c == uc) {
/*  32 */         return beanName;
/*     */       }
/*  34 */       StringBuilder sb = new StringBuilder(beanName);
/*  35 */       sb.setCharAt(0, uc);
/*  36 */       return sb.toString();
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   SNAKE_CASE
/*     */   {
/*     */     public String translate(String beanName) {
/*  46 */       if (beanName == null) return beanName; 
/*  47 */       int length = beanName.length();
/*  48 */       StringBuilder result = new StringBuilder(length * 2);
/*  49 */       int resultLength = 0;
/*  50 */       boolean wasPrevTranslated = false;
/*  51 */       for (int i = 0; i < length; i++) {
/*  52 */         char c = beanName.charAt(i);
/*  53 */         if (i > 0 || c != '_') {
/*     */           
/*  55 */           if (Character.isUpperCase(c)) {
/*  56 */             if (!wasPrevTranslated && resultLength > 0 && result.charAt(resultLength - 1) != '_') {
/*  57 */               result.append('_');
/*  58 */               resultLength++;
/*     */             } 
/*  60 */             c = Character.toLowerCase(c);
/*  61 */             wasPrevTranslated = true;
/*     */           } else {
/*  63 */             wasPrevTranslated = false;
/*     */           } 
/*  65 */           result.append(c);
/*  66 */           resultLength++;
/*     */         } 
/*     */       } 
/*  69 */       return (resultLength > 0) ? result.toString() : beanName;
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   UPPER_SNAKE_CASE
/*     */   {
/*     */     public String translate(String beanName) {
/*  79 */       String output = SNAKE_CASE.translate(beanName);
/*  80 */       if (output == null) {
/*  81 */         return null;
/*     */       }
/*  83 */       return output.toUpperCase();
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   LOWER_CASE
/*     */   {
/*     */     public String translate(String beanName) {
/*  93 */       if (beanName == null || beanName.isEmpty()) {
/*  94 */         return beanName;
/*     */       }
/*  96 */       return beanName.toLowerCase();
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   KEBAB_CASE
/*     */   {
/*     */     public String translate(String beanName) {
/* 106 */       return null.translateLowerCaseWithSeparator(beanName, '-');
/*     */     }
/*     */   },
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   LOWER_DOT_CASE
/*     */   {
/*     */     public String translate(String beanName) {
/* 116 */       return null.translateLowerCaseWithSeparator(beanName, '.');
/*     */     }
/*     */   };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String translateLowerCaseWithSeparator(String beanName, char separator) {
/* 127 */     if (beanName == null || beanName.isEmpty()) {
/* 128 */       return beanName;
/*     */     }
/*     */     
/* 131 */     int length = beanName.length();
/* 132 */     StringBuilder result = new StringBuilder(length + (length >> 1));
/* 133 */     int upperCount = 0;
/* 134 */     for (int i = 0; i < length; i++) {
/* 135 */       char ch = beanName.charAt(i);
/* 136 */       char lc = Character.toLowerCase(ch);
/*     */       
/* 138 */       if (lc == ch) {
/*     */ 
/*     */         
/* 141 */         if (upperCount > 1)
/*     */         {
/* 143 */           result.insert(result.length() - 1, separator);
/*     */         }
/* 145 */         upperCount = 0;
/*     */       } else {
/*     */         
/* 148 */         if (upperCount == 0 && i > 0) {
/* 149 */           result.append(separator);
/*     */         }
/* 151 */         upperCount++;
/*     */       } 
/* 153 */       result.append(lc);
/*     */     } 
/* 155 */     return result.toString();
/*     */   }
/*     */   
/*     */   public abstract String translate(String paramString);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\NamingStrategyImpls.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */