/*     */ package com.fasterxml.jackson.databind.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CompactStringObjectMap
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  25 */   private static final CompactStringObjectMap EMPTY = new CompactStringObjectMap(1, 0, new Object[4]);
/*     */   
/*     */   private final int _hashMask;
/*     */   
/*     */   private final int _spillCount;
/*     */   
/*     */   private final Object[] _hashArea;
/*     */   
/*     */   private CompactStringObjectMap(int hashMask, int spillCount, Object[] hashArea) {
/*  34 */     this._hashMask = hashMask;
/*  35 */     this._spillCount = spillCount;
/*  36 */     this._hashArea = hashArea;
/*     */   }
/*     */ 
/*     */   
/*     */   public static <T> CompactStringObjectMap construct(Map<String, T> all) {
/*  41 */     if (all.isEmpty()) {
/*  42 */       return EMPTY;
/*     */     }
/*     */ 
/*     */     
/*  46 */     int size = findSize(all.size());
/*  47 */     int mask = size - 1;
/*     */     
/*  49 */     int alloc = (size + (size >> 1)) * 2;
/*  50 */     Object[] hashArea = new Object[alloc];
/*  51 */     int spillCount = 0;
/*     */     
/*  53 */     for (Map.Entry<String, T> entry : all.entrySet()) {
/*  54 */       String key = entry.getKey();
/*     */ 
/*     */       
/*  57 */       if (key == null) {
/*     */         continue;
/*     */       }
/*     */       
/*  61 */       int slot = key.hashCode() & mask;
/*  62 */       int ix = slot + slot;
/*     */ 
/*     */       
/*  65 */       if (hashArea[ix] != null) {
/*     */         
/*  67 */         ix = size + (slot >> 1) << 1;
/*  68 */         if (hashArea[ix] != null) {
/*     */           
/*  70 */           ix = (size + (size >> 1) << 1) + spillCount;
/*  71 */           spillCount += 2;
/*  72 */           if (ix >= hashArea.length) {
/*  73 */             hashArea = Arrays.copyOf(hashArea, hashArea.length + 4);
/*     */           }
/*     */         } 
/*     */       } 
/*  77 */       hashArea[ix] = key;
/*  78 */       hashArea[ix + 1] = entry.getValue();
/*     */     } 
/*  80 */     return new CompactStringObjectMap(mask, spillCount, hashArea);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final int findSize(int size) {
/*  85 */     if (size <= 5) {
/*  86 */       return 8;
/*     */     }
/*  88 */     if (size <= 12) {
/*  89 */       return 16;
/*     */     }
/*  91 */     int needed = size + (size >> 2);
/*  92 */     int result = 32;
/*  93 */     while (result < needed) {
/*  94 */       result += result;
/*     */     }
/*  96 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object find(String key) {
/* 101 */     int slot = key.hashCode() & this._hashMask;
/* 102 */     int ix = slot << 1;
/* 103 */     Object match = this._hashArea[ix];
/* 104 */     if (match == key || key.equals(match)) {
/* 105 */       return this._hashArea[ix + 1];
/*     */     }
/* 107 */     return _find2(key, slot, match);
/*     */   }
/*     */ 
/*     */   
/*     */   private final Object _find2(String key, int slot, Object match) {
/* 112 */     if (match == null) {
/* 113 */       return null;
/*     */     }
/* 115 */     int hashSize = this._hashMask + 1;
/* 116 */     int ix = hashSize + (slot >> 1) << 1;
/* 117 */     match = this._hashArea[ix];
/* 118 */     if (key.equals(match)) {
/* 119 */       return this._hashArea[ix + 1];
/*     */     }
/* 121 */     if (match != null) {
/* 122 */       int i = hashSize + (hashSize >> 1) << 1;
/* 123 */       for (int end = i + this._spillCount; i < end; i += 2) {
/* 124 */         match = this._hashArea[i];
/* 125 */         if (match == key || key.equals(match)) {
/* 126 */           return this._hashArea[i + 1];
/*     */         }
/*     */       } 
/*     */     } 
/* 130 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object findCaseInsensitive(String key) {
/* 135 */     for (int i = 0, end = this._hashArea.length; i < end; i += 2) {
/* 136 */       Object k2 = this._hashArea[i];
/* 137 */       if (k2 != null) {
/* 138 */         String s = (String)k2;
/* 139 */         if (s.equalsIgnoreCase(key)) {
/* 140 */           return this._hashArea[i + 1];
/*     */         }
/*     */       } 
/*     */     } 
/* 144 */     return null;
/*     */   }
/*     */   
/*     */   public List<String> keys() {
/* 148 */     int end = this._hashArea.length;
/* 149 */     List<String> keys = new ArrayList<>(end >> 2);
/* 150 */     for (int i = 0; i < end; i += 2) {
/* 151 */       Object key = this._hashArea[i];
/* 152 */       if (key != null) {
/* 153 */         keys.add((String)key);
/*     */       }
/*     */     } 
/* 156 */     return keys;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\CompactStringObjectMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */