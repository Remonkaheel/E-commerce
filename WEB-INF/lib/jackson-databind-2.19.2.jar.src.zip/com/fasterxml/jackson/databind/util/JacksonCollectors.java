/*    */ package com.fasterxml.jackson.databind.util;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.JsonNode;
/*    */ import com.fasterxml.jackson.databind.node.ArrayNode;
/*    */ import com.fasterxml.jackson.databind.node.JsonNodeCreator;
/*    */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*    */ import java.util.stream.Collector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JacksonCollectors
/*    */ {
/*    */   public static Collector<JsonNode, ArrayNode, ArrayNode> toArrayNode() {
/* 32 */     return toArrayNode((JsonNodeCreator)JsonNodeFactory.instance);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Collector<JsonNode, ArrayNode, ArrayNode> toArrayNode(JsonNodeCreator nodeCreator) {
/* 47 */     return Collector.of(nodeCreator::arrayNode, ArrayNode::add, ArrayNode::addAll, new Collector.Characteristics[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\JacksonCollectors.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */