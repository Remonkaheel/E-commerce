/*     */ package com.fasterxml.jackson.databind.util;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonSerializable;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSONWrappedObject
/*     */   implements JsonSerializable
/*     */ {
/*     */   protected final String _prefix;
/*     */   protected final String _suffix;
/*     */   protected final Object _value;
/*     */   protected final JavaType _serializationType;
/*     */   
/*     */   public JSONWrappedObject(String prefix, String suffix, Object value) {
/*  45 */     this(prefix, suffix, value, (JavaType)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JSONWrappedObject(String prefix, String suffix, Object value, JavaType asType) {
/*  55 */     this._prefix = prefix;
/*  56 */     this._suffix = suffix;
/*  57 */     this._value = value;
/*  58 */     this._serializationType = asType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeWithType(JsonGenerator jgen, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/*  72 */     serialize(jgen, provider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(JsonGenerator jgen, SerializerProvider provider) throws IOException {
/*  80 */     if (this._prefix != null) jgen.writeRaw(this._prefix); 
/*  81 */     if (this._value == null) {
/*  82 */       provider.defaultSerializeNull(jgen);
/*  83 */     } else if (this._serializationType != null) {
/*  84 */       provider.findTypedValueSerializer(this._serializationType, true, null).serialize(this._value, jgen, provider);
/*     */     } else {
/*  86 */       Class<?> cls = this._value.getClass();
/*  87 */       provider.findTypedValueSerializer(cls, true, null).serialize(this._value, jgen, provider);
/*     */     } 
/*  89 */     if (this._suffix != null) jgen.writeRaw(this._suffix);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPrefix() {
/*  98 */     return this._prefix;
/*  99 */   } public String getSuffix() { return this._suffix; }
/* 100 */   public Object getValue() { return this._value; } public JavaType getSerializationType() {
/* 101 */     return this._serializationType;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databin\\util\JSONWrappedObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */