/*     */ package com.fasterxml.jackson.databind.module;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.Serializers;
/*     */ import com.fasterxml.jackson.databind.type.ArrayType;
/*     */ import com.fasterxml.jackson.databind.type.ClassKey;
/*     */ import com.fasterxml.jackson.databind.type.CollectionLikeType;
/*     */ import com.fasterxml.jackson.databind.type.CollectionType;
/*     */ import com.fasterxml.jackson.databind.type.MapLikeType;
/*     */ import com.fasterxml.jackson.databind.type.MapType;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleSerializers
/*     */   extends Serializers.Base
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 3L;
/*  36 */   protected HashMap<ClassKey, JsonSerializer<?>> _classMappings = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   protected HashMap<ClassKey, JsonSerializer<?>> _interfaceMappings = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _hasEnumSerializer = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleSerializers() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleSerializers(List<JsonSerializer<?>> sers) {
/*  62 */     addSerializers(sers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSerializer(JsonSerializer<?> ser) {
/*  77 */     Class<?> cls = ser.handledType();
/*  78 */     if (cls == null || cls == Object.class) {
/*  79 */       throw new IllegalArgumentException("JsonSerializer of type " + ser.getClass().getName() + " does not define valid handledType() -- must either register with method that takes type argument  or make serializer extend 'com.fasterxml.jackson.databind.ser.std.StdSerializer'");
/*     */     }
/*     */ 
/*     */     
/*  83 */     _addSerializer(cls, ser);
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> void addSerializer(Class<? extends T> type, JsonSerializer<T> ser) {
/*  88 */     _addSerializer(type, ser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSerializers(List<JsonSerializer<?>> sers) {
/*  95 */     for (JsonSerializer<?> ser : sers) {
/*  96 */       addSerializer(ser);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> findSerializer(SerializationConfig config, JavaType type, BeanDescription beanDesc) {
/* 110 */     Class<?> cls = type.getRawClass();
/* 111 */     ClassKey key = new ClassKey(cls);
/* 112 */     JsonSerializer<?> ser = null;
/*     */ 
/*     */     
/* 115 */     if (cls.isInterface()) {
/* 116 */       if (this._interfaceMappings != null) {
/* 117 */         ser = this._interfaceMappings.get(key);
/* 118 */         if (ser != null) {
/* 119 */           return ser;
/*     */         }
/*     */       }
/*     */     
/* 123 */     } else if (this._classMappings != null) {
/* 124 */       ser = this._classMappings.get(key);
/* 125 */       if (ser != null) {
/* 126 */         return ser;
/*     */       }
/*     */ 
/*     */       
/* 130 */       if (this._hasEnumSerializer && type.isEnumType()) {
/* 131 */         key.reset(Enum.class);
/* 132 */         ser = this._classMappings.get(key);
/* 133 */         if (ser != null) {
/* 134 */           return ser;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 139 */       for (Class<?> curr = cls; curr != null; curr = curr.getSuperclass()) {
/* 140 */         key.reset(curr);
/* 141 */         ser = this._classMappings.get(key);
/* 142 */         if (ser != null) {
/* 143 */           return ser;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 149 */     if (this._interfaceMappings != null) {
/* 150 */       ser = _findInterfaceMapping(cls, key);
/* 151 */       if (ser != null) {
/* 152 */         return ser;
/*     */       }
/*     */       
/* 155 */       if (!cls.isInterface()) {
/* 156 */         while ((cls = cls.getSuperclass()) != null) {
/* 157 */           ser = _findInterfaceMapping(cls, key);
/* 158 */           if (ser != null) {
/* 159 */             return ser;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 164 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> findArraySerializer(SerializationConfig config, ArrayType type, BeanDescription beanDesc, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer) {
/* 171 */     return findSerializer(config, (JavaType)type, beanDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> findCollectionSerializer(SerializationConfig config, CollectionType type, BeanDescription beanDesc, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer) {
/* 178 */     return findSerializer(config, (JavaType)type, beanDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> findCollectionLikeSerializer(SerializationConfig config, CollectionLikeType type, BeanDescription beanDesc, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer) {
/* 185 */     return findSerializer(config, (JavaType)type, beanDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> findMapSerializer(SerializationConfig config, MapType type, BeanDescription beanDesc, JsonSerializer<Object> keySerializer, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer) {
/* 193 */     return findSerializer(config, (JavaType)type, beanDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> findMapLikeSerializer(SerializationConfig config, MapLikeType type, BeanDescription beanDesc, JsonSerializer<Object> keySerializer, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer) {
/* 201 */     return findSerializer(config, (JavaType)type, beanDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<?> _findInterfaceMapping(Class<?> cls, ClassKey key) {
/* 212 */     for (Class<?> iface : cls.getInterfaces()) {
/* 213 */       key.reset(iface);
/* 214 */       JsonSerializer<?> ser = this._interfaceMappings.get(key);
/* 215 */       if (ser != null) {
/* 216 */         return ser;
/*     */       }
/* 218 */       ser = _findInterfaceMapping(iface, key);
/* 219 */       if (ser != null) {
/* 220 */         return ser;
/*     */       }
/*     */     } 
/* 223 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _addSerializer(Class<?> cls, JsonSerializer<?> ser) {
/* 228 */     ClassKey key = new ClassKey(cls);
/*     */     
/* 230 */     if (cls.isInterface()) {
/* 231 */       if (this._interfaceMappings == null) {
/* 232 */         this._interfaceMappings = new HashMap<>();
/*     */       }
/* 234 */       this._interfaceMappings.put(key, ser);
/*     */     } else {
/* 236 */       if (this._classMappings == null) {
/* 237 */         this._classMappings = new HashMap<>();
/*     */       }
/* 239 */       this._classMappings.put(key, ser);
/* 240 */       if (cls == Enum.class)
/* 241 */         this._hasEnumSerializer = true; 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\module\SimpleSerializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */