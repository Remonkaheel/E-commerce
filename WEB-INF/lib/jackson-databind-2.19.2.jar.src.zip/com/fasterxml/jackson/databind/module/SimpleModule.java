/*     */ package com.fasterxml.jackson.databind.module;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Version;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*     */ import com.fasterxml.jackson.databind.Module;
/*     */ import com.fasterxml.jackson.databind.PropertyNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.deser.BeanDeserializerModifier;
/*     */ import com.fasterxml.jackson.databind.deser.Deserializers;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiators;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import com.fasterxml.jackson.databind.ser.BeanSerializerModifier;
/*     */ import com.fasterxml.jackson.databind.ser.Serializers;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleModule
/*     */   extends Module
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  57 */   private static final AtomicInteger MODULE_ID_SEQ = new AtomicInteger(1);
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _name;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Version _version;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _hasExplicitName;
/*     */ 
/*     */   
/*  72 */   protected SimpleSerializers _serializers = null;
/*  73 */   protected SimpleDeserializers _deserializers = null;
/*     */   
/*  75 */   protected SimpleSerializers _keySerializers = null;
/*  76 */   protected SimpleKeyDeserializers _keyDeserializers = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   protected SimpleAbstractTypeResolver _abstractTypes = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   protected SimpleValueInstantiators _valueInstantiators = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   protected BeanDeserializerModifier _deserializerModifier = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   protected BeanSerializerModifier _serializerModifier = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   protected HashMap<Class<?>, Class<?>> _mixins = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   protected LinkedHashSet<NamedType> _subtypes = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   protected PropertyNamingStrategy _namingStrategy = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleModule() {
/* 134 */     this._name = _generateName(getClass());
/* 135 */     this._version = Version.unknownVersion();
/*     */     
/* 137 */     this._hasExplicitName = false;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String _generateName(Class<?> cls) {
/* 142 */     return (cls == SimpleModule.class) ? ("SimpleModule-" + MODULE_ID_SEQ
/* 143 */       .getAndIncrement()) : cls
/* 144 */       .getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleModule(String name) {
/* 152 */     this(name, Version.unknownVersion());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleModule(Version version) {
/* 163 */     String maybeName = version.getArtifactId();
/*     */     
/* 165 */     this._hasExplicitName = (maybeName != null && !maybeName.isEmpty());
/* 166 */     if (this._hasExplicitName) {
/* 167 */       this._name = maybeName;
/*     */     } else {
/* 169 */       this._name = _generateName(getClass());
/*     */     } 
/* 171 */     this._version = version;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleModule(String name, Version version) {
/* 184 */     this._name = name;
/* 185 */     this._version = version;
/*     */     
/* 187 */     this._hasExplicitName = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleModule(String name, Version version, Map<Class<?>, JsonDeserializer<?>> deserializers) {
/* 195 */     this(name, version, deserializers, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleModule(String name, Version version, List<JsonSerializer<?>> serializers) {
/* 203 */     this(name, version, null, serializers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleModule(String name, Version version, Map<Class<?>, JsonDeserializer<?>> deserializers, List<JsonSerializer<?>> serializers) {
/* 213 */     this._name = name;
/*     */     
/* 215 */     this._hasExplicitName = true;
/* 216 */     this._version = version;
/* 217 */     if (deserializers != null) {
/* 218 */       this._deserializers = new SimpleDeserializers(deserializers);
/*     */     }
/* 220 */     if (serializers != null) {
/* 221 */       this._serializers = new SimpleSerializers(serializers);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getTypeId() {
/* 235 */     if (this._hasExplicitName) {
/* 236 */       return this._name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     if (getClass() == SimpleModule.class) {
/* 244 */       return this._name;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 249 */     return super.getTypeId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSerializers(SimpleSerializers s) {
/* 262 */     this._serializers = s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeserializers(SimpleDeserializers d) {
/* 269 */     this._deserializers = d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeySerializers(SimpleSerializers ks) {
/* 276 */     this._keySerializers = ks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeyDeserializers(SimpleKeyDeserializers kd) {
/* 283 */     this._keyDeserializers = kd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAbstractTypes(SimpleAbstractTypeResolver atr) {
/* 290 */     this._abstractTypes = atr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValueInstantiators(SimpleValueInstantiators svi) {
/* 297 */     this._valueInstantiators = svi;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleModule setDeserializerModifier(BeanDeserializerModifier mod) {
/* 304 */     this._deserializerModifier = mod;
/* 305 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleModule setSerializerModifier(BeanSerializerModifier mod) {
/* 312 */     this._serializerModifier = mod;
/* 313 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SimpleModule setNamingStrategy(PropertyNamingStrategy naming) {
/* 320 */     this._namingStrategy = naming;
/* 321 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleModule addSerializer(JsonSerializer<?> ser) {
/* 346 */     _checkNotNull(ser, "serializer");
/* 347 */     if (this._serializers == null) {
/* 348 */       this._serializers = new SimpleSerializers();
/*     */     }
/* 350 */     this._serializers.addSerializer(ser);
/* 351 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> SimpleModule addSerializer(Class<? extends T> type, JsonSerializer<T> ser) {
/* 371 */     _checkNotNull(type, "type to register serializer for");
/* 372 */     _checkNotNull(ser, "serializer");
/* 373 */     if (this._serializers == null) {
/* 374 */       this._serializers = new SimpleSerializers();
/*     */     }
/* 376 */     this._serializers.addSerializer(type, ser);
/* 377 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> SimpleModule addKeySerializer(Class<? extends T> type, JsonSerializer<T> ser) {
/* 385 */     _checkNotNull(type, "type to register key serializer for");
/* 386 */     _checkNotNull(ser, "key serializer");
/* 387 */     if (this._keySerializers == null) {
/* 388 */       this._keySerializers = new SimpleSerializers();
/*     */     }
/* 390 */     this._keySerializers.addSerializer(type, ser);
/* 391 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> SimpleModule addDeserializer(Class<T> type, JsonDeserializer<? extends T> deser) {
/* 415 */     _checkNotNull(type, "type to register deserializer for");
/* 416 */     _checkNotNull(deser, "deserializer");
/* 417 */     if (this._deserializers == null) {
/* 418 */       this._deserializers = new SimpleDeserializers();
/*     */     }
/* 420 */     this._deserializers.addDeserializer(type, deser);
/* 421 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleModule addKeyDeserializer(Class<?> type, KeyDeserializer deser) {
/* 429 */     _checkNotNull(type, "type to register key deserializer for");
/* 430 */     _checkNotNull(deser, "key deserializer");
/* 431 */     if (this._keyDeserializers == null) {
/* 432 */       this._keyDeserializers = new SimpleKeyDeserializers();
/*     */     }
/* 434 */     this._keyDeserializers.addDeserializer(type, deser);
/* 435 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> SimpleModule addAbstractTypeMapping(Class<T> superType, Class<? extends T> subType) {
/* 452 */     _checkNotNull(superType, "abstract type to map");
/* 453 */     _checkNotNull(subType, "concrete type to map to");
/* 454 */     if (this._abstractTypes == null) {
/* 455 */       this._abstractTypes = new SimpleAbstractTypeResolver();
/*     */     }
/*     */     
/* 458 */     this._abstractTypes = this._abstractTypes.addMapping(superType, subType);
/* 459 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleModule registerSubtypes(Class<?>... subtypes) {
/* 469 */     if (this._subtypes == null) {
/* 470 */       this._subtypes = new LinkedHashSet<>();
/*     */     }
/* 472 */     for (Class<?> subtype : subtypes) {
/* 473 */       _checkNotNull(subtype, "subtype to register");
/* 474 */       this._subtypes.add(new NamedType(subtype));
/*     */     } 
/* 476 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleModule registerSubtypes(NamedType... subtypes) {
/* 486 */     if (this._subtypes == null) {
/* 487 */       this._subtypes = new LinkedHashSet<>();
/*     */     }
/* 489 */     for (NamedType subtype : subtypes) {
/* 490 */       _checkNotNull(subtype, "subtype to register");
/* 491 */       this._subtypes.add(subtype);
/*     */     } 
/* 493 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleModule registerSubtypes(Collection<Class<?>> subtypes) {
/* 505 */     if (this._subtypes == null) {
/* 506 */       this._subtypes = new LinkedHashSet<>();
/*     */     }
/* 508 */     for (Class<?> subtype : subtypes) {
/* 509 */       _checkNotNull(subtype, "subtype to register");
/* 510 */       this._subtypes.add(new NamedType(subtype));
/*     */     } 
/* 512 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleModule addValueInstantiator(Class<?> beanType, ValueInstantiator inst) {
/* 530 */     _checkNotNull(beanType, "class to register value instantiator for");
/* 531 */     _checkNotNull(inst, "value instantiator");
/* 532 */     if (this._valueInstantiators == null) {
/* 533 */       this._valueInstantiators = new SimpleValueInstantiators();
/*     */     }
/* 535 */     this._valueInstantiators = this._valueInstantiators.addValueInstantiator(beanType, inst);
/* 536 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleModule setMixInAnnotation(Class<?> targetType, Class<?> mixinClass) {
/* 549 */     _checkNotNull(targetType, "target type");
/* 550 */     _checkNotNull(mixinClass, "mixin class");
/* 551 */     if (this._mixins == null) {
/* 552 */       this._mixins = new HashMap<>();
/*     */     }
/* 554 */     this._mixins.put(targetType, mixinClass);
/* 555 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getModuleName() {
/* 566 */     return this._name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setupModule(Module.SetupContext context) {
/* 579 */     if (this._serializers != null) {
/* 580 */       context.addSerializers((Serializers)this._serializers);
/*     */     }
/* 582 */     if (this._deserializers != null) {
/* 583 */       context.addDeserializers((Deserializers)this._deserializers);
/*     */     }
/* 585 */     if (this._keySerializers != null) {
/* 586 */       context.addKeySerializers((Serializers)this._keySerializers);
/*     */     }
/* 588 */     if (this._keyDeserializers != null) {
/* 589 */       context.addKeyDeserializers(this._keyDeserializers);
/*     */     }
/* 591 */     if (this._abstractTypes != null) {
/* 592 */       context.addAbstractTypeResolver(this._abstractTypes);
/*     */     }
/* 594 */     if (this._valueInstantiators != null) {
/* 595 */       context.addValueInstantiators((ValueInstantiators)this._valueInstantiators);
/*     */     }
/* 597 */     if (this._deserializerModifier != null) {
/* 598 */       context.addBeanDeserializerModifier(this._deserializerModifier);
/*     */     }
/* 600 */     if (this._serializerModifier != null) {
/* 601 */       context.addBeanSerializerModifier(this._serializerModifier);
/*     */     }
/* 603 */     if (this._subtypes != null && this._subtypes.size() > 0) {
/* 604 */       context.registerSubtypes((NamedType[])this._subtypes.toArray((Object[])new NamedType[this._subtypes.size()]));
/*     */     }
/* 606 */     if (this._namingStrategy != null) {
/* 607 */       context.setNamingStrategy(this._namingStrategy);
/*     */     }
/* 609 */     if (this._mixins != null) {
/* 610 */       for (Map.Entry<Class<?>, Class<?>> entry : this._mixins.entrySet()) {
/* 611 */         context.setMixInAnnotations(entry.getKey(), entry.getValue());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Version version() {
/* 617 */     return this._version;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _checkNotNull(Object thingy, String type) {
/* 630 */     if (thingy == null)
/* 631 */       throw new IllegalArgumentException(String.format("Cannot pass `null` as %s", new Object[] { type })); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\module\SimpleModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */