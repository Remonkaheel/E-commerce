/*     */ package com.fasterxml.jackson.databind.jdk14;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedConstructor;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedWithParams;
/*     */ import com.fasterxml.jackson.databind.introspect.PotentialCreator;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.NativeImageUtil;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDK14Util
/*     */ {
/*     */   public static String[] getRecordFieldNames(Class<?> recordType) {
/*  35 */     return RecordAccessor.instance().getRecordFieldNames(recordType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PotentialCreator findCanonicalRecordConstructor(MapperConfig<?> config, AnnotatedClass recordClass, List<PotentialCreator> constructors) {
/*  45 */     RawTypeName[] recordFields = RecordAccessor.instance().getRecordFields(recordClass.getRawType());
/*     */     
/*  47 */     if (recordFields == null)
/*     */     {
/*  49 */       return null;
/*     */     }
/*     */ 
/*     */     
/*  53 */     int argCount = recordFields.length;
/*     */     
/*  55 */     if (argCount == 0) {
/*     */       
/*  57 */       AnnotatedConstructor defCtor = recordClass.getDefaultConstructor();
/*  58 */       if (defCtor != null) {
/*  59 */         return new PotentialCreator((AnnotatedWithParams)defCtor, null);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  64 */     label30: for (PotentialCreator ctor : constructors) {
/*  65 */       if (ctor.paramCount() != argCount) {
/*     */         continue;
/*     */       }
/*  68 */       for (int i = 0; i < argCount; i++) {
/*  69 */         if (!ctor.creator().getRawParameterType(i).equals((recordFields[i]).rawType)) {
/*     */           continue label30;
/*     */         }
/*     */       } 
/*     */       
/*  74 */       PropertyName[] implicits = new PropertyName[argCount];
/*  75 */       for (int j = 0; j < argCount; j++) {
/*  76 */         implicits[j] = PropertyName.construct((recordFields[j]).name);
/*     */       }
/*  78 */       return ctor.introspectParamNames(config, implicits);
/*     */     } 
/*     */     
/*  81 */     throw new IllegalArgumentException("Failed to find the canonical Record constructor of type " + 
/*  82 */         ClassUtil.getTypeDescription(recordClass.getType()));
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static AnnotatedConstructor findRecordConstructor(DeserializationContext ctxt, BeanDescription beanDesc, List<String> names) {
/*  88 */     return findRecordConstructor(beanDesc.getClassInfo(), ctxt.getAnnotationIntrospector(), (MapperConfig<?>)ctxt.getConfig(), names);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static AnnotatedConstructor findRecordConstructor(AnnotatedClass recordClass, AnnotationIntrospector intr, MapperConfig<?> config, List<String> names) {
/*  94 */     return (new CreatorLocator(config, recordClass))
/*  95 */       .locate(names);
/*     */   }
/*     */   
/*     */   static class RecordAccessor
/*     */   {
/*     */     private final Method RECORD_GET_RECORD_COMPONENTS;
/*     */     private final Method RECORD_COMPONENT_GET_NAME;
/*     */     private final Method RECORD_COMPONENT_GET_TYPE;
/*     */     private static final RecordAccessor INSTANCE;
/*     */     private static final RuntimeException PROBLEM;
/*     */     
/*     */     static {
/* 107 */       RuntimeException prob = null;
/* 108 */       RecordAccessor inst = null;
/*     */       try {
/* 110 */         inst = new RecordAccessor();
/* 111 */       } catch (RuntimeException e) {
/* 112 */         prob = e;
/*     */       } 
/* 114 */       INSTANCE = inst;
/* 115 */       PROBLEM = prob;
/*     */     }
/*     */     
/*     */     private RecordAccessor() throws RuntimeException {
/*     */       try {
/* 120 */         this.RECORD_GET_RECORD_COMPONENTS = Class.class.getMethod("getRecordComponents", new Class[0]);
/* 121 */         Class<?> c = Class.forName("java.lang.reflect.RecordComponent");
/* 122 */         this.RECORD_COMPONENT_GET_NAME = c.getMethod("getName", new Class[0]);
/* 123 */         this.RECORD_COMPONENT_GET_TYPE = c.getMethod("getType", new Class[0]);
/* 124 */       } catch (Exception e) {
/* 125 */         throw new RuntimeException(String.format("Failed to access Methods needed to support `java.lang.Record`: (%s) %s", new Object[] { e
/*     */                 
/* 127 */                 .getClass().getName(), e.getMessage() }), e);
/*     */       } 
/*     */     }
/*     */     
/*     */     public static RecordAccessor instance() {
/* 132 */       if (PROBLEM != null) {
/* 133 */         throw PROBLEM;
/*     */       }
/* 135 */       return INSTANCE;
/*     */     }
/*     */ 
/*     */     
/*     */     public String[] getRecordFieldNames(Class<?> recordType) throws IllegalArgumentException {
/* 140 */       Object[] components = recordComponents(recordType);
/* 141 */       if (components == null)
/*     */       {
/* 143 */         return null;
/*     */       }
/* 145 */       String[] names = new String[components.length];
/* 146 */       for (int i = 0; i < components.length; i++) {
/*     */         try {
/* 148 */           names[i] = (String)this.RECORD_COMPONENT_GET_NAME.invoke(components[i], new Object[0]);
/* 149 */         } catch (Exception e) {
/* 150 */           throw new IllegalArgumentException(String.format("Failed to access name of field #%d (of %d) of Record type %s", new Object[] {
/*     */                   
/* 152 */                   Integer.valueOf(i), Integer.valueOf(components.length), ClassUtil.nameOf(recordType) }), e);
/*     */         } 
/*     */       } 
/* 155 */       return names;
/*     */     }
/*     */ 
/*     */     
/*     */     public JDK14Util.RawTypeName[] getRecordFields(Class<?> recordType) throws IllegalArgumentException {
/* 160 */       Object[] components = recordComponents(recordType);
/* 161 */       if (components == null)
/*     */       {
/* 163 */         return null;
/*     */       }
/* 165 */       JDK14Util.RawTypeName[] results = new JDK14Util.RawTypeName[components.length];
/* 166 */       for (int i = 0; i < components.length; i++) {
/*     */         String name; Class<?> type;
/*     */         try {
/* 169 */           name = (String)this.RECORD_COMPONENT_GET_NAME.invoke(components[i], new Object[0]);
/* 170 */         } catch (Exception e) {
/* 171 */           throw new IllegalArgumentException(String.format("Failed to access name of field #%d (of %d) of Record type %s", new Object[] {
/*     */                   
/* 173 */                   Integer.valueOf(i), Integer.valueOf(components.length), ClassUtil.nameOf(recordType)
/*     */                 }), e);
/*     */         } 
/*     */         try {
/* 177 */           type = (Class)this.RECORD_COMPONENT_GET_TYPE.invoke(components[i], new Object[0]);
/* 178 */         } catch (Exception e) {
/* 179 */           throw new IllegalArgumentException(String.format("Failed to access type of field #%d (of %d) of Record type %s", new Object[] {
/*     */                   
/* 181 */                   Integer.valueOf(i), Integer.valueOf(components.length), ClassUtil.nameOf(recordType) }), e);
/*     */         } 
/* 183 */         results[i] = new JDK14Util.RawTypeName(type, name);
/*     */       } 
/* 185 */       return results;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object[] recordComponents(Class<?> recordType) throws IllegalArgumentException {
/*     */       try {
/* 191 */         return (Object[])this.RECORD_GET_RECORD_COMPONENTS.invoke(recordType, new Object[0]);
/* 192 */       } catch (Exception e) {
/* 193 */         if (NativeImageUtil.isUnsupportedFeatureError(e)) {
/* 194 */           return null;
/*     */         }
/* 196 */         throw new IllegalArgumentException("Failed to access RecordComponents of type " + 
/* 197 */             ClassUtil.nameOf(recordType));
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class RawTypeName
/*     */   {
/*     */     public final Class<?> rawType;
/*     */     public final String name;
/*     */     
/*     */     public RawTypeName(Class<?> rt, String n) {
/* 208 */       this.rawType = rt;
/* 209 */       this.name = n;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   static class CreatorLocator
/*     */   {
/*     */     protected final AnnotatedClass _recordClass;
/*     */     protected final MapperConfig<?> _config;
/*     */     protected final AnnotationIntrospector _intr;
/*     */     protected final List<AnnotatedConstructor> _constructors;
/*     */     protected final AnnotatedConstructor _primaryConstructor;
/*     */     protected final JDK14Util.RawTypeName[] _recordFields;
/*     */     
/*     */     CreatorLocator(MapperConfig<?> config, AnnotatedClass recordClass) {
/* 225 */       this._recordClass = recordClass;
/*     */       
/* 227 */       this._intr = config.getAnnotationIntrospector();
/* 228 */       this._config = config;
/*     */       
/* 230 */       this._recordFields = JDK14Util.RecordAccessor.instance().getRecordFields(recordClass.getRawType());
/* 231 */       if (this._recordFields == null) {
/*     */         
/* 233 */         this._constructors = recordClass.getConstructors();
/* 234 */         this._primaryConstructor = null;
/*     */       } else {
/* 236 */         int argCount = this._recordFields.length;
/*     */ 
/*     */ 
/*     */         
/* 240 */         AnnotatedConstructor primary = null;
/*     */ 
/*     */         
/* 243 */         if (argCount == 0) {
/* 244 */           primary = recordClass.getDefaultConstructor();
/* 245 */           this._constructors = Collections.singletonList(primary);
/*     */         } else {
/* 247 */           this._constructors = recordClass.getConstructors();
/*     */           
/* 249 */           label28: for (AnnotatedConstructor ctor : this._constructors) {
/* 250 */             if (ctor.getParameterCount() != argCount) {
/*     */               continue;
/*     */             }
/* 253 */             for (int i = 0; i < argCount; i++) {
/* 254 */               if (!ctor.getRawParameterType(i).equals((this._recordFields[i]).rawType)) {
/*     */                 continue label28;
/*     */               }
/*     */             } 
/* 258 */             primary = ctor;
/*     */           } 
/*     */         } 
/*     */         
/* 262 */         if (primary == null) {
/* 263 */           throw new IllegalArgumentException("Failed to find the canonical Record constructor of type " + 
/* 264 */               ClassUtil.getTypeDescription(this._recordClass.getType()));
/*     */         }
/* 266 */         this._primaryConstructor = primary;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotatedConstructor locate(List<String> names) {
/* 275 */       for (AnnotatedConstructor ctor : this._constructors) {
/* 276 */         JsonCreator.Mode creatorMode = this._intr.findCreatorAnnotation(this._config, (Annotated)ctor);
/* 277 */         if (null == creatorMode || JsonCreator.Mode.DISABLED == creatorMode) {
/*     */           continue;
/*     */         }
/*     */         
/* 281 */         if (JsonCreator.Mode.DELEGATING == creatorMode) {
/* 282 */           return null;
/*     */         }
/* 284 */         if (ctor != this._primaryConstructor) {
/* 285 */           return null;
/*     */         }
/*     */       } 
/*     */       
/* 289 */       if (this._recordFields == null)
/*     */       {
/* 291 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 296 */       for (JDK14Util.RawTypeName field : this._recordFields) {
/* 297 */         names.add(field.name);
/*     */       }
/* 299 */       return this._primaryConstructor;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jdk14\JDK14Util.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */