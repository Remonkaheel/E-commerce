/*      */ package com.fasterxml.jackson.databind.introspect;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonInclude;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.annotation.JsonSetter;
/*      */ import com.fasterxml.jackson.annotation.Nulls;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.MapperFeature;
/*      */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*      */ import com.fasterxml.jackson.databind.PropertyName;
/*      */ import com.fasterxml.jackson.databind.cfg.ConfigOverride;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import java.lang.reflect.Member;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ import java.util.stream.Collectors;
/*      */ 
/*      */ public class POJOPropertyBuilder extends BeanPropertyDefinition implements Comparable<POJOPropertyBuilder> {
/*   30 */   private static final AnnotationIntrospector.ReferenceProperty NOT_REFEFERENCE_PROP = AnnotationIntrospector.ReferenceProperty.managed("");
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _forSerialization;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final MapperConfig<?> _config;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final AnnotationIntrospector _annotationIntrospector;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final PropertyName _name;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final PropertyName _internalName;
/*      */ 
/*      */ 
/*      */   
/*      */   protected Linked<AnnotatedField> _fields;
/*      */ 
/*      */ 
/*      */   
/*      */   protected Linked<AnnotatedParameter> _ctorParameters;
/*      */ 
/*      */   
/*      */   protected Linked<AnnotatedMethod> _getters;
/*      */ 
/*      */   
/*      */   protected Linked<AnnotatedMethod> _setters;
/*      */ 
/*      */   
/*      */   protected transient PropertyMetadata _metadata;
/*      */ 
/*      */   
/*      */   protected transient AnnotationIntrospector.ReferenceProperty _referenceInfo;
/*      */ 
/*      */ 
/*      */   
/*      */   public POJOPropertyBuilder(MapperConfig<?> config, AnnotationIntrospector ai, boolean forSerialization, PropertyName internalName) {
/*   75 */     this(config, ai, forSerialization, internalName, internalName);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected POJOPropertyBuilder(MapperConfig<?> config, AnnotationIntrospector ai, boolean forSerialization, PropertyName internalName, PropertyName name) {
/*   81 */     this._config = config;
/*   82 */     this._annotationIntrospector = ai;
/*   83 */     this._internalName = internalName;
/*   84 */     this._name = name;
/*   85 */     this._forSerialization = forSerialization;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected POJOPropertyBuilder(POJOPropertyBuilder src, PropertyName newName) {
/*   91 */     this._config = src._config;
/*   92 */     this._annotationIntrospector = src._annotationIntrospector;
/*   93 */     this._internalName = src._internalName;
/*   94 */     this._name = newName;
/*   95 */     this._fields = src._fields;
/*   96 */     this._ctorParameters = src._ctorParameters;
/*   97 */     this._getters = src._getters;
/*   98 */     this._setters = src._setters;
/*   99 */     this._forSerialization = src._forSerialization;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public POJOPropertyBuilder withName(PropertyName newName) {
/*  110 */     return new POJOPropertyBuilder(this, newName);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public POJOPropertyBuilder withSimpleName(String newSimpleName) {
/*  116 */     PropertyName newName = this._name.withSimpleName(newSimpleName);
/*  117 */     return (newName == this._name) ? this : new POJOPropertyBuilder(this, newName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareTo(POJOPropertyBuilder other) {
/*  132 */     if (this._ctorParameters != null) {
/*  133 */       if (other._ctorParameters == null) {
/*  134 */         return -1;
/*      */       }
/*  136 */     } else if (other._ctorParameters != null) {
/*  137 */       return 1;
/*      */     } 
/*      */     
/*  140 */     return getName().compareTo(other.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  151 */     return (this._name == null) ? null : this._name.getSimpleName();
/*      */   }
/*      */ 
/*      */   
/*      */   public PropertyName getFullName() {
/*  156 */     return this._name;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasName(PropertyName name) {
/*  161 */     return this._name.equals(name);
/*      */   }
/*      */   
/*      */   public String getInternalName() {
/*  165 */     return this._internalName.getSimpleName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyName getWrapperName() {
/*  174 */     AnnotatedMember member = getPrimaryMember();
/*  175 */     return (member == null || this._annotationIntrospector == null) ? null : this._annotationIntrospector
/*  176 */       .findWrapperName(member);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isExplicitlyIncluded() {
/*  189 */     return (_anyExplicits(this._fields) || 
/*  190 */       _anyExplicits(this._getters) || 
/*  191 */       _anyExplicits(this._setters) || 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  196 */       _anyExplicitNames(this._ctorParameters));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isExplicitlyNamed() {
/*  202 */     return (_anyExplicitNames(this._fields) || 
/*  203 */       _anyExplicitNames(this._getters) || 
/*  204 */       _anyExplicitNames(this._setters) || 
/*  205 */       _anyExplicitNames(this._ctorParameters));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyMetadata getMetadata() {
/*  218 */     if (this._metadata == null) {
/*      */ 
/*      */       
/*  221 */       AnnotatedMember prim = getPrimaryMemberUnchecked();
/*      */       
/*  223 */       if (prim == null) {
/*  224 */         this._metadata = PropertyMetadata.STD_REQUIRED_OR_OPTIONAL;
/*      */       } else {
/*  226 */         Boolean b = this._annotationIntrospector.hasRequiredMarker(prim);
/*  227 */         String desc = this._annotationIntrospector.findPropertyDescription(prim);
/*  228 */         Integer idx = this._annotationIntrospector.findPropertyIndex(prim);
/*  229 */         String def = this._annotationIntrospector.findPropertyDefaultValue(prim);
/*      */         
/*  231 */         if (b == null && idx == null && def == null) {
/*  232 */           this
/*  233 */             ._metadata = (desc == null) ? PropertyMetadata.STD_REQUIRED_OR_OPTIONAL : PropertyMetadata.STD_REQUIRED_OR_OPTIONAL.withDescription(desc);
/*      */         } else {
/*  235 */           this._metadata = PropertyMetadata.construct(b, desc, idx, def);
/*      */         } 
/*  237 */         if (!this._forSerialization) {
/*  238 */           this._metadata = _getSetterInfo(this._metadata, prim);
/*      */         }
/*      */       } 
/*      */     } 
/*  242 */     return this._metadata;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PropertyMetadata _getSetterInfo(PropertyMetadata metadata, AnnotatedMember primary) {
/*  254 */     boolean needMerge = true;
/*  255 */     Nulls valueNulls = null;
/*  256 */     Nulls contentNulls = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  261 */     AnnotatedMember acc = getAccessor();
/*      */     
/*  263 */     if (primary != null) {
/*      */       
/*  265 */       if (this._annotationIntrospector != null) {
/*  266 */         if (acc != null) {
/*  267 */           Boolean b = this._annotationIntrospector.findMergeInfo(primary);
/*  268 */           if (b != null) {
/*  269 */             needMerge = false;
/*  270 */             if (b.booleanValue()) {
/*  271 */               metadata = metadata.withMergeInfo(PropertyMetadata.MergeInfo.createForPropertyOverride(acc));
/*      */             }
/*      */           } 
/*      */         } 
/*  275 */         JsonSetter.Value setterInfo = this._annotationIntrospector.findSetterInfo(primary);
/*  276 */         if (setterInfo != null) {
/*  277 */           valueNulls = setterInfo.nonDefaultValueNulls();
/*  278 */           contentNulls = setterInfo.nonDefaultContentNulls();
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  283 */       if (needMerge || valueNulls == null || contentNulls == null) {
/*      */ 
/*      */ 
/*      */         
/*  287 */         Class<?> rawType = _rawTypeOf(primary);
/*  288 */         ConfigOverride co = this._config.getConfigOverride(rawType);
/*  289 */         JsonSetter.Value setterInfo = co.getSetterInfo();
/*  290 */         if (setterInfo != null) {
/*  291 */           if (valueNulls == null) {
/*  292 */             valueNulls = setterInfo.nonDefaultValueNulls();
/*      */           }
/*  294 */           if (contentNulls == null) {
/*  295 */             contentNulls = setterInfo.nonDefaultContentNulls();
/*      */           }
/*      */         } 
/*  298 */         if (needMerge && acc != null) {
/*  299 */           Boolean b = co.getMergeable();
/*  300 */           if (b != null) {
/*  301 */             needMerge = false;
/*  302 */             if (b.booleanValue()) {
/*  303 */               metadata = metadata.withMergeInfo(PropertyMetadata.MergeInfo.createForTypeOverride(acc));
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  309 */     if (needMerge || valueNulls == null || contentNulls == null) {
/*  310 */       JsonSetter.Value setterInfo = this._config.getDefaultSetterInfo();
/*  311 */       if (valueNulls == null) {
/*  312 */         valueNulls = setterInfo.nonDefaultValueNulls();
/*      */       }
/*  314 */       if (contentNulls == null) {
/*  315 */         contentNulls = setterInfo.nonDefaultContentNulls();
/*      */       }
/*  317 */       if (needMerge) {
/*  318 */         Boolean b = this._config.getDefaultMergeable();
/*  319 */         if (Boolean.TRUE.equals(b) && acc != null) {
/*  320 */           metadata = metadata.withMergeInfo(PropertyMetadata.MergeInfo.createForDefaults(acc));
/*      */         }
/*      */       } 
/*      */     } 
/*  324 */     if (valueNulls != null || contentNulls != null) {
/*  325 */       metadata = metadata.withNulls(valueNulls, contentNulls);
/*      */     }
/*  327 */     return metadata;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType getPrimaryType() {
/*  337 */     if (this._forSerialization) {
/*  338 */       AnnotatedMember annotatedMember = getGetter();
/*  339 */       if (annotatedMember == null) {
/*  340 */         annotatedMember = getField();
/*  341 */         if (annotatedMember == null)
/*      */         {
/*  343 */           return TypeFactory.unknownType();
/*      */         }
/*      */       } 
/*  346 */       return annotatedMember.getType();
/*      */     } 
/*  348 */     AnnotatedMember m = getConstructorParameter();
/*  349 */     if (m == null) {
/*  350 */       m = getSetter();
/*      */ 
/*      */       
/*  353 */       if (m != null) {
/*  354 */         return ((AnnotatedMethod)m).getParameterType(0);
/*      */       }
/*  356 */       m = getField();
/*      */     } 
/*      */     
/*  359 */     if (m == null) {
/*  360 */       m = getGetter();
/*  361 */       if (m == null) {
/*  362 */         return TypeFactory.unknownType();
/*      */       }
/*      */     } 
/*  365 */     return m.getType();
/*      */   }
/*      */ 
/*      */   
/*      */   public Class<?> getRawPrimaryType() {
/*  370 */     return getPrimaryType().getRawClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasGetter() {
/*  380 */     return (this._getters != null);
/*      */   }
/*      */   public boolean hasSetter() {
/*  383 */     return (this._setters != null);
/*      */   }
/*      */   public boolean hasField() {
/*  386 */     return (this._fields != null);
/*      */   }
/*      */   public boolean hasConstructorParameter() {
/*  389 */     return (this._ctorParameters != null);
/*      */   }
/*      */   
/*      */   public boolean couldDeserialize() {
/*  393 */     return (this._ctorParameters != null || this._setters != null || (this._fields != null && 
/*      */ 
/*      */ 
/*      */       
/*  397 */       _anyVisible(this._fields)));
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean couldSerialize() {
/*  402 */     return (this._getters != null || this._fields != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotatedMethod getGetter() {
/*  409 */     Linked<AnnotatedMethod> curr = this._getters;
/*  410 */     if (curr == null) {
/*  411 */       return null;
/*      */     }
/*  413 */     Linked<AnnotatedMethod> next = curr.next;
/*  414 */     if (next == null) {
/*  415 */       return (AnnotatedMethod)curr.value;
/*      */     }
/*      */     
/*  418 */     for (; next != null; next = next.next) {
/*      */ 
/*      */ 
/*      */       
/*  422 */       Class<?> currClass = ((AnnotatedMethod)curr.value).getDeclaringClass();
/*  423 */       Class<?> nextClass = ((AnnotatedMethod)next.value).getDeclaringClass();
/*  424 */       if (currClass != nextClass) {
/*  425 */         if (currClass.isAssignableFrom(nextClass)) {
/*  426 */           curr = next;
/*      */           continue;
/*      */         } 
/*  429 */         if (nextClass.isAssignableFrom(currClass)) {
/*      */           continue;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  439 */       int priNext = _getterPriority((AnnotatedMethod)next.value);
/*  440 */       int priCurr = _getterPriority((AnnotatedMethod)curr.value);
/*      */       
/*  442 */       if (priNext != priCurr) {
/*  443 */         if (priNext < priCurr) {
/*  444 */           curr = next;
/*      */         }
/*      */       } else {
/*      */         
/*  448 */         throw new IllegalArgumentException("Conflicting getter definitions for property \"" + getName() + "\": " + ((AnnotatedMethod)curr.value)
/*  449 */             .getFullName() + " vs " + ((AnnotatedMethod)next.value).getFullName());
/*      */       }  continue;
/*      */     } 
/*  452 */     this._getters = curr.withoutNext();
/*  453 */     return (AnnotatedMethod)curr.value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AnnotatedMethod getGetterUnchecked() {
/*  462 */     Linked<AnnotatedMethod> curr = this._getters;
/*  463 */     if (curr == null) {
/*  464 */       return null;
/*      */     }
/*  466 */     return (AnnotatedMethod)curr.value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotatedMethod getSetter() {
/*  473 */     Linked<AnnotatedMethod> curr = this._setters;
/*  474 */     if (curr == null) {
/*  475 */       return null;
/*      */     }
/*  477 */     Linked<AnnotatedMethod> next = curr.next;
/*  478 */     if (next == null) {
/*  479 */       return (AnnotatedMethod)curr.value;
/*      */     }
/*      */     
/*  482 */     for (; next != null; next = next.next) {
/*  483 */       AnnotatedMethod selected = _selectSetter((AnnotatedMethod)curr.value, (AnnotatedMethod)next.value);
/*  484 */       if (selected != curr.value)
/*      */       {
/*      */         
/*  487 */         if (selected == next.value) {
/*  488 */           curr = next;
/*      */         }
/*      */         else {
/*      */           
/*  492 */           return _selectSetterFromMultiple(curr, next);
/*      */         } 
/*      */       }
/*      */     } 
/*  496 */     this._setters = curr.withoutNext();
/*  497 */     return (AnnotatedMethod)curr.value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AnnotatedMethod getSetterUnchecked() {
/*  506 */     Linked<AnnotatedMethod> curr = this._setters;
/*  507 */     if (curr == null) {
/*  508 */       return null;
/*      */     }
/*  510 */     return (AnnotatedMethod)curr.value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AnnotatedMethod _selectSetterFromMultiple(Linked<AnnotatedMethod> curr, Linked<AnnotatedMethod> next) {
/*  532 */     List<AnnotatedMethod> conflicts = new ArrayList<>();
/*  533 */     conflicts.add((AnnotatedMethod)curr.value);
/*  534 */     conflicts.add((AnnotatedMethod)next.value);
/*      */     
/*  536 */     next = next.next;
/*  537 */     for (; next != null; next = next.next) {
/*  538 */       AnnotatedMethod selected = _selectSetter((AnnotatedMethod)curr.value, (AnnotatedMethod)next.value);
/*  539 */       if (selected != curr.value)
/*      */       {
/*      */ 
/*      */         
/*  543 */         if (selected == next.value) {
/*      */           
/*  545 */           conflicts.clear();
/*  546 */           curr = next;
/*      */         }
/*      */         else {
/*      */           
/*  550 */           conflicts.add((AnnotatedMethod)next.value);
/*      */         } 
/*      */       }
/*      */     } 
/*  554 */     if (conflicts.isEmpty()) {
/*  555 */       this._setters = curr.withoutNext();
/*  556 */       return (AnnotatedMethod)curr.value;
/*      */     } 
/*      */ 
/*      */     
/*  560 */     String desc = conflicts.stream().map(AnnotatedMethod::getFullName).collect(Collectors.joining(" vs "));
/*  561 */     throw new IllegalArgumentException(String.format("Conflicting setter definitions for property \"%s\": %s", new Object[] {
/*      */             
/*  563 */             getName(), desc
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected AnnotatedMethod _selectSetter(AnnotatedMethod currM, AnnotatedMethod nextM) {
/*  570 */     Class<?> currClass = currM.getDeclaringClass();
/*  571 */     Class<?> nextClass = nextM.getDeclaringClass();
/*  572 */     if (currClass != nextClass) {
/*  573 */       if (currClass.isAssignableFrom(nextClass)) {
/*  574 */         return nextM;
/*      */       }
/*  576 */       if (nextClass.isAssignableFrom(currClass)) {
/*  577 */         return currM;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  588 */     int priNext = _setterPriority(nextM);
/*  589 */     int priCurr = _setterPriority(currM);
/*      */     
/*  591 */     if (priNext != priCurr) {
/*      */       
/*  593 */       if (priNext < priCurr) {
/*  594 */         return nextM;
/*      */       }
/*      */       
/*  597 */       return currM;
/*      */     } 
/*      */     
/*  600 */     return (this._annotationIntrospector == null) ? null : this._annotationIntrospector
/*  601 */       .resolveSetterConflict(this._config, currM, nextM);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotatedField getField() {
/*  607 */     if (this._fields == null) {
/*  608 */       return null;
/*      */     }
/*      */     
/*  611 */     AnnotatedField field = (AnnotatedField)this._fields.value;
/*  612 */     Linked<AnnotatedField> next = this._fields.next;
/*  613 */     for (; next != null; next = next.next) {
/*  614 */       AnnotatedField nextField = (AnnotatedField)next.value;
/*  615 */       Class<?> fieldClass = field.getDeclaringClass();
/*  616 */       Class<?> nextClass = nextField.getDeclaringClass();
/*  617 */       if (fieldClass != nextClass) {
/*  618 */         if (fieldClass.isAssignableFrom(nextClass)) {
/*  619 */           field = nextField;
/*      */           continue;
/*      */         } 
/*  622 */         if (nextClass.isAssignableFrom(fieldClass)) {
/*      */           continue;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  631 */       boolean currStatic = field.isStatic();
/*  632 */       boolean nextStatic = nextField.isStatic();
/*      */       
/*  634 */       if (currStatic != nextStatic) {
/*  635 */         if (currStatic) {
/*  636 */           field = nextField;
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/*  641 */         throw new IllegalArgumentException("Multiple fields representing property \"" + getName() + "\": " + field
/*  642 */             .getFullName() + " vs " + nextField.getFullName());
/*      */       }  continue;
/*  644 */     }  return field;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AnnotatedField getFieldUnchecked() {
/*  653 */     Linked<AnnotatedField> curr = this._fields;
/*  654 */     if (curr == null) {
/*  655 */       return null;
/*      */     }
/*  657 */     return (AnnotatedField)curr.value;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotatedParameter getConstructorParameter() {
/*  663 */     if (this._ctorParameters == null) {
/*  664 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  674 */     Linked<AnnotatedParameter> curr = this._ctorParameters;
/*      */     while (true) {
/*  676 */       if (((AnnotatedParameter)curr.value).getOwner() instanceof AnnotatedConstructor) {
/*  677 */         return (AnnotatedParameter)curr.value;
/*      */       }
/*  679 */       curr = curr.next;
/*  680 */       if (curr == null)
/*  681 */         return (AnnotatedParameter)this._ctorParameters.value; 
/*      */     } 
/*      */   }
/*      */   
/*      */   public Iterator<AnnotatedParameter> getConstructorParameters() {
/*  686 */     if (this._ctorParameters == null) {
/*  687 */       return ClassUtil.emptyIterator();
/*      */     }
/*  689 */     return new MemberIterator<>(this._ctorParameters);
/*      */   }
/*      */ 
/*      */   
/*      */   public AnnotatedMember getPrimaryMember() {
/*  694 */     if (this._forSerialization) {
/*  695 */       return getAccessor();
/*      */     }
/*  697 */     AnnotatedMember m = getMutator();
/*      */     
/*  699 */     if (m == null) {
/*  700 */       m = getAccessor();
/*      */     }
/*  702 */     return m;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AnnotatedMember getPrimaryMemberUnchecked() {
/*  710 */     if (this._forSerialization) {
/*      */       
/*  712 */       if (this._getters != null) {
/*  713 */         return (AnnotatedMember)this._getters.value;
/*      */       }
/*      */       
/*  716 */       if (this._fields != null) {
/*  717 */         return (AnnotatedMember)this._fields.value;
/*      */       }
/*  719 */       return null;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  725 */     if (this._ctorParameters != null) {
/*  726 */       return (AnnotatedMember)this._ctorParameters.value;
/*      */     }
/*      */     
/*  729 */     if (this._setters != null) {
/*  730 */       return (AnnotatedMember)this._setters.value;
/*      */     }
/*      */     
/*  733 */     if (this._fields != null) {
/*  734 */       return (AnnotatedMember)this._fields.value;
/*      */     }
/*      */ 
/*      */     
/*  738 */     if (this._getters != null) {
/*  739 */       return (AnnotatedMember)this._getters.value;
/*      */     }
/*  741 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected int _getterPriority(AnnotatedMethod m) {
/*  746 */     String name = m.getName();
/*      */     
/*  748 */     if (name.startsWith("get") && name.length() > 3)
/*      */     {
/*  750 */       return 1;
/*      */     }
/*  752 */     if (name.startsWith("is") && name.length() > 2) {
/*  753 */       return 2;
/*      */     }
/*  755 */     return 3;
/*      */   }
/*      */ 
/*      */   
/*      */   protected int _setterPriority(AnnotatedMethod m) {
/*  760 */     String name = m.getName();
/*  761 */     if (name.startsWith("set") && name.length() > 3)
/*      */     {
/*  763 */       return 1;
/*      */     }
/*  765 */     return 2;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasFieldOrGetter(AnnotatedMember member) {
/*  770 */     return (_hasAccessor((Linked)this._fields, member) || _hasAccessor((Linked)this._getters, member));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _hasAccessor(Linked<? extends AnnotatedMember> node, AnnotatedMember memberToMatch) {
/*  777 */     Member rawMemberToMatch = memberToMatch.getMember();
/*  778 */     for (; node != null; node = node.next) {
/*  779 */       if (((AnnotatedMember)node.value).getMember() == rawMemberToMatch) {
/*  780 */         return true;
/*      */       }
/*      */     } 
/*  783 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?>[] findViews() {
/*  794 */     return fromMemberAnnotations((WithMember)new WithMember<Class<?>[]>()
/*      */         {
/*      */           public Class<?>[] withMember(AnnotatedMember member) {
/*  797 */             return POJOPropertyBuilder.this._annotationIntrospector.findViews(member);
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationIntrospector.ReferenceProperty findReferenceType() {
/*  806 */     AnnotationIntrospector.ReferenceProperty result = this._referenceInfo;
/*  807 */     if (result != null) {
/*  808 */       if (result == NOT_REFEFERENCE_PROP) {
/*  809 */         return null;
/*      */       }
/*  811 */       return result;
/*      */     } 
/*  813 */     result = fromMemberAnnotations(new WithMember<AnnotationIntrospector.ReferenceProperty>()
/*      */         {
/*      */           public AnnotationIntrospector.ReferenceProperty withMember(AnnotatedMember member) {
/*  816 */             return POJOPropertyBuilder.this._annotationIntrospector.findReferenceType(member);
/*      */           }
/*      */         });
/*  819 */     this._referenceInfo = (result == null) ? NOT_REFEFERENCE_PROP : result;
/*  820 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isTypeId() {
/*  825 */     Boolean b = fromMemberAnnotations(new WithMember<Boolean>()
/*      */         {
/*      */           public Boolean withMember(AnnotatedMember member) {
/*  828 */             return POJOPropertyBuilder.this._annotationIntrospector.isTypeId(member);
/*      */           }
/*      */         });
/*  831 */     return (b != null && b.booleanValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public ObjectIdInfo findObjectIdInfo() {
/*  836 */     return fromMemberAnnotations(new WithMember<ObjectIdInfo>()
/*      */         {
/*      */           public ObjectIdInfo withMember(AnnotatedMember member) {
/*  839 */             ObjectIdInfo info = POJOPropertyBuilder.this._annotationIntrospector.findObjectIdInfo(member);
/*  840 */             if (info != null) {
/*  841 */               info = POJOPropertyBuilder.this._annotationIntrospector.findObjectReferenceInfo(member, info);
/*      */             }
/*  843 */             return info;
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonInclude.Value findInclusion() {
/*  850 */     AnnotatedMember a = getAccessor();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  856 */     JsonInclude.Value v = (this._annotationIntrospector == null) ? null : this._annotationIntrospector.findPropertyInclusion(a);
/*  857 */     return (v == null) ? JsonInclude.Value.empty() : v;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<PropertyName> findAliases() {
/*  863 */     AnnotatedMember ann = getPrimaryMember();
/*  864 */     if (ann != null) {
/*  865 */       List<PropertyName> propertyNames = this._annotationIntrospector.findPropertyAliases(ann);
/*  866 */       if (propertyNames != null) {
/*  867 */         return propertyNames;
/*      */       }
/*      */     } 
/*  870 */     return Collections.emptyList();
/*      */   }
/*      */   
/*      */   public JsonProperty.Access findAccess() {
/*  874 */     JsonProperty.Access acc = fromMemberAnnotationsExcept(new WithMember<JsonProperty.Access>()
/*      */         {
/*      */           public JsonProperty.Access withMember(AnnotatedMember member) {
/*  877 */             return POJOPropertyBuilder.this._annotationIntrospector.findPropertyAccess(member);
/*      */           }
/*      */         },  JsonProperty.Access.AUTO);
/*      */ 
/*      */     
/*  882 */     if (this._config.isEnabled(MapperFeature.INVERSE_READ_WRITE_ACCESS)) {
/*  883 */       if (acc == JsonProperty.Access.READ_ONLY) {
/*  884 */         acc = JsonProperty.Access.WRITE_ONLY;
/*  885 */       } else if (acc == JsonProperty.Access.WRITE_ONLY) {
/*  886 */         acc = JsonProperty.Access.READ_ONLY;
/*      */       } 
/*      */     }
/*  889 */     return acc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addField(AnnotatedField a, PropertyName name, boolean explName, boolean visible, boolean ignored) {
/*  899 */     this._fields = new Linked<>(a, this._fields, name, explName, visible, ignored);
/*      */   }
/*      */   
/*      */   public void addCtor(AnnotatedParameter a, PropertyName name, boolean explName, boolean visible, boolean ignored) {
/*  903 */     this._ctorParameters = new Linked<>(a, this._ctorParameters, name, explName, visible, ignored);
/*      */   }
/*      */   
/*      */   public void addGetter(AnnotatedMethod a, PropertyName name, boolean explName, boolean visible, boolean ignored) {
/*  907 */     this._getters = new Linked<>(a, this._getters, name, explName, visible, ignored);
/*      */   }
/*      */   
/*      */   public void addSetter(AnnotatedMethod a, PropertyName name, boolean explName, boolean visible, boolean ignored) {
/*  911 */     this._setters = new Linked<>(a, this._setters, name, explName, visible, ignored);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addAll(POJOPropertyBuilder src) {
/*  920 */     this._fields = merge(this._fields, src._fields);
/*  921 */     this._ctorParameters = merge(this._ctorParameters, src._ctorParameters);
/*  922 */     this._getters = merge(this._getters, src._getters);
/*  923 */     this._setters = merge(this._setters, src._setters);
/*      */   }
/*      */ 
/*      */   
/*      */   private static <T> Linked<T> merge(Linked<T> chain1, Linked<T> chain2) {
/*  928 */     if (chain1 == null) {
/*  929 */       return chain2;
/*      */     }
/*  931 */     if (chain2 == null) {
/*  932 */       return chain1;
/*      */     }
/*  934 */     return chain1.append(chain2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeIgnored() {
/*  949 */     this._fields = _removeIgnored(this._fields);
/*  950 */     this._getters = _removeIgnored(this._getters);
/*  951 */     this._setters = _removeIgnored(this._setters);
/*  952 */     this._ctorParameters = _removeIgnored(this._ctorParameters);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonProperty.Access removeNonVisible(boolean inferMutators, POJOPropertiesCollector parent) {
/*  969 */     JsonProperty.Access acc = findAccess();
/*  970 */     if (acc == null) {
/*  971 */       acc = JsonProperty.Access.AUTO;
/*      */     }
/*      */     
/*  974 */     switch (acc) {
/*      */ 
/*      */ 
/*      */       
/*      */       case READ_ONLY:
/*  979 */         if (parent != null) {
/*  980 */           parent._collectIgnorals(getName());
/*  981 */           for (PropertyName pn : findExplicitNames()) {
/*  982 */             parent._collectIgnorals(pn.getSimpleName());
/*      */           }
/*      */         } 
/*      */         
/*  986 */         this._setters = null;
/*  987 */         this._ctorParameters = null;
/*  988 */         if (!this._forSerialization) {
/*  989 */           this._fields = null;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case READ_WRITE:
/* 1012 */         return acc;
/*      */       case WRITE_ONLY:
/*      */         this._getters = null; if (this._forSerialization)
/*      */           this._fields = null; 
/*      */     }  this._getters = _removeNonVisible(this._getters);
/*      */     this._ctorParameters = _removeNonVisible(this._ctorParameters);
/*      */     if (!inferMutators || this._getters == null) {
/*      */       this._fields = _removeNonVisible(this._fields);
/*      */       this._setters = _removeNonVisible(this._setters);
/* 1021 */     }  } public void removeConstructors() { this._ctorParameters = null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeFields() {
/* 1030 */     this._fields = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void trimByVisibility() {
/* 1040 */     this._fields = _trimByVisibility(this._fields);
/* 1041 */     this._getters = _trimByVisibility(this._getters);
/* 1042 */     this._setters = _trimByVisibility(this._setters);
/* 1043 */     this._ctorParameters = _trimByVisibility(this._ctorParameters);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void mergeAnnotations(boolean forSerialization) {
/* 1049 */     if (forSerialization) {
/* 1050 */       if (this._getters != null) {
/* 1051 */         AnnotationMap ann = _mergeAnnotations(0, (Linked<? extends AnnotatedMember>[])new Linked[] { this._getters, this._fields, this._ctorParameters, this._setters });
/* 1052 */         this._getters = _applyAnnotations(this._getters, ann);
/* 1053 */       } else if (this._fields != null) {
/* 1054 */         AnnotationMap ann = _mergeAnnotations(0, (Linked<? extends AnnotatedMember>[])new Linked[] { this._fields, this._ctorParameters, this._setters });
/* 1055 */         this._fields = _applyAnnotations(this._fields, ann);
/*      */       }
/*      */     
/* 1058 */     } else if (this._ctorParameters != null) {
/* 1059 */       AnnotationMap ann = _mergeAnnotations(0, (Linked<? extends AnnotatedMember>[])new Linked[] { this._ctorParameters, this._setters, this._fields, this._getters });
/* 1060 */       this._ctorParameters = _applyAnnotations(this._ctorParameters, ann);
/* 1061 */     } else if (this._setters != null) {
/* 1062 */       AnnotationMap ann = _mergeAnnotations(0, (Linked<? extends AnnotatedMember>[])new Linked[] { this._setters, this._fields, this._getters });
/* 1063 */       this._setters = _applyAnnotations(this._setters, ann);
/* 1064 */     } else if (this._fields != null) {
/* 1065 */       AnnotationMap ann = _mergeAnnotations(0, (Linked<? extends AnnotatedMember>[])new Linked[] { this._fields, this._getters });
/* 1066 */       this._fields = _applyAnnotations(this._fields, ann);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private AnnotationMap _mergeAnnotations(int index, Linked<? extends AnnotatedMember>... nodes) {
/* 1074 */     AnnotationMap ann = _getAllAnnotations(nodes[index]);
/* 1075 */     while (++index < nodes.length) {
/* 1076 */       if (nodes[index] != null) {
/* 1077 */         return AnnotationMap.merge(ann, _mergeAnnotations(index, nodes));
/*      */       }
/*      */     } 
/* 1080 */     return ann;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private <T extends AnnotatedMember> AnnotationMap _getAllAnnotations(Linked<T> node) {
/* 1093 */     AnnotationMap ann = ((AnnotatedMember)node.value).getAllAnnotations();
/* 1094 */     if (node.next != null) {
/* 1095 */       ann = AnnotationMap.merge(ann, _getAllAnnotations(node.next));
/*      */     }
/* 1097 */     return ann;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private <T extends AnnotatedMember> Linked<T> _applyAnnotations(Linked<T> node, AnnotationMap ann) {
/* 1111 */     AnnotatedMember annotatedMember = (AnnotatedMember)((AnnotatedMember)node.value).withAnnotations(ann);
/* 1112 */     if (node.next != null) {
/* 1113 */       node = node.withNext(_applyAnnotations(node.next, ann));
/*      */     }
/* 1115 */     return node.withValue((T)annotatedMember);
/*      */   }
/*      */ 
/*      */   
/*      */   private <T> Linked<T> _removeIgnored(Linked<T> node) {
/* 1120 */     if (node == null) {
/* 1121 */       return node;
/*      */     }
/* 1123 */     return node.withoutIgnored();
/*      */   }
/*      */ 
/*      */   
/*      */   private <T> Linked<T> _removeNonVisible(Linked<T> node) {
/* 1128 */     if (node == null) {
/* 1129 */       return node;
/*      */     }
/* 1131 */     return node.withoutNonVisible();
/*      */   }
/*      */ 
/*      */   
/*      */   private <T> Linked<T> _trimByVisibility(Linked<T> node) {
/* 1136 */     if (node == null) {
/* 1137 */       return node;
/*      */     }
/* 1139 */     return node.trimByVisibility();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private <T> boolean _anyExplicits(Linked<T> n) {
/* 1150 */     for (; n != null; n = n.next) {
/* 1151 */       if (n.name != null && n.name.hasSimpleName()) {
/* 1152 */         return true;
/*      */       }
/*      */     } 
/* 1155 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private <T> boolean _anyExplicitNames(Linked<T> n) {
/* 1160 */     for (; n != null; n = n.next) {
/* 1161 */       if (n.name != null && n.isNameExplicit) {
/* 1162 */         return true;
/*      */       }
/*      */     } 
/* 1165 */     return false;
/*      */   }
/*      */   
/*      */   public boolean anyVisible() {
/* 1169 */     return (_anyVisible(this._fields) || 
/* 1170 */       _anyVisible(this._getters) || 
/* 1171 */       _anyVisible(this._setters) || 
/* 1172 */       _anyVisible(this._ctorParameters));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private <T> boolean _anyVisible(Linked<T> n) {
/* 1178 */     for (; n != null; n = n.next) {
/* 1179 */       if (n.isVisible) {
/* 1180 */         return true;
/*      */       }
/*      */     } 
/* 1183 */     return false;
/*      */   }
/*      */   
/*      */   public boolean anyIgnorals() {
/* 1187 */     return (_anyIgnorals(this._fields) || 
/* 1188 */       _anyIgnorals(this._getters) || 
/* 1189 */       _anyIgnorals(this._setters) || 
/* 1190 */       _anyIgnorals(this._ctorParameters));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private <T> boolean _anyIgnorals(Linked<T> n) {
/* 1196 */     for (; n != null; n = n.next) {
/* 1197 */       if (n.isMarkedIgnored) {
/* 1198 */         return true;
/*      */       }
/*      */     } 
/* 1201 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean anyExplicitsWithoutIgnoral() {
/* 1206 */     return (_anyExplicitsWithoutIgnoral(this._fields) || 
/* 1207 */       _anyExplicitsWithoutIgnoral(this._getters) || 
/* 1208 */       _anyExplicitsWithoutIgnoral(this._setters) || 
/*      */       
/* 1210 */       _anyExplicitNamesWithoutIgnoral(this._ctorParameters));
/*      */   }
/*      */ 
/*      */   
/*      */   private <T> boolean _anyExplicitsWithoutIgnoral(Linked<T> n) {
/* 1215 */     for (; n != null; n = n.next) {
/* 1216 */       if (!n.isMarkedIgnored && n.name != null && n.name
/* 1217 */         .hasSimpleName()) {
/* 1218 */         return true;
/*      */       }
/*      */     } 
/* 1221 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private <T> boolean _anyExplicitNamesWithoutIgnoral(Linked<T> n) {
/* 1226 */     for (; n != null; n = n.next) {
/* 1227 */       if (!n.isMarkedIgnored && n.name != null && n.isNameExplicit)
/*      */       {
/* 1229 */         return true;
/*      */       }
/*      */     } 
/* 1232 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<PropertyName> findExplicitNames() {
/* 1243 */     Set<PropertyName> renamed = null;
/* 1244 */     renamed = _findExplicitNames((Linked)this._fields, renamed);
/* 1245 */     renamed = _findExplicitNames((Linked)this._getters, renamed);
/* 1246 */     renamed = _findExplicitNames((Linked)this._setters, renamed);
/* 1247 */     renamed = _findExplicitNames((Linked)this._ctorParameters, renamed);
/* 1248 */     return (renamed == null) ? Collections.<PropertyName>emptySet() : renamed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasExplicitName(PropertyName name) {
/* 1263 */     return (_hasExplicitName((Linked)this._fields, name) || 
/* 1264 */       _hasExplicitName((Linked)this._getters, name) || 
/* 1265 */       _hasExplicitName((Linked)this._setters, name) || 
/* 1266 */       _hasExplicitName((Linked)this._ctorParameters, name));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _hasExplicitName(Linked<? extends AnnotatedMember> node, PropertyName nameToMatch) {
/* 1272 */     for (; node != null; node = node.next) {
/* 1273 */       if (node.isNameExplicit && nameToMatch.equals(node.name)) {
/* 1274 */         return true;
/*      */       }
/*      */     } 
/* 1277 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection<POJOPropertyBuilder> explode(Collection<PropertyName> newNames) {
/* 1290 */     HashMap<PropertyName, POJOPropertyBuilder> props = new HashMap<>();
/* 1291 */     _explode(newNames, props, this._fields);
/* 1292 */     _explode(newNames, props, this._getters);
/* 1293 */     _explode(newNames, props, this._setters);
/* 1294 */     _explode(newNames, props, this._ctorParameters);
/* 1295 */     return props.values();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _explode(Collection<PropertyName> newNames, Map<PropertyName, POJOPropertyBuilder> props, Linked<?> accessors) {
/* 1303 */     Linked<?> firstAcc = accessors;
/* 1304 */     for (Linked<?> node = accessors; node != null; node = node.next) {
/* 1305 */       PropertyName name = node.name;
/* 1306 */       if (!node.isNameExplicit || name == null) {
/*      */         
/* 1308 */         if (node.isVisible)
/*      */         {
/*      */ 
/*      */           
/* 1312 */           throw new IllegalStateException("Conflicting/ambiguous property name definitions (implicit name " + 
/* 1313 */               ClassUtil.name(this._name) + "): found multiple explicit names: " + newNames + ", but also implicit accessor: " + node);
/*      */         }
/*      */       } else {
/* 1316 */         POJOPropertyBuilder prop = props.get(name);
/* 1317 */         if (prop == null) {
/* 1318 */           prop = new POJOPropertyBuilder(this._config, this._annotationIntrospector, this._forSerialization, this._internalName, name);
/*      */           
/* 1320 */           props.put(name, prop);
/*      */         } 
/*      */         
/* 1323 */         if (firstAcc == this._fields) {
/* 1324 */           Linked<AnnotatedField> n2 = (Linked)node;
/* 1325 */           prop._fields = n2.withNext(prop._fields);
/* 1326 */         } else if (firstAcc == this._getters) {
/* 1327 */           Linked<AnnotatedMethod> n2 = (Linked)node;
/* 1328 */           prop._getters = n2.withNext(prop._getters);
/* 1329 */         } else if (firstAcc == this._setters) {
/* 1330 */           Linked<AnnotatedMethod> n2 = (Linked)node;
/* 1331 */           prop._setters = n2.withNext(prop._setters);
/* 1332 */         } else if (firstAcc == this._ctorParameters) {
/* 1333 */           Linked<AnnotatedParameter> n2 = (Linked)node;
/* 1334 */           prop._ctorParameters = n2.withNext(prop._ctorParameters);
/*      */         } else {
/* 1336 */           throw new IllegalStateException("Internal error: mismatched accessors, property: " + this);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private Set<PropertyName> _findExplicitNames(Linked<? extends AnnotatedMember> node, Set<PropertyName> renamed) {
/* 1344 */     for (; node != null; node = node.next) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1351 */       if (node.isNameExplicit && node.name != null) {
/*      */ 
/*      */         
/* 1354 */         if (renamed == null) {
/* 1355 */           renamed = new HashSet<>();
/*      */         }
/* 1357 */         renamed.add(node.name);
/*      */       } 
/* 1359 */     }  return renamed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1366 */     StringBuilder sb = new StringBuilder();
/* 1367 */     sb.append("[Property '").append(this._name)
/* 1368 */       .append("'; ctors: ").append(this._ctorParameters)
/* 1369 */       .append(", field(s): ").append(this._fields)
/* 1370 */       .append(", getter(s): ").append(this._getters)
/* 1371 */       .append(", setter(s): ").append(this._setters);
/*      */     
/* 1373 */     sb.append("]");
/* 1374 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T> T fromMemberAnnotations(WithMember<T> func) {
/* 1389 */     T result = null;
/* 1390 */     if (this._annotationIntrospector != null) {
/* 1391 */       if (this._forSerialization) {
/* 1392 */         if (this._getters != null) {
/* 1393 */           result = func.withMember((AnnotatedMember)this._getters.value);
/*      */         }
/*      */       } else {
/* 1396 */         if (this._ctorParameters != null) {
/* 1397 */           result = func.withMember((AnnotatedMember)this._ctorParameters.value);
/*      */         }
/* 1399 */         if (result == null && this._setters != null) {
/* 1400 */           result = func.withMember((AnnotatedMember)this._setters.value);
/*      */         }
/*      */       } 
/* 1403 */       if (result == null && this._fields != null) {
/* 1404 */         result = func.withMember((AnnotatedMember)this._fields.value);
/*      */       }
/*      */     } 
/* 1407 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   protected <T> T fromMemberAnnotationsExcept(WithMember<T> func, T defaultValue) {
/* 1412 */     if (this._annotationIntrospector == null) {
/* 1413 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1418 */     if (this._forSerialization) {
/* 1419 */       if (this._getters != null) {
/* 1420 */         T result = func.withMember((AnnotatedMember)this._getters.value);
/* 1421 */         if (result != null && result != defaultValue) {
/* 1422 */           return result;
/*      */         }
/*      */       } 
/* 1425 */       if (this._fields != null) {
/* 1426 */         T result = func.withMember((AnnotatedMember)this._fields.value);
/* 1427 */         if (result != null && result != defaultValue) {
/* 1428 */           return result;
/*      */         }
/*      */       } 
/* 1431 */       if (this._ctorParameters != null) {
/* 1432 */         T result = func.withMember((AnnotatedMember)this._ctorParameters.value);
/* 1433 */         if (result != null && result != defaultValue) {
/* 1434 */           return result;
/*      */         }
/*      */       } 
/* 1437 */       if (this._setters != null) {
/* 1438 */         T result = func.withMember((AnnotatedMember)this._setters.value);
/* 1439 */         if (result != null && result != defaultValue) {
/* 1440 */           return result;
/*      */         }
/*      */       } 
/* 1443 */       return null;
/*      */     } 
/* 1445 */     if (this._ctorParameters != null) {
/* 1446 */       T result = func.withMember((AnnotatedMember)this._ctorParameters.value);
/* 1447 */       if (result != null && result != defaultValue) {
/* 1448 */         return result;
/*      */       }
/*      */     } 
/* 1451 */     if (this._setters != null) {
/* 1452 */       T result = func.withMember((AnnotatedMember)this._setters.value);
/* 1453 */       if (result != null && result != defaultValue) {
/* 1454 */         return result;
/*      */       }
/*      */     } 
/* 1457 */     if (this._fields != null) {
/* 1458 */       T result = func.withMember((AnnotatedMember)this._fields.value);
/* 1459 */       if (result != null && result != defaultValue) {
/* 1460 */         return result;
/*      */       }
/*      */     } 
/* 1463 */     if (this._getters != null) {
/* 1464 */       T result = func.withMember((AnnotatedMember)this._getters.value);
/* 1465 */       if (result != null && result != defaultValue) {
/* 1466 */         return result;
/*      */       }
/*      */     } 
/* 1469 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Class<?> _rawTypeOf(AnnotatedMember m) {
/* 1479 */     if (m instanceof AnnotatedMethod) {
/* 1480 */       AnnotatedMethod meh = (AnnotatedMethod)m;
/* 1481 */       if (meh.getParameterCount() > 0)
/*      */       {
/*      */         
/* 1484 */         return meh.getParameterType(0).getRawClass();
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1489 */     return m.getType().getRawClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static class MemberIterator<T extends AnnotatedMember>
/*      */     implements Iterator<T>
/*      */   {
/*      */     private POJOPropertyBuilder.Linked<T> next;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MemberIterator(POJOPropertyBuilder.Linked<T> first) {
/* 1511 */       this.next = first;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean hasNext() {
/* 1516 */       return (this.next != null);
/*      */     }
/*      */ 
/*      */     
/*      */     public T next() {
/* 1521 */       if (this.next == null) throw new NoSuchElementException(); 
/* 1522 */       AnnotatedMember annotatedMember = (AnnotatedMember)this.next.value;
/* 1523 */       this.next = this.next.next;
/* 1524 */       return (T)annotatedMember;
/*      */     }
/*      */ 
/*      */     
/*      */     public void remove() {
/* 1529 */       throw new UnsupportedOperationException();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final class Linked<T>
/*      */   {
/*      */     public final T value;
/*      */     
/*      */     public final Linked<T> next;
/*      */     
/*      */     public final PropertyName name;
/*      */     
/*      */     public final boolean isNameExplicit;
/*      */     
/*      */     public final boolean isVisible;
/*      */     
/*      */     public final boolean isMarkedIgnored;
/*      */ 
/*      */     
/*      */     public Linked(T v, Linked<T> n, PropertyName name, boolean explName, boolean visible, boolean ignored) {
/* 1551 */       this.value = v;
/* 1552 */       this.next = n;
/*      */       
/* 1554 */       this.name = (name == null || name.isEmpty()) ? null : name;
/*      */       
/* 1556 */       if (explName) {
/* 1557 */         if (this.name == null) {
/* 1558 */           throw new IllegalArgumentException("Cannot pass true for 'explName' if name is null/empty");
/*      */         }
/*      */ 
/*      */         
/* 1562 */         if (!name.hasSimpleName()) {
/* 1563 */           explName = false;
/*      */         }
/*      */       } 
/*      */       
/* 1567 */       this.isNameExplicit = explName;
/* 1568 */       this.isVisible = visible;
/* 1569 */       this.isMarkedIgnored = ignored;
/*      */     }
/*      */     
/*      */     public Linked<T> withoutNext() {
/* 1573 */       if (this.next == null) {
/* 1574 */         return this;
/*      */       }
/* 1576 */       return new Linked(this.value, null, this.name, this.isNameExplicit, this.isVisible, this.isMarkedIgnored);
/*      */     }
/*      */     
/*      */     public Linked<T> withValue(T newValue) {
/* 1580 */       if (newValue == this.value) {
/* 1581 */         return this;
/*      */       }
/* 1583 */       return new Linked(newValue, this.next, this.name, this.isNameExplicit, this.isVisible, this.isMarkedIgnored);
/*      */     }
/*      */     
/*      */     public Linked<T> withNext(Linked<T> newNext) {
/* 1587 */       if (newNext == this.next) {
/* 1588 */         return this;
/*      */       }
/* 1590 */       return new Linked(this.value, newNext, this.name, this.isNameExplicit, this.isVisible, this.isMarkedIgnored);
/*      */     }
/*      */     
/*      */     public Linked<T> withoutIgnored() {
/* 1594 */       if (this.isMarkedIgnored) {
/* 1595 */         return (this.next == null) ? null : this.next.withoutIgnored();
/*      */       }
/* 1597 */       if (this.next != null) {
/* 1598 */         Linked<T> newNext = this.next.withoutIgnored();
/* 1599 */         if (newNext != this.next) {
/* 1600 */           return withNext(newNext);
/*      */         }
/*      */       } 
/* 1603 */       return this;
/*      */     }
/*      */     
/*      */     public Linked<T> withoutNonVisible() {
/* 1607 */       Linked<T> newNext = (this.next == null) ? null : this.next.withoutNonVisible();
/* 1608 */       return this.isVisible ? withNext(newNext) : newNext;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Linked<T> append(Linked<T> appendable) {
/* 1616 */       if (this.next == null) {
/* 1617 */         return withNext(appendable);
/*      */       }
/* 1619 */       return withNext(this.next.append(appendable));
/*      */     }
/*      */     
/*      */     public Linked<T> trimByVisibility() {
/* 1623 */       if (this.next == null) {
/* 1624 */         return this;
/*      */       }
/* 1626 */       Linked<T> newNext = this.next.trimByVisibility();
/* 1627 */       if (this.name != null) {
/* 1628 */         if (newNext.name == null) {
/* 1629 */           return withNext(null);
/*      */         }
/*      */         
/* 1632 */         return withNext(newNext);
/*      */       } 
/* 1634 */       if (newNext.name != null) {
/* 1635 */         return newNext;
/*      */       }
/*      */       
/* 1638 */       if (this.isVisible == newNext.isVisible) {
/* 1639 */         return withNext(newNext);
/*      */       }
/* 1641 */       return this.isVisible ? withNext(null) : newNext;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 1646 */       String msg = String.format("%s[visible=%b,ignore=%b,explicitName=%b]", new Object[] { this.value
/* 1647 */             .toString(), Boolean.valueOf(this.isVisible), Boolean.valueOf(this.isMarkedIgnored), Boolean.valueOf(this.isNameExplicit) });
/* 1648 */       if (this.next != null) {
/* 1649 */         msg = msg + ", " + this.next.toString();
/*      */       }
/* 1651 */       return msg;
/*      */     }
/*      */   }
/*      */   
/*      */   private static interface WithMember<T> {
/*      */     T withMember(AnnotatedMember param1AnnotatedMember);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\POJOPropertyBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */