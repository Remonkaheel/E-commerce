/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AnnotatedConstructor
/*     */   extends AnnotatedWithParams
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final Constructor<?> _constructor;
/*     */   protected Serialization _serialization;
/*     */   
/*     */   public AnnotatedConstructor(TypeResolutionContext ctxt, Constructor<?> constructor, AnnotationMap classAnn, AnnotationMap[] paramAnn) {
/*  35 */     super(ctxt, classAnn, paramAnn);
/*  36 */     this._constructor = Objects.<Constructor>requireNonNull(constructor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotatedConstructor(Serialization ser) {
/*  45 */     super((TypeResolutionContext)null, (AnnotationMap)null, (AnnotationMap[])null);
/*  46 */     this._constructor = null;
/*  47 */     this._serialization = ser;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedConstructor withAnnotations(AnnotationMap ann) {
/*  52 */     return new AnnotatedConstructor(this._typeContext, this._constructor, ann, this._paramAnnotations);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Constructor<?> getAnnotated() {
/*  62 */     return this._constructor;
/*     */   }
/*     */   public int getModifiers() {
/*  65 */     return this._constructor.getModifiers();
/*     */   }
/*     */   public String getName() {
/*  68 */     return this._constructor.getName();
/*     */   }
/*     */   
/*     */   public JavaType getType() {
/*  72 */     return this._typeContext.resolveType(getRawType());
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getRawType() {
/*  77 */     return this._constructor.getDeclaringClass();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getParameterCount() {
/*  88 */     return this._constructor.getParameterCount();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getRawParameterType(int index) {
/*  94 */     Class<?>[] types = this._constructor.getParameterTypes();
/*  95 */     return (index >= types.length) ? null : types[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType getParameterType(int index) {
/* 100 */     Type[] types = this._constructor.getGenericParameterTypes();
/* 101 */     if (index >= types.length) {
/* 102 */       return null;
/*     */     }
/* 104 */     return this._typeContext.resolveType(types[index]);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Type getGenericParameterType(int index) {
/* 110 */     Type[] types = this._constructor.getGenericParameterTypes();
/* 111 */     if (index >= types.length) {
/* 112 */       return null;
/*     */     }
/* 114 */     return types[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object call() throws Exception {
/* 121 */     return this._constructor.newInstance((Object[])null);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object call(Object[] args) throws Exception {
/* 126 */     return this._constructor.newInstance(args);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object call1(Object arg) throws Exception {
/* 131 */     return this._constructor.newInstance(new Object[] { arg });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getDeclaringClass() {
/* 141 */     return this._constructor.getDeclaringClass();
/*     */   }
/*     */   public Member getMember() {
/* 144 */     return this._constructor;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(Object pojo, Object value) throws UnsupportedOperationException {
/* 150 */     throw new UnsupportedOperationException("Cannot call setValue() on constructor of " + 
/* 151 */         getDeclaringClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(Object pojo) throws UnsupportedOperationException {
/* 158 */     throw new UnsupportedOperationException("Cannot call getValue() on constructor of " + 
/* 159 */         getDeclaringClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 170 */     int argCount = this._constructor.getParameterCount();
/* 171 */     return String.format("[constructor for %s (%d arg%s), annotations: %s", new Object[] {
/* 172 */           ClassUtil.nameOf(this._constructor.getDeclaringClass()), Integer.valueOf(argCount), (argCount == 1) ? "" : "s", this._annotations
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 179 */     return Objects.hashCode(this._constructor);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 184 */     if (o == this) return true; 
/* 185 */     if (!ClassUtil.hasClass(o, getClass())) {
/* 186 */       return false;
/*     */     }
/* 188 */     AnnotatedConstructor other = (AnnotatedConstructor)o;
/* 189 */     return Objects.equals(this._constructor, other._constructor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object writeReplace() {
/* 199 */     return new AnnotatedConstructor(new Serialization(this._constructor));
/*     */   }
/*     */   
/*     */   Object readResolve() {
/* 203 */     Class<?> clazz = this._serialization.clazz;
/*     */     try {
/* 205 */       Constructor<?> ctor = clazz.getDeclaredConstructor(this._serialization.args);
/*     */       
/* 207 */       if (!ctor.isAccessible()) {
/* 208 */         ClassUtil.checkAndFixAccess(ctor, false);
/*     */       }
/* 210 */       return new AnnotatedConstructor(null, ctor, null, null);
/* 211 */     } catch (Exception e) {
/* 212 */       throw new IllegalArgumentException("Could not find constructor with " + this._serialization.args.length + " args from Class '" + clazz
/* 213 */           .getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Serialization
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     protected Class<?> clazz;
/*     */     
/*     */     protected Class<?>[] args;
/*     */ 
/*     */     
/*     */     public Serialization(Constructor<?> ctor) {
/* 230 */       this.clazz = ctor.getDeclaringClass();
/* 231 */       this.args = ctor.getParameterTypes();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\AnnotatedConstructor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */