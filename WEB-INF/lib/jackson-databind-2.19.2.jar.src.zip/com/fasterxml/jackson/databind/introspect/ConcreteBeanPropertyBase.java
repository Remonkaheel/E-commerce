/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ConcreteBeanPropertyBase
/*     */   implements BeanProperty, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final PropertyMetadata _metadata;
/*     */   protected transient List<PropertyName> _aliases;
/*     */   
/*     */   protected ConcreteBeanPropertyBase(PropertyMetadata md) {
/*  39 */     this._metadata = (md == null) ? PropertyMetadata.STD_REQUIRED_OR_OPTIONAL : md;
/*     */   }
/*     */   
/*     */   protected ConcreteBeanPropertyBase(ConcreteBeanPropertyBase src) {
/*  43 */     this._metadata = src._metadata;
/*     */   }
/*     */   
/*     */   public boolean isRequired() {
/*  47 */     return this._metadata.isRequired();
/*     */   }
/*     */   public PropertyMetadata getMetadata() {
/*  50 */     return this._metadata;
/*     */   }
/*     */   public boolean isVirtual() {
/*  53 */     return false;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public final JsonFormat.Value findFormatOverrides(AnnotationIntrospector intr) {
/*  58 */     JsonFormat.Value f = null;
/*  59 */     if (intr != null) {
/*  60 */       AnnotatedMember member = getMember();
/*  61 */       if (member != null) {
/*  62 */         f = intr.findFormat(member);
/*     */       }
/*     */     } 
/*  65 */     if (f == null) {
/*  66 */       f = EMPTY_FORMAT;
/*     */     }
/*  68 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonFormat.Value findPropertyFormat(MapperConfig<?> config, Class<?> baseType) {
/*  74 */     JsonFormat.Value v1 = config.getDefaultPropertyFormat(baseType);
/*  75 */     JsonFormat.Value v2 = null;
/*  76 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/*  77 */     if (intr != null) {
/*  78 */       AnnotatedMember member = getMember();
/*  79 */       if (member != null) {
/*  80 */         v2 = intr.findFormat(member);
/*     */       }
/*     */     } 
/*  83 */     if (v1 == null) {
/*  84 */       return (v2 == null) ? EMPTY_FORMAT : v2;
/*     */     }
/*  86 */     return (v2 == null) ? v1 : v1.withOverrides(v2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonInclude.Value findPropertyInclusion(MapperConfig<?> config, Class<?> baseType) {
/*  92 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/*  93 */     AnnotatedMember member = getMember();
/*  94 */     if (member == null) {
/*  95 */       JsonInclude.Value def = config.getDefaultPropertyInclusion(baseType);
/*  96 */       return def;
/*     */     } 
/*  98 */     JsonInclude.Value v0 = config.getDefaultInclusion(baseType, member.getRawType());
/*  99 */     if (intr == null) {
/* 100 */       return v0;
/*     */     }
/* 102 */     JsonInclude.Value v = intr.findPropertyInclusion(member);
/* 103 */     if (v0 == null) {
/* 104 */       return v;
/*     */     }
/* 106 */     return v0.withOverrides(v);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<PropertyName> findAliases(MapperConfig<?> config) {
/* 112 */     List<PropertyName> aliases = this._aliases;
/* 113 */     if (aliases == null) {
/* 114 */       AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 115 */       if (intr != null) {
/* 116 */         AnnotatedMember member = getMember();
/* 117 */         if (member != null) {
/* 118 */           aliases = intr.findPropertyAliases(member);
/*     */         }
/*     */       } 
/* 121 */       if (aliases == null) {
/* 122 */         aliases = Collections.emptyList();
/*     */       }
/* 124 */       this._aliases = aliases;
/*     */     } 
/* 126 */     return aliases;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\ConcreteBeanPropertyBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */