/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.type.TypeBindings;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.Annotations;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ public final class AnnotatedClass
/*     */   extends Annotated
/*     */   implements TypeResolutionContext
/*     */ {
/*  20 */   private static final Creators NO_CREATORS = new Creators(null, 
/*  21 */       Collections.emptyList(), 
/*  22 */       Collections.emptyList());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JavaType _type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Class<?> _class;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final TypeBindings _bindings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final List<JavaType> _superTypes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AnnotationIntrospector _annotationIntrospector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final TypeFactory _typeFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ClassIntrospector.MixInResolver _mixInResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Class<?> _primaryMixIn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _collectAnnotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Annotations _classAnnotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Creators _creators;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotatedMethodMap _memberMethods;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<AnnotatedField> _fields;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected transient Boolean _nonStaticInnerClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotatedClass(JavaType type, Class<?> rawType, List<JavaType> superTypes, Class<?> primaryMixIn, Annotations classAnnotations, TypeBindings bindings, AnnotationIntrospector aintr, ClassIntrospector.MixInResolver mir, TypeFactory tf, boolean collectAnnotations) {
/* 143 */     this._type = type;
/* 144 */     this._class = rawType;
/* 145 */     this._superTypes = superTypes;
/* 146 */     this._primaryMixIn = primaryMixIn;
/* 147 */     this._classAnnotations = classAnnotations;
/* 148 */     this._bindings = bindings;
/* 149 */     this._annotationIntrospector = aintr;
/* 150 */     this._mixInResolver = mir;
/* 151 */     this._typeFactory = tf;
/* 152 */     this._collectAnnotations = collectAnnotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   AnnotatedClass(JavaType type, Class<?> rawType, List<JavaType> superTypes, Class<?> primaryMixIn, Annotations classAnnotations, TypeBindings bindings, AnnotationIntrospector aintr, ClassIntrospector.MixInResolver mir, TypeFactory tf) {
/* 160 */     this(type, rawType, superTypes, primaryMixIn, classAnnotations, bindings, aintr, mir, tf, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotatedClass(Class<?> rawType) {
/* 171 */     this._type = null;
/* 172 */     this._class = rawType;
/* 173 */     this._superTypes = Collections.emptyList();
/* 174 */     this._primaryMixIn = null;
/* 175 */     this._classAnnotations = AnnotationCollector.emptyAnnotations();
/* 176 */     this._bindings = TypeBindings.emptyBindings();
/* 177 */     this._annotationIntrospector = null;
/* 178 */     this._mixInResolver = null;
/* 179 */     this._typeFactory = null;
/* 180 */     this._collectAnnotations = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static AnnotatedClass construct(JavaType type, MapperConfig<?> config) {
/* 188 */     return construct(type, config, (ClassIntrospector.MixInResolver)config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static AnnotatedClass construct(JavaType type, MapperConfig<?> config, ClassIntrospector.MixInResolver mir) {
/* 198 */     return AnnotatedClassResolver.resolve(config, type, mir);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static AnnotatedClass constructWithoutSuperTypes(Class<?> raw, MapperConfig<?> config) {
/* 210 */     return constructWithoutSuperTypes(raw, config, (ClassIntrospector.MixInResolver)config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static AnnotatedClass constructWithoutSuperTypes(Class<?> raw, MapperConfig<?> config, ClassIntrospector.MixInResolver mir) {
/* 220 */     return AnnotatedClassResolver.resolveWithoutSuperTypes(config, raw, mir);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType resolveType(Type type) {
/* 233 */     return this._typeFactory.resolveMemberType(type, this._bindings);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getAnnotated() {
/* 243 */     return this._class;
/*     */   }
/*     */   public int getModifiers() {
/* 246 */     return this._class.getModifiers();
/*     */   }
/*     */   public String getName() {
/* 249 */     return this._class.getName();
/*     */   }
/*     */   
/*     */   public <A extends Annotation> A getAnnotation(Class<A> acls) {
/* 253 */     return (A)this._classAnnotations.get(acls);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasAnnotation(Class<?> acls) {
/* 258 */     return this._classAnnotations.has(acls);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasOneOf(Class<? extends Annotation>[] annoClasses) {
/* 263 */     return this._classAnnotations.hasOneOf((Class[])annoClasses);
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getRawType() {
/* 268 */     return this._class;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Iterable<Annotation> annotations() {
/* 274 */     if (this._classAnnotations instanceof AnnotationMap)
/* 275 */       return ((AnnotationMap)this._classAnnotations).annotations(); 
/* 276 */     if (this._classAnnotations instanceof AnnotationCollector.OneAnnotation || this._classAnnotations instanceof AnnotationCollector.TwoAnnotations)
/*     */     {
/* 278 */       throw new UnsupportedOperationException("please use getAnnotations/ hasAnnotation to check for Annotations");
/*     */     }
/* 280 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType getType() {
/* 285 */     return this._type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotations getAnnotations() {
/* 295 */     return this._classAnnotations;
/*     */   }
/*     */   
/*     */   public boolean hasAnnotations() {
/* 299 */     return (this._classAnnotations.size() > 0);
/*     */   }
/*     */   
/*     */   public AnnotatedConstructor getDefaultConstructor() {
/* 303 */     return (_creators()).defaultConstructor;
/*     */   }
/*     */   
/*     */   public List<AnnotatedConstructor> getConstructors() {
/* 307 */     return (_creators()).constructors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotatedMethod> getFactoryMethods() {
/* 314 */     return (_creators()).creatorMethods;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public List<AnnotatedMethod> getStaticMethods() {
/* 322 */     return getFactoryMethods();
/*     */   }
/*     */   
/*     */   public Iterable<AnnotatedMethod> memberMethods() {
/* 326 */     return _methods();
/*     */   }
/*     */   
/*     */   public int getMemberMethodCount() {
/* 330 */     return _methods().size();
/*     */   }
/*     */   
/*     */   public AnnotatedMethod findMethod(String name, Class<?>[] paramTypes) {
/* 334 */     return _methods().find(name, paramTypes);
/*     */   }
/*     */   
/*     */   public int getFieldCount() {
/* 338 */     return _fields().size();
/*     */   }
/*     */   
/*     */   public Iterable<AnnotatedField> fields() {
/* 342 */     return _fields();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNonStaticInnerClass() {
/* 350 */     Boolean B = this._nonStaticInnerClass;
/* 351 */     if (B == null) {
/* 352 */       this._nonStaticInnerClass = B = Boolean.valueOf(ClassUtil.isNonStaticInnerClass(this._class));
/*     */     }
/* 354 */     return B.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final List<AnnotatedField> _fields() {
/* 364 */     List<AnnotatedField> f = this._fields;
/* 365 */     if (f == null) {
/*     */       
/* 367 */       if (this._type == null) {
/* 368 */         f = Collections.emptyList();
/*     */       } else {
/* 370 */         f = AnnotatedFieldCollector.collectFields(this._annotationIntrospector, this, this._mixInResolver, this._typeFactory, this._type, this._collectAnnotations);
/*     */       } 
/*     */       
/* 373 */       this._fields = f;
/*     */     } 
/* 375 */     return f;
/*     */   }
/*     */   
/*     */   private final AnnotatedMethodMap _methods() {
/* 379 */     AnnotatedMethodMap m = this._memberMethods;
/* 380 */     if (m == null) {
/*     */ 
/*     */       
/* 383 */       if (this._type == null) {
/* 384 */         m = new AnnotatedMethodMap();
/*     */       } else {
/* 386 */         m = AnnotatedMethodCollector.collectMethods(this._annotationIntrospector, this, this._mixInResolver, this._typeFactory, this._type, this._superTypes, this._primaryMixIn, this._collectAnnotations);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 391 */       this._memberMethods = m;
/*     */     } 
/* 393 */     return m;
/*     */   }
/*     */   
/*     */   private final Creators _creators() {
/* 397 */     Creators c = this._creators;
/* 398 */     if (c == null) {
/* 399 */       if (this._type == null) {
/* 400 */         c = NO_CREATORS;
/*     */       } else {
/* 402 */         c = AnnotatedCreatorCollector.collectCreators(this._annotationIntrospector, this._typeFactory, this, this._type, this._primaryMixIn, this._collectAnnotations);
/*     */       } 
/*     */ 
/*     */       
/* 406 */       this._creators = c;
/*     */     } 
/* 408 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 419 */     return "[AnnotedClass " + this._class.getName() + "]";
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 424 */     return this._class.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 429 */     if (o == this) return true; 
/* 430 */     if (!ClassUtil.hasClass(o, getClass())) {
/* 431 */       return false;
/*     */     }
/* 433 */     return (((AnnotatedClass)o)._class == this._class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Creators
/*     */   {
/*     */     public final AnnotatedConstructor defaultConstructor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final List<AnnotatedConstructor> constructors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final List<AnnotatedMethod> creatorMethods;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Creators(AnnotatedConstructor defCtor, List<AnnotatedConstructor> ctors, List<AnnotatedMethod> ctorMethods) {
/* 464 */       this.defaultConstructor = defCtor;
/* 465 */       this.constructors = ctors;
/* 466 */       this.creatorMethods = ctorMethods;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\AnnotatedClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */