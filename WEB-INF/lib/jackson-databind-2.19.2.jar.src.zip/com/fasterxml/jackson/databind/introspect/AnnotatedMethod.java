/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AnnotatedMethod
/*     */   extends AnnotatedWithParams
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final transient Method _method;
/*     */   protected Class<?>[] _paramClasses;
/*     */   protected Serialization _serialization;
/*     */   
/*     */   public AnnotatedMethod(TypeResolutionContext ctxt, Method method, AnnotationMap classAnn, AnnotationMap[] paramAnnotations) {
/*  38 */     super(ctxt, classAnn, paramAnnotations);
/*  39 */     if (method == null) {
/*  40 */       throw new IllegalArgumentException("Cannot construct AnnotatedMethod with null Method");
/*     */     }
/*  42 */     this._method = method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotatedMethod(Serialization ser) {
/*  51 */     super((TypeResolutionContext)null, (AnnotationMap)null, (AnnotationMap[])null);
/*  52 */     this._method = null;
/*  53 */     this._serialization = ser;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedMethod withAnnotations(AnnotationMap ann) {
/*  58 */     return new AnnotatedMethod(this._typeContext, this._method, ann, this._paramAnnotations);
/*     */   }
/*     */   
/*     */   public Method getAnnotated() {
/*  62 */     return this._method;
/*     */   }
/*     */   public int getModifiers() {
/*  65 */     return this._method.getModifiers();
/*     */   }
/*     */   public String getName() {
/*  68 */     return this._method.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType getType() {
/*  77 */     return this._typeContext.resolveType(this._method.getGenericReturnType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getRawType() {
/*  87 */     return this._method.getReturnType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object call() throws Exception {
/* 100 */     return this._method.invoke((Object)null, new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object call(Object[] args) throws Exception {
/* 105 */     return this._method.invoke((Object)null, args);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Object call1(Object arg) throws Exception {
/* 110 */     return this._method.invoke((Object)null, new Object[] { arg });
/*     */   }
/*     */   
/*     */   public final Object callOn(Object pojo) throws Exception {
/* 114 */     return this._method.invoke(pojo, (Object[])null);
/*     */   }
/*     */   
/*     */   public final Object callOnWith(Object pojo, Object... args) throws Exception {
/* 118 */     return this._method.invoke(pojo, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getParameterCount() {
/* 129 */     return this._method.getParameterCount();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getRawParameterType(int index) {
/* 135 */     Class<?>[] types = getRawParameterTypes();
/* 136 */     return (index >= types.length) ? null : types[index];
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType getParameterType(int index) {
/* 141 */     Type[] types = this._method.getGenericParameterTypes();
/* 142 */     if (index >= types.length) {
/* 143 */       return null;
/*     */     }
/* 145 */     return this._typeContext.resolveType(types[index]);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Type getGenericParameterType(int index) {
/* 151 */     Type[] types = getGenericParameterTypes();
/* 152 */     if (index >= types.length) {
/* 153 */       return null;
/*     */     }
/* 155 */     return types[index];
/*     */   }
/*     */   
/*     */   public Class<?> getDeclaringClass() {
/* 159 */     return this._method.getDeclaringClass();
/*     */   }
/*     */   public Method getMember() {
/* 162 */     return this._method;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(Object pojo, Object value) throws IllegalArgumentException {
/*     */     try {
/* 168 */       this._method.invoke(pojo, new Object[] { value });
/* 169 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 170 */       throw new IllegalArgumentException("Failed to setValue() with method " + 
/* 171 */           getFullName() + ": " + ClassUtil.exceptionMessage(e), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(Object pojo) throws IllegalArgumentException {
/*     */     try {
/* 179 */       return this._method.invoke(pojo, (Object[])null);
/* 180 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 181 */       throw new IllegalArgumentException("Failed to getValue() with method " + 
/* 182 */           getFullName() + ": " + ClassUtil.exceptionMessage(e), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFullName() {
/* 194 */     String methodName = super.getFullName();
/* 195 */     switch (getParameterCount()) {
/*     */       case 0:
/* 197 */         return methodName + "()";
/*     */       case 1:
/* 199 */         return methodName + "(" + getRawParameterType(0).getName() + ")";
/*     */     } 
/*     */     
/* 202 */     return String.format("%s(%d params)", new Object[] { super.getFullName(), Integer.valueOf(getParameterCount()) });
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?>[] getRawParameterTypes() {
/* 207 */     if (this._paramClasses == null) {
/* 208 */       this._paramClasses = this._method.getParameterTypes();
/*     */     }
/* 210 */     return this._paramClasses;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public Type[] getGenericParameterTypes() {
/* 215 */     return this._method.getGenericParameterTypes();
/*     */   }
/*     */   
/*     */   public Class<?> getRawReturnType() {
/* 219 */     return this._method.getReturnType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean hasReturnType() {
/* 233 */     Class<?> rt = getRawReturnType();
/*     */     
/* 235 */     return (rt != void.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 246 */     return "[method " + getFullName() + "]";
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 251 */     return this._method.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 256 */     if (o == this) return true; 
/* 257 */     if (!ClassUtil.hasClass(o, getClass())) {
/* 258 */       return false;
/*     */     }
/* 260 */     AnnotatedMethod other = (AnnotatedMethod)o;
/* 261 */     return Objects.equals(this._method, other._method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object writeReplace() {
/* 271 */     return new AnnotatedMethod(new Serialization(this._method));
/*     */   }
/*     */   
/*     */   Object readResolve() {
/* 275 */     Class<?> clazz = this._serialization.clazz;
/*     */     try {
/* 277 */       Method m = clazz.getDeclaredMethod(this._serialization.name, this._serialization.args);
/*     */ 
/*     */       
/* 280 */       if (!m.isAccessible()) {
/* 281 */         ClassUtil.checkAndFixAccess(m, false);
/*     */       }
/* 283 */       return new AnnotatedMethod(null, m, null, null);
/* 284 */     } catch (Exception e) {
/* 285 */       throw new IllegalArgumentException("Could not find method '" + this._serialization.name + "' from Class '" + clazz
/* 286 */           .getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class Serialization
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     protected Class<?> clazz;
/*     */     
/*     */     protected String name;
/*     */     
/*     */     protected Class<?>[] args;
/*     */ 
/*     */     
/*     */     public Serialization(Method setter) {
/* 304 */       this.clazz = setter.getDeclaringClass();
/* 305 */       this.name = setter.getName();
/* 306 */       this.args = setter.getParameterTypes();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\AnnotatedMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */