/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.jdk14.JDK14Util;
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultAccessorNamingStrategy
/*     */   extends AccessorNamingStrategy
/*     */ {
/*     */   protected final MapperConfig<?> _config;
/*     */   protected final AnnotatedClass _forClass;
/*     */   protected final BaseNameValidator _baseNameValidator;
/*     */   protected final boolean _stdBeanNaming;
/*     */   protected final boolean _isGettersNonBoolean;
/*     */   protected final String _getterPrefix;
/*     */   protected final String _isGetterPrefix;
/*     */   protected final String _mutatorPrefix;
/*     */   
/*     */   protected DefaultAccessorNamingStrategy(MapperConfig<?> config, AnnotatedClass forClass, String mutatorPrefix, String getterPrefix, String isGetterPrefix, BaseNameValidator baseNameValidator) {
/*  65 */     this._config = config;
/*  66 */     this._forClass = forClass;
/*     */     
/*  68 */     this._stdBeanNaming = config.isEnabled(MapperFeature.USE_STD_BEAN_NAMING);
/*  69 */     this._isGettersNonBoolean = config.isEnabled(MapperFeature.ALLOW_IS_GETTERS_FOR_NON_BOOLEAN);
/*  70 */     this._mutatorPrefix = mutatorPrefix;
/*  71 */     this._getterPrefix = getterPrefix;
/*  72 */     this._isGetterPrefix = isGetterPrefix;
/*  73 */     this._baseNameValidator = baseNameValidator;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String findNameForIsGetter(AnnotatedMethod am, String name) {
/*  79 */     if (this._isGetterPrefix != null && (
/*  80 */       this._isGettersNonBoolean || _booleanType(am.getType())) && 
/*  81 */       name.startsWith(this._isGetterPrefix)) {
/*  82 */       return this._stdBeanNaming ? 
/*  83 */         stdManglePropertyName(name, this._isGetterPrefix.length()) : 
/*  84 */         legacyManglePropertyName(name, this._isGetterPrefix.length());
/*     */     }
/*     */ 
/*     */     
/*  88 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _booleanType(JavaType type) {
/*  94 */     if (type.isReferenceType()) {
/*  95 */       type = type.getReferencedType();
/*     */     }
/*     */     
/*  98 */     if (type.hasRawClass(boolean.class) || type
/*  99 */       .hasRawClass(Boolean.class) || type
/* 100 */       .hasRawClass(AtomicBoolean.class)) {
/* 101 */       return true;
/*     */     }
/* 103 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String findNameForRegularGetter(AnnotatedMethod am, String name) {
/* 109 */     if (this._getterPrefix != null && name.startsWith(this._getterPrefix)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 114 */       if ("getCallbacks".equals(name)) {
/* 115 */         if (_isCglibGetCallbacks(am)) {
/* 116 */           return null;
/*     */         }
/* 118 */       } else if ("getMetaClass".equals(name)) {
/*     */         
/* 120 */         if (_isGroovyMetaClassGetter(am)) {
/* 121 */           return null;
/*     */         }
/*     */       } 
/* 124 */       return this._stdBeanNaming ? 
/* 125 */         stdManglePropertyName(name, this._getterPrefix.length()) : 
/* 126 */         legacyManglePropertyName(name, this._getterPrefix.length());
/*     */     } 
/* 128 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String findNameForMutator(AnnotatedMethod am, String name) {
/* 134 */     if (this._mutatorPrefix != null && name.startsWith(this._mutatorPrefix)) {
/* 135 */       return this._stdBeanNaming ? 
/* 136 */         stdManglePropertyName(name, this._mutatorPrefix.length()) : 
/* 137 */         legacyManglePropertyName(name, this._mutatorPrefix.length());
/*     */     }
/* 139 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String modifyFieldName(AnnotatedField field, String name) {
/* 145 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String legacyManglePropertyName(String basename, int offset) {
/* 163 */     int end = basename.length();
/* 164 */     if (end == offset) {
/* 165 */       return null;
/*     */     }
/* 167 */     char c = basename.charAt(offset);
/*     */ 
/*     */     
/* 170 */     if (this._baseNameValidator != null && 
/* 171 */       !this._baseNameValidator.accept(c, basename, offset)) {
/* 172 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 177 */     char d = Character.toLowerCase(c);
/*     */     
/* 179 */     if (c == d) {
/* 180 */       return basename.substring(offset);
/*     */     }
/*     */     
/* 183 */     StringBuilder sb = new StringBuilder(end - offset);
/* 184 */     sb.append(d);
/* 185 */     int i = offset + 1;
/* 186 */     for (; i < end; i++) {
/* 187 */       c = basename.charAt(i);
/* 188 */       d = Character.toLowerCase(c);
/* 189 */       if (c == d) {
/* 190 */         sb.append(basename, i, end);
/*     */         break;
/*     */       } 
/* 193 */       sb.append(d);
/*     */     } 
/* 195 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected String stdManglePropertyName(String basename, int offset) {
/* 200 */     int end = basename.length();
/* 201 */     if (end == offset) {
/* 202 */       return null;
/*     */     }
/*     */     
/* 205 */     char c0 = basename.charAt(offset);
/*     */ 
/*     */     
/* 208 */     if (this._baseNameValidator != null && 
/* 209 */       !this._baseNameValidator.accept(c0, basename, offset)) {
/* 210 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 214 */     char c1 = Character.toLowerCase(c0);
/* 215 */     if (c0 == c1) {
/* 216 */       return basename.substring(offset);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 221 */     if (offset + 1 < end && 
/* 222 */       Character.isUpperCase(basename.charAt(offset + 1))) {
/* 223 */       return basename.substring(offset);
/*     */     }
/*     */     
/* 226 */     StringBuilder sb = new StringBuilder(end - offset);
/* 227 */     sb.append(c1);
/* 228 */     sb.append(basename, offset + 1, end);
/* 229 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _isCglibGetCallbacks(AnnotatedMethod am) {
/* 245 */     Class<?> rt = am.getRawType();
/*     */     
/* 247 */     if (rt.isArray()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 252 */       Class<?> compType = rt.getComponentType();
/*     */       
/* 254 */       String className = compType.getName();
/* 255 */       if (className.contains(".cglib")) {
/* 256 */         return (className.startsWith("net.sf.cglib") || className
/*     */           
/* 258 */           .startsWith("org.hibernate.repackage.cglib") || className
/*     */           
/* 260 */           .startsWith("org.springframework.cglib"));
/*     */       }
/*     */     } 
/* 263 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _isGroovyMetaClassGetter(AnnotatedMethod am) {
/* 268 */     return am.getRawType().getName().startsWith("groovy.lang");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface BaseNameValidator
/*     */   {
/*     */     boolean accept(char param1Char, String param1String, int param1Int);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Provider
/*     */     extends AccessorNamingStrategy.Provider
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final String _setterPrefix;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final String _withPrefix;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final String _getterPrefix;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final String _isGetterPrefix;
/*     */ 
/*     */     
/*     */     protected final DefaultAccessorNamingStrategy.BaseNameValidator _baseNameValidator;
/*     */ 
/*     */ 
/*     */     
/*     */     public Provider() {
/* 310 */       this("set", "with", "get", "is", (DefaultAccessorNamingStrategy.BaseNameValidator)null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Provider(Provider p, String setterPrefix, String withPrefix, String getterPrefix, String isGetterPrefix) {
/* 318 */       this(setterPrefix, withPrefix, getterPrefix, isGetterPrefix, p._baseNameValidator);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected Provider(Provider p, DefaultAccessorNamingStrategy.BaseNameValidator vld) {
/* 324 */       this(p._setterPrefix, p._withPrefix, p._getterPrefix, p._isGetterPrefix, vld);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Provider(String setterPrefix, String withPrefix, String getterPrefix, String isGetterPrefix, DefaultAccessorNamingStrategy.BaseNameValidator vld) {
/* 332 */       this._setterPrefix = setterPrefix;
/* 333 */       this._withPrefix = withPrefix;
/* 334 */       this._getterPrefix = getterPrefix;
/* 335 */       this._isGetterPrefix = isGetterPrefix;
/* 336 */       this._baseNameValidator = vld;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Provider withSetterPrefix(String prefix) {
/* 351 */       return new Provider(this, prefix, this._withPrefix, this._getterPrefix, this._isGetterPrefix);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Provider withBuilderPrefix(String prefix) {
/* 367 */       return new Provider(this, this._setterPrefix, prefix, this._getterPrefix, this._isGetterPrefix);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Provider withGetterPrefix(String prefix) {
/* 383 */       return new Provider(this, this._setterPrefix, this._withPrefix, prefix, this._isGetterPrefix);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Provider withIsGetterPrefix(String prefix) {
/* 399 */       return new Provider(this, this._setterPrefix, this._withPrefix, this._getterPrefix, prefix);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Provider withFirstCharAcceptance(boolean allowLowerCaseFirstChar, boolean allowNonLetterFirstChar) {
/* 431 */       return withBaseNameValidator(
/* 432 */           DefaultAccessorNamingStrategy.FirstCharBasedValidator.forFirstNameRule(allowLowerCaseFirstChar, allowNonLetterFirstChar));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Provider withBaseNameValidator(DefaultAccessorNamingStrategy.BaseNameValidator vld) {
/* 446 */       return new Provider(this, vld);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public AccessorNamingStrategy forPOJO(MapperConfig<?> config, AnnotatedClass targetClass) {
/* 452 */       return new DefaultAccessorNamingStrategy(config, targetClass, this._setterPrefix, this._getterPrefix, this._isGetterPrefix, this._baseNameValidator);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AccessorNamingStrategy forBuilder(MapperConfig<?> config, AnnotatedClass builderClass, BeanDescription valueTypeDesc) {
/* 461 */       AnnotationIntrospector ai = config.isAnnotationProcessingEnabled() ? config.getAnnotationIntrospector() : null;
/* 462 */       JsonPOJOBuilder.Value builderConfig = (ai == null) ? null : ai.findPOJOBuilderConfig(builderClass);
/* 463 */       String mutatorPrefix = (builderConfig == null) ? this._withPrefix : builderConfig.withPrefix;
/* 464 */       return new DefaultAccessorNamingStrategy(config, builderClass, mutatorPrefix, this._getterPrefix, this._isGetterPrefix, this._baseNameValidator);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AccessorNamingStrategy forRecord(MapperConfig<?> config, AnnotatedClass recordClass) {
/* 472 */       return new DefaultAccessorNamingStrategy.RecordNaming(config, recordClass);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FirstCharBasedValidator
/*     */     implements BaseNameValidator
/*     */   {
/*     */     private final boolean _allowLowerCaseFirstChar;
/*     */ 
/*     */ 
/*     */     
/*     */     private final boolean _allowNonLetterFirstChar;
/*     */ 
/*     */ 
/*     */     
/*     */     protected FirstCharBasedValidator(boolean allowLowerCaseFirstChar, boolean allowNonLetterFirstChar) {
/* 491 */       this._allowLowerCaseFirstChar = allowLowerCaseFirstChar;
/* 492 */       this._allowNonLetterFirstChar = allowNonLetterFirstChar;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static DefaultAccessorNamingStrategy.BaseNameValidator forFirstNameRule(boolean allowLowerCaseFirstChar, boolean allowNonLetterFirstChar) {
/* 511 */       if (allowLowerCaseFirstChar && allowNonLetterFirstChar) {
/* 512 */         return null;
/*     */       }
/* 514 */       return new FirstCharBasedValidator(allowLowerCaseFirstChar, allowNonLetterFirstChar);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean accept(char firstChar, String basename, int offset) {
/* 522 */       if (Character.isLetter(firstChar)) {
/* 523 */         return (this._allowLowerCaseFirstChar || !Character.isLowerCase(firstChar));
/*     */       }
/*     */       
/* 526 */       return this._allowNonLetterFirstChar;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class RecordNaming
/*     */     extends DefaultAccessorNamingStrategy
/*     */   {
/*     */     protected final Set<String> _fieldNames;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RecordNaming(MapperConfig<?> config, AnnotatedClass forClass) {
/* 548 */       super(config, forClass, null, "get", "is", null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 554 */       String[] recordFieldNames = JDK14Util.getRecordFieldNames(forClass.getRawType());
/*     */       
/* 556 */       this
/*     */         
/* 558 */         ._fieldNames = (recordFieldNames == null) ? Collections.<String>emptySet() : new HashSet<>(Arrays.asList(recordFieldNames));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String findNameForRegularGetter(AnnotatedMethod am, String name) {
/* 567 */       if (this._fieldNames.contains(name)) {
/* 568 */         return name;
/*     */       }
/*     */       
/* 571 */       return super.findNameForRegularGetter(am, name);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\DefaultAccessorNamingStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */