/*    */ package com.fasterxml.jackson.databind.introspect;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.EnumNamingStrategy;
/*    */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnumNamingStrategyFactory
/*    */ {
/*    */   @Deprecated
/*    */   public static EnumNamingStrategy createEnumNamingStrategyInstance(Object namingDef, boolean canOverrideAccessModifiers) {
/* 40 */     return createEnumNamingStrategyInstance(namingDef, canOverrideAccessModifiers, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static EnumNamingStrategy createEnumNamingStrategyInstance(Object namingDef, boolean canOverrideAccessModifiers, EnumNamingStrategy defaultNamingStrategy) {
/* 62 */     if (namingDef == null) {
/* 63 */       return defaultNamingStrategy;
/*    */     }
/* 65 */     if (namingDef instanceof EnumNamingStrategy) {
/* 66 */       return (EnumNamingStrategy)namingDef;
/*    */     }
/* 68 */     if (!(namingDef instanceof Class)) {
/* 69 */       throw new IllegalArgumentException(String.format("AnnotationIntrospector returned EnumNamingStrategy definition of type %s; expected type `Class<EnumNamingStrategy>` instead", new Object[] {
/*    */               
/* 71 */               ClassUtil.classNameOf(namingDef)
/*    */             }));
/*    */     }
/* 74 */     Class<?> namingClass = (Class)namingDef;
/*    */     
/* 76 */     if (namingClass == EnumNamingStrategy.class) {
/* 77 */       return null;
/*    */     }
/* 79 */     if (!EnumNamingStrategy.class.isAssignableFrom(namingClass))
/* 80 */       throw new IllegalArgumentException(String.format("Problem with AnnotationIntrospector returned Class %s; expected `Class<EnumNamingStrategy>`", new Object[] {
/*    */               
/* 82 */               ClassUtil.classNameOf(namingClass)
/*    */             })); 
/* 84 */     return (EnumNamingStrategy)ClassUtil.createInstance(namingClass, canOverrideAccessModifiers);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\EnumNamingStrategyFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */