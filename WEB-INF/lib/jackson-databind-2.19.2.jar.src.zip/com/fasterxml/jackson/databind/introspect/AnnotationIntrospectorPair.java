/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JacksonInject;
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.annotation.JsonIncludeProperties;
/*     */ import com.fasterxml.jackson.annotation.JsonProperty;
/*     */ import com.fasterxml.jackson.annotation.JsonSetter;
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.core.Version;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import com.fasterxml.jackson.databind.ser.BeanPropertyWriter;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ public class AnnotationIntrospectorPair
/*     */   extends AnnotationIntrospector
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final AnnotationIntrospector _primary;
/*     */   protected final AnnotationIntrospector _secondary;
/*     */   
/*     */   public AnnotationIntrospectorPair(AnnotationIntrospector p, AnnotationIntrospector s) {
/*  44 */     this._primary = p;
/*  45 */     this._secondary = s;
/*     */   }
/*     */ 
/*     */   
/*     */   public Version version() {
/*  50 */     return this._primary.version();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotationIntrospector create(AnnotationIntrospector primary, AnnotationIntrospector secondary) {
/*  61 */     if (primary == null) {
/*  62 */       return secondary;
/*     */     }
/*  64 */     if (secondary == null) {
/*  65 */       return primary;
/*     */     }
/*  67 */     return new AnnotationIntrospectorPair(primary, secondary);
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<AnnotationIntrospector> allIntrospectors() {
/*  72 */     return allIntrospectors(new ArrayList<>());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<AnnotationIntrospector> allIntrospectors(Collection<AnnotationIntrospector> result) {
/*  78 */     this._primary.allIntrospectors(result);
/*  79 */     this._secondary.allIntrospectors(result);
/*  80 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAnnotationBundle(Annotation ann) {
/*  87 */     return (this._primary.isAnnotationBundle(ann) || this._secondary.isAnnotationBundle(ann));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyName findRootName(AnnotatedClass ac) {
/*  99 */     return PropertyName.merge(this._primary.findRootName(ac), this._secondary
/* 100 */         .findRootName(ac));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonIgnoreProperties.Value findPropertyIgnoralByName(MapperConfig<?> config, Annotated ann) {
/* 107 */     JsonIgnoreProperties.Value v2 = this._secondary.findPropertyIgnoralByName(config, ann);
/* 108 */     JsonIgnoreProperties.Value v1 = this._primary.findPropertyIgnoralByName(config, ann);
/* 109 */     return (v2 == null) ? v1 : v2
/* 110 */       .withOverrides(v1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonIncludeProperties.Value findPropertyInclusionByName(MapperConfig<?> config, Annotated a) {
/* 116 */     JsonIncludeProperties.Value v2 = this._secondary.findPropertyInclusionByName(config, a);
/* 117 */     JsonIncludeProperties.Value v1 = this._primary.findPropertyInclusionByName(config, a);
/* 118 */     return (v2 == null) ? v1 : v2
/* 119 */       .withOverrides(v1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isIgnorableType(AnnotatedClass ac) {
/* 125 */     Boolean result = this._primary.isIgnorableType(ac);
/* 126 */     if (result == null) {
/* 127 */       result = this._secondary.isIgnorableType(ac);
/*     */     }
/* 129 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findFilterId(Annotated ann) {
/* 135 */     Object id = this._primary.findFilterId(ann);
/* 136 */     if (id == null) {
/* 137 */       id = this._secondary.findFilterId(ann);
/*     */     }
/* 139 */     return id;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findNamingStrategy(AnnotatedClass ac) {
/* 145 */     Object str = this._primary.findNamingStrategy(ac);
/* 146 */     if (str == null) {
/* 147 */       str = this._secondary.findNamingStrategy(ac);
/*     */     }
/* 149 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findEnumNamingStrategy(MapperConfig<?> config, AnnotatedClass ac) {
/* 155 */     Object str = this._primary.findEnumNamingStrategy(config, ac);
/* 156 */     if (str == null) {
/* 157 */       str = this._secondary.findEnumNamingStrategy(config, ac);
/*     */     }
/* 159 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   public String findClassDescription(AnnotatedClass ac) {
/* 164 */     String str = this._primary.findClassDescription(ac);
/* 165 */     if (str == null || str.isEmpty()) {
/* 166 */       str = this._secondary.findClassDescription(ac);
/*     */     }
/* 168 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonIgnoreProperties.Value findPropertyIgnorals(Annotated a) {
/* 175 */     JsonIgnoreProperties.Value v2 = this._secondary.findPropertyIgnorals(a);
/* 176 */     JsonIgnoreProperties.Value v1 = this._primary.findPropertyIgnorals(a);
/* 177 */     return (v2 == null) ? v1 : v2
/* 178 */       .withOverrides(v1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VisibilityChecker<?> findAutoDetectVisibility(AnnotatedClass ac, VisibilityChecker<?> checker) {
/* 194 */     checker = this._secondary.findAutoDetectVisibility(ac, checker);
/* 195 */     return this._primary.findAutoDetectVisibility(ac, checker);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonTypeInfo.Value findPolymorphicTypeInfo(MapperConfig<?> config, Annotated ann) {
/* 210 */     JsonTypeInfo.Value v = this._primary.findPolymorphicTypeInfo(config, ann);
/* 211 */     if (v == null) {
/* 212 */       v = this._secondary.findPolymorphicTypeInfo(config, ann);
/*     */     }
/* 214 */     return v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeResolverBuilder<?> findTypeResolver(MapperConfig<?> config, AnnotatedClass ac, JavaType baseType) {
/* 221 */     TypeResolverBuilder<?> b = this._primary.findTypeResolver(config, ac, baseType);
/* 222 */     if (b == null) {
/* 223 */       b = this._secondary.findTypeResolver(config, ac, baseType);
/*     */     }
/* 225 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeResolverBuilder<?> findPropertyTypeResolver(MapperConfig<?> config, AnnotatedMember am, JavaType baseType) {
/* 232 */     TypeResolverBuilder<?> b = this._primary.findPropertyTypeResolver(config, am, baseType);
/* 233 */     if (b == null) {
/* 234 */       b = this._secondary.findPropertyTypeResolver(config, am, baseType);
/*     */     }
/* 236 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeResolverBuilder<?> findPropertyContentTypeResolver(MapperConfig<?> config, AnnotatedMember am, JavaType baseType) {
/* 243 */     TypeResolverBuilder<?> b = this._primary.findPropertyContentTypeResolver(config, am, baseType);
/* 244 */     if (b == null) {
/* 245 */       b = this._secondary.findPropertyContentTypeResolver(config, am, baseType);
/*     */     }
/* 247 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<NamedType> findSubtypes(Annotated a) {
/* 253 */     List<NamedType> types1 = this._primary.findSubtypes(a);
/* 254 */     List<NamedType> types2 = this._secondary.findSubtypes(a);
/* 255 */     if (types1 == null || types1.isEmpty()) return types2; 
/* 256 */     if (types2 == null || types2.isEmpty()) return types1; 
/* 257 */     ArrayList<NamedType> result = new ArrayList<>(types1.size() + types2.size());
/* 258 */     result.addAll(types1);
/* 259 */     result.addAll(types2);
/* 260 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String findTypeName(AnnotatedClass ac) {
/* 266 */     String name = this._primary.findTypeName(ac);
/* 267 */     if (name == null || name.isEmpty()) {
/* 268 */       name = this._secondary.findTypeName(ac);
/*     */     }
/* 270 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotationIntrospector.ReferenceProperty findReferenceType(AnnotatedMember member) {
/* 280 */     AnnotationIntrospector.ReferenceProperty r = this._primary.findReferenceType(member);
/* 281 */     return (r == null) ? this._secondary.findReferenceType(member) : r;
/*     */   }
/*     */ 
/*     */   
/*     */   public NameTransformer findUnwrappingNameTransformer(AnnotatedMember member) {
/* 286 */     NameTransformer r = this._primary.findUnwrappingNameTransformer(member);
/* 287 */     return (r == null) ? this._secondary.findUnwrappingNameTransformer(member) : r;
/*     */   }
/*     */ 
/*     */   
/*     */   public JacksonInject.Value findInjectableValue(AnnotatedMember m) {
/* 292 */     JacksonInject.Value r = this._primary.findInjectableValue(m);
/* 293 */     if (r == null || r.getUseInput() == null) {
/* 294 */       JacksonInject.Value secondary = this._secondary.findInjectableValue(m);
/* 295 */       if (secondary != null) {
/* 296 */         r = (r == null) ? secondary : r.withUseInput(secondary.getUseInput());
/*     */       }
/*     */     } 
/* 299 */     return r;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasIgnoreMarker(AnnotatedMember m) {
/* 304 */     return (this._primary.hasIgnoreMarker(m) || this._secondary.hasIgnoreMarker(m));
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean hasRequiredMarker(AnnotatedMember m) {
/* 309 */     Boolean r = this._primary.hasRequiredMarker(m);
/* 310 */     return (r == null) ? this._secondary.hasRequiredMarker(m) : r;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Object findInjectableValueId(AnnotatedMember m) {
/* 316 */     Object r = this._primary.findInjectableValueId(m);
/* 317 */     return (r == null) ? this._secondary.findInjectableValueId(m) : r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findSerializer(Annotated am) {
/* 324 */     Object r = this._primary.findSerializer(am);
/* 325 */     if (_isExplicitClassOrOb(r, JsonSerializer.None.class)) {
/* 326 */       return r;
/*     */     }
/* 328 */     return _explicitClassOrOb(this._secondary.findSerializer(am), JsonSerializer.None.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findKeySerializer(Annotated a) {
/* 334 */     Object r = this._primary.findKeySerializer(a);
/* 335 */     if (_isExplicitClassOrOb(r, JsonSerializer.None.class)) {
/* 336 */       return r;
/*     */     }
/* 338 */     return _explicitClassOrOb(this._secondary.findKeySerializer(a), JsonSerializer.None.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findContentSerializer(Annotated a) {
/* 344 */     Object r = this._primary.findContentSerializer(a);
/* 345 */     if (_isExplicitClassOrOb(r, JsonSerializer.None.class)) {
/* 346 */       return r;
/*     */     }
/* 348 */     return _explicitClassOrOb(this._secondary.findContentSerializer(a), JsonSerializer.None.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findNullSerializer(Annotated a) {
/* 354 */     Object r = this._primary.findNullSerializer(a);
/* 355 */     if (_isExplicitClassOrOb(r, JsonSerializer.None.class)) {
/* 356 */       return r;
/*     */     }
/* 358 */     return _explicitClassOrOb(this._secondary.findNullSerializer(a), JsonSerializer.None.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonInclude.Value findPropertyInclusion(Annotated a) {
/* 365 */     JsonInclude.Value v2 = this._secondary.findPropertyInclusion(a);
/* 366 */     JsonInclude.Value v1 = this._primary.findPropertyInclusion(a);
/*     */     
/* 368 */     if (v2 == null) {
/* 369 */       return v1;
/*     */     }
/* 371 */     return v2.withOverrides(v1);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerialize.Typing findSerializationTyping(Annotated a) {
/* 376 */     JsonSerialize.Typing r = this._primary.findSerializationTyping(a);
/* 377 */     return (r == null) ? this._secondary.findSerializationTyping(a) : r;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object findSerializationConverter(Annotated a) {
/* 382 */     Object r = this._primary.findSerializationConverter(a);
/* 383 */     return (r == null) ? this._secondary.findSerializationConverter(a) : r;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object findSerializationContentConverter(AnnotatedMember a) {
/* 388 */     Object r = this._primary.findSerializationContentConverter(a);
/* 389 */     return (r == null) ? this._secondary.findSerializationContentConverter(a) : r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?>[] findViews(Annotated a) {
/* 398 */     Class<?>[] result = this._primary.findViews(a);
/* 399 */     if (result == null) {
/* 400 */       result = this._secondary.findViews(a);
/*     */     }
/* 402 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean isTypeId(AnnotatedMember member) {
/* 407 */     Boolean b = this._primary.isTypeId(member);
/* 408 */     return (b == null) ? this._secondary.isTypeId(member) : b;
/*     */   }
/*     */ 
/*     */   
/*     */   public ObjectIdInfo findObjectIdInfo(Annotated ann) {
/* 413 */     ObjectIdInfo r = this._primary.findObjectIdInfo(ann);
/* 414 */     return (r == null) ? this._secondary.findObjectIdInfo(ann) : r;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectIdInfo findObjectReferenceInfo(Annotated ann, ObjectIdInfo objectIdInfo) {
/* 420 */     objectIdInfo = this._secondary.findObjectReferenceInfo(ann, objectIdInfo);
/* 421 */     objectIdInfo = this._primary.findObjectReferenceInfo(ann, objectIdInfo);
/* 422 */     return objectIdInfo;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonFormat.Value findFormat(Annotated ann) {
/* 427 */     JsonFormat.Value v1 = this._primary.findFormat(ann);
/* 428 */     JsonFormat.Value v2 = this._secondary.findFormat(ann);
/* 429 */     if (v2 == null) {
/* 430 */       return v1;
/*     */     }
/* 432 */     return v2.withOverrides(v1);
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyName findWrapperName(Annotated ann) {
/* 437 */     return PropertyName.merge(this._primary.findWrapperName(ann), this._secondary
/* 438 */         .findWrapperName(ann));
/*     */   }
/*     */ 
/*     */   
/*     */   public String findPropertyDefaultValue(Annotated ann) {
/* 443 */     String str = this._primary.findPropertyDefaultValue(ann);
/* 444 */     return (str == null || str.isEmpty()) ? this._secondary.findPropertyDefaultValue(ann) : str;
/*     */   }
/*     */ 
/*     */   
/*     */   public String findPropertyDescription(Annotated ann) {
/* 449 */     String r = this._primary.findPropertyDescription(ann);
/* 450 */     return (r == null) ? this._secondary.findPropertyDescription(ann) : r;
/*     */   }
/*     */ 
/*     */   
/*     */   public Integer findPropertyIndex(Annotated ann) {
/* 455 */     Integer r = this._primary.findPropertyIndex(ann);
/* 456 */     return (r == null) ? this._secondary.findPropertyIndex(ann) : r;
/*     */   }
/*     */ 
/*     */   
/*     */   public String findImplicitPropertyName(AnnotatedMember ann) {
/* 461 */     String r = this._primary.findImplicitPropertyName(ann);
/* 462 */     return (r == null) ? this._secondary.findImplicitPropertyName(ann) : r;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<PropertyName> findPropertyAliases(Annotated ann) {
/* 467 */     List<PropertyName> r = this._primary.findPropertyAliases(ann);
/* 468 */     return (r == null) ? this._secondary.findPropertyAliases(ann) : r;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonProperty.Access findPropertyAccess(Annotated ann) {
/* 473 */     JsonProperty.Access acc = this._primary.findPropertyAccess(ann);
/* 474 */     if (acc != null && acc != JsonProperty.Access.AUTO) {
/* 475 */       return acc;
/*     */     }
/* 477 */     acc = this._secondary.findPropertyAccess(ann);
/* 478 */     if (acc != null) {
/* 479 */       return acc;
/*     */     }
/* 481 */     return JsonProperty.Access.AUTO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedMethod resolveSetterConflict(MapperConfig<?> config, AnnotatedMethod setter1, AnnotatedMethod setter2) {
/* 488 */     AnnotatedMethod res = this._primary.resolveSetterConflict(config, setter1, setter2);
/* 489 */     if (res == null) {
/* 490 */       res = this._secondary.resolveSetterConflict(config, setter1, setter2);
/*     */     }
/* 492 */     return res;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyName findRenameByField(MapperConfig<?> config, AnnotatedField f, PropertyName implName) {
/* 498 */     return PropertyName.merge(this._secondary.findRenameByField(config, f, implName), this._primary
/* 499 */         .findRenameByField(config, f, implName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType refineSerializationType(MapperConfig<?> config, Annotated a, JavaType baseType) throws JsonMappingException {
/* 508 */     JavaType t = this._secondary.refineSerializationType(config, a, baseType);
/* 509 */     return this._primary.refineSerializationType(config, a, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] findSerializationPropertyOrder(AnnotatedClass ac) {
/* 516 */     String[] r = this._primary.findSerializationPropertyOrder(ac);
/* 517 */     return (r == null) ? this._secondary.findSerializationPropertyOrder(ac) : r;
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean findSerializationSortAlphabetically(Annotated ann) {
/* 522 */     Boolean r = this._primary.findSerializationSortAlphabetically(ann);
/* 523 */     return (r == null) ? this._secondary.findSerializationSortAlphabetically(ann) : r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void findAndAddVirtualProperties(MapperConfig<?> config, AnnotatedClass ac, List<BeanPropertyWriter> properties) {
/* 530 */     this._primary.findAndAddVirtualProperties(config, ac, properties);
/* 531 */     this._secondary.findAndAddVirtualProperties(config, ac, properties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyName findNameForSerialization(Annotated a) {
/* 538 */     return PropertyName.merge(this._primary.findNameForSerialization(a), this._secondary
/* 539 */         .findNameForSerialization(a));
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean hasAsKey(MapperConfig<?> config, Annotated a) {
/* 544 */     Boolean b = this._primary.hasAsKey(config, a);
/* 545 */     if (b == null) {
/* 546 */       b = this._secondary.hasAsKey(config, a);
/*     */     }
/* 548 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean hasAsValue(Annotated a) {
/* 553 */     Boolean b = this._primary.hasAsValue(a);
/* 554 */     if (b == null) {
/* 555 */       b = this._secondary.hasAsValue(a);
/*     */     }
/* 557 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean hasAnyGetter(Annotated a) {
/* 562 */     Boolean b = this._primary.hasAnyGetter(a);
/* 563 */     if (b == null) {
/* 564 */       b = this._secondary.hasAnyGetter(a);
/*     */     }
/* 566 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String[] findEnumValues(Class<?> enumType, Enum<?>[] enumValues, String[] names) {
/* 573 */     names = this._secondary.findEnumValues(enumType, (Enum[])enumValues, names);
/* 574 */     names = this._primary.findEnumValues(enumType, (Enum[])enumValues, names);
/* 575 */     return names;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] findEnumValues(MapperConfig<?> config, AnnotatedClass annotatedClass, Enum<?>[] enumValues, String[] names) {
/* 582 */     names = this._secondary.findEnumValues(config, annotatedClass, (Enum[])enumValues, names);
/* 583 */     names = this._primary.findEnumValues(config, annotatedClass, (Enum[])enumValues, names);
/* 584 */     return names;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void findEnumAliases(Class<?> enumType, Enum<?>[] enumValues, String[][] aliases) {
/* 591 */     this._secondary.findEnumAliases(enumType, (Enum[])enumValues, aliases);
/* 592 */     this._primary.findEnumAliases(enumType, (Enum[])enumValues, aliases);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void findEnumAliases(MapperConfig<?> config, AnnotatedClass annotatedClass, Enum<?>[] enumConstants, String[][] aliases) {
/* 599 */     this._secondary.findEnumAliases(config, annotatedClass, (Enum[])enumConstants, aliases);
/* 600 */     this._primary.findEnumAliases(config, annotatedClass, (Enum[])enumConstants, aliases);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Enum<?> findDefaultEnumValue(Class<Enum<?>> enumCls) {
/* 606 */     Enum<?> en = this._primary.findDefaultEnumValue(enumCls);
/* 607 */     return (en == null) ? this._secondary.findDefaultEnumValue(enumCls) : en;
/*     */   }
/*     */ 
/*     */   
/*     */   public Enum<?> findDefaultEnumValue(AnnotatedClass annotatedClass, Enum<?>[] enumValues) {
/* 612 */     Enum<?> en = this._primary.findDefaultEnumValue(annotatedClass, (Enum[])enumValues);
/* 613 */     return (en == null) ? this._secondary.findDefaultEnumValue(annotatedClass, (Enum[])enumValues) : en;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String findEnumValue(Enum<?> value) {
/* 619 */     String r = this._primary.findEnumValue(value);
/* 620 */     return (r == null) ? this._secondary.findEnumValue(value) : r;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean hasAsValueAnnotation(AnnotatedMethod am) {
/* 626 */     return (this._primary.hasAsValueAnnotation(am) || this._secondary.hasAsValueAnnotation(am));
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean hasAnyGetterAnnotation(AnnotatedMethod am) {
/* 632 */     return (this._primary.hasAnyGetterAnnotation(am) || this._secondary.hasAnyGetterAnnotation(am));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findDeserializer(Annotated a) {
/* 639 */     Object r = this._primary.findDeserializer(a);
/* 640 */     if (_isExplicitClassOrOb(r, JsonDeserializer.None.class)) {
/* 641 */       return r;
/*     */     }
/* 643 */     return _explicitClassOrOb(this._secondary.findDeserializer(a), JsonDeserializer.None.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findKeyDeserializer(Annotated a) {
/* 649 */     Object r = this._primary.findKeyDeserializer(a);
/* 650 */     if (_isExplicitClassOrOb(r, KeyDeserializer.None.class)) {
/* 651 */       return r;
/*     */     }
/* 653 */     return _explicitClassOrOb(this._secondary.findKeyDeserializer(a), KeyDeserializer.None.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findContentDeserializer(Annotated am) {
/* 659 */     Object r = this._primary.findContentDeserializer(am);
/* 660 */     if (_isExplicitClassOrOb(r, JsonDeserializer.None.class)) {
/* 661 */       return r;
/*     */     }
/* 663 */     return _explicitClassOrOb(this._secondary.findContentDeserializer(am), JsonDeserializer.None.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findDeserializationConverter(Annotated a) {
/* 670 */     Object ob = this._primary.findDeserializationConverter(a);
/* 671 */     return (ob == null) ? this._secondary.findDeserializationConverter(a) : ob;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object findDeserializationContentConverter(AnnotatedMember a) {
/* 676 */     Object ob = this._primary.findDeserializationContentConverter(a);
/* 677 */     return (ob == null) ? this._secondary.findDeserializationContentConverter(a) : ob;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType refineDeserializationType(MapperConfig<?> config, Annotated a, JavaType baseType) throws JsonMappingException {
/* 687 */     JavaType t = this._secondary.refineDeserializationType(config, a, baseType);
/* 688 */     return this._primary.refineDeserializationType(config, a, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object findValueInstantiator(AnnotatedClass ac) {
/* 699 */     Object result = this._primary.findValueInstantiator(ac);
/* 700 */     return (result == null) ? this._secondary.findValueInstantiator(ac) : result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> findPOJOBuilder(AnnotatedClass ac) {
/* 705 */     Class<?> result = this._primary.findPOJOBuilder(ac);
/* 706 */     return (result == null) ? this._secondary.findPOJOBuilder(ac) : result;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonPOJOBuilder.Value findPOJOBuilderConfig(AnnotatedClass ac) {
/* 711 */     JsonPOJOBuilder.Value result = this._primary.findPOJOBuilderConfig(ac);
/* 712 */     return (result == null) ? this._secondary.findPOJOBuilderConfig(ac) : result;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean hasCreatorAnnotation(Annotated a) {
/* 718 */     return (this._primary.hasCreatorAnnotation(a) || this._secondary.hasCreatorAnnotation(a));
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonCreator.Mode findCreatorBinding(Annotated a) {
/* 724 */     JsonCreator.Mode mode = this._primary.findCreatorBinding(a);
/* 725 */     if (mode != null) {
/* 726 */       return mode;
/*     */     }
/* 728 */     return this._secondary.findCreatorBinding(a);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonCreator.Mode findCreatorAnnotation(MapperConfig<?> config, Annotated a) {
/* 733 */     JsonCreator.Mode mode = this._primary.findCreatorAnnotation(config, a);
/* 734 */     return (mode == null) ? this._secondary.findCreatorAnnotation(config, a) : mode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PotentialCreator findDefaultCreator(MapperConfig<?> config, AnnotatedClass valueClass, List<PotentialCreator> declaredConstructors, List<PotentialCreator> declaredFactories) {
/* 742 */     PotentialCreator primaryCtor = this._primary.findDefaultCreator(config, valueClass, declaredConstructors, declaredFactories);
/*     */     
/* 744 */     if (primaryCtor == null) {
/* 745 */       primaryCtor = this._secondary.findDefaultCreator(config, valueClass, declaredConstructors, declaredFactories);
/*     */     }
/*     */     
/* 748 */     return primaryCtor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyName findNameForDeserialization(Annotated a) {
/* 760 */     return PropertyName.merge(this._primary
/* 761 */         .findNameForDeserialization(a), this._secondary
/* 762 */         .findNameForDeserialization(a));
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean hasAnySetter(Annotated a) {
/* 767 */     Boolean b = this._primary.hasAnySetter(a);
/* 768 */     if (b == null) {
/* 769 */       b = this._secondary.hasAnySetter(a);
/*     */     }
/* 771 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSetter.Value findSetterInfo(Annotated a) {
/* 776 */     JsonSetter.Value v2 = this._secondary.findSetterInfo(a);
/* 777 */     JsonSetter.Value v1 = this._primary.findSetterInfo(a);
/* 778 */     return (v2 == null) ? v1 : v2
/* 779 */       .withOverrides(v1);
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean findMergeInfo(Annotated a) {
/* 784 */     Boolean b = this._primary.findMergeInfo(a);
/* 785 */     if (b == null) {
/* 786 */       b = this._secondary.findMergeInfo(a);
/*     */     }
/* 788 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean hasAnySetterAnnotation(AnnotatedMethod am) {
/* 795 */     return (this._primary.hasAnySetterAnnotation(am) || this._secondary.hasAnySetterAnnotation(am));
/*     */   }
/*     */   
/*     */   protected boolean _isExplicitClassOrOb(Object maybeCls, Class<?> implicit) {
/* 799 */     if (maybeCls == null || maybeCls == implicit) {
/* 800 */       return false;
/*     */     }
/* 802 */     if (maybeCls instanceof Class) {
/* 803 */       return !ClassUtil.isBogusClass((Class)maybeCls);
/*     */     }
/* 805 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object _explicitClassOrOb(Object maybeCls, Class<?> implicit) {
/* 810 */     if (maybeCls == null || maybeCls == implicit) {
/* 811 */       return null;
/*     */     }
/* 813 */     if (maybeCls instanceof Class && ClassUtil.isBogusClass((Class)maybeCls)) {
/* 814 */       return null;
/*     */     }
/* 816 */     return maybeCls;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\AnnotationIntrospectorPair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */