/*    */ package com.fasterxml.jackson.databind.introspect;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*    */ import com.fasterxml.jackson.annotation.ObjectIdResolver;
/*    */ import com.fasterxml.jackson.annotation.SimpleObjectIdResolver;
/*    */ import com.fasterxml.jackson.databind.PropertyName;
/*    */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObjectIdInfo
/*    */ {
/*    */   protected final PropertyName _propertyName;
/*    */   protected final Class<? extends ObjectIdGenerator<?>> _generator;
/*    */   protected final Class<? extends ObjectIdResolver> _resolver;
/*    */   protected final Class<?> _scope;
/*    */   protected final boolean _alwaysAsId;
/* 27 */   private static final ObjectIdInfo EMPTY = new ObjectIdInfo(PropertyName.NO_NAME, Object.class, null, false, null);
/*    */ 
/*    */ 
/*    */   
/*    */   public ObjectIdInfo(PropertyName name, Class<?> scope, Class<? extends ObjectIdGenerator<?>> gen, Class<? extends ObjectIdResolver> resolver) {
/* 32 */     this(name, scope, gen, false, resolver);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ObjectIdInfo(PropertyName prop, Class<?> scope, Class<? extends ObjectIdGenerator<?>> gen, boolean alwaysAsId) {
/* 38 */     this(prop, scope, gen, alwaysAsId, (Class)SimpleObjectIdResolver.class);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected ObjectIdInfo(PropertyName prop, Class<?> scope, Class<? extends ObjectIdGenerator<?>> gen, boolean alwaysAsId, Class<? extends ObjectIdResolver> resolver) {
/*    */     Class<SimpleObjectIdResolver> clazz;
/* 45 */     this._propertyName = prop;
/* 46 */     this._scope = scope;
/* 47 */     this._generator = gen;
/* 48 */     this._alwaysAsId = alwaysAsId;
/* 49 */     if (resolver == null) {
/* 50 */       clazz = SimpleObjectIdResolver.class;
/*    */     }
/* 52 */     this._resolver = (Class)clazz;
/*    */   }
/*    */   
/*    */   public static ObjectIdInfo empty() {
/* 56 */     return EMPTY;
/*    */   }
/*    */   
/*    */   public ObjectIdInfo withAlwaysAsId(boolean state) {
/* 60 */     if (this._alwaysAsId == state) {
/* 61 */       return this;
/*    */     }
/* 63 */     return new ObjectIdInfo(this._propertyName, this._scope, this._generator, state, this._resolver);
/*    */   }
/*    */   
/* 66 */   public PropertyName getPropertyName() { return this._propertyName; }
/* 67 */   public Class<?> getScope() { return this._scope; }
/* 68 */   public Class<? extends ObjectIdGenerator<?>> getGeneratorType() { return this._generator; }
/* 69 */   public Class<? extends ObjectIdResolver> getResolverType() { return this._resolver; } public boolean getAlwaysAsId() {
/* 70 */     return this._alwaysAsId;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 74 */     return "ObjectIdInfo: propName=" + this._propertyName + ", scope=" + 
/* 75 */       ClassUtil.nameOf(this._scope) + ", generatorType=" + 
/* 76 */       ClassUtil.nameOf(this._generator) + ", alwaysAsId=" + this._alwaysAsId;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\ObjectIdInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */