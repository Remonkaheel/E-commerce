/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.type.SimpleType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class BasicClassIntrospector extends ClassIntrospector implements Serializable {
/*     */   private static final long serialVersionUID = 2L;
/*  17 */   private static final Class<?> CLS_OBJECT = Object.class;
/*  18 */   private static final Class<?> CLS_STRING = String.class;
/*  19 */   private static final Class<?> CLS_JSON_NODE = JsonNode.class;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  31 */   protected static final BasicBeanDescription STRING_DESC = BasicBeanDescription.forOtherUse(null, (JavaType)SimpleType.constructUnsafe(String.class), 
/*  32 */       AnnotatedClassResolver.createPrimordial(CLS_STRING));
/*     */ 
/*     */ 
/*     */   
/*  36 */   protected static final BasicBeanDescription BOOLEAN_DESC = BasicBeanDescription.forOtherUse(null, (JavaType)SimpleType.constructUnsafe(boolean.class), 
/*  37 */       AnnotatedClassResolver.createPrimordial(boolean.class));
/*     */ 
/*     */ 
/*     */   
/*  41 */   protected static final BasicBeanDescription INT_DESC = BasicBeanDescription.forOtherUse(null, (JavaType)SimpleType.constructUnsafe(int.class), 
/*  42 */       AnnotatedClassResolver.createPrimordial(int.class));
/*     */ 
/*     */ 
/*     */   
/*  46 */   protected static final BasicBeanDescription LONG_DESC = BasicBeanDescription.forOtherUse(null, (JavaType)SimpleType.constructUnsafe(long.class), 
/*  47 */       AnnotatedClassResolver.createPrimordial(long.class));
/*     */ 
/*     */ 
/*     */   
/*  51 */   protected static final BasicBeanDescription OBJECT_DESC = BasicBeanDescription.forOtherUse(null, (JavaType)SimpleType.constructUnsafe(Object.class), 
/*  52 */       AnnotatedClassResolver.createPrimordial(CLS_OBJECT));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassIntrospector copy() {
/*  66 */     return new BasicClassIntrospector();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicBeanDescription forSerialization(SerializationConfig config, JavaType type, ClassIntrospector.MixInResolver r) {
/*  80 */     BasicBeanDescription desc = _findStdTypeDesc((MapperConfig<?>)config, type);
/*  81 */     if (desc == null) {
/*     */ 
/*     */       
/*  84 */       desc = _findStdJdkCollectionDesc((MapperConfig<?>)config, type);
/*  85 */       if (desc == null) {
/*  86 */         desc = BasicBeanDescription.forSerialization(collectProperties((MapperConfig<?>)config, type, r, true));
/*     */       }
/*     */     } 
/*     */     
/*  90 */     return desc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicBeanDescription forDeserialization(DeserializationConfig config, JavaType type, ClassIntrospector.MixInResolver r) {
/*  98 */     BasicBeanDescription desc = _findStdTypeDesc((MapperConfig<?>)config, type);
/*  99 */     if (desc == null) {
/*     */ 
/*     */       
/* 102 */       desc = _findStdJdkCollectionDesc((MapperConfig<?>)config, type);
/* 103 */       if (desc == null) {
/* 104 */         desc = BasicBeanDescription.forDeserialization(collectProperties((MapperConfig<?>)config, type, r, false));
/*     */       }
/*     */     } 
/*     */     
/* 108 */     return desc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicBeanDescription forDeserializationWithBuilder(DeserializationConfig config, JavaType builderType, ClassIntrospector.MixInResolver r, BeanDescription valueTypeDesc) {
/* 116 */     return BasicBeanDescription.forDeserialization(collectPropertiesWithBuilder((MapperConfig<?>)config, builderType, r, valueTypeDesc, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicBeanDescription forCreation(DeserializationConfig config, JavaType type, ClassIntrospector.MixInResolver r) {
/* 124 */     BasicBeanDescription desc = _findStdTypeDesc((MapperConfig<?>)config, type);
/* 125 */     if (desc == null) {
/*     */ 
/*     */       
/* 128 */       desc = _findStdJdkCollectionDesc((MapperConfig<?>)config, type);
/* 129 */       if (desc == null) {
/* 130 */         desc = BasicBeanDescription.forDeserialization(
/* 131 */             collectProperties((MapperConfig<?>)config, type, r, false));
/*     */       }
/*     */     } 
/* 134 */     return desc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicBeanDescription forClassAnnotations(MapperConfig<?> config, JavaType type, ClassIntrospector.MixInResolver r) {
/* 141 */     BasicBeanDescription desc = _findStdTypeDesc(config, type);
/* 142 */     if (desc == null) {
/* 143 */       desc = BasicBeanDescription.forOtherUse(config, type, 
/* 144 */           _resolveAnnotatedClass(config, type, r));
/*     */     }
/* 146 */     return desc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BasicBeanDescription forDirectClassAnnotations(MapperConfig<?> config, JavaType type, ClassIntrospector.MixInResolver r) {
/* 153 */     BasicBeanDescription desc = _findStdTypeDesc(config, type);
/* 154 */     if (desc == null) {
/* 155 */       desc = BasicBeanDescription.forOtherUse(config, type, 
/* 156 */           _resolveAnnotatedWithoutSuperTypes(config, type, r));
/*     */     }
/* 158 */     return desc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected POJOPropertiesCollector collectProperties(MapperConfig<?> config, JavaType type, ClassIntrospector.MixInResolver r, boolean forSerialization) {
/* 173 */     AnnotatedClass classDef = _resolveAnnotatedClass(config, type, r);
/*     */ 
/*     */     
/* 176 */     AccessorNamingStrategy accNaming = type.isRecordType() ? config.getAccessorNaming().forRecord(config, classDef) : config.getAccessorNaming().forPOJO(config, classDef);
/* 177 */     return constructPropertyCollector(config, classDef, type, forSerialization, accNaming);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected POJOPropertiesCollector collectPropertiesWithBuilder(MapperConfig<?> config, JavaType type, ClassIntrospector.MixInResolver r, BeanDescription valueTypeDesc, boolean forSerialization) {
/* 187 */     AnnotatedClass builderClassDef = _resolveAnnotatedClass(config, type, r);
/*     */     
/* 189 */     AccessorNamingStrategy accNaming = config.getAccessorNaming().forBuilder(config, builderClassDef, valueTypeDesc);
/* 190 */     return constructPropertyCollector(config, builderClassDef, type, forSerialization, accNaming);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected POJOPropertiesCollector constructPropertyCollector(MapperConfig<?> config, AnnotatedClass classDef, JavaType type, boolean forSerialization, AccessorNamingStrategy accNaming) {
/* 203 */     return new POJOPropertiesCollector(config, forSerialization, type, classDef, accNaming);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BasicBeanDescription _findStdTypeDesc(MapperConfig<?> config, JavaType type) {
/* 212 */     Class<?> cls = type.getRawClass();
/* 213 */     if (cls.isPrimitive()) {
/* 214 */       if (cls == int.class) {
/* 215 */         return INT_DESC;
/*     */       }
/* 217 */       if (cls == long.class) {
/* 218 */         return LONG_DESC;
/*     */       }
/* 220 */       if (cls == boolean.class) {
/* 221 */         return BOOLEAN_DESC;
/*     */       }
/* 223 */     } else if (ClassUtil.isJDKClass(cls)) {
/* 224 */       if (cls == CLS_OBJECT) {
/* 225 */         return OBJECT_DESC;
/*     */       }
/* 227 */       if (cls == CLS_STRING) {
/* 228 */         return STRING_DESC;
/*     */       }
/* 230 */       if (cls == Integer.class) {
/* 231 */         return INT_DESC;
/*     */       }
/* 233 */       if (cls == Long.class) {
/* 234 */         return LONG_DESC;
/*     */       }
/* 236 */       if (cls == Boolean.class) {
/* 237 */         return BOOLEAN_DESC;
/*     */       }
/* 239 */     } else if (CLS_JSON_NODE.isAssignableFrom(cls)) {
/* 240 */       return BasicBeanDescription.forOtherUse(config, type, 
/* 241 */           AnnotatedClassResolver.createPrimordial(cls));
/*     */     } 
/* 243 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _isStdJDKCollection(JavaType type) {
/* 253 */     if (!type.isContainerType() || type.isArrayType()) {
/* 254 */       return false;
/*     */     }
/* 256 */     Class<?> raw = type.getRawClass();
/* 257 */     if (ClassUtil.isJDKClass(raw))
/*     */     {
/*     */       
/* 260 */       if (Collection.class.isAssignableFrom(raw) || Map.class
/* 261 */         .isAssignableFrom(raw)) {
/*     */ 
/*     */         
/* 264 */         if (raw.toString().indexOf('$') > 0) {
/* 265 */           return false;
/*     */         }
/* 267 */         return true;
/*     */       } 
/*     */     }
/* 270 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected BasicBeanDescription _findStdJdkCollectionDesc(MapperConfig<?> cfg, JavaType type) {
/* 275 */     if (_isStdJDKCollection(type)) {
/* 276 */       return BasicBeanDescription.forOtherUse(cfg, type, 
/* 277 */           _resolveAnnotatedClass(cfg, type, (ClassIntrospector.MixInResolver)cfg));
/*     */     }
/* 279 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotatedClass _resolveAnnotatedClass(MapperConfig<?> config, JavaType type, ClassIntrospector.MixInResolver r) {
/* 287 */     return AnnotatedClassResolver.resolve(config, type, r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotatedClass _resolveAnnotatedWithoutSuperTypes(MapperConfig<?> config, JavaType type, ClassIntrospector.MixInResolver r) {
/* 295 */     return AnnotatedClassResolver.resolveWithoutSuperTypes(config, type, r);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\BasicClassIntrospector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */