/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.PropertyAccessor;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface VisibilityChecker<T extends VisibilityChecker<T>>
/*     */ {
/*     */   T with(JsonAutoDetect paramJsonAutoDetect);
/*     */   
/*     */   T withOverrides(JsonAutoDetect.Value paramValue);
/*     */   
/*     */   T with(JsonAutoDetect.Visibility paramVisibility);
/*     */   
/*     */   T withVisibility(PropertyAccessor paramPropertyAccessor, JsonAutoDetect.Visibility paramVisibility);
/*     */   
/*     */   T withGetterVisibility(JsonAutoDetect.Visibility paramVisibility);
/*     */   
/*     */   T withIsGetterVisibility(JsonAutoDetect.Visibility paramVisibility);
/*     */   
/*     */   T withSetterVisibility(JsonAutoDetect.Visibility paramVisibility);
/*     */   
/*     */   T withCreatorVisibility(JsonAutoDetect.Visibility paramVisibility);
/*     */   
/*     */   T withFieldVisibility(JsonAutoDetect.Visibility paramVisibility);
/*     */   
/*     */   boolean isGetterVisible(Method paramMethod);
/*     */   
/*     */   boolean isGetterVisible(AnnotatedMethod paramAnnotatedMethod);
/*     */   
/*     */   boolean isIsGetterVisible(Method paramMethod);
/*     */   
/*     */   boolean isIsGetterVisible(AnnotatedMethod paramAnnotatedMethod);
/*     */   
/*     */   boolean isSetterVisible(Method paramMethod);
/*     */   
/*     */   boolean isSetterVisible(AnnotatedMethod paramAnnotatedMethod);
/*     */   
/*     */   boolean isCreatorVisible(Member paramMember);
/*     */   
/*     */   boolean isCreatorVisible(AnnotatedMember paramAnnotatedMember);
/*     */   
/*     */   boolean isFieldVisible(Field paramField);
/*     */   
/*     */   boolean isFieldVisible(AnnotatedField paramAnnotatedField);
/*     */   
/*     */   public static class Std
/*     */     implements VisibilityChecker<Std>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/* 163 */     protected static final Std DEFAULT = new Std(JsonAutoDetect.Visibility.PUBLIC_ONLY, JsonAutoDetect.Visibility.PUBLIC_ONLY, JsonAutoDetect.Visibility.ANY, JsonAutoDetect.Visibility.ANY, JsonAutoDetect.Visibility.PUBLIC_ONLY);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 177 */     protected static final Std ALL_PUBLIC = new Std(JsonAutoDetect.Visibility.PUBLIC_ONLY, JsonAutoDetect.Visibility.PUBLIC_ONLY, JsonAutoDetect.Visibility.PUBLIC_ONLY, JsonAutoDetect.Visibility.PUBLIC_ONLY, JsonAutoDetect.Visibility.PUBLIC_ONLY);
/*     */ 
/*     */     
/*     */     protected final JsonAutoDetect.Visibility _getterMinLevel;
/*     */ 
/*     */     
/*     */     protected final JsonAutoDetect.Visibility _isGetterMinLevel;
/*     */ 
/*     */     
/*     */     protected final JsonAutoDetect.Visibility _setterMinLevel;
/*     */ 
/*     */     
/*     */     protected final JsonAutoDetect.Visibility _creatorMinLevel;
/*     */     
/*     */     protected final JsonAutoDetect.Visibility _fieldMinLevel;
/*     */ 
/*     */     
/*     */     public static Std defaultInstance() {
/* 195 */       return DEFAULT;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Std allPublicInstance() {
/* 202 */       return ALL_PUBLIC;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Std(JsonAutoDetect ann) {
/* 213 */       this._getterMinLevel = ann.getterVisibility();
/* 214 */       this._isGetterMinLevel = ann.isGetterVisibility();
/* 215 */       this._setterMinLevel = ann.setterVisibility();
/* 216 */       this._creatorMinLevel = ann.creatorVisibility();
/* 217 */       this._fieldMinLevel = ann.fieldVisibility();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Std(JsonAutoDetect.Visibility getter, JsonAutoDetect.Visibility isGetter, JsonAutoDetect.Visibility setter, JsonAutoDetect.Visibility creator, JsonAutoDetect.Visibility field) {
/* 226 */       this._getterMinLevel = getter;
/* 227 */       this._isGetterMinLevel = isGetter;
/* 228 */       this._setterMinLevel = setter;
/* 229 */       this._creatorMinLevel = creator;
/* 230 */       this._fieldMinLevel = field;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Std(JsonAutoDetect.Visibility v) {
/* 242 */       if (v == JsonAutoDetect.Visibility.DEFAULT) {
/* 243 */         this._getterMinLevel = DEFAULT._getterMinLevel;
/* 244 */         this._isGetterMinLevel = DEFAULT._isGetterMinLevel;
/* 245 */         this._setterMinLevel = DEFAULT._setterMinLevel;
/* 246 */         this._creatorMinLevel = DEFAULT._creatorMinLevel;
/* 247 */         this._fieldMinLevel = DEFAULT._fieldMinLevel;
/*     */       } else {
/* 249 */         this._getterMinLevel = v;
/* 250 */         this._isGetterMinLevel = v;
/* 251 */         this._setterMinLevel = v;
/* 252 */         this._creatorMinLevel = v;
/* 253 */         this._fieldMinLevel = v;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Std construct(JsonAutoDetect.Value vis) {
/* 261 */       return DEFAULT.withOverrides(vis);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Std _with(JsonAutoDetect.Visibility g, JsonAutoDetect.Visibility isG, JsonAutoDetect.Visibility s, JsonAutoDetect.Visibility cr, JsonAutoDetect.Visibility f) {
/* 273 */       if (g == this._getterMinLevel && isG == this._isGetterMinLevel && s == this._setterMinLevel && cr == this._creatorMinLevel && f == this._fieldMinLevel)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 279 */         return this;
/*     */       }
/* 281 */       return new Std(g, isG, s, cr, f);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Std with(JsonAutoDetect ann) {
/* 287 */       Std curr = this;
/* 288 */       if (ann != null) {
/* 289 */         return _with(
/* 290 */             _defaultOrOverride(this._getterMinLevel, ann.getterVisibility()), 
/* 291 */             _defaultOrOverride(this._isGetterMinLevel, ann.isGetterVisibility()), 
/* 292 */             _defaultOrOverride(this._setterMinLevel, ann.setterVisibility()), 
/* 293 */             _defaultOrOverride(this._creatorMinLevel, ann.creatorVisibility()), 
/* 294 */             _defaultOrOverride(this._fieldMinLevel, ann.fieldVisibility()));
/*     */       }
/*     */       
/* 297 */       return curr;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Std withOverrides(JsonAutoDetect.Value vis) {
/* 303 */       Std curr = this;
/* 304 */       if (vis != null) {
/* 305 */         return _with(
/* 306 */             _defaultOrOverride(this._getterMinLevel, vis.getGetterVisibility()), 
/* 307 */             _defaultOrOverride(this._isGetterMinLevel, vis.getIsGetterVisibility()), 
/* 308 */             _defaultOrOverride(this._setterMinLevel, vis.getSetterVisibility()), 
/* 309 */             _defaultOrOverride(this._creatorMinLevel, vis.getCreatorVisibility()), 
/* 310 */             _defaultOrOverride(this._fieldMinLevel, vis.getFieldVisibility()));
/*     */       }
/*     */       
/* 313 */       return curr;
/*     */     }
/*     */     
/*     */     private JsonAutoDetect.Visibility _defaultOrOverride(JsonAutoDetect.Visibility defaults, JsonAutoDetect.Visibility override) {
/* 317 */       if (override == JsonAutoDetect.Visibility.DEFAULT) {
/* 318 */         return defaults;
/*     */       }
/* 320 */       return override;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Std with(JsonAutoDetect.Visibility v) {
/* 326 */       if (v == JsonAutoDetect.Visibility.DEFAULT) {
/* 327 */         return DEFAULT;
/*     */       }
/* 329 */       return new Std(v);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Std withVisibility(PropertyAccessor method, JsonAutoDetect.Visibility v) {
/* 335 */       switch (method) {
/*     */         case GETTER:
/* 337 */           return withGetterVisibility(v);
/*     */         case SETTER:
/* 339 */           return withSetterVisibility(v);
/*     */         case CREATOR:
/* 341 */           return withCreatorVisibility(v);
/*     */         case FIELD:
/* 343 */           return withFieldVisibility(v);
/*     */         case IS_GETTER:
/* 345 */           return withIsGetterVisibility(v);
/*     */         case ALL:
/* 347 */           return with(v);
/*     */       } 
/*     */ 
/*     */       
/* 351 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Std withGetterVisibility(JsonAutoDetect.Visibility v) {
/* 357 */       if (v == JsonAutoDetect.Visibility.DEFAULT) v = DEFAULT._getterMinLevel; 
/* 358 */       if (this._getterMinLevel == v) return this; 
/* 359 */       return new Std(v, this._isGetterMinLevel, this._setterMinLevel, this._creatorMinLevel, this._fieldMinLevel);
/*     */     }
/*     */ 
/*     */     
/*     */     public Std withIsGetterVisibility(JsonAutoDetect.Visibility v) {
/* 364 */       if (v == JsonAutoDetect.Visibility.DEFAULT) v = DEFAULT._isGetterMinLevel; 
/* 365 */       if (this._isGetterMinLevel == v) return this; 
/* 366 */       return new Std(this._getterMinLevel, v, this._setterMinLevel, this._creatorMinLevel, this._fieldMinLevel);
/*     */     }
/*     */ 
/*     */     
/*     */     public Std withSetterVisibility(JsonAutoDetect.Visibility v) {
/* 371 */       if (v == JsonAutoDetect.Visibility.DEFAULT) v = DEFAULT._setterMinLevel; 
/* 372 */       if (this._setterMinLevel == v) return this; 
/* 373 */       return new Std(this._getterMinLevel, this._isGetterMinLevel, v, this._creatorMinLevel, this._fieldMinLevel);
/*     */     }
/*     */ 
/*     */     
/*     */     public Std withCreatorVisibility(JsonAutoDetect.Visibility v) {
/* 378 */       if (v == JsonAutoDetect.Visibility.DEFAULT) v = DEFAULT._creatorMinLevel; 
/* 379 */       if (this._creatorMinLevel == v) return this; 
/* 380 */       return new Std(this._getterMinLevel, this._isGetterMinLevel, this._setterMinLevel, v, this._fieldMinLevel);
/*     */     }
/*     */ 
/*     */     
/*     */     public Std withFieldVisibility(JsonAutoDetect.Visibility v) {
/* 385 */       if (v == JsonAutoDetect.Visibility.DEFAULT) v = DEFAULT._fieldMinLevel; 
/* 386 */       if (this._fieldMinLevel == v) return this; 
/* 387 */       return new Std(this._getterMinLevel, this._isGetterMinLevel, this._setterMinLevel, this._creatorMinLevel, v);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isCreatorVisible(Member m) {
/* 398 */       return this._creatorMinLevel.isVisible(m);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isCreatorVisible(AnnotatedMember m) {
/* 403 */       return isCreatorVisible(m.getMember());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isFieldVisible(Field f) {
/* 408 */       return this._fieldMinLevel.isVisible(f);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isFieldVisible(AnnotatedField f) {
/* 413 */       return isFieldVisible(f.getAnnotated());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isGetterVisible(Method m) {
/* 418 */       return this._getterMinLevel.isVisible(m);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isGetterVisible(AnnotatedMethod m) {
/* 423 */       return isGetterVisible(m.getAnnotated());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isIsGetterVisible(Method m) {
/* 428 */       return this._isGetterMinLevel.isVisible(m);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isIsGetterVisible(AnnotatedMethod m) {
/* 433 */       return isIsGetterVisible(m.getAnnotated());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isSetterVisible(Method m) {
/* 438 */       return this._setterMinLevel.isVisible(m);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isSetterVisible(AnnotatedMethod m) {
/* 443 */       return isSetterVisible(m.getAnnotated());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 454 */       return String.format("[Visibility: getter=%s,isGetter=%s,setter=%s,creator=%s,field=%s]", new Object[] { this._getterMinLevel, this._isGetterMinLevel, this._setterMinLevel, this._creatorMinLevel, this._fieldMinLevel });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\VisibilityChecker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */