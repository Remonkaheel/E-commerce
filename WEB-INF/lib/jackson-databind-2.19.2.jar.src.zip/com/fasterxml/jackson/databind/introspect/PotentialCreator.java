/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PotentialCreator
/*     */ {
/*  19 */   private static final PropertyName[] NO_NAMES = new PropertyName[0];
/*     */ 
/*     */ 
/*     */   
/*     */   private final AnnotatedWithParams _creator;
/*     */ 
/*     */   
/*     */   private final boolean _isAnnotated;
/*     */ 
/*     */   
/*     */   private JsonCreator.Mode _creatorMode;
/*     */ 
/*     */   
/*     */   private PropertyName[] _implicitParamNames;
/*     */ 
/*     */   
/*     */   private PropertyName[] _explicitParamNames;
/*     */ 
/*     */   
/*     */   private List<BeanPropertyDefinition> _propertyDefs;
/*     */ 
/*     */ 
/*     */   
/*     */   public PotentialCreator(AnnotatedWithParams cr, JsonCreator.Mode cm) {
/*  43 */     this._creator = cr;
/*  44 */     this._isAnnotated = (cm != null);
/*  45 */     this._creatorMode = (cm == null) ? JsonCreator.Mode.DEFAULT : cm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PotentialCreator overrideMode(JsonCreator.Mode mode) {
/*  58 */     this._creatorMode = mode;
/*  59 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void assignPropertyDefs(List<? extends BeanPropertyDefinition> propertyDefs) {
/*  70 */     this._propertyDefs = (List)propertyDefs;
/*     */   }
/*     */ 
/*     */   
/*     */   public PotentialCreator introspectParamNames(MapperConfig<?> config) {
/*  75 */     if (this._implicitParamNames != null) {
/*  76 */       return this;
/*     */     }
/*  78 */     int paramCount = this._creator.getParameterCount();
/*     */     
/*  80 */     if (paramCount == 0) {
/*  81 */       this._implicitParamNames = this._explicitParamNames = NO_NAMES;
/*  82 */       return this;
/*     */     } 
/*     */     
/*  85 */     this._explicitParamNames = new PropertyName[paramCount];
/*  86 */     this._implicitParamNames = new PropertyName[paramCount];
/*     */     
/*  88 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/*  89 */     for (int i = 0; i < paramCount; i++) {
/*  90 */       AnnotatedParameter param = this._creator.getParameter(i);
/*     */       
/*  92 */       String rawImplName = intr.findImplicitPropertyName(param);
/*  93 */       if (rawImplName != null && !rawImplName.isEmpty()) {
/*  94 */         this._implicitParamNames[i] = PropertyName.construct(rawImplName);
/*     */       }
/*  96 */       PropertyName explName = intr.findNameForDeserialization(param);
/*  97 */       if (explName != null && !explName.isEmpty()) {
/*  98 */         this._explicitParamNames[i] = explName;
/*     */       }
/*     */     } 
/* 101 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PotentialCreator introspectParamNames(MapperConfig<?> config, PropertyName[] implicits) {
/* 111 */     if (this._implicitParamNames != null) {
/* 112 */       return this;
/*     */     }
/* 114 */     int paramCount = this._creator.getParameterCount();
/* 115 */     if (paramCount == 0) {
/* 116 */       this._implicitParamNames = this._explicitParamNames = NO_NAMES;
/* 117 */       return this;
/*     */     } 
/*     */     
/* 120 */     this._explicitParamNames = new PropertyName[paramCount];
/* 121 */     this._implicitParamNames = implicits;
/*     */     
/* 123 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 124 */     for (int i = 0; i < paramCount; i++) {
/* 125 */       AnnotatedParameter param = this._creator.getParameter(i);
/*     */       
/* 127 */       PropertyName explName = intr.findNameForDeserialization(param);
/* 128 */       if (explName != null && !explName.isEmpty()) {
/* 129 */         this._explicitParamNames[i] = explName;
/*     */       }
/*     */     } 
/* 132 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAnnotated() {
/* 142 */     return this._isAnnotated;
/*     */   }
/*     */   
/*     */   public AnnotatedWithParams creator() {
/* 146 */     return this._creator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonCreator.Mode creatorMode() {
/* 154 */     return this._creatorMode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonCreator.Mode creatorModeOrDefault() {
/* 162 */     if (this._creatorMode == null) {
/* 163 */       return JsonCreator.Mode.DEFAULT;
/*     */     }
/* 165 */     return this._creatorMode;
/*     */   }
/*     */   
/*     */   public int paramCount() {
/* 169 */     return this._creator.getParameterCount();
/*     */   }
/*     */   
/*     */   public AnnotatedParameter param(int ix) {
/* 173 */     return this._creator.getParameter(ix);
/*     */   }
/*     */   
/*     */   public boolean hasExplicitNames() {
/* 177 */     for (int i = 0, end = this._explicitParamNames.length; i < end; i++) {
/* 178 */       if (this._explicitParamNames[i] != null) {
/* 179 */         return true;
/*     */       }
/*     */     } 
/* 182 */     return false;
/*     */   }
/*     */   
/*     */   public boolean hasNameFor(int ix) {
/* 186 */     return (this._explicitParamNames[ix] != null || this._implicitParamNames[ix] != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNameOrInjectForAllParams(MapperConfig<?> config) {
/* 192 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 193 */     for (int i = 0, end = this._implicitParamNames.length; i < end; i++) {
/* 194 */       if (!hasNameFor(i) && (
/* 195 */         intr == null || intr.findInjectableValue(this._creator.getParameter(i)) == null)) {
/* 196 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 200 */     return true;
/*     */   }
/*     */   
/*     */   public PropertyName explicitName(int ix) {
/* 204 */     return this._explicitParamNames[ix];
/*     */   }
/*     */   
/*     */   public PropertyName implicitName(int ix) {
/* 208 */     return this._implicitParamNames[ix];
/*     */   }
/*     */   
/*     */   public String implicitNameSimple(int ix) {
/* 212 */     PropertyName pn = this._implicitParamNames[ix];
/* 213 */     return (pn == null) ? null : pn.getSimpleName();
/*     */   }
/*     */   
/*     */   public BeanPropertyDefinition[] propertyDefs() {
/* 217 */     if (this._propertyDefs == null || this._propertyDefs.isEmpty()) {
/* 218 */       return new BeanPropertyDefinition[0];
/*     */     }
/* 220 */     return this._propertyDefs.<BeanPropertyDefinition>toArray(new BeanPropertyDefinition[this._propertyDefs.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 232 */     return "(mode=" + this._creatorMode + ")" + this._creator;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\PotentialCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */