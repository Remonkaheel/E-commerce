/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
/*     */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.util.Annotations;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class BasicBeanDescription
/*     */   extends BeanDescription {
/*  28 */   private static final Class<?>[] NO_VIEWS = new Class[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final POJOPropertiesCollector _propCollector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MapperConfig<?> _config;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AnnotationIntrospector _annotationIntrospector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AnnotatedClass _classInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?>[] _defaultViews;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _defaultViewsResolved;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<BeanPropertyDefinition> _properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectIdInfo _objectIdInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BasicBeanDescription(POJOPropertiesCollector coll, JavaType type, AnnotatedClass classDef) {
/*  93 */     super(type);
/*  94 */     this._propCollector = coll;
/*  95 */     this._config = coll.getConfig();
/*     */     
/*  97 */     if (this._config == null) {
/*  98 */       this._annotationIntrospector = null;
/*     */     } else {
/* 100 */       this._annotationIntrospector = this._config.getAnnotationIntrospector();
/*     */     } 
/* 102 */     this._classInfo = classDef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BasicBeanDescription(MapperConfig<?> config, JavaType type, AnnotatedClass classDef, List<BeanPropertyDefinition> props) {
/* 112 */     super(type);
/* 113 */     this._propCollector = null;
/* 114 */     this._config = config;
/*     */     
/* 116 */     if (this._config == null) {
/* 117 */       this._annotationIntrospector = null;
/*     */     } else {
/* 119 */       this._annotationIntrospector = this._config.getAnnotationIntrospector();
/*     */     } 
/* 121 */     this._classInfo = classDef;
/* 122 */     this._properties = props;
/*     */   }
/*     */ 
/*     */   
/*     */   protected BasicBeanDescription(POJOPropertiesCollector coll) {
/* 127 */     this(coll, coll.getType(), coll.getClassDef());
/* 128 */     this._objectIdInfo = coll.getObjectIdInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BasicBeanDescription forDeserialization(POJOPropertiesCollector coll) {
/* 136 */     return new BasicBeanDescription(coll);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BasicBeanDescription forSerialization(POJOPropertiesCollector coll) {
/* 144 */     return new BasicBeanDescription(coll);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BasicBeanDescription forOtherUse(MapperConfig<?> config, JavaType type, AnnotatedClass ac) {
/* 155 */     return new BasicBeanDescription(config, type, ac, 
/* 156 */         Collections.emptyList());
/*     */   }
/*     */   
/*     */   protected List<BeanPropertyDefinition> _properties() {
/* 160 */     if (this._properties == null) {
/* 161 */       this._properties = this._propCollector.getProperties();
/*     */     }
/* 163 */     return this._properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeProperty(String propName) {
/* 181 */     Iterator<BeanPropertyDefinition> it = _properties().iterator();
/* 182 */     while (it.hasNext()) {
/* 183 */       BeanPropertyDefinition prop = it.next();
/* 184 */       if (prop.getName().equals(propName)) {
/* 185 */         it.remove();
/* 186 */         return true;
/*     */       } 
/*     */     } 
/* 189 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addProperty(BeanPropertyDefinition def) {
/* 195 */     if (hasProperty(def.getFullName())) {
/* 196 */       return false;
/*     */     }
/* 198 */     _properties().add(def);
/* 199 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasProperty(PropertyName name) {
/* 206 */     return (findProperty(name) != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyDefinition findProperty(PropertyName name) {
/* 214 */     for (BeanPropertyDefinition prop : _properties()) {
/* 215 */       if (prop.hasName(name)) {
/* 216 */         return prop;
/*     */       }
/*     */     } 
/* 219 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedClass getClassInfo() {
/* 229 */     return this._classInfo;
/*     */   }
/*     */   public ObjectIdInfo getObjectIdInfo() {
/* 232 */     return this._objectIdInfo;
/*     */   }
/*     */   
/*     */   public List<BeanPropertyDefinition> findProperties() {
/* 236 */     return _properties();
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedMember findJsonKeyAccessor() {
/* 241 */     return (this._propCollector == null) ? null : this._propCollector
/* 242 */       .getJsonKeyAccessor();
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedMember findJsonValueAccessor() {
/* 247 */     return (this._propCollector == null) ? null : this._propCollector
/* 248 */       .getJsonValueAccessor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getIgnoredPropertyNames() {
/* 254 */     Set<String> ign = (this._propCollector == null) ? null : this._propCollector.getIgnoredPropertyNames();
/* 255 */     if (ign == null) {
/* 256 */       return Collections.emptySet();
/*     */     }
/* 258 */     return ign;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasKnownClassAnnotations() {
/* 263 */     return this._classInfo.hasAnnotations();
/*     */   }
/*     */ 
/*     */   
/*     */   public Annotations getClassAnnotations() {
/* 268 */     return this._classInfo.getAnnotations();
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedConstructor findDefaultConstructor() {
/* 273 */     return this._classInfo.getDefaultConstructor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedMember findAnySetterAccessor() throws IllegalArgumentException {
/* 279 */     if (this._propCollector != null) {
/* 280 */       AnnotatedMethod anyMethod = this._propCollector.getAnySetterMethod();
/* 281 */       if (anyMethod != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 288 */         Class<?> type = anyMethod.getRawParameterType(0);
/* 289 */         if (type != String.class && type != Object.class) {
/* 290 */           throw new IllegalArgumentException(String.format("Invalid 'any-setter' annotation on method '%s()': first argument not of type String or Object, but %s", new Object[] { anyMethod
/*     */                   
/* 292 */                   .getName(), type.getName() }));
/*     */         }
/* 294 */         return anyMethod;
/*     */       } 
/* 296 */       AnnotatedMember anyField = this._propCollector.getAnySetterField();
/* 297 */       if (anyField != null) {
/*     */ 
/*     */         
/* 300 */         Class<?> type = anyField.getRawType();
/* 301 */         if (!Map.class.isAssignableFrom(type) && 
/* 302 */           !JsonNode.class.isAssignableFrom(type)) {
/* 303 */           throw new IllegalArgumentException(String.format("Invalid 'any-setter' annotation on field '%s': type is not instance of `java.util.Map` or `JsonNode`", new Object[] { anyField
/*     */                   
/* 305 */                   .getName() }));
/*     */         }
/* 307 */         return anyField;
/*     */       } 
/*     */     } 
/* 310 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<Object, AnnotatedMember> findInjectables() {
/* 315 */     if (this._propCollector != null) {
/* 316 */       return this._propCollector.getInjectables();
/*     */     }
/* 318 */     return Collections.emptyMap();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<AnnotatedConstructor> getConstructors() {
/* 323 */     return this._classInfo.getConstructors();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<AnnotatedAndMetadata<AnnotatedConstructor, JsonCreator.Mode>> getConstructorsWithMode() {
/* 328 */     List<AnnotatedConstructor> allCtors = this._classInfo.getConstructors();
/* 329 */     if (allCtors.isEmpty()) {
/* 330 */       return Collections.emptyList();
/*     */     }
/* 332 */     List<AnnotatedAndMetadata<AnnotatedConstructor, JsonCreator.Mode>> result = new ArrayList<>();
/* 333 */     for (AnnotatedConstructor ctor : allCtors) {
/* 334 */       JsonCreator.Mode mode = this._annotationIntrospector.findCreatorAnnotation(this._config, ctor);
/* 335 */       if (mode == JsonCreator.Mode.DISABLED) {
/*     */         continue;
/*     */       }
/* 338 */       result.add(AnnotatedAndMetadata.of(ctor, mode));
/*     */     } 
/* 340 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public PotentialCreators getPotentialCreators() {
/* 345 */     if (this._propCollector == null) {
/* 346 */       return new PotentialCreators();
/*     */     }
/* 348 */     return this._propCollector.getPotentialCreators();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object instantiateBean(boolean fixAccess) {
/* 353 */     AnnotatedConstructor ac = this._classInfo.getDefaultConstructor();
/* 354 */     if (ac == null) {
/* 355 */       return null;
/*     */     }
/* 357 */     if (fixAccess) {
/* 358 */       ac.fixAccess(this._config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */     }
/*     */     try {
/* 361 */       return ac.call();
/* 362 */     } catch (Exception e) {
/* 363 */       Throwable t = e;
/* 364 */       while (t.getCause() != null) {
/* 365 */         t = t.getCause();
/*     */       }
/* 367 */       ClassUtil.throwIfError(t);
/* 368 */       ClassUtil.throwIfRTE(t);
/* 369 */       throw new IllegalArgumentException("Failed to instantiate bean of type " + this._classInfo
/* 370 */           .getAnnotated().getName() + ": (" + t.getClass().getName() + ") " + 
/* 371 */           ClassUtil.exceptionMessage(t), t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedMethod findMethod(String name, Class<?>[] paramTypes) {
/* 383 */     return this._classInfo.findMethod(name, paramTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonFormat.Value findExpectedFormat() {
/* 395 */     if (this._propCollector == null) {
/* 396 */       return JsonFormat.Value.empty();
/*     */     }
/* 398 */     return this._propCollector.getFormatOverrides();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?>[] findDefaultViews() {
/* 404 */     if (!this._defaultViewsResolved) {
/* 405 */       this._defaultViewsResolved = true;
/*     */       
/* 407 */       Class<?>[] def = (this._annotationIntrospector == null) ? null : this._annotationIntrospector.findViews(this._classInfo);
/*     */       
/* 409 */       if (def == null && 
/* 410 */         !this._config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION)) {
/* 411 */         def = NO_VIEWS;
/*     */       }
/*     */       
/* 414 */       this._defaultViews = def;
/*     */     } 
/* 416 */     return this._defaultViews;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Converter<Object, Object> findSerializationConverter() {
/* 428 */     if (this._annotationIntrospector == null) {
/* 429 */       return null;
/*     */     }
/* 431 */     return _createConverter(this._annotationIntrospector.findSerializationConverter(this._classInfo));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonInclude.Value findPropertyInclusion(JsonInclude.Value defValue) {
/* 442 */     if (this._annotationIntrospector != null) {
/* 443 */       JsonInclude.Value incl = this._annotationIntrospector.findPropertyInclusion(this._classInfo);
/* 444 */       if (incl != null) {
/* 445 */         return (defValue == null) ? incl : defValue.withOverrides(incl);
/*     */       }
/*     */     } 
/* 448 */     return defValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedMember findAnyGetter() throws IllegalArgumentException {
/* 460 */     if (this._propCollector != null) {
/* 461 */       AnnotatedMember anyGetter = this._propCollector.getAnyGetterMethod();
/* 462 */       if (anyGetter != null) {
/*     */ 
/*     */         
/* 465 */         Class<?> type = anyGetter.getRawType();
/* 466 */         if (!Map.class.isAssignableFrom(type)) {
/* 467 */           throw new IllegalArgumentException(String.format("Invalid 'any-getter' annotation on method %s(): return type is not instance of java.util.Map", new Object[] { anyGetter
/*     */                   
/* 469 */                   .getName() }));
/*     */         }
/* 471 */         return anyGetter;
/*     */       } 
/*     */       
/* 474 */       AnnotatedMember anyField = this._propCollector.getAnyGetterField();
/* 475 */       if (anyField != null) {
/*     */ 
/*     */         
/* 478 */         Class<?> type = anyField.getRawType();
/* 479 */         if (!Map.class.isAssignableFrom(type)) {
/* 480 */           throw new IllegalArgumentException(String.format("Invalid 'any-getter' annotation on field '%s': type is not instance of java.util.Map", new Object[] { anyField
/*     */                   
/* 482 */                   .getName() }));
/*     */         }
/* 484 */         return anyField;
/*     */       } 
/*     */     } 
/* 487 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<BeanPropertyDefinition> findBackReferences() {
/* 493 */     List<BeanPropertyDefinition> result = null;
/* 494 */     HashSet<String> names = null;
/* 495 */     for (BeanPropertyDefinition property : _properties()) {
/* 496 */       AnnotationIntrospector.ReferenceProperty refDef = property.findReferenceType();
/* 497 */       if (refDef == null || !refDef.isBackReference()) {
/*     */         continue;
/*     */       }
/* 500 */       String refName = refDef.getName();
/* 501 */       if (result == null) {
/* 502 */         result = new ArrayList<>();
/* 503 */         names = new HashSet<>();
/* 504 */         names.add(refName);
/*     */       }
/* 506 */       else if (!names.add(refName)) {
/* 507 */         throw new IllegalArgumentException("Multiple back-reference properties with name " + ClassUtil.name(refName));
/*     */       } 
/*     */       
/* 510 */       result.add(property);
/*     */     } 
/* 512 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotatedMethod> getFactoryMethods() {
/* 525 */     List<AnnotatedMethod> candidates = this._classInfo.getFactoryMethods();
/* 526 */     if (candidates.isEmpty()) {
/* 527 */       return candidates;
/*     */     }
/* 529 */     List<AnnotatedMethod> result = null;
/* 530 */     for (AnnotatedMethod am : candidates) {
/* 531 */       if (isFactoryMethod(am)) {
/* 532 */         if (result == null) {
/* 533 */           result = new ArrayList<>();
/*     */         }
/* 535 */         result.add(am);
/*     */       } 
/*     */     } 
/* 538 */     if (result == null) {
/* 539 */       return Collections.emptyList();
/*     */     }
/* 541 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<AnnotatedAndMetadata<AnnotatedMethod, JsonCreator.Mode>> getFactoryMethodsWithMode() {
/* 547 */     List<AnnotatedMethod> candidates = this._classInfo.getFactoryMethods();
/* 548 */     if (candidates.isEmpty()) {
/* 549 */       return Collections.emptyList();
/*     */     }
/* 551 */     List<AnnotatedAndMetadata<AnnotatedMethod, JsonCreator.Mode>> result = null;
/* 552 */     for (AnnotatedMethod am : candidates) {
/*     */       
/* 554 */       AnnotatedAndMetadata<AnnotatedMethod, JsonCreator.Mode> match = findFactoryMethodMetadata(am);
/* 555 */       if (match != null) {
/* 556 */         if (result == null) {
/* 557 */           result = new ArrayList<>();
/*     */         }
/* 559 */         result.add(match);
/*     */       } 
/*     */     } 
/* 562 */     if (result == null) {
/* 563 */       return Collections.emptyList();
/*     */     }
/* 565 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isFactoryMethod(AnnotatedMethod am) {
/* 572 */     Class<?> rt = am.getRawReturnType();
/* 573 */     if (!getBeanClass().isAssignableFrom(rt)) {
/* 574 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 581 */     JsonCreator.Mode mode = this._annotationIntrospector.findCreatorAnnotation(this._config, am);
/* 582 */     if (mode != null && mode != JsonCreator.Mode.DISABLED) {
/* 583 */       return true;
/*     */     }
/* 585 */     String name = am.getName();
/*     */     
/* 587 */     if ("valueOf".equals(name) && 
/* 588 */       am.getParameterCount() == 1) {
/* 589 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 593 */     if ("fromString".equals(name) && 
/* 594 */       am.getParameterCount() == 1) {
/* 595 */       Class<?> cls = am.getRawParameterType(0);
/* 596 */       if (cls == String.class || CharSequence.class.isAssignableFrom(cls)) {
/* 597 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 601 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotatedAndMetadata<AnnotatedMethod, JsonCreator.Mode> findFactoryMethodMetadata(AnnotatedMethod am) {
/* 609 */     Class<?> rt = am.getRawReturnType();
/* 610 */     if (!getBeanClass().isAssignableFrom(rt)) {
/* 611 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 617 */     JsonCreator.Mode mode = this._annotationIntrospector.findCreatorAnnotation(this._config, am);
/* 618 */     if (mode != null) {
/* 619 */       if (mode == JsonCreator.Mode.DISABLED) {
/* 620 */         return null;
/*     */       }
/* 622 */       return AnnotatedAndMetadata.of(am, mode);
/*     */     } 
/* 624 */     String name = am.getName();
/*     */     
/* 626 */     if ("valueOf".equals(name) && 
/* 627 */       am.getParameterCount() == 1) {
/* 628 */       return AnnotatedAndMetadata.of(am, mode);
/*     */     }
/*     */ 
/*     */     
/* 632 */     if ("fromString".equals(name) && 
/* 633 */       am.getParameterCount() == 1) {
/* 634 */       Class<?> cls = am.getRawParameterType(0);
/* 635 */       if (cls == String.class || CharSequence.class.isAssignableFrom(cls)) {
/* 636 */         return AnnotatedAndMetadata.of(am, mode);
/*     */       }
/*     */     } 
/*     */     
/* 640 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> findPOJOBuilder() {
/* 651 */     return (this._annotationIntrospector == null) ? null : this._annotationIntrospector
/* 652 */       .findPOJOBuilder(this._classInfo);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPOJOBuilder.Value findPOJOBuilderConfig() {
/* 658 */     return (this._annotationIntrospector == null) ? null : this._annotationIntrospector
/* 659 */       .findPOJOBuilderConfig(this._classInfo);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Converter<Object, Object> findDeserializationConverter() {
/* 665 */     if (this._annotationIntrospector == null) {
/* 666 */       return null;
/*     */     }
/* 668 */     return _createConverter(this._annotationIntrospector.findDeserializationConverter(this._classInfo));
/*     */   }
/*     */ 
/*     */   
/*     */   public String findClassDescription() {
/* 673 */     return (this._annotationIntrospector == null) ? null : this._annotationIntrospector
/* 674 */       .findClassDescription(this._classInfo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Converter<Object, Object> _createConverter(Object converterDef) {
/* 686 */     if (converterDef == null) {
/* 687 */       return null;
/*     */     }
/* 689 */     if (converterDef instanceof Converter) {
/* 690 */       return (Converter<Object, Object>)converterDef;
/*     */     }
/* 692 */     if (!(converterDef instanceof Class)) {
/* 693 */       throw new IllegalStateException("AnnotationIntrospector returned Converter definition of type " + converterDef
/* 694 */           .getClass().getName() + "; expected type Converter or Class<Converter> instead");
/*     */     }
/* 696 */     Class<?> converterClass = (Class)converterDef;
/*     */     
/* 698 */     if (converterClass == Converter.None.class || ClassUtil.isBogusClass(converterClass)) {
/* 699 */       return null;
/*     */     }
/* 701 */     if (!Converter.class.isAssignableFrom(converterClass)) {
/* 702 */       throw new IllegalStateException("AnnotationIntrospector returned Class " + converterClass
/* 703 */           .getName() + "; expected Class<Converter>");
/*     */     }
/* 705 */     HandlerInstantiator hi = this._config.getHandlerInstantiator();
/* 706 */     Converter<?, ?> conv = (hi == null) ? null : hi.converterInstance(this._config, this._classInfo, converterClass);
/* 707 */     if (conv == null) {
/* 708 */       conv = (Converter<?, ?>)ClassUtil.createInstance(converterClass, this._config
/* 709 */           .canOverrideAccessModifiers());
/*     */     }
/* 711 */     return (Converter)conv;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\BasicBeanDescription.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */