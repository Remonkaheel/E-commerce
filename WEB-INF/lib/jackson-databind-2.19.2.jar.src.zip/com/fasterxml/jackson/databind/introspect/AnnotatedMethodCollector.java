/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotatedMethodCollector
/*     */   extends CollectorBase
/*     */ {
/*     */   private final ClassIntrospector.MixInResolver _mixInResolver;
/*     */   private final boolean _collectAnnotations;
/*     */   
/*     */   AnnotatedMethodCollector(AnnotationIntrospector intr, ClassIntrospector.MixInResolver mixins, boolean collectAnnotations) {
/*  27 */     super(intr);
/*  28 */     this._mixInResolver = (intr == null) ? null : mixins;
/*  29 */     this._collectAnnotations = collectAnnotations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AnnotatedMethodMap collectMethods(AnnotationIntrospector intr, TypeResolutionContext tc, ClassIntrospector.MixInResolver mixins, TypeFactory types, JavaType type, List<JavaType> superTypes, Class<?> primaryMixIn, boolean collectAnnotations) {
/*  39 */     return (new AnnotatedMethodCollector(intr, mixins, collectAnnotations))
/*  40 */       .collect(types, tc, type, superTypes, primaryMixIn);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   AnnotatedMethodMap collect(TypeFactory typeFactory, TypeResolutionContext tc, JavaType mainType, List<JavaType> superTypes, Class<?> primaryMixIn) {
/*  46 */     Map<MemberKey, MethodBuilder> methods = new LinkedHashMap<>();
/*     */ 
/*     */     
/*  49 */     _addMemberMethods(tc, mainType.getRawClass(), methods, primaryMixIn);
/*     */ 
/*     */     
/*  52 */     for (JavaType type : superTypes) {
/*  53 */       Class<?> mixin = (this._mixInResolver == null) ? null : this._mixInResolver.findMixInClassFor(type.getRawClass());
/*  54 */       _addMemberMethods(new TypeResolutionContext.Basic(typeFactory, type
/*  55 */             .getBindings()), type
/*  56 */           .getRawClass(), methods, mixin);
/*     */     } 
/*     */     
/*  59 */     boolean checkJavaLangObject = false;
/*  60 */     if (this._mixInResolver != null) {
/*  61 */       Class<?> mixin = this._mixInResolver.findMixInClassFor(Object.class);
/*  62 */       if (mixin != null) {
/*  63 */         _addMethodMixIns(tc, mainType.getRawClass(), methods, mixin);
/*  64 */         checkJavaLangObject = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     if (checkJavaLangObject && this._intr != null && !methods.isEmpty())
/*     */     {
/*  74 */       for (Map.Entry<MemberKey, MethodBuilder> entry : methods.entrySet()) {
/*  75 */         MemberKey k = entry.getKey();
/*  76 */         if (!"hashCode".equals(k.getName()) || 0 != k.argCount()) {
/*     */           continue;
/*     */         }
/*     */         
/*     */         try {
/*  81 */           Method m = Object.class.getDeclaredMethod(k.getName(), new Class[0]);
/*  82 */           MethodBuilder b = entry.getValue();
/*  83 */           b.annotations = collectDefaultAnnotations(b.annotations, m
/*  84 */               .getDeclaredAnnotations());
/*  85 */           b.method = m;
/*  86 */         } catch (Exception exception) {}
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*  91 */     if (methods.isEmpty()) {
/*  92 */       return new AnnotatedMethodMap();
/*     */     }
/*  94 */     Map<MemberKey, AnnotatedMethod> actual = new LinkedHashMap<>(methods.size());
/*  95 */     for (Map.Entry<MemberKey, MethodBuilder> entry : methods.entrySet()) {
/*  96 */       AnnotatedMethod am = ((MethodBuilder)entry.getValue()).build();
/*  97 */       if (am != null) {
/*  98 */         actual.put(entry.getKey(), am);
/*     */       }
/*     */     } 
/* 101 */     return new AnnotatedMethodMap(actual);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _addMemberMethods(TypeResolutionContext tc, Class<?> cls, Map<MemberKey, MethodBuilder> methods, Class<?> mixInCls) {
/* 108 */     if (mixInCls != null) {
/* 109 */       _addMethodMixIns(tc, cls, methods, mixInCls);
/*     */     }
/* 111 */     if (cls == null) {
/*     */       return;
/*     */     }
/*     */     
/* 115 */     for (Method m : ClassUtil.getClassMethods(cls)) {
/* 116 */       if (_isIncludableMemberMethod(m)) {
/*     */ 
/*     */         
/* 119 */         MemberKey key = new MemberKey(m);
/* 120 */         MethodBuilder b = methods.get(key);
/* 121 */         if (b == null) {
/*     */           
/* 123 */           AnnotationCollector c = (this._intr == null) ? AnnotationCollector.emptyCollector() : collectAnnotations(m.getDeclaredAnnotations());
/* 124 */           methods.put(key, new MethodBuilder(tc, m, c));
/*     */         } else {
/* 126 */           if (this._collectAnnotations) {
/* 127 */             b.annotations = collectDefaultAnnotations(b.annotations, m.getDeclaredAnnotations());
/*     */           }
/* 129 */           Method old = b.method;
/* 130 */           if (old == null) {
/* 131 */             b.method = m;
/*     */           }
/* 133 */           else if (Modifier.isAbstract(old.getModifiers()) && 
/* 134 */             !Modifier.isAbstract(m.getModifiers())) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 141 */             b.method = m;
/*     */ 
/*     */             
/* 144 */             b.typeContext = tc;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _addMethodMixIns(TypeResolutionContext tc, Class<?> targetClass, Map<MemberKey, MethodBuilder> methods, Class<?> mixInCls) {
/* 153 */     if (this._intr == null) {
/*     */       return;
/*     */     }
/* 156 */     for (Class<?> mixin : (Iterable<Class<?>>)ClassUtil.findRawSuperTypes(mixInCls, targetClass, true)) {
/* 157 */       for (Method m : mixin.getDeclaredMethods()) {
/* 158 */         if (_isIncludableMemberMethod(m)) {
/*     */ 
/*     */           
/* 161 */           MemberKey key = new MemberKey(m);
/* 162 */           MethodBuilder b = methods.get(key);
/* 163 */           Annotation[] anns = m.getDeclaredAnnotations();
/* 164 */           if (b == null) {
/*     */ 
/*     */             
/* 167 */             methods.put(key, new MethodBuilder(tc, null, collectAnnotations(anns)));
/*     */           } else {
/* 169 */             b.annotations = collectDefaultAnnotations(b.annotations, anns);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean _isIncludableMemberMethod(Method m) {
/* 177 */     if (Modifier.isStatic(m.getModifiers()) || m
/*     */ 
/*     */       
/* 180 */       .isSynthetic() || m.isBridge()) {
/* 181 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 185 */     return (m.getParameterCount() <= 2);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class MethodBuilder
/*     */   {
/*     */     public TypeResolutionContext typeContext;
/*     */     
/*     */     public Method method;
/*     */     public AnnotationCollector annotations;
/*     */     
/*     */     public MethodBuilder(TypeResolutionContext tc, Method m, AnnotationCollector ann) {
/* 197 */       this.typeContext = tc;
/* 198 */       this.method = m;
/* 199 */       this.annotations = ann;
/*     */     }
/*     */     
/*     */     public AnnotatedMethod build() {
/* 203 */       if (this.method == null) {
/* 204 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 208 */       return new AnnotatedMethod(this.typeContext, this.method, this.annotations.asAnnotationMap(), null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\AnnotatedMethodCollector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */