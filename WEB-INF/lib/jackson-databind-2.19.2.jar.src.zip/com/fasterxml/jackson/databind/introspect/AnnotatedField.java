/*     */ package com.fasterxml.jackson.databind.introspect;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AnnotatedField
/*     */   extends AnnotatedMember
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final transient Field _field;
/*     */   protected Serialization _serialization;
/*     */   
/*     */   public AnnotatedField(TypeResolutionContext contextClass, Field field, AnnotationMap annMap) {
/*  40 */     super(contextClass, annMap);
/*  41 */     this._field = Objects.<Field>requireNonNull(field);
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedField withAnnotations(AnnotationMap ann) {
/*  46 */     return new AnnotatedField(this._typeContext, this._field, ann);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotatedField(Serialization ser) {
/*  54 */     super(null, null);
/*  55 */     this._field = null;
/*  56 */     this._serialization = ser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Field getAnnotated() {
/*  66 */     return this._field;
/*     */   }
/*     */   public int getModifiers() {
/*  69 */     return this._field.getModifiers();
/*     */   }
/*     */   public String getName() {
/*  72 */     return this._field.getName();
/*     */   }
/*     */   
/*     */   public Class<?> getRawType() {
/*  76 */     return this._field.getType();
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType getType() {
/*  81 */     return this._typeContext.resolveType(this._field.getGenericType());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getDeclaringClass() {
/*  91 */     return this._field.getDeclaringClass();
/*     */   }
/*     */   public Member getMember() {
/*  94 */     return this._field;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(Object pojo, Object value) throws IllegalArgumentException {
/*     */     try {
/* 100 */       this._field.set(pojo, value);
/* 101 */     } catch (IllegalAccessException e) {
/* 102 */       throw new IllegalArgumentException("Failed to setValue() for field " + 
/* 103 */           getFullName() + ": " + e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(Object pojo) throws IllegalArgumentException {
/*     */     try {
/* 111 */       return this._field.get(pojo);
/* 112 */     } catch (IllegalAccessException e) {
/* 113 */       throw new IllegalArgumentException("Failed to getValue() for field " + 
/* 114 */           getFullName() + ": " + e.getMessage(), e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnnotationCount() {
/* 124 */     return this._annotations.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isTransient() {
/* 129 */     return Modifier.isTransient(getModifiers());
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 133 */     return Objects.hashCode(this._field);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 138 */     if (o == this) return true; 
/* 139 */     if (!ClassUtil.hasClass(o, getClass())) {
/* 140 */       return false;
/*     */     }
/* 142 */     AnnotatedField other = (AnnotatedField)o;
/* 143 */     return Objects.equals(this._field, other._field);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 148 */     return "[field " + getFullName() + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object writeReplace() {
/* 158 */     return new AnnotatedField(new Serialization(this._field));
/*     */   }
/*     */   
/*     */   Object readResolve() {
/* 162 */     Class<?> clazz = this._serialization.clazz;
/*     */     try {
/* 164 */       Field f = clazz.getDeclaredField(this._serialization.name);
/*     */       
/* 166 */       if (!f.isAccessible()) {
/* 167 */         ClassUtil.checkAndFixAccess(f, false);
/*     */       }
/* 169 */       return new AnnotatedField(null, f, null);
/* 170 */     } catch (Exception e) {
/* 171 */       throw new IllegalArgumentException("Could not find method '" + this._serialization.name + "' from Class '" + clazz
/* 172 */           .getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Serialization
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     protected Class<?> clazz;
/*     */     
/*     */     protected String name;
/*     */ 
/*     */     
/*     */     public Serialization(Field f) {
/* 189 */       this.clazz = f.getDeclaringClass();
/* 190 */       this.name = f.getName();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\AnnotatedField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */