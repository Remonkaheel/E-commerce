/*      */ package com.fasterxml.jackson.databind.introspect;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JacksonInject;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonFormat;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.MapperFeature;
/*      */ import com.fasterxml.jackson.databind.PropertyName;
/*      */ import com.fasterxml.jackson.databind.PropertyNamingStrategy;
/*      */ import com.fasterxml.jackson.databind.cfg.ConstructorDetector;
/*      */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.deser.impl.UnwrappedPropertyHandler;
/*      */ import com.fasterxml.jackson.databind.jdk14.JDK14Util;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class POJOPropertiesCollector
/*      */ {
/*      */   protected final MapperConfig<?> _config;
/*      */   protected final AccessorNamingStrategy _accessorNaming;
/*      */   protected final boolean _forSerialization;
/*      */   protected final JavaType _type;
/*      */   protected final AnnotatedClass _classDef;
/*      */   protected final VisibilityChecker<?> _visibilityChecker;
/*      */   protected final AnnotationIntrospector _annotationIntrospector;
/*      */   protected final boolean _useAnnotations;
/*      */   protected final boolean _isRecordType;
/*      */   protected boolean _collected;
/*      */   protected LinkedHashMap<String, POJOPropertyBuilder> _properties;
/*      */   protected List<POJOPropertyBuilder> _creatorProperties;
/*      */   protected PotentialCreators _potentialCreators;
/*      */   protected Map<PropertyName, PropertyName> _fieldRenameMappings;
/*      */   protected LinkedList<AnnotatedMember> _anyGetters;
/*      */   protected LinkedList<AnnotatedMember> _anyGetterField;
/*      */   protected LinkedList<AnnotatedMethod> _anySetters;
/*      */   protected LinkedList<AnnotatedMember> _anySetterField;
/*      */   protected LinkedList<AnnotatedMember> _jsonKeyAccessors;
/*      */   protected LinkedList<AnnotatedMember> _jsonValueAccessors;
/*      */   protected HashSet<String> _ignoredPropertyNames;
/*      */   protected LinkedHashMap<Object, AnnotatedMember> _injectables;
/*      */   protected JsonFormat.Value _formatOverrides;
/*      */   
/*      */   protected POJOPropertiesCollector(MapperConfig<?> config, boolean forSerialization, JavaType type, AnnotatedClass classDef, AccessorNamingStrategy accessorNaming) {
/*  175 */     this._config = config;
/*  176 */     this._forSerialization = forSerialization;
/*  177 */     this._type = type;
/*  178 */     this._classDef = classDef;
/*  179 */     this._isRecordType = this._type.isRecordType();
/*  180 */     if (config.isAnnotationProcessingEnabled()) {
/*  181 */       this._useAnnotations = true;
/*  182 */       this._annotationIntrospector = this._config.getAnnotationIntrospector();
/*      */     } else {
/*  184 */       this._useAnnotations = false;
/*  185 */       this._annotationIntrospector = AnnotationIntrospector.nopInstance();
/*      */     } 
/*  187 */     this._visibilityChecker = this._config.getDefaultVisibilityChecker(type.getRawClass(), classDef);
/*      */     
/*  189 */     this._accessorNaming = accessorNaming;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapperConfig<?> getConfig() {
/*  199 */     return this._config;
/*      */   }
/*      */   
/*      */   public JavaType getType() {
/*  203 */     return this._type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRecordType() {
/*  210 */     return this._isRecordType;
/*      */   }
/*      */   
/*      */   public AnnotatedClass getClassDef() {
/*  214 */     return this._classDef;
/*      */   }
/*      */   
/*      */   public AnnotationIntrospector getAnnotationIntrospector() {
/*  218 */     return this._annotationIntrospector;
/*      */   }
/*      */ 
/*      */   
/*      */   public List<BeanPropertyDefinition> getProperties() {
/*  223 */     Map<String, POJOPropertyBuilder> props = getPropertyMap();
/*  224 */     return new ArrayList<>(props.values());
/*      */   }
/*      */ 
/*      */   
/*      */   public PotentialCreators getPotentialCreators() {
/*  229 */     if (!this._collected) {
/*  230 */       collectAll();
/*      */     }
/*  232 */     return this._potentialCreators;
/*      */   }
/*      */   
/*      */   public Map<Object, AnnotatedMember> getInjectables() {
/*  236 */     if (!this._collected) {
/*  237 */       collectAll();
/*      */     }
/*  239 */     return this._injectables;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotatedMember getJsonKeyAccessor() {
/*  246 */     if (!this._collected) {
/*  247 */       collectAll();
/*      */     }
/*      */     
/*  250 */     if (this._jsonKeyAccessors != null) {
/*  251 */       if (this._jsonKeyAccessors.size() > 1 && 
/*  252 */         !_resolveFieldVsGetter(this._jsonKeyAccessors)) {
/*  253 */         reportProblem("Multiple 'as-key' properties defined (%s vs %s)", new Object[] { this._jsonKeyAccessors
/*  254 */               .get(0), this._jsonKeyAccessors
/*  255 */               .get(1) });
/*      */       }
/*      */ 
/*      */       
/*  259 */       return this._jsonKeyAccessors.get(0);
/*      */     } 
/*  261 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotatedMember getJsonValueAccessor() {
/*  269 */     if (!this._collected) {
/*  270 */       collectAll();
/*      */     }
/*      */ 
/*      */     
/*  274 */     if (this._jsonValueAccessors != null) {
/*  275 */       if (this._jsonValueAccessors.size() > 1 && 
/*  276 */         !_resolveFieldVsGetter(this._jsonValueAccessors)) {
/*  277 */         reportProblem("Multiple 'as-value' properties defined (%s vs %s)", new Object[] { this._jsonValueAccessors
/*  278 */               .get(0), this._jsonValueAccessors
/*  279 */               .get(1) });
/*      */       }
/*      */ 
/*      */       
/*  283 */       return this._jsonValueAccessors.get(0);
/*      */     } 
/*  285 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public AnnotatedMember getAnyGetter() {
/*  296 */     return getAnyGetterMethod();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotatedMember getAnyGetterField() {
/*  304 */     if (!this._collected) {
/*  305 */       collectAll();
/*      */     }
/*  307 */     if (this._anyGetterField != null) {
/*  308 */       if (this._anyGetterField.size() > 1) {
/*  309 */         reportProblem("Multiple 'any-getter' fields defined (%s vs %s)", new Object[] { this._anyGetterField
/*  310 */               .get(0), this._anyGetterField.get(1) });
/*      */       }
/*  312 */       return this._anyGetterField.getFirst();
/*      */     } 
/*  314 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotatedMember getAnyGetterMethod() {
/*  322 */     if (!this._collected) {
/*  323 */       collectAll();
/*      */     }
/*  325 */     if (this._anyGetters != null) {
/*  326 */       if (this._anyGetters.size() > 1) {
/*  327 */         reportProblem("Multiple 'any-getter' methods defined (%s vs %s)", new Object[] { this._anyGetters
/*  328 */               .get(0), this._anyGetters.get(1) });
/*      */       }
/*  330 */       return this._anyGetters.getFirst();
/*      */     } 
/*  332 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public AnnotatedMember getAnySetterField() {
/*  337 */     if (!this._collected) {
/*  338 */       collectAll();
/*      */     }
/*  340 */     if (this._anySetterField != null) {
/*  341 */       if (this._anySetterField.size() > 1) {
/*  342 */         reportProblem("Multiple 'any-setter' fields defined (%s vs %s)", new Object[] { this._anySetterField
/*  343 */               .get(0), this._anySetterField.get(1) });
/*      */       }
/*  345 */       return this._anySetterField.getFirst();
/*      */     } 
/*  347 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public AnnotatedMethod getAnySetterMethod() {
/*  352 */     if (!this._collected) {
/*  353 */       collectAll();
/*      */     }
/*  355 */     if (this._anySetters != null) {
/*  356 */       if (this._anySetters.size() > 1) {
/*  357 */         reportProblem("Multiple 'any-setter' methods defined (%s vs %s)", new Object[] { this._anySetters
/*  358 */               .get(0), this._anySetters.get(1) });
/*      */       }
/*  360 */       return this._anySetters.getFirst();
/*      */     } 
/*  362 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> getIgnoredPropertyNames() {
/*  370 */     return this._ignoredPropertyNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectIdInfo getObjectIdInfo() {
/*  379 */     ObjectIdInfo info = this._annotationIntrospector.findObjectIdInfo(this._classDef);
/*  380 */     if (info != null) {
/*  381 */       info = this._annotationIntrospector.findObjectReferenceInfo(this._classDef, info);
/*      */     }
/*  383 */     return info;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<String, POJOPropertyBuilder> getPropertyMap() {
/*  389 */     if (!this._collected) {
/*  390 */       collectAll();
/*      */     }
/*  392 */     return this._properties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFormat.Value getFormatOverrides() {
/*  399 */     if (this._formatOverrides == null) {
/*  400 */       JsonFormat.Value format = null;
/*      */ 
/*      */ 
/*      */       
/*  404 */       if (this._annotationIntrospector != null) {
/*  405 */         format = this._annotationIntrospector.findFormat(this._classDef);
/*      */       }
/*  407 */       JsonFormat.Value v = this._config.getDefaultPropertyFormat(this._type.getRawClass());
/*  408 */       if (v != null) {
/*  409 */         if (format == null) {
/*  410 */           format = v;
/*      */         } else {
/*  412 */           format = format.withOverrides(v);
/*      */         } 
/*      */       }
/*  415 */       this._formatOverrides = (format == null) ? JsonFormat.Value.empty() : format;
/*      */     } 
/*  417 */     return this._formatOverrides;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void collectAll() {
/*  433 */     this._potentialCreators = new PotentialCreators();
/*      */ 
/*      */     
/*  436 */     LinkedHashMap<String, POJOPropertyBuilder> props = new LinkedHashMap<>();
/*      */ 
/*      */ 
/*      */     
/*  440 */     _addFields(props);
/*      */     
/*  442 */     _addMethods(props);
/*      */ 
/*      */ 
/*      */     
/*  446 */     if (!this._classDef.isNonStaticInnerClass()) {
/*  447 */       _addCreators(props);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  452 */     _removeUnwantedProperties(props);
/*      */     
/*  454 */     _removeUnwantedAccessors(props);
/*      */ 
/*      */     
/*  457 */     _renameProperties(props);
/*      */ 
/*      */ 
/*      */     
/*  461 */     _addInjectables(props);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  466 */     for (POJOPropertyBuilder property : props.values()) {
/*  467 */       property.mergeAnnotations(this._forSerialization);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  473 */     PropertyNamingStrategy naming = _findNamingStrategy();
/*  474 */     if (naming != null) {
/*  475 */       _renameUsing(props, naming);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  480 */     for (POJOPropertyBuilder property : props.values()) {
/*  481 */       property.trimByVisibility();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  486 */     if (this._isRecordType && !this._forSerialization) {
/*  487 */       for (POJOPropertyBuilder property : props.values()) {
/*  488 */         property.removeFields();
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  494 */     if (this._config.isEnabled(MapperFeature.USE_WRAPPER_NAME_AS_PROPERTY_NAME)) {
/*  495 */       _renameWithWrappers(props);
/*      */     }
/*      */ 
/*      */     
/*  499 */     _sortProperties(props);
/*  500 */     this._properties = props;
/*  501 */     this._collected = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<String, POJOPropertyBuilder> _putAnyGettersInTheEnd(Map<String, POJOPropertyBuilder> sortedProps) {
/*      */     AnnotatedMember anyAccessor;
/*  513 */     if (this._anyGetters != null) {
/*  514 */       anyAccessor = this._anyGetters.getFirst();
/*  515 */     } else if (this._anyGetterField != null) {
/*  516 */       anyAccessor = this._anyGetterField.getFirst();
/*      */     } else {
/*  518 */       return sortedProps;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  523 */     Map<String, POJOPropertyBuilder> newAll = new LinkedHashMap<>(sortedProps.size() * 2);
/*  524 */     POJOPropertyBuilder anyGetterProp = null;
/*  525 */     for (POJOPropertyBuilder prop : sortedProps.values()) {
/*  526 */       if (prop.hasFieldOrGetter(anyAccessor)) {
/*  527 */         anyGetterProp = prop; continue;
/*      */       } 
/*  529 */       newAll.put(prop.getName(), prop);
/*      */     } 
/*      */     
/*  532 */     if (anyGetterProp != null) {
/*  533 */       newAll.put(anyGetterProp.getName(), anyGetterProp);
/*      */     }
/*  535 */     return newAll;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _addFields(Map<String, POJOPropertyBuilder> props) {
/*  549 */     AnnotationIntrospector ai = this._annotationIntrospector;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  554 */     boolean pruneFinalFields = (!this._forSerialization && !this._config.isEnabled(MapperFeature.ALLOW_FINAL_FIELDS_AS_MUTATORS));
/*  555 */     boolean transientAsIgnoral = this._config.isEnabled(MapperFeature.PROPAGATE_TRANSIENT_MARKER);
/*      */     
/*  557 */     for (AnnotatedField f : this._classDef.fields()) {
/*      */       PropertyName pn;
/*  559 */       if (Boolean.TRUE.equals(ai.hasAsKey(this._config, f))) {
/*  560 */         if (this._jsonKeyAccessors == null) {
/*  561 */           this._jsonKeyAccessors = new LinkedList<>();
/*      */         }
/*  563 */         this._jsonKeyAccessors.add(f);
/*      */       } 
/*      */       
/*  566 */       if (Boolean.TRUE.equals(ai.hasAsValue(f))) {
/*  567 */         if (this._jsonValueAccessors == null) {
/*  568 */           this._jsonValueAccessors = new LinkedList<>();
/*      */         }
/*  570 */         this._jsonValueAccessors.add(f);
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  575 */       boolean anyGetter = Boolean.TRUE.equals(ai.hasAnyGetter(f));
/*  576 */       boolean anySetter = Boolean.TRUE.equals(ai.hasAnySetter(f));
/*  577 */       if (anyGetter || anySetter) {
/*      */         
/*  579 */         if (anyGetter) {
/*  580 */           if (this._anyGetterField == null) {
/*  581 */             this._anyGetterField = new LinkedList<>();
/*      */           }
/*  583 */           this._anyGetterField.add(f);
/*      */         } 
/*      */         
/*  586 */         if (anySetter) {
/*  587 */           if (this._anySetterField == null) {
/*  588 */             this._anySetterField = new LinkedList<>();
/*      */           }
/*  590 */           this._anySetterField.add(f);
/*      */           
/*      */           continue;
/*      */         } 
/*      */       } 
/*      */       
/*  596 */       String implName = ai.findImplicitPropertyName(f);
/*  597 */       if (implName == null) {
/*  598 */         implName = f.getName();
/*      */       }
/*      */ 
/*      */       
/*  602 */       implName = this._accessorNaming.modifyFieldName(f, implName);
/*  603 */       if (implName == null) {
/*      */         continue;
/*      */       }
/*      */       
/*  607 */       PropertyName implNameP = _propNameFromSimple(implName);
/*      */ 
/*      */ 
/*      */       
/*  611 */       PropertyName rename = ai.findRenameByField(this._config, f, implNameP);
/*  612 */       if (rename != null && !rename.equals(implNameP)) {
/*  613 */         if (this._fieldRenameMappings == null) {
/*  614 */           this._fieldRenameMappings = new HashMap<>();
/*      */         }
/*  616 */         this._fieldRenameMappings.put(rename, implNameP);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  621 */       if (this._forSerialization) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  626 */         pn = ai.findNameForSerialization(f);
/*      */       } else {
/*  628 */         pn = ai.findNameForDeserialization(f);
/*      */       } 
/*  630 */       boolean hasName = (pn != null);
/*  631 */       boolean nameExplicit = hasName;
/*      */       
/*  633 */       if (nameExplicit && pn.isEmpty()) {
/*  634 */         pn = _propNameFromSimple(implName);
/*  635 */         nameExplicit = false;
/*      */       } 
/*      */       
/*  638 */       boolean visible = (pn != null);
/*  639 */       if (!visible) {
/*  640 */         visible = this._visibilityChecker.isFieldVisible(f);
/*      */       }
/*      */       
/*  643 */       boolean ignored = ai.hasIgnoreMarker(f);
/*      */ 
/*      */       
/*  646 */       if (f.isTransient())
/*      */       {
/*      */         
/*  649 */         if (!hasName)
/*      */         {
/*      */           
/*  652 */           if (transientAsIgnoral) {
/*  653 */             ignored = true;
/*      */ 
/*      */           
/*      */           }
/*  657 */           else if (!ignored) {
/*      */             continue;
/*      */           } 
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  667 */       if (pruneFinalFields && pn == null && !ignored && 
/*  668 */         Modifier.isFinal(f.getModifiers())) {
/*      */         continue;
/*      */       }
/*  671 */       _property(props, implName).addField(f, pn, nameExplicit, visible, ignored);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _addCreators(Map<String, POJOPropertyBuilder> props) {
/*      */     PotentialCreator primaryCreator;
/*  684 */     PotentialCreators creators = this._potentialCreators;
/*      */ 
/*      */ 
/*      */     
/*  688 */     List<PotentialCreator> constructors = _collectCreators((List)this._classDef.getConstructors());
/*  689 */     List<PotentialCreator> factories = _collectCreators((List)this._classDef.getFactoryMethods());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  695 */     if (this._isRecordType) {
/*  696 */       primaryCreator = JDK14Util.findCanonicalRecordConstructor(this._config, this._classDef, constructors);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  701 */       primaryCreator = this._annotationIntrospector.findDefaultCreator(this._config, this._classDef, constructors, factories);
/*      */     } 
/*      */ 
/*      */     
/*  705 */     _removeDisabledCreators(constructors);
/*  706 */     _removeDisabledCreators(factories);
/*      */ 
/*      */     
/*  709 */     _removeNonFactoryStaticMethods(factories, primaryCreator);
/*      */ 
/*      */     
/*  712 */     if (this._useAnnotations) {
/*      */       
/*  714 */       _addExplicitlyAnnotatedCreators(creators, constructors, props, false);
/*      */       
/*  716 */       _addExplicitlyAnnotatedCreators(creators, factories, props, creators
/*  717 */           .hasPropertiesBased());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  722 */     if (!creators.hasPropertiesBased())
/*      */     {
/*  724 */       _addCreatorsWithAnnotatedNames(creators, constructors, primaryCreator);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  729 */     if (primaryCreator != null)
/*      */     {
/*  731 */       if (constructors.remove(primaryCreator) || factories
/*  732 */         .remove(primaryCreator))
/*      */       {
/*  734 */         if (_isDelegatingConstructor(primaryCreator)) {
/*      */ 
/*      */           
/*  737 */           if (!creators.hasDelegating())
/*      */           {
/*  739 */             creators.addExplicitDelegating(primaryCreator);
/*      */           }
/*      */         }
/*  742 */         else if (!creators.hasPropertiesBased()) {
/*  743 */           creators.setPropertiesBased(this._config, primaryCreator, "Primary");
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  751 */     ConstructorDetector ctorDetector = this._config.getConstructorDetector();
/*  752 */     if (!creators.hasPropertiesBasedOrDelegating() && 
/*  753 */       !ctorDetector.requireCtorAnnotation())
/*      */     {
/*      */       
/*  756 */       if (this._classDef.getDefaultConstructor() == null || ctorDetector
/*  757 */         .singleArgCreatorDefaultsToProperties()) {
/*  758 */         _addImplicitConstructor(creators, constructors, props);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  764 */     _removeNonVisibleCreators(constructors);
/*  765 */     _removeNonVisibleCreators(factories);
/*  766 */     creators.setImplicitDelegating(constructors, factories);
/*      */ 
/*      */ 
/*      */     
/*  770 */     PotentialCreator propsCtor = creators.propertiesBased;
/*  771 */     if (propsCtor == null) {
/*  772 */       this._creatorProperties = Collections.emptyList();
/*      */     } else {
/*  774 */       this._creatorProperties = new ArrayList<>();
/*  775 */       _addCreatorParams(props, propsCtor, this._creatorProperties);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _isDelegatingConstructor(PotentialCreator ctor) {
/*  784 */     switch (ctor.creatorModeOrDefault()) {
/*      */       case DELEGATING:
/*  786 */         return true;
/*      */       case PROPERTIES:
/*      */       case REQUIRE_MODE:
/*  789 */         return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  794 */     if (ctor.paramCount() == 1)
/*      */     {
/*  796 */       if (this._jsonValueAccessors != null && !this._jsonValueAccessors.isEmpty()) {
/*  797 */         return true;
/*      */       }
/*      */     }
/*  800 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private List<PotentialCreator> _collectCreators(List<? extends AnnotatedWithParams> ctors) {
/*  805 */     if (ctors.isEmpty()) {
/*  806 */       return Collections.emptyList();
/*      */     }
/*  808 */     List<PotentialCreator> result = new ArrayList<>();
/*  809 */     for (AnnotatedWithParams ctor : ctors) {
/*      */       
/*  811 */       JsonCreator.Mode creatorMode = this._useAnnotations ? this._annotationIntrospector.findCreatorAnnotation(this._config, ctor) : null;
/*      */       
/*  813 */       result.add(new PotentialCreator(ctor, creatorMode));
/*      */     } 
/*  815 */     return (result == null) ? Collections.<PotentialCreator>emptyList() : result;
/*      */   }
/*      */ 
/*      */   
/*      */   private void _removeDisabledCreators(List<PotentialCreator> ctors) {
/*  820 */     Iterator<PotentialCreator> it = ctors.iterator();
/*  821 */     while (it.hasNext()) {
/*      */       
/*  823 */       if (((PotentialCreator)it.next()).creatorMode() == JsonCreator.Mode.DISABLED) {
/*  824 */         it.remove();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void _removeNonVisibleCreators(List<PotentialCreator> ctors) {
/*  831 */     Iterator<PotentialCreator> it = ctors.iterator();
/*  832 */     while (it.hasNext()) {
/*  833 */       PotentialCreator ctor = it.next();
/*  834 */       if (!this._visibilityChecker.isCreatorVisible(ctor.creator())) {
/*  835 */         it.remove();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _removeNonFactoryStaticMethods(List<PotentialCreator> ctors, PotentialCreator primaryCreator) {
/*  843 */     Class<?> rawType = this._type.getRawClass();
/*  844 */     Iterator<PotentialCreator> it = ctors.iterator();
/*  845 */     while (it.hasNext()) {
/*      */       
/*  847 */       PotentialCreator ctor = it.next();
/*  848 */       if (ctor.isAnnotated()) {
/*      */         continue;
/*      */       }
/*      */       
/*  852 */       if (primaryCreator == ctor) {
/*      */         continue;
/*      */       }
/*      */       
/*  856 */       AnnotatedWithParams factory = ctor.creator();
/*  857 */       if (rawType.isAssignableFrom(factory.getRawType()) && ctor
/*  858 */         .paramCount() == 1) {
/*  859 */         String name = factory.getName();
/*      */         
/*  861 */         if ("valueOf".equals(name))
/*      */           continue; 
/*  863 */         if ("fromString".equals(name)) {
/*  864 */           Class<?> cls = factory.getRawParameterType(0);
/*  865 */           if (cls == String.class || CharSequence.class.isAssignableFrom(cls)) {
/*      */             continue;
/*      */           }
/*      */         } 
/*      */       } 
/*  870 */       it.remove();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _addExplicitlyAnnotatedCreators(PotentialCreators collector, List<PotentialCreator> ctors, Map<String, POJOPropertyBuilder> props, boolean skipPropsBased) {
/*  879 */     ConstructorDetector ctorDetector = this._config.getConstructorDetector();
/*  880 */     Iterator<PotentialCreator> it = ctors.iterator();
/*  881 */     while (it.hasNext()) {
/*  882 */       boolean isPropsBased; PotentialCreator ctor = it.next();
/*      */ 
/*      */ 
/*      */       
/*  886 */       if (!ctor.isAnnotated()) {
/*      */         continue;
/*      */       }
/*      */       
/*  890 */       it.remove();
/*      */ 
/*      */ 
/*      */       
/*  894 */       switch (ctor.creatorMode()) {
/*      */         case DELEGATING:
/*  896 */           isPropsBased = false;
/*      */           break;
/*      */         case REQUIRE_MODE:
/*  899 */           isPropsBased = true;
/*      */           break;
/*      */         
/*      */         default:
/*  903 */           isPropsBased = _isExplicitlyAnnotatedCreatorPropsBased(ctor, props, ctorDetector);
/*      */           break;
/*      */       } 
/*      */       
/*  907 */       if (isPropsBased) {
/*      */         
/*  909 */         if (!skipPropsBased)
/*  910 */           collector.setPropertiesBased(this._config, ctor, "explicit"); 
/*      */         continue;
/*      */       } 
/*  913 */       collector.addExplicitDelegating(ctor);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _isExplicitlyAnnotatedCreatorPropsBased(PotentialCreator ctor, Map<String, POJOPropertyBuilder> props, ConstructorDetector ctorDetector) {
/*  921 */     if (ctor.paramCount() == 1)
/*      */     {
/*  923 */       switch (ctorDetector.singleArgMode()) {
/*      */         case DELEGATING:
/*  925 */           return false;
/*      */         case PROPERTIES:
/*  927 */           return true;
/*      */         case REQUIRE_MODE:
/*  929 */           throw new IllegalArgumentException(String.format("Single-argument constructor (%s) is annotated but no 'mode' defined; `ConstructorDetector`configured with `SingleArgConstructor.REQUIRE_MODE`", new Object[] { ctor
/*      */ 
/*      */                   
/*  932 */                   .creator() }));
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  939 */     ctor.introspectParamNames(this._config);
/*  940 */     if (ctor.hasExplicitNames()) {
/*  941 */       return true;
/*      */     }
/*      */     
/*  944 */     if (this._jsonValueAccessors != null && !this._jsonValueAccessors.isEmpty()) {
/*  945 */       return false;
/*      */     }
/*  947 */     if (ctor.paramCount() == 1) {
/*      */ 
/*      */       
/*  950 */       PropertyName paramName = ctor.implicitName(0);
/*  951 */       if (paramName != null) {
/*  952 */         POJOPropertyBuilder prop = props.get(paramName.getSimpleName());
/*  953 */         if (prop != null) {
/*  954 */           if (prop.anyVisible() && !prop.anyIgnorals()) {
/*  955 */             return true;
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/*  960 */           for (POJOPropertyBuilder pb : props.values()) {
/*  961 */             if (pb.anyVisible() && 
/*  962 */               !pb.anyIgnorals() && pb
/*  963 */               .hasExplicitName(paramName)) {
/*  964 */               return true;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  970 */       if (this._annotationIntrospector != null && this._annotationIntrospector
/*  971 */         .findInjectableValue(ctor.param(0)) != null) {
/*  972 */         return true;
/*      */       }
/*  974 */       return false;
/*      */     } 
/*      */     
/*  977 */     return ctor.hasNameOrInjectForAllParams(this._config);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _addCreatorsWithAnnotatedNames(PotentialCreators collector, List<PotentialCreator> ctors, PotentialCreator primaryCtor) {
/*  983 */     List<PotentialCreator> found = _findCreatorsWithAnnotatedNames(ctors);
/*      */ 
/*      */     
/*  986 */     if (primaryCtor != null && 
/*  987 */       found.contains(primaryCtor)) {
/*  988 */       collector.setPropertiesBased(this._config, primaryCtor, "implicit");
/*      */       
/*      */       return;
/*      */     } 
/*  992 */     for (PotentialCreator ctor : found) {
/*  993 */       collector.setPropertiesBased(this._config, ctor, "implicit");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private List<PotentialCreator> _findCreatorsWithAnnotatedNames(List<PotentialCreator> ctors) {
/*  999 */     List<PotentialCreator> found = null;
/* 1000 */     Iterator<PotentialCreator> it = ctors.iterator();
/* 1001 */     while (it.hasNext()) {
/* 1002 */       PotentialCreator ctor = it.next();
/*      */       
/* 1004 */       ctor.introspectParamNames(this._config);
/* 1005 */       if (!ctor.hasExplicitNames()) {
/*      */         continue;
/*      */       }
/* 1008 */       it.remove();
/* 1009 */       if (found == null) {
/* 1010 */         found = new ArrayList<>(4);
/*      */       }
/* 1012 */       found.add(ctor);
/*      */     } 
/* 1014 */     return (found == null) ? Collections.<PotentialCreator>emptyList() : found;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _addImplicitConstructor(PotentialCreators collector, List<PotentialCreator> ctors, Map<String, POJOPropertyBuilder> props) {
/* 1021 */     if (ctors.size() != 1) {
/* 1022 */       return false;
/*      */     }
/* 1024 */     PotentialCreator ctor = ctors.get(0);
/*      */     
/* 1026 */     if (!this._visibilityChecker.isCreatorVisible(ctor.creator())) {
/* 1027 */       return false;
/*      */     }
/* 1029 */     ctor.introspectParamNames(this._config);
/*      */ 
/*      */     
/* 1032 */     if (ctor.paramCount() != 1) {
/* 1033 */       if (!ctor.hasNameOrInjectForAllParams(this._config)) {
/* 1034 */         return false;
/*      */       
/*      */       }
/*      */     }
/* 1038 */     else if (this._annotationIntrospector == null || this._annotationIntrospector
/* 1039 */       .findInjectableValue(ctor.param(0)) == null) {
/*      */ 
/*      */ 
/*      */       
/* 1043 */       ConstructorDetector ctorDetector = this._config.getConstructorDetector();
/* 1044 */       if (ctorDetector.singleArgCreatorDefaultsToDelegating()) {
/* 1045 */         return false;
/*      */       }
/*      */ 
/*      */       
/* 1049 */       String implicitParamName = ctor.implicitNameSimple(0);
/* 1050 */       if (implicitParamName == null) {
/* 1051 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1056 */       if (!ctorDetector.singleArgCreatorDefaultsToProperties()) {
/* 1057 */         POJOPropertyBuilder prop = props.get(implicitParamName);
/* 1058 */         if (prop == null || !prop.anyVisible() || prop.anyIgnorals()) {
/* 1059 */           return false;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1065 */     ctors.remove(0);
/* 1066 */     collector.setPropertiesBased(this._config, ctor, "implicit");
/* 1067 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _addCreatorParams(Map<String, POJOPropertyBuilder> props, PotentialCreator ctor, List<POJOPropertyBuilder> creatorProps) {
/* 1073 */     int paramCount = ctor.paramCount();
/* 1074 */     for (int i = 0; i < paramCount; i++) {
/* 1075 */       POJOPropertyBuilder prop; AnnotatedParameter param = ctor.param(i);
/* 1076 */       PropertyName explName = ctor.explicitName(i);
/* 1077 */       PropertyName implName = ctor.implicitName(i);
/* 1078 */       boolean hasExplicit = (explName != null);
/*      */ 
/*      */ 
/*      */       
/* 1082 */       if (!hasExplicit && implName == null) {
/* 1083 */         boolean isUnwrapping = (this._annotationIntrospector.findUnwrappingNameTransformer(param) != null);
/*      */         
/* 1085 */         if (isUnwrapping) {
/*      */ 
/*      */           
/* 1088 */           PropertyName name = UnwrappedPropertyHandler.creatorParamName(param.getIndex());
/* 1089 */           prop = _property(props, name);
/* 1090 */           prop.addCtor(param, name, false, true, false);
/*      */         }
/*      */         else {
/*      */           
/* 1094 */           prop = null;
/*      */         } 
/*      */       } else {
/*      */         
/* 1098 */         if (implName != null) {
/* 1099 */           String n = _checkRenameByField(implName.getSimpleName());
/* 1100 */           implName = PropertyName.construct(n);
/*      */         } 
/*      */         
/* 1103 */         prop = (implName == null) ? _property(props, explName) : _property(props, implName);
/* 1104 */         prop.addCtor(param, hasExplicit ? explName : implName, hasExplicit, true, false);
/*      */       } 
/* 1106 */       creatorProps.add(prop);
/*      */     } 
/* 1108 */     ctor.assignPropertyDefs((List)creatorProps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _addMethods(Map<String, POJOPropertyBuilder> props) {
/* 1122 */     for (AnnotatedMethod m : this._classDef.memberMethods()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1128 */       int argCount = m.getParameterCount();
/* 1129 */       if (argCount == 0) {
/* 1130 */         _addGetterMethod(props, m, this._annotationIntrospector); continue;
/* 1131 */       }  if (argCount == 1) {
/* 1132 */         _addSetterMethod(props, m, this._annotationIntrospector); continue;
/* 1133 */       }  if (argCount == 2 && 
/* 1134 */         Boolean.TRUE.equals(this._annotationIntrospector.hasAnySetter(m))) {
/* 1135 */         if (this._anySetters == null) {
/* 1136 */           this._anySetters = new LinkedList<>();
/*      */         }
/* 1138 */         this._anySetters.add(m);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _addGetterMethod(Map<String, POJOPropertyBuilder> props, AnnotatedMethod m, AnnotationIntrospector ai) {
/*      */     boolean visible;
/* 1150 */     Class<?> rt = m.getRawReturnType();
/* 1151 */     if (rt == void.class || (rt == Void.class && 
/* 1152 */       !this._config.isEnabled(MapperFeature.ALLOW_VOID_VALUED_PROPERTIES))) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1159 */     if (Boolean.TRUE.equals(ai.hasAnyGetter(m))) {
/* 1160 */       if (this._anyGetters == null) {
/* 1161 */         this._anyGetters = new LinkedList<>();
/*      */       }
/* 1163 */       this._anyGetters.add(m);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1168 */       if (Boolean.TRUE.equals(ai.hasAsKey(this._config, m))) {
/* 1169 */         if (this._jsonKeyAccessors == null) {
/* 1170 */           this._jsonKeyAccessors = new LinkedList<>();
/*      */         }
/* 1172 */         this._jsonKeyAccessors.add(m);
/*      */         
/*      */         return;
/*      */       } 
/* 1176 */       if (Boolean.TRUE.equals(ai.hasAsValue(m))) {
/* 1177 */         if (this._jsonValueAccessors == null) {
/* 1178 */           this._jsonValueAccessors = new LinkedList<>();
/*      */         }
/* 1180 */         this._jsonValueAccessors.add(m);
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/* 1186 */     PropertyName pn = ai.findNameForSerialization(m);
/* 1187 */     boolean nameExplicit = (pn != null);
/*      */     
/* 1189 */     if (!nameExplicit) {
/* 1190 */       implName = ai.findImplicitPropertyName(m);
/* 1191 */       if (implName == null) {
/* 1192 */         implName = this._accessorNaming.findNameForRegularGetter(m, m.getName());
/*      */       }
/* 1194 */       if (implName == null) {
/* 1195 */         implName = this._accessorNaming.findNameForIsGetter(m, m.getName());
/* 1196 */         if (implName == null) {
/*      */           return;
/*      */         }
/* 1199 */         visible = this._visibilityChecker.isIsGetterVisible(m);
/*      */       } else {
/* 1201 */         visible = this._visibilityChecker.isGetterVisible(m);
/*      */       } 
/*      */     } else {
/*      */       
/* 1205 */       implName = ai.findImplicitPropertyName(m);
/* 1206 */       if (implName == null) {
/* 1207 */         implName = this._accessorNaming.findNameForRegularGetter(m, m.getName());
/* 1208 */         if (implName == null) {
/* 1209 */           implName = this._accessorNaming.findNameForIsGetter(m, m.getName());
/*      */         }
/*      */       } 
/*      */       
/* 1213 */       if (implName == null) {
/* 1214 */         implName = m.getName();
/*      */       }
/* 1216 */       if (pn.isEmpty()) {
/*      */         
/* 1218 */         pn = _propNameFromSimple(implName);
/* 1219 */         nameExplicit = false;
/*      */       } 
/* 1221 */       visible = true;
/*      */     } 
/*      */     
/* 1224 */     String implName = _checkRenameByField(implName);
/* 1225 */     boolean ignore = ai.hasIgnoreMarker(m);
/* 1226 */     _property(props, implName).addGetter(m, pn, nameExplicit, visible, ignore);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _addSetterMethod(Map<String, POJOPropertyBuilder> props, AnnotatedMethod m, AnnotationIntrospector ai) {
/*      */     boolean visible;
/* 1234 */     PropertyName pn = ai.findNameForDeserialization(m);
/* 1235 */     boolean nameExplicit = (pn != null);
/* 1236 */     if (!nameExplicit) {
/* 1237 */       implName = ai.findImplicitPropertyName(m);
/* 1238 */       if (implName == null) {
/* 1239 */         implName = this._accessorNaming.findNameForMutator(m, m.getName());
/*      */       }
/* 1241 */       if (implName == null) {
/*      */         return;
/*      */       }
/* 1244 */       visible = this._visibilityChecker.isSetterVisible(m);
/*      */     } else {
/*      */       
/* 1247 */       implName = ai.findImplicitPropertyName(m);
/* 1248 */       if (implName == null) {
/* 1249 */         implName = this._accessorNaming.findNameForMutator(m, m.getName());
/*      */       }
/*      */       
/* 1252 */       if (implName == null) {
/* 1253 */         implName = m.getName();
/*      */       }
/* 1255 */       if (pn.isEmpty()) {
/*      */         
/* 1257 */         pn = _propNameFromSimple(implName);
/* 1258 */         nameExplicit = false;
/*      */       } 
/* 1260 */       visible = true;
/*      */     } 
/*      */     
/* 1263 */     String implName = _checkRenameByField(implName);
/* 1264 */     boolean ignore = ai.hasIgnoreMarker(m);
/* 1265 */     _property(props, implName)
/* 1266 */       .addSetter(m, pn, nameExplicit, visible, ignore);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _addInjectables(Map<String, POJOPropertyBuilder> props) {
/* 1272 */     for (AnnotatedField f : this._classDef.fields()) {
/* 1273 */       _doAddInjectable(this._annotationIntrospector.findInjectableValue(f), f);
/*      */     }
/*      */     
/* 1276 */     for (AnnotatedMethod m : this._classDef.memberMethods()) {
/*      */       
/* 1278 */       if (m.getParameterCount() != 1) {
/*      */         continue;
/*      */       }
/* 1281 */       _doAddInjectable(this._annotationIntrospector.findInjectableValue(m), m);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _doAddInjectable(JacksonInject.Value injectable, AnnotatedMember m) {
/* 1287 */     if (injectable == null) {
/*      */       return;
/*      */     }
/* 1290 */     Object id = injectable.getId();
/* 1291 */     if (this._injectables == null) {
/* 1292 */       this._injectables = new LinkedHashMap<>();
/*      */     }
/* 1294 */     AnnotatedMember prev = this._injectables.put(id, m);
/* 1295 */     if (prev != null)
/*      */     {
/* 1297 */       if (prev.getClass() == m.getClass()) {
/* 1298 */         reportProblem("Duplicate injectable value with id '%s' (of type %s)", new Object[] { id, 
/* 1299 */               ClassUtil.classNameOf(id) });
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private PropertyName _propNameFromSimple(String simpleName) {
/* 1305 */     return PropertyName.construct(simpleName, null);
/*      */   }
/*      */ 
/*      */   
/*      */   private String _checkRenameByField(String implName) {
/* 1310 */     if (this._fieldRenameMappings != null) {
/* 1311 */       PropertyName p = this._fieldRenameMappings.get(_propNameFromSimple(implName));
/* 1312 */       if (p != null) {
/* 1313 */         implName = p.getSimpleName();
/* 1314 */         return implName;
/*      */       } 
/*      */     } 
/*      */     
/* 1318 */     return implName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _removeUnwantedProperties(Map<String, POJOPropertyBuilder> props) {
/* 1333 */     Iterator<POJOPropertyBuilder> it = props.values().iterator();
/* 1334 */     while (it.hasNext()) {
/* 1335 */       POJOPropertyBuilder prop = it.next();
/*      */ 
/*      */       
/* 1338 */       if (!prop.anyVisible()) {
/* 1339 */         it.remove();
/*      */         
/*      */         continue;
/*      */       } 
/* 1343 */       if (prop.anyIgnorals()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1349 */         if (isRecordType() && !this._forSerialization) {
/*      */ 
/*      */           
/* 1352 */           prop.removeIgnored();
/*      */           
/* 1354 */           _collectIgnorals(prop.getName());
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */ 
/*      */         
/* 1361 */         if (!prop.anyExplicitsWithoutIgnoral()) {
/* 1362 */           it.remove();
/* 1363 */           _collectIgnorals(prop.getName());
/*      */           
/*      */           continue;
/*      */         } 
/* 1367 */         prop.removeIgnored();
/* 1368 */         if (!prop.couldDeserialize()) {
/* 1369 */           _collectIgnorals(prop.getName());
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _removeUnwantedAccessors(Map<String, POJOPropertyBuilder> props) {
/* 1385 */     boolean inferMutators = this._config.isEnabled(MapperFeature.INFER_PROPERTY_MUTATORS);
/* 1386 */     Iterator<POJOPropertyBuilder> it = props.values().iterator();
/*      */     
/* 1388 */     while (it.hasNext()) {
/* 1389 */       POJOPropertyBuilder prop = it.next();
/*      */ 
/*      */ 
/*      */       
/* 1393 */       prop.removeNonVisible(inferMutators, this._forSerialization ? null : this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _collectIgnorals(String name) {
/* 1404 */     if (!this._forSerialization && name != null) {
/* 1405 */       if (this._ignoredPropertyNames == null) {
/* 1406 */         this._ignoredPropertyNames = new HashSet<>();
/*      */       }
/* 1408 */       this._ignoredPropertyNames.add(name);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _renameProperties(Map<String, POJOPropertyBuilder> props) {
/* 1421 */     Iterator<Map.Entry<String, POJOPropertyBuilder>> it = props.entrySet().iterator();
/* 1422 */     LinkedList<POJOPropertyBuilder> renamed = null;
/* 1423 */     while (it.hasNext()) {
/* 1424 */       Map.Entry<String, POJOPropertyBuilder> entry = it.next();
/* 1425 */       POJOPropertyBuilder prop = entry.getValue();
/*      */ 
/*      */ 
/*      */       
/* 1429 */       if (this._ignoredPropertyNames != null && this._ignoredPropertyNames.contains(prop.getName())) {
/*      */         continue;
/*      */       }
/*      */       
/* 1433 */       Collection<PropertyName> l = prop.findExplicitNames();
/*      */ 
/*      */       
/* 1436 */       if (l.isEmpty()) {
/*      */         continue;
/*      */       }
/* 1439 */       it.remove();
/* 1440 */       if (renamed == null) {
/* 1441 */         renamed = new LinkedList<>();
/*      */       }
/*      */       
/* 1444 */       if (l.size() == 1) {
/* 1445 */         PropertyName n = l.iterator().next();
/* 1446 */         renamed.add(prop.withName(n));
/*      */         
/*      */         continue;
/*      */       } 
/* 1450 */       renamed.addAll(prop.explode(l));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1466 */     if (renamed != null) {
/* 1467 */       for (POJOPropertyBuilder prop : renamed) {
/* 1468 */         String name = prop.getName();
/* 1469 */         POJOPropertyBuilder old = props.get(name);
/* 1470 */         if (old == null) {
/* 1471 */           props.put(name, prop);
/*      */         } else {
/* 1473 */           old.addAll(prop);
/*      */         } 
/*      */         
/* 1476 */         if (_replaceCreatorProperty(this._creatorProperties, prop))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1487 */           if (this._ignoredPropertyNames != null) {
/* 1488 */             this._ignoredPropertyNames.remove(name);
/*      */           }
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _renameUsing(Map<String, POJOPropertyBuilder> propMap, PropertyNamingStrategy naming) {
/* 1499 */     if (this._type.isEnumType() && 
/* 1500 */       getFormatOverrides().getShape() != JsonFormat.Shape.OBJECT) {
/*      */       return;
/*      */     }
/*      */     
/* 1504 */     POJOPropertyBuilder[] props = (POJOPropertyBuilder[])propMap.values().toArray((Object[])new POJOPropertyBuilder[propMap.size()]);
/* 1505 */     propMap.clear();
/* 1506 */     for (POJOPropertyBuilder prop : props) {
/* 1507 */       String simpleName; PropertyName fullName = prop.getFullName();
/* 1508 */       String rename = null;
/*      */ 
/*      */       
/* 1511 */       if (!prop.isExplicitlyNamed() || this._config.isEnabled(MapperFeature.ALLOW_EXPLICIT_PROPERTY_RENAMING)) {
/* 1512 */         if (this._forSerialization) {
/* 1513 */           if (prop.hasGetter()) {
/* 1514 */             rename = naming.nameForGetterMethod(this._config, prop.getGetter(), fullName.getSimpleName());
/* 1515 */           } else if (prop.hasField()) {
/* 1516 */             rename = naming.nameForField(this._config, prop.getField(), fullName.getSimpleName());
/*      */           }
/*      */         
/* 1519 */         } else if (prop.hasSetter()) {
/* 1520 */           rename = naming.nameForSetterMethod(this._config, prop.getSetterUnchecked(), fullName.getSimpleName());
/* 1521 */         } else if (prop.hasConstructorParameter()) {
/* 1522 */           rename = naming.nameForConstructorParameter(this._config, prop.getConstructorParameter(), fullName.getSimpleName());
/* 1523 */         } else if (prop.hasField()) {
/* 1524 */           rename = naming.nameForField(this._config, prop.getFieldUnchecked(), fullName.getSimpleName());
/* 1525 */         } else if (prop.hasGetter()) {
/*      */ 
/*      */           
/* 1528 */           rename = naming.nameForGetterMethod(this._config, prop.getGetterUnchecked(), fullName.getSimpleName());
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 1533 */       if (rename != null && !fullName.hasSimpleName(rename)) {
/* 1534 */         prop = prop.withSimpleName(rename);
/* 1535 */         simpleName = rename;
/*      */       } else {
/* 1537 */         simpleName = fullName.getSimpleName();
/*      */       } 
/*      */       
/* 1540 */       POJOPropertyBuilder old = propMap.get(simpleName);
/* 1541 */       if (old == null) {
/* 1542 */         propMap.put(simpleName, prop);
/*      */       } else {
/* 1544 */         old.addAll(prop);
/*      */       } 
/*      */ 
/*      */       
/* 1548 */       _replaceCreatorProperty(this._creatorProperties, prop);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _renameWithWrappers(Map<String, POJOPropertyBuilder> props) {
/* 1556 */     Iterator<Map.Entry<String, POJOPropertyBuilder>> it = props.entrySet().iterator();
/* 1557 */     LinkedList<POJOPropertyBuilder> renamed = null;
/* 1558 */     while (it.hasNext()) {
/* 1559 */       Map.Entry<String, POJOPropertyBuilder> entry = it.next();
/* 1560 */       POJOPropertyBuilder prop = entry.getValue();
/* 1561 */       AnnotatedMember member = prop.getPrimaryMember();
/* 1562 */       if (member == null) {
/*      */         continue;
/*      */       }
/* 1565 */       PropertyName wrapperName = this._annotationIntrospector.findWrapperName(member);
/*      */ 
/*      */ 
/*      */       
/* 1569 */       if (wrapperName == null || !wrapperName.hasSimpleName()) {
/*      */         continue;
/*      */       }
/* 1572 */       if (!wrapperName.equals(prop.getFullName())) {
/* 1573 */         if (renamed == null) {
/* 1574 */           renamed = new LinkedList<>();
/*      */         }
/* 1576 */         prop = prop.withName(wrapperName);
/* 1577 */         renamed.add(prop);
/* 1578 */         it.remove();
/*      */       } 
/*      */     } 
/*      */     
/* 1582 */     if (renamed != null) {
/* 1583 */       for (POJOPropertyBuilder prop : renamed) {
/* 1584 */         String name = prop.getName();
/* 1585 */         POJOPropertyBuilder old = props.get(name);
/* 1586 */         if (old == null) {
/* 1587 */           props.put(name, prop); continue;
/*      */         } 
/* 1589 */         old.addAll(prop);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _sortProperties(Map<String, POJOPropertyBuilder> props) {
/* 1608 */     AnnotationIntrospector intr = this._annotationIntrospector;
/* 1609 */     Boolean alpha = intr.findSerializationSortAlphabetically(this._classDef);
/*      */ 
/*      */     
/* 1612 */     boolean sortAlpha = (alpha == null) ? this._config.shouldSortPropertiesAlphabetically() : alpha.booleanValue();
/* 1613 */     boolean indexed = _anyIndexed(props.values());
/*      */     
/* 1615 */     String[] propertyOrder = intr.findSerializationPropertyOrder(this._classDef);
/*      */ 
/*      */     
/* 1618 */     if (!sortAlpha && !indexed && this._creatorProperties == null && propertyOrder == null) {
/*      */       return;
/*      */     }
/* 1621 */     int size = props.size();
/*      */ 
/*      */     
/* 1624 */     if (sortAlpha) {
/* 1625 */       all = new TreeMap<>();
/*      */     } else {
/* 1627 */       all = new LinkedHashMap<>(size + size);
/*      */     } 
/*      */     
/* 1630 */     for (POJOPropertyBuilder prop : props.values()) {
/* 1631 */       all.put(prop.getName(), prop);
/*      */     }
/* 1633 */     Map<String, POJOPropertyBuilder> all = _putAnyGettersInTheEnd(all);
/*      */     
/* 1635 */     Map<String, POJOPropertyBuilder> ordered = new LinkedHashMap<>(size + size);
/*      */     
/* 1637 */     if (propertyOrder != null) {
/* 1638 */       for (String name : propertyOrder) {
/* 1639 */         POJOPropertyBuilder w = all.remove(name);
/* 1640 */         if (w == null) {
/* 1641 */           for (POJOPropertyBuilder prop : props.values()) {
/* 1642 */             if (name.equals(prop.getInternalName())) {
/* 1643 */               w = prop;
/*      */               
/* 1645 */               name = prop.getName();
/*      */               break;
/*      */             } 
/*      */           } 
/*      */         }
/* 1650 */         if (w != null) {
/* 1651 */           ordered.put(name, w);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1657 */     if (indexed) {
/* 1658 */       Map<Integer, POJOPropertyBuilder> byIndex = new TreeMap<>();
/* 1659 */       Iterator<Map.Entry<String, POJOPropertyBuilder>> it = all.entrySet().iterator();
/* 1660 */       while (it.hasNext()) {
/* 1661 */         Map.Entry<String, POJOPropertyBuilder> entry = it.next();
/* 1662 */         POJOPropertyBuilder prop = entry.getValue();
/* 1663 */         Integer index = prop.getMetadata().getIndex();
/* 1664 */         if (index != null) {
/* 1665 */           byIndex.put(index, prop);
/* 1666 */           it.remove();
/*      */         } 
/*      */       } 
/* 1669 */       for (POJOPropertyBuilder prop : byIndex.values()) {
/* 1670 */         ordered.put(prop.getName(), prop);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1676 */     if (this._creatorProperties != null && (!sortAlpha || this._config
/* 1677 */       .isEnabled(MapperFeature.SORT_CREATOR_PROPERTIES_FIRST))) {
/*      */       Collection<POJOPropertyBuilder> cr;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1687 */       boolean sortCreatorPropsByAlpha = (sortAlpha && !this._config.isEnabled(MapperFeature.SORT_CREATOR_PROPERTIES_BY_DECLARATION_ORDER));
/* 1688 */       if (sortCreatorPropsByAlpha) {
/* 1689 */         TreeMap<String, POJOPropertyBuilder> sorted = new TreeMap<>();
/*      */         
/* 1691 */         for (POJOPropertyBuilder prop : this._creatorProperties) {
/* 1692 */           if (prop != null) {
/* 1693 */             sorted.put(prop.getName(), prop);
/*      */           }
/*      */         } 
/* 1696 */         cr = sorted.values();
/*      */       } else {
/* 1698 */         cr = this._creatorProperties;
/*      */       } 
/* 1700 */       for (POJOPropertyBuilder prop : cr) {
/* 1701 */         if (prop == null) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1707 */         String name = prop.getName();
/*      */ 
/*      */         
/* 1710 */         if (all.containsKey(name)) {
/* 1711 */           ordered.put(name, prop);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1716 */     ordered.putAll(all);
/* 1717 */     props.clear();
/* 1718 */     props.putAll(ordered);
/*      */   }
/*      */   
/*      */   private boolean _anyIndexed(Collection<POJOPropertyBuilder> props) {
/* 1722 */     for (POJOPropertyBuilder prop : props) {
/* 1723 */       if (prop.getMetadata().hasIndex()) {
/* 1724 */         return true;
/*      */       }
/*      */     } 
/* 1727 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _resolveFieldVsGetter(List<AnnotatedMember> accessors) {
/*      */     while (true) {
/* 1750 */       AnnotatedMember acc1 = accessors.get(0);
/* 1751 */       AnnotatedMember acc2 = accessors.get(1);
/*      */       
/* 1753 */       if (acc1 instanceof AnnotatedField)
/* 1754 */       { if (acc2 instanceof AnnotatedMethod)
/*      */         
/* 1756 */         { accessors.remove(0);
/*      */ 
/*      */ 
/*      */           
/*      */            }
/*      */         
/*      */         else
/*      */         
/*      */         { 
/*      */ 
/*      */           
/* 1767 */           return false; }  } else if (acc1 instanceof AnnotatedMethod) { if (acc2 instanceof AnnotatedField) { accessors.remove(1); } else { return false; }  } else { return false; }
/* 1768 */        if (accessors.size() <= 1) {
/* 1769 */         return true;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void reportProblem(String msg, Object... args) {
/* 1779 */     if (args.length > 0) {
/* 1780 */       msg = String.format(msg, args);
/*      */     }
/* 1782 */     throw new IllegalArgumentException("Problem with definition of " + this._classDef + ": " + msg);
/*      */   }
/*      */ 
/*      */   
/*      */   protected POJOPropertyBuilder _property(Map<String, POJOPropertyBuilder> props, PropertyName name) {
/* 1787 */     String simpleName = name.getSimpleName();
/* 1788 */     POJOPropertyBuilder prop = props.get(simpleName);
/* 1789 */     if (prop == null) {
/* 1790 */       prop = new POJOPropertyBuilder(this._config, this._annotationIntrospector, this._forSerialization, name);
/*      */       
/* 1792 */       props.put(simpleName, prop);
/*      */     } 
/* 1794 */     return prop;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected POJOPropertyBuilder _property(Map<String, POJOPropertyBuilder> props, String implName) {
/* 1801 */     POJOPropertyBuilder prop = props.get(implName);
/* 1802 */     if (prop == null) {
/*      */       
/* 1804 */       prop = new POJOPropertyBuilder(this._config, this._annotationIntrospector, this._forSerialization, PropertyName.construct(implName));
/* 1805 */       props.put(implName, prop);
/*      */     } 
/* 1807 */     return prop;
/*      */   }
/*      */ 
/*      */   
/*      */   private PropertyNamingStrategy _findNamingStrategy() {
/* 1812 */     Object namingDef = this._annotationIntrospector.findNamingStrategy(this._classDef);
/* 1813 */     if (namingDef == null) {
/* 1814 */       return this._config.getPropertyNamingStrategy();
/*      */     }
/* 1816 */     if (namingDef instanceof PropertyNamingStrategy) {
/* 1817 */       return (PropertyNamingStrategy)namingDef;
/*      */     }
/*      */ 
/*      */     
/* 1821 */     if (!(namingDef instanceof Class))
/* 1822 */       reportProblem("AnnotationIntrospector returned PropertyNamingStrategy definition of type %s; expected type `PropertyNamingStrategy` or `Class<PropertyNamingStrategy>` instead", new Object[] {
/*      */             
/* 1824 */             ClassUtil.classNameOf(namingDef)
/*      */           }); 
/* 1826 */     Class<?> namingClass = (Class)namingDef;
/*      */     
/* 1828 */     if (namingClass == PropertyNamingStrategy.class) {
/* 1829 */       return null;
/*      */     }
/*      */     
/* 1832 */     if (!PropertyNamingStrategy.class.isAssignableFrom(namingClass))
/* 1833 */       reportProblem("AnnotationIntrospector returned Class %s; expected `Class<PropertyNamingStrategy>`", new Object[] {
/* 1834 */             ClassUtil.classNameOf(namingClass)
/*      */           }); 
/* 1836 */     HandlerInstantiator hi = this._config.getHandlerInstantiator();
/* 1837 */     if (hi != null) {
/* 1838 */       PropertyNamingStrategy pns = hi.namingStrategyInstance(this._config, this._classDef, namingClass);
/* 1839 */       if (pns != null) {
/* 1840 */         return pns;
/*      */       }
/*      */     } 
/* 1843 */     return (PropertyNamingStrategy)ClassUtil.createInstance(namingClass, this._config
/* 1844 */         .canOverrideAccessModifiers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _replaceCreatorProperty(List<POJOPropertyBuilder> creatorProperties, POJOPropertyBuilder prop) {
/* 1852 */     AnnotatedParameter ctorParam = prop.getConstructorParameter();
/* 1853 */     if (creatorProperties != null && ctorParam != null) {
/* 1854 */       for (int i = 0, len = creatorProperties.size(); i < len; i++) {
/* 1855 */         POJOPropertyBuilder cprop = creatorProperties.get(i);
/* 1856 */         if (cprop != null && 
/* 1857 */           cprop.getConstructorParameter() == ctorParam) {
/* 1858 */           creatorProperties.set(i, prop);
/* 1859 */           return true;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/* 1864 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\POJOPropertiesCollector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */