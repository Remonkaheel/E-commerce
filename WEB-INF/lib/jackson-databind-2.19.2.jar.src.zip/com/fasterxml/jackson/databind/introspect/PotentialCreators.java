/*    */ package com.fasterxml.jackson.databind.introspect;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PotentialCreators
/*    */ {
/*    */   public PotentialCreator propertiesBased;
/*    */   private List<PotentialCreator> explicitDelegating;
/*    */   private List<PotentialCreator> implicitDelegatingConstructors;
/*    */   private List<PotentialCreator> implicitDelegatingFactories;
/*    */   
/*    */   public void setPropertiesBased(MapperConfig<?> config, PotentialCreator ctor, String mode) {
/* 30 */     if (this.propertiesBased != null) {
/* 31 */       throw new IllegalArgumentException(String.format("Conflicting property-based creators: already had %s creator %s, encountered another: %s", new Object[] { mode, this.propertiesBased
/*    */               
/* 33 */               .creator(), ctor.creator() }));
/*    */     }
/* 35 */     this.propertiesBased = ctor.introspectParamNames(config);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addExplicitDelegating(PotentialCreator ctor) {
/* 40 */     if (this.explicitDelegating == null) {
/* 41 */       this.explicitDelegating = new ArrayList<>();
/*    */     }
/* 43 */     this.explicitDelegating.add(ctor);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setImplicitDelegating(List<PotentialCreator> implicitConstructors, List<PotentialCreator> implicitFactories) {
/* 49 */     this.implicitDelegatingConstructors = implicitConstructors;
/* 50 */     this.implicitDelegatingFactories = implicitFactories;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasDelegating() {
/* 61 */     return (this.explicitDelegating != null && !this.explicitDelegating.isEmpty());
/*    */   }
/*    */   
/*    */   public boolean hasPropertiesBased() {
/* 65 */     return (this.propertiesBased != null);
/*    */   }
/*    */   
/*    */   public boolean hasPropertiesBasedOrDelegating() {
/* 69 */     return (this.propertiesBased != null || (this.explicitDelegating != null && !this.explicitDelegating.isEmpty()));
/*    */   }
/*    */   
/*    */   public List<PotentialCreator> getExplicitDelegating() {
/* 73 */     return (this.explicitDelegating == null) ? Collections.<PotentialCreator>emptyList() : this.explicitDelegating;
/*    */   }
/*    */   
/*    */   public List<PotentialCreator> getImplicitDelegatingFactories() {
/* 77 */     return (this.implicitDelegatingFactories == null) ? Collections.<PotentialCreator>emptyList() : this.implicitDelegatingFactories;
/*    */   }
/*    */   
/*    */   public List<PotentialCreator> getImplicitDelegatingConstructors() {
/* 81 */     return (this.implicitDelegatingConstructors == null) ? Collections.<PotentialCreator>emptyList() : this.implicitDelegatingConstructors;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\PotentialCreators.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */