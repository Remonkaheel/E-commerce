/*      */ package com.fasterxml.jackson.databind.introspect;
/*      */ import com.fasterxml.jackson.annotation.JacksonInject;
/*      */ import com.fasterxml.jackson.annotation.JsonAlias;
/*      */ import com.fasterxml.jackson.annotation.JsonCreator;
/*      */ import com.fasterxml.jackson.annotation.JsonFormat;
/*      */ import com.fasterxml.jackson.annotation.JsonIdentityInfo;
/*      */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*      */ import com.fasterxml.jackson.annotation.JsonInclude;
/*      */ import com.fasterxml.jackson.annotation.JsonIncludeProperties;
/*      */ import com.fasterxml.jackson.annotation.JsonManagedReference;
/*      */ import com.fasterxml.jackson.annotation.JsonProperty;
/*      */ import com.fasterxml.jackson.annotation.JsonPropertyOrder;
/*      */ import com.fasterxml.jackson.annotation.JsonSetter;
/*      */ import com.fasterxml.jackson.annotation.JsonSubTypes;
/*      */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*      */ import com.fasterxml.jackson.annotation.JsonUnwrapped;
/*      */ import com.fasterxml.jackson.annotation.JsonValue;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonSerializer;
/*      */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*      */ import com.fasterxml.jackson.databind.PropertyName;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonAppend;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*      */ import com.fasterxml.jackson.databind.ser.BeanPropertyWriter;
/*      */ import com.fasterxml.jackson.databind.type.MapLikeType;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import java.lang.reflect.Field;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ 
/*      */ public class JacksonAnnotationIntrospector extends AnnotationIntrospector implements Serializable {
/*   38 */   private static final Class<? extends Annotation>[] ANNOTATIONS_TO_INFER_SER = new Class[] { JsonSerialize.class, JsonView.class, JsonFormat.class, JsonTypeInfo.class, JsonRawValue.class, JsonUnwrapped.class, JsonBackReference.class, JsonManagedReference.class };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   51 */   private static final Class<? extends Annotation>[] ANNOTATIONS_TO_INFER_DESER = new Class[] { JsonDeserialize.class, JsonView.class, JsonFormat.class, JsonTypeInfo.class, JsonUnwrapped.class, JsonBackReference.class, JsonManagedReference.class, JsonMerge.class };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final Java7Support _java7Helper;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*   67 */     Java7Support x = null;
/*      */     try {
/*   69 */       x = Java7Support.instance();
/*   70 */     } catch (Throwable t) {
/*   71 */       ExceptionUtil.rethrowIfFatal(t);
/*      */     } 
/*   73 */     _java7Helper = x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   88 */   protected transient LRUMap<String, Boolean> _annotationsInside = new LRUMap(48, 48);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _cfgConstructorPropertiesImpliesCreator = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Version version() {
/*  116 */     return PackageVersion.VERSION;
/*      */   }
/*      */   
/*      */   protected Object readResolve() {
/*  120 */     if (this._annotationsInside == null) {
/*  121 */       this._annotationsInside = new LRUMap(48, 48);
/*      */     }
/*  123 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JacksonAnnotationIntrospector setConstructorPropertiesImpliesCreator(boolean b) {
/*  144 */     this._cfgConstructorPropertiesImpliesCreator = b;
/*  145 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAnnotationBundle(Annotation ann) {
/*  164 */     Class<?> type = ann.annotationType();
/*  165 */     String typeName = type.getName();
/*  166 */     Boolean b = (Boolean)this._annotationsInside.get(typeName);
/*  167 */     if (b == null) {
/*  168 */       b = Boolean.valueOf((type.getAnnotation(JacksonAnnotationsInside.class) != null));
/*  169 */       this._annotationsInside.putIfAbsent(typeName, b);
/*      */     } 
/*  171 */     return b.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String[] findEnumValues(Class<?> enumType, Enum<?>[] enumValues, String[] names) {
/*  186 */     HashMap<String, String> expl = null;
/*  187 */     for (Field f : enumType.getDeclaredFields()) {
/*  188 */       if (f.isEnumConstant()) {
/*      */ 
/*      */         
/*  191 */         JsonProperty prop = f.<JsonProperty>getAnnotation(JsonProperty.class);
/*  192 */         if (prop != null) {
/*      */ 
/*      */           
/*  195 */           String n = prop.value();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  202 */           if (expl == null) {
/*  203 */             expl = new HashMap<>();
/*      */           }
/*  205 */           expl.put(f.getName(), n);
/*      */         } 
/*      */       } 
/*  208 */     }  if (expl != null) {
/*  209 */       for (int i = 0, end = enumValues.length; i < end; i++) {
/*  210 */         String defName = enumValues[i].name();
/*  211 */         String explValue = expl.get(defName);
/*  212 */         if (explValue != null) {
/*  213 */           names[i] = explValue;
/*      */         }
/*      */       } 
/*      */     }
/*  217 */     return names;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] findEnumValues(MapperConfig<?> config, AnnotatedClass annotatedClass, Enum<?>[] enumValues, String[] names) {
/*  224 */     Map<String, String> enumToPropertyMap = new LinkedHashMap<>();
/*  225 */     for (AnnotatedField field : annotatedClass.fields()) {
/*  226 */       JsonProperty property = field.<JsonProperty>getAnnotation(JsonProperty.class);
/*  227 */       if (property != null) {
/*  228 */         String propValue = property.value();
/*  229 */         if (propValue != null)
/*      */         {
/*      */           
/*  232 */           enumToPropertyMap.put(field.getName(), propValue);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  238 */     for (int i = 0, end = enumValues.length; i < end; i++) {
/*  239 */       String defName = enumValues[i].name();
/*  240 */       String explValue = enumToPropertyMap.get(defName);
/*  241 */       if (explValue != null) {
/*  242 */         names[i] = explValue;
/*      */       }
/*      */     } 
/*  245 */     return names;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void findEnumAliases(Class<?> enumType, Enum<?>[] enumValues, String[][] aliasList) {
/*  254 */     for (Field f : enumType.getDeclaredFields()) {
/*  255 */       if (f.isEnumConstant()) {
/*  256 */         JsonAlias aliasAnnotation = f.<JsonAlias>getAnnotation(JsonAlias.class);
/*  257 */         if (aliasAnnotation != null) {
/*  258 */           String[] aliases = aliasAnnotation.value();
/*  259 */           if (aliases.length != 0) {
/*  260 */             String name = f.getName();
/*      */             
/*  262 */             for (int i = 0, end = enumValues.length; i < end; i++) {
/*  263 */               if (name.equals(enumValues[i].name())) {
/*  264 */                 aliasList[i] = aliases;
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void findEnumAliases(MapperConfig<?> config, AnnotatedClass annotatedClass, Enum<?>[] enumValues, String[][] aliasList) {
/*  277 */     HashMap<String, String[]> enumToAliasMap = (HashMap)new HashMap<>();
/*  278 */     for (AnnotatedField field : annotatedClass.fields()) {
/*  279 */       JsonAlias alias = field.<JsonAlias>getAnnotation(JsonAlias.class);
/*  280 */       if (alias != null) {
/*  281 */         enumToAliasMap.putIfAbsent(field.getName(), alias.value());
/*      */       }
/*      */     } 
/*      */     
/*  285 */     for (int i = 0, end = enumValues.length; i < end; i++) {
/*  286 */       Enum<?> enumValue = enumValues[i];
/*  287 */       aliasList[i] = enumToAliasMap.getOrDefault(enumValue.name(), new String[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Enum<?> findDefaultEnumValue(Class<Enum<?>> enumCls) {
/*  294 */     return ClassUtil.findFirstAnnotatedEnumValue(enumCls, JsonEnumDefaultValue.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Enum<?> findDefaultEnumValue(AnnotatedClass annotatedClass, Enum<?>[] enumValues) {
/*  308 */     for (Annotated field : annotatedClass.fields()) {
/*  309 */       if (!field.getType().isEnumType()) {
/*      */         continue;
/*      */       }
/*  312 */       JsonEnumDefaultValue found = (JsonEnumDefaultValue)_findAnnotation(field, JsonEnumDefaultValue.class);
/*  313 */       if (found == null) {
/*      */         continue;
/*      */       }
/*      */       
/*  317 */       for (Enum<?> enumValue : enumValues) {
/*  318 */         if (enumValue.name().equals(field.getName())) {
/*  319 */           return enumValue;
/*      */         }
/*      */       } 
/*      */     } 
/*  323 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyName findRootName(AnnotatedClass ac) {
/*  335 */     JsonRootName ann = (JsonRootName)_findAnnotation(ac, JsonRootName.class);
/*  336 */     if (ann == null) {
/*  337 */       return null;
/*      */     }
/*  339 */     String ns = ann.namespace();
/*  340 */     if (ns != null && ns.isEmpty()) {
/*  341 */       ns = null;
/*      */     }
/*  343 */     return PropertyName.construct(ann.value(), ns);
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean isIgnorableType(AnnotatedClass ac) {
/*  348 */     JsonIgnoreType ignore = (JsonIgnoreType)_findAnnotation(ac, JsonIgnoreType.class);
/*  349 */     return (ignore == null) ? null : Boolean.valueOf(ignore.value());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonIgnoreProperties.Value findPropertyIgnoralByName(MapperConfig<?> config, Annotated a) {
/*  355 */     JsonIgnoreProperties v = (JsonIgnoreProperties)_findAnnotation(a, JsonIgnoreProperties.class);
/*  356 */     if (v == null) {
/*  357 */       return JsonIgnoreProperties.Value.empty();
/*      */     }
/*  359 */     return JsonIgnoreProperties.Value.from(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonIgnoreProperties.Value findPropertyIgnorals(Annotated ac) {
/*  366 */     return findPropertyIgnoralByName((MapperConfig<?>)null, ac);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonIncludeProperties.Value findPropertyInclusionByName(MapperConfig<?> config, Annotated a) {
/*  372 */     JsonIncludeProperties v = (JsonIncludeProperties)_findAnnotation(a, JsonIncludeProperties.class);
/*  373 */     if (v == null) {
/*  374 */       return JsonIncludeProperties.Value.all();
/*      */     }
/*  376 */     return JsonIncludeProperties.Value.from(v);
/*      */   }
/*      */ 
/*      */   
/*      */   public Object findFilterId(Annotated a) {
/*  381 */     JsonFilter ann = (JsonFilter)_findAnnotation(a, JsonFilter.class);
/*  382 */     if (ann != null) {
/*  383 */       String id = ann.value();
/*      */       
/*  385 */       if (!id.isEmpty()) {
/*  386 */         return id;
/*      */       }
/*      */     } 
/*  389 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findNamingStrategy(AnnotatedClass ac) {
/*  395 */     JsonNaming ann = (JsonNaming)_findAnnotation(ac, JsonNaming.class);
/*  396 */     return (ann == null) ? null : ann.value();
/*      */   }
/*      */ 
/*      */   
/*      */   public Object findEnumNamingStrategy(MapperConfig<?> config, AnnotatedClass ac) {
/*  401 */     EnumNaming ann = (EnumNaming)_findAnnotation(ac, EnumNaming.class);
/*  402 */     return (ann == null) ? null : ann.value();
/*      */   }
/*      */ 
/*      */   
/*      */   public String findClassDescription(AnnotatedClass ac) {
/*  407 */     JsonClassDescription ann = (JsonClassDescription)_findAnnotation(ac, JsonClassDescription.class);
/*  408 */     return (ann == null) ? null : ann.value();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VisibilityChecker<?> findAutoDetectVisibility(AnnotatedClass ac, VisibilityChecker<?> checker) {
/*  421 */     JsonAutoDetect ann = (JsonAutoDetect)_findAnnotation(ac, JsonAutoDetect.class);
/*  422 */     return (ann == null) ? checker : (VisibilityChecker<?>)checker.with(ann);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String findImplicitPropertyName(AnnotatedMember m) {
/*  433 */     PropertyName n = _findConstructorName(m);
/*  434 */     return (n == null) ? null : n.getSimpleName();
/*      */   }
/*      */ 
/*      */   
/*      */   public List<PropertyName> findPropertyAliases(Annotated m) {
/*  439 */     JsonAlias ann = (JsonAlias)_findAnnotation(m, JsonAlias.class);
/*  440 */     if (ann == null) {
/*  441 */       return null;
/*      */     }
/*  443 */     String[] strs = ann.value();
/*  444 */     int len = strs.length;
/*  445 */     if (len == 0) {
/*  446 */       return Collections.emptyList();
/*      */     }
/*  448 */     List<PropertyName> result = new ArrayList<>(len);
/*  449 */     for (int i = 0; i < len; i++) {
/*  450 */       result.add(PropertyName.construct(strs[i]));
/*      */     }
/*  452 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasIgnoreMarker(AnnotatedMember m) {
/*  457 */     return _isIgnorable(m);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Boolean hasRequiredMarker(AnnotatedMember m) {
/*  463 */     JsonProperty ann = (JsonProperty)_findAnnotation(m, JsonProperty.class);
/*  464 */     if (ann != null) {
/*      */       
/*  466 */       OptBoolean required = ann.isRequired();
/*  467 */       if (required != OptBoolean.DEFAULT) {
/*  468 */         return required.asBoolean();
/*      */       }
/*  470 */       return Boolean.valueOf(ann.required());
/*      */     } 
/*  472 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonProperty.Access findPropertyAccess(Annotated m) {
/*  477 */     JsonProperty ann = (JsonProperty)_findAnnotation(m, JsonProperty.class);
/*  478 */     if (ann != null) {
/*  479 */       return ann.access();
/*      */     }
/*  481 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String findPropertyDescription(Annotated ann) {
/*  486 */     JsonPropertyDescription desc = (JsonPropertyDescription)_findAnnotation(ann, JsonPropertyDescription.class);
/*  487 */     return (desc == null) ? null : desc.value();
/*      */   }
/*      */ 
/*      */   
/*      */   public Integer findPropertyIndex(Annotated ann) {
/*  492 */     JsonProperty prop = (JsonProperty)_findAnnotation(ann, JsonProperty.class);
/*  493 */     if (prop != null) {
/*  494 */       int ix = prop.index();
/*  495 */       if (ix != -1) {
/*  496 */         return Integer.valueOf(ix);
/*      */       }
/*      */     } 
/*  499 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String findPropertyDefaultValue(Annotated ann) {
/*  504 */     JsonProperty prop = (JsonProperty)_findAnnotation(ann, JsonProperty.class);
/*  505 */     if (prop == null) {
/*  506 */       return null;
/*      */     }
/*  508 */     String str = prop.defaultValue();
/*      */     
/*  510 */     return str.isEmpty() ? null : str;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonFormat.Value findFormat(Annotated ann) {
/*  515 */     JsonFormat f = (JsonFormat)_findAnnotation(ann, JsonFormat.class);
/*      */ 
/*      */     
/*  518 */     return (f == null) ? null : JsonFormat.Value.from(f);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotationIntrospector.ReferenceProperty findReferenceType(AnnotatedMember member) {
/*  524 */     JsonManagedReference ref1 = (JsonManagedReference)_findAnnotation(member, JsonManagedReference.class);
/*  525 */     if (ref1 != null) {
/*  526 */       return AnnotationIntrospector.ReferenceProperty.managed(ref1.value());
/*      */     }
/*  528 */     JsonBackReference ref2 = (JsonBackReference)_findAnnotation(member, JsonBackReference.class);
/*  529 */     if (ref2 != null) {
/*  530 */       return AnnotationIntrospector.ReferenceProperty.back(ref2.value());
/*      */     }
/*  532 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public NameTransformer findUnwrappingNameTransformer(AnnotatedMember member) {
/*  538 */     JsonUnwrapped ann = (JsonUnwrapped)_findAnnotation(member, JsonUnwrapped.class);
/*      */ 
/*      */     
/*  541 */     if (ann == null || !ann.enabled()) {
/*  542 */       return null;
/*      */     }
/*  544 */     String prefix = ann.prefix();
/*  545 */     String suffix = ann.suffix();
/*  546 */     return NameTransformer.simpleTransformer(prefix, suffix);
/*      */   }
/*      */ 
/*      */   
/*      */   public JacksonInject.Value findInjectableValue(AnnotatedMember m) {
/*  551 */     JacksonInject ann = (JacksonInject)_findAnnotation(m, JacksonInject.class);
/*  552 */     if (ann == null) {
/*  553 */       return null;
/*      */     }
/*      */     
/*  556 */     JacksonInject.Value v = JacksonInject.Value.from(ann);
/*  557 */     if (!v.hasId()) {
/*      */       Object id;
/*      */       
/*  560 */       if (!(m instanceof AnnotatedMethod)) {
/*  561 */         id = m.getRawType().getName();
/*      */       } else {
/*  563 */         AnnotatedMethod am = (AnnotatedMethod)m;
/*  564 */         if (am.getParameterCount() == 0) {
/*  565 */           id = m.getRawType().getName();
/*      */         } else {
/*  567 */           id = am.getRawParameterType(0).getName();
/*      */         } 
/*      */       } 
/*  570 */       v = v.withId(id);
/*      */     } 
/*  572 */     return v;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Object findInjectableValueId(AnnotatedMember m) {
/*  578 */     JacksonInject.Value v = findInjectableValue(m);
/*  579 */     return (v == null) ? null : v.getId();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?>[] findViews(Annotated a) {
/*  585 */     JsonView ann = (JsonView)_findAnnotation(a, JsonView.class);
/*  586 */     return (ann == null) ? null : ann.value();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AnnotatedMethod resolveSetterConflict(MapperConfig<?> config, AnnotatedMethod setter1, AnnotatedMethod setter2) {
/*  607 */     Class<?> cls1 = setter1.getRawParameterType(0);
/*  608 */     Class<?> cls2 = setter2.getRawParameterType(0);
/*      */ 
/*      */ 
/*      */     
/*  612 */     if (cls1.isPrimitive()) {
/*  613 */       if (!cls2.isPrimitive()) {
/*  614 */         return setter1;
/*      */       }
/*      */       
/*  617 */       return null;
/*  618 */     }  if (cls2.isPrimitive()) {
/*  619 */       return setter2;
/*      */     }
/*      */     
/*  622 */     if (cls1 == String.class) {
/*  623 */       if (cls2 != String.class) {
/*  624 */         return setter1;
/*      */       }
/*  626 */     } else if (cls2 == String.class) {
/*  627 */       return setter2;
/*      */     } 
/*      */     
/*  630 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyName findRenameByField(MapperConfig<?> config, AnnotatedField f, PropertyName implName) {
/*  637 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonTypeInfo.Value findPolymorphicTypeInfo(MapperConfig<?> config, Annotated ann) {
/*  652 */     JsonTypeInfo t = (JsonTypeInfo)_findAnnotation(ann, JsonTypeInfo.class);
/*  653 */     return (t == null) ? null : JsonTypeInfo.Value.from(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeResolverBuilder<?> findTypeResolver(MapperConfig<?> config, AnnotatedClass ac, JavaType baseType) {
/*  660 */     return _findTypeResolver(config, ac, baseType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeResolverBuilder<?> findPropertyTypeResolver(MapperConfig<?> config, AnnotatedMember am, JavaType baseType) {
/*  671 */     if (baseType.isContainerType() || baseType.isReferenceType()) {
/*  672 */       return null;
/*      */     }
/*      */     
/*  675 */     return _findTypeResolver(config, am, baseType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeResolverBuilder<?> findPropertyContentTypeResolver(MapperConfig<?> config, AnnotatedMember am, JavaType containerType) {
/*  684 */     if (containerType.getContentType() == null) {
/*  685 */       throw new IllegalArgumentException("Must call method with a container or reference type (got " + containerType + ")");
/*      */     }
/*  687 */     return _findTypeResolver(config, am, containerType);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List<NamedType> findSubtypes(Annotated a) {
/*  693 */     JsonSubTypes t = (JsonSubTypes)_findAnnotation(a, JsonSubTypes.class);
/*  694 */     if (t == null) return null; 
/*  695 */     JsonSubTypes.Type[] types = t.value();
/*      */ 
/*      */ 
/*      */     
/*  699 */     if (t.failOnRepeatedNames()) {
/*  700 */       return findSubtypesCheckRepeatedNames(a.getName(), types);
/*      */     }
/*  702 */     ArrayList<NamedType> result = new ArrayList<>(types.length);
/*  703 */     for (JsonSubTypes.Type type : types) {
/*  704 */       result.add(new NamedType(type.value(), type.name()));
/*      */       
/*  706 */       for (String name : type.names()) {
/*  707 */         result.add(new NamedType(type.value(), name));
/*      */       }
/*      */     } 
/*  710 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<NamedType> findSubtypesCheckRepeatedNames(String annotatedTypeName, JsonSubTypes.Type[] types) {
/*  717 */     ArrayList<NamedType> result = new ArrayList<>(types.length);
/*  718 */     Set<String> seenNames = new HashSet<>();
/*  719 */     for (JsonSubTypes.Type type : types) {
/*  720 */       String typeName = type.name();
/*  721 */       if (!typeName.isEmpty() && seenNames.contains(typeName)) {
/*  722 */         throw new IllegalArgumentException("Annotated type [" + annotatedTypeName + "] got repeated subtype name [" + typeName + "]");
/*      */       }
/*  724 */       seenNames.add(typeName);
/*      */       
/*  726 */       result.add(new NamedType(type.value(), typeName));
/*      */ 
/*      */       
/*  729 */       for (String altName : type.names()) {
/*  730 */         if (!altName.isEmpty() && seenNames.contains(altName)) {
/*  731 */           throw new IllegalArgumentException("Annotated type [" + annotatedTypeName + "] got repeated subtype name [" + altName + "]");
/*      */         }
/*  733 */         seenNames.add(altName);
/*      */         
/*  735 */         result.add(new NamedType(type.value(), altName));
/*      */       } 
/*      */     } 
/*      */     
/*  739 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String findTypeName(AnnotatedClass ac) {
/*  745 */     JsonTypeName tn = (JsonTypeName)_findAnnotation(ac, JsonTypeName.class);
/*  746 */     return (tn == null) ? null : tn.value();
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean isTypeId(AnnotatedMember member) {
/*  751 */     return Boolean.valueOf(_hasAnnotation(member, JsonTypeId.class));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectIdInfo findObjectIdInfo(Annotated ann) {
/*  762 */     JsonIdentityInfo info = (JsonIdentityInfo)_findAnnotation(ann, JsonIdentityInfo.class);
/*  763 */     if (info == null || info.generator() == ObjectIdGenerators.None.class) {
/*  764 */       return null;
/*      */     }
/*      */     
/*  767 */     PropertyName name = PropertyName.construct(info.property());
/*  768 */     return new ObjectIdInfo(name, info.scope(), info.generator(), info.resolver());
/*      */   }
/*      */ 
/*      */   
/*      */   public ObjectIdInfo findObjectReferenceInfo(Annotated ann, ObjectIdInfo objectIdInfo) {
/*  773 */     JsonIdentityReference ref = (JsonIdentityReference)_findAnnotation(ann, JsonIdentityReference.class);
/*  774 */     if (ref == null) {
/*  775 */       return objectIdInfo;
/*      */     }
/*  777 */     if (objectIdInfo == null) {
/*  778 */       objectIdInfo = ObjectIdInfo.empty();
/*      */     }
/*  780 */     return objectIdInfo.withAlwaysAsId(ref.alwaysAsId());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findSerializer(Annotated a) {
/*  792 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  793 */     if (ann != null) {
/*      */       
/*  795 */       Class<? extends JsonSerializer> serClass = ann.using();
/*  796 */       if (serClass != JsonSerializer.None.class) {
/*  797 */         return serClass;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  805 */     JsonRawValue annRaw = (JsonRawValue)_findAnnotation(a, JsonRawValue.class);
/*  806 */     if (annRaw != null && annRaw.value()) {
/*      */       
/*  808 */       Class<?> cls = a.getRawType();
/*  809 */       return new RawSerializer(cls);
/*      */     } 
/*  811 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findKeySerializer(Annotated a) {
/*  817 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  818 */     if (ann != null) {
/*      */       
/*  820 */       Class<? extends JsonSerializer> serClass = ann.keyUsing();
/*  821 */       if (serClass != JsonSerializer.None.class) {
/*  822 */         return serClass;
/*      */       }
/*      */     } 
/*  825 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findContentSerializer(Annotated a) {
/*  831 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  832 */     if (ann != null) {
/*      */       
/*  834 */       Class<? extends JsonSerializer> serClass = ann.contentUsing();
/*  835 */       if (serClass != JsonSerializer.None.class) {
/*  836 */         return serClass;
/*      */       }
/*      */     } 
/*  839 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findNullSerializer(Annotated a) {
/*  845 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  846 */     if (ann != null) {
/*      */       
/*  848 */       Class<? extends JsonSerializer> serClass = ann.nullsUsing();
/*  849 */       if (serClass != JsonSerializer.None.class) {
/*  850 */         return serClass;
/*      */       }
/*      */     } 
/*  853 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonInclude.Value findPropertyInclusion(Annotated a) {
/*  859 */     JsonInclude inc = (JsonInclude)_findAnnotation(a, JsonInclude.class);
/*  860 */     JsonInclude.Value value = (inc == null) ? JsonInclude.Value.empty() : JsonInclude.Value.from(inc);
/*      */ 
/*      */     
/*  863 */     if (value.getValueInclusion() == JsonInclude.Include.USE_DEFAULTS) {
/*  864 */       value = _refinePropertyInclusion(a, value);
/*      */     }
/*  866 */     return value;
/*      */   }
/*      */ 
/*      */   
/*      */   private JsonInclude.Value _refinePropertyInclusion(Annotated a, JsonInclude.Value value) {
/*  871 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  872 */     if (ann != null) {
/*  873 */       switch (ann.include()) {
/*      */         case ALWAYS:
/*  875 */           return value.withValueInclusion(JsonInclude.Include.ALWAYS);
/*      */         case NON_NULL:
/*  877 */           return value.withValueInclusion(JsonInclude.Include.NON_NULL);
/*      */         case NON_DEFAULT:
/*  879 */           return value.withValueInclusion(JsonInclude.Include.NON_DEFAULT);
/*      */         case NON_EMPTY:
/*  881 */           return value.withValueInclusion(JsonInclude.Include.NON_EMPTY);
/*      */       } 
/*      */ 
/*      */     
/*      */     }
/*  886 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerialize.Typing findSerializationTyping(Annotated a) {
/*  892 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  893 */     return (ann == null) ? null : ann.typing();
/*      */   }
/*      */ 
/*      */   
/*      */   public Object findSerializationConverter(Annotated a) {
/*  898 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  899 */     return (ann == null) ? null : _classIfExplicit(ann.converter(), Converter.None.class);
/*      */   }
/*      */ 
/*      */   
/*      */   public Object findSerializationContentConverter(AnnotatedMember a) {
/*  904 */     JsonSerialize ann = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*  905 */     return (ann == null) ? null : _classIfExplicit(ann.contentConverter(), Converter.None.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType refineSerializationType(MapperConfig<?> config, Annotated a, JavaType baseType) throws JsonMappingException {
/*      */     MapLikeType mapLikeType;
/*  919 */     JavaType javaType1, type = baseType;
/*  920 */     TypeFactory tf = config.getTypeFactory();
/*      */     
/*  922 */     JsonSerialize jsonSer = (JsonSerialize)_findAnnotation(a, JsonSerialize.class);
/*      */ 
/*      */ 
/*      */     
/*  926 */     Class<?> serClass = (jsonSer == null) ? null : _classIfExplicit(jsonSer.as());
/*  927 */     if (serClass != null) {
/*  928 */       if (type.hasRawClass(serClass)) {
/*      */ 
/*      */         
/*  931 */         type = type.withStaticTyping();
/*      */       } else {
/*  933 */         Class<?> currRaw = type.getRawClass();
/*      */ 
/*      */         
/*      */         try {
/*  937 */           if (serClass.isAssignableFrom(currRaw)) {
/*  938 */             type = tf.constructGeneralizedType(type, serClass);
/*  939 */           } else if (currRaw.isAssignableFrom(serClass)) {
/*  940 */             type = tf.constructSpecializedType(type, serClass);
/*  941 */           } else if (_primitiveAndWrapper(currRaw, serClass)) {
/*      */             
/*  943 */             type = type.withStaticTyping();
/*      */           } else {
/*  945 */             throw _databindException(
/*  946 */                 String.format("Cannot refine serialization type %s into %s; types not related", new Object[] {
/*  947 */                     type, serClass.getName() }));
/*      */           } 
/*  949 */         } catch (IllegalArgumentException iae) {
/*  950 */           throw _databindException(iae, 
/*  951 */               String.format("Failed to widen type %s with annotation (value %s), from '%s': %s", new Object[] {
/*  952 */                   type, serClass.getName(), a.getName(), iae.getMessage()
/*      */                 }));
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  959 */     if (type.isMapLikeType()) {
/*  960 */       JavaType keyType = type.getKeyType();
/*  961 */       Class<?> keyClass = (jsonSer == null) ? null : _classIfExplicit(jsonSer.keyAs());
/*  962 */       if (keyClass != null) {
/*  963 */         if (keyType.hasRawClass(keyClass)) {
/*  964 */           keyType = keyType.withStaticTyping();
/*      */         } else {
/*  966 */           Class<?> currRaw = keyType.getRawClass();
/*      */ 
/*      */ 
/*      */           
/*      */           try {
/*  971 */             if (keyClass.isAssignableFrom(currRaw)) {
/*  972 */               keyType = tf.constructGeneralizedType(keyType, keyClass);
/*  973 */             } else if (currRaw.isAssignableFrom(keyClass)) {
/*  974 */               keyType = tf.constructSpecializedType(keyType, keyClass);
/*  975 */             } else if (_primitiveAndWrapper(currRaw, keyClass)) {
/*      */               
/*  977 */               keyType = keyType.withStaticTyping();
/*      */             } else {
/*  979 */               throw _databindException(
/*  980 */                   String.format("Cannot refine serialization key type %s into %s; types not related", new Object[] {
/*  981 */                       keyType, keyClass.getName() }));
/*      */             } 
/*  983 */           } catch (IllegalArgumentException iae) {
/*  984 */             throw _databindException(iae, 
/*  985 */                 String.format("Failed to widen key type of %s with concrete-type annotation (value %s), from '%s': %s", new Object[] {
/*  986 */                     type, keyClass.getName(), a.getName(), iae.getMessage() }));
/*      */           } 
/*      */         } 
/*  989 */         mapLikeType = ((MapLikeType)type).withKeyType(keyType);
/*      */       } 
/*      */     } 
/*      */     
/*  993 */     JavaType contentType = mapLikeType.getContentType();
/*  994 */     if (contentType != null) {
/*      */       
/*  996 */       Class<?> contentClass = (jsonSer == null) ? null : _classIfExplicit(jsonSer.contentAs());
/*  997 */       if (contentClass != null) {
/*  998 */         if (contentType.hasRawClass(contentClass)) {
/*  999 */           contentType = contentType.withStaticTyping();
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1004 */           Class<?> currRaw = contentType.getRawClass();
/*      */           try {
/* 1006 */             if (contentClass.isAssignableFrom(currRaw)) {
/* 1007 */               contentType = tf.constructGeneralizedType(contentType, contentClass);
/* 1008 */             } else if (currRaw.isAssignableFrom(contentClass)) {
/* 1009 */               contentType = tf.constructSpecializedType(contentType, contentClass);
/* 1010 */             } else if (_primitiveAndWrapper(currRaw, contentClass)) {
/*      */               
/* 1012 */               contentType = contentType.withStaticTyping();
/*      */             } else {
/* 1014 */               throw _databindException(
/* 1015 */                   String.format("Cannot refine serialization content type %s into %s; types not related", new Object[] {
/* 1016 */                       contentType, contentClass.getName() }));
/*      */             } 
/* 1018 */           } catch (IllegalArgumentException iae) {
/* 1019 */             throw _databindException(iae, 
/* 1020 */                 String.format("Internal error: failed to refine value type of %s with concrete-type annotation (value %s), from '%s': %s", new Object[] {
/* 1021 */                     mapLikeType, contentClass.getName(), a.getName(), iae.getMessage() }));
/*      */           } 
/*      */         } 
/* 1024 */         javaType1 = mapLikeType.withContentType(contentType);
/*      */       } 
/*      */     } 
/* 1027 */     return javaType1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] findSerializationPropertyOrder(AnnotatedClass ac) {
/* 1038 */     JsonPropertyOrder order = (JsonPropertyOrder)_findAnnotation(ac, JsonPropertyOrder.class);
/* 1039 */     return (order == null) ? null : order.value();
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean findSerializationSortAlphabetically(Annotated ann) {
/* 1044 */     return _findSortAlpha(ann);
/*      */   }
/*      */   
/*      */   private final Boolean _findSortAlpha(Annotated ann) {
/* 1048 */     JsonPropertyOrder order = (JsonPropertyOrder)_findAnnotation(ann, JsonPropertyOrder.class);
/*      */ 
/*      */     
/* 1051 */     if (order != null && order.alphabetic()) {
/* 1052 */       return Boolean.TRUE;
/*      */     }
/* 1054 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void findAndAddVirtualProperties(MapperConfig<?> config, AnnotatedClass ac, List<BeanPropertyWriter> properties) {
/* 1060 */     JsonAppend ann = (JsonAppend)_findAnnotation(ac, JsonAppend.class);
/* 1061 */     if (ann == null) {
/*      */       return;
/*      */     }
/* 1064 */     boolean prepend = ann.prepend();
/* 1065 */     JavaType propType = null;
/*      */ 
/*      */     
/* 1068 */     JsonAppend.Attr[] attrs = ann.attrs();
/* 1069 */     for (int i = 0, len = attrs.length; i < len; i++) {
/* 1070 */       if (propType == null) {
/* 1071 */         propType = config.constructType(Object.class);
/*      */       }
/* 1073 */       BeanPropertyWriter bpw = _constructVirtualProperty(attrs[i], config, ac, propType);
/*      */       
/* 1075 */       if (prepend) {
/* 1076 */         properties.add(i, bpw);
/*      */       } else {
/* 1078 */         properties.add(bpw);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1083 */     JsonAppend.Prop[] props = ann.props();
/* 1084 */     for (int j = 0, k = props.length; j < k; j++) {
/* 1085 */       BeanPropertyWriter bpw = _constructVirtualProperty(props[j], config, ac);
/*      */       
/* 1087 */       if (prepend) {
/* 1088 */         properties.add(j, bpw);
/*      */       } else {
/* 1090 */         properties.add(bpw);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanPropertyWriter _constructVirtualProperty(JsonAppend.Attr attr, MapperConfig<?> config, AnnotatedClass ac, JavaType type) {
/* 1098 */     PropertyMetadata metadata = attr.required() ? PropertyMetadata.STD_REQUIRED : PropertyMetadata.STD_OPTIONAL;
/*      */ 
/*      */     
/* 1101 */     String attrName = attr.value();
/*      */ 
/*      */     
/* 1104 */     PropertyName propName = _propertyName(attr.propName(), attr.propNamespace());
/* 1105 */     if (!propName.hasSimpleName()) {
/* 1106 */       propName = PropertyName.construct(attrName);
/*      */     }
/*      */     
/* 1109 */     AnnotatedMember member = new VirtualAnnotatedMember(ac, ac.getRawType(), attrName, type);
/*      */ 
/*      */     
/* 1112 */     SimpleBeanPropertyDefinition propDef = SimpleBeanPropertyDefinition.construct(config, member, propName, metadata, attr
/* 1113 */         .include());
/*      */     
/* 1115 */     return (BeanPropertyWriter)AttributePropertyWriter.construct(attrName, (BeanPropertyDefinition)propDef, ac
/* 1116 */         .getAnnotations(), type);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanPropertyWriter _constructVirtualProperty(JsonAppend.Prop prop, MapperConfig<?> config, AnnotatedClass ac) {
/* 1122 */     PropertyMetadata metadata = prop.required() ? PropertyMetadata.STD_REQUIRED : PropertyMetadata.STD_OPTIONAL;
/*      */     
/* 1124 */     PropertyName propName = _propertyName(prop.name(), prop.namespace());
/* 1125 */     JavaType type = config.constructType(prop.type());
/*      */ 
/*      */     
/* 1128 */     AnnotatedMember member = new VirtualAnnotatedMember(ac, ac.getRawType(), propName.getSimpleName(), type);
/*      */     
/* 1130 */     SimpleBeanPropertyDefinition propDef = SimpleBeanPropertyDefinition.construct(config, member, propName, metadata, prop
/* 1131 */         .include());
/*      */     
/* 1133 */     Class<?> implClass = prop.value();
/*      */     
/* 1135 */     HandlerInstantiator hi = config.getHandlerInstantiator();
/*      */     
/* 1137 */     VirtualBeanPropertyWriter bpw = (hi == null) ? null : hi.virtualPropertyWriterInstance(config, implClass);
/* 1138 */     if (bpw == null) {
/* 1139 */       bpw = (VirtualBeanPropertyWriter)ClassUtil.createInstance(implClass, config
/* 1140 */           .canOverrideAccessModifiers());
/*      */     }
/*      */ 
/*      */     
/* 1144 */     return (BeanPropertyWriter)bpw.withConfig(config, ac, (BeanPropertyDefinition)propDef, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyName findNameForSerialization(Annotated a) {
/* 1156 */     boolean useDefault = false;
/* 1157 */     JsonGetter jg = (JsonGetter)_findAnnotation(a, JsonGetter.class);
/* 1158 */     if (jg != null) {
/* 1159 */       String s = jg.value();
/*      */       
/* 1161 */       if (!s.isEmpty()) {
/* 1162 */         return PropertyName.construct(s);
/*      */       }
/* 1164 */       useDefault = true;
/*      */     } 
/* 1166 */     JsonProperty pann = (JsonProperty)_findAnnotation(a, JsonProperty.class);
/* 1167 */     if (pann != null) {
/*      */       
/* 1169 */       String ns = pann.namespace();
/* 1170 */       if (ns != null && ns.isEmpty()) {
/* 1171 */         ns = null;
/*      */       }
/* 1173 */       return PropertyName.construct(pann.value(), ns);
/*      */     } 
/* 1175 */     if (useDefault || _hasOneOf(a, (Class[])ANNOTATIONS_TO_INFER_SER)) {
/* 1176 */       return PropertyName.USE_DEFAULT;
/*      */     }
/* 1178 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean hasAsKey(MapperConfig<?> config, Annotated a) {
/* 1183 */     JsonKey ann = (JsonKey)_findAnnotation(a, JsonKey.class);
/* 1184 */     if (ann == null) {
/* 1185 */       return null;
/*      */     }
/* 1187 */     return Boolean.valueOf(ann.value());
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean hasAsValue(Annotated a) {
/* 1192 */     JsonValue ann = (JsonValue)_findAnnotation(a, JsonValue.class);
/* 1193 */     if (ann == null) {
/* 1194 */       return null;
/*      */     }
/* 1196 */     return Boolean.valueOf(ann.value());
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean hasAnyGetter(Annotated a) {
/* 1201 */     JsonAnyGetter ann = (JsonAnyGetter)_findAnnotation(a, JsonAnyGetter.class);
/* 1202 */     if (ann == null) {
/* 1203 */       return null;
/*      */     }
/* 1205 */     return Boolean.valueOf(ann.enabled());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean hasAnyGetterAnnotation(AnnotatedMethod am) {
/* 1212 */     return _hasAnnotation(am, JsonAnyGetter.class);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean hasAsValueAnnotation(AnnotatedMethod am) {
/* 1218 */     JsonValue ann = (JsonValue)_findAnnotation(am, JsonValue.class);
/*      */     
/* 1220 */     return (ann != null && ann.value());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findDeserializer(Annotated a) {
/* 1232 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/* 1233 */     if (ann != null) {
/*      */       
/* 1235 */       Class<? extends JsonDeserializer> deserClass = ann.using();
/* 1236 */       if (deserClass != JsonDeserializer.None.class) {
/* 1237 */         return deserClass;
/*      */       }
/*      */     } 
/* 1240 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findKeyDeserializer(Annotated a) {
/* 1246 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/* 1247 */     if (ann != null) {
/* 1248 */       Class<? extends KeyDeserializer> deserClass = ann.keyUsing();
/* 1249 */       if (deserClass != KeyDeserializer.None.class) {
/* 1250 */         return deserClass;
/*      */       }
/*      */     } 
/* 1253 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findContentDeserializer(Annotated a) {
/* 1259 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/* 1260 */     if (ann != null) {
/*      */       
/* 1262 */       Class<? extends JsonDeserializer> deserClass = ann.contentUsing();
/* 1263 */       if (deserClass != JsonDeserializer.None.class) {
/* 1264 */         return deserClass;
/*      */       }
/*      */     } 
/* 1267 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findDeserializationConverter(Annotated a) {
/* 1273 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/* 1274 */     return (ann == null) ? null : _classIfExplicit(ann.converter(), Converter.None.class);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findDeserializationContentConverter(AnnotatedMember a) {
/* 1280 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/* 1281 */     return (ann == null) ? null : _classIfExplicit(ann.contentConverter(), Converter.None.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType refineDeserializationType(MapperConfig<?> config, Annotated a, JavaType baseType) throws JsonMappingException {
/*      */     MapLikeType mapLikeType;
/* 1294 */     JavaType javaType1, type = baseType;
/* 1295 */     TypeFactory tf = config.getTypeFactory();
/*      */     
/* 1297 */     JsonDeserialize jsonDeser = (JsonDeserialize)_findAnnotation(a, JsonDeserialize.class);
/*      */ 
/*      */     
/* 1300 */     Class<?> valueClass = (jsonDeser == null) ? null : _classIfExplicit(jsonDeser.as());
/* 1301 */     if (valueClass != null && !type.hasRawClass(valueClass) && 
/* 1302 */       !_primitiveAndWrapper(type, valueClass)) {
/*      */       try {
/* 1304 */         type = tf.constructSpecializedType(type, valueClass);
/* 1305 */       } catch (IllegalArgumentException iae) {
/* 1306 */         throw _databindException(iae, 
/* 1307 */             String.format("Failed to narrow type %s with annotation (value %s), from '%s': %s", new Object[] {
/* 1308 */                 type, valueClass.getName(), a.getName(), iae.getMessage()
/*      */               }));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1314 */     if (type.isMapLikeType()) {
/* 1315 */       JavaType keyType = type.getKeyType();
/* 1316 */       Class<?> keyClass = (jsonDeser == null) ? null : _classIfExplicit(jsonDeser.keyAs());
/* 1317 */       if (keyClass != null && 
/* 1318 */         !_primitiveAndWrapper(keyType, keyClass))
/*      */         try {
/* 1320 */           keyType = tf.constructSpecializedType(keyType, keyClass);
/* 1321 */           mapLikeType = ((MapLikeType)type).withKeyType(keyType);
/* 1322 */         } catch (IllegalArgumentException iae) {
/* 1323 */           throw _databindException(iae, 
/* 1324 */               String.format("Failed to narrow key type of %s with concrete-type annotation (value %s), from '%s': %s", new Object[] {
/* 1325 */                   mapLikeType, keyClass.getName(), a.getName(), iae.getMessage()
/*      */                 }));
/*      */         }  
/*      */     } 
/* 1329 */     JavaType contentType = mapLikeType.getContentType();
/* 1330 */     if (contentType != null) {
/*      */       
/* 1332 */       Class<?> contentClass = (jsonDeser == null) ? null : _classIfExplicit(jsonDeser.contentAs());
/* 1333 */       if (contentClass != null && 
/* 1334 */         !_primitiveAndWrapper(contentType, contentClass))
/*      */         try {
/* 1336 */           contentType = tf.constructSpecializedType(contentType, contentClass);
/* 1337 */           javaType1 = mapLikeType.withContentType(contentType);
/* 1338 */         } catch (IllegalArgumentException iae) {
/* 1339 */           throw _databindException(iae, 
/* 1340 */               String.format("Failed to narrow value type of %s with concrete-type annotation (value %s), from '%s': %s", new Object[] {
/* 1341 */                   javaType1, contentClass.getName(), a.getName(), iae.getMessage()
/*      */                 }));
/*      */         }  
/*      */     } 
/* 1345 */     return javaType1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object findValueInstantiator(AnnotatedClass ac) {
/* 1357 */     JsonValueInstantiator ann = (JsonValueInstantiator)_findAnnotation(ac, JsonValueInstantiator.class);
/*      */     
/* 1359 */     return (ann == null) ? null : ann.value();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?> findPOJOBuilder(AnnotatedClass ac) {
/* 1365 */     JsonDeserialize ann = (JsonDeserialize)_findAnnotation(ac, JsonDeserialize.class);
/* 1366 */     return (ann == null) ? null : _classIfExplicit(ann.builder());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonPOJOBuilder.Value findPOJOBuilderConfig(AnnotatedClass ac) {
/* 1372 */     JsonPOJOBuilder ann = (JsonPOJOBuilder)_findAnnotation(ac, JsonPOJOBuilder.class);
/* 1373 */     return (ann == null) ? null : new JsonPOJOBuilder.Value(ann);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyName findNameForDeserialization(Annotated a) {
/* 1387 */     boolean useDefault = false;
/* 1388 */     JsonSetter js = (JsonSetter)_findAnnotation(a, JsonSetter.class);
/* 1389 */     if (js != null) {
/* 1390 */       String s = js.value();
/*      */       
/* 1392 */       if (s.isEmpty()) {
/* 1393 */         useDefault = true;
/*      */       } else {
/* 1395 */         return PropertyName.construct(s);
/*      */       } 
/*      */     } 
/* 1398 */     JsonProperty pann = (JsonProperty)_findAnnotation(a, JsonProperty.class);
/* 1399 */     if (pann != null) {
/*      */       
/* 1401 */       String ns = pann.namespace();
/* 1402 */       if (ns != null && ns.isEmpty()) {
/* 1403 */         ns = null;
/*      */       }
/* 1405 */       return PropertyName.construct(pann.value(), ns);
/*      */     } 
/* 1407 */     if (useDefault || _hasOneOf(a, (Class[])ANNOTATIONS_TO_INFER_DESER)) {
/* 1408 */       return PropertyName.USE_DEFAULT;
/*      */     }
/* 1410 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean hasAnySetter(Annotated a) {
/* 1415 */     JsonAnySetter ann = (JsonAnySetter)_findAnnotation(a, JsonAnySetter.class);
/* 1416 */     return (ann == null) ? null : Boolean.valueOf(ann.enabled());
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonSetter.Value findSetterInfo(Annotated a) {
/* 1421 */     return JsonSetter.Value.from((JsonSetter)_findAnnotation(a, JsonSetter.class));
/*      */   }
/*      */ 
/*      */   
/*      */   public Boolean findMergeInfo(Annotated a) {
/* 1426 */     JsonMerge ann = (JsonMerge)_findAnnotation(a, JsonMerge.class);
/* 1427 */     return (ann == null) ? null : ann.value().asBoolean();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean hasAnySetterAnnotation(AnnotatedMethod am) {
/* 1433 */     return _hasAnnotation(am, JsonAnySetter.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean hasCreatorAnnotation(Annotated a) {
/* 1443 */     JsonCreator ann = (JsonCreator)_findAnnotation(a, JsonCreator.class);
/* 1444 */     if (ann != null) {
/* 1445 */       return (ann.mode() != JsonCreator.Mode.DISABLED);
/*      */     }
/*      */ 
/*      */     
/* 1449 */     if (this._cfgConstructorPropertiesImpliesCreator && 
/* 1450 */       a instanceof AnnotatedConstructor && 
/* 1451 */       _java7Helper != null) {
/* 1452 */       Boolean b = _java7Helper.hasCreatorAnnotation(a);
/* 1453 */       if (b != null) {
/* 1454 */         return b.booleanValue();
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1459 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonCreator.Mode findCreatorBinding(Annotated a) {
/* 1465 */     JsonCreator ann = (JsonCreator)_findAnnotation(a, JsonCreator.class);
/* 1466 */     return (ann == null) ? null : ann.mode();
/*      */   }
/*      */   
/*      */   public JsonCreator.Mode findCreatorAnnotation(MapperConfig<?> config, Annotated a) {
/*      */     JsonCreator.Mode mode;
/* 1471 */     JsonCreator ann = (JsonCreator)_findAnnotation(a, JsonCreator.class);
/*      */     
/* 1473 */     if (ann == null) {
/* 1474 */       mode = null;
/*      */     } else {
/* 1476 */       mode = ann.mode();
/*      */ 
/*      */       
/* 1479 */       if (mode != JsonCreator.Mode.DEFAULT) {
/* 1480 */         return mode;
/*      */       }
/*      */     } 
/* 1483 */     if (this._cfgConstructorPropertiesImpliesCreator && config
/* 1484 */       .isEnabled(MapperFeature.INFER_CREATOR_FROM_CONSTRUCTOR_PROPERTIES))
/*      */     {
/* 1486 */       if (a instanceof AnnotatedConstructor && 
/* 1487 */         _java7Helper != null) {
/* 1488 */         Boolean b = _java7Helper.hasCreatorAnnotation(a);
/* 1489 */         if (b != null && b.booleanValue())
/*      */         {
/*      */           
/* 1492 */           return JsonCreator.Mode.PROPERTIES;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 1497 */     return mode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _isIgnorable(Annotated a) {
/* 1508 */     JsonIgnore ann = (JsonIgnore)_findAnnotation(a, JsonIgnore.class);
/* 1509 */     if (ann != null) {
/* 1510 */       return ann.value();
/*      */     }
/* 1512 */     if (_java7Helper != null) {
/* 1513 */       Boolean b = _java7Helper.findTransient(a);
/* 1514 */       if (b != null) {
/* 1515 */         return b.booleanValue();
/*      */       }
/*      */     } 
/* 1518 */     return false;
/*      */   }
/*      */   
/*      */   protected Class<?> _classIfExplicit(Class<?> cls) {
/* 1522 */     if (cls == null || ClassUtil.isBogusClass(cls)) {
/* 1523 */       return null;
/*      */     }
/* 1525 */     return cls;
/*      */   }
/*      */   
/*      */   protected Class<?> _classIfExplicit(Class<?> cls, Class<?> implicit) {
/* 1529 */     cls = _classIfExplicit(cls);
/* 1530 */     return (cls == null || cls == implicit) ? null : cls;
/*      */   }
/*      */   
/*      */   protected PropertyName _propertyName(String localName, String namespace) {
/* 1534 */     if (localName.isEmpty()) {
/* 1535 */       return PropertyName.USE_DEFAULT;
/*      */     }
/* 1537 */     if (namespace == null || namespace.isEmpty()) {
/* 1538 */       return PropertyName.construct(localName);
/*      */     }
/* 1540 */     return PropertyName.construct(localName, namespace);
/*      */   }
/*      */ 
/*      */   
/*      */   protected PropertyName _findConstructorName(Annotated a) {
/* 1545 */     if (a instanceof AnnotatedParameter) {
/* 1546 */       AnnotatedParameter p = (AnnotatedParameter)a;
/* 1547 */       AnnotatedWithParams ctor = p.getOwner();
/*      */       
/* 1549 */       if (ctor != null && 
/* 1550 */         _java7Helper != null) {
/* 1551 */         PropertyName name = _java7Helper.findConstructorName(p);
/* 1552 */         if (name != null) {
/* 1553 */           return name;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1558 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TypeResolverBuilder<?> _findTypeResolver(MapperConfig<?> config, Annotated ann, JavaType baseType) {
/* 1570 */     JsonTypeInfo.Value typeInfo = findPolymorphicTypeInfo(config, ann);
/*      */ 
/*      */ 
/*      */     
/* 1574 */     JsonTypeResolver resAnn = (JsonTypeResolver)_findAnnotation(ann, JsonTypeResolver.class);
/*      */     
/* 1576 */     if (resAnn != null) {
/* 1577 */       if (typeInfo == null) {
/* 1578 */         return null;
/*      */       }
/*      */ 
/*      */       
/* 1582 */       b = config.typeResolverBuilderInstance(ann, resAnn.value());
/*      */     } else {
/* 1584 */       if (typeInfo == null) {
/* 1585 */         return null;
/*      */       }
/*      */       
/* 1588 */       if (typeInfo.getIdType() == JsonTypeInfo.Id.NONE) {
/* 1589 */         return (TypeResolverBuilder<?>)_constructNoTypeResolverBuilder();
/*      */       }
/* 1591 */       b = _constructStdTypeResolverBuilder(config, typeInfo, baseType);
/*      */     } 
/*      */     
/* 1594 */     JsonTypeIdResolver idResInfo = (JsonTypeIdResolver)_findAnnotation(ann, JsonTypeIdResolver.class);
/*      */     
/* 1596 */     TypeIdResolver idRes = (idResInfo == null) ? null : config.typeIdResolverInstance(ann, idResInfo.value());
/* 1597 */     if (idRes != null) {
/* 1598 */       idRes.init(baseType);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1603 */     JsonTypeInfo.As inclusion = typeInfo.getInclusionType();
/* 1604 */     if (inclusion == JsonTypeInfo.As.EXTERNAL_PROPERTY && ann instanceof AnnotatedClass) {
/* 1605 */       typeInfo = typeInfo.withInclusionType(JsonTypeInfo.As.PROPERTY);
/*      */     }
/* 1607 */     Class<?> defaultImpl = typeInfo.getDefaultImpl();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1613 */     if (defaultImpl != null && defaultImpl != JsonTypeInfo.None.class && !defaultImpl.isAnnotation()) {
/* 1614 */       typeInfo = typeInfo.withDefaultImpl(defaultImpl);
/*      */     }
/*      */     
/* 1617 */     TypeResolverBuilder<?> b = b.init(typeInfo, idRes);
/* 1618 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected StdTypeResolverBuilder _constructStdTypeResolverBuilder() {
/* 1626 */     return new StdTypeResolverBuilder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TypeResolverBuilder<?> _constructStdTypeResolverBuilder(MapperConfig<?> config, JsonTypeInfo.Value typeInfo, JavaType baseType) {
/* 1637 */     return (TypeResolverBuilder<?>)new StdTypeResolverBuilder(typeInfo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected StdTypeResolverBuilder _constructNoTypeResolverBuilder() {
/* 1645 */     return StdTypeResolverBuilder.noTypeInfoBuilder();
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean _primitiveAndWrapper(Class<?> baseType, Class<?> refinement) {
/* 1650 */     if (baseType.isPrimitive()) {
/* 1651 */       return (baseType == ClassUtil.primitiveType(refinement));
/*      */     }
/* 1653 */     if (refinement.isPrimitive()) {
/* 1654 */       return (refinement == ClassUtil.primitiveType(baseType));
/*      */     }
/* 1656 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean _primitiveAndWrapper(JavaType baseType, Class<?> refinement) {
/* 1661 */     if (baseType.isPrimitive()) {
/* 1662 */       return baseType.hasRawClass(ClassUtil.primitiveType(refinement));
/*      */     }
/* 1664 */     if (refinement.isPrimitive()) {
/* 1665 */       return (refinement == ClassUtil.primitiveType(baseType.getRawClass()));
/*      */     }
/* 1667 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private JsonMappingException _databindException(String msg) {
/* 1672 */     return new JsonMappingException(null, msg);
/*      */   }
/*      */ 
/*      */   
/*      */   private JsonMappingException _databindException(Throwable t, String msg) {
/* 1677 */     return new JsonMappingException(null, msg, t);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\introspect\JacksonAnnotationIntrospector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */