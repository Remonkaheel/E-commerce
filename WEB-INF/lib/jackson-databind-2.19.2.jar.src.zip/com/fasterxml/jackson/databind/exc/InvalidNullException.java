/*    */ package com.fasterxml.jackson.databind.exc;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.PropertyName;
/*    */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidNullException
/*    */   extends MismatchedInputException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected final PropertyName _propertyName;
/*    */   
/*    */   protected InvalidNullException(JsonParser p, String msg, PropertyName pname) {
/* 35 */     super(p, msg);
/* 36 */     this._propertyName = pname;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected InvalidNullException(DeserializationContext ctxt, String msg, PropertyName pname) {
/* 42 */     this((ctxt == null) ? null : ctxt.getParser(), msg, pname);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static InvalidNullException from(DeserializationContext ctxt, PropertyName name, JavaType type) {
/* 48 */     String msg = String.format("Invalid `null` value encountered for property %s", new Object[] {
/* 49 */           ClassUtil.quotedOr(name, "<UNKNOWN>") });
/* 50 */     InvalidNullException exc = new InvalidNullException(ctxt, msg, name);
/* 51 */     if (type != null) {
/* 52 */       exc.setTargetType(type);
/*    */     }
/* 54 */     return exc;
/*    */   }
/*    */   
/*    */   public PropertyName getPropertyName() {
/* 58 */     return this._propertyName;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\exc\InvalidNullException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */