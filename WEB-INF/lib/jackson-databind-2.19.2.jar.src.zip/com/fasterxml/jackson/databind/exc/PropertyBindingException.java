/*     */ package com.fasterxml.jackson.databind.exc;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PropertyBindingException
/*     */   extends MismatchedInputException
/*     */ {
/*     */   protected final Class<?> _referringClass;
/*     */   protected final String _propertyName;
/*     */   protected final Collection<Object> _propertyIds;
/*     */   protected transient String _propertiesAsString;
/*     */   private static final int MAX_DESC_LENGTH = 1000;
/*     */   
/*     */   protected PropertyBindingException(JsonParser p, String msg, JsonLocation loc, Class<?> referringClass, String propName, Collection<Object> propertyIds) {
/*  54 */     super(p, msg, loc);
/*  55 */     this._referringClass = referringClass;
/*  56 */     this._propertyName = propName;
/*  57 */     this._propertyIds = propertyIds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected PropertyBindingException(String msg, JsonLocation loc, Class<?> referringClass, String propName, Collection<Object> propertyIds) {
/*  68 */     this(null, msg, loc, referringClass, propName, propertyIds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessageSuffix() {
/*  86 */     String suffix = this._propertiesAsString;
/*  87 */     if (suffix == null && this._propertyIds != null) {
/*  88 */       StringBuilder sb = new StringBuilder(100);
/*  89 */       int len = this._propertyIds.size();
/*  90 */       if (len == 1) {
/*  91 */         sb.append(" (one known property: \"");
/*  92 */         sb.append(String.valueOf(this._propertyIds.iterator().next()));
/*  93 */         sb.append('"');
/*     */       } else {
/*  95 */         sb.append(" (").append(len).append(" known properties: ");
/*  96 */         Iterator<Object> it = this._propertyIds.iterator();
/*  97 */         while (it.hasNext()) {
/*  98 */           sb.append('"');
/*  99 */           sb.append(String.valueOf(it.next()));
/* 100 */           sb.append('"');
/*     */           
/* 102 */           if (sb.length() > 1000) {
/* 103 */             sb.append(" [truncated]");
/*     */             break;
/*     */           } 
/* 106 */           if (it.hasNext()) {
/* 107 */             sb.append(", ");
/*     */           }
/*     */         } 
/*     */       } 
/* 111 */       sb.append("])");
/* 112 */       this._propertiesAsString = suffix = sb.toString();
/*     */     } 
/* 114 */     return suffix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getReferringClass() {
/* 127 */     return this._referringClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPropertyName() {
/* 137 */     return this._propertyName;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<Object> getKnownPropertyIds() {
/* 142 */     if (this._propertyIds == null) {
/* 143 */       return null;
/*     */     }
/* 145 */     return Collections.unmodifiableCollection(this._propertyIds);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\exc\PropertyBindingException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */