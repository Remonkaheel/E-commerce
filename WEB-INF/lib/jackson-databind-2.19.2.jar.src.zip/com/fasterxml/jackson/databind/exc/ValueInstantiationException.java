/*    */ package com.fasterxml.jackson.databind.exc;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import java.io.Closeable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValueInstantiationException
/*    */   extends JsonMappingException
/*    */ {
/*    */   protected final JavaType _type;
/*    */   
/*    */   protected ValueInstantiationException(JsonParser p, String msg, JavaType type, Throwable cause) {
/* 29 */     super((Closeable)p, msg, cause);
/* 30 */     this._type = type;
/*    */   }
/*    */ 
/*    */   
/*    */   protected ValueInstantiationException(JsonParser p, String msg, JavaType type) {
/* 35 */     super((Closeable)p, msg);
/* 36 */     this._type = type;
/*    */   }
/*    */ 
/*    */   
/*    */   public static ValueInstantiationException from(JsonParser p, String msg, JavaType type) {
/* 41 */     return new ValueInstantiationException(p, msg, type);
/*    */   }
/*    */ 
/*    */   
/*    */   public static ValueInstantiationException from(JsonParser p, String msg, JavaType type, Throwable cause) {
/* 46 */     return new ValueInstantiationException(p, msg, type, cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JavaType getType() {
/* 54 */     return this._type;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\exc\ValueInstantiationException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */