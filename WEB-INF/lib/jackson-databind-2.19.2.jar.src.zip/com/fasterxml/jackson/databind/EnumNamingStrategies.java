/*     */ package com.fasterxml.jackson.databind;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.util.NamingStrategyImpls;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnumNamingStrategies
/*     */ {
/*  24 */   public static final EnumNamingStrategy LOWER_CAMEL_CASE = LowerCamelCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  35 */   public static final EnumNamingStrategy UPPER_CAMEL_CASE = UpperCamelCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public static final EnumNamingStrategy SNAKE_CASE = SnakeCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public static final EnumNamingStrategy UPPER_SNAKE_CASE = UpperSnakeCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public static final EnumNamingStrategy LOWER_CASE = LowerCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   public static final EnumNamingStrategy KEBAB_CASE = KebabCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public static final EnumNamingStrategy LOWER_DOT_CASE = LowerDotCaseStrategy.INSTANCE;
/*     */   
/*     */   public static abstract class DelegatingEnumNamingStrategy implements EnumNamingStrategy {
/*     */     private final NamingStrategyImpls strategy;
/*     */     
/*     */     protected DelegatingEnumNamingStrategy(NamingStrategyImpls strategy) {
/*  92 */       this.strategy = strategy;
/*     */     }
/*     */ 
/*     */     
/*     */     public String convertEnumToExternalName(String enumName) {
/*  97 */       return this.strategy.translate(toBeanName(enumName));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected static String toBeanName(String enumName) {
/* 107 */       if (enumName == null) {
/* 108 */         return null;
/*     */       }
/*     */       
/* 111 */       String UNDERSCORE = "_";
/* 112 */       StringBuilder out = null;
/* 113 */       int iterationCnt = 0;
/* 114 */       int lastSeparatorIdx = -1;
/*     */       
/*     */       do {
/* 117 */         lastSeparatorIdx = nextIndexOfUnderscore(enumName, lastSeparatorIdx + 1);
/* 118 */         if (lastSeparatorIdx == -1)
/* 119 */           continue;  if (iterationCnt == 0) {
/* 120 */           out = new StringBuilder(enumName.length() + 4 * "_".length());
/* 121 */           out.append(enumName.substring(iterationCnt, lastSeparatorIdx).toLowerCase(Locale.ROOT));
/*     */         } else {
/* 123 */           out.append(normalizeWord(enumName.substring(iterationCnt, lastSeparatorIdx)));
/*     */         } 
/* 125 */         iterationCnt = lastSeparatorIdx + "_".length();
/*     */       }
/* 127 */       while (lastSeparatorIdx != -1);
/*     */       
/* 129 */       if (iterationCnt == 0) {
/* 130 */         return enumName.toLowerCase(Locale.ROOT);
/*     */       }
/* 132 */       out.append(normalizeWord(enumName.substring(iterationCnt)));
/* 133 */       return out.toString();
/*     */     }
/*     */     
/*     */     private static int nextIndexOfUnderscore(CharSequence sequence, int start) {
/* 137 */       int length = sequence.length();
/* 138 */       for (int i = start; i < length; i++) {
/* 139 */         if ('_' == sequence.charAt(i)) {
/* 140 */           return i;
/*     */         }
/*     */       } 
/* 143 */       return -1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static String normalizeWord(String word) {
/* 150 */       int length = word.length();
/* 151 */       if (length == 0) {
/* 152 */         return word;
/*     */       }
/* 154 */       return Character.toUpperCase(word.charAt(0)) + word.substring(1).toLowerCase();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static class CamelCaseStrategy
/*     */     extends DelegatingEnumNamingStrategy
/*     */   {
/* 169 */     public static final CamelCaseStrategy INSTANCE = new CamelCaseStrategy();
/*     */     
/*     */     protected CamelCaseStrategy() {
/* 172 */       super(NamingStrategyImpls.LOWER_CAMEL_CASE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class LowerCamelCaseStrategy
/*     */     extends DelegatingEnumNamingStrategy
/*     */   {
/* 218 */     public static final LowerCamelCaseStrategy INSTANCE = new LowerCamelCaseStrategy();
/*     */     
/*     */     protected LowerCamelCaseStrategy() {
/* 221 */       super(NamingStrategyImpls.LOWER_CAMEL_CASE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class UpperCamelCaseStrategy
/*     */     extends DelegatingEnumNamingStrategy
/*     */   {
/* 260 */     public static final UpperCamelCaseStrategy INSTANCE = new UpperCamelCaseStrategy();
/*     */     
/*     */     protected UpperCamelCaseStrategy() {
/* 263 */       super(NamingStrategyImpls.UPPER_CAMEL_CASE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class SnakeCaseStrategy
/*     */     extends DelegatingEnumNamingStrategy
/*     */   {
/* 302 */     public static final SnakeCaseStrategy INSTANCE = new SnakeCaseStrategy();
/*     */     
/*     */     protected SnakeCaseStrategy() {
/* 305 */       super(NamingStrategyImpls.SNAKE_CASE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class UpperSnakeCaseStrategy
/*     */     extends DelegatingEnumNamingStrategy
/*     */   {
/* 344 */     public static final UpperSnakeCaseStrategy INSTANCE = new UpperSnakeCaseStrategy();
/*     */     
/*     */     protected UpperSnakeCaseStrategy() {
/* 347 */       super(NamingStrategyImpls.UPPER_SNAKE_CASE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class LowerCaseStrategy
/*     */     extends DelegatingEnumNamingStrategy
/*     */   {
/* 386 */     public static final LowerCaseStrategy INSTANCE = new LowerCaseStrategy();
/*     */     
/*     */     protected LowerCaseStrategy() {
/* 389 */       super(NamingStrategyImpls.LOWER_CASE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class KebabCaseStrategy
/*     */     extends DelegatingEnumNamingStrategy
/*     */   {
/* 428 */     public static final KebabCaseStrategy INSTANCE = new KebabCaseStrategy();
/*     */     
/*     */     protected KebabCaseStrategy() {
/* 431 */       super(NamingStrategyImpls.KEBAB_CASE);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class LowerDotCaseStrategy
/*     */     extends DelegatingEnumNamingStrategy
/*     */   {
/* 470 */     public static final LowerDotCaseStrategy INSTANCE = new LowerDotCaseStrategy();
/*     */     
/*     */     protected LowerDotCaseStrategy() {
/* 473 */       super(NamingStrategyImpls.LOWER_DOT_CASE);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\EnumNamingStrategies.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */