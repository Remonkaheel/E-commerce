/*      */ package com.fasterxml.jackson.databind;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonFormat;
/*      */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*      */ import com.fasterxml.jackson.annotation.ObjectIdResolver;
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeature;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*      */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeatures;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*      */ import com.fasterxml.jackson.databind.deser.ContextualKeyDeserializer;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializerCache;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializerFactory;
/*      */ import com.fasterxml.jackson.databind.deser.UnresolvedForwardReference;
/*      */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ObjectIdReader;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*      */ import com.fasterxml.jackson.databind.deser.impl.TypeWrappedDeserializer;
/*      */ import com.fasterxml.jackson.databind.exc.InvalidDefinitionException;
/*      */ import com.fasterxml.jackson.databind.exc.InvalidFormatException;
/*      */ import com.fasterxml.jackson.databind.exc.InvalidTypeIdException;
/*      */ import com.fasterxml.jackson.databind.exc.MismatchedInputException;
/*      */ import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
/*      */ import com.fasterxml.jackson.databind.exc.ValueInstantiationException;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*      */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*      */ import com.fasterxml.jackson.databind.node.TreeTraversingParser;
/*      */ import com.fasterxml.jackson.databind.type.LogicalType;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ArrayBuilders;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.LinkedNode;
/*      */ import com.fasterxml.jackson.databind.util.Named;
/*      */ import com.fasterxml.jackson.databind.util.ObjectBuffer;
/*      */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.text.DateFormat;
/*      */ import java.text.ParseException;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.Locale;
/*      */ import java.util.Objects;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class DeserializationContext
/*      */   extends DatabindContext
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   protected final DeserializerCache _cache;
/*      */   protected final DeserializerFactory _factory;
/*      */   protected final DeserializationConfig _config;
/*      */   protected final int _featureFlags;
/*      */   protected final JacksonFeatureSet<StreamReadCapability> _readCapabilities;
/*      */   protected final Class<?> _view;
/*      */   protected transient JsonParser _parser;
/*      */   protected final InjectableValues _injectableValues;
/*      */   protected transient ArrayBuilders _arrayBuilders;
/*      */   protected transient ObjectBuffer _objectBuffer;
/*      */   protected transient DateFormat _dateFormat;
/*      */   protected transient ContextAttributes _attributes;
/*      */   protected LinkedNode<JavaType> _currentType;
/*      */   
/*      */   protected DeserializationContext(DeserializerFactory df, DeserializerCache cache) {
/*  167 */     this._factory = Objects.<DeserializerFactory>requireNonNull(df);
/*      */ 
/*      */     
/*  170 */     if (cache == null) {
/*  171 */       cache = new DeserializerCache();
/*      */     }
/*  173 */     this._cache = cache;
/*  174 */     this._featureFlags = 0;
/*  175 */     this._readCapabilities = null;
/*  176 */     this._config = null;
/*  177 */     this._injectableValues = null;
/*  178 */     this._view = null;
/*  179 */     this._attributes = null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeserializationContext(DeserializationContext src, DeserializerFactory factory) {
/*  185 */     this._cache = src._cache;
/*  186 */     this._factory = factory;
/*      */     
/*  188 */     this._config = src._config;
/*  189 */     this._featureFlags = src._featureFlags;
/*  190 */     this._readCapabilities = src._readCapabilities;
/*  191 */     this._view = src._view;
/*  192 */     this._parser = src._parser;
/*  193 */     this._injectableValues = src._injectableValues;
/*  194 */     this._attributes = src._attributes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeserializationContext(DeserializationContext src, DeserializerCache cache) {
/*  203 */     this._cache = cache;
/*  204 */     this._factory = src._factory;
/*      */     
/*  206 */     this._config = src._config;
/*  207 */     this._featureFlags = src._featureFlags;
/*  208 */     this._readCapabilities = src._readCapabilities;
/*  209 */     this._view = src._view;
/*  210 */     this._parser = src._parser;
/*  211 */     this._injectableValues = src._injectableValues;
/*  212 */     this._attributes = src._attributes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeserializationContext(DeserializationContext src, DeserializationConfig config, JsonParser p, InjectableValues injectableValues) {
/*  222 */     this._cache = src._cache;
/*  223 */     this._factory = src._factory;
/*      */ 
/*      */ 
/*      */     
/*  227 */     this._readCapabilities = (p == null) ? null : p.getReadCapabilities();
/*      */     
/*  229 */     this._config = config;
/*  230 */     this._featureFlags = config.getDeserializationFeatures();
/*  231 */     this._view = config.getActiveView();
/*  232 */     this._parser = p;
/*  233 */     this._injectableValues = injectableValues;
/*  234 */     this._attributes = config.getAttributes();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeserializationContext(DeserializationContext src, DeserializationConfig config) {
/*  246 */     this._cache = src._cache;
/*  247 */     this._factory = src._factory;
/*  248 */     this._readCapabilities = null;
/*      */     
/*  250 */     this._config = config;
/*  251 */     this._featureFlags = config.getDeserializationFeatures();
/*  252 */     this._view = null;
/*  253 */     this._parser = null;
/*  254 */     this._injectableValues = null;
/*  255 */     this._attributes = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeserializationContext(DeserializationContext src) {
/*  263 */     this._cache = src._cache.emptyCopy();
/*  264 */     this._factory = src._factory;
/*      */     
/*  266 */     this._config = src._config;
/*  267 */     this._featureFlags = src._featureFlags;
/*  268 */     this._readCapabilities = src._readCapabilities;
/*  269 */     this._view = src._view;
/*  270 */     this._injectableValues = src._injectableValues;
/*  271 */     this._attributes = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig getConfig() {
/*  281 */     return this._config;
/*      */   }
/*      */   public final Class<?> getActiveView() {
/*  284 */     return this._view;
/*      */   }
/*      */   
/*      */   public final boolean canOverrideAccessModifiers() {
/*  288 */     return this._config.canOverrideAccessModifiers();
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(MapperFeature feature) {
/*  293 */     return this._config.isEnabled(feature);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(DatatypeFeature feature) {
/*  298 */     return this._config.isEnabled(feature);
/*      */   }
/*      */ 
/*      */   
/*      */   public final DatatypeFeatures getDatatypeFeatures() {
/*  303 */     return this._config.getDatatypeFeatures();
/*      */   }
/*      */ 
/*      */   
/*      */   public final JsonFormat.Value getDefaultPropertyFormat(Class<?> baseType) {
/*  308 */     return this._config.getDefaultPropertyFormat(baseType);
/*      */   }
/*      */ 
/*      */   
/*      */   public final AnnotationIntrospector getAnnotationIntrospector() {
/*  313 */     return this._config.getAnnotationIntrospector();
/*      */   }
/*      */ 
/*      */   
/*      */   public final TypeFactory getTypeFactory() {
/*  318 */     return this._config.getTypeFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructSpecializedType(JavaType baseType, Class<?> subclass) throws IllegalArgumentException {
/*  325 */     if (baseType.hasRawClass(subclass)) {
/*  326 */       return baseType;
/*      */     }
/*      */ 
/*      */     
/*  330 */     return getConfig().getTypeFactory().constructSpecializedType(baseType, subclass, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Locale getLocale() {
/*  341 */     return this._config.getLocale();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TimeZone getTimeZone() {
/*  352 */     return this._config.getTimeZone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getAttribute(Object key) {
/*  363 */     return this._attributes.getAttribute(key);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationContext setAttribute(Object key, Object value) {
/*  369 */     this._attributes = this._attributes.withPerCallAttribute(key, value);
/*  370 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType getContextualType() {
/*  387 */     return (this._currentType == null) ? null : (JavaType)this._currentType.value();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializerFactory getFactory() {
/*  400 */     return this._factory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(DeserializationFeature feat) {
/*  411 */     return ((this._featureFlags & feat.getMask()) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(StreamReadCapability cap) {
/*  423 */     return this._readCapabilities.isEnabled((JacksonFeature)cap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getDeserializationFeatures() {
/*  433 */     return this._featureFlags;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean hasDeserializationFeatures(int featureMask) {
/*  443 */     return ((this._featureFlags & featureMask) == featureMask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean hasSomeOfFeatures(int featureMask) {
/*  453 */     return ((this._featureFlags & featureMask) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonParser getParser() {
/*  464 */     return this._parser;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final Object findInjectableValue(Object valueId, BeanProperty forProperty, Object beanInstance) throws JsonMappingException {
/*  470 */     if (this._injectableValues == null) {
/*  471 */       return reportBadDefinition(ClassUtil.classOf(valueId), String.format("No 'injectableValues' configured, cannot inject value with id [%s]", new Object[] { valueId }));
/*      */     }
/*      */     
/*  474 */     return this._injectableValues.findInjectableValue(valueId, this, forProperty, beanInstance);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Base64Variant getBase64Variant() {
/*  486 */     return this._config.getBase64Variant();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonNodeFactory getNodeFactory() {
/*  496 */     return this._config.getNodeFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CoercionAction findCoercionAction(LogicalType targetType, Class<?> targetClass, CoercionInputShape inputShape) {
/*  520 */     return this._config.findCoercionAction(targetType, targetClass, inputShape);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CoercionAction findCoercionFromBlankString(LogicalType targetType, Class<?> targetClass, CoercionAction actionIfBlankNotAllowed) {
/*  543 */     return this._config.findCoercionFromBlankString(targetType, targetClass, actionIfBlankNotAllowed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer bufferForInputBuffering(JsonParser p) {
/*  562 */     return new TokenBuffer(p, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final TokenBuffer bufferForInputBuffering() {
/*  572 */     return bufferForInputBuffering(getParser());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenBuffer bufferAsCopyOfValue(JsonParser p) throws IOException {
/*  591 */     TokenBuffer buf = bufferForInputBuffering(p);
/*  592 */     buf.copyCurrentStructure(p);
/*  593 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasValueDeserializerFor(JavaType type, AtomicReference<Throwable> cause) {
/*      */     try {
/*  614 */       return this._cache.hasValueDeserializerFor(this, this._factory, type);
/*  615 */     } catch (DatabindException e) {
/*  616 */       if (cause != null) {
/*  617 */         cause.set(e);
/*      */       }
/*  619 */     } catch (RuntimeException e) {
/*  620 */       if (cause == null) {
/*  621 */         throw e;
/*      */       }
/*  623 */       cause.set(e);
/*      */     } 
/*  625 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonDeserializer<Object> findContextualValueDeserializer(JavaType type, BeanProperty prop) throws JsonMappingException {
/*  636 */     JsonDeserializer<Object> deser = this._cache.findValueDeserializer(this, this._factory, type);
/*  637 */     if (deser != null) {
/*  638 */       deser = (JsonDeserializer)handleSecondaryContextualization(deser, prop, type);
/*      */     }
/*  640 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonDeserializer<Object> findNonContextualValueDeserializer(JavaType type) throws JsonMappingException {
/*  659 */     return this._cache.findValueDeserializer(this, this._factory, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonDeserializer<Object> findRootValueDeserializer(JavaType type) throws JsonMappingException {
/*  669 */     JsonDeserializer<Object> deser = this._cache.findValueDeserializer(this, this._factory, type);
/*      */     
/*  671 */     if (deser == null) {
/*  672 */       return null;
/*      */     }
/*  674 */     deser = (JsonDeserializer)handleSecondaryContextualization(deser, (BeanProperty)null, type);
/*  675 */     TypeDeserializer typeDeser = this._factory.findTypeDeserializer(this._config, type);
/*  676 */     if (typeDeser != null) {
/*      */       
/*  678 */       typeDeser = typeDeser.forProperty(null);
/*  679 */       return (JsonDeserializer<Object>)new TypeWrappedDeserializer(typeDeser, deser);
/*      */     } 
/*  681 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final KeyDeserializer findKeyDeserializer(JavaType keyType, BeanProperty prop) throws JsonMappingException {
/*      */     KeyDeserializer kd;
/*      */     try {
/*  696 */       kd = this._cache.findKeyDeserializer(this, this._factory, keyType);
/*  697 */     } catch (IllegalArgumentException iae) {
/*      */ 
/*      */       
/*  700 */       reportBadDefinition(keyType, ClassUtil.exceptionMessage(iae));
/*  701 */       kd = null;
/*      */     } 
/*      */     
/*  704 */     if (kd instanceof ContextualKeyDeserializer) {
/*  705 */       kd = ((ContextualKeyDeserializer)kd).createContextual(this, prop);
/*      */     }
/*  707 */     return kd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void flushCachedDeserializers() {
/*  720 */     this._cache.flushCachedDeserializers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JavaType constructType(Class<?> cls) {
/*  757 */     return (cls == null) ? null : this._config.constructType(cls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?> findClass(String className) throws ClassNotFoundException {
/*  771 */     return getTypeFactory().findClass(className);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ObjectBuffer leaseObjectBuffer() {
/*  788 */     ObjectBuffer buf = this._objectBuffer;
/*  789 */     if (buf == null) {
/*  790 */       buf = new ObjectBuffer();
/*      */     } else {
/*  792 */       this._objectBuffer = null;
/*      */     } 
/*  794 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void returnObjectBuffer(ObjectBuffer buf) {
/*  807 */     if (this._objectBuffer == null || buf
/*  808 */       .initialCapacity() >= this._objectBuffer.initialCapacity()) {
/*  809 */       this._objectBuffer = buf;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ArrayBuilders getArrayBuilders() {
/*  819 */     if (this._arrayBuilders == null) {
/*  820 */       this._arrayBuilders = new ArrayBuilders();
/*      */     }
/*  822 */     return this._arrayBuilders;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<?> handlePrimaryContextualization(JsonDeserializer<?> deser, BeanProperty prop, JavaType type) throws JsonMappingException {
/*  861 */     if (deser instanceof ContextualDeserializer) {
/*  862 */       this._currentType = new LinkedNode(type, this._currentType);
/*      */       try {
/*  864 */         deser = ((ContextualDeserializer)deser).createContextual(this, prop);
/*      */       } finally {
/*  866 */         this._currentType = this._currentType.next();
/*      */       } 
/*      */     } 
/*  869 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<?> handleSecondaryContextualization(JsonDeserializer<?> deser, BeanProperty prop, JavaType type) throws JsonMappingException {
/*  892 */     if (deser instanceof ContextualDeserializer) {
/*  893 */       this._currentType = new LinkedNode(type, this._currentType);
/*      */       try {
/*  895 */         deser = ((ContextualDeserializer)deser).createContextual(this, prop);
/*      */       } finally {
/*  897 */         this._currentType = this._currentType.next();
/*      */       } 
/*      */     } 
/*  900 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date parseDate(String dateStr) throws IllegalArgumentException {
/*      */     try {
/*  922 */       DateFormat df = _getDateFormat();
/*  923 */       return df.parse(dateStr);
/*  924 */     } catch (ParseException e) {
/*  925 */       throw new IllegalArgumentException(String.format("Failed to parse Date value '%s': %s", new Object[] { dateStr, 
/*      */               
/*  927 */               ClassUtil.exceptionMessage(e) }));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Calendar constructCalendar(Date d) {
/*  937 */     Calendar c = Calendar.getInstance(getTimeZone());
/*  938 */     c.setTime(d);
/*  939 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String extractScalarFromObject(JsonParser p, JsonDeserializer<?> deser, Class<?> scalarType) throws IOException {
/*  971 */     return (String)handleUnexpectedToken(scalarType, p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, Class<T> type) throws IOException {
/*  992 */     return readValue(p, getTypeFactory().constructType(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, JavaType type) throws IOException {
/* 1000 */     JsonDeserializer<Object> deser = findRootValueDeserializer(type);
/* 1001 */     if (deser == null) {
/* 1002 */       return reportBadDefinition(type, "Could not find JsonDeserializer for type " + 
/* 1003 */           ClassUtil.getTypeDescription(type));
/*      */     }
/* 1005 */     return (T)_readValue(p, deser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readPropertyValue(JsonParser p, BeanProperty prop, Class<T> type) throws IOException {
/* 1021 */     return readPropertyValue(p, prop, getTypeFactory().constructType(type));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readPropertyValue(JsonParser p, BeanProperty prop, JavaType type) throws IOException {
/* 1033 */     JsonDeserializer<Object> deser = findContextualValueDeserializer(type, prop);
/* 1034 */     if (deser == null)
/* 1035 */       return reportBadDefinition(type, String.format("Could not find JsonDeserializer for type %s (via property %s)", new Object[] {
/*      */               
/* 1037 */               ClassUtil.getTypeDescription(type), ClassUtil.nameOf(prop)
/*      */             })); 
/* 1039 */     return (T)_readValue(p, deser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(JsonParser p) throws IOException {
/* 1053 */     JsonToken t = p.currentToken();
/* 1054 */     if (t == null) {
/* 1055 */       t = p.nextToken();
/* 1056 */       if (t == null) {
/* 1057 */         return getNodeFactory().missingNode();
/*      */       }
/*      */     } 
/* 1060 */     if (t == JsonToken.VALUE_NULL) {
/* 1061 */       return (JsonNode)getNodeFactory().nullNode();
/*      */     }
/* 1063 */     return (JsonNode)findRootValueDeserializer(this._config.constructType(JsonNode.class))
/* 1064 */       .deserialize(p, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readTreeAsValue(JsonNode n, Class<T> targetType) throws IOException {
/* 1090 */     if (n == null || n.isMissingNode()) {
/* 1091 */       return null;
/*      */     }
/* 1093 */     try (TreeTraversingParser p = _treeAsTokens(n)) {
/* 1094 */       return (T)readValue((JsonParser)p, (Class)targetType);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readTreeAsValue(JsonNode n, JavaType targetType) throws IOException {
/* 1114 */     if (n == null || n.isMissingNode()) {
/* 1115 */       return null;
/*      */     }
/* 1117 */     try (TreeTraversingParser p = _treeAsTokens(n)) {
/* 1118 */       return (T)readValue((JsonParser)p, targetType);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private TreeTraversingParser _treeAsTokens(JsonNode n) throws IOException {
/* 1125 */     ObjectCodec codec = (this._parser == null) ? null : this._parser.getCodec();
/* 1126 */     TreeTraversingParser p = new TreeTraversingParser(n, codec);
/*      */     
/* 1128 */     p.nextToken();
/* 1129 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object _readValue(JsonParser p, JsonDeserializer<Object> deser) throws IOException {
/* 1140 */     if (p.hasToken(JsonToken.VALUE_NULL)) {
/* 1141 */       return deser.getNullValue(this);
/*      */     }
/* 1143 */     return deser.deserialize(p, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean handleUnknownProperty(JsonParser p, JsonDeserializer<?> deser, Object instanceOrClass, String propName) throws IOException {
/* 1165 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1166 */     while (h != null) {
/*      */       
/* 1168 */       if (((DeserializationProblemHandler)h.value()).handleUnknownProperty(this, p, deser, instanceOrClass, propName)) {
/* 1169 */         return true;
/*      */       }
/* 1171 */       h = h.next();
/*      */     } 
/*      */     
/* 1174 */     if (!isEnabled(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)) {
/* 1175 */       p.skipChildren();
/* 1176 */       return true;
/*      */     } 
/*      */     
/* 1179 */     Collection<Object> propIds = (deser == null) ? null : deser.getKnownPropertyNames();
/* 1180 */     throw UnrecognizedPropertyException.from(this._parser, instanceOrClass, propName, propIds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleWeirdKey(Class<?> keyClass, String keyValue, String msg, Object... msgArgs) throws IOException {
/* 1208 */     msg = _format(msg, msgArgs);
/* 1209 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1210 */     while (h != null) {
/*      */       
/* 1212 */       Object key = ((DeserializationProblemHandler)h.value()).handleWeirdKey(this, keyClass, keyValue, msg);
/* 1213 */       if (key != DeserializationProblemHandler.NOT_HANDLED) {
/*      */         
/* 1215 */         if (key == null || keyClass.isInstance(key)) {
/* 1216 */           return key;
/*      */         }
/* 1218 */         throw weirdStringException(keyValue, keyClass, String.format("DeserializationProblemHandler.handleWeirdKey() for type %s returned value of type %s", new Object[] {
/*      */                 
/* 1220 */                 ClassUtil.getClassDescription(keyClass), 
/* 1221 */                 ClassUtil.getClassDescription(key)
/*      */               }));
/*      */       } 
/* 1224 */       h = h.next();
/*      */     } 
/* 1226 */     throw weirdKeyException(keyClass, keyValue, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleWeirdStringValue(Class<?> targetClass, String value, String msg, Object... msgArgs) throws IOException {
/* 1254 */     msg = _format(msg, msgArgs);
/* 1255 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1256 */     while (h != null) {
/*      */       
/* 1258 */       Object instance = ((DeserializationProblemHandler)h.value()).handleWeirdStringValue(this, targetClass, value, msg);
/* 1259 */       if (instance != DeserializationProblemHandler.NOT_HANDLED) {
/*      */         
/* 1261 */         if (_isCompatible(targetClass, instance)) {
/* 1262 */           return instance;
/*      */         }
/* 1264 */         throw weirdStringException(value, targetClass, String.format("DeserializationProblemHandler.handleWeirdStringValue() for type %s returned value of type %s", new Object[] {
/*      */                 
/* 1266 */                 ClassUtil.getClassDescription(targetClass), 
/* 1267 */                 ClassUtil.getClassDescription(instance)
/*      */               }));
/*      */       } 
/* 1270 */       h = h.next();
/*      */     } 
/* 1272 */     throw weirdStringException(value, targetClass, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleWeirdNumberValue(Class<?> targetClass, Number value, String msg, Object... msgArgs) throws IOException {
/* 1299 */     msg = _format(msg, msgArgs);
/* 1300 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1301 */     while (h != null) {
/*      */       
/* 1303 */       Object key = ((DeserializationProblemHandler)h.value()).handleWeirdNumberValue(this, targetClass, value, msg);
/* 1304 */       if (key != DeserializationProblemHandler.NOT_HANDLED) {
/*      */         
/* 1306 */         if (_isCompatible(targetClass, key)) {
/* 1307 */           return key;
/*      */         }
/* 1309 */         throw weirdNumberException(value, targetClass, _format("DeserializationProblemHandler.handleWeirdNumberValue() for type %s returned value of type %s", new Object[] {
/*      */                 
/* 1311 */                 ClassUtil.getClassDescription(targetClass), 
/* 1312 */                 ClassUtil.getClassDescription(key)
/*      */               }));
/*      */       } 
/* 1315 */       h = h.next();
/*      */     } 
/* 1317 */     throw weirdNumberException(value, targetClass, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleWeirdNativeValue(JavaType targetType, Object badValue, JsonParser p) throws IOException {
/* 1324 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1325 */     Class<?> raw = targetType.getRawClass();
/* 1326 */     for (; h != null; h = h.next()) {
/*      */       
/* 1328 */       Object goodValue = ((DeserializationProblemHandler)h.value()).handleWeirdNativeValue(this, targetType, badValue, p);
/* 1329 */       if (goodValue != DeserializationProblemHandler.NOT_HANDLED) {
/*      */         
/* 1331 */         if (goodValue == null || raw.isInstance(goodValue)) {
/* 1332 */           return goodValue;
/*      */         }
/* 1334 */         throw JsonMappingException.from(p, _format("DeserializationProblemHandler.handleWeirdNativeValue() for type %s returned value of type %s", new Object[] {
/*      */                 
/* 1336 */                 ClassUtil.getClassDescription(targetType), 
/* 1337 */                 ClassUtil.getClassDescription(goodValue)
/*      */               }));
/*      */       } 
/*      */     } 
/* 1341 */     throw weirdNativeValueException(badValue, raw);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleMissingInstantiator(Class<?> instClass, ValueInstantiator valueInst, JsonParser p, String msg, Object... msgArgs) throws IOException {
/* 1366 */     if (p == null) {
/* 1367 */       p = getParser();
/*      */     }
/* 1369 */     msg = _format(msg, msgArgs);
/* 1370 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1371 */     while (h != null) {
/*      */       
/* 1373 */       Object instance = ((DeserializationProblemHandler)h.value()).handleMissingInstantiator(this, instClass, valueInst, p, msg);
/*      */       
/* 1375 */       if (instance != DeserializationProblemHandler.NOT_HANDLED) {
/*      */         
/* 1377 */         if (_isCompatible(instClass, instance)) {
/* 1378 */           return instance;
/*      */         }
/* 1380 */         reportBadDefinition(constructType(instClass), String.format("DeserializationProblemHandler.handleMissingInstantiator() for type %s returned value of type %s", new Object[] {
/*      */                 
/* 1382 */                 ClassUtil.getClassDescription(instClass), 
/* 1383 */                 ClassUtil.getClassDescription(instance)
/*      */               }));
/*      */       } 
/* 1386 */       h = h.next();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1394 */     if (valueInst == null) {
/* 1395 */       msg = String.format("Cannot construct instance of %s: %s", new Object[] {
/* 1396 */             ClassUtil.nameOf(instClass), msg });
/* 1397 */       return reportBadDefinition(instClass, msg);
/*      */     } 
/* 1399 */     if (!valueInst.canInstantiate()) {
/* 1400 */       msg = String.format("Cannot construct instance of %s (no Creators, like default constructor, exist): %s", new Object[] {
/* 1401 */             ClassUtil.nameOf(instClass), msg });
/* 1402 */       return reportBadDefinition(instClass, msg);
/*      */     } 
/* 1404 */     msg = String.format("Cannot construct instance of %s (although at least one Creator exists): %s", new Object[] {
/* 1405 */           ClassUtil.nameOf(instClass), msg });
/* 1406 */     return reportInputMismatch(instClass, msg, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleInstantiationProblem(Class<?> instClass, Object argument, Throwable t) throws IOException {
/* 1430 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1431 */     while (h != null) {
/*      */       
/* 1433 */       Object instance = ((DeserializationProblemHandler)h.value()).handleInstantiationProblem(this, instClass, argument, t);
/* 1434 */       if (instance != DeserializationProblemHandler.NOT_HANDLED) {
/*      */         
/* 1436 */         if (_isCompatible(instClass, instance)) {
/* 1437 */           return instance;
/*      */         }
/* 1439 */         reportBadDefinition(constructType(instClass), String.format("DeserializationProblemHandler.handleInstantiationProblem() for type %s returned value of type %s", new Object[] {
/*      */                 
/* 1441 */                 ClassUtil.getClassDescription(instClass), 
/* 1442 */                 ClassUtil.classNameOf(instance)
/*      */               }));
/*      */       } 
/* 1445 */       h = h.next();
/*      */     } 
/*      */     
/* 1448 */     ClassUtil.throwIfIOE(t);
/*      */     
/* 1450 */     if (!isEnabled(DeserializationFeature.WRAP_EXCEPTIONS)) {
/* 1451 */       ClassUtil.throwIfRTE(t);
/*      */     }
/* 1453 */     throw instantiationException(instClass, t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleUnexpectedToken(Class<?> instClass, JsonParser p) throws IOException {
/* 1473 */     return handleUnexpectedToken(constructType(instClass), p.currentToken(), p, (String)null, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleUnexpectedToken(Class<?> instClass, JsonToken t, JsonParser p, String msg, Object... msgArgs) throws IOException {
/* 1495 */     return handleUnexpectedToken(constructType(instClass), t, p, msg, msgArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleUnexpectedToken(JavaType targetType, JsonParser p) throws IOException {
/* 1515 */     return handleUnexpectedToken(targetType, p.currentToken(), p, (String)null, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object handleUnexpectedToken(JavaType targetType, JsonToken t, JsonParser p, String msg, Object... msgArgs) throws IOException {
/* 1537 */     msg = _format(msg, msgArgs);
/* 1538 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1539 */     while (h != null) {
/* 1540 */       Object instance = ((DeserializationProblemHandler)h.value()).handleUnexpectedToken(this, targetType, t, p, msg);
/*      */       
/* 1542 */       if (instance != DeserializationProblemHandler.NOT_HANDLED) {
/* 1543 */         if (_isCompatible(targetType.getRawClass(), instance)) {
/* 1544 */           return instance;
/*      */         }
/* 1546 */         reportBadDefinition(targetType, String.format("DeserializationProblemHandler.handleUnexpectedToken() for type %s returned value of type %s", new Object[] {
/*      */                 
/* 1548 */                 ClassUtil.getTypeDescription(targetType), 
/* 1549 */                 ClassUtil.classNameOf(instance)
/*      */               }));
/*      */       } 
/* 1552 */       h = h.next();
/*      */     } 
/* 1554 */     if (msg == null) {
/* 1555 */       String targetDesc = ClassUtil.getTypeDescription(targetType);
/* 1556 */       if (t == null) {
/* 1557 */         msg = String.format("Unexpected end-of-input when trying read value of type %s", new Object[] { targetDesc });
/*      */       } else {
/*      */         
/* 1560 */         msg = String.format("Cannot deserialize value of type %s from %s (token `JsonToken.%s`)", new Object[] { targetDesc, 
/* 1561 */               _shapeForToken(t), t });
/*      */       } 
/*      */     } 
/*      */     
/* 1565 */     if (t != null && t.isScalarValue()) {
/* 1566 */       p.getText();
/*      */     }
/* 1568 */     reportInputMismatch(targetType, msg, new Object[0]);
/* 1569 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType handleUnknownTypeId(JavaType baseType, String id, TypeIdResolver idResolver, String extraDesc) throws IOException {
/* 1595 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1596 */     while (h != null) {
/*      */       
/* 1598 */       JavaType type = ((DeserializationProblemHandler)h.value()).handleUnknownTypeId(this, baseType, id, idResolver, extraDesc);
/* 1599 */       if (type != null) {
/* 1600 */         if (type.hasRawClass(Void.class)) {
/* 1601 */           return null;
/*      */         }
/*      */         
/* 1604 */         if (type.isTypeOrSubTypeOf(baseType.getRawClass())) {
/* 1605 */           return type;
/*      */         }
/* 1607 */         throw invalidTypeIdException(baseType, id, "problem handler tried to resolve into non-subtype: " + 
/*      */             
/* 1609 */             ClassUtil.getTypeDescription(type));
/*      */       } 
/* 1611 */       h = h.next();
/*      */     } 
/*      */     
/* 1614 */     if (!isEnabled(DeserializationFeature.FAIL_ON_INVALID_SUBTYPE)) {
/* 1615 */       return null;
/*      */     }
/* 1617 */     throw invalidTypeIdException(baseType, id, extraDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType handleMissingTypeId(JavaType baseType, TypeIdResolver idResolver, String extraDesc) throws IOException {
/* 1626 */     LinkedNode<DeserializationProblemHandler> h = this._config.getProblemHandlers();
/* 1627 */     while (h != null) {
/*      */       
/* 1629 */       JavaType type = ((DeserializationProblemHandler)h.value()).handleMissingTypeId(this, baseType, idResolver, extraDesc);
/* 1630 */       if (type != null) {
/* 1631 */         if (type.hasRawClass(Void.class)) {
/* 1632 */           return null;
/*      */         }
/*      */         
/* 1635 */         if (type.isTypeOrSubTypeOf(baseType.getRawClass())) {
/* 1636 */           return type;
/*      */         }
/* 1638 */         throw invalidTypeIdException(baseType, null, "problem handler tried to resolve into non-subtype: " + 
/*      */             
/* 1640 */             ClassUtil.getTypeDescription(type));
/*      */       } 
/* 1642 */       h = h.next();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1649 */     throw missingTypeIdException(baseType, extraDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void handleBadMerge(JsonDeserializer<?> deser) throws JsonMappingException {
/* 1665 */     if (!isEnabled(MapperFeature.IGNORE_MERGE_FOR_UNMERGEABLE)) {
/* 1666 */       JavaType type = constructType(deser.handledType());
/* 1667 */       String msg = String.format("Invalid configuration: values of type %s cannot be merged", new Object[] {
/* 1668 */             ClassUtil.getTypeDescription(type) });
/* 1669 */       throw InvalidDefinitionException.from(getParser(), msg, type);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _isCompatible(Class<?> target, Object value) {
/* 1678 */     if (value == null || target.isInstance(value)) {
/* 1679 */       return true;
/*      */     }
/*      */     
/* 1682 */     return (target.isPrimitive() && 
/* 1683 */       ClassUtil.wrapperType(target).isInstance(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reportWrongTokenException(JsonDeserializer<?> deser, JsonToken expToken, String msg, Object... msgArgs) throws JsonMappingException {
/* 1707 */     msg = _format(msg, msgArgs);
/* 1708 */     throw wrongTokenException(getParser(), deser.handledType(), expToken, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reportWrongTokenException(JavaType targetType, JsonToken expToken, String msg, Object... msgArgs) throws JsonMappingException {
/* 1725 */     msg = _format(msg, msgArgs);
/* 1726 */     throw wrongTokenException(getParser(), targetType, expToken, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void reportWrongTokenException(Class<?> targetType, JsonToken expToken, String msg, Object... msgArgs) throws JsonMappingException {
/* 1743 */     msg = _format(msg, msgArgs);
/* 1744 */     throw wrongTokenException(getParser(), targetType, expToken, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportUnresolvedObjectId(ObjectIdReader oidReader, Object bean) throws JsonMappingException {
/* 1753 */     String msg = String.format("No Object Id found for an instance of %s, to assign to property '%s'", new Object[] {
/* 1754 */           ClassUtil.classNameOf(bean), oidReader.propertyName });
/* 1755 */     return reportInputMismatch((BeanProperty)oidReader.idProperty, msg, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportInputMismatch(JsonDeserializer<?> src, String msg, Object... msgArgs) throws JsonMappingException {
/* 1767 */     msg = _format(msg, msgArgs);
/* 1768 */     throw MismatchedInputException.from(getParser(), src.handledType(), msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportInputMismatch(Class<?> targetType, String msg, Object... msgArgs) throws JsonMappingException {
/* 1780 */     msg = _format(msg, msgArgs);
/* 1781 */     throw MismatchedInputException.from(getParser(), targetType, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportInputMismatch(JavaType targetType, String msg, Object... msgArgs) throws JsonMappingException {
/* 1793 */     msg = _format(msg, msgArgs);
/* 1794 */     throw MismatchedInputException.from(getParser(), targetType, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportInputMismatch(BeanProperty prop, String msg, Object... msgArgs) throws JsonMappingException {
/* 1806 */     msg = _format(msg, msgArgs);
/* 1807 */     JavaType type = (prop == null) ? null : prop.getType();
/* 1808 */     MismatchedInputException e = MismatchedInputException.from(getParser(), type, msg);
/*      */     
/* 1810 */     if (prop != null) {
/* 1811 */       AnnotatedMember member = prop.getMember();
/* 1812 */       if (member != null) {
/* 1813 */         e.prependPath(member.getDeclaringClass(), prop.getName());
/*      */       }
/*      */     } 
/* 1816 */     throw e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportPropertyInputMismatch(Class<?> targetType, String propertyName, String msg, Object... msgArgs) throws JsonMappingException {
/* 1828 */     msg = _format(msg, msgArgs);
/* 1829 */     MismatchedInputException e = MismatchedInputException.from(getParser(), targetType, msg);
/* 1830 */     if (propertyName != null) {
/* 1831 */       e.prependPath(targetType, propertyName);
/*      */     }
/* 1833 */     throw e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportPropertyInputMismatch(JavaType targetType, String propertyName, String msg, Object... msgArgs) throws JsonMappingException {
/* 1845 */     return reportPropertyInputMismatch(targetType.getRawClass(), propertyName, msg, msgArgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportBadCoercion(JsonDeserializer<?> src, Class<?> targetType, Object inputValue, String msg, Object... msgArgs) throws JsonMappingException {
/* 1858 */     msg = _format(msg, msgArgs);
/* 1859 */     InvalidFormatException e = InvalidFormatException.from(getParser(), msg, inputValue, targetType);
/*      */     
/* 1861 */     throw e;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportTrailingTokens(Class<?> targetType, JsonParser p, JsonToken trailingToken) throws JsonMappingException {
/* 1867 */     throw MismatchedInputException.from(p, targetType, String.format("Trailing token (of type %s) found after value (bound as %s): not allowed as per `DeserializationFeature.FAIL_ON_TRAILING_TOKENS`", new Object[] { trailingToken, 
/*      */             
/* 1869 */             ClassUtil.nameOf(targetType) }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportBadTypeDefinition(BeanDescription bean, String msg, Object... msgArgs) throws JsonMappingException {
/* 1891 */     String beanDesc = ClassUtil.nameOf(bean.getBeanClass());
/* 1892 */     msg = String.format("Invalid type definition for type %s: %s", new Object[] { beanDesc, _format(msg, msgArgs) });
/* 1893 */     throw InvalidDefinitionException.from(this._parser, msg, bean, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T reportBadPropertyDefinition(BeanDescription bean, BeanPropertyDefinition prop, String msg, Object... msgArgs) throws JsonMappingException {
/* 1905 */     msg = _format(msg, msgArgs);
/* 1906 */     String propName = ClassUtil.nameOf((Named)prop);
/* 1907 */     String beanDesc = ClassUtil.nameOf(bean.getBeanClass());
/* 1908 */     msg = String.format("Invalid definition for property %s (of type %s): %s", new Object[] { propName, beanDesc, msg });
/*      */     
/* 1910 */     throw InvalidDefinitionException.from(this._parser, msg, bean, prop);
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T reportBadDefinition(JavaType type, String msg) throws JsonMappingException {
/* 1915 */     throw InvalidDefinitionException.from(this._parser, msg, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException wrongTokenException(JsonParser p, JavaType targetType, JsonToken expToken, String extra) {
/* 1938 */     String msg = String.format("Unexpected token (%s), expected %s", new Object[] { p
/* 1939 */           .currentToken(), expToken });
/* 1940 */     msg = _colonConcat(msg, extra);
/* 1941 */     return (JsonMappingException)MismatchedInputException.from(p, targetType, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException wrongTokenException(JsonParser p, Class<?> targetType, JsonToken expToken, String extra) {
/* 1947 */     String msg = String.format("Unexpected token (%s), expected %s", new Object[] { p
/* 1948 */           .currentToken(), expToken });
/* 1949 */     msg = _colonConcat(msg, extra);
/* 1950 */     return (JsonMappingException)MismatchedInputException.from(p, targetType, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException weirdKeyException(Class<?> keyClass, String keyValue, String msg) {
/* 1963 */     return (JsonMappingException)InvalidFormatException.from(this._parser, 
/* 1964 */         String.format("Cannot deserialize Map key of type %s from String %s: %s", new Object[] {
/* 1965 */             ClassUtil.nameOf(keyClass), _quotedString(keyValue), msg
/*      */           }), keyValue, keyClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException weirdStringException(String value, Class<?> instClass, String msgBase) {
/* 1984 */     String msg = String.format("Cannot deserialize value of type %s from String %s: %s", new Object[] {
/* 1985 */           ClassUtil.nameOf(instClass), _quotedString(value), msgBase });
/* 1986 */     return (JsonMappingException)InvalidFormatException.from(this._parser, msg, value, instClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException weirdNumberException(Number value, Class<?> instClass, String msg) {
/* 1998 */     return (JsonMappingException)InvalidFormatException.from(this._parser, 
/* 1999 */         String.format("Cannot deserialize value of type %s from number %s: %s", new Object[] {
/* 2000 */             ClassUtil.nameOf(instClass), String.valueOf(value), msg
/*      */           }), value, instClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException weirdNativeValueException(Object value, Class<?> instClass) {
/* 2016 */     return (JsonMappingException)InvalidFormatException.from(this._parser, String.format("Cannot deserialize value of type %s from native value (`JsonToken.VALUE_EMBEDDED_OBJECT`) of type %s: incompatible types", new Object[] {
/*      */             
/* 2018 */             ClassUtil.nameOf(instClass), ClassUtil.classNameOf(value)
/*      */           }), value, instClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException instantiationException(Class<?> instClass, Throwable cause) {
/*      */     String excMsg;
/* 2033 */     if (cause == null) {
/* 2034 */       excMsg = "N/A";
/* 2035 */     } else if ((excMsg = ClassUtil.exceptionMessage(cause)) == null) {
/* 2036 */       excMsg = ClassUtil.nameOf(cause.getClass());
/*      */     } 
/* 2038 */     String msg = String.format("Cannot construct instance of %s, problem: %s", new Object[] {
/* 2039 */           ClassUtil.nameOf(instClass), excMsg
/*      */         });
/*      */     
/* 2042 */     return (JsonMappingException)ValueInstantiationException.from(this._parser, msg, constructType(instClass), cause);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException instantiationException(Class<?> instClass, String msg0) {
/* 2057 */     return (JsonMappingException)ValueInstantiationException.from(this._parser, 
/* 2058 */         String.format("Cannot construct instance of %s: %s", new Object[] {
/* 2059 */             ClassUtil.nameOf(instClass), msg0
/* 2060 */           }), constructType(instClass));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException invalidTypeIdException(JavaType baseType, String typeId, String extraDesc) {
/* 2066 */     String msg = String.format("Could not resolve type id '%s' as a subtype of %s", new Object[] { typeId, 
/* 2067 */           ClassUtil.getTypeDescription(baseType) });
/* 2068 */     return (JsonMappingException)InvalidTypeIdException.from(this._parser, _colonConcat(msg, extraDesc), baseType, typeId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonMappingException missingTypeIdException(JavaType baseType, String extraDesc) {
/* 2076 */     String msg = String.format("Could not resolve subtype of %s", new Object[] { baseType });
/*      */     
/* 2078 */     return (JsonMappingException)InvalidTypeIdException.from(this._parser, _colonConcat(msg, extraDesc), baseType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DateFormat _getDateFormat() {
/* 2088 */     if (this._dateFormat != null) {
/* 2089 */       return this._dateFormat;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2096 */     DateFormat df = this._config.getDateFormat();
/* 2097 */     this._dateFormat = df = (DateFormat)df.clone();
/* 2098 */     return df;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _shapeForToken(JsonToken t) {
/* 2109 */     return JsonToken.valueDescFor(t);
/*      */   }
/*      */   
/*      */   public abstract ReadableObjectId findObjectId(Object paramObject, ObjectIdGenerator<?> paramObjectIdGenerator, ObjectIdResolver paramObjectIdResolver);
/*      */   
/*      */   public abstract void checkUnresolvedObjectId() throws UnresolvedForwardReference;
/*      */   
/*      */   public abstract JsonDeserializer<Object> deserializerInstance(Annotated paramAnnotated, Object paramObject) throws JsonMappingException;
/*      */   
/*      */   public abstract KeyDeserializer keyDeserializerInstance(Annotated paramAnnotated, Object paramObject) throws JsonMappingException;
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\DeserializationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */