/*      */ package com.fasterxml.jackson.databind;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.FormatFeature;
/*      */ import com.fasterxml.jackson.core.FormatSchema;
/*      */ import com.fasterxml.jackson.core.JacksonException;
/*      */ import com.fasterxml.jackson.core.JsonFactory;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonPointer;
/*      */ import com.fasterxml.jackson.core.JsonProcessingException;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.StreamReadFeature;
/*      */ import com.fasterxml.jackson.core.TreeNode;
/*      */ import com.fasterxml.jackson.core.Version;
/*      */ import com.fasterxml.jackson.core.Versioned;
/*      */ import com.fasterxml.jackson.core.exc.StreamReadException;
/*      */ import com.fasterxml.jackson.core.filter.FilteringParserDelegate;
/*      */ import com.fasterxml.jackson.core.filter.JsonPointerBasedFilter;
/*      */ import com.fasterxml.jackson.core.filter.TokenFilter;
/*      */ import com.fasterxml.jackson.core.type.ResolvedType;
/*      */ import com.fasterxml.jackson.core.type.TypeReference;
/*      */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*      */ import com.fasterxml.jackson.databind.cfg.PackageVersion;
/*      */ import com.fasterxml.jackson.databind.deser.DataFormatReaders;
/*      */ import com.fasterxml.jackson.databind.deser.DefaultDeserializationContext;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
/*      */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*      */ import com.fasterxml.jackson.databind.node.NullNode;
/*      */ import com.fasterxml.jackson.databind.node.TreeTraversingParser;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import java.io.DataInput;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Type;
/*      */ import java.net.URL;
/*      */ import java.util.Iterator;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ObjectReader
/*      */   extends ObjectCodec
/*      */   implements Versioned, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 2L;
/*      */   protected final DeserializationConfig _config;
/*      */   protected final DefaultDeserializationContext _context;
/*      */   protected final JsonFactory _parserFactory;
/*      */   protected final boolean _unwrapRoot;
/*      */   private final TokenFilter _filter;
/*      */   protected final JavaType _valueType;
/*      */   protected final JsonDeserializer<Object> _rootDeserializer;
/*      */   protected final Object _valueToUpdate;
/*      */   protected final FormatSchema _schema;
/*      */   protected final InjectableValues _injectableValues;
/*      */   protected final DataFormatReaders _dataFormatReaders;
/*      */   protected final ConcurrentHashMap<JavaType, JsonDeserializer<Object>> _rootDeserializers;
/*      */   protected transient JavaType _jsonNodeType;
/*      */   
/*      */   protected ObjectReader(ObjectMapper mapper, DeserializationConfig config) {
/*  172 */     this(mapper, config, null, null, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader(ObjectMapper mapper, DeserializationConfig config, JavaType valueType, Object valueToUpdate, FormatSchema schema, InjectableValues injectableValues) {
/*  183 */     this._config = config;
/*  184 */     this._context = mapper._deserializationContext;
/*  185 */     this._rootDeserializers = mapper._rootDeserializers;
/*  186 */     this._parserFactory = mapper._jsonFactory;
/*  187 */     this._valueType = valueType;
/*  188 */     this._valueToUpdate = valueToUpdate;
/*  189 */     this._schema = schema;
/*  190 */     this._injectableValues = injectableValues;
/*  191 */     this._unwrapRoot = config.useRootWrapping();
/*      */     
/*  193 */     this._rootDeserializer = _prefetchRootDeserializer(valueType);
/*  194 */     this._dataFormatReaders = null;
/*  195 */     this._filter = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader(ObjectReader base, DeserializationConfig config, JavaType valueType, JsonDeserializer<Object> rootDeser, Object valueToUpdate, FormatSchema schema, InjectableValues injectableValues, DataFormatReaders dataFormatReaders) {
/*  206 */     this._config = config;
/*  207 */     this._context = base._context;
/*      */     
/*  209 */     this._rootDeserializers = base._rootDeserializers;
/*  210 */     this._parserFactory = base._parserFactory;
/*      */     
/*  212 */     this._valueType = valueType;
/*  213 */     this._rootDeserializer = rootDeser;
/*  214 */     this._valueToUpdate = valueToUpdate;
/*  215 */     this._schema = schema;
/*  216 */     this._injectableValues = injectableValues;
/*  217 */     this._unwrapRoot = config.useRootWrapping();
/*  218 */     this._dataFormatReaders = dataFormatReaders;
/*  219 */     this._filter = base._filter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader(ObjectReader base, DeserializationConfig config) {
/*  227 */     this._config = config;
/*  228 */     this._context = base._context;
/*      */     
/*  230 */     this._rootDeserializers = base._rootDeserializers;
/*  231 */     this._parserFactory = base._parserFactory;
/*      */     
/*  233 */     this._valueType = base._valueType;
/*  234 */     this._rootDeserializer = base._rootDeserializer;
/*  235 */     this._valueToUpdate = base._valueToUpdate;
/*  236 */     this._schema = base._schema;
/*  237 */     this._injectableValues = base._injectableValues;
/*  238 */     this._unwrapRoot = config.useRootWrapping();
/*  239 */     this._dataFormatReaders = base._dataFormatReaders;
/*  240 */     this._filter = base._filter;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader(ObjectReader base, JsonFactory f) {
/*  246 */     this
/*  247 */       ._config = (DeserializationConfig)base._config.with(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, f.requiresPropertyOrdering());
/*  248 */     this._context = base._context;
/*      */     
/*  250 */     this._rootDeserializers = base._rootDeserializers;
/*  251 */     this._parserFactory = f;
/*      */     
/*  253 */     this._valueType = base._valueType;
/*  254 */     this._rootDeserializer = base._rootDeserializer;
/*  255 */     this._valueToUpdate = base._valueToUpdate;
/*  256 */     this._schema = base._schema;
/*  257 */     this._injectableValues = base._injectableValues;
/*  258 */     this._unwrapRoot = base._unwrapRoot;
/*  259 */     this._dataFormatReaders = base._dataFormatReaders;
/*  260 */     this._filter = base._filter;
/*      */   }
/*      */   
/*      */   protected ObjectReader(ObjectReader base, TokenFilter filter) {
/*  264 */     this._config = base._config;
/*  265 */     this._context = base._context;
/*  266 */     this._rootDeserializers = base._rootDeserializers;
/*  267 */     this._parserFactory = base._parserFactory;
/*  268 */     this._valueType = base._valueType;
/*  269 */     this._rootDeserializer = base._rootDeserializer;
/*  270 */     this._valueToUpdate = base._valueToUpdate;
/*  271 */     this._schema = base._schema;
/*  272 */     this._injectableValues = base._injectableValues;
/*  273 */     this._unwrapRoot = base._unwrapRoot;
/*  274 */     this._dataFormatReaders = base._dataFormatReaders;
/*  275 */     this._filter = filter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Version version() {
/*  284 */     return PackageVersion.VERSION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader _new(ObjectReader base, JsonFactory f) {
/*  301 */     return new ObjectReader(base, f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader _new(ObjectReader base, DeserializationConfig config) {
/*  310 */     return new ObjectReader(base, config);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader _new(ObjectReader base, DeserializationConfig config, JavaType valueType, JsonDeserializer<Object> rootDeser, Object valueToUpdate, FormatSchema schema, InjectableValues injectableValues, DataFormatReaders dataFormatReaders) {
/*  322 */     return new ObjectReader(base, config, valueType, rootDeser, valueToUpdate, schema, injectableValues, dataFormatReaders);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T> MappingIterator<T> _newIterator(JsonParser p, DeserializationContext ctxt, JsonDeserializer<?> deser, boolean parserManaged) {
/*  335 */     return new MappingIterator<>(this._valueType, p, ctxt, deser, parserManaged, this._valueToUpdate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _initForReading(DeserializationContext ctxt, JsonParser p) throws IOException {
/*  348 */     this._config.initialize(p, this._schema);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  354 */     JsonToken t = p.currentToken();
/*  355 */     if (t == null) {
/*  356 */       t = p.nextToken();
/*  357 */       if (t == null)
/*      */       {
/*  359 */         ctxt.reportInputMismatch(this._valueType, "No content to map due to end-of-input", new Object[0]);
/*      */       }
/*      */     } 
/*      */     
/*  363 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _initForMultiRead(DeserializationContext ctxt, JsonParser p) throws IOException {
/*  378 */     this._config.initialize(p, this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(DeserializationFeature feature) {
/*  392 */     return _with(this._config.with(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(DeserializationFeature first, DeserializationFeature... other) {
/*  402 */     return _with(this._config.with(first, other));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withFeatures(DeserializationFeature... features) {
/*  410 */     return _with(this._config.withFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader without(DeserializationFeature feature) {
/*  418 */     return _with(this._config.without(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader without(DeserializationFeature first, DeserializationFeature... other) {
/*  427 */     return _with(this._config.without(first, other));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withoutFeatures(DeserializationFeature... features) {
/*  435 */     return _with(this._config.withoutFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(DatatypeFeature feature) {
/*  451 */     return _with((DeserializationConfig)this._config.with(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withFeatures(DatatypeFeature... features) {
/*  461 */     return _with((DeserializationConfig)this._config.withFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader without(DatatypeFeature feature) {
/*  471 */     return _with((DeserializationConfig)this._config.without(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withoutFeatures(DatatypeFeature... features) {
/*  481 */     return _with((DeserializationConfig)this._config.withoutFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(JsonParser.Feature feature) {
/*  500 */     return _with(this._config.with(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withFeatures(JsonParser.Feature... features) {
/*  512 */     return _with(this._config.withFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader without(JsonParser.Feature feature) {
/*  524 */     return _with(this._config.without(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withoutFeatures(JsonParser.Feature... features) {
/*  536 */     return _with(this._config.withoutFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(StreamReadFeature feature) {
/*  554 */     return _with(this._config.with(feature.mappedFeature()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader without(StreamReadFeature feature) {
/*  566 */     return _with(this._config.without(feature.mappedFeature()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(FormatFeature feature) {
/*  582 */     return _with(this._config.with(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withFeatures(FormatFeature... features) {
/*  592 */     return _with(this._config.withFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader without(FormatFeature feature) {
/*  602 */     return _with(this._config.without(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withoutFeatures(FormatFeature... features) {
/*  612 */     return _with(this._config.withoutFeatures(features));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader at(String pointerExpr) {
/*  627 */     _assertNotNull("pointerExpr", pointerExpr);
/*  628 */     return new ObjectReader(this, (TokenFilter)new JsonPointerBasedFilter(pointerExpr));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader at(JsonPointer pointer) {
/*  637 */     _assertNotNull("pointer", pointer);
/*  638 */     return new ObjectReader(this, (TokenFilter)new JsonPointerBasedFilter(pointer));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(DeserializationConfig config) {
/*  649 */     return _with(config);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(InjectableValues injectableValues) {
/*  661 */     if (this._injectableValues == injectableValues) {
/*  662 */       return this;
/*      */     }
/*  664 */     return _new(this, this._config, this._valueType, this._rootDeserializer, this._valueToUpdate, this._schema, injectableValues, this._dataFormatReaders);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(JsonNodeFactory f) {
/*  678 */     return _with(this._config.with(f));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(JsonFactory f) {
/*  693 */     if (f == this._parserFactory) {
/*  694 */       return this;
/*      */     }
/*  696 */     ObjectReader r = _new(this, f);
/*      */     
/*  698 */     if (f.getCodec() == null) {
/*  699 */       f.setCodec(r);
/*      */     }
/*  701 */     return r;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withRootName(String rootName) {
/*  714 */     return _with((DeserializationConfig)this._config.withRootName(rootName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withRootName(PropertyName rootName) {
/*  721 */     return _with(this._config.withRootName(rootName));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withoutRootName() {
/*  735 */     return _with(this._config.withRootName(PropertyName.NO_NAME));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(FormatSchema schema) {
/*  748 */     if (this._schema == schema) {
/*  749 */       return this;
/*      */     }
/*  751 */     _verifySchemaType(schema);
/*  752 */     return _new(this, this._config, this._valueType, this._rootDeserializer, this._valueToUpdate, schema, this._injectableValues, this._dataFormatReaders);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader forType(JavaType valueType) {
/*  767 */     if (valueType != null && valueType.equals(this._valueType)) {
/*  768 */       return this;
/*      */     }
/*  770 */     JsonDeserializer<Object> rootDeser = _prefetchRootDeserializer(valueType);
/*      */     
/*  772 */     DataFormatReaders det = this._dataFormatReaders;
/*  773 */     if (det != null) {
/*  774 */       det = det.withType(valueType);
/*      */     }
/*  776 */     return _new(this, this._config, valueType, rootDeser, this._valueToUpdate, this._schema, this._injectableValues, det);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader forType(Class<?> valueType) {
/*  790 */     return forType(this._config.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader forType(Type valueType) {
/*  810 */     return forType(this._config.getTypeFactory().constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader forType(TypeReference<?> valueTypeRef) {
/*  823 */     return forType(this._config.getTypeFactory().constructType(valueTypeRef.getType()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectReader withType(JavaType valueType) {
/*  831 */     return forType(valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectReader withType(Class<?> valueType) {
/*  839 */     return forType(this._config.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectReader withType(Type valueType) {
/*  847 */     return forType(this._config.getTypeFactory().constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectReader withType(TypeReference<?> valueTypeRef) {
/*  855 */     return forType(this._config.getTypeFactory().constructType(valueTypeRef.getType()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withValueToUpdate(Object value) {
/*      */     JavaType t;
/*  868 */     if (value == this._valueToUpdate) return this; 
/*  869 */     if (value == null)
/*      */     {
/*      */       
/*  872 */       return _new(this, this._config, this._valueType, this._rootDeserializer, null, this._schema, this._injectableValues, this._dataFormatReaders);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  881 */     if (this._valueType == null) {
/*  882 */       t = this._config.constructType(value.getClass());
/*      */     } else {
/*  884 */       t = this._valueType;
/*      */     } 
/*  886 */     return _new(this, this._config, t, this._rootDeserializer, value, this._schema, this._injectableValues, this._dataFormatReaders);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withView(Class<?> activeView) {
/*  898 */     return _with(this._config.withView(activeView));
/*      */   }
/*      */   
/*      */   public ObjectReader with(Locale l) {
/*  902 */     return _with((DeserializationConfig)this._config.with(l));
/*      */   }
/*      */   
/*      */   public ObjectReader with(TimeZone tz) {
/*  906 */     return _with((DeserializationConfig)this._config.with(tz));
/*      */   }
/*      */   
/*      */   public ObjectReader withHandler(DeserializationProblemHandler h) {
/*  910 */     return _with(this._config.withHandler(h));
/*      */   }
/*      */   
/*      */   public ObjectReader with(Base64Variant defaultBase64) {
/*  914 */     return _with((DeserializationConfig)this._config.with(defaultBase64));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withFormatDetection(ObjectReader... readers) {
/*  940 */     return withFormatDetection(new DataFormatReaders(readers));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withFormatDetection(DataFormatReaders readers) {
/*  959 */     return _new(this, this._config, this._valueType, this._rootDeserializer, this._valueToUpdate, this._schema, this._injectableValues, readers);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader with(ContextAttributes attrs) {
/*  967 */     return _with(this._config.with(attrs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withAttributes(Map<?, ?> attrs) {
/*  974 */     return _with((DeserializationConfig)this._config.withAttributes(attrs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withAttribute(Object key, Object value) {
/*  981 */     return _with((DeserializationConfig)this._config.withAttribute(key, value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader withoutAttribute(Object key) {
/*  988 */     return _with((DeserializationConfig)this._config.withoutAttribute(key));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader _with(DeserializationConfig newConfig) {
/*  998 */     if (newConfig == this._config) {
/*  999 */       return this;
/*      */     }
/* 1001 */     ObjectReader r = _new(this, newConfig);
/* 1002 */     if (this._dataFormatReaders != null) {
/* 1003 */       r = r.withFormatDetection(this._dataFormatReaders.with(newConfig));
/*      */     }
/* 1005 */     return r;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(DeserializationFeature f) {
/* 1015 */     return this._config.isEnabled(f);
/*      */   }
/*      */   
/*      */   public boolean isEnabled(MapperFeature f) {
/* 1019 */     return this._config.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(DatatypeFeature f) {
/* 1026 */     return this._config.isEnabled(f);
/*      */   }
/*      */   
/*      */   public boolean isEnabled(JsonParser.Feature f) {
/* 1030 */     return this._config.isEnabled(f, this._parserFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(StreamReadFeature f) {
/* 1037 */     return this._config.isEnabled(f.mappedFeature(), this._parserFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig getConfig() {
/* 1044 */     return this._config;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory getFactory() {
/* 1052 */     return this._parserFactory;
/*      */   }
/*      */   
/*      */   public TypeFactory getTypeFactory() {
/* 1056 */     return this._config.getTypeFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ContextAttributes getAttributes() {
/* 1063 */     return this._config.getAttributes();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InjectableValues getInjectableValues() {
/* 1070 */     return this._injectableValues;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType getValueType() {
/* 1077 */     return this._valueType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(File src) throws IOException {
/* 1095 */     _assertNotNull("src", src);
/* 1096 */     return this._config.initialize(this._parserFactory.createParser(src), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(URL src) throws IOException {
/* 1108 */     _assertNotNull("src", src);
/* 1109 */     return this._config.initialize(this._parserFactory.createParser(src), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(InputStream in) throws IOException {
/* 1121 */     _assertNotNull("in", in);
/* 1122 */     return this._config.initialize(this._parserFactory.createParser(in), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(Reader r) throws IOException {
/* 1134 */     _assertNotNull("r", r);
/* 1135 */     return this._config.initialize(this._parserFactory.createParser(r), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(byte[] content) throws IOException {
/* 1147 */     _assertNotNull("content", content);
/* 1148 */     return this._config.initialize(this._parserFactory.createParser(content), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(byte[] content, int offset, int len) throws IOException {
/* 1160 */     _assertNotNull("content", content);
/* 1161 */     return this._config.initialize(this._parserFactory.createParser(content, offset, len), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(String content) throws IOException {
/* 1173 */     _assertNotNull("content", content);
/* 1174 */     return this._config.initialize(this._parserFactory.createParser(content), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(char[] content) throws IOException {
/* 1186 */     _assertNotNull("content", content);
/* 1187 */     return this._config.initialize(this._parserFactory.createParser(content), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(char[] content, int offset, int len) throws IOException {
/* 1199 */     _assertNotNull("content", content);
/* 1200 */     return this._config.initialize(this._parserFactory.createParser(content, offset, len), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(DataInput content) throws IOException {
/* 1212 */     _assertNotNull("content", content);
/* 1213 */     return this._config.initialize(this._parserFactory.createParser(content), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createNonBlockingByteArrayParser() throws IOException {
/* 1225 */     return this._config.initialize(this._parserFactory.createNonBlockingByteArrayParser(), this._schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p) throws IOException {
/* 1247 */     _assertNotNull("p", p);
/* 1248 */     return (T)_bind(p, this._valueToUpdate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, Class<T> valueType) throws IOException {
/* 1265 */     _assertNotNull("p", p);
/* 1266 */     return forType(valueType).readValue(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, TypeReference<T> valueTypeRef) throws IOException {
/* 1283 */     _assertNotNull("p", p);
/* 1284 */     return forType(valueTypeRef).readValue(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, ResolvedType valueType) throws IOException {
/* 1300 */     _assertNotNull("p", p);
/* 1301 */     return forType((JavaType)valueType).readValue(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, JavaType valueType) throws IOException {
/* 1312 */     _assertNotNull("p", p);
/* 1313 */     return forType(valueType).readValue(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> Iterator<T> readValues(JsonParser p, Class<T> valueType) throws IOException {
/* 1337 */     _assertNotNull("p", p);
/* 1338 */     return forType(valueType).readValues(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> Iterator<T> readValues(JsonParser p, TypeReference<T> valueTypeRef) throws IOException {
/* 1362 */     _assertNotNull("p", p);
/* 1363 */     return forType(valueTypeRef).readValues(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> Iterator<T> readValues(JsonParser p, ResolvedType valueType) throws IOException {
/* 1387 */     _assertNotNull("p", p);
/* 1388 */     return readValues(p, (JavaType)valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> Iterator<T> readValues(JsonParser p, JavaType valueType) throws IOException {
/* 1411 */     _assertNotNull("p", p);
/* 1412 */     return forType(valueType).readValues(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode createArrayNode() {
/* 1423 */     return (JsonNode)this._config.getNodeFactory().arrayNode();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode createObjectNode() {
/* 1428 */     return (JsonNode)this._config.getNodeFactory().objectNode();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode missingNode() {
/* 1433 */     return this._config.getNodeFactory().missingNode();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode nullNode() {
/* 1438 */     return (JsonNode)this._config.getNodeFactory().nullNode();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonParser treeAsTokens(TreeNode n) {
/* 1443 */     _assertNotNull("n", n);
/*      */ 
/*      */     
/* 1446 */     ObjectReader codec = withValueToUpdate(null);
/* 1447 */     return (JsonParser)new TreeTraversingParser((JsonNode)n, codec);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends TreeNode> T readTree(JsonParser p) throws IOException {
/* 1471 */     _assertNotNull("p", p);
/* 1472 */     return (T)_bindAsTreeOrNull(p);
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeTree(JsonGenerator g, TreeNode rootNode) {
/* 1477 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(InputStream src) throws IOException {
/* 1497 */     if (this._dataFormatReaders != null) {
/* 1498 */       return (T)_detectBindAndClose(this._dataFormatReaders.findFormat(src), false);
/*      */     }
/* 1500 */     return (T)_bindAndClose(_considerFilter(createParser(src), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(InputStream src, Class<T> valueType) throws IOException {
/* 1515 */     return forType(valueType).readValue(src);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(Reader src) throws IOException {
/* 1529 */     if (this._dataFormatReaders != null) {
/* 1530 */       _reportUndetectableSource(src);
/*      */     }
/* 1532 */     return (T)_bindAndClose(_considerFilter(createParser(src), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(Reader src, Class<T> valueType) throws IOException {
/* 1547 */     return forType(valueType).readValue(src);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(String src) throws JsonProcessingException, JsonMappingException {
/* 1561 */     if (this._dataFormatReaders != null) {
/* 1562 */       _reportUndetectableSource(src);
/*      */     }
/*      */     try {
/* 1565 */       return (T)_bindAndClose(_considerFilter(createParser(src), false));
/* 1566 */     } catch (JsonProcessingException e) {
/* 1567 */       throw e;
/* 1568 */     } catch (IOException e) {
/* 1569 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(String src, Class<T> valueType) throws IOException {
/* 1585 */     return forType(valueType).readValue(src);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] content) throws IOException {
/* 1599 */     if (this._dataFormatReaders != null) {
/* 1600 */       return (T)_detectBindAndClose(content, 0, content.length);
/*      */     }
/* 1602 */     return (T)_bindAndClose(_considerFilter(createParser(content), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] content, Class<T> valueType) throws IOException {
/* 1617 */     return forType(valueType).readValue(content);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] buffer, int offset, int length) throws IOException {
/* 1633 */     if (this._dataFormatReaders != null) {
/* 1634 */       return (T)_detectBindAndClose(buffer, offset, length);
/*      */     }
/* 1636 */     return (T)_bindAndClose(_considerFilter(createParser(buffer, offset, length), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] buffer, int offset, int length, Class<T> valueType) throws IOException {
/* 1654 */     return forType(valueType).readValue(buffer, offset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(File src) throws IOException {
/* 1668 */     if (this._dataFormatReaders != null) {
/* 1669 */       return (T)_detectBindAndClose(this._dataFormatReaders.findFormat(_inputStream(src)), true);
/*      */     }
/*      */     
/* 1672 */     return (T)_bindAndClose(_considerFilter(createParser(src), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(File src, Class<T> valueType) throws IOException {
/* 1687 */     return forType(valueType).readValue(src);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(URL src) throws IOException {
/* 1706 */     if (this._dataFormatReaders != null) {
/* 1707 */       return (T)_detectBindAndClose(this._dataFormatReaders.findFormat(_inputStream(src)), true);
/*      */     }
/* 1709 */     return (T)_bindAndClose(_considerFilter(createParser(src), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(URL src, Class<T> valueType) throws IOException {
/* 1724 */     return forType(valueType).readValue(src);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonNode content) throws IOException {
/* 1739 */     _assertNotNull("content", content);
/* 1740 */     if (this._dataFormatReaders != null) {
/* 1741 */       _reportUndetectableSource(content);
/*      */     }
/* 1743 */     return (T)_bindAndClose(_considerFilter(treeAsTokens(content), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonNode content, Class<T> valueType) throws IOException {
/* 1758 */     return forType(valueType).readValue(content);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(DataInput src) throws IOException {
/* 1764 */     if (this._dataFormatReaders != null) {
/* 1765 */       _reportUndetectableSource(src);
/*      */     }
/* 1767 */     return (T)_bindAndClose(_considerFilter(createParser(src), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(DataInput content, Class<T> valueType) throws IOException {
/* 1782 */     return forType(valueType).readValue(content);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(InputStream src) throws IOException {
/* 1810 */     if (this._dataFormatReaders != null) {
/* 1811 */       return _detectBindAndCloseAsTree(src);
/*      */     }
/* 1813 */     return _bindAndCloseAsTree(_considerFilter(createParser(src), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(Reader src) throws IOException {
/* 1822 */     if (this._dataFormatReaders != null) {
/* 1823 */       _reportUndetectableSource(src);
/*      */     }
/* 1825 */     return _bindAndCloseAsTree(_considerFilter(createParser(src), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(String json) throws JsonProcessingException, JsonMappingException {
/* 1834 */     if (this._dataFormatReaders != null) {
/* 1835 */       _reportUndetectableSource(json);
/*      */     }
/*      */     try {
/* 1838 */       return _bindAndCloseAsTree(_considerFilter(createParser(json), false));
/* 1839 */     } catch (JsonProcessingException e) {
/* 1840 */       throw e;
/* 1841 */     } catch (IOException e) {
/* 1842 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(byte[] json) throws IOException {
/* 1852 */     _assertNotNull("json", json);
/* 1853 */     if (this._dataFormatReaders != null) {
/* 1854 */       _reportUndetectableSource(json);
/*      */     }
/* 1856 */     return _bindAndCloseAsTree(_considerFilter(createParser(json), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(byte[] json, int offset, int len) throws IOException {
/* 1865 */     if (this._dataFormatReaders != null) {
/* 1866 */       _reportUndetectableSource(json);
/*      */     }
/* 1868 */     return _bindAndCloseAsTree(_considerFilter(createParser(json, offset, len), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(DataInput src) throws IOException {
/* 1877 */     if (this._dataFormatReaders != null) {
/* 1878 */       _reportUndetectableSource(src);
/*      */     }
/* 1880 */     return _bindAndCloseAsTree(_considerFilter(createParser(src), false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(JsonParser p) throws IOException {
/* 1902 */     _assertNotNull("p", p);
/* 1903 */     DefaultDeserializationContext defaultDeserializationContext = createDeserializationContext(p);
/*      */     
/* 1905 */     return _newIterator(p, (DeserializationContext)defaultDeserializationContext, _findRootDeserializer((DeserializationContext)defaultDeserializationContext), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(InputStream src) throws IOException {
/* 1930 */     if (this._dataFormatReaders != null) {
/* 1931 */       return _detectBindAndReadValues(this._dataFormatReaders.findFormat(src), false);
/*      */     }
/*      */     
/* 1934 */     return _bindAndReadValues(_considerFilter(createParser(src), true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(Reader src) throws IOException {
/* 1942 */     if (this._dataFormatReaders != null) {
/* 1943 */       _reportUndetectableSource(src);
/*      */     }
/* 1945 */     JsonParser p = _considerFilter(createParser(src), true);
/* 1946 */     DefaultDeserializationContext defaultDeserializationContext = createDeserializationContext(p);
/* 1947 */     _initForMultiRead((DeserializationContext)defaultDeserializationContext, p);
/* 1948 */     p.nextToken();
/* 1949 */     return _newIterator(p, (DeserializationContext)defaultDeserializationContext, _findRootDeserializer((DeserializationContext)defaultDeserializationContext), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(String json) throws IOException {
/* 1959 */     if (this._dataFormatReaders != null) {
/* 1960 */       _reportUndetectableSource(json);
/*      */     }
/* 1962 */     JsonParser p = _considerFilter(createParser(json), true);
/* 1963 */     DefaultDeserializationContext defaultDeserializationContext = createDeserializationContext(p);
/* 1964 */     _initForMultiRead((DeserializationContext)defaultDeserializationContext, p);
/* 1965 */     p.nextToken();
/* 1966 */     return _newIterator(p, (DeserializationContext)defaultDeserializationContext, _findRootDeserializer((DeserializationContext)defaultDeserializationContext), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(byte[] src, int offset, int length) throws IOException {
/* 1974 */     if (this._dataFormatReaders != null) {
/* 1975 */       return _detectBindAndReadValues(this._dataFormatReaders.findFormat(src, offset, length), false);
/*      */     }
/* 1977 */     return _bindAndReadValues(_considerFilter(createParser(src, offset, length), true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <T> MappingIterator<T> readValues(byte[] src) throws IOException {
/* 1985 */     _assertNotNull("src", src);
/* 1986 */     return readValues(src, 0, src.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(File src) throws IOException {
/* 1994 */     if (this._dataFormatReaders != null) {
/* 1995 */       return _detectBindAndReadValues(this._dataFormatReaders
/* 1996 */           .findFormat(_inputStream(src)), false);
/*      */     }
/* 1998 */     return _bindAndReadValues(_considerFilter(createParser(src), true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(URL src) throws IOException {
/* 2014 */     if (this._dataFormatReaders != null) {
/* 2015 */       return _detectBindAndReadValues(this._dataFormatReaders
/* 2016 */           .findFormat(_inputStream(src)), true);
/*      */     }
/* 2018 */     return _bindAndReadValues(_considerFilter(createParser(src), true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(DataInput src) throws IOException {
/* 2026 */     if (this._dataFormatReaders != null) {
/* 2027 */       _reportUndetectableSource(src);
/*      */     }
/* 2029 */     return _bindAndReadValues(_considerFilter(createParser(src), true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T treeToValue(TreeNode n, Class<T> valueType) throws JsonProcessingException {
/* 2041 */     _assertNotNull("n", n);
/*      */     try {
/* 2043 */       return readValue(treeAsTokens(n), valueType);
/* 2044 */     } catch (JsonProcessingException e) {
/* 2045 */       throw e;
/* 2046 */     } catch (IOException e) {
/* 2047 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T treeToValue(TreeNode n, JavaType valueType) throws JsonProcessingException {
/* 2058 */     _assertNotNull("n", n);
/*      */     try {
/* 2060 */       return readValue(treeAsTokens(n), valueType);
/* 2061 */     } catch (JsonProcessingException e) {
/* 2062 */       throw e;
/* 2063 */     } catch (IOException e) {
/* 2064 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeValue(JsonGenerator gen, Object value) throws IOException {
/* 2070 */     throw new UnsupportedOperationException("Not implemented for ObjectReader");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _bind(JsonParser p, Object valueToUpdate) throws IOException {
/*      */     Object result;
/* 2087 */     DefaultDeserializationContext ctxt = createDeserializationContext(p);
/* 2088 */     JsonToken t = _initForReading((DeserializationContext)ctxt, p);
/* 2089 */     if (t == JsonToken.VALUE_NULL) {
/* 2090 */       if (valueToUpdate == null) {
/* 2091 */         result = _findRootDeserializer((DeserializationContext)ctxt).getNullValue((DeserializationContext)ctxt);
/*      */       } else {
/* 2093 */         result = valueToUpdate;
/*      */       } 
/* 2095 */     } else if (t == JsonToken.END_ARRAY || t == JsonToken.END_OBJECT) {
/* 2096 */       result = valueToUpdate;
/* 2097 */     } else if (t == JsonToken.NOT_AVAILABLE) {
/*      */       
/* 2099 */       result = valueToUpdate;
/*      */     } else {
/* 2101 */       result = ctxt.readRootValue(p, this._valueType, _findRootDeserializer((DeserializationContext)ctxt), this._valueToUpdate);
/*      */     } 
/*      */     
/* 2104 */     p.clearCurrentToken();
/* 2105 */     if (this._config.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 2106 */       _verifyNoTrailingTokens(p, (DeserializationContext)ctxt, this._valueType);
/*      */     }
/* 2108 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Object _bindAndClose(JsonParser p0) throws IOException {
/* 2113 */     try (JsonParser p = p0) {
/*      */       Object result;
/*      */       
/* 2116 */       DefaultDeserializationContext ctxt = createDeserializationContext(p);
/* 2117 */       JsonToken t = _initForReading((DeserializationContext)ctxt, p);
/* 2118 */       if (t == JsonToken.VALUE_NULL) {
/* 2119 */         if (this._valueToUpdate == null) {
/* 2120 */           result = _findRootDeserializer((DeserializationContext)ctxt).getNullValue((DeserializationContext)ctxt);
/*      */         } else {
/* 2122 */           result = this._valueToUpdate;
/*      */         } 
/* 2124 */       } else if (t == JsonToken.END_ARRAY || t == JsonToken.END_OBJECT) {
/* 2125 */         result = this._valueToUpdate;
/* 2126 */       } else if (t == JsonToken.NOT_AVAILABLE) {
/*      */         
/* 2128 */         result = this._valueToUpdate;
/*      */       } else {
/* 2130 */         result = ctxt.readRootValue(p, this._valueType, _findRootDeserializer((DeserializationContext)ctxt), this._valueToUpdate);
/*      */       } 
/*      */       
/* 2133 */       if (this._config.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 2134 */         _verifyNoTrailingTokens(p, (DeserializationContext)ctxt, this._valueType);
/*      */       }
/* 2136 */       return result;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected final JsonNode _bindAndCloseAsTree(JsonParser p0) throws IOException {
/* 2141 */     try (JsonParser p = p0) {
/* 2142 */       return _bindAsTree(p);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonNode _bindAsTree(JsonParser p) throws IOException {
/*      */     JsonNode resultNode;
/* 2150 */     if (this._valueToUpdate != null) {
/* 2151 */       return (JsonNode)_bind(p, this._valueToUpdate);
/*      */     }
/*      */ 
/*      */     
/* 2155 */     this._config.initialize(p);
/* 2156 */     if (this._schema != null) {
/* 2157 */       p.setSchema(this._schema);
/*      */     }
/*      */     
/* 2160 */     JsonToken t = p.currentToken();
/* 2161 */     if (t == null) {
/* 2162 */       t = p.nextToken();
/* 2163 */       if (t == null) {
/* 2164 */         return this._config.getNodeFactory().missingNode();
/*      */       }
/*      */     } 
/* 2167 */     DefaultDeserializationContext ctxt = createDeserializationContext(p);
/*      */ 
/*      */     
/* 2170 */     if (t == JsonToken.VALUE_NULL) {
/* 2171 */       NullNode nullNode = this._config.getNodeFactory().nullNode();
/*      */     } else {
/*      */       
/* 2174 */       resultNode = (JsonNode)ctxt.readRootValue(p, _jsonNodeType(), _findTreeDeserializer((DeserializationContext)ctxt), null);
/*      */     } 
/*      */     
/* 2177 */     p.clearCurrentToken();
/* 2178 */     if (this._config.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 2179 */       _verifyNoTrailingTokens(p, (DeserializationContext)ctxt, _jsonNodeType());
/*      */     }
/* 2181 */     return resultNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonNode _bindAsTreeOrNull(JsonParser p) throws IOException {
/*      */     JsonNode resultNode;
/* 2192 */     if (this._valueToUpdate != null) {
/* 2193 */       return (JsonNode)_bind(p, this._valueToUpdate);
/*      */     }
/*      */ 
/*      */     
/* 2197 */     this._config.initialize(p);
/* 2198 */     if (this._schema != null) {
/* 2199 */       p.setSchema(this._schema);
/*      */     }
/* 2201 */     JsonToken t = p.currentToken();
/* 2202 */     if (t == null) {
/* 2203 */       t = p.nextToken();
/* 2204 */       if (t == null) {
/* 2205 */         return null;
/*      */       }
/*      */     } 
/* 2208 */     DefaultDeserializationContext ctxt = createDeserializationContext(p);
/*      */     
/* 2210 */     if (t == JsonToken.VALUE_NULL) {
/* 2211 */       NullNode nullNode = this._config.getNodeFactory().nullNode();
/*      */     } else {
/*      */       
/* 2214 */       resultNode = (JsonNode)ctxt.readRootValue(p, _jsonNodeType(), _findTreeDeserializer((DeserializationContext)ctxt), null);
/*      */     } 
/*      */     
/* 2217 */     p.clearCurrentToken();
/* 2218 */     if (this._config.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 2219 */       _verifyNoTrailingTokens(p, (DeserializationContext)ctxt, _jsonNodeType());
/*      */     }
/* 2221 */     return resultNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T> MappingIterator<T> _bindAndReadValues(JsonParser p) throws IOException {
/* 2229 */     DefaultDeserializationContext defaultDeserializationContext = createDeserializationContext(p);
/* 2230 */     _initForMultiRead((DeserializationContext)defaultDeserializationContext, p);
/* 2231 */     p.nextToken();
/* 2232 */     return _newIterator(p, (DeserializationContext)defaultDeserializationContext, _findRootDeserializer((DeserializationContext)defaultDeserializationContext), true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _considerFilter(JsonParser p, boolean multiValue) {
/* 2241 */     return (this._filter == null || FilteringParserDelegate.class.isInstance(p)) ? p : (JsonParser)new FilteringParserDelegate(p, this._filter, TokenFilter.Inclusion.ONLY_INCLUDE_ALL, multiValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _verifyNoTrailingTokens(JsonParser p, DeserializationContext ctxt, JavaType bindType) throws IOException {
/* 2252 */     JsonToken t = p.nextToken();
/* 2253 */     if (t != null) {
/* 2254 */       Class<?> bt = ClassUtil.rawClass(bindType);
/* 2255 */       if (bt == null && 
/* 2256 */         this._valueToUpdate != null) {
/* 2257 */         bt = this._valueToUpdate.getClass();
/*      */       }
/*      */       
/* 2260 */       ctxt.reportTrailingTokens(bt, p, t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _detectBindAndClose(byte[] src, int offset, int length) throws IOException {
/* 2272 */     DataFormatReaders.Match match = this._dataFormatReaders.findFormat(src, offset, length);
/* 2273 */     if (!match.hasMatch()) {
/* 2274 */       _reportUnkownFormat(this._dataFormatReaders, match);
/*      */     }
/* 2276 */     JsonParser p = match.createParserWithMatch();
/* 2277 */     return match.getReader()._bindAndClose(p);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _detectBindAndClose(DataFormatReaders.Match match, boolean forceClosing) throws IOException {
/* 2283 */     if (!match.hasMatch()) {
/* 2284 */       _reportUnkownFormat(this._dataFormatReaders, match);
/*      */     }
/* 2286 */     JsonParser p = match.createParserWithMatch();
/*      */ 
/*      */     
/* 2289 */     if (forceClosing) {
/* 2290 */       p.enable(JsonParser.Feature.AUTO_CLOSE_SOURCE);
/*      */     }
/*      */     
/* 2293 */     return match.getReader()._bindAndClose(p);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T> MappingIterator<T> _detectBindAndReadValues(DataFormatReaders.Match match, boolean forceClosing) throws IOException {
/* 2299 */     if (!match.hasMatch()) {
/* 2300 */       _reportUnkownFormat(this._dataFormatReaders, match);
/*      */     }
/* 2302 */     JsonParser p = match.createParserWithMatch();
/*      */ 
/*      */     
/* 2305 */     if (forceClosing) {
/* 2306 */       p.enable(JsonParser.Feature.AUTO_CLOSE_SOURCE);
/*      */     }
/*      */     
/* 2309 */     return match.getReader()._bindAndReadValues(p);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonNode _detectBindAndCloseAsTree(InputStream in) throws IOException {
/* 2314 */     DataFormatReaders.Match match = this._dataFormatReaders.findFormat(in);
/* 2315 */     if (!match.hasMatch()) {
/* 2316 */       _reportUnkownFormat(this._dataFormatReaders, match);
/*      */     }
/* 2318 */     JsonParser p = match.createParserWithMatch();
/* 2319 */     p.enable(JsonParser.Feature.AUTO_CLOSE_SOURCE);
/* 2320 */     return match.getReader()._bindAndCloseAsTree(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportUnkownFormat(DataFormatReaders detector, DataFormatReaders.Match match) throws IOException {
/* 2331 */     throw new JsonParseException(null, "Cannot detect format from input, does not look like any of detectable formats " + detector
/* 2332 */         .toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _verifySchemaType(FormatSchema schema) {
/* 2346 */     if (schema != null && 
/* 2347 */       !this._parserFactory.canUseSchema(schema)) {
/* 2348 */       throw new IllegalArgumentException("Cannot use FormatSchema of type " + schema.getClass().getName() + " for format " + this._parserFactory
/* 2349 */           .getFormatName());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DefaultDeserializationContext createDeserializationContext(JsonParser p) {
/* 2360 */     return this._context.createInstance(this._config, p, this._injectableValues);
/*      */   }
/*      */ 
/*      */   
/*      */   protected DefaultDeserializationContext createDummyDeserializationContext() {
/* 2365 */     return this._context.createDummyInstance(this._config);
/*      */   }
/*      */   
/*      */   protected InputStream _inputStream(URL src) throws IOException {
/* 2369 */     return src.openStream();
/*      */   }
/*      */   
/*      */   protected InputStream _inputStream(File f) throws IOException {
/* 2373 */     return new FileInputStream(f);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportUndetectableSource(Object src) throws StreamReadException {
/* 2379 */     throw new JsonParseException(null, "Cannot use source of type " + src
/* 2380 */         .getClass().getName() + " with format auto-detection: must be byte- not char-based");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> _findRootDeserializer(DeserializationContext ctxt) throws DatabindException {
/* 2395 */     if (this._rootDeserializer != null) {
/* 2396 */       return this._rootDeserializer;
/*      */     }
/*      */ 
/*      */     
/* 2400 */     JavaType t = this._valueType;
/* 2401 */     if (t == null) {
/* 2402 */       ctxt.reportBadDefinition((JavaType)null, "No value type configured for ObjectReader");
/*      */     }
/*      */ 
/*      */     
/* 2406 */     JsonDeserializer<Object> deser = this._rootDeserializers.get(t);
/* 2407 */     if (deser != null) {
/* 2408 */       return deser;
/*      */     }
/*      */     
/* 2411 */     deser = ctxt.findRootValueDeserializer(t);
/* 2412 */     if (deser == null) {
/* 2413 */       ctxt.reportBadDefinition(t, "Cannot find a deserializer for type " + t);
/*      */     }
/* 2415 */     this._rootDeserializers.put(t, deser);
/* 2416 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> _findTreeDeserializer(DeserializationContext ctxt) throws DatabindException {
/* 2425 */     JavaType nodeType = _jsonNodeType();
/* 2426 */     JsonDeserializer<Object> deser = this._rootDeserializers.get(nodeType);
/* 2427 */     if (deser == null) {
/*      */       
/* 2429 */       deser = ctxt.findRootValueDeserializer(nodeType);
/* 2430 */       if (deser == null) {
/* 2431 */         ctxt.reportBadDefinition(nodeType, "Cannot find a deserializer for type " + nodeType);
/*      */       }
/*      */       
/* 2434 */       this._rootDeserializers.put(nodeType, deser);
/*      */     } 
/* 2436 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> _prefetchRootDeserializer(JavaType valueType) {
/* 2446 */     if (valueType == null || !this._config.isEnabled(DeserializationFeature.EAGER_DESERIALIZER_FETCH)) {
/* 2447 */       return null;
/*      */     }
/*      */     
/* 2450 */     JsonDeserializer<Object> deser = this._rootDeserializers.get(valueType);
/* 2451 */     if (deser == null) {
/*      */       
/*      */       try {
/* 2454 */         DefaultDeserializationContext defaultDeserializationContext = createDummyDeserializationContext();
/* 2455 */         deser = defaultDeserializationContext.findRootValueDeserializer(valueType);
/* 2456 */         if (deser != null) {
/* 2457 */           this._rootDeserializers.put(valueType, deser);
/*      */         }
/* 2459 */         return deser;
/* 2460 */       } catch (JacksonException jacksonException) {}
/*      */     }
/*      */ 
/*      */     
/* 2464 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JavaType _jsonNodeType() {
/* 2471 */     JavaType t = this._jsonNodeType;
/* 2472 */     if (t == null) {
/* 2473 */       t = getTypeFactory().constructType(JsonNode.class);
/* 2474 */       this._jsonNodeType = t;
/*      */     } 
/* 2476 */     return t;
/*      */   }
/*      */   
/*      */   protected final void _assertNotNull(String paramName, Object src) {
/* 2480 */     if (src == null)
/* 2481 */       throw new IllegalArgumentException(String.format("argument \"%s\" is null", new Object[] { paramName })); 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ObjectReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */