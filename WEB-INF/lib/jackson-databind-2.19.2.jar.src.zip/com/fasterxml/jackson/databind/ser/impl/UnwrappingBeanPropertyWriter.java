/*     */ package com.fasterxml.jackson.databind.ser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import com.fasterxml.jackson.core.io.SerializedString;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonObjectFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import com.fasterxml.jackson.databind.ser.BeanPropertyWriter;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnwrappingBeanPropertyWriter
/*     */   extends BeanPropertyWriter
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final NameTransformer _nameTransformer;
/*     */   
/*     */   public UnwrappingBeanPropertyWriter(BeanPropertyWriter base, NameTransformer unwrapper) {
/*  42 */     super(base);
/*  43 */     this._nameTransformer = unwrapper;
/*     */   }
/*     */ 
/*     */   
/*     */   protected UnwrappingBeanPropertyWriter(UnwrappingBeanPropertyWriter base, NameTransformer transformer, SerializedString name) {
/*  48 */     super(base, name);
/*  49 */     this._nameTransformer = transformer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UnwrappingBeanPropertyWriter rename(NameTransformer transformer) {
/*  55 */     String oldName = this._name.getValue();
/*  56 */     String newName = transformer.transform(oldName);
/*     */ 
/*     */     
/*  59 */     transformer = NameTransformer.chainedTransformer(transformer, this._nameTransformer);
/*     */     
/*  61 */     return _new(transformer, new SerializedString(newName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UnwrappingBeanPropertyWriter _new(NameTransformer transformer, SerializedString newName) {
/*  71 */     return new UnwrappingBeanPropertyWriter(this, transformer, newName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUnwrapping() {
/*  82 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeAsField(Object bean, JsonGenerator gen, SerializerProvider prov) throws Exception {
/*  89 */     Object value = get(bean);
/*  90 */     if (value == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  95 */     JsonSerializer<Object> ser = this._serializer;
/*  96 */     if (ser == null) {
/*  97 */       Class<?> cls = value.getClass();
/*  98 */       PropertySerializerMap map = this._dynamicSerializers;
/*  99 */       ser = map.serializerFor(cls);
/* 100 */       if (ser == null) {
/* 101 */         ser = _findAndAddDynamic(map, cls, prov);
/*     */       }
/*     */     } 
/* 104 */     if (this._suppressableValue != null) {
/* 105 */       if (MARKER_FOR_EMPTY == this._suppressableValue) {
/* 106 */         if (ser.isEmpty(prov, value)) {
/*     */           return;
/*     */         }
/* 109 */       } else if (this._suppressableValue.equals(value)) {
/*     */         return;
/*     */       } 
/*     */     }
/*     */     
/* 114 */     if (value == bean && 
/* 115 */       _handleSelfReference(bean, gen, prov, ser)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 121 */     if (!ser.isUnwrappingSerializer()) {
/* 122 */       gen.writeFieldName((SerializableString)this._name);
/*     */     }
/*     */     
/* 125 */     if (this._typeSerializer == null) {
/* 126 */       ser.serialize(value, gen, prov);
/*     */     } else {
/* 128 */       ser.serializeWithType(value, gen, prov, this._typeSerializer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void assignSerializer(JsonSerializer<Object> ser) {
/* 136 */     if (ser != null) {
/* 137 */       NameTransformer t = this._nameTransformer;
/* 138 */       if (ser.isUnwrappingSerializer() && ser instanceof UnwrappingBeanSerializer)
/*     */       {
/*     */ 
/*     */         
/* 142 */         t = NameTransformer.chainedTransformer(t, ((UnwrappingBeanSerializer)ser)._nameTransformer);
/*     */       }
/* 144 */       ser = ser.unwrappingSerializer(t);
/*     */     } 
/* 146 */     super.assignSerializer(ser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void depositSchemaProperty(final JsonObjectFormatVisitor visitor, SerializerProvider provider) throws JsonMappingException {
/* 161 */     JsonSerializer<Object> ser = provider.findValueSerializer(getType(), (BeanProperty)this).unwrappingSerializer(this._nameTransformer);
/*     */     
/* 163 */     if (ser.isUnwrappingSerializer()) {
/* 164 */       ser.acceptJsonFormatVisitor((JsonFormatVisitorWrapper)new JsonFormatVisitorWrapper.Base(provider)
/*     */           {
/*     */ 
/*     */             
/*     */             public JsonObjectFormatVisitor expectObjectFormat(JavaType type) throws JsonMappingException
/*     */             {
/* 170 */               return visitor;
/*     */             }
/* 172 */           }getType());
/*     */     } else {
/* 174 */       super.depositSchemaProperty(visitor, provider);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _depositSchemaProperty(ObjectNode propertiesNode, JsonNode schemaNode) {
/* 182 */     JsonNode props = schemaNode.get("properties");
/* 183 */     if (props != null) {
/* 184 */       for (Map.Entry<String, JsonNode> entry : (Iterable<Map.Entry<String, JsonNode>>)props.properties()) {
/* 185 */         String name = entry.getKey();
/* 186 */         if (this._nameTransformer != null) {
/* 187 */           name = this._nameTransformer.transform(name);
/*     */         }
/* 189 */         propertiesNode.set(name, entry.getValue());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<Object> _findAndAddDynamic(PropertySerializerMap map, Class<?> type, SerializerProvider provider) throws JsonMappingException {
/* 206 */     if (this._nonTrivialBaseType != null) {
/* 207 */       JavaType subtype = provider.constructSpecializedType(this._nonTrivialBaseType, type);
/* 208 */       serializer = provider.findValueSerializer(subtype, (BeanProperty)this);
/*     */     } else {
/* 210 */       serializer = provider.findValueSerializer(type, (BeanProperty)this);
/*     */     } 
/* 212 */     NameTransformer t = this._nameTransformer;
/* 213 */     if (serializer.isUnwrappingSerializer() && serializer instanceof UnwrappingBeanSerializer)
/*     */     {
/*     */ 
/*     */       
/* 217 */       t = NameTransformer.chainedTransformer(t, ((UnwrappingBeanSerializer)serializer)._nameTransformer);
/*     */     }
/* 219 */     JsonSerializer<Object> serializer = serializer.unwrappingSerializer(t);
/*     */     
/* 221 */     this._dynamicSerializers = this._dynamicSerializers.newWith(type, serializer);
/* 222 */     return serializer;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\impl\UnwrappingBeanPropertyWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */