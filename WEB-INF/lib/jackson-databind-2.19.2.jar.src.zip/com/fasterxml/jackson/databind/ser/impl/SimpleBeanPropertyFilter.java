/*     */ package com.fasterxml.jackson.databind.ser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonObjectFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import com.fasterxml.jackson.databind.ser.AnyGetterWriter;
/*     */ import com.fasterxml.jackson.databind.ser.BeanPropertyFilter;
/*     */ import com.fasterxml.jackson.databind.ser.BeanPropertyWriter;
/*     */ import com.fasterxml.jackson.databind.ser.PropertyFilter;
/*     */ import com.fasterxml.jackson.databind.ser.PropertyWriter;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleBeanPropertyFilter
/*     */   implements BeanPropertyFilter, PropertyFilter
/*     */ {
/*     */   public static SimpleBeanPropertyFilter serializeAll() {
/*  41 */     return SerializeExceptFilter.INCLUDE_ALL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SimpleBeanPropertyFilter filterOutAll() {
/*  51 */     return FilterExceptFilter.EXCLUDE_ALL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static SimpleBeanPropertyFilter serializeAll(Set<String> properties) {
/*  63 */     return new FilterExceptFilter(properties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SimpleBeanPropertyFilter filterOutAllExcept(Set<String> properties) {
/*  71 */     return new FilterExceptFilter(properties);
/*     */   }
/*     */   
/*     */   public static SimpleBeanPropertyFilter filterOutAllExcept(String... propertyArray) {
/*  75 */     HashSet<String> properties = new HashSet<>(propertyArray.length);
/*  76 */     Collections.addAll(properties, propertyArray);
/*  77 */     return new FilterExceptFilter(properties);
/*     */   }
/*     */   
/*     */   public static SimpleBeanPropertyFilter serializeAllExcept(Set<String> properties) {
/*  81 */     return new SerializeExceptFilter(properties);
/*     */   }
/*     */   
/*     */   public static SimpleBeanPropertyFilter serializeAllExcept(String... propertyArray) {
/*  85 */     HashSet<String> properties = new HashSet<>(propertyArray.length);
/*  86 */     Collections.addAll(properties, propertyArray);
/*  87 */     return new SerializeExceptFilter(properties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyFilter from(final BeanPropertyFilter src) {
/*  98 */     return new PropertyFilter()
/*     */       {
/*     */         
/*     */         public void serializeAsField(Object pojo, JsonGenerator jgen, SerializerProvider prov, PropertyWriter writer) throws Exception
/*     */         {
/* 103 */           src.serializeAsField(pojo, jgen, prov, (BeanPropertyWriter)writer);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void depositSchemaProperty(PropertyWriter writer, ObjectNode propertiesNode, SerializerProvider provider) throws JsonMappingException {
/* 110 */           src.depositSchemaProperty((BeanPropertyWriter)writer, propertiesNode, provider);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void depositSchemaProperty(PropertyWriter writer, JsonObjectFormatVisitor objectVisitor, SerializerProvider provider) throws JsonMappingException {
/* 117 */           src.depositSchemaProperty((BeanPropertyWriter)writer, objectVisitor, provider);
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void serializeAsElement(Object elementValue, JsonGenerator jgen, SerializerProvider prov, PropertyWriter writer) throws Exception {
/* 125 */           throw new UnsupportedOperationException();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean include(BeanPropertyWriter writer) {
/* 142 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean include(PropertyWriter writer) {
/* 152 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean includeElement(Object elementValue) {
/* 163 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void serializeAsField(Object bean, JsonGenerator jgen, SerializerProvider provider, BeanPropertyWriter writer) throws Exception {
/* 177 */     if (include(writer)) {
/* 178 */       writer.serializeAsField(bean, jgen, provider);
/* 179 */     } else if (!jgen.canOmitFields()) {
/* 180 */       writer.serializeAsOmittedField(bean, jgen, provider);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void depositSchemaProperty(BeanPropertyWriter writer, ObjectNode propertiesNode, SerializerProvider provider) throws JsonMappingException {
/* 190 */     if (include(writer)) {
/* 191 */       writer.depositSchemaProperty(propertiesNode, provider);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void depositSchemaProperty(BeanPropertyWriter writer, JsonObjectFormatVisitor objectVisitor, SerializerProvider provider) throws JsonMappingException {
/* 201 */     if (include(writer)) {
/* 202 */       writer.depositSchemaProperty(objectVisitor, provider);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeAsField(Object pojo, JsonGenerator jgen, SerializerProvider provider, PropertyWriter writer) throws Exception {
/* 217 */     if (include(writer)) {
/* 218 */       writer.serializeAsField(pojo, jgen, provider);
/* 219 */     } else if (!jgen.canOmitFields()) {
/* 220 */       writer.serializeAsOmittedField(pojo, jgen, provider);
/* 221 */     } else if (writer instanceof AnyGetterWriter) {
/* 222 */       ((AnyGetterWriter)writer).getAndFilter(pojo, jgen, provider, this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeAsElement(Object elementValue, JsonGenerator jgen, SerializerProvider provider, PropertyWriter writer) throws Exception {
/* 231 */     if (includeElement(elementValue)) {
/* 232 */       writer.serializeAsElement(elementValue, jgen, provider);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void depositSchemaProperty(PropertyWriter writer, ObjectNode propertiesNode, SerializerProvider provider) throws JsonMappingException {
/* 242 */     if (include(writer)) {
/* 243 */       writer.depositSchemaProperty(propertiesNode, provider);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void depositSchemaProperty(PropertyWriter writer, JsonObjectFormatVisitor objectVisitor, SerializerProvider provider) throws JsonMappingException {
/* 252 */     if (include(writer)) {
/* 253 */       writer.depositSchemaProperty(objectVisitor, provider);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FilterExceptFilter
/*     */     extends SimpleBeanPropertyFilter
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 273 */     static final FilterExceptFilter EXCLUDE_ALL = new FilterExceptFilter(Collections.emptySet());
/*     */ 
/*     */     
/*     */     protected final Set<String> _propertiesToInclude;
/*     */ 
/*     */ 
/*     */     
/*     */     public FilterExceptFilter(Set<String> properties) {
/* 281 */       this._propertiesToInclude = properties;
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean include(BeanPropertyWriter writer) {
/* 286 */       return this._propertiesToInclude.contains(writer.getName());
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean include(PropertyWriter writer) {
/* 291 */       return this._propertiesToInclude.contains(writer.getName());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class SerializeExceptFilter
/*     */     extends SimpleBeanPropertyFilter
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/* 305 */     static final SerializeExceptFilter INCLUDE_ALL = new SerializeExceptFilter(Collections.emptySet());
/*     */ 
/*     */     
/*     */     protected final Set<String> _propertiesToExclude;
/*     */ 
/*     */ 
/*     */     
/*     */     public SerializeExceptFilter(Set<String> properties) {
/* 313 */       this._propertiesToExclude = properties;
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean include(BeanPropertyWriter writer) {
/* 318 */       return !this._propertiesToExclude.contains(writer.getName());
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean include(PropertyWriter writer) {
/* 323 */       return !this._propertiesToExclude.contains(writer.getName());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\impl\SimpleBeanPropertyFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */