/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonValueFormat;
/*     */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*     */ import com.fasterxml.jackson.databind.util.StdDateFormat;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DateTimeSerializerBase<T>
/*     */   extends StdScalarSerializer<T>
/*     */   implements ContextualSerializer
/*     */ {
/*     */   protected final Boolean _useTimestamp;
/*     */   protected final DateFormat _customFormat;
/*     */   protected final AtomicReference<DateFormat> _reusedCustomFormat;
/*     */   
/*     */   protected DateTimeSerializerBase(Class<T> type, Boolean useTimestamp, DateFormat customFormat) {
/*  52 */     super(type);
/*  53 */     this._useTimestamp = useTimestamp;
/*  54 */     this._customFormat = customFormat;
/*  55 */     this._reusedCustomFormat = (customFormat == null) ? null : new AtomicReference<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract DateTimeSerializerBase<T> withFormat(Boolean paramBoolean, DateFormat paramDateFormat);
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> createContextual(SerializerProvider serializers, BeanProperty property) throws JsonMappingException {
/*  66 */     JsonFormat.Value format = findFormatOverrides(serializers, property, handledType());
/*  67 */     if (format == null) {
/*  68 */       return this;
/*     */     }
/*     */     
/*  71 */     JsonFormat.Shape shape = format.getShape();
/*  72 */     if (shape.isNumeric()) {
/*  73 */       return withFormat(Boolean.TRUE, (DateFormat)null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  78 */     if (format.hasPattern()) {
/*     */ 
/*     */       
/*  81 */       Locale loc = format.hasLocale() ? format.getLocale() : serializers.getLocale();
/*  82 */       SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format.getPattern(), loc);
/*     */       
/*  84 */       TimeZone tz = format.hasTimeZone() ? format.getTimeZone() : serializers.getTimeZone();
/*  85 */       simpleDateFormat.setTimeZone(tz);
/*  86 */       return withFormat(Boolean.FALSE, simpleDateFormat);
/*     */     } 
/*     */ 
/*     */     
/*  90 */     boolean hasLocale = format.hasLocale();
/*  91 */     boolean hasTZ = format.hasTimeZone();
/*  92 */     boolean asString = (shape == JsonFormat.Shape.STRING);
/*     */     
/*  94 */     if (!hasLocale && !hasTZ && !asString) {
/*  95 */       return this;
/*     */     }
/*     */     
/*  98 */     DateFormat df0 = serializers.getConfig().getDateFormat();
/*     */     
/* 100 */     if (df0 instanceof StdDateFormat) {
/* 101 */       StdDateFormat std = (StdDateFormat)df0;
/* 102 */       if (format.hasLocale()) {
/* 103 */         std = std.withLocale(format.getLocale());
/*     */       }
/* 105 */       if (format.hasTimeZone()) {
/* 106 */         std = std.withTimeZone(format.getTimeZone());
/*     */       }
/* 108 */       return withFormat(Boolean.FALSE, (DateFormat)std);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     if (!(df0 instanceof SimpleDateFormat)) {
/* 115 */       serializers.reportBadDefinition(handledType(), String.format("Configured `DateFormat` (%s) not a `SimpleDateFormat`; cannot configure `Locale` or `TimeZone`", new Object[] { df0
/*     */               
/* 117 */               .getClass().getName() }));
/*     */     }
/* 119 */     SimpleDateFormat df = (SimpleDateFormat)df0;
/* 120 */     if (hasLocale) {
/*     */       
/* 122 */       df = new SimpleDateFormat(df.toPattern(), format.getLocale());
/*     */     } else {
/* 124 */       df = (SimpleDateFormat)df.clone();
/*     */     } 
/* 126 */     TimeZone newTz = format.getTimeZone();
/* 127 */     boolean changeTZ = (newTz != null && !newTz.equals(df.getTimeZone()));
/* 128 */     if (changeTZ) {
/* 129 */       df.setTimeZone(newTz);
/*     */     }
/* 131 */     return withFormat(Boolean.FALSE, df);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty(SerializerProvider serializers, T value) {
/* 145 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract long _timestamp(T paramT);
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonNode getSchema(SerializerProvider serializers, Type typeHint) {
/* 157 */     return (JsonNode)createSchemaNode(_asTimestamp(serializers) ? "number" : "string", true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 163 */     _acceptJsonFormatVisitor(visitor, typeHint, _asTimestamp(visitor.getProvider()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void serialize(T paramT, JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _asTimestamp(SerializerProvider serializers) {
/* 184 */     if (this._useTimestamp != null) {
/* 185 */       return this._useTimestamp.booleanValue();
/*     */     }
/* 187 */     if (this._customFormat == null) {
/* 188 */       if (serializers != null) {
/* 189 */         return serializers.isEnabled(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
/*     */       }
/*     */       
/* 192 */       throw new IllegalArgumentException("Null SerializerProvider passed for " + handledType().getName());
/*     */     } 
/* 194 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint, boolean asNumber) throws JsonMappingException {
/* 200 */     if (asNumber) {
/* 201 */       visitIntFormat(visitor, typeHint, JsonParser.NumberType.LONG, JsonValueFormat.UTC_MILLISEC);
/*     */     } else {
/*     */       
/* 204 */       visitStringFormat(visitor, typeHint, JsonValueFormat.DATE_TIME);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _serializeAsString(Date value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 213 */     if (this._customFormat == null) {
/* 214 */       provider.defaultSerializeDateValue(value, g);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 225 */     DateFormat f = this._reusedCustomFormat.getAndSet(null);
/* 226 */     if (f == null) {
/* 227 */       f = (DateFormat)this._customFormat.clone();
/*     */     }
/* 229 */     g.writeString(f.format(value));
/* 230 */     this._reusedCustomFormat.compareAndSet(null, f);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\DateTimeSerializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */