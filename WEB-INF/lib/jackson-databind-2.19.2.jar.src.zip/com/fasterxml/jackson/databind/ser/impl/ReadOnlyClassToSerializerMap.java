/*     */ package com.fasterxml.jackson.databind.ser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.util.LookupCache;
/*     */ import com.fasterxml.jackson.databind.util.TypeKey;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadOnlyClassToSerializerMap
/*     */ {
/*     */   private final Bucket[] _buckets;
/*     */   private final int _size;
/*     */   private final int _mask;
/*     */   
/*     */   public ReadOnlyClassToSerializerMap(LookupCache<TypeKey, JsonSerializer<Object>> src) {
/*  27 */     this._size = findSize(src.size());
/*  28 */     this._mask = this._size - 1;
/*  29 */     Bucket[] buckets = new Bucket[this._size];
/*  30 */     src.contents((key, value) -> {
/*     */           int index = key.hashCode() & this._mask;
/*     */           buckets[index] = new Bucket(buckets[index], key, value);
/*     */         });
/*  34 */     this._buckets = buckets;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int findSize(int size) {
/*  40 */     int needed = (size <= 64) ? (size + size) : (size + (size >> 2));
/*  41 */     int result = 8;
/*  42 */     while (result < needed) {
/*  43 */       result += result;
/*     */     }
/*  45 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReadOnlyClassToSerializerMap from(LookupCache<TypeKey, JsonSerializer<Object>> src) {
/*  52 */     return new ReadOnlyClassToSerializerMap(src);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  61 */     return this._size;
/*     */   }
/*     */   
/*     */   public JsonSerializer<Object> typedValueSerializer(JavaType type) {
/*  65 */     Bucket bucket = this._buckets[TypeKey.typedHash(type) & this._mask];
/*  66 */     if (bucket == null) {
/*  67 */       return null;
/*     */     }
/*  69 */     if (bucket.matchesTyped(type)) {
/*  70 */       return bucket.value;
/*     */     }
/*  72 */     while ((bucket = bucket.next) != null) {
/*  73 */       if (bucket.matchesTyped(type)) {
/*  74 */         return bucket.value;
/*     */       }
/*     */     } 
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> typedValueSerializer(Class<?> type) {
/*  82 */     Bucket bucket = this._buckets[TypeKey.typedHash(type) & this._mask];
/*  83 */     if (bucket == null) {
/*  84 */       return null;
/*     */     }
/*  86 */     if (bucket.matchesTyped(type)) {
/*  87 */       return bucket.value;
/*     */     }
/*  89 */     while ((bucket = bucket.next) != null) {
/*  90 */       if (bucket.matchesTyped(type)) {
/*  91 */         return bucket.value;
/*     */       }
/*     */     } 
/*  94 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> untypedValueSerializer(JavaType type) {
/*  99 */     Bucket bucket = this._buckets[TypeKey.untypedHash(type) & this._mask];
/* 100 */     if (bucket == null) {
/* 101 */       return null;
/*     */     }
/* 103 */     if (bucket.matchesUntyped(type)) {
/* 104 */       return bucket.value;
/*     */     }
/* 106 */     while ((bucket = bucket.next) != null) {
/* 107 */       if (bucket.matchesUntyped(type)) {
/* 108 */         return bucket.value;
/*     */       }
/*     */     } 
/* 111 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> untypedValueSerializer(Class<?> type) {
/* 116 */     Bucket bucket = this._buckets[TypeKey.untypedHash(type) & this._mask];
/* 117 */     if (bucket == null) {
/* 118 */       return null;
/*     */     }
/* 120 */     if (bucket.matchesUntyped(type)) {
/* 121 */       return bucket.value;
/*     */     }
/* 123 */     while ((bucket = bucket.next) != null) {
/* 124 */       if (bucket.matchesUntyped(type)) {
/* 125 */         return bucket.value;
/*     */       }
/*     */     } 
/* 128 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Bucket
/*     */   {
/*     */     public final JsonSerializer<Object> value;
/*     */ 
/*     */     
/*     */     public final Bucket next;
/*     */ 
/*     */     
/*     */     protected final Class<?> _class;
/*     */     
/*     */     protected final JavaType _type;
/*     */     
/*     */     protected final boolean _isTyped;
/*     */ 
/*     */     
/*     */     public Bucket(Bucket next, TypeKey key, JsonSerializer<Object> value) {
/* 149 */       this.next = next;
/* 150 */       this.value = value;
/* 151 */       this._isTyped = key.isTyped();
/* 152 */       this._class = key.getRawType();
/* 153 */       this._type = key.getType();
/*     */     }
/*     */     
/*     */     public boolean matchesTyped(Class<?> key) {
/* 157 */       return (this._class == key && this._isTyped);
/*     */     }
/*     */     
/*     */     public boolean matchesUntyped(Class<?> key) {
/* 161 */       return (this._class == key && !this._isTyped);
/*     */     }
/*     */     
/*     */     public boolean matchesTyped(JavaType key) {
/* 165 */       return (this._isTyped && key.equals(this._type));
/*     */     }
/*     */     
/*     */     public boolean matchesUntyped(JavaType key) {
/* 169 */       return (!this._isTyped && key.equals(this._type));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\impl\ReadOnlyClassToSerializerMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */