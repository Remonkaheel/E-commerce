/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonschema.JsonSchema;
/*     */ import com.fasterxml.jackson.databind.jsonschema.SchemaAware;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import com.fasterxml.jackson.databind.ser.ContainerSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.impl.PropertySerializerMap;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AsArraySerializerBase<T>
/*     */   extends ContainerSerializer<T>
/*     */   implements ContextualSerializer
/*     */ {
/*     */   protected final JavaType _elementType;
/*     */   protected final BeanProperty _property;
/*     */   protected final boolean _staticTyping;
/*     */   protected final Boolean _unwrapSingle;
/*     */   protected final TypeSerializer _valueTypeSerializer;
/*     */   protected final JsonSerializer<Object> _elementSerializer;
/*     */   protected PropertySerializerMap _dynamicSerializers;
/*     */   
/*     */   protected AsArraySerializerBase(Class<?> cls, JavaType et, boolean staticTyping, TypeSerializer vts, JsonSerializer<Object> elementSerializer) {
/*  79 */     this(cls, et, staticTyping, vts, (BeanProperty)null, elementSerializer, (Boolean)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected AsArraySerializerBase(Class<?> cls, JavaType et, boolean staticTyping, TypeSerializer vts, BeanProperty property, JsonSerializer<Object> elementSerializer) {
/*  90 */     this(cls, et, staticTyping, vts, property, elementSerializer, (Boolean)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AsArraySerializerBase(Class<?> cls, JavaType elementType, boolean staticTyping, TypeSerializer vts, BeanProperty property, JsonSerializer<?> elementSerializer, Boolean unwrapSingle) {
/* 104 */     super(cls, false);
/* 105 */     this._elementType = elementType;
/*     */     
/* 107 */     this._staticTyping = (staticTyping || (elementType != null && elementType.isFinal()));
/* 108 */     this._valueTypeSerializer = vts;
/* 109 */     this._property = property;
/* 110 */     this._elementSerializer = (JsonSerializer)elementSerializer;
/* 111 */     this._dynamicSerializers = PropertySerializerMap.emptyForProperties();
/* 112 */     this._unwrapSingle = unwrapSingle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AsArraySerializerBase(AsArraySerializerBase<?> src, BeanProperty property, TypeSerializer vts, JsonSerializer<?> elementSerializer, Boolean unwrapSingle) {
/* 120 */     super(src);
/* 121 */     this._elementType = src._elementType;
/* 122 */     this._staticTyping = src._staticTyping;
/* 123 */     this._valueTypeSerializer = vts;
/* 124 */     this._property = property;
/* 125 */     this._elementSerializer = (JsonSerializer)elementSerializer;
/*     */     
/* 127 */     this._dynamicSerializers = PropertySerializerMap.emptyForProperties();
/* 128 */     this._unwrapSingle = unwrapSingle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected AsArraySerializerBase(AsArraySerializerBase<?> src, BeanProperty property, TypeSerializer vts, JsonSerializer<?> elementSerializer) {
/* 138 */     this(src, property, vts, elementSerializer, src._unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final AsArraySerializerBase<T> withResolved(BeanProperty property, TypeSerializer vts, JsonSerializer<?> elementSerializer) {
/* 147 */     return withResolved(property, vts, elementSerializer, this._unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract AsArraySerializerBase<T> withResolved(BeanProperty paramBeanProperty, TypeSerializer paramTypeSerializer, JsonSerializer<?> paramJsonSerializer, Boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> createContextual(SerializerProvider serializers, BeanProperty property) throws JsonMappingException {
/* 174 */     TypeSerializer typeSer = this._valueTypeSerializer;
/* 175 */     if (typeSer != null) {
/* 176 */       typeSer = typeSer.forProperty(property);
/*     */     }
/* 178 */     JsonSerializer<?> ser = null;
/* 179 */     Boolean unwrapSingle = null;
/*     */ 
/*     */     
/* 182 */     if (property != null) {
/* 183 */       AnnotationIntrospector intr = serializers.getAnnotationIntrospector();
/* 184 */       AnnotatedMember m = property.getMember();
/* 185 */       if (m != null) {
/* 186 */         Object serDef = intr.findContentSerializer((Annotated)m);
/* 187 */         if (serDef != null) {
/* 188 */           ser = serializers.serializerInstance((Annotated)m, serDef);
/*     */         }
/*     */       } 
/*     */     } 
/* 192 */     JsonFormat.Value format = findFormatOverrides(serializers, property, handledType());
/* 193 */     if (format != null) {
/* 194 */       unwrapSingle = format.getFeature(JsonFormat.Feature.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED);
/*     */     }
/* 196 */     if (ser == null) {
/* 197 */       ser = this._elementSerializer;
/*     */     }
/*     */     
/* 200 */     ser = findContextualConvertingSerializer(serializers, property, ser);
/* 201 */     if (ser == null)
/*     */     {
/*     */       
/* 204 */       if (this._elementType != null && 
/* 205 */         this._staticTyping && !this._elementType.isJavaLangObject()) {
/* 206 */         ser = serializers.findContentValueSerializer(this._elementType, property);
/*     */       }
/*     */     }
/*     */     
/* 210 */     if (ser != this._elementSerializer || property != this._property || this._valueTypeSerializer != typeSer || 
/*     */ 
/*     */       
/* 213 */       !Objects.equals(this._unwrapSingle, unwrapSingle)) {
/* 214 */       return (JsonSerializer<?>)withResolved(property, typeSer, ser, unwrapSingle);
/*     */     }
/* 216 */     return (JsonSerializer<?>)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType getContentType() {
/* 227 */     return this._elementType;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> getContentSerializer() {
/* 232 */     return this._elementSerializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(T value, JsonGenerator gen, SerializerProvider provider) throws IOException {
/* 247 */     if (provider.isEnabled(SerializationFeature.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED) && 
/* 248 */       hasSingleElement(value)) {
/* 249 */       serializeContents(value, gen, provider);
/*     */       return;
/*     */     } 
/* 252 */     gen.writeStartArray(value);
/* 253 */     serializeContents(value, gen, provider);
/* 254 */     gen.writeEndArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeWithType(T value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/* 261 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/* 262 */         .typeId(value, JsonToken.START_ARRAY));
/*     */     
/* 264 */     g.assignCurrentValue(value);
/* 265 */     serializeContents(value, g, provider);
/* 266 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void serializeContents(T paramT, JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint) throws JsonMappingException {
/* 280 */     ObjectNode o = createSchemaNode("array", true);
/* 281 */     if (this._elementSerializer != null) {
/* 282 */       JsonNode schemaNode = null;
/* 283 */       if (this._elementSerializer instanceof SchemaAware)
/*     */       {
/* 285 */         schemaNode = ((SchemaAware)this._elementSerializer).getSchema(provider, null);
/*     */       }
/* 287 */       if (schemaNode == null) {
/* 288 */         schemaNode = JsonSchema.getDefaultSchemaNode();
/*     */       }
/* 290 */       o.set("items", schemaNode);
/*     */     } 
/* 292 */     return (JsonNode)o;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 299 */     JsonSerializer<?> valueSer = this._elementSerializer;
/* 300 */     if (valueSer == null)
/*     */     {
/*     */       
/* 303 */       if (this._elementType != null) {
/* 304 */         valueSer = visitor.getProvider().findContentValueSerializer(this._elementType, this._property);
/*     */       }
/*     */     }
/* 307 */     visitArrayFormat(visitor, typeHint, valueSer, this._elementType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonSerializer<Object> _findAndAddDynamic(PropertySerializerMap map, Class<?> type, SerializerProvider provider) throws JsonMappingException {
/* 313 */     PropertySerializerMap.SerializerAndMapResult result = map.findAndAddSecondarySerializer(type, provider, this._property);
/*     */     
/* 315 */     if (map != result.map) {
/* 316 */       this._dynamicSerializers = result.map;
/*     */     }
/* 318 */     return result.serializer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonSerializer<Object> _findAndAddDynamic(PropertySerializerMap map, JavaType type, SerializerProvider provider) throws JsonMappingException {
/* 324 */     PropertySerializerMap.SerializerAndMapResult result = map.findAndAddSecondarySerializer(type, provider, this._property);
/* 325 */     if (map != result.map) {
/* 326 */       this._dynamicSerializers = result.map;
/*     */     }
/* 328 */     return result.serializer;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\AsArraySerializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */