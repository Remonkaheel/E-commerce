/*     */ package com.fasterxml.jackson.databind.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.impl.PropertySerializerMap;
/*     */ import com.fasterxml.jackson.databind.util.Annotations;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class VirtualBeanPropertyWriter
/*     */   extends BeanPropertyWriter
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   protected VirtualBeanPropertyWriter(BeanPropertyDefinition propDef, Annotations contextAnnotations, JavaType declaredType) {
/*  34 */     this(propDef, contextAnnotations, declaredType, (JsonSerializer<?>)null, (TypeSerializer)null, (JavaType)null, propDef
/*  35 */         .findInclusion());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected VirtualBeanPropertyWriter() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected VirtualBeanPropertyWriter(BeanPropertyDefinition propDef, Annotations contextAnnotations, JavaType declaredType, JsonSerializer<?> ser, TypeSerializer typeSer, JavaType serType, JsonInclude.Value inclusion, Class<?>[] includeInViews) {
/*  56 */     super(propDef, propDef.getPrimaryMember(), contextAnnotations, declaredType, ser, typeSer, serType, 
/*     */         
/*  58 */         _suppressNulls(inclusion), _suppressableValue(inclusion), includeInViews);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected VirtualBeanPropertyWriter(BeanPropertyDefinition propDef, Annotations contextAnnotations, JavaType declaredType, JsonSerializer<?> ser, TypeSerializer typeSer, JavaType serType, JsonInclude.Value inclusion) {
/*  68 */     this(propDef, contextAnnotations, declaredType, ser, typeSer, serType, inclusion, (Class<?>[])null);
/*     */   }
/*     */   
/*     */   protected VirtualBeanPropertyWriter(VirtualBeanPropertyWriter base) {
/*  72 */     super(base);
/*     */   }
/*     */   
/*     */   protected VirtualBeanPropertyWriter(VirtualBeanPropertyWriter base, PropertyName name) {
/*  76 */     super(base, name);
/*     */   }
/*     */   
/*     */   protected static boolean _suppressNulls(JsonInclude.Value inclusion) {
/*  80 */     if (inclusion == null) {
/*  81 */       return false;
/*     */     }
/*  83 */     JsonInclude.Include incl = inclusion.getValueInclusion();
/*  84 */     return (incl != JsonInclude.Include.ALWAYS && incl != JsonInclude.Include.USE_DEFAULTS);
/*     */   }
/*     */   
/*     */   protected static Object _suppressableValue(JsonInclude.Value inclusion) {
/*  88 */     if (inclusion == null) {
/*  89 */       return Boolean.valueOf(false);
/*     */     }
/*  91 */     JsonInclude.Include incl = inclusion.getValueInclusion();
/*  92 */     if (incl == JsonInclude.Include.ALWAYS || incl == JsonInclude.Include.NON_NULL || incl == JsonInclude.Include.USE_DEFAULTS)
/*     */     {
/*     */       
/*  95 */       return null;
/*     */     }
/*  97 */     return MARKER_FOR_EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVirtual() {
/* 107 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Object value(Object paramObject, JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider) throws Exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract VirtualBeanPropertyWriter withConfig(MapperConfig<?> paramMapperConfig, AnnotatedClass paramAnnotatedClass, BeanPropertyDefinition paramBeanPropertyDefinition, JavaType paramJavaType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeAsField(Object bean, JsonGenerator gen, SerializerProvider prov) throws Exception {
/* 150 */     Object value = value(bean, gen, prov);
/*     */     
/* 152 */     if (value == null) {
/* 153 */       if (this._nullSerializer != null) {
/* 154 */         gen.writeFieldName((SerializableString)this._name);
/* 155 */         this._nullSerializer.serialize(null, gen, prov);
/*     */       } 
/*     */       return;
/*     */     } 
/* 159 */     JsonSerializer<Object> ser = this._serializer;
/* 160 */     if (ser == null) {
/* 161 */       Class<?> cls = value.getClass();
/* 162 */       PropertySerializerMap m = this._dynamicSerializers;
/* 163 */       ser = m.serializerFor(cls);
/* 164 */       if (ser == null) {
/* 165 */         ser = _findAndAddDynamic(m, cls, prov);
/*     */       }
/*     */     } 
/* 168 */     if (this._suppressableValue != null) {
/* 169 */       if (MARKER_FOR_EMPTY == this._suppressableValue) {
/* 170 */         if (ser.isEmpty(prov, value)) {
/*     */           return;
/*     */         }
/* 173 */       } else if (this._suppressableValue.equals(value)) {
/*     */         return;
/*     */       } 
/*     */     }
/* 177 */     if (value == bean)
/*     */     {
/* 179 */       if (_handleSelfReference(bean, gen, prov, ser)) {
/*     */         return;
/*     */       }
/*     */     }
/* 183 */     gen.writeFieldName((SerializableString)this._name);
/* 184 */     if (this._typeSerializer == null) {
/* 185 */       ser.serialize(value, gen, prov);
/*     */     } else {
/* 187 */       ser.serializeWithType(value, gen, prov, this._typeSerializer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeAsElement(Object bean, JsonGenerator gen, SerializerProvider prov) throws Exception {
/* 199 */     Object value = value(bean, gen, prov);
/*     */     
/* 201 */     if (value == null) {
/* 202 */       if (this._nullSerializer != null) {
/* 203 */         this._nullSerializer.serialize(null, gen, prov);
/*     */       } else {
/* 205 */         gen.writeNull();
/*     */       } 
/*     */       return;
/*     */     } 
/* 209 */     JsonSerializer<Object> ser = this._serializer;
/* 210 */     if (ser == null) {
/* 211 */       Class<?> cls = value.getClass();
/* 212 */       PropertySerializerMap map = this._dynamicSerializers;
/* 213 */       ser = map.serializerFor(cls);
/* 214 */       if (ser == null) {
/* 215 */         ser = _findAndAddDynamic(map, cls, prov);
/*     */       }
/*     */     } 
/* 218 */     if (this._suppressableValue != null) {
/* 219 */       if (MARKER_FOR_EMPTY == this._suppressableValue) {
/* 220 */         if (ser.isEmpty(prov, value)) {
/* 221 */           serializeAsPlaceholder(bean, gen, prov);
/*     */           return;
/*     */         } 
/* 224 */       } else if (this._suppressableValue.equals(value)) {
/* 225 */         serializeAsPlaceholder(bean, gen, prov);
/*     */         return;
/*     */       } 
/*     */     }
/* 229 */     if (value == bean && 
/* 230 */       _handleSelfReference(bean, gen, prov, ser)) {
/*     */       return;
/*     */     }
/*     */     
/* 234 */     if (this._typeSerializer == null) {
/* 235 */       ser.serialize(value, gen, prov);
/*     */     } else {
/* 237 */       ser.serializeWithType(value, gen, prov, this._typeSerializer);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\VirtualBeanPropertyWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */