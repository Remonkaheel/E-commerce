/*     */ package com.fasterxml.jackson.databind.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.ser.impl.ObjectIdWriter;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanSerializerBuilder
/*     */ {
/*  19 */   private static final BeanPropertyWriter[] NO_PROPERTIES = new BeanPropertyWriter[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final BeanDescription _beanDesc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializationConfig _config;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   protected List<BeanPropertyWriter> _properties = Collections.emptyList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanPropertyWriter[] _filteredProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnyGetterWriter _anyGetter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _filterId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotatedMember _typeId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectIdWriter _objectIdWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanSerializerBuilder(BeanDescription beanDesc) {
/*  77 */     this._beanDesc = beanDesc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanSerializerBuilder(BeanSerializerBuilder src) {
/*  84 */     this._beanDesc = src._beanDesc;
/*  85 */     this._config = src._config;
/*  86 */     this._properties = src._properties;
/*  87 */     this._filteredProperties = src._filteredProperties;
/*  88 */     this._anyGetter = src._anyGetter;
/*  89 */     this._filterId = src._filterId;
/*  90 */     this._typeId = src._typeId;
/*  91 */     this._objectIdWriter = src._objectIdWriter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setConfig(SerializationConfig config) {
/* 104 */     this._config = config;
/*     */   }
/*     */   
/*     */   public void setProperties(List<BeanPropertyWriter> properties) {
/* 108 */     this._properties = properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFilteredProperties(BeanPropertyWriter[] properties) {
/* 117 */     if (properties != null && 
/* 118 */       properties.length != this._properties.size()) {
/* 119 */       throw new IllegalArgumentException(String.format("Trying to set %d filtered properties; must match length of non-filtered `properties` (%d)", new Object[] {
/*     */               
/* 121 */               Integer.valueOf(properties.length), Integer.valueOf(this._properties.size())
/*     */             }));
/*     */     }
/* 124 */     this._filteredProperties = properties;
/*     */   }
/*     */   
/*     */   public void setAnyGetter(AnyGetterWriter anyGetter) {
/* 128 */     this._anyGetter = anyGetter;
/*     */   }
/*     */   
/*     */   public void setFilterId(Object filterId) {
/* 132 */     this._filterId = filterId;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTypeId(AnnotatedMember idProp) {
/* 137 */     if (this._typeId != null) {
/* 138 */       throw new IllegalArgumentException("Multiple type ids specified with " + this._typeId + " and " + idProp);
/*     */     }
/* 140 */     this._typeId = idProp;
/*     */   }
/*     */   
/*     */   public void setObjectIdWriter(ObjectIdWriter w) {
/* 144 */     this._objectIdWriter = w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedClass getClassInfo() {
/* 155 */     return this._beanDesc.getClassInfo();
/*     */   } public BeanDescription getBeanDescription() {
/* 157 */     return this._beanDesc;
/*     */   } public List<BeanPropertyWriter> getProperties() {
/* 159 */     return this._properties;
/*     */   } public boolean hasProperties() {
/* 161 */     return (this._properties != null && this._properties.size() > 0);
/*     */   }
/*     */   public BeanPropertyWriter[] getFilteredProperties() {
/* 164 */     return this._filteredProperties;
/*     */   } public AnyGetterWriter getAnyGetter() {
/* 166 */     return this._anyGetter;
/*     */   } public Object getFilterId() {
/* 168 */     return this._filterId;
/*     */   } public AnnotatedMember getTypeId() {
/* 170 */     return this._typeId;
/*     */   } public ObjectIdWriter getObjectIdWriter() {
/* 172 */     return this._objectIdWriter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> build() {
/*     */     BeanPropertyWriter[] properties;
/* 189 */     if (this._typeId != null && 
/* 190 */       this._config.isEnabled(MapperFeature.CAN_OVERRIDE_ACCESS_MODIFIERS)) {
/* 191 */       this._typeId.fixAccess(this._config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */     }
/*     */     
/* 194 */     if (this._anyGetter != null) {
/* 195 */       this._anyGetter.fixAccess(this._config);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 201 */     if (this._properties == null || this._properties.isEmpty()) {
/* 202 */       if (this._anyGetter == null && this._objectIdWriter == null)
/*     */       {
/* 204 */         return null;
/*     */       }
/* 206 */       properties = NO_PROPERTIES;
/*     */     } else {
/* 208 */       properties = this._properties.<BeanPropertyWriter>toArray(new BeanPropertyWriter[this._properties.size()]);
/* 209 */       if (this._config.isEnabled(MapperFeature.CAN_OVERRIDE_ACCESS_MODIFIERS)) {
/* 210 */         for (int i = 0, end = properties.length; i < end; i++) {
/* 211 */           properties[i].fixAccess(this._config);
/*     */         }
/*     */       }
/*     */     } 
/*     */     
/* 216 */     if (this._filteredProperties != null && 
/* 217 */       this._filteredProperties.length != this._properties.size()) {
/* 218 */       throw new IllegalStateException(String.format("Mismatch between `properties` size (%d), `filteredProperties` (%s): should have as many (or `null` for latter)", new Object[] {
/*     */               
/* 220 */               Integer.valueOf(this._properties.size()), Integer.valueOf(this._filteredProperties.length)
/*     */             }));
/*     */     }
/* 223 */     return (JsonSerializer<?>)new BeanSerializer(this._beanDesc.getType(), this, properties, this._filteredProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanSerializer createDummy() {
/* 234 */     return BeanSerializer.createDummy(this._beanDesc.getType(), this);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\BeanSerializerBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */