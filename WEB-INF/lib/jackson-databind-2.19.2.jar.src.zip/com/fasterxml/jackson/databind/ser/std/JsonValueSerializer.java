/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.RuntimeJsonMappingException;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitable;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonschema.JsonSchema;
/*     */ import com.fasterxml.jackson.databind.jsonschema.SchemaAware;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.impl.PropertySerializerMap;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Collections;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class JsonValueSerializer
/*     */   extends StdSerializer<Object>
/*     */   implements ContextualSerializer, JsonFormatVisitable
/*     */ {
/*     */   protected final AnnotatedMember _accessor;
/*     */   protected final TypeSerializer _valueTypeSerializer;
/*     */   protected final JsonSerializer<Object> _valueSerializer;
/*     */   protected final BeanProperty _property;
/*     */   protected final JavaType _valueType;
/*     */   protected final boolean _forceTypeInformation;
/*     */   protected final Set<String> _ignoredProperties;
/*     */   protected transient PropertySerializerMap _dynamicSerializers;
/*     */   
/*     */   public JsonValueSerializer(AnnotatedMember accessor, TypeSerializer vts, JsonSerializer<?> ser, Set<String> ignoredProperties) {
/* 111 */     super(accessor.getType());
/* 112 */     this._accessor = accessor;
/* 113 */     this._valueType = accessor.getType();
/* 114 */     this._valueTypeSerializer = vts;
/* 115 */     this._valueSerializer = (JsonSerializer)ser;
/* 116 */     this._property = null;
/* 117 */     this._forceTypeInformation = true;
/* 118 */     this._ignoredProperties = ignoredProperties;
/* 119 */     this._dynamicSerializers = PropertySerializerMap.emptyForProperties();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonValueSerializer(AnnotatedMember accessor, TypeSerializer vts, JsonSerializer<?> ser) {
/* 126 */     this(accessor, vts, ser, Collections.emptySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonValueSerializer(AnnotatedMember accessor, JsonSerializer<?> ser) {
/* 134 */     this(accessor, (TypeSerializer)null, ser, Collections.emptySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonValueSerializer(JsonValueSerializer src, BeanProperty property, TypeSerializer vts, JsonSerializer<?> ser, boolean forceTypeInfo) {
/* 142 */     super(_notNullClass(src.handledType()));
/* 143 */     this._accessor = src._accessor;
/* 144 */     this._valueType = src._valueType;
/* 145 */     this._valueTypeSerializer = vts;
/* 146 */     this._valueSerializer = (JsonSerializer)ser;
/* 147 */     this._property = property;
/* 148 */     this._forceTypeInformation = forceTypeInfo;
/* 149 */     this._ignoredProperties = src._ignoredProperties;
/* 150 */     this._dynamicSerializers = PropertySerializerMap.emptyForProperties();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonValueSerializer construct(SerializationConfig config, AnnotatedMember accessor, TypeSerializer vts, JsonSerializer<?> ser) {
/* 161 */     JsonIgnoreProperties.Value ignorals = config.getAnnotationIntrospector().findPropertyIgnoralByName((MapperConfig)config, (Annotated)accessor);
/* 162 */     Set<String> ignoredProperties = ignorals.findIgnoredForSerialization();
/* 163 */     ser = _withIgnoreProperties(ser, ignoredProperties);
/* 164 */     return new JsonValueSerializer(accessor, vts, ser, ignoredProperties);
/*     */   }
/*     */ 
/*     */   
/*     */   private static final Class<Object> _notNullClass(Class<?> cls) {
/* 169 */     return (cls == null) ? Object.class : (Class)cls;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonValueSerializer withResolved(BeanProperty property, TypeSerializer vts, JsonSerializer<?> ser, boolean forceTypeInfo) {
/* 175 */     if (this._property == property && this._valueTypeSerializer == vts && this._valueSerializer == ser && forceTypeInfo == this._forceTypeInformation)
/*     */     {
/*     */       
/* 178 */       return this;
/*     */     }
/* 180 */     return new JsonValueSerializer(this, property, vts, ser, forceTypeInfo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty(SerializerProvider ctxt, Object bean) {
/* 193 */     Object referenced = this._accessor.getValue(bean);
/* 194 */     if (referenced == null) {
/* 195 */       return true;
/*     */     }
/* 197 */     JsonSerializer<Object> ser = this._valueSerializer;
/* 198 */     if (ser == null) {
/*     */       try {
/* 200 */         ser = _findDynamicSerializer(ctxt, referenced.getClass());
/* 201 */       } catch (JsonMappingException e) {
/* 202 */         throw new RuntimeJsonMappingException(e);
/*     */       } 
/*     */     }
/* 205 */     return ser.isEmpty(ctxt, referenced);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> createContextual(SerializerProvider ctxt, BeanProperty property) throws JsonMappingException {
/* 223 */     TypeSerializer typeSer = this._valueTypeSerializer;
/* 224 */     if (typeSer != null) {
/* 225 */       typeSer = typeSer.forProperty(property);
/*     */     }
/* 227 */     JsonSerializer<?> ser = this._valueSerializer;
/* 228 */     if (ser == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 233 */       if (ctxt.isEnabled(MapperFeature.USE_STATIC_TYPING) || this._valueType.isFinal()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 239 */         ser = ctxt.findPrimaryPropertySerializer(this._valueType, property);
/* 240 */         ser = _withIgnoreProperties(ser, this._ignoredProperties);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 246 */         boolean forceTypeInformation = isNaturalTypeWithStdHandling(this._valueType.getRawClass(), ser);
/* 247 */         return withResolved(property, typeSer, ser, forceTypeInformation);
/*     */       } 
/*     */       
/* 250 */       if (property != this._property) {
/* 251 */         return withResolved(property, typeSer, ser, this._forceTypeInformation);
/*     */       }
/*     */     } else {
/*     */       
/* 255 */       ser = ctxt.handlePrimaryContextualization(ser, property);
/* 256 */       return withResolved(property, typeSer, ser, this._forceTypeInformation);
/*     */     } 
/* 258 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(Object bean, JsonGenerator gen, SerializerProvider ctxt) throws IOException {
/*     */     Object value;
/*     */     try {
/* 272 */       value = this._accessor.getValue(bean);
/* 273 */     } catch (Exception e) {
/* 274 */       value = null;
/* 275 */       wrapAndThrow(ctxt, e, bean, this._accessor.getName() + "()");
/*     */     } 
/*     */     
/* 278 */     if (value == null) {
/* 279 */       ctxt.defaultSerializeNull(gen);
/*     */     } else {
/* 281 */       JsonSerializer<Object> ser = this._valueSerializer;
/* 282 */       if (ser == null) {
/* 283 */         ser = _findDynamicSerializer(ctxt, value.getClass());
/*     */       }
/* 285 */       if (this._valueTypeSerializer != null) {
/* 286 */         ser.serializeWithType(value, gen, ctxt, this._valueTypeSerializer);
/*     */       } else {
/* 288 */         ser.serialize(value, gen, ctxt);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeWithType(Object bean, JsonGenerator gen, SerializerProvider ctxt, TypeSerializer typeSer0) throws IOException {
/*     */     Object value;
/*     */     try {
/* 300 */       value = this._accessor.getValue(bean);
/* 301 */     } catch (Exception e) {
/* 302 */       value = null;
/* 303 */       wrapAndThrow(ctxt, e, bean, this._accessor.getName() + "()");
/*     */     } 
/*     */ 
/*     */     
/* 307 */     if (value == null) {
/* 308 */       ctxt.defaultSerializeNull(gen);
/*     */       return;
/*     */     } 
/* 311 */     JsonSerializer<Object> ser = this._valueSerializer;
/* 312 */     if (ser == null) {
/* 313 */       ser = _findDynamicSerializer(ctxt, value.getClass());
/*     */ 
/*     */     
/*     */     }
/* 317 */     else if (this._forceTypeInformation) {
/*     */       
/* 319 */       WritableTypeId typeIdDef = typeSer0.writeTypePrefix(gen, typeSer0
/* 320 */           .typeId(bean, JsonToken.VALUE_STRING));
/* 321 */       ser.serialize(value, gen, ctxt);
/* 322 */       typeSer0.writeTypeSuffix(gen, typeIdDef);
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 330 */     TypeSerializerRerouter rr = new TypeSerializerRerouter(typeSer0, bean);
/* 331 */     ser.serializeWithType(value, gen, ctxt, rr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonNode getSchema(SerializerProvider ctxt, Type typeHint) throws JsonMappingException {
/* 348 */     if (this._valueSerializer instanceof SchemaAware) {
/* 349 */       return ((SchemaAware)this._valueSerializer)
/* 350 */         .getSchema(ctxt, null);
/*     */     }
/* 352 */     return JsonSchema.getDefaultSchemaNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 368 */     Class<?> declaring = this._accessor.getDeclaringClass();
/* 369 */     if (declaring != null && ClassUtil.isEnumType(declaring) && 
/* 370 */       _acceptJsonFormatVisitorForEnum(visitor, typeHint, declaring)) {
/*     */       return;
/*     */     }
/*     */     
/* 374 */     JsonSerializer<Object> ser = this._valueSerializer;
/* 375 */     if (ser == null) {
/* 376 */       ser = visitor.getProvider().findTypedValueSerializer(this._valueType, false, this._property);
/* 377 */       if (ser == null) {
/* 378 */         visitor.expectAnyFormat(typeHint);
/*     */         return;
/*     */       } 
/*     */     } 
/* 382 */     ser.acceptJsonFormatVisitor(visitor, this._valueType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _acceptJsonFormatVisitorForEnum(JsonFormatVisitorWrapper visitor, JavaType typeHint, Class<?> enumType) throws JsonMappingException {
/*     */     // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: aload_2
/*     */     //   2: invokeinterface expectStringFormat : (Lcom/fasterxml/jackson/databind/JavaType;)Lcom/fasterxml/jackson/databind/jsonFormatVisitors/JsonStringFormatVisitor;
/*     */     //   7: astore #4
/*     */     //   9: aload #4
/*     */     //   11: ifnull -> 160
/*     */     //   14: new java/util/LinkedHashSet
/*     */     //   17: dup
/*     */     //   18: invokespecial <init> : ()V
/*     */     //   21: astore #5
/*     */     //   23: aload_3
/*     */     //   24: invokevirtual getEnumConstants : ()[Ljava/lang/Object;
/*     */     //   27: astore #6
/*     */     //   29: aload #6
/*     */     //   31: arraylength
/*     */     //   32: istore #7
/*     */     //   34: iconst_0
/*     */     //   35: istore #8
/*     */     //   37: iload #8
/*     */     //   39: iload #7
/*     */     //   41: if_icmpge -> 151
/*     */     //   44: aload #6
/*     */     //   46: iload #8
/*     */     //   48: aaload
/*     */     //   49: astore #9
/*     */     //   51: aload #5
/*     */     //   53: aload_0
/*     */     //   54: getfield _accessor : Lcom/fasterxml/jackson/databind/introspect/AnnotatedMember;
/*     */     //   57: aload #9
/*     */     //   59: invokevirtual getValue : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   62: invokestatic valueOf : (Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   65: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   70: pop
/*     */     //   71: goto -> 145
/*     */     //   74: astore #10
/*     */     //   76: aload #10
/*     */     //   78: astore #11
/*     */     //   80: aload #11
/*     */     //   82: instanceof java/lang/reflect/InvocationTargetException
/*     */     //   85: ifeq -> 106
/*     */     //   88: aload #11
/*     */     //   90: invokevirtual getCause : ()Ljava/lang/Throwable;
/*     */     //   93: ifnull -> 106
/*     */     //   96: aload #11
/*     */     //   98: invokevirtual getCause : ()Ljava/lang/Throwable;
/*     */     //   101: astore #11
/*     */     //   103: goto -> 80
/*     */     //   106: aload #11
/*     */     //   108: invokestatic throwIfError : (Ljava/lang/Throwable;)Ljava/lang/Throwable;
/*     */     //   111: pop
/*     */     //   112: aload #11
/*     */     //   114: aload #9
/*     */     //   116: new java/lang/StringBuilder
/*     */     //   119: dup
/*     */     //   120: invokespecial <init> : ()V
/*     */     //   123: aload_0
/*     */     //   124: getfield _accessor : Lcom/fasterxml/jackson/databind/introspect/AnnotatedMember;
/*     */     //   127: invokevirtual getName : ()Ljava/lang/String;
/*     */     //   130: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   133: ldc '()'
/*     */     //   135: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   138: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   141: invokestatic wrapWithPath : (Ljava/lang/Throwable;Ljava/lang/Object;Ljava/lang/String;)Lcom/fasterxml/jackson/databind/JsonMappingException;
/*     */     //   144: athrow
/*     */     //   145: iinc #8, 1
/*     */     //   148: goto -> 37
/*     */     //   151: aload #4
/*     */     //   153: aload #5
/*     */     //   155: invokeinterface enumTypes : (Ljava/util/Set;)V
/*     */     //   160: iconst_1
/*     */     //   161: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #399	-> 0
/*     */     //   #400	-> 9
/*     */     //   #401	-> 14
/*     */     //   #402	-> 23
/*     */     //   #407	-> 51
/*     */     //   #415	-> 71
/*     */     //   #408	-> 74
/*     */     //   #409	-> 76
/*     */     //   #410	-> 80
/*     */     //   #411	-> 96
/*     */     //   #413	-> 106
/*     */     //   #414	-> 112
/*     */     //   #402	-> 145
/*     */     //   #417	-> 151
/*     */     //   #419	-> 160
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   80	65	11	t	Ljava/lang/Throwable;
/*     */     //   76	69	10	e	Ljava/lang/Exception;
/*     */     //   51	94	9	en	Ljava/lang/Object;
/*     */     //   23	137	5	enums	Ljava/util/Set;
/*     */     //   0	162	0	this	Lcom/fasterxml/jackson/databind/ser/std/JsonValueSerializer;
/*     */     //   0	162	1	visitor	Lcom/fasterxml/jackson/databind/jsonFormatVisitors/JsonFormatVisitorWrapper;
/*     */     //   0	162	2	typeHint	Lcom/fasterxml/jackson/databind/JavaType;
/*     */     //   0	162	3	enumType	Ljava/lang/Class;
/*     */     //   9	153	4	stringVisitor	Lcom/fasterxml/jackson/databind/jsonFormatVisitors/JsonStringFormatVisitor;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   23	137	5	enums	Ljava/util/Set<Ljava/lang/String;>;
/*     */     //   0	162	3	enumType	Ljava/lang/Class<*>;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   51	71	74	java/lang/Exception
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isNaturalTypeWithStdHandling(Class<?> rawType, JsonSerializer<?> ser) {
/* 431 */     if (rawType.isPrimitive()) {
/* 432 */       if (rawType != int.class && rawType != boolean.class && rawType != double.class) {
/* 433 */         return false;
/*     */       }
/*     */     }
/* 436 */     else if (rawType != String.class && rawType != Integer.class && rawType != Boolean.class && rawType != Double.class) {
/*     */       
/* 438 */       return false;
/*     */     } 
/*     */     
/* 441 */     return isDefaultSerializer(ser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<Object> _findDynamicSerializer(SerializerProvider ctxt, Class<?> valueClass) throws JsonMappingException {
/* 448 */     JsonSerializer<Object> serializer = this._dynamicSerializers.serializerFor(valueClass);
/* 449 */     if (serializer == null) {
/* 450 */       if (this._valueType.hasGenericTypes()) {
/* 451 */         JavaType fullType = ctxt.constructSpecializedType(this._valueType, valueClass);
/* 452 */         serializer = ctxt.findPrimaryPropertySerializer(fullType, this._property);
/* 453 */         serializer = _withIgnoreProperties(serializer, this._ignoredProperties);
/* 454 */         PropertySerializerMap.SerializerAndMapResult result = this._dynamicSerializers.addSerializer(fullType, serializer);
/* 455 */         this._dynamicSerializers = result.map;
/*     */       } else {
/* 457 */         serializer = ctxt.findPrimaryPropertySerializer(valueClass, this._property);
/*     */         
/* 459 */         serializer = _withIgnoreProperties(serializer, this._ignoredProperties);
/* 460 */         PropertySerializerMap.SerializerAndMapResult result = this._dynamicSerializers.addSerializer(valueClass, serializer);
/* 461 */         this._dynamicSerializers = result.map;
/*     */       } 
/*     */     }
/* 464 */     return serializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static JsonSerializer<Object> _withIgnoreProperties(JsonSerializer<?> ser, Set<String> ignoredProperties) {
/* 496 */     if (ser != null && 
/* 497 */       !ignoredProperties.isEmpty()) {
/* 498 */       ser = ser.withIgnoredProperties(ignoredProperties);
/*     */     }
/*     */     
/* 501 */     return (JsonSerializer)ser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 512 */     return "(@JsonValue serializer for method " + this._accessor.getDeclaringClass() + "#" + this._accessor.getName() + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class TypeSerializerRerouter
/*     */     extends TypeSerializer
/*     */   {
/*     */     protected final TypeSerializer _typeSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final Object _forObject;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeSerializerRerouter(TypeSerializer ts, Object ob) {
/* 533 */       this._typeSerializer = ts;
/* 534 */       this._forObject = ob;
/*     */     }
/*     */ 
/*     */     
/*     */     public TypeSerializer forProperty(BeanProperty prop) {
/* 539 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/*     */     public JsonTypeInfo.As getTypeInclusion() {
/* 544 */       return this._typeSerializer.getTypeInclusion();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getPropertyName() {
/* 549 */       return this._typeSerializer.getPropertyName();
/*     */     }
/*     */ 
/*     */     
/*     */     public TypeIdResolver getTypeIdResolver() {
/* 554 */       return this._typeSerializer.getTypeIdResolver();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WritableTypeId writeTypePrefix(JsonGenerator g, WritableTypeId typeId) throws IOException {
/* 563 */       typeId.forValue = this._forObject;
/* 564 */       return this._typeSerializer.writeTypePrefix(g, typeId);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public WritableTypeId writeTypeSuffix(JsonGenerator g, WritableTypeId typeId) throws IOException {
/* 571 */       return this._typeSerializer.writeTypeSuffix(g, typeId);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypePrefixForScalar(Object value, JsonGenerator gen) throws IOException {
/* 579 */       this._typeSerializer.writeTypePrefixForScalar(this._forObject, gen);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypePrefixForObject(Object value, JsonGenerator gen) throws IOException {
/* 585 */       this._typeSerializer.writeTypePrefixForObject(this._forObject, gen);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypePrefixForArray(Object value, JsonGenerator gen) throws IOException {
/* 591 */       this._typeSerializer.writeTypePrefixForArray(this._forObject, gen);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypeSuffixForScalar(Object value, JsonGenerator gen) throws IOException {
/* 597 */       this._typeSerializer.writeTypeSuffixForScalar(this._forObject, gen);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypeSuffixForObject(Object value, JsonGenerator gen) throws IOException {
/* 603 */       this._typeSerializer.writeTypeSuffixForObject(this._forObject, gen);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypeSuffixForArray(Object value, JsonGenerator gen) throws IOException {
/* 609 */       this._typeSerializer.writeTypeSuffixForArray(this._forObject, gen);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypePrefixForScalar(Object value, JsonGenerator gen, Class<?> type) throws IOException {
/* 615 */       this._typeSerializer.writeTypePrefixForScalar(this._forObject, gen, type);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypePrefixForObject(Object value, JsonGenerator gen, Class<?> type) throws IOException {
/* 621 */       this._typeSerializer.writeTypePrefixForObject(this._forObject, gen, type);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeTypePrefixForArray(Object value, JsonGenerator gen, Class<?> type) throws IOException {
/* 627 */       this._typeSerializer.writeTypePrefixForArray(this._forObject, gen, type);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeCustomTypePrefixForScalar(Object value, JsonGenerator gen, String typeId) throws IOException {
/* 640 */       this._typeSerializer.writeCustomTypePrefixForScalar(this._forObject, gen, typeId);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeCustomTypePrefixForObject(Object value, JsonGenerator gen, String typeId) throws IOException {
/* 646 */       this._typeSerializer.writeCustomTypePrefixForObject(this._forObject, gen, typeId);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeCustomTypePrefixForArray(Object value, JsonGenerator gen, String typeId) throws IOException {
/* 652 */       this._typeSerializer.writeCustomTypePrefixForArray(this._forObject, gen, typeId);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeCustomTypeSuffixForScalar(Object value, JsonGenerator gen, String typeId) throws IOException {
/* 658 */       this._typeSerializer.writeCustomTypeSuffixForScalar(this._forObject, gen, typeId);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeCustomTypeSuffixForObject(Object value, JsonGenerator gen, String typeId) throws IOException {
/* 664 */       this._typeSerializer.writeCustomTypeSuffixForObject(this._forObject, gen, typeId);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void writeCustomTypeSuffixForArray(Object value, JsonGenerator gen, String typeId) throws IOException {
/* 670 */       this._typeSerializer.writeCustomTypeSuffixForArray(this._forObject, gen, typeId);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\JsonValueSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */