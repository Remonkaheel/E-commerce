/*     */ package com.fasterxml.jackson.databind.ser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatTypes;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.ContainerSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.std.ArraySerializerBase;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class StringArraySerializer
/*     */   extends ArraySerializerBase<String[]>
/*     */   implements ContextualSerializer
/*     */ {
/*  34 */   private static final JavaType VALUE_TYPE = TypeFactory.defaultInstance().uncheckedSimpleType(String.class);
/*     */   
/*  36 */   public static final StringArraySerializer instance = new StringArraySerializer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonSerializer<Object> _elementSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StringArraySerializer() {
/*  51 */     super(String[].class);
/*  52 */     this._elementSerializer = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringArraySerializer(StringArraySerializer src, BeanProperty prop, JsonSerializer<?> ser, Boolean unwrapSingle) {
/*  58 */     super(src, prop, unwrapSingle);
/*  59 */     this._elementSerializer = (JsonSerializer)ser;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> _withResolved(BeanProperty prop, Boolean unwrapSingle) {
/*  64 */     return (JsonSerializer<?>)new StringArraySerializer(this, prop, this._elementSerializer, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContainerSerializer<?> _withValueTypeSerializer(TypeSerializer vts) {
/*  73 */     return (ContainerSerializer<?>)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> createContextual(SerializerProvider provider, BeanProperty property) throws JsonMappingException {
/*  90 */     JsonSerializer<?> ser = null;
/*     */ 
/*     */     
/*  93 */     if (property != null) {
/*  94 */       AnnotationIntrospector ai = provider.getAnnotationIntrospector();
/*  95 */       AnnotatedMember m = property.getMember();
/*  96 */       if (m != null) {
/*  97 */         Object serDef = ai.findContentSerializer((Annotated)m);
/*  98 */         if (serDef != null) {
/*  99 */           ser = provider.serializerInstance((Annotated)m, serDef);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 105 */     Boolean unwrapSingle = findFormatFeature(provider, property, String[].class, JsonFormat.Feature.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED);
/*     */     
/* 107 */     if (ser == null) {
/* 108 */       ser = this._elementSerializer;
/*     */     }
/*     */     
/* 111 */     ser = findContextualConvertingSerializer(provider, property, ser);
/* 112 */     if (ser == null) {
/* 113 */       ser = provider.findContentValueSerializer(String.class, property);
/*     */     }
/*     */     
/* 116 */     if (isDefaultSerializer(ser)) {
/* 117 */       ser = null;
/*     */     }
/*     */     
/* 120 */     if (ser == this._elementSerializer && Objects.equals(unwrapSingle, this._unwrapSingle)) {
/* 121 */       return (JsonSerializer<?>)this;
/*     */     }
/* 123 */     return (JsonSerializer<?>)new StringArraySerializer(this, property, ser, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType getContentType() {
/* 134 */     return VALUE_TYPE;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> getContentSerializer() {
/* 139 */     return this._elementSerializer;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEmpty(SerializerProvider prov, String[] value) {
/* 144 */     return (value.length == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasSingleElement(String[] value) {
/* 149 */     return (value.length == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void serialize(String[] value, JsonGenerator gen, SerializerProvider provider) throws IOException {
/* 162 */     int len = value.length;
/* 163 */     if (len == 1 && ((
/* 164 */       this._unwrapSingle == null && provider
/* 165 */       .isEnabled(SerializationFeature.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED)) || this._unwrapSingle == Boolean.TRUE)) {
/*     */       
/* 167 */       serializeContents(value, gen, provider);
/*     */       
/*     */       return;
/*     */     } 
/* 171 */     gen.writeStartArray(value, len);
/* 172 */     serializeContents(value, gen, provider);
/* 173 */     gen.writeEndArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeContents(String[] value, JsonGenerator gen, SerializerProvider provider) throws IOException {
/* 180 */     int len = value.length;
/* 181 */     if (len == 0) {
/*     */       return;
/*     */     }
/* 184 */     if (this._elementSerializer != null) {
/* 185 */       serializeContentsSlow(value, gen, provider, this._elementSerializer);
/*     */       return;
/*     */     } 
/* 188 */     for (int i = 0; i < len; i++) {
/* 189 */       String str = value[i];
/* 190 */       if (str == null) {
/* 191 */         gen.writeNull();
/*     */       } else {
/* 193 */         gen.writeString(value[i]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void serializeContentsSlow(String[] value, JsonGenerator gen, SerializerProvider provider, JsonSerializer<Object> ser) throws IOException {
/* 201 */     for (int i = 0, len = value.length; i < len; i++) {
/* 202 */       String str = value[i];
/* 203 */       if (str == null) {
/* 204 */         provider.defaultSerializeNull(gen);
/*     */       } else {
/* 206 */         ser.serialize(value[i], gen, provider);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint) {
/* 217 */     return createSchemaNode("array", true).set("items", (JsonNode)createSchemaNode("string"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 223 */     visitArrayFormat(visitor, typeHint, JsonFormatTypes.STRING);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\impl\StringArraySerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */