/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.EnumNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.EnumNamingStrategyFactory;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonStringFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.node.ArrayNode;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*     */ import com.fasterxml.jackson.databind.util.EnumValues;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class EnumSerializer
/*     */   extends StdScalarSerializer<Enum<?>>
/*     */   implements ContextualSerializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final EnumValues _values;
/*     */   protected final Boolean _serializeAsIndex;
/*     */   protected final EnumValues _valuesByEnumNaming;
/*     */   protected final EnumValues _valuesByToString;
/*     */   
/*     */   @Deprecated
/*     */   public EnumSerializer(EnumValues v, Boolean serializeAsIndex) {
/*  82 */     this(v, serializeAsIndex, (EnumValues)null, (EnumValues)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EnumSerializer(EnumValues v, Boolean serializeAsIndex, EnumValues valuesByEnumNaming) {
/*  92 */     this(v, serializeAsIndex, valuesByEnumNaming, (EnumValues)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumSerializer(EnumValues v, Boolean serializeAsIndex, EnumValues valuesByEnumNaming, EnumValues valuesByToString) {
/* 101 */     super(v.getEnumClass(), false);
/* 102 */     this._values = v;
/* 103 */     this._serializeAsIndex = serializeAsIndex;
/* 104 */     this._valuesByEnumNaming = valuesByEnumNaming;
/* 105 */     this._valuesByToString = valuesByToString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static EnumSerializer construct(Class<?> enumClass, SerializationConfig config, BeanDescription beanDesc, JsonFormat.Value format) {
/* 122 */     EnumValues v = EnumValues.constructFromName((MapperConfig)config, beanDesc.getClassInfo());
/* 123 */     EnumValues valuesByEnumNaming = constructEnumNamingStrategyValues(config, (Class)enumClass, beanDesc.getClassInfo());
/* 124 */     EnumValues valuesByToString = EnumValues.constructFromToString((MapperConfig)config, beanDesc.getClassInfo());
/* 125 */     Boolean serializeAsIndex = _isShapeWrittenUsingIndex(enumClass, format, true, (Boolean)null);
/* 126 */     return new EnumSerializer(v, serializeAsIndex, valuesByEnumNaming, valuesByToString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> createContextual(SerializerProvider serializers, BeanProperty property) throws JsonMappingException {
/* 138 */     JsonFormat.Value format = findFormatOverrides(serializers, property, 
/* 139 */         handledType());
/* 140 */     if (format != null) {
/* 141 */       Class<?> type = handledType();
/* 142 */       Boolean serializeAsIndex = _isShapeWrittenUsingIndex(type, format, false, this._serializeAsIndex);
/*     */       
/* 144 */       if (!Objects.equals(serializeAsIndex, this._serializeAsIndex)) {
/* 145 */         return new EnumSerializer(this._values, serializeAsIndex, this._valuesByEnumNaming, this._valuesByToString);
/*     */       }
/*     */     } 
/*     */     
/* 149 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumValues getEnumValues() {
/* 158 */     return this._values;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void serialize(Enum<?> en, JsonGenerator gen, SerializerProvider serializers) throws IOException {
/* 170 */     if (this._valuesByEnumNaming != null) {
/* 171 */       gen.writeString(this._valuesByEnumNaming.serializedValueFor(en));
/*     */       return;
/*     */     } 
/* 174 */     if (_serializeAsIndex(serializers)) {
/* 175 */       gen.writeNumber(en.ordinal());
/*     */       
/*     */       return;
/*     */     } 
/* 179 */     if (serializers.isEnabled(SerializationFeature.WRITE_ENUMS_USING_TO_STRING)) {
/* 180 */       gen.writeString(this._valuesByToString.serializedValueFor(en));
/*     */       return;
/*     */     } 
/* 183 */     gen.writeString(this._values.serializedValueFor(en));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint) {
/* 199 */     if (_serializeAsIndex(provider)) {
/* 200 */       return (JsonNode)createSchemaNode("integer", true);
/*     */     }
/* 202 */     ObjectNode objectNode = createSchemaNode("string", true);
/* 203 */     if (typeHint != null) {
/* 204 */       JavaType type = provider.constructType(typeHint);
/* 205 */       if (type.isEnumType()) {
/* 206 */         ArrayNode enumNode = objectNode.putArray("enum");
/* 207 */         for (SerializableString value : this._values.values()) {
/* 208 */           enumNode.add(value.getValue());
/*     */         }
/*     */       } 
/*     */     } 
/* 212 */     return (JsonNode)objectNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 219 */     SerializerProvider serializers = visitor.getProvider();
/* 220 */     if (_serializeAsIndex(serializers)) {
/* 221 */       visitIntFormat(visitor, typeHint, JsonParser.NumberType.INT);
/*     */       return;
/*     */     } 
/* 224 */     JsonStringFormatVisitor stringVisitor = visitor.expectStringFormat(typeHint);
/* 225 */     if (stringVisitor != null) {
/* 226 */       Set<String> enums = new LinkedHashSet<>();
/*     */ 
/*     */       
/* 229 */       if (serializers != null && serializers
/* 230 */         .isEnabled(SerializationFeature.WRITE_ENUMS_USING_TO_STRING)) {
/* 231 */         for (SerializableString value : this._valuesByToString.values()) {
/* 232 */           enums.add(value.getValue());
/*     */         }
/*     */       } else {
/*     */         
/* 236 */         for (SerializableString value : this._values.values()) {
/* 237 */           enums.add(value.getValue());
/*     */         }
/*     */       } 
/* 240 */       stringVisitor.enumTypes(enums);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _serializeAsIndex(SerializerProvider serializers) {
/* 252 */     if (this._serializeAsIndex != null) {
/* 253 */       return this._serializeAsIndex.booleanValue();
/*     */     }
/* 255 */     return serializers.isEnabled(SerializationFeature.WRITE_ENUMS_USING_INDEX);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Boolean _isShapeWrittenUsingIndex(Class<?> enumClass, JsonFormat.Value format, boolean fromClass, Boolean defaultValue) {
/* 266 */     JsonFormat.Shape shape = (format == null) ? null : format.getShape();
/* 267 */     if (shape == null) {
/* 268 */       return defaultValue;
/*     */     }
/*     */     
/* 271 */     if (shape == JsonFormat.Shape.ANY || shape == JsonFormat.Shape.SCALAR) {
/* 272 */       return defaultValue;
/*     */     }
/*     */     
/* 275 */     if (shape == JsonFormat.Shape.STRING || shape == JsonFormat.Shape.NATURAL) {
/* 276 */       return Boolean.FALSE;
/*     */     }
/*     */     
/* 279 */     if (shape.isNumeric() || shape == JsonFormat.Shape.ARRAY) {
/* 280 */       return Boolean.TRUE;
/*     */     }
/*     */     
/* 283 */     throw new IllegalArgumentException(String.format("Unsupported serialization shape (%s) for Enum %s, not supported as %s annotation", new Object[] { shape, enumClass
/*     */             
/* 285 */             .getName(), fromClass ? "class" : "property" }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static EnumValues constructEnumNamingStrategyValues(SerializationConfig config, Class<Enum<?>> enumClass, AnnotatedClass annotatedClass) {
/* 296 */     Object namingDef = config.getAnnotationIntrospector().findEnumNamingStrategy((MapperConfig)config, annotatedClass);
/*     */     
/* 298 */     EnumNamingStrategy enumNamingStrategy = EnumNamingStrategyFactory.createEnumNamingStrategyInstance(namingDef, config
/* 299 */         .canOverrideAccessModifiers(), config.getEnumNamingStrategy());
/* 300 */     return (enumNamingStrategy == null) ? null : EnumValues.constructUsingEnumNamingStrategy((MapperConfig)config, annotatedClass, enumNamingStrategy);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\EnumSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */