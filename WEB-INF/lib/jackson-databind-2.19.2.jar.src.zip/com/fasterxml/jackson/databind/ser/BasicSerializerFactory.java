/*      */ package com.fasterxml.jackson.databind.ser;
/*      */ import com.fasterxml.jackson.annotation.JsonFormat;
/*      */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*      */ import com.fasterxml.jackson.annotation.JsonInclude;
/*      */ import com.fasterxml.jackson.annotation.JsonIncludeProperties;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.BeanDescription;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.JsonSerializer;
/*      */ import com.fasterxml.jackson.databind.MapperFeature;
/*      */ import com.fasterxml.jackson.databind.SerializationConfig;
/*      */ import com.fasterxml.jackson.databind.SerializationFeature;
/*      */ import com.fasterxml.jackson.databind.SerializerProvider;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*      */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.IndexedStringListSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.MapEntrySerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.StringArraySerializer;
/*      */ import com.fasterxml.jackson.databind.ser.impl.StringCollectionSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.AtomicReferenceSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.BooleanSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.CalendarSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.DateSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.EnumSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.JsonValueSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.MapSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.NumberSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.ObjectArraySerializer;
/*      */ import com.fasterxml.jackson.databind.ser.std.StdKeySerializers;
/*      */ import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
/*      */ import com.fasterxml.jackson.databind.type.ArrayType;
/*      */ import com.fasterxml.jackson.databind.type.CollectionLikeType;
/*      */ import com.fasterxml.jackson.databind.type.CollectionType;
/*      */ import com.fasterxml.jackson.databind.type.MapLikeType;
/*      */ import com.fasterxml.jackson.databind.type.MapType;
/*      */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ArrayBuilders;
/*      */ import com.fasterxml.jackson.databind.util.BeanUtil;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.Converter;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ 
/*      */ public abstract class BasicSerializerFactory extends SerializerFactory implements Serializable {
/*      */   static {
/*   64 */     HashMap<String, Class<? extends JsonSerializer<?>>> concLazy = new HashMap<>();
/*      */     
/*   66 */     HashMap<String, JsonSerializer<?>> concrete = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   73 */     concrete.put(String.class.getName(), new StringSerializer());
/*   74 */     ToStringSerializer sls = ToStringSerializer.instance;
/*   75 */     concrete.put(StringBuffer.class.getName(), sls);
/*   76 */     concrete.put(StringBuilder.class.getName(), sls);
/*   77 */     concrete.put(Character.class.getName(), sls);
/*   78 */     concrete.put(char.class.getName(), sls);
/*      */ 
/*      */     
/*   81 */     NumberSerializers.addAll(concrete);
/*   82 */     concrete.put(boolean.class.getName(), new BooleanSerializer(true));
/*   83 */     concrete.put(Boolean.class.getName(), new BooleanSerializer(false));
/*      */ 
/*      */     
/*   86 */     concrete.put(BigInteger.class.getName(), new NumberSerializer(BigInteger.class));
/*   87 */     concrete.put(BigDecimal.class.getName(), new NumberSerializer(BigDecimal.class));
/*      */ 
/*      */ 
/*      */     
/*   91 */     concrete.put(Calendar.class.getName(), CalendarSerializer.instance);
/*   92 */     concrete.put(Date.class.getName(), DateSerializer.instance);
/*      */ 
/*      */     
/*   95 */     for (Map.Entry<Class<?>, Object> en : (Iterable<Map.Entry<Class<?>, Object>>)StdJdkSerializers.all()) {
/*   96 */       Object value = en.getValue();
/*   97 */       if (value instanceof JsonSerializer) {
/*   98 */         concrete.put(((Class)en.getKey()).getName(), (JsonSerializer)value);
/*      */         continue;
/*      */       } 
/*  101 */       Class<? extends JsonSerializer<?>> cls = (Class<? extends JsonSerializer<?>>)value;
/*  102 */       concLazy.put(((Class)en.getKey()).getName(), cls);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  108 */     concLazy.put(TokenBuffer.class.getName(), TokenBufferSerializer.class);
/*      */     
/*  110 */     _concrete = concrete;
/*  111 */     _concreteLazy = concLazy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final HashMap<String, JsonSerializer<?>> _concrete;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final HashMap<String, Class<? extends JsonSerializer<?>>> _concreteLazy;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final SerializerFactoryConfig _factoryConfig;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BasicSerializerFactory(SerializerFactoryConfig config) {
/*  138 */     this._factoryConfig = (config == null) ? new SerializerFactoryConfig() : config;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SerializerFactoryConfig getFactoryConfig() {
/*  149 */     return this._factoryConfig;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SerializerFactory withAdditionalSerializers(Serializers additional) {
/*  170 */     return withConfig(this._factoryConfig.withAdditionalSerializers(additional));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SerializerFactory withAdditionalKeySerializers(Serializers additional) {
/*  179 */     return withConfig(this._factoryConfig.withAdditionalKeySerializers(additional));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SerializerFactory withSerializerModifier(BeanSerializerModifier modifier) {
/*  188 */     return withConfig(this._factoryConfig.withSerializerModifier(modifier));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<Object> createKeySerializer(SerializerProvider ctxt, JavaType keyType, JsonSerializer<Object> defaultImpl) throws JsonMappingException {
/*  210 */     SerializationConfig config = ctxt.getConfig();
/*  211 */     BeanDescription beanDesc = config.introspect(keyType);
/*  212 */     JsonSerializer<?> ser = null;
/*      */     
/*  214 */     if (this._factoryConfig.hasKeySerializers())
/*      */     {
/*  216 */       for (Serializers serializers : this._factoryConfig.keySerializers()) {
/*  217 */         ser = serializers.findSerializer(config, keyType, beanDesc);
/*  218 */         if (ser != null) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/*  223 */     if (ser == null) {
/*      */       
/*  225 */       ser = _findKeySerializer(ctxt, (Annotated)beanDesc.getClassInfo());
/*  226 */       if (ser == null) {
/*      */ 
/*      */ 
/*      */         
/*  230 */         ser = defaultImpl;
/*  231 */         if (ser == null) {
/*      */ 
/*      */           
/*  234 */           ser = StdKeySerializers.getStdKeySerializer(config, keyType.getRawClass(), false);
/*  235 */           if (ser == null) {
/*  236 */             AnnotatedMember acc = beanDesc.findJsonKeyAccessor();
/*  237 */             if (acc == null)
/*      */             {
/*  239 */               acc = beanDesc.findJsonValueAccessor();
/*      */             }
/*  241 */             if (acc != null) {
/*  242 */               JsonSerializer<?> delegate = createKeySerializer(ctxt, acc.getType(), defaultImpl);
/*  243 */               if (config.canOverrideAccessModifiers()) {
/*  244 */                 ClassUtil.checkAndFixAccess(acc.getMember(), config
/*  245 */                     .isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*      */               }
/*      */               
/*  248 */               JsonValueSerializer jsonValueSerializer = JsonValueSerializer.construct(config, acc, null, delegate);
/*      */             } else {
/*  250 */               ser = StdKeySerializers.getFallbackKeySerializer(config, keyType.getRawClass(), beanDesc
/*  251 */                   .getClassInfo());
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  259 */     if (this._factoryConfig.hasSerializerModifiers()) {
/*  260 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/*  261 */         ser = mod.modifyKeySerializer(config, keyType, beanDesc, ser);
/*      */       }
/*      */     }
/*  264 */     return (JsonSerializer)ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonSerializer<Object> createKeySerializer(SerializationConfig config, JavaType keyType, JsonSerializer<Object> defaultImpl) {
/*  273 */     BeanDescription beanDesc = config.introspect(keyType);
/*  274 */     JsonSerializer<?> ser = null;
/*  275 */     if (this._factoryConfig.hasKeySerializers()) {
/*  276 */       for (Serializers serializers : this._factoryConfig.keySerializers()) {
/*  277 */         ser = serializers.findSerializer(config, keyType, beanDesc);
/*  278 */         if (ser != null) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/*  283 */     if (ser == null) {
/*  284 */       ser = defaultImpl;
/*  285 */       if (ser == null) {
/*  286 */         ser = StdKeySerializers.getStdKeySerializer(config, keyType.getRawClass(), false);
/*  287 */         if (ser == null) {
/*  288 */           ser = StdKeySerializers.getFallbackKeySerializer(config, keyType.getRawClass(), beanDesc
/*  289 */               .getClassInfo());
/*      */         }
/*      */       } 
/*      */     } 
/*  293 */     if (this._factoryConfig.hasSerializerModifiers()) {
/*  294 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/*  295 */         ser = mod.modifyKeySerializer(config, keyType, beanDesc, ser);
/*      */       }
/*      */     }
/*  298 */     return (JsonSerializer)ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeSerializer createTypeSerializer(SerializationConfig config, JavaType baseType) {
/*  310 */     BeanDescription bean = config.introspectClassAnnotations(baseType.getRawClass());
/*  311 */     AnnotatedClass ac = bean.getClassInfo();
/*  312 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/*  313 */     TypeResolverBuilder<?> b = ai.findTypeResolver((MapperConfig)config, ac, baseType);
/*      */ 
/*      */ 
/*      */     
/*  317 */     Collection<NamedType> subtypes = null;
/*  318 */     if (b == null) {
/*  319 */       b = config.getDefaultTyper(baseType);
/*      */     } else {
/*  321 */       subtypes = config.getSubtypeResolver().collectAndResolveSubtypesByClass((MapperConfig)config, ac);
/*      */     } 
/*  323 */     if (b == null) {
/*  324 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  328 */     return b.buildTypeSerializer(config, baseType, subtypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonSerializer<?> findSerializerByLookup(JavaType type, SerializationConfig config, BeanDescription beanDesc, boolean staticTyping) {
/*  353 */     Class<?> raw = type.getRawClass();
/*  354 */     String clsName = raw.getName();
/*  355 */     JsonSerializer<?> ser = _concrete.get(clsName);
/*  356 */     if (ser == null) {
/*  357 */       Class<? extends JsonSerializer<?>> serClass = _concreteLazy.get(clsName);
/*  358 */       if (serClass != null)
/*      */       {
/*      */ 
/*      */         
/*  362 */         return (JsonSerializer)ClassUtil.createInstance(serClass, false);
/*      */       }
/*      */     } 
/*  365 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonSerializer<?> findSerializerByAnnotations(SerializerProvider prov, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*  388 */     Class<?> raw = type.getRawClass();
/*      */     
/*  390 */     if (JsonSerializable.class.isAssignableFrom(raw)) {
/*  391 */       return (JsonSerializer<?>)SerializableSerializer.instance;
/*      */     }
/*      */     
/*  394 */     AnnotatedMember valueAccessor = beanDesc.findJsonValueAccessor();
/*  395 */     if (valueAccessor != null) {
/*  396 */       if (prov.canOverrideAccessModifiers()) {
/*  397 */         ClassUtil.checkAndFixAccess(valueAccessor.getMember(), prov
/*  398 */             .isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*      */       }
/*  400 */       JavaType valueType = valueAccessor.getType();
/*  401 */       JsonSerializer<Object> valueSerializer = findSerializerFromAnnotation(prov, (Annotated)valueAccessor);
/*  402 */       if (valueSerializer == null) {
/*  403 */         valueSerializer = (JsonSerializer<Object>)valueType.getValueHandler();
/*      */       }
/*  405 */       TypeSerializer typeSerializer = (TypeSerializer)valueType.getTypeHandler();
/*  406 */       if (typeSerializer == null) {
/*  407 */         typeSerializer = createTypeSerializer(prov.getConfig(), valueType);
/*      */       }
/*  409 */       return (JsonSerializer<?>)JsonValueSerializer.construct(prov.getConfig(), valueAccessor, typeSerializer, valueSerializer);
/*      */     } 
/*      */ 
/*      */     
/*  413 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonSerializer<?> findSerializerByPrimaryType(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/*  428 */     if (type.isEnumType()) {
/*  429 */       return buildEnumSerializer(prov.getConfig(), type, beanDesc);
/*      */     }
/*      */     
/*  432 */     Class<?> raw = type.getRawClass();
/*      */     
/*  434 */     JsonSerializer<?> ser = findOptionalStdSerializer(prov, type, beanDesc, staticTyping);
/*  435 */     if (ser != null) {
/*  436 */       return ser;
/*      */     }
/*      */     
/*  439 */     if (Calendar.class.isAssignableFrom(raw)) {
/*  440 */       return (JsonSerializer<?>)CalendarSerializer.instance;
/*      */     }
/*  442 */     if (Date.class.isAssignableFrom(raw)) {
/*  443 */       return (JsonSerializer<?>)DateSerializer.instance;
/*      */     }
/*  445 */     if (Map.Entry.class.isAssignableFrom(raw)) {
/*      */       
/*  447 */       JavaType mapEntryType = type.findSuperType(Map.Entry.class);
/*      */ 
/*      */       
/*  450 */       JavaType kt = mapEntryType.containedTypeOrUnknown(0);
/*  451 */       JavaType vt = mapEntryType.containedTypeOrUnknown(1);
/*  452 */       return buildMapEntrySerializer(prov, type, beanDesc, staticTyping, kt, vt);
/*      */     } 
/*  454 */     if (ByteBuffer.class.isAssignableFrom(raw)) {
/*  455 */       return (JsonSerializer<?>)new ByteBufferSerializer();
/*      */     }
/*  457 */     if (InetAddress.class.isAssignableFrom(raw)) {
/*  458 */       return (JsonSerializer<?>)new InetAddressSerializer();
/*      */     }
/*  460 */     if (InetSocketAddress.class.isAssignableFrom(raw)) {
/*  461 */       return (JsonSerializer<?>)new InetSocketAddressSerializer();
/*      */     }
/*  463 */     if (TimeZone.class.isAssignableFrom(raw)) {
/*  464 */       return (JsonSerializer<?>)new TimeZoneSerializer();
/*      */     }
/*  466 */     if (Charset.class.isAssignableFrom(raw)) {
/*  467 */       return (JsonSerializer<?>)ToStringSerializer.instance;
/*      */     }
/*  469 */     if (Number.class.isAssignableFrom(raw)) {
/*      */       
/*  471 */       JsonFormat.Value format = beanDesc.findExpectedFormat();
/*  472 */       switch (format.getShape()) {
/*      */         case DYNAMIC:
/*  474 */           return (JsonSerializer<?>)ToStringSerializer.instance;
/*      */         case STATIC:
/*      */         case DEFAULT_TYPING:
/*  477 */           return null;
/*      */       } 
/*      */       
/*  480 */       return (JsonSerializer<?>)NumberSerializer.instance;
/*      */     } 
/*      */     
/*  483 */     if (ClassLoader.class.isAssignableFrom(raw)) {
/*  484 */       return (JsonSerializer<?>)new ToEmptyObjectSerializer(type);
/*      */     }
/*  486 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> findOptionalStdSerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/*  498 */     return OptionalHandlerFactory.instance.findSerializer(prov.getConfig(), type, beanDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonSerializer<?> findSerializerByAddonType(SerializationConfig config, JavaType javaType, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/*  512 */     Class<?> rawType = javaType.getRawClass();
/*      */     
/*  514 */     if (Iterator.class.isAssignableFrom(rawType)) {
/*  515 */       JavaType[] params = config.getTypeFactory().findTypeParameters(javaType, Iterator.class);
/*      */       
/*  517 */       JavaType vt = (params == null || params.length != 1) ? TypeFactory.unknownType() : params[0];
/*  518 */       return buildIteratorSerializer(config, javaType, beanDesc, staticTyping, vt);
/*      */     } 
/*  520 */     if (Iterable.class.isAssignableFrom(rawType)) {
/*  521 */       JavaType[] params = config.getTypeFactory().findTypeParameters(javaType, Iterable.class);
/*      */       
/*  523 */       JavaType vt = (params == null || params.length != 1) ? TypeFactory.unknownType() : params[0];
/*  524 */       return buildIterableSerializer(config, javaType, beanDesc, staticTyping, vt);
/*      */     } 
/*  526 */     if (CharSequence.class.isAssignableFrom(rawType)) {
/*  527 */       return (JsonSerializer<?>)ToStringSerializer.instance;
/*      */     }
/*  529 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> findSerializerFromAnnotation(SerializerProvider prov, Annotated a) throws JsonMappingException {
/*  544 */     Object serDef = prov.getAnnotationIntrospector().findSerializer(a);
/*  545 */     if (serDef == null) {
/*  546 */       return null;
/*      */     }
/*  548 */     JsonSerializer<Object> ser = prov.serializerInstance(a, serDef);
/*      */     
/*  550 */     return (JsonSerializer)findConvertingSerializer(prov, a, ser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> findConvertingSerializer(SerializerProvider prov, Annotated a, JsonSerializer<?> ser) throws JsonMappingException {
/*  563 */     Converter<Object, Object> conv = findConverter(prov, a);
/*  564 */     if (conv == null) {
/*  565 */       return ser;
/*      */     }
/*  567 */     JavaType delegateType = conv.getOutputType(prov.getTypeFactory());
/*  568 */     return (JsonSerializer<?>)new StdDelegatingSerializer(conv, delegateType, ser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Converter<Object, Object> findConverter(SerializerProvider prov, Annotated a) throws JsonMappingException {
/*  575 */     Object convDef = prov.getAnnotationIntrospector().findSerializationConverter(a);
/*  576 */     if (convDef == null) {
/*  577 */       return null;
/*      */     }
/*  579 */     return prov.converterInstance(a, convDef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildContainerSerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/*  595 */     SerializationConfig config = prov.getConfig();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  601 */     if (!staticTyping && type.useStaticType() && (
/*  602 */       !type.isContainerType() || !type.getContentType().isJavaLangObject())) {
/*  603 */       staticTyping = true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  608 */     JavaType elementType = type.getContentType();
/*  609 */     TypeSerializer elementTypeSerializer = createTypeSerializer(config, elementType);
/*      */ 
/*      */ 
/*      */     
/*  613 */     if (elementTypeSerializer != null) {
/*  614 */       staticTyping = false;
/*      */     }
/*  616 */     JsonSerializer<Object> elementValueSerializer = _findContentSerializer(prov, (Annotated)beanDesc
/*  617 */         .getClassInfo());
/*  618 */     if (type.isMapLikeType()) {
/*  619 */       MapLikeType mlt = (MapLikeType)type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  625 */       JsonSerializer<Object> keySerializer = _findKeySerializer(prov, (Annotated)beanDesc.getClassInfo());
/*  626 */       if (mlt instanceof MapType) {
/*  627 */         return buildMapSerializer(prov, (MapType)mlt, beanDesc, staticTyping, keySerializer, elementTypeSerializer, elementValueSerializer);
/*      */       }
/*      */ 
/*      */       
/*  631 */       JsonSerializer<?> ser = null;
/*  632 */       MapLikeType mlType = (MapLikeType)type;
/*  633 */       for (Serializers serializers : customSerializers()) {
/*  634 */         ser = serializers.findMapLikeSerializer(config, mlType, beanDesc, keySerializer, elementTypeSerializer, elementValueSerializer);
/*      */         
/*  636 */         if (ser != null) {
/*      */           break;
/*      */         }
/*      */       } 
/*  640 */       if (ser == null) {
/*  641 */         ser = findSerializerByAnnotations(prov, type, beanDesc);
/*      */       }
/*  643 */       if (ser != null && 
/*  644 */         this._factoryConfig.hasSerializerModifiers()) {
/*  645 */         for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/*  646 */           ser = mod.modifyMapLikeSerializer(config, mlType, beanDesc, ser);
/*      */         }
/*      */       }
/*      */       
/*  650 */       return ser;
/*      */     } 
/*  652 */     if (type.isCollectionLikeType()) {
/*  653 */       CollectionLikeType clt = (CollectionLikeType)type;
/*  654 */       if (clt instanceof CollectionType) {
/*  655 */         return buildCollectionSerializer(prov, (CollectionType)clt, beanDesc, staticTyping, elementTypeSerializer, elementValueSerializer);
/*      */       }
/*      */ 
/*      */       
/*  659 */       JsonSerializer<?> ser = null;
/*  660 */       CollectionLikeType clType = (CollectionLikeType)type;
/*  661 */       for (Serializers serializers : customSerializers()) {
/*  662 */         ser = serializers.findCollectionLikeSerializer(config, clType, beanDesc, elementTypeSerializer, elementValueSerializer);
/*      */         
/*  664 */         if (ser != null) {
/*      */           break;
/*      */         }
/*      */       } 
/*  668 */       if (ser == null) {
/*  669 */         ser = findSerializerByAnnotations(prov, type, beanDesc);
/*      */       }
/*  671 */       if (ser != null && 
/*  672 */         this._factoryConfig.hasSerializerModifiers()) {
/*  673 */         for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/*  674 */           ser = mod.modifyCollectionLikeSerializer(config, clType, beanDesc, ser);
/*      */         }
/*      */       }
/*      */       
/*  678 */       return ser;
/*      */     } 
/*  680 */     if (type.isArrayType()) {
/*  681 */       return buildArraySerializer(prov, (ArrayType)type, beanDesc, staticTyping, elementTypeSerializer, elementValueSerializer);
/*      */     }
/*      */     
/*  684 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildCollectionSerializer(SerializerProvider prov, CollectionType type, BeanDescription beanDesc, boolean staticTyping, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer) throws JsonMappingException {
/*      */     ContainerSerializer<?> containerSerializer;
/*      */     JsonSerializer<?> jsonSerializer1;
/*  698 */     SerializationConfig config = prov.getConfig();
/*  699 */     JsonSerializer<?> ser = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  704 */     for (Serializers serializers : customSerializers()) {
/*  705 */       ser = serializers.findCollectionSerializer(config, type, beanDesc, elementTypeSerializer, elementValueSerializer);
/*      */       
/*  707 */       if (ser != null) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/*  712 */     if (ser == null) {
/*  713 */       ser = findSerializerByAnnotations(prov, (JavaType)type, beanDesc);
/*  714 */       if (ser == null) {
/*      */ 
/*      */         
/*  717 */         JsonFormat.Value format = beanDesc.findExpectedFormat();
/*  718 */         if (format.getShape() == JsonFormat.Shape.OBJECT) {
/*  719 */           return null;
/*      */         }
/*  721 */         Class<?> raw = type.getRawClass();
/*  722 */         if (EnumSet.class.isAssignableFrom(raw)) {
/*      */           
/*  724 */           JavaType enumType = type.getContentType();
/*      */           
/*  726 */           if (!enumType.isEnumImplType()) {
/*  727 */             enumType = null;
/*      */           }
/*  729 */           ser = buildEnumSetSerializer(enumType);
/*      */         } else {
/*  731 */           StringCollectionSerializer stringCollectionSerializer; Class<?> elementRaw = type.getContentType().getRawClass();
/*  732 */           if (isIndexedList(raw)) {
/*  733 */             if (elementRaw == String.class) {
/*      */               
/*  735 */               if (ClassUtil.isJacksonStdImpl(elementValueSerializer)) {
/*  736 */                 IndexedStringListSerializer indexedStringListSerializer = IndexedStringListSerializer.instance;
/*      */               }
/*      */             } else {
/*  739 */               containerSerializer = buildIndexedListSerializer(type.getContentType(), staticTyping, elementTypeSerializer, elementValueSerializer);
/*      */             }
/*      */           
/*  742 */           } else if (elementRaw == String.class) {
/*      */             
/*  744 */             if (ClassUtil.isJacksonStdImpl(elementValueSerializer)) {
/*  745 */               stringCollectionSerializer = StringCollectionSerializer.instance;
/*      */             }
/*      */           } 
/*  748 */           if (stringCollectionSerializer == null) {
/*  749 */             containerSerializer = buildCollectionSerializer(type.getContentType(), staticTyping, elementTypeSerializer, elementValueSerializer);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  756 */     if (this._factoryConfig.hasSerializerModifiers()) {
/*  757 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/*  758 */         jsonSerializer1 = mod.modifyCollectionSerializer(config, type, beanDesc, (JsonSerializer<?>)containerSerializer);
/*      */       }
/*      */     }
/*  761 */     return jsonSerializer1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isIndexedList(Class<?> cls) {
/*  772 */     return RandomAccess.class.isAssignableFrom(cls);
/*      */   }
/*      */ 
/*      */   
/*      */   public ContainerSerializer<?> buildIndexedListSerializer(JavaType elemType, boolean staticTyping, TypeSerializer vts, JsonSerializer<Object> valueSerializer) {
/*  777 */     return (ContainerSerializer<?>)new IndexedListSerializer(elemType, staticTyping, vts, valueSerializer);
/*      */   }
/*      */ 
/*      */   
/*      */   public ContainerSerializer<?> buildCollectionSerializer(JavaType elemType, boolean staticTyping, TypeSerializer vts, JsonSerializer<Object> valueSerializer) {
/*  782 */     return (ContainerSerializer<?>)new CollectionSerializer(elemType, staticTyping, vts, valueSerializer);
/*      */   }
/*      */   
/*      */   public JsonSerializer<?> buildEnumSetSerializer(JavaType enumType) {
/*  786 */     return (JsonSerializer<?>)new EnumSetSerializer(enumType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildMapSerializer(SerializerProvider prov, MapType type, BeanDescription beanDesc, boolean staticTyping, JsonSerializer<Object> keySerializer, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer) throws JsonMappingException {
/*      */     MapSerializer mapSerializer;
/*      */     JsonSerializer<?> jsonSerializer1;
/*  807 */     JsonFormat.Value format = beanDesc.findExpectedFormat();
/*  808 */     if (format.getShape() == JsonFormat.Shape.OBJECT) {
/*  809 */       return null;
/*      */     }
/*      */     
/*  812 */     JsonSerializer<?> ser = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  819 */     SerializationConfig config = prov.getConfig();
/*  820 */     for (Serializers serializers : customSerializers()) {
/*  821 */       ser = serializers.findMapSerializer(config, type, beanDesc, keySerializer, elementTypeSerializer, elementValueSerializer);
/*      */       
/*  823 */       if (ser != null)
/*      */         break; 
/*  825 */     }  if (ser == null) {
/*  826 */       ser = findSerializerByAnnotations(prov, (JavaType)type, beanDesc);
/*  827 */       if (ser == null) {
/*  828 */         Object filterId = findFilterId(config, beanDesc);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  833 */         JsonIgnoreProperties.Value ignorals = config.getDefaultPropertyIgnorals(Map.class, beanDesc
/*  834 */             .getClassInfo());
/*      */         
/*  836 */         Set<String> ignored = (ignorals == null) ? null : ignorals.findIgnoredForSerialization();
/*  837 */         JsonIncludeProperties.Value inclusions = config.getDefaultPropertyInclusions(Map.class, beanDesc
/*  838 */             .getClassInfo());
/*      */         
/*  840 */         Set<String> included = (inclusions == null) ? null : inclusions.getIncluded();
/*  841 */         MapSerializer mapSer = MapSerializer.construct(ignored, included, (JavaType)type, staticTyping, elementTypeSerializer, keySerializer, elementValueSerializer, filterId);
/*      */ 
/*      */         
/*  844 */         mapSerializer = _checkMapContentInclusion(prov, beanDesc, mapSer);
/*      */       } 
/*      */     } 
/*      */     
/*  848 */     if (this._factoryConfig.hasSerializerModifiers()) {
/*  849 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/*  850 */         jsonSerializer1 = mod.modifyMapSerializer(config, type, beanDesc, (JsonSerializer<?>)mapSerializer);
/*      */       }
/*      */     }
/*  853 */     return jsonSerializer1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MapSerializer _checkMapContentInclusion(SerializerProvider prov, BeanDescription beanDesc, MapSerializer mapSer) throws JsonMappingException {
/*  867 */     JavaType contentType = mapSer.getContentType();
/*  868 */     JsonInclude.Value inclV = _findInclusionWithContent(prov, beanDesc, contentType, Map.class);
/*      */ 
/*      */ 
/*      */     
/*  872 */     JsonInclude.Include incl = (inclV == null) ? JsonInclude.Include.USE_DEFAULTS : inclV.getContentInclusion();
/*  873 */     if (incl == JsonInclude.Include.USE_DEFAULTS || incl == JsonInclude.Include.ALWAYS) {
/*      */       
/*  875 */       if (!prov.isEnabled(SerializationFeature.WRITE_NULL_MAP_VALUES)) {
/*  876 */         return mapSer.withContentInclusion(null, true);
/*      */       }
/*  878 */       return mapSer;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  884 */     boolean suppressNulls = true;
/*      */     
/*  886 */     switch (incl)
/*      */     { case DYNAMIC:
/*  888 */         valueToSuppress = BeanUtil.getDefaultValue(contentType);
/*  889 */         if (valueToSuppress != null && 
/*  890 */           valueToSuppress.getClass().isArray()) {
/*  891 */           valueToSuppress = ArrayBuilders.getArrayComparator(valueToSuppress);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  914 */         return mapSer.withContentInclusion(valueToSuppress, suppressNulls);case STATIC: valueToSuppress = contentType.isReferenceType() ? MapSerializer.MARKER_FOR_EMPTY : null; return mapSer.withContentInclusion(valueToSuppress, suppressNulls);case DEFAULT_TYPING: valueToSuppress = MapSerializer.MARKER_FOR_EMPTY; return mapSer.withContentInclusion(valueToSuppress, suppressNulls);case null: valueToSuppress = prov.includeFilterInstance(null, inclV.getContentFilter()); if (valueToSuppress != null) suppressNulls = prov.includeFilterSuppressNulls(valueToSuppress);  return mapSer.withContentInclusion(valueToSuppress, suppressNulls); }  Object valueToSuppress = null; return mapSer.withContentInclusion(valueToSuppress, suppressNulls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildMapEntrySerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping, JavaType keyType, JavaType valueType) throws JsonMappingException {
/*  927 */     JsonFormat.Value formatOverride = prov.getDefaultPropertyFormat(Map.Entry.class);
/*  928 */     JsonFormat.Value formatFromAnnotation = beanDesc.findExpectedFormat();
/*  929 */     JsonFormat.Value format = JsonFormat.Value.merge(formatFromAnnotation, formatOverride);
/*  930 */     if (format.getShape() == JsonFormat.Shape.OBJECT) {
/*  931 */       return null;
/*      */     }
/*      */     
/*  934 */     MapEntrySerializer ser = new MapEntrySerializer(valueType, keyType, valueType, staticTyping, createTypeSerializer(prov.getConfig(), valueType), null);
/*      */     
/*  936 */     JavaType contentType = ser.getContentType();
/*  937 */     JsonInclude.Value inclV = _findInclusionWithContent(prov, beanDesc, contentType, Map.Entry.class);
/*      */ 
/*      */ 
/*      */     
/*  941 */     JsonInclude.Include incl = (inclV == null) ? JsonInclude.Include.USE_DEFAULTS : inclV.getContentInclusion();
/*  942 */     if (incl == JsonInclude.Include.USE_DEFAULTS || incl == JsonInclude.Include.ALWAYS)
/*      */     {
/*  944 */       return (JsonSerializer<?>)ser;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  950 */     boolean suppressNulls = true;
/*      */     
/*  952 */     switch (incl)
/*      */     { case DYNAMIC:
/*  954 */         valueToSuppress = BeanUtil.getDefaultValue(contentType);
/*  955 */         if (valueToSuppress != null && 
/*  956 */           valueToSuppress.getClass().isArray()) {
/*  957 */           valueToSuppress = ArrayBuilders.getArrayComparator(valueToSuppress);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  979 */         return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls);case STATIC: valueToSuppress = contentType.isReferenceType() ? MapSerializer.MARKER_FOR_EMPTY : null; return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls);case DEFAULT_TYPING: valueToSuppress = MapSerializer.MARKER_FOR_EMPTY; return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls);case null: valueToSuppress = prov.includeFilterInstance(null, inclV.getContentFilter()); if (valueToSuppress != null) suppressNulls = prov.includeFilterSuppressNulls(valueToSuppress);  return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls); }  Object valueToSuppress = null; return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonInclude.Value _findInclusionWithContent(SerializerProvider prov, BeanDescription beanDesc, JavaType contentType, Class<?> configType) throws JsonMappingException {
/*  995 */     SerializationConfig config = prov.getConfig();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1002 */     JsonInclude.Value inclV = beanDesc.findPropertyInclusion(config.getDefaultPropertyInclusion());
/* 1003 */     inclV = config.getDefaultPropertyInclusion(configType, inclV);
/*      */ 
/*      */ 
/*      */     
/* 1007 */     JsonInclude.Value valueIncl = config.getDefaultPropertyInclusion(contentType.getRawClass(), null);
/*      */     
/* 1009 */     if (valueIncl != null) {
/* 1010 */       switch (valueIncl.getValueInclusion()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case null:
/* 1020 */           return inclV;
/*      */         case null:
/*      */           inclV = inclV.withContentFilter(valueIncl.getContentFilter());
/*      */       } 
/*      */       inclV = inclV.withContentInclusion(valueIncl.getValueInclusion());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildArraySerializer(SerializerProvider prov, ArrayType type, BeanDescription beanDesc, boolean staticTyping, TypeSerializer elementTypeSerializer, JsonSerializer<Object> elementValueSerializer) throws JsonMappingException {
/*      */     ObjectArraySerializer objectArraySerializer;
/*      */     JsonSerializer<?> jsonSerializer1;
/* 1043 */     SerializationConfig config = prov.getConfig();
/* 1044 */     JsonSerializer<?> ser = null;
/*      */     
/* 1046 */     for (Serializers serializers : customSerializers()) {
/* 1047 */       ser = serializers.findArraySerializer(config, type, beanDesc, elementTypeSerializer, elementValueSerializer);
/*      */       
/* 1049 */       if (ser != null) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/* 1054 */     if (ser == null) {
/* 1055 */       Class<?> raw = type.getRawClass();
/*      */       
/* 1057 */       if (elementValueSerializer == null || ClassUtil.isJacksonStdImpl(elementValueSerializer)) {
/* 1058 */         if (String[].class == raw) {
/* 1059 */           StringArraySerializer stringArraySerializer = StringArraySerializer.instance;
/*      */         } else {
/*      */           
/* 1062 */           ser = StdArraySerializers.findStandardImpl(raw);
/*      */         } 
/*      */       }
/* 1065 */       if (ser == null) {
/* 1066 */         objectArraySerializer = new ObjectArraySerializer(type.getContentType(), staticTyping, elementTypeSerializer, elementValueSerializer);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1071 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 1072 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 1073 */         jsonSerializer1 = mod.modifyArraySerializer(config, type, beanDesc, (JsonSerializer<?>)objectArraySerializer);
/*      */       }
/*      */     }
/* 1076 */     return jsonSerializer1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<?> findReferenceSerializer(SerializerProvider prov, ReferenceType refType, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/* 1093 */     JavaType contentType = refType.getContentType();
/* 1094 */     TypeSerializer contentTypeSerializer = (TypeSerializer)contentType.getTypeHandler();
/* 1095 */     SerializationConfig config = prov.getConfig();
/* 1096 */     if (contentTypeSerializer == null) {
/* 1097 */       contentTypeSerializer = createTypeSerializer(config, contentType);
/*      */     }
/* 1099 */     JsonSerializer<Object> contentSerializer = (JsonSerializer<Object>)contentType.getValueHandler();
/* 1100 */     for (Serializers serializers : customSerializers()) {
/* 1101 */       JsonSerializer<?> ser = serializers.findReferenceSerializer(config, refType, beanDesc, contentTypeSerializer, contentSerializer);
/*      */       
/* 1103 */       if (ser != null) {
/* 1104 */         return ser;
/*      */       }
/*      */     } 
/* 1107 */     if (refType.isTypeOrSubTypeOf(AtomicReference.class)) {
/* 1108 */       return buildAtomicReferenceSerializer(prov, refType, beanDesc, staticTyping, contentTypeSerializer, contentSerializer);
/*      */     }
/*      */     
/* 1111 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildAtomicReferenceSerializer(SerializerProvider prov, ReferenceType refType, BeanDescription beanDesc, boolean staticTyping, TypeSerializer contentTypeSerializer, JsonSerializer<Object> contentSerializer) throws JsonMappingException {
/*      */     Object valueToSuppress;
/*      */     boolean suppressNulls;
/* 1119 */     JavaType contentType = refType.getReferencedType();
/* 1120 */     JsonInclude.Value inclV = _findInclusionWithContent(prov, beanDesc, contentType, AtomicReference.class);
/*      */ 
/*      */ 
/*      */     
/* 1124 */     JsonInclude.Include incl = (inclV == null) ? JsonInclude.Include.USE_DEFAULTS : inclV.getContentInclusion();
/*      */ 
/*      */ 
/*      */     
/* 1128 */     if (incl == JsonInclude.Include.USE_DEFAULTS || incl == JsonInclude.Include.ALWAYS)
/*      */     
/* 1130 */     { valueToSuppress = null;
/* 1131 */       suppressNulls = false; }
/*      */     else
/* 1133 */     { AtomicReferenceSerializer ser; suppressNulls = true;
/* 1134 */       switch (incl)
/*      */       { case DYNAMIC:
/* 1136 */           valueToSuppress = BeanUtil.getDefaultValue(contentType);
/* 1137 */           if (valueToSuppress != null && 
/* 1138 */             valueToSuppress.getClass().isArray()) {
/* 1139 */             valueToSuppress = ArrayBuilders.getArrayComparator(valueToSuppress);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1164 */           ser = new AtomicReferenceSerializer(refType, staticTyping, contentTypeSerializer, contentSerializer);
/*      */           
/* 1166 */           return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls);case STATIC: valueToSuppress = contentType.isReferenceType() ? MapSerializer.MARKER_FOR_EMPTY : null; ser = new AtomicReferenceSerializer(refType, staticTyping, contentTypeSerializer, contentSerializer); return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls);case DEFAULT_TYPING: valueToSuppress = MapSerializer.MARKER_FOR_EMPTY; ser = new AtomicReferenceSerializer(refType, staticTyping, contentTypeSerializer, contentSerializer); return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls);case null: valueToSuppress = prov.includeFilterInstance(null, inclV.getContentFilter()); if (valueToSuppress == null) { suppressNulls = true; } else { suppressNulls = prov.includeFilterSuppressNulls(valueToSuppress); }  ser = new AtomicReferenceSerializer(refType, staticTyping, contentTypeSerializer, contentSerializer); return (JsonSerializer<?>)ser.withContentInclusion(valueToSuppress, suppressNulls); }  valueToSuppress = null; }  AtomicReferenceSerializer atomicReferenceSerializer = new AtomicReferenceSerializer(refType, staticTyping, contentTypeSerializer, contentSerializer); return (JsonSerializer<?>)atomicReferenceSerializer.withContentInclusion(valueToSuppress, suppressNulls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildIteratorSerializer(SerializationConfig config, JavaType type, BeanDescription beanDesc, boolean staticTyping, JavaType valueType) throws JsonMappingException {
/* 1183 */     return (JsonSerializer<?>)new IteratorSerializer(valueType, staticTyping, createTypeSerializer(config, valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildIterableSerializer(SerializationConfig config, JavaType type, BeanDescription beanDesc, boolean staticTyping, JavaType valueType) throws JsonMappingException {
/* 1194 */     return (JsonSerializer<?>)new IterableSerializer(valueType, staticTyping, createTypeSerializer(config, valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<?> buildEnumSerializer(SerializationConfig config, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*      */     JsonSerializer<?> jsonSerializer;
/* 1206 */     JsonFormat.Value format = beanDesc.findExpectedFormat();
/* 1207 */     if (format.getShape() == JsonFormat.Shape.OBJECT) {
/*      */       
/* 1209 */       ((BasicBeanDescription)beanDesc).removeProperty("declaringClass");
/*      */       
/* 1211 */       if (type.isEnumType()) {
/* 1212 */         _removeEnumSelfReferences(beanDesc);
/*      */       }
/*      */       
/* 1215 */       return null;
/*      */     } 
/*      */     
/* 1218 */     Class<Enum<?>> enumClass = type.getRawClass();
/* 1219 */     EnumSerializer enumSerializer = EnumSerializer.construct(enumClass, config, beanDesc, format);
/*      */     
/* 1221 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 1222 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 1223 */         jsonSerializer = mod.modifyEnumSerializer(config, type, beanDesc, (JsonSerializer<?>)enumSerializer);
/*      */       }
/*      */     }
/* 1226 */     return jsonSerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _removeEnumSelfReferences(BeanDescription beanDesc) {
/* 1242 */     Class<?> aClass = ClassUtil.findEnumType(beanDesc.getBeanClass());
/* 1243 */     Iterator<BeanPropertyDefinition> it = beanDesc.findProperties().iterator();
/* 1244 */     while (it.hasNext()) {
/* 1245 */       BeanPropertyDefinition property = it.next();
/* 1246 */       JavaType propType = property.getPrimaryType();
/*      */       
/* 1248 */       if (propType.isEnumType() && propType.isTypeOrSubTypeOf(aClass) && property
/*      */         
/* 1250 */         .getAccessor().isStatic())
/*      */       {
/* 1252 */         it.remove();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _findKeySerializer(SerializerProvider prov, Annotated a) throws JsonMappingException {
/* 1272 */     AnnotationIntrospector intr = prov.getAnnotationIntrospector();
/* 1273 */     Object serDef = intr.findKeySerializer(a);
/* 1274 */     if (serDef != null) {
/* 1275 */       return prov.serializerInstance(a, serDef);
/*      */     }
/* 1277 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _findContentSerializer(SerializerProvider prov, Annotated a) throws JsonMappingException {
/* 1289 */     AnnotationIntrospector intr = prov.getAnnotationIntrospector();
/* 1290 */     Object serDef = intr.findContentSerializer(a);
/* 1291 */     if (serDef != null) {
/* 1292 */       return prov.serializerInstance(a, serDef);
/*      */     }
/* 1294 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object findFilterId(SerializationConfig config, BeanDescription beanDesc) {
/* 1302 */     return config.getAnnotationIntrospector().findFilterId((Annotated)beanDesc.getClassInfo());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean usesStaticTyping(SerializationConfig config, BeanDescription beanDesc) {
/* 1316 */     JsonSerialize.Typing t = config.getAnnotationIntrospector().findSerializationTyping((Annotated)beanDesc.getClassInfo());
/* 1317 */     if (t != null) {
/* 1318 */       switch (t) {
/*      */         case DYNAMIC:
/* 1320 */           return false;
/*      */         case STATIC:
/* 1322 */           return true;
/*      */       } 
/*      */ 
/*      */     
/*      */     }
/* 1327 */     return config.isEnabled(MapperFeature.USE_STATIC_TYPING);
/*      */   }
/*      */   
/*      */   public abstract SerializerFactory withConfig(SerializerFactoryConfig paramSerializerFactoryConfig);
/*      */   
/*      */   public abstract JsonSerializer<Object> createSerializer(SerializerProvider paramSerializerProvider, JavaType paramJavaType) throws JsonMappingException;
/*      */   
/*      */   protected abstract Iterable<Serializers> customSerializers();
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\BasicSerializerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */