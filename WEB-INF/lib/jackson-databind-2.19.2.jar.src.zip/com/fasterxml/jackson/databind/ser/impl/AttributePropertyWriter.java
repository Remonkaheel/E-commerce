/*    */ package com.fasterxml.jackson.databind.ser.impl;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonInclude;
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*    */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*    */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*    */ import com.fasterxml.jackson.databind.ser.VirtualBeanPropertyWriter;
/*    */ import com.fasterxml.jackson.databind.util.Annotations;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttributePropertyWriter
/*    */   extends VirtualBeanPropertyWriter
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected final String _attrName;
/*    */   
/*    */   protected AttributePropertyWriter(String attrName, BeanPropertyDefinition propDef, Annotations contextAnnotations, JavaType declaredType) {
/* 36 */     this(attrName, propDef, contextAnnotations, declaredType, propDef.findInclusion());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected AttributePropertyWriter(String attrName, BeanPropertyDefinition propDef, Annotations contextAnnotations, JavaType declaredType, JsonInclude.Value inclusion) {
/* 43 */     super(propDef, contextAnnotations, declaredType, null, null, null, inclusion, null);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 48 */     this._attrName = attrName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static AttributePropertyWriter construct(String attrName, BeanPropertyDefinition propDef, Annotations contextAnnotations, JavaType declaredType) {
/* 56 */     return new AttributePropertyWriter(attrName, propDef, contextAnnotations, declaredType);
/*    */   }
/*    */ 
/*    */   
/*    */   protected AttributePropertyWriter(AttributePropertyWriter base) {
/* 61 */     super(base);
/* 62 */     this._attrName = base._attrName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public VirtualBeanPropertyWriter withConfig(MapperConfig<?> config, AnnotatedClass declaringClass, BeanPropertyDefinition propDef, JavaType type) {
/* 72 */     throw new IllegalStateException("Should not be called on this type");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Object value(Object bean, JsonGenerator jgen, SerializerProvider prov) throws Exception {
/* 83 */     return prov.getAttribute(this._attrName);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\impl\AttributePropertyWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */