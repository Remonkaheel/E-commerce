/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.ContainerSerializer;
/*     */ import java.io.IOException;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class IterableSerializer
/*     */   extends AsArraySerializerBase<Iterable<?>> {
/*     */   public IterableSerializer(JavaType elemType, boolean staticTyping, TypeSerializer vts) {
/*  19 */     super(Iterable.class, elemType, staticTyping, vts, (JsonSerializer)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IterableSerializer(IterableSerializer src, BeanProperty property, TypeSerializer vts, JsonSerializer<?> valueSerializer, Boolean unwrapSingle) {
/*  25 */     super(src, property, vts, valueSerializer, unwrapSingle);
/*     */   }
/*     */ 
/*     */   
/*     */   public ContainerSerializer<?> _withValueTypeSerializer(TypeSerializer vts) {
/*  30 */     return new IterableSerializer(this, this._property, vts, this._elementSerializer, this._unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IterableSerializer withResolved(BeanProperty property, TypeSerializer vts, JsonSerializer<?> elementSerializer, Boolean unwrapSingle) {
/*  37 */     return new IterableSerializer(this, property, vts, elementSerializer, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty(SerializerProvider prov, Iterable<?> value) {
/*  43 */     return !value.iterator().hasNext();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasSingleElement(Iterable<?> value) {
/*  49 */     if (value != null) {
/*  50 */       Iterator<?> it = value.iterator();
/*  51 */       if (it.hasNext()) {
/*  52 */         it.next();
/*  53 */         return !it.hasNext();
/*     */       } 
/*     */     } 
/*  56 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void serialize(Iterable<?> value, JsonGenerator gen, SerializerProvider provider) throws IOException {
/*  63 */     if ((this._unwrapSingle == null && provider
/*  64 */       .isEnabled(SerializationFeature.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED)) || this._unwrapSingle == Boolean.TRUE)
/*     */     {
/*  66 */       if (hasSingleElement(value)) {
/*  67 */         serializeContents(value, gen, provider);
/*     */         return;
/*     */       } 
/*     */     }
/*  71 */     gen.writeStartArray(value);
/*  72 */     serializeContents(value, gen, provider);
/*  73 */     gen.writeEndArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeContents(Iterable<?> value, JsonGenerator jgen, SerializerProvider provider) throws IOException {
/*  80 */     Iterator<?> it = value.iterator();
/*  81 */     if (it.hasNext()) {
/*  82 */       TypeSerializer typeSer = this._valueTypeSerializer;
/*  83 */       JsonSerializer<Object> prevSerializer = null;
/*  84 */       Class<?> prevClass = null;
/*     */       
/*     */       do {
/*  87 */         Object elem = it.next();
/*  88 */         if (elem == null) {
/*  89 */           provider.defaultSerializeNull(jgen);
/*     */         } else {
/*     */           
/*  92 */           JsonSerializer<Object> currSerializer = this._elementSerializer;
/*  93 */           if (currSerializer == null) {
/*     */             
/*  95 */             Class<?> cc = elem.getClass();
/*  96 */             if (cc == prevClass) {
/*  97 */               currSerializer = prevSerializer;
/*     */             } else {
/*  99 */               currSerializer = provider.findValueSerializer(cc, this._property);
/* 100 */               prevSerializer = currSerializer;
/* 101 */               prevClass = cc;
/*     */             } 
/*     */           } 
/* 104 */           if (typeSer == null)
/* 105 */           { currSerializer.serialize(elem, jgen, provider); }
/*     */           else
/* 107 */           { currSerializer.serializeWithType(elem, jgen, provider, typeSer); } 
/*     */         } 
/* 109 */       } while (it.hasNext());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\IterableSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */