/*     */ package com.fasterxml.jackson.databind.ser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.ser.BeanPropertyFilter;
/*     */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*     */ import com.fasterxml.jackson.databind.ser.PropertyFilter;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleFilterProvider
/*     */   extends FilterProvider
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final Map<String, PropertyFilter> _filtersById;
/*     */   protected PropertyFilter _defaultFilter;
/*     */   protected boolean _cfgFailOnUnknownId = true;
/*     */   
/*     */   public SimpleFilterProvider() {
/*  50 */     this(new HashMap<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleFilterProvider(Map<String, ?> mapping) {
/*  63 */     for (Object ob : mapping.values()) {
/*  64 */       if (!(ob instanceof PropertyFilter)) {
/*  65 */         this._filtersById = _convert(mapping);
/*     */         return;
/*     */       } 
/*     */     } 
/*  69 */     this._filtersById = (Map)mapping;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Map<String, PropertyFilter> _convert(Map<String, ?> filters) {
/*  75 */     HashMap<String, PropertyFilter> result = new HashMap<>();
/*  76 */     for (Map.Entry<String, ?> entry : filters.entrySet()) {
/*  77 */       Object f = entry.getValue();
/*  78 */       if (f instanceof PropertyFilter) {
/*  79 */         result.put(entry.getKey(), (PropertyFilter)f); continue;
/*  80 */       }  if (f instanceof BeanPropertyFilter) {
/*  81 */         result.put(entry.getKey(), _convert((BeanPropertyFilter)f)); continue;
/*     */       } 
/*  83 */       throw new IllegalArgumentException("Unrecognized filter type (" + f.getClass().getName() + ")");
/*     */     } 
/*     */     
/*  86 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final PropertyFilter _convert(BeanPropertyFilter f) {
/*  91 */     return SimpleBeanPropertyFilter.from(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SimpleFilterProvider setDefaultFilter(BeanPropertyFilter f) {
/* 105 */     this._defaultFilter = SimpleBeanPropertyFilter.from(f);
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleFilterProvider setDefaultFilter(PropertyFilter f) {
/* 119 */     this._defaultFilter = f;
/* 120 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleFilterProvider setDefaultFilter(SimpleBeanPropertyFilter f) {
/* 128 */     this._defaultFilter = f;
/* 129 */     return this;
/*     */   }
/*     */   
/*     */   public PropertyFilter getDefaultFilter() {
/* 133 */     return this._defaultFilter;
/*     */   }
/*     */   
/*     */   public SimpleFilterProvider setFailOnUnknownId(boolean state) {
/* 137 */     this._cfgFailOnUnknownId = state;
/* 138 */     return this;
/*     */   }
/*     */   
/*     */   public boolean willFailOnUnknownId() {
/* 142 */     return this._cfgFailOnUnknownId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SimpleFilterProvider addFilter(String id, BeanPropertyFilter filter) {
/* 150 */     this._filtersById.put(id, _convert(filter));
/* 151 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleFilterProvider addFilter(String id, PropertyFilter filter) {
/* 170 */     this._filtersById.put(id, filter);
/* 171 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleFilterProvider addFilter(String id, SimpleBeanPropertyFilter filter) {
/* 193 */     this._filtersById.put(id, filter);
/* 194 */     return this;
/*     */   }
/*     */   
/*     */   public PropertyFilter removeFilter(String id) {
/* 198 */     return this._filtersById.remove(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public BeanPropertyFilter findFilter(Object filterId) {
/* 211 */     throw new UnsupportedOperationException("Access to deprecated filters not supported");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyFilter findPropertyFilter(Object filterId, Object valueToFilter) {
/* 217 */     PropertyFilter f = this._filtersById.get(filterId);
/* 218 */     if (f == null) {
/* 219 */       f = this._defaultFilter;
/* 220 */       if (f == null && this._cfgFailOnUnknownId) {
/* 221 */         throw new IllegalArgumentException("No filter configured with id '" + filterId + "' (type " + filterId
/* 222 */             .getClass().getName() + ")");
/*     */       }
/*     */     } 
/* 225 */     return f;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\impl\SimpleFilterProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */