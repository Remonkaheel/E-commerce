/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.ser.impl.PropertySerializerMap;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.EnumValues;
/*     */ import java.io.IOException;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ 
/*     */ public abstract class StdKeySerializers {
/*  19 */   protected static final JsonSerializer<Object> DEFAULT_KEY_SERIALIZER = new StdKeySerializer();
/*     */   
/*  21 */   protected static final JsonSerializer<Object> DEFAULT_STRING_SERIALIZER = new StringKeySerializer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonSerializer<Object> getStdKeySerializer(SerializationConfig config, Class<?> rawKeyType, boolean useDefault) {
/*  39 */     if (rawKeyType == null || rawKeyType == Object.class) {
/*  40 */       return new Dynamic();
/*     */     }
/*  42 */     if (rawKeyType == String.class) {
/*  43 */       return DEFAULT_STRING_SERIALIZER;
/*     */     }
/*  45 */     if (rawKeyType.isPrimitive()) {
/*  46 */       rawKeyType = ClassUtil.wrapperType(rawKeyType);
/*     */     }
/*  48 */     if (rawKeyType == Integer.class) {
/*  49 */       return new Default(5, rawKeyType);
/*     */     }
/*  51 */     if (rawKeyType == Long.class) {
/*  52 */       return new Default(6, rawKeyType);
/*     */     }
/*  54 */     if (rawKeyType.isPrimitive() || Number.class.isAssignableFrom(rawKeyType))
/*     */     {
/*     */       
/*  57 */       return new Default(8, rawKeyType);
/*     */     }
/*  59 */     if (rawKeyType == Class.class) {
/*  60 */       return new Default(3, rawKeyType);
/*     */     }
/*  62 */     if (Date.class.isAssignableFrom(rawKeyType)) {
/*  63 */       return new Default(1, rawKeyType);
/*     */     }
/*  65 */     if (Calendar.class.isAssignableFrom(rawKeyType)) {
/*  66 */       return new Default(2, rawKeyType);
/*     */     }
/*     */     
/*  69 */     if (rawKeyType == UUID.class) {
/*  70 */       return new Default(8, rawKeyType);
/*     */     }
/*  72 */     if (rawKeyType == byte[].class) {
/*  73 */       return new Default(7, rawKeyType);
/*     */     }
/*  75 */     if (useDefault)
/*     */     {
/*  77 */       return new Default(8, rawKeyType);
/*     */     }
/*  79 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonSerializer<Object> getFallbackKeySerializer(SerializationConfig config, Class<?> rawKeyType, AnnotatedClass annotatedClass) {
/*  92 */     if (rawKeyType != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  99 */       if (rawKeyType == Enum.class) {
/* 100 */         return new Dynamic();
/*     */       }
/*     */ 
/*     */       
/* 104 */       if (ClassUtil.isEnumType(rawKeyType)) {
/* 105 */         return EnumKeySerializer.construct(rawKeyType, 
/* 106 */             EnumValues.constructFromName((MapperConfig)config, annotatedClass), 
/* 107 */             EnumSerializer.constructEnumNamingStrategyValues(config, (Class)rawKeyType, annotatedClass));
/*     */       }
/*     */     } 
/*     */     
/* 111 */     return new Default(8, rawKeyType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static JsonSerializer<Object> getDefault() {
/* 119 */     return DEFAULT_KEY_SERIALIZER;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Default
/*     */     extends StdSerializer<Object>
/*     */   {
/*     */     static final int TYPE_DATE = 1;
/*     */ 
/*     */     
/*     */     static final int TYPE_CALENDAR = 2;
/*     */ 
/*     */     
/*     */     static final int TYPE_CLASS = 3;
/*     */     
/*     */     static final int TYPE_ENUM = 4;
/*     */     
/*     */     static final int TYPE_INTEGER = 5;
/*     */     
/*     */     static final int TYPE_LONG = 6;
/*     */     
/*     */     static final int TYPE_BYTE_ARRAY = 7;
/*     */     
/*     */     static final int TYPE_TO_STRING = 8;
/*     */     
/*     */     protected final int _typeId;
/*     */ 
/*     */     
/*     */     public Default(int typeId, Class<?> type) {
/* 149 */       super(type, false);
/* 150 */       this._typeId = typeId;
/*     */     }
/*     */     
/*     */     public void serialize(Object value, JsonGenerator g, SerializerProvider provider) throws IOException {
/*     */       String key, encoded;
/* 155 */       switch (this._typeId) {
/*     */         case 1:
/* 157 */           provider.defaultSerializeDateKey((Date)value, g);
/*     */           return;
/*     */         case 2:
/* 160 */           provider.defaultSerializeDateKey(((Calendar)value).getTimeInMillis(), g);
/*     */           return;
/*     */         case 3:
/* 163 */           g.writeFieldName(((Class)value).getName());
/*     */           return;
/*     */ 
/*     */ 
/*     */         
/*     */         case 4:
/* 169 */           if (provider.isEnabled(SerializationFeature.WRITE_ENUMS_USING_TO_STRING)) {
/* 170 */             key = value.toString();
/*     */           } else {
/* 172 */             Enum<?> e = (Enum)value;
/*     */             
/* 174 */             if (provider.isEnabled(SerializationFeature.WRITE_ENUM_KEYS_USING_INDEX)) {
/* 175 */               key = String.valueOf(e.ordinal());
/*     */             } else {
/* 177 */               key = e.name();
/*     */             } 
/*     */           } 
/* 180 */           g.writeFieldName(key);
/*     */           return;
/*     */         
/*     */         case 5:
/*     */         case 6:
/* 185 */           g.writeFieldId(((Number)value).longValue());
/*     */           return;
/*     */         
/*     */         case 7:
/* 189 */           encoded = provider.getConfig().getBase64Variant().encode((byte[])value);
/* 190 */           g.writeFieldName(encoded);
/*     */           return;
/*     */       } 
/*     */ 
/*     */       
/* 195 */       g.writeFieldName(value.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Dynamic
/*     */     extends StdSerializer<Object>
/*     */   {
/*     */     protected transient PropertySerializerMap _dynamicSerializers;
/*     */ 
/*     */ 
/*     */     
/*     */     public Dynamic() {
/* 210 */       super(String.class, false);
/* 211 */       this._dynamicSerializers = PropertySerializerMap.emptyForProperties();
/*     */     }
/*     */ 
/*     */     
/*     */     Object readResolve() {
/* 216 */       this._dynamicSerializers = PropertySerializerMap.emptyForProperties();
/* 217 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void serialize(Object value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 224 */       Class<?> cls = value.getClass();
/* 225 */       PropertySerializerMap m = this._dynamicSerializers;
/* 226 */       JsonSerializer<Object> ser = m.serializerFor(cls);
/* 227 */       if (ser == null) {
/* 228 */         ser = _findAndAddDynamic(m, cls, provider);
/*     */       }
/* 230 */       ser.serialize(value, g, provider);
/*     */     }
/*     */ 
/*     */     
/*     */     public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 235 */       visitStringFormat(visitor, typeHint);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected JsonSerializer<Object> _findAndAddDynamic(PropertySerializerMap map, Class<?> type, SerializerProvider provider) throws JsonMappingException {
/* 242 */       if (type == Object.class) {
/*     */         
/* 244 */         JsonSerializer<Object> ser = new StdKeySerializers.Default(8, type);
/* 245 */         this._dynamicSerializers = map.newWith(type, ser);
/* 246 */         return ser;
/*     */       } 
/*     */ 
/*     */       
/* 250 */       PropertySerializerMap.SerializerAndMapResult result = map.findAndAddKeySerializer(type, provider, null);
/*     */       
/* 252 */       if (map != result.map) {
/* 253 */         this._dynamicSerializers = result.map;
/*     */       }
/* 255 */       return result.serializer;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class StringKeySerializer
/*     */     extends StdSerializer<Object>
/*     */   {
/*     */     public StringKeySerializer() {
/* 264 */       super(String.class, false);
/*     */     }
/*     */     
/*     */     public void serialize(Object value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 268 */       g.writeFieldName((String)value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class EnumKeySerializer
/*     */     extends StdSerializer<Object>
/*     */   {
/*     */     protected final EnumValues _values;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final EnumValues _valuesByEnumNaming;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected EnumKeySerializer(Class<?> enumType, EnumValues values) {
/* 290 */       super(enumType, false);
/* 291 */       this._values = values;
/* 292 */       this._valuesByEnumNaming = null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected EnumKeySerializer(Class<?> enumType, EnumValues values, EnumValues valuesByEnumNaming) {
/* 299 */       super(enumType, false);
/* 300 */       this._values = values;
/* 301 */       this._valuesByEnumNaming = valuesByEnumNaming;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public static EnumKeySerializer construct(Class<?> enumType, EnumValues enumValues) {
/* 307 */       return new EnumKeySerializer(enumType, enumValues);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public static EnumKeySerializer construct(Class<?> enumType, EnumValues enumValues, EnumValues valuesByEnumNaming) {
/* 313 */       return new EnumKeySerializer(enumType, enumValues, valuesByEnumNaming);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void serialize(Object value, JsonGenerator g, SerializerProvider serializers) throws IOException {
/* 320 */       if (serializers.isEnabled(SerializationFeature.WRITE_ENUMS_USING_TO_STRING)) {
/* 321 */         g.writeFieldName(value.toString());
/*     */         return;
/*     */       } 
/* 324 */       Enum<?> en = (Enum)value;
/* 325 */       if (this._valuesByEnumNaming != null) {
/* 326 */         g.writeFieldName(this._valuesByEnumNaming.serializedValueFor(en));
/*     */         
/*     */         return;
/*     */       } 
/* 330 */       if (serializers.isEnabled(SerializationFeature.WRITE_ENUM_KEYS_USING_INDEX)) {
/* 331 */         g.writeFieldName(String.valueOf(en.ordinal()));
/*     */         return;
/*     */       } 
/* 334 */       g.writeFieldName(this._values.serializedValueFor(en));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\StdKeySerializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */