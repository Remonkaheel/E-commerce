/*     */ package com.fasterxml.jackson.databind.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.ser.impl.BeanAsArraySerializer;
/*     */ import com.fasterxml.jackson.databind.ser.impl.ObjectIdWriter;
/*     */ import com.fasterxml.jackson.databind.ser.impl.UnwrappingBeanSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.std.BeanSerializerBase;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import java.io.IOException;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanSerializer
/*     */   extends BeanSerializerBase
/*     */ {
/*     */   private static final long serialVersionUID = 29L;
/*     */   
/*     */   public BeanSerializer(JavaType type, BeanSerializerBuilder builder, BeanPropertyWriter[] properties, BeanPropertyWriter[] filteredProperties) {
/*  45 */     super(type, builder, properties, filteredProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanSerializer(BeanSerializerBase src) {
/*  54 */     super(src);
/*     */   }
/*     */ 
/*     */   
/*     */   protected BeanSerializer(BeanSerializerBase src, ObjectIdWriter objectIdWriter) {
/*  59 */     super(src, objectIdWriter);
/*     */   }
/*     */ 
/*     */   
/*     */   protected BeanSerializer(BeanSerializerBase src, ObjectIdWriter objectIdWriter, Object filterId) {
/*  64 */     super(src, objectIdWriter, filterId);
/*     */   }
/*     */   
/*     */   protected BeanSerializer(BeanSerializerBase src, Set<String> toIgnore, Set<String> toInclude) {
/*  68 */     super(src, toIgnore, toInclude);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanSerializer(BeanSerializerBase src, BeanPropertyWriter[] properties, BeanPropertyWriter[] filteredProperties) {
/*  74 */     super(src, properties, filteredProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static BeanSerializer createDummy(JavaType forType) {
/*  89 */     return new BeanSerializer(forType, null, NO_PROPS, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BeanSerializer createDummy(JavaType forType, BeanSerializerBuilder builder) {
/* 100 */     return new BeanSerializer(forType, builder, NO_PROPS, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> unwrappingSerializer(NameTransformer unwrapper) {
/* 105 */     return (JsonSerializer<Object>)new UnwrappingBeanSerializer(this, unwrapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanSerializerBase withObjectIdWriter(ObjectIdWriter objectIdWriter) {
/* 110 */     return new BeanSerializer(this, objectIdWriter, this._propertyFilterId);
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanSerializerBase withFilterId(Object filterId) {
/* 115 */     return new BeanSerializer(this, this._objectIdWriter, filterId);
/*     */   }
/*     */ 
/*     */   
/*     */   protected BeanSerializerBase withByNameInclusion(Set<String> toIgnore, Set<String> toInclude) {
/* 120 */     return new BeanSerializer(this, toIgnore, toInclude);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanSerializerBase withProperties(BeanPropertyWriter[] properties, BeanPropertyWriter[] filteredProperties) {
/* 126 */     return new BeanSerializer(this, properties, filteredProperties);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> withIgnoredProperties(Set<String> toIgnore) {
/* 131 */     return (JsonSerializer<?>)new BeanSerializer(this, toIgnore, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanSerializerBase asArraySerializer() {
/* 149 */     if (this._objectIdWriter == null && this._propertyFilterId == null)
/*     */     {
/*     */       
/* 152 */       return (BeanSerializerBase)new BeanAsArraySerializer(this);
/*     */     }
/*     */     
/* 155 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(Object bean, JsonGenerator gen, SerializerProvider provider) throws IOException {
/* 174 */     if (this._objectIdWriter != null) {
/* 175 */       gen.assignCurrentValue(bean);
/* 176 */       _serializeWithObjectId(bean, gen, provider, true);
/*     */       return;
/*     */     } 
/* 179 */     gen.writeStartObject(bean);
/* 180 */     if (this._propertyFilterId != null) {
/* 181 */       serializeFieldsFiltered(bean, gen, provider);
/*     */     } else {
/* 183 */       serializeFields(bean, gen, provider);
/*     */     } 
/* 185 */     gen.writeEndObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 195 */     return "BeanSerializer for " + handledType().getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\BeanSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */