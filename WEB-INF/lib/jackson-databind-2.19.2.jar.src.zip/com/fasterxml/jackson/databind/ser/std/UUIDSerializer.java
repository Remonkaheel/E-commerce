/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonValueFormat;
/*     */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*     */ import java.io.IOException;
/*     */ import java.util.Objects;
/*     */ import java.util.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UUIDSerializer
/*     */   extends StdScalarSerializer<UUID>
/*     */   implements ContextualSerializer
/*     */ {
/*  28 */   static final char[] HEX_CHARS = "0123456789abcdef".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Boolean _asBinary;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UUIDSerializer() {
/*  39 */     this((Boolean)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected UUIDSerializer(Boolean asBinary) {
/*  45 */     super(UUID.class);
/*  46 */     this._asBinary = asBinary;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty(SerializerProvider prov, UUID value) {
/*  53 */     return (value.getLeastSignificantBits() == 0L && value
/*  54 */       .getMostSignificantBits() == 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> createContextual(SerializerProvider serializers, BeanProperty property) throws JsonMappingException {
/*  61 */     JsonFormat.Value format = findFormatOverrides(serializers, property, 
/*  62 */         handledType());
/*  63 */     Boolean asBinary = null;
/*     */     
/*  65 */     if (format != null) {
/*  66 */       JsonFormat.Shape shape = format.getShape();
/*  67 */       if (shape == JsonFormat.Shape.BINARY) {
/*  68 */         asBinary = Boolean.valueOf(true);
/*  69 */       } else if (shape == JsonFormat.Shape.STRING) {
/*  70 */         asBinary = Boolean.valueOf(false);
/*     */       } 
/*     */     } 
/*     */     
/*  74 */     if (!Objects.equals(asBinary, this._asBinary)) {
/*  75 */       return new UUIDSerializer(asBinary);
/*     */     }
/*  77 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(UUID value, JsonGenerator gen, SerializerProvider provider) throws IOException {
/*  85 */     if (_writeAsBinary(gen)) {
/*  86 */       gen.writeBinary(_asBytes(value));
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/*  93 */     char[] ch = new char[36];
/*  94 */     long msb = value.getMostSignificantBits();
/*  95 */     _appendInt((int)(msb >> 32L), ch, 0);
/*  96 */     ch[8] = '-';
/*  97 */     int i = (int)msb;
/*  98 */     _appendShort(i >>> 16, ch, 9);
/*  99 */     ch[13] = '-';
/* 100 */     _appendShort(i, ch, 14);
/* 101 */     ch[18] = '-';
/*     */     
/* 103 */     long lsb = value.getLeastSignificantBits();
/* 104 */     _appendShort((int)(lsb >>> 48L), ch, 19);
/* 105 */     ch[23] = '-';
/* 106 */     _appendShort((int)(lsb >>> 32L), ch, 24);
/* 107 */     _appendInt((int)lsb, ch, 28);
/*     */     
/* 109 */     gen.writeString(ch, 0, 36);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _writeAsBinary(JsonGenerator g) {
/* 115 */     if (this._asBinary != null) {
/* 116 */       return this._asBinary.booleanValue();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     return (!(g instanceof com.fasterxml.jackson.databind.util.TokenBuffer) && g.canWriteBinaryNatively());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 131 */     visitStringFormat(visitor, typeHint, JsonValueFormat.UUID);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void _appendInt(int bits, char[] ch, int offset) {
/* 136 */     _appendShort(bits >> 16, ch, offset);
/* 137 */     _appendShort(bits, ch, offset + 4);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void _appendShort(int bits, char[] ch, int offset) {
/* 142 */     ch[offset] = HEX_CHARS[bits >> 12 & 0xF];
/* 143 */     ch[++offset] = HEX_CHARS[bits >> 8 & 0xF];
/* 144 */     ch[++offset] = HEX_CHARS[bits >> 4 & 0xF];
/* 145 */     ch[++offset] = HEX_CHARS[bits & 0xF];
/*     */   }
/*     */ 
/*     */   
/*     */   private static final byte[] _asBytes(UUID uuid) {
/* 150 */     byte[] buffer = new byte[16];
/* 151 */     long hi = uuid.getMostSignificantBits();
/* 152 */     long lo = uuid.getLeastSignificantBits();
/* 153 */     _appendInt((int)(hi >> 32L), buffer, 0);
/* 154 */     _appendInt((int)hi, buffer, 4);
/* 155 */     _appendInt((int)(lo >> 32L), buffer, 8);
/* 156 */     _appendInt((int)lo, buffer, 12);
/* 157 */     return buffer;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final void _appendInt(int value, byte[] buffer, int offset) {
/* 162 */     buffer[offset] = (byte)(value >> 24);
/* 163 */     buffer[++offset] = (byte)(value >> 16);
/* 164 */     buffer[++offset] = (byte)(value >> 8);
/* 165 */     buffer[++offset] = (byte)value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\UUIDSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */