/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.ContainerSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.impl.PropertySerializerMap;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CollectionSerializer
/*     */   extends AsArraySerializerBase<Collection<?>>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final boolean _maybeEnumSet;
/*     */   
/*     */   public CollectionSerializer(JavaType elemType, boolean staticTyping, TypeSerializer vts, JsonSerializer<Object> valueSerializer) {
/*  50 */     super(Collection.class, elemType, staticTyping, vts, valueSerializer);
/*     */ 
/*     */ 
/*     */     
/*  54 */     this._maybeEnumSet = (elemType.isEnumType() || elemType.isJavaLangObject());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionSerializer(CollectionSerializer src, BeanProperty property, TypeSerializer vts, JsonSerializer<?> valueSerializer, Boolean unwrapSingle) {
/*  60 */     super(src, property, vts, valueSerializer, unwrapSingle);
/*  61 */     this._maybeEnumSet = src._maybeEnumSet;
/*     */   }
/*     */ 
/*     */   
/*     */   public ContainerSerializer<?> _withValueTypeSerializer(TypeSerializer vts) {
/*  66 */     return new CollectionSerializer(this, this._property, vts, this._elementSerializer, this._unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionSerializer withResolved(BeanProperty property, TypeSerializer vts, JsonSerializer<?> elementSerializer, Boolean unwrapSingle) {
/*  73 */     return new CollectionSerializer(this, property, vts, elementSerializer, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty(SerializerProvider prov, Collection<?> value) {
/*  84 */     return value.isEmpty();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasSingleElement(Collection<?> value) {
/*  89 */     return (value.size() == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void serialize(Collection<?> value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 101 */     int len = value.size();
/* 102 */     if (len == 1 && ((
/* 103 */       this._unwrapSingle == null && provider
/* 104 */       .isEnabled(SerializationFeature.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED)) || this._unwrapSingle == Boolean.TRUE)) {
/*     */       
/* 106 */       serializeContents(value, g, provider);
/*     */       
/*     */       return;
/*     */     } 
/* 110 */     g.writeStartArray(value, len);
/* 111 */     serializeContents(value, g, provider);
/* 112 */     g.writeEndArray();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeContents(Collection<?> value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 118 */     g.assignCurrentValue(value);
/* 119 */     if (this._elementSerializer != null) {
/* 120 */       serializeContentsUsing(value, g, provider, this._elementSerializer);
/*     */       return;
/*     */     } 
/* 123 */     Iterator<?> it = value.iterator();
/* 124 */     if (!it.hasNext()) {
/*     */       return;
/*     */     }
/* 127 */     PropertySerializerMap serializers = this._dynamicSerializers;
/*     */     
/* 129 */     TypeSerializer typeSer = (this._maybeEnumSet && value instanceof java.util.EnumSet) ? null : this._valueTypeSerializer;
/*     */ 
/*     */     
/* 132 */     int i = 0;
/*     */     try {
/*     */       do {
/* 135 */         Object elem = it.next();
/* 136 */         if (elem == null) {
/* 137 */           provider.defaultSerializeNull(g);
/*     */         } else {
/* 139 */           Class<?> cc = elem.getClass();
/* 140 */           JsonSerializer<Object> serializer = serializers.serializerFor(cc);
/* 141 */           if (serializer == null) {
/* 142 */             if (this._elementType.hasGenericTypes()) {
/* 143 */               serializer = _findAndAddDynamic(serializers, provider
/* 144 */                   .constructSpecializedType(this._elementType, cc), provider);
/*     */             } else {
/* 146 */               serializer = _findAndAddDynamic(serializers, cc, provider);
/*     */             } 
/* 148 */             serializers = this._dynamicSerializers;
/*     */           } 
/* 150 */           if (typeSer == null) {
/* 151 */             serializer.serialize(elem, g, provider);
/*     */           } else {
/* 153 */             serializer.serializeWithType(elem, g, provider, typeSer);
/*     */           } 
/*     */         } 
/* 156 */         i++;
/* 157 */       } while (it.hasNext());
/* 158 */     } catch (Exception e) {
/* 159 */       wrapAndThrow(provider, e, value, i);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeContentsUsing(Collection<?> value, JsonGenerator g, SerializerProvider provider, JsonSerializer<Object> ser) throws IOException {
/* 166 */     Iterator<?> it = value.iterator();
/* 167 */     if (it.hasNext()) {
/*     */       
/* 169 */       TypeSerializer typeSer = (this._maybeEnumSet && value instanceof java.util.EnumSet) ? null : this._valueTypeSerializer;
/*     */       
/* 171 */       int i = 0;
/*     */       do {
/* 173 */         Object elem = it.next();
/*     */         try {
/* 175 */           if (elem == null) {
/* 176 */             provider.defaultSerializeNull(g);
/*     */           }
/* 178 */           else if (typeSer == null) {
/* 179 */             ser.serialize(elem, g, provider);
/*     */           } else {
/* 181 */             ser.serializeWithType(elem, g, provider, typeSer);
/*     */           } 
/*     */           
/* 184 */           i++;
/* 185 */         } catch (Exception e) {
/* 186 */           wrapAndThrow(provider, e, value, i);
/*     */         } 
/* 188 */       } while (it.hasNext());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\CollectionSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */