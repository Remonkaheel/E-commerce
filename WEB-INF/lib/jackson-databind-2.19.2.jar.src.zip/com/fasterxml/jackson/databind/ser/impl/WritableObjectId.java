/*    */ package com.fasterxml.jackson.databind.ser.impl;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.core.SerializableString;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WritableObjectId
/*    */ {
/*    */   public final ObjectIdGenerator<?> generator;
/*    */   public Object id;
/*    */   protected boolean idWritten = false;
/*    */   
/*    */   public WritableObjectId(ObjectIdGenerator<?> generator) {
/* 28 */     this.generator = generator;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean writeAsId(JsonGenerator gen, SerializerProvider provider, ObjectIdWriter w) throws IOException {
/* 33 */     if (this.id != null && (this.idWritten || w.alwaysAsId)) {
/*    */       
/* 35 */       if (gen.canWriteObjectId()) {
/* 36 */         gen.writeObjectRef(String.valueOf(this.id));
/*    */       } else {
/* 38 */         w.serializer.serialize(this.id, gen, provider);
/*    */       } 
/* 40 */       return true;
/*    */     } 
/* 42 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object generateId(Object forPojo) {
/* 49 */     if (this.id == null) {
/* 50 */       this.id = this.generator.generateId(forPojo);
/*    */     }
/* 52 */     return this.id;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void writeAsField(JsonGenerator gen, SerializerProvider provider, ObjectIdWriter w) throws IOException {
/* 61 */     this.idWritten = true;
/*    */ 
/*    */     
/* 64 */     if (gen.canWriteObjectId()) {
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 69 */       String idStr = (this.id == null) ? null : String.valueOf(this.id);
/* 70 */       gen.writeObjectId(idStr);
/*    */       
/*    */       return;
/*    */     } 
/* 74 */     SerializableString name = w.propertyName;
/* 75 */     if (name != null) {
/*    */       
/* 77 */       gen.writeFieldName(name);
/* 78 */       w.serializer.serialize(this.id, gen, provider);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\impl\WritableObjectId.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */