/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public final class BooleanSerializer
/*     */   extends StdScalarSerializer<Object>
/*     */   implements ContextualSerializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final boolean _forPrimitive;
/*     */   
/*     */   public BooleanSerializer(boolean forPrimitive) {
/*  43 */     super(forPrimitive ? boolean.class : Boolean.class, false);
/*  44 */     this._forPrimitive = forPrimitive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> createContextual(SerializerProvider serializers, BeanProperty property) throws JsonMappingException {
/*  53 */     JsonFormat.Value format = findFormatOverrides(serializers, property, 
/*  54 */         handledType());
/*  55 */     if (format != null) {
/*  56 */       JsonFormat.Shape shape = format.getShape();
/*  57 */       if (shape.isNumeric()) {
/*  58 */         return new AsNumber(this._forPrimitive);
/*     */       }
/*  60 */       if (shape == JsonFormat.Shape.STRING) {
/*  61 */         return new ToStringSerializer(this._handledType);
/*     */       }
/*     */     } 
/*  64 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void serialize(Object value, JsonGenerator g, SerializerProvider provider) throws IOException {
/*  69 */     g.writeBoolean(Boolean.TRUE.equals(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void serializeWithType(Object value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/*  76 */     g.writeBoolean(Boolean.TRUE.equals(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint) {
/*  85 */     return (JsonNode)createSchemaNode("boolean", !this._forPrimitive);
/*     */   }
/*     */ 
/*     */   
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/*  90 */     visitor.expectBooleanFormat(typeHint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class AsNumber
/*     */     extends StdScalarSerializer<Object>
/*     */     implements ContextualSerializer
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final boolean _forPrimitive;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AsNumber(boolean forPrimitive) {
/* 112 */       super(forPrimitive ? boolean.class : Boolean.class, false);
/* 113 */       this._forPrimitive = forPrimitive;
/*     */     }
/*     */ 
/*     */     
/*     */     public void serialize(Object value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 118 */       g.writeNumber(Boolean.FALSE.equals(value) ? 0 : 1);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void serializeWithType(Object value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/* 129 */       g.writeBoolean(Boolean.TRUE.equals(value));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 136 */       visitIntFormat(visitor, typeHint, JsonParser.NumberType.INT);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonSerializer<?> createContextual(SerializerProvider serializers, BeanProperty property) throws JsonMappingException {
/* 143 */       JsonFormat.Value format = findFormatOverrides(serializers, property, Boolean.class);
/*     */       
/* 145 */       if (format != null) {
/* 146 */         JsonFormat.Shape shape = format.getShape();
/* 147 */         if (!shape.isNumeric()) {
/* 148 */           return new BooleanSerializer(this._forPrimitive);
/*     */         }
/*     */       } 
/* 151 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\BooleanSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */