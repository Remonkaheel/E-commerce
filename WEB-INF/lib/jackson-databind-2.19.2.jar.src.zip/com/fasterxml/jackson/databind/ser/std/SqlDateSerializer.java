/*    */ package com.fasterxml.jackson.databind.ser.std;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*    */ import java.io.IOException;
/*    */ import java.sql.Date;
/*    */ import java.text.DateFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @JacksonStdImpl
/*    */ public class SqlDateSerializer
/*    */   extends DateTimeSerializerBase<Date>
/*    */ {
/*    */   public SqlDateSerializer() {
/* 22 */     this((Boolean)null, (DateFormat)null);
/*    */   }
/*    */   
/*    */   protected SqlDateSerializer(Boolean useTimestamp, DateFormat customFormat) {
/* 26 */     super(Date.class, useTimestamp, customFormat);
/*    */   }
/*    */ 
/*    */   
/*    */   public SqlDateSerializer withFormat(Boolean timestamp, DateFormat customFormat) {
/* 31 */     return new SqlDateSerializer(timestamp, customFormat);
/*    */   }
/*    */ 
/*    */   
/*    */   protected long _timestamp(Date value) {
/* 36 */     return (value == null) ? 0L : value.getTime();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serialize(Date value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 43 */     if (_asTimestamp(provider)) {
/* 44 */       g.writeNumber(_timestamp(value));
/*    */       
/*    */       return;
/*    */     } 
/* 48 */     if (this._customFormat == null) {
/*    */ 
/*    */ 
/*    */       
/* 52 */       g.writeString(value.toString());
/*    */       return;
/*    */     } 
/* 55 */     _serializeAsString(value, g, provider);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\SqlDateSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */