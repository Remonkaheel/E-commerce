/*    */ package com.fasterxml.jackson.databind.ser.std;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonFormat;
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.core.JsonToken;
/*    */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*    */ import com.fasterxml.jackson.databind.BeanProperty;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*    */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*    */ import java.io.IOException;
/*    */ import java.net.InetAddress;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InetAddressSerializer
/*    */   extends StdScalarSerializer<InetAddress>
/*    */   implements ContextualSerializer
/*    */ {
/*    */   protected final boolean _asNumeric;
/*    */   
/*    */   public InetAddressSerializer() {
/* 37 */     this(false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InetAddressSerializer(boolean asNumeric) {
/* 44 */     super(InetAddress.class);
/* 45 */     this._asNumeric = asNumeric;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JsonSerializer<?> createContextual(SerializerProvider serializers, BeanProperty property) throws JsonMappingException {
/* 52 */     JsonFormat.Value format = findFormatOverrides(serializers, property, 
/* 53 */         handledType());
/* 54 */     boolean asNumeric = false;
/* 55 */     if (format != null) {
/* 56 */       JsonFormat.Shape shape = format.getShape();
/* 57 */       if (shape.isNumeric() || shape == JsonFormat.Shape.ARRAY) {
/* 58 */         asNumeric = true;
/*    */       }
/*    */     } 
/* 61 */     if (asNumeric != this._asNumeric) {
/* 62 */       return new InetAddressSerializer(asNumeric);
/*    */     }
/* 64 */     return this;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serialize(InetAddress value, JsonGenerator g, SerializerProvider provider) throws IOException {
/*    */     String str;
/* 72 */     if (this._asNumeric) {
/* 73 */       str = value.getHostAddress();
/*    */     } else {
/*    */       
/* 76 */       str = value.toString().trim();
/* 77 */       int ix = str.indexOf('/');
/* 78 */       if (ix >= 0) {
/* 79 */         if (ix == 0) {
/* 80 */           str = str.substring(1);
/*    */         } else {
/* 82 */           str = str.substring(0, ix);
/*    */         } 
/*    */       }
/*    */     } 
/* 86 */     g.writeString(str);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serializeWithType(InetAddress value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/* 94 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/* 95 */         .typeId(value, InetAddress.class, JsonToken.VALUE_STRING));
/* 96 */     serialize(value, g, provider);
/* 97 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\InetAddressSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */