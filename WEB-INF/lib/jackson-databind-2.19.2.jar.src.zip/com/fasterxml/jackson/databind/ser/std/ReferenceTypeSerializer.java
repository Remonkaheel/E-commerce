/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.RuntimeJsonMappingException;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.impl.PropertySerializerMap;
/*     */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*     */ import com.fasterxml.jackson.databind.util.ArrayBuilders;
/*     */ import com.fasterxml.jackson.databind.util.BeanUtil;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReferenceTypeSerializer<T>
/*     */   extends StdSerializer<T>
/*     */   implements ContextualSerializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  36 */   public static final Object MARKER_FOR_EMPTY = JsonInclude.Include.NON_EMPTY;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JavaType _referredType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final BeanProperty _property;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final TypeSerializer _valueTypeSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonSerializer<Object> _valueSerializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final NameTransformer _unwrapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected transient PropertySerializerMap _dynamicSerializers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Object _suppressableValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _suppressNulls;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceTypeSerializer(ReferenceType fullType, boolean staticTyping, TypeSerializer vts, JsonSerializer<Object> ser) {
/* 101 */     super((JavaType)fullType);
/* 102 */     this._referredType = fullType.getReferencedType();
/* 103 */     this._property = null;
/* 104 */     this._valueTypeSerializer = vts;
/* 105 */     this._valueSerializer = ser;
/* 106 */     this._unwrapper = null;
/* 107 */     this._suppressableValue = null;
/* 108 */     this._suppressNulls = false;
/* 109 */     this._dynamicSerializers = PropertySerializerMap.emptyForProperties();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ReferenceTypeSerializer(ReferenceTypeSerializer<?> base, BeanProperty property, TypeSerializer vts, JsonSerializer<?> valueSer, NameTransformer unwrapper, Object suppressableValue, boolean suppressNulls) {
/* 118 */     super(base);
/* 119 */     this._referredType = base._referredType;
/*     */     
/* 121 */     this._dynamicSerializers = PropertySerializerMap.emptyForProperties();
/* 122 */     this._property = property;
/* 123 */     this._valueTypeSerializer = vts;
/* 124 */     this._valueSerializer = (JsonSerializer)valueSer;
/* 125 */     this._unwrapper = unwrapper;
/* 126 */     this._suppressableValue = suppressableValue;
/* 127 */     this._suppressNulls = suppressNulls;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<T> unwrappingSerializer(NameTransformer transformer) {
/* 132 */     JsonSerializer<Object> valueSer = this._valueSerializer;
/* 133 */     if (valueSer != null) {
/*     */ 
/*     */       
/* 136 */       valueSer = valueSer.unwrappingSerializer(transformer);
/* 137 */       if (valueSer == this._valueSerializer) {
/* 138 */         return this;
/*     */       }
/*     */     } 
/*     */     
/* 142 */     NameTransformer unwrapper = (this._unwrapper == null) ? transformer : NameTransformer.chainedTransformer(transformer, this._unwrapper);
/* 143 */     if (this._valueSerializer == valueSer && this._unwrapper == unwrapper) {
/* 144 */       return this;
/*     */     }
/* 146 */     return withResolved(this._property, this._valueTypeSerializer, valueSer, unwrapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract ReferenceTypeSerializer<T> withResolved(BeanProperty paramBeanProperty, TypeSerializer paramTypeSerializer, JsonSerializer<?> paramJsonSerializer, NameTransformer paramNameTransformer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract ReferenceTypeSerializer<T> withContentInclusion(Object paramObject, boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract boolean _isValuePresent(T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Object _getReferenced(T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Object _getReferencedIfPresent(T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> createContextual(SerializerProvider provider, BeanProperty property) throws JsonMappingException {
/*     */     ReferenceTypeSerializer<?> refSer;
/* 202 */     TypeSerializer typeSer = this._valueTypeSerializer;
/* 203 */     if (typeSer != null) {
/* 204 */       typeSer = typeSer.forProperty(property);
/*     */     }
/*     */     
/* 207 */     JsonSerializer<?> ser = findAnnotatedContentSerializer(provider, property);
/* 208 */     if (ser == null) {
/*     */       
/* 210 */       ser = this._valueSerializer;
/* 211 */       if (ser == null) {
/*     */         
/* 213 */         if (_useStatic(provider, property, this._referredType)) {
/* 214 */           ser = _findSerializer(provider, this._referredType, property);
/*     */         }
/*     */       } else {
/* 217 */         ser = provider.handlePrimaryContextualization(ser, property);
/*     */       } 
/*     */     } 
/*     */     
/* 221 */     ser = findContextualConvertingSerializer(provider, property, ser);
/*     */ 
/*     */ 
/*     */     
/* 225 */     if (this._property == property && this._valueTypeSerializer == typeSer && this._valueSerializer == ser) {
/*     */       
/* 227 */       refSer = this;
/*     */     } else {
/* 229 */       refSer = withResolved(property, typeSer, ser, this._unwrapper);
/*     */     } 
/*     */ 
/*     */     
/* 233 */     if (property != null) {
/* 234 */       JsonInclude.Value inclV = property.findPropertyInclusion((MapperConfig)provider.getConfig(), handledType());
/* 235 */       if (inclV != null) {
/* 236 */         JsonInclude.Include incl = inclV.getContentInclusion();
/*     */         
/* 238 */         if (incl != JsonInclude.Include.USE_DEFAULTS) {
/*     */           Object valueToSuppress;
/*     */           boolean suppressNulls;
/* 241 */           switch (incl) {
/*     */             case NON_DEFAULT:
/* 243 */               valueToSuppress = BeanUtil.getDefaultValue(this._referredType);
/* 244 */               suppressNulls = true;
/* 245 */               if (valueToSuppress != null && 
/* 246 */                 valueToSuppress.getClass().isArray()) {
/* 247 */                 valueToSuppress = ArrayBuilders.getArrayComparator(valueToSuppress);
/*     */               }
/*     */               break;
/*     */             
/*     */             case NON_ABSENT:
/* 252 */               suppressNulls = true;
/* 253 */               valueToSuppress = this._referredType.isReferenceType() ? MARKER_FOR_EMPTY : null;
/*     */               break;
/*     */             case NON_EMPTY:
/* 256 */               suppressNulls = true;
/* 257 */               valueToSuppress = MARKER_FOR_EMPTY;
/*     */               break;
/*     */             case CUSTOM:
/* 260 */               valueToSuppress = provider.includeFilterInstance(null, inclV.getContentFilter());
/* 261 */               if (valueToSuppress == null) {
/* 262 */                 suppressNulls = true; break;
/*     */               } 
/* 264 */               suppressNulls = provider.includeFilterSuppressNulls(valueToSuppress);
/*     */               break;
/*     */             
/*     */             case NON_NULL:
/* 268 */               valueToSuppress = null;
/* 269 */               suppressNulls = true;
/*     */               break;
/*     */             
/*     */             default:
/* 273 */               valueToSuppress = null;
/* 274 */               suppressNulls = false;
/*     */               break;
/*     */           } 
/* 277 */           if (this._suppressableValue != valueToSuppress || this._suppressNulls != suppressNulls)
/*     */           {
/* 279 */             refSer = refSer.withContentInclusion(valueToSuppress, suppressNulls);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 284 */     return refSer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _useStatic(SerializerProvider provider, BeanProperty property, JavaType referredType) {
/* 291 */     if (referredType.isJavaLangObject()) {
/* 292 */       return false;
/*     */     }
/*     */     
/* 295 */     if (referredType.isFinal()) {
/* 296 */       return true;
/*     */     }
/*     */     
/* 299 */     if (referredType.useStaticType()) {
/* 300 */       return true;
/*     */     }
/*     */     
/* 303 */     AnnotationIntrospector intr = provider.getAnnotationIntrospector();
/* 304 */     if (intr != null && property != null) {
/* 305 */       AnnotatedMember annotatedMember = property.getMember();
/* 306 */       if (annotatedMember != null) {
/* 307 */         JsonSerialize.Typing t = intr.findSerializationTyping((Annotated)property.getMember());
/* 308 */         if (t == JsonSerialize.Typing.STATIC) {
/* 309 */           return true;
/*     */         }
/* 311 */         if (t == JsonSerialize.Typing.DYNAMIC) {
/* 312 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 317 */     return provider.isEnabled(MapperFeature.USE_STATIC_TYPING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty(SerializerProvider provider, T value) {
/* 330 */     if (!_isValuePresent(value)) {
/* 331 */       return true;
/*     */     }
/* 333 */     Object contents = _getReferenced(value);
/* 334 */     if (contents == null) {
/* 335 */       return this._suppressNulls;
/*     */     }
/* 337 */     if (this._suppressableValue == null) {
/* 338 */       return false;
/*     */     }
/* 340 */     JsonSerializer<Object> ser = this._valueSerializer;
/* 341 */     if (ser == null) {
/*     */       try {
/* 343 */         ser = _findCachedSerializer(provider, contents.getClass());
/* 344 */       } catch (JsonMappingException e) {
/* 345 */         throw new RuntimeJsonMappingException(e);
/*     */       } 
/*     */     }
/* 348 */     if (this._suppressableValue == MARKER_FOR_EMPTY) {
/* 349 */       return ser.isEmpty(provider, contents);
/*     */     }
/* 351 */     return this._suppressableValue.equals(contents);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUnwrappingSerializer() {
/* 356 */     return (this._unwrapper != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType getReferredType() {
/* 363 */     return this._referredType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(T ref, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 376 */     Object value = _getReferencedIfPresent(ref);
/* 377 */     if (value == null) {
/* 378 */       if (this._unwrapper == null) {
/* 379 */         provider.defaultSerializeNull(g);
/*     */       }
/*     */       return;
/*     */     } 
/* 383 */     JsonSerializer<Object> ser = this._valueSerializer;
/* 384 */     if (ser == null) {
/* 385 */       ser = _findCachedSerializer(provider, value.getClass());
/*     */     }
/* 387 */     if (this._valueTypeSerializer != null) {
/* 388 */       ser.serializeWithType(value, g, provider, this._valueTypeSerializer);
/*     */     } else {
/* 390 */       ser.serialize(value, g, provider);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeWithType(T ref, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/* 399 */     Object value = _getReferencedIfPresent(ref);
/* 400 */     if (value == null) {
/* 401 */       if (this._unwrapper == null) {
/* 402 */         provider.defaultSerializeNull(g);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 417 */     JsonSerializer<Object> ser = this._valueSerializer;
/* 418 */     if (ser == null) {
/* 419 */       ser = _findCachedSerializer(provider, value.getClass());
/*     */     }
/* 421 */     ser.serializeWithType(value, g, provider, typeSer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 434 */     JsonSerializer<?> ser = this._valueSerializer;
/* 435 */     if (ser == null) {
/* 436 */       ser = _findSerializer(visitor.getProvider(), this._referredType, this._property);
/* 437 */       if (this._unwrapper != null) {
/* 438 */         ser = ser.unwrappingSerializer(this._unwrapper);
/*     */       }
/*     */     } 
/* 441 */     ser.acceptJsonFormatVisitor(visitor, this._referredType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final JsonSerializer<Object> _findCachedSerializer(SerializerProvider provider, Class<?> rawType) throws JsonMappingException {
/* 457 */     JsonSerializer<Object> ser = this._dynamicSerializers.serializerFor(rawType);
/* 458 */     if (ser == null) {
/*     */ 
/*     */ 
/*     */       
/* 462 */       if (this._referredType.hasGenericTypes()) {
/*     */ 
/*     */         
/* 465 */         JavaType fullType = provider.constructSpecializedType(this._referredType, rawType);
/*     */ 
/*     */ 
/*     */         
/* 469 */         ser = provider.findPrimaryPropertySerializer(fullType, this._property);
/*     */       } else {
/* 471 */         ser = provider.findPrimaryPropertySerializer(rawType, this._property);
/*     */       } 
/* 473 */       if (this._unwrapper != null) {
/* 474 */         ser = ser.unwrappingSerializer(this._unwrapper);
/*     */       }
/* 476 */       this._dynamicSerializers = this._dynamicSerializers.newWith(rawType, ser);
/*     */     } 
/* 478 */     return ser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final JsonSerializer<Object> _findSerializer(SerializerProvider provider, JavaType type, BeanProperty prop) throws JsonMappingException {
/* 489 */     return provider.findPrimaryPropertySerializer(type, prop);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\ReferenceTypeSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */