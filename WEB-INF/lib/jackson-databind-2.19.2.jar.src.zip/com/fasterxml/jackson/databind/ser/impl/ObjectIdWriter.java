/*    */ package com.fasterxml.jackson.databind.ser.impl;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*    */ import com.fasterxml.jackson.core.SerializableString;
/*    */ import com.fasterxml.jackson.core.io.SerializedString;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ import com.fasterxml.jackson.databind.PropertyName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ObjectIdWriter
/*    */ {
/*    */   public final JavaType idType;
/*    */   public final SerializableString propertyName;
/*    */   public final ObjectIdGenerator<?> generator;
/*    */   public final JsonSerializer<Object> serializer;
/*    */   public final boolean alwaysAsId;
/*    */   
/*    */   protected ObjectIdWriter(JavaType t, SerializableString propName, ObjectIdGenerator<?> gen, JsonSerializer<?> ser, boolean alwaysAsId) {
/* 54 */     this.idType = t;
/* 55 */     this.propertyName = propName;
/* 56 */     this.generator = gen;
/* 57 */     this.serializer = (JsonSerializer)ser;
/* 58 */     this.alwaysAsId = alwaysAsId;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static ObjectIdWriter construct(JavaType idType, PropertyName propName, ObjectIdGenerator<?> generator, boolean alwaysAsId) {
/* 71 */     String simpleName = (propName == null) ? null : propName.getSimpleName();
/* 72 */     SerializedString serializedString = (simpleName == null) ? null : new SerializedString(simpleName);
/* 73 */     return new ObjectIdWriter(idType, (SerializableString)serializedString, generator, null, alwaysAsId);
/*    */   }
/*    */   
/*    */   public ObjectIdWriter withSerializer(JsonSerializer<?> ser) {
/* 77 */     return new ObjectIdWriter(this.idType, this.propertyName, this.generator, ser, this.alwaysAsId);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ObjectIdWriter withAlwaysAsId(boolean newState) {
/* 84 */     if (newState == this.alwaysAsId) {
/* 85 */       return this;
/*    */     }
/* 87 */     return new ObjectIdWriter(this.idType, this.propertyName, this.generator, this.serializer, newState);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\impl\ObjectIdWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */