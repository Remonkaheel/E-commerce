/*    */ package com.fasterxml.jackson.databind.ser.impl;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import com.fasterxml.jackson.databind.ser.std.StdSerializer;
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MapEntryAsPOJOSerializer
/*    */   extends StdSerializer<Map.Entry<?, ?>>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   protected MapEntryAsPOJOSerializer(JavaType type) {
/* 26 */     super(type);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static MapEntryAsPOJOSerializer create(SerializerProvider ctxt, JavaType type) {
/* 32 */     return new MapEntryAsPOJOSerializer(type);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serialize(Map.Entry<?, ?> value, JsonGenerator gen, SerializerProvider ctxt) throws IOException {
/* 39 */     gen.writeStartObject(value);
/* 40 */     ctxt.defaultSerializeField("key", value.getKey(), gen);
/* 41 */     ctxt.defaultSerializeField("value", value.getValue(), gen);
/* 42 */     gen.writeEndObject();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\impl\MapEntryAsPOJOSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */