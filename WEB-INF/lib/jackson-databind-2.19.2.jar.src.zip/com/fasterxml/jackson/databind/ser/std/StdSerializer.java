/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonArrayFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatTypes;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitable;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonIntegerFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonNumberFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonStringFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonValueFormat;
/*     */ import com.fasterxml.jackson.databind.jsonschema.SchemaAware;
/*     */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*     */ import com.fasterxml.jackson.databind.ser.PropertyFilter;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Collection;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public abstract class StdSerializer<T>
/*     */   extends JsonSerializer<T>
/*     */   implements JsonFormatVisitable, SchemaAware, Serializable {
/*     */   private static final long serialVersionUID = 1L;
/*  44 */   private static final Object KEY_CONTENT_CONVERTER_LOCK = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Class<T> _handledType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StdSerializer(Class<T> t) {
/*  59 */     this._handledType = t;
/*     */   }
/*     */ 
/*     */   
/*     */   protected StdSerializer(JavaType type) {
/*  64 */     this._handledType = type.getRawClass();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StdSerializer(Class<?> t, boolean dummy) {
/*  73 */     this._handledType = (Class)t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StdSerializer(StdSerializer<?> src) {
/*  81 */     this._handledType = src._handledType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<T> handledType() {
/*  91 */     return this._handledType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void serialize(T paramT, JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 117 */     visitor.expectAnyFormat(typeHint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint) throws JsonMappingException {
/* 131 */     return (JsonNode)createSchemaNode("string");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint, boolean isOptional) throws JsonMappingException {
/* 146 */     ObjectNode schema = (ObjectNode)getSchema(provider, typeHint);
/* 147 */     if (!isOptional) {
/* 148 */       schema.put("required", true);
/*     */     }
/* 150 */     return (JsonNode)schema;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectNode createSchemaNode(String type) {
/* 161 */     ObjectNode schema = JsonNodeFactory.instance.objectNode();
/* 162 */     schema.put("type", type);
/* 163 */     return schema;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ObjectNode createSchemaNode(String type, boolean isOptional) {
/* 168 */     ObjectNode schema = createSchemaNode(type);
/* 169 */     if (!isOptional) {
/* 170 */       schema.put("required", true);
/*     */     }
/* 172 */     return schema;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void visitStringFormat(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 183 */     visitor.expectStringFormat(typeHint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void visitStringFormat(JsonFormatVisitorWrapper visitor, JavaType typeHint, JsonValueFormat format) throws JsonMappingException {
/* 197 */     JsonStringFormatVisitor v2 = visitor.expectStringFormat(typeHint);
/* 198 */     if (v2 != null) {
/* 199 */       v2.format(format);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void visitIntFormat(JsonFormatVisitorWrapper visitor, JavaType typeHint, JsonParser.NumberType numberType) throws JsonMappingException {
/* 213 */     JsonIntegerFormatVisitor v2 = visitor.expectIntegerFormat(typeHint);
/* 214 */     if (_neitherNull(v2, numberType)) {
/* 215 */       v2.numberType(numberType);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void visitIntFormat(JsonFormatVisitorWrapper visitor, JavaType typeHint, JsonParser.NumberType numberType, JsonValueFormat format) throws JsonMappingException {
/* 230 */     JsonIntegerFormatVisitor v2 = visitor.expectIntegerFormat(typeHint);
/* 231 */     if (v2 != null) {
/* 232 */       if (numberType != null) {
/* 233 */         v2.numberType(numberType);
/*     */       }
/* 235 */       if (format != null) {
/* 236 */         v2.format(format);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void visitFloatFormat(JsonFormatVisitorWrapper visitor, JavaType typeHint, JsonParser.NumberType numberType) throws JsonMappingException {
/* 251 */     JsonNumberFormatVisitor v2 = visitor.expectNumberFormat(typeHint);
/* 252 */     if (v2 != null) {
/* 253 */       v2.numberType(numberType);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void visitArrayFormat(JsonFormatVisitorWrapper visitor, JavaType typeHint, JsonSerializer<?> itemSerializer, JavaType itemType) throws JsonMappingException {
/* 264 */     JsonArrayFormatVisitor v2 = visitor.expectArrayFormat(typeHint);
/* 265 */     if (_neitherNull(v2, itemSerializer)) {
/* 266 */       v2.itemsFormat((JsonFormatVisitable)itemSerializer, itemType);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void visitArrayFormat(JsonFormatVisitorWrapper visitor, JavaType typeHint, JsonFormatTypes itemType) throws JsonMappingException {
/* 277 */     JsonArrayFormatVisitor v2 = visitor.expectArrayFormat(typeHint);
/* 278 */     if (v2 != null) {
/* 279 */       v2.itemsFormat(itemType);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void wrapAndThrow(SerializerProvider provider, Throwable t, Object bean, String fieldName) throws IOException {
/* 309 */     while (t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null) {
/* 310 */       t = t.getCause();
/*     */     }
/*     */     
/* 313 */     ClassUtil.throwIfError(t);
/*     */     
/* 315 */     boolean wrap = (provider == null || provider.isEnabled(SerializationFeature.WRAP_EXCEPTIONS));
/* 316 */     if (t instanceof IOException) {
/* 317 */       if (!wrap || !(t instanceof com.fasterxml.jackson.core.JacksonException)) {
/* 318 */         throw (IOException)t;
/*     */       }
/* 320 */     } else if (!wrap) {
/* 321 */       ClassUtil.throwIfRTE(t);
/*     */     } 
/*     */     
/* 324 */     throw JsonMappingException.wrapWithPath(t, bean, fieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void wrapAndThrow(SerializerProvider provider, Throwable t, Object bean, int index) throws IOException {
/* 331 */     while (t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null) {
/* 332 */       t = t.getCause();
/*     */     }
/*     */     
/* 335 */     ClassUtil.throwIfError(t);
/*     */     
/* 337 */     boolean wrap = (provider == null || provider.isEnabled(SerializationFeature.WRAP_EXCEPTIONS));
/* 338 */     if (t instanceof IOException) {
/* 339 */       if (!wrap || !(t instanceof com.fasterxml.jackson.core.JacksonException)) {
/* 340 */         throw (IOException)t;
/*     */       }
/* 342 */     } else if (!wrap) {
/* 343 */       ClassUtil.throwIfRTE(t);
/*     */     } 
/*     */     
/* 346 */     throw JsonMappingException.wrapWithPath(t, bean, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<?> findContextualConvertingSerializer(SerializerProvider provider, BeanProperty property, JsonSerializer<?> existingSerializer) throws JsonMappingException {
/* 372 */     Map<Object, Object> conversions = (Map<Object, Object>)provider.getAttribute(KEY_CONTENT_CONVERTER_LOCK);
/* 373 */     if (conversions != null) {
/* 374 */       Object lock = conversions.get(property);
/* 375 */       if (lock != null) {
/* 376 */         return existingSerializer;
/*     */       }
/*     */     } else {
/* 379 */       conversions = new IdentityHashMap<>();
/* 380 */       provider.setAttribute(KEY_CONTENT_CONVERTER_LOCK, conversions);
/*     */     } 
/* 382 */     conversions.put(property, Boolean.TRUE);
/*     */     try {
/* 384 */       JsonSerializer<?> ser = findConvertingContentSerializer(provider, property, existingSerializer);
/* 385 */       if (ser != null) {
/* 386 */         return provider.handleSecondaryContextualization(ser, property);
/*     */       }
/*     */     } finally {
/* 389 */       conversions.remove(property);
/*     */     } 
/* 391 */     return existingSerializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected JsonSerializer<?> findConvertingContentSerializer(SerializerProvider provider, BeanProperty prop, JsonSerializer<?> existingSerializer) throws JsonMappingException {
/* 402 */     AnnotationIntrospector intr = provider.getAnnotationIntrospector();
/* 403 */     if (_neitherNull(intr, prop)) {
/* 404 */       AnnotatedMember m = prop.getMember();
/* 405 */       if (m != null) {
/* 406 */         Object convDef = intr.findSerializationContentConverter(m);
/* 407 */         if (convDef != null) {
/* 408 */           Converter<Object, Object> conv = provider.converterInstance((Annotated)prop.getMember(), convDef);
/* 409 */           JavaType delegateType = conv.getOutputType(provider.getTypeFactory());
/*     */           
/* 411 */           if (existingSerializer == null && !delegateType.isJavaLangObject()) {
/* 412 */             existingSerializer = provider.findValueSerializer(delegateType);
/*     */           }
/* 414 */           return new StdDelegatingSerializer(conv, delegateType, existingSerializer);
/*     */         } 
/*     */       } 
/*     */     } 
/* 418 */     return existingSerializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PropertyFilter findPropertyFilter(SerializerProvider provider, Object filterId, Object valueToFilter) throws JsonMappingException {
/* 431 */     FilterProvider filters = provider.getFilterProvider();
/*     */     
/* 433 */     if (filters == null) {
/* 434 */       return (PropertyFilter)provider.reportBadDefinition(handledType(), "Cannot resolve PropertyFilter with id '" + filterId + "'; no FilterProvider configured");
/*     */     }
/*     */ 
/*     */     
/* 438 */     return filters.findPropertyFilter(filterId, valueToFilter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonFormat.Value findFormatOverrides(SerializerProvider provider, BeanProperty prop, Class<?> typeForDefaults) {
/* 453 */     if (prop != null) {
/* 454 */       return prop.findPropertyFormat((MapperConfig)provider.getConfig(), typeForDefaults);
/*     */     }
/*     */     
/* 457 */     return provider.getDefaultPropertyFormat(typeForDefaults);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Boolean findFormatFeature(SerializerProvider provider, BeanProperty prop, Class<?> typeForDefaults, JsonFormat.Feature feat) {
/* 472 */     JsonFormat.Value format = findFormatOverrides(provider, prop, typeForDefaults);
/* 473 */     if (format != null) {
/* 474 */       return format.getFeature(feat);
/*     */     }
/* 476 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonInclude.Value findIncludeOverrides(SerializerProvider provider, BeanProperty prop, Class<?> typeForDefaults) {
/* 485 */     if (prop != null) {
/* 486 */       return prop.findPropertyInclusion((MapperConfig)provider.getConfig(), typeForDefaults);
/*     */     }
/*     */     
/* 489 */     return provider.getDefaultPropertyInclusion(typeForDefaults);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<?> findAnnotatedContentSerializer(SerializerProvider serializers, BeanProperty property) throws JsonMappingException {
/* 501 */     if (property != null) {
/*     */       
/* 503 */       AnnotatedMember m = property.getMember();
/* 504 */       AnnotationIntrospector intr = serializers.getAnnotationIntrospector();
/* 505 */       if (m != null) {
/* 506 */         Object serDef = intr.findContentSerializer((Annotated)m);
/* 507 */         if (serDef != null) {
/* 508 */           return serializers.serializerInstance((Annotated)m, serDef);
/*     */         }
/*     */       } 
/*     */     } 
/* 512 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isDefaultSerializer(JsonSerializer<?> serializer) {
/* 528 */     return ClassUtil.isJacksonStdImpl(serializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final boolean _neitherNull(Object a, Object b) {
/* 535 */     return (a != null && b != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final boolean _nonEmpty(Collection<?> c) {
/* 542 */     return (c != null && !c.isEmpty());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\StdSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */