/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class NumberSerializer
/*     */   extends StdScalarSerializer<Number>
/*     */   implements ContextualSerializer
/*     */ {
/*  31 */   public static final NumberSerializer instance = new NumberSerializer(Number.class);
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int MAX_BIG_DECIMAL_SCALE = 9999;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _isInt;
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberSerializer(Class<? extends Number> rawType) {
/*  44 */     super(rawType, false);
/*     */     
/*  46 */     this._isInt = (rawType == BigInteger.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> createContextual(SerializerProvider prov, BeanProperty property) throws JsonMappingException {
/*  53 */     JsonFormat.Value format = findFormatOverrides(prov, property, handledType());
/*  54 */     if (format != null) {
/*  55 */       switch (format.getShape()) {
/*     */         
/*     */         case STRING:
/*  58 */           if (handledType() == BigDecimal.class) {
/*  59 */             return bigDecimalAsStringSerializer();
/*     */           }
/*  61 */           return ToStringSerializer.instance;
/*     */       } 
/*     */     
/*     */     }
/*  65 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(Number value, JsonGenerator g, SerializerProvider provider) throws IOException {
/*  72 */     if (value instanceof BigDecimal) {
/*  73 */       g.writeNumber((BigDecimal)value);
/*  74 */     } else if (value instanceof BigInteger) {
/*  75 */       g.writeNumber((BigInteger)value);
/*     */ 
/*     */     
/*     */     }
/*  79 */     else if (value instanceof Long) {
/*  80 */       g.writeNumber(value.longValue());
/*  81 */     } else if (value instanceof Double) {
/*  82 */       g.writeNumber(value.doubleValue());
/*  83 */     } else if (value instanceof Float) {
/*  84 */       g.writeNumber(value.floatValue());
/*  85 */     } else if (value instanceof Integer || value instanceof Byte || value instanceof Short) {
/*  86 */       g.writeNumber(value.intValue());
/*     */     } else {
/*     */       
/*  89 */       g.writeNumber(value.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint) {
/*  99 */     return (JsonNode)createSchemaNode(this._isInt ? "integer" : "number", true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 105 */     if (this._isInt) {
/* 106 */       visitIntFormat(visitor, typeHint, JsonParser.NumberType.BIG_INTEGER);
/*     */     }
/* 108 */     else if (handledType() == BigDecimal.class) {
/* 109 */       visitFloatFormat(visitor, typeHint, JsonParser.NumberType.BIG_DECIMAL);
/*     */     } else {
/*     */       
/* 112 */       visitor.expectNumberFormat(typeHint);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonSerializer<?> bigDecimalAsStringSerializer() {
/* 121 */     return BigDecimalAsStringSerializer.BD_INSTANCE;
/*     */   }
/*     */   
/*     */   static final class BigDecimalAsStringSerializer
/*     */     extends ToStringSerializerBase
/*     */   {
/* 127 */     static final BigDecimalAsStringSerializer BD_INSTANCE = new BigDecimalAsStringSerializer();
/*     */     
/*     */     public BigDecimalAsStringSerializer() {
/* 130 */       super(BigDecimal.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isEmpty(SerializerProvider prov, Object value) {
/* 137 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void serialize(Object value, JsonGenerator gen, SerializerProvider provider) throws IOException {
/*     */       String text;
/* 145 */       if (gen.isEnabled(JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN)) {
/* 146 */         BigDecimal bd = (BigDecimal)value;
/*     */         
/* 148 */         if (!_verifyBigDecimalRange(gen, bd)) {
/*     */ 
/*     */           
/* 151 */           String errorMsg = String.format("Attempt to write plain `java.math.BigDecimal` (see JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN) with illegal scale (%d): needs to be between [-%d, %d]", new Object[] {
/*     */                 
/* 153 */                 Integer.valueOf(bd.scale()), Integer.valueOf(9999), Integer.valueOf(9999) });
/* 154 */           provider.reportMappingProblem(errorMsg, new Object[0]);
/*     */         } 
/* 156 */         text = bd.toPlainString();
/*     */       } else {
/* 158 */         text = value.toString();
/*     */       } 
/* 160 */       gen.writeString(text);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String valueToString(Object value) {
/* 166 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean _verifyBigDecimalRange(JsonGenerator gen, BigDecimal value) throws IOException {
/* 171 */       int scale = value.scale();
/* 172 */       return (scale >= -9999 && scale <= 9999);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\NumberSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */