/*     */ package com.fasterxml.jackson.databind.ser;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.util.Annotations;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ 
/*     */ public class PropertyBuilder {
/*  19 */   private static final Object NO_DEFAULT_MARKER = Boolean.FALSE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final SerializationConfig _config;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final BeanDescription _beanDesc;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AnnotationIntrospector _annotationIntrospector;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _defaultBean;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonInclude.Value _defaultInclusion;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _useRealPropertyDefaults;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyBuilder(SerializationConfig config, BeanDescription beanDesc) {
/*  55 */     this._config = config;
/*  56 */     this._beanDesc = beanDesc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     JsonInclude.Value inclPerType = JsonInclude.Value.merge(beanDesc
/*  68 */         .findPropertyInclusion(JsonInclude.Value.empty()), config
/*  69 */         .getDefaultPropertyInclusion(beanDesc.getBeanClass(), 
/*  70 */           JsonInclude.Value.empty()));
/*  71 */     this._defaultInclusion = JsonInclude.Value.merge(config.getDefaultPropertyInclusion(), inclPerType);
/*     */     
/*  73 */     this._useRealPropertyDefaults = (inclPerType.getValueInclusion() == JsonInclude.Include.NON_DEFAULT);
/*  74 */     this._annotationIntrospector = this._config.getAnnotationIntrospector();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Annotations getClassAnnotations() {
/*  84 */     return this._beanDesc.getClassAnnotations();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanPropertyWriter buildWriter(SerializerProvider prov, BeanPropertyDefinition propDef, JavaType declaredType, JsonSerializer<?> ser, TypeSerializer typeSer, TypeSerializer contentTypeSer, AnnotatedMember am, boolean defaultUseStaticTyping) throws JsonMappingException {
/*     */     JavaType serializationType;
/*     */     Object defaultBean;
/*     */     SerializationFeature emptyJsonArrays;
/*     */     try {
/* 101 */       serializationType = findSerializationType((Annotated)am, defaultUseStaticTyping, declaredType);
/* 102 */     } catch (JsonMappingException e) {
/* 103 */       if (propDef == null) {
/* 104 */         return (BeanPropertyWriter)prov.reportBadDefinition(declaredType, ClassUtil.exceptionMessage((Throwable)e));
/*     */       }
/* 106 */       return (BeanPropertyWriter)prov.reportBadPropertyDefinition(this._beanDesc, propDef, ClassUtil.exceptionMessage((Throwable)e), new Object[0]);
/*     */     } 
/*     */ 
/*     */     
/* 110 */     if (contentTypeSer != null) {
/*     */ 
/*     */ 
/*     */       
/* 114 */       if (serializationType == null)
/*     */       {
/* 116 */         serializationType = declaredType;
/*     */       }
/* 118 */       JavaType ct = serializationType.getContentType();
/*     */       
/* 120 */       if (ct == null) {
/* 121 */         prov.reportBadPropertyDefinition(this._beanDesc, propDef, "serialization type " + serializationType + " has no content", new Object[0]);
/*     */       }
/*     */       
/* 124 */       serializationType = serializationType.withContentTypeHandler(contentTypeSer);
/* 125 */       ct = serializationType.getContentType();
/*     */     } 
/*     */     
/* 128 */     Object valueToSuppress = null;
/* 129 */     boolean suppressNulls = false;
/*     */ 
/*     */     
/* 132 */     JavaType actualType = (serializationType == null) ? declaredType : serializationType;
/*     */ 
/*     */     
/* 135 */     AnnotatedMember accessor = propDef.getAccessor();
/* 136 */     if (accessor == null)
/*     */     {
/* 138 */       return (BeanPropertyWriter)prov.reportBadPropertyDefinition(this._beanDesc, propDef, "could not determine property type", new Object[0]);
/*     */     }
/*     */     
/* 141 */     Class<?> rawPropertyType = accessor.getRawType();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     JsonInclude.Value inclV = this._config.getDefaultInclusion(actualType.getRawClass(), rawPropertyType, this._defaultInclusion);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 151 */     inclV = inclV.withOverrides(propDef.findInclusion());
/*     */     
/* 153 */     JsonInclude.Include inclusion = inclV.getValueInclusion();
/* 154 */     if (inclusion == JsonInclude.Include.USE_DEFAULTS) {
/* 155 */       inclusion = JsonInclude.Include.ALWAYS;
/*     */     }
/* 157 */     switch (inclusion) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case NON_DEFAULT:
/* 170 */         if (this._useRealPropertyDefaults && (defaultBean = getDefaultBean()) != null) {
/*     */           
/* 172 */           if (prov.isEnabled(MapperFeature.CAN_OVERRIDE_ACCESS_MODIFIERS)) {
/* 173 */             am.fixAccess(this._config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */           }
/*     */           try {
/* 176 */             valueToSuppress = am.getValue(defaultBean);
/* 177 */           } catch (Exception e) {
/* 178 */             _throwWrapped(e, propDef.getName(), defaultBean);
/*     */           } 
/*     */         } else {
/* 181 */           valueToSuppress = BeanUtil.getDefaultValue(actualType);
/* 182 */           suppressNulls = true;
/*     */         } 
/* 184 */         if (valueToSuppress == null) {
/* 185 */           suppressNulls = true;
/*     */ 
/*     */           
/* 188 */           if (!this._useRealPropertyDefaults)
/*     */           {
/* 190 */             valueToSuppress = BeanPropertyWriter.MARKER_FOR_EMPTY; } 
/*     */           break;
/*     */         } 
/* 193 */         if (valueToSuppress.getClass().isArray()) {
/* 194 */           valueToSuppress = ArrayBuilders.getArrayComparator(valueToSuppress);
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       case NON_ABSENT:
/* 200 */         suppressNulls = true;
/*     */         
/* 202 */         if (actualType.isReferenceType()) {
/* 203 */           valueToSuppress = BeanPropertyWriter.MARKER_FOR_EMPTY;
/*     */         }
/*     */         break;
/*     */       
/*     */       case NON_EMPTY:
/* 208 */         suppressNulls = true;
/*     */         
/* 210 */         valueToSuppress = BeanPropertyWriter.MARKER_FOR_EMPTY;
/*     */         break;
/*     */       case CUSTOM:
/* 213 */         valueToSuppress = prov.includeFilterInstance(propDef, inclV.getValueFilter());
/*     */         break;
/*     */       case NON_NULL:
/* 216 */         suppressNulls = true;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       default:
/* 222 */         emptyJsonArrays = SerializationFeature.WRITE_EMPTY_JSON_ARRAYS;
/* 223 */         if (actualType.isContainerType() && !this._config.isEnabled(emptyJsonArrays)) {
/* 224 */           valueToSuppress = BeanPropertyWriter.MARKER_FOR_EMPTY;
/*     */         }
/*     */         break;
/*     */     } 
/* 228 */     Class<?>[] views = propDef.findViews();
/* 229 */     if (views == null) {
/* 230 */       views = this._beanDesc.findDefaultViews();
/*     */     }
/* 232 */     BeanPropertyWriter bpw = _constructPropertyWriter(propDef, am, this._beanDesc
/* 233 */         .getClassAnnotations(), declaredType, ser, typeSer, serializationType, suppressNulls, valueToSuppress, views);
/*     */ 
/*     */ 
/*     */     
/* 237 */     Object serDef = this._annotationIntrospector.findNullSerializer((Annotated)am);
/* 238 */     if (serDef != null) {
/* 239 */       bpw.assignNullSerializer(prov.serializerInstance((Annotated)am, serDef));
/*     */     }
/*     */     
/* 242 */     NameTransformer unwrapper = this._annotationIntrospector.findUnwrappingNameTransformer(am);
/* 243 */     if (unwrapper != null) {
/* 244 */       bpw = bpw.unwrappingWriter(unwrapper);
/*     */     }
/* 246 */     return bpw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanPropertyWriter _constructPropertyWriter(BeanPropertyDefinition propDef, AnnotatedMember member, Annotations contextAnnotations, JavaType declaredType, JsonSerializer<?> ser, TypeSerializer typeSer, JavaType serType, boolean suppressNulls, Object suppressableValue, Class<?>[] includeInViews) throws JsonMappingException {
/* 263 */     return new BeanPropertyWriter(propDef, member, contextAnnotations, declaredType, ser, typeSer, serType, suppressNulls, suppressableValue, includeInViews);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JavaType findSerializationType(Annotated a, boolean useStaticTyping, JavaType declaredType) throws JsonMappingException {
/* 283 */     JavaType secondary = this._annotationIntrospector.refineSerializationType((MapperConfig)this._config, a, declaredType);
/*     */ 
/*     */ 
/*     */     
/* 287 */     if (secondary != declaredType) {
/* 288 */       Class<?> serClass = secondary.getRawClass();
/*     */       
/* 290 */       Class<?> rawDeclared = declaredType.getRawClass();
/* 291 */       if (!serClass.isAssignableFrom(rawDeclared))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 300 */         if (!rawDeclared.isAssignableFrom(serClass)) {
/* 301 */           throw new IllegalArgumentException("Illegal concrete-type annotation for method '" + a.getName() + "': class " + serClass.getName() + " not a super-type of (declared) class " + rawDeclared.getName());
/*     */         }
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 308 */       useStaticTyping = true;
/* 309 */       declaredType = secondary;
/*     */     } 
/*     */     
/* 312 */     JsonSerialize.Typing typing = this._annotationIntrospector.findSerializationTyping(a);
/* 313 */     if (typing != null && typing != JsonSerialize.Typing.DEFAULT_TYPING) {
/* 314 */       useStaticTyping = (typing == JsonSerialize.Typing.STATIC);
/*     */     }
/* 316 */     if (useStaticTyping)
/*     */     {
/* 318 */       return declaredType.withStaticTyping();
/*     */     }
/*     */     
/* 321 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object getDefaultBean() {
/* 332 */     Object def = this._defaultBean;
/* 333 */     if (def == null) {
/*     */ 
/*     */ 
/*     */       
/* 337 */       def = this._beanDesc.instantiateBean(this._config.canOverrideAccessModifiers());
/* 338 */       if (def == null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 346 */         def = NO_DEFAULT_MARKER;
/*     */       }
/* 348 */       this._defaultBean = def;
/*     */     } 
/* 350 */     return (def == NO_DEFAULT_MARKER) ? null : this._defaultBean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected Object getPropertyDefaultValue(String name, AnnotatedMember member, JavaType type) {
/* 372 */     Object defaultBean = getDefaultBean();
/* 373 */     if (defaultBean == null) {
/* 374 */       return getDefaultValue(type);
/*     */     }
/*     */     try {
/* 377 */       return member.getValue(defaultBean);
/* 378 */     } catch (Exception e) {
/* 379 */       return _throwWrapped(e, name, defaultBean);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected Object getDefaultValue(JavaType type) {
/* 388 */     return BeanUtil.getDefaultValue(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _throwWrapped(Exception e, String propName, Object defaultBean) {
/* 399 */     Throwable t = e;
/* 400 */     while (t.getCause() != null) {
/* 401 */       t = t.getCause();
/*     */     }
/* 403 */     ClassUtil.throwIfError(t);
/* 404 */     ClassUtil.throwIfRTE(t);
/* 405 */     throw new IllegalArgumentException("Failed to get property '" + propName + "' of default " + defaultBean.getClass().getName() + " instance");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\PropertyBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */