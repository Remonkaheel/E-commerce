/*     */ package com.fasterxml.jackson.databind.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.ser.impl.ReadOnlyClassToSerializerMap;
/*     */ import com.fasterxml.jackson.databind.util.LRUMap;
/*     */ import com.fasterxml.jackson.databind.util.LookupCache;
/*     */ import com.fasterxml.jackson.databind.util.TypeKey;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SerializerCache
/*     */ {
/*     */   public static final int DEFAULT_MAX_CACHE_SIZE = 4000;
/*     */   @Deprecated
/*     */   public static final int DEFAULT_MAX_CACHED = 4000;
/*     */   private final LookupCache<TypeKey, JsonSerializer<Object>> _sharedMap;
/*  51 */   private final AtomicReference<ReadOnlyClassToSerializerMap> _readOnlyMap = new AtomicReference<>();
/*     */ 
/*     */   
/*     */   public SerializerCache() {
/*  55 */     this(4000);
/*     */   }
/*     */   
/*     */   public SerializerCache(int maxCached) {
/*  59 */     int initial = Math.min(64, maxCached >> 2);
/*  60 */     this._sharedMap = (LookupCache<TypeKey, JsonSerializer<Object>>)new LRUMap(initial, maxCached);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializerCache(LookupCache<TypeKey, JsonSerializer<Object>> cache) {
/*  67 */     this._sharedMap = cache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadOnlyClassToSerializerMap getReadOnlyLookupMap() {
/*  76 */     ReadOnlyClassToSerializerMap m = this._readOnlyMap.get();
/*  77 */     if (m != null) {
/*  78 */       return m;
/*     */     }
/*  80 */     return _makeReadOnlyLookupMap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final synchronized ReadOnlyClassToSerializerMap _makeReadOnlyLookupMap() {
/*  86 */     ReadOnlyClassToSerializerMap m = this._readOnlyMap.get();
/*  87 */     if (m == null) {
/*  88 */       m = ReadOnlyClassToSerializerMap.from(this._sharedMap);
/*  89 */       this._readOnlyMap.set(m);
/*     */     } 
/*  91 */     return m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized int size() {
/* 101 */     return this._sharedMap.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> untypedValueSerializer(Class<?> type) {
/* 110 */     synchronized (this) {
/* 111 */       return (JsonSerializer<Object>)this._sharedMap.get(new TypeKey(type, false));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> untypedValueSerializer(JavaType type) {
/* 117 */     synchronized (this) {
/* 118 */       return (JsonSerializer<Object>)this._sharedMap.get(new TypeKey(type, false));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> typedValueSerializer(JavaType type) {
/* 124 */     synchronized (this) {
/* 125 */       return (JsonSerializer<Object>)this._sharedMap.get(new TypeKey(type, true));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> typedValueSerializer(Class<?> cls) {
/* 131 */     synchronized (this) {
/* 132 */       return (JsonSerializer<Object>)this._sharedMap.get(new TypeKey(cls, true));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTypedSerializer(JavaType type, JsonSerializer<Object> ser) {
/* 149 */     synchronized (this) {
/* 150 */       if (this._sharedMap.put(new TypeKey(type, true), ser) == null)
/*     */       {
/* 152 */         this._readOnlyMap.set(null);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void addTypedSerializer(Class<?> cls, JsonSerializer<Object> ser) {
/* 159 */     synchronized (this) {
/* 160 */       if (this._sharedMap.put(new TypeKey(cls, true), ser) == null)
/*     */       {
/* 162 */         this._readOnlyMap.set(null);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAndResolveNonTypedSerializer(Class<?> type, JsonSerializer<Object> ser, SerializerProvider provider) throws JsonMappingException {
/* 171 */     synchronized (this) {
/* 172 */       if (this._sharedMap.put(new TypeKey(type, false), ser) == null) {
/* 173 */         this._readOnlyMap.set(null);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 180 */       if (ser instanceof ResolvableSerializer) {
/* 181 */         ((ResolvableSerializer)ser).resolve(provider);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAndResolveNonTypedSerializer(JavaType type, JsonSerializer<Object> ser, SerializerProvider provider) throws JsonMappingException {
/* 190 */     synchronized (this) {
/* 191 */       if (this._sharedMap.put(new TypeKey(type, false), ser) == null) {
/* 192 */         this._readOnlyMap.set(null);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 199 */       if (ser instanceof ResolvableSerializer) {
/* 200 */         ((ResolvableSerializer)ser).resolve(provider);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAndResolveNonTypedSerializer(Class<?> rawType, JavaType fullType, JsonSerializer<Object> ser, SerializerProvider provider) throws JsonMappingException {
/* 216 */     synchronized (this) {
/* 217 */       Object ob1 = this._sharedMap.put(new TypeKey(rawType, false), ser);
/* 218 */       Object ob2 = this._sharedMap.put(new TypeKey(fullType, false), ser);
/* 219 */       if (ob1 == null || ob2 == null) {
/* 220 */         this._readOnlyMap.set(null);
/*     */       }
/* 222 */       if (ser instanceof ResolvableSerializer) {
/* 223 */         ((ResolvableSerializer)ser).resolve(provider);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void flush() {
/* 233 */     this._sharedMap.clear();
/* 234 */     this._readOnlyMap.set(null);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\SerializerCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */