/*      */ package com.fasterxml.jackson.databind.ser.std;
/*      */ import com.fasterxml.jackson.annotation.JsonFormat;
/*      */ import com.fasterxml.jackson.annotation.JsonInclude;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.BeanProperty;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.JsonNode;
/*      */ import com.fasterxml.jackson.databind.JsonSerializer;
/*      */ import com.fasterxml.jackson.databind.SerializationConfig;
/*      */ import com.fasterxml.jackson.databind.SerializationFeature;
/*      */ import com.fasterxml.jackson.databind.SerializerProvider;
/*      */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitable;
/*      */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*      */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonMapFormatVisitor;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.ContainerSerializer;
/*      */ import com.fasterxml.jackson.databind.ser.PropertyFilter;
/*      */ import com.fasterxml.jackson.databind.ser.impl.PropertySerializerMap;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.util.ArrayBuilders;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
/*      */ import java.io.IOException;
/*      */ import java.lang.reflect.Type;
/*      */ import java.util.HashSet;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ @JacksonStdImpl
/*      */ public class MapSerializer extends ContainerSerializer<Map<?, ?>> implements ContextualSerializer {
/*   41 */   protected static final JavaType UNSPECIFIED_TYPE = TypeFactory.unknownType();
/*      */ 
/*      */   
/*      */   private static final long serialVersionUID = 1L;
/*      */   
/*   46 */   public static final Object MARKER_FOR_EMPTY = JsonInclude.Include.NON_EMPTY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final BeanProperty _property;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _valueTypeIsStatic;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JavaType _keyType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JavaType _valueType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _keySerializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonSerializer<Object> _valueSerializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final TypeSerializer _valueTypeSerializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PropertySerializerMap _dynamicValueSerializers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Set<String> _ignoredEntries;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Set<String> _includedEntries;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object _filterId;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object _suppressableValue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _suppressNulls;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final IgnorePropertiesUtil.Checker _inclusionChecker;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _sortKeys;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MapSerializer(Set<String> ignoredEntries, Set<String> includedEntries, JavaType keyType, JavaType valueType, boolean valueTypeIsStatic, TypeSerializer vts, JsonSerializer<?> keySerializer, JsonSerializer<?> valueSerializer) {
/*  183 */     super(Map.class, false);
/*  184 */     this._ignoredEntries = (ignoredEntries == null || ignoredEntries.isEmpty()) ? null : ignoredEntries;
/*      */     
/*  186 */     this._includedEntries = includedEntries;
/*  187 */     this._keyType = keyType;
/*  188 */     this._valueType = valueType;
/*  189 */     this._valueTypeIsStatic = valueTypeIsStatic;
/*  190 */     this._valueTypeSerializer = vts;
/*  191 */     this._keySerializer = (JsonSerializer)keySerializer;
/*  192 */     this._valueSerializer = (JsonSerializer)valueSerializer;
/*  193 */     this._dynamicValueSerializers = PropertySerializerMap.emptyForProperties();
/*  194 */     this._property = null;
/*  195 */     this._filterId = null;
/*  196 */     this._sortKeys = false;
/*  197 */     this._suppressableValue = null;
/*  198 */     this._suppressNulls = false;
/*      */     
/*  200 */     this._inclusionChecker = IgnorePropertiesUtil.buildCheckerIfNeeded(this._ignoredEntries, this._includedEntries);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected MapSerializer(Set<String> ignoredEntries, JavaType keyType, JavaType valueType, boolean valueTypeIsStatic, TypeSerializer vts, JsonSerializer<?> keySerializer, JsonSerializer<?> valueSerializer) {
/*  213 */     this(ignoredEntries, (Set<String>)null, keyType, valueType, valueTypeIsStatic, vts, keySerializer, valueSerializer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MapSerializer(MapSerializer src, BeanProperty property, JsonSerializer<?> keySerializer, JsonSerializer<?> valueSerializer, Set<String> ignoredEntries, Set<String> includedEntries) {
/*  227 */     super(Map.class, false);
/*  228 */     this._ignoredEntries = (ignoredEntries == null || ignoredEntries.isEmpty()) ? null : ignoredEntries;
/*      */     
/*  230 */     this._includedEntries = includedEntries;
/*  231 */     this._keyType = src._keyType;
/*  232 */     this._valueType = src._valueType;
/*  233 */     this._valueTypeIsStatic = src._valueTypeIsStatic;
/*  234 */     this._valueTypeSerializer = src._valueTypeSerializer;
/*  235 */     this._keySerializer = (JsonSerializer)keySerializer;
/*  236 */     this._valueSerializer = (JsonSerializer)valueSerializer;
/*      */     
/*  238 */     this._dynamicValueSerializers = PropertySerializerMap.emptyForProperties();
/*  239 */     this._property = property;
/*  240 */     this._filterId = src._filterId;
/*  241 */     this._sortKeys = src._sortKeys;
/*  242 */     this._suppressableValue = src._suppressableValue;
/*  243 */     this._suppressNulls = src._suppressNulls;
/*      */     
/*  245 */     this._inclusionChecker = IgnorePropertiesUtil.buildCheckerIfNeeded(this._ignoredEntries, this._includedEntries);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected MapSerializer(MapSerializer src, BeanProperty property, JsonSerializer<?> keySerializer, JsonSerializer<?> valueSerializer, Set<String> ignoredEntries) {
/*  256 */     this(src, property, keySerializer, valueSerializer, ignoredEntries, (Set<String>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MapSerializer(MapSerializer src, TypeSerializer vts, Object suppressableValue, boolean suppressNulls) {
/*  265 */     super(Map.class, false);
/*  266 */     this._ignoredEntries = src._ignoredEntries;
/*  267 */     this._includedEntries = src._includedEntries;
/*  268 */     this._keyType = src._keyType;
/*  269 */     this._valueType = src._valueType;
/*  270 */     this._valueTypeIsStatic = src._valueTypeIsStatic;
/*  271 */     this._valueTypeSerializer = vts;
/*  272 */     this._keySerializer = src._keySerializer;
/*  273 */     this._valueSerializer = src._valueSerializer;
/*      */ 
/*      */     
/*  276 */     this._dynamicValueSerializers = src._dynamicValueSerializers;
/*  277 */     this._property = src._property;
/*  278 */     this._filterId = src._filterId;
/*  279 */     this._sortKeys = src._sortKeys;
/*  280 */     this._suppressableValue = suppressableValue;
/*  281 */     this._suppressNulls = suppressNulls;
/*      */     
/*  283 */     this._inclusionChecker = src._inclusionChecker;
/*      */   }
/*      */ 
/*      */   
/*      */   protected MapSerializer(MapSerializer src, Object filterId, boolean sortKeys) {
/*  288 */     super(Map.class, false);
/*  289 */     this._ignoredEntries = src._ignoredEntries;
/*  290 */     this._includedEntries = src._includedEntries;
/*  291 */     this._keyType = src._keyType;
/*  292 */     this._valueType = src._valueType;
/*  293 */     this._valueTypeIsStatic = src._valueTypeIsStatic;
/*  294 */     this._valueTypeSerializer = src._valueTypeSerializer;
/*  295 */     this._keySerializer = src._keySerializer;
/*  296 */     this._valueSerializer = src._valueSerializer;
/*      */     
/*  298 */     this._dynamicValueSerializers = PropertySerializerMap.emptyForProperties();
/*  299 */     this._property = src._property;
/*  300 */     this._filterId = filterId;
/*  301 */     this._sortKeys = sortKeys;
/*  302 */     this._suppressableValue = src._suppressableValue;
/*  303 */     this._suppressNulls = src._suppressNulls;
/*      */     
/*  305 */     this._inclusionChecker = src._inclusionChecker;
/*      */   }
/*      */ 
/*      */   
/*      */   public MapSerializer _withValueTypeSerializer(TypeSerializer vts) {
/*  310 */     if (this._valueTypeSerializer == vts) {
/*  311 */       return this;
/*      */     }
/*  313 */     _ensureOverride("_withValueTypeSerializer");
/*  314 */     return new MapSerializer(this, vts, this._suppressableValue, this._suppressNulls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapSerializer withResolved(BeanProperty property, JsonSerializer<?> keySerializer, JsonSerializer<?> valueSerializer, Set<String> ignored, Set<String> included, boolean sortKeys) {
/*  324 */     _ensureOverride("withResolved");
/*  325 */     MapSerializer ser = new MapSerializer(this, property, keySerializer, valueSerializer, ignored, included);
/*  326 */     if (sortKeys != ser._sortKeys) {
/*  327 */       ser = new MapSerializer(ser, this._filterId, sortKeys);
/*      */     }
/*  329 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapSerializer withResolved(BeanProperty property, JsonSerializer<?> keySerializer, JsonSerializer<?> valueSerializer, Set<String> ignored, boolean sortKeys) {
/*  339 */     return withResolved(property, keySerializer, valueSerializer, ignored, (Set<String>)null, sortKeys);
/*      */   }
/*      */ 
/*      */   
/*      */   public MapSerializer withFilterId(Object filterId) {
/*  344 */     if (this._filterId == filterId) {
/*  345 */       return this;
/*      */     }
/*  347 */     _ensureOverride("withFilterId");
/*  348 */     return new MapSerializer(this, filterId, this._sortKeys);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapSerializer withContentInclusion(Object suppressableValue, boolean suppressNulls) {
/*  358 */     if (suppressableValue == this._suppressableValue && suppressNulls == this._suppressNulls) {
/*  359 */       return this;
/*      */     }
/*  361 */     _ensureOverride("withContentInclusion");
/*  362 */     return new MapSerializer(this, this._valueTypeSerializer, suppressableValue, suppressNulls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MapSerializer construct(Set<String> ignoredEntries, Set<String> includedEntries, JavaType mapType, boolean staticValueType, TypeSerializer vts, JsonSerializer<Object> keySerializer, JsonSerializer<Object> valueSerializer, Object filterId) {
/*      */     JavaType keyType, valueType;
/*  375 */     if (mapType == null) {
/*  376 */       keyType = valueType = UNSPECIFIED_TYPE;
/*      */     } else {
/*  378 */       keyType = mapType.getKeyType();
/*  379 */       if (mapType.hasRawClass(Properties.class)) {
/*      */ 
/*      */         
/*  382 */         valueType = TypeFactory.unknownType();
/*      */       } else {
/*  384 */         valueType = mapType.getContentType();
/*      */       } 
/*      */     } 
/*      */     
/*  388 */     if (!staticValueType) {
/*  389 */       staticValueType = (valueType != null && valueType.isFinal());
/*      */     
/*      */     }
/*  392 */     else if (valueType.getRawClass() == Object.class) {
/*  393 */       staticValueType = false;
/*      */     } 
/*      */     
/*  396 */     MapSerializer ser = new MapSerializer(ignoredEntries, includedEntries, keyType, valueType, staticValueType, vts, keySerializer, valueSerializer);
/*      */     
/*  398 */     if (filterId != null) {
/*  399 */       ser = ser.withFilterId(filterId);
/*      */     }
/*  401 */     return ser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MapSerializer construct(Set<String> ignoredEntries, JavaType mapType, boolean staticValueType, TypeSerializer vts, JsonSerializer<Object> keySerializer, JsonSerializer<Object> valueSerializer, Object filterId) {
/*  412 */     return construct(ignoredEntries, (Set<String>)null, mapType, staticValueType, vts, keySerializer, valueSerializer, filterId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _ensureOverride(String method) {
/*  419 */     ClassUtil.verifyMustOverride(MapSerializer.class, this, method);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void _ensureOverride() {
/*  427 */     _ensureOverride("N/A");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected MapSerializer(MapSerializer src, TypeSerializer vts, Object suppressableValue) {
/*  444 */     this(src, vts, suppressableValue, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public MapSerializer withContentInclusion(Object suppressableValue) {
/*  452 */     return new MapSerializer(this, this._valueTypeSerializer, suppressableValue, this._suppressNulls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static MapSerializer construct(String[] ignoredList, JavaType mapType, boolean staticValueType, TypeSerializer vts, JsonSerializer<Object> keySerializer, JsonSerializer<Object> valueSerializer, Object filterId) {
/*  466 */     Set<String> ignoredEntries = ArrayBuilders.arrayToSet((Object[])ignoredList);
/*  467 */     return construct(ignoredEntries, mapType, staticValueType, vts, keySerializer, valueSerializer, filterId);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<?> createContextual(SerializerProvider provider, BeanProperty property) throws JsonMappingException {
/*  482 */     JsonSerializer<?> ser = null;
/*  483 */     JsonSerializer<?> keySer = null;
/*  484 */     AnnotationIntrospector intr = provider.getAnnotationIntrospector();
/*  485 */     AnnotatedMember propertyAcc = (property == null) ? null : property.getMember();
/*      */ 
/*      */     
/*  488 */     if (_neitherNull(propertyAcc, intr)) {
/*  489 */       Object serDef = intr.findKeySerializer((Annotated)propertyAcc);
/*  490 */       if (serDef != null) {
/*  491 */         keySer = provider.serializerInstance((Annotated)propertyAcc, serDef);
/*      */       }
/*  493 */       serDef = intr.findContentSerializer((Annotated)propertyAcc);
/*  494 */       if (serDef != null) {
/*  495 */         ser = provider.serializerInstance((Annotated)propertyAcc, serDef);
/*      */       }
/*      */     } 
/*  498 */     if (ser == null) {
/*  499 */       ser = this._valueSerializer;
/*      */     }
/*      */     
/*  502 */     ser = findContextualConvertingSerializer(provider, property, ser);
/*  503 */     if (ser == null)
/*      */     {
/*      */ 
/*      */       
/*  507 */       if (this._valueTypeIsStatic && !this._valueType.isJavaLangObject()) {
/*  508 */         ser = provider.findContentValueSerializer(this._valueType, property);
/*      */       }
/*      */     }
/*  511 */     if (keySer == null) {
/*  512 */       keySer = this._keySerializer;
/*      */     }
/*  514 */     if (keySer == null) {
/*  515 */       keySer = provider.findKeySerializer(this._keyType, property);
/*      */     } else {
/*  517 */       keySer = provider.handleSecondaryContextualization(keySer, property);
/*      */     } 
/*  519 */     Set<String> ignored = this._ignoredEntries;
/*  520 */     Set<String> included = this._includedEntries;
/*  521 */     boolean sortKeys = false;
/*  522 */     if (_neitherNull(propertyAcc, intr)) {
/*  523 */       SerializationConfig config = provider.getConfig();
/*      */       
/*  525 */       Set<String> newIgnored = intr.findPropertyIgnoralByName((MapperConfig)config, (Annotated)propertyAcc).findIgnoredForSerialization();
/*  526 */       if (_nonEmpty(newIgnored)) {
/*  527 */         ignored = (ignored == null) ? new HashSet<>() : new HashSet<>(ignored);
/*  528 */         for (String str : newIgnored) {
/*  529 */           ignored.add(str);
/*      */         }
/*      */       } 
/*      */       
/*  533 */       Set<String> newIncluded = intr.findPropertyInclusionByName((MapperConfig)config, (Annotated)propertyAcc).getIncluded();
/*  534 */       if (newIncluded != null) {
/*  535 */         included = (included == null) ? new HashSet<>() : new HashSet<>(included);
/*  536 */         for (String str : newIncluded) {
/*  537 */           included.add(str);
/*      */         }
/*      */       } 
/*      */       
/*  541 */       Boolean b = intr.findSerializationSortAlphabetically((Annotated)propertyAcc);
/*  542 */       sortKeys = Boolean.TRUE.equals(b);
/*      */     } 
/*  544 */     JsonFormat.Value format = findFormatOverrides(provider, property, Map.class);
/*  545 */     if (format != null) {
/*  546 */       Boolean B = format.getFeature(JsonFormat.Feature.WRITE_SORTED_MAP_ENTRIES);
/*  547 */       if (B != null) {
/*  548 */         sortKeys = B.booleanValue();
/*      */       }
/*      */     } 
/*  551 */     MapSerializer mser = withResolved(property, keySer, ser, ignored, included, sortKeys);
/*      */ 
/*      */     
/*  554 */     if (propertyAcc != null) {
/*  555 */       Object filterId = intr.findFilterId((Annotated)propertyAcc);
/*  556 */       if (filterId != null) {
/*  557 */         mser = mser.withFilterId(filterId);
/*      */       }
/*      */     } 
/*  560 */     JsonInclude.Value inclV = findIncludeOverrides(provider, property, Map.class);
/*  561 */     if (inclV != null) {
/*  562 */       JsonInclude.Include incl = inclV.getContentInclusion();
/*      */       
/*  564 */       if (incl != JsonInclude.Include.USE_DEFAULTS) {
/*      */         Object valueToSuppress;
/*      */         boolean suppressNulls;
/*  567 */         switch (incl) {
/*      */           case NON_DEFAULT:
/*  569 */             valueToSuppress = BeanUtil.getDefaultValue(this._valueType);
/*  570 */             suppressNulls = true;
/*  571 */             if (valueToSuppress != null && 
/*  572 */               valueToSuppress.getClass().isArray()) {
/*  573 */               valueToSuppress = ArrayBuilders.getArrayComparator(valueToSuppress);
/*      */             }
/*      */             break;
/*      */           
/*      */           case NON_ABSENT:
/*  578 */             suppressNulls = true;
/*  579 */             valueToSuppress = this._valueType.isReferenceType() ? MARKER_FOR_EMPTY : null;
/*      */             break;
/*      */           case NON_EMPTY:
/*  582 */             suppressNulls = true;
/*  583 */             valueToSuppress = MARKER_FOR_EMPTY;
/*      */             break;
/*      */           case CUSTOM:
/*  586 */             valueToSuppress = provider.includeFilterInstance(null, inclV.getContentFilter());
/*  587 */             if (valueToSuppress == null) {
/*  588 */               suppressNulls = true; break;
/*      */             } 
/*  590 */             suppressNulls = provider.includeFilterSuppressNulls(valueToSuppress);
/*      */             break;
/*      */           
/*      */           case NON_NULL:
/*  594 */             valueToSuppress = null;
/*  595 */             suppressNulls = true;
/*      */             break;
/*      */           
/*      */           default:
/*  599 */             valueToSuppress = null;
/*      */ 
/*      */             
/*  602 */             suppressNulls = false;
/*      */             break;
/*      */         } 
/*  605 */         mser = mser.withContentInclusion(valueToSuppress, suppressNulls);
/*      */       } 
/*      */     } 
/*  608 */     return (JsonSerializer<?>)mser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType getContentType() {
/*  619 */     return this._valueType;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonSerializer<?> getContentSerializer() {
/*  624 */     return this._valueSerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty(SerializerProvider prov, Map<?, ?> value) {
/*  630 */     if (value.isEmpty()) {
/*  631 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  636 */     Object supp = this._suppressableValue;
/*  637 */     if (supp == null && !this._suppressNulls) {
/*  638 */       return false;
/*      */     }
/*  640 */     JsonSerializer<Object> valueSer = this._valueSerializer;
/*  641 */     boolean checkEmpty = (MARKER_FOR_EMPTY == supp);
/*  642 */     if (valueSer != null) {
/*  643 */       for (Object elemValue : value.values()) {
/*  644 */         if (elemValue == null) {
/*  645 */           if (this._suppressNulls) {
/*      */             continue;
/*      */           }
/*  648 */           return false;
/*      */         } 
/*  650 */         if (checkEmpty) {
/*  651 */           if (!valueSer.isEmpty(prov, elemValue))
/*  652 */             return false;  continue;
/*      */         } 
/*  654 */         if (supp == null || !supp.equals(value)) {
/*  655 */           return false;
/*      */         }
/*      */       } 
/*  658 */       return true;
/*      */     } 
/*      */     
/*  661 */     for (Object elemValue : value.values()) {
/*  662 */       if (elemValue == null) {
/*  663 */         if (this._suppressNulls) {
/*      */           continue;
/*      */         }
/*  666 */         return false;
/*      */       } 
/*      */       try {
/*  669 */         valueSer = _findSerializer(prov, elemValue);
/*  670 */       } catch (DatabindException e) {
/*      */         
/*  672 */         return false;
/*      */       } 
/*  674 */       if (checkEmpty) {
/*  675 */         if (!valueSer.isEmpty(prov, elemValue))
/*  676 */           return false;  continue;
/*      */       } 
/*  678 */       if (supp == null || !supp.equals(value)) {
/*  679 */         return false;
/*      */       }
/*      */     } 
/*  682 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean hasSingleElement(Map<?, ?> value) {
/*  687 */     return (value.size() == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonSerializer<?> getKeySerializer() {
/*  705 */     return this._keySerializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serialize(Map<?, ?> value, JsonGenerator gen, SerializerProvider provider) throws IOException {
/*  718 */     gen.writeStartObject(value);
/*  719 */     serializeWithoutTypeInfo(value, gen, provider);
/*  720 */     gen.writeEndObject();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serializeWithType(Map<?, ?> value, JsonGenerator gen, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/*  729 */     gen.assignCurrentValue(value);
/*  730 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(gen, typeSer
/*  731 */         .typeId(value, JsonToken.START_OBJECT));
/*  732 */     serializeWithoutTypeInfo(value, gen, provider);
/*  733 */     typeSer.writeTypeSuffix(gen, typeIdDef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serializeWithoutTypeInfo(Map<?, ?> value, JsonGenerator gen, SerializerProvider provider) throws IOException {
/*  751 */     if (!value.isEmpty()) {
/*  752 */       if (this._sortKeys || provider.isEnabled(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS)) {
/*  753 */         value = _orderEntries(value, gen, provider);
/*      */       }
/*      */       PropertyFilter pf;
/*  756 */       if (this._filterId != null && (pf = findPropertyFilter(provider, this._filterId, value)) != null) {
/*  757 */         serializeFilteredFields(value, gen, provider, pf, this._suppressableValue);
/*  758 */       } else if (this._suppressableValue != null || this._suppressNulls) {
/*  759 */         serializeOptionalFields(value, gen, provider, this._suppressableValue);
/*  760 */       } else if (this._valueSerializer != null) {
/*  761 */         serializeFieldsUsing(value, gen, provider, this._valueSerializer);
/*      */       } else {
/*  763 */         serializeFields(value, gen, provider);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serializeFields(Map<?, ?> value, JsonGenerator gen, SerializerProvider provider) throws IOException {
/*  777 */     if (this._valueTypeSerializer != null) {
/*  778 */       serializeTypedFields(value, gen, provider, (Object)null);
/*      */       return;
/*      */     } 
/*  781 */     JsonSerializer<Object> keySerializer = this._keySerializer;
/*  782 */     Object keyElem = null;
/*      */     
/*      */     try {
/*  785 */       for (Map.Entry<?, ?> entry : value.entrySet()) {
/*  786 */         Object valueElem = entry.getValue();
/*      */         
/*  788 */         keyElem = entry.getKey();
/*  789 */         if (keyElem == null) {
/*  790 */           provider.findNullKeySerializer(this._keyType, this._property).serialize(null, gen, provider);
/*      */         } else {
/*      */           
/*  793 */           if (this._inclusionChecker != null && this._inclusionChecker.shouldIgnore(keyElem)) {
/*      */             continue;
/*      */           }
/*  796 */           keySerializer.serialize(keyElem, gen, provider);
/*      */         } 
/*      */         
/*  799 */         if (valueElem == null) {
/*  800 */           provider.defaultSerializeNull(gen);
/*      */           continue;
/*      */         } 
/*  803 */         JsonSerializer<Object> serializer = this._valueSerializer;
/*  804 */         if (serializer == null) {
/*  805 */           serializer = _findSerializer(provider, valueElem);
/*      */         }
/*  807 */         serializer.serialize(valueElem, gen, provider);
/*      */       } 
/*  809 */     } catch (Exception e) {
/*  810 */       wrapAndThrow(provider, e, value, String.valueOf(keyElem));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serializeOptionalFields(Map<?, ?> value, JsonGenerator gen, SerializerProvider provider, Object suppressableValue) throws IOException {
/*  822 */     if (this._valueTypeSerializer != null) {
/*  823 */       serializeTypedFields(value, gen, provider, suppressableValue);
/*      */       return;
/*      */     } 
/*  826 */     boolean checkEmpty = (MARKER_FOR_EMPTY == suppressableValue);
/*      */     
/*  828 */     for (Map.Entry<?, ?> entry : value.entrySet()) {
/*      */       JsonSerializer<Object> keySerializer, valueSer;
/*  830 */       Object keyElem = entry.getKey();
/*      */       
/*  832 */       if (keyElem == null) {
/*  833 */         keySerializer = provider.findNullKeySerializer(this._keyType, this._property);
/*      */       } else {
/*  835 */         if (this._inclusionChecker != null && this._inclusionChecker.shouldIgnore(keyElem)) {
/*      */           continue;
/*      */         }
/*  838 */         keySerializer = this._keySerializer;
/*      */       } 
/*      */ 
/*      */       
/*  842 */       Object valueElem = entry.getValue();
/*      */       
/*  844 */       if (valueElem == null) {
/*  845 */         if (this._suppressNulls) {
/*      */           continue;
/*      */         }
/*  848 */         valueSer = provider.getDefaultNullValueSerializer();
/*      */       } else {
/*  850 */         valueSer = this._valueSerializer;
/*  851 */         if (valueSer == null) {
/*  852 */           valueSer = _findSerializer(provider, valueElem);
/*      */         }
/*      */         
/*  855 */         if (checkEmpty ? 
/*  856 */           valueSer.isEmpty(provider, valueElem) : (
/*      */ 
/*      */           
/*  859 */           suppressableValue != null && 
/*  860 */           suppressableValue.equals(valueElem))) {
/*      */           continue;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/*  867 */         keySerializer.serialize(keyElem, gen, provider);
/*  868 */         valueSer.serialize(valueElem, gen, provider);
/*  869 */       } catch (Exception e) {
/*  870 */         wrapAndThrow(provider, e, value, String.valueOf(keyElem));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serializeFieldsUsing(Map<?, ?> value, JsonGenerator gen, SerializerProvider provider, JsonSerializer<Object> ser) throws IOException {
/*  884 */     JsonSerializer<Object> keySerializer = this._keySerializer;
/*  885 */     TypeSerializer typeSer = this._valueTypeSerializer;
/*      */     
/*  887 */     for (Map.Entry<?, ?> entry : value.entrySet()) {
/*  888 */       Object keyElem = entry.getKey();
/*  889 */       if (this._inclusionChecker != null && this._inclusionChecker.shouldIgnore(keyElem)) {
/*      */         continue;
/*      */       }
/*      */       
/*  893 */       if (keyElem == null) {
/*  894 */         provider.findNullKeySerializer(this._keyType, this._property).serialize(null, gen, provider);
/*      */       } else {
/*  896 */         keySerializer.serialize(keyElem, gen, provider);
/*      */       } 
/*  898 */       Object valueElem = entry.getValue();
/*  899 */       if (valueElem == null) {
/*  900 */         provider.defaultSerializeNull(gen); continue;
/*      */       } 
/*      */       try {
/*  903 */         if (typeSer == null) {
/*  904 */           ser.serialize(valueElem, gen, provider); continue;
/*      */         } 
/*  906 */         ser.serializeWithType(valueElem, gen, provider, typeSer);
/*      */       }
/*  908 */       catch (Exception e) {
/*  909 */         wrapAndThrow(provider, e, value, String.valueOf(keyElem));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serializeFilteredFields(Map<?, ?> value, JsonGenerator gen, SerializerProvider provider, PropertyFilter filter, Object suppressableValue) throws IOException {
/*  926 */     MapProperty prop = new MapProperty(this._valueTypeSerializer, this._property);
/*  927 */     boolean checkEmpty = (MARKER_FOR_EMPTY == suppressableValue);
/*      */     
/*  929 */     for (Map.Entry<?, ?> entry : value.entrySet()) {
/*      */       JsonSerializer<Object> keySerializer, valueSer;
/*  931 */       Object keyElem = entry.getKey();
/*  932 */       if (this._inclusionChecker != null && this._inclusionChecker.shouldIgnore(keyElem)) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/*  937 */       if (keyElem == null) {
/*  938 */         keySerializer = provider.findNullKeySerializer(this._keyType, this._property);
/*      */       } else {
/*  940 */         keySerializer = this._keySerializer;
/*      */       } 
/*      */       
/*  943 */       Object valueElem = entry.getValue();
/*      */ 
/*      */ 
/*      */       
/*  947 */       if (valueElem == null) {
/*  948 */         if (this._suppressNulls) {
/*      */           continue;
/*      */         }
/*  951 */         valueSer = provider.getDefaultNullValueSerializer();
/*      */       } else {
/*  953 */         valueSer = this._valueSerializer;
/*  954 */         if (valueSer == null) {
/*  955 */           valueSer = _findSerializer(provider, valueElem);
/*      */         }
/*      */         
/*  958 */         if (checkEmpty ? 
/*  959 */           valueSer.isEmpty(provider, valueElem) : (
/*      */ 
/*      */           
/*  962 */           suppressableValue != null && 
/*  963 */           suppressableValue.equals(valueElem))) {
/*      */           continue;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  969 */       prop.reset(keyElem, valueElem, keySerializer, valueSer);
/*      */       try {
/*  971 */         filter.serializeAsField(value, gen, provider, prop);
/*  972 */       } catch (Exception e) {
/*  973 */         wrapAndThrow(provider, e, value, String.valueOf(keyElem));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serializeTypedFields(Map<?, ?> value, JsonGenerator gen, SerializerProvider provider, Object suppressableValue) throws IOException {
/*  985 */     boolean checkEmpty = (MARKER_FOR_EMPTY == suppressableValue);
/*      */     
/*  987 */     for (Map.Entry<?, ?> entry : value.entrySet()) {
/*  988 */       JsonSerializer<Object> keySerializer, valueSer; Object keyElem = entry.getKey();
/*      */       
/*  990 */       if (keyElem == null) {
/*  991 */         keySerializer = provider.findNullKeySerializer(this._keyType, this._property);
/*      */       } else {
/*      */         
/*  994 */         if (this._inclusionChecker != null && this._inclusionChecker.shouldIgnore(keyElem)) {
/*      */           continue;
/*      */         }
/*  997 */         keySerializer = this._keySerializer;
/*      */       } 
/*  999 */       Object valueElem = entry.getValue();
/*      */ 
/*      */ 
/*      */       
/* 1003 */       if (valueElem == null) {
/* 1004 */         if (this._suppressNulls) {
/*      */           continue;
/*      */         }
/* 1007 */         valueSer = provider.getDefaultNullValueSerializer();
/*      */       } else {
/* 1009 */         valueSer = this._valueSerializer;
/* 1010 */         if (valueSer == null) {
/* 1011 */           valueSer = _findSerializer(provider, valueElem);
/*      */         }
/*      */         
/* 1014 */         if (checkEmpty ? 
/* 1015 */           valueSer.isEmpty(provider, valueElem) : (
/*      */ 
/*      */           
/* 1018 */           suppressableValue != null && 
/* 1019 */           suppressableValue.equals(valueElem))) {
/*      */           continue;
/*      */         }
/*      */       } 
/*      */       
/* 1024 */       keySerializer.serialize(keyElem, gen, provider);
/*      */       try {
/* 1026 */         valueSer.serializeWithType(valueElem, gen, provider, this._valueTypeSerializer);
/* 1027 */       } catch (Exception e) {
/* 1028 */         wrapAndThrow(provider, e, value, String.valueOf(keyElem));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void serializeFilteredAnyProperties(SerializerProvider provider, JsonGenerator gen, Object bean, Map<?, ?> value, PropertyFilter filter, Object suppressableValue) throws IOException {
/* 1046 */     MapProperty prop = new MapProperty(this._valueTypeSerializer, this._property);
/* 1047 */     boolean checkEmpty = (MARKER_FOR_EMPTY == suppressableValue);
/*      */     
/* 1049 */     for (Map.Entry<?, ?> entry : value.entrySet()) {
/*      */       JsonSerializer<Object> keySerializer, valueSer;
/* 1051 */       Object keyElem = entry.getKey();
/* 1052 */       if (this._inclusionChecker != null && this._inclusionChecker.shouldIgnore(keyElem)) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */       
/* 1057 */       if (keyElem == null) {
/* 1058 */         keySerializer = provider.findNullKeySerializer(this._keyType, this._property);
/*      */       } else {
/* 1060 */         keySerializer = this._keySerializer;
/*      */       } 
/*      */       
/* 1063 */       Object valueElem = entry.getValue();
/*      */ 
/*      */ 
/*      */       
/* 1067 */       if (valueElem == null) {
/* 1068 */         if (this._suppressNulls) {
/*      */           continue;
/*      */         }
/* 1071 */         valueSer = provider.getDefaultNullValueSerializer();
/*      */       } else {
/* 1073 */         valueSer = this._valueSerializer;
/* 1074 */         if (valueSer == null) {
/* 1075 */           valueSer = _findSerializer(provider, valueElem);
/*      */         }
/*      */         
/* 1078 */         if (checkEmpty ? 
/* 1079 */           valueSer.isEmpty(provider, valueElem) : (
/*      */ 
/*      */           
/* 1082 */           suppressableValue != null && 
/* 1083 */           suppressableValue.equals(valueElem))) {
/*      */           continue;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1089 */       prop.reset(keyElem, valueElem, keySerializer, valueSer);
/*      */       try {
/* 1091 */         filter.serializeAsField(bean, gen, provider, prop);
/* 1092 */       } catch (Exception e) {
/* 1093 */         wrapAndThrow(provider, e, value, String.valueOf(keyElem));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonNode getSchema(SerializerProvider provider, Type typeHint) {
/* 1113 */     return (JsonNode)createSchemaNode("object", true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 1120 */     JsonMapFormatVisitor v2 = visitor.expectMapFormat(typeHint);
/* 1121 */     if (v2 != null) {
/* 1122 */       v2.keyFormat((JsonFormatVisitable)this._keySerializer, this._keyType);
/* 1123 */       JsonSerializer<?> valueSer = this._valueSerializer;
/* 1124 */       if (valueSer == null) {
/* 1125 */         valueSer = _findAndAddDynamic(this._dynamicValueSerializers, this._valueType, visitor
/* 1126 */             .getProvider());
/*      */       }
/* 1128 */       v2.valueFormat((JsonFormatVisitable)valueSer, this._valueType);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonSerializer<Object> _findAndAddDynamic(PropertySerializerMap map, Class<?> type, SerializerProvider provider) throws JsonMappingException {
/* 1142 */     PropertySerializerMap.SerializerAndMapResult result = map.findAndAddSecondarySerializer(type, provider, this._property);
/*      */     
/* 1144 */     if (map != result.map) {
/* 1145 */       this._dynamicValueSerializers = result.map;
/*      */     }
/* 1147 */     return result.serializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonSerializer<Object> _findAndAddDynamic(PropertySerializerMap map, JavaType type, SerializerProvider provider) throws JsonMappingException {
/* 1154 */     PropertySerializerMap.SerializerAndMapResult result = map.findAndAddSecondarySerializer(type, provider, this._property);
/* 1155 */     if (map != result.map) {
/* 1156 */       this._dynamicValueSerializers = result.map;
/*      */     }
/* 1158 */     return result.serializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Map<?, ?> _orderEntries(Map<?, ?> input, JsonGenerator gen, SerializerProvider provider) throws IOException {
/* 1166 */     if (input instanceof java.util.SortedMap) {
/* 1167 */       return input;
/*      */     }
/*      */     
/* 1170 */     if (input.isEmpty()) {
/* 1171 */       return input;
/*      */     }
/*      */ 
/*      */     
/* 1175 */     Object firstKey = input.keySet().iterator().next();
/* 1176 */     if (!Comparable.class.isInstance(firstKey)) {
/*      */       
/* 1178 */       if (!provider.isEnabled(SerializationFeature.FAIL_ON_ORDER_MAP_BY_INCOMPARABLE_KEY)) {
/* 1179 */         return input;
/*      */       }
/* 1181 */       Class<?> clazz = (firstKey == null) ? Object.class : firstKey.getClass();
/* 1182 */       provider.reportBadDefinition(clazz, 
/* 1183 */           String.format("Cannot order Map entries by key of incomparable type %s, consider disabling `SerializationFeature.FAIL_ON_ORDER_MAP_BY_INCOMPARABLE_KEY` to simply skip sorting", new Object[] {
/*      */               
/* 1185 */               ClassUtil.classNameOf(firstKey)
/*      */             }));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1193 */     if (_hasNullKey(input)) {
/* 1194 */       TreeMap<Object, Object> result = new TreeMap<>();
/* 1195 */       for (Map.Entry<?, ?> entry : input.entrySet()) {
/* 1196 */         Object key = entry.getKey();
/* 1197 */         if (key == null) {
/* 1198 */           _writeNullKeyedEntry(gen, provider, entry.getValue());
/*      */           continue;
/*      */         } 
/* 1201 */         result.put(key, entry.getValue());
/*      */       } 
/* 1203 */       return result;
/*      */     } 
/* 1205 */     return new TreeMap<>(input);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _hasNullKey(Map<?, ?> input) {
/* 1221 */     return (input instanceof java.util.HashMap && input.containsKey(null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _writeNullKeyedEntry(JsonGenerator gen, SerializerProvider provider, Object value) throws IOException {
/* 1228 */     JsonSerializer<Object> valueSer, keySerializer = provider.findNullKeySerializer(this._keyType, this._property);
/*      */     
/* 1230 */     if (value == null) {
/* 1231 */       if (this._suppressNulls) {
/*      */         return;
/*      */       }
/* 1234 */       valueSer = provider.getDefaultNullValueSerializer();
/*      */     } else {
/* 1236 */       valueSer = this._valueSerializer;
/* 1237 */       if (valueSer == null) {
/* 1238 */         valueSer = _findSerializer(provider, value);
/*      */       }
/* 1240 */       if (this._suppressableValue == MARKER_FOR_EMPTY) {
/* 1241 */         if (valueSer.isEmpty(provider, value)) {
/*      */           return;
/*      */         }
/* 1244 */       } else if (this._suppressableValue != null && this._suppressableValue
/* 1245 */         .equals(value)) {
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/*      */     try {
/* 1251 */       keySerializer.serialize(null, gen, provider);
/* 1252 */       valueSer.serialize(value, gen, provider);
/* 1253 */     } catch (Exception e) {
/* 1254 */       wrapAndThrow(provider, e, value, "");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonSerializer<Object> _findSerializer(SerializerProvider provider, Object value) throws JsonMappingException {
/* 1262 */     Class<?> cc = value.getClass();
/* 1263 */     JsonSerializer<Object> valueSer = this._dynamicValueSerializers.serializerFor(cc);
/* 1264 */     if (valueSer != null) {
/* 1265 */       return valueSer;
/*      */     }
/* 1267 */     if (this._valueType.hasGenericTypes()) {
/* 1268 */       return _findAndAddDynamic(this._dynamicValueSerializers, provider
/* 1269 */           .constructSpecializedType(this._valueType, cc), provider);
/*      */     }
/* 1271 */     return _findAndAddDynamic(this._dynamicValueSerializers, cc, provider);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\MapSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */