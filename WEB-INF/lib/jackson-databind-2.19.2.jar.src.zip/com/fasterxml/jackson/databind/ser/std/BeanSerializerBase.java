/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.ObjectIdInfo;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonObjectFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsonschema.JsonSerializableSchema;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import com.fasterxml.jackson.databind.ser.BeanPropertyWriter;
/*     */ import com.fasterxml.jackson.databind.ser.BeanSerializerBuilder;
/*     */ import com.fasterxml.jackson.databind.ser.ContainerSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.PropertyFilter;
/*     */ import com.fasterxml.jackson.databind.ser.PropertyWriter;
/*     */ import com.fasterxml.jackson.databind.ser.impl.MapEntrySerializer;
/*     */ import com.fasterxml.jackson.databind.ser.impl.ObjectIdWriter;
/*     */ import com.fasterxml.jackson.databind.ser.impl.PropertyBasedObjectIdGenerator;
/*     */ import com.fasterxml.jackson.databind.ser.impl.WritableObjectId;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public abstract class BeanSerializerBase extends StdSerializer<Object> implements ContextualSerializer, ResolvableSerializer, JsonFormatVisitable {
/*  42 */   protected static final PropertyName NAME_FOR_OBJECT_REF = new PropertyName("#object-ref");
/*     */   
/*  44 */   protected static final BeanPropertyWriter[] NO_PROPS = new BeanPropertyWriter[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JavaType _beanType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final BeanPropertyWriter[] _props;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final BeanPropertyWriter[] _filteredProps;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Object _propertyFilterId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AnnotatedMember _typeId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ObjectIdWriter _objectIdWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonFormat.Shape _serializationShape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanSerializerBase(JavaType type, BeanSerializerBuilder builder, BeanPropertyWriter[] properties, BeanPropertyWriter[] filteredProperties) {
/* 107 */     super(type);
/* 108 */     this._beanType = type;
/* 109 */     this._props = properties;
/* 110 */     this._filteredProps = filteredProperties;
/* 111 */     if (builder == null) {
/*     */ 
/*     */       
/* 114 */       this._typeId = null;
/* 115 */       this._propertyFilterId = null;
/* 116 */       this._objectIdWriter = null;
/* 117 */       this._serializationShape = null;
/*     */     } else {
/* 119 */       this._typeId = builder.getTypeId();
/* 120 */       this._propertyFilterId = builder.getFilterId();
/* 121 */       this._objectIdWriter = builder.getObjectIdWriter();
/* 122 */       JsonFormat.Value format = builder.getBeanDescription().findExpectedFormat();
/* 123 */       this._serializationShape = format.getShape();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanSerializerBase(BeanSerializerBase src, BeanPropertyWriter[] properties, BeanPropertyWriter[] filteredProperties) {
/* 130 */     super(src._handledType);
/* 131 */     this._beanType = src._beanType;
/* 132 */     this._props = properties;
/* 133 */     this._filteredProps = filteredProperties;
/*     */     
/* 135 */     this._typeId = src._typeId;
/* 136 */     this._objectIdWriter = src._objectIdWriter;
/* 137 */     this._propertyFilterId = src._propertyFilterId;
/* 138 */     this._serializationShape = src._serializationShape;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanSerializerBase(BeanSerializerBase src, ObjectIdWriter objectIdWriter) {
/* 144 */     this(src, objectIdWriter, src._propertyFilterId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanSerializerBase(BeanSerializerBase src, ObjectIdWriter objectIdWriter, Object filterId) {
/* 153 */     super(src._handledType);
/* 154 */     this._beanType = src._beanType;
/* 155 */     this._props = src._props;
/* 156 */     this._filteredProps = src._filteredProps;
/*     */     
/* 158 */     this._typeId = src._typeId;
/* 159 */     this._objectIdWriter = objectIdWriter;
/* 160 */     this._propertyFilterId = filterId;
/* 161 */     this._serializationShape = src._serializationShape;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected BeanSerializerBase(BeanSerializerBase src, String[] toIgnore) {
/* 167 */     this(src, ArrayBuilders.arrayToSet((Object[])toIgnore), (Set<String>)null);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected BeanSerializerBase(BeanSerializerBase src, Set<String> toIgnore) {
/* 172 */     this(src, toIgnore, (Set<String>)null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected BeanSerializerBase(BeanSerializerBase src, Set<String> toIgnore, Set<String> toInclude) {
/* 177 */     super(src._handledType);
/*     */     
/* 179 */     this._beanType = src._beanType;
/* 180 */     BeanPropertyWriter[] propsIn = src._props;
/* 181 */     BeanPropertyWriter[] fpropsIn = src._filteredProps;
/* 182 */     int len = propsIn.length;
/*     */     
/* 184 */     ArrayList<BeanPropertyWriter> propsOut = new ArrayList<>(len);
/* 185 */     ArrayList<BeanPropertyWriter> fpropsOut = (fpropsIn == null) ? null : new ArrayList<>(len);
/*     */     
/* 187 */     for (int i = 0; i < len; i++) {
/* 188 */       BeanPropertyWriter bpw = propsIn[i];
/*     */       
/* 190 */       if (!IgnorePropertiesUtil.shouldIgnore(bpw.getName(), toIgnore, toInclude)) {
/*     */ 
/*     */         
/* 193 */         propsOut.add(bpw);
/* 194 */         if (fpropsIn != null)
/* 195 */           fpropsOut.add(fpropsIn[i]); 
/*     */       } 
/*     */     } 
/* 198 */     this._props = propsOut.<BeanPropertyWriter>toArray(new BeanPropertyWriter[propsOut.size()]);
/* 199 */     this._filteredProps = (fpropsOut == null) ? null : fpropsOut.<BeanPropertyWriter>toArray(new BeanPropertyWriter[fpropsOut.size()]);
/*     */     
/* 201 */     this._typeId = src._typeId;
/* 202 */     this._objectIdWriter = src._objectIdWriter;
/* 203 */     this._propertyFilterId = src._propertyFilterId;
/* 204 */     this._serializationShape = src._serializationShape;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected BeanSerializerBase withIgnorals(Set<String> toIgnore) {
/* 224 */     return withByNameInclusion(toIgnore, (Set<String>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected BeanSerializerBase withIgnorals(String[] toIgnore) {
/* 244 */     return withIgnorals(ArrayBuilders.arrayToSet((Object[])toIgnore));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanSerializerBase(BeanSerializerBase src) {
/* 282 */     this(src, src._props, src._filteredProps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanSerializerBase(BeanSerializerBase src, NameTransformer unwrapper) {
/* 290 */     this(src, rename(src._props, unwrapper), rename(src._filteredProps, unwrapper));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final BeanPropertyWriter[] rename(BeanPropertyWriter[] props, NameTransformer transformer) {
/* 296 */     if (props == null || props.length == 0 || transformer == null || transformer == NameTransformer.NOP) {
/* 297 */       return props;
/*     */     }
/* 299 */     int len = props.length;
/* 300 */     BeanPropertyWriter[] result = new BeanPropertyWriter[len];
/* 301 */     for (int i = 0; i < len; i++) {
/* 302 */       BeanPropertyWriter bpw = props[i];
/* 303 */       if (bpw != null) {
/* 304 */         result[i] = bpw.rename(transformer);
/*     */       }
/*     */     } 
/* 307 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(SerializerProvider provider) throws JsonMappingException {
/* 324 */     int filteredCount = (this._filteredProps == null) ? 0 : this._filteredProps.length; int i, len;
/* 325 */     for (i = 0, len = this._props.length; i < len; i++) {
/* 326 */       ContainerSerializer containerSerializer; BeanPropertyWriter prop = this._props[i];
/*     */       
/* 328 */       if (!prop.willSuppressNulls() && !prop.hasNullSerializer()) {
/* 329 */         JsonSerializer<Object> nullSer = provider.findNullValueSerializer((BeanProperty)prop);
/* 330 */         if (nullSer != null) {
/* 331 */           prop.assignNullSerializer(nullSer);
/*     */           
/* 333 */           if (i < filteredCount) {
/* 334 */             BeanPropertyWriter w2 = this._filteredProps[i];
/* 335 */             if (w2 != null) {
/* 336 */               w2.assignNullSerializer(nullSer);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 342 */       if (prop.hasSerializer()) {
/*     */         continue;
/*     */       }
/*     */       
/* 346 */       JsonSerializer<Object> ser = findConvertingSerializer(provider, prop);
/* 347 */       if (ser == null) {
/*     */         
/* 349 */         JavaType type = prop.getSerializationType();
/*     */ 
/*     */ 
/*     */         
/* 353 */         if (type == null) {
/* 354 */           type = prop.getType();
/* 355 */           if (!type.isFinal()) {
/* 356 */             if (type.isContainerType() || type.containedTypeCount() > 0) {
/* 357 */               prop.setNonTrivialBaseType(type);
/*     */             }
/*     */             continue;
/*     */           } 
/*     */         } 
/* 362 */         ser = provider.findValueSerializer(type, (BeanProperty)prop);
/*     */ 
/*     */         
/* 365 */         if (type.isContainerType()) {
/* 366 */           TypeSerializer typeSer = (TypeSerializer)type.getContentType().getTypeHandler();
/* 367 */           if (typeSer != null)
/*     */           {
/* 369 */             if (ser instanceof ContainerSerializer) {
/*     */ 
/*     */               
/* 372 */               ContainerSerializer containerSerializer1 = ((ContainerSerializer)ser).withValueTypeSerializer(typeSer);
/* 373 */               containerSerializer = containerSerializer1;
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 379 */       if (i < filteredCount) {
/* 380 */         BeanPropertyWriter w2 = this._filteredProps[i];
/* 381 */         if (w2 != null) {
/* 382 */           w2.assignSerializer((JsonSerializer)containerSerializer);
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */       } 
/*     */       
/* 389 */       prop.assignSerializer((JsonSerializer)containerSerializer);
/*     */       
/*     */       continue;
/*     */     } 
/* 393 */     for (i = 0; i < this._props.length; i++) {
/* 394 */       BeanPropertyWriter prop = this._props[i];
/* 395 */       if (prop instanceof AnyGetterWriter) {
/* 396 */         ((AnyGetterWriter)prop).resolve(provider);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<Object> findConvertingSerializer(SerializerProvider provider, BeanPropertyWriter prop) throws JsonMappingException {
/* 412 */     AnnotationIntrospector intr = provider.getAnnotationIntrospector();
/* 413 */     if (intr != null) {
/* 414 */       AnnotatedMember m = prop.getMember();
/* 415 */       if (m != null) {
/* 416 */         Object convDef = intr.findSerializationConverter((Annotated)m);
/* 417 */         if (convDef != null) {
/* 418 */           Converter<Object, Object> conv = provider.converterInstance((Annotated)prop.getMember(), convDef);
/* 419 */           JavaType delegateType = conv.getOutputType(provider.getTypeFactory());
/*     */ 
/*     */           
/* 422 */           JsonSerializer<?> ser = delegateType.isJavaLangObject() ? null : provider.findValueSerializer(delegateType, (BeanProperty)prop);
/* 423 */           return new StdDelegatingSerializer(conv, delegateType, ser);
/*     */         } 
/*     */       } 
/*     */     } 
/* 427 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> createContextual(SerializerProvider provider, BeanProperty property) throws JsonMappingException {
/* 436 */     AnnotationIntrospector intr = provider.getAnnotationIntrospector();
/*     */     
/* 438 */     AnnotatedMember accessor = (property == null || intr == null) ? null : property.getMember();
/* 439 */     SerializationConfig config = provider.getConfig();
/*     */ 
/*     */ 
/*     */     
/* 443 */     JsonFormat.Value format = findFormatOverrides(provider, property, this._handledType);
/* 444 */     JsonFormat.Shape shape = null;
/* 445 */     if (format != null && format.hasShape()) {
/* 446 */       shape = format.getShape();
/*     */       
/* 448 */       if (shape != JsonFormat.Shape.ANY && shape != this._serializationShape) {
/* 449 */         if (this._beanType.isEnumType()) {
/* 450 */           BeanDescription desc; JsonSerializer<?> ser; switch (shape) {
/*     */ 
/*     */             
/*     */             case STRING:
/*     */             case NUMBER:
/*     */             case NUMBER_INT:
/* 456 */               desc = config.introspectClassAnnotations(this._beanType);
/* 457 */               ser = EnumSerializer.construct(this._beanType.getRawClass(), provider
/* 458 */                   .getConfig(), desc, format);
/* 459 */               return provider.handlePrimaryContextualization(ser, property);
/*     */           } 
/*     */         
/* 462 */         } else if (shape == JsonFormat.Shape.NATURAL && (
/* 463 */           !this._beanType.isMapLikeType() || !Map.class.isAssignableFrom(this._handledType))) {
/*     */           
/* 465 */           if (Map.Entry.class.isAssignableFrom(this._handledType)) {
/* 466 */             JavaType mapEntryType = this._beanType.findSuperType(Map.Entry.class);
/*     */             
/* 468 */             JavaType kt = mapEntryType.containedTypeOrUnknown(0);
/* 469 */             JavaType vt = mapEntryType.containedTypeOrUnknown(1);
/*     */ 
/*     */ 
/*     */             
/* 473 */             MapEntrySerializer mapEntrySerializer = new MapEntrySerializer(this._beanType, kt, vt, false, null, property);
/*     */             
/* 475 */             return provider.handlePrimaryContextualization((JsonSerializer)mapEntrySerializer, property);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 481 */     ObjectIdWriter oiw = this._objectIdWriter;
/*     */ 
/*     */ 
/*     */     
/* 485 */     int idPropOrigIndex = 0;
/* 486 */     Set<String> ignoredProps = null;
/* 487 */     Set<String> includedProps = null;
/* 488 */     Object newFilterId = null;
/*     */ 
/*     */     
/* 491 */     if (accessor != null) {
/* 492 */       ignoredProps = intr.findPropertyIgnoralByName((MapperConfig)config, (Annotated)accessor).findIgnoredForSerialization();
/* 493 */       includedProps = intr.findPropertyInclusionByName((MapperConfig)config, (Annotated)accessor).getIncluded();
/* 494 */       ObjectIdInfo objectIdInfo = intr.findObjectIdInfo((Annotated)accessor);
/* 495 */       if (objectIdInfo == null) {
/*     */         
/* 497 */         if (oiw != null) {
/* 498 */           objectIdInfo = intr.findObjectReferenceInfo((Annotated)accessor, null);
/* 499 */           if (objectIdInfo != null) {
/* 500 */             oiw = this._objectIdWriter.withAlwaysAsId(objectIdInfo.getAlwaysAsId());
/*     */           
/*     */           }
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 508 */         objectIdInfo = intr.findObjectReferenceInfo((Annotated)accessor, objectIdInfo);
/* 509 */         Class<?> implClass = objectIdInfo.getGeneratorType();
/* 510 */         JavaType type = provider.constructType(implClass);
/* 511 */         JavaType idType = provider.getTypeFactory().findTypeParameters(type, ObjectIdGenerator.class)[0];
/*     */         
/* 513 */         if (implClass == ObjectIdGenerators.PropertyGenerator.class) {
/* 514 */           String propName = objectIdInfo.getPropertyName().getSimpleName();
/* 515 */           BeanPropertyWriter idProp = null;
/*     */           
/* 517 */           for (int i = 0, len = this._props.length;; i++) {
/* 518 */             if (i == len)
/* 519 */               provider.reportBadDefinition(this._beanType, String.format("Invalid Object Id definition for %s: cannot find property with name %s", new Object[] {
/*     */                       
/* 521 */                       ClassUtil.nameOf(handledType()), ClassUtil.name(propName)
/*     */                     })); 
/* 523 */             BeanPropertyWriter prop = this._props[i];
/* 524 */             if (propName.equals(prop.getName())) {
/* 525 */               idProp = prop;
/*     */ 
/*     */               
/* 528 */               idPropOrigIndex = i;
/*     */               break;
/*     */             } 
/*     */           } 
/* 532 */           idType = idProp.getType();
/* 533 */           PropertyBasedObjectIdGenerator propertyBasedObjectIdGenerator = new PropertyBasedObjectIdGenerator(objectIdInfo, idProp);
/* 534 */           oiw = ObjectIdWriter.construct(idType, (PropertyName)null, (ObjectIdGenerator)propertyBasedObjectIdGenerator, objectIdInfo.getAlwaysAsId());
/*     */         } else {
/* 536 */           ObjectIdGenerator<?> gen = provider.objectIdGeneratorInstance((Annotated)accessor, objectIdInfo);
/* 537 */           oiw = ObjectIdWriter.construct(idType, objectIdInfo.getPropertyName(), gen, objectIdInfo
/* 538 */               .getAlwaysAsId());
/*     */         } 
/*     */       } 
/*     */       
/* 542 */       Object filterId = intr.findFilterId((Annotated)accessor);
/*     */       
/* 544 */       if (filterId != null && !filterId.equals(this._propertyFilterId)) {
/* 545 */         newFilterId = filterId;
/*     */       }
/*     */     } 
/*     */     
/* 549 */     BeanSerializerBase contextual = this;
/*     */ 
/*     */     
/* 552 */     if (idPropOrigIndex > 0) {
/* 553 */       BeanPropertyWriter[] newFiltered, newProps = Arrays.<BeanPropertyWriter>copyOf(this._props, this._props.length);
/* 554 */       BeanPropertyWriter bpw = newProps[idPropOrigIndex];
/* 555 */       System.arraycopy(newProps, 0, newProps, 1, idPropOrigIndex);
/* 556 */       newProps[0] = bpw;
/*     */       
/* 558 */       if (this._filteredProps == null) {
/* 559 */         newFiltered = null;
/*     */       } else {
/* 561 */         newFiltered = Arrays.<BeanPropertyWriter>copyOf(this._filteredProps, this._filteredProps.length);
/* 562 */         bpw = newFiltered[idPropOrigIndex];
/* 563 */         System.arraycopy(newFiltered, 0, newFiltered, 1, idPropOrigIndex);
/* 564 */         newFiltered[0] = bpw;
/*     */       } 
/* 566 */       contextual = contextual.withProperties(newProps, newFiltered);
/*     */     } 
/*     */     
/* 569 */     if (oiw != null) {
/* 570 */       JsonSerializer<?> ser = provider.findValueSerializer(oiw.idType, property);
/* 571 */       oiw = oiw.withSerializer(ser);
/* 572 */       if (oiw != this._objectIdWriter) {
/* 573 */         contextual = contextual.withObjectIdWriter(oiw);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 578 */     if ((ignoredProps != null && !ignoredProps.isEmpty()) || includedProps != null)
/*     */     {
/* 580 */       contextual = contextual.withByNameInclusion(ignoredProps, includedProps);
/*     */     }
/* 582 */     if (newFilterId != null) {
/* 583 */       contextual = contextual.withFilterId(newFilterId);
/*     */     }
/*     */     
/* 586 */     if (shape == null) {
/* 587 */       shape = this._serializationShape;
/*     */     }
/*     */     
/* 590 */     if (shape == JsonFormat.Shape.ARRAY) {
/* 591 */       return contextual.asArraySerializer();
/*     */     }
/* 593 */     return contextual;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<PropertyWriter> properties() {
/* 604 */     return Arrays.asList((Object[])this._props).iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean usesObjectId() {
/* 615 */     return (this._objectIdWriter != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeWithType(Object bean, JsonGenerator gen, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/* 629 */     if (this._objectIdWriter != null) {
/*     */ 
/*     */ 
/*     */       
/* 633 */       _serializeWithObjectId(bean, gen, provider, typeSer);
/*     */       
/*     */       return;
/*     */     } 
/* 637 */     WritableTypeId typeIdDef = _typeIdDef(typeSer, bean, JsonToken.START_OBJECT);
/* 638 */     typeSer.writeTypePrefix(gen, typeIdDef);
/* 639 */     gen.assignCurrentValue(bean);
/* 640 */     if (this._propertyFilterId != null) {
/* 641 */       serializeFieldsFiltered(bean, gen, provider);
/*     */     } else {
/* 643 */       serializeFields(bean, gen, provider);
/*     */     } 
/* 645 */     typeSer.writeTypeSuffix(gen, typeIdDef);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void _serializeWithObjectId(Object bean, JsonGenerator gen, SerializerProvider provider, boolean startEndObject) throws IOException {
/* 651 */     ObjectIdWriter w = this._objectIdWriter;
/* 652 */     WritableObjectId objectId = provider.findObjectId(bean, w.generator);
/*     */     
/* 654 */     if (objectId.writeAsId(gen, provider, w)) {
/*     */       return;
/*     */     }
/*     */     
/* 658 */     Object id = objectId.generateId(bean);
/* 659 */     if (w.alwaysAsId) {
/* 660 */       w.serializer.serialize(id, gen, provider);
/*     */       return;
/*     */     } 
/* 663 */     if (startEndObject) {
/* 664 */       gen.writeStartObject(bean);
/*     */     }
/* 666 */     objectId.writeAsField(gen, provider, w);
/* 667 */     if (this._propertyFilterId != null) {
/* 668 */       serializeFieldsFiltered(bean, gen, provider);
/*     */     } else {
/* 670 */       serializeFields(bean, gen, provider);
/*     */     } 
/* 672 */     if (startEndObject) {
/* 673 */       gen.writeEndObject();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void _serializeWithObjectId(Object bean, JsonGenerator gen, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/* 680 */     ObjectIdWriter w = this._objectIdWriter;
/* 681 */     WritableObjectId objectId = provider.findObjectId(bean, w.generator);
/*     */     
/* 683 */     if (objectId.writeAsId(gen, provider, w)) {
/*     */       return;
/*     */     }
/*     */     
/* 687 */     Object id = objectId.generateId(bean);
/* 688 */     if (w.alwaysAsId) {
/* 689 */       w.serializer.serialize(id, gen, provider);
/*     */       return;
/*     */     } 
/* 692 */     _serializeObjectId(bean, gen, provider, typeSer, objectId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _serializeObjectId(Object bean, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer, WritableObjectId objectId) throws IOException {
/* 699 */     ObjectIdWriter w = this._objectIdWriter;
/* 700 */     WritableTypeId typeIdDef = _typeIdDef(typeSer, bean, JsonToken.START_OBJECT);
/*     */     
/* 702 */     typeSer.writeTypePrefix(g, typeIdDef);
/*     */     
/* 704 */     g.assignCurrentValue(bean);
/* 705 */     objectId.writeAsField(g, provider, w);
/* 706 */     if (this._propertyFilterId != null) {
/* 707 */       serializeFieldsFiltered(bean, g, provider);
/*     */     } else {
/* 709 */       serializeFields(bean, g, provider);
/*     */     } 
/* 711 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final WritableTypeId _typeIdDef(TypeSerializer typeSer, Object bean, JsonToken valueShape) {
/* 719 */     if (this._typeId == null) {
/* 720 */       return typeSer.typeId(bean, valueShape);
/*     */     }
/* 722 */     Object typeId = this._typeId.getValue(bean);
/* 723 */     if (typeId == null)
/*     */     {
/* 725 */       typeId = "";
/*     */     }
/* 727 */     return typeSer.typeId(bean, valueShape, typeId);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected final String _customTypeId(Object bean) {
/* 733 */     Object typeId = this._typeId.getValue(bean);
/* 734 */     if (typeId == null) {
/* 735 */       return "";
/*     */     }
/* 737 */     return (typeId instanceof String) ? (String)typeId : typeId.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void serializeFields(Object bean, JsonGenerator gen, SerializerProvider provider) throws IOException {
/*     */     BeanPropertyWriter[] props;
/* 750 */     if (this._filteredProps != null && provider.getActiveView() != null) {
/* 751 */       props = this._filteredProps;
/*     */     } else {
/* 753 */       props = this._props;
/*     */     } 
/* 755 */     int i = 0;
/*     */     try {
/* 757 */       for (int len = props.length; i < len; i++) {
/* 758 */         BeanPropertyWriter prop = props[i];
/* 759 */         if (prop != null) {
/* 760 */           prop.serializeAsField(bean, gen, provider);
/*     */         }
/*     */       } 
/* 763 */     } catch (Exception e) {
/* 764 */       String name = (i == props.length) ? "[anySetter]" : props[i].getName();
/* 765 */       wrapAndThrow(provider, e, bean, name);
/* 766 */     } catch (StackOverflowError e) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 772 */       JsonMappingException jsonMappingException = new JsonMappingException((Closeable)gen, "Infinite recursion (StackOverflowError)", e);
/*     */       
/* 774 */       String name = (i == props.length) ? "[anySetter]" : props[i].getName();
/* 775 */       jsonMappingException.prependPath(bean, name);
/* 776 */       throw jsonMappingException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void serializeFieldsFiltered(Object bean, JsonGenerator gen, SerializerProvider provider) throws IOException {
/*     */     BeanPropertyWriter[] props;
/* 792 */     if (this._filteredProps != null && provider.getActiveView() != null) {
/* 793 */       props = this._filteredProps;
/*     */     } else {
/* 795 */       props = this._props;
/*     */     } 
/* 797 */     PropertyFilter filter = findPropertyFilter(provider, this._propertyFilterId, bean);
/*     */     
/* 799 */     if (filter == null) {
/* 800 */       serializeFields(bean, gen, provider);
/*     */       return;
/*     */     } 
/* 803 */     int i = 0;
/*     */     try {
/* 805 */       for (int len = props.length; i < len; i++) {
/* 806 */         BeanPropertyWriter prop = props[i];
/* 807 */         if (prop != null) {
/* 808 */           filter.serializeAsField(bean, gen, provider, (PropertyWriter)prop);
/*     */         }
/*     */       } 
/* 811 */     } catch (Exception e) {
/* 812 */       String name = (i == props.length) ? "[anySetter]" : props[i].getName();
/* 813 */       wrapAndThrow(provider, e, bean, name);
/* 814 */     } catch (StackOverflowError e) {
/*     */ 
/*     */       
/* 817 */       JsonMappingException jsonMappingException = new JsonMappingException((Closeable)gen, "Infinite recursion (StackOverflowError)", e);
/* 818 */       String name = (i == props.length) ? "[anySetter]" : props[i].getName();
/* 819 */       jsonMappingException.prependPath(bean, name);
/* 820 */       throw jsonMappingException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint) throws JsonMappingException {
/*     */     PropertyFilter filter;
/* 829 */     ObjectNode o = createSchemaNode("object", true);
/*     */ 
/*     */ 
/*     */     
/* 833 */     JsonSerializableSchema ann = (JsonSerializableSchema)this._handledType.getAnnotation(JsonSerializableSchema.class);
/* 834 */     if (ann != null) {
/* 835 */       String id = ann.id();
/* 836 */       if (id != null && !id.isEmpty()) {
/* 837 */         o.put("id", id);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 843 */     ObjectNode propertiesNode = o.objectNode();
/*     */     
/* 845 */     if (this._propertyFilterId != null) {
/* 846 */       filter = findPropertyFilter(provider, this._propertyFilterId, null);
/*     */     } else {
/* 848 */       filter = null;
/*     */     } 
/*     */     
/* 851 */     for (int i = 0; i < this._props.length; i++) {
/* 852 */       BeanPropertyWriter prop = this._props[i];
/* 853 */       if (filter == null) {
/* 854 */         prop.depositSchemaProperty(propertiesNode, provider);
/*     */       } else {
/* 856 */         filter.depositSchemaProperty((PropertyWriter)prop, propertiesNode, provider);
/*     */       } 
/*     */     } 
/*     */     
/* 860 */     o.set("properties", (JsonNode)propertiesNode);
/* 861 */     return (JsonNode)o;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 869 */     if (visitor == null) {
/*     */       return;
/*     */     }
/* 872 */     JsonObjectFormatVisitor objectVisitor = visitor.expectObjectFormat(typeHint);
/* 873 */     if (objectVisitor == null) {
/*     */       return;
/*     */     }
/* 876 */     SerializerProvider provider = visitor.getProvider();
/* 877 */     if (this._propertyFilterId != null) {
/* 878 */       PropertyFilter filter = findPropertyFilter(visitor.getProvider(), this._propertyFilterId, null);
/*     */       
/* 880 */       for (int i = 0, end = this._props.length; i < end; i++) {
/* 881 */         filter.depositSchemaProperty((PropertyWriter)this._props[i], objectVisitor, provider);
/*     */       }
/*     */     } else {
/*     */       BeanPropertyWriter[] props;
/* 885 */       Class<?> view = (this._filteredProps == null || provider == null) ? null : provider.getActiveView();
/*     */       
/* 887 */       if (view != null) {
/* 888 */         props = this._filteredProps;
/*     */       } else {
/* 890 */         props = this._props;
/*     */       } 
/*     */       
/* 893 */       for (int i = 0, end = props.length; i < end; i++) {
/* 894 */         BeanPropertyWriter prop = props[i];
/* 895 */         if (prop != null)
/* 896 */           prop.depositSchemaProperty(objectVisitor, provider); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract BeanSerializerBase withObjectIdWriter(ObjectIdWriter paramObjectIdWriter);
/*     */   
/*     */   protected abstract BeanSerializerBase withByNameInclusion(Set<String> paramSet1, Set<String> paramSet2);
/*     */   
/*     */   protected abstract BeanSerializerBase asArraySerializer();
/*     */   
/*     */   public abstract BeanSerializerBase withFilterId(Object paramObject);
/*     */   
/*     */   protected abstract BeanSerializerBase withProperties(BeanPropertyWriter[] paramArrayOfBeanPropertyWriter1, BeanPropertyWriter[] paramArrayOfBeanPropertyWriter2);
/*     */   
/*     */   public abstract void serialize(Object paramObject, JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider) throws IOException;
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\BeanSerializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */