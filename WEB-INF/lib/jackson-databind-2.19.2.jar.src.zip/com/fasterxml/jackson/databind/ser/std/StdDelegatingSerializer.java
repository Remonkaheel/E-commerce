/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitable;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonschema.SchemaAware;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.ResolvableSerializer;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StdDelegatingSerializer
/*     */   extends StdSerializer<Object>
/*     */   implements ContextualSerializer, ResolvableSerializer, JsonFormatVisitable
/*     */ {
/*     */   protected final Converter<Object, ?> _converter;
/*     */   protected final JavaType _delegateType;
/*     */   protected final JsonSerializer<Object> _delegateSerializer;
/*     */   
/*     */   public StdDelegatingSerializer(Converter<?, ?> converter) {
/*  54 */     super(Object.class);
/*  55 */     this._converter = (Converter)converter;
/*  56 */     this._delegateType = null;
/*  57 */     this._delegateSerializer = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> StdDelegatingSerializer(Class<T> cls, Converter<T, ?> converter) {
/*  63 */     super(cls, false);
/*  64 */     this._converter = (Converter)converter;
/*  65 */     this._delegateType = null;
/*  66 */     this._delegateSerializer = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StdDelegatingSerializer(Converter<Object, ?> converter, JavaType delegateType, JsonSerializer<?> delegateSerializer) {
/*  73 */     super(delegateType);
/*  74 */     this._converter = converter;
/*  75 */     this._delegateType = delegateType;
/*  76 */     this._delegateSerializer = (JsonSerializer)delegateSerializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StdDelegatingSerializer withDelegate(Converter<Object, ?> converter, JavaType delegateType, JsonSerializer<?> delegateSerializer) {
/*  86 */     ClassUtil.verifyMustOverride(StdDelegatingSerializer.class, this, "withDelegate");
/*  87 */     return new StdDelegatingSerializer(converter, delegateType, delegateSerializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(SerializerProvider provider) throws JsonMappingException {
/*  99 */     if (this._delegateSerializer != null && this._delegateSerializer instanceof ResolvableSerializer)
/*     */     {
/* 101 */       ((ResolvableSerializer)this._delegateSerializer).resolve(provider);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> createContextual(SerializerProvider provider, BeanProperty property) throws JsonMappingException {
/* 109 */     JsonSerializer<?> delSer = this._delegateSerializer;
/* 110 */     JavaType delegateType = this._delegateType;
/*     */     
/* 112 */     if (delSer == null) {
/*     */       
/* 114 */       if (delegateType == null) {
/* 115 */         delegateType = this._converter.getOutputType(provider.getTypeFactory());
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 120 */       if (!delegateType.isJavaLangObject()) {
/* 121 */         delSer = provider.findValueSerializer(delegateType);
/*     */       }
/*     */     } 
/* 124 */     if (delSer instanceof ContextualSerializer) {
/* 125 */       delSer = provider.handleSecondaryContextualization(delSer, property);
/*     */     }
/* 127 */     if (delSer == this._delegateSerializer && delegateType == this._delegateType) {
/* 128 */       return this;
/*     */     }
/* 130 */     return withDelegate(this._converter, delegateType, delSer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Converter<Object, ?> getConverter() {
/* 140 */     return this._converter;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> getDelegatee() {
/* 145 */     return this._delegateSerializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(Object value, JsonGenerator gen, SerializerProvider ctxt) throws IOException {
/* 157 */     Object delegateValue = convertValue(ctxt, value);
/*     */     
/* 159 */     if (delegateValue == null) {
/* 160 */       ctxt.defaultSerializeNull(gen);
/*     */       
/*     */       return;
/*     */     } 
/* 164 */     JsonSerializer<Object> ser = this._delegateSerializer;
/* 165 */     if (ser == null) {
/* 166 */       ser = _findSerializer(delegateValue, ctxt);
/*     */     }
/* 168 */     ser.serialize(delegateValue, gen, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeWithType(Object value, JsonGenerator gen, SerializerProvider ctxt, TypeSerializer typeSer) throws IOException {
/* 177 */     Object delegateValue = convertValue(ctxt, value);
/*     */     
/* 179 */     if (delegateValue == null) {
/* 180 */       ctxt.defaultSerializeNull(gen);
/*     */       return;
/*     */     } 
/* 183 */     JsonSerializer<Object> ser = this._delegateSerializer;
/* 184 */     if (ser == null) {
/* 185 */       ser = _findSerializer(delegateValue, ctxt);
/*     */     }
/* 187 */     ser.serializeWithType(delegateValue, gen, ctxt, typeSer);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty(SerializerProvider ctxt, Object value) {
/* 193 */     Object delegateValue = convertValue(ctxt, value);
/* 194 */     if (delegateValue == null) {
/* 195 */       return true;
/*     */     }
/* 197 */     if (this._delegateSerializer == null) {
/* 198 */       return (value == null);
/*     */     }
/* 200 */     return this._delegateSerializer.isEmpty(ctxt, delegateValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint) throws JsonMappingException {
/* 217 */     if (this._delegateSerializer instanceof SchemaAware) {
/* 218 */       return ((SchemaAware)this._delegateSerializer)
/* 219 */         .getSchema(provider, typeHint);
/*     */     }
/* 221 */     return super.getSchema(provider, typeHint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonNode getSchema(SerializerProvider provider, Type typeHint, boolean isOptional) throws JsonMappingException {
/* 232 */     if (this._delegateSerializer instanceof SchemaAware) {
/* 233 */       return ((SchemaAware)this._delegateSerializer)
/* 234 */         .getSchema(provider, typeHint, isOptional);
/*     */     }
/* 236 */     return super.getSchema(provider, typeHint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 247 */     if (this._delegateSerializer != null) {
/* 248 */       this._delegateSerializer.acceptJsonFormatVisitor(visitor, typeHint);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected Object convertValue(Object value) {
/* 273 */     return this._converter.convert(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object convertValue(SerializerProvider ctxt, Object value) {
/* 290 */     return this._converter.convert(ctxt, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<Object> _findSerializer(Object value, SerializerProvider serializers) throws JsonMappingException {
/* 306 */     JsonSerializer<Object> ser = serializers.findValueSerializer(value.getClass());
/*     */     
/* 308 */     if (ser instanceof ContextualSerializer)
/*     */     {
/* 310 */       ser = ((ContextualSerializer)ser).createContextual(serializers, null);
/*     */     }
/* 312 */     return ser;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\StdDelegatingSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */