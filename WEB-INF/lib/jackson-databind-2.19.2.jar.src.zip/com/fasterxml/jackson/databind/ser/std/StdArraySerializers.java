/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatTypes;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import com.fasterxml.jackson.databind.ser.ContainerSerializer;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class StdArraySerializers {
/*  25 */   protected static final HashMap<String, JsonSerializer<?>> _arraySerializers = new HashMap<>();
/*     */ 
/*     */   
/*     */   static {
/*  29 */     _arraySerializers.put(boolean[].class.getName(), new BooleanArraySerializer());
/*  30 */     _arraySerializers.put(byte[].class.getName(), new ByteArraySerializer());
/*  31 */     _arraySerializers.put(char[].class.getName(), new CharArraySerializer());
/*  32 */     _arraySerializers.put(short[].class.getName(), new ShortArraySerializer());
/*  33 */     _arraySerializers.put(int[].class.getName(), new IntArraySerializer());
/*  34 */     _arraySerializers.put(long[].class.getName(), new LongArraySerializer());
/*  35 */     _arraySerializers.put(float[].class.getName(), new FloatArraySerializer());
/*  36 */     _arraySerializers.put(double[].class.getName(), new DoubleArraySerializer());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonSerializer<?> findStandardImpl(Class<?> cls) {
/*  46 */     return _arraySerializers.get(cls.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static JavaType simpleElementType(Class<?> elemClass) {
/*  52 */     return TypeFactory.defaultInstance().uncheckedSimpleType(elemClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static abstract class TypedPrimitiveArraySerializer<T>
/*     */     extends ArraySerializerBase<T>
/*     */   {
/*     */     protected TypedPrimitiveArraySerializer(Class<T> cls) {
/*  69 */       super(cls);
/*     */     }
/*     */ 
/*     */     
/*     */     protected TypedPrimitiveArraySerializer(TypedPrimitiveArraySerializer<T> src, BeanProperty prop, Boolean unwrapSingle) {
/*  74 */       super(src, prop, unwrapSingle);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final ContainerSerializer<?> _withValueTypeSerializer(TypeSerializer vts) {
/*  82 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JacksonStdImpl
/*     */   public static class BooleanArraySerializer
/*     */     extends ArraySerializerBase<boolean[]>
/*     */   {
/*  97 */     private static final JavaType VALUE_TYPE = StdArraySerializers.simpleElementType(boolean.class);
/*     */     public BooleanArraySerializer() {
/*  99 */       super((Class)boolean[].class);
/*     */     }
/*     */     
/*     */     protected BooleanArraySerializer(BooleanArraySerializer src, BeanProperty prop, Boolean unwrapSingle) {
/* 103 */       super(src, prop, unwrapSingle);
/*     */     }
/*     */ 
/*     */     
/*     */     public JsonSerializer<?> _withResolved(BeanProperty prop, Boolean unwrapSingle) {
/* 108 */       return (JsonSerializer<?>)new BooleanArraySerializer(this, prop, unwrapSingle);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ContainerSerializer<?> _withValueTypeSerializer(TypeSerializer vts) {
/* 117 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public JavaType getContentType() {
/* 122 */       return VALUE_TYPE;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonSerializer<?> getContentSerializer() {
/* 128 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty(SerializerProvider prov, boolean[] value) {
/* 133 */       return (value.length == 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasSingleElement(boolean[] value) {
/* 138 */       return (value.length == 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final void serialize(boolean[] value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 144 */       int len = value.length;
/* 145 */       if (len == 1 && _shouldUnwrapSingle(provider)) {
/* 146 */         serializeContents(value, g, provider);
/*     */         return;
/*     */       } 
/* 149 */       g.writeStartArray(value, len);
/* 150 */       serializeContents(value, g, provider);
/* 151 */       g.writeEndArray();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void serializeContents(boolean[] value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 158 */       for (int i = 0, len = value.length; i < len; i++) {
/* 159 */         g.writeBoolean(value[i]);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint) {
/* 170 */       ObjectNode o = createSchemaNode("array", true);
/* 171 */       o.set("items", (JsonNode)createSchemaNode("boolean"));
/* 172 */       return (JsonNode)o;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 179 */       visitArrayFormat(visitor, typeHint, JsonFormatTypes.BOOLEAN);
/*     */     }
/*     */   }
/*     */   
/*     */   @JacksonStdImpl
/*     */   public static class ShortArraySerializer
/*     */     extends TypedPrimitiveArraySerializer<short[]>
/*     */   {
/* 187 */     private static final JavaType VALUE_TYPE = StdArraySerializers.simpleElementType(short.class);
/*     */     public ShortArraySerializer() {
/* 189 */       super((Class)short[].class);
/*     */     }
/*     */     public ShortArraySerializer(ShortArraySerializer src, BeanProperty prop, Boolean unwrapSingle) {
/* 192 */       super(src, prop, unwrapSingle);
/*     */     }
/*     */ 
/*     */     
/*     */     public JsonSerializer<?> _withResolved(BeanProperty prop, Boolean unwrapSingle) {
/* 197 */       return (JsonSerializer<?>)new ShortArraySerializer(this, prop, unwrapSingle);
/*     */     }
/*     */ 
/*     */     
/*     */     public JavaType getContentType() {
/* 202 */       return VALUE_TYPE;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonSerializer<?> getContentSerializer() {
/* 208 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty(SerializerProvider prov, short[] value) {
/* 213 */       return (value.length == 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasSingleElement(short[] value) {
/* 218 */       return (value.length == 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final void serialize(short[] value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 224 */       int len = value.length;
/* 225 */       if (len == 1 && _shouldUnwrapSingle(provider)) {
/* 226 */         serializeContents(value, g, provider);
/*     */         return;
/*     */       } 
/* 229 */       g.writeStartArray(value, len);
/* 230 */       serializeContents(value, g, provider);
/* 231 */       g.writeEndArray();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void serializeContents(short[] value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 238 */       for (int i = 0, len = value.length; i < len; i++) {
/* 239 */         g.writeNumber(value[i]);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint) {
/* 251 */       ObjectNode o = createSchemaNode("array", true);
/* 252 */       return o.set("items", (JsonNode)createSchemaNode("integer"));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 259 */       visitArrayFormat(visitor, typeHint, JsonFormatTypes.INTEGER);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JacksonStdImpl
/*     */   public static class CharArraySerializer
/*     */     extends StdSerializer<char[]>
/*     */   {
/*     */     public CharArraySerializer() {
/* 273 */       super((Class)char[].class);
/*     */     }
/*     */     
/*     */     public boolean isEmpty(SerializerProvider prov, char[] value) {
/* 277 */       return (value.length == 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void serialize(char[] value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 285 */       if (provider.isEnabled(SerializationFeature.WRITE_CHAR_ARRAYS_AS_JSON_ARRAYS)) {
/* 286 */         g.writeStartArray(value, value.length);
/* 287 */         _writeArrayContents(g, value);
/* 288 */         g.writeEndArray();
/*     */       } else {
/* 290 */         g.writeString(value, 0, value.length);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void serializeWithType(char[] value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/*     */       WritableTypeId typeIdDef;
/* 300 */       boolean asArray = provider.isEnabled(SerializationFeature.WRITE_CHAR_ARRAYS_AS_JSON_ARRAYS);
/*     */       
/* 302 */       if (asArray) {
/* 303 */         typeIdDef = typeSer.writeTypePrefix(g, typeSer
/* 304 */             .typeId(value, JsonToken.START_ARRAY));
/* 305 */         _writeArrayContents(g, value);
/*     */       } else {
/* 307 */         typeIdDef = typeSer.writeTypePrefix(g, typeSer
/* 308 */             .typeId(value, JsonToken.VALUE_STRING));
/* 309 */         g.writeString(value, 0, value.length);
/*     */       } 
/* 311 */       typeSer.writeTypeSuffix(g, typeIdDef);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private final void _writeArrayContents(JsonGenerator g, char[] value) throws IOException {
/* 317 */       for (int i = 0, len = value.length; i < len; i++) {
/* 318 */         g.writeString(value, i, 1);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint) {
/* 329 */       ObjectNode o = createSchemaNode("array", true);
/* 330 */       ObjectNode itemSchema = createSchemaNode("string");
/* 331 */       itemSchema.put("type", "string");
/* 332 */       return o.set("items", (JsonNode)itemSchema);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 339 */       visitArrayFormat(visitor, typeHint, JsonFormatTypes.STRING);
/*     */     }
/*     */   }
/*     */   
/*     */   @JacksonStdImpl
/*     */   public static class IntArraySerializer
/*     */     extends ArraySerializerBase<int[]>
/*     */   {
/* 347 */     private static final JavaType VALUE_TYPE = StdArraySerializers.simpleElementType(int.class);
/*     */     public IntArraySerializer() {
/* 349 */       super((Class)int[].class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected IntArraySerializer(IntArraySerializer src, BeanProperty prop, Boolean unwrapSingle) {
/* 356 */       super(src, prop, unwrapSingle);
/*     */     }
/*     */ 
/*     */     
/*     */     public JsonSerializer<?> _withResolved(BeanProperty prop, Boolean unwrapSingle) {
/* 361 */       return (JsonSerializer<?>)new IntArraySerializer(this, prop, unwrapSingle);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ContainerSerializer<?> _withValueTypeSerializer(TypeSerializer vts) {
/* 370 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public JavaType getContentType() {
/* 375 */       return VALUE_TYPE;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonSerializer<?> getContentSerializer() {
/* 381 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty(SerializerProvider prov, int[] value) {
/* 386 */       return (value.length == 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasSingleElement(int[] value) {
/* 391 */       return (value.length == 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final void serialize(int[] value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 397 */       int len = value.length;
/* 398 */       if (len == 1 && _shouldUnwrapSingle(provider)) {
/* 399 */         serializeContents(value, g, provider);
/*     */         
/*     */         return;
/*     */       } 
/* 403 */       g.writeArray(value, 0, value.length);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void serializeContents(int[] value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 410 */       for (int i = 0, len = value.length; i < len; i++) {
/* 411 */         g.writeNumber(value[i]);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint) {
/* 421 */       return createSchemaNode("array", true).set("items", (JsonNode)createSchemaNode("integer"));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 427 */       visitArrayFormat(visitor, typeHint, JsonFormatTypes.INTEGER);
/*     */     }
/*     */   }
/*     */   
/*     */   @JacksonStdImpl
/*     */   public static class LongArraySerializer
/*     */     extends TypedPrimitiveArraySerializer<long[]>
/*     */   {
/* 435 */     private static final JavaType VALUE_TYPE = StdArraySerializers.simpleElementType(long.class);
/*     */     public LongArraySerializer() {
/* 437 */       super((Class)long[].class);
/*     */     }
/*     */     public LongArraySerializer(LongArraySerializer src, BeanProperty prop, Boolean unwrapSingle) {
/* 440 */       super(src, prop, unwrapSingle);
/*     */     }
/*     */ 
/*     */     
/*     */     public JsonSerializer<?> _withResolved(BeanProperty prop, Boolean unwrapSingle) {
/* 445 */       return (JsonSerializer<?>)new LongArraySerializer(this, prop, unwrapSingle);
/*     */     }
/*     */ 
/*     */     
/*     */     public JavaType getContentType() {
/* 450 */       return VALUE_TYPE;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonSerializer<?> getContentSerializer() {
/* 456 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty(SerializerProvider prov, long[] value) {
/* 461 */       return (value.length == 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasSingleElement(long[] value) {
/* 466 */       return (value.length == 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final void serialize(long[] value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 472 */       int len = value.length;
/* 473 */       if (len == 1 && _shouldUnwrapSingle(provider)) {
/* 474 */         serializeContents(value, g, provider);
/*     */         
/*     */         return;
/*     */       } 
/* 478 */       g.writeArray(value, 0, value.length);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void serializeContents(long[] value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 485 */       for (int i = 0, len = value.length; i < len; i++) {
/* 486 */         g.writeNumber(value[i]);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint) {
/* 497 */       return createSchemaNode("array", true)
/* 498 */         .set("items", (JsonNode)createSchemaNode("number", true));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 505 */       visitArrayFormat(visitor, typeHint, JsonFormatTypes.NUMBER);
/*     */     }
/*     */   }
/*     */   
/*     */   @JacksonStdImpl
/*     */   public static class FloatArraySerializer
/*     */     extends TypedPrimitiveArraySerializer<float[]>
/*     */   {
/* 513 */     private static final JavaType VALUE_TYPE = StdArraySerializers.simpleElementType(float.class);
/*     */     
/*     */     public FloatArraySerializer() {
/* 516 */       super((Class)float[].class);
/*     */     }
/*     */     
/*     */     public FloatArraySerializer(FloatArraySerializer src, BeanProperty prop, Boolean unwrapSingle) {
/* 520 */       super(src, prop, unwrapSingle);
/*     */     }
/*     */ 
/*     */     
/*     */     public JsonSerializer<?> _withResolved(BeanProperty prop, Boolean unwrapSingle) {
/* 525 */       return (JsonSerializer<?>)new FloatArraySerializer(this, prop, unwrapSingle);
/*     */     }
/*     */ 
/*     */     
/*     */     public JavaType getContentType() {
/* 530 */       return VALUE_TYPE;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonSerializer<?> getContentSerializer() {
/* 536 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty(SerializerProvider prov, float[] value) {
/* 541 */       return (value.length == 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasSingleElement(float[] value) {
/* 546 */       return (value.length == 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final void serialize(float[] value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 552 */       int len = value.length;
/* 553 */       if (len == 1 && _shouldUnwrapSingle(provider)) {
/* 554 */         serializeContents(value, g, provider);
/*     */         return;
/*     */       } 
/* 557 */       g.writeStartArray(value, len);
/* 558 */       serializeContents(value, g, provider);
/* 559 */       g.writeEndArray();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void serializeContents(float[] value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 566 */       for (int i = 0, len = value.length; i < len; i++) {
/* 567 */         g.writeNumber(value[i]);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint) {
/* 577 */       return createSchemaNode("array", true).set("items", (JsonNode)createSchemaNode("number"));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 583 */       visitArrayFormat(visitor, typeHint, JsonFormatTypes.NUMBER);
/*     */     }
/*     */   }
/*     */   
/*     */   @JacksonStdImpl
/*     */   public static class DoubleArraySerializer
/*     */     extends ArraySerializerBase<double[]>
/*     */   {
/* 591 */     private static final JavaType VALUE_TYPE = StdArraySerializers.simpleElementType(double.class);
/*     */     public DoubleArraySerializer() {
/* 593 */       super((Class)double[].class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected DoubleArraySerializer(DoubleArraySerializer src, BeanProperty prop, Boolean unwrapSingle) {
/* 600 */       super(src, prop, unwrapSingle);
/*     */     }
/*     */ 
/*     */     
/*     */     public JsonSerializer<?> _withResolved(BeanProperty prop, Boolean unwrapSingle) {
/* 605 */       return (JsonSerializer<?>)new DoubleArraySerializer(this, prop, unwrapSingle);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ContainerSerializer<?> _withValueTypeSerializer(TypeSerializer vts) {
/* 614 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public JavaType getContentType() {
/* 619 */       return VALUE_TYPE;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonSerializer<?> getContentSerializer() {
/* 625 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty(SerializerProvider prov, double[] value) {
/* 630 */       return (value.length == 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasSingleElement(double[] value) {
/* 635 */       return (value.length == 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final void serialize(double[] value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 641 */       int len = value.length;
/* 642 */       if (len == 1 && _shouldUnwrapSingle(provider)) {
/* 643 */         serializeContents(value, g, provider);
/*     */         
/*     */         return;
/*     */       } 
/* 647 */       g.writeArray(value, 0, value.length);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void serializeContents(double[] value, JsonGenerator g, SerializerProvider provider) throws IOException {
/* 653 */       for (int i = 0, len = value.length; i < len; i++) {
/* 654 */         g.writeNumber(value[i]);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public JsonNode getSchema(SerializerProvider provider, Type typeHint) {
/* 664 */       return createSchemaNode("array", true).set("items", (JsonNode)createSchemaNode("number"));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 671 */       visitArrayFormat(visitor, typeHint, JsonFormatTypes.NUMBER);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\StdArraySerializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */