/*     */ package com.fasterxml.jackson.databind.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.cfg.CacheProvider;
/*     */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsonschema.JsonSchema;
/*     */ import com.fasterxml.jackson.databind.jsonschema.SchemaAware;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import com.fasterxml.jackson.databind.ser.impl.WritableObjectId;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DefaultSerializerProvider
/*     */   extends SerializerProvider
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected transient Map<Object, WritableObjectId> _seenObjectIds;
/*     */   protected transient ArrayList<ObjectIdGenerator<?>> _objectIdGenerators;
/*     */   protected transient JsonGenerator _generator;
/*     */   
/*     */   protected DefaultSerializerProvider() {}
/*     */   
/*     */   protected DefaultSerializerProvider(SerializerProvider src, SerializationConfig config, SerializerFactory f) {
/*  71 */     super(src, config, f);
/*     */   }
/*     */   
/*     */   protected DefaultSerializerProvider(DefaultSerializerProvider src) {
/*  75 */     super(src);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DefaultSerializerProvider(DefaultSerializerProvider src, CacheProvider cp) {
/*  83 */     super(src, new SerializerCache(cp
/*  84 */           .forSerializerCache(src._config)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract DefaultSerializerProvider createInstance(SerializationConfig paramSerializationConfig, SerializerFactory paramSerializerFactory);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultSerializerProvider copy() {
/* 104 */     throw new IllegalStateException("DefaultSerializerProvider sub-class not overriding copy()");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> serializerInstance(Annotated annotated, Object serDef) throws JsonMappingException {
/*     */     JsonSerializer<?> ser;
/* 117 */     if (serDef == null) {
/* 118 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 122 */     if (serDef instanceof JsonSerializer) {
/* 123 */       ser = (JsonSerializer)serDef;
/*     */     }
/*     */     else {
/*     */       
/* 127 */       if (!(serDef instanceof Class)) {
/* 128 */         reportBadDefinition(annotated.getType(), "AnnotationIntrospector returned serializer definition of type " + serDef
/*     */             
/* 130 */             .getClass().getName() + "; expected type JsonSerializer or Class<JsonSerializer> instead");
/*     */       }
/* 132 */       Class<?> serClass = (Class)serDef;
/*     */       
/* 134 */       if (serClass == JsonSerializer.None.class || ClassUtil.isBogusClass(serClass)) {
/* 135 */         return null;
/*     */       }
/* 137 */       if (!JsonSerializer.class.isAssignableFrom(serClass)) {
/* 138 */         reportBadDefinition(annotated.getType(), "AnnotationIntrospector returned Class " + serClass
/*     */             
/* 140 */             .getName() + "; expected Class<JsonSerializer>");
/*     */       }
/* 142 */       HandlerInstantiator hi = this._config.getHandlerInstantiator();
/* 143 */       ser = (hi == null) ? null : hi.serializerInstance(this._config, annotated, serClass);
/* 144 */       if (ser == null) {
/* 145 */         ser = (JsonSerializer)ClassUtil.createInstance(serClass, this._config
/* 146 */             .canOverrideAccessModifiers());
/*     */       }
/*     */     } 
/* 149 */     return _handleResolvable(ser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object includeFilterInstance(BeanPropertyDefinition forProperty, Class<?> filterClass) {
/* 156 */     if (filterClass == null) {
/* 157 */       return null;
/*     */     }
/* 159 */     HandlerInstantiator hi = this._config.getHandlerInstantiator();
/* 160 */     Object filter = (hi == null) ? null : hi.includeFilterInstance(this._config, forProperty, filterClass);
/* 161 */     if (filter == null) {
/* 162 */       filter = ClassUtil.createInstance(filterClass, this._config
/* 163 */           .canOverrideAccessModifiers());
/*     */     }
/* 165 */     return filter;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean includeFilterSuppressNulls(Object filter) throws JsonMappingException {
/* 171 */     if (filter == null) {
/* 172 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 177 */       return filter.equals((Object)null);
/* 178 */     } catch (Exception e) {
/* 179 */       String msg = String.format("Problem determining whether filter of type '%s' should filter out `null` values: (%s) %s", new Object[] { filter
/*     */             
/* 181 */             .getClass().getName(), e.getClass().getName(), ClassUtil.exceptionMessage(e) });
/* 182 */       reportBadDefinition(filter.getClass(), msg, e);
/* 183 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract DefaultSerializerProvider withCaches(CacheProvider paramCacheProvider);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableObjectId findObjectId(Object forPojo, ObjectIdGenerator<?> generatorType) {
/* 209 */     if (this._seenObjectIds == null) {
/* 210 */       this._seenObjectIds = _createObjectIdMap();
/*     */     } else {
/* 212 */       WritableObjectId writableObjectId = this._seenObjectIds.get(forPojo);
/* 213 */       if (writableObjectId != null) {
/* 214 */         return writableObjectId;
/*     */       }
/*     */     } 
/*     */     
/* 218 */     ObjectIdGenerator<?> generator = null;
/*     */     
/* 220 */     if (this._objectIdGenerators == null) {
/* 221 */       this._objectIdGenerators = new ArrayList<>(8);
/*     */     } else {
/* 223 */       for (int i = 0, len = this._objectIdGenerators.size(); i < len; i++) {
/* 224 */         ObjectIdGenerator<?> gen = this._objectIdGenerators.get(i);
/* 225 */         if (gen.canUseFor(generatorType)) {
/* 226 */           generator = gen;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 231 */     if (generator == null) {
/* 232 */       generator = generatorType.newForSerialization(this);
/* 233 */       this._objectIdGenerators.add(generator);
/*     */     } 
/* 235 */     WritableObjectId oid = new WritableObjectId(generator);
/* 236 */     this._seenObjectIds.put(forPojo, oid);
/* 237 */     return oid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<Object, WritableObjectId> _createObjectIdMap() {
/* 252 */     if (isEnabled(SerializationFeature.USE_EQUALITY_FOR_OBJECT_ID)) {
/* 253 */       return new HashMap<>();
/*     */     }
/* 255 */     return new IdentityHashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasSerializerFor(Class<?> cls, AtomicReference<Throwable> cause) {
/* 276 */     if (cls == Object.class && 
/* 277 */       !this._config.isEnabled(SerializationFeature.FAIL_ON_EMPTY_BEANS)) {
/* 278 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 283 */       JsonSerializer<?> ser = _findExplicitUntypedSerializer(cls);
/* 284 */       return (ser != null);
/* 285 */     } catch (JsonMappingException e) {
/* 286 */       if (cause != null) {
/* 287 */         cause.set(e);
/*     */       }
/* 289 */     } catch (RuntimeException e) {
/* 290 */       if (cause == null) {
/* 291 */         throw e;
/*     */       }
/* 293 */       cause.set(e);
/*     */     } 
/* 295 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonGenerator getGenerator() {
/* 307 */     return this._generator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeValue(JsonGenerator gen, Object value) throws IOException {
/* 324 */     this._generator = gen;
/* 325 */     if (value == null) {
/* 326 */       _serializeNull(gen);
/*     */       return;
/*     */     } 
/* 329 */     Class<?> cls = value.getClass();
/*     */     
/* 331 */     JsonSerializer<Object> ser = findTypedValueSerializer(cls, true, null);
/* 332 */     PropertyName rootName = this._config.getFullRootName();
/* 333 */     if (rootName == null) {
/* 334 */       if (this._config.isEnabled(SerializationFeature.WRAP_ROOT_VALUE)) {
/* 335 */         _serialize(gen, value, ser, this._config.findRootName(cls));
/*     */         return;
/*     */       } 
/* 338 */     } else if (!rootName.isEmpty()) {
/* 339 */       _serialize(gen, value, ser, rootName);
/*     */       return;
/*     */     } 
/* 342 */     _serialize(gen, value, ser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeValue(JsonGenerator gen, Object value, JavaType rootType) throws IOException {
/* 358 */     this._generator = gen;
/* 359 */     if (value == null) {
/* 360 */       _serializeNull(gen);
/*     */       
/*     */       return;
/*     */     } 
/* 364 */     if (!rootType.getRawClass().isAssignableFrom(value.getClass())) {
/* 365 */       _reportIncompatibleRootType(value, rootType);
/*     */     }
/*     */     
/* 368 */     JsonSerializer<Object> ser = findTypedValueSerializer(rootType, true, null);
/* 369 */     PropertyName rootName = this._config.getFullRootName();
/* 370 */     if (rootName == null) {
/* 371 */       if (this._config.isEnabled(SerializationFeature.WRAP_ROOT_VALUE)) {
/* 372 */         _serialize(gen, value, ser, this._config.findRootName(rootType));
/*     */         return;
/*     */       } 
/* 375 */     } else if (!rootName.isEmpty()) {
/* 376 */       _serialize(gen, value, ser, rootName);
/*     */       return;
/*     */     } 
/* 379 */     _serialize(gen, value, ser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializeValue(JsonGenerator gen, Object value, JavaType rootType, JsonSerializer<Object> ser) throws IOException {
/* 397 */     this._generator = gen;
/* 398 */     if (value == null) {
/* 399 */       _serializeNull(gen);
/*     */       
/*     */       return;
/*     */     } 
/* 403 */     if (rootType != null && !rootType.getRawClass().isAssignableFrom(value.getClass())) {
/* 404 */       _reportIncompatibleRootType(value, rootType);
/*     */     }
/*     */     
/* 407 */     if (ser == null) {
/* 408 */       ser = findTypedValueSerializer(rootType, true, null);
/*     */     }
/* 410 */     PropertyName rootName = this._config.getFullRootName();
/* 411 */     if (rootName == null) {
/* 412 */       if (this._config.isEnabled(SerializationFeature.WRAP_ROOT_VALUE)) {
/*     */ 
/*     */         
/* 415 */         rootName = (rootType == null) ? this._config.findRootName(value.getClass()) : this._config.findRootName(rootType);
/* 416 */         _serialize(gen, value, ser, rootName);
/*     */         return;
/*     */       } 
/* 419 */     } else if (!rootName.isEmpty()) {
/* 420 */       _serialize(gen, value, ser, rootName);
/*     */       return;
/*     */     } 
/* 423 */     _serialize(gen, value, ser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serializePolymorphic(JsonGenerator gen, Object value, JavaType rootType, JsonSerializer<Object> valueSer, TypeSerializer typeSer) throws IOException {
/*     */     boolean wrap;
/* 436 */     this._generator = gen;
/* 437 */     if (value == null) {
/* 438 */       _serializeNull(gen);
/*     */       
/*     */       return;
/*     */     } 
/* 442 */     if (rootType != null && !rootType.getRawClass().isAssignableFrom(value.getClass())) {
/* 443 */       _reportIncompatibleRootType(value, rootType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 450 */     if (valueSer == null) {
/* 451 */       if (rootType != null && rootType.isContainerType()) {
/* 452 */         valueSer = findValueSerializer(rootType, null);
/*     */       } else {
/* 454 */         valueSer = findValueSerializer(value.getClass(), null);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 459 */     PropertyName rootName = this._config.getFullRootName();
/* 460 */     if (rootName == null) {
/* 461 */       wrap = this._config.isEnabled(SerializationFeature.WRAP_ROOT_VALUE);
/* 462 */       if (wrap) {
/* 463 */         gen.writeStartObject();
/* 464 */         PropertyName pname = this._config.findRootName(value.getClass());
/* 465 */         gen.writeFieldName(pname.simpleAsEncoded((MapperConfig)this._config));
/*     */       } 
/* 467 */     } else if (rootName.isEmpty()) {
/* 468 */       wrap = false;
/*     */     } else {
/* 470 */       wrap = true;
/* 471 */       gen.writeStartObject();
/* 472 */       gen.writeFieldName(rootName.getSimpleName());
/*     */     } 
/*     */     try {
/* 475 */       valueSer.serializeWithType(value, gen, this, typeSer);
/* 476 */       if (wrap) {
/* 477 */         gen.writeEndObject();
/*     */       }
/* 479 */     } catch (Exception e) {
/* 480 */       throw _wrapAsIOE(gen, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void _serialize(JsonGenerator gen, Object value, JsonSerializer<Object> ser, PropertyName rootName) throws IOException {
/*     */     try {
/* 489 */       gen.writeStartObject();
/* 490 */       gen.writeFieldName(rootName.simpleAsEncoded((MapperConfig)this._config));
/* 491 */       ser.serialize(value, gen, this);
/* 492 */       gen.writeEndObject();
/* 493 */     } catch (Exception e) {
/* 494 */       throw _wrapAsIOE(gen, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void _serialize(JsonGenerator gen, Object value, JsonSerializer<Object> ser) throws IOException {
/*     */     try {
/* 503 */       ser.serialize(value, gen, this);
/* 504 */     } catch (Exception e) {
/* 505 */       throw _wrapAsIOE(gen, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _serializeNull(JsonGenerator gen) throws IOException {
/* 516 */     JsonSerializer<Object> ser = getDefaultNullValueSerializer();
/*     */     try {
/* 518 */       ser.serialize(null, gen, this);
/* 519 */     } catch (Exception e) {
/* 520 */       throw _wrapAsIOE(gen, e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private IOException _wrapAsIOE(JsonGenerator g, Exception e) {
/* 525 */     if (e instanceof IOException) {
/* 526 */       return (IOException)e;
/*     */     }
/* 528 */     String msg = ClassUtil.exceptionMessage(e);
/* 529 */     if (msg == null) {
/* 530 */       msg = "[no message for " + e.getClass().getName() + "]";
/*     */     }
/* 532 */     return (IOException)new JsonMappingException((Closeable)g, msg, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int cachedSerializersCount() {
/* 553 */     return this._serializerCache.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void acceptJsonFormatVisitor(JavaType javaType, JsonFormatVisitorWrapper visitor) throws JsonMappingException {
/* 572 */     if (javaType == null) {
/* 573 */       throw new IllegalArgumentException("A class must be provided");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 578 */     visitor.setProvider(this);
/* 579 */     findValueSerializer(javaType, null).acceptJsonFormatVisitor(visitor, javaType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonSchema generateJsonSchema(Class<?> type) throws JsonMappingException {
/* 598 */     JsonSerializer<Object> ser = findValueSerializer(type, null);
/*     */ 
/*     */     
/* 601 */     JsonNode schemaNode = (ser instanceof SchemaAware) ? ((SchemaAware)ser).getSchema(this, null) : JsonSchema.getDefaultSchemaNode();
/* 602 */     if (!(schemaNode instanceof ObjectNode)) {
/* 603 */       throw new IllegalArgumentException("Class " + type.getName() + " would not be serialized as a JSON object and therefore has no schema");
/*     */     }
/*     */     
/* 606 */     return new JsonSchema((ObjectNode)schemaNode);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Impl
/*     */     extends DefaultSerializerProvider
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     public Impl() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public Impl(Impl src) {
/* 623 */       super(src);
/*     */     }
/*     */     
/*     */     protected Impl(SerializerProvider src, SerializationConfig config, SerializerFactory f) {
/* 627 */       super(src, config, f);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Impl(Impl src, CacheProvider cp) {
/* 634 */       super(src, cp);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public DefaultSerializerProvider copy() {
/* 640 */       return new Impl(this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Impl createInstance(SerializationConfig config, SerializerFactory jsf) {
/* 645 */       return new Impl(this, config, jsf);
/*     */     }
/*     */ 
/*     */     
/*     */     public DefaultSerializerProvider withCaches(CacheProvider cp) {
/* 650 */       return new Impl(this, cp);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\DefaultSerializerProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */