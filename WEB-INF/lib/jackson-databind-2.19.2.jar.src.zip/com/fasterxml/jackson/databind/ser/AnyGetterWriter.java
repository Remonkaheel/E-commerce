/*     */ package com.fasterxml.jackson.databind.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.ser.std.MapSerializer;
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnyGetterWriter
/*     */   extends BeanPropertyWriter
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final BeanProperty _property;
/*     */   protected final AnnotatedMember _accessor;
/*     */   protected JsonSerializer<Object> _serializer;
/*     */   protected MapSerializer _mapSerializer;
/*     */   
/*     */   public AnyGetterWriter(BeanPropertyWriter parent, BeanProperty property, AnnotatedMember accessor, JsonSerializer<?> serializer) {
/*  39 */     super(parent);
/*  40 */     this._accessor = accessor;
/*  41 */     this._property = property;
/*  42 */     this._serializer = (JsonSerializer)serializer;
/*  43 */     if (serializer instanceof MapSerializer) {
/*  44 */       this._mapSerializer = (MapSerializer)serializer;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public AnyGetterWriter(BeanProperty property, AnnotatedMember accessor, JsonSerializer<?> serializer) {
/*  55 */     this(null, property, accessor, serializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fixAccess(SerializationConfig config) {
/*  63 */     this._accessor.fixAccess(config
/*  64 */         .isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void getAndSerialize(Object bean, JsonGenerator gen, SerializerProvider provider) throws Exception {
/*  70 */     Object value = this._accessor.getValue(bean);
/*  71 */     if (value == null) {
/*     */       return;
/*     */     }
/*  74 */     if (!(value instanceof Map)) {
/*  75 */       provider.reportBadDefinition(this._property.getType(), String.format("Value returned by 'any-getter' %s() not java.util.Map but %s", new Object[] { this._accessor
/*     */               
/*  77 */               .getName(), value.getClass().getName() }));
/*     */     }
/*     */     
/*  80 */     if (this._mapSerializer != null) {
/*  81 */       this._mapSerializer.serializeWithoutTypeInfo((Map)value, gen, provider);
/*     */       return;
/*     */     } 
/*  84 */     this._serializer.serialize(value, gen, provider);
/*     */   }
/*     */ 
/*     */   
/*     */   public void serializeAsField(Object bean, JsonGenerator gen, SerializerProvider prov) throws Exception {
/*  89 */     getAndSerialize(bean, gen, prov);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getAndFilter(Object bean, JsonGenerator gen, SerializerProvider provider, PropertyFilter filter) throws Exception {
/*  99 */     Object value = this._accessor.getValue(bean);
/* 100 */     if (value == null) {
/*     */       return;
/*     */     }
/* 103 */     if (!(value instanceof Map)) {
/* 104 */       provider.reportBadDefinition(this._property.getType(), 
/* 105 */           String.format("Value returned by 'any-getter' (%s()) not java.util.Map but %s", new Object[] {
/* 106 */               this._accessor.getName(), value.getClass().getName()
/*     */             }));
/*     */     }
/* 109 */     if (this._mapSerializer != null) {
/* 110 */       this._mapSerializer.serializeFilteredAnyProperties(provider, gen, bean, (Map)value, filter, null);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 115 */     this._serializer.serialize(value, gen, provider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(SerializerProvider provider) throws JsonMappingException {
/* 123 */     if (this._serializer instanceof ContextualSerializer) {
/* 124 */       JsonSerializer<?> ser = provider.handlePrimaryContextualization(this._serializer, this._property);
/* 125 */       this._serializer = (JsonSerializer)ser;
/* 126 */       if (ser instanceof MapSerializer)
/* 127 */         this._mapSerializer = (MapSerializer)ser; 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\AnyGetterWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */