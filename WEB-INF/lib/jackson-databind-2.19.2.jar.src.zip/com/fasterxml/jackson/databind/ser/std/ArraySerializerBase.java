/*     */ package com.fasterxml.jackson.databind.ser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.ContainerSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*     */ import java.io.IOException;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ArraySerializerBase<T>
/*     */   extends ContainerSerializer<T>
/*     */   implements ContextualSerializer
/*     */ {
/*     */   protected final BeanProperty _property;
/*     */   protected final Boolean _unwrapSingle;
/*     */   
/*     */   protected ArraySerializerBase(Class<T> cls) {
/*  38 */     super(cls);
/*  39 */     this._property = null;
/*  40 */     this._unwrapSingle = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected ArraySerializerBase(Class<T> cls, BeanProperty property) {
/*  52 */     super(cls);
/*  53 */     this._property = property;
/*  54 */     this._unwrapSingle = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected ArraySerializerBase(ArraySerializerBase<?> src) {
/*  59 */     super(src._handledType, false);
/*  60 */     this._property = src._property;
/*  61 */     this._unwrapSingle = src._unwrapSingle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ArraySerializerBase(ArraySerializerBase<?> src, BeanProperty property, Boolean unwrapSingle) {
/*  70 */     super(src._handledType, false);
/*  71 */     this._property = property;
/*  72 */     this._unwrapSingle = unwrapSingle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected ArraySerializerBase(ArraySerializerBase<?> src, BeanProperty property) {
/*  81 */     super(src._handledType, false);
/*  82 */     this._property = property;
/*  83 */     this._unwrapSingle = src._unwrapSingle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonSerializer<?> _withResolved(BeanProperty paramBeanProperty, Boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> createContextual(SerializerProvider serializers, BeanProperty property) throws JsonMappingException {
/*  96 */     Boolean unwrapSingle = null;
/*     */ 
/*     */     
/*  99 */     if (property != null) {
/* 100 */       JsonFormat.Value format = findFormatOverrides(serializers, property, handledType());
/* 101 */       if (format != null) {
/* 102 */         unwrapSingle = format.getFeature(JsonFormat.Feature.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED);
/* 103 */         if (!Objects.equals(unwrapSingle, this._unwrapSingle)) {
/* 104 */           return _withResolved(property, unwrapSingle);
/*     */         }
/*     */       } 
/*     */     } 
/* 108 */     return (JsonSerializer<?>)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void serialize(T value, JsonGenerator gen, SerializerProvider provider) throws IOException {
/* 117 */     if (_shouldUnwrapSingle(provider) && 
/* 118 */       hasSingleElement(value)) {
/* 119 */       serializeContents(value, gen, provider);
/*     */       
/*     */       return;
/*     */     } 
/* 123 */     gen.writeStartArray(value);
/* 124 */     serializeContents(value, gen, provider);
/* 125 */     gen.writeEndArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void serializeWithType(T value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/* 133 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/* 134 */         .typeId(value, JsonToken.START_ARRAY));
/*     */     
/* 136 */     g.assignCurrentValue(value);
/* 137 */     serializeContents(value, g, provider);
/* 138 */     typeSer.writeTypeSuffix(g, typeIdDef);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void serializeContents(T paramT, JsonGenerator paramJsonGenerator, SerializerProvider paramSerializerProvider) throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _shouldUnwrapSingle(SerializerProvider provider) {
/* 148 */     if (this._unwrapSingle == null) {
/* 149 */       return provider.isEnabled(SerializationFeature.WRITE_SINGLE_ELEM_ARRAYS_UNWRAPPED);
/*     */     }
/* 151 */     return this._unwrapSingle.booleanValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\std\ArraySerializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */