/*     */ package com.fasterxml.jackson.databind.ser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*     */ import com.fasterxml.jackson.annotation.JsonIncludeProperties;
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerators;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.TokenStreamFactory;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DatabindContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.ObjectReader;
/*     */ import com.fasterxml.jackson.databind.ObjectWriter;
/*     */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.cfg.SerializerFactoryConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*     */ import com.fasterxml.jackson.databind.introspect.ObjectIdInfo;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.impl.FilteredBeanPropertyWriter;
/*     */ import com.fasterxml.jackson.databind.ser.impl.MapEntryAsPOJOSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.impl.ObjectIdWriter;
/*     */ import com.fasterxml.jackson.databind.ser.impl.PropertyBasedObjectIdGenerator;
/*     */ import com.fasterxml.jackson.databind.ser.impl.UnsupportedTypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.std.MapSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.std.StdDelegatingSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.std.ToEmptyObjectSerializer;
/*     */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*     */ import com.fasterxml.jackson.databind.util.BeanUtil;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
/*     */ import com.fasterxml.jackson.databind.util.NativeImageUtil;
/*     */ import com.fasterxml.jackson.databind.util.SimpleBeanPropertyDefinition;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanSerializerFactory
/*     */   extends BasicSerializerFactory
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  70 */   public static final BeanSerializerFactory instance = new BeanSerializerFactory(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanSerializerFactory(SerializerFactoryConfig config) {
/*  83 */     super(config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializerFactory withConfig(SerializerFactoryConfig config) {
/*  95 */     if (this._factoryConfig == config) {
/*  96 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     if (getClass() != BeanSerializerFactory.class) {
/* 105 */       throw new IllegalStateException("Subtype of BeanSerializerFactory (" + getClass().getName() + ") has not properly overridden method 'withAdditionalSerializers': cannot instantiate subtype with additional serializer definitions");
/*     */     }
/*     */ 
/*     */     
/* 109 */     return new BeanSerializerFactory(config);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Iterable<Serializers> customSerializers() {
/* 114 */     return this._factoryConfig.serializers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> createSerializer(SerializerProvider prov, JavaType origType) throws JsonMappingException {
/*     */     boolean staticTyping;
/*     */     JavaType type;
/* 140 */     SerializationConfig config = prov.getConfig();
/* 141 */     BeanDescription beanDesc = config.introspect(origType);
/* 142 */     JsonSerializer<?> ser = findSerializerFromAnnotation(prov, (Annotated)beanDesc.getClassInfo());
/* 143 */     if (ser != null) {
/* 144 */       return (JsonSerializer)ser;
/*     */     }
/*     */ 
/*     */     
/* 148 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/*     */ 
/*     */     
/* 151 */     if (intr == null) {
/* 152 */       type = origType;
/*     */     } else {
/*     */       try {
/* 155 */         type = intr.refineSerializationType((MapperConfig)config, (Annotated)beanDesc.getClassInfo(), origType);
/* 156 */       } catch (JsonMappingException e) {
/* 157 */         return (JsonSerializer<Object>)prov.reportBadTypeDefinition(beanDesc, e.getMessage(), new Object[0]);
/*     */       } 
/*     */     } 
/* 160 */     if (type == origType) {
/* 161 */       staticTyping = false;
/*     */     } else {
/* 163 */       staticTyping = true;
/* 164 */       if (!type.hasRawClass(origType.getRawClass())) {
/* 165 */         beanDesc = config.introspect(type);
/*     */       }
/*     */     } 
/*     */     
/* 169 */     Converter<Object, Object> conv = beanDesc.findSerializationConverter();
/* 170 */     if (conv == null) {
/* 171 */       return (JsonSerializer)_createSerializer2(prov, type, beanDesc, staticTyping);
/*     */     }
/* 173 */     JavaType delegateType = conv.getOutputType(prov.getTypeFactory());
/*     */ 
/*     */     
/* 176 */     if (!delegateType.hasRawClass(type.getRawClass())) {
/* 177 */       beanDesc = config.introspect(delegateType);
/*     */       
/* 179 */       ser = findSerializerFromAnnotation(prov, (Annotated)beanDesc.getClassInfo());
/*     */     } 
/*     */     
/* 182 */     if (ser == null && !delegateType.isJavaLangObject()) {
/* 183 */       ser = _createSerializer2(prov, delegateType, beanDesc, true);
/*     */     }
/* 185 */     return (JsonSerializer<Object>)new StdDelegatingSerializer(conv, delegateType, ser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<?> _createSerializer2(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/* 192 */     JsonSerializer<?> ser = null;
/* 193 */     SerializationConfig config = prov.getConfig();
/*     */ 
/*     */ 
/*     */     
/* 197 */     if (type.isContainerType()) {
/* 198 */       if (!staticTyping) {
/* 199 */         staticTyping = usesStaticTyping(config, beanDesc);
/*     */       }
/*     */       
/* 202 */       ser = buildContainerSerializer(prov, type, beanDesc, staticTyping);
/*     */       
/* 204 */       if (ser != null) {
/* 205 */         return ser;
/*     */       }
/*     */     } else {
/* 208 */       if (type.isReferenceType()) {
/* 209 */         ser = findReferenceSerializer(prov, (ReferenceType)type, beanDesc, staticTyping);
/*     */       } else {
/*     */         
/* 212 */         for (Serializers serializers : customSerializers()) {
/* 213 */           ser = serializers.findSerializer(config, type, beanDesc);
/* 214 */           if (ser != null) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 221 */       if (ser == null) {
/* 222 */         ser = findSerializerByAnnotations(prov, type, beanDesc);
/*     */       }
/*     */     } 
/*     */     
/* 226 */     if (ser == null) {
/*     */ 
/*     */ 
/*     */       
/* 230 */       ser = findSerializerByLookup(type, config, beanDesc, staticTyping);
/* 231 */       if (ser == null) {
/* 232 */         ser = findSerializerByPrimaryType(prov, type, beanDesc, staticTyping);
/* 233 */         if (ser == null) {
/*     */ 
/*     */ 
/*     */           
/* 237 */           ser = findBeanOrAddOnSerializer(prov, type, beanDesc, staticTyping);
/*     */ 
/*     */ 
/*     */           
/* 241 */           if (ser == null) {
/* 242 */             ser = prov.getUnknownTypeSerializer(beanDesc.getBeanClass());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 247 */     if (ser != null)
/*     */     {
/* 249 */       if (this._factoryConfig.hasSerializerModifiers()) {
/* 250 */         for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 251 */           ser = mod.modifySerializer(config, beanDesc, ser);
/*     */         }
/*     */       }
/*     */     }
/* 255 */     return ser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonSerializer<Object> findBeanSerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/* 270 */     return findBeanOrAddOnSerializer(prov, type, beanDesc, prov.isEnabled(MapperFeature.USE_STATIC_TYPING));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<Object> findBeanOrAddOnSerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/* 285 */     if (!isPotentialBeanType(type.getRawClass()))
/*     */     {
/*     */       
/* 288 */       if (!ClassUtil.isEnumType(type.getRawClass())) {
/* 289 */         return null;
/*     */       }
/*     */     }
/* 292 */     return constructBeanOrAddOnSerializer(prov, type, beanDesc, staticTyping);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeSerializer findPropertyTypeSerializer(JavaType baseType, SerializationConfig config, AnnotatedMember accessor) throws JsonMappingException {
/*     */     TypeSerializer typeSer;
/* 309 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 310 */     TypeResolverBuilder<?> b = ai.findPropertyTypeResolver((MapperConfig)config, accessor, baseType);
/*     */ 
/*     */ 
/*     */     
/* 314 */     if (b == null) {
/* 315 */       typeSer = createTypeSerializer(config, baseType);
/*     */     } else {
/* 317 */       Collection<NamedType> subtypes = config.getSubtypeResolver().collectAndResolveSubtypesByClass((MapperConfig)config, accessor, baseType);
/*     */       
/* 319 */       typeSer = b.buildTypeSerializer(config, baseType, subtypes);
/*     */     } 
/* 321 */     return typeSer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeSerializer findPropertyContentTypeSerializer(JavaType containerType, SerializationConfig config, AnnotatedMember accessor) throws JsonMappingException {
/*     */     TypeSerializer typeSer;
/* 338 */     JavaType contentType = containerType.getContentType();
/* 339 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 340 */     TypeResolverBuilder<?> b = ai.findPropertyContentTypeResolver((MapperConfig)config, accessor, containerType);
/*     */ 
/*     */ 
/*     */     
/* 344 */     if (b == null) {
/* 345 */       typeSer = createTypeSerializer(config, contentType);
/*     */     } else {
/* 347 */       Collection<NamedType> subtypes = config.getSubtypeResolver().collectAndResolveSubtypesByClass((MapperConfig)config, accessor, contentType);
/*     */       
/* 349 */       typeSer = b.buildTypeSerializer(config, contentType, subtypes);
/*     */     } 
/* 351 */     return typeSer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected JsonSerializer<Object> constructBeanSerializer(SerializerProvider prov, BeanDescription beanDesc) throws JsonMappingException {
/* 365 */     return constructBeanOrAddOnSerializer(prov, beanDesc.getType(), beanDesc, prov.isEnabled(MapperFeature.USE_STATIC_TYPING));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<Object> constructBeanOrAddOnSerializer(SerializerProvider prov, JavaType type, BeanDescription beanDesc, boolean staticTyping) throws JsonMappingException {
/* 381 */     if (beanDesc.getBeanClass() == Object.class) {
/* 382 */       return prov.getUnknownTypeSerializer(Object.class);
/*     */     }
/*     */     
/* 385 */     JsonSerializer<?> ser = _findUnsupportedTypeSerializer(prov, type, beanDesc);
/* 386 */     if (ser != null) {
/* 387 */       return (JsonSerializer)ser;
/*     */     }
/*     */ 
/*     */     
/* 391 */     if (_isUnserializableJacksonType(prov, type)) {
/* 392 */       return (JsonSerializer<Object>)new ToEmptyObjectSerializer(type);
/*     */     }
/*     */ 
/*     */     
/* 396 */     if (type.isTypeOrSubTypeOf(Map.Entry.class) && 
/* 397 */       ClassUtil.isJDKClass(type.getRawClass())) {
/* 398 */       return (JsonSerializer<Object>)MapEntryAsPOJOSerializer.create(prov, type);
/*     */     }
/* 400 */     SerializationConfig config = prov.getConfig();
/* 401 */     BeanSerializerBuilder builder = constructBeanSerializerBuilder(beanDesc);
/* 402 */     builder.setConfig(config);
/*     */ 
/*     */     
/* 405 */     List<BeanPropertyWriter> props = findBeanProperties(prov, beanDesc, builder);
/* 406 */     if (props == null) {
/* 407 */       props = new ArrayList<>();
/*     */     } else {
/* 409 */       props = removeOverlappingTypeIds(prov, beanDesc, builder, props);
/*     */     } 
/*     */ 
/*     */     
/* 413 */     prov.getAnnotationIntrospector().findAndAddVirtualProperties((MapperConfig)config, beanDesc.getClassInfo(), props);
/*     */ 
/*     */     
/* 416 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 417 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 418 */         props = mod.changeProperties(config, beanDesc, props);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 426 */     props = filterUnwantedJDKProperties(config, beanDesc, props);
/* 427 */     props = filterBeanProperties(config, beanDesc, props);
/*     */ 
/*     */     
/* 430 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 431 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 432 */         props = mod.orderProperties(config, beanDesc, props);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 439 */     builder.setObjectIdWriter(constructObjectIdHandler(prov, beanDesc, props));
/*     */     
/* 441 */     builder.setProperties(props);
/* 442 */     builder.setFilterId(findFilterId(config, beanDesc));
/*     */     
/* 444 */     AnnotatedMember anyGetter = beanDesc.findAnyGetter();
/* 445 */     if (anyGetter != null) {
/* 446 */       MapSerializer mapSerializer; JavaType anyType = anyGetter.getType();
/*     */       
/* 448 */       JavaType valueType = anyType.getContentType();
/* 449 */       TypeSerializer typeSer = createTypeSerializer(config, valueType);
/*     */ 
/*     */       
/* 452 */       JsonSerializer<?> anySer = findSerializerFromAnnotation(prov, (Annotated)anyGetter);
/* 453 */       if (anySer == null)
/*     */       {
/* 455 */         mapSerializer = MapSerializer.construct((Set)null, anyType, config
/* 456 */             .isEnabled(MapperFeature.USE_STATIC_TYPING), typeSer, null, null, null);
/*     */       }
/*     */ 
/*     */       
/* 460 */       PropertyName name = PropertyName.construct(anyGetter.getName());
/* 461 */       BeanProperty.Std anyProp = new BeanProperty.Std(name, valueType, null, anyGetter, PropertyMetadata.STD_OPTIONAL);
/*     */ 
/*     */ 
/*     */       
/* 465 */       BeanPropertyWriter anyGetterProp = null;
/* 466 */       int anyGetterIndex = -1;
/* 467 */       for (int i = 0; i < props.size(); i++) {
/* 468 */         BeanPropertyWriter prop = props.get(i);
/*     */         
/* 470 */         if (Objects.equals(prop.getName(), anyGetter.getName()) || 
/*     */           
/* 472 */           Objects.equals(prop.getMember().getMember(), anyGetter.getMember())) {
/*     */           
/* 474 */           anyGetterProp = prop;
/* 475 */           anyGetterIndex = i;
/*     */           break;
/*     */         } 
/*     */       } 
/* 479 */       if (anyGetterIndex != -1) {
/*     */         
/* 481 */         AnyGetterWriter anyGetterWriter = new AnyGetterWriter(anyGetterProp, (BeanProperty)anyProp, anyGetter, (JsonSerializer<?>)mapSerializer);
/* 482 */         props.set(anyGetterIndex, anyGetterWriter);
/*     */       }
/*     */       else {
/*     */         
/* 486 */         SimpleBeanPropertyDefinition simpleBeanPropertyDefinition = SimpleBeanPropertyDefinition.construct((MapperConfig)config, anyGetter, name);
/* 487 */         BeanPropertyWriter anyPropWriter = _constructWriter(prov, (BeanPropertyDefinition)simpleBeanPropertyDefinition, new PropertyBuilder(config, beanDesc), staticTyping, anyGetter);
/* 488 */         props.add(new AnyGetterWriter(anyPropWriter, (BeanProperty)anyProp, anyGetter, (JsonSerializer<?>)mapSerializer));
/*     */       } 
/*     */     } 
/*     */     
/* 492 */     processViews(config, builder);
/*     */ 
/*     */     
/* 495 */     if (this._factoryConfig.hasSerializerModifiers()) {
/* 496 */       for (BeanSerializerModifier mod : this._factoryConfig.serializerModifiers()) {
/* 497 */         builder = mod.updateBuilder(config, beanDesc, builder);
/*     */       }
/*     */     }
/*     */     
/*     */     try {
/* 502 */       ser = builder.build();
/* 503 */     } catch (RuntimeException e) {
/* 504 */       return (JsonSerializer<Object>)prov.reportBadTypeDefinition(beanDesc, "Failed to construct BeanSerializer for %s: (%s) %s", new Object[] { beanDesc
/* 505 */             .getType(), e.getClass().getName(), e.getMessage() });
/*     */     } 
/* 507 */     if (ser == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 512 */       if (type.isRecordType() && !NativeImageUtil.needsReflectionConfiguration(type.getRawClass())) {
/* 513 */         return (JsonSerializer<Object>)builder.createDummy();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 518 */       ser = findSerializerByAddonType(config, type, beanDesc, staticTyping);
/* 519 */       if (ser == null)
/*     */       {
/*     */ 
/*     */         
/* 523 */         if (beanDesc.hasKnownClassAnnotations()) {
/* 524 */           return (JsonSerializer<Object>)builder.createDummy();
/*     */         }
/*     */       }
/*     */     } 
/* 528 */     return (JsonSerializer)ser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectIdWriter constructObjectIdHandler(SerializerProvider prov, BeanDescription beanDesc, List<BeanPropertyWriter> props) throws JsonMappingException {
/* 535 */     ObjectIdInfo objectIdInfo = beanDesc.getObjectIdInfo();
/* 536 */     if (objectIdInfo == null) {
/* 537 */       return null;
/*     */     }
/*     */     
/* 540 */     Class<?> implClass = objectIdInfo.getGeneratorType();
/*     */ 
/*     */     
/* 543 */     if (implClass == ObjectIdGenerators.PropertyGenerator.class) {
/* 544 */       String propName = objectIdInfo.getPropertyName().getSimpleName();
/* 545 */       BeanPropertyWriter idProp = null;
/*     */       
/* 547 */       for (int i = 0, len = props.size();; i++) {
/* 548 */         if (i == len)
/* 549 */           throw new IllegalArgumentException(String.format("Invalid Object Id definition for %s: cannot find property with name %s", new Object[] {
/*     */                   
/* 551 */                   ClassUtil.getTypeDescription(beanDesc.getType()), ClassUtil.name(propName)
/*     */                 })); 
/* 553 */         BeanPropertyWriter prop = props.get(i);
/* 554 */         if (propName.equals(prop.getName())) {
/* 555 */           idProp = prop;
/*     */ 
/*     */           
/* 558 */           if (i > 0) {
/* 559 */             props.remove(i);
/* 560 */             props.add(0, idProp);
/*     */           } 
/*     */           break;
/*     */         } 
/*     */       } 
/* 565 */       JavaType javaType = idProp.getType();
/* 566 */       PropertyBasedObjectIdGenerator propertyBasedObjectIdGenerator = new PropertyBasedObjectIdGenerator(objectIdInfo, idProp);
/*     */       
/* 568 */       return ObjectIdWriter.construct(javaType, (PropertyName)null, (ObjectIdGenerator)propertyBasedObjectIdGenerator, objectIdInfo.getAlwaysAsId());
/*     */     } 
/*     */ 
/*     */     
/* 572 */     JavaType type = prov.constructType(implClass);
/*     */     
/* 574 */     JavaType idType = prov.getTypeFactory().findTypeParameters(type, ObjectIdGenerator.class)[0];
/* 575 */     ObjectIdGenerator<?> gen = prov.objectIdGeneratorInstance((Annotated)beanDesc.getClassInfo(), objectIdInfo);
/* 576 */     return ObjectIdWriter.construct(idType, objectIdInfo.getPropertyName(), gen, objectIdInfo
/* 577 */         .getAlwaysAsId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanPropertyWriter constructFilteredBeanWriter(BeanPropertyWriter writer, Class<?>[] inViews) {
/* 588 */     return FilteredBeanPropertyWriter.constructViewBased(writer, inViews);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected PropertyBuilder constructPropertyBuilder(SerializationConfig config, BeanDescription beanDesc) {
/* 594 */     return new PropertyBuilder(config, beanDesc);
/*     */   }
/*     */   
/*     */   protected BeanSerializerBuilder constructBeanSerializerBuilder(BeanDescription beanDesc) {
/* 598 */     return new BeanSerializerBuilder(beanDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isPotentialBeanType(Class<?> type) {
/* 617 */     return (ClassUtil.canBeABeanType(type) == null && !ClassUtil.isProxyType(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<BeanPropertyWriter> findBeanProperties(SerializerProvider prov, BeanDescription beanDesc, BeanSerializerBuilder builder) throws JsonMappingException {
/* 628 */     List<BeanPropertyDefinition> properties = beanDesc.findProperties();
/* 629 */     SerializationConfig config = prov.getConfig();
/*     */ 
/*     */     
/* 632 */     removeIgnorableTypes(config, beanDesc, properties);
/*     */ 
/*     */     
/* 635 */     if (config.isEnabled(MapperFeature.REQUIRE_SETTERS_FOR_GETTERS)) {
/* 636 */       removeSetterlessGetters(config, beanDesc, properties);
/*     */     }
/*     */ 
/*     */     
/* 640 */     if (properties.isEmpty()) {
/* 641 */       return null;
/*     */     }
/*     */     
/* 644 */     boolean staticTyping = usesStaticTyping(config, beanDesc);
/* 645 */     PropertyBuilder pb = constructPropertyBuilder(config, beanDesc);
/*     */     
/* 647 */     ArrayList<BeanPropertyWriter> result = new ArrayList<>(properties.size());
/* 648 */     for (BeanPropertyDefinition property : properties) {
/* 649 */       AnnotatedMember accessor = property.getAccessor();
/*     */       
/* 651 */       if (property.isTypeId()) {
/* 652 */         if (accessor != null) {
/* 653 */           builder.setTypeId(accessor);
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/* 658 */       AnnotationIntrospector.ReferenceProperty refType = property.findReferenceType();
/* 659 */       if (refType != null && refType.isBackReference()) {
/*     */         continue;
/*     */       }
/* 662 */       if (accessor instanceof com.fasterxml.jackson.databind.introspect.AnnotatedMethod) {
/* 663 */         result.add(_constructWriter(prov, property, pb, staticTyping, accessor)); continue;
/*     */       } 
/* 665 */       result.add(_constructWriter(prov, property, pb, staticTyping, accessor));
/*     */     } 
/*     */     
/* 668 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<BeanPropertyWriter> filterBeanProperties(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyWriter> props) {
/* 688 */     JsonIgnoreProperties.Value ignorals = config.getDefaultPropertyIgnorals(beanDesc.getBeanClass(), beanDesc
/* 689 */         .getClassInfo());
/* 690 */     Set<String> ignored = null;
/* 691 */     if (ignorals != null) {
/* 692 */       ignored = ignorals.findIgnoredForSerialization();
/*     */     }
/* 694 */     JsonIncludeProperties.Value inclusions = config.getDefaultPropertyInclusions(beanDesc.getBeanClass(), beanDesc
/* 695 */         .getClassInfo());
/* 696 */     Set<String> included = null;
/* 697 */     if (inclusions != null) {
/* 698 */       included = inclusions.getIncluded();
/*     */     }
/* 700 */     if (included != null || (ignored != null && !ignored.isEmpty())) {
/* 701 */       Iterator<BeanPropertyWriter> it = props.iterator();
/* 702 */       while (it.hasNext()) {
/* 703 */         if (IgnorePropertiesUtil.shouldIgnore(((BeanPropertyWriter)it.next()).getName(), ignored, included)) {
/* 704 */           it.remove();
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 709 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<BeanPropertyWriter> filterUnwantedJDKProperties(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyWriter> props) {
/* 725 */     if (beanDesc.getType().isTypeOrSubTypeOf(CharSequence.class))
/*     */     {
/* 727 */       if (props.size() == 1) {
/* 728 */         BeanPropertyWriter prop = props.get(0);
/*     */ 
/*     */ 
/*     */         
/* 732 */         AnnotatedMember m = prop.getMember();
/* 733 */         if (m instanceof com.fasterxml.jackson.databind.introspect.AnnotatedMethod && "isEmpty"
/* 734 */           .equals(m.getName()) && m
/* 735 */           .getDeclaringClass() == CharSequence.class) {
/* 736 */           props.remove(0);
/*     */         }
/*     */       } 
/*     */     }
/* 740 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processViews(SerializationConfig config, BeanSerializerBuilder builder) {
/* 755 */     List<BeanPropertyWriter> props = builder.getProperties();
/* 756 */     boolean includeByDefault = config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION);
/* 757 */     int propCount = props.size();
/* 758 */     int viewsFound = 0;
/* 759 */     BeanPropertyWriter[] filtered = new BeanPropertyWriter[propCount];
/*     */     
/* 761 */     for (int i = 0; i < propCount; i++) {
/* 762 */       BeanPropertyWriter bpw = props.get(i);
/* 763 */       Class<?>[] views = bpw.getViews();
/* 764 */       if (views == null || views.length == 0) {
/*     */ 
/*     */         
/* 767 */         if (includeByDefault) {
/* 768 */           filtered[i] = bpw;
/*     */         }
/*     */       } else {
/* 771 */         viewsFound++;
/* 772 */         filtered[i] = constructFilteredBeanWriter(bpw, views);
/*     */       } 
/*     */     } 
/*     */     
/* 776 */     if (includeByDefault && viewsFound == 0) {
/*     */       return;
/*     */     }
/* 779 */     builder.setFilteredProperties(filtered);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeIgnorableTypes(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyDefinition> properties) {
/* 791 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 792 */     HashMap<Class<?>, Boolean> ignores = new HashMap<>();
/* 793 */     Iterator<BeanPropertyDefinition> it = properties.iterator();
/* 794 */     while (it.hasNext()) {
/* 795 */       BeanPropertyDefinition property = it.next();
/* 796 */       AnnotatedMember accessor = property.getAccessor();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 801 */       if (accessor == null) {
/* 802 */         it.remove();
/*     */         continue;
/*     */       } 
/* 805 */       Class<?> type = property.getRawPrimaryType();
/* 806 */       Boolean result = ignores.get(type);
/* 807 */       if (result == null) {
/*     */         
/* 809 */         result = config.getConfigOverride(type).getIsIgnoredType();
/* 810 */         if (result == null) {
/* 811 */           BeanDescription desc = config.introspectClassAnnotations(type);
/* 812 */           AnnotatedClass ac = desc.getClassInfo();
/* 813 */           result = intr.isIgnorableType(ac);
/*     */           
/* 815 */           if (result == null) {
/* 816 */             result = Boolean.FALSE;
/*     */           }
/*     */         } 
/* 819 */         ignores.put(type, result);
/*     */       } 
/*     */       
/* 822 */       if (result.booleanValue()) {
/* 823 */         it.remove();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeSetterlessGetters(SerializationConfig config, BeanDescription beanDesc, List<BeanPropertyDefinition> properties) {
/* 836 */     properties.removeIf(property -> (!property.couldDeserialize() && !property.isExplicitlyIncluded()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<BeanPropertyWriter> removeOverlappingTypeIds(SerializerProvider prov, BeanDescription beanDesc, BeanSerializerBuilder builder, List<BeanPropertyWriter> props) {
/* 849 */     for (int i = 0, end = props.size(); i < end; i++) {
/* 850 */       BeanPropertyWriter bpw = props.get(i);
/* 851 */       TypeSerializer td = bpw.getTypeSerializer();
/* 852 */       if (td != null && td.getTypeInclusion() == JsonTypeInfo.As.EXTERNAL_PROPERTY) {
/*     */ 
/*     */         
/* 855 */         String n = td.getPropertyName();
/* 856 */         PropertyName typePropName = PropertyName.construct(n);
/*     */         
/* 858 */         for (BeanPropertyWriter w2 : props) {
/* 859 */           if (w2 != bpw && w2.wouldConflictWithName(typePropName)) {
/* 860 */             bpw.assignTypeSerializer(null); break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 865 */     return props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanPropertyWriter _constructWriter(SerializerProvider prov, BeanPropertyDefinition propDef, PropertyBuilder pb, boolean staticTyping, AnnotatedMember accessor) throws JsonMappingException {
/* 883 */     PropertyName name = propDef.getFullName();
/* 884 */     JavaType type = accessor.getType();
/*     */     
/* 886 */     BeanProperty.Std property = new BeanProperty.Std(name, type, propDef.getWrapperName(), accessor, propDef.getMetadata());
/*     */ 
/*     */     
/* 889 */     JsonSerializer<?> annotatedSerializer = findSerializerFromAnnotation(prov, (Annotated)accessor);
/*     */ 
/*     */ 
/*     */     
/* 893 */     if (annotatedSerializer instanceof ResolvableSerializer) {
/* 894 */       ((ResolvableSerializer)annotatedSerializer).resolve(prov);
/*     */     }
/*     */     
/* 897 */     annotatedSerializer = prov.handlePrimaryContextualization(annotatedSerializer, (BeanProperty)property);
/*     */     
/* 899 */     TypeSerializer contentTypeSer = null;
/*     */     
/* 901 */     if (type.isContainerType() || type.isReferenceType()) {
/* 902 */       contentTypeSer = findPropertyContentTypeSerializer(type, prov.getConfig(), accessor);
/*     */     }
/*     */     
/* 905 */     TypeSerializer typeSer = findPropertyTypeSerializer(type, prov.getConfig(), accessor);
/* 906 */     return pb.buildWriter(prov, propDef, type, annotatedSerializer, typeSer, contentTypeSer, accessor, staticTyping);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonSerializer<?> _findUnsupportedTypeSerializer(SerializerProvider ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/* 916 */     String errorMsg = BeanUtil.checkUnsupportedType((MapperConfig)ctxt.getConfig(), type);
/* 917 */     if (errorMsg != null)
/*     */     {
/*     */       
/* 920 */       if (ctxt.getConfig().findMixInClassFor(type.getRawClass()) == null) {
/* 921 */         return (JsonSerializer<?>)new UnsupportedTypeSerializer(type, errorMsg);
/*     */       }
/*     */     }
/* 924 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _isUnserializableJacksonType(SerializerProvider ctxt, JavaType type) {
/* 935 */     Class<?> raw = type.getRawClass();
/* 936 */     return (ObjectMapper.class.isAssignableFrom(raw) || ObjectReader.class
/* 937 */       .isAssignableFrom(raw) || ObjectWriter.class
/* 938 */       .isAssignableFrom(raw) || DatabindContext.class
/* 939 */       .isAssignableFrom(raw) || TokenStreamFactory.class
/* 940 */       .isAssignableFrom(raw) || JsonParser.class
/* 941 */       .isAssignableFrom(raw) || JsonGenerator.class
/* 942 */       .isAssignableFrom(raw));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ser\BeanSerializerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */