/*      */ package com.fasterxml.jackson.databind;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*      */ import com.fasterxml.jackson.annotation.JsonInclude;
/*      */ import com.fasterxml.jackson.annotation.JsonSetter;
/*      */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*      */ import com.fasterxml.jackson.annotation.PropertyAccessor;
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.Base64Variants;
/*      */ import com.fasterxml.jackson.core.FormatSchema;
/*      */ import com.fasterxml.jackson.core.JsonEncoding;
/*      */ import com.fasterxml.jackson.core.JsonFactory;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonProcessingException;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.PrettyPrinter;
/*      */ import com.fasterxml.jackson.core.StreamReadFeature;
/*      */ import com.fasterxml.jackson.core.StreamWriteFeature;
/*      */ import com.fasterxml.jackson.core.TreeNode;
/*      */ import com.fasterxml.jackson.core.Version;
/*      */ import com.fasterxml.jackson.core.Versioned;
/*      */ import com.fasterxml.jackson.core.exc.StreamReadException;
/*      */ import com.fasterxml.jackson.core.exc.StreamWriteException;
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.io.SegmentedStringWriter;
/*      */ import com.fasterxml.jackson.core.type.ResolvedType;
/*      */ import com.fasterxml.jackson.core.type.TypeReference;
/*      */ import com.fasterxml.jackson.core.util.BufferRecycler;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.databind.cfg.BaseSettings;
/*      */ import com.fasterxml.jackson.databind.cfg.CacheProvider;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionConfigs;
/*      */ import com.fasterxml.jackson.databind.cfg.ConfigOverrides;
/*      */ import com.fasterxml.jackson.databind.cfg.ConstructorDetector;
/*      */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*      */ import com.fasterxml.jackson.databind.cfg.DatatypeFeatures;
/*      */ import com.fasterxml.jackson.databind.cfg.DefaultCacheProvider;
/*      */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.cfg.MutableCoercionConfig;
/*      */ import com.fasterxml.jackson.databind.cfg.MutableConfigOverride;
/*      */ import com.fasterxml.jackson.databind.cfg.PackageVersion;
/*      */ import com.fasterxml.jackson.databind.deser.BeanDeserializerFactory;
/*      */ import com.fasterxml.jackson.databind.deser.BeanDeserializerModifier;
/*      */ import com.fasterxml.jackson.databind.deser.DefaultDeserializationContext;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
/*      */ import com.fasterxml.jackson.databind.deser.DeserializerFactory;
/*      */ import com.fasterxml.jackson.databind.deser.Deserializers;
/*      */ import com.fasterxml.jackson.databind.deser.KeyDeserializers;
/*      */ import com.fasterxml.jackson.databind.deser.ValueInstantiators;
/*      */ import com.fasterxml.jackson.databind.exc.MismatchedInputException;
/*      */ import com.fasterxml.jackson.databind.introspect.AccessorNamingStrategy;
/*      */ import com.fasterxml.jackson.databind.introspect.BasicClassIntrospector;
/*      */ import com.fasterxml.jackson.databind.introspect.ClassIntrospector;
/*      */ import com.fasterxml.jackson.databind.introspect.DefaultAccessorNamingStrategy;
/*      */ import com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.introspect.SimpleMixInResolver;
/*      */ import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
/*      */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*      */ import com.fasterxml.jackson.databind.jsonschema.JsonSchema;
/*      */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*      */ import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
/*      */ import com.fasterxml.jackson.databind.jsontype.SubtypeResolver;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*      */ import com.fasterxml.jackson.databind.jsontype.impl.LaissezFaireSubTypeValidator;
/*      */ import com.fasterxml.jackson.databind.jsontype.impl.StdSubtypeResolver;
/*      */ import com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder;
/*      */ import com.fasterxml.jackson.databind.node.ArrayNode;
/*      */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*      */ import com.fasterxml.jackson.databind.node.NullNode;
/*      */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*      */ import com.fasterxml.jackson.databind.node.POJONode;
/*      */ import com.fasterxml.jackson.databind.node.TreeTraversingParser;
/*      */ import com.fasterxml.jackson.databind.ser.BeanSerializerFactory;
/*      */ import com.fasterxml.jackson.databind.ser.BeanSerializerModifier;
/*      */ import com.fasterxml.jackson.databind.ser.DefaultSerializerProvider;
/*      */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*      */ import com.fasterxml.jackson.databind.ser.SerializerFactory;
/*      */ import com.fasterxml.jackson.databind.ser.Serializers;
/*      */ import com.fasterxml.jackson.databind.type.LogicalType;
/*      */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*      */ import com.fasterxml.jackson.databind.type.TypeModifier;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.RootNameLookup;
/*      */ import com.fasterxml.jackson.databind.util.StdDateFormat;
/*      */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*      */ import java.io.Closeable;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.io.Writer;
/*      */ import java.lang.reflect.Type;
/*      */ import java.net.URL;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.text.DateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.ServiceLoader;
/*      */ import java.util.Set;
/*      */ import java.util.TimeZone;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ObjectMapper
/*      */   extends ObjectCodec
/*      */   implements Versioned, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 2L;
/*      */   
/*      */   public enum DefaultTyping
/*      */   {
/*  161 */     JAVA_LANG_OBJECT,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  171 */     OBJECT_AND_NON_CONCRETE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  180 */     NON_CONCRETE_AND_ARRAYS,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  191 */     NON_FINAL,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  201 */     NON_FINAL_AND_ENUMS,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  227 */     EVERYTHING;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DefaultTypeResolverBuilder
/*      */     extends StdTypeResolverBuilder
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final ObjectMapper.DefaultTyping _appliesFor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final PolymorphicTypeValidator _subtypeValidator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public DefaultTypeResolverBuilder(ObjectMapper.DefaultTyping t) {
/*  266 */       this(t, (PolymorphicTypeValidator)LaissezFaireSubTypeValidator.instance);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DefaultTypeResolverBuilder(ObjectMapper.DefaultTyping t, PolymorphicTypeValidator ptv) {
/*  273 */       this._appliesFor = _requireNonNull(t, "Can not pass `null` DefaultTyping");
/*  274 */       this._subtypeValidator = _requireNonNull(ptv, "Can not pass `null` PolymorphicTypeValidator");
/*      */     }
/*      */ 
/*      */     
/*      */     protected DefaultTypeResolverBuilder(DefaultTypeResolverBuilder base, Class<?> defaultImpl) {
/*  279 */       super(base, defaultImpl);
/*  280 */       this._appliesFor = base._appliesFor;
/*  281 */       this._subtypeValidator = base._subtypeValidator;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static <T> T _requireNonNull(T value, String msg) {
/*  287 */       if (value == null) {
/*  288 */         throw new NullPointerException(msg);
/*      */       }
/*  290 */       return value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static DefaultTypeResolverBuilder construct(ObjectMapper.DefaultTyping t, PolymorphicTypeValidator ptv) {
/*  298 */       return new DefaultTypeResolverBuilder(t, ptv);
/*      */     }
/*      */ 
/*      */     
/*      */     public DefaultTypeResolverBuilder withDefaultImpl(Class<?> defaultImpl) {
/*  303 */       if (this._defaultImpl == defaultImpl) {
/*  304 */         return this;
/*      */       }
/*  306 */       ClassUtil.verifyMustOverride(DefaultTypeResolverBuilder.class, this, "withDefaultImpl");
/*  307 */       return new DefaultTypeResolverBuilder(this, defaultImpl);
/*      */     }
/*      */ 
/*      */     
/*      */     public PolymorphicTypeValidator subTypeValidator(MapperConfig<?> config) {
/*  312 */       return this._subtypeValidator;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeDeserializer buildTypeDeserializer(DeserializationConfig config, JavaType baseType, Collection<NamedType> subtypes) {
/*  319 */       return useForType(baseType) ? super.buildTypeDeserializer(config, baseType, subtypes) : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public TypeSerializer buildTypeSerializer(SerializationConfig config, JavaType baseType, Collection<NamedType> subtypes) {
/*  326 */       return useForType(baseType) ? super.buildTypeSerializer(config, baseType, subtypes) : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean useForType(JavaType t) {
/*  341 */       if (t.isPrimitive()) {
/*  342 */         return false;
/*      */       }
/*      */       
/*  345 */       switch (this._appliesFor) {
/*      */         case NON_CONCRETE_AND_ARRAYS:
/*  347 */           while (t.isArrayType()) {
/*  348 */             t = t.getContentType();
/*      */           }
/*      */ 
/*      */         
/*      */         case OBJECT_AND_NON_CONCRETE:
/*  353 */           while (t.isReferenceType()) {
/*  354 */             t = t.getReferencedType();
/*      */           }
/*  356 */           return (t.isJavaLangObject() || (
/*  357 */             !t.isConcrete() && 
/*      */             
/*  359 */             !TreeNode.class.isAssignableFrom(t.getRawClass())));
/*      */         
/*      */         case NON_FINAL:
/*  362 */           while (t.isArrayType()) {
/*  363 */             t = t.getContentType();
/*      */           }
/*      */           
/*  366 */           while (t.isReferenceType()) {
/*  367 */             t = t.getReferencedType();
/*      */           }
/*      */           
/*  370 */           return (!t.isFinal() && !TreeNode.class.isAssignableFrom(t.getRawClass()));
/*      */         
/*      */         case NON_FINAL_AND_ENUMS:
/*  373 */           while (t.isArrayType()) {
/*  374 */             t = t.getContentType();
/*      */           }
/*      */           
/*  377 */           while (t.isReferenceType()) {
/*  378 */             t = t.getReferencedType();
/*      */           }
/*      */           
/*  381 */           return ((!t.isFinal() && !TreeNode.class.isAssignableFrom(t.getRawClass())) || t
/*      */             
/*  383 */             .isEnumType());
/*      */ 
/*      */ 
/*      */         
/*      */         case EVERYTHING:
/*  388 */           return true;
/*      */       } 
/*      */       
/*  391 */       return t.isJavaLangObject();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  403 */   protected static final AnnotationIntrospector DEFAULT_ANNOTATION_INTROSPECTOR = (AnnotationIntrospector)new JacksonAnnotationIntrospector();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  409 */   protected static final BaseSettings DEFAULT_BASE = new BaseSettings(null, DEFAULT_ANNOTATION_INTROSPECTOR, null, null, 
/*      */ 
/*      */       
/*  412 */       TypeFactory.defaultInstance(), null, (DateFormat)StdDateFormat.instance, null, 
/*      */       
/*  414 */       Locale.getDefault(), null, 
/*      */       
/*  416 */       Base64Variants.getDefaultVariant(), (PolymorphicTypeValidator)LaissezFaireSubTypeValidator.instance, (AccessorNamingStrategy.Provider)new DefaultAccessorNamingStrategy.Provider(), 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  422 */       DefaultCacheProvider.defaultInstance());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonFactory _jsonFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TypeFactory _typeFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InjectableValues _injectableValues;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SubtypeResolver _subtypeResolver;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ConfigOverrides _configOverrides;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final CoercionConfigs _coercionConfigs;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SimpleMixInResolver _mixIns;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SerializationConfig _serializationConfig;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DefaultSerializerProvider _serializerProvider;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SerializerFactory _serializerFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DeserializationConfig _deserializationConfig;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DefaultDeserializationContext _deserializationContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Set<Object> _registeredModuleTypes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  584 */   protected final ConcurrentHashMap<JavaType, JsonDeserializer<Object>> _rootDeserializers = new ConcurrentHashMap<>(64, 0.6F, 2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper() {
/*  606 */     this(null, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper(JsonFactory jf) {
/*  615 */     this(jf, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectMapper(ObjectMapper src) {
/*  625 */     this(src, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectMapper(ObjectMapper src, JsonFactory factory) {
/*  635 */     this._jsonFactory = (factory != null) ? factory : src._jsonFactory.copy();
/*  636 */     this._jsonFactory.setCodec(this);
/*  637 */     this._subtypeResolver = src._subtypeResolver.copy();
/*  638 */     this._typeFactory = src._typeFactory;
/*  639 */     this._injectableValues = src._injectableValues;
/*  640 */     this._configOverrides = src._configOverrides.copy();
/*  641 */     this._coercionConfigs = src._coercionConfigs.copy();
/*  642 */     this._mixIns = src._mixIns.copy();
/*      */     
/*  644 */     RootNameLookup rootNames = new RootNameLookup();
/*  645 */     this._serializationConfig = new SerializationConfig(src._serializationConfig, this._subtypeResolver, this._mixIns, rootNames, this._configOverrides);
/*      */     
/*  647 */     this._deserializationConfig = new DeserializationConfig(src._deserializationConfig, this._subtypeResolver, this._mixIns, rootNames, this._configOverrides, this._coercionConfigs);
/*      */ 
/*      */     
/*  650 */     this._serializerProvider = src._serializerProvider.copy();
/*  651 */     this._deserializationContext = src._deserializationContext.copy();
/*      */ 
/*      */     
/*  654 */     this._serializerFactory = src._serializerFactory;
/*      */ 
/*      */     
/*  657 */     Set<Object> reg = src._registeredModuleTypes;
/*  658 */     if (reg == null) {
/*  659 */       this._registeredModuleTypes = null;
/*      */     } else {
/*  661 */       this._registeredModuleTypes = new LinkedHashSet(reg);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper(JsonFactory jf, DefaultSerializerProvider sp, DefaultDeserializationContext dc) {
/*  682 */     if (jf == null) {
/*  683 */       this._jsonFactory = new MappingJsonFactory(this);
/*      */     } else {
/*  685 */       this._jsonFactory = jf;
/*  686 */       if (jf.getCodec() == null) {
/*  687 */         this._jsonFactory.setCodec(this);
/*      */       }
/*      */     } 
/*  690 */     this._subtypeResolver = (SubtypeResolver)new StdSubtypeResolver();
/*  691 */     RootNameLookup rootNames = new RootNameLookup();
/*      */     
/*  693 */     this._typeFactory = TypeFactory.defaultInstance();
/*      */     
/*  695 */     SimpleMixInResolver mixins = new SimpleMixInResolver(null);
/*  696 */     this._mixIns = mixins;
/*  697 */     BaseSettings base = DEFAULT_BASE.withClassIntrospector(defaultClassIntrospector());
/*  698 */     this._configOverrides = new ConfigOverrides();
/*  699 */     this._coercionConfigs = new CoercionConfigs();
/*  700 */     this
/*      */       
/*  702 */       ._serializationConfig = new SerializationConfig(base, this._subtypeResolver, mixins, rootNames, this._configOverrides, DatatypeFeatures.defaultFeatures());
/*  703 */     this
/*      */ 
/*      */       
/*  706 */       ._deserializationConfig = new DeserializationConfig(base, this._subtypeResolver, mixins, rootNames, this._configOverrides, this._coercionConfigs, DatatypeFeatures.defaultFeatures());
/*      */ 
/*      */     
/*  709 */     boolean needOrder = this._jsonFactory.requiresPropertyOrdering();
/*  710 */     if (needOrder ^ this._serializationConfig.isEnabled(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY)) {
/*  711 */       configure(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY, needOrder);
/*      */     }
/*      */     
/*  714 */     this._serializerProvider = (sp == null) ? (DefaultSerializerProvider)new DefaultSerializerProvider.Impl() : sp;
/*  715 */     this._deserializationContext = (dc == null) ? (DefaultDeserializationContext)new DefaultDeserializationContext.Impl((DeserializerFactory)BeanDeserializerFactory.instance) : dc;
/*      */ 
/*      */ 
/*      */     
/*  719 */     this._serializerFactory = (SerializerFactory)BeanSerializerFactory.instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ClassIntrospector defaultClassIntrospector() {
/*  729 */     return (ClassIntrospector)new BasicClassIntrospector();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper copy() {
/*  754 */     _checkInvalidCopy(ObjectMapper.class);
/*  755 */     return new ObjectMapper(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper copyWith(JsonFactory factory) {
/*  768 */     _checkInvalidCopy(ObjectMapper.class);
/*  769 */     return new ObjectMapper(this, factory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _checkInvalidCopy(Class<?> exp) {
/*  777 */     if (getClass() != exp)
/*      */     {
/*  779 */       throw new IllegalStateException("Failed copy()/copyWith(): " + getClass().getName() + " (version: " + 
/*  780 */           version() + ") does not override copy()/copyWith(); it has to");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader _newReader(DeserializationConfig config) {
/*  798 */     return new ObjectReader(this, config);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectReader _newReader(DeserializationConfig config, JavaType valueType, Object valueToUpdate, FormatSchema schema, InjectableValues injectableValues) {
/*  810 */     return new ObjectReader(this, config, valueType, valueToUpdate, schema, injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectWriter _newWriter(SerializationConfig config) {
/*  820 */     return new ObjectWriter(this, config);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectWriter _newWriter(SerializationConfig config, FormatSchema schema) {
/*  830 */     return new ObjectWriter(this, config, schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectWriter _newWriter(SerializationConfig config, JavaType rootType, PrettyPrinter pp) {
/*  841 */     return new ObjectWriter(this, config, rootType, pp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Version version() {
/*  856 */     return PackageVersion.VERSION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper registerModule(Module module) {
/*  874 */     _assertNotNull("module", module);
/*      */ 
/*      */ 
/*      */     
/*  878 */     String name = module.getModuleName();
/*  879 */     if (name == null) {
/*  880 */       throw new IllegalArgumentException("Module without defined name");
/*      */     }
/*  882 */     Version version = module.version();
/*  883 */     if (version == null) {
/*  884 */       throw new IllegalArgumentException("Module without defined version");
/*      */     }
/*      */ 
/*      */     
/*  888 */     for (Module dep : module.getDependencies()) {
/*  889 */       registerModule(dep);
/*      */     }
/*      */ 
/*      */     
/*  893 */     if (isEnabled(MapperFeature.IGNORE_DUPLICATE_MODULE_REGISTRATIONS)) {
/*  894 */       Object typeId = module.getTypeId();
/*  895 */       if (typeId != null) {
/*  896 */         if (this._registeredModuleTypes == null)
/*      */         {
/*      */           
/*  899 */           this._registeredModuleTypes = new LinkedHashSet();
/*      */         }
/*      */         
/*  902 */         if (!this._registeredModuleTypes.add(typeId)) {
/*  903 */           return this;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  909 */     module.setupModule(new Module.SetupContext()
/*      */         {
/*      */ 
/*      */           
/*      */           public Version getMapperVersion()
/*      */           {
/*  915 */             return ObjectMapper.this.version();
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public <C extends ObjectCodec> C getOwner() {
/*  922 */             return (C)ObjectMapper.this;
/*      */           }
/*      */ 
/*      */           
/*      */           public TypeFactory getTypeFactory() {
/*  927 */             return ObjectMapper.this._typeFactory;
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean isEnabled(MapperFeature f) {
/*  932 */             return ObjectMapper.this.isEnabled(f);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean isEnabled(DeserializationFeature f) {
/*  937 */             return ObjectMapper.this.isEnabled(f);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean isEnabled(SerializationFeature f) {
/*  942 */             return ObjectMapper.this.isEnabled(f);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean isEnabled(JsonFactory.Feature f) {
/*  947 */             return ObjectMapper.this.isEnabled(f);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean isEnabled(JsonParser.Feature f) {
/*  952 */             return ObjectMapper.this.isEnabled(f);
/*      */           }
/*      */ 
/*      */           
/*      */           public boolean isEnabled(JsonGenerator.Feature f) {
/*  957 */             return ObjectMapper.this.isEnabled(f);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public MutableConfigOverride configOverride(Class<?> type) {
/*  964 */             return ObjectMapper.this.configOverride(type);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void addDeserializers(Deserializers d) {
/*  971 */             DeserializerFactory df = ObjectMapper.this._deserializationContext._factory.withAdditionalDeserializers(d);
/*  972 */             ObjectMapper.this._deserializationContext = ObjectMapper.this._deserializationContext.with(df);
/*      */           }
/*      */ 
/*      */           
/*      */           public void addKeyDeserializers(KeyDeserializers d) {
/*  977 */             DeserializerFactory df = ObjectMapper.this._deserializationContext._factory.withAdditionalKeyDeserializers(d);
/*  978 */             ObjectMapper.this._deserializationContext = ObjectMapper.this._deserializationContext.with(df);
/*      */           }
/*      */ 
/*      */           
/*      */           public void addBeanDeserializerModifier(BeanDeserializerModifier modifier) {
/*  983 */             DeserializerFactory df = ObjectMapper.this._deserializationContext._factory.withDeserializerModifier(modifier);
/*  984 */             ObjectMapper.this._deserializationContext = ObjectMapper.this._deserializationContext.with(df);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void addSerializers(Serializers s) {
/*  991 */             ObjectMapper.this._serializerFactory = ObjectMapper.this._serializerFactory.withAdditionalSerializers(s);
/*      */           }
/*      */ 
/*      */           
/*      */           public void addKeySerializers(Serializers s) {
/*  996 */             ObjectMapper.this._serializerFactory = ObjectMapper.this._serializerFactory.withAdditionalKeySerializers(s);
/*      */           }
/*      */ 
/*      */           
/*      */           public void addBeanSerializerModifier(BeanSerializerModifier modifier) {
/* 1001 */             ObjectMapper.this._serializerFactory = ObjectMapper.this._serializerFactory.withSerializerModifier(modifier);
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           public void addAbstractTypeResolver(AbstractTypeResolver resolver) {
/* 1008 */             DeserializerFactory df = ObjectMapper.this._deserializationContext._factory.withAbstractTypeResolver(resolver);
/* 1009 */             ObjectMapper.this._deserializationContext = ObjectMapper.this._deserializationContext.with(df);
/*      */           }
/*      */ 
/*      */           
/*      */           public void addTypeModifier(TypeModifier modifier) {
/* 1014 */             TypeFactory f = ObjectMapper.this._typeFactory;
/* 1015 */             f = f.withModifier(modifier);
/* 1016 */             ObjectMapper.this.setTypeFactory(f);
/*      */           }
/*      */ 
/*      */           
/*      */           public void addValueInstantiators(ValueInstantiators instantiators) {
/* 1021 */             DeserializerFactory df = ObjectMapper.this._deserializationContext._factory.withValueInstantiators(instantiators);
/* 1022 */             ObjectMapper.this._deserializationContext = ObjectMapper.this._deserializationContext.with(df);
/*      */           }
/*      */ 
/*      */           
/*      */           public void setClassIntrospector(ClassIntrospector ci) {
/* 1027 */             ObjectMapper.this._deserializationConfig = (DeserializationConfig)ObjectMapper.this._deserializationConfig.with(ci);
/* 1028 */             ObjectMapper.this._serializationConfig = (SerializationConfig)ObjectMapper.this._serializationConfig.with(ci);
/*      */           }
/*      */ 
/*      */           
/*      */           public void insertAnnotationIntrospector(AnnotationIntrospector ai) {
/* 1033 */             ObjectMapper.this._deserializationConfig = (DeserializationConfig)ObjectMapper.this._deserializationConfig.withInsertedAnnotationIntrospector(ai);
/* 1034 */             ObjectMapper.this._serializationConfig = (SerializationConfig)ObjectMapper.this._serializationConfig.withInsertedAnnotationIntrospector(ai);
/*      */           }
/*      */ 
/*      */           
/*      */           public void appendAnnotationIntrospector(AnnotationIntrospector ai) {
/* 1039 */             ObjectMapper.this._deserializationConfig = (DeserializationConfig)ObjectMapper.this._deserializationConfig.withAppendedAnnotationIntrospector(ai);
/* 1040 */             ObjectMapper.this._serializationConfig = (SerializationConfig)ObjectMapper.this._serializationConfig.withAppendedAnnotationIntrospector(ai);
/*      */           }
/*      */ 
/*      */           
/*      */           public void registerSubtypes(Class<?>... subtypes) {
/* 1045 */             ObjectMapper.this.registerSubtypes(subtypes);
/*      */           }
/*      */ 
/*      */           
/*      */           public void registerSubtypes(NamedType... subtypes) {
/* 1050 */             ObjectMapper.this.registerSubtypes(subtypes);
/*      */           }
/*      */ 
/*      */           
/*      */           public void registerSubtypes(Collection<Class<?>> subtypes) {
/* 1055 */             ObjectMapper.this.registerSubtypes(subtypes);
/*      */           }
/*      */ 
/*      */           
/*      */           public void setMixInAnnotations(Class<?> target, Class<?> mixinSource) {
/* 1060 */             ObjectMapper.this.addMixIn(target, mixinSource);
/*      */           }
/*      */ 
/*      */           
/*      */           public void addDeserializationProblemHandler(DeserializationProblemHandler handler) {
/* 1065 */             ObjectMapper.this.addHandler(handler);
/*      */           }
/*      */ 
/*      */           
/*      */           public void setNamingStrategy(PropertyNamingStrategy naming) {
/* 1070 */             ObjectMapper.this.setPropertyNamingStrategy(naming);
/*      */           }
/*      */         });
/*      */     
/* 1074 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper registerModules(Module... modules) {
/* 1090 */     for (Module module : modules) {
/* 1091 */       registerModule(module);
/*      */     }
/* 1093 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper registerModules(Iterable<? extends Module> modules) {
/* 1109 */     _assertNotNull("modules", modules);
/* 1110 */     for (Module module : modules) {
/* 1111 */       registerModule(module);
/*      */     }
/* 1113 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<Object> getRegisteredModuleIds() {
/* 1131 */     return (this._registeredModuleTypes == null) ? 
/* 1132 */       Collections.<Object>emptySet() : Collections.<Object>unmodifiableSet(this._registeredModuleTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Module> findModules() {
/* 1145 */     return findModules(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Module> findModules(ClassLoader classLoader) {
/* 1159 */     ArrayList<Module> modules = new ArrayList<>();
/* 1160 */     ServiceLoader<Module> loader = secureGetServiceLoader(Module.class, classLoader);
/* 1161 */     for (Module module : loader) {
/* 1162 */       modules.add(module);
/*      */     }
/* 1164 */     return modules;
/*      */   }
/*      */   
/*      */   private static <T> ServiceLoader<T> secureGetServiceLoader(final Class<T> clazz, final ClassLoader classLoader) {
/* 1168 */     SecurityManager sm = System.getSecurityManager();
/* 1169 */     if (sm == null) {
/* 1170 */       return (classLoader == null) ? 
/* 1171 */         ServiceLoader.<T>load(clazz) : ServiceLoader.<T>load(clazz, classLoader);
/*      */     }
/* 1173 */     return AccessController.<ServiceLoader<T>>doPrivileged((PrivilegedAction)new PrivilegedAction<ServiceLoader<ServiceLoader<T>>>()
/*      */         {
/*      */           public ServiceLoader<T> run() {
/* 1176 */             return (classLoader == null) ? 
/* 1177 */               ServiceLoader.<T>load(clazz) : ServiceLoader.<T>load(clazz, classLoader);
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper findAndRegisterModules() {
/* 1195 */     return registerModules(findModules());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(OutputStream out) throws IOException {
/* 1213 */     _assertNotNull("out", out);
/* 1214 */     JsonGenerator g = this._jsonFactory.createGenerator(out, JsonEncoding.UTF8);
/* 1215 */     this._serializationConfig.initialize(g);
/* 1216 */     return g;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(OutputStream out, JsonEncoding enc) throws IOException {
/* 1228 */     _assertNotNull("out", out);
/* 1229 */     JsonGenerator g = this._jsonFactory.createGenerator(out, enc);
/* 1230 */     this._serializationConfig.initialize(g);
/* 1231 */     return g;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(Writer w) throws IOException {
/* 1243 */     _assertNotNull("w", w);
/* 1244 */     JsonGenerator g = this._jsonFactory.createGenerator(w);
/* 1245 */     this._serializationConfig.initialize(g);
/* 1246 */     return g;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(File outputFile, JsonEncoding enc) throws IOException {
/* 1258 */     _assertNotNull("outputFile", outputFile);
/* 1259 */     JsonGenerator g = this._jsonFactory.createGenerator(outputFile, enc);
/* 1260 */     this._serializationConfig.initialize(g);
/* 1261 */     return g;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(DataOutput out) throws IOException {
/* 1273 */     _assertNotNull("out", out);
/* 1274 */     JsonGenerator g = this._jsonFactory.createGenerator(out);
/* 1275 */     this._serializationConfig.initialize(g);
/* 1276 */     return g;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(File src) throws IOException {
/* 1294 */     _assertNotNull("src", src);
/* 1295 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(src));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(URL src) throws IOException {
/* 1307 */     _assertNotNull("src", src);
/* 1308 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(src));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(InputStream in) throws IOException {
/* 1320 */     _assertNotNull("in", in);
/* 1321 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(in));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(Reader r) throws IOException {
/* 1333 */     _assertNotNull("r", r);
/* 1334 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(r));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(byte[] content) throws IOException {
/* 1346 */     _assertNotNull("content", content);
/* 1347 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(byte[] content, int offset, int len) throws IOException {
/* 1359 */     _assertNotNull("content", content);
/* 1360 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content, offset, len));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(String content) throws IOException {
/* 1372 */     _assertNotNull("content", content);
/* 1373 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(char[] content) throws IOException {
/* 1385 */     _assertNotNull("content", content);
/* 1386 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(char[] content, int offset, int len) throws IOException {
/* 1398 */     _assertNotNull("content", content);
/* 1399 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content, offset, len));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(DataInput content) throws IOException {
/* 1411 */     _assertNotNull("content", content);
/* 1412 */     return this._deserializationConfig.initialize(this._jsonFactory.createParser(content));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createNonBlockingByteArrayParser() throws IOException {
/* 1424 */     return this._deserializationConfig.initialize(this._jsonFactory.createNonBlockingByteArrayParser());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SerializationConfig getSerializationConfig() {
/* 1442 */     return this._serializationConfig;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationConfig getDeserializationConfig() {
/* 1455 */     return this._deserializationConfig;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializationContext getDeserializationContext() {
/* 1466 */     return (DeserializationContext)this._deserializationContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setSerializerFactory(SerializerFactory f) {
/* 1480 */     this._serializerFactory = f;
/* 1481 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SerializerFactory getSerializerFactory() {
/* 1492 */     return this._serializerFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setSerializerProvider(DefaultSerializerProvider p) {
/* 1501 */     this._serializerProvider = p;
/* 1502 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SerializerProvider getSerializerProvider() {
/* 1513 */     return (SerializerProvider)this._serializerProvider;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SerializerProvider getSerializerProviderInstance() {
/* 1525 */     return (SerializerProvider)_serializerProvider(this._serializationConfig);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setMixIns(Map<Class<?>, Class<?>> sourceMixins) {
/* 1554 */     this._mixIns.setLocalDefinitions(sourceMixins);
/* 1555 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper addMixIn(Class<?> target, Class<?> mixinSource) {
/* 1572 */     this._mixIns.addLocalDefinition(target, mixinSource);
/* 1573 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setMixInResolver(ClassIntrospector.MixInResolver resolver) {
/* 1586 */     SimpleMixInResolver r = this._mixIns.withOverrides(resolver);
/* 1587 */     if (r != this._mixIns) {
/* 1588 */       this._mixIns = r;
/* 1589 */       this._deserializationConfig = new DeserializationConfig(this._deserializationConfig, r);
/* 1590 */       this._serializationConfig = new SerializationConfig(this._serializationConfig, r);
/*      */     } 
/* 1592 */     return this;
/*      */   }
/*      */   
/*      */   public Class<?> findMixInClassFor(Class<?> cls) {
/* 1596 */     return this._mixIns.findMixInClassFor(cls);
/*      */   }
/*      */ 
/*      */   
/*      */   public int mixInCount() {
/* 1601 */     return this._mixIns.localSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setMixInAnnotations(Map<Class<?>, Class<?>> sourceMixins) {
/* 1609 */     setMixIns(sourceMixins);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final void addMixInAnnotations(Class<?> target, Class<?> mixinSource) {
/* 1617 */     addMixIn(target, mixinSource);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VisibilityChecker<?> getVisibilityChecker() {
/* 1632 */     return this._serializationConfig.getDefaultVisibilityChecker();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setVisibility(VisibilityChecker<?> vc) {
/* 1646 */     this._configOverrides.setDefaultVisibility(vc);
/* 1647 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setVisibility(PropertyAccessor forMethod, JsonAutoDetect.Visibility visibility) {
/* 1676 */     VisibilityChecker<?> vc = this._configOverrides.getDefaultVisibility();
/* 1677 */     vc = vc.withVisibility(forMethod, visibility);
/* 1678 */     this._configOverrides.setDefaultVisibility(vc);
/* 1679 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SubtypeResolver getSubtypeResolver() {
/* 1686 */     return this._subtypeResolver;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setSubtypeResolver(SubtypeResolver str) {
/* 1693 */     this._subtypeResolver = str;
/* 1694 */     this._deserializationConfig = this._deserializationConfig.with(str);
/* 1695 */     this._serializationConfig = this._serializationConfig.with(str);
/* 1696 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setAnnotationIntrospector(AnnotationIntrospector ai) {
/* 1710 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(ai);
/* 1711 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(ai);
/* 1712 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setAnnotationIntrospectors(AnnotationIntrospector serializerAI, AnnotationIntrospector deserializerAI) {
/* 1732 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(serializerAI);
/* 1733 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(deserializerAI);
/* 1734 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setPropertyNamingStrategy(PropertyNamingStrategy s) {
/* 1741 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(s);
/* 1742 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(s);
/* 1743 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PropertyNamingStrategy getPropertyNamingStrategy() {
/* 1751 */     return this._serializationConfig.getPropertyNamingStrategy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setEnumNamingStrategy(EnumNamingStrategy s) {
/* 1760 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(s);
/* 1761 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(s);
/* 1762 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public EnumNamingStrategy getEnumNamingStrategy() {
/* 1769 */     return this._serializationConfig.getEnumNamingStrategy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setAccessorNaming(AccessorNamingStrategy.Provider s) {
/* 1778 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(s);
/* 1779 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(s);
/* 1780 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultPrettyPrinter(PrettyPrinter pp) {
/* 1794 */     this._serializationConfig = this._serializationConfig.withDefaultPrettyPrinter(pp);
/* 1795 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setVisibilityChecker(VisibilityChecker<?> vc) {
/* 1803 */     setVisibility(vc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setPolymorphicTypeValidator(PolymorphicTypeValidator ptv) {
/* 1815 */     BaseSettings s = this._deserializationConfig.getBaseSettings().with(ptv);
/* 1816 */     this._deserializationConfig = this._deserializationConfig._withBase(s);
/* 1817 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PolymorphicTypeValidator getPolymorphicTypeValidator() {
/* 1829 */     return this._deserializationConfig.getBaseSettings().getPolymorphicTypeValidator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setSerializationInclusion(JsonInclude.Include incl) {
/* 1848 */     setPropertyInclusion(JsonInclude.Value.construct(incl, incl));
/* 1849 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper setPropertyInclusion(JsonInclude.Value incl) {
/* 1858 */     return setDefaultPropertyInclusion(incl);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultPropertyInclusion(JsonInclude.Value incl) {
/* 1869 */     this._configOverrides.setDefaultInclusion(incl);
/* 1870 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultPropertyInclusion(JsonInclude.Include incl) {
/* 1882 */     this._configOverrides.setDefaultInclusion(JsonInclude.Value.construct(incl, incl));
/* 1883 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultSetterInfo(JsonSetter.Value v) {
/* 1894 */     this._configOverrides.setDefaultSetterInfo(v);
/* 1895 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultVisibility(JsonAutoDetect.Value vis) {
/* 1907 */     this._configOverrides.setDefaultVisibility((VisibilityChecker)VisibilityChecker.Std.construct(vis));
/* 1908 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultMergeable(Boolean b) {
/* 1919 */     this._configOverrides.setDefaultMergeable(b);
/* 1920 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultLeniency(Boolean b) {
/* 1927 */     this._configOverrides.setDefaultLeniency(b);
/* 1928 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerSubtypes(Class<?>... classes) {
/* 1945 */     getSubtypeResolver().registerSubtypes(classes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerSubtypes(NamedType... types) {
/* 1957 */     getSubtypeResolver().registerSubtypes(types);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerSubtypes(Collection<Class<?>> subtypes) {
/* 1964 */     getSubtypeResolver().registerSubtypes(subtypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper activateDefaultTyping(PolymorphicTypeValidator ptv) {
/* 1988 */     return activateDefaultTyping(ptv, DefaultTyping.OBJECT_AND_NON_CONCRETE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper activateDefaultTyping(PolymorphicTypeValidator ptv, DefaultTyping applicability) {
/* 2009 */     return activateDefaultTyping(ptv, applicability, JsonTypeInfo.As.WRAPPER_ARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper activateDefaultTyping(PolymorphicTypeValidator ptv, DefaultTyping applicability, JsonTypeInfo.As includeAs) {
/* 2037 */     if (includeAs == JsonTypeInfo.As.EXTERNAL_PROPERTY) {
/* 2038 */       throw new IllegalArgumentException("Cannot use includeAs of " + includeAs);
/*      */     }
/*      */     
/* 2041 */     TypeResolverBuilder<?> typer = _constructDefaultTypeResolverBuilder(applicability, ptv);
/*      */     
/* 2043 */     JsonTypeInfo.Value typeInfo = JsonTypeInfo.Value.construct(JsonTypeInfo.Id.CLASS, includeAs, null, null, false, null);
/*      */     
/* 2045 */     typer = typer.withSettings(typeInfo);
/* 2046 */     return setDefaultTyping(typer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper activateDefaultTypingAsProperty(PolymorphicTypeValidator ptv, DefaultTyping applicability, String propertyName) {
/* 2071 */     TypeResolverBuilder<?> typer = _constructDefaultTypeResolverBuilder(applicability, ptv);
/*      */ 
/*      */     
/* 2074 */     JsonTypeInfo.Value typeInfo = JsonTypeInfo.Value.construct(JsonTypeInfo.Id.CLASS, JsonTypeInfo.As.PROPERTY, propertyName, null, false, null);
/*      */     
/* 2076 */     typer = typer.withSettings(typeInfo);
/* 2077 */     return setDefaultTyping(typer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper deactivateDefaultTyping() {
/* 2089 */     return setDefaultTyping(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultTyping(TypeResolverBuilder<?> typer) {
/* 2108 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(typer);
/* 2109 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(typer);
/* 2110 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper enableDefaultTyping() {
/* 2124 */     return activateDefaultTyping(getPolymorphicTypeValidator());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper enableDefaultTyping(DefaultTyping dti) {
/* 2132 */     return enableDefaultTyping(dti, JsonTypeInfo.As.WRAPPER_ARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper enableDefaultTyping(DefaultTyping applicability, JsonTypeInfo.As includeAs) {
/* 2140 */     return activateDefaultTyping(getPolymorphicTypeValidator(), applicability, includeAs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper enableDefaultTypingAsProperty(DefaultTyping applicability, String propertyName) {
/* 2148 */     return activateDefaultTypingAsProperty(getPolymorphicTypeValidator(), applicability, propertyName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper disableDefaultTyping() {
/* 2156 */     return setDefaultTyping(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MutableConfigOverride configOverride(Class<?> type) {
/* 2183 */     return this._configOverrides.findOrCreateOverride(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MutableCoercionConfig coercionConfigDefaults() {
/* 2206 */     return this._coercionConfigs.defaultCoercions();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MutableCoercionConfig coercionConfigFor(LogicalType logicalType) {
/* 2220 */     return this._coercionConfigs.findOrCreateCoercion(logicalType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MutableCoercionConfig coercionConfigFor(Class<?> physicalType) {
/* 2234 */     return this._coercionConfigs.findOrCreateCoercion(physicalType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeFactory getTypeFactory() {
/* 2247 */     return this._typeFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setTypeFactory(TypeFactory f) {
/* 2259 */     this._typeFactory = f;
/* 2260 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(f);
/* 2261 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(f);
/* 2262 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructType(Type t) {
/* 2271 */     _assertNotNull("t", t);
/* 2272 */     return this._typeFactory.constructType(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructType(TypeReference<?> typeRef) {
/* 2282 */     _assertNotNull("typeRef", typeRef);
/* 2283 */     return this._typeFactory.constructType(typeRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNodeFactory getNodeFactory() {
/* 2303 */     return this._deserializationConfig.getNodeFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setNodeFactory(JsonNodeFactory f) {
/* 2312 */     this._deserializationConfig = this._deserializationConfig.with(f);
/* 2313 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setConstructorDetector(ConstructorDetector cd) {
/* 2325 */     this._deserializationConfig = this._deserializationConfig.with(cd);
/*      */     
/* 2327 */     this._serializationConfig = this._serializationConfig.with(cd);
/* 2328 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setCacheProvider(CacheProvider cacheProvider) {
/* 2341 */     _assertNotNull("cacheProvider", cacheProvider);
/* 2342 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(cacheProvider);
/* 2343 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(cacheProvider);
/* 2344 */     this._deserializationContext = this._deserializationContext.withCaches(cacheProvider);
/* 2345 */     this._serializerProvider = this._serializerProvider.withCaches(cacheProvider);
/* 2346 */     this._typeFactory = this._typeFactory.withCache(cacheProvider.forTypeFactory());
/* 2347 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper addHandler(DeserializationProblemHandler h) {
/* 2355 */     this._deserializationConfig = this._deserializationConfig.withHandler(h);
/* 2356 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper clearProblemHandlers() {
/* 2364 */     this._deserializationConfig = this._deserializationConfig.withNoProblemHandlers();
/* 2365 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setConfig(DeserializationConfig config) {
/* 2383 */     _assertNotNull("config", config);
/* 2384 */     this._deserializationConfig = config;
/* 2385 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setFilters(FilterProvider filterProvider) {
/* 2399 */     this._serializationConfig = this._serializationConfig.withFilters(filterProvider);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setFilterProvider(FilterProvider filterProvider) {
/* 2414 */     this._serializationConfig = this._serializationConfig.withFilters(filterProvider);
/* 2415 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setBase64Variant(Base64Variant v) {
/* 2429 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(v);
/* 2430 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(v);
/* 2431 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setConfig(SerializationConfig config) {
/* 2449 */     _assertNotNull("config", config);
/* 2450 */     this._serializationConfig = config;
/* 2451 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory tokenStreamFactory() {
/* 2479 */     return this._jsonFactory;
/*      */   }
/*      */   public JsonFactory getFactory() {
/* 2482 */     return this._jsonFactory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDateFormat(DateFormat dateFormat) {
/* 2496 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(dateFormat);
/* 2497 */     this._serializationConfig = this._serializationConfig.with(dateFormat);
/* 2498 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DateFormat getDateFormat() {
/* 2506 */     return this._serializationConfig.getDateFormat();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object setHandlerInstantiator(HandlerInstantiator hi) {
/* 2518 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(hi);
/* 2519 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(hi);
/* 2520 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setInjectableValues(InjectableValues injectableValues) {
/* 2528 */     this._injectableValues = injectableValues;
/* 2529 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InjectableValues getInjectableValues() {
/* 2536 */     return this._injectableValues;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setLocale(Locale l) {
/* 2544 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(l);
/* 2545 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(l);
/* 2546 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setTimeZone(TimeZone tz) {
/* 2554 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(tz);
/* 2555 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(tz);
/* 2556 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper setDefaultAttributes(ContextAttributes attrs) {
/* 2568 */     this._deserializationConfig = this._deserializationConfig.with(attrs);
/* 2569 */     this._serializationConfig = this._serializationConfig.with(attrs);
/* 2570 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(MapperFeature f) {
/* 2584 */     return this._serializationConfig.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper configure(MapperFeature f, boolean state) {
/* 2592 */     this
/* 2593 */       ._serializationConfig = state ? (SerializationConfig)this._serializationConfig.with(new MapperFeature[] { f }) : (SerializationConfig)this._serializationConfig.without(new MapperFeature[] { f });
/* 2594 */     this
/* 2595 */       ._deserializationConfig = state ? (DeserializationConfig)this._deserializationConfig.with(new MapperFeature[] { f }) : (DeserializationConfig)this._deserializationConfig.without(new MapperFeature[] { f });
/* 2596 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper enable(MapperFeature... f) {
/* 2604 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(f);
/* 2605 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.with(f);
/* 2606 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectMapper disable(MapperFeature... f) {
/* 2614 */     this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.without(f);
/* 2615 */     this._serializationConfig = (SerializationConfig)this._serializationConfig.without(f);
/* 2616 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(SerializationFeature f) {
/* 2630 */     return this._serializationConfig.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper configure(SerializationFeature f, boolean state) {
/* 2645 */     this
/* 2646 */       ._serializationConfig = state ? this._serializationConfig.with(f) : this._serializationConfig.without(f);
/* 2647 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper enable(SerializationFeature f) {
/* 2662 */     this._serializationConfig = this._serializationConfig.with(f);
/* 2663 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper enable(SerializationFeature first, SerializationFeature... f) {
/* 2679 */     this._serializationConfig = this._serializationConfig.with(first, f);
/* 2680 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper disable(SerializationFeature f) {
/* 2695 */     this._serializationConfig = this._serializationConfig.without(f);
/* 2696 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper disable(SerializationFeature first, SerializationFeature... f) {
/* 2712 */     this._serializationConfig = this._serializationConfig.without(first, f);
/* 2713 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(DeserializationFeature f) {
/* 2727 */     return this._deserializationConfig.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper configure(DeserializationFeature f, boolean state) {
/* 2742 */     this
/* 2743 */       ._deserializationConfig = state ? this._deserializationConfig.with(f) : this._deserializationConfig.without(f);
/* 2744 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper enable(DeserializationFeature feature) {
/* 2759 */     this._deserializationConfig = this._deserializationConfig.with(feature);
/* 2760 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper enable(DeserializationFeature first, DeserializationFeature... f) {
/* 2776 */     this._deserializationConfig = this._deserializationConfig.with(first, f);
/* 2777 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper disable(DeserializationFeature feature) {
/* 2792 */     this._deserializationConfig = this._deserializationConfig.without(feature);
/* 2793 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper disable(DeserializationFeature first, DeserializationFeature... f) {
/* 2809 */     this._deserializationConfig = this._deserializationConfig.without(first, f);
/* 2810 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper configure(DatatypeFeature f, boolean state) {
/* 2831 */     if (state) {
/* 2832 */       this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.with(f);
/* 2833 */       this._serializationConfig = (SerializationConfig)this._serializationConfig.with(f);
/*      */     } else {
/* 2835 */       this._deserializationConfig = (DeserializationConfig)this._deserializationConfig.without(f);
/* 2836 */       this._serializationConfig = (SerializationConfig)this._serializationConfig.without(f);
/*      */     } 
/* 2838 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(JsonParser.Feature f) {
/* 2848 */     return this._deserializationConfig.isEnabled(f, this._jsonFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper configure(JsonParser.Feature f, boolean state) {
/* 2866 */     this._jsonFactory.configure(f, state);
/* 2867 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper enable(JsonParser.Feature... features) {
/* 2886 */     for (JsonParser.Feature f : features) {
/* 2887 */       this._jsonFactory.enable(f);
/*      */     }
/* 2889 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper disable(JsonParser.Feature... features) {
/* 2908 */     for (JsonParser.Feature f : features) {
/* 2909 */       this._jsonFactory.disable(f);
/*      */     }
/* 2911 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(JsonGenerator.Feature f) {
/* 2921 */     return this._serializationConfig.isEnabled(f, this._jsonFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper configure(JsonGenerator.Feature f, boolean state) {
/* 2939 */     this._jsonFactory.configure(f, state);
/* 2940 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper enable(JsonGenerator.Feature... features) {
/* 2959 */     for (JsonGenerator.Feature f : features) {
/* 2960 */       this._jsonFactory.enable(f);
/*      */     }
/* 2962 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectMapper disable(JsonGenerator.Feature... features) {
/* 2981 */     for (JsonGenerator.Feature f : features) {
/* 2982 */       this._jsonFactory.disable(f);
/*      */     }
/* 2984 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(JsonFactory.Feature f) {
/* 3000 */     return this._jsonFactory.isEnabled(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(StreamReadFeature f) {
/* 3013 */     return isEnabled(f.mappedFeature());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(StreamWriteFeature f) {
/* 3020 */     return isEnabled(f.mappedFeature());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, Class<T> valueType) throws IOException, StreamReadException, DatabindException {
/* 3054 */     _assertNotNull("p", p);
/* 3055 */     return (T)_readValue(getDeserializationConfig(), p, this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, TypeReference<T> valueTypeRef) throws IOException, StreamReadException, DatabindException {
/* 3079 */     _assertNotNull("p", p);
/* 3080 */     return (T)_readValue(getDeserializationConfig(), p, this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final <T> T readValue(JsonParser p, ResolvedType valueType) throws IOException, StreamReadException, DatabindException {
/* 3103 */     _assertNotNull("p", p);
/* 3104 */     return (T)_readValue(getDeserializationConfig(), p, (JavaType)valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(JsonParser p, JavaType valueType) throws IOException, StreamReadException, DatabindException {
/* 3123 */     _assertNotNull("p", p);
/* 3124 */     return (T)_readValue(getDeserializationConfig(), p, valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends TreeNode> T readTree(JsonParser p) throws IOException {
/*      */     NullNode nullNode;
/* 3154 */     _assertNotNull("p", p);
/*      */     
/* 3156 */     DeserializationConfig cfg = getDeserializationConfig();
/* 3157 */     JsonToken t = p.currentToken();
/* 3158 */     if (t == null) {
/* 3159 */       t = p.nextToken();
/* 3160 */       if (t == null) {
/* 3161 */         return null;
/*      */       }
/*      */     } 
/*      */     
/* 3165 */     JsonNode n = (JsonNode)_readValue(cfg, p, constructType(JsonNode.class));
/* 3166 */     if (n == null) {
/* 3167 */       nullNode = getNodeFactory().nullNode();
/*      */     }
/*      */     
/* 3170 */     return (T)nullNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(JsonParser p, ResolvedType valueType) throws IOException {
/* 3196 */     return readValues(p, (JavaType)valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(JsonParser p, JavaType valueType) throws IOException {
/* 3210 */     _assertNotNull("p", p);
/* 3211 */     DeserializationConfig config = getDeserializationConfig();
/* 3212 */     DefaultDeserializationContext defaultDeserializationContext = createDeserializationContext(p, config);
/* 3213 */     JsonDeserializer<?> deser = _findRootDeserializer((DeserializationContext)defaultDeserializationContext, valueType);
/*      */     
/* 3215 */     return new MappingIterator<>(valueType, p, (DeserializationContext)defaultDeserializationContext, deser, false, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(JsonParser p, Class<T> valueType) throws IOException {
/* 3231 */     return readValues(p, this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> MappingIterator<T> readValues(JsonParser p, TypeReference<T> valueTypeRef) throws IOException {
/* 3241 */     return readValues(p, this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(InputStream in) throws IOException {
/* 3279 */     _assertNotNull("in", in);
/* 3280 */     return _readTreeAndClose(this._jsonFactory.createParser(in));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(Reader r) throws IOException {
/* 3288 */     _assertNotNull("r", r);
/* 3289 */     return _readTreeAndClose(this._jsonFactory.createParser(r));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(String content) throws JsonProcessingException, JsonMappingException {
/* 3298 */     _assertNotNull("content", content);
/*      */     try {
/* 3300 */       return _readTreeAndClose(this._jsonFactory.createParser(content));
/* 3301 */     } catch (JsonProcessingException e) {
/* 3302 */       throw e;
/* 3303 */     } catch (IOException e) {
/* 3304 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(byte[] content) throws IOException {
/* 3313 */     _assertNotNull("content", content);
/* 3314 */     return _readTreeAndClose(this._jsonFactory.createParser(content));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(byte[] content, int offset, int len) throws IOException {
/* 3322 */     _assertNotNull("content", content);
/* 3323 */     return _readTreeAndClose(this._jsonFactory.createParser(content, offset, len));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(File file) throws IOException {
/* 3332 */     _assertNotNull("file", file);
/* 3333 */     return _readTreeAndClose(this._jsonFactory.createParser(file));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonNode readTree(URL source) throws IOException {
/* 3348 */     _assertNotNull("source", source);
/* 3349 */     return _readTreeAndClose(this._jsonFactory.createParser(source));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeValue(JsonGenerator g, Object value) throws IOException, StreamWriteException, DatabindException {
/* 3367 */     _assertNotNull("g", g);
/* 3368 */     SerializationConfig config = getSerializationConfig();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3376 */     if (config.isEnabled(SerializationFeature.INDENT_OUTPUT) && 
/* 3377 */       g.getPrettyPrinter() == null) {
/* 3378 */       g.setPrettyPrinter(config.constructDefaultPrettyPrinter());
/*      */     }
/*      */     
/* 3381 */     if (config.isEnabled(SerializationFeature.CLOSE_CLOSEABLE) && value instanceof Closeable) {
/* 3382 */       _writeCloseableValue(g, value, config);
/*      */     } else {
/* 3384 */       _serializerProvider(config).serializeValue(g, value);
/* 3385 */       if (config.isEnabled(SerializationFeature.FLUSH_AFTER_WRITE_VALUE)) {
/* 3386 */         g.flush();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeTree(JsonGenerator g, TreeNode rootNode) throws IOException {
/* 3401 */     _assertNotNull("g", g);
/* 3402 */     SerializationConfig config = getSerializationConfig();
/* 3403 */     _serializerProvider(config).serializeValue(g, rootNode);
/* 3404 */     if (config.isEnabled(SerializationFeature.FLUSH_AFTER_WRITE_VALUE)) {
/* 3405 */       g.flush();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeTree(JsonGenerator g, JsonNode rootNode) throws IOException {
/* 3416 */     _assertNotNull("g", g);
/* 3417 */     SerializationConfig config = getSerializationConfig();
/* 3418 */     _serializerProvider(config).serializeValue(g, rootNode);
/* 3419 */     if (config.isEnabled(SerializationFeature.FLUSH_AFTER_WRITE_VALUE)) {
/* 3420 */       g.flush();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectNode createObjectNode() {
/* 3433 */     return this._deserializationConfig.getNodeFactory().objectNode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayNode createArrayNode() {
/* 3445 */     return this._deserializationConfig.getNodeFactory().arrayNode();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode missingNode() {
/* 3450 */     return this._deserializationConfig.getNodeFactory().missingNode();
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonNode nullNode() {
/* 3455 */     return (JsonNode)this._deserializationConfig.getNodeFactory().nullNode();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser treeAsTokens(TreeNode n) {
/* 3466 */     _assertNotNull("n", n);
/* 3467 */     return (JsonParser)new TreeTraversingParser((JsonNode)n, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T treeToValue(TreeNode n, Class<T> valueType) throws IllegalArgumentException, JsonProcessingException {
/* 3492 */     if (n == null) {
/* 3493 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 3498 */       if (TreeNode.class.isAssignableFrom(valueType) && valueType
/* 3499 */         .isAssignableFrom(n.getClass())) {
/* 3500 */         return (T)n;
/*      */       }
/* 3502 */       JsonToken tt = n.asToken();
/*      */ 
/*      */       
/* 3505 */       if (tt == JsonToken.VALUE_EMBEDDED_OBJECT && 
/* 3506 */         n instanceof POJONode) {
/* 3507 */         Object ob = ((POJONode)n).getPojo();
/* 3508 */         if (ob == null || valueType.isInstance(ob)) {
/* 3509 */           return (T)ob;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3519 */       return readValue(treeAsTokens(n), valueType);
/* 3520 */     } catch (JsonProcessingException e) {
/*      */ 
/*      */       
/* 3523 */       throw e;
/* 3524 */     } catch (IOException e) {
/* 3525 */       throw new IllegalArgumentException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T treeToValue(TreeNode n, JavaType valueType) throws IllegalArgumentException, JsonProcessingException {
/* 3541 */     if (n == null) {
/* 3542 */       return null;
/*      */     }
/*      */     try {
/* 3545 */       if (valueType.isTypeOrSubTypeOf(TreeNode.class) && valueType
/* 3546 */         .isTypeOrSuperTypeOf(n.getClass())) {
/* 3547 */         return (T)n;
/*      */       }
/* 3549 */       JsonToken tt = n.asToken();
/* 3550 */       if (tt == JsonToken.VALUE_EMBEDDED_OBJECT && 
/* 3551 */         n instanceof POJONode) {
/* 3552 */         Object ob = ((POJONode)n).getPojo();
/* 3553 */         if (ob == null || valueType.isTypeOrSuperTypeOf(ob.getClass())) {
/* 3554 */           return (T)ob;
/*      */         }
/*      */       } 
/*      */       
/* 3558 */       return readValue(treeAsTokens(n), valueType);
/* 3559 */     } catch (JsonProcessingException e) {
/*      */ 
/*      */       
/* 3562 */       throw e;
/* 3563 */     } catch (IOException e) {
/* 3564 */       throw new IllegalArgumentException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T treeToValue(TreeNode n, TypeReference<T> toValueTypeRef) throws IllegalArgumentException, JsonProcessingException {
/* 3578 */     JavaType valueType = constructType(toValueTypeRef);
/* 3579 */     return treeToValue(n, valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends JsonNode> T valueToTree(Object fromValue) throws IllegalArgumentException {
/* 3612 */     if (fromValue == null) {
/* 3613 */       return (T)getNodeFactory().nullNode();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3619 */     SerializationConfig config = getSerializationConfig();
/* 3620 */     DefaultSerializerProvider context = _serializerProvider(config);
/*      */ 
/*      */     
/* 3623 */     TokenBuffer buf = context.bufferForValueConversion(this);
/* 3624 */     if (isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 3625 */       buf = buf.forceUseOfBigDecimal(true);
/*      */     }
/*      */     try {
/* 3628 */       context.serializeValue((JsonGenerator)buf, fromValue);
/* 3629 */       try (JsonParser p = buf.asParser()) {
/* 3630 */         return (T)readTree(p);
/*      */       } 
/* 3632 */     } catch (IOException e) {
/* 3633 */       throw new IllegalArgumentException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean canSerialize(Class<?> type) {
/* 3664 */     return _serializerProvider(getSerializationConfig()).hasSerializerFor(type, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean canSerialize(Class<?> type, AtomicReference<Throwable> cause) {
/* 3680 */     return _serializerProvider(getSerializationConfig()).hasSerializerFor(type, cause);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean canDeserialize(JavaType type) {
/* 3707 */     return createDeserializationContext(null, 
/* 3708 */         getDeserializationConfig()).hasValueDeserializerFor(type, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean canDeserialize(JavaType type, AtomicReference<Throwable> cause) {
/* 3725 */     return createDeserializationContext(null, 
/* 3726 */         getDeserializationConfig()).hasValueDeserializerFor(type, cause);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(File src, Class<T> valueType) throws IOException, StreamReadException, DatabindException {
/* 3751 */     _assertNotNull("src", src);
/* 3752 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(File src, TypeReference<T> valueTypeRef) throws IOException, StreamReadException, DatabindException {
/* 3771 */     _assertNotNull("src", src);
/* 3772 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(File src, JavaType valueType) throws IOException, StreamReadException, DatabindException {
/* 3791 */     _assertNotNull("src", src);
/* 3792 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(URL src, Class<T> valueType) throws IOException, StreamReadException, DatabindException {
/* 3817 */     _assertNotNull("src", src);
/* 3818 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(URL src, TypeReference<T> valueTypeRef) throws IOException, StreamReadException, DatabindException {
/* 3828 */     _assertNotNull("src", src);
/* 3829 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(URL src, JavaType valueType) throws IOException, StreamReadException, DatabindException {
/* 3839 */     _assertNotNull("src", src);
/* 3840 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(String content, Class<T> valueType) throws JsonProcessingException, JsonMappingException {
/* 3854 */     _assertNotNull("content", content);
/* 3855 */     return readValue(content, this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(String content, TypeReference<T> valueTypeRef) throws JsonProcessingException, JsonMappingException {
/* 3869 */     _assertNotNull("content", content);
/* 3870 */     return readValue(content, this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(String content, JavaType valueType) throws JsonProcessingException, JsonMappingException {
/* 3885 */     _assertNotNull("content", content);
/*      */     try {
/* 3887 */       return (T)_readMapAndClose(this._jsonFactory.createParser(content), valueType);
/* 3888 */     } catch (JsonProcessingException e) {
/* 3889 */       throw e;
/* 3890 */     } catch (IOException e) {
/* 3891 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(Reader src, Class<T> valueType) throws IOException, StreamReadException, DatabindException {
/* 3899 */     _assertNotNull("src", src);
/* 3900 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(Reader src, TypeReference<T> valueTypeRef) throws IOException, StreamReadException, DatabindException {
/* 3907 */     _assertNotNull("src", src);
/* 3908 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(Reader src, JavaType valueType) throws IOException, StreamReadException, DatabindException {
/* 3915 */     _assertNotNull("src", src);
/* 3916 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(InputStream src, Class<T> valueType) throws IOException, StreamReadException, DatabindException {
/* 3923 */     _assertNotNull("src", src);
/* 3924 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(InputStream src, TypeReference<T> valueTypeRef) throws IOException, StreamReadException, DatabindException {
/* 3931 */     _assertNotNull("src", src);
/* 3932 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(InputStream src, JavaType valueType) throws IOException, StreamReadException, DatabindException {
/* 3939 */     _assertNotNull("src", src);
/* 3940 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] src, Class<T> valueType) throws IOException, StreamReadException, DatabindException {
/* 3947 */     _assertNotNull("src", src);
/* 3948 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] src, int offset, int len, Class<T> valueType) throws IOException, StreamReadException, DatabindException {
/* 3956 */     _assertNotNull("src", src);
/* 3957 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src, offset, len), this._typeFactory.constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] src, TypeReference<T> valueTypeRef) throws IOException, StreamReadException, DatabindException {
/* 3964 */     _assertNotNull("src", src);
/* 3965 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] src, int offset, int len, TypeReference<T> valueTypeRef) throws IOException, StreamReadException, DatabindException {
/* 3972 */     _assertNotNull("src", src);
/* 3973 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src, offset, len), this._typeFactory.constructType(valueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] src, JavaType valueType) throws IOException, StreamReadException, DatabindException {
/* 3980 */     _assertNotNull("src", src);
/* 3981 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(byte[] src, int offset, int len, JavaType valueType) throws IOException, StreamReadException, DatabindException {
/* 3988 */     _assertNotNull("src", src);
/* 3989 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src, offset, len), valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(DataInput src, Class<T> valueType) throws IOException {
/* 3995 */     _assertNotNull("src", src);
/* 3996 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), this._typeFactory
/* 3997 */         .constructType(valueType));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T readValue(DataInput src, JavaType valueType) throws IOException {
/* 4003 */     _assertNotNull("src", src);
/* 4004 */     return (T)_readMapAndClose(this._jsonFactory.createParser(src), valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeValue(File resultFile, Object value) throws IOException, StreamWriteException, DatabindException {
/* 4021 */     _writeValueAndClose(createGenerator(resultFile, JsonEncoding.UTF8), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeValue(OutputStream out, Object value) throws IOException, StreamWriteException, DatabindException {
/* 4038 */     _writeValueAndClose(createGenerator(out, JsonEncoding.UTF8), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeValue(DataOutput out, Object value) throws IOException {
/* 4046 */     _writeValueAndClose(createGenerator(out), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeValue(Writer w, Object value) throws IOException, StreamWriteException, DatabindException {
/* 4062 */     _writeValueAndClose(createGenerator(w), value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String writeValueAsString(Object value) throws JsonProcessingException {
/* 4077 */     BufferRecycler br = this._jsonFactory._getBufferRecycler();
/* 4078 */     try (SegmentedStringWriter sw = new SegmentedStringWriter(br)) {
/* 4079 */       _writeValueAndClose(createGenerator((Writer)sw), value);
/* 4080 */       return sw.getAndClear();
/* 4081 */     } catch (JsonProcessingException e) {
/* 4082 */       throw e;
/* 4083 */     } catch (IOException e) {
/* 4084 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } finally {
/* 4086 */       br.releaseToPool();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] writeValueAsBytes(Object value) throws JsonProcessingException {
/* 4102 */     BufferRecycler br = this._jsonFactory._getBufferRecycler();
/* 4103 */     try (ByteArrayBuilder bb = new ByteArrayBuilder(br)) {
/* 4104 */       _writeValueAndClose(createGenerator((OutputStream)bb, JsonEncoding.UTF8), value);
/* 4105 */       byte[] result = bb.toByteArray();
/* 4106 */       bb.release();
/* 4107 */       return result;
/* 4108 */     } catch (JsonProcessingException e) {
/* 4109 */       throw e;
/* 4110 */     } catch (IOException e) {
/* 4111 */       throw JsonMappingException.fromUnexpectedIOE(e);
/*      */     } finally {
/* 4113 */       br.releaseToPool();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer() {
/* 4129 */     return _newWriter(getSerializationConfig());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(SerializationFeature feature) {
/* 4138 */     return _newWriter(getSerializationConfig().with(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(SerializationFeature first, SerializationFeature... other) {
/* 4148 */     return _newWriter(getSerializationConfig().with(first, other));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(DateFormat df) {
/* 4157 */     return _newWriter(getSerializationConfig().with(df));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writerWithView(Class<?> serializationView) {
/* 4165 */     return _newWriter(getSerializationConfig().withView(serializationView));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writerFor(Class<?> rootType) {
/* 4180 */     return _newWriter(getSerializationConfig(), (rootType == null) ? null : this._typeFactory
/* 4181 */         .constructType(rootType), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writerFor(TypeReference<?> rootType) {
/* 4197 */     return _newWriter(getSerializationConfig(), (rootType == null) ? null : this._typeFactory
/* 4198 */         .constructType(rootType), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writerFor(JavaType rootType) {
/* 4214 */     return _newWriter(getSerializationConfig(), rootType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(PrettyPrinter pp) {
/* 4223 */     if (pp == null) {
/* 4224 */       pp = ObjectWriter.NULL_PRETTY_PRINTER;
/*      */     }
/* 4226 */     return _newWriter(getSerializationConfig(), null, pp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writerWithDefaultPrettyPrinter() {
/* 4234 */     SerializationConfig config = getSerializationConfig();
/* 4235 */     return _newWriter(config, null, config
/* 4236 */         .getDefaultPrettyPrinter());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(FilterProvider filterProvider) {
/* 4244 */     return _newWriter(getSerializationConfig().withFilters(filterProvider));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(FormatSchema schema) {
/* 4255 */     _verifySchemaType(schema);
/* 4256 */     return _newWriter(getSerializationConfig(), schema);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(Base64Variant defaultBase64) {
/* 4266 */     return _newWriter((SerializationConfig)getSerializationConfig().with(defaultBase64));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(CharacterEscapes escapes) {
/* 4276 */     return _newWriter(getSerializationConfig()).with(escapes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectWriter writer(ContextAttributes attrs) {
/* 4286 */     return _newWriter(getSerializationConfig().with(attrs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectWriter writerWithType(Class<?> rootType) {
/* 4294 */     return _newWriter(getSerializationConfig(), (rootType == null) ? null : this._typeFactory
/*      */         
/* 4296 */         .constructType(rootType), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectWriter writerWithType(TypeReference<?> rootType) {
/* 4305 */     return _newWriter(getSerializationConfig(), (rootType == null) ? null : this._typeFactory
/*      */         
/* 4307 */         .constructType(rootType), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectWriter writerWithType(JavaType rootType) {
/* 4316 */     return _newWriter(getSerializationConfig(), rootType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader reader() {
/* 4332 */     return _newReader(getDeserializationConfig()).with(this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader reader(DeserializationFeature feature) {
/* 4343 */     return _newReader(getDeserializationConfig().with(feature));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader reader(DeserializationFeature first, DeserializationFeature... other) {
/* 4355 */     return _newReader(getDeserializationConfig().with(first, other));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader readerForUpdating(Object valueToUpdate) {
/* 4370 */     JavaType t = (valueToUpdate == null) ? null : this._typeFactory.constructType(valueToUpdate.getClass());
/* 4371 */     return _newReader(getDeserializationConfig(), t, valueToUpdate, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader readerFor(JavaType type) {
/* 4382 */     return _newReader(getDeserializationConfig(), type, null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader readerFor(Class<?> type) {
/* 4393 */     JavaType t = (type == null) ? null : this._typeFactory.constructType(type);
/* 4394 */     return _newReader(getDeserializationConfig(), t, null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader readerFor(TypeReference<?> typeRef) {
/* 4405 */     _assertNotNull("type", typeRef);
/* 4406 */     return _newReader(getDeserializationConfig(), this._typeFactory.constructType(typeRef), null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader readerForArrayOf(Class<?> type) {
/* 4421 */     _assertNotNull("type", type);
/* 4422 */     return _newReader(getDeserializationConfig(), (JavaType)this._typeFactory
/* 4423 */         .constructArrayType(type), null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader readerForListOf(Class<?> type) {
/* 4438 */     _assertNotNull("type", type);
/* 4439 */     return _newReader(getDeserializationConfig(), (JavaType)this._typeFactory
/* 4440 */         .constructCollectionType(List.class, type), null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader readerForMapOf(Class<?> type) {
/* 4455 */     _assertNotNull("type", type);
/* 4456 */     return _newReader(getDeserializationConfig(), (JavaType)this._typeFactory
/* 4457 */         .constructMapType(Map.class, String.class, type), null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader reader(JsonNodeFactory nodeFactory) {
/* 4466 */     _assertNotNull("nodeFactory", nodeFactory);
/* 4467 */     return _newReader(getDeserializationConfig()).with(nodeFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader reader(FormatSchema schema) {
/* 4479 */     _verifySchemaType(schema);
/* 4480 */     return _newReader(getDeserializationConfig(), null, null, schema, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader reader(InjectableValues injectableValues) {
/* 4491 */     return _newReader(getDeserializationConfig(), null, null, null, injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader readerWithView(Class<?> view) {
/* 4500 */     return _newReader(getDeserializationConfig().withView(view));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader reader(Base64Variant defaultBase64) {
/* 4510 */     return _newReader((DeserializationConfig)getDeserializationConfig().with(defaultBase64));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectReader reader(ContextAttributes attrs) {
/* 4520 */     return _newReader(getDeserializationConfig().with(attrs));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectReader reader(JavaType type) {
/* 4528 */     return _newReader(getDeserializationConfig(), type, null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectReader reader(Class<?> type) {
/* 4537 */     return _newReader(getDeserializationConfig(), this._typeFactory.constructType(type), null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public ObjectReader reader(TypeReference<?> type) {
/* 4546 */     return _newReader(getDeserializationConfig(), this._typeFactory.constructType(type), null, null, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T convertValue(Object fromValue, Class<T> toValueType) throws IllegalArgumentException {
/* 4594 */     return (T)_convert(fromValue, this._typeFactory.constructType(toValueType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T convertValue(Object fromValue, TypeReference<T> toValueTypeRef) throws IllegalArgumentException {
/* 4604 */     return (T)_convert(fromValue, this._typeFactory.constructType(toValueTypeRef));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T convertValue(Object fromValue, JavaType toValueType) throws IllegalArgumentException {
/* 4614 */     return (T)_convert(fromValue, toValueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _convert(Object fromValue, JavaType toValueType) throws IllegalArgumentException {
/* 4631 */     SerializationConfig config = getSerializationConfig().without(SerializationFeature.WRAP_ROOT_VALUE);
/* 4632 */     DefaultSerializerProvider context = _serializerProvider(config);
/*      */ 
/*      */     
/* 4635 */     TokenBuffer buf = context.bufferForValueConversion(this);
/* 4636 */     if (isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 4637 */       buf = buf.forceUseOfBigDecimal(true);
/*      */     }
/*      */     try {
/*      */       Object result;
/* 4641 */       context.serializeValue((JsonGenerator)buf, fromValue);
/*      */ 
/*      */       
/* 4644 */       JsonParser p = buf.asParser();
/*      */ 
/*      */       
/* 4647 */       DeserializationConfig deserConfig = getDeserializationConfig();
/* 4648 */       JsonToken t = _initForReading(p, toValueType);
/* 4649 */       if (t == JsonToken.VALUE_NULL) {
/* 4650 */         DefaultDeserializationContext defaultDeserializationContext = createDeserializationContext(p, deserConfig);
/* 4651 */         result = _findRootDeserializer((DeserializationContext)defaultDeserializationContext, toValueType).getNullValue((DeserializationContext)defaultDeserializationContext);
/* 4652 */       } else if (t == JsonToken.END_ARRAY || t == JsonToken.END_OBJECT) {
/* 4653 */         result = null;
/*      */       } else {
/* 4655 */         DefaultDeserializationContext defaultDeserializationContext = createDeserializationContext(p, deserConfig);
/* 4656 */         JsonDeserializer<Object> deser = _findRootDeserializer((DeserializationContext)defaultDeserializationContext, toValueType);
/*      */         
/* 4658 */         result = deser.deserialize(p, (DeserializationContext)defaultDeserializationContext);
/*      */       } 
/* 4660 */       p.close();
/* 4661 */       return result;
/* 4662 */     } catch (IOException e) {
/* 4663 */       throw new IllegalArgumentException(e.getMessage(), e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T updateValue(T valueToUpdate, Object overrides) throws JsonMappingException {
/* 4706 */     T result = valueToUpdate;
/* 4707 */     if (valueToUpdate != null && overrides != null) {
/*      */       
/* 4709 */       SerializationConfig config = getSerializationConfig().without(SerializationFeature.WRAP_ROOT_VALUE);
/* 4710 */       DefaultSerializerProvider context = _serializerProvider(config);
/*      */       
/* 4712 */       TokenBuffer buf = context.bufferForValueConversion(this);
/* 4713 */       if (isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 4714 */         buf = buf.forceUseOfBigDecimal(true);
/*      */       }
/*      */       try {
/* 4717 */         context.serializeValue((JsonGenerator)buf, overrides);
/* 4718 */         JsonParser p = buf.asParser();
/* 4719 */         result = readerForUpdating(valueToUpdate).readValue(p);
/* 4720 */         p.close();
/* 4721 */       } catch (IOException e) {
/* 4722 */         if (e instanceof JsonMappingException) {
/* 4723 */           throw (JsonMappingException)e;
/*      */         }
/*      */         
/* 4726 */         throw JsonMappingException.fromUnexpectedIOE(e);
/*      */       } 
/*      */     } 
/* 4729 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonSchema generateJsonSchema(Class<?> t) throws JsonMappingException {
/* 4751 */     return _serializerProvider(getSerializationConfig()).generateJsonSchema(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void acceptJsonFormatVisitor(Class<?> type, JsonFormatVisitorWrapper visitor) throws JsonMappingException {
/* 4768 */     acceptJsonFormatVisitor(this._typeFactory.constructType(type), visitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void acceptJsonFormatVisitor(JavaType type, JsonFormatVisitorWrapper visitor) throws JsonMappingException {
/* 4786 */     if (type == null) {
/* 4787 */       throw new IllegalArgumentException("type must be provided");
/*      */     }
/* 4789 */     _serializerProvider(getSerializationConfig()).acceptJsonFormatVisitor(type, visitor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearCaches() {
/* 4807 */     this._rootDeserializers.clear();
/* 4808 */     this._typeFactory.clearCache();
/* 4809 */     this._deserializationContext.flushCachedDeserializers();
/* 4810 */     this._serializerProvider.flushCachedSerializers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TypeResolverBuilder<?> _constructDefaultTypeResolverBuilder(DefaultTyping applicability, PolymorphicTypeValidator ptv) {
/* 4827 */     return (TypeResolverBuilder<?>)DefaultTypeResolverBuilder.construct(applicability, ptv);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DefaultSerializerProvider _serializerProvider(SerializationConfig config) {
/* 4841 */     return this._serializerProvider.createInstance(config, this._serializerFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _writeValueAndClose(JsonGenerator g, Object value) throws IOException {
/* 4853 */     SerializationConfig cfg = getSerializationConfig();
/* 4854 */     if (cfg.isEnabled(SerializationFeature.CLOSE_CLOSEABLE) && value instanceof Closeable) {
/* 4855 */       _writeCloseable(g, value, cfg);
/*      */       return;
/*      */     } 
/*      */     try {
/* 4859 */       _serializerProvider(cfg).serializeValue(g, value);
/* 4860 */     } catch (Exception e) {
/* 4861 */       ClassUtil.closeOnFailAndThrowAsIOE(g, e);
/*      */       return;
/*      */     } 
/* 4864 */     g.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeCloseable(JsonGenerator g, Object value, SerializationConfig cfg) throws IOException {
/* 4874 */     Closeable toClose = (Closeable)value;
/*      */     try {
/* 4876 */       _serializerProvider(cfg).serializeValue(g, value);
/* 4877 */       Closeable tmpToClose = toClose;
/* 4878 */       toClose = null;
/* 4879 */       tmpToClose.close();
/* 4880 */     } catch (Exception e) {
/* 4881 */       ClassUtil.closeOnFailAndThrowAsIOE(g, toClose, e);
/*      */       return;
/*      */     } 
/* 4884 */     g.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeCloseableValue(JsonGenerator g, Object value, SerializationConfig cfg) throws IOException {
/* 4894 */     Closeable toClose = (Closeable)value;
/*      */     try {
/* 4896 */       _serializerProvider(cfg).serializeValue(g, value);
/* 4897 */       if (cfg.isEnabled(SerializationFeature.FLUSH_AFTER_WRITE_VALUE)) {
/* 4898 */         g.flush();
/*      */       }
/* 4900 */     } catch (Exception e) {
/* 4901 */       ClassUtil.closeOnFailAndThrowAsIOE(null, toClose, e);
/*      */       return;
/*      */     } 
/* 4904 */     toClose.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final void _configAndWriteValue(JsonGenerator g, Object value) throws IOException {
/* 4912 */     getSerializationConfig().initialize(g);
/* 4913 */     _writeValueAndClose(g, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _readValue(DeserializationConfig cfg, JsonParser p, JavaType valueType) throws IOException {
/*      */     Object result;
/* 4933 */     JsonToken t = _initForReading(p, valueType);
/* 4934 */     DefaultDeserializationContext ctxt = createDeserializationContext(p, cfg);
/* 4935 */     if (t == JsonToken.VALUE_NULL) {
/*      */       
/* 4937 */       result = _findRootDeserializer((DeserializationContext)ctxt, valueType).getNullValue((DeserializationContext)ctxt);
/* 4938 */     } else if (t == JsonToken.END_ARRAY || t == JsonToken.END_OBJECT) {
/* 4939 */       result = null;
/* 4940 */     } else if (t == JsonToken.NOT_AVAILABLE) {
/*      */       
/* 4942 */       result = null;
/*      */     } else {
/* 4944 */       result = ctxt.readRootValue(p, valueType, _findRootDeserializer((DeserializationContext)ctxt, valueType), null);
/*      */     } 
/*      */     
/* 4947 */     p.clearCurrentToken();
/* 4948 */     if (cfg.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 4949 */       _verifyNoTrailingTokens(p, (DeserializationContext)ctxt, valueType);
/*      */     }
/* 4951 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _readMapAndClose(JsonParser p0, JavaType valueType) throws IOException {
/* 4957 */     try (JsonParser p = p0) {
/*      */       Object result;
/* 4959 */       DeserializationConfig cfg = getDeserializationConfig();
/* 4960 */       DefaultDeserializationContext ctxt = createDeserializationContext(p, cfg);
/* 4961 */       JsonToken t = _initForReading(p, valueType);
/* 4962 */       if (t == JsonToken.VALUE_NULL) {
/*      */         
/* 4964 */         result = _findRootDeserializer((DeserializationContext)ctxt, valueType).getNullValue((DeserializationContext)ctxt);
/* 4965 */       } else if (t == JsonToken.END_ARRAY || t == JsonToken.END_OBJECT) {
/* 4966 */         result = null;
/* 4967 */       } else if (t == JsonToken.NOT_AVAILABLE) {
/*      */         
/* 4969 */         result = null;
/*      */       } else {
/* 4971 */         result = ctxt.readRootValue(p, valueType, 
/* 4972 */             _findRootDeserializer((DeserializationContext)ctxt, valueType), null);
/* 4973 */         ctxt.checkUnresolvedObjectId();
/*      */       } 
/* 4975 */       if (cfg.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 4976 */         _verifyNoTrailingTokens(p, (DeserializationContext)ctxt, valueType);
/*      */       }
/* 4978 */       return result;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonNode _readTreeAndClose(JsonParser p0) throws IOException {
/* 4990 */     try (JsonParser p = p0) {
/* 4991 */       JsonNode resultNode; JavaType valueType = constructType(JsonNode.class);
/*      */       
/* 4993 */       DeserializationConfig cfg = getDeserializationConfig();
/*      */ 
/*      */ 
/*      */       
/* 4997 */       cfg.initialize(p);
/* 4998 */       JsonToken t = p.currentToken();
/* 4999 */       if (t == null) {
/* 5000 */         t = p.nextToken();
/* 5001 */         if (t == null) {
/*      */ 
/*      */           
/* 5004 */           resultNode = cfg.getNodeFactory().missingNode(); return resultNode;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 5009 */       DefaultDeserializationContext ctxt = createDeserializationContext(p, cfg);
/* 5010 */       if (t == JsonToken.VALUE_NULL) {
/* 5011 */         NullNode nullNode = cfg.getNodeFactory().nullNode();
/*      */       } else {
/* 5013 */         resultNode = (JsonNode)ctxt.readRootValue(p, valueType, 
/* 5014 */             _findRootDeserializer((DeserializationContext)ctxt, valueType), null);
/*      */       } 
/*      */ 
/*      */       
/* 5018 */       if (cfg.isEnabled(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)) {
/* 5019 */         _verifyNoTrailingTokens(p, (DeserializationContext)ctxt, valueType);
/*      */       }
/* 5021 */       return resultNode;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DefaultDeserializationContext createDeserializationContext(JsonParser p, DeserializationConfig cfg) {
/* 5034 */     return this._deserializationContext.createInstance(cfg, p, this._injectableValues);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _initForReading(JsonParser p, JavaType targetType) throws IOException {
/* 5050 */     this._deserializationConfig.initialize(p);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5055 */     JsonToken t = p.currentToken();
/* 5056 */     if (t == null) {
/*      */       
/* 5058 */       t = p.nextToken();
/* 5059 */       if (t == null)
/*      */       {
/*      */         
/* 5062 */         throw MismatchedInputException.from(p, targetType, "No content to map due to end-of-input");
/*      */       }
/*      */     } 
/*      */     
/* 5066 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _verifyNoTrailingTokens(JsonParser p, DeserializationContext ctxt, JavaType bindType) throws IOException {
/* 5076 */     JsonToken t = p.nextToken();
/* 5077 */     if (t != null) {
/* 5078 */       Class<?> bt = ClassUtil.rawClass(bindType);
/* 5079 */       ctxt.reportTrailingTokens(bt, p, t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> _findRootDeserializer(DeserializationContext ctxt, JavaType valueType) throws DatabindException {
/* 5097 */     JsonDeserializer<Object> deser = this._rootDeserializers.get(valueType);
/* 5098 */     if (deser != null) {
/* 5099 */       return deser;
/*      */     }
/*      */     
/* 5102 */     deser = ctxt.findRootValueDeserializer(valueType);
/* 5103 */     if (deser == null) {
/* 5104 */       return ctxt.<JsonDeserializer<Object>>reportBadDefinition(valueType, "Cannot find a deserializer for type " + valueType);
/*      */     }
/*      */     
/* 5107 */     this._rootDeserializers.put(valueType, deser);
/* 5108 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _verifySchemaType(FormatSchema schema) {
/* 5116 */     if (schema != null && 
/* 5117 */       !this._jsonFactory.canUseSchema(schema)) {
/* 5118 */       throw new IllegalArgumentException("Cannot use FormatSchema of type " + schema.getClass().getName() + " for format " + this._jsonFactory
/* 5119 */           .getFormatName());
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _assertNotNull(String paramName, Object src) {
/* 5125 */     if (src == null)
/* 5126 */       throw new IllegalArgumentException(String.format("argument \"%s\" is null", new Object[] { paramName })); 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ObjectMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */