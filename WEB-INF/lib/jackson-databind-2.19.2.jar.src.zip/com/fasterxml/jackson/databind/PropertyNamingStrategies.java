/*     */ package com.fasterxml.jackson.databind;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedField;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedParameter;
/*     */ import com.fasterxml.jackson.databind.util.NamingStrategyImpls;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PropertyNamingStrategies
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*  37 */   public static final PropertyNamingStrategy LOWER_CAMEL_CASE = LowerCamelCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final PropertyNamingStrategy UPPER_CAMEL_CASE = UpperCamelCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public static final PropertyNamingStrategy SNAKE_CASE = SnakeCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   public static final PropertyNamingStrategy UPPER_SNAKE_CASE = UpperSnakeCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public static final PropertyNamingStrategy LOWER_CASE = LowerCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public static final PropertyNamingStrategy KEBAB_CASE = KebabCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public static final PropertyNamingStrategy LOWER_DOT_CASE = LowerDotCaseStrategy.INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class NamingBase
/*     */     extends PropertyNamingStrategy
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String nameForField(MapperConfig<?> config, AnnotatedField field, String defaultName) {
/* 108 */       return translate(defaultName);
/*     */     }
/*     */ 
/*     */     
/*     */     public String nameForGetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName) {
/* 113 */       return translate(defaultName);
/*     */     }
/*     */ 
/*     */     
/*     */     public String nameForSetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName) {
/* 118 */       return translate(defaultName);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String nameForConstructorParameter(MapperConfig<?> config, AnnotatedParameter ctorParam, String defaultName) {
/* 124 */       return translate(defaultName);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract String translate(String param1String);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class SnakeCaseStrategy
/*     */     extends NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     public static final SnakeCaseStrategy INSTANCE = new SnakeCaseStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String translate(String input) {
/* 198 */       return NamingStrategyImpls.SNAKE_CASE.translate(input);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class UpperSnakeCaseStrategy
/*     */     extends SnakeCaseStrategy
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 216 */     public static final UpperSnakeCaseStrategy INSTANCE = new UpperSnakeCaseStrategy();
/*     */ 
/*     */ 
/*     */     
/*     */     public String translate(String input) {
/* 221 */       return NamingStrategyImpls.UPPER_SNAKE_CASE.translate(input);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class LowerCamelCaseStrategy
/*     */     extends NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */     
/* 236 */     public static final LowerCamelCaseStrategy INSTANCE = new LowerCamelCaseStrategy();
/*     */ 
/*     */ 
/*     */     
/*     */     public String translate(String input) {
/* 241 */       return NamingStrategyImpls.LOWER_CAMEL_CASE.translate(input);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class UpperCamelCaseStrategy
/*     */     extends NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 265 */     public static final UpperCamelCaseStrategy INSTANCE = new UpperCamelCaseStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String translate(String input) {
/* 279 */       return NamingStrategyImpls.UPPER_CAMEL_CASE.translate(input);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class LowerCaseStrategy
/*     */     extends NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 296 */     public static final LowerCaseStrategy INSTANCE = new LowerCaseStrategy();
/*     */ 
/*     */ 
/*     */     
/*     */     public String translate(String input) {
/* 301 */       return NamingStrategyImpls.LOWER_CASE.translate(input);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class KebabCaseStrategy
/*     */     extends NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 318 */     public static final KebabCaseStrategy INSTANCE = new KebabCaseStrategy();
/*     */ 
/*     */ 
/*     */     
/*     */     public String translate(String input) {
/* 323 */       return NamingStrategyImpls.KEBAB_CASE.translate(input);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class LowerDotCaseStrategy
/*     */     extends NamingBase
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 339 */     public static final LowerDotCaseStrategy INSTANCE = new LowerDotCaseStrategy();
/*     */ 
/*     */ 
/*     */     
/*     */     public String translate(String input) {
/* 344 */       return NamingStrategyImpls.LOWER_DOT_CASE.translate(input);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\PropertyNamingStrategies.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */