package com.fasterxml.jackson.databind.jsonFormatVisitors;

public interface JsonBooleanFormatVisitor extends JsonValueFormatVisitor {
  public static class Base extends JsonValueFormatVisitor.Base implements JsonBooleanFormatVisitor {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jsonFormatVisitors\JsonBooleanFormatVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */