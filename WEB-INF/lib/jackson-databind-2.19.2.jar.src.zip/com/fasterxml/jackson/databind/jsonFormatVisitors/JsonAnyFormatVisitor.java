package com.fasterxml.jackson.databind.jsonFormatVisitors;

public interface JsonAnyFormatVisitor {
  public static class Base implements JsonAnyFormatVisitor {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jsonFormatVisitors\JsonAnyFormatVisitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */