/*     */ package com.fasterxml.jackson.databind;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdResolver;
/*     */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*     */ import com.fasterxml.jackson.databind.cfg.DatatypeFeatures;
/*     */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.ObjectIdInfo;
/*     */ import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import java.lang.reflect.Type;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DatabindContext
/*     */ {
/*     */   private static final int MAX_ERROR_STR_LEN = 500;
/*     */   
/*     */   public abstract MapperConfig<?> getConfig();
/*     */   
/*     */   public abstract AnnotationIntrospector getAnnotationIntrospector();
/*     */   
/*     */   public abstract boolean isEnabled(MapperFeature paramMapperFeature);
/*     */   
/*     */   public abstract boolean isEnabled(DatatypeFeature paramDatatypeFeature);
/*     */   
/*     */   public abstract DatatypeFeatures getDatatypeFeatures();
/*     */   
/*     */   public abstract boolean canOverrideAccessModifiers();
/*     */   
/*     */   public abstract Class<?> getActiveView();
/*     */   
/*     */   public abstract Locale getLocale();
/*     */   
/*     */   public abstract TimeZone getTimeZone();
/*     */   
/*     */   public abstract JsonFormat.Value getDefaultPropertyFormat(Class<?> paramClass);
/*     */   
/*     */   public abstract Object getAttribute(Object paramObject);
/*     */   
/*     */   public abstract DatabindContext setAttribute(Object paramObject1, Object paramObject2);
/*     */   
/*     */   public JavaType constructType(Type type) {
/* 163 */     if (type == null) {
/* 164 */       return null;
/*     */     }
/* 166 */     return getTypeFactory().constructType(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JavaType constructSpecializedType(JavaType paramJavaType, Class<?> paramClass);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType resolveSubType(JavaType baseType, String subClassName) throws JsonMappingException {
/* 192 */     if (subClassName.indexOf('<') > 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 197 */       JavaType t = getTypeFactory().constructFromCanonical(subClassName);
/* 198 */       if (t.isTypeOrSubTypeOf(baseType.getRawClass())) {
/* 199 */         return t;
/*     */       }
/*     */     } else {
/*     */       Class<?> cls;
/*     */       try {
/* 204 */         cls = getTypeFactory().findClass(subClassName);
/* 205 */       } catch (ClassNotFoundException e) {
/* 206 */         return null;
/* 207 */       } catch (Exception e) {
/* 208 */         throw invalidTypeIdException(baseType, subClassName, String.format("problem: (%s) %s", new Object[] { e
/*     */                 
/* 210 */                 .getClass().getName(), 
/* 211 */                 ClassUtil.exceptionMessage(e) }));
/*     */       } 
/* 213 */       if (baseType.isTypeOrSuperTypeOf(cls)) {
/* 214 */         return getTypeFactory().constructSpecializedType(baseType, cls);
/*     */       }
/*     */     } 
/* 217 */     throw invalidTypeIdException(baseType, subClassName, "Not a subtype");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType resolveAndValidateSubType(JavaType baseType, String subClass, PolymorphicTypeValidator ptv) throws JsonMappingException {
/*     */     Class<?> cls;
/* 231 */     int ltIndex = subClass.indexOf('<');
/* 232 */     if (ltIndex > 0) {
/* 233 */       return _resolveAndValidateGeneric(baseType, subClass, ptv, ltIndex);
/*     */     }
/* 235 */     MapperConfig<?> config = getConfig();
/* 236 */     PolymorphicTypeValidator.Validity vld = ptv.validateSubClassName(config, baseType, subClass);
/* 237 */     if (vld == PolymorphicTypeValidator.Validity.DENIED) {
/* 238 */       return _throwSubtypeNameNotAllowed(baseType, subClass, ptv);
/*     */     }
/*     */     
/*     */     try {
/* 242 */       cls = getTypeFactory().findClass(subClass);
/* 243 */     } catch (ClassNotFoundException e) {
/* 244 */       return null;
/* 245 */     } catch (Exception e) {
/* 246 */       throw invalidTypeIdException(baseType, subClass, String.format("problem: (%s) %s", new Object[] { e
/*     */               
/* 248 */               .getClass().getName(), 
/* 249 */               ClassUtil.exceptionMessage(e) }));
/*     */     } 
/* 251 */     if (!baseType.isTypeOrSuperTypeOf(cls)) {
/* 252 */       return _throwNotASubtype(baseType, subClass);
/*     */     }
/* 254 */     JavaType subType = config.getTypeFactory().constructSpecializedType(baseType, cls);
/*     */     
/* 256 */     if (vld == PolymorphicTypeValidator.Validity.INDETERMINATE) {
/* 257 */       vld = ptv.validateSubType(config, baseType, subType);
/* 258 */       if (vld != PolymorphicTypeValidator.Validity.ALLOWED) {
/* 259 */         return _throwSubtypeClassNotAllowed(baseType, subClass, ptv);
/*     */       }
/*     */     } 
/* 262 */     return subType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JavaType _resolveAndValidateGeneric(JavaType baseType, String subClass, PolymorphicTypeValidator ptv, int ltIndex) throws JsonMappingException {
/* 269 */     MapperConfig<?> config = getConfig();
/*     */ 
/*     */ 
/*     */     
/* 273 */     PolymorphicTypeValidator.Validity vld = ptv.validateSubClassName(config, baseType, subClass.substring(0, ltIndex));
/* 274 */     if (vld == PolymorphicTypeValidator.Validity.DENIED) {
/* 275 */       return _throwSubtypeNameNotAllowed(baseType, subClass, ptv);
/*     */     }
/* 277 */     JavaType subType = getTypeFactory().constructFromCanonical(subClass);
/* 278 */     if (!subType.isTypeOrSubTypeOf(baseType.getRawClass())) {
/* 279 */       return _throwNotASubtype(baseType, subClass);
/*     */     }
/*     */     
/* 282 */     if (vld != PolymorphicTypeValidator.Validity.ALLOWED && 
/* 283 */       ptv.validateSubType(config, baseType, subType) != PolymorphicTypeValidator.Validity.ALLOWED) {
/* 284 */       return _throwSubtypeClassNotAllowed(baseType, subClass, ptv);
/*     */     }
/*     */     
/* 287 */     return subType;
/*     */   }
/*     */   
/*     */   protected <T> T _throwNotASubtype(JavaType baseType, String subType) throws JsonMappingException {
/* 291 */     throw invalidTypeIdException(baseType, subType, "Not a subtype");
/*     */   }
/*     */ 
/*     */   
/*     */   protected <T> T _throwSubtypeNameNotAllowed(JavaType baseType, String subType, PolymorphicTypeValidator ptv) throws JsonMappingException {
/* 296 */     throw invalidTypeIdException(baseType, subType, "Configured `PolymorphicTypeValidator` (of type " + 
/* 297 */         ClassUtil.classNameOf(ptv) + ") denied resolution");
/*     */   }
/*     */ 
/*     */   
/*     */   protected <T> T _throwSubtypeClassNotAllowed(JavaType baseType, String subType, PolymorphicTypeValidator ptv) throws JsonMappingException {
/* 302 */     throw invalidTypeIdException(baseType, subType, "Configured `PolymorphicTypeValidator` (of type " + 
/* 303 */         ClassUtil.classNameOf(ptv) + ") denied resolution");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract JsonMappingException invalidTypeIdException(JavaType paramJavaType, String paramString1, String paramString2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract TypeFactory getTypeFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectIdGenerator<?> objectIdGeneratorInstance(Annotated annotated, ObjectIdInfo objectIdInfo) throws JsonMappingException {
/* 332 */     Class<?> implClass = objectIdInfo.getGeneratorType();
/* 333 */     MapperConfig<?> config = getConfig();
/* 334 */     HandlerInstantiator hi = config.getHandlerInstantiator();
/* 335 */     ObjectIdGenerator<?> gen = (hi == null) ? null : hi.objectIdGeneratorInstance(config, annotated, implClass);
/* 336 */     if (gen == null) {
/* 337 */       gen = (ObjectIdGenerator)ClassUtil.createInstance(implClass, config
/* 338 */           .canOverrideAccessModifiers());
/*     */     }
/* 340 */     return gen.forScope(objectIdInfo.getScope());
/*     */   }
/*     */ 
/*     */   
/*     */   public ObjectIdResolver objectIdResolverInstance(Annotated annotated, ObjectIdInfo objectIdInfo) {
/* 345 */     Class<? extends ObjectIdResolver> implClass = objectIdInfo.getResolverType();
/* 346 */     MapperConfig<?> config = getConfig();
/* 347 */     HandlerInstantiator hi = config.getHandlerInstantiator();
/* 348 */     ObjectIdResolver resolver = (hi == null) ? null : hi.resolverIdGeneratorInstance(config, annotated, implClass);
/* 349 */     if (resolver == null) {
/* 350 */       resolver = (ObjectIdResolver)ClassUtil.createInstance(implClass, config.canOverrideAccessModifiers());
/*     */     }
/*     */     
/* 353 */     return resolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Converter<Object, Object> converterInstance(Annotated annotated, Object converterDef) throws JsonMappingException {
/* 367 */     if (converterDef == null) {
/* 368 */       return null;
/*     */     }
/* 370 */     if (converterDef instanceof Converter) {
/* 371 */       return (Converter<Object, Object>)converterDef;
/*     */     }
/* 373 */     if (!(converterDef instanceof Class)) {
/* 374 */       throw new IllegalStateException("AnnotationIntrospector returned Converter definition of type " + converterDef
/* 375 */           .getClass().getName() + "; expected type Converter or Class<Converter> instead");
/*     */     }
/* 377 */     Class<?> converterClass = (Class)converterDef;
/*     */     
/* 379 */     if (converterClass == Converter.None.class || ClassUtil.isBogusClass(converterClass)) {
/* 380 */       return null;
/*     */     }
/* 382 */     if (!Converter.class.isAssignableFrom(converterClass)) {
/* 383 */       throw new IllegalStateException("AnnotationIntrospector returned Class " + converterClass
/* 384 */           .getName() + "; expected Class<Converter>");
/*     */     }
/* 386 */     MapperConfig<?> config = getConfig();
/* 387 */     HandlerInstantiator hi = config.getHandlerInstantiator();
/* 388 */     Converter<?, ?> conv = (hi == null) ? null : hi.converterInstance(config, annotated, converterClass);
/* 389 */     if (conv == null) {
/* 390 */       conv = (Converter<?, ?>)ClassUtil.createInstance(converterClass, config
/* 391 */           .canOverrideAccessModifiers());
/*     */     }
/* 393 */     return (Converter)conv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract <T> T reportBadDefinition(JavaType paramJavaType, String paramString) throws JsonMappingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T reportBadDefinition(Class<?> type, String msg) throws JsonMappingException {
/* 415 */     return reportBadDefinition(constructType(type), msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract <T> T reportBadTypeDefinition(BeanDescription paramBeanDescription, String paramString, Object... paramVarArgs) throws JsonMappingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _format(String msg, Object... msgArgs) {
/* 434 */     if (msgArgs.length > 0) {
/* 435 */       return String.format(msg, msgArgs);
/*     */     }
/* 437 */     return msg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _truncate(String desc) {
/* 444 */     if (desc == null) {
/* 445 */       return "";
/*     */     }
/* 447 */     if (desc.length() <= 500) {
/* 448 */       return desc;
/*     */     }
/* 450 */     return desc.substring(0, 500) + "]...[" + desc.substring(desc.length() - 500);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String _quotedString(String desc) {
/* 457 */     if (desc == null) {
/* 458 */       return "[N/A]";
/*     */     }
/*     */     
/* 461 */     return String.format("\"%s\"", new Object[] { _truncate(desc) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String _colonConcat(String msgBase, String extra) {
/* 468 */     if (extra == null) {
/* 469 */       return msgBase;
/*     */     }
/* 471 */     return msgBase + ": " + extra;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String _desc(String desc) {
/* 478 */     if (desc == null) {
/* 479 */       return "[N/A]";
/*     */     }
/*     */     
/* 482 */     return _truncate(desc);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\DatabindContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */