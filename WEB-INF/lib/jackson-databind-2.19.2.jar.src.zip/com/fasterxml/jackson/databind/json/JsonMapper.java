/*     */ package com.fasterxml.jackson.databind.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.Version;
/*     */ import com.fasterxml.jackson.core.json.JsonReadFeature;
/*     */ import com.fasterxml.jackson.core.json.JsonWriteFeature;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperBuilder;
/*     */ import com.fasterxml.jackson.databind.cfg.PackageVersion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonMapper
/*     */   extends ObjectMapper
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public static class Builder
/*     */     extends MapperBuilder<JsonMapper, Builder>
/*     */   {
/*     */     public Builder(JsonMapper m) {
/*  29 */       super(m);
/*     */     }
/*     */     
/*     */     public Builder enable(JsonReadFeature... features) {
/*  33 */       for (JsonReadFeature f : features) {
/*  34 */         ((JsonMapper)this._mapper).enable(new JsonParser.Feature[] { f.mappedFeature() });
/*     */       } 
/*  36 */       return this;
/*     */     }
/*     */     
/*     */     public Builder disable(JsonReadFeature... features) {
/*  40 */       for (JsonReadFeature f : features) {
/*  41 */         ((JsonMapper)this._mapper).disable(new JsonParser.Feature[] { f.mappedFeature() });
/*     */       } 
/*  43 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder configure(JsonReadFeature f, boolean state) {
/*  48 */       if (state) {
/*  49 */         ((JsonMapper)this._mapper).enable(new JsonParser.Feature[] { f.mappedFeature() });
/*     */       } else {
/*  51 */         ((JsonMapper)this._mapper).disable(new JsonParser.Feature[] { f.mappedFeature() });
/*     */       } 
/*  53 */       return this;
/*     */     }
/*     */     
/*     */     public Builder enable(JsonWriteFeature... features) {
/*  57 */       for (JsonWriteFeature f : features) {
/*  58 */         ((JsonMapper)this._mapper).enable(new JsonGenerator.Feature[] { f.mappedFeature() });
/*     */       } 
/*  60 */       return this;
/*     */     }
/*     */     
/*     */     public Builder disable(JsonWriteFeature... features) {
/*  64 */       for (JsonWriteFeature f : features) {
/*  65 */         ((JsonMapper)this._mapper).disable(new JsonGenerator.Feature[] { f.mappedFeature() });
/*     */       } 
/*  67 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     public Builder configure(JsonWriteFeature f, boolean state) {
/*  72 */       if (state) {
/*  73 */         ((JsonMapper)this._mapper).enable(new JsonGenerator.Feature[] { f.mappedFeature() });
/*     */       } else {
/*  75 */         ((JsonMapper)this._mapper).disable(new JsonGenerator.Feature[] { f.mappedFeature() });
/*     */       } 
/*  77 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonMapper() {
/*  88 */     this(new JsonFactory());
/*     */   }
/*     */   
/*     */   public JsonMapper(JsonFactory f) {
/*  92 */     super(f);
/*     */   }
/*     */   
/*     */   protected JsonMapper(JsonMapper src) {
/*  96 */     super(src);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonMapper copy() {
/* 102 */     _checkInvalidCopy(JsonMapper.class);
/* 103 */     return new JsonMapper(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 113 */     return new Builder(new JsonMapper());
/*     */   }
/*     */   
/*     */   public static Builder builder(JsonFactory streamFactory) {
/* 117 */     return new Builder(new JsonMapper(streamFactory));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder rebuild() {
/* 123 */     return new Builder(copy());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Version version() {
/* 134 */     return PackageVersion.VERSION;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonFactory getFactory() {
/* 139 */     return this._jsonFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(JsonReadFeature f) {
/* 152 */     return isEnabled(f.mappedFeature());
/*     */   }
/*     */   
/*     */   public boolean isEnabled(JsonWriteFeature f) {
/* 156 */     return isEnabled(f.mappedFeature());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\json\JsonMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */