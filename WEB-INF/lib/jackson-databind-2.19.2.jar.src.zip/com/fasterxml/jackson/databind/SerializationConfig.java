/*     */ package com.fasterxml.jackson.databind;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.core.FormatFeature;
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.PrettyPrinter;
/*     */ import com.fasterxml.jackson.core.json.JsonWriteFeature;
/*     */ import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
/*     */ import com.fasterxml.jackson.core.util.Instantiatable;
/*     */ import com.fasterxml.jackson.databind.cfg.BaseSettings;
/*     */ import com.fasterxml.jackson.databind.cfg.ConfigOverrides;
/*     */ import com.fasterxml.jackson.databind.cfg.ConstructorDetector;
/*     */ import com.fasterxml.jackson.databind.cfg.ContextAttributes;
/*     */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*     */ import com.fasterxml.jackson.databind.cfg.DatatypeFeatures;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfigBase;
/*     */ import com.fasterxml.jackson.databind.introspect.ClassIntrospector;
/*     */ import com.fasterxml.jackson.databind.introspect.SimpleMixInResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.SubtypeResolver;
/*     */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*     */ import com.fasterxml.jackson.databind.util.RootNameLookup;
/*     */ import java.io.Serializable;
/*     */ import java.text.DateFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SerializationConfig
/*     */   extends MapperConfigBase<SerializationFeature, SerializationConfig>
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  37 */   protected static final PrettyPrinter DEFAULT_PRETTY_PRINTER = (PrettyPrinter)new DefaultPrettyPrinter();
/*     */ 
/*     */   
/*  40 */   private static final int SER_FEATURE_DEFAULTS = collectFeatureDefaults(SerializationFeature.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final FilterProvider _filterProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final PrettyPrinter _defaultPrettyPrinter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ConstructorDetector _ctorDetector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _serFeatures;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _generatorFeatures;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _generatorFeaturesToChange;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _formatWriteFeatures;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _formatWriteFeaturesToChange;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig(BaseSettings base, SubtypeResolver str, SimpleMixInResolver mixins, RootNameLookup rootNames, ConfigOverrides configOverrides, DatatypeFeatures datatypeFeatures) {
/* 123 */     super(base, str, mixins, rootNames, configOverrides, datatypeFeatures);
/* 124 */     this._serFeatures = SER_FEATURE_DEFAULTS;
/* 125 */     this._filterProvider = null;
/* 126 */     this._defaultPrettyPrinter = DEFAULT_PRETTY_PRINTER;
/* 127 */     this._ctorDetector = null;
/* 128 */     this._generatorFeatures = 0;
/* 129 */     this._generatorFeaturesToChange = 0;
/* 130 */     this._formatWriteFeatures = 0;
/* 131 */     this._formatWriteFeaturesToChange = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SerializationConfig(BaseSettings base, SubtypeResolver str, SimpleMixInResolver mixins, RootNameLookup rootNames, ConfigOverrides configOverrides) {
/* 142 */     this(base, str, mixins, rootNames, configOverrides, 
/* 143 */         DatatypeFeatures.defaultFeatures());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializationConfig(SerializationConfig src, SubtypeResolver str, SimpleMixInResolver mixins, RootNameLookup rootNames, ConfigOverrides configOverrides) {
/* 155 */     super(src, str, mixins, rootNames, configOverrides);
/* 156 */     this._serFeatures = src._serFeatures;
/* 157 */     this._filterProvider = src._filterProvider;
/* 158 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 159 */     this._ctorDetector = src._ctorDetector;
/* 160 */     this._generatorFeatures = src._generatorFeatures;
/* 161 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 162 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 163 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SerializationConfig(SerializationConfig src, SubtypeResolver str) {
/* 175 */     super(src, str);
/* 176 */     this._serFeatures = src._serFeatures;
/* 177 */     this._filterProvider = src._filterProvider;
/* 178 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 179 */     this._ctorDetector = src._ctorDetector;
/* 180 */     this._generatorFeatures = src._generatorFeatures;
/* 181 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 182 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 183 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SerializationConfig(SerializationConfig src, long mapperFeatures, int serFeatures, int generatorFeatures, int generatorFeatureMask, int formatFeatures, int formatFeaturesMask) {
/* 191 */     super(src, mapperFeatures);
/* 192 */     this._serFeatures = serFeatures;
/* 193 */     this._filterProvider = src._filterProvider;
/* 194 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 195 */     this._ctorDetector = src._ctorDetector;
/* 196 */     this._generatorFeatures = generatorFeatures;
/* 197 */     this._generatorFeaturesToChange = generatorFeatureMask;
/* 198 */     this._formatWriteFeatures = formatFeatures;
/* 199 */     this._formatWriteFeaturesToChange = formatFeaturesMask;
/*     */   }
/*     */ 
/*     */   
/*     */   private SerializationConfig(SerializationConfig src, BaseSettings base) {
/* 204 */     super(src, base);
/* 205 */     this._serFeatures = src._serFeatures;
/* 206 */     this._filterProvider = src._filterProvider;
/* 207 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 208 */     this._ctorDetector = src._ctorDetector;
/* 209 */     this._generatorFeatures = src._generatorFeatures;
/* 210 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 211 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 212 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */   
/*     */   private SerializationConfig(SerializationConfig src, FilterProvider filters) {
/* 217 */     super(src);
/* 218 */     this._serFeatures = src._serFeatures;
/* 219 */     this._filterProvider = filters;
/* 220 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 221 */     this._ctorDetector = src._ctorDetector;
/* 222 */     this._generatorFeatures = src._generatorFeatures;
/* 223 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 224 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 225 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */   
/*     */   private SerializationConfig(SerializationConfig src, Class<?> view) {
/* 230 */     super(src, view);
/* 231 */     this._serFeatures = src._serFeatures;
/* 232 */     this._filterProvider = src._filterProvider;
/* 233 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 234 */     this._ctorDetector = src._ctorDetector;
/* 235 */     this._generatorFeatures = src._generatorFeatures;
/* 236 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 237 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 238 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */   
/*     */   private SerializationConfig(SerializationConfig src, PropertyName rootName) {
/* 243 */     super(src, rootName);
/* 244 */     this._serFeatures = src._serFeatures;
/* 245 */     this._filterProvider = src._filterProvider;
/* 246 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 247 */     this._ctorDetector = src._ctorDetector;
/* 248 */     this._generatorFeatures = src._generatorFeatures;
/* 249 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 250 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 251 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializationConfig(SerializationConfig src, ContextAttributes attrs) {
/* 259 */     super(src, attrs);
/* 260 */     this._serFeatures = src._serFeatures;
/* 261 */     this._filterProvider = src._filterProvider;
/* 262 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 263 */     this._ctorDetector = src._ctorDetector;
/* 264 */     this._generatorFeatures = src._generatorFeatures;
/* 265 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 266 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 267 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializationConfig(SerializationConfig src, SimpleMixInResolver mixins) {
/* 275 */     super(src, mixins);
/* 276 */     this._serFeatures = src._serFeatures;
/* 277 */     this._filterProvider = src._filterProvider;
/* 278 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 279 */     this._ctorDetector = src._ctorDetector;
/* 280 */     this._generatorFeatures = src._generatorFeatures;
/* 281 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 282 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 283 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializationConfig(SerializationConfig src, PrettyPrinter defaultPP) {
/* 291 */     super(src);
/* 292 */     this._serFeatures = src._serFeatures;
/* 293 */     this._filterProvider = src._filterProvider;
/* 294 */     this._defaultPrettyPrinter = defaultPP;
/* 295 */     this._ctorDetector = src._ctorDetector;
/* 296 */     this._generatorFeatures = src._generatorFeatures;
/* 297 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 298 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 299 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializationConfig(SerializationConfig src, DatatypeFeatures dtFeatures) {
/* 307 */     super(src, dtFeatures);
/* 308 */     this._serFeatures = src._serFeatures;
/* 309 */     this._filterProvider = src._filterProvider;
/* 310 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 311 */     this._ctorDetector = src._ctorDetector;
/* 312 */     this._generatorFeatures = src._generatorFeatures;
/* 313 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 314 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 315 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializationConfig(SerializationConfig src, ConstructorDetector ctorDetector) {
/* 323 */     super(src);
/* 324 */     this._serFeatures = src._serFeatures;
/* 325 */     this._filterProvider = src._filterProvider;
/* 326 */     this._defaultPrettyPrinter = src._defaultPrettyPrinter;
/* 327 */     this._ctorDetector = ctorDetector;
/* 328 */     this._generatorFeatures = src._generatorFeatures;
/* 329 */     this._generatorFeaturesToChange = src._generatorFeaturesToChange;
/* 330 */     this._formatWriteFeatures = src._formatWriteFeatures;
/* 331 */     this._formatWriteFeaturesToChange = src._formatWriteFeaturesToChange;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final SerializationConfig _withBase(BaseSettings newBase) {
/* 342 */     return (this._base == newBase) ? this : new SerializationConfig(this, newBase);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final SerializationConfig _withMapperFeatures(long mapperFeatures) {
/* 347 */     return new SerializationConfig(this, mapperFeatures, this._serFeatures, this._generatorFeatures, this._generatorFeaturesToChange, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final SerializationConfig _with(DatatypeFeatures dtFeatures) {
/* 354 */     return new SerializationConfig(this, dtFeatures);
/*     */   }
/*     */ 
/*     */   
/*     */   public SerializationConfig withRootName(PropertyName rootName) {
/* 359 */     if (rootName == null) {
/* 360 */       if (this._rootName == null) {
/* 361 */         return this;
/*     */       }
/* 363 */     } else if (rootName.equals(this._rootName)) {
/* 364 */       return this;
/*     */     } 
/* 366 */     return new SerializationConfig(this, rootName);
/*     */   }
/*     */ 
/*     */   
/*     */   public SerializationConfig with(SubtypeResolver str) {
/* 371 */     return (str == this._subtypeResolver) ? this : new SerializationConfig(this, str);
/*     */   }
/*     */ 
/*     */   
/*     */   public SerializationConfig withView(Class<?> view) {
/* 376 */     return (this._view == view) ? this : new SerializationConfig(this, view);
/*     */   }
/*     */ 
/*     */   
/*     */   public SerializationConfig with(ContextAttributes attrs) {
/* 381 */     return (attrs == this._attributes) ? this : new SerializationConfig(this, attrs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig with(DateFormat df) {
/* 397 */     SerializationConfig cfg = (SerializationConfig)super.with(df);
/*     */     
/* 399 */     if (df == null) {
/* 400 */       return cfg.with(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
/*     */     }
/* 402 */     return cfg.without(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig with(SerializationFeature feature) {
/* 417 */     int newSerFeatures = this._serFeatures | feature.getMask();
/* 418 */     return (newSerFeatures == this._serFeatures) ? this : new SerializationConfig(this, this._mapperFeatures, newSerFeatures, this._generatorFeatures, this._generatorFeaturesToChange, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig with(SerializationFeature first, SerializationFeature... features) {
/* 430 */     int newSerFeatures = this._serFeatures | first.getMask();
/* 431 */     for (SerializationFeature f : features) {
/* 432 */       newSerFeatures |= f.getMask();
/*     */     }
/* 434 */     return (newSerFeatures == this._serFeatures) ? this : new SerializationConfig(this, this._mapperFeatures, newSerFeatures, this._generatorFeatures, this._generatorFeaturesToChange, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig withFeatures(SerializationFeature... features) {
/* 446 */     int newSerFeatures = this._serFeatures;
/* 447 */     for (SerializationFeature f : features) {
/* 448 */       newSerFeatures |= f.getMask();
/*     */     }
/* 450 */     return (newSerFeatures == this._serFeatures) ? this : new SerializationConfig(this, this._mapperFeatures, newSerFeatures, this._generatorFeatures, this._generatorFeaturesToChange, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig without(SerializationFeature feature) {
/* 462 */     int newSerFeatures = this._serFeatures & (feature.getMask() ^ 0xFFFFFFFF);
/* 463 */     return (newSerFeatures == this._serFeatures) ? this : new SerializationConfig(this, this._mapperFeatures, newSerFeatures, this._generatorFeatures, this._generatorFeaturesToChange, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig without(SerializationFeature first, SerializationFeature... features) {
/* 475 */     int newSerFeatures = this._serFeatures & (first.getMask() ^ 0xFFFFFFFF);
/* 476 */     for (SerializationFeature f : features) {
/* 477 */       newSerFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*     */     }
/* 479 */     return (newSerFeatures == this._serFeatures) ? this : new SerializationConfig(this, this._mapperFeatures, newSerFeatures, this._generatorFeatures, this._generatorFeaturesToChange, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig withoutFeatures(SerializationFeature... features) {
/* 491 */     int newSerFeatures = this._serFeatures;
/* 492 */     for (SerializationFeature f : features) {
/* 493 */       newSerFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*     */     }
/* 495 */     return (newSerFeatures == this._serFeatures) ? this : new SerializationConfig(this, this._mapperFeatures, newSerFeatures, this._generatorFeatures, this._generatorFeaturesToChange, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig with(JsonGenerator.Feature feature) {
/* 514 */     int newSet = this._generatorFeatures | feature.getMask();
/* 515 */     int newMask = this._generatorFeaturesToChange | feature.getMask();
/* 516 */     return (this._generatorFeatures == newSet && this._generatorFeaturesToChange == newMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, newSet, newMask, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig withFeatures(JsonGenerator.Feature... features) {
/* 530 */     int newSet = this._generatorFeatures;
/* 531 */     int newMask = this._generatorFeaturesToChange;
/* 532 */     for (JsonGenerator.Feature f : features) {
/* 533 */       int mask = f.getMask();
/* 534 */       newSet |= mask;
/* 535 */       newMask |= mask;
/*     */     } 
/* 537 */     return (this._generatorFeatures == newSet && this._generatorFeaturesToChange == newMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, newSet, newMask, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig without(JsonGenerator.Feature feature) {
/* 551 */     int newSet = this._generatorFeatures & (feature.getMask() ^ 0xFFFFFFFF);
/* 552 */     int newMask = this._generatorFeaturesToChange | feature.getMask();
/* 553 */     return (this._generatorFeatures == newSet && this._generatorFeaturesToChange == newMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, newSet, newMask, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig withoutFeatures(JsonGenerator.Feature... features) {
/* 567 */     int newSet = this._generatorFeatures;
/* 568 */     int newMask = this._generatorFeaturesToChange;
/* 569 */     for (JsonGenerator.Feature f : features) {
/* 570 */       int mask = f.getMask();
/* 571 */       newSet &= mask ^ 0xFFFFFFFF;
/* 572 */       newMask |= mask;
/*     */     } 
/* 574 */     return (this._generatorFeatures == newSet && this._generatorFeaturesToChange == newMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, newSet, newMask, this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig with(FormatFeature feature) {
/* 594 */     if (feature instanceof JsonWriteFeature) {
/* 595 */       return _withJsonWriteFeatures(new FormatFeature[] { feature });
/*     */     }
/* 597 */     int newSet = this._formatWriteFeatures | feature.getMask();
/* 598 */     int newMask = this._formatWriteFeaturesToChange | feature.getMask();
/* 599 */     return (this._formatWriteFeatures == newSet && this._formatWriteFeaturesToChange == newMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, this._generatorFeatures, this._generatorFeaturesToChange, newSet, newMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig withFeatures(FormatFeature... features) {
/* 614 */     if (features.length > 0 && features[0] instanceof JsonWriteFeature) {
/* 615 */       return _withJsonWriteFeatures(features);
/*     */     }
/* 617 */     int newSet = this._formatWriteFeatures;
/* 618 */     int newMask = this._formatWriteFeaturesToChange;
/* 619 */     for (FormatFeature f : features) {
/* 620 */       int mask = f.getMask();
/* 621 */       newSet |= mask;
/* 622 */       newMask |= mask;
/*     */     } 
/* 624 */     return (this._formatWriteFeatures == newSet && this._formatWriteFeaturesToChange == newMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, this._generatorFeatures, this._generatorFeaturesToChange, newSet, newMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig without(FormatFeature feature) {
/* 639 */     if (feature instanceof JsonWriteFeature) {
/* 640 */       return _withoutJsonWriteFeatures(new FormatFeature[] { feature });
/*     */     }
/* 642 */     int newSet = this._formatWriteFeatures & (feature.getMask() ^ 0xFFFFFFFF);
/* 643 */     int newMask = this._formatWriteFeaturesToChange | feature.getMask();
/* 644 */     return (this._formatWriteFeatures == newSet && this._formatWriteFeaturesToChange == newMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, this._generatorFeatures, this._generatorFeaturesToChange, newSet, newMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig withoutFeatures(FormatFeature... features) {
/* 658 */     if (features.length > 0 && features[0] instanceof JsonWriteFeature) {
/* 659 */       return _withoutJsonWriteFeatures(features);
/*     */     }
/* 661 */     int newSet = this._formatWriteFeatures;
/* 662 */     int newMask = this._formatWriteFeaturesToChange;
/* 663 */     for (FormatFeature f : features) {
/* 664 */       int mask = f.getMask();
/* 665 */       newSet &= mask ^ 0xFFFFFFFF;
/* 666 */       newMask |= mask;
/*     */     } 
/* 668 */     return (this._formatWriteFeatures == newSet && this._formatWriteFeaturesToChange == newMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, this._generatorFeatures, this._generatorFeaturesToChange, newSet, newMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SerializationConfig _withJsonWriteFeatures(FormatFeature... features) {
/* 676 */     int parserSet = this._generatorFeatures;
/* 677 */     int parserMask = this._generatorFeaturesToChange;
/* 678 */     int newSet = this._formatWriteFeatures;
/* 679 */     int newMask = this._formatWriteFeaturesToChange;
/* 680 */     for (FormatFeature f : features) {
/* 681 */       int mask = f.getMask();
/* 682 */       newSet |= mask;
/* 683 */       newMask |= mask;
/*     */       
/* 685 */       if (f instanceof JsonWriteFeature) {
/* 686 */         JsonGenerator.Feature oldF = ((JsonWriteFeature)f).mappedFeature();
/* 687 */         if (oldF != null) {
/* 688 */           int pmask = oldF.getMask();
/* 689 */           parserSet |= pmask;
/* 690 */           parserMask |= pmask;
/*     */         } 
/*     */       } 
/*     */     } 
/* 694 */     return (this._formatWriteFeatures == newSet && this._formatWriteFeaturesToChange == newMask && this._generatorFeatures == parserSet && this._generatorFeaturesToChange == parserMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, parserSet, parserMask, newSet, newMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SerializationConfig _withoutJsonWriteFeatures(FormatFeature... features) {
/* 703 */     int parserSet = this._generatorFeatures;
/* 704 */     int parserMask = this._generatorFeaturesToChange;
/* 705 */     int newSet = this._formatWriteFeatures;
/* 706 */     int newMask = this._formatWriteFeaturesToChange;
/* 707 */     for (FormatFeature f : features) {
/* 708 */       int mask = f.getMask();
/* 709 */       newSet &= mask ^ 0xFFFFFFFF;
/* 710 */       newMask |= mask;
/*     */       
/* 712 */       if (f instanceof JsonWriteFeature) {
/* 713 */         JsonGenerator.Feature oldF = ((JsonWriteFeature)f).mappedFeature();
/* 714 */         if (oldF != null) {
/* 715 */           int pmask = oldF.getMask();
/* 716 */           parserSet &= pmask ^ 0xFFFFFFFF;
/* 717 */           parserMask |= pmask;
/*     */         } 
/*     */       } 
/*     */     } 
/* 721 */     return (this._formatWriteFeatures == newSet && this._formatWriteFeaturesToChange == newMask && this._generatorFeatures == parserSet && this._generatorFeaturesToChange == parserMask) ? this : new SerializationConfig(this, this._mapperFeatures, this._serFeatures, parserSet, parserMask, newSet, newMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig withFilters(FilterProvider filterProvider) {
/* 735 */     return (filterProvider == this._filterProvider) ? this : new SerializationConfig(this, filterProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SerializationConfig withPropertyInclusion(JsonInclude.Value incl) {
/* 748 */     this._configOverrides.setDefaultInclusion(incl);
/* 749 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig withDefaultPrettyPrinter(PrettyPrinter pp) {
/* 756 */     return (this._defaultPrettyPrinter == pp) ? this : new SerializationConfig(this, pp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializationConfig with(ConstructorDetector ctorDetector) {
/* 763 */     if (this._ctorDetector == ctorDetector) {
/* 764 */       return this;
/*     */     }
/* 766 */     return new SerializationConfig(this, ctorDetector);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrettyPrinter constructDefaultPrettyPrinter() {
/* 776 */     PrettyPrinter pp = this._defaultPrettyPrinter;
/* 777 */     if (pp instanceof Instantiatable) {
/* 778 */       pp = (PrettyPrinter)((Instantiatable)pp).createInstance();
/*     */     }
/* 780 */     return pp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(JsonGenerator g) {
/* 798 */     if (SerializationFeature.INDENT_OUTPUT.enabledIn(this._serFeatures))
/*     */     {
/* 800 */       if (g.getPrettyPrinter() == null) {
/* 801 */         PrettyPrinter pp = constructDefaultPrettyPrinter();
/* 802 */         if (pp != null) {
/* 803 */           g.setPrettyPrinter(pp);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 808 */     boolean useBigDec = SerializationFeature.WRITE_BIGDECIMAL_AS_PLAIN.enabledIn(this._serFeatures);
/*     */     
/* 810 */     int mask = this._generatorFeaturesToChange;
/* 811 */     if (mask != 0 || useBigDec) {
/* 812 */       int newFlags = this._generatorFeatures;
/*     */       
/* 814 */       if (useBigDec) {
/* 815 */         int f = JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN.getMask();
/* 816 */         newFlags |= f;
/* 817 */         mask |= f;
/*     */       } 
/* 819 */       g.overrideStdFeatures(newFlags, mask);
/*     */     } 
/* 821 */     if (this._formatWriteFeaturesToChange != 0) {
/* 822 */       g.overrideFormatFeatures(this._formatWriteFeatures, this._formatWriteFeaturesToChange);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonInclude.Include getSerializationInclusion() {
/* 838 */     JsonInclude.Include incl = getDefaultPropertyInclusion().getValueInclusion();
/* 839 */     return (incl == JsonInclude.Include.USE_DEFAULTS) ? JsonInclude.Include.ALWAYS : incl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean useRootWrapping() {
/* 851 */     if (this._rootName != null) {
/* 852 */       return !this._rootName.isEmpty();
/*     */     }
/* 854 */     return isEnabled(SerializationFeature.WRAP_ROOT_VALUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEnabled(SerializationFeature feature) {
/* 866 */     return ((this._serFeatures & feature.getMask()) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEnabled(JsonGenerator.Feature f, JsonFactory factory) {
/* 877 */     int mask = f.getMask();
/* 878 */     if ((this._generatorFeaturesToChange & mask) != 0) {
/* 879 */       return ((this._generatorFeatures & f.getMask()) != 0);
/*     */     }
/* 881 */     return factory.isEnabled(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasSerializationFeatures(int featureMask) {
/* 891 */     return ((this._serFeatures & featureMask) == featureMask);
/*     */   }
/*     */   
/*     */   public final int getSerializationFeatures() {
/* 895 */     return this._serFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEnabled(DatatypeFeature feature) {
/* 910 */     return this._datatypeFeatures.isEnabled(feature);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FilterProvider getFilterProvider() {
/* 920 */     return this._filterProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrettyPrinter getDefaultPrettyPrinter() {
/* 934 */     return this._defaultPrettyPrinter;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConstructorDetector getConstructorDetector() {
/* 939 */     if (this._ctorDetector == null) {
/* 940 */       return ConstructorDetector.DEFAULT;
/*     */     }
/* 942 */     return this._ctorDetector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDescription introspect(JavaType type) {
/* 956 */     return getClassIntrospector().forSerialization(this, type, (ClassIntrospector.MixInResolver)this);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\SerializationConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */