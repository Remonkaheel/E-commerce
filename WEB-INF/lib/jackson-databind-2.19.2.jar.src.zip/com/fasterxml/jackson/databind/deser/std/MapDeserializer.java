/*      */ package com.fasterxml.jackson.databind.deser.std;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*      */ import com.fasterxml.jackson.annotation.JsonIncludeProperties;
/*      */ import com.fasterxml.jackson.core.JacksonException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.BeanProperty;
/*      */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*      */ import com.fasterxml.jackson.databind.MapperFeature;
/*      */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*      */ import com.fasterxml.jackson.databind.deser.ContextualKeyDeserializer;
/*      */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*      */ import com.fasterxml.jackson.databind.deser.ResolvableDeserializer;
/*      */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*      */ import com.fasterxml.jackson.databind.deser.UnresolvedForwardReference;
/*      */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*      */ import com.fasterxml.jackson.databind.deser.impl.PropertyBasedCreator;
/*      */ import com.fasterxml.jackson.databind.deser.impl.PropertyValueBuffer;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.type.LogicalType;
/*      */ import com.fasterxml.jackson.databind.util.ArrayBuilders;
/*      */ import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @JacksonStdImpl
/*      */ public class MapDeserializer
/*      */   extends ContainerDeserializerBase<Map<Object, Object>>
/*      */   implements ContextualDeserializer, ResolvableDeserializer
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   protected final KeyDeserializer _keyDeserializer;
/*      */   protected boolean _standardStringKey;
/*      */   protected final JsonDeserializer<Object> _valueDeserializer;
/*      */   protected final TypeDeserializer _valueTypeDeserializer;
/*      */   protected final ValueInstantiator _valueInstantiator;
/*      */   protected JsonDeserializer<Object> _delegateDeserializer;
/*      */   protected PropertyBasedCreator _propertyBasedCreator;
/*      */   protected final boolean _hasDefaultCreator;
/*      */   protected Set<String> _ignorableProperties;
/*      */   protected Set<String> _includableProperties;
/*      */   protected IgnorePropertiesUtil.Checker _inclusionChecker;
/*      */   protected boolean _checkDupSquash;
/*      */   
/*      */   public MapDeserializer(JavaType mapType, ValueInstantiator valueInstantiator, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser) {
/*  122 */     super(mapType, (NullValueProvider)null, (Boolean)null);
/*  123 */     this._keyDeserializer = keyDeser;
/*  124 */     this._valueDeserializer = valueDeser;
/*  125 */     this._valueTypeDeserializer = valueTypeDeser;
/*  126 */     this._valueInstantiator = valueInstantiator;
/*  127 */     this._hasDefaultCreator = valueInstantiator.canCreateUsingDefault();
/*  128 */     this._delegateDeserializer = null;
/*  129 */     this._propertyBasedCreator = null;
/*  130 */     this._standardStringKey = _isStdKeyDeser(mapType, keyDeser);
/*  131 */     this._inclusionChecker = null;
/*  132 */     this._checkDupSquash = mapType.getContentType().hasRawClass(Object.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MapDeserializer(MapDeserializer src) {
/*  141 */     super(src);
/*  142 */     this._keyDeserializer = src._keyDeserializer;
/*  143 */     this._valueDeserializer = src._valueDeserializer;
/*  144 */     this._valueTypeDeserializer = src._valueTypeDeserializer;
/*  145 */     this._valueInstantiator = src._valueInstantiator;
/*  146 */     this._propertyBasedCreator = src._propertyBasedCreator;
/*  147 */     this._delegateDeserializer = src._delegateDeserializer;
/*  148 */     this._hasDefaultCreator = src._hasDefaultCreator;
/*      */     
/*  150 */     this._ignorableProperties = src._ignorableProperties;
/*  151 */     this._includableProperties = src._includableProperties;
/*  152 */     this._inclusionChecker = src._inclusionChecker;
/*      */     
/*  154 */     this._standardStringKey = src._standardStringKey;
/*  155 */     this._checkDupSquash = src._checkDupSquash;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MapDeserializer(MapDeserializer src, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser, NullValueProvider nuller, Set<String> ignorable) {
/*  164 */     this(src, keyDeser, valueDeser, valueTypeDeser, nuller, ignorable, (Set<String>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MapDeserializer(MapDeserializer src, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser, NullValueProvider nuller, Set<String> ignorable, Set<String> includable) {
/*  177 */     super(src, nuller, src._unwrapSingle);
/*  178 */     this._keyDeserializer = keyDeser;
/*  179 */     this._valueDeserializer = valueDeser;
/*  180 */     this._valueTypeDeserializer = valueTypeDeser;
/*  181 */     this._valueInstantiator = src._valueInstantiator;
/*  182 */     this._propertyBasedCreator = src._propertyBasedCreator;
/*  183 */     this._delegateDeserializer = src._delegateDeserializer;
/*  184 */     this._hasDefaultCreator = src._hasDefaultCreator;
/*  185 */     this._ignorableProperties = ignorable;
/*  186 */     this._includableProperties = includable;
/*  187 */     this._inclusionChecker = IgnorePropertiesUtil.buildCheckerIfNeeded(ignorable, includable);
/*      */     
/*  189 */     this._standardStringKey = _isStdKeyDeser(this._containerType, keyDeser);
/*  190 */     this._checkDupSquash = src._checkDupSquash;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MapDeserializer withResolved(KeyDeserializer keyDeser, TypeDeserializer valueTypeDeser, JsonDeserializer<?> valueDeser, NullValueProvider nuller, Set<String> ignorable) {
/*  202 */     return withResolved(keyDeser, valueTypeDeser, valueDeser, nuller, ignorable, this._includableProperties);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MapDeserializer withResolved(KeyDeserializer keyDeser, TypeDeserializer valueTypeDeser, JsonDeserializer<?> valueDeser, NullValueProvider nuller, Set<String> ignorable, Set<String> includable) {
/*  214 */     if (this._keyDeserializer == keyDeser && this._valueDeserializer == valueDeser && this._valueTypeDeserializer == valueTypeDeser && this._nullProvider == nuller && this._ignorableProperties == ignorable && this._includableProperties == includable)
/*      */     {
/*      */       
/*  217 */       return this;
/*      */     }
/*  219 */     return new MapDeserializer(this, keyDeser, (JsonDeserializer)valueDeser, valueTypeDeser, nuller, ignorable, includable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _isStdKeyDeser(JavaType mapType, KeyDeserializer keyDeser) {
/*  230 */     if (keyDeser == null) {
/*  231 */       return true;
/*      */     }
/*  233 */     JavaType keyType = mapType.getKeyType();
/*  234 */     if (keyType == null) {
/*  235 */       return true;
/*      */     }
/*  237 */     Class<?> rawKeyType = keyType.getRawClass();
/*  238 */     return ((rawKeyType == String.class || rawKeyType == Object.class) && 
/*  239 */       isDefaultKeyDeserializer(keyDeser));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setIgnorableProperties(String[] ignorable) {
/*  247 */     this
/*  248 */       ._ignorableProperties = (ignorable == null || ignorable.length == 0) ? null : ArrayBuilders.arrayToSet((Object[])ignorable);
/*  249 */     this._inclusionChecker = IgnorePropertiesUtil.buildCheckerIfNeeded(this._ignorableProperties, this._includableProperties);
/*      */   }
/*      */   
/*      */   public void setIgnorableProperties(Set<String> ignorable) {
/*  253 */     this._ignorableProperties = (ignorable == null || ignorable.isEmpty()) ? null : ignorable;
/*      */     
/*  255 */     this._inclusionChecker = IgnorePropertiesUtil.buildCheckerIfNeeded(this._ignorableProperties, this._includableProperties);
/*      */   }
/*      */   
/*      */   public void setIncludableProperties(Set<String> includable) {
/*  259 */     this._includableProperties = includable;
/*  260 */     this._inclusionChecker = IgnorePropertiesUtil.buildCheckerIfNeeded(this._ignorableProperties, this._includableProperties);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resolve(DeserializationContext ctxt) throws JsonMappingException {
/*  273 */     if (this._valueInstantiator.canCreateUsingDelegate()) {
/*  274 */       JavaType delegateType = this._valueInstantiator.getDelegateType(ctxt.getConfig());
/*  275 */       if (delegateType == null) {
/*  276 */         ctxt.reportBadDefinition(this._containerType, String.format("Invalid delegate-creator definition for %s: value instantiator (%s) returned true for 'canCreateUsingDelegate()', but null for 'getDelegateType()'", new Object[] { this._containerType, this._valueInstantiator
/*      */ 
/*      */                 
/*  279 */                 .getClass().getName() }));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  284 */       this._delegateDeserializer = findDeserializer(ctxt, delegateType, null);
/*  285 */     } else if (this._valueInstantiator.canCreateUsingArrayDelegate()) {
/*  286 */       JavaType delegateType = this._valueInstantiator.getArrayDelegateType(ctxt.getConfig());
/*  287 */       if (delegateType == null) {
/*  288 */         ctxt.reportBadDefinition(this._containerType, String.format("Invalid delegate-creator definition for %s: value instantiator (%s) returned true for 'canCreateUsingArrayDelegate()', but null for 'getArrayDelegateType()'", new Object[] { this._containerType, this._valueInstantiator
/*      */ 
/*      */                 
/*  291 */                 .getClass().getName() }));
/*      */       }
/*  293 */       this._delegateDeserializer = findDeserializer(ctxt, delegateType, null);
/*      */     } 
/*  295 */     if (this._valueInstantiator.canCreateFromObjectWith()) {
/*  296 */       SettableBeanProperty[] creatorProps = this._valueInstantiator.getFromObjectArguments(ctxt.getConfig());
/*  297 */       this._propertyBasedCreator = PropertyBasedCreator.construct(ctxt, this._valueInstantiator, creatorProps, ctxt
/*  298 */           .isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES));
/*      */     } 
/*  300 */     this._standardStringKey = _isStdKeyDeser(this._containerType, this._keyDeserializer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/*  311 */     KeyDeserializer keyDeser = this._keyDeserializer;
/*  312 */     if (keyDeser == null) {
/*  313 */       keyDeser = ctxt.findKeyDeserializer(this._containerType.getKeyType(), property);
/*      */     }
/*  315 */     else if (keyDeser instanceof ContextualKeyDeserializer) {
/*  316 */       keyDeser = ((ContextualKeyDeserializer)keyDeser).createContextual(ctxt, property);
/*      */     } 
/*      */ 
/*      */     
/*  320 */     JsonDeserializer<?> valueDeser = this._valueDeserializer;
/*      */     
/*  322 */     if (property != null) {
/*  323 */       valueDeser = findConvertingContentDeserializer(ctxt, property, valueDeser);
/*      */     }
/*  325 */     JavaType vt = this._containerType.getContentType();
/*  326 */     if (valueDeser == null) {
/*  327 */       valueDeser = ctxt.findContextualValueDeserializer(vt, property);
/*      */     } else {
/*  329 */       valueDeser = ctxt.handleSecondaryContextualization(valueDeser, property, vt);
/*      */     } 
/*  331 */     TypeDeserializer vtd = this._valueTypeDeserializer;
/*  332 */     if (vtd != null) {
/*  333 */       vtd = vtd.forProperty(property);
/*      */     }
/*  335 */     Set<String> ignored = this._ignorableProperties;
/*  336 */     Set<String> included = this._includableProperties;
/*  337 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/*  338 */     if (_neitherNull(intr, property)) {
/*  339 */       AnnotatedMember member = property.getMember();
/*  340 */       if (member != null) {
/*  341 */         DeserializationConfig config = ctxt.getConfig();
/*  342 */         JsonIgnoreProperties.Value ignorals = intr.findPropertyIgnoralByName((MapperConfig)config, (Annotated)member);
/*  343 */         if (ignorals != null) {
/*  344 */           Set<String> ignoresToAdd = ignorals.findIgnoredForDeserialization();
/*  345 */           if (!ignoresToAdd.isEmpty()) {
/*  346 */             if (ignored == null) {
/*  347 */               ignored = new HashSet<>(ignoresToAdd);
/*      */             } else {
/*  349 */               ignored = new HashSet<>(ignored);
/*  350 */               ignored.addAll(ignoresToAdd);
/*      */             } 
/*      */           }
/*      */         } 
/*  354 */         JsonIncludeProperties.Value inclusions = intr.findPropertyInclusionByName((MapperConfig)config, (Annotated)member);
/*  355 */         if (inclusions != null) {
/*  356 */           Set<String> includedToAdd = inclusions.getIncluded();
/*  357 */           if (includedToAdd != null) {
/*  358 */             Set<String> newIncluded = new HashSet<>();
/*  359 */             if (included == null) {
/*  360 */               newIncluded = new HashSet<>(includedToAdd);
/*      */             } else {
/*  362 */               for (String str : includedToAdd) {
/*  363 */                 if (included.contains(str)) {
/*  364 */                   newIncluded.add(str);
/*      */                 }
/*      */               } 
/*      */             } 
/*  368 */             included = newIncluded;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  373 */     return withResolved(keyDeser, vtd, valueDeser, 
/*  374 */         findContentNullProvider(ctxt, property, valueDeser), ignored, included);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<Object> getContentDeserializer() {
/*  385 */     return this._valueDeserializer;
/*      */   }
/*      */ 
/*      */   
/*      */   public ValueInstantiator getValueInstantiator() {
/*  390 */     return this._valueInstantiator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCachable() {
/*  416 */     return (this._valueDeserializer == null && this._keyDeserializer == null && this._valueTypeDeserializer == null && this._ignorableProperties == null && this._includableProperties == null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LogicalType logicalType() {
/*  425 */     return LogicalType.Map;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<Object, Object> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     Map<Object, Object> result;
/*  432 */     if (this._propertyBasedCreator != null) {
/*  433 */       return _deserializeUsingCreator(p, ctxt);
/*      */     }
/*  435 */     if (this._delegateDeserializer != null) {
/*  436 */       return (Map<Object, Object>)this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer
/*  437 */           .deserialize(p, ctxt));
/*      */     }
/*  439 */     if (!this._hasDefaultCreator) {
/*  440 */       return (Map<Object, Object>)ctxt.handleMissingInstantiator(getMapClass(), 
/*  441 */           getValueInstantiator(), p, "no default constructor found", new Object[0]);
/*      */     }
/*      */     
/*  444 */     switch (p.currentTokenId()) {
/*      */       case 1:
/*      */       case 2:
/*      */       case 5:
/*  448 */         result = (Map<Object, Object>)this._valueInstantiator.createUsingDefault(ctxt);
/*  449 */         if (this._standardStringKey) {
/*  450 */           return _readAndBindStringKeyMap(p, ctxt, result);
/*      */         }
/*  452 */         return _readAndBind(p, ctxt, result);
/*      */       
/*      */       case 6:
/*  455 */         return _deserializeFromString(p, ctxt);
/*      */       
/*      */       case 3:
/*  458 */         return _deserializeFromArray(p, ctxt);
/*      */     } 
/*      */     
/*  461 */     return (Map<Object, Object>)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<Object, Object> deserialize(JsonParser p, DeserializationContext ctxt, Map<Object, Object> result) throws IOException {
/*  471 */     p.assignCurrentValue(result);
/*      */ 
/*      */     
/*  474 */     JsonToken t = p.currentToken();
/*  475 */     if (t != JsonToken.START_OBJECT && t != JsonToken.FIELD_NAME) {
/*  476 */       return (Map<Object, Object>)ctxt.handleUnexpectedToken(getMapClass(), p);
/*      */     }
/*      */     
/*  479 */     if (this._standardStringKey) {
/*  480 */       _readAndUpdateStringKeyMap(p, ctxt, result);
/*  481 */       return result;
/*      */     } 
/*  483 */     _readAndUpdate(p, ctxt, result);
/*  484 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/*  493 */     return typeDeserializer.deserializeTypedFromObject(p, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Class<?> getMapClass() {
/*  503 */     return this._containerType.getRawClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Map<Object, Object> _readAndBind(JsonParser p, DeserializationContext ctxt, Map<Object, Object> result) throws IOException {
/*  514 */     MapReferringAccumulator referringAccumulator = null;
/*  515 */     boolean useObjectId = (this._valueDeserializer.getObjectIdReader() != null);
/*  516 */     if (useObjectId) {
/*  517 */       referringAccumulator = new MapReferringAccumulator(this._containerType.getContentType().getRawClass(), result);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  522 */     if (p.isExpectedStartObjectToken()) {
/*  523 */       str = p.nextFieldName();
/*      */     } else {
/*  525 */       JsonToken t = p.currentToken();
/*  526 */       if (t != JsonToken.FIELD_NAME) {
/*  527 */         if (t == JsonToken.END_OBJECT) {
/*  528 */           return result;
/*      */         }
/*  530 */         ctxt.reportWrongTokenException(this, JsonToken.FIELD_NAME, null, new Object[0]);
/*      */       } 
/*  532 */       str = p.currentName();
/*      */     } 
/*      */     String str;
/*  535 */     for (; str != null; str = p.nextFieldName()) {
/*  536 */       Object key = this._keyDeserializer.deserializeKey(str, ctxt);
/*      */       
/*  538 */       JsonToken t = p.nextToken();
/*  539 */       if (this._inclusionChecker != null && this._inclusionChecker.shouldIgnore(str)) {
/*  540 */         p.skipChildren();
/*      */         
/*      */         continue;
/*      */       } 
/*      */       try {
/*      */         Object value;
/*  546 */         if (t == JsonToken.VALUE_NULL) {
/*  547 */           if (this._skipNullValues) {
/*      */             continue;
/*      */           }
/*  550 */           value = null;
/*      */         } else {
/*  552 */           value = _deserializeNoNullChecks(p, ctxt);
/*      */         } 
/*      */         
/*  555 */         if (value == null) {
/*  556 */           value = this._nullProvider.getNullValue(ctxt);
/*      */           
/*  558 */           if (value == null && this._skipNullValues) {
/*      */             continue;
/*      */           }
/*      */         } 
/*      */         
/*  563 */         if (useObjectId) {
/*  564 */           referringAccumulator.put(key, value);
/*      */         } else {
/*  566 */           Object oldValue = result.put(key, value);
/*  567 */           if (oldValue != null) {
/*  568 */             _squashDups(ctxt, result, key, oldValue, value);
/*      */           }
/*      */         } 
/*  571 */       } catch (UnresolvedForwardReference reference) {
/*  572 */         handleUnresolvedReference(ctxt, referringAccumulator, key, reference);
/*  573 */       } catch (Exception e) {
/*  574 */         wrapAndThrow(ctxt, e, result, str);
/*      */       }  continue;
/*      */     } 
/*  577 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Map<Object, Object> _readAndBindStringKeyMap(JsonParser p, DeserializationContext ctxt, Map<Object, Object> result) throws IOException {
/*  588 */     MapReferringAccumulator referringAccumulator = null;
/*  589 */     boolean useObjectId = (this._valueDeserializer.getObjectIdReader() != null);
/*  590 */     if (useObjectId) {
/*  591 */       referringAccumulator = new MapReferringAccumulator(this._containerType.getContentType().getRawClass(), result);
/*      */     }
/*      */ 
/*      */     
/*  595 */     if (p.isExpectedStartObjectToken()) {
/*  596 */       str = p.nextFieldName();
/*      */     } else {
/*  598 */       JsonToken t = p.currentToken();
/*  599 */       if (t == JsonToken.END_OBJECT) {
/*  600 */         return result;
/*      */       }
/*  602 */       if (t != JsonToken.FIELD_NAME) {
/*  603 */         ctxt.reportWrongTokenException(this, JsonToken.FIELD_NAME, null, new Object[0]);
/*      */       }
/*  605 */       str = p.currentName();
/*      */     } 
/*      */     String str;
/*  608 */     for (; str != null; str = p.nextFieldName()) {
/*  609 */       JsonToken t = p.nextToken();
/*  610 */       if (this._inclusionChecker != null && this._inclusionChecker.shouldIgnore(str)) {
/*  611 */         p.skipChildren();
/*      */         
/*      */         continue;
/*      */       } 
/*      */       try {
/*      */         Object value;
/*  617 */         if (t == JsonToken.VALUE_NULL) {
/*  618 */           if (this._skipNullValues) {
/*      */             continue;
/*      */           }
/*  621 */           value = null;
/*      */         } else {
/*  623 */           value = _deserializeNoNullChecks(p, ctxt);
/*      */         } 
/*      */         
/*  626 */         if (value == null) {
/*  627 */           value = this._nullProvider.getNullValue(ctxt);
/*      */           
/*  629 */           if (value == null && this._skipNullValues) {
/*      */             continue;
/*      */           }
/*      */         } 
/*      */         
/*  634 */         if (useObjectId) {
/*  635 */           referringAccumulator.put(str, value);
/*      */         } else {
/*  637 */           Object oldValue = result.put(str, value);
/*  638 */           if (oldValue != null) {
/*  639 */             _squashDups(ctxt, result, str, oldValue, value);
/*      */           }
/*      */         } 
/*  642 */       } catch (UnresolvedForwardReference reference) {
/*  643 */         handleUnresolvedReference(ctxt, referringAccumulator, str, reference);
/*  644 */       } catch (Exception e) {
/*  645 */         wrapAndThrow(ctxt, e, result, str);
/*      */       } 
/*      */       
/*      */       continue;
/*      */     } 
/*  650 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<Object, Object> _deserializeUsingCreator(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  656 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/*      */     
/*  658 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, null);
/*      */ 
/*      */     
/*  661 */     if (p.isExpectedStartObjectToken()) {
/*  662 */       str = p.nextFieldName();
/*  663 */     } else if (p.hasToken(JsonToken.FIELD_NAME)) {
/*  664 */       str = p.currentName();
/*      */     } else {
/*  666 */       str = null;
/*      */     } 
/*      */     String str;
/*  669 */     for (; str != null; str = p.nextFieldName()) {
/*  670 */       Object value; JsonToken t = p.nextToken();
/*  671 */       if (this._inclusionChecker != null && this._inclusionChecker.shouldIgnore(str)) {
/*  672 */         p.skipChildren();
/*      */         
/*      */         continue;
/*      */       } 
/*  676 */       SettableBeanProperty prop = creator.findCreatorProperty(str);
/*  677 */       if (prop != null) {
/*      */         
/*  679 */         if (buffer.assignParameter(prop, prop.deserialize(p, ctxt))) {
/*  680 */           Map<Object, Object> result; p.nextToken();
/*      */           
/*      */           try {
/*  683 */             result = (Map<Object, Object>)creator.build(ctxt, buffer);
/*  684 */           } catch (Exception e) {
/*  685 */             return (Map<Object, Object>)wrapAndThrow(ctxt, e, this._containerType.getRawClass(), str);
/*      */           } 
/*  687 */           return _readAndBind(p, ctxt, result);
/*      */         } 
/*      */         
/*      */         continue;
/*      */       } 
/*  692 */       Object actualKey = this._keyDeserializer.deserializeKey(str, ctxt);
/*      */ 
/*      */       
/*      */       try {
/*  696 */         if (t == JsonToken.VALUE_NULL) {
/*  697 */           if (this._skipNullValues) {
/*      */             continue;
/*      */           }
/*  700 */           value = null;
/*      */         } else {
/*  702 */           value = _deserializeNoNullChecks(p, ctxt);
/*      */         } 
/*      */         
/*  705 */         if (value == null) {
/*  706 */           value = this._nullProvider.getNullValue(ctxt);
/*      */           
/*  708 */           if (value == null && this._skipNullValues) {
/*      */             continue;
/*      */           }
/*      */         } 
/*  712 */       } catch (Exception e) {
/*  713 */         wrapAndThrow(ctxt, e, this._containerType.getRawClass(), str);
/*  714 */         return null;
/*      */       } 
/*  716 */       buffer.bufferMapProperty(actualKey, value);
/*      */       
/*      */       continue;
/*      */     } 
/*      */     try {
/*  721 */       return (Map<Object, Object>)creator.build(ctxt, buffer);
/*  722 */     } catch (Exception e) {
/*  723 */       wrapAndThrow(ctxt, e, this._containerType.getRawClass(), str);
/*  724 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _readAndUpdate(JsonParser p, DeserializationContext ctxt, Map<Object, Object> result) throws IOException {
/*  740 */     JsonDeserializer<Object> valueDes = this._valueDeserializer;
/*  741 */     TypeDeserializer typeDeser = this._valueTypeDeserializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  747 */     if (p.isExpectedStartObjectToken()) {
/*  748 */       str = p.nextFieldName();
/*      */     } else {
/*  750 */       JsonToken t = p.currentToken();
/*  751 */       if (t == JsonToken.END_OBJECT) {
/*      */         return;
/*      */       }
/*  754 */       if (t != JsonToken.FIELD_NAME) {
/*  755 */         ctxt.reportWrongTokenException(this, JsonToken.FIELD_NAME, null, new Object[0]);
/*      */       }
/*  757 */       str = p.currentName();
/*      */     } 
/*      */     String str;
/*  760 */     for (; str != null; str = p.nextFieldName()) {
/*  761 */       Object key = this._keyDeserializer.deserializeKey(str, ctxt);
/*      */       
/*  763 */       JsonToken t = p.nextToken();
/*  764 */       if (this._inclusionChecker != null && this._inclusionChecker.shouldIgnore(str)) {
/*  765 */         p.skipChildren();
/*      */         continue;
/*      */       } 
/*      */       try {
/*      */         Object value;
/*  770 */         if (t == JsonToken.VALUE_NULL) {
/*  771 */           if (!this._skipNullValues)
/*      */           {
/*      */             
/*  774 */             result.put(key, this._nullProvider.getNullValue(ctxt)); } 
/*      */           continue;
/*      */         } 
/*  777 */         Object old = result.get(key);
/*      */         
/*  779 */         if (old != null) {
/*  780 */           if (typeDeser == null) {
/*  781 */             value = valueDes.deserialize(p, ctxt, old);
/*      */           } else {
/*  783 */             value = valueDes.deserializeWithType(p, ctxt, typeDeser, old);
/*      */           } 
/*      */         } else {
/*  786 */           value = _deserializeNoNullChecks(p, ctxt);
/*      */         } 
/*      */         
/*  789 */         if (value == null) {
/*  790 */           value = this._nullProvider.getNullValue(ctxt);
/*      */           
/*  792 */           if (value == null && this._skipNullValues) {
/*      */             continue;
/*      */           }
/*      */         } 
/*      */         
/*  797 */         if (value != old) {
/*  798 */           result.put(key, value);
/*      */         }
/*  800 */       } catch (Exception e) {
/*  801 */         wrapAndThrow(ctxt, e, result, str);
/*      */       } 
/*      */       continue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _readAndUpdateStringKeyMap(JsonParser p, DeserializationContext ctxt, Map<Object, Object> result) throws IOException {
/*  816 */     JsonDeserializer<Object> valueDes = this._valueDeserializer;
/*  817 */     TypeDeserializer typeDeser = this._valueTypeDeserializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  823 */     if (p.isExpectedStartObjectToken()) {
/*  824 */       str = p.nextFieldName();
/*      */     } else {
/*  826 */       JsonToken t = p.currentToken();
/*  827 */       if (t == JsonToken.END_OBJECT) {
/*      */         return;
/*      */       }
/*  830 */       if (t != JsonToken.FIELD_NAME) {
/*  831 */         ctxt.reportWrongTokenException(this, JsonToken.FIELD_NAME, null, new Object[0]);
/*      */       }
/*  833 */       str = p.currentName();
/*      */     } 
/*      */     String str;
/*  836 */     for (; str != null; str = p.nextFieldName()) {
/*  837 */       JsonToken t = p.nextToken();
/*  838 */       if (this._inclusionChecker != null && this._inclusionChecker.shouldIgnore(str)) {
/*  839 */         p.skipChildren();
/*      */         continue;
/*      */       } 
/*      */       try {
/*      */         Object value;
/*  844 */         if (t == JsonToken.VALUE_NULL) {
/*  845 */           if (!this._skipNullValues)
/*      */           {
/*      */             
/*  848 */             result.put(str, this._nullProvider.getNullValue(ctxt)); } 
/*      */           continue;
/*      */         } 
/*  851 */         Object old = result.get(str);
/*      */         
/*  853 */         if (old != null) {
/*  854 */           if (typeDeser == null) {
/*  855 */             value = valueDes.deserialize(p, ctxt, old);
/*      */           } else {
/*  857 */             value = valueDes.deserializeWithType(p, ctxt, typeDeser, old);
/*      */           } 
/*      */         } else {
/*  860 */           value = _deserializeNoNullChecks(p, ctxt);
/*      */         } 
/*      */         
/*  863 */         if (value == null) {
/*  864 */           value = this._nullProvider.getNullValue(ctxt);
/*      */           
/*  866 */           if (value == null && this._skipNullValues) {
/*      */             continue;
/*      */           }
/*      */         } 
/*      */         
/*  871 */         if (value != old) {
/*  872 */           result.put(str, value);
/*      */         }
/*  874 */       } catch (Exception e) {
/*  875 */         wrapAndThrow(ctxt, e, result, str);
/*      */       } 
/*      */       continue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _deserializeNoNullChecks(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  890 */     if (this._valueTypeDeserializer == null) {
/*  891 */       return this._valueDeserializer.deserialize(p, ctxt);
/*      */     }
/*  893 */     return this._valueDeserializer.deserializeWithType(p, ctxt, this._valueTypeDeserializer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _squashDups(DeserializationContext ctxt, Map<Object, Object> result, Object key, Object oldValue, Object newValue) {
/*  904 */     if (this._checkDupSquash && ctxt.isEnabled(StreamReadCapability.DUPLICATE_PROPERTIES)) {
/*  905 */       if (oldValue instanceof List) {
/*  906 */         ((List<Object>)oldValue).add(newValue);
/*  907 */         result.put(key, oldValue);
/*      */       } else {
/*  909 */         ArrayList<Object> l = new ArrayList();
/*  910 */         l.add(oldValue);
/*  911 */         l.add(newValue);
/*  912 */         result.put(key, l);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleUnresolvedReference(DeserializationContext ctxt, MapReferringAccumulator accumulator, Object key, UnresolvedForwardReference reference) throws JsonMappingException {
/*  928 */     if (accumulator == null) {
/*  929 */       ctxt.reportInputMismatch(this, "Unresolved forward reference but no identity info: " + reference, new Object[0]);
/*      */     }
/*      */     
/*  932 */     ReadableObjectId.Referring referring = accumulator.handleUnresolvedReference(reference, key);
/*  933 */     reference.getRoid().appendReferring(referring);
/*      */   }
/*      */ 
/*      */   
/*      */   private static final class MapReferringAccumulator
/*      */   {
/*      */     private final Class<?> _valueType;
/*      */     
/*      */     private final Map<Object, Object> _result;
/*  942 */     private final List<MapDeserializer.MapReferring> _accumulator = new ArrayList<>();
/*      */     
/*      */     public MapReferringAccumulator(Class<?> valueType, Map<Object, Object> result) {
/*  945 */       this._valueType = valueType;
/*  946 */       this._result = result;
/*      */     }
/*      */ 
/*      */     
/*      */     public void put(Object key, Object value) {
/*  951 */       if (this._accumulator.isEmpty()) {
/*  952 */         this._result.put(key, value);
/*      */       } else {
/*  954 */         MapDeserializer.MapReferring ref = this._accumulator.get(this._accumulator.size() - 1);
/*  955 */         ref.next.put(key, value);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public ReadableObjectId.Referring handleUnresolvedReference(UnresolvedForwardReference reference, Object key) {
/*  961 */       MapDeserializer.MapReferring id = new MapDeserializer.MapReferring(this, reference, this._valueType, key);
/*  962 */       this._accumulator.add(id);
/*  963 */       return id;
/*      */     }
/*      */ 
/*      */     
/*      */     public void resolveForwardReference(Object id, Object value) throws IOException {
/*  968 */       Iterator<MapDeserializer.MapReferring> iterator = this._accumulator.iterator();
/*      */ 
/*      */ 
/*      */       
/*  972 */       Map<Object, Object> previous = this._result;
/*  973 */       while (iterator.hasNext()) {
/*  974 */         MapDeserializer.MapReferring ref = iterator.next();
/*  975 */         if (ref.hasId(id)) {
/*  976 */           iterator.remove();
/*  977 */           previous.put(ref.key, value);
/*  978 */           previous.putAll(ref.next);
/*      */           return;
/*      */         } 
/*  981 */         previous = ref.next;
/*      */       } 
/*      */       
/*  984 */       throw new IllegalArgumentException("Trying to resolve a forward reference with id [" + id + "] that wasn't previously seen as unresolved.");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class MapReferring
/*      */     extends ReadableObjectId.Referring
/*      */   {
/*      */     private final MapDeserializer.MapReferringAccumulator _parent;
/*      */ 
/*      */     
/*  997 */     public final Map<Object, Object> next = new LinkedHashMap<>();
/*      */     
/*      */     public final Object key;
/*      */ 
/*      */     
/*      */     MapReferring(MapDeserializer.MapReferringAccumulator parent, UnresolvedForwardReference ref, Class<?> valueType, Object key) {
/* 1003 */       super(ref, valueType);
/* 1004 */       this._parent = parent;
/* 1005 */       this.key = key;
/*      */     }
/*      */ 
/*      */     
/*      */     public void handleResolvedForwardReference(Object id, Object value) throws IOException {
/* 1010 */       this._parent.resolveForwardReference(id, value);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\MapDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */