/*     */ package com.fasterxml.jackson.databind.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*     */ import com.fasterxml.jackson.databind.deser.impl.PropertyValueBuffer;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedWithParams;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ValueInstantiator
/*     */ {
/*     */   public ValueInstantiator createContextual(DeserializationContext ctxt, BeanDescription beanDesc) throws JsonMappingException {
/*  73 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getValueClass() {
/*  93 */     return Object.class;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValueTypeDesc() {
/* 101 */     Class<?> cls = getValueClass();
/* 102 */     if (cls == null) {
/* 103 */       return "UNKNOWN";
/*     */     }
/* 105 */     return cls.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canInstantiate() {
/* 114 */     return (canCreateUsingDefault() || 
/* 115 */       canCreateUsingDelegate() || canCreateUsingArrayDelegate() || 
/* 116 */       canCreateFromObjectWith() || canCreateFromString() || 
/* 117 */       canCreateFromInt() || canCreateFromLong() || 
/* 118 */       canCreateFromDouble() || canCreateFromBoolean());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canCreateFromString() {
/* 128 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canCreateFromInt() {
/* 134 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canCreateFromLong() {
/* 140 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canCreateFromBigInteger() {
/* 146 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canCreateFromDouble() {
/* 152 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canCreateFromBigDecimal() {
/* 158 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canCreateFromBoolean() {
/* 164 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canCreateUsingDefault() {
/* 172 */     return (getDefaultCreator() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canCreateUsingDelegate() {
/* 179 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canCreateUsingArrayDelegate() {
/* 188 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canCreateFromObjectWith() {
/* 195 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SettableBeanProperty[] getFromObjectArguments(DeserializationConfig config) {
/* 208 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType getDelegateType(DeserializationConfig config) {
/* 218 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType getArrayDelegateType(DeserializationConfig config) {
/* 229 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createUsingDefault(DeserializationContext ctxt) throws IOException {
/* 248 */     return ctxt.handleMissingInstantiator(getValueClass(), this, null, "no default no-arguments constructor found", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createFromObjectWith(DeserializationContext ctxt, Object[] args) throws IOException {
/* 262 */     return ctxt.handleMissingInstantiator(getValueClass(), this, null, "no creator with arguments specified", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createUsingDefaultOrWithoutArguments(DeserializationContext ctxt) throws IOException {
/* 275 */     return ctxt.handleMissingInstantiator(getValueClass(), this, null, "neither default (no-arguments) nor with-arguments Creator found", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createFromObjectWith(DeserializationContext ctxt, SettableBeanProperty[] props, PropertyValueBuffer buffer) throws IOException {
/* 301 */     return createFromObjectWith(ctxt, buffer.getParameters(props));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createUsingDelegate(DeserializationContext ctxt, Object delegate) throws IOException {
/* 309 */     return ctxt.handleMissingInstantiator(getValueClass(), this, null, "no delegate creator specified", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createUsingArrayDelegate(DeserializationContext ctxt, Object delegate) throws IOException {
/* 318 */     return ctxt.handleMissingInstantiator(getValueClass(), this, null, "no array delegate creator specified", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createFromString(DeserializationContext ctxt, String value) throws IOException {
/* 330 */     return ctxt.handleMissingInstantiator(getValueClass(), this, ctxt.getParser(), "no String-argument constructor/factory method to deserialize from String value ('%s')", new Object[] { value });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createFromInt(DeserializationContext ctxt, int value) throws IOException {
/* 337 */     return ctxt.handleMissingInstantiator(getValueClass(), this, null, "no int/Int-argument constructor/factory method to deserialize from Number value (%s)", new Object[] {
/*     */           
/* 339 */           Integer.valueOf(value) });
/*     */   }
/*     */   
/*     */   public Object createFromLong(DeserializationContext ctxt, long value) throws IOException {
/* 343 */     return ctxt.handleMissingInstantiator(getValueClass(), this, null, "no long/Long-argument constructor/factory method to deserialize from Number value (%s)", new Object[] {
/*     */           
/* 345 */           Long.valueOf(value)
/*     */         });
/*     */   }
/*     */   
/*     */   public Object createFromBigInteger(DeserializationContext ctxt, BigInteger value) throws IOException {
/* 350 */     return ctxt.handleMissingInstantiator(getValueClass(), this, null, "no BigInteger-argument constructor/factory method to deserialize from Number value (%s)", new Object[] { value });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createFromDouble(DeserializationContext ctxt, double value) throws IOException {
/* 357 */     return ctxt.handleMissingInstantiator(getValueClass(), this, null, "no double/Double-argument constructor/factory method to deserialize from Number value (%s)", new Object[] {
/*     */           
/* 359 */           Double.valueOf(value)
/*     */         });
/*     */   }
/*     */   
/*     */   public Object createFromBigDecimal(DeserializationContext ctxt, BigDecimal value) throws IOException {
/* 364 */     return ctxt.handleMissingInstantiator(getValueClass(), this, null, "no BigDecimal/double/Double-argument constructor/factory method to deserialize from Number value (%s)", new Object[] { value });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createFromBoolean(DeserializationContext ctxt, boolean value) throws IOException {
/* 371 */     return ctxt.handleMissingInstantiator(getValueClass(), this, null, "no boolean/Boolean-argument constructor/factory method to deserialize from boolean value (%s)", new Object[] {
/*     */           
/* 373 */           Boolean.valueOf(value)
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedWithParams getDefaultCreator() {
/* 392 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedWithParams getDelegateCreator() {
/* 402 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedWithParams getArrayDelegateCreator() {
/* 412 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedWithParams getWithArgsCreator() {
/* 423 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected Object _createFromStringFallbacks(DeserializationContext ctxt, String value) throws IOException {
/* 441 */     if (value.isEmpty() && 
/* 442 */       ctxt.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)) {
/* 443 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 451 */     if (canCreateFromBoolean())
/*     */     {
/* 453 */       if (ctxt.findCoercionAction(LogicalType.Boolean, Boolean.class, CoercionInputShape.String) == CoercionAction.TryConvert) {
/*     */         
/* 455 */         String str = value.trim();
/* 456 */         if ("true".equals(str)) {
/* 457 */           return createFromBoolean(ctxt, true);
/*     */         }
/* 459 */         if ("false".equals(str)) {
/* 460 */           return createFromBoolean(ctxt, false);
/*     */         }
/*     */       } 
/*     */     }
/* 464 */     return ctxt.handleMissingInstantiator(getValueClass(), this, ctxt.getParser(), "no String-argument constructor/factory method to deserialize from String value ('%s')", new Object[] { value });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface Gettable
/*     */   {
/*     */     ValueInstantiator getValueInstantiator();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Base
/*     */     extends ValueInstantiator
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/*     */     protected final Class<?> _valueType;
/*     */ 
/*     */     
/*     */     public Base(Class<?> type) {
/* 487 */       this._valueType = type;
/*     */     }
/*     */     
/*     */     public Base(JavaType type) {
/* 491 */       this._valueType = type.getRawClass();
/*     */     }
/*     */ 
/*     */     
/*     */     public String getValueTypeDesc() {
/* 496 */       return this._valueType.getName();
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> getValueClass() {
/* 501 */       return this._valueType;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Delegating
/*     */     extends ValueInstantiator
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/*     */     protected final ValueInstantiator _delegate;
/*     */ 
/*     */ 
/*     */     
/*     */     protected Delegating(ValueInstantiator delegate) {
/* 519 */       this._delegate = delegate;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ValueInstantiator createContextual(DeserializationContext ctxt, BeanDescription beanDesc) throws JsonMappingException {
/* 526 */       ValueInstantiator d = this._delegate.createContextual(ctxt, beanDesc);
/* 527 */       return (d == this._delegate) ? this : new Delegating(d);
/*     */     }
/*     */     protected ValueInstantiator delegate() {
/* 530 */       return this._delegate;
/*     */     }
/*     */     public Class<?> getValueClass() {
/* 533 */       return delegate().getValueClass();
/*     */     }
/*     */     public String getValueTypeDesc() {
/* 536 */       return delegate().getValueTypeDesc();
/*     */     }
/*     */     public boolean canInstantiate() {
/* 539 */       return delegate().canInstantiate();
/*     */     }
/*     */     public boolean canCreateFromString() {
/* 542 */       return delegate().canCreateFromString();
/*     */     } public boolean canCreateFromInt() {
/* 544 */       return delegate().canCreateFromInt();
/*     */     } public boolean canCreateFromLong() {
/* 546 */       return delegate().canCreateFromLong();
/*     */     } public boolean canCreateFromDouble() {
/* 548 */       return delegate().canCreateFromDouble();
/*     */     } public boolean canCreateFromBoolean() {
/* 550 */       return delegate().canCreateFromBoolean();
/*     */     } public boolean canCreateUsingDefault() {
/* 552 */       return delegate().canCreateUsingDefault();
/*     */     } public boolean canCreateUsingDelegate() {
/* 554 */       return delegate().canCreateUsingDelegate();
/*     */     } public boolean canCreateUsingArrayDelegate() {
/* 556 */       return delegate().canCreateUsingArrayDelegate();
/*     */     } public boolean canCreateFromObjectWith() {
/* 558 */       return delegate().canCreateFromObjectWith();
/*     */     }
/*     */     
/*     */     public SettableBeanProperty[] getFromObjectArguments(DeserializationConfig config) {
/* 562 */       return delegate().getFromObjectArguments(config);
/*     */     }
/*     */ 
/*     */     
/*     */     public JavaType getDelegateType(DeserializationConfig config) {
/* 567 */       return delegate().getDelegateType(config);
/*     */     }
/*     */ 
/*     */     
/*     */     public JavaType getArrayDelegateType(DeserializationConfig config) {
/* 572 */       return delegate().getArrayDelegateType(config);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException {
/* 583 */       return delegate().createUsingDefault(ctxt);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createFromObjectWith(DeserializationContext ctxt, Object[] args) throws IOException {
/* 588 */       return delegate().createFromObjectWith(ctxt, args);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object createFromObjectWith(DeserializationContext ctxt, SettableBeanProperty[] props, PropertyValueBuffer buffer) throws IOException {
/* 595 */       return delegate().createFromObjectWith(ctxt, props, buffer);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createUsingDelegate(DeserializationContext ctxt, Object delegate) throws IOException {
/* 600 */       return delegate().createUsingDelegate(ctxt, delegate);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createUsingArrayDelegate(DeserializationContext ctxt, Object delegate) throws IOException {
/* 605 */       return delegate().createUsingArrayDelegate(ctxt, delegate);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createFromString(DeserializationContext ctxt, String value) throws IOException {
/* 610 */       return delegate().createFromString(ctxt, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createFromInt(DeserializationContext ctxt, int value) throws IOException {
/* 615 */       return delegate().createFromInt(ctxt, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createFromLong(DeserializationContext ctxt, long value) throws IOException {
/* 620 */       return delegate().createFromLong(ctxt, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createFromBigInteger(DeserializationContext ctxt, BigInteger value) throws IOException {
/* 625 */       return delegate().createFromBigInteger(ctxt, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createFromDouble(DeserializationContext ctxt, double value) throws IOException {
/* 630 */       return delegate().createFromDouble(ctxt, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createFromBigDecimal(DeserializationContext ctxt, BigDecimal value) throws IOException {
/* 635 */       return delegate().createFromBigDecimal(ctxt, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createFromBoolean(DeserializationContext ctxt, boolean value) throws IOException {
/* 640 */       return delegate().createFromBoolean(ctxt, value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnnotatedWithParams getDefaultCreator() {
/* 650 */       return delegate().getDefaultCreator();
/*     */     }
/*     */     public AnnotatedWithParams getDelegateCreator() {
/* 653 */       return delegate().getDelegateCreator();
/*     */     }
/*     */     public AnnotatedWithParams getArrayDelegateCreator() {
/* 656 */       return delegate().getArrayDelegateCreator();
/*     */     }
/*     */     public AnnotatedWithParams getWithArgsCreator() {
/* 659 */       return delegate().getWithArgsCreator();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\ValueInstantiator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */