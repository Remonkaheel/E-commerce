/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.ResolvableDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ObjectIdReader;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DelegatingDeserializer
/*     */   extends StdDeserializer<Object>
/*     */   implements ContextualDeserializer, ResolvableDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JsonDeserializer<?> _delegatee;
/*     */   
/*     */   public DelegatingDeserializer(JsonDeserializer<?> d) {
/*  39 */     super(d.handledType());
/*  40 */     this._delegatee = d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract JsonDeserializer<?> newDelegatingInstance(JsonDeserializer<?> paramJsonDeserializer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(DeserializationContext ctxt) throws JsonMappingException {
/*  59 */     if (this._delegatee instanceof ResolvableDeserializer) {
/*  60 */       ((ResolvableDeserializer)this._delegatee).resolve(ctxt);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/*  69 */     JavaType vt = ctxt.constructType(this._delegatee.handledType());
/*  70 */     JsonDeserializer<?> del = ctxt.handleSecondaryContextualization(this._delegatee, property, vt);
/*     */     
/*  72 */     if (del == this._delegatee) {
/*  73 */       return this;
/*     */     }
/*  75 */     return newDelegatingInstance(del);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<Object> unwrappingDeserializer(NameTransformer unwrapper) {
/*  81 */     JsonDeserializer<?> unwrapping = this._delegatee.unwrappingDeserializer(unwrapper);
/*  82 */     if (unwrapping == this._delegatee) {
/*  83 */       return this;
/*     */     }
/*  85 */     return (JsonDeserializer)newDelegatingInstance(unwrapping);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> replaceDelegatee(JsonDeserializer<?> delegatee) {
/*  91 */     if (delegatee == this._delegatee) {
/*  92 */       return this;
/*     */     }
/*  94 */     return newDelegatingInstance(delegatee);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 107 */     return this._delegatee.deserialize(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt, Object intoValue) throws IOException {
/* 116 */     return this._delegatee.deserialize(p, ctxt, intoValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 124 */     return this._delegatee.deserializeWithType(p, ctxt, typeDeserializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/* 134 */     return this._delegatee.isCachable();
/*     */   }
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 138 */     return this._delegatee.supportsUpdate(config);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> getDelegatee() {
/* 143 */     return this._delegatee;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SettableBeanProperty findBackReference(String logicalName) {
/* 149 */     return this._delegatee.findBackReference(logicalName);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getNullValue(DeserializationContext ctxt) throws JsonMappingException {
/* 154 */     return this._delegatee.getNullValue(ctxt);
/*     */   }
/*     */ 
/*     */   
/*     */   public AccessPattern getNullAccessPattern() {
/* 159 */     return this._delegatee.getNullAccessPattern();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getAbsentValue(DeserializationContext ctxt) throws JsonMappingException {
/* 164 */     return this._delegatee.getAbsentValue(ctxt);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/* 169 */     return this._delegatee.getEmptyValue(ctxt);
/*     */   }
/*     */ 
/*     */   
/*     */   public AccessPattern getEmptyAccessPattern() {
/* 174 */     return this._delegatee.getEmptyAccessPattern();
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 179 */     return this._delegatee.logicalType();
/*     */   }
/*     */   
/*     */   public Collection<Object> getKnownPropertyNames() {
/* 183 */     return this._delegatee.getKnownPropertyNames();
/*     */   }
/*     */   public ObjectIdReader getObjectIdReader() {
/* 186 */     return this._delegatee.getObjectIdReader();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\DelegatingDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */