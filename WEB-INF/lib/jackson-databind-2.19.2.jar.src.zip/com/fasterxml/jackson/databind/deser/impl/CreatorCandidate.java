/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JacksonInject;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedParameter;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedWithParams;
/*     */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*     */ 
/*     */ 
/*     */ public final class CreatorCandidate
/*     */ {
/*     */   protected final AnnotationIntrospector _intr;
/*     */   protected final AnnotatedWithParams _creator;
/*     */   protected final int _paramCount;
/*     */   protected final Param[] _params;
/*     */   
/*     */   protected CreatorCandidate(AnnotationIntrospector intr, AnnotatedWithParams ct, Param[] params, int count) {
/*  20 */     this._intr = intr;
/*  21 */     this._creator = ct;
/*  22 */     this._params = params;
/*  23 */     this._paramCount = count;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static CreatorCandidate construct(AnnotationIntrospector intr, AnnotatedWithParams creator, BeanPropertyDefinition[] propDefs) {
/*  29 */     int pcount = creator.getParameterCount();
/*  30 */     Param[] params = new Param[pcount];
/*  31 */     for (int i = 0; i < pcount; i++) {
/*  32 */       AnnotatedParameter annParam = creator.getParameter(i);
/*  33 */       JacksonInject.Value injectId = intr.findInjectableValue((AnnotatedMember)annParam);
/*  34 */       params[i] = new Param(annParam, (propDefs == null) ? null : propDefs[i], injectId);
/*     */     } 
/*  36 */     return new CreatorCandidate(intr, creator, params, pcount);
/*     */   }
/*     */   
/*  39 */   public AnnotatedWithParams creator() { return this._creator; }
/*  40 */   public int paramCount() { return this._paramCount; }
/*  41 */   public JacksonInject.Value injection(int i) { return (this._params[i]).injection; }
/*  42 */   public AnnotatedParameter parameter(int i) { return (this._params[i]).annotated; } public BeanPropertyDefinition propertyDef(int i) {
/*  43 */     return (this._params[i]).propDef;
/*     */   }
/*     */   public PropertyName paramName(int i) {
/*  46 */     BeanPropertyDefinition propDef = (this._params[i]).propDef;
/*  47 */     if (propDef != null) {
/*  48 */       return propDef.getFullName();
/*     */     }
/*  50 */     return null;
/*     */   }
/*     */   
/*     */   public PropertyName explicitParamName(int i) {
/*  54 */     BeanPropertyDefinition propDef = (this._params[i]).propDef;
/*  55 */     if (propDef != null && 
/*  56 */       propDef.isExplicitlyNamed()) {
/*  57 */       return propDef.getFullName();
/*     */     }
/*     */     
/*  60 */     return null;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public PropertyName findImplicitParamName(int i) {
/*  65 */     String str = this._intr.findImplicitPropertyName((AnnotatedMember)(this._params[i]).annotated);
/*  66 */     if (str != null && !str.isEmpty()) {
/*  67 */       return PropertyName.construct(str);
/*     */     }
/*  69 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public int findOnlyParamWithoutInjectionX() {
/*  75 */     int missing = -1;
/*  76 */     for (int i = 0; i < this._paramCount; i++) {
/*  77 */       if ((this._params[i]).injection == null) {
/*  78 */         if (missing >= 0) {
/*  79 */           return -1;
/*     */         }
/*  81 */         missing = i;
/*     */       } 
/*     */     } 
/*  84 */     return missing;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  89 */     return this._creator.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class Param
/*     */   {
/*     */     public final AnnotatedParameter annotated;
/*     */     public final BeanPropertyDefinition propDef;
/*     */     public final JacksonInject.Value injection;
/*     */     
/*     */     public Param(AnnotatedParameter p, BeanPropertyDefinition pd, JacksonInject.Value i) {
/* 100 */       this.annotated = p;
/* 101 */       this.propDef = pd;
/* 102 */       this.injection = i;
/*     */     }
/*     */     
/*     */     public PropertyName fullName() {
/* 106 */       if (this.propDef == null) {
/* 107 */         return null;
/*     */       }
/* 109 */       return this.propDef.getFullName();
/*     */     }
/*     */     
/*     */     public boolean hasFullName() {
/* 113 */       if (this.propDef == null) {
/* 114 */         return false;
/*     */       }
/* 116 */       PropertyName n = this.propDef.getFullName();
/* 117 */       return n.hasSimpleName();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\impl\CreatorCandidate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */