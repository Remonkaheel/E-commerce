/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedConstructor;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Constructor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InnerClassProperty
/*     */   extends SettableBeanProperty.Delegating
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final transient Constructor<?> _creator;
/*     */   protected AnnotatedConstructor _annotated;
/*     */   
/*     */   public InnerClassProperty(SettableBeanProperty delegate, Constructor<?> ctor) {
/*  38 */     super(delegate);
/*  39 */     this._creator = ctor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InnerClassProperty(SettableBeanProperty src, AnnotatedConstructor ann) {
/*  48 */     super(src);
/*  49 */     this._annotated = ann;
/*  50 */     this._creator = (this._annotated == null) ? null : this._annotated.getAnnotated();
/*  51 */     if (this._creator == null) {
/*  52 */       throw new IllegalArgumentException("Missing constructor (broken JDK (de)serialization?)");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected SettableBeanProperty withDelegate(SettableBeanProperty d) {
/*  58 */     if (d == this.delegate) {
/*  59 */       return (SettableBeanProperty)this;
/*     */     }
/*  61 */     return (SettableBeanProperty)new InnerClassProperty(d, this._creator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deserializeAndSet(JsonParser p, DeserializationContext ctxt, Object bean) throws IOException {
/*     */     Object value;
/*  74 */     JsonToken t = p.currentToken();
/*     */     
/*  76 */     if (t == JsonToken.VALUE_NULL) {
/*  77 */       value = this._valueDeserializer.getNullValue(ctxt);
/*  78 */     } else if (this._valueTypeDeserializer != null) {
/*  79 */       value = this._valueDeserializer.deserializeWithType(p, ctxt, this._valueTypeDeserializer);
/*     */     } else {
/*     */       try {
/*  82 */         value = this._creator.newInstance(new Object[] { bean });
/*  83 */       } catch (Exception e) {
/*  84 */         ClassUtil.unwrapAndThrowAsIAE(e, String.format("Failed to instantiate class %s, problem: %s", new Object[] { this._creator
/*     */                 
/*  86 */                 .getDeclaringClass().getName(), e.getMessage() }));
/*  87 */         value = null;
/*     */       } 
/*  89 */       this._valueDeserializer.deserialize(p, ctxt, value);
/*     */     } 
/*  91 */     set(bean, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeSetAndReturn(JsonParser p, DeserializationContext ctxt, Object instance) throws IOException {
/*  98 */     return setAndReturn(instance, deserialize(p, ctxt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object readResolve() {
/* 113 */     return new InnerClassProperty((SettableBeanProperty)this, this._annotated);
/*     */   }
/*     */ 
/*     */   
/*     */   Object writeReplace() {
/* 118 */     if (this._annotated == null) {
/* 119 */       return new InnerClassProperty((SettableBeanProperty)this, new AnnotatedConstructor(null, this._creator, null, null));
/*     */     }
/* 121 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\impl\InnerClassProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */