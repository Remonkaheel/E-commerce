/*     */ package com.fasterxml.jackson.databind.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.deser.std.StdDelegatingDeserializer;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.type.ArrayType;
/*     */ import com.fasterxml.jackson.databind.type.CollectionLikeType;
/*     */ import com.fasterxml.jackson.databind.type.CollectionType;
/*     */ import com.fasterxml.jackson.databind.type.MapLikeType;
/*     */ import com.fasterxml.jackson.databind.type.MapType;
/*     */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import com.fasterxml.jackson.databind.util.LRUMap;
/*     */ import com.fasterxml.jackson.databind.util.LookupCache;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DeserializerCache
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final int DEFAULT_MAX_CACHE_SIZE = 2000;
/*     */   protected final LookupCache<JavaType, JsonDeserializer<Object>> _cachedDeserializers;
/*  55 */   protected final HashMap<JavaType, JsonDeserializer<Object>> _incompleteDeserializers = new HashMap<>(8);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private final ReentrantLock _incompleteDeserializersLock = new ReentrantLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeserializerCache() {
/*  73 */     this(2000);
/*     */   }
/*     */   
/*     */   public DeserializerCache(int maxSize) {
/*  77 */     this((LookupCache<JavaType, JsonDeserializer<Object>>)new LRUMap(Math.min(64, maxSize >> 2), maxSize));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeserializerCache(LookupCache<JavaType, JsonDeserializer<Object>> cache) {
/*  84 */     this._cachedDeserializers = cache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeserializerCache emptyCopy() {
/*  91 */     return new DeserializerCache(this._cachedDeserializers.emptyCopy());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object writeReplace() {
/* 102 */     this._incompleteDeserializers.clear();
/* 103 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int cachedDeserializersCount() {
/* 125 */     return this._cachedDeserializers.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flushCachedDeserializers() {
/* 136 */     this._cachedDeserializers.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<Object> findValueDeserializer(DeserializationContext ctxt, DeserializerFactory factory, JavaType propertyType) throws JsonMappingException {
/* 171 */     Objects.requireNonNull(propertyType, "Null 'propertyType' passed");
/* 172 */     JsonDeserializer<Object> deser = _findCachedDeserializer(propertyType);
/* 173 */     if (deser == null) {
/*     */       
/* 175 */       deser = _createAndCacheValueDeserializer(ctxt, factory, propertyType);
/* 176 */       if (deser == null)
/*     */       {
/*     */ 
/*     */         
/* 180 */         deser = _handleUnknownValueDeserializer(ctxt, propertyType);
/*     */       }
/*     */     } 
/* 183 */     return deser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyDeserializer findKeyDeserializer(DeserializationContext ctxt, DeserializerFactory factory, JavaType type) throws JsonMappingException {
/* 198 */     Objects.requireNonNull(type, "Null 'type' passed");
/* 199 */     KeyDeserializer kd = factory.createKeyDeserializer(ctxt, type);
/* 200 */     if (kd == null) {
/* 201 */       return _handleUnknownKeyDeserializer(ctxt, type);
/*     */     }
/*     */     
/* 204 */     if (kd instanceof ResolvableDeserializer) {
/* 205 */       ((ResolvableDeserializer)kd).resolve(ctxt);
/*     */     }
/* 207 */     return kd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasValueDeserializerFor(DeserializationContext ctxt, DeserializerFactory factory, JavaType type) throws JsonMappingException {
/* 219 */     Objects.requireNonNull(type, "Null 'type' passed");
/*     */ 
/*     */ 
/*     */     
/* 223 */     JsonDeserializer<Object> deser = _findCachedDeserializer(type);
/* 224 */     if (deser == null) {
/* 225 */       deser = _createAndCacheValueDeserializer(ctxt, factory, type);
/*     */     }
/* 227 */     return (deser != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> _findCachedDeserializer(JavaType type) {
/* 239 */     if (_hasCustomHandlers(type)) {
/* 240 */       return null;
/*     */     }
/* 242 */     return (JsonDeserializer<Object>)this._cachedDeserializers.get(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> _createAndCacheValueDeserializer(DeserializationContext ctxt, DeserializerFactory factory, JavaType type) throws JsonMappingException {
/* 259 */     boolean isCustom = _hasCustomHandlers(type);
/* 260 */     if (!isCustom) {
/* 261 */       JsonDeserializer<Object> deser = (JsonDeserializer<Object>)this._cachedDeserializers.get(type);
/* 262 */       if (deser != null) {
/* 263 */         return deser;
/*     */       }
/*     */     } 
/* 266 */     this._incompleteDeserializersLock.lock();
/*     */     try {
/* 268 */       if (!isCustom) {
/* 269 */         JsonDeserializer<Object> deser = (JsonDeserializer<Object>)this._cachedDeserializers.get(type);
/* 270 */         if (deser != null) {
/* 271 */           return deser;
/*     */         }
/*     */       } 
/*     */       
/* 275 */       int count = this._incompleteDeserializers.size();
/*     */       
/* 277 */       if (count > 0) {
/* 278 */         JsonDeserializer<Object> deser = this._incompleteDeserializers.get(type);
/* 279 */         if (deser != null) {
/* 280 */           return deser;
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */       
/* 293 */       this._incompleteDeserializersLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected JsonDeserializer<Object> _createAndCache2(DeserializationContext ctxt, DeserializerFactory factory, JavaType type) throws JsonMappingException {
/* 308 */     return _createAndCache2(ctxt, factory, type, _hasCustomHandlers(type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> _createAndCache2(DeserializationContext ctxt, DeserializerFactory factory, JavaType type, boolean isCustom) throws JsonMappingException {
/*     */     JsonDeserializer<Object> deser;
/*     */     try {
/* 318 */       deser = _createDeserializer(ctxt, factory, type);
/* 319 */     } catch (IllegalArgumentException iae) {
/*     */ 
/*     */       
/* 322 */       ctxt.reportBadDefinition(type, ClassUtil.exceptionMessage(iae));
/* 323 */       deser = null;
/*     */     } 
/* 325 */     if (deser == null) {
/* 326 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 332 */     boolean addToCache = (!isCustom && deser.isCachable());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 345 */     if (deser instanceof ResolvableDeserializer) {
/* 346 */       this._incompleteDeserializers.put(type, deser);
/*     */       try {
/* 348 */         ((ResolvableDeserializer)deser).resolve(ctxt);
/*     */       } finally {
/* 350 */         this._incompleteDeserializers.remove(type);
/*     */       } 
/*     */     } 
/* 353 */     if (addToCache) {
/* 354 */       this._cachedDeserializers.put(type, deser);
/*     */     }
/* 356 */     return deser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> _createDeserializer(DeserializationContext ctxt, DeserializerFactory factory, JavaType type) throws JsonMappingException {
/* 375 */     DeserializationConfig config = ctxt.getConfig();
/*     */ 
/*     */     
/* 378 */     if (type.isAbstract() || type.isMapLikeType() || type.isCollectionLikeType()) {
/* 379 */       type = factory.mapAbstractType(config, type);
/*     */     }
/* 381 */     BeanDescription beanDesc = config.introspect(type);
/*     */     
/* 383 */     JsonDeserializer<Object> deser = findDeserializerFromAnnotation(ctxt, (Annotated)beanDesc
/* 384 */         .getClassInfo());
/* 385 */     if (deser != null) {
/* 386 */       return deser;
/*     */     }
/*     */ 
/*     */     
/* 390 */     JavaType newType = modifyTypeByAnnotation(ctxt, (Annotated)beanDesc.getClassInfo(), type);
/* 391 */     if (newType != type) {
/* 392 */       type = newType;
/* 393 */       beanDesc = config.introspect(newType);
/*     */     } 
/*     */ 
/*     */     
/* 397 */     Class<?> builder = beanDesc.findPOJOBuilder();
/* 398 */     if (builder != null) {
/* 399 */       return factory.createBuilderBasedDeserializer(ctxt, type, beanDesc, builder);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 404 */     Converter<Object, Object> conv = beanDesc.findDeserializationConverter();
/* 405 */     if (conv != null) {
/*     */       
/* 407 */       JavaType delegateType = conv.getInputType(ctxt.getTypeFactory());
/*     */       
/* 409 */       if (!delegateType.hasRawClass(type.getRawClass())) {
/* 410 */         beanDesc = config.introspect(delegateType);
/*     */       }
/* 412 */       return (JsonDeserializer<Object>)new StdDelegatingDeserializer(conv, delegateType, 
/* 413 */           _createDeserializer2(ctxt, factory, delegateType, beanDesc));
/*     */     } 
/*     */     
/* 416 */     return (JsonDeserializer)_createDeserializer2(ctxt, factory, type, beanDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<?> _createDeserializer2(DeserializationContext ctxt, DeserializerFactory factory, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/* 423 */     DeserializationConfig config = ctxt.getConfig();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 428 */     if (type.isEnumType()) {
/* 429 */       return factory.createEnumDeserializer(ctxt, type, beanDesc);
/*     */     }
/* 431 */     if (type.isContainerType()) {
/* 432 */       if (type.isArrayType()) {
/* 433 */         return factory.createArrayDeserializer(ctxt, (ArrayType)type, beanDesc);
/*     */       }
/* 435 */       if (type.isMapLikeType()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 441 */         JsonFormat.Value format = beanDesc.findExpectedFormat();
/* 442 */         if (format.getShape() != JsonFormat.Shape.OBJECT) {
/* 443 */           MapLikeType mlt = (MapLikeType)type;
/* 444 */           if (mlt instanceof MapType) {
/* 445 */             return factory.createMapDeserializer(ctxt, (MapType)mlt, beanDesc);
/*     */           }
/* 447 */           return factory.createMapLikeDeserializer(ctxt, mlt, beanDesc);
/*     */         } 
/*     */       } 
/* 450 */       if (type.isCollectionLikeType()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 456 */         JsonFormat.Value format = beanDesc.findExpectedFormat();
/* 457 */         if (format.getShape() != JsonFormat.Shape.OBJECT) {
/* 458 */           CollectionLikeType clt = (CollectionLikeType)type;
/* 459 */           if (clt instanceof CollectionType) {
/* 460 */             return factory.createCollectionDeserializer(ctxt, (CollectionType)clt, beanDesc);
/*     */           }
/* 462 */           return factory.createCollectionLikeDeserializer(ctxt, clt, beanDesc);
/*     */         } 
/*     */       } 
/*     */     } 
/* 466 */     if (type.isReferenceType()) {
/* 467 */       return factory.createReferenceDeserializer(ctxt, (ReferenceType)type, beanDesc);
/*     */     }
/* 469 */     if (JsonNode.class.isAssignableFrom(type.getRawClass())) {
/* 470 */       return factory.createTreeDeserializer(config, type, beanDesc);
/*     */     }
/* 472 */     return factory.createBeanDeserializer(ctxt, type, beanDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> findDeserializerFromAnnotation(DeserializationContext ctxt, Annotated ann) throws JsonMappingException {
/* 484 */     Object deserDef = ctxt.getAnnotationIntrospector().findDeserializer(ann);
/* 485 */     if (deserDef == null) {
/* 486 */       return null;
/*     */     }
/* 488 */     JsonDeserializer<Object> deser = ctxt.deserializerInstance(ann, deserDef);
/*     */     
/* 490 */     return findConvertingDeserializer(ctxt, ann, deser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> findConvertingDeserializer(DeserializationContext ctxt, Annotated a, JsonDeserializer<Object> deser) throws JsonMappingException {
/* 503 */     Converter<Object, Object> conv = findConverter(ctxt, a);
/* 504 */     if (conv == null) {
/* 505 */       return deser;
/*     */     }
/* 507 */     JavaType delegateType = conv.getInputType(ctxt.getTypeFactory());
/* 508 */     return (JsonDeserializer<Object>)new StdDelegatingDeserializer(conv, delegateType, deser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Converter<Object, Object> findConverter(DeserializationContext ctxt, Annotated a) throws JsonMappingException {
/* 515 */     Object convDef = ctxt.getAnnotationIntrospector().findDeserializationConverter(a);
/* 516 */     if (convDef == null) {
/* 517 */       return null;
/*     */     }
/* 519 */     return ctxt.converterInstance(a, convDef);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JavaType modifyTypeByAnnotation(DeserializationContext ctxt, Annotated a, JavaType type) throws JsonMappingException {
/*     */     MapLikeType mapLikeType;
/* 541 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 542 */     if (intr == null) {
/* 543 */       return type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 549 */     if (type.isMapLikeType()) {
/* 550 */       JavaType keyType = type.getKeyType();
/*     */ 
/*     */ 
/*     */       
/* 554 */       if (keyType != null && keyType.getValueHandler() == null) {
/* 555 */         Object kdDef = intr.findKeyDeserializer(a);
/* 556 */         if (kdDef != null) {
/* 557 */           KeyDeserializer kd = ctxt.keyDeserializerInstance(a, kdDef);
/* 558 */           if (kd != null) {
/* 559 */             mapLikeType = ((MapLikeType)type).withKeyValueHandler(kd);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 565 */     JavaType contentType = mapLikeType.getContentType();
/* 566 */     if (contentType != null && 
/* 567 */       contentType.getValueHandler() == null) {
/* 568 */       Object cdDef = intr.findContentDeserializer(a);
/* 569 */       if (cdDef != null) {
/* 570 */         JsonDeserializer<?> cd = null;
/* 571 */         if (cdDef instanceof JsonDeserializer) {
/* 572 */           cd = (JsonDeserializer)cdDef;
/*     */         } else {
/* 574 */           Class<?> cdClass = _verifyAsClass(cdDef, "findContentDeserializer", JsonDeserializer.None.class);
/* 575 */           if (cdClass != null) {
/* 576 */             cd = ctxt.deserializerInstance(a, cdClass);
/*     */           }
/*     */         } 
/* 579 */         if (cd != null) {
/* 580 */           javaType1 = mapLikeType.withContentValueHandler(cd);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 588 */     JavaType javaType1 = intr.refineDeserializationType((MapperConfig)ctxt.getConfig(), a, javaType1);
/*     */     
/* 590 */     return javaType1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _hasCustomHandlers(JavaType t) {
/* 606 */     if (t.isContainerType()) {
/*     */       
/* 608 */       JavaType ct = t.getContentType();
/* 609 */       if (ct != null && (
/* 610 */         ct.getValueHandler() != null || ct.getTypeHandler() != null)) {
/* 611 */         return true;
/*     */       }
/*     */ 
/*     */       
/* 615 */       if (t.isMapLikeType()) {
/* 616 */         JavaType kt = t.getKeyType();
/* 617 */         if (kt.getValueHandler() != null) {
/* 618 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 622 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private Class<?> _verifyAsClass(Object src, String methodName, Class<?> noneClass) {
/* 627 */     if (src == null) {
/* 628 */       return null;
/*     */     }
/* 630 */     if (!(src instanceof Class)) {
/* 631 */       throw new IllegalStateException("AnnotationIntrospector." + methodName + "() returned value of type " + src.getClass().getName() + ": expected type JsonSerializer or Class<JsonSerializer> instead");
/*     */     }
/* 633 */     Class<?> cls = (Class)src;
/* 634 */     if (cls == noneClass || ClassUtil.isBogusClass(cls)) {
/* 635 */       return null;
/*     */     }
/* 637 */     return cls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> _handleUnknownValueDeserializer(DeserializationContext ctxt, JavaType type) throws JsonMappingException {
/* 650 */     Class<?> rawClass = type.getRawClass();
/* 651 */     if (!ClassUtil.isConcrete(rawClass)) {
/* 652 */       return (JsonDeserializer<Object>)ctxt.reportBadDefinition(type, "Cannot find a Value deserializer for abstract type " + type);
/*     */     }
/* 654 */     return (JsonDeserializer<Object>)ctxt.reportBadDefinition(type, "Cannot find a Value deserializer for type " + type);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected KeyDeserializer _handleUnknownKeyDeserializer(DeserializationContext ctxt, JavaType type) throws JsonMappingException {
/* 660 */     return (KeyDeserializer)ctxt.reportBadDefinition(type, "Cannot find a (Map) Key deserializer for type " + type);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\DeserializerCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */