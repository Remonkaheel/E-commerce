/*     */ package com.fasterxml.jackson.databind.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.deser.impl.JDKValueInstantiators;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedField;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SettableAnyProperty
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final BeanProperty _property;
/*     */   protected final AnnotatedMember _setter;
/*     */   protected final boolean _setterIsField;
/*     */   protected final JavaType _type;
/*     */   protected JsonDeserializer<Object> _valueDeserializer;
/*     */   protected final TypeDeserializer _valueTypeDeserializer;
/*     */   protected final KeyDeserializer _keyDeserializer;
/*     */   
/*     */   public SettableAnyProperty(BeanProperty property, AnnotatedMember setter, JavaType type, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer typeDeser) {
/*  68 */     this._property = property;
/*  69 */     this._setter = setter;
/*  70 */     this._type = type;
/*  71 */     this._valueDeserializer = valueDeser;
/*  72 */     this._valueTypeDeserializer = typeDeser;
/*  73 */     this._keyDeserializer = keyDeser;
/*  74 */     this._setterIsField = setter instanceof AnnotatedField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SettableAnyProperty constructForMethod(DeserializationContext ctxt, BeanProperty property, AnnotatedMember field, JavaType valueType, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer typeDeser) {
/*  85 */     return new MethodAnyProperty(property, field, valueType, keyDeser, valueDeser, typeDeser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SettableAnyProperty constructForMapField(DeserializationContext ctxt, BeanProperty property, AnnotatedMember field, JavaType valueType, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer typeDeser) {
/*  98 */     Class<?> mapType = field.getRawType();
/*     */ 
/*     */ 
/*     */     
/* 102 */     if (mapType == Map.class) {
/* 103 */       mapType = LinkedHashMap.class;
/*     */     }
/* 105 */     ValueInstantiator vi = JDKValueInstantiators.findStdValueInstantiator(ctxt.getConfig(), mapType);
/* 106 */     return new MapFieldAnyProperty(property, field, valueType, keyDeser, valueDeser, typeDeser, vi);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SettableAnyProperty constructForJsonNodeField(DeserializationContext ctxt, BeanProperty property, AnnotatedMember field, JavaType valueType, JsonDeserializer<Object> valueDeser) {
/* 117 */     return new JsonNodeFieldAnyProperty(property, field, valueType, valueDeser, ctxt
/*     */         
/* 119 */         .getNodeFactory());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SettableAnyProperty constructForMapParameter(DeserializationContext ctxt, BeanProperty property, AnnotatedMember field, JavaType valueType, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer typeDeser, int parameterIndex) {
/* 129 */     Class<?> mapType = field.getRawType();
/*     */ 
/*     */ 
/*     */     
/* 133 */     if (mapType == Map.class) {
/* 134 */       mapType = LinkedHashMap.class;
/*     */     }
/* 136 */     ValueInstantiator vi = JDKValueInstantiators.findStdValueInstantiator(ctxt.getConfig(), mapType);
/* 137 */     return new MapParameterAnyProperty(property, field, valueType, keyDeser, valueDeser, typeDeser, vi, parameterIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SettableAnyProperty constructForJsonNodeParameter(DeserializationContext ctxt, BeanProperty prop, AnnotatedMember mutator, JavaType valueType, JsonDeserializer<Object> valueDeser, int parameterIndex) {
/* 143 */     return new JsonNodeParameterAnyProperty(prop, mutator, valueType, valueDeser, ctxt.getNodeFactory(), parameterIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract SettableAnyProperty withValueDeserializer(JsonDeserializer<Object> paramJsonDeserializer);
/*     */ 
/*     */   
/*     */   public void fixAccess(DeserializationConfig config) {
/* 151 */     this._setter.fixAccess(config
/* 152 */         .isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object readResolve() {
/* 166 */     if (this._setter == null || this._setter.getAnnotated() == null) {
/* 167 */       throw new IllegalArgumentException("Missing method/field (broken JDK (de)serialization?)");
/*     */     }
/* 169 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanProperty getProperty() {
/* 178 */     return this._property;
/*     */   } public boolean hasValueDeserializer() {
/* 180 */     return (this._valueDeserializer != null);
/*     */   } public JavaType getType() {
/* 182 */     return this._type;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPropertyName() {
/* 187 */     return this._property.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getParameterIndex() {
/* 195 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFieldType() {
/* 202 */     return this._setterIsField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSetterType() {
/* 209 */     return this._setter instanceof AnnotatedMethod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createParameterObject() {
/* 217 */     throw new UnsupportedOperationException("Cannot call createParameterObject() on " + getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deserializeAndSet(JsonParser p, DeserializationContext ctxt, Object instance, String propName) throws IOException {
/*     */     try {
/* 236 */       Object key = (this._keyDeserializer == null) ? propName : this._keyDeserializer.deserializeKey(propName, ctxt);
/* 237 */       set(instance, key, deserialize(p, ctxt));
/* 238 */     } catch (UnresolvedForwardReference reference) {
/* 239 */       if (this._valueDeserializer.getObjectIdReader() == null) {
/* 240 */         throw JsonMappingException.from(p, "Unresolved forward reference but no identity info.", reference);
/*     */       }
/*     */       
/* 243 */       AnySetterReferring referring = new AnySetterReferring(this, reference, this._type.getRawClass(), instance, propName);
/* 244 */       reference.getRoid().appendReferring(referring);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 250 */     if (p.hasToken(JsonToken.VALUE_NULL)) {
/* 251 */       return this._valueDeserializer.getNullValue(ctxt);
/*     */     }
/* 253 */     if (this._valueTypeDeserializer != null) {
/* 254 */       return this._valueDeserializer.deserializeWithType(p, ctxt, this._valueTypeDeserializer);
/*     */     }
/* 256 */     return this._valueDeserializer.deserialize(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(Object instance, Object propName, Object value) throws IOException {
/*     */     try {
/* 263 */       _set(instance, propName, value);
/* 264 */     } catch (IOException e) {
/* 265 */       throw e;
/* 266 */     } catch (Exception e) {
/* 267 */       _throwAsIOE(e, propName, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void _set(Object paramObject1, Object paramObject2, Object paramObject3) throws Exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _throwAsIOE(Exception e, Object propName, Object value) throws IOException {
/* 287 */     if (e instanceof IllegalArgumentException) {
/* 288 */       String actType = ClassUtil.classNameOf(value);
/* 289 */       StringBuilder msg = (new StringBuilder("Problem deserializing \"any-property\" '")).append(propName);
/* 290 */       msg.append("' of class " + getClassName() + " (expected type: ").append(this._type);
/* 291 */       msg.append("; actual type: ").append(actType).append(")");
/* 292 */       String origMsg = ClassUtil.exceptionMessage(e);
/* 293 */       if (origMsg != null) {
/* 294 */         msg.append(", problem: ").append(origMsg);
/*     */       } else {
/* 296 */         msg.append(" (no error message provided)");
/*     */       } 
/* 298 */       throw new JsonMappingException(null, msg.toString(), e);
/*     */     } 
/* 300 */     ClassUtil.throwIfIOE(e);
/* 301 */     ClassUtil.throwIfRTE(e);
/*     */     
/* 303 */     Throwable t = ClassUtil.getRootCause(e);
/* 304 */     throw new JsonMappingException(null, ClassUtil.exceptionMessage(t), t);
/*     */   }
/*     */   private String getClassName() {
/* 307 */     return ClassUtil.nameOf(this._setter.getDeclaringClass());
/*     */   } public String toString() {
/* 309 */     return "[any property on class " + getClassName() + "]";
/*     */   }
/*     */   
/*     */   private static class AnySetterReferring
/*     */     extends ReadableObjectId.Referring {
/*     */     private final SettableAnyProperty _parent;
/*     */     private final Object _pojo;
/*     */     private final String _propName;
/*     */     
/*     */     public AnySetterReferring(SettableAnyProperty parent, UnresolvedForwardReference reference, Class<?> type, Object instance, String propName) {
/* 319 */       super(reference, type);
/* 320 */       this._parent = parent;
/* 321 */       this._pojo = instance;
/* 322 */       this._propName = propName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void handleResolvedForwardReference(Object id, Object value) throws IOException {
/* 329 */       if (!hasId(id)) {
/* 330 */         throw new IllegalArgumentException("Trying to resolve a forward reference with id [" + id.toString() + "] that wasn't previously registered.");
/*     */       }
/*     */       
/* 333 */       this._parent.set(this._pojo, this._propName, value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class MethodAnyProperty
/*     */     extends SettableAnyProperty
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodAnyProperty(BeanProperty property, AnnotatedMember field, JavaType valueType, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer typeDeser) {
/* 355 */       super(property, field, valueType, keyDeser, valueDeser, typeDeser);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void _set(Object instance, Object propName, Object value) throws Exception {
/* 363 */       ((AnnotatedMethod)this._setter).callOnWith(instance, new Object[] { propName, value });
/*     */     }
/*     */ 
/*     */     
/*     */     public SettableAnyProperty withValueDeserializer(JsonDeserializer<Object> deser) {
/* 368 */       return new MethodAnyProperty(this._property, this._setter, this._type, this._keyDeserializer, deser, this._valueTypeDeserializer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class MapFieldAnyProperty
/*     */     extends SettableAnyProperty
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final ValueInstantiator _valueInstantiator;
/*     */ 
/*     */ 
/*     */     
/*     */     public MapFieldAnyProperty(BeanProperty property, AnnotatedMember field, JavaType valueType, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer typeDeser, ValueInstantiator inst) {
/* 388 */       super(property, field, valueType, keyDeser, valueDeser, typeDeser);
/*     */       
/* 390 */       this._valueInstantiator = inst;
/*     */     }
/*     */ 
/*     */     
/*     */     public SettableAnyProperty withValueDeserializer(JsonDeserializer<Object> deser) {
/* 395 */       return new MapFieldAnyProperty(this._property, this._setter, this._type, this._keyDeserializer, deser, this._valueTypeDeserializer, this._valueInstantiator);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void _set(Object instance, Object propName, Object value) throws Exception {
/* 404 */       AnnotatedField field = (AnnotatedField)this._setter;
/* 405 */       Map<Object, Object> val = (Map<Object, Object>)field.getValue(instance);
/*     */ 
/*     */       
/* 408 */       if (val == null) {
/* 409 */         val = _createAndSetMap((DeserializationContext)null, field, instance, propName);
/*     */       }
/*     */       
/* 412 */       val.put(propName, value);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Map<Object, Object> _createAndSetMap(DeserializationContext ctxt, AnnotatedField field, Object instance, Object propName) throws IOException {
/* 420 */       if (this._valueInstantiator == null)
/* 421 */         throw JsonMappingException.from(ctxt, String.format("Cannot create an instance of %s for use as \"any-setter\" '%s'", new Object[] {
/*     */                 
/* 423 */                 ClassUtil.nameOf(this._type.getRawClass()), this._property.getName()
/*     */               })); 
/* 425 */       Map<Object, Object> map = (Map<Object, Object>)this._valueInstantiator.createUsingDefault(ctxt);
/* 426 */       field.setValue(instance, map);
/* 427 */       return map;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class JsonNodeFieldAnyProperty
/*     */     extends SettableAnyProperty
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/*     */     protected final JsonNodeFactory _nodeFactory;
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonNodeFieldAnyProperty(BeanProperty property, AnnotatedMember field, JavaType valueType, JsonDeserializer<Object> valueDeser, JsonNodeFactory nodeFactory) {
/* 445 */       super(property, field, valueType, null, valueDeser, null);
/* 446 */       this._nodeFactory = nodeFactory;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void deserializeAndSet(JsonParser p, DeserializationContext ctxt, Object instance, String propName) throws IOException {
/* 455 */       setProperty(instance, propName, (JsonNode)deserialize(p, ctxt));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 462 */       return this._valueDeserializer.deserialize(p, ctxt);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void _set(Object instance, Object propName, Object value) throws Exception {
/* 467 */       setProperty(instance, (String)propName, (JsonNode)value);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void setProperty(Object instance, String propName, JsonNode value) throws IOException {
/*     */       ObjectNode objectNode;
/* 473 */       AnnotatedField field = (AnnotatedField)this._setter;
/* 474 */       Object val0 = field.getValue(instance);
/*     */ 
/*     */       
/* 477 */       if (val0 == null)
/* 478 */       { objectNode = this._nodeFactory.objectNode();
/* 479 */         field.setValue(instance, objectNode); }
/* 480 */       else { if (!(val0 instanceof ObjectNode))
/* 481 */           throw JsonMappingException.from((DeserializationContext)null, String.format("Value \"any-setter\" '%s' not `ObjectNode` but %s", new Object[] {
/*     */                   
/* 483 */                   getPropertyName(), 
/* 484 */                   ClassUtil.nameOf(val0.getClass())
/*     */                 })); 
/* 486 */         objectNode = (ObjectNode)val0; }
/*     */ 
/*     */       
/* 489 */       objectNode.set(propName, value);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public SettableAnyProperty withValueDeserializer(JsonDeserializer<Object> deser) {
/* 495 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class MapParameterAnyProperty
/*     */     extends SettableAnyProperty
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final ValueInstantiator _valueInstantiator;
/*     */ 
/*     */     
/*     */     protected final int _parameterIndex;
/*     */ 
/*     */ 
/*     */     
/*     */     public MapParameterAnyProperty(BeanProperty property, AnnotatedMember field, JavaType valueType, KeyDeserializer keyDeser, JsonDeserializer<Object> valueDeser, TypeDeserializer typeDeser, ValueInstantiator inst, int parameterIndex) {
/* 518 */       super(property, field, valueType, keyDeser, valueDeser, typeDeser);
/* 519 */       this._valueInstantiator = Objects.<ValueInstantiator>requireNonNull(inst, "ValueInstantiator for MapParameterAnyProperty cannot be `null`");
/* 520 */       this._parameterIndex = parameterIndex;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public SettableAnyProperty withValueDeserializer(JsonDeserializer<Object> deser) {
/* 526 */       return new MapParameterAnyProperty(this._property, this._setter, this._type, this._keyDeserializer, deser, this._valueTypeDeserializer, this._valueInstantiator, this._parameterIndex);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void _set(Object instance, Object propName, Object value) {
/* 534 */       ((Map<Object, Object>)instance).put(propName, value);
/*     */     }
/*     */     
/*     */     public int getParameterIndex() {
/* 538 */       return this._parameterIndex;
/*     */     }
/*     */     public Object createParameterObject() {
/* 541 */       return new HashMap<>();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class JsonNodeParameterAnyProperty
/*     */     extends SettableAnyProperty
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/*     */     protected final JsonNodeFactory _nodeFactory;
/*     */ 
/*     */     
/*     */     protected final int _parameterIndex;
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonNodeParameterAnyProperty(BeanProperty property, AnnotatedMember field, JavaType valueType, JsonDeserializer<Object> valueDeser, JsonNodeFactory nodeFactory, int parameterIndex) {
/* 562 */       super(property, field, valueType, null, valueDeser, null);
/* 563 */       this._nodeFactory = nodeFactory;
/* 564 */       this._parameterIndex = parameterIndex;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 572 */       return this._valueDeserializer.deserialize(p, ctxt);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void _set(Object instance, Object propName, Object value) throws Exception {
/* 579 */       ((ObjectNode)instance).set((String)propName, (JsonNode)value);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public SettableAnyProperty withValueDeserializer(JsonDeserializer<Object> deser) {
/* 585 */       throw new UnsupportedOperationException("Cannot call withValueDeserializer() on " + getClass().getName());
/*     */     }
/*     */     
/*     */     public int getParameterIndex() {
/* 589 */       return this._parameterIndex;
/*     */     }
/*     */     public Object createParameterObject() {
/* 592 */       return this._nodeFactory.objectNode();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\SettableAnyProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */