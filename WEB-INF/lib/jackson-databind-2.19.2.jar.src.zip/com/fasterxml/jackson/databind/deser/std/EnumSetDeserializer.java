/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*     */ import com.fasterxml.jackson.databind.deser.impl.NullsConstantProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*     */ import java.io.IOException;
/*     */ import java.util.EnumSet;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnumSetDeserializer
/*     */   extends StdDeserializer<EnumSet<?>>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   protected final JavaType _enumType;
/*     */   protected JsonDeserializer<Enum<?>> _enumDeserializer;
/*     */   protected final NullValueProvider _nullProvider;
/*     */   protected final boolean _skipNullValues;
/*     */   protected final Boolean _unwrapSingle;
/*     */   
/*     */   public EnumSetDeserializer(JavaType enumType, JsonDeserializer<?> deser) {
/*  73 */     super(EnumSet.class);
/*  74 */     this._enumType = enumType;
/*     */     
/*  76 */     if (!enumType.isEnumType()) {
/*  77 */       throw new IllegalArgumentException("Type " + enumType + " not Java Enum type");
/*     */     }
/*  79 */     this._enumDeserializer = (JsonDeserializer)deser;
/*  80 */     this._unwrapSingle = null;
/*  81 */     this._nullProvider = null;
/*  82 */     this._skipNullValues = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EnumSetDeserializer(JavaType enumType, JsonDeserializer<?> deser, TypeDeserializer valueTypeDeser) {
/*  92 */     this(enumType, deser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EnumSetDeserializer(EnumSetDeserializer base, JsonDeserializer<?> deser, NullValueProvider nuller, Boolean unwrapSingle) {
/* 101 */     super(base);
/* 102 */     this._enumType = base._enumType;
/* 103 */     this._enumDeserializer = (JsonDeserializer)deser;
/* 104 */     this._nullProvider = nuller;
/* 105 */     this._skipNullValues = NullsConstantProvider.isSkipper(nuller);
/* 106 */     this._unwrapSingle = unwrapSingle;
/*     */   }
/*     */   
/*     */   public EnumSetDeserializer withDeserializer(JsonDeserializer<?> deser) {
/* 110 */     if (this._enumDeserializer == deser) {
/* 111 */       return this;
/*     */     }
/* 113 */     return new EnumSetDeserializer(this, deser, this._nullProvider, this._unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumSetDeserializer withResolved(JsonDeserializer<?> deser, NullValueProvider nuller, Boolean unwrapSingle) {
/* 121 */     if (Objects.equals(this._unwrapSingle, unwrapSingle) && this._enumDeserializer == deser && this._nullProvider == deser)
/*     */     {
/*     */       
/* 124 */       return this;
/*     */     }
/* 126 */     return new EnumSetDeserializer(this, deser, nuller, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/* 142 */     return (this._enumType.getValueHandler() == null);
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 147 */     return LogicalType.Collection;
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 152 */     return Boolean.TRUE;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/* 157 */     return constructSet();
/*     */   }
/*     */ 
/*     */   
/*     */   public AccessPattern getEmptyAccessPattern() {
/* 162 */     return AccessPattern.DYNAMIC;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 178 */     Boolean unwrapSingle = findFormatFeature(ctxt, property, EnumSet.class, JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
/*     */     
/* 180 */     JsonDeserializer<?> deser = this._enumDeserializer;
/* 181 */     if (deser == null) {
/* 182 */       deser = ctxt.findContextualValueDeserializer(this._enumType, property);
/*     */     } else {
/* 184 */       deser = ctxt.handleSecondaryContextualization(deser, property, this._enumType);
/*     */     } 
/* 186 */     return withResolved(deser, 
/* 187 */         findContentNullProvider(ctxt, property, deser), unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumSet<?> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 199 */     EnumSet result = constructSet();
/*     */     
/* 201 */     if (!p.isExpectedStartArrayToken()) {
/* 202 */       return handleNonArray(p, ctxt, result);
/*     */     }
/* 204 */     return _deserialize(p, ctxt, result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumSet<?> deserialize(JsonParser p, DeserializationContext ctxt, EnumSet<?> result) throws IOException {
/* 212 */     if (!p.isExpectedStartArrayToken()) {
/* 213 */       return handleNonArray(p, ctxt, result);
/*     */     }
/* 215 */     return _deserialize(p, ctxt, result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final EnumSet<?> _deserialize(JsonParser p, DeserializationContext ctxt, EnumSet<Enum<?>> result) throws IOException {
/*     */     try {
/*     */       JsonToken t;
/* 224 */       while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/*     */         Enum<?> value;
/*     */ 
/*     */ 
/*     */         
/* 229 */         if (t == JsonToken.VALUE_NULL) {
/* 230 */           if (this._skipNullValues) {
/*     */             continue;
/*     */           }
/* 233 */           value = (Enum)this._nullProvider.getNullValue(ctxt);
/*     */         } else {
/* 235 */           value = (Enum)this._enumDeserializer.deserialize(p, ctxt);
/*     */         } 
/* 237 */         if (value != null) {
/* 238 */           result.add(value);
/*     */         }
/*     */       } 
/* 241 */     } catch (Exception e) {
/* 242 */       throw JsonMappingException.wrapWithPath(e, result, result.size());
/*     */     } 
/* 244 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 252 */     return typeDeserializer.deserializeTypedFromArray(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private EnumSet constructSet() {
/* 258 */     return EnumSet.noneOf(this._enumType.getRawClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EnumSet<?> handleNonArray(JsonParser p, DeserializationContext ctxt, EnumSet<Enum<?>> result) throws IOException {
/* 268 */     boolean canWrap = (this._unwrapSingle == Boolean.TRUE || (this._unwrapSingle == null && ctxt.isEnabled(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)));
/*     */     
/* 270 */     if (!canWrap) {
/* 271 */       return (EnumSet)ctxt.handleUnexpectedToken(EnumSet.class, p);
/*     */     }
/*     */     
/* 274 */     if (p.hasToken(JsonToken.VALUE_NULL)) {
/* 275 */       return (EnumSet)ctxt.handleUnexpectedToken(this._enumType, p);
/*     */     }
/*     */     try {
/* 278 */       Enum<?> value = (Enum)this._enumDeserializer.deserialize(p, ctxt);
/* 279 */       if (value != null) {
/* 280 */         result.add(value);
/*     */       }
/* 282 */     } catch (Exception e) {
/* 283 */       throw JsonMappingException.wrapWithPath(e, result, result.size());
/*     */     } 
/* 285 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\EnumSetDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */