/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.annotation.Nulls;
/*     */ import com.fasterxml.jackson.core.Base64Variants;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.exc.StreamReadException;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*     */ import com.fasterxml.jackson.databind.deser.impl.NullsConstantProvider;
/*     */ import com.fasterxml.jackson.databind.deser.impl.NullsFailProvider;
/*     */ import com.fasterxml.jackson.databind.exc.InvalidNullException;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*     */ import com.fasterxml.jackson.databind.util.ArrayBuilders;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PrimitiveArrayDeserializers<T>
/*     */   extends StdDeserializer<T>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   protected final Boolean _unwrapSingle;
/*     */   private transient Object _emptyValue;
/*     */   protected final NullValueProvider _nuller;
/*     */   
/*     */   protected PrimitiveArrayDeserializers(Class<T> cls) {
/*  58 */     super(cls);
/*  59 */     this._unwrapSingle = null;
/*  60 */     this._nuller = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PrimitiveArrayDeserializers(PrimitiveArrayDeserializers<?> base, NullValueProvider nuller, Boolean unwrapSingle) {
/*  68 */     super(base._valueClass);
/*  69 */     this._unwrapSingle = unwrapSingle;
/*  70 */     this._nuller = nuller;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonDeserializer<?> forType(Class<?> rawType) {
/*  76 */     if (rawType == int.class) {
/*  77 */       return IntDeser.instance;
/*     */     }
/*  79 */     if (rawType == long.class) {
/*  80 */       return LongDeser.instance;
/*     */     }
/*     */     
/*  83 */     if (rawType == byte.class) {
/*  84 */       return new ByteDeser();
/*     */     }
/*  86 */     if (rawType == short.class) {
/*  87 */       return new ShortDeser();
/*     */     }
/*  89 */     if (rawType == float.class) {
/*  90 */       return new FloatDeser();
/*     */     }
/*  92 */     if (rawType == double.class) {
/*  93 */       return new DoubleDeser();
/*     */     }
/*  95 */     if (rawType == boolean.class) {
/*  96 */       return new BooleanDeser();
/*     */     }
/*  98 */     if (rawType == char.class) {
/*  99 */       return new CharDeser();
/*     */     }
/* 101 */     throw new IllegalArgumentException("Unknown primitive array element type: " + rawType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/*     */     NullsFailProvider nullsFailProvider;
/* 108 */     Boolean unwrapSingle = findFormatFeature(ctxt, property, this._valueClass, JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
/*     */     
/* 110 */     NullValueProvider nuller = null;
/*     */     
/* 112 */     Nulls nullStyle = findContentNullStyle(ctxt, property);
/* 113 */     if (nullStyle == Nulls.SKIP) {
/* 114 */       NullsConstantProvider nullsConstantProvider = NullsConstantProvider.skipper();
/* 115 */     } else if (nullStyle == Nulls.FAIL) {
/* 116 */       if (property == null) {
/*     */         
/* 118 */         nullsFailProvider = NullsFailProvider.constructForRootValue(ctxt.constructType(this._valueClass.getComponentType()));
/*     */       } else {
/*     */         
/* 121 */         nullsFailProvider = NullsFailProvider.constructForProperty(property, property.getType().getContentType());
/*     */       } 
/*     */     } 
/* 124 */     if (Objects.equals(unwrapSingle, this._unwrapSingle) && nullsFailProvider == this._nuller) {
/* 125 */       return this;
/*     */     }
/* 127 */     return withResolved((NullValueProvider)nullsFailProvider, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract T _concat(T paramT1, T paramT2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract T handleSingleElementUnwrapped(JsonParser paramJsonParser, DeserializationContext paramDeserializationContext) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract PrimitiveArrayDeserializers<?> withResolved(NullValueProvider paramNullValueProvider, Boolean paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract T _constructEmpty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 161 */     return LogicalType.Array;
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 166 */     return Boolean.TRUE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AccessPattern getEmptyAccessPattern() {
/* 172 */     return AccessPattern.CONSTANT;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/* 177 */     Object empty = this._emptyValue;
/* 178 */     if (empty == null) {
/* 179 */       this._emptyValue = empty = _constructEmpty();
/*     */     }
/* 181 */     return empty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 190 */     return typeDeserializer.deserializeTypedFromArray(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T deserialize(JsonParser p, DeserializationContext ctxt, T existing) throws IOException {
/* 196 */     T newValue = (T)deserialize(p, ctxt);
/* 197 */     if (existing == null) {
/* 198 */       return newValue;
/*     */     }
/* 200 */     int len = Array.getLength(existing);
/* 201 */     if (len == 0) {
/* 202 */       return newValue;
/*     */     }
/* 204 */     return _concat(existing, newValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T handleNonArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 219 */     boolean canWrap = (this._unwrapSingle == Boolean.TRUE || (this._unwrapSingle == null && ctxt.isEnabled(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 224 */     if (p.hasToken(JsonToken.VALUE_STRING) && (
/* 225 */       !canWrap || _isBlank(p.getText()))) {
/* 226 */       return _deserializeFromString(p, ctxt);
/*     */     }
/*     */     
/* 229 */     if (canWrap) {
/* 230 */       return handleSingleElementUnwrapped(p, ctxt);
/*     */     }
/* 232 */     return (T)ctxt.handleUnexpectedToken(this._valueClass, p);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _failOnNull(DeserializationContext ctxt) throws IOException {
/* 237 */     throw InvalidNullException.from(ctxt, null, ctxt.constructType(this._valueClass));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JacksonStdImpl
/*     */   static final class CharDeser
/*     */     extends PrimitiveArrayDeserializers<char[]>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     public CharDeser() {
/* 252 */       super((Class)char[].class);
/*     */     } protected CharDeser(CharDeser base, NullValueProvider nuller, Boolean unwrapSingle) {
/* 254 */       super(base, nuller, unwrapSingle);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller, Boolean unwrapSingle) {
/* 261 */       return this;
/*     */     }
/*     */ 
/*     */     
/*     */     protected char[] _constructEmpty() {
/* 266 */       return new char[0];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public char[] deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 276 */       if (p.hasToken(JsonToken.VALUE_STRING)) {
/*     */         
/* 278 */         char[] buffer = p.getTextCharacters();
/* 279 */         int offset = p.getTextOffset();
/* 280 */         int len = p.getTextLength();
/*     */         
/* 282 */         char[] result = new char[len];
/* 283 */         System.arraycopy(buffer, offset, result, 0, len);
/* 284 */         return result;
/*     */       } 
/* 286 */       if (p.isExpectedStartArrayToken()) {
/*     */         
/* 288 */         StringBuilder sb = new StringBuilder(64);
/*     */         JsonToken t;
/* 290 */         while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/*     */           String str;
/* 292 */           if (t == JsonToken.VALUE_STRING) {
/* 293 */             str = p.getText();
/* 294 */           } else if (t == JsonToken.VALUE_NULL) {
/* 295 */             if (this._nuller != null) {
/* 296 */               this._nuller.getNullValue(ctxt);
/*     */               continue;
/*     */             } 
/* 299 */             _verifyNullForPrimitive(ctxt);
/* 300 */             str = "\000";
/*     */           } else {
/* 302 */             CharSequence cs = (CharSequence)ctxt.handleUnexpectedToken(char.class, p);
/* 303 */             str = cs.toString();
/*     */           } 
/* 305 */           if (str.length() != 1)
/* 306 */             ctxt.reportInputMismatch(this, "Cannot convert a JSON String of length %d into a char element of char array", new Object[] {
/* 307 */                   Integer.valueOf(str.length())
/*     */                 }); 
/* 309 */           sb.append(str.charAt(0));
/*     */         } 
/* 311 */         return sb.toString().toCharArray();
/*     */       } 
/*     */       
/* 314 */       if (p.hasToken(JsonToken.VALUE_EMBEDDED_OBJECT)) {
/* 315 */         Object ob = p.getEmbeddedObject();
/* 316 */         if (ob == null) return null; 
/* 317 */         if (ob instanceof char[]) {
/* 318 */           return (char[])ob;
/*     */         }
/* 320 */         if (ob instanceof String) {
/* 321 */           return ((String)ob).toCharArray();
/*     */         }
/*     */         
/* 324 */         if (ob instanceof byte[]) {
/* 325 */           return Base64Variants.getDefaultVariant().encode((byte[])ob, false).toCharArray();
/*     */         }
/*     */       } 
/*     */       
/* 329 */       return (char[])ctxt.handleUnexpectedToken(this._valueClass, p);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected char[] handleSingleElementUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 336 */       return (char[])ctxt.handleUnexpectedToken(this._valueClass, p);
/*     */     }
/*     */ 
/*     */     
/*     */     protected char[] _concat(char[] oldValue, char[] newValue) {
/* 341 */       int len1 = oldValue.length;
/* 342 */       int len2 = newValue.length;
/* 343 */       char[] result = Arrays.copyOf(oldValue, len1 + len2);
/* 344 */       System.arraycopy(newValue, 0, result, len1, len2);
/* 345 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JacksonStdImpl
/*     */   static final class BooleanDeser
/*     */     extends PrimitiveArrayDeserializers<boolean[]>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     public BooleanDeser() {
/* 361 */       super((Class)boolean[].class);
/*     */     } protected BooleanDeser(BooleanDeser base, NullValueProvider nuller, Boolean unwrapSingle) {
/* 363 */       super(base, nuller, unwrapSingle);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller, Boolean unwrapSingle) {
/* 369 */       return new BooleanDeser(this, nuller, unwrapSingle);
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean[] _constructEmpty() {
/* 374 */       return new boolean[0];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean[] deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 381 */       if (!p.isExpectedStartArrayToken()) {
/* 382 */         return handleNonArray(p, ctxt);
/*     */       }
/* 384 */       ArrayBuilders.BooleanBuilder builder = ctxt.getArrayBuilders().getBooleanBuilder();
/* 385 */       boolean[] chunk = (boolean[])builder.resetAndStart();
/* 386 */       int ix = 0;
/*     */       
/*     */       try {
/*     */         JsonToken t;
/* 390 */         while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/*     */           boolean value;
/* 392 */           if (t == JsonToken.VALUE_TRUE) {
/* 393 */             value = true;
/* 394 */           } else if (t == JsonToken.VALUE_FALSE) {
/* 395 */             value = false;
/* 396 */           } else if (t == JsonToken.VALUE_NULL) {
/* 397 */             if (this._nuller != null) {
/* 398 */               this._nuller.getNullValue(ctxt);
/*     */               continue;
/*     */             } 
/* 401 */             _verifyNullForPrimitive(ctxt);
/* 402 */             value = false;
/*     */           } else {
/* 404 */             value = _parseBooleanPrimitive(p, ctxt);
/*     */           } 
/* 406 */           if (ix >= chunk.length) {
/* 407 */             chunk = (boolean[])builder.appendCompletedChunk(chunk, ix);
/* 408 */             ix = 0;
/*     */           } 
/* 410 */           chunk[ix++] = value;
/*     */         } 
/* 412 */       } catch (Exception e) {
/* 413 */         throw JsonMappingException.wrapWithPath(e, chunk, builder.bufferedSize() + ix);
/*     */       } 
/* 415 */       return (boolean[])builder.completeAndClearBuffer(chunk, ix);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected boolean[] handleSingleElementUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 421 */       return new boolean[] { _parseBooleanPrimitive(p, ctxt) };
/*     */     }
/*     */ 
/*     */     
/*     */     protected boolean[] _concat(boolean[] oldValue, boolean[] newValue) {
/* 426 */       int len1 = oldValue.length;
/* 427 */       int len2 = newValue.length;
/* 428 */       boolean[] result = Arrays.copyOf(oldValue, len1 + len2);
/* 429 */       System.arraycopy(newValue, 0, result, len1, len2);
/* 430 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @JacksonStdImpl
/*     */   static final class ByteDeser
/*     */     extends PrimitiveArrayDeserializers<byte[]>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/*     */     public ByteDeser() {
/* 444 */       super((Class)byte[].class);
/*     */     } protected ByteDeser(ByteDeser base, NullValueProvider nuller, Boolean unwrapSingle) {
/* 446 */       super(base, nuller, unwrapSingle);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller, Boolean unwrapSingle) {
/* 452 */       return new ByteDeser(this, nuller, unwrapSingle);
/*     */     }
/*     */ 
/*     */     
/*     */     protected byte[] _constructEmpty() {
/* 457 */       return new byte[0];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public LogicalType logicalType() {
/* 464 */       return LogicalType.Binary;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public byte[] deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 470 */       JsonToken t = p.currentToken();
/*     */ 
/*     */       
/* 473 */       if (t == JsonToken.VALUE_STRING) {
/*     */         try {
/* 475 */           return p.getBinaryValue(ctxt.getBase64Variant());
/* 476 */         } catch (StreamReadException|com.fasterxml.jackson.databind.DatabindException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 481 */           String msg = e.getOriginalMessage();
/* 482 */           if (msg.contains("base64")) {
/* 483 */             return (byte[])ctxt.handleWeirdStringValue(byte[].class, p
/* 484 */                 .getText(), msg, new Object[0]);
/*     */           }
/*     */         } 
/*     */       }
/*     */       
/* 489 */       if (t == JsonToken.VALUE_EMBEDDED_OBJECT) {
/* 490 */         Object ob = p.getEmbeddedObject();
/* 491 */         if (ob == null) return null; 
/* 492 */         if (ob instanceof byte[]) {
/* 493 */           return (byte[])ob;
/*     */         }
/*     */       } 
/* 496 */       if (!p.isExpectedStartArrayToken()) {
/* 497 */         return handleNonArray(p, ctxt);
/*     */       }
/* 499 */       ArrayBuilders.ByteBuilder builder = ctxt.getArrayBuilders().getByteBuilder();
/* 500 */       byte[] chunk = (byte[])builder.resetAndStart();
/* 501 */       int ix = 0;
/*     */       
/*     */       try {
/* 504 */         while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/*     */           byte value;
/*     */           
/* 507 */           if (t == JsonToken.VALUE_NUMBER_INT) {
/* 508 */             value = p.getByteValue();
/*     */           
/*     */           }
/* 511 */           else if (t == JsonToken.VALUE_NULL) {
/* 512 */             if (this._nuller != null) {
/* 513 */               this._nuller.getNullValue(ctxt);
/*     */               continue;
/*     */             } 
/* 516 */             _verifyNullForPrimitive(ctxt);
/* 517 */             value = 0;
/*     */           } else {
/* 519 */             value = _parseBytePrimitive(p, ctxt);
/*     */           } 
/*     */           
/* 522 */           if (ix >= chunk.length) {
/* 523 */             chunk = (byte[])builder.appendCompletedChunk(chunk, ix);
/* 524 */             ix = 0;
/*     */           } 
/* 526 */           chunk[ix++] = value;
/*     */         } 
/* 528 */       } catch (Exception e) {
/* 529 */         throw JsonMappingException.wrapWithPath(e, chunk, builder.bufferedSize() + ix);
/*     */       } 
/* 531 */       return (byte[])builder.completeAndClearBuffer(chunk, ix);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected byte[] handleSingleElementUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/*     */       byte value;
/* 539 */       JsonToken t = p.currentToken();
/* 540 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 541 */         value = p.getByteValue();
/*     */       } else {
/*     */         
/* 544 */         if (t == JsonToken.VALUE_NULL) {
/* 545 */           if (this._nuller != null) {
/* 546 */             this._nuller.getNullValue(ctxt);
/* 547 */             return (byte[])getEmptyValue(ctxt);
/*     */           } 
/* 549 */           _verifyNullForPrimitive(ctxt);
/* 550 */           return null;
/*     */         } 
/* 552 */         Number n = (Number)ctxt.handleUnexpectedToken(this._valueClass.getComponentType(), p);
/* 553 */         value = n.byteValue();
/*     */       } 
/* 555 */       return new byte[] { value };
/*     */     }
/*     */ 
/*     */     
/*     */     protected byte[] _concat(byte[] oldValue, byte[] newValue) {
/* 560 */       int len1 = oldValue.length;
/* 561 */       int len2 = newValue.length;
/* 562 */       byte[] result = Arrays.copyOf(oldValue, len1 + len2);
/* 563 */       System.arraycopy(newValue, 0, result, len1, len2);
/* 564 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */   @JacksonStdImpl
/*     */   static final class ShortDeser
/*     */     extends PrimitiveArrayDeserializers<short[]> {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     public ShortDeser() {
/* 574 */       super((Class)short[].class);
/*     */     } protected ShortDeser(ShortDeser base, NullValueProvider nuller, Boolean unwrapSingle) {
/* 576 */       super(base, nuller, unwrapSingle);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller, Boolean unwrapSingle) {
/* 582 */       return new ShortDeser(this, nuller, unwrapSingle);
/*     */     }
/*     */ 
/*     */     
/*     */     protected short[] _constructEmpty() {
/* 587 */       return new short[0];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public short[] deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 593 */       if (!p.isExpectedStartArrayToken()) {
/* 594 */         return handleNonArray(p, ctxt);
/*     */       }
/* 596 */       ArrayBuilders.ShortBuilder builder = ctxt.getArrayBuilders().getShortBuilder();
/* 597 */       short[] chunk = (short[])builder.resetAndStart();
/* 598 */       int ix = 0;
/*     */       
/*     */       try {
/*     */         JsonToken t;
/* 602 */         while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/*     */           short value;
/* 604 */           if (t == JsonToken.VALUE_NULL) {
/* 605 */             if (this._nuller != null) {
/* 606 */               this._nuller.getNullValue(ctxt);
/*     */               continue;
/*     */             } 
/* 609 */             _verifyNullForPrimitive(ctxt);
/* 610 */             value = 0;
/*     */           } else {
/* 612 */             value = _parseShortPrimitive(p, ctxt);
/*     */           } 
/* 614 */           if (ix >= chunk.length) {
/* 615 */             chunk = (short[])builder.appendCompletedChunk(chunk, ix);
/* 616 */             ix = 0;
/*     */           } 
/* 618 */           chunk[ix++] = value;
/*     */         } 
/* 620 */       } catch (Exception e) {
/* 621 */         throw JsonMappingException.wrapWithPath(e, chunk, builder.bufferedSize() + ix);
/*     */       } 
/* 623 */       return (short[])builder.completeAndClearBuffer(chunk, ix);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected short[] handleSingleElementUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 629 */       return new short[] { _parseShortPrimitive(p, ctxt) };
/*     */     }
/*     */ 
/*     */     
/*     */     protected short[] _concat(short[] oldValue, short[] newValue) {
/* 634 */       int len1 = oldValue.length;
/* 635 */       int len2 = newValue.length;
/* 636 */       short[] result = Arrays.copyOf(oldValue, len1 + len2);
/* 637 */       System.arraycopy(newValue, 0, result, len1, len2);
/* 638 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @JacksonStdImpl
/*     */   static final class IntDeser
/*     */     extends PrimitiveArrayDeserializers<int[]>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/* 648 */     public static final IntDeser instance = new IntDeser();
/*     */     public IntDeser() {
/* 650 */       super((Class)int[].class);
/*     */     } protected IntDeser(IntDeser base, NullValueProvider nuller, Boolean unwrapSingle) {
/* 652 */       super(base, nuller, unwrapSingle);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller, Boolean unwrapSingle) {
/* 658 */       return new IntDeser(this, nuller, unwrapSingle);
/*     */     }
/*     */ 
/*     */     
/*     */     protected int[] _constructEmpty() {
/* 663 */       return new int[0];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int[] deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 669 */       if (!p.isExpectedStartArrayToken()) {
/* 670 */         return handleNonArray(p, ctxt);
/*     */       }
/* 672 */       ArrayBuilders.IntBuilder builder = ctxt.getArrayBuilders().getIntBuilder();
/* 673 */       int[] chunk = (int[])builder.resetAndStart();
/* 674 */       int ix = 0;
/*     */       
/*     */       try {
/*     */         JsonToken t;
/* 678 */         while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/*     */           int value;
/* 680 */           if (t == JsonToken.VALUE_NUMBER_INT) {
/* 681 */             value = p.getIntValue();
/* 682 */           } else if (t == JsonToken.VALUE_NULL) {
/* 683 */             if (this._nuller != null) {
/* 684 */               this._nuller.getNullValue(ctxt);
/*     */               continue;
/*     */             } 
/* 687 */             _verifyNullForPrimitive(ctxt);
/* 688 */             value = 0;
/*     */           } else {
/* 690 */             value = _parseIntPrimitive(p, ctxt);
/*     */           } 
/* 692 */           if (ix >= chunk.length) {
/* 693 */             chunk = (int[])builder.appendCompletedChunk(chunk, ix);
/* 694 */             ix = 0;
/*     */           } 
/* 696 */           chunk[ix++] = value;
/*     */         } 
/* 698 */       } catch (Exception e) {
/* 699 */         throw JsonMappingException.wrapWithPath(e, chunk, builder.bufferedSize() + ix);
/*     */       } 
/* 701 */       return (int[])builder.completeAndClearBuffer(chunk, ix);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected int[] handleSingleElementUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 707 */       return new int[] { _parseIntPrimitive(p, ctxt) };
/*     */     }
/*     */ 
/*     */     
/*     */     protected int[] _concat(int[] oldValue, int[] newValue) {
/* 712 */       int len1 = oldValue.length;
/* 713 */       int len2 = newValue.length;
/* 714 */       int[] result = Arrays.copyOf(oldValue, len1 + len2);
/* 715 */       System.arraycopy(newValue, 0, result, len1, len2);
/* 716 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @JacksonStdImpl
/*     */   static final class LongDeser
/*     */     extends PrimitiveArrayDeserializers<long[]>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/* 726 */     public static final LongDeser instance = new LongDeser();
/*     */     public LongDeser() {
/* 728 */       super((Class)long[].class);
/*     */     } protected LongDeser(LongDeser base, NullValueProvider nuller, Boolean unwrapSingle) {
/* 730 */       super(base, nuller, unwrapSingle);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller, Boolean unwrapSingle) {
/* 736 */       return new LongDeser(this, nuller, unwrapSingle);
/*     */     }
/*     */ 
/*     */     
/*     */     protected long[] _constructEmpty() {
/* 741 */       return new long[0];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public long[] deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 747 */       if (!p.isExpectedStartArrayToken()) {
/* 748 */         return handleNonArray(p, ctxt);
/*     */       }
/* 750 */       ArrayBuilders.LongBuilder builder = ctxt.getArrayBuilders().getLongBuilder();
/* 751 */       long[] chunk = (long[])builder.resetAndStart();
/* 752 */       int ix = 0;
/*     */       
/*     */       try {
/*     */         JsonToken t;
/* 756 */         while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/*     */           long value;
/* 758 */           if (t == JsonToken.VALUE_NUMBER_INT) {
/* 759 */             value = p.getLongValue();
/* 760 */           } else if (t == JsonToken.VALUE_NULL) {
/* 761 */             if (this._nuller != null) {
/* 762 */               this._nuller.getNullValue(ctxt);
/*     */               continue;
/*     */             } 
/* 765 */             _verifyNullForPrimitive(ctxt);
/* 766 */             value = 0L;
/*     */           } else {
/* 768 */             value = _parseLongPrimitive(p, ctxt);
/*     */           } 
/* 770 */           if (ix >= chunk.length) {
/* 771 */             chunk = (long[])builder.appendCompletedChunk(chunk, ix);
/* 772 */             ix = 0;
/*     */           } 
/* 774 */           chunk[ix++] = value;
/*     */         } 
/* 776 */       } catch (Exception e) {
/* 777 */         throw JsonMappingException.wrapWithPath(e, chunk, builder.bufferedSize() + ix);
/*     */       } 
/* 779 */       return (long[])builder.completeAndClearBuffer(chunk, ix);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected long[] handleSingleElementUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 785 */       return new long[] { _parseLongPrimitive(p, ctxt) };
/*     */     }
/*     */ 
/*     */     
/*     */     protected long[] _concat(long[] oldValue, long[] newValue) {
/* 790 */       int len1 = oldValue.length;
/* 791 */       int len2 = newValue.length;
/* 792 */       long[] result = Arrays.copyOf(oldValue, len1 + len2);
/* 793 */       System.arraycopy(newValue, 0, result, len1, len2);
/* 794 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */   @JacksonStdImpl
/*     */   static final class FloatDeser
/*     */     extends PrimitiveArrayDeserializers<float[]> {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     public FloatDeser() {
/* 804 */       super((Class)float[].class);
/*     */     } protected FloatDeser(FloatDeser base, NullValueProvider nuller, Boolean unwrapSingle) {
/* 806 */       super(base, nuller, unwrapSingle);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller, Boolean unwrapSingle) {
/* 812 */       return new FloatDeser(this, nuller, unwrapSingle);
/*     */     }
/*     */ 
/*     */     
/*     */     protected float[] _constructEmpty() {
/* 817 */       return new float[0];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public float[] deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 823 */       if (!p.isExpectedStartArrayToken()) {
/* 824 */         return handleNonArray(p, ctxt);
/*     */       }
/* 826 */       ArrayBuilders.FloatBuilder builder = ctxt.getArrayBuilders().getFloatBuilder();
/* 827 */       float[] chunk = (float[])builder.resetAndStart();
/* 828 */       int ix = 0;
/*     */       
/*     */       try {
/*     */         JsonToken t;
/* 832 */         while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/*     */           
/* 834 */           if (t == JsonToken.VALUE_NULL && 
/* 835 */             this._nuller != null) {
/* 836 */             this._nuller.getNullValue(ctxt);
/*     */             
/*     */             continue;
/*     */           } 
/* 840 */           float value = _parseFloatPrimitive(p, ctxt);
/* 841 */           if (ix >= chunk.length) {
/* 842 */             chunk = (float[])builder.appendCompletedChunk(chunk, ix);
/* 843 */             ix = 0;
/*     */           } 
/* 845 */           chunk[ix++] = value;
/*     */         } 
/* 847 */       } catch (Exception e) {
/* 848 */         throw JsonMappingException.wrapWithPath(e, chunk, builder.bufferedSize() + ix);
/*     */       } 
/* 850 */       return (float[])builder.completeAndClearBuffer(chunk, ix);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected float[] handleSingleElementUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 856 */       return new float[] { _parseFloatPrimitive(p, ctxt) };
/*     */     }
/*     */ 
/*     */     
/*     */     protected float[] _concat(float[] oldValue, float[] newValue) {
/* 861 */       int len1 = oldValue.length;
/* 862 */       int len2 = newValue.length;
/* 863 */       float[] result = Arrays.copyOf(oldValue, len1 + len2);
/* 864 */       System.arraycopy(newValue, 0, result, len1, len2);
/* 865 */       return result;
/*     */     }
/*     */   }
/*     */   
/*     */   @JacksonStdImpl
/*     */   static final class DoubleDeser
/*     */     extends PrimitiveArrayDeserializers<double[]> {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     public DoubleDeser() {
/* 875 */       super((Class)double[].class);
/*     */     } protected DoubleDeser(DoubleDeser base, NullValueProvider nuller, Boolean unwrapSingle) {
/* 877 */       super(base, nuller, unwrapSingle);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected PrimitiveArrayDeserializers<?> withResolved(NullValueProvider nuller, Boolean unwrapSingle) {
/* 883 */       return new DoubleDeser(this, nuller, unwrapSingle);
/*     */     }
/*     */ 
/*     */     
/*     */     protected double[] _constructEmpty() {
/* 888 */       return new double[0];
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public double[] deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 894 */       if (!p.isExpectedStartArrayToken()) {
/* 895 */         return handleNonArray(p, ctxt);
/*     */       }
/* 897 */       ArrayBuilders.DoubleBuilder builder = ctxt.getArrayBuilders().getDoubleBuilder();
/* 898 */       double[] chunk = (double[])builder.resetAndStart();
/* 899 */       int ix = 0;
/*     */       
/*     */       try {
/*     */         JsonToken t;
/* 903 */         while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/* 904 */           if (t == JsonToken.VALUE_NULL && 
/* 905 */             this._nuller != null) {
/* 906 */             this._nuller.getNullValue(ctxt);
/*     */             
/*     */             continue;
/*     */           } 
/* 910 */           double value = _parseDoublePrimitive(p, ctxt);
/* 911 */           if (ix >= chunk.length) {
/* 912 */             chunk = (double[])builder.appendCompletedChunk(chunk, ix);
/* 913 */             ix = 0;
/*     */           } 
/* 915 */           chunk[ix++] = value;
/*     */         } 
/* 917 */       } catch (Exception e) {
/* 918 */         throw JsonMappingException.wrapWithPath(e, chunk, builder.bufferedSize() + ix);
/*     */       } 
/* 920 */       return (double[])builder.completeAndClearBuffer(chunk, ix);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected double[] handleSingleElementUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 926 */       return new double[] { _parseDoublePrimitive(p, ctxt) };
/*     */     }
/*     */ 
/*     */     
/*     */     protected double[] _concat(double[] oldValue, double[] newValue) {
/* 931 */       int len1 = oldValue.length;
/* 932 */       int len2 = newValue.length;
/* 933 */       double[] result = Arrays.copyOf(oldValue, len1 + len2);
/* 934 */       System.arraycopy(newValue, 0, result, len1, len2);
/* 935 */       return result;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\PrimitiveArrayDeserializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */