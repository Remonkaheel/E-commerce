/*     */ package com.fasterxml.jackson.databind.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.format.InputAccessor;
/*     */ import com.fasterxml.jackson.core.format.MatchStrength;
/*     */ import com.fasterxml.jackson.core.io.MergedStream;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.ObjectReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataFormatReaders
/*     */ {
/*     */   public static final int DEFAULT_MAX_INPUT_LOOKAHEAD = 64;
/*     */   protected final ObjectReader[] _readers;
/*     */   protected final MatchStrength _optimalMatch;
/*     */   protected final MatchStrength _minimalMatch;
/*     */   protected final int _maxInputLookahead;
/*     */   
/*     */   public DataFormatReaders(ObjectReader... detectors) {
/*  64 */     this(detectors, MatchStrength.SOLID_MATCH, MatchStrength.WEAK_MATCH, 64);
/*     */   }
/*     */ 
/*     */   
/*     */   public DataFormatReaders(Collection<ObjectReader> detectors) {
/*  69 */     this(detectors.<ObjectReader>toArray(new ObjectReader[detectors.size()]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DataFormatReaders(ObjectReader[] detectors, MatchStrength optMatch, MatchStrength minMatch, int maxInputLookahead) {
/*  76 */     this._readers = detectors;
/*  77 */     this._optimalMatch = optMatch;
/*  78 */     this._minimalMatch = minMatch;
/*  79 */     this._maxInputLookahead = maxInputLookahead;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataFormatReaders withOptimalMatch(MatchStrength optMatch) {
/*  89 */     if (optMatch == this._optimalMatch) {
/*  90 */       return this;
/*     */     }
/*  92 */     return new DataFormatReaders(this._readers, optMatch, this._minimalMatch, this._maxInputLookahead);
/*     */   }
/*     */   
/*     */   public DataFormatReaders withMinimalMatch(MatchStrength minMatch) {
/*  96 */     if (minMatch == this._minimalMatch) {
/*  97 */       return this;
/*     */     }
/*  99 */     return new DataFormatReaders(this._readers, this._optimalMatch, minMatch, this._maxInputLookahead);
/*     */   }
/*     */   
/*     */   public DataFormatReaders with(ObjectReader[] readers) {
/* 103 */     return new DataFormatReaders(readers, this._optimalMatch, this._minimalMatch, this._maxInputLookahead);
/*     */   }
/*     */ 
/*     */   
/*     */   public DataFormatReaders withMaxInputLookahead(int lookaheadBytes) {
/* 108 */     if (lookaheadBytes == this._maxInputLookahead) {
/* 109 */       return this;
/*     */     }
/* 111 */     return new DataFormatReaders(this._readers, this._optimalMatch, this._minimalMatch, lookaheadBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataFormatReaders with(DeserializationConfig config) {
/* 122 */     int len = this._readers.length;
/* 123 */     ObjectReader[] r = new ObjectReader[len];
/* 124 */     for (int i = 0; i < len; i++) {
/* 125 */       r[i] = this._readers[i].with(config);
/*     */     }
/* 127 */     return new DataFormatReaders(r, this._optimalMatch, this._minimalMatch, this._maxInputLookahead);
/*     */   }
/*     */ 
/*     */   
/*     */   public DataFormatReaders withType(JavaType type) {
/* 132 */     int len = this._readers.length;
/* 133 */     ObjectReader[] r = new ObjectReader[len];
/* 134 */     for (int i = 0; i < len; i++) {
/* 135 */       r[i] = this._readers[i].forType(type);
/*     */     }
/* 137 */     return new DataFormatReaders(r, this._optimalMatch, this._minimalMatch, this._maxInputLookahead);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Match findFormat(InputStream in) throws IOException {
/* 156 */     return _findFormat(new AccessorForReader(in, new byte[this._maxInputLookahead]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Match findFormat(byte[] fullInputData) throws IOException {
/* 168 */     return _findFormat(new AccessorForReader(fullInputData));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Match findFormat(byte[] fullInputData, int offset, int len) throws IOException {
/* 182 */     return _findFormat(new AccessorForReader(fullInputData, offset, len));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 194 */     StringBuilder sb = new StringBuilder();
/* 195 */     sb.append('[');
/* 196 */     int len = this._readers.length;
/* 197 */     if (len > 0) {
/* 198 */       sb.append(this._readers[0].getFactory().getFormatName());
/* 199 */       for (int i = 1; i < len; i++) {
/* 200 */         sb.append(", ");
/* 201 */         sb.append(this._readers[i].getFactory().getFormatName());
/*     */       } 
/*     */     } 
/* 204 */     sb.append(']');
/* 205 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Match _findFormat(AccessorForReader acc) throws IOException {
/* 216 */     ObjectReader bestMatch = null;
/* 217 */     MatchStrength bestMatchStrength = null;
/* 218 */     for (ObjectReader f : this._readers) {
/* 219 */       acc.reset();
/* 220 */       MatchStrength strength = f.getFactory().hasFormat((InputAccessor)acc);
/*     */       
/* 222 */       if (strength != null && strength.ordinal() >= this._minimalMatch.ordinal())
/*     */       {
/*     */ 
/*     */         
/* 226 */         if (bestMatch == null || 
/* 227 */           bestMatchStrength.ordinal() < strength.ordinal()) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 232 */           bestMatch = f;
/* 233 */           bestMatchStrength = strength;
/* 234 */           if (strength.ordinal() >= this._optimalMatch.ordinal())
/*     */             break; 
/*     */         }  } 
/*     */     } 
/* 238 */     return acc.createMatcher(bestMatch, bestMatchStrength);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class AccessorForReader
/*     */     extends InputAccessor.Std
/*     */   {
/*     */     public AccessorForReader(InputStream in, byte[] buffer) {
/* 253 */       super(in, buffer);
/*     */     }
/*     */     public AccessorForReader(byte[] inputDocument) {
/* 256 */       super(inputDocument);
/*     */     }
/*     */     public AccessorForReader(byte[] inputDocument, int start, int len) {
/* 259 */       super(inputDocument, start, len);
/*     */     }
/*     */ 
/*     */     
/*     */     public DataFormatReaders.Match createMatcher(ObjectReader match, MatchStrength matchStrength) {
/* 264 */       return new DataFormatReaders.Match(this._in, this._buffer, this._bufferedStart, this._bufferedEnd - this._bufferedStart, match, matchStrength);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Match
/*     */   {
/*     */     protected final InputStream _originalStream;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final byte[] _bufferedData;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final int _bufferedStart;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final int _bufferedLength;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final ObjectReader _match;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final MatchStrength _matchStrength;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Match(InputStream in, byte[] buffered, int bufferedStart, int bufferedLength, ObjectReader match, MatchStrength strength) {
/* 305 */       this._originalStream = in;
/* 306 */       this._bufferedData = buffered;
/* 307 */       this._bufferedStart = bufferedStart;
/* 308 */       this._bufferedLength = bufferedLength;
/* 309 */       this._match = match;
/* 310 */       this._matchStrength = strength;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasMatch() {
/* 323 */       return (this._match != null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MatchStrength getMatchStrength() {
/* 330 */       return (this._matchStrength == null) ? MatchStrength.INCONCLUSIVE : this._matchStrength;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ObjectReader getReader() {
/* 336 */       return this._match;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getMatchedFormatName() {
/* 346 */       return this._match.getFactory().getFormatName();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonParser createParserWithMatch() throws IOException {
/* 362 */       if (this._match == null) {
/* 363 */         return null;
/*     */       }
/* 365 */       JsonFactory jf = this._match.getFactory();
/* 366 */       if (this._originalStream == null) {
/* 367 */         return jf.createParser(this._bufferedData, this._bufferedStart, this._bufferedLength);
/*     */       }
/* 369 */       return jf.createParser(getDataStream());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InputStream getDataStream() {
/* 380 */       if (this._originalStream == null) {
/* 381 */         return new ByteArrayInputStream(this._bufferedData, this._bufferedStart, this._bufferedLength);
/*     */       }
/* 383 */       return (InputStream)new MergedStream(null, this._originalStream, this._bufferedData, this._bufferedStart, this._bufferedLength);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\DataFormatReaders.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */