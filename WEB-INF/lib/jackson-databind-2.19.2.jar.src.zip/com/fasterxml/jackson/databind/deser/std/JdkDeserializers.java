/*    */ package com.fasterxml.jackson.databind.deser.std;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.util.HashSet;
/*    */ import java.util.UUID;
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ import java.util.concurrent.atomic.AtomicLong;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JdkDeserializers
/*    */ {
/* 17 */   private static final HashSet<String> _classNames = new HashSet<>();
/*    */   
/*    */   static {
/* 20 */     Class<?>[] types = new Class[] { UUID.class, AtomicBoolean.class, AtomicInteger.class, AtomicLong.class, StackTraceElement.class, ByteBuffer.class, Void.class, ThreadGroup.class };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 30 */     for (Class<?> cls : types) _classNames.add(cls.getName()); 
/* 31 */     for (Class<?> cls : FromStringDeserializer.types()) _classNames.add(cls.getName());
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static JsonDeserializer<?> find(DeserializationContext ctxt, Class<?> rawType, String clsName) throws JsonMappingException {
/* 41 */     if (_classNames.contains(clsName)) {
/* 42 */       JsonDeserializer<?> d = FromStringDeserializer.findDeserializer(rawType);
/* 43 */       if (d != null) {
/* 44 */         return d;
/*    */       }
/* 46 */       if (rawType == UUID.class) {
/* 47 */         return new UUIDDeserializer();
/*    */       }
/* 49 */       if (rawType == StackTraceElement.class) {
/* 50 */         return StackTraceElementDeserializer.construct(ctxt);
/*    */       }
/* 52 */       if (rawType == AtomicBoolean.class) {
/* 53 */         return new AtomicBooleanDeserializer();
/*    */       }
/* 55 */       if (rawType == AtomicInteger.class) {
/* 56 */         return new AtomicIntegerDeserializer();
/*    */       }
/* 58 */       if (rawType == AtomicLong.class) {
/* 59 */         return new AtomicLongDeserializer();
/*    */       }
/* 61 */       if (rawType == ByteBuffer.class) {
/* 62 */         return new ByteBufferDeserializer();
/*    */       }
/* 64 */       if (rawType == Void.class) {
/* 65 */         return NullifyingDeserializer.instance;
/*    */       }
/* 67 */       if (rawType == ThreadGroup.class) {
/* 68 */         return new ThreadGroupDeserializer();
/*    */       }
/*    */     } 
/* 71 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean hasDeserializerFor(Class<?> rawType) {
/* 76 */     return _classNames.contains(rawType.getName());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\JdkDeserializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */