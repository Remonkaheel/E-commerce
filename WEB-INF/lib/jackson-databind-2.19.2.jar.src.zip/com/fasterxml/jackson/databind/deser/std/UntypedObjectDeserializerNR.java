/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ final class UntypedObjectDeserializerNR
/*     */   extends StdDeserializer<Object>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  31 */   protected static final Object[] NO_OBJECTS = new Object[0];
/*     */   
/*  33 */   public static final UntypedObjectDeserializerNR std = new UntypedObjectDeserializerNR();
/*     */   
/*     */   protected final boolean _nonMerging;
/*     */   
/*     */   public UntypedObjectDeserializerNR() {
/*  38 */     this(false);
/*     */   }
/*     */   protected UntypedObjectDeserializerNR(boolean nonMerging) {
/*  41 */     super(Object.class);
/*  42 */     this._nonMerging = nonMerging;
/*     */   }
/*     */   
/*     */   public static UntypedObjectDeserializerNR instance(boolean nonMerging) {
/*  46 */     if (nonMerging) {
/*  47 */       return new UntypedObjectDeserializerNR(true);
/*     */     }
/*  49 */     return std;
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/*  54 */     return LogicalType.Untyped;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/*  61 */     return this._nonMerging ? Boolean.FALSE : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  67 */     switch (p.currentTokenId()) {
/*     */       case 1:
/*  69 */         return _deserializeNR(p, ctxt, 
/*  70 */             Scope.rootObjectScope(ctxt.isEnabled(StreamReadCapability.DUPLICATE_PROPERTIES)));
/*     */ 
/*     */       
/*     */       case 2:
/*  74 */         return Scope.emptyMap();
/*     */       case 5:
/*  76 */         return _deserializeObjectAtName(p, ctxt);
/*     */       case 3:
/*  78 */         return _deserializeNR(p, ctxt, Scope.rootArrayScope());
/*     */       
/*     */       case 6:
/*  81 */         return p.getText();
/*     */       case 7:
/*  83 */         if (ctxt.hasSomeOfFeatures(F_MASK_INT_COERCIONS)) {
/*  84 */           return _coerceIntegral(p, ctxt);
/*     */         }
/*  86 */         return p.getNumberValue();
/*     */       case 8:
/*  88 */         return _deserializeFP(p, ctxt);
/*     */       case 9:
/*  90 */         return Boolean.TRUE;
/*     */       case 10:
/*  92 */         return Boolean.FALSE;
/*     */       case 11:
/*  94 */         return null;
/*     */       case 12:
/*  96 */         return p.getEmbeddedObject();
/*     */     } 
/*     */     
/*  99 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 107 */     switch (p.currentTokenId()) {
/*     */       case 1:
/*     */       case 3:
/*     */       case 5:
/* 111 */         return typeDeserializer.deserializeTypedFromAny(p, ctxt);
/*     */     } 
/* 113 */     return _deserializeAnyScalar(p, ctxt, p.currentTokenId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt, Object intoValue) throws IOException {
/*     */     JsonToken t;
/* 122 */     if (this._nonMerging) {
/* 123 */       return deserialize(p, ctxt);
/*     */     }
/* 125 */     switch (p.currentTokenId()) {
/*     */       case 2:
/*     */       case 4:
/* 128 */         return intoValue;
/*     */       
/*     */       case 1:
/* 131 */         t = p.nextToken();
/* 132 */         if (t == JsonToken.END_OBJECT) {
/* 133 */           return intoValue;
/*     */         }
/*     */ 
/*     */       
/*     */       case 5:
/* 138 */         if (intoValue instanceof Map) {
/* 139 */           Map<Object, Object> m = (Map<Object, Object>)intoValue;
/*     */           
/* 141 */           String key = p.currentName(); while (true) {
/*     */             Object newV;
/* 143 */             p.nextToken();
/*     */             
/* 145 */             Object old = m.get(key);
/*     */             
/* 147 */             if (old != null) {
/* 148 */               newV = deserialize(p, ctxt, old);
/*     */             } else {
/* 150 */               newV = deserialize(p, ctxt);
/*     */             } 
/* 152 */             if (newV != old) {
/* 153 */               m.put(key, newV);
/*     */             }
/* 155 */             if ((key = p.nextFieldName()) == null)
/* 156 */               return intoValue; 
/*     */           } 
/*     */         } 
/*     */         break;
/*     */       case 3:
/* 161 */         t = p.nextToken();
/* 162 */         if (t == JsonToken.END_ARRAY) {
/* 163 */           return intoValue;
/*     */         }
/*     */ 
/*     */         
/* 167 */         if (intoValue instanceof Collection) {
/* 168 */           Collection<Object> c = (Collection<Object>)intoValue;
/*     */           
/*     */           while (true) {
/* 171 */             c.add(deserialize(p, ctxt));
/* 172 */             if (p.nextToken() == JsonToken.END_ARRAY) {
/* 173 */               return intoValue;
/*     */             }
/*     */           } 
/*     */         } 
/*     */         break;
/*     */     } 
/*     */     
/* 180 */     return deserialize(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object _deserializeObjectAtName(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 186 */     Scope rootObject = Scope.rootObjectScope(ctxt.isEnabled(StreamReadCapability.DUPLICATE_PROPERTIES));
/* 187 */     String key = p.currentName();
/* 188 */     for (; key != null; key = p.nextFieldName()) {
/*     */       Object value;
/* 190 */       JsonToken t = p.nextToken();
/* 191 */       if (t == null) {
/* 192 */         t = JsonToken.NOT_AVAILABLE;
/*     */       }
/* 194 */       switch (t.id()) {
/*     */         case 1:
/* 196 */           value = _deserializeNR(p, ctxt, rootObject.childObject());
/*     */           break;
/*     */         case 2:
/* 199 */           return rootObject.finishRootObject();
/*     */         case 3:
/* 201 */           value = _deserializeNR(p, ctxt, rootObject.childArray());
/*     */           break;
/*     */         default:
/* 204 */           value = _deserializeAnyScalar(p, ctxt, t.id()); break;
/*     */       } 
/* 206 */       rootObject.putValue(key, value);
/*     */     } 
/* 208 */     return rootObject.finishRootObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object _deserializeNR(JsonParser p, DeserializationContext ctxt, Scope rootScope) throws IOException {
/*     */     // Byte code:
/*     */     //   0: aload_2
/*     */     //   1: getstatic com/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR.F_MASK_INT_COERCIONS : I
/*     */     //   4: invokevirtual hasSomeOfFeatures : (I)Z
/*     */     //   7: istore #4
/*     */     //   9: aload_2
/*     */     //   10: getstatic com/fasterxml/jackson/databind/DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY : Lcom/fasterxml/jackson/databind/DeserializationFeature;
/*     */     //   13: invokevirtual isEnabled : (Lcom/fasterxml/jackson/databind/DeserializationFeature;)Z
/*     */     //   16: istore #5
/*     */     //   18: aload_3
/*     */     //   19: astore #6
/*     */     //   21: aload #6
/*     */     //   23: invokevirtual isObject : ()Z
/*     */     //   26: ifeq -> 273
/*     */     //   29: aload_1
/*     */     //   30: invokevirtual nextFieldName : ()Ljava/lang/String;
/*     */     //   33: astore #7
/*     */     //   35: aload #7
/*     */     //   37: ifnull -> 251
/*     */     //   40: aload_1
/*     */     //   41: invokevirtual nextToken : ()Lcom/fasterxml/jackson/core/JsonToken;
/*     */     //   44: astore #9
/*     */     //   46: aload #9
/*     */     //   48: ifnonnull -> 56
/*     */     //   51: getstatic com/fasterxml/jackson/core/JsonToken.NOT_AVAILABLE : Lcom/fasterxml/jackson/core/JsonToken;
/*     */     //   54: astore #9
/*     */     //   56: aload #9
/*     */     //   58: invokevirtual id : ()I
/*     */     //   61: tableswitch default -> 222, 1 -> 124, 2 -> 222, 3 -> 136, 4 -> 222, 5 -> 222, 6 -> 148, 7 -> 157, 8 -> 180, 9 -> 191, 10 -> 199, 11 -> 207, 12 -> 213
/*     */     //   124: aload #6
/*     */     //   126: aload #7
/*     */     //   128: invokevirtual childObject : (Ljava/lang/String;)Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR$Scope;
/*     */     //   131: astore #6
/*     */     //   133: goto -> 242
/*     */     //   136: aload #6
/*     */     //   138: aload #7
/*     */     //   140: invokevirtual childArray : (Ljava/lang/String;)Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR$Scope;
/*     */     //   143: astore #6
/*     */     //   145: goto -> 21
/*     */     //   148: aload_1
/*     */     //   149: invokevirtual getText : ()Ljava/lang/String;
/*     */     //   152: astore #8
/*     */     //   154: goto -> 233
/*     */     //   157: iload #4
/*     */     //   159: ifeq -> 171
/*     */     //   162: aload_0
/*     */     //   163: aload_1
/*     */     //   164: aload_2
/*     */     //   165: invokevirtual _coerceIntegral : (Lcom/fasterxml/jackson/core/JsonParser;Lcom/fasterxml/jackson/databind/DeserializationContext;)Ljava/lang/Object;
/*     */     //   168: goto -> 175
/*     */     //   171: aload_1
/*     */     //   172: invokevirtual getNumberValue : ()Ljava/lang/Number;
/*     */     //   175: astore #8
/*     */     //   177: goto -> 233
/*     */     //   180: aload_0
/*     */     //   181: aload_1
/*     */     //   182: aload_2
/*     */     //   183: invokevirtual _deserializeFP : (Lcom/fasterxml/jackson/core/JsonParser;Lcom/fasterxml/jackson/databind/DeserializationContext;)Ljava/lang/Object;
/*     */     //   186: astore #8
/*     */     //   188: goto -> 233
/*     */     //   191: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
/*     */     //   194: astore #8
/*     */     //   196: goto -> 233
/*     */     //   199: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
/*     */     //   202: astore #8
/*     */     //   204: goto -> 233
/*     */     //   207: aconst_null
/*     */     //   208: astore #8
/*     */     //   210: goto -> 233
/*     */     //   213: aload_1
/*     */     //   214: invokevirtual getEmbeddedObject : ()Ljava/lang/Object;
/*     */     //   217: astore #8
/*     */     //   219: goto -> 233
/*     */     //   222: aload_2
/*     */     //   223: aload_0
/*     */     //   224: aload_2
/*     */     //   225: invokevirtual getValueType : (Lcom/fasterxml/jackson/databind/DeserializationContext;)Lcom/fasterxml/jackson/databind/JavaType;
/*     */     //   228: aload_1
/*     */     //   229: invokevirtual handleUnexpectedToken : (Lcom/fasterxml/jackson/databind/JavaType;Lcom/fasterxml/jackson/core/JsonParser;)Ljava/lang/Object;
/*     */     //   232: areturn
/*     */     //   233: aload #6
/*     */     //   235: aload #7
/*     */     //   237: aload #8
/*     */     //   239: invokevirtual putValue : (Ljava/lang/String;Ljava/lang/Object;)V
/*     */     //   242: aload_1
/*     */     //   243: invokevirtual nextFieldName : ()Ljava/lang/String;
/*     */     //   246: astore #7
/*     */     //   248: goto -> 35
/*     */     //   251: aload #6
/*     */     //   253: aload_3
/*     */     //   254: if_acmpne -> 263
/*     */     //   257: aload #6
/*     */     //   259: invokevirtual finishRootObject : ()Ljava/lang/Object;
/*     */     //   262: areturn
/*     */     //   263: aload #6
/*     */     //   265: invokevirtual finishBranchObject : ()Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR$Scope;
/*     */     //   268: astore #6
/*     */     //   270: goto -> 21
/*     */     //   273: aload_1
/*     */     //   274: invokevirtual nextToken : ()Lcom/fasterxml/jackson/core/JsonToken;
/*     */     //   277: astore #7
/*     */     //   279: aload #7
/*     */     //   281: ifnonnull -> 289
/*     */     //   284: getstatic com/fasterxml/jackson/core/JsonToken.NOT_AVAILABLE : Lcom/fasterxml/jackson/core/JsonToken;
/*     */     //   287: astore #7
/*     */     //   289: aload #7
/*     */     //   291: invokevirtual id : ()I
/*     */     //   294: tableswitch default -> 476, 1 -> 356, 2 -> 476, 3 -> 366, 4 -> 376, 5 -> 476, 6 -> 402, 7 -> 411, 8 -> 434, 9 -> 445, 10 -> 453, 11 -> 461, 12 -> 467
/*     */     //   356: aload #6
/*     */     //   358: invokevirtual childObject : ()Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR$Scope;
/*     */     //   361: astore #6
/*     */     //   363: goto -> 21
/*     */     //   366: aload #6
/*     */     //   368: invokevirtual childArray : ()Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR$Scope;
/*     */     //   371: astore #6
/*     */     //   373: goto -> 21
/*     */     //   376: aload #6
/*     */     //   378: aload_3
/*     */     //   379: if_acmpne -> 390
/*     */     //   382: aload #6
/*     */     //   384: iload #5
/*     */     //   386: invokevirtual finishRootArray : (Z)Ljava/lang/Object;
/*     */     //   389: areturn
/*     */     //   390: aload #6
/*     */     //   392: iload #5
/*     */     //   394: invokevirtual finishBranchArray : (Z)Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR$Scope;
/*     */     //   397: astore #6
/*     */     //   399: goto -> 21
/*     */     //   402: aload_1
/*     */     //   403: invokevirtual getText : ()Ljava/lang/String;
/*     */     //   406: astore #8
/*     */     //   408: goto -> 487
/*     */     //   411: iload #4
/*     */     //   413: ifeq -> 425
/*     */     //   416: aload_0
/*     */     //   417: aload_1
/*     */     //   418: aload_2
/*     */     //   419: invokevirtual _coerceIntegral : (Lcom/fasterxml/jackson/core/JsonParser;Lcom/fasterxml/jackson/databind/DeserializationContext;)Ljava/lang/Object;
/*     */     //   422: goto -> 429
/*     */     //   425: aload_1
/*     */     //   426: invokevirtual getNumberValue : ()Ljava/lang/Number;
/*     */     //   429: astore #8
/*     */     //   431: goto -> 487
/*     */     //   434: aload_0
/*     */     //   435: aload_1
/*     */     //   436: aload_2
/*     */     //   437: invokevirtual _deserializeFP : (Lcom/fasterxml/jackson/core/JsonParser;Lcom/fasterxml/jackson/databind/DeserializationContext;)Ljava/lang/Object;
/*     */     //   440: astore #8
/*     */     //   442: goto -> 487
/*     */     //   445: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
/*     */     //   448: astore #8
/*     */     //   450: goto -> 487
/*     */     //   453: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
/*     */     //   456: astore #8
/*     */     //   458: goto -> 487
/*     */     //   461: aconst_null
/*     */     //   462: astore #8
/*     */     //   464: goto -> 487
/*     */     //   467: aload_1
/*     */     //   468: invokevirtual getEmbeddedObject : ()Ljava/lang/Object;
/*     */     //   471: astore #8
/*     */     //   473: goto -> 487
/*     */     //   476: aload_2
/*     */     //   477: aload_0
/*     */     //   478: aload_2
/*     */     //   479: invokevirtual getValueType : (Lcom/fasterxml/jackson/databind/DeserializationContext;)Lcom/fasterxml/jackson/databind/JavaType;
/*     */     //   482: aload_1
/*     */     //   483: invokevirtual handleUnexpectedToken : (Lcom/fasterxml/jackson/databind/JavaType;Lcom/fasterxml/jackson/core/JsonParser;)Ljava/lang/Object;
/*     */     //   486: areturn
/*     */     //   487: aload #6
/*     */     //   489: aload #8
/*     */     //   491: invokevirtual addValue : (Ljava/lang/Object;)V
/*     */     //   494: goto -> 273
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #215	-> 0
/*     */     //   #216	-> 9
/*     */     //   #218	-> 18
/*     */     //   #222	-> 21
/*     */     //   #223	-> 29
/*     */     //   #226	-> 35
/*     */     //   #228	-> 40
/*     */     //   #229	-> 46
/*     */     //   #230	-> 51
/*     */     //   #232	-> 56
/*     */     //   #234	-> 124
/*     */     //   #236	-> 133
/*     */     //   #238	-> 136
/*     */     //   #240	-> 145
/*     */     //   #242	-> 148
/*     */     //   #243	-> 154
/*     */     //   #245	-> 157
/*     */     //   #246	-> 177
/*     */     //   #248	-> 180
/*     */     //   #249	-> 188
/*     */     //   #251	-> 191
/*     */     //   #252	-> 196
/*     */     //   #254	-> 199
/*     */     //   #255	-> 204
/*     */     //   #257	-> 207
/*     */     //   #258	-> 210
/*     */     //   #260	-> 213
/*     */     //   #261	-> 219
/*     */     //   #263	-> 222
/*     */     //   #265	-> 233
/*     */     //   #226	-> 242
/*     */     //   #268	-> 251
/*     */     //   #269	-> 257
/*     */     //   #271	-> 263
/*     */     //   #272	-> 270
/*     */     //   #276	-> 273
/*     */     //   #277	-> 279
/*     */     //   #278	-> 284
/*     */     //   #281	-> 289
/*     */     //   #283	-> 356
/*     */     //   #284	-> 363
/*     */     //   #286	-> 366
/*     */     //   #287	-> 373
/*     */     //   #289	-> 376
/*     */     //   #290	-> 382
/*     */     //   #292	-> 390
/*     */     //   #293	-> 399
/*     */     //   #295	-> 402
/*     */     //   #296	-> 408
/*     */     //   #298	-> 411
/*     */     //   #299	-> 431
/*     */     //   #301	-> 434
/*     */     //   #302	-> 442
/*     */     //   #304	-> 445
/*     */     //   #305	-> 450
/*     */     //   #307	-> 453
/*     */     //   #308	-> 458
/*     */     //   #310	-> 461
/*     */     //   #311	-> 464
/*     */     //   #313	-> 467
/*     */     //   #314	-> 473
/*     */     //   #316	-> 476
/*     */     //   #318	-> 487
/*     */     //   #319	-> 494
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   154	3	8	value	Ljava/lang/Object;
/*     */     //   177	3	8	value	Ljava/lang/Object;
/*     */     //   188	3	8	value	Ljava/lang/Object;
/*     */     //   196	3	8	value	Ljava/lang/Object;
/*     */     //   204	3	8	value	Ljava/lang/Object;
/*     */     //   210	3	8	value	Ljava/lang/Object;
/*     */     //   219	3	8	value	Ljava/lang/Object;
/*     */     //   233	9	8	value	Ljava/lang/Object;
/*     */     //   46	196	9	t	Lcom/fasterxml/jackson/core/JsonToken;
/*     */     //   35	235	7	propName	Ljava/lang/String;
/*     */     //   408	3	8	value	Ljava/lang/Object;
/*     */     //   431	3	8	value	Ljava/lang/Object;
/*     */     //   442	3	8	value	Ljava/lang/Object;
/*     */     //   450	3	8	value	Ljava/lang/Object;
/*     */     //   458	3	8	value	Ljava/lang/Object;
/*     */     //   464	3	8	value	Ljava/lang/Object;
/*     */     //   473	3	8	value	Ljava/lang/Object;
/*     */     //   279	215	7	t	Lcom/fasterxml/jackson/core/JsonToken;
/*     */     //   487	7	8	value	Ljava/lang/Object;
/*     */     //   0	497	0	this	Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR;
/*     */     //   0	497	1	p	Lcom/fasterxml/jackson/core/JsonParser;
/*     */     //   0	497	2	ctxt	Lcom/fasterxml/jackson/databind/DeserializationContext;
/*     */     //   0	497	3	rootScope	Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR$Scope;
/*     */     //   9	488	4	intCoercions	Z
/*     */     //   18	479	5	useJavaArray	Z
/*     */     //   21	476	6	currScope	Lcom/fasterxml/jackson/databind/deser/std/UntypedObjectDeserializerNR$Scope;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object _deserializeAnyScalar(JsonParser p, DeserializationContext ctxt, int tokenType) throws IOException {
/* 328 */     switch (tokenType) {
/*     */       case 6:
/* 330 */         return p.getText();
/*     */       case 7:
/* 332 */         if (ctxt.isEnabled(DeserializationFeature.USE_BIG_INTEGER_FOR_INTS)) {
/* 333 */           return p.getBigIntegerValue();
/*     */         }
/* 335 */         return p.getNumberValue();
/*     */       
/*     */       case 8:
/* 338 */         return _deserializeFP(p, ctxt);
/*     */       case 9:
/* 340 */         return Boolean.TRUE;
/*     */       case 10:
/* 342 */         return Boolean.FALSE;
/*     */       case 12:
/* 344 */         return p.getEmbeddedObject();
/*     */       
/*     */       case 11:
/* 347 */         return null;
/*     */     } 
/*     */ 
/*     */     
/* 351 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserializeFP(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 357 */     JsonParser.NumberTypeFP nt = p.getNumberTypeFP();
/* 358 */     if (nt == JsonParser.NumberTypeFP.BIG_DECIMAL) {
/* 359 */       return p.getDecimalValue();
/*     */     }
/* 361 */     if (!p.isNaN() && 
/* 362 */       ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 363 */       return p.getDecimalValue();
/*     */     }
/*     */     
/* 366 */     if (nt == JsonParser.NumberTypeFP.FLOAT32) {
/* 367 */       return Float.valueOf(p.getFloatValue());
/*     */     }
/* 369 */     return Double.valueOf(p.getDoubleValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _mapObjectWithDups(JsonParser p, DeserializationContext ctxt, Map<String, Object> result, String initialKey, Object oldValue, Object newValue, String nextKey) throws IOException {
/* 378 */     boolean squashDups = ctxt.isEnabled(StreamReadCapability.DUPLICATE_PROPERTIES);
/*     */     
/* 380 */     if (squashDups) {
/* 381 */       _squashDups(result, initialKey, oldValue, newValue);
/*     */     }
/*     */     
/* 384 */     while (nextKey != null) {
/* 385 */       p.nextToken();
/* 386 */       newValue = deserialize(p, ctxt);
/* 387 */       oldValue = result.put(nextKey, newValue);
/* 388 */       if (oldValue != null && squashDups) {
/* 389 */         _squashDups(result, nextKey, oldValue, newValue);
/*     */       }
/* 391 */       nextKey = p.nextFieldName();
/*     */     } 
/*     */     
/* 394 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _squashDups(Map<String, Object> result, String key, Object oldValue, Object newValue) {
/* 402 */     if (oldValue instanceof List) {
/* 403 */       ((List<Object>)oldValue).add(newValue);
/* 404 */       result.put(key, oldValue);
/*     */     } else {
/* 406 */       ArrayList<Object> l = new ArrayList();
/* 407 */       l.add(oldValue);
/* 408 */       l.add(newValue);
/* 409 */       result.put(key, l);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Scope
/*     */   {
/*     */     private final Scope _parent;
/*     */ 
/*     */     
/*     */     private Scope _child;
/*     */ 
/*     */     
/*     */     private boolean _isObject;
/*     */ 
/*     */     
/*     */     private boolean _squashDups;
/*     */ 
/*     */     
/*     */     private String _deferredKey;
/*     */ 
/*     */     
/*     */     private Map<String, Object> _map;
/*     */ 
/*     */     
/*     */     private List<Object> _list;
/*     */ 
/*     */ 
/*     */     
/*     */     private Scope(Scope p) {
/* 441 */       this._parent = p;
/* 442 */       this._isObject = false;
/* 443 */       this._squashDups = false;
/*     */     }
/*     */ 
/*     */     
/*     */     private Scope(Scope p, boolean isObject, boolean squashDups) {
/* 448 */       this._parent = p;
/* 449 */       this._isObject = isObject;
/* 450 */       this._squashDups = squashDups;
/*     */     }
/*     */     
/*     */     public static Scope rootObjectScope(boolean squashDups) {
/* 454 */       return new Scope(null, true, squashDups);
/*     */     }
/*     */     
/*     */     public static Scope rootArrayScope() {
/* 458 */       return new Scope(null);
/*     */     }
/*     */     
/*     */     private Scope resetAsArray() {
/* 462 */       this._isObject = false;
/* 463 */       return this;
/*     */     }
/*     */     
/*     */     private Scope resetAsObject(boolean squashDups) {
/* 467 */       this._isObject = true;
/* 468 */       this._squashDups = squashDups;
/* 469 */       return this;
/*     */     }
/*     */     
/*     */     public Scope childObject() {
/* 473 */       if (this._child == null) {
/* 474 */         return new Scope(this, true, this._squashDups);
/*     */       }
/* 476 */       return this._child.resetAsObject(this._squashDups);
/*     */     }
/*     */     
/*     */     public Scope childObject(String deferredKey) {
/* 480 */       this._deferredKey = deferredKey;
/* 481 */       if (this._child == null) {
/* 482 */         return new Scope(this, true, this._squashDups);
/*     */       }
/* 484 */       return this._child.resetAsObject(this._squashDups);
/*     */     }
/*     */     
/*     */     public Scope childArray() {
/* 488 */       if (this._child == null) {
/* 489 */         return new Scope(this);
/*     */       }
/* 491 */       return this._child.resetAsArray();
/*     */     }
/*     */     
/*     */     public Scope childArray(String deferredKey) {
/* 495 */       this._deferredKey = deferredKey;
/* 496 */       if (this._child == null) {
/* 497 */         return new Scope(this);
/*     */       }
/* 499 */       return this._child.resetAsArray();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isObject() {
/* 509 */       return this._isObject;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void putValue(String key, Object value) {
/* 519 */       if (this._squashDups) {
/* 520 */         _putValueHandleDups(key, value);
/*     */         return;
/*     */       } 
/* 523 */       if (this._map == null) {
/* 524 */         this._map = new LinkedHashMap<>();
/*     */       }
/* 526 */       this._map.put(key, value);
/*     */     }
/*     */     
/*     */     public Scope putDeferredValue(Object value) {
/* 530 */       String key = Objects.<String>requireNonNull(this._deferredKey);
/* 531 */       this._deferredKey = null;
/* 532 */       if (this._squashDups) {
/* 533 */         _putValueHandleDups(key, value);
/* 534 */         return this;
/*     */       } 
/* 536 */       if (this._map == null) {
/* 537 */         this._map = new LinkedHashMap<>();
/*     */       }
/* 539 */       this._map.put(key, value);
/* 540 */       return this;
/*     */     }
/*     */     
/*     */     public void addValue(Object value) {
/* 544 */       if (this._list == null) {
/* 545 */         this._list = new ArrayList();
/*     */       }
/* 547 */       this._list.add(value);
/*     */     }
/*     */     
/*     */     public Object finishRootObject() {
/* 551 */       if (this._map == null) {
/* 552 */         return emptyMap();
/*     */       }
/* 554 */       return this._map;
/*     */     }
/*     */     
/*     */     public Scope finishBranchObject() {
/*     */       Object<String, Object> value;
/* 559 */       if (this._map == null) {
/* 560 */         Object<Object, Object> object = (Object<Object, Object>)new LinkedHashMap<>();
/*     */       } else {
/* 562 */         value = (Object<String, Object>)this._map;
/* 563 */         this._map = null;
/*     */       } 
/* 565 */       if (this._parent.isObject()) {
/* 566 */         return this._parent.putDeferredValue(value);
/*     */       }
/* 568 */       this._parent.addValue(value);
/* 569 */       return this._parent;
/*     */     }
/*     */     
/*     */     public Object finishRootArray(boolean asJavaArray) {
/* 573 */       if (this._list == null) {
/* 574 */         if (asJavaArray) {
/* 575 */           return UntypedObjectDeserializerNR.NO_OBJECTS;
/*     */         }
/* 577 */         return emptyList();
/*     */       } 
/* 579 */       if (asJavaArray) {
/* 580 */         return this._list.toArray(UntypedObjectDeserializerNR.NO_OBJECTS);
/*     */       }
/* 582 */       return this._list;
/*     */     }
/*     */     
/*     */     public Scope finishBranchArray(boolean asJavaArray) {
/*     */       Object<Object> value;
/* 587 */       if (this._list == null) {
/* 588 */         if (asJavaArray) {
/* 589 */           value = (Object<Object>)UntypedObjectDeserializerNR.NO_OBJECTS;
/*     */         } else {
/* 591 */           value = (Object<Object>)emptyList();
/*     */         } 
/*     */       } else {
/* 594 */         if (asJavaArray) {
/* 595 */           value = this._list.toArray(UntypedObjectDeserializerNR.NO_OBJECTS);
/*     */         } else {
/* 597 */           value = (Object<Object>)this._list;
/*     */         } 
/* 599 */         this._list = null;
/*     */       } 
/* 601 */       if (this._parent.isObject()) {
/* 602 */         return this._parent.putDeferredValue(value);
/*     */       }
/* 604 */       this._parent.addValue(value);
/* 605 */       return this._parent;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void _putValueHandleDups(String key, Object newValue) {
/* 614 */       if (this._map == null) {
/* 615 */         this._map = new LinkedHashMap<>();
/* 616 */         this._map.put(key, newValue);
/*     */         return;
/*     */       } 
/* 619 */       Object old = this._map.put(key, newValue);
/* 620 */       if (old != null)
/*     */       {
/* 622 */         if (old instanceof List) {
/* 623 */           ((List<Object>)old).add(newValue);
/* 624 */           this._map.put(key, old);
/*     */         } else {
/* 626 */           ArrayList<Object> l = new ArrayList();
/* 627 */           l.add(old);
/* 628 */           l.add(newValue);
/* 629 */           this._map.put(key, l);
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Map<String, Object> emptyMap() {
/* 642 */       return new LinkedHashMap<>(2);
/*     */     }
/*     */     
/*     */     public static List<Object> emptyList() {
/* 646 */       return new ArrayList(2);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\UntypedObjectDeserializerNR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */