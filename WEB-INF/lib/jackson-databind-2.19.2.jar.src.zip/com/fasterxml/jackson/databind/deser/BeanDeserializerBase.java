/*      */ package com.fasterxml.jackson.databind.deser;
/*      */ import com.fasterxml.jackson.annotation.JsonFormat;
/*      */ import com.fasterxml.jackson.annotation.JsonSetter;
/*      */ import com.fasterxml.jackson.annotation.Nulls;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.BeanProperty;
/*      */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*      */ import com.fasterxml.jackson.databind.PropertyName;
/*      */ import com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ObjectIdReader;
/*      */ import com.fasterxml.jackson.databind.deser.impl.PropertyBasedCreator;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*      */ import com.fasterxml.jackson.databind.deser.impl.UnwrappedPropertyHandler;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ValueInjector;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.introspect.ObjectIdInfo;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.type.ClassKey;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*      */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*      */ import java.io.IOException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.util.Set;
/*      */ 
/*      */ public abstract class BeanDeserializerBase extends StdDeserializer<Object> implements ContextualDeserializer, ResolvableDeserializer, ValueInstantiator.Gettable, Serializable {
/*   36 */   protected static final PropertyName TEMP_PROPERTY_NAME = new PropertyName("#temporary-name");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JavaType _beanType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonFormat.Shape _serializationShape;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ValueInstantiator _valueInstantiator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> _delegateDeserializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> _arrayDelegateDeserializer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PropertyBasedCreator _propertyBasedCreator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _nonStandardCreation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _vanillaProcessing;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final BeanPropertyMap _beanProperties;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ValueInjector[] _injectables;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SettableAnyProperty _anySetter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Set<String> _ignorableProps;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Set<String> _includableProps;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _ignoreAllUnknown;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _needViewProcesing;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Map<String, SettableBeanProperty> _backRefs;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected transient ConcurrentHashMap<ClassKey, JsonDeserializer<Object>> _subDeserializers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected UnwrappedPropertyHandler _unwrappedPropertyHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ExternalTypeHandler _externalTypeIdHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ObjectIdReader _objectIdReader;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanDeserializerBase(BeanDeserializerBuilder builder, BeanDescription beanDesc, BeanPropertyMap properties, Map<String, SettableBeanProperty> backRefs, Set<String> ignorableProps, boolean ignoreAllUnknown, Set<String> includableProps, boolean hasViews) {
/*  220 */     super(beanDesc.getType());
/*  221 */     this._beanType = beanDesc.getType();
/*      */     
/*  223 */     this._valueInstantiator = builder.getValueInstantiator();
/*  224 */     this._delegateDeserializer = null;
/*  225 */     this._arrayDelegateDeserializer = null;
/*  226 */     this._propertyBasedCreator = null;
/*      */     
/*  228 */     this._beanProperties = properties;
/*  229 */     this._backRefs = backRefs;
/*  230 */     this._ignorableProps = ignorableProps;
/*  231 */     this._ignoreAllUnknown = ignoreAllUnknown;
/*  232 */     this._includableProps = includableProps;
/*      */     
/*  234 */     this._anySetter = builder.getAnySetter();
/*  235 */     List<ValueInjector> injectables = builder.getInjectables();
/*  236 */     this
/*  237 */       ._injectables = (injectables == null || injectables.isEmpty()) ? null : injectables.<ValueInjector>toArray(new ValueInjector[injectables.size()]);
/*  238 */     this._objectIdReader = builder.getObjectIdReader();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  245 */     this
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  251 */       ._nonStandardCreation = (this._unwrappedPropertyHandler != null || this._valueInstantiator.canCreateUsingDelegate() || this._valueInstantiator.canCreateFromObjectWith() || !this._valueInstantiator.canCreateUsingDefault());
/*      */ 
/*      */ 
/*      */     
/*  255 */     JsonFormat.Value format = beanDesc.findExpectedFormat();
/*  256 */     this._serializationShape = format.getShape();
/*      */     
/*  258 */     this._needViewProcesing = hasViews;
/*  259 */     this._vanillaProcessing = (!this._nonStandardCreation && this._injectables == null && !this._needViewProcesing && this._objectIdReader == null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanDeserializerBase(BeanDeserializerBase src) {
/*  268 */     this(src, src._ignoreAllUnknown);
/*      */   }
/*      */ 
/*      */   
/*      */   protected BeanDeserializerBase(BeanDeserializerBase src, boolean ignoreAllUnknown) {
/*  273 */     super(src._beanType);
/*      */     
/*  275 */     this._beanType = src._beanType;
/*      */     
/*  277 */     this._valueInstantiator = src._valueInstantiator;
/*  278 */     this._delegateDeserializer = src._delegateDeserializer;
/*  279 */     this._arrayDelegateDeserializer = src._arrayDelegateDeserializer;
/*  280 */     this._propertyBasedCreator = src._propertyBasedCreator;
/*      */     
/*  282 */     this._beanProperties = src._beanProperties;
/*  283 */     this._backRefs = src._backRefs;
/*  284 */     this._ignorableProps = src._ignorableProps;
/*  285 */     this._ignoreAllUnknown = ignoreAllUnknown;
/*  286 */     this._includableProps = src._includableProps;
/*  287 */     this._anySetter = src._anySetter;
/*  288 */     this._injectables = src._injectables;
/*  289 */     this._objectIdReader = src._objectIdReader;
/*      */     
/*  291 */     this._nonStandardCreation = src._nonStandardCreation;
/*  292 */     this._unwrappedPropertyHandler = src._unwrappedPropertyHandler;
/*  293 */     this._needViewProcesing = src._needViewProcesing;
/*  294 */     this._serializationShape = src._serializationShape;
/*      */     
/*  296 */     this._vanillaProcessing = src._vanillaProcessing;
/*      */     
/*  298 */     this._externalTypeIdHandler = src._externalTypeIdHandler;
/*      */   }
/*      */ 
/*      */   
/*      */   protected BeanDeserializerBase(BeanDeserializerBase src, NameTransformer unwrapper) {
/*  303 */     super(src._beanType);
/*      */     
/*  305 */     this._beanType = src._beanType;
/*      */     
/*  307 */     this._valueInstantiator = src._valueInstantiator;
/*  308 */     this._delegateDeserializer = src._delegateDeserializer;
/*  309 */     this._arrayDelegateDeserializer = src._arrayDelegateDeserializer;
/*      */     
/*  311 */     this._backRefs = src._backRefs;
/*  312 */     this._ignorableProps = src._ignorableProps;
/*  313 */     this._ignoreAllUnknown = (unwrapper != null || src._ignoreAllUnknown);
/*  314 */     this._includableProps = src._includableProps;
/*  315 */     this._anySetter = src._anySetter;
/*  316 */     this._injectables = src._injectables;
/*  317 */     this._objectIdReader = src._objectIdReader;
/*      */     
/*  319 */     this._nonStandardCreation = src._nonStandardCreation;
/*  320 */     UnwrappedPropertyHandler uph = src._unwrappedPropertyHandler;
/*  321 */     PropertyBasedCreator pbc = src._propertyBasedCreator;
/*      */     
/*  323 */     if (unwrapper != null) {
/*      */       
/*  325 */       if (uph != null) {
/*  326 */         uph = uph.renameAll(unwrapper);
/*      */       }
/*      */       
/*  329 */       if (pbc != null) {
/*  330 */         pbc = pbc.renameAll(unwrapper);
/*      */       }
/*  332 */       this._beanProperties = src._beanProperties.renameAll(unwrapper);
/*      */     } else {
/*  334 */       this._beanProperties = src._beanProperties;
/*      */     } 
/*  336 */     this._propertyBasedCreator = pbc;
/*  337 */     this._unwrappedPropertyHandler = uph;
/*  338 */     this._needViewProcesing = src._needViewProcesing;
/*  339 */     this._serializationShape = src._serializationShape;
/*      */ 
/*      */     
/*  342 */     this._vanillaProcessing = false;
/*      */     
/*  344 */     this._externalTypeIdHandler = src._externalTypeIdHandler;
/*      */   }
/*      */ 
/*      */   
/*      */   public BeanDeserializerBase(BeanDeserializerBase src, ObjectIdReader oir) {
/*  349 */     super(src._beanType);
/*  350 */     this._beanType = src._beanType;
/*      */     
/*  352 */     this._valueInstantiator = src._valueInstantiator;
/*  353 */     this._delegateDeserializer = src._delegateDeserializer;
/*  354 */     this._arrayDelegateDeserializer = src._arrayDelegateDeserializer;
/*  355 */     this._propertyBasedCreator = src._propertyBasedCreator;
/*      */     
/*  357 */     this._backRefs = src._backRefs;
/*  358 */     this._ignorableProps = src._ignorableProps;
/*  359 */     this._ignoreAllUnknown = src._ignoreAllUnknown;
/*  360 */     this._includableProps = src._includableProps;
/*  361 */     this._anySetter = src._anySetter;
/*  362 */     this._injectables = src._injectables;
/*      */     
/*  364 */     this._nonStandardCreation = src._nonStandardCreation;
/*  365 */     this._unwrappedPropertyHandler = src._unwrappedPropertyHandler;
/*  366 */     this._needViewProcesing = src._needViewProcesing;
/*  367 */     this._serializationShape = src._serializationShape;
/*      */ 
/*      */     
/*  370 */     this._objectIdReader = oir;
/*      */     
/*  372 */     if (oir == null) {
/*  373 */       this._beanProperties = src._beanProperties;
/*  374 */       this._vanillaProcessing = src._vanillaProcessing;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  380 */       ObjectIdValueProperty idProp = new ObjectIdValueProperty(oir, PropertyMetadata.STD_REQUIRED);
/*  381 */       this._beanProperties = src._beanProperties.withProperty((SettableBeanProperty)idProp);
/*  382 */       this._vanillaProcessing = false;
/*      */     } 
/*      */     
/*  385 */     this._externalTypeIdHandler = src._externalTypeIdHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDeserializerBase(BeanDeserializerBase src, Set<String> ignorableProps, Set<String> includableProps) {
/*  394 */     super(src._beanType);
/*  395 */     this._beanType = src._beanType;
/*      */     
/*  397 */     this._valueInstantiator = src._valueInstantiator;
/*  398 */     this._delegateDeserializer = src._delegateDeserializer;
/*  399 */     this._arrayDelegateDeserializer = src._arrayDelegateDeserializer;
/*  400 */     this._propertyBasedCreator = src._propertyBasedCreator;
/*      */     
/*  402 */     this._backRefs = src._backRefs;
/*  403 */     this._ignorableProps = ignorableProps;
/*  404 */     this._ignoreAllUnknown = src._ignoreAllUnknown;
/*  405 */     this._includableProps = includableProps;
/*  406 */     this._anySetter = src._anySetter;
/*  407 */     this._injectables = src._injectables;
/*      */     
/*  409 */     this._nonStandardCreation = src._nonStandardCreation;
/*  410 */     this._unwrappedPropertyHandler = src._unwrappedPropertyHandler;
/*  411 */     this._needViewProcesing = src._needViewProcesing;
/*  412 */     this._serializationShape = src._serializationShape;
/*      */     
/*  414 */     this._vanillaProcessing = src._vanillaProcessing;
/*  415 */     this._objectIdReader = src._objectIdReader;
/*      */ 
/*      */ 
/*      */     
/*  419 */     this._beanProperties = src._beanProperties.withoutProperties(ignorableProps, includableProps);
/*      */     
/*  421 */     this._externalTypeIdHandler = src._externalTypeIdHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanDeserializerBase(BeanDeserializerBase src, BeanPropertyMap beanProps) {
/*  429 */     super(src._beanType);
/*  430 */     this._beanType = src._beanType;
/*      */     
/*  432 */     this._valueInstantiator = src._valueInstantiator;
/*  433 */     this._delegateDeserializer = src._delegateDeserializer;
/*  434 */     this._arrayDelegateDeserializer = src._arrayDelegateDeserializer;
/*  435 */     this._propertyBasedCreator = src._propertyBasedCreator;
/*      */     
/*  437 */     this._beanProperties = beanProps;
/*  438 */     this._backRefs = src._backRefs;
/*  439 */     this._ignorableProps = src._ignorableProps;
/*  440 */     this._ignoreAllUnknown = src._ignoreAllUnknown;
/*  441 */     this._includableProps = src._includableProps;
/*  442 */     this._anySetter = src._anySetter;
/*  443 */     this._injectables = src._injectables;
/*  444 */     this._objectIdReader = src._objectIdReader;
/*      */     
/*  446 */     this._nonStandardCreation = src._nonStandardCreation;
/*  447 */     this._unwrappedPropertyHandler = src._unwrappedPropertyHandler;
/*  448 */     this._needViewProcesing = src._needViewProcesing;
/*  449 */     this._serializationShape = src._serializationShape;
/*      */     
/*  451 */     this._vanillaProcessing = src._vanillaProcessing;
/*      */     
/*  453 */     this._externalTypeIdHandler = src._externalTypeIdHandler;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected BeanDeserializerBase(BeanDeserializerBase src, Set<String> ignorableProps) {
/*  459 */     this(src, ignorableProps, src._includableProps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract JsonDeserializer<Object> unwrappingDeserializer(NameTransformer paramNameTransformer);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract BeanDeserializerBase withObjectIdReader(ObjectIdReader paramObjectIdReader);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract BeanDeserializerBase withByNameInclusion(Set<String> paramSet1, Set<String> paramSet2);
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract BeanDeserializerBase withIgnoreAllUnknown(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDeserializerBase withBeanProperties(BeanPropertyMap props) {
/*  484 */     throw new UnsupportedOperationException("Class " + getClass().getName() + " does not override `withBeanProperties()`, needs to");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract BeanDeserializerBase asArrayDeserializer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public BeanDeserializerBase withIgnorableProperties(Set<String> ignorableProps) {
/*  502 */     return withByNameInclusion(ignorableProps, this._includableProps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resolve(DeserializationContext ctxt) throws JsonMappingException {
/*      */     SettableBeanProperty[] creatorProps;
/*  519 */     ExternalTypeHandler.Builder extTypes = null;
/*      */ 
/*      */ 
/*      */     
/*  523 */     if (this._valueInstantiator.canCreateFromObjectWith()) {
/*  524 */       creatorProps = this._valueInstantiator.getFromObjectArguments(ctxt.getConfig());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  529 */       if (this._ignorableProps != null || this._includableProps != null) {
/*  530 */         for (int i = 0, end = creatorProps.length; i < end; i++) {
/*  531 */           SettableBeanProperty prop = creatorProps[i];
/*  532 */           if (IgnorePropertiesUtil.shouldIgnore(prop.getName(), this._ignorableProps, this._includableProps)) {
/*  533 */             creatorProps[i].markAsIgnorable();
/*      */           }
/*      */         } 
/*      */       }
/*      */     } else {
/*  538 */       creatorProps = null;
/*      */     } 
/*  540 */     UnwrappedPropertyHandler unwrapped = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  550 */     for (SettableBeanProperty prop : this._beanProperties) {
/*  551 */       if (!prop.hasValueDeserializer()) {
/*      */         
/*  553 */         JsonDeserializer<?> deser = findConvertingDeserializer(ctxt, prop);
/*  554 */         if (deser == null) {
/*  555 */           deser = ctxt.findNonContextualValueDeserializer(prop.getType());
/*      */         }
/*  557 */         SettableBeanProperty newProp = prop.withValueDeserializer(deser);
/*  558 */         _replaceProperty(this._beanProperties, creatorProps, prop, newProp);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  563 */     for (SettableBeanProperty origProp : this._beanProperties) {
/*  564 */       SettableBeanProperty prop = origProp;
/*  565 */       JsonDeserializer<?> deser = prop.getValueDeserializer();
/*  566 */       deser = ctxt.handlePrimaryContextualization(deser, (BeanProperty)prop, prop.getType());
/*  567 */       prop = prop.withValueDeserializer(deser);
/*      */       
/*  569 */       prop = _resolveManagedReferenceProperty(ctxt, prop);
/*      */ 
/*      */       
/*  572 */       if (!(prop instanceof ManagedReferenceProperty)) {
/*  573 */         prop = _resolvedObjectIdProperty(ctxt, prop);
/*      */       }
/*      */       
/*  576 */       NameTransformer xform = _findPropertyUnwrapper(ctxt, prop);
/*  577 */       if (xform != null) {
/*  578 */         JsonDeserializer<Object> orig = prop.getValueDeserializer();
/*  579 */         JsonDeserializer<Object> unwrapping = orig.unwrappingDeserializer(xform);
/*  580 */         if (unwrapping != orig && unwrapping != null) {
/*  581 */           prop = prop.withValueDeserializer(unwrapping);
/*  582 */           if (unwrapped == null) {
/*  583 */             unwrapped = new UnwrappedPropertyHandler();
/*      */           }
/*      */           
/*  586 */           if (prop instanceof CreatorProperty) {
/*  587 */             unwrapped.addCreatorProperty(prop);
/*      */           } else {
/*  589 */             unwrapped.addProperty(prop);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  596 */           this._beanProperties.remove(prop);
/*      */ 
/*      */           
/*      */           continue;
/*      */         } 
/*      */       } 
/*      */       
/*  603 */       PropertyMetadata md = prop.getMetadata();
/*  604 */       prop = _resolveMergeAndNullSettings(ctxt, prop, md);
/*      */ 
/*      */       
/*  607 */       prop = _resolveInnerClassValuedProperty(ctxt, prop);
/*  608 */       if (prop != origProp) {
/*  609 */         _replaceProperty(this._beanProperties, creatorProps, origProp, prop);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  614 */       if (prop.hasValueTypeDeserializer()) {
/*  615 */         TypeDeserializer typeDeser = prop.getValueTypeDeserializer();
/*  616 */         if (typeDeser.getTypeInclusion() == JsonTypeInfo.As.EXTERNAL_PROPERTY) {
/*  617 */           if (extTypes == null) {
/*  618 */             extTypes = ExternalTypeHandler.builder(this._beanType);
/*      */           }
/*  620 */           extTypes.addExternal(prop, typeDeser);
/*      */           
/*  622 */           this._beanProperties.remove(prop);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  628 */     if (this._anySetter != null && !this._anySetter.hasValueDeserializer()) {
/*  629 */       this._anySetter = this._anySetter.withValueDeserializer(findDeserializer(ctxt, this._anySetter
/*  630 */             .getType(), this._anySetter.getProperty()));
/*      */     }
/*      */     
/*  633 */     if (this._valueInstantiator.canCreateUsingDelegate()) {
/*  634 */       JavaType delegateType = this._valueInstantiator.getDelegateType(ctxt.getConfig());
/*  635 */       if (delegateType == null)
/*  636 */         ctxt.reportBadDefinition(this._beanType, String.format("Invalid delegate-creator definition for %s: value instantiator (%s) returned true for 'canCreateUsingDelegate()', but null for 'getDelegateType()'", new Object[] {
/*      */                 
/*  638 */                 ClassUtil.getTypeDescription(this._beanType), ClassUtil.classNameOf(this._valueInstantiator)
/*      */               })); 
/*  640 */       this._delegateDeserializer = _findDelegateDeserializer(ctxt, delegateType, this._valueInstantiator
/*  641 */           .getDelegateCreator());
/*      */     } 
/*      */ 
/*      */     
/*  645 */     if (this._valueInstantiator.canCreateUsingArrayDelegate()) {
/*  646 */       JavaType delegateType = this._valueInstantiator.getArrayDelegateType(ctxt.getConfig());
/*  647 */       if (delegateType == null)
/*  648 */         ctxt.reportBadDefinition(this._beanType, String.format("Invalid delegate-creator definition for %s: value instantiator (%s) returned true for 'canCreateUsingArrayDelegate()', but null for 'getArrayDelegateType()'", new Object[] {
/*      */                 
/*  650 */                 ClassUtil.getTypeDescription(this._beanType), ClassUtil.classNameOf(this._valueInstantiator)
/*      */               })); 
/*  652 */       this._arrayDelegateDeserializer = _findDelegateDeserializer(ctxt, delegateType, this._valueInstantiator
/*  653 */           .getArrayDelegateCreator());
/*      */     } 
/*      */ 
/*      */     
/*  657 */     if (creatorProps != null) {
/*  658 */       this._propertyBasedCreator = PropertyBasedCreator.construct(ctxt, this._valueInstantiator, creatorProps, this._beanProperties);
/*      */     }
/*      */ 
/*      */     
/*  662 */     if (extTypes != null) {
/*      */ 
/*      */       
/*  665 */       this._externalTypeIdHandler = extTypes.build(this._beanProperties);
/*      */       
/*  667 */       this._nonStandardCreation = true;
/*      */     } 
/*      */     
/*  670 */     this._unwrappedPropertyHandler = unwrapped;
/*  671 */     if (unwrapped != null) {
/*  672 */       this._nonStandardCreation = true;
/*      */     }
/*      */     
/*  675 */     this._vanillaProcessing = (this._vanillaProcessing && !this._nonStandardCreation);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _replaceProperty(BeanPropertyMap props, SettableBeanProperty[] creatorProps, SettableBeanProperty origProp, SettableBeanProperty newProp) {
/*  684 */     props.replace(origProp, newProp);
/*      */     
/*  686 */     if (creatorProps != null)
/*      */     {
/*      */       
/*  689 */       for (int i = 0, len = creatorProps.length; i < len; i++) {
/*  690 */         if (creatorProps[i] == origProp) {
/*  691 */           creatorProps[i] = newProp;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JsonDeserializer<Object> _findDelegateDeserializer(DeserializationContext ctxt, JavaType delegateType, AnnotatedWithParams delegateCreator) throws JsonMappingException {
/*      */     BeanProperty.Std std;
/*  720 */     if (delegateCreator != null && delegateCreator.getParameterCount() == 1) {
/*  721 */       AnnotatedParameter annotatedParameter = delegateCreator.getParameter(0);
/*  722 */       PropertyMetadata propMd = _getSetterInfo(ctxt, (AnnotatedMember)annotatedParameter, delegateType);
/*  723 */       std = new BeanProperty.Std(TEMP_PROPERTY_NAME, delegateType, null, (AnnotatedMember)annotatedParameter, propMd);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  729 */       std = new BeanProperty.Std(TEMP_PROPERTY_NAME, delegateType, null, (AnnotatedMember)delegateCreator, PropertyMetadata.STD_OPTIONAL);
/*      */     } 
/*      */ 
/*      */     
/*  733 */     TypeDeserializer td = (TypeDeserializer)delegateType.getTypeHandler();
/*  734 */     if (td == null) {
/*  735 */       td = ctxt.getConfig().findTypeDeserializer(delegateType);
/*      */     }
/*      */ 
/*      */     
/*  739 */     JsonDeserializer<Object> dd = (JsonDeserializer<Object>)delegateType.getValueHandler();
/*  740 */     if (dd == null) {
/*  741 */       dd = findDeserializer(ctxt, delegateType, (BeanProperty)std);
/*      */     } else {
/*  743 */       dd = ctxt.handleSecondaryContextualization(dd, (BeanProperty)std, delegateType);
/*      */     } 
/*  745 */     if (td != null) {
/*  746 */       td = td.forProperty((BeanProperty)std);
/*  747 */       return (JsonDeserializer<Object>)new TypeWrappedDeserializer(td, dd);
/*      */     } 
/*  749 */     return dd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PropertyMetadata _getSetterInfo(DeserializationContext ctxt, AnnotatedMember accessor, JavaType type) {
/*  762 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/*  763 */     DeserializationConfig config = ctxt.getConfig();
/*      */     
/*  765 */     PropertyMetadata metadata = PropertyMetadata.STD_OPTIONAL;
/*  766 */     boolean needMerge = true;
/*  767 */     Nulls valueNulls = null;
/*  768 */     Nulls contentNulls = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  773 */     if (intr != null) {
/*  774 */       JsonSetter.Value setterInfo = intr.findSetterInfo((Annotated)accessor);
/*  775 */       if (setterInfo != null) {
/*  776 */         valueNulls = setterInfo.nonDefaultValueNulls();
/*  777 */         contentNulls = setterInfo.nonDefaultContentNulls();
/*      */       } 
/*      */     } 
/*      */     
/*  781 */     if (needMerge || valueNulls == null || contentNulls == null) {
/*  782 */       ConfigOverride co = config.getConfigOverride(type.getRawClass());
/*  783 */       JsonSetter.Value setterInfo = co.getSetterInfo();
/*  784 */       if (setterInfo != null) {
/*  785 */         if (valueNulls == null) {
/*  786 */           valueNulls = setterInfo.nonDefaultValueNulls();
/*      */         }
/*  788 */         if (contentNulls == null) {
/*  789 */           contentNulls = setterInfo.nonDefaultContentNulls();
/*      */         }
/*      */       } 
/*      */     } 
/*  793 */     if (needMerge || valueNulls == null || contentNulls == null) {
/*  794 */       JsonSetter.Value setterInfo = config.getDefaultSetterInfo();
/*  795 */       if (valueNulls == null) {
/*  796 */         valueNulls = setterInfo.nonDefaultValueNulls();
/*      */       }
/*  798 */       if (contentNulls == null) {
/*  799 */         contentNulls = setterInfo.nonDefaultContentNulls();
/*      */       }
/*      */     } 
/*  802 */     if (valueNulls != null || contentNulls != null) {
/*  803 */       metadata = metadata.withNulls(valueNulls, contentNulls);
/*      */     }
/*  805 */     return metadata;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> findConvertingDeserializer(DeserializationContext ctxt, SettableBeanProperty prop) throws JsonMappingException {
/*  822 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/*  823 */     if (intr != null) {
/*  824 */       Object convDef = intr.findDeserializationConverter((Annotated)prop.getMember());
/*  825 */       if (convDef != null) {
/*  826 */         Converter<Object, Object> conv = ctxt.converterInstance((Annotated)prop.getMember(), convDef);
/*  827 */         JavaType delegateType = conv.getInputType(ctxt.getTypeFactory());
/*      */ 
/*      */         
/*  830 */         JsonDeserializer<?> deser = ctxt.findNonContextualValueDeserializer(delegateType);
/*  831 */         return (JsonDeserializer<Object>)new StdDelegatingDeserializer(conv, delegateType, deser);
/*      */       } 
/*      */     } 
/*  834 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/*  848 */     ObjectIdReader oir = this._objectIdReader;
/*      */ 
/*      */     
/*  851 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/*  852 */     AnnotatedMember accessor = _neitherNull(property, intr) ? property.getMember() : null;
/*  853 */     if (accessor != null) {
/*  854 */       ObjectIdInfo objectIdInfo = intr.findObjectIdInfo((Annotated)accessor);
/*  855 */       if (objectIdInfo != null) {
/*      */         JavaType idType; SettableBeanProperty idProp; ObjectIdGenerator<?> idGen;
/*  857 */         objectIdInfo = intr.findObjectReferenceInfo((Annotated)accessor, objectIdInfo);
/*      */         
/*  859 */         Class<?> implClass = objectIdInfo.getGeneratorType();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  864 */         ObjectIdResolver resolver = ctxt.objectIdResolverInstance((Annotated)accessor, objectIdInfo);
/*  865 */         if (implClass == ObjectIdGenerators.PropertyGenerator.class) {
/*  866 */           PropertyName propName = objectIdInfo.getPropertyName();
/*  867 */           idProp = findProperty(propName);
/*  868 */           if (idProp == null)
/*  869 */             return (JsonDeserializer)ctxt.reportBadDefinition(this._beanType, String.format("Invalid Object Id definition for %s: cannot find property with name %s", new Object[] {
/*      */                     
/*  871 */                     ClassUtil.nameOf(handledType()), ClassUtil.name(propName)
/*      */                   })); 
/*  873 */           idType = idProp.getType();
/*  874 */           PropertyBasedObjectIdGenerator propertyBasedObjectIdGenerator = new PropertyBasedObjectIdGenerator(objectIdInfo.getScope());
/*      */         } else {
/*  876 */           JavaType type = ctxt.constructType(implClass);
/*  877 */           idType = ctxt.getTypeFactory().findTypeParameters(type, ObjectIdGenerator.class)[0];
/*  878 */           idProp = null;
/*  879 */           idGen = ctxt.objectIdGeneratorInstance((Annotated)accessor, objectIdInfo);
/*      */         } 
/*  881 */         JsonDeserializer<?> deser = ctxt.findRootValueDeserializer(idType);
/*  882 */         oir = ObjectIdReader.construct(idType, objectIdInfo.getPropertyName(), idGen, deser, idProp, resolver);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  887 */     BeanDeserializerBase contextual = this;
/*  888 */     if (oir != null && oir != this._objectIdReader) {
/*  889 */       contextual = contextual.withObjectIdReader(oir);
/*      */     }
/*      */     
/*  892 */     if (accessor != null) {
/*  893 */       contextual = _handleByNameInclusion(ctxt, intr, contextual, accessor);
/*      */     }
/*      */ 
/*      */     
/*  897 */     JsonFormat.Value format = findFormatOverrides(ctxt, property, handledType());
/*  898 */     JsonFormat.Shape shape = null;
/*  899 */     if (format != null) {
/*  900 */       if (format.hasShape()) {
/*  901 */         shape = format.getShape();
/*      */       }
/*      */       
/*  904 */       Boolean B = format.getFeature(JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES);
/*  905 */       if (B != null) {
/*  906 */         BeanPropertyMap propsOrig = this._beanProperties;
/*  907 */         BeanPropertyMap props = propsOrig.withCaseInsensitivity(B.booleanValue());
/*  908 */         if (props != propsOrig) {
/*  909 */           contextual = contextual.withBeanProperties(props);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  914 */     if (shape == null) {
/*  915 */       shape = this._serializationShape;
/*      */     }
/*  917 */     if (shape == JsonFormat.Shape.ARRAY) {
/*  918 */       contextual = contextual.asArrayDeserializer();
/*      */     }
/*  920 */     return (JsonDeserializer<?>)contextual;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanDeserializerBase _handleByNameInclusion(DeserializationContext ctxt, AnnotationIntrospector intr, BeanDeserializerBase contextual, AnnotatedMember accessor) throws JsonMappingException {
/*      */     Set<String> newNamesToIgnore;
/*  929 */     DeserializationConfig config = ctxt.getConfig();
/*  930 */     JsonIgnoreProperties.Value ignorals = intr.findPropertyIgnoralByName((MapperConfig)config, (Annotated)accessor);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  936 */     if (ignorals.getIgnoreUnknown() && !this._ignoreAllUnknown) {
/*  937 */       contextual = contextual.withIgnoreAllUnknown(true);
/*      */     }
/*      */     
/*  940 */     Set<String> namesToIgnore = ignorals.findIgnoredForDeserialization();
/*  941 */     Set<String> prevNamesToIgnore = contextual._ignorableProps;
/*      */ 
/*      */     
/*  944 */     if (namesToIgnore.isEmpty()) {
/*  945 */       newNamesToIgnore = prevNamesToIgnore;
/*  946 */     } else if (prevNamesToIgnore == null || prevNamesToIgnore.isEmpty()) {
/*  947 */       newNamesToIgnore = namesToIgnore;
/*      */     } else {
/*  949 */       newNamesToIgnore = new HashSet<>(prevNamesToIgnore);
/*  950 */       newNamesToIgnore.addAll(namesToIgnore);
/*      */     } 
/*      */     
/*  953 */     Set<String> prevNamesToInclude = contextual._includableProps;
/*  954 */     Set<String> newNamesToInclude = IgnorePropertiesUtil.combineNamesToInclude(prevNamesToInclude, intr
/*  955 */         .findPropertyInclusionByName((MapperConfig)config, (Annotated)accessor).getIncluded());
/*      */     
/*  957 */     if (newNamesToIgnore != prevNamesToIgnore || newNamesToInclude != prevNamesToInclude)
/*      */     {
/*  959 */       contextual = contextual.withByNameInclusion(newNamesToIgnore, newNamesToInclude);
/*      */     }
/*  961 */     return contextual;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SettableBeanProperty _resolveManagedReferenceProperty(DeserializationContext ctxt, SettableBeanProperty prop) throws JsonMappingException {
/*  972 */     String refName = prop.getManagedReferenceName();
/*  973 */     if (refName == null) {
/*  974 */       return prop;
/*      */     }
/*  976 */     JsonDeserializer<?> valueDeser = prop.getValueDeserializer();
/*  977 */     SettableBeanProperty backProp = valueDeser.findBackReference(refName);
/*  978 */     if (backProp == null) {
/*  979 */       return (SettableBeanProperty)ctxt.reportBadDefinition(this._beanType, String.format("Cannot handle managed/back reference %s: no back reference property found from type %s", new Object[] {
/*      */               
/*  981 */               ClassUtil.name(refName), ClassUtil.getTypeDescription(prop.getType())
/*      */             }));
/*      */     }
/*  984 */     JavaType referredType = this._beanType;
/*  985 */     JavaType backRefType = backProp.getType();
/*  986 */     boolean isContainer = prop.getType().isContainerType();
/*  987 */     if (!backRefType.getRawClass().isAssignableFrom(referredType.getRawClass()))
/*  988 */       ctxt.reportBadDefinition(this._beanType, String.format("Cannot handle managed/back reference %s: back reference type (%s) not compatible with managed type (%s)", new Object[] {
/*      */               
/*  990 */               ClassUtil.name(refName), ClassUtil.getTypeDescription(backRefType), referredType
/*  991 */               .getRawClass().getName()
/*      */             })); 
/*  993 */     return (SettableBeanProperty)new ManagedReferenceProperty(prop, refName, backProp, isContainer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SettableBeanProperty _resolvedObjectIdProperty(DeserializationContext ctxt, SettableBeanProperty prop) throws JsonMappingException {
/* 1003 */     ObjectIdInfo objectIdInfo = prop.getObjectIdInfo();
/* 1004 */     JsonDeserializer<Object> valueDeser = prop.getValueDeserializer();
/* 1005 */     ObjectIdReader objectIdReader = (valueDeser == null) ? null : valueDeser.getObjectIdReader();
/* 1006 */     if (objectIdInfo == null && objectIdReader == null) {
/* 1007 */       return prop;
/*      */     }
/* 1009 */     return (SettableBeanProperty)new ObjectIdReferenceProperty(prop, objectIdInfo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected NameTransformer _findPropertyUnwrapper(DeserializationContext ctxt, SettableBeanProperty prop) throws JsonMappingException {
/* 1020 */     AnnotatedMember am = prop.getMember();
/* 1021 */     if (am != null) {
/* 1022 */       NameTransformer unwrapper = ctxt.getAnnotationIntrospector().findUnwrappingNameTransformer(am);
/* 1023 */       if (unwrapper != null) {
/* 1024 */         return unwrapper;
/*      */       }
/*      */     } 
/* 1027 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SettableBeanProperty _resolveInnerClassValuedProperty(DeserializationContext ctxt, SettableBeanProperty prop) {
/* 1040 */     JsonDeserializer<Object> deser = prop.getValueDeserializer();
/*      */     
/* 1042 */     if (deser instanceof BeanDeserializerBase) {
/* 1043 */       BeanDeserializerBase bd = (BeanDeserializerBase)deser;
/* 1044 */       ValueInstantiator vi = bd.getValueInstantiator();
/* 1045 */       if (!vi.canCreateUsingDefault()) {
/* 1046 */         Class<?> valueClass = prop.getType().getRawClass();
/*      */         
/* 1048 */         Class<?> enclosing = ClassUtil.getOuterClass(valueClass);
/*      */         
/* 1050 */         if (enclosing != null && enclosing == this._beanType.getRawClass()) {
/* 1051 */           for (Constructor<?> ctor : valueClass.getConstructors()) {
/* 1052 */             if (ctor.getParameterCount() == 1) {
/* 1053 */               Class<?>[] paramTypes = ctor.getParameterTypes();
/* 1054 */               if (enclosing.equals(paramTypes[0])) {
/* 1055 */                 if (ctxt.canOverrideAccessModifiers()) {
/* 1056 */                   ClassUtil.checkAndFixAccess(ctor, ctxt.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*      */                 }
/* 1058 */                 return (SettableBeanProperty)new InnerClassProperty(prop, ctor);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/* 1065 */     return prop;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected SettableBeanProperty _resolveMergeAndNullSettings(DeserializationContext ctxt, SettableBeanProperty prop, PropertyMetadata propMetadata) throws JsonMappingException {
/*      */     MergingSettableBeanProperty mergingSettableBeanProperty;
/*      */     SettableBeanProperty settableBeanProperty;
/* 1073 */     PropertyMetadata.MergeInfo merge = propMetadata.getMergeInfo();
/*      */     
/* 1075 */     if (merge != null) {
/* 1076 */       JsonDeserializer<?> valueDeser = prop.getValueDeserializer();
/* 1077 */       Boolean mayMerge = valueDeser.supportsUpdate(ctxt.getConfig());
/*      */       
/* 1079 */       if (mayMerge == null) {
/*      */         
/* 1081 */         if (merge.fromDefaults) {
/* 1082 */           return prop;
/*      */         }
/* 1084 */       } else if (!mayMerge.booleanValue()) {
/* 1085 */         if (!merge.fromDefaults)
/*      */         {
/*      */           
/* 1088 */           ctxt.handleBadMerge(valueDeser);
/*      */         }
/* 1090 */         return prop;
/*      */       } 
/*      */       
/* 1093 */       AnnotatedMember accessor = merge.getter;
/* 1094 */       accessor.fixAccess(ctxt.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/* 1095 */       if (!(prop instanceof com.fasterxml.jackson.databind.deser.impl.SetterlessProperty)) {
/* 1096 */         mergingSettableBeanProperty = MergingSettableBeanProperty.construct(prop, accessor);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1101 */     NullValueProvider nuller = findValueNullProvider(ctxt, (SettableBeanProperty)mergingSettableBeanProperty, propMetadata);
/* 1102 */     if (nuller != null) {
/* 1103 */       settableBeanProperty = mergingSettableBeanProperty.withNullProvider(nuller);
/*      */     }
/* 1105 */     return settableBeanProperty;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public AccessPattern getNullAccessPattern() {
/* 1117 */     return AccessPattern.ALWAYS_NULL;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public AccessPattern getEmptyAccessPattern() {
/* 1123 */     return AccessPattern.DYNAMIC;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/*      */     try {
/* 1134 */       return this._valueInstantiator.createUsingDefaultOrWithoutArguments(ctxt);
/* 1135 */     } catch (IOException e) {
/* 1136 */       return ClassUtil.throwAsMappingException(ctxt, e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCachable() {
/* 1147 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCaseInsensitive() {
/* 1159 */     return this._beanProperties.isCaseInsensitive();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 1167 */     return Boolean.TRUE;
/*      */   }
/*      */ 
/*      */   
/*      */   public Class<?> handledType() {
/* 1172 */     return this._beanType.getRawClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ObjectIdReader getObjectIdReader() {
/* 1182 */     return this._objectIdReader;
/*      */   }
/*      */   
/*      */   public boolean hasProperty(String propertyName) {
/* 1186 */     return (this._beanProperties.find(propertyName) != null);
/*      */   }
/*      */   
/*      */   public boolean hasViews() {
/* 1190 */     return this._needViewProcesing;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPropertyCount() {
/* 1197 */     return this._beanProperties.size();
/*      */   }
/*      */ 
/*      */   
/*      */   public Collection<Object> getKnownPropertyNames() {
/* 1202 */     ArrayList<Object> names = new ArrayList();
/* 1203 */     for (SettableBeanProperty prop : this._beanProperties) {
/* 1204 */       names.add(prop.getName());
/*      */     }
/* 1206 */     return names;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final Class<?> getBeanClass() {
/* 1213 */     return this._beanType.getRawClass();
/*      */   }
/*      */   public JavaType getValueType() {
/* 1216 */     return this._beanType;
/*      */   }
/*      */   
/*      */   public LogicalType logicalType() {
/* 1220 */     return LogicalType.POJO;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterator<SettableBeanProperty> properties() {
/* 1232 */     if (this._beanProperties == null) {
/* 1233 */       throw new IllegalStateException("Can only call after BeanDeserializer has been resolved");
/*      */     }
/* 1235 */     return this._beanProperties.iterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterator<SettableBeanProperty> creatorProperties() {
/* 1247 */     if (this._propertyBasedCreator == null) {
/* 1248 */       return Collections.<SettableBeanProperty>emptyList().iterator();
/*      */     }
/* 1250 */     return this._propertyBasedCreator.properties().iterator();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public SettableBeanProperty findProperty(PropertyName propertyName) {
/* 1256 */     return findProperty(propertyName.getSimpleName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SettableBeanProperty findProperty(String propertyName) {
/* 1269 */     SettableBeanProperty prop = (this._beanProperties == null) ? null : this._beanProperties.find(propertyName);
/* 1270 */     if (prop == null && this._propertyBasedCreator != null) {
/* 1271 */       prop = this._propertyBasedCreator.findCreatorProperty(propertyName);
/*      */     }
/* 1273 */     return prop;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SettableBeanProperty findProperty(int propertyIndex) {
/* 1289 */     SettableBeanProperty prop = (this._beanProperties == null) ? null : this._beanProperties.find(propertyIndex);
/* 1290 */     if (prop == null && this._propertyBasedCreator != null) {
/* 1291 */       prop = this._propertyBasedCreator.findCreatorProperty(propertyIndex);
/*      */     }
/* 1293 */     return prop;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SettableBeanProperty findBackReference(String logicalName) {
/* 1303 */     if (this._backRefs == null) {
/* 1304 */       return null;
/*      */     }
/* 1306 */     return this._backRefs.get(logicalName);
/*      */   }
/*      */ 
/*      */   
/*      */   public ValueInstantiator getValueInstantiator() {
/* 1311 */     return this._valueInstantiator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void replaceProperty(SettableBeanProperty original, SettableBeanProperty replacement) {
/* 1335 */     this._beanProperties.replace(original, replacement);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract Object deserializeFromObject(JsonParser paramJsonParser, DeserializationContext paramDeserializationContext) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 1357 */     if (this._objectIdReader != null) {
/*      */       
/* 1359 */       if (p.canReadObjectId()) {
/* 1360 */         Object id = p.getObjectId();
/* 1361 */         if (id != null) {
/* 1362 */           Object ob = typeDeserializer.deserializeTypedFromObject(p, ctxt);
/* 1363 */           return _handleTypedObjectId(p, ctxt, ob, id);
/*      */         } 
/*      */       } 
/*      */       
/* 1367 */       JsonToken t = p.currentToken();
/* 1368 */       if (t != null) {
/*      */         
/* 1370 */         if (t.isScalarValue()) {
/* 1371 */           return deserializeFromObjectId(p, ctxt);
/*      */         }
/*      */         
/* 1374 */         if (t == JsonToken.START_OBJECT) {
/* 1375 */           t = p.nextToken();
/*      */         }
/* 1377 */         if (t == JsonToken.FIELD_NAME && this._objectIdReader.maySerializeAsObject() && this._objectIdReader
/* 1378 */           .isValidReferencePropertyName(p.currentName(), p)) {
/* 1379 */           return deserializeFromObjectId(p, ctxt);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1384 */     return typeDeserializer.deserializeTypedFromObject(p, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _handleTypedObjectId(JsonParser p, DeserializationContext ctxt, Object pojo, Object rawId) throws IOException {
/*      */     Object id;
/* 1399 */     JsonDeserializer<Object> idDeser = this._objectIdReader.getDeserializer();
/*      */ 
/*      */ 
/*      */     
/* 1403 */     if (idDeser.handledType() == rawId.getClass()) {
/*      */       
/* 1405 */       id = rawId;
/*      */     } else {
/* 1407 */       id = _convertObjectId(p, ctxt, rawId, idDeser);
/*      */     } 
/*      */     
/* 1410 */     ReadableObjectId roid = ctxt.findObjectId(id, this._objectIdReader.generator, this._objectIdReader.resolver);
/* 1411 */     roid.bindItem(pojo);
/*      */     
/* 1413 */     SettableBeanProperty idProp = this._objectIdReader.idProperty;
/* 1414 */     if (idProp != null) {
/* 1415 */       return idProp.setAndReturn(pojo, id);
/*      */     }
/* 1417 */     return pojo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _convertObjectId(JsonParser p, DeserializationContext ctxt, Object rawId, JsonDeserializer<Object> idDeser) throws IOException {
/* 1433 */     TokenBuffer buf = ctxt.bufferForInputBuffering(p);
/* 1434 */     if (rawId instanceof String) {
/* 1435 */       buf.writeString((String)rawId);
/* 1436 */     } else if (rawId instanceof Long) {
/* 1437 */       buf.writeNumber(((Long)rawId).longValue());
/* 1438 */     } else if (rawId instanceof Integer) {
/* 1439 */       buf.writeNumber(((Integer)rawId).intValue());
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1446 */       buf.writeObject(rawId);
/*      */     } 
/* 1448 */     JsonParser bufParser = buf.asParser(p.streamReadConstraints());
/* 1449 */     bufParser.nextToken();
/* 1450 */     return idDeser.deserialize(bufParser, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithObjectId(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1463 */     return deserializeFromObject(p, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeFromObjectId(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1472 */     Object id = this._objectIdReader.readObjectReference(p, ctxt);
/* 1473 */     ReadableObjectId roid = ctxt.findObjectId(id, this._objectIdReader.generator, this._objectIdReader.resolver);
/*      */     
/* 1475 */     Object pojo = roid.resolve();
/* 1476 */     if (pojo == null) {
/* 1477 */       throw new UnresolvedForwardReference(p, "Could not resolve Object Id [" + id + "] (for " + this._beanType + ").", p
/*      */           
/* 1479 */           .currentLocation(), roid);
/*      */     }
/* 1481 */     return pojo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeFromObjectUsingNonDefault(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1489 */     JsonDeserializer<Object> delegateDeser = _delegateDeserializer(p);
/* 1490 */     if (delegateDeser != null) {
/* 1491 */       Object bean = this._valueInstantiator.createUsingDelegate(ctxt, delegateDeser
/* 1492 */           .deserialize(p, ctxt));
/* 1493 */       if (this._injectables != null) {
/* 1494 */         injectValues(ctxt, bean);
/*      */       }
/* 1496 */       return bean;
/*      */     } 
/* 1498 */     if (this._propertyBasedCreator != null) {
/* 1499 */       return _deserializeUsingPropertyBased(p, ctxt);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1504 */     Class<?> raw = this._beanType.getRawClass();
/* 1505 */     if (ClassUtil.isNonStaticInnerClass(raw)) {
/* 1506 */       return ctxt.handleMissingInstantiator(raw, null, p, "non-static inner classes like this can only by instantiated using default, no-argument constructor", new Object[0]);
/*      */     }
/*      */ 
/*      */     
/* 1510 */     if (NativeImageUtil.needsReflectionConfiguration(raw)) {
/* 1511 */       return ctxt.handleMissingInstantiator(raw, null, p, "cannot deserialize from Object value (no delegate- or property-based Creator): this appears to be a native image, in which case you may need to configure reflection for the class that is to be deserialized", new Object[0]);
/*      */     }
/*      */     
/* 1514 */     return ctxt.handleMissingInstantiator(raw, getValueInstantiator(), p, "cannot deserialize from Object value (no delegate- or property-based Creator)", new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract Object _deserializeUsingPropertyBased(JsonParser paramJsonParser, DeserializationContext paramDeserializationContext) throws IOException;
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserializeFromNumber(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1525 */     if (this._objectIdReader != null) {
/* 1526 */       return deserializeFromObjectId(p, ctxt);
/*      */     }
/* 1528 */     JsonDeserializer<Object> delegateDeser = _delegateDeserializer();
/* 1529 */     JsonParser.NumberType nt = p.getNumberType();
/* 1530 */     if (nt == JsonParser.NumberType.INT) {
/* 1531 */       if (delegateDeser != null && 
/* 1532 */         !this._valueInstantiator.canCreateFromInt()) {
/* 1533 */         Object bean = this._valueInstantiator.createUsingDelegate(ctxt, delegateDeser
/* 1534 */             .deserialize(p, ctxt));
/* 1535 */         if (this._injectables != null) {
/* 1536 */           injectValues(ctxt, bean);
/*      */         }
/* 1538 */         return bean;
/*      */       } 
/*      */       
/* 1541 */       return this._valueInstantiator.createFromInt(ctxt, p.getIntValue());
/*      */     } 
/* 1543 */     if (nt == JsonParser.NumberType.LONG) {
/* 1544 */       if (delegateDeser != null && 
/* 1545 */         !this._valueInstantiator.canCreateFromInt()) {
/* 1546 */         Object bean = this._valueInstantiator.createUsingDelegate(ctxt, delegateDeser
/* 1547 */             .deserialize(p, ctxt));
/* 1548 */         if (this._injectables != null) {
/* 1549 */           injectValues(ctxt, bean);
/*      */         }
/* 1551 */         return bean;
/*      */       } 
/*      */       
/* 1554 */       return this._valueInstantiator.createFromLong(ctxt, p.getLongValue());
/*      */     } 
/* 1556 */     if (nt == JsonParser.NumberType.BIG_INTEGER) {
/* 1557 */       if (delegateDeser != null && 
/* 1558 */         !this._valueInstantiator.canCreateFromBigInteger()) {
/* 1559 */         Object bean = this._valueInstantiator.createUsingDelegate(ctxt, delegateDeser.deserialize(p, ctxt));
/* 1560 */         if (this._injectables != null) {
/* 1561 */           injectValues(ctxt, bean);
/*      */         }
/* 1563 */         return bean;
/*      */       } 
/*      */       
/* 1566 */       return this._valueInstantiator.createFromBigInteger(ctxt, p.getBigIntegerValue());
/*      */     } 
/*      */     
/* 1569 */     return ctxt.handleMissingInstantiator(handledType(), getValueInstantiator(), p, "no suitable creator method found to deserialize from Number value (%s)", new Object[] { p
/*      */           
/* 1571 */           .getNumberValue() });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserializeFromString(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1578 */     if (this._objectIdReader != null) {
/* 1579 */       return deserializeFromObjectId(p, ctxt);
/*      */     }
/*      */ 
/*      */     
/* 1583 */     JsonDeserializer<Object> delegateDeser = _delegateDeserializer();
/* 1584 */     if (delegateDeser != null && 
/* 1585 */       !this._valueInstantiator.canCreateFromString()) {
/* 1586 */       Object bean = this._valueInstantiator.createUsingDelegate(ctxt, delegateDeser
/* 1587 */           .deserialize(p, ctxt));
/* 1588 */       if (this._injectables != null) {
/* 1589 */         injectValues(ctxt, bean);
/*      */       }
/* 1591 */       return bean;
/*      */     } 
/*      */     
/* 1594 */     return _deserializeFromString(p, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserializeFromDouble(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1603 */     JsonParser.NumberType t = p.getNumberType();
/*      */     
/* 1605 */     if (t == JsonParser.NumberType.DOUBLE || t == JsonParser.NumberType.FLOAT) {
/* 1606 */       JsonDeserializer<Object> delegateDeser = _delegateDeserializer();
/* 1607 */       if (delegateDeser != null && 
/* 1608 */         !this._valueInstantiator.canCreateFromDouble()) {
/* 1609 */         Object bean = this._valueInstantiator.createUsingDelegate(ctxt, delegateDeser
/* 1610 */             .deserialize(p, ctxt));
/* 1611 */         if (this._injectables != null) {
/* 1612 */           injectValues(ctxt, bean);
/*      */         }
/* 1614 */         return bean;
/*      */       } 
/*      */       
/* 1617 */       return this._valueInstantiator.createFromDouble(ctxt, p.getDoubleValue());
/*      */     } 
/*      */     
/* 1620 */     if (t == JsonParser.NumberType.BIG_DECIMAL) {
/* 1621 */       JsonDeserializer<Object> delegateDeser = _delegateDeserializer();
/* 1622 */       if (delegateDeser != null && 
/* 1623 */         !this._valueInstantiator.canCreateFromBigDecimal()) {
/* 1624 */         Object bean = this._valueInstantiator.createUsingDelegate(ctxt, delegateDeser.deserialize(p, ctxt));
/* 1625 */         if (this._injectables != null) {
/* 1626 */           injectValues(ctxt, bean);
/*      */         }
/* 1628 */         return bean;
/*      */       } 
/*      */ 
/*      */       
/* 1632 */       return this._valueInstantiator.createFromBigDecimal(ctxt, p.getDecimalValue());
/*      */     } 
/*      */     
/* 1635 */     return ctxt.handleMissingInstantiator(handledType(), getValueInstantiator(), p, "no suitable creator method found to deserialize from Number value (%s)", new Object[] { p
/*      */           
/* 1637 */           .getNumberValue() });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserializeFromBoolean(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1645 */     JsonDeserializer<Object> delegateDeser = _delegateDeserializer();
/* 1646 */     if (delegateDeser != null && 
/* 1647 */       !this._valueInstantiator.canCreateFromBoolean()) {
/* 1648 */       Object bean = this._valueInstantiator.createUsingDelegate(ctxt, delegateDeser
/* 1649 */           .deserialize(p, ctxt));
/* 1650 */       if (this._injectables != null) {
/* 1651 */         injectValues(ctxt, bean);
/*      */       }
/* 1653 */       return bean;
/*      */     } 
/*      */     
/* 1656 */     boolean value = (p.currentToken() == JsonToken.VALUE_TRUE);
/* 1657 */     return this._valueInstantiator.createFromBoolean(ctxt, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Object deserializeFromArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1668 */     return _deserializeFromArray(p, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserializeFromEmbedded(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1676 */     if (this._objectIdReader != null) {
/* 1677 */       return deserializeFromObjectId(p, ctxt);
/*      */     }
/*      */     
/* 1680 */     JsonDeserializer<Object> delegateDeser = _delegateDeserializer();
/* 1681 */     if (delegateDeser != null && 
/* 1682 */       !this._valueInstantiator.canCreateFromString()) {
/* 1683 */       Object bean = this._valueInstantiator.createUsingDelegate(ctxt, delegateDeser
/* 1684 */           .deserialize(p, ctxt));
/* 1685 */       if (this._injectables != null) {
/* 1686 */         injectValues(ctxt, bean);
/*      */       }
/* 1688 */       return bean;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1696 */     Object value = p.getEmbeddedObject();
/* 1697 */     if (value != null && 
/* 1698 */       !this._beanType.isTypeOrSuperTypeOf(value.getClass()))
/*      */     {
/* 1700 */       value = ctxt.handleWeirdNativeValue(this._beanType, value, p);
/*      */     }
/*      */     
/* 1703 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonDeserializer<Object> _delegateDeserializer() {
/* 1710 */     JsonDeserializer<Object> deser = this._delegateDeserializer;
/* 1711 */     if (deser == null) {
/* 1712 */       deser = this._arrayDelegateDeserializer;
/*      */     }
/* 1714 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonDeserializer<Object> _delegateDeserializer(JsonParser p) {
/* 1725 */     if (this._delegateDeserializer == null)
/*      */     {
/*      */ 
/*      */       
/* 1729 */       if (this._arrayDelegateDeserializer != null)
/*      */       {
/*      */         
/* 1732 */         if (p.hasToken(JsonToken.START_ARRAY) || this._propertyBasedCreator == null)
/*      */         {
/* 1734 */           return this._arrayDelegateDeserializer;
/*      */         }
/*      */       }
/*      */     }
/* 1738 */     return this._delegateDeserializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void injectValues(DeserializationContext ctxt, Object bean) throws IOException {
/* 1750 */     for (ValueInjector injector : this._injectables) {
/* 1751 */       injector.inject(ctxt, bean);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object handleUnknownProperties(DeserializationContext ctxt, Object bean, TokenBuffer unknownTokens) throws IOException {
/* 1765 */     unknownTokens.writeEndObject();
/*      */ 
/*      */     
/* 1768 */     JsonParser bufferParser = unknownTokens.asParser();
/* 1769 */     while (bufferParser.nextToken() != JsonToken.END_OBJECT) {
/* 1770 */       String propName = bufferParser.currentName();
/*      */       
/* 1772 */       bufferParser.nextToken();
/* 1773 */       handleUnknownProperty(bufferParser, ctxt, bean, propName);
/*      */     } 
/* 1775 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleUnknownVanilla(JsonParser p, DeserializationContext ctxt, Object beanOrBuilder, String propName) throws IOException {
/* 1790 */     if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/* 1791 */       handleIgnoredProperty(p, ctxt, beanOrBuilder, propName);
/* 1792 */     } else if (this._anySetter != null) {
/*      */       
/*      */       try {
/* 1795 */         this._anySetter.deserializeAndSet(p, ctxt, beanOrBuilder, propName);
/* 1796 */       } catch (Exception e) {
/* 1797 */         wrapAndThrow(e, beanOrBuilder, propName, ctxt);
/*      */       } 
/*      */     } else {
/*      */       
/* 1801 */       handleUnknownProperty(p, ctxt, beanOrBuilder, propName);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleUnknownProperty(JsonParser p, DeserializationContext ctxt, Object beanOrClass, String propName) throws IOException {
/* 1814 */     if (this._ignoreAllUnknown) {
/* 1815 */       p.skipChildren();
/*      */       return;
/*      */     } 
/* 1818 */     if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/* 1819 */       handleIgnoredProperty(p, ctxt, beanOrClass, propName);
/*      */     }
/*      */ 
/*      */     
/* 1823 */     super.handleUnknownProperty(p, ctxt, beanOrClass, propName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleIgnoredProperty(JsonParser p, DeserializationContext ctxt, Object beanOrClass, String propName) throws IOException {
/* 1836 */     if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES)) {
/* 1837 */       throw IgnoredPropertyException.from(p, beanOrClass, propName, getKnownPropertyNames());
/*      */     }
/* 1839 */     p.skipChildren();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected Object handlePolymorphic(JsonParser p, DeserializationContext ctxt, Object bean, TokenBuffer unknownTokens) throws IOException {
/* 1860 */     StreamReadConstraints streamReadConstraints = (p == null) ? StreamReadConstraints.defaults() : p.streamReadConstraints();
/* 1861 */     return handlePolymorphic(p, ctxt, streamReadConstraints, bean, unknownTokens);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object handlePolymorphic(JsonParser p, DeserializationContext ctxt, StreamReadConstraints streamReadConstraints, Object bean, TokenBuffer unknownTokens) throws IOException {
/* 1881 */     JsonDeserializer<Object> subDeser = _findSubclassDeserializer(ctxt, bean, unknownTokens);
/* 1882 */     if (subDeser != null) {
/* 1883 */       if (unknownTokens != null) {
/*      */         
/* 1885 */         unknownTokens.writeEndObject();
/* 1886 */         JsonParser p2 = unknownTokens.asParser(streamReadConstraints);
/* 1887 */         p2.nextToken();
/* 1888 */         bean = subDeser.deserialize(p2, ctxt, bean);
/*      */       } 
/*      */       
/* 1891 */       if (p != null) {
/* 1892 */         bean = subDeser.deserialize(p, ctxt, bean);
/*      */       }
/* 1894 */       return bean;
/*      */     } 
/*      */     
/* 1897 */     if (unknownTokens != null) {
/* 1898 */       bean = handleUnknownProperties(ctxt, bean, unknownTokens);
/*      */     }
/*      */     
/* 1901 */     if (p != null) {
/* 1902 */       bean = deserialize(p, ctxt, bean);
/*      */     }
/* 1904 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> _findSubclassDeserializer(DeserializationContext ctxt, Object bean, TokenBuffer unknownTokens) throws IOException {
/* 1916 */     ClassKey classKey = new ClassKey(bean.getClass());
/* 1917 */     JsonDeserializer<Object> subDeser = (this._subDeserializers == null) ? null : this._subDeserializers.get(classKey);
/* 1918 */     if (subDeser != null) {
/* 1919 */       return subDeser;
/*      */     }
/*      */     
/* 1922 */     JavaType type = ctxt.constructType(bean.getClass());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1929 */     subDeser = ctxt.findRootValueDeserializer(type);
/*      */     
/* 1931 */     if (subDeser != null) {
/* 1932 */       if (this._subDeserializers == null) {
/* 1933 */         synchronized (this) {
/* 1934 */           if (this._subDeserializers == null) {
/* 1935 */             this._subDeserializers = new ConcurrentHashMap<>();
/*      */           }
/*      */         } 
/*      */       }
/* 1939 */       this._subDeserializers.put(classKey, subDeser);
/*      */     } 
/* 1941 */     return subDeser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T wrapAndThrow(Throwable t, Object bean, String fieldName, DeserializationContext ctxt) throws IOException {
/* 1966 */     throw JsonMappingException.wrapWithPath(throwOrReturnThrowable(t, ctxt), bean, fieldName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Throwable throwOrReturnThrowable(Throwable t, DeserializationContext ctxt) throws IOException {
/* 1975 */     while (t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null) {
/* 1976 */       t = t.getCause();
/*      */     }
/*      */     
/* 1979 */     ClassUtil.throwIfError(t);
/* 1980 */     boolean wrap = (ctxt == null || ctxt.isEnabled(DeserializationFeature.WRAP_EXCEPTIONS));
/*      */     
/* 1982 */     if (t instanceof IOException) {
/* 1983 */       if (!wrap || !(t instanceof com.fasterxml.jackson.core.JacksonException)) {
/* 1984 */         throw (IOException)t;
/*      */       }
/* 1986 */     } else if (!wrap) {
/* 1987 */       ClassUtil.throwIfRTE(t);
/*      */     } 
/* 1989 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T> T wrapInstantiationProblem(Throwable t, DeserializationContext ctxt) throws IOException {
/* 1996 */     while (t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null) {
/* 1997 */       t = t.getCause();
/*      */     }
/*      */     
/* 2000 */     ClassUtil.throwIfError(t);
/* 2001 */     if (t instanceof IOException)
/*      */     {
/* 2003 */       throw (IOException)t;
/*      */     }
/* 2005 */     if (ctxt == null) {
/* 2006 */       throw new IllegalArgumentException(t.getMessage(), t);
/*      */     }
/* 2008 */     if (!ctxt.isEnabled(DeserializationFeature.WRAP_EXCEPTIONS)) {
/* 2009 */       ClassUtil.throwIfRTE(t);
/*      */     }
/* 2011 */     return (T)ctxt.handleInstantiationProblem(this._beanType.getRawClass(), null, t);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\BeanDeserializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */