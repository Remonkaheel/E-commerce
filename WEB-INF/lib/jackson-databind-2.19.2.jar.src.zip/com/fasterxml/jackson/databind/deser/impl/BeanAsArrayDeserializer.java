/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.BeanDeserializerBase;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import java.io.IOException;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanAsArrayDeserializer
/*     */   extends BeanDeserializerBase
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final BeanDeserializerBase _delegate;
/*     */   protected final SettableBeanProperty[] _orderedProperties;
/*     */   
/*     */   public BeanAsArrayDeserializer(BeanDeserializerBase delegate, SettableBeanProperty[] ordered) {
/*  48 */     super(delegate);
/*  49 */     this._delegate = delegate;
/*  50 */     this._orderedProperties = ordered;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<Object> unwrappingDeserializer(NameTransformer unwrapper) {
/*  60 */     return this._delegate.unwrappingDeserializer(unwrapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanDeserializerBase withObjectIdReader(ObjectIdReader oir) {
/*  65 */     return new BeanAsArrayDeserializer(this._delegate.withObjectIdReader(oir), this._orderedProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDeserializerBase withByNameInclusion(Set<String> ignorableProps, Set<String> includableProps) {
/*  72 */     return new BeanAsArrayDeserializer(this._delegate.withByNameInclusion(ignorableProps, includableProps), this._orderedProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDeserializerBase withIgnoreAllUnknown(boolean ignoreUnknown) {
/*  78 */     return new BeanAsArrayDeserializer(this._delegate.withIgnoreAllUnknown(ignoreUnknown), this._orderedProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDeserializerBase withBeanProperties(BeanPropertyMap props) {
/*  84 */     return new BeanAsArrayDeserializer(this._delegate.withBeanProperties(props), this._orderedProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanDeserializerBase asArrayDeserializer() {
/*  90 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 104 */     if (!p.isExpectedStartArrayToken()) {
/* 105 */       return _deserializeFromNonArray(p, ctxt);
/*     */     }
/* 107 */     if (!this._vanillaProcessing) {
/* 108 */       return _deserializeNonVanilla(p, ctxt);
/*     */     }
/* 110 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/*     */     
/* 112 */     p.assignCurrentValue(bean);
/*     */     
/* 114 */     SettableBeanProperty[] props = this._orderedProperties;
/* 115 */     int i = 0;
/* 116 */     int propCount = props.length;
/*     */     while (true) {
/* 118 */       if (p.nextToken() == JsonToken.END_ARRAY) {
/* 119 */         return bean;
/*     */       }
/* 121 */       if (i == propCount) {
/*     */         break;
/*     */       }
/* 124 */       SettableBeanProperty prop = props[i];
/* 125 */       if (prop != null) {
/*     */         try {
/* 127 */           prop.deserializeAndSet(p, ctxt, bean);
/* 128 */         } catch (Exception e) {
/* 129 */           wrapAndThrow(e, bean, prop.getName(), ctxt);
/*     */         } 
/*     */       } else {
/* 132 */         p.skipChildren();
/*     */       } 
/* 134 */       i++;
/*     */     } 
/*     */     
/* 137 */     if (!this._ignoreAllUnknown && ctxt.isEnabled(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)) {
/* 138 */       ctxt.reportWrongTokenException((JsonDeserializer)this, JsonToken.END_ARRAY, "Unexpected JSON values; expected at most %d properties (in JSON Array)", new Object[] {
/*     */             
/* 140 */             Integer.valueOf(propCount)
/*     */           });
/*     */     }
/*     */     
/*     */     while (true) {
/* 145 */       p.skipChildren();
/* 146 */       if (p.nextToken() == JsonToken.END_ARRAY) {
/* 147 */         return bean;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt, Object bean) throws IOException {
/* 155 */     p.assignCurrentValue(bean);
/*     */     
/* 157 */     if (!p.isExpectedStartArrayToken()) {
/* 158 */       return _deserializeFromNonArray(p, ctxt);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 163 */     if (this._injectables != null) {
/* 164 */       injectValues(ctxt, bean);
/*     */     }
/* 166 */     SettableBeanProperty[] props = this._orderedProperties;
/* 167 */     int i = 0;
/* 168 */     int propCount = props.length;
/*     */     while (true) {
/* 170 */       if (p.nextToken() == JsonToken.END_ARRAY) {
/* 171 */         return bean;
/*     */       }
/* 173 */       if (i == propCount) {
/*     */         break;
/*     */       }
/* 176 */       SettableBeanProperty prop = props[i];
/* 177 */       if (prop != null) {
/*     */         try {
/* 179 */           prop.deserializeAndSet(p, ctxt, bean);
/* 180 */         } catch (Exception e) {
/* 181 */           wrapAndThrow(e, bean, prop.getName(), ctxt);
/*     */         } 
/*     */       } else {
/* 184 */         p.skipChildren();
/*     */       } 
/* 186 */       i++;
/*     */     } 
/*     */ 
/*     */     
/* 190 */     if (!this._ignoreAllUnknown && ctxt.isEnabled(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)) {
/* 191 */       ctxt.reportWrongTokenException((JsonDeserializer)this, JsonToken.END_ARRAY, "Unexpected JSON values; expected at most %d properties (in JSON Array)", new Object[] {
/*     */             
/* 193 */             Integer.valueOf(propCount)
/*     */           });
/*     */     }
/*     */     
/*     */     while (true) {
/* 198 */       p.skipChildren();
/* 199 */       if (p.nextToken() == JsonToken.END_ARRAY) {
/* 200 */         return bean;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeFromObject(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 208 */     return _deserializeFromNonArray(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserializeNonVanilla(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 224 */     if (this._nonStandardCreation) {
/* 225 */       return deserializeFromObjectUsingNonDefault(p, ctxt);
/*     */     }
/* 227 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/*     */     
/* 229 */     p.assignCurrentValue(bean);
/* 230 */     if (this._injectables != null) {
/* 231 */       injectValues(ctxt, bean);
/*     */     }
/* 233 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/* 234 */     SettableBeanProperty[] props = this._orderedProperties;
/* 235 */     int i = 0;
/* 236 */     int propCount = props.length;
/*     */     
/*     */     while (true) {
/* 239 */       if (p.nextToken() == JsonToken.END_ARRAY) {
/* 240 */         return bean;
/*     */       }
/* 242 */       if (i == propCount) {
/*     */         break;
/*     */       }
/* 245 */       SettableBeanProperty prop = props[i];
/* 246 */       i++;
/* 247 */       if (prop != null && (
/* 248 */         activeView == null || prop.visibleInView(activeView))) {
/*     */         try {
/* 250 */           prop.deserializeAndSet(p, ctxt, bean);
/* 251 */         } catch (Exception e) {
/* 252 */           wrapAndThrow(e, bean, prop.getName(), ctxt);
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 258 */       p.skipChildren();
/*     */     } 
/*     */     
/* 261 */     if (!this._ignoreAllUnknown && ctxt.isEnabled(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)) {
/* 262 */       ctxt.reportWrongTokenException((JsonDeserializer)this, JsonToken.END_ARRAY, "Unexpected JSON values; expected at most %d properties (in JSON Array)", new Object[] {
/*     */             
/* 264 */             Integer.valueOf(propCount)
/*     */           });
/*     */     }
/*     */     
/*     */     while (true) {
/* 269 */       p.skipChildren();
/* 270 */       if (p.nextToken() == JsonToken.END_ARRAY) {
/* 271 */         return bean;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Object _deserializeUsingPropertyBased(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 286 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/* 287 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, this._objectIdReader);
/*     */     
/* 289 */     SettableBeanProperty[] props = this._orderedProperties;
/* 290 */     int propCount = props.length;
/* 291 */     int i = 0;
/* 292 */     Object bean = null;
/* 293 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*     */     
/* 295 */     for (; p.nextToken() != JsonToken.END_ARRAY; i++) {
/* 296 */       SettableBeanProperty prop = (i < propCount) ? props[i] : null;
/* 297 */       if (prop == null) {
/* 298 */         p.skipChildren();
/*     */       
/*     */       }
/* 301 */       else if (activeView != null && !prop.visibleInView(activeView)) {
/* 302 */         p.skipChildren();
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 307 */       else if (bean != null) {
/*     */         try {
/* 309 */           prop.deserializeAndSet(p, ctxt, bean);
/* 310 */         } catch (Exception e) {
/* 311 */           wrapAndThrow(e, bean, prop.getName(), ctxt);
/*     */         } 
/*     */       } else {
/*     */         
/* 315 */         String propName = prop.getName();
/*     */         
/* 317 */         SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/*     */         
/* 319 */         if (!buffer.readIdProperty(propName) || creatorProp != null)
/*     */         {
/*     */           
/* 322 */           if (creatorProp != null) {
/*     */             
/* 324 */             if (buffer.assignParameter(creatorProp, creatorProp.deserialize(p, ctxt))) {
/*     */               try {
/* 326 */                 bean = creator.build(ctxt, buffer);
/* 327 */               } catch (Exception e) {
/* 328 */                 wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/*     */               } 
/*     */ 
/*     */               
/* 332 */               p.assignCurrentValue(bean);
/*     */ 
/*     */               
/* 335 */               if (bean.getClass() != this._beanType.getRawClass())
/*     */               {
/*     */ 
/*     */ 
/*     */                 
/* 340 */                 ctxt.reportBadDefinition(this._beanType, String.format("Cannot support implicit polymorphic deserialization for POJOs-as-Arrays style: nominal type %s, actual type %s", new Object[] {
/*     */ 
/*     */                         
/* 343 */                         ClassUtil.getTypeDescription(this._beanType), 
/* 344 */                         ClassUtil.getClassDescription(bean)
/*     */                       }));
/*     */               }
/*     */             } 
/*     */           } else {
/*     */             
/* 350 */             buffer.bufferProperty(prop, prop.deserialize(p, ctxt));
/*     */           }  } 
/*     */       } 
/*     */     } 
/* 354 */     if (bean == null) {
/*     */       try {
/* 356 */         bean = creator.build(ctxt, buffer);
/* 357 */       } catch (Exception e) {
/* 358 */         return wrapInstantiationProblem(e, ctxt);
/*     */       } 
/*     */     }
/* 361 */     return bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserializeFromNonArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 373 */     String message = "Cannot deserialize a POJO (of type %s) from non-Array representation (token: %s): type/property designed to be serialized as JSON Array";
/*     */     
/* 375 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p.currentToken(), p, message, new Object[] {
/* 376 */           ClassUtil.getTypeDescription(this._beanType), p.currentToken()
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\impl\BeanAsArrayDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */