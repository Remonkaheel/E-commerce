/*      */ package com.fasterxml.jackson.databind.deser;
/*      */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*      */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.BeanDescription;
/*      */ import com.fasterxml.jackson.databind.BeanProperty;
/*      */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.JsonNode;
/*      */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*      */ import com.fasterxml.jackson.databind.MapperFeature;
/*      */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*      */ import com.fasterxml.jackson.databind.PropertyName;
/*      */ import com.fasterxml.jackson.databind.PropertyNamingStrategy;
/*      */ import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
/*      */ import com.fasterxml.jackson.databind.cfg.DeserializerFactoryConfig;
/*      */ import com.fasterxml.jackson.databind.deser.impl.FieldProperty;
/*      */ import com.fasterxml.jackson.databind.deser.impl.SetterlessProperty;
/*      */ import com.fasterxml.jackson.databind.deser.std.ThrowableDeserializer;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedField;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedParameter;
/*      */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*      */ import com.fasterxml.jackson.databind.introspect.ObjectIdInfo;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.SimpleBeanPropertyDefinition;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ 
/*      */ public class BeanDeserializerFactory extends BasicDeserializerFactory implements Serializable {
/*   42 */   private static final Class<?>[] INIT_CAUSE_PARAMS = new Class[] { Throwable.class };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   54 */   public static final BeanDeserializerFactory instance = new BeanDeserializerFactory(new DeserializerFactoryConfig());
/*      */ 
/*      */   
/*      */   public BeanDeserializerFactory(DeserializerFactoryConfig config) {
/*   58 */     super(config);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializerFactory withConfig(DeserializerFactoryConfig config) {
/*   69 */     if (this._factoryConfig == config) {
/*   70 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   78 */     ClassUtil.verifyMustOverride(BeanDeserializerFactory.class, this, "withConfig");
/*   79 */     return new BeanDeserializerFactory(config);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<Object> createBeanDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*   99 */     DeserializationConfig config = ctxt.getConfig();
/*      */     
/*  101 */     JsonDeserializer<?> deser = _findCustomBeanDeserializer(type, config, beanDesc);
/*  102 */     if (deser != null) {
/*      */       
/*  104 */       if (this._factoryConfig.hasDeserializerModifiers()) {
/*  105 */         for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  106 */           deser = mod.modifyDeserializer(ctxt.getConfig(), beanDesc, deser);
/*      */         }
/*      */       }
/*  109 */       return (JsonDeserializer)deser;
/*      */     } 
/*      */ 
/*      */     
/*  113 */     if (type.isThrowable()) {
/*  114 */       return buildThrowableDeserializer(ctxt, type, beanDesc);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  121 */     if (type.isAbstract() && !type.isPrimitive() && !type.isEnumType()) {
/*      */       
/*  123 */       JavaType concreteType = materializeAbstractType(ctxt, type, beanDesc);
/*  124 */       if (concreteType != null) {
/*      */ 
/*      */         
/*  127 */         beanDesc = config.introspect(concreteType);
/*  128 */         return buildBeanDeserializer(ctxt, concreteType, beanDesc);
/*      */       } 
/*      */     } 
/*      */     
/*  132 */     deser = findStdDeserializer(ctxt, type, beanDesc);
/*  133 */     if (deser != null) {
/*  134 */       return (JsonDeserializer)deser;
/*      */     }
/*      */ 
/*      */     
/*  138 */     if (!isPotentialBeanType(type.getRawClass())) {
/*  139 */       return null;
/*      */     }
/*      */     
/*  142 */     _validateSubType(ctxt, type, beanDesc);
/*      */ 
/*      */ 
/*      */     
/*  146 */     deser = _findUnsupportedTypeDeserializer(ctxt, type, beanDesc);
/*  147 */     if (deser != null) {
/*  148 */       return (JsonDeserializer)deser;
/*      */     }
/*      */ 
/*      */     
/*  152 */     return buildBeanDeserializer(ctxt, type, beanDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<Object> createBuilderBasedDeserializer(DeserializationContext ctxt, JavaType valueType, BeanDescription valueBeanDesc, Class<?> builderClass) throws JsonMappingException {
/*      */     JavaType builderType;
/*  163 */     if (ctxt.isEnabled(MapperFeature.INFER_BUILDER_TYPE_BINDINGS)) {
/*  164 */       builderType = ctxt.getTypeFactory().constructParametricType(builderClass, valueType.getBindings());
/*      */     } else {
/*  166 */       builderType = ctxt.constructType(builderClass);
/*      */     } 
/*  168 */     BeanDescription builderDesc = ctxt.getConfig().introspectForBuilder(builderType, valueBeanDesc);
/*      */ 
/*      */     
/*  171 */     return buildBuilderBasedDeserializer(ctxt, valueType, builderDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<?> findStdDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*  184 */     JsonDeserializer<?> deser = findDefaultDeserializer(ctxt, type, beanDesc);
/*      */     
/*  186 */     if (deser != null && 
/*  187 */       this._factoryConfig.hasDeserializerModifiers()) {
/*  188 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  189 */         deser = mod.modifyDeserializer(ctxt.getConfig(), beanDesc, deser);
/*      */       }
/*      */     }
/*      */     
/*  193 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> _findUnsupportedTypeDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*  211 */     String errorMsg = BeanUtil.checkUnsupportedType((MapperConfig)ctxt.getConfig(), type);
/*  212 */     if (errorMsg != null)
/*      */     {
/*      */       
/*  215 */       if (ctxt.getConfig().findMixInClassFor(type.getRawClass()) == null) {
/*  216 */         return (JsonDeserializer<Object>)new UnsupportedTypeDeserializer(type, errorMsg);
/*      */       }
/*      */     }
/*  219 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType materializeAbstractType(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*  227 */     for (AbstractTypeResolver r : this._factoryConfig.abstractTypeResolvers()) {
/*  228 */       JavaType concrete = r.resolveAbstractType(ctxt.getConfig(), beanDesc);
/*  229 */       if (concrete != null) {
/*  230 */         return concrete;
/*      */       }
/*      */     } 
/*  233 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<Object> buildBeanDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*      */     ValueInstantiator valueInstantiator;
/*      */     JsonDeserializer<?> deserializer;
/*      */     try {
/*  263 */       valueInstantiator = findValueInstantiator(ctxt, beanDesc);
/*  264 */     } catch (NoClassDefFoundError error) {
/*  265 */       return (JsonDeserializer<Object>)new ErrorThrowingDeserializer(error);
/*  266 */     } catch (IllegalArgumentException e0) {
/*      */ 
/*      */ 
/*      */       
/*  270 */       throw InvalidDefinitionException.from(ctxt.getParser(), 
/*  271 */           ClassUtil.exceptionMessage(e0), beanDesc, null)
/*      */         
/*  273 */         .withCause(e0);
/*      */     } 
/*  275 */     BeanDeserializerBuilder builder = constructBeanDeserializerBuilder(ctxt, beanDesc);
/*  276 */     builder.setValueInstantiator(valueInstantiator);
/*      */     
/*  278 */     addBeanProps(ctxt, beanDesc, builder);
/*  279 */     addObjectIdReader(ctxt, beanDesc, builder);
/*      */ 
/*      */     
/*  282 */     addBackReferenceProperties(ctxt, beanDesc, builder);
/*  283 */     addInjectables(ctxt, beanDesc, builder);
/*      */     
/*  285 */     DeserializationConfig config = ctxt.getConfig();
/*  286 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  287 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  288 */         builder = mod.updateBuilder(config, beanDesc, builder);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*  293 */     if (type.isAbstract() && !valueInstantiator.canInstantiate()) {
/*  294 */       deserializer = builder.buildAbstract();
/*      */     } else {
/*  296 */       deserializer = builder.build();
/*      */     } 
/*      */ 
/*      */     
/*  300 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  301 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  302 */         deserializer = mod.modifyDeserializer(config, beanDesc, deserializer);
/*      */       }
/*      */     }
/*  305 */     return (JsonDeserializer)deserializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> buildBuilderBasedDeserializer(DeserializationContext ctxt, JavaType valueType, BeanDescription builderDesc) throws JsonMappingException {
/*      */     ValueInstantiator valueInstantiator;
/*      */     try {
/*  323 */       valueInstantiator = findValueInstantiator(ctxt, builderDesc);
/*  324 */     } catch (NoClassDefFoundError error) {
/*  325 */       return (JsonDeserializer<Object>)new ErrorThrowingDeserializer(error);
/*  326 */     } catch (IllegalArgumentException e) {
/*      */ 
/*      */ 
/*      */       
/*  330 */       throw InvalidDefinitionException.from(ctxt.getParser(), 
/*  331 */           ClassUtil.exceptionMessage(e), builderDesc, null);
/*      */     } 
/*      */     
/*  334 */     DeserializationConfig config = ctxt.getConfig();
/*  335 */     BeanDeserializerBuilder builder = constructBeanDeserializerBuilder(ctxt, builderDesc);
/*  336 */     builder.setValueInstantiator(valueInstantiator);
/*      */     
/*  338 */     addBeanProps(ctxt, builderDesc, builder);
/*  339 */     addObjectIdReader(ctxt, builderDesc, builder);
/*      */ 
/*      */     
/*  342 */     addBackReferenceProperties(ctxt, builderDesc, builder);
/*  343 */     addInjectables(ctxt, builderDesc, builder);
/*      */     
/*  345 */     JsonPOJOBuilder.Value builderConfig = builderDesc.findPOJOBuilderConfig();
/*  346 */     String buildMethodName = (builderConfig == null) ? "build" : builderConfig.buildMethodName;
/*      */ 
/*      */ 
/*      */     
/*  350 */     AnnotatedMethod buildMethod = builderDesc.findMethod(buildMethodName, null);
/*  351 */     if (buildMethod != null && 
/*  352 */       config.canOverrideAccessModifiers()) {
/*  353 */       ClassUtil.checkAndFixAccess(buildMethod.getMember(), config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*      */     }
/*      */     
/*  356 */     builder.setPOJOBuilder(buildMethod, builderConfig);
/*      */     
/*  358 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  359 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  360 */         builder = mod.updateBuilder(config, builderDesc, builder);
/*      */       }
/*      */     }
/*  363 */     JsonDeserializer<?> deserializer = builder.buildBuilderBased(valueType, buildMethodName);
/*      */ 
/*      */ 
/*      */     
/*  367 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  368 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  369 */         deserializer = mod.modifyDeserializer(config, builderDesc, deserializer);
/*      */       }
/*      */     }
/*  372 */     return (JsonDeserializer)deserializer;
/*      */   }
/*      */   
/*      */   protected void addObjectIdReader(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder) throws JsonMappingException {
/*      */     JavaType idType;
/*      */     SettableBeanProperty idProp;
/*      */     ObjectIdGenerator<?> gen;
/*  379 */     ObjectIdInfo objectIdInfo = beanDesc.getObjectIdInfo();
/*  380 */     if (objectIdInfo == null) {
/*      */       return;
/*      */     }
/*  383 */     Class<?> implClass = objectIdInfo.getGeneratorType();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  388 */     ObjectIdResolver resolver = ctxt.objectIdResolverInstance((Annotated)beanDesc.getClassInfo(), objectIdInfo);
/*      */ 
/*      */     
/*  391 */     if (implClass == ObjectIdGenerators.PropertyGenerator.class) {
/*  392 */       PropertyName propName = objectIdInfo.getPropertyName();
/*  393 */       idProp = builder.findProperty(propName);
/*  394 */       if (idProp == null)
/*  395 */         throw new IllegalArgumentException(String.format("Invalid Object Id definition for %s: cannot find property with name %s", new Object[] {
/*      */                 
/*  397 */                 ClassUtil.getTypeDescription(beanDesc.getType()), 
/*  398 */                 ClassUtil.name(propName)
/*      */               })); 
/*  400 */       idType = idProp.getType();
/*  401 */       PropertyBasedObjectIdGenerator propertyBasedObjectIdGenerator = new PropertyBasedObjectIdGenerator(objectIdInfo.getScope());
/*      */     } else {
/*  403 */       JavaType type = ctxt.constructType(implClass);
/*  404 */       idType = ctxt.getTypeFactory().findTypeParameters(type, ObjectIdGenerator.class)[0];
/*  405 */       idProp = null;
/*  406 */       gen = ctxt.objectIdGeneratorInstance((Annotated)beanDesc.getClassInfo(), objectIdInfo);
/*      */     } 
/*      */     
/*  409 */     JsonDeserializer<?> deser = ctxt.findRootValueDeserializer(idType);
/*  410 */     builder.setObjectIdReader(ObjectIdReader.construct(idType, objectIdInfo
/*  411 */           .getPropertyName(), gen, deser, idProp, resolver));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<Object> buildThrowableDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*      */     ThrowableDeserializer throwableDeserializer;
/*      */     JsonDeserializer<?> jsonDeserializer1;
/*  419 */     DeserializationConfig config = ctxt.getConfig();
/*      */     
/*  421 */     BeanDeserializerBuilder builder = constructBeanDeserializerBuilder(ctxt, beanDesc);
/*  422 */     builder.setValueInstantiator(findValueInstantiator(ctxt, beanDesc));
/*      */     
/*  424 */     addBeanProps(ctxt, beanDesc, builder);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  431 */     Iterator<SettableBeanProperty> it = builder.getProperties();
/*  432 */     while (it.hasNext()) {
/*  433 */       SettableBeanProperty prop = it.next();
/*  434 */       if ("setCause".equals(prop.getMember().getName())) {
/*      */         
/*  436 */         it.remove();
/*      */         break;
/*      */       } 
/*      */     } 
/*  440 */     AnnotatedMethod am = beanDesc.findMethod("initCause", INIT_CAUSE_PARAMS);
/*  441 */     if (am != null) {
/*  442 */       SettableBeanProperty causeCreatorProp = builder.findProperty(PropertyName.construct("cause"));
/*      */       
/*  444 */       if (causeCreatorProp instanceof CreatorProperty) {
/*      */         
/*  446 */         ((CreatorProperty)causeCreatorProp).setFallbackSetter((SettableBeanProperty)null);
/*      */       } else {
/*      */         
/*  449 */         String name = "cause";
/*  450 */         PropertyNamingStrategy pts = config.getPropertyNamingStrategy();
/*  451 */         if (pts != null) {
/*  452 */           name = pts.nameForSetterMethod((MapperConfig)config, am, "cause");
/*      */         }
/*  454 */         SimpleBeanPropertyDefinition propDef = SimpleBeanPropertyDefinition.construct((MapperConfig)ctxt.getConfig(), (AnnotatedMember)am, new PropertyName(name));
/*      */         
/*  456 */         SettableBeanProperty prop = constructSettableProperty(ctxt, beanDesc, (BeanPropertyDefinition)propDef, am
/*  457 */             .getParameterType(0));
/*  458 */         if (prop != null)
/*      */         {
/*      */           
/*  461 */           builder.addOrReplaceProperty(prop, true);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  466 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  467 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  468 */         builder = mod.updateBuilder(config, beanDesc, builder);
/*      */       }
/*      */     }
/*  471 */     JsonDeserializer<?> deserializer = builder.build();
/*      */ 
/*      */ 
/*      */     
/*  475 */     if (deserializer instanceof BeanDeserializer) {
/*  476 */       throwableDeserializer = ThrowableDeserializer.construct(ctxt, (BeanDeserializer)deserializer);
/*      */     }
/*      */ 
/*      */     
/*  480 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  481 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  482 */         jsonDeserializer1 = mod.modifyDeserializer(config, beanDesc, (JsonDeserializer<?>)throwableDeserializer);
/*      */       }
/*      */     }
/*  485 */     return (JsonDeserializer)jsonDeserializer1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanDeserializerBuilder constructBeanDeserializerBuilder(DeserializationContext ctxt, BeanDescription beanDesc) {
/*  501 */     return new BeanDeserializerBuilder(beanDesc, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addBeanProps(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder) throws JsonMappingException {
/*      */     Set<String> ignored;
/*  515 */     ValueInstantiator valueInstantiator = builder.getValueInstantiator();
/*      */     
/*  517 */     SettableBeanProperty[] creatorProps = (valueInstantiator != null) ? valueInstantiator.getFromObjectArguments(ctxt.getConfig()) : null;
/*      */     
/*  519 */     boolean hasCreatorProps = (creatorProps != null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  526 */     JsonIgnoreProperties.Value ignorals = ctxt.getConfig().getDefaultPropertyIgnorals(beanDesc.getBeanClass(), beanDesc
/*  527 */         .getClassInfo());
/*      */     
/*  529 */     if (ignorals != null) {
/*  530 */       boolean ignoreAny = ignorals.getIgnoreUnknown();
/*  531 */       builder.setIgnoreUnknownProperties(ignoreAny);
/*      */       
/*  533 */       ignored = ignorals.findIgnoredForDeserialization();
/*  534 */       for (String propName : ignored) {
/*  535 */         builder.addIgnorable(propName);
/*      */       }
/*      */     } else {
/*  538 */       ignored = Collections.emptySet();
/*      */     } 
/*      */     
/*  541 */     JsonIncludeProperties.Value inclusions = ctxt.getConfig().getDefaultPropertyInclusions(beanDesc.getBeanClass(), beanDesc
/*  542 */         .getClassInfo());
/*  543 */     Set<String> included = null;
/*  544 */     if (inclusions != null) {
/*  545 */       included = inclusions.getIncluded();
/*  546 */       if (included != null) {
/*  547 */         for (String propName : included) {
/*  548 */           builder.addIncludable(propName);
/*      */         }
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  554 */     SettableAnyProperty anySetter = _resolveAnySetter(ctxt, beanDesc, creatorProps);
/*  555 */     if (anySetter != null) {
/*  556 */       builder.setAnySetter(anySetter);
/*      */     }
/*      */     else {
/*      */       
/*  560 */       Collection<String> ignored2 = beanDesc.getIgnoredPropertyNames();
/*  561 */       if (ignored2 != null) {
/*  562 */         for (String propName : ignored2)
/*      */         {
/*      */           
/*  565 */           builder.addIgnorable(propName);
/*      */         }
/*      */       }
/*      */     } 
/*      */     
/*  570 */     boolean useGettersAsSetters = (ctxt.isEnabled(MapperFeature.USE_GETTERS_AS_SETTERS) && ctxt.isEnabled(MapperFeature.AUTO_DETECT_GETTERS));
/*      */ 
/*      */     
/*  573 */     List<BeanPropertyDefinition> propDefs = filterBeanProps(ctxt, beanDesc, builder, beanDesc
/*  574 */         .findProperties(), ignored, included);
/*      */     
/*  576 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  577 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  578 */         propDefs = mod.updateProperties(ctxt.getConfig(), beanDesc, propDefs);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*  583 */     for (BeanPropertyDefinition propDef : propDefs) {
/*  584 */       SettableBeanProperty prop = null;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  589 */       if (propDef.hasSetter()) {
/*  590 */         AnnotatedMethod setter = propDef.getSetter();
/*  591 */         JavaType propertyType = setter.getParameterType(0);
/*  592 */         prop = constructSettableProperty(ctxt, beanDesc, propDef, propertyType);
/*  593 */       } else if (propDef.hasField()) {
/*  594 */         AnnotatedField field = propDef.getField();
/*  595 */         JavaType propertyType = field.getType();
/*  596 */         prop = constructSettableProperty(ctxt, beanDesc, propDef, propertyType);
/*      */       } else {
/*      */         
/*  599 */         AnnotatedMethod getter = propDef.getGetter();
/*  600 */         if (getter != null) {
/*  601 */           if (useGettersAsSetters && _isSetterlessType(getter.getRawType())) {
/*      */ 
/*      */             
/*  604 */             if (!builder.hasIgnorable(propDef.getName()))
/*      */             {
/*      */               
/*  607 */               prop = constructSetterlessProperty(ctxt, beanDesc, propDef);
/*      */             }
/*  609 */           } else if (!propDef.hasConstructorParameter()) {
/*  610 */             PropertyMetadata md = propDef.getMetadata();
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  615 */             if (md.getMergeInfo() != null) {
/*  616 */               prop = constructSetterlessProperty(ctxt, beanDesc, propDef);
/*      */             }
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  624 */       if (hasCreatorProps && propDef.hasConstructorParameter()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  630 */         String name = propDef.getName();
/*  631 */         CreatorProperty cprop = null;
/*      */         
/*  633 */         for (SettableBeanProperty cp : creatorProps) {
/*  634 */           if (name.equals(cp.getName()) && cp instanceof CreatorProperty) {
/*  635 */             cprop = (CreatorProperty)cp;
/*      */             break;
/*      */           } 
/*      */         } 
/*  639 */         if (cprop == null) {
/*  640 */           List<String> n = new ArrayList<>();
/*  641 */           for (SettableBeanProperty cp : creatorProps) {
/*  642 */             n.add(cp.getName());
/*      */           }
/*  644 */           ctxt.reportBadPropertyDefinition(beanDesc, propDef, "Could not find creator property with name %s (known Creator properties: %s)", new Object[] {
/*      */                 
/*  646 */                 ClassUtil.name(name), n });
/*      */           continue;
/*      */         } 
/*  649 */         if (prop != null) {
/*  650 */           cprop.setFallbackSetter(prop);
/*      */         }
/*  652 */         Class<?>[] views = propDef.findViews();
/*  653 */         if (views == null) {
/*  654 */           views = beanDesc.findDefaultViews();
/*      */         }
/*  656 */         cprop.setViews(views);
/*  657 */         builder.addCreatorProperty(cprop);
/*      */         continue;
/*      */       } 
/*  660 */       if (prop != null) {
/*      */         
/*  662 */         Class<?>[] views = propDef.findViews();
/*  663 */         if (views == null) {
/*  664 */           views = beanDesc.findDefaultViews();
/*      */         }
/*  666 */         prop.setViews(views);
/*  667 */         builder.addProperty(prop);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SettableAnyProperty _resolveAnySetter(DeserializationContext ctxt, BeanDescription beanDesc, SettableBeanProperty[] creatorProps) throws JsonMappingException {
/*  678 */     if (creatorProps != null) {
/*  679 */       for (SettableBeanProperty prop : creatorProps) {
/*  680 */         AnnotatedMember member = prop.getMember();
/*  681 */         if (member != null && Boolean.TRUE.equals(ctxt.getAnnotationIntrospector().hasAnySetter((Annotated)member))) {
/*  682 */           return constructAnySetter(ctxt, beanDesc, member);
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*  687 */     AnnotatedMember anySetter = beanDesc.findAnySetterAccessor();
/*  688 */     if (anySetter != null) {
/*  689 */       return constructAnySetter(ctxt, beanDesc, anySetter);
/*      */     }
/*      */     
/*  692 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _isSetterlessType(Class<?> rawType) {
/*  699 */     return (Collection.class.isAssignableFrom(rawType) || Map.class
/*  700 */       .isAssignableFrom(rawType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected List<BeanPropertyDefinition> filterBeanProps(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder, List<BeanPropertyDefinition> propDefsIn, Set<String> ignored) throws JsonMappingException {
/*  718 */     return filterBeanProps(ctxt, beanDesc, builder, propDefsIn, ignored, (Set<String>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<BeanPropertyDefinition> filterBeanProps(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder, List<BeanPropertyDefinition> propDefsIn, Set<String> ignored, Set<String> included) {
/*  736 */     ArrayList<BeanPropertyDefinition> result = new ArrayList<>(Math.max(4, propDefsIn.size()));
/*  737 */     HashMap<Class<?>, Boolean> ignoredTypes = new HashMap<>();
/*      */     
/*  739 */     for (BeanPropertyDefinition property : propDefsIn) {
/*  740 */       String name = property.getName();
/*      */       
/*  742 */       if (IgnorePropertiesUtil.shouldIgnore(name, ignored, included)) {
/*      */         continue;
/*      */       }
/*  745 */       if (!property.hasConstructorParameter()) {
/*  746 */         Class<?> rawPropertyType = property.getRawPrimaryType();
/*      */         
/*  748 */         if (rawPropertyType != null && 
/*  749 */           isIgnorableType(ctxt.getConfig(), property, rawPropertyType, ignoredTypes)) {
/*      */           
/*  751 */           builder.addIgnorable(name);
/*      */           continue;
/*      */         } 
/*      */       } 
/*  755 */       result.add(property);
/*      */     } 
/*  757 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addBackReferenceProperties(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder) throws JsonMappingException {
/*  771 */     List<BeanPropertyDefinition> refProps = beanDesc.findBackReferences();
/*  772 */     if (refProps != null) {
/*  773 */       for (BeanPropertyDefinition refProp : refProps) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  790 */         String refName = refProp.findReferenceName();
/*  791 */         builder.addBackReferenceProperty(refName, constructSettableProperty(ctxt, beanDesc, refProp, refProp
/*  792 */               .getPrimaryType()));
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void addReferenceProperties(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder) throws JsonMappingException {
/*  802 */     addBackReferenceProperties(ctxt, beanDesc, builder);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addInjectables(DeserializationContext ctxt, BeanDescription beanDesc, BeanDeserializerBuilder builder) throws JsonMappingException {
/*  813 */     Map<Object, AnnotatedMember> raw = beanDesc.findInjectables();
/*  814 */     if (raw != null) {
/*  815 */       for (Map.Entry<Object, AnnotatedMember> entry : raw.entrySet()) {
/*  816 */         AnnotatedMember m = entry.getValue();
/*  817 */         builder.addInjectable(PropertyName.construct(m.getName()), m
/*  818 */             .getType(), beanDesc
/*  819 */             .getClassAnnotations(), m, entry.getKey());
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SettableAnyProperty constructAnySetter(DeserializationContext ctxt, BeanDescription beanDesc, AnnotatedMember mutator) throws JsonMappingException {
/*      */     BeanProperty.Std std;
/*      */     JavaType keyType, valueType;
/*  842 */     boolean isField = mutator instanceof AnnotatedField;
/*      */     
/*  844 */     boolean isParameter = mutator instanceof AnnotatedParameter;
/*  845 */     int parameterIndex = -1;
/*      */     
/*  847 */     if (mutator instanceof AnnotatedMethod) {
/*      */       
/*  849 */       AnnotatedMethod am = (AnnotatedMethod)mutator;
/*  850 */       keyType = am.getParameterType(0);
/*  851 */       valueType = am.getParameterType(1);
/*      */       
/*  853 */       valueType = resolveMemberAndTypeAnnotations(ctxt, mutator, valueType);
/*  854 */       std = new BeanProperty.Std(PropertyName.construct(mutator.getName()), valueType, null, mutator, PropertyMetadata.STD_OPTIONAL);
/*      */ 
/*      */     
/*      */     }
/*  858 */     else if (isField) {
/*  859 */       AnnotatedField af = (AnnotatedField)mutator;
/*      */       
/*  861 */       JavaType fieldType = af.getType();
/*      */       
/*  863 */       if (fieldType.isMapLikeType()) {
/*  864 */         fieldType = resolveMemberAndTypeAnnotations(ctxt, mutator, fieldType);
/*  865 */         keyType = fieldType.getKeyType();
/*  866 */         valueType = fieldType.getContentType();
/*  867 */         std = new BeanProperty.Std(PropertyName.construct(mutator.getName()), fieldType, null, mutator, PropertyMetadata.STD_OPTIONAL);
/*      */       } else {
/*  869 */         if (fieldType.hasRawClass(JsonNode.class) || fieldType
/*  870 */           .hasRawClass(ObjectNode.class)) {
/*  871 */           fieldType = resolveMemberAndTypeAnnotations(ctxt, mutator, fieldType);
/*      */           
/*  873 */           valueType = ctxt.constructType(JsonNode.class);
/*  874 */           std = new BeanProperty.Std(PropertyName.construct(mutator.getName()), fieldType, null, mutator, PropertyMetadata.STD_OPTIONAL);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  879 */           return SettableAnyProperty.constructForJsonNodeField(ctxt, (BeanProperty)std, mutator, valueType, ctxt
/*      */               
/*  881 */               .findRootValueDeserializer(valueType));
/*      */         } 
/*  883 */         return (SettableAnyProperty)ctxt.reportBadDefinition(beanDesc.getType(), String.format("Unsupported type for any-setter: %s -- only support `Map`s, `JsonNode` and `ObjectNode` ", new Object[] {
/*      */                 
/*  885 */                 ClassUtil.getTypeDescription(fieldType) }));
/*      */       } 
/*  887 */     } else if (isParameter) {
/*  888 */       AnnotatedParameter af = (AnnotatedParameter)mutator;
/*  889 */       JavaType paramType = af.getType();
/*  890 */       parameterIndex = af.getIndex();
/*      */       
/*  892 */       if (paramType.isMapLikeType()) {
/*  893 */         paramType = resolveMemberAndTypeAnnotations(ctxt, mutator, paramType);
/*  894 */         keyType = paramType.getKeyType();
/*  895 */         valueType = paramType.getContentType();
/*  896 */         std = new BeanProperty.Std(PropertyName.construct(mutator.getName()), paramType, null, mutator, PropertyMetadata.STD_OPTIONAL);
/*      */       } else {
/*  898 */         if (paramType.hasRawClass(JsonNode.class) || paramType.hasRawClass(ObjectNode.class)) {
/*  899 */           paramType = resolveMemberAndTypeAnnotations(ctxt, mutator, paramType);
/*      */           
/*  901 */           valueType = ctxt.constructType(JsonNode.class);
/*  902 */           std = new BeanProperty.Std(PropertyName.construct(mutator.getName()), paramType, null, mutator, PropertyMetadata.STD_OPTIONAL);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  907 */           return SettableAnyProperty.constructForJsonNodeParameter(ctxt, (BeanProperty)std, mutator, valueType, ctxt
/*  908 */               .findRootValueDeserializer(valueType), parameterIndex);
/*      */         } 
/*  910 */         return (SettableAnyProperty)ctxt.reportBadDefinition(beanDesc.getType(), String.format("Unsupported type for any-setter: %s -- only support `Map`s, `JsonNode` and `ObjectNode` ", new Object[] {
/*      */                 
/*  912 */                 ClassUtil.getTypeDescription(paramType) }));
/*      */       } 
/*      */     } else {
/*  915 */       return (SettableAnyProperty)ctxt.reportBadDefinition(beanDesc.getType(), String.format("Unrecognized mutator type for any-setter: %s", new Object[] {
/*      */               
/*  917 */               ClassUtil.nameOf(mutator.getClass())
/*      */             }));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  926 */     KeyDeserializer keyDeser = findKeyDeserializerFromAnnotation(ctxt, (Annotated)mutator);
/*  927 */     if (keyDeser == null) {
/*  928 */       keyDeser = (KeyDeserializer)keyType.getValueHandler();
/*      */     }
/*  930 */     if (keyDeser == null) {
/*  931 */       keyDeser = ctxt.findKeyDeserializer(keyType, (BeanProperty)std);
/*      */     }
/*  933 */     else if (keyDeser instanceof ContextualKeyDeserializer) {
/*      */       
/*  935 */       keyDeser = ((ContextualKeyDeserializer)keyDeser).createContextual(ctxt, (BeanProperty)std);
/*      */     } 
/*      */     
/*  938 */     JsonDeserializer<Object> deser = findContentDeserializerFromAnnotation(ctxt, (Annotated)mutator);
/*  939 */     if (deser == null) {
/*  940 */       deser = (JsonDeserializer<Object>)valueType.getValueHandler();
/*      */     }
/*  942 */     if (deser != null)
/*      */     {
/*  944 */       deser = ctxt.handlePrimaryContextualization(deser, (BeanProperty)std, valueType);
/*      */     }
/*  946 */     TypeDeserializer typeDeser = (TypeDeserializer)valueType.getTypeHandler();
/*  947 */     if (isField) {
/*  948 */       return SettableAnyProperty.constructForMapField(ctxt, (BeanProperty)std, mutator, valueType, keyDeser, deser, typeDeser);
/*      */     }
/*      */     
/*  951 */     if (isParameter) {
/*  952 */       return SettableAnyProperty.constructForMapParameter(ctxt, (BeanProperty)std, mutator, valueType, keyDeser, deser, typeDeser, parameterIndex);
/*      */     }
/*      */     
/*  955 */     return SettableAnyProperty.constructForMethod(ctxt, (BeanProperty)std, mutator, valueType, keyDeser, deser, typeDeser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SettableBeanProperty constructSettableProperty(DeserializationContext ctxt, BeanDescription beanDesc, BeanPropertyDefinition propDef, JavaType propType0) throws JsonMappingException {
/*      */     FieldProperty fieldProperty;
/*      */     SettableBeanProperty settableBeanProperty;
/*  972 */     AnnotatedMember mutator = propDef.getNonConstructorMutator();
/*      */ 
/*      */ 
/*      */     
/*  976 */     if (mutator == null) {
/*  977 */       ctxt.reportBadPropertyDefinition(beanDesc, propDef, "No non-constructor mutator available", new Object[0]);
/*      */     }
/*  979 */     JavaType type = resolveMemberAndTypeAnnotations(ctxt, mutator, propType0);
/*      */     
/*  981 */     TypeDeserializer typeDeser = (TypeDeserializer)type.getTypeHandler();
/*      */     
/*  983 */     if (mutator instanceof AnnotatedMethod) {
/*      */       
/*  985 */       MethodProperty methodProperty = new MethodProperty(propDef, type, typeDeser, beanDesc.getClassAnnotations(), (AnnotatedMethod)mutator);
/*      */     }
/*      */     else {
/*      */       
/*  989 */       fieldProperty = new FieldProperty(propDef, type, typeDeser, beanDesc.getClassAnnotations(), (AnnotatedField)mutator);
/*      */     } 
/*  991 */     JsonDeserializer<?> deser = findDeserializerFromAnnotation(ctxt, (Annotated)mutator);
/*  992 */     if (deser == null) {
/*  993 */       deser = (JsonDeserializer)type.getValueHandler();
/*      */     }
/*  995 */     if (deser != null) {
/*  996 */       deser = ctxt.handlePrimaryContextualization(deser, (BeanProperty)fieldProperty, type);
/*  997 */       settableBeanProperty = fieldProperty.withValueDeserializer(deser);
/*      */     } 
/*      */     
/* 1000 */     AnnotationIntrospector.ReferenceProperty ref = propDef.findReferenceType();
/* 1001 */     if (ref != null && ref.isManagedReference()) {
/* 1002 */       settableBeanProperty.setManagedReferenceName(ref.getName());
/*      */     }
/* 1004 */     ObjectIdInfo objectIdInfo = propDef.findObjectIdInfo();
/* 1005 */     if (objectIdInfo != null) {
/* 1006 */       settableBeanProperty.setObjectIdInfo(objectIdInfo);
/*      */     }
/* 1008 */     return settableBeanProperty;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SettableBeanProperty constructSetterlessProperty(DeserializationContext ctxt, BeanDescription beanDesc, BeanPropertyDefinition propDef) throws JsonMappingException {
/*      */     SettableBeanProperty settableBeanProperty;
/* 1019 */     AnnotatedMethod getter = propDef.getGetter();
/* 1020 */     JavaType type = resolveMemberAndTypeAnnotations(ctxt, (AnnotatedMember)getter, getter.getType());
/* 1021 */     TypeDeserializer typeDeser = (TypeDeserializer)type.getTypeHandler();
/*      */     
/* 1023 */     SetterlessProperty setterlessProperty = new SetterlessProperty(propDef, type, typeDeser, beanDesc.getClassAnnotations(), getter);
/* 1024 */     JsonDeserializer<?> deser = findDeserializerFromAnnotation(ctxt, (Annotated)getter);
/* 1025 */     if (deser == null) {
/* 1026 */       deser = (JsonDeserializer)type.getValueHandler();
/*      */     }
/* 1028 */     if (deser != null) {
/* 1029 */       deser = ctxt.handlePrimaryContextualization(deser, (BeanProperty)setterlessProperty, type);
/* 1030 */       settableBeanProperty = setterlessProperty.withValueDeserializer(deser);
/*      */     } 
/* 1032 */     return settableBeanProperty;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isPotentialBeanType(Class<?> type) {
/* 1051 */     String typeStr = ClassUtil.canBeABeanType(type);
/* 1052 */     if (typeStr != null) {
/* 1053 */       throw new IllegalArgumentException("Cannot deserialize Class " + type.getName() + " (of type " + typeStr + ") as a Bean");
/*      */     }
/* 1055 */     if (ClassUtil.isProxyType(type)) {
/* 1056 */       throw new IllegalArgumentException("Cannot deserialize Proxy class " + type.getName() + " as a Bean");
/*      */     }
/*      */ 
/*      */     
/* 1060 */     typeStr = ClassUtil.isLocalType(type, true);
/* 1061 */     if (typeStr != null) {
/* 1062 */       throw new IllegalArgumentException("Cannot deserialize Class " + type.getName() + " (of type " + typeStr + ") as a Bean");
/*      */     }
/* 1064 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isIgnorableType(DeserializationConfig config, BeanPropertyDefinition propDef, Class<?> type, Map<Class<?>, Boolean> ignoredTypes) {
/* 1074 */     Boolean status = ignoredTypes.get(type);
/* 1075 */     if (status != null) {
/* 1076 */       return status.booleanValue();
/*      */     }
/*      */     
/* 1079 */     if (type == String.class || type.isPrimitive()) {
/* 1080 */       status = Boolean.FALSE;
/*      */     } else {
/*      */       
/* 1083 */       status = config.getConfigOverride(type).getIsIgnoredType();
/* 1084 */       if (status == null) {
/* 1085 */         BeanDescription desc = config.introspectClassAnnotations(type);
/* 1086 */         status = config.getAnnotationIntrospector().isIgnorableType(desc.getClassInfo());
/*      */         
/* 1088 */         if (status == null) {
/* 1089 */           status = Boolean.FALSE;
/*      */         }
/*      */       } 
/*      */     } 
/* 1093 */     ignoredTypes.put(type, status);
/* 1094 */     return status.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _validateSubType(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/* 1104 */     SubTypeValidator.instance().validateSubType(ctxt, type, beanDesc);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\BeanDeserializerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */