/*    */ package com.fasterxml.jackson.databind.deser.std;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JacksonException;
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import com.fasterxml.jackson.databind.type.LogicalType;
/*    */ import java.io.IOException;
/*    */ import java.util.concurrent.atomic.AtomicLong;
/*    */ 
/*    */ public class AtomicLongDeserializer
/*    */   extends StdScalarDeserializer<AtomicLong> {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public AtomicLongDeserializer() {
/* 16 */     super(AtomicLong.class);
/*    */   }
/*    */   
/*    */   public AtomicLong deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 20 */     if (p.isExpectedNumberIntToken()) {
/* 21 */       return new AtomicLong(p.getLongValue());
/*    */     }
/*    */ 
/*    */     
/* 25 */     Long L = _parseLong(p, ctxt, AtomicLong.class);
/* 26 */     return (L == null) ? null : new AtomicLong(L.intValue());
/*    */   }
/*    */   
/*    */   public LogicalType logicalType() {
/* 30 */     return LogicalType.Integer;
/*    */   }
/*    */   
/*    */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/* 34 */     return new AtomicLong();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\AtomicLongDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */