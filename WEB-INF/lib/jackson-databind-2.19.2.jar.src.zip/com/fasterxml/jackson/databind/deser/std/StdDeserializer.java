/*      */ package com.fasterxml.jackson.databind.deser.std;
/*      */ 
/*      */ import com.fasterxml.jackson.annotation.JsonFormat;
/*      */ import com.fasterxml.jackson.annotation.Nulls;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.StreamReadFeature;
/*      */ import com.fasterxml.jackson.core.exc.StreamReadException;
/*      */ import com.fasterxml.jackson.core.io.NumberInput;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.BeanProperty;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*      */ import com.fasterxml.jackson.databind.MapperFeature;
/*      */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.deser.BeanDeserializerBase;
/*      */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*      */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*      */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*      */ import com.fasterxml.jackson.databind.deser.impl.NullsAsEmptyProvider;
/*      */ import com.fasterxml.jackson.databind.deser.impl.NullsConstantProvider;
/*      */ import com.fasterxml.jackson.databind.deser.impl.NullsFailProvider;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.type.LogicalType;
/*      */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.Converter;
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.util.Date;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class StdDeserializer<T>
/*      */   extends JsonDeserializer<T>
/*      */   implements Serializable, ValueInstantiator.Gettable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*   50 */   protected static final int F_MASK_INT_COERCIONS = DeserializationFeature.USE_BIG_INTEGER_FOR_INTS
/*   51 */     .getMask() | DeserializationFeature.USE_LONG_FOR_INTS
/*   52 */     .getMask();
/*      */   
/*      */   @Deprecated
/*   55 */   protected static final int F_MASK_ACCEPT_ARRAYS = DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS
/*   56 */     .getMask() | DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT
/*   57 */     .getMask();
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Class<?> _valueClass;
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JavaType _valueType;
/*      */ 
/*      */ 
/*      */   
/*      */   protected StdDeserializer(Class<?> vc) {
/*   70 */     this._valueClass = vc;
/*   71 */     this._valueType = null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected StdDeserializer(JavaType valueType) {
/*   76 */     this._valueClass = (valueType == null) ? Object.class : valueType.getRawClass();
/*   77 */     this._valueType = valueType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected StdDeserializer(StdDeserializer<?> src) {
/*   87 */     this._valueClass = src._valueClass;
/*   88 */     this._valueType = src._valueType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?> handledType() {
/*   98 */     return this._valueClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final Class<?> getValueClass() {
/*  110 */     return this._valueClass;
/*      */   }
/*      */ 
/*      */   
/*      */   public JavaType getValueType() {
/*  115 */     return this._valueType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType getValueType(DeserializationContext ctxt) {
/*  131 */     if (this._valueType != null) {
/*  132 */       return this._valueType;
/*      */     }
/*  134 */     return ctxt.constructType(this._valueClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ValueInstantiator getValueInstantiator() {
/*  141 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isDefaultDeserializer(JsonDeserializer<?> deserializer) {
/*  150 */     return ClassUtil.isJacksonStdImpl(deserializer);
/*      */   }
/*      */   
/*      */   protected boolean isDefaultKeyDeserializer(KeyDeserializer keyDeser) {
/*  154 */     return ClassUtil.isJacksonStdImpl(keyDeser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/*  171 */     return typeDeserializer.deserializeTypedFromAny(p, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected T _deserializeFromArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  199 */     CoercionAction act = _findCoercionFromEmptyArray(ctxt);
/*  200 */     boolean unwrap = ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS);
/*      */     
/*  202 */     if (unwrap || act != CoercionAction.Fail) {
/*  203 */       JsonToken t = p.nextToken();
/*  204 */       if (t == JsonToken.END_ARRAY) {
/*  205 */         switch (act) {
/*      */           case AsEmpty:
/*  207 */             return (T)getEmptyValue(ctxt);
/*      */           case AsNull:
/*      */           case TryConvert:
/*  210 */             return (T)getNullValue(ctxt);
/*      */         } 
/*      */       
/*  213 */       } else if (unwrap) {
/*  214 */         T parsed = _deserializeWrappedValue(p, ctxt);
/*  215 */         if (p.nextToken() != JsonToken.END_ARRAY) {
/*  216 */           handleMissingEndArrayForSingle(p, ctxt);
/*      */         }
/*  218 */         return parsed;
/*      */       } 
/*      */     } 
/*  221 */     return (T)ctxt.handleUnexpectedToken(getValueType(ctxt), JsonToken.START_ARRAY, p, null, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected T _deserializeFromEmpty(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  237 */     if (p.hasToken(JsonToken.START_ARRAY) && 
/*  238 */       ctxt.isEnabled(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT)) {
/*  239 */       JsonToken t = p.nextToken();
/*  240 */       if (t == JsonToken.END_ARRAY) {
/*  241 */         return null;
/*      */       }
/*  243 */       return (T)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */     } 
/*      */     
/*  246 */     return (T)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected T _deserializeFromString(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  259 */     ValueInstantiator inst = getValueInstantiator();
/*  260 */     Class<?> rawTargetType = handledType();
/*  261 */     String value = p.getValueAsString();
/*      */     
/*  263 */     if (inst != null && inst.canCreateFromString()) {
/*  264 */       return (T)inst.createFromString(ctxt, value);
/*      */     }
/*  266 */     if (value.isEmpty()) {
/*  267 */       CoercionAction act = ctxt.findCoercionAction(logicalType(), rawTargetType, CoercionInputShape.EmptyString);
/*      */       
/*  269 */       return (T)_deserializeFromEmptyString(p, ctxt, act, rawTargetType, "empty String (\"\")");
/*      */     } 
/*      */     
/*  272 */     if (_isBlank(value)) {
/*  273 */       CoercionAction act = ctxt.findCoercionFromBlankString(logicalType(), rawTargetType, CoercionAction.Fail);
/*      */       
/*  275 */       return (T)_deserializeFromEmptyString(p, ctxt, act, rawTargetType, "blank String (all whitespace)");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  282 */     if (inst != null) {
/*  283 */       value = value.trim();
/*  284 */       if (inst.canCreateFromInt() && 
/*  285 */         ctxt.findCoercionAction(LogicalType.Integer, Integer.class, CoercionInputShape.String) == CoercionAction.TryConvert)
/*      */       {
/*  287 */         return (T)inst.createFromInt(ctxt, _parseIntPrimitive(ctxt, value));
/*      */       }
/*      */       
/*  290 */       if (inst.canCreateFromLong() && 
/*  291 */         ctxt.findCoercionAction(LogicalType.Integer, Long.class, CoercionInputShape.String) == CoercionAction.TryConvert)
/*      */       {
/*  293 */         return (T)inst.createFromLong(ctxt, _parseLongPrimitive(ctxt, value));
/*      */       }
/*      */       
/*  296 */       if (inst.canCreateFromBoolean())
/*      */       {
/*  298 */         if (ctxt.findCoercionAction(LogicalType.Boolean, Boolean.class, CoercionInputShape.String) == CoercionAction.TryConvert) {
/*      */           
/*  300 */           String str = value.trim();
/*  301 */           if ("true".equals(str)) {
/*  302 */             return (T)inst.createFromBoolean(ctxt, true);
/*      */           }
/*  304 */           if ("false".equals(str)) {
/*  305 */             return (T)inst.createFromBoolean(ctxt, false);
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*  310 */     return (T)ctxt.handleMissingInstantiator(rawTargetType, inst, ctxt.getParser(), "no String-argument constructor/factory method to deserialize from String value ('%s')", new Object[] { value });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _deserializeFromEmptyString(JsonParser p, DeserializationContext ctxt, CoercionAction act, Class<?> rawTargetType, String desc) throws IOException {
/*  319 */     switch (act) {
/*      */       case AsEmpty:
/*  321 */         return getEmptyValue(ctxt);
/*      */       
/*      */       case Fail:
/*  324 */         _checkCoercionFail(ctxt, act, rawTargetType, "", "empty String (\"\")");
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  330 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected T _deserializeWrappedValue(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  358 */     if (p.hasToken(JsonToken.START_ARRAY)) {
/*      */       
/*  360 */       T result = (T)handleNestedArrayForSingle(p, ctxt);
/*  361 */       return result;
/*      */     } 
/*      */     
/*  364 */     if (p.hasToken(JsonToken.VALUE_NULL)) {
/*  365 */       return (T)getNullValue(ctxt);
/*      */     }
/*  367 */     return (T)deserialize(p, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final boolean _parseBooleanPrimitive(DeserializationContext ctxt, JsonParser p, Class<?> targetType) throws IOException {
/*  381 */     return _parseBooleanPrimitive(p, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _parseBooleanPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  392 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  394 */         text = p.getText();
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 7:
/*  400 */         return Boolean.TRUE.equals(_coerceBooleanFromInt(p, ctxt, boolean.class));
/*      */       case 9:
/*  402 */         return true;
/*      */       case 10:
/*  404 */         return false;
/*      */       case 11:
/*  406 */         _verifyNullForPrimitive(ctxt);
/*  407 */         return false;
/*      */       
/*      */       case 1:
/*  410 */         text = ctxt.extractScalarFromObject(p, this, boolean.class);
/*      */         break;
/*      */       
/*      */       case 3:
/*  414 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  415 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/*  416 */             return ((Boolean)handleNestedArrayForSingle(p, ctxt)).booleanValue();
/*      */           }
/*  418 */           boolean parsed = _parseBooleanPrimitive(p, ctxt);
/*  419 */           _verifyEndArrayForSingle(p, ctxt);
/*  420 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/*  424 */         return ((Boolean)ctxt.handleUnexpectedToken(boolean.class, p)).booleanValue();
/*      */     } 
/*      */     
/*  427 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Boolean, boolean.class);
/*      */     
/*  429 */     if (act == CoercionAction.AsNull) {
/*  430 */       _verifyNullForPrimitive(ctxt);
/*  431 */       return false;
/*      */     } 
/*  433 */     if (act == CoercionAction.AsEmpty) {
/*  434 */       return false;
/*      */     }
/*  436 */     String text = text.trim();
/*  437 */     int len = text.length();
/*      */ 
/*      */ 
/*      */     
/*  441 */     if (len == 4) {
/*  442 */       if (_isTrue(text)) {
/*  443 */         return true;
/*      */       }
/*  445 */     } else if (len == 5 && 
/*  446 */       _isFalse(text)) {
/*  447 */       return false;
/*      */     } 
/*      */     
/*  450 */     if (_hasTextualNull(text)) {
/*  451 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  452 */       return false;
/*      */     } 
/*  454 */     Boolean b = (Boolean)ctxt.handleWeirdStringValue(boolean.class, text, "only \"true\"/\"True\"/\"TRUE\" or \"false\"/\"False\"/\"FALSE\" recognized", new Object[0]);
/*      */     
/*  456 */     return Boolean.TRUE.equals(b);
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean _isTrue(String text) {
/*  461 */     char c = text.charAt(0);
/*  462 */     if (c == 't') {
/*  463 */       return "true".equals(text);
/*      */     }
/*  465 */     if (c == 'T') {
/*  466 */       return ("TRUE".equals(text) || "True".equals(text));
/*      */     }
/*  468 */     return false;
/*      */   }
/*      */   
/*      */   protected boolean _isFalse(String text) {
/*  472 */     char c = text.charAt(0);
/*  473 */     if (c == 'f') {
/*  474 */       return "false".equals(text);
/*      */     }
/*  476 */     if (c == 'F') {
/*  477 */       return ("FALSE".equals(text) || "False".equals(text));
/*      */     }
/*  479 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Boolean _parseBoolean(JsonParser p, DeserializationContext ctxt, Class<?> targetType) throws IOException {
/*  505 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  507 */         text = p.getText();
/*      */         break;
/*      */       
/*      */       case 7:
/*  511 */         return _coerceBooleanFromInt(p, ctxt, targetType);
/*      */       case 9:
/*  513 */         return Boolean.valueOf(true);
/*      */       case 10:
/*  515 */         return Boolean.valueOf(false);
/*      */       case 11:
/*  517 */         return null;
/*      */       
/*      */       case 1:
/*  520 */         text = ctxt.extractScalarFromObject(p, this, targetType);
/*      */         break;
/*      */       case 3:
/*  523 */         return (Boolean)_deserializeFromArray(p, ctxt);
/*      */       default:
/*  525 */         return (Boolean)ctxt.handleUnexpectedToken(targetType, p);
/*      */     } 
/*      */     
/*  528 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Boolean, targetType);
/*      */     
/*  530 */     if (act == CoercionAction.AsNull) {
/*  531 */       return null;
/*      */     }
/*  533 */     if (act == CoercionAction.AsEmpty) {
/*  534 */       return Boolean.valueOf(false);
/*      */     }
/*  536 */     String text = text.trim();
/*  537 */     int len = text.length();
/*      */ 
/*      */ 
/*      */     
/*  541 */     if (len == 4) {
/*  542 */       if (_isTrue(text)) {
/*  543 */         return Boolean.valueOf(true);
/*      */       }
/*  545 */     } else if (len == 5 && 
/*  546 */       _isFalse(text)) {
/*  547 */       return Boolean.valueOf(false);
/*      */     } 
/*      */     
/*  550 */     if (_checkTextualNull(ctxt, text)) {
/*  551 */       return null;
/*      */     }
/*  553 */     return (Boolean)ctxt.handleWeirdStringValue(targetType, text, "only \"true\" or \"false\" recognized", new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final byte _parseBytePrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     int value;
/*  561 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  563 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  566 */         act = _checkFloatToIntCoercion(p, ctxt, byte.class);
/*  567 */         if (act == CoercionAction.AsNull) {
/*  568 */           return 0;
/*      */         }
/*  570 */         if (act == CoercionAction.AsEmpty) {
/*  571 */           return 0;
/*      */         }
/*  573 */         return p.getByteValue();
/*      */       case 7:
/*  575 */         return p.getByteValue();
/*      */       case 11:
/*  577 */         _verifyNullForPrimitive(ctxt);
/*  578 */         return 0;
/*      */       
/*      */       case 1:
/*  581 */         text = ctxt.extractScalarFromObject(p, this, byte.class);
/*      */         break;
/*      */       
/*      */       case 3:
/*  585 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  586 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/*  587 */             return ((Byte)handleNestedArrayForSingle(p, ctxt)).byteValue();
/*      */           }
/*  589 */           byte parsed = _parseBytePrimitive(p, ctxt);
/*  590 */           _verifyEndArrayForSingle(p, ctxt);
/*  591 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/*  595 */         return ((Byte)ctxt.handleUnexpectedToken(ctxt.constructType(byte.class), p)).byteValue();
/*      */     } 
/*      */ 
/*      */     
/*  599 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, byte.class);
/*      */     
/*  601 */     if (act == CoercionAction.AsNull) {
/*      */       
/*  603 */       _verifyNullForPrimitive(ctxt);
/*  604 */       return 0;
/*      */     } 
/*  606 */     if (act == CoercionAction.AsEmpty) {
/*  607 */       return 0;
/*      */     }
/*  609 */     String text = text.trim();
/*  610 */     if (_hasTextualNull(text)) {
/*  611 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  612 */       return 0;
/*      */     } 
/*  614 */     p.streamReadConstraints().validateIntegerLength(text.length());
/*      */     
/*      */     try {
/*  617 */       value = NumberInput.parseInt(text);
/*  618 */     } catch (IllegalArgumentException iae) {
/*  619 */       return ((Byte)ctxt.handleWeirdStringValue(this._valueClass, text, "not a valid `byte` value", new Object[0])).byteValue();
/*      */     } 
/*      */ 
/*      */     
/*  623 */     if (_byteOverflow(value)) {
/*  624 */       return ((Byte)ctxt.handleWeirdStringValue(this._valueClass, text, "overflow, value cannot be represented as 8-bit value", new Object[0])).byteValue();
/*      */     }
/*      */     
/*  627 */     return (byte)value;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final short _parseShortPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     int value;
/*  634 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  636 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  639 */         act = _checkFloatToIntCoercion(p, ctxt, short.class);
/*  640 */         if (act == CoercionAction.AsNull) {
/*  641 */           return 0;
/*      */         }
/*  643 */         if (act == CoercionAction.AsEmpty) {
/*  644 */           return 0;
/*      */         }
/*  646 */         return p.getShortValue();
/*      */       case 7:
/*  648 */         return p.getShortValue();
/*      */       case 11:
/*  650 */         _verifyNullForPrimitive(ctxt);
/*  651 */         return 0;
/*      */       
/*      */       case 1:
/*  654 */         text = ctxt.extractScalarFromObject(p, this, short.class);
/*      */         break;
/*      */       
/*      */       case 3:
/*  658 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  659 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/*  660 */             return ((Short)handleNestedArrayForSingle(p, ctxt)).shortValue();
/*      */           }
/*  662 */           short parsed = _parseShortPrimitive(p, ctxt);
/*  663 */           _verifyEndArrayForSingle(p, ctxt);
/*  664 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/*  668 */         return ((Short)ctxt.handleUnexpectedToken(ctxt.constructType(short.class), p)).shortValue();
/*      */     } 
/*      */     
/*  671 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, short.class);
/*      */     
/*  673 */     if (act == CoercionAction.AsNull) {
/*      */       
/*  675 */       _verifyNullForPrimitive(ctxt);
/*  676 */       return 0;
/*      */     } 
/*  678 */     if (act == CoercionAction.AsEmpty) {
/*  679 */       return 0;
/*      */     }
/*  681 */     String text = text.trim();
/*  682 */     if (_hasTextualNull(text)) {
/*  683 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  684 */       return 0;
/*      */     } 
/*  686 */     p.streamReadConstraints().validateIntegerLength(text.length());
/*      */     
/*      */     try {
/*  689 */       value = NumberInput.parseInt(text);
/*  690 */     } catch (IllegalArgumentException iae) {
/*  691 */       return ((Short)ctxt.handleWeirdStringValue(short.class, text, "not a valid `short` value", new Object[0])).shortValue();
/*      */     } 
/*      */     
/*  694 */     if (_shortOverflow(value)) {
/*  695 */       return ((Short)ctxt.handleWeirdStringValue(short.class, text, "overflow, value cannot be represented as 16-bit value", new Object[0])).shortValue();
/*      */     }
/*      */     
/*  698 */     return (short)value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _parseIntPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  705 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  707 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  710 */         act = _checkFloatToIntCoercion(p, ctxt, int.class);
/*  711 */         if (act == CoercionAction.AsNull) {
/*  712 */           return 0;
/*      */         }
/*  714 */         if (act == CoercionAction.AsEmpty) {
/*  715 */           return 0;
/*      */         }
/*  717 */         return p.getValueAsInt();
/*      */       case 7:
/*  719 */         return p.getIntValue();
/*      */       case 11:
/*  721 */         _verifyNullForPrimitive(ctxt);
/*  722 */         return 0;
/*      */       
/*      */       case 1:
/*  725 */         text = ctxt.extractScalarFromObject(p, this, int.class);
/*      */         break;
/*      */       case 3:
/*  728 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  729 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/*  730 */             return ((Integer)handleNestedArrayForSingle(p, ctxt)).intValue();
/*      */           }
/*  732 */           int parsed = _parseIntPrimitive(p, ctxt);
/*  733 */           _verifyEndArrayForSingle(p, ctxt);
/*  734 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/*  738 */         return ((Number)ctxt.handleUnexpectedToken(int.class, p)).intValue();
/*      */     } 
/*      */     
/*  741 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, int.class);
/*      */     
/*  743 */     if (act == CoercionAction.AsNull) {
/*      */       
/*  745 */       _verifyNullForPrimitive(ctxt);
/*  746 */       return 0;
/*      */     } 
/*  748 */     if (act == CoercionAction.AsEmpty) {
/*  749 */       return 0;
/*      */     }
/*  751 */     String text = text.trim();
/*  752 */     if (_hasTextualNull(text)) {
/*  753 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  754 */       return 0;
/*      */     } 
/*  756 */     return _parseIntPrimitive(ctxt, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _parseIntPrimitive(DeserializationContext ctxt, String text) throws IOException {
/*      */     try {
/*  765 */       if (text.length() > 9) {
/*  766 */         ctxt.getParser().streamReadConstraints().validateIntegerLength(text.length());
/*  767 */         long l = NumberInput.parseLong(text);
/*  768 */         if (_intOverflow(l)) {
/*  769 */           Number v = (Number)ctxt.handleWeirdStringValue(int.class, text, "Overflow: numeric value (%s) out of range of int (%d -%d)", new Object[] { text, 
/*      */                 
/*  771 */                 Integer.valueOf(-2147483648), Integer.valueOf(2147483647) });
/*  772 */           return _nonNullNumber(v).intValue();
/*      */         } 
/*  774 */         return (int)l;
/*      */       } 
/*  776 */       return NumberInput.parseInt(text);
/*  777 */     } catch (IllegalArgumentException iae) {
/*  778 */       Number v = (Number)ctxt.handleWeirdStringValue(int.class, text, "not a valid `int` value", new Object[0]);
/*      */       
/*  780 */       return _nonNullNumber(v).intValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Integer _parseInteger(JsonParser p, DeserializationContext ctxt, Class<?> targetType) throws IOException {
/*  792 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  794 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  797 */         act = _checkFloatToIntCoercion(p, ctxt, targetType);
/*  798 */         if (act == CoercionAction.AsNull) {
/*  799 */           return (Integer)getNullValue(ctxt);
/*      */         }
/*  801 */         if (act == CoercionAction.AsEmpty) {
/*  802 */           return (Integer)getEmptyValue(ctxt);
/*      */         }
/*  804 */         return Integer.valueOf(p.getValueAsInt());
/*      */       case 7:
/*  806 */         return Integer.valueOf(p.getIntValue());
/*      */       case 11:
/*  808 */         return (Integer)getNullValue(ctxt);
/*      */       
/*      */       case 1:
/*  811 */         text = ctxt.extractScalarFromObject(p, this, targetType);
/*      */         break;
/*      */       case 3:
/*  814 */         return (Integer)_deserializeFromArray(p, ctxt);
/*      */       default:
/*  816 */         return (Integer)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */     } 
/*      */     
/*  819 */     CoercionAction act = _checkFromStringCoercion(ctxt, text);
/*  820 */     if (act == CoercionAction.AsNull) {
/*  821 */       return (Integer)getNullValue(ctxt);
/*      */     }
/*  823 */     if (act == CoercionAction.AsEmpty) {
/*  824 */       return (Integer)getEmptyValue(ctxt);
/*      */     }
/*  826 */     String text = text.trim();
/*  827 */     if (_checkTextualNull(ctxt, text)) {
/*  828 */       return (Integer)getNullValue(ctxt);
/*      */     }
/*  830 */     return _parseInteger(ctxt, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Integer _parseInteger(DeserializationContext ctxt, String text) throws IOException {
/*      */     try {
/*  839 */       if (text.length() > 9) {
/*  840 */         ctxt.getParser().streamReadConstraints().validateIntegerLength(text.length());
/*  841 */         long l = NumberInput.parseLong(text);
/*  842 */         if (_intOverflow(l)) {
/*  843 */           return (Integer)ctxt.handleWeirdStringValue(Integer.class, text, "Overflow: numeric value (%s) out of range of `java.lang.Integer` (%d -%d)", new Object[] { text, 
/*      */                 
/*  845 */                 Integer.valueOf(-2147483648), Integer.valueOf(2147483647) });
/*      */         }
/*  847 */         return Integer.valueOf((int)l);
/*      */       } 
/*  849 */       return Integer.valueOf(NumberInput.parseInt(text));
/*  850 */     } catch (IllegalArgumentException iae) {
/*  851 */       return (Integer)ctxt.handleWeirdStringValue(Integer.class, text, "not a valid `java.lang.Integer` value", new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final long _parseLongPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  860 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  862 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  865 */         act = _checkFloatToIntCoercion(p, ctxt, long.class);
/*  866 */         if (act == CoercionAction.AsNull) {
/*  867 */           return 0L;
/*      */         }
/*  869 */         if (act == CoercionAction.AsEmpty) {
/*  870 */           return 0L;
/*      */         }
/*  872 */         return p.getValueAsLong();
/*      */       case 7:
/*  874 */         return p.getLongValue();
/*      */       case 11:
/*  876 */         _verifyNullForPrimitive(ctxt);
/*  877 */         return 0L;
/*      */       
/*      */       case 1:
/*  880 */         text = ctxt.extractScalarFromObject(p, this, long.class);
/*      */         break;
/*      */       case 3:
/*  883 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  884 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/*  885 */             return ((Long)handleNestedArrayForSingle(p, ctxt)).longValue();
/*      */           }
/*  887 */           long parsed = _parseLongPrimitive(p, ctxt);
/*  888 */           _verifyEndArrayForSingle(p, ctxt);
/*  889 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/*  893 */         return ((Number)ctxt.handleUnexpectedToken(long.class, p)).longValue();
/*      */     } 
/*      */     
/*  896 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, long.class);
/*      */     
/*  898 */     if (act == CoercionAction.AsNull) {
/*      */       
/*  900 */       _verifyNullForPrimitive(ctxt);
/*  901 */       return 0L;
/*      */     } 
/*  903 */     if (act == CoercionAction.AsEmpty) {
/*  904 */       return 0L;
/*      */     }
/*  906 */     String text = text.trim();
/*  907 */     if (_hasTextualNull(text)) {
/*  908 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/*  909 */       return 0L;
/*      */     } 
/*  911 */     return _parseLongPrimitive(ctxt, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final long _parseLongPrimitive(DeserializationContext ctxt, String text) throws IOException {
/*  919 */     ctxt.getParser().streamReadConstraints().validateIntegerLength(text.length());
/*      */     try {
/*  921 */       return NumberInput.parseLong(text);
/*  922 */     } catch (IllegalArgumentException illegalArgumentException) {
/*      */       
/*  924 */       Number v = (Number)ctxt.handleWeirdStringValue(long.class, text, "not a valid `long` value", new Object[0]);
/*      */       
/*  926 */       return _nonNullNumber(v).longValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Long _parseLong(JsonParser p, DeserializationContext ctxt, Class<?> targetType) throws IOException {
/*  938 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  940 */         text = p.getText();
/*      */         break;
/*      */       case 8:
/*  943 */         act = _checkFloatToIntCoercion(p, ctxt, targetType);
/*  944 */         if (act == CoercionAction.AsNull) {
/*  945 */           return (Long)getNullValue(ctxt);
/*      */         }
/*  947 */         if (act == CoercionAction.AsEmpty) {
/*  948 */           return (Long)getEmptyValue(ctxt);
/*      */         }
/*  950 */         return Long.valueOf(p.getValueAsLong());
/*      */       case 11:
/*  952 */         return (Long)getNullValue(ctxt);
/*      */       case 7:
/*  954 */         return Long.valueOf(p.getLongValue());
/*      */       
/*      */       case 1:
/*  957 */         text = ctxt.extractScalarFromObject(p, this, targetType);
/*      */         break;
/*      */       case 3:
/*  960 */         return (Long)_deserializeFromArray(p, ctxt);
/*      */       default:
/*  962 */         return (Long)ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */     } 
/*      */     
/*  965 */     CoercionAction act = _checkFromStringCoercion(ctxt, text);
/*  966 */     if (act == CoercionAction.AsNull) {
/*  967 */       return (Long)getNullValue(ctxt);
/*      */     }
/*  969 */     if (act == CoercionAction.AsEmpty) {
/*  970 */       return (Long)getEmptyValue(ctxt);
/*      */     }
/*  972 */     String text = text.trim();
/*  973 */     if (_checkTextualNull(ctxt, text)) {
/*  974 */       return (Long)getNullValue(ctxt);
/*      */     }
/*      */     
/*  977 */     return _parseLong(ctxt, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Long _parseLong(DeserializationContext ctxt, String text) throws IOException {
/*  985 */     ctxt.getParser().streamReadConstraints().validateIntegerLength(text.length());
/*      */     try {
/*  987 */       return Long.valueOf(NumberInput.parseLong(text));
/*  988 */     } catch (IllegalArgumentException illegalArgumentException) {
/*  989 */       return (Long)ctxt.handleWeirdStringValue(Long.class, text, "not a valid `java.lang.Long` value", new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final float _parseFloatPrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     CoercionAction coercionAction1;
/*  997 */     switch (p.currentTokenId()) {
/*      */       case 6:
/*  999 */         text = p.getText();
/*      */         break;
/*      */       case 7:
/* 1002 */         coercionAction1 = _checkIntToFloatCoercion(p, ctxt, float.class);
/* 1003 */         if (coercionAction1 == CoercionAction.AsNull) {
/* 1004 */           return 0.0F;
/*      */         }
/* 1006 */         if (coercionAction1 == CoercionAction.AsEmpty) {
/* 1007 */           return 0.0F;
/*      */         }
/*      */       
/*      */       case 8:
/* 1011 */         return p.getFloatValue();
/*      */       case 11:
/* 1013 */         _verifyNullForPrimitive(ctxt);
/* 1014 */         return 0.0F;
/*      */       
/*      */       case 1:
/* 1017 */         text = ctxt.extractScalarFromObject(p, this, float.class);
/*      */         break;
/*      */       case 3:
/* 1020 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/* 1021 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/* 1022 */             return ((Float)handleNestedArrayForSingle(p, ctxt)).floatValue();
/*      */           }
/* 1024 */           float parsed = _parseFloatPrimitive(p, ctxt);
/* 1025 */           _verifyEndArrayForSingle(p, ctxt);
/* 1026 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/* 1030 */         return ((Number)ctxt.handleUnexpectedToken(float.class, p)).floatValue();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1037 */     Float nan = _checkFloatSpecialValue(text);
/* 1038 */     if (nan != null) {
/* 1039 */       return nan.floatValue();
/*      */     }
/*      */ 
/*      */     
/* 1043 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, float.class);
/*      */     
/* 1045 */     if (act == CoercionAction.AsNull) {
/*      */       
/* 1047 */       _verifyNullForPrimitive(ctxt);
/* 1048 */       return 0.0F;
/*      */     } 
/* 1050 */     if (act == CoercionAction.AsEmpty) {
/* 1051 */       return 0.0F;
/*      */     }
/* 1053 */     String text = text.trim();
/* 1054 */     if (_hasTextualNull(text)) {
/* 1055 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/* 1056 */       return 0.0F;
/*      */     } 
/* 1058 */     return _parseFloatPrimitive(p, ctxt, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final float _parseFloatPrimitive(DeserializationContext ctxt, String text) throws IOException {
/* 1071 */     if (NumberInput.looksLikeValidNumber(text)) {
/* 1072 */       ctxt.getParser().streamReadConstraints().validateFPLength(text.length());
/*      */       try {
/* 1074 */         return NumberInput.parseFloat(text, false);
/* 1075 */       } catch (IllegalArgumentException illegalArgumentException) {}
/*      */     } 
/* 1077 */     Number v = (Number)ctxt.handleWeirdStringValue(float.class, text, "not a valid `float` value", new Object[0]);
/*      */     
/* 1079 */     return _nonNullNumber(v).floatValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final float _parseFloatPrimitive(JsonParser p, DeserializationContext ctxt, String text) throws IOException {
/* 1089 */     if (NumberInput.looksLikeValidNumber(text)) {
/* 1090 */       ctxt.getParser().streamReadConstraints().validateFPLength(text.length());
/*      */       try {
/* 1092 */         return NumberInput.parseFloat(text, p.isEnabled(StreamReadFeature.USE_FAST_DOUBLE_PARSER));
/* 1093 */       } catch (IllegalArgumentException illegalArgumentException) {}
/*      */     } 
/* 1095 */     Number v = (Number)ctxt.handleWeirdStringValue(float.class, text, "not a valid `float` value", new Object[0]);
/*      */     
/* 1097 */     return _nonNullNumber(v).floatValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Float _checkFloatSpecialValue(String text) {
/* 1114 */     if (!text.isEmpty()) {
/* 1115 */       switch (text.charAt(0)) {
/*      */         case 'I':
/* 1117 */           if (_isPosInf(text)) {
/* 1118 */             return Float.valueOf(Float.POSITIVE_INFINITY);
/*      */           }
/*      */           break;
/*      */         case 'N':
/* 1122 */           if (_isNaN(text)) return Float.valueOf(Float.NaN); 
/*      */           break;
/*      */         case '-':
/* 1125 */           if (_isNegInf(text)) {
/* 1126 */             return Float.valueOf(Float.NEGATIVE_INFINITY);
/*      */           }
/*      */           break;
/*      */       } 
/*      */     
/*      */     }
/* 1132 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final double _parseDoublePrimitive(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     CoercionAction coercionAction1;
/* 1139 */     switch (p.currentTokenId()) {
/*      */       case 6:
/* 1141 */         text = p.getText();
/*      */         break;
/*      */       case 7:
/* 1144 */         coercionAction1 = _checkIntToFloatCoercion(p, ctxt, double.class);
/* 1145 */         if (coercionAction1 == CoercionAction.AsNull) {
/* 1146 */           return 0.0D;
/*      */         }
/* 1148 */         if (coercionAction1 == CoercionAction.AsEmpty) {
/* 1149 */           return 0.0D;
/*      */         }
/*      */       
/*      */       case 8:
/* 1153 */         return p.getDoubleValue();
/*      */       case 11:
/* 1155 */         _verifyNullForPrimitive(ctxt);
/* 1156 */         return 0.0D;
/*      */       
/*      */       case 1:
/* 1159 */         text = ctxt.extractScalarFromObject(p, this, double.class);
/*      */         break;
/*      */       case 3:
/* 1162 */         if (ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/* 1163 */           if (p.nextToken() == JsonToken.START_ARRAY) {
/* 1164 */             return ((Double)handleNestedArrayForSingle(p, ctxt)).doubleValue();
/*      */           }
/* 1166 */           double parsed = _parseDoublePrimitive(p, ctxt);
/* 1167 */           _verifyEndArrayForSingle(p, ctxt);
/* 1168 */           return parsed;
/*      */         } 
/*      */       
/*      */       default:
/* 1172 */         return ((Number)ctxt.handleUnexpectedToken(double.class, p)).doubleValue();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1179 */     Double nan = _checkDoubleSpecialValue(text);
/* 1180 */     if (nan != null) {
/* 1181 */       return nan.doubleValue();
/*      */     }
/*      */ 
/*      */     
/* 1185 */     CoercionAction act = _checkFromStringCoercion(ctxt, text, LogicalType.Integer, double.class);
/*      */     
/* 1187 */     if (act == CoercionAction.AsNull) {
/*      */       
/* 1189 */       _verifyNullForPrimitive(ctxt);
/* 1190 */       return 0.0D;
/*      */     } 
/* 1192 */     if (act == CoercionAction.AsEmpty) {
/* 1193 */       return 0.0D;
/*      */     }
/* 1195 */     String text = text.trim();
/* 1196 */     if (_hasTextualNull(text)) {
/* 1197 */       _verifyNullForPrimitiveCoercion(ctxt, text);
/* 1198 */       return 0.0D;
/*      */     } 
/* 1200 */     return _parseDoublePrimitive(p, ctxt, text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final double _parseDoublePrimitive(DeserializationContext ctxt, String text) throws IOException {
/*      */     try {
/* 1210 */       return _parseDouble(text);
/* 1211 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 1212 */       Number v = (Number)ctxt.handleWeirdStringValue(double.class, text, "not a valid `double` value (as String to convert)", new Object[0]);
/*      */       
/* 1214 */       return _nonNullNumber(v).doubleValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final double _parseDoublePrimitive(JsonParser p, DeserializationContext ctxt, String text) throws IOException {
/*      */     try {
/* 1224 */       return _parseDouble(text, p.isEnabled(StreamReadFeature.USE_FAST_DOUBLE_PARSER));
/* 1225 */     } catch (IllegalArgumentException illegalArgumentException) {
/* 1226 */       Number v = (Number)ctxt.handleWeirdStringValue(double.class, text, "not a valid `double` value (as String to convert)", new Object[0]);
/*      */       
/* 1228 */       return _nonNullNumber(v).doubleValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final double _parseDouble(String numStr) throws NumberFormatException {
/* 1240 */     return _parseDouble(numStr, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final double _parseDouble(String numStr, boolean useFastParser) throws NumberFormatException {
/* 1251 */     return NumberInput.parseDouble(numStr, useFastParser);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Double _checkDoubleSpecialValue(String text) {
/* 1268 */     if (!text.isEmpty()) {
/* 1269 */       switch (text.charAt(0)) {
/*      */         case 'I':
/* 1271 */           if (_isPosInf(text)) {
/* 1272 */             return Double.valueOf(Double.POSITIVE_INFINITY);
/*      */           }
/*      */           break;
/*      */         case 'N':
/* 1276 */           if (_isNaN(text)) {
/* 1277 */             return Double.valueOf(Double.NaN);
/*      */           }
/*      */           break;
/*      */         case '-':
/* 1281 */           if (_isNegInf(text)) {
/* 1282 */             return Double.valueOf(Double.NEGATIVE_INFINITY);
/*      */           }
/*      */           break;
/*      */       } 
/*      */     
/*      */     }
/* 1288 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Date _parseDate(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     String text;
/*      */     long ts;
/* 1295 */     switch (p.currentTokenId()) {
/*      */       case 6:
/* 1297 */         text = p.getText();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1324 */         return _parseDate(text.trim(), ctxt);case 7: try { ts = p.getLongValue(); } catch (StreamReadException e) { Number v = (Number)ctxt.handleWeirdNumberValue(this._valueClass, p.getNumberValue(), "not a valid 64-bit `long` for creating `java.util.Date`", new Object[0]); ts = v.longValue(); }  return new Date(ts);case 11: return (Date)getNullValue(ctxt);case 1: text = ctxt.extractScalarFromObject(p, this, this._valueClass); return _parseDate(text.trim(), ctxt);
/*      */       case 3:
/*      */         return _parseDateFromArray(p, ctxt);
/*      */     } 
/*      */     return (Date)ctxt.handleUnexpectedToken(this._valueClass, p);
/*      */   }
/*      */   protected Date _parseDateFromArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1331 */     CoercionAction act = _findCoercionFromEmptyArray(ctxt);
/* 1332 */     boolean unwrap = ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS);
/*      */     
/* 1334 */     if (unwrap || act != CoercionAction.Fail) {
/* 1335 */       JsonToken t = p.nextToken();
/* 1336 */       if (t == JsonToken.END_ARRAY) {
/* 1337 */         switch (act) {
/*      */           case AsEmpty:
/* 1339 */             return (Date)getEmptyValue(ctxt);
/*      */           case AsNull:
/*      */           case TryConvert:
/* 1342 */             return (Date)getNullValue(ctxt);
/*      */         } 
/*      */       
/* 1345 */       } else if (unwrap) {
/* 1346 */         if (t == JsonToken.START_ARRAY) {
/* 1347 */           return (Date)handleNestedArrayForSingle(p, ctxt);
/*      */         }
/* 1349 */         Date parsed = _parseDate(p, ctxt);
/* 1350 */         _verifyEndArrayForSingle(p, ctxt);
/* 1351 */         return parsed;
/*      */       } 
/*      */     } 
/* 1354 */     return (Date)ctxt.handleUnexpectedToken(this._valueClass, JsonToken.START_ARRAY, p, null, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Date _parseDate(String value, DeserializationContext ctxt) throws IOException {
/*      */     try {
/* 1365 */       if (value.isEmpty()) {
/* 1366 */         CoercionAction act = _checkFromStringCoercion(ctxt, value);
/* 1367 */         switch (act) {
/*      */           case AsEmpty:
/* 1369 */             return new Date(0L);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1374 */         return null;
/*      */       } 
/*      */       
/* 1377 */       if (_hasTextualNull(value)) {
/* 1378 */         return null;
/*      */       }
/* 1380 */       return ctxt.parseDate(value);
/* 1381 */     } catch (IllegalArgumentException iae) {
/* 1382 */       return (Date)ctxt.handleWeirdStringValue(this._valueClass, value, "not a valid representation (error: %s)", new Object[] {
/*      */             
/* 1384 */             ClassUtil.exceptionMessage(iae)
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final String _parseString(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1396 */     return _parseString(p, ctxt, 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1401 */         (NullValueProvider)NullsConstantProvider.nuller());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String _parseString(JsonParser p, DeserializationContext ctxt, NullValueProvider nullProvider) throws IOException {
/*      */     Object ob;
/* 1423 */     CoercionAction act = CoercionAction.TryConvert;
/*      */ 
/*      */     
/* 1426 */     Class<?> rawTargetType = String.class;
/*      */     
/* 1428 */     switch (p.currentTokenId()) {
/*      */       case 6:
/* 1430 */         return p.getText();
/*      */       
/*      */       case 12:
/* 1433 */         ob = p.getEmbeddedObject();
/* 1434 */         if (ob instanceof byte[]) {
/* 1435 */           return ctxt.getBase64Variant().encode((byte[])ob, false);
/*      */         }
/* 1437 */         if (ob == null) {
/* 1438 */           return null;
/*      */         }
/*      */         
/* 1441 */         return ob.toString();
/*      */       
/*      */       case 1:
/* 1444 */         return ctxt.extractScalarFromObject(p, this, rawTargetType);
/*      */       case 7:
/* 1446 */         act = _checkIntToStringCoercion(p, ctxt, rawTargetType);
/*      */         break;
/*      */       case 8:
/* 1449 */         act = _checkFloatToStringCoercion(p, ctxt, rawTargetType);
/*      */         break;
/*      */       case 9:
/*      */       case 10:
/* 1453 */         act = _checkBooleanToStringCoercion(p, ctxt, rawTargetType);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1460 */     if (act == CoercionAction.AsNull) {
/* 1461 */       return (String)nullProvider.getNullValue(ctxt);
/*      */     }
/* 1463 */     if (act == CoercionAction.AsEmpty) {
/* 1464 */       return "";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1470 */     if (p.currentToken().isScalarValue()) {
/* 1471 */       String text = p.getValueAsString();
/* 1472 */       if (text != null) {
/* 1473 */         return text;
/*      */       }
/*      */     } 
/* 1476 */     return (String)ctxt.handleUnexpectedToken(rawTargetType, p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _hasTextualNull(String value) {
/* 1487 */     return "null".equals(value);
/*      */   }
/*      */   
/*      */   protected final boolean _isNegInf(String text) {
/* 1491 */     return ("-Infinity".equals(text) || "-INF".equals(text));
/*      */   }
/*      */   
/*      */   protected final boolean _isPosInf(String text) {
/* 1495 */     return ("Infinity".equals(text) || "INF".equals(text));
/*      */   }
/*      */   protected final boolean _isNaN(String text) {
/* 1498 */     return "NaN".equals(text);
/*      */   }
/*      */ 
/*      */   
/*      */   protected static final boolean _isBlank(String text) {
/* 1503 */     int len = text.length();
/* 1504 */     for (int i = 0; i < len; i++) {
/* 1505 */       if (text.charAt(i) > ' ') {
/* 1506 */         return false;
/*      */       }
/*      */     } 
/* 1509 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkFromStringCoercion(DeserializationContext ctxt, String value) throws IOException {
/* 1524 */     return _checkFromStringCoercion(ctxt, value, logicalType(), handledType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkFromStringCoercion(DeserializationContext ctxt, String value, LogicalType logicalType, Class<?> rawTargetType) throws IOException {
/* 1541 */     if (value.isEmpty()) {
/* 1542 */       CoercionAction coercionAction = ctxt.findCoercionAction(logicalType, rawTargetType, CoercionInputShape.EmptyString);
/*      */       
/* 1544 */       return _checkCoercionFail(ctxt, coercionAction, rawTargetType, value, "empty String (\"\")");
/*      */     } 
/* 1546 */     if (_isBlank(value)) {
/* 1547 */       CoercionAction coercionAction = ctxt.findCoercionFromBlankString(logicalType, rawTargetType, CoercionAction.Fail);
/* 1548 */       return _checkCoercionFail(ctxt, coercionAction, rawTargetType, value, "blank String (all whitespace)");
/*      */     } 
/*      */ 
/*      */     
/* 1552 */     if (ctxt.isEnabled(StreamReadCapability.UNTYPED_SCALARS)) {
/* 1553 */       return CoercionAction.TryConvert;
/*      */     }
/* 1555 */     CoercionAction act = ctxt.findCoercionAction(logicalType, rawTargetType, CoercionInputShape.String);
/* 1556 */     if (act == CoercionAction.Fail)
/*      */     {
/* 1558 */       ctxt.reportInputMismatch(this, "Cannot coerce String value (\"%s\") to %s (but might if coercion using `CoercionConfig` was enabled)", new Object[] { value, 
/*      */             
/* 1560 */             _coercedTypeDesc() });
/*      */     }
/*      */     
/* 1563 */     return act;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkFloatToIntCoercion(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType) throws IOException {
/* 1573 */     CoercionAction act = ctxt.findCoercionAction(LogicalType.Integer, rawTargetType, CoercionInputShape.Float);
/*      */     
/* 1575 */     if (act == CoercionAction.Fail) {
/* 1576 */       return _checkCoercionFail(ctxt, act, rawTargetType, p.getNumberValue(), "Floating-point value (" + p
/* 1577 */           .getText() + ")");
/*      */     }
/* 1579 */     return act;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkIntToStringCoercion(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType) throws IOException {
/* 1589 */     return _checkToStringCoercion(p, ctxt, rawTargetType, p.getNumberValue(), CoercionInputShape.Integer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkFloatToStringCoercion(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType) throws IOException {
/* 1599 */     return _checkToStringCoercion(p, ctxt, rawTargetType, p.getNumberValue(), CoercionInputShape.Float);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkBooleanToStringCoercion(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType) throws IOException {
/* 1609 */     return _checkToStringCoercion(p, ctxt, rawTargetType, Boolean.valueOf(p.getBooleanValue()), CoercionInputShape.Boolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkToStringCoercion(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType, Object inputValue, CoercionInputShape inputShape) throws IOException {
/* 1619 */     CoercionAction act = ctxt.findCoercionAction(LogicalType.Textual, rawTargetType, inputShape);
/*      */     
/* 1621 */     if (act == CoercionAction.Fail) {
/* 1622 */       return _checkCoercionFail(ctxt, act, rawTargetType, inputValue, inputShape
/* 1623 */           .name() + " value (" + p.getText() + ")");
/*      */     }
/* 1625 */     return act;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkIntToFloatCoercion(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType) throws IOException {
/* 1635 */     CoercionAction act = ctxt.findCoercionAction(LogicalType.Float, rawTargetType, CoercionInputShape.Integer);
/*      */     
/* 1637 */     if (act == CoercionAction.Fail) {
/* 1638 */       return _checkCoercionFail(ctxt, act, rawTargetType, p.getNumberValue(), "Integer value (" + p
/* 1639 */           .getText() + ")");
/*      */     }
/* 1641 */     return act;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Boolean _coerceBooleanFromInt(JsonParser p, DeserializationContext ctxt, Class<?> rawTargetType) throws IOException {
/* 1651 */     CoercionAction act = ctxt.findCoercionAction(LogicalType.Boolean, rawTargetType, CoercionInputShape.Integer);
/* 1652 */     switch (act) {
/*      */       case Fail:
/* 1654 */         _checkCoercionFail(ctxt, act, rawTargetType, p.getNumberValue(), "Integer value (" + p
/* 1655 */             .getText() + ")");
/* 1656 */         return Boolean.FALSE;
/*      */       case AsNull:
/* 1658 */         return null;
/*      */       case AsEmpty:
/* 1660 */         return Boolean.FALSE;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1666 */     if (p.getNumberType() == JsonParser.NumberType.INT)
/*      */     {
/* 1668 */       return Boolean.valueOf((p.getIntValue() != 0));
/*      */     }
/* 1670 */     return Boolean.valueOf(!"0".equals(p.getText()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _checkCoercionFail(DeserializationContext ctxt, CoercionAction act, Class<?> targetType, Object inputValue, String inputDesc) throws IOException {
/* 1681 */     if (act == CoercionAction.Fail) {
/* 1682 */       ctxt.reportBadCoercion(this, targetType, inputValue, "Cannot coerce %s to %s (but could if coercion was enabled using `CoercionConfig`)", new Object[] { inputDesc, 
/*      */             
/* 1684 */             _coercedTypeDesc(targetType) });
/*      */     }
/* 1686 */     return act;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _checkTextualNull(DeserializationContext ctxt, String text) throws JsonMappingException {
/* 1699 */     if (_hasTextualNull(text)) {
/* 1700 */       if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1701 */         _reportFailedNullCoerce(ctxt, true, (Enum<?>)MapperFeature.ALLOW_COERCION_OF_SCALARS, "String \"null\"");
/*      */       }
/* 1703 */       return true;
/*      */     } 
/* 1705 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _coerceIntegral(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1727 */     if (ctxt.isEnabled(DeserializationFeature.USE_BIG_INTEGER_FOR_INTS)) {
/* 1728 */       return p.getBigIntegerValue();
/*      */     }
/* 1730 */     if (ctxt.isEnabled(DeserializationFeature.USE_LONG_FOR_INTS)) {
/* 1731 */       return Long.valueOf(p.getLongValue());
/*      */     }
/* 1733 */     return p.getNumberValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _verifyNullForPrimitive(DeserializationContext ctxt) throws JsonMappingException {
/* 1746 */     if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES)) {
/* 1747 */       ctxt.reportInputMismatch(this, "Cannot coerce `null` to %s (disable `DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES` to allow)", new Object[] {
/*      */             
/* 1749 */             _coercedTypeDesc()
/*      */           });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _verifyNullForPrimitiveCoercion(DeserializationContext ctxt, String str) throws JsonMappingException {
/*      */     DeserializationFeature deserializationFeature;
/*      */     boolean enable;
/* 1766 */     if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1767 */       MapperFeature mapperFeature = MapperFeature.ALLOW_COERCION_OF_SCALARS;
/* 1768 */       enable = true;
/* 1769 */     } else if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES)) {
/* 1770 */       deserializationFeature = DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES;
/* 1771 */       enable = false;
/*      */     } else {
/*      */       return;
/*      */     } 
/* 1775 */     String strDesc = str.isEmpty() ? "empty String (\"\")" : String.format("String \"%s\"", new Object[] { str });
/* 1776 */     _reportFailedNullCoerce(ctxt, enable, (Enum<?>)deserializationFeature, strDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportFailedNullCoerce(DeserializationContext ctxt, boolean state, Enum<?> feature, String inputDesc) throws JsonMappingException {
/* 1782 */     String enableDesc = state ? "enable" : "disable";
/* 1783 */     ctxt.reportInputMismatch(this, "Cannot coerce %s to Null value as %s (%s `%s.%s` to allow)", new Object[] { inputDesc, 
/* 1784 */           _coercedTypeDesc(), enableDesc, feature.getDeclaringClass().getSimpleName(), feature.name() });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _coercedTypeDesc() {
/*      */     boolean structured;
/*      */     String typeDesc;
/* 1800 */     JavaType t = getValueType();
/* 1801 */     if (t != null && !t.isPrimitive()) {
/* 1802 */       structured = (t.isContainerType() || t.isReferenceType());
/* 1803 */       typeDesc = ClassUtil.getTypeDescription(t);
/*      */     } else {
/* 1805 */       Class<?> cls = handledType();
/* 1806 */       structured = ClassUtil.isCollectionMapOrArray(cls);
/* 1807 */       typeDesc = ClassUtil.getClassDescription(cls);
/*      */     } 
/* 1809 */     if (structured) {
/* 1810 */       return "element of " + typeDesc;
/*      */     }
/* 1812 */     return typeDesc + " value";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _coercedTypeDesc(Class<?> rawTargetType) {
/* 1825 */     String typeDesc = ClassUtil.getClassDescription(rawTargetType);
/* 1826 */     if (ClassUtil.isCollectionMapOrArray(rawTargetType)) {
/* 1827 */       return "element of " + typeDesc;
/*      */     }
/* 1829 */     return typeDesc + " value";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected boolean _parseBooleanFromInt(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1846 */     _verifyNumberForScalarCoercion(ctxt, p);
/*      */ 
/*      */     
/* 1849 */     return !"0".equals(p.getText());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void _verifyStringForScalarCoercion(DeserializationContext ctxt, String str) throws JsonMappingException {
/* 1858 */     MapperFeature feat = MapperFeature.ALLOW_COERCION_OF_SCALARS;
/* 1859 */     if (!ctxt.isEnabled(feat)) {
/* 1860 */       ctxt.reportInputMismatch(this, "Cannot coerce String \"%s\" to %s (enable `%s.%s` to allow)", new Object[] { str, 
/* 1861 */             _coercedTypeDesc(), feat.getDeclaringClass().getSimpleName(), feat.name() });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected Object _coerceEmptyString(DeserializationContext ctxt, boolean isPrimitive) throws JsonMappingException {
/*      */     DeserializationFeature deserializationFeature;
/*      */     boolean enable;
/* 1876 */     if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1877 */       MapperFeature mapperFeature = MapperFeature.ALLOW_COERCION_OF_SCALARS;
/* 1878 */       enable = true;
/* 1879 */     } else if (isPrimitive && ctxt.isEnabled(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES)) {
/* 1880 */       deserializationFeature = DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES;
/* 1881 */       enable = false;
/*      */     } else {
/* 1883 */       return getNullValue(ctxt);
/*      */     } 
/* 1885 */     _reportFailedNullCoerce(ctxt, enable, (Enum<?>)deserializationFeature, "empty String (\"\")");
/* 1886 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void _failDoubleToIntCoercion(JsonParser p, DeserializationContext ctxt, String type) throws IOException {
/* 1893 */     ctxt.reportInputMismatch(handledType(), "Cannot coerce a floating-point value ('%s') into %s (enable `DeserializationFeature.ACCEPT_FLOAT_AS_INT` to allow)", new Object[] { p
/*      */           
/* 1895 */           .getValueAsString(), type });
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final void _verifyNullForScalarCoercion(DeserializationContext ctxt, String str) throws JsonMappingException {
/* 1901 */     if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1902 */       String strDesc = str.isEmpty() ? "empty String (\"\")" : String.format("String \"%s\"", new Object[] { str });
/* 1903 */       _reportFailedNullCoerce(ctxt, true, (Enum<?>)MapperFeature.ALLOW_COERCION_OF_SCALARS, strDesc);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void _verifyNumberForScalarCoercion(DeserializationContext ctxt, JsonParser p) throws IOException {
/* 1910 */     MapperFeature feat = MapperFeature.ALLOW_COERCION_OF_SCALARS;
/* 1911 */     if (!ctxt.isEnabled(feat)) {
/*      */ 
/*      */       
/* 1914 */       String valueDesc = p.getText();
/* 1915 */       ctxt.reportInputMismatch(this, "Cannot coerce Number (%s) to %s (enable `%s.%s` to allow)", new Object[] { valueDesc, 
/* 1916 */             _coercedTypeDesc(), feat.getDeclaringClass().getSimpleName(), feat.name() });
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected Object _coerceNullToken(DeserializationContext ctxt, boolean isPrimitive) throws JsonMappingException {
/* 1923 */     if (isPrimitive) {
/* 1924 */       _verifyNullForPrimitive(ctxt);
/*      */     }
/* 1926 */     return getNullValue(ctxt);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected Object _coerceTextualNull(DeserializationContext ctxt, boolean isPrimitive) throws JsonMappingException {
/* 1931 */     if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 1932 */       _reportFailedNullCoerce(ctxt, true, (Enum<?>)MapperFeature.ALLOW_COERCION_OF_SCALARS, "String \"null\"");
/*      */     }
/* 1934 */     return getNullValue(ctxt);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected boolean _isEmptyOrTextualNull(String value) {
/* 1939 */     return (value.isEmpty() || "null".equals(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> findDeserializer(DeserializationContext ctxt, JavaType type, BeanProperty property) throws JsonMappingException {
/* 1961 */     return ctxt.findContextualValueDeserializer(type, property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _isIntNumber(String text) {
/* 1973 */     int len = text.length();
/* 1974 */     if (len > 0) {
/* 1975 */       int i; char c = text.charAt(0);
/*      */ 
/*      */ 
/*      */       
/* 1979 */       if (c == '-' || c == '+') {
/* 1980 */         if (len == 1) {
/* 1981 */           return false;
/*      */         }
/* 1983 */         i = 1;
/*      */       } else {
/* 1985 */         i = 0;
/*      */       } 
/*      */       
/* 1988 */       for (; i < len; i++) {
/* 1989 */         int ch = text.charAt(i);
/* 1990 */         if (ch > 57 || ch < 48) {
/* 1991 */           return false;
/*      */         }
/*      */       } 
/* 1994 */       return true;
/*      */     } 
/* 1996 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<?> findConvertingContentDeserializer(DeserializationContext ctxt, BeanProperty prop, JsonDeserializer<?> existingDeserializer) throws JsonMappingException {
/* 2019 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 2020 */     if (_neitherNull(intr, prop)) {
/* 2021 */       AnnotatedMember member = prop.getMember();
/* 2022 */       if (member != null) {
/* 2023 */         Object convDef = intr.findDeserializationContentConverter(member);
/* 2024 */         if (convDef != null) {
/* 2025 */           Converter<Object, Object> conv = ctxt.converterInstance((Annotated)prop.getMember(), convDef);
/* 2026 */           JavaType delegateType = conv.getInputType(ctxt.getTypeFactory());
/* 2027 */           if (existingDeserializer == null) {
/* 2028 */             existingDeserializer = ctxt.findContextualValueDeserializer(delegateType, prop);
/*      */           }
/* 2030 */           return new StdDelegatingDeserializer(conv, delegateType, existingDeserializer);
/*      */         } 
/*      */       } 
/*      */     } 
/* 2034 */     return existingDeserializer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonFormat.Value findFormatOverrides(DeserializationContext ctxt, BeanProperty prop, Class<?> typeForDefaults) {
/* 2055 */     if (prop != null) {
/* 2056 */       return prop.findPropertyFormat((MapperConfig)ctxt.getConfig(), typeForDefaults);
/*      */     }
/*      */     
/* 2059 */     return ctxt.getDefaultPropertyFormat(typeForDefaults);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Boolean findFormatFeature(DeserializationContext ctxt, BeanProperty prop, Class<?> typeForDefaults, JsonFormat.Feature feat) {
/* 2075 */     JsonFormat.Value format = findFormatOverrides(ctxt, prop, typeForDefaults);
/* 2076 */     if (format != null) {
/* 2077 */       return format.getFeature(feat);
/*      */     }
/* 2079 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final NullValueProvider findValueNullProvider(DeserializationContext ctxt, SettableBeanProperty prop, PropertyMetadata propMetadata) throws JsonMappingException {
/* 2093 */     if (prop != null) {
/* 2094 */       return _findNullProvider(ctxt, (BeanProperty)prop, propMetadata.getValueNulls(), prop
/* 2095 */           .getValueDeserializer());
/*      */     }
/* 2097 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected NullValueProvider findContentNullProvider(DeserializationContext ctxt, BeanProperty prop, JsonDeserializer<?> valueDeser) throws JsonMappingException {
/* 2112 */     Nulls nulls = findContentNullStyle(ctxt, prop);
/* 2113 */     if (nulls == Nulls.SKIP) {
/* 2114 */       return (NullValueProvider)NullsConstantProvider.skipper();
/*      */     }
/*      */ 
/*      */     
/* 2118 */     if (nulls == Nulls.FAIL) {
/* 2119 */       if (prop == null) {
/* 2120 */         JavaType type = ctxt.constructType(valueDeser.handledType());
/*      */         
/* 2122 */         if (type.isContainerType()) {
/* 2123 */           type = type.getContentType();
/*      */         }
/* 2125 */         return (NullValueProvider)NullsFailProvider.constructForRootValue(type);
/*      */       } 
/* 2127 */       return (NullValueProvider)NullsFailProvider.constructForProperty(prop, prop.getType().getContentType());
/*      */     } 
/*      */     
/* 2130 */     NullValueProvider prov = _findNullProvider(ctxt, prop, nulls, valueDeser);
/* 2131 */     if (prov != null) {
/* 2132 */       return prov;
/*      */     }
/* 2134 */     return (NullValueProvider)valueDeser;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Nulls findContentNullStyle(DeserializationContext ctxt, BeanProperty prop) throws JsonMappingException {
/* 2140 */     if (prop != null) {
/* 2141 */       return prop.getMetadata().getContentNulls();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2146 */     return ctxt.getConfig().getDefaultSetterInfo().getContentNulls();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final NullValueProvider _findNullProvider(DeserializationContext ctxt, BeanProperty prop, Nulls nulls, JsonDeserializer<?> valueDeser) throws JsonMappingException {
/* 2154 */     if (nulls == Nulls.FAIL) {
/* 2155 */       if (prop == null) {
/* 2156 */         Class<?> rawType = (valueDeser == null) ? Object.class : valueDeser.handledType();
/* 2157 */         return (NullValueProvider)NullsFailProvider.constructForRootValue(ctxt.constructType(rawType));
/*      */       } 
/* 2159 */       return (NullValueProvider)NullsFailProvider.constructForProperty(prop);
/*      */     } 
/* 2161 */     if (nulls == Nulls.AS_EMPTY) {
/*      */ 
/*      */       
/* 2164 */       if (valueDeser == null) {
/* 2165 */         return null;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2171 */       if (valueDeser instanceof BeanDeserializerBase) {
/* 2172 */         BeanDeserializerBase bd = (BeanDeserializerBase)valueDeser;
/* 2173 */         ValueInstantiator vi = bd.getValueInstantiator();
/* 2174 */         if (!vi.canCreateUsingDefault()) {
/* 2175 */           JavaType type = (prop == null) ? bd.getValueType() : prop.getType();
/* 2176 */           return (NullValueProvider)ctxt.reportBadDefinition(type, 
/* 2177 */               String.format("Cannot create empty instance of %s, no default Creator", new Object[] { type }));
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 2182 */       AccessPattern access = valueDeser.getEmptyAccessPattern();
/* 2183 */       if (access == AccessPattern.ALWAYS_NULL) {
/* 2184 */         return (NullValueProvider)NullsConstantProvider.nuller();
/*      */       }
/* 2186 */       if (access == AccessPattern.CONSTANT) {
/* 2187 */         return (NullValueProvider)NullsConstantProvider.forValue(valueDeser.getEmptyValue(ctxt));
/*      */       }
/*      */       
/* 2190 */       return (NullValueProvider)new NullsAsEmptyProvider(valueDeser);
/*      */     } 
/* 2192 */     if (nulls == Nulls.SKIP) {
/* 2193 */       return (NullValueProvider)NullsConstantProvider.skipper();
/*      */     }
/* 2195 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected CoercionAction _findCoercionFromEmptyString(DeserializationContext ctxt) {
/* 2200 */     return ctxt.findCoercionAction(logicalType(), handledType(), CoercionInputShape.EmptyString);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _findCoercionFromEmptyArray(DeserializationContext ctxt) {
/* 2206 */     return ctxt.findCoercionAction(logicalType(), handledType(), CoercionInputShape.EmptyArray);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected CoercionAction _findCoercionFromBlankString(DeserializationContext ctxt) {
/* 2212 */     return ctxt.findCoercionFromBlankString(logicalType(), handledType(), CoercionAction.Fail);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleUnknownProperty(JsonParser p, DeserializationContext ctxt, Object<?> instanceOrClass, String propName) throws IOException {
/* 2240 */     if (instanceOrClass == null) {
/* 2241 */       instanceOrClass = (Object<?>)handledType();
/*      */     }
/*      */     
/* 2244 */     if (ctxt.handleUnknownProperty(p, this, instanceOrClass, propName)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2250 */     p.skipChildren();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void handleMissingEndArrayForSingle(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 2256 */     ctxt.reportWrongTokenException(this, JsonToken.END_ARRAY, "Attempted to unwrap '%s' value from an array (with `DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS`) but it contains more than one value", new Object[] {
/*      */           
/* 2258 */           handledType().getName()
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object handleNestedArrayForSingle(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 2271 */     String msg = String.format("Cannot deserialize instance of %s out of %s token: nested Arrays not allowed with %s", new Object[] {
/*      */           
/* 2273 */           ClassUtil.nameOf(this._valueClass), JsonToken.START_ARRAY, "DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS"
/*      */         });
/* 2275 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p.currentToken(), p, msg, new Object[0]);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _verifyEndArrayForSingle(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 2280 */     JsonToken t = p.nextToken();
/* 2281 */     if (t != JsonToken.END_ARRAY) {
/* 2282 */       handleMissingEndArrayForSingle(p, ctxt);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final boolean _neitherNull(Object a, Object b) {
/* 2296 */     return (a != null && b != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _byteOverflow(int value) {
/* 2305 */     return (value < -128 || value > 255);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _shortOverflow(int value) {
/* 2312 */     return (value < -32768 || value > 32767);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _intOverflow(long value) {
/* 2319 */     return (value < -2147483648L || value > 2147483647L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Number _nonNullNumber(Number n) {
/* 2326 */     if (n == null) {
/* 2327 */       n = Integer.valueOf(0);
/*      */     }
/* 2329 */     return n;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\StdDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */