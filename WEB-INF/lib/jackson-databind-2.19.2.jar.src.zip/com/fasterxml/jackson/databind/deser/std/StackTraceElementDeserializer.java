/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ public class StackTraceElementDeserializer
/*     */   extends StdScalarDeserializer<StackTraceElement>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JsonDeserializer<?> _adapterDeserializer;
/*     */   
/*     */   @Deprecated
/*     */   public StackTraceElementDeserializer() {
/*  21 */     this((JsonDeserializer<?>)null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected StackTraceElementDeserializer(JsonDeserializer<?> ad) {
/*  26 */     super(StackTraceElement.class);
/*  27 */     this._adapterDeserializer = ad;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonDeserializer<?> construct(DeserializationContext ctxt) throws JsonMappingException {
/*  35 */     if (ctxt == null) {
/*  36 */       return new StackTraceElementDeserializer();
/*     */     }
/*  38 */     JsonDeserializer<?> adapterDeser = ctxt.findNonContextualValueDeserializer(ctxt.constructType(Adapter.class));
/*  39 */     return new StackTraceElementDeserializer(adapterDeser);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StackTraceElement deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  45 */     JsonToken t = p.currentToken();
/*     */ 
/*     */     
/*  48 */     if (t == JsonToken.START_OBJECT || t == JsonToken.FIELD_NAME) {
/*     */       Adapter adapted;
/*     */       
/*  51 */       if (this._adapterDeserializer == null) {
/*  52 */         adapted = (Adapter)ctxt.readValue(p, Adapter.class);
/*     */       } else {
/*  54 */         adapted = (Adapter)this._adapterDeserializer.deserialize(p, ctxt);
/*     */       } 
/*  56 */       return constructValue(ctxt, adapted);
/*  57 */     }  if (t == JsonToken.START_ARRAY && ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)) {
/*  58 */       p.nextToken();
/*  59 */       StackTraceElement value = deserialize(p, ctxt);
/*  60 */       if (p.nextToken() != JsonToken.END_ARRAY) {
/*  61 */         handleMissingEndArrayForSingle(p, ctxt);
/*     */       }
/*  63 */       return value;
/*     */     } 
/*  65 */     return (StackTraceElement)ctxt.handleUnexpectedToken(this._valueClass, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StackTraceElement constructValue(DeserializationContext ctxt, Adapter adapted) {
/*  74 */     return constructValue(ctxt, adapted.className, adapted.methodName, adapted.fileName, adapted.lineNumber, adapted.moduleName, adapted.moduleVersion, adapted.classLoaderName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected StackTraceElement constructValue(DeserializationContext ctxt, String className, String methodName, String fileName, int lineNumber, String moduleName, String moduleVersion) {
/*  84 */     return constructValue(ctxt, className, methodName, fileName, lineNumber, moduleName, moduleVersion, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StackTraceElement constructValue(DeserializationContext ctxt, String className, String methodName, String fileName, int lineNumber, String moduleName, String moduleVersion, String classLoaderName) {
/*  99 */     return new StackTraceElement(className, methodName, fileName, lineNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Adapter
/*     */   {
/*     */     public String classLoaderName;
/*     */     
/*     */     public String declaringClass;
/*     */     
/* 110 */     public String className = "";
/*     */     public String format;
/* 112 */     public String fileName = ""; public String methodName = "";
/* 113 */     public int lineNumber = -1;
/*     */     public String moduleName;
/*     */     public String moduleVersion;
/*     */     public boolean nativeMethod;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\StackTraceElementDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */