/*     */ package com.fasterxml.jackson.databind.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerators;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdResolver;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ObjectIdReader;
/*     */ import com.fasterxml.jackson.databind.deser.impl.PropertyBasedObjectIdGenerator;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.ObjectIdInfo;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AbstractDeserializer
/*     */   extends JsonDeserializer<Object>
/*     */   implements ContextualDeserializer, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JavaType _baseType;
/*     */   protected final ObjectIdReader _objectIdReader;
/*     */   protected final Map<String, SettableBeanProperty> _backRefProperties;
/*     */   protected transient Map<String, SettableBeanProperty> _properties;
/*     */   protected final boolean _acceptString;
/*     */   protected final boolean _acceptBoolean;
/*     */   protected final boolean _acceptInt;
/*     */   protected final boolean _acceptDouble;
/*     */   
/*     */   public AbstractDeserializer(BeanDeserializerBuilder builder, BeanDescription beanDesc, Map<String, SettableBeanProperty> backRefProps, Map<String, SettableBeanProperty> props) {
/*  66 */     this._baseType = beanDesc.getType();
/*  67 */     this._objectIdReader = builder.getObjectIdReader();
/*  68 */     this._backRefProperties = backRefProps;
/*  69 */     this._properties = props;
/*  70 */     Class<?> cls = this._baseType.getRawClass();
/*  71 */     this._acceptString = cls.isAssignableFrom(String.class);
/*  72 */     this._acceptBoolean = (cls == boolean.class || cls.isAssignableFrom(Boolean.class));
/*  73 */     this._acceptInt = (cls == int.class || cls.isAssignableFrom(Integer.class));
/*  74 */     this._acceptDouble = (cls == double.class || cls.isAssignableFrom(Double.class));
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public AbstractDeserializer(BeanDeserializerBuilder builder, BeanDescription beanDesc, Map<String, SettableBeanProperty> backRefProps) {
/*  80 */     this(builder, beanDesc, backRefProps, null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected AbstractDeserializer(BeanDescription beanDesc) {
/*  85 */     this._baseType = beanDesc.getType();
/*  86 */     this._objectIdReader = null;
/*  87 */     this._backRefProperties = null;
/*  88 */     Class<?> cls = this._baseType.getRawClass();
/*  89 */     this._acceptString = cls.isAssignableFrom(String.class);
/*  90 */     this._acceptBoolean = (cls == boolean.class || cls.isAssignableFrom(Boolean.class));
/*  91 */     this._acceptInt = (cls == int.class || cls.isAssignableFrom(Integer.class));
/*  92 */     this._acceptDouble = (cls == double.class || cls.isAssignableFrom(Double.class));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbstractDeserializer(AbstractDeserializer base, ObjectIdReader objectIdReader, Map<String, SettableBeanProperty> props) {
/* 101 */     this._baseType = base._baseType;
/* 102 */     this._backRefProperties = base._backRefProperties;
/* 103 */     this._acceptString = base._acceptString;
/* 104 */     this._acceptBoolean = base._acceptBoolean;
/* 105 */     this._acceptInt = base._acceptInt;
/* 106 */     this._acceptDouble = base._acceptDouble;
/*     */     
/* 108 */     this._objectIdReader = objectIdReader;
/* 109 */     this._properties = props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AbstractDeserializer constructForNonPOJO(BeanDescription beanDesc) {
/* 119 */     return new AbstractDeserializer(beanDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 126 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 127 */     if (property != null && intr != null) {
/* 128 */       AnnotatedMember accessor = property.getMember();
/* 129 */       if (accessor != null) {
/* 130 */         ObjectIdInfo objectIdInfo = intr.findObjectIdInfo((Annotated)accessor);
/* 131 */         if (objectIdInfo != null) {
/*     */           JavaType idType;
/*     */           ObjectIdGenerator<?> idGen;
/* 134 */           SettableBeanProperty idProp = null;
/* 135 */           ObjectIdResolver resolver = ctxt.objectIdResolverInstance((Annotated)accessor, objectIdInfo);
/*     */ 
/*     */           
/* 138 */           objectIdInfo = intr.findObjectReferenceInfo((Annotated)accessor, objectIdInfo);
/* 139 */           Class<?> implClass = objectIdInfo.getGeneratorType();
/*     */           
/* 141 */           if (implClass == ObjectIdGenerators.PropertyGenerator.class) {
/* 142 */             PropertyName propName = objectIdInfo.getPropertyName();
/* 143 */             idProp = (this._properties == null) ? null : this._properties.get(propName.getSimpleName());
/* 144 */             if (idProp == null)
/* 145 */               ctxt.reportBadDefinition(this._baseType, String.format("Invalid Object Id definition for %s: cannot find property with name %s", new Object[] {
/*     */                       
/* 147 */                       ClassUtil.nameOf(handledType()), ClassUtil.name(propName)
/*     */                     })); 
/* 149 */             idType = idProp.getType();
/* 150 */             PropertyBasedObjectIdGenerator propertyBasedObjectIdGenerator = new PropertyBasedObjectIdGenerator(objectIdInfo.getScope());
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */ 
/*     */             
/* 158 */             resolver = ctxt.objectIdResolverInstance((Annotated)accessor, objectIdInfo);
/* 159 */             JavaType type = ctxt.constructType(implClass);
/* 160 */             idType = ctxt.getTypeFactory().findTypeParameters(type, ObjectIdGenerator.class)[0];
/* 161 */             idGen = ctxt.objectIdGeneratorInstance((Annotated)accessor, objectIdInfo);
/*     */           } 
/* 163 */           JsonDeserializer<?> deser = ctxt.findRootValueDeserializer(idType);
/* 164 */           ObjectIdReader oir = ObjectIdReader.construct(idType, objectIdInfo.getPropertyName(), idGen, deser, idProp, resolver);
/*     */           
/* 166 */           return new AbstractDeserializer(this, oir, null);
/*     */         } 
/*     */       } 
/*     */     } 
/* 170 */     if (this._properties == null) {
/* 171 */       return this;
/*     */     }
/*     */     
/* 174 */     return new AbstractDeserializer(this, this._objectIdReader, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> handledType() {
/* 185 */     return this._baseType.getRawClass();
/*     */   }
/*     */   
/*     */   public boolean isCachable() {
/* 189 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 195 */     return LogicalType.POJO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 205 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectIdReader getObjectIdReader() {
/* 215 */     return this._objectIdReader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SettableBeanProperty findBackReference(String logicalName) {
/* 224 */     return (this._backRefProperties == null) ? null : this._backRefProperties.get(logicalName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 240 */     if (this._objectIdReader != null) {
/* 241 */       JsonToken t = p.currentToken();
/* 242 */       if (t != null) {
/*     */         
/* 244 */         if (t.isScalarValue()) {
/* 245 */           return _deserializeFromObjectId(p, ctxt);
/*     */         }
/*     */         
/* 248 */         if (t == JsonToken.START_OBJECT) {
/* 249 */           t = p.nextToken();
/*     */         }
/* 251 */         if (t == JsonToken.FIELD_NAME && this._objectIdReader.maySerializeAsObject() && this._objectIdReader
/* 252 */           .isValidReferencePropertyName(p.currentName(), p)) {
/* 253 */           return _deserializeFromObjectId(p, ctxt);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 258 */     Object result = _deserializeIfNatural(p, ctxt);
/* 259 */     if (result != null) {
/* 260 */       return result;
/*     */     }
/* 262 */     return typeDeserializer.deserializeTypedFromObject(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 272 */     ValueInstantiator bogus = new ValueInstantiator.Base(this._baseType);
/* 273 */     return ctxt.handleMissingInstantiator(this._baseType.getRawClass(), bogus, p, "abstract types either need to be mapped to concrete types, have custom deserializer, or contain additional type information", new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserializeIfNatural(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 291 */     switch (p.currentTokenId()) {
/*     */       case 6:
/* 293 */         if (this._acceptString) {
/* 294 */           return p.getText();
/*     */         }
/*     */         break;
/*     */       case 7:
/* 298 */         if (this._acceptInt) {
/* 299 */           return Integer.valueOf(p.getIntValue());
/*     */         }
/*     */         break;
/*     */       case 8:
/* 303 */         if (this._acceptDouble) {
/* 304 */           return Double.valueOf(p.getDoubleValue());
/*     */         }
/*     */         break;
/*     */       case 9:
/* 308 */         if (this._acceptBoolean) {
/* 309 */           return Boolean.TRUE;
/*     */         }
/*     */         break;
/*     */       case 10:
/* 313 */         if (this._acceptBoolean) {
/* 314 */           return Boolean.FALSE;
/*     */         }
/*     */         break;
/*     */     } 
/* 318 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserializeFromObjectId(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 327 */     Object id = this._objectIdReader.readObjectReference(p, ctxt);
/* 328 */     ReadableObjectId roid = ctxt.findObjectId(id, this._objectIdReader.generator, this._objectIdReader.resolver);
/*     */     
/* 330 */     Object pojo = roid.resolve();
/* 331 */     if (pojo == null) {
/* 332 */       throw new UnresolvedForwardReference(p, "Could not resolve Object Id [" + id + "] -- unresolved forward-reference?", p
/* 333 */           .currentLocation(), roid);
/*     */     }
/* 335 */     return pojo;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\AbstractDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */