/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonCreator;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.deser.KeyDeserializers;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedAndMetadata;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedConstructor;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.EnumResolver;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StdKeyDeserializers
/*     */   implements KeyDeserializers, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public static KeyDeserializer constructEnumKeyDeserializer(EnumResolver enumResolver) {
/*  40 */     return new StdKeyDeserializer.EnumKD(enumResolver, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public static KeyDeserializer constructEnumKeyDeserializer(EnumResolver enumResolver, AnnotatedMethod factory) {
/*  45 */     return new StdKeyDeserializer.EnumKD(enumResolver, factory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyDeserializer constructEnumKeyDeserializer(EnumResolver enumRes, EnumResolver byEnumNamingResolver, EnumResolver byToStringResolver, EnumResolver byIndexResolver) {
/*  54 */     return new StdKeyDeserializer.EnumKD(enumRes, null, byEnumNamingResolver, byToStringResolver, byIndexResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyDeserializer constructEnumKeyDeserializer(EnumResolver enumResolver, AnnotatedMethod factory, EnumResolver enumNamingResolver, EnumResolver byToStringResolver, EnumResolver byIndexResolver) {
/*  63 */     return new StdKeyDeserializer.EnumKD(enumResolver, factory, enumNamingResolver, byToStringResolver, byIndexResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyDeserializer constructDelegatingKeyDeserializer(DeserializationConfig config, JavaType type, JsonDeserializer<?> deser) {
/*  69 */     return new StdKeyDeserializer.DelegatingKD(type.getRawClass(), deser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyDeserializer findStringBasedKeyDeserializer(DeserializationConfig config, JavaType type) throws JsonMappingException {
/*  87 */     BeanDescription beanDesc = config.introspectForCreation(type);
/*     */     
/*  89 */     AnnotatedAndMetadata<AnnotatedConstructor, JsonCreator.Mode> ctorInfo = _findStringConstructor(beanDesc);
/*     */     
/*  91 */     if (ctorInfo != null && ctorInfo.metadata != null) {
/*  92 */       return _constructCreatorKeyDeserializer(config, (AnnotatedMember)ctorInfo.annotated);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  97 */     List<AnnotatedAndMetadata<AnnotatedMethod, JsonCreator.Mode>> factoryCandidates = beanDesc.getFactoryMethodsWithMode();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     factoryCandidates.removeIf(m -> 
/* 103 */         (((AnnotatedMethod)m.annotated).getParameterCount() != 1 || ((AnnotatedMethod)m.annotated).getRawParameterType(0) != String.class || m.metadata == JsonCreator.Mode.PROPERTIES));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     AnnotatedMethod explicitFactory = _findExplicitStringFactoryMethod(factoryCandidates);
/* 110 */     if (explicitFactory != null) {
/* 111 */       return _constructCreatorKeyDeserializer(config, (AnnotatedMember)explicitFactory);
/*     */     }
/*     */     
/* 114 */     if (ctorInfo != null) {
/* 115 */       return _constructCreatorKeyDeserializer(config, (AnnotatedMember)ctorInfo.annotated);
/*     */     }
/*     */ 
/*     */     
/* 119 */     if (!factoryCandidates.isEmpty())
/*     */     {
/*     */       
/* 122 */       return _constructCreatorKeyDeserializer(config, (AnnotatedMember)((AnnotatedAndMetadata)factoryCandidates.get(0)).annotated);
/*     */     }
/* 124 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static KeyDeserializer _constructCreatorKeyDeserializer(DeserializationConfig config, AnnotatedMember creator) {
/* 130 */     if (creator instanceof AnnotatedConstructor) {
/* 131 */       Constructor<?> rawCtor = ((AnnotatedConstructor)creator).getAnnotated();
/* 132 */       if (config.canOverrideAccessModifiers()) {
/* 133 */         ClassUtil.checkAndFixAccess(rawCtor, config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */       }
/* 135 */       return new StdKeyDeserializer.StringCtorKeyDeserializer(rawCtor);
/*     */     } 
/* 137 */     Method m = ((AnnotatedMethod)creator).getAnnotated();
/* 138 */     if (config.canOverrideAccessModifiers()) {
/* 139 */       ClassUtil.checkAndFixAccess(m, config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */     }
/* 141 */     return new StdKeyDeserializer.StringFactoryKeyDeserializer(m);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static AnnotatedAndMetadata<AnnotatedConstructor, JsonCreator.Mode> _findStringConstructor(BeanDescription beanDesc) {
/* 149 */     for (AnnotatedAndMetadata<AnnotatedConstructor, JsonCreator.Mode> entry : (Iterable<AnnotatedAndMetadata<AnnotatedConstructor, JsonCreator.Mode>>)beanDesc.getConstructorsWithMode()) {
/*     */ 
/*     */ 
/*     */       
/* 153 */       AnnotatedConstructor ctor = (AnnotatedConstructor)entry.annotated;
/* 154 */       if (ctor.getParameterCount() == 1 && String.class == ctor
/* 155 */         .getRawParameterType(0)) {
/* 156 */         return entry;
/*     */       }
/*     */     } 
/* 159 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static AnnotatedMethod _findExplicitStringFactoryMethod(List<AnnotatedAndMetadata<AnnotatedMethod, JsonCreator.Mode>> candidates) throws JsonMappingException {
/* 166 */     AnnotatedMethod match = null;
/* 167 */     for (AnnotatedAndMetadata<AnnotatedMethod, JsonCreator.Mode> entry : candidates) {
/*     */       
/* 169 */       if (entry.metadata != null) {
/* 170 */         if (match == null) {
/* 171 */           match = (AnnotatedMethod)entry.annotated;
/*     */           
/*     */           continue;
/*     */         } 
/* 175 */         Class<?> rawKeyType = ((AnnotatedMethod)entry.annotated).getDeclaringClass();
/* 176 */         throw new IllegalArgumentException("Multiple suitable annotated Creator factory methods to be used as the Key deserializer for type " + 
/*     */             
/* 178 */             ClassUtil.nameOf(rawKeyType));
/*     */       } 
/*     */     } 
/*     */     
/* 182 */     return match;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyDeserializer findKeyDeserializer(JavaType type, DeserializationConfig config, BeanDescription beanDesc) throws JsonMappingException {
/* 195 */     Class<?> raw = type.getRawClass();
/*     */     
/* 197 */     if (raw.isPrimitive()) {
/* 198 */       raw = ClassUtil.wrapperType(raw);
/*     */     }
/* 200 */     return StdKeyDeserializer.forType(raw);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\StdKeyDeserializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */