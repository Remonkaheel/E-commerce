/*      */ package com.fasterxml.jackson.databind.deser;
/*      */ import com.fasterxml.jackson.annotation.JacksonInject;
/*      */ import com.fasterxml.jackson.annotation.JsonSetter;
/*      */ import com.fasterxml.jackson.annotation.Nulls;
/*      */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*      */ import com.fasterxml.jackson.databind.BeanDescription;
/*      */ import com.fasterxml.jackson.databind.BeanProperty;
/*      */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*      */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*      */ import com.fasterxml.jackson.databind.PropertyName;
/*      */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*      */ import com.fasterxml.jackson.databind.deser.impl.CreatorCandidate;
/*      */ import com.fasterxml.jackson.databind.deser.impl.CreatorCollector;
/*      */ import com.fasterxml.jackson.databind.deser.std.MapDeserializer;
/*      */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedParameter;
/*      */ import com.fasterxml.jackson.databind.introspect.AnnotatedWithParams;
/*      */ import com.fasterxml.jackson.databind.introspect.PotentialCreator;
/*      */ import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*      */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*      */ import com.fasterxml.jackson.databind.type.CollectionType;
/*      */ import com.fasterxml.jackson.databind.type.MapLikeType;
/*      */ import com.fasterxml.jackson.databind.type.MapType;
/*      */ import com.fasterxml.jackson.databind.type.ReferenceType;
/*      */ import com.fasterxml.jackson.databind.util.EnumResolver;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ public abstract class BasicDeserializerFactory extends DeserializerFactory implements Serializable {
/*   41 */   private static final Class<?> CLASS_OBJECT = Object.class;
/*   42 */   private static final Class<?> CLASS_STRING = String.class;
/*   43 */   private static final Class<?> CLASS_CHAR_SEQUENCE = CharSequence.class;
/*   44 */   private static final Class<?> CLASS_ITERABLE = Iterable.class;
/*   45 */   private static final Class<?> CLASS_MAP_ENTRY = Map.Entry.class;
/*   46 */   private static final Class<?> CLASS_SERIALIZABLE = Serializable.class;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final DeserializerFactoryConfig _factoryConfig;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BasicDeserializerFactory(DeserializerFactoryConfig config) {
/*   67 */     this._factoryConfig = config;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DeserializerFactoryConfig getFactoryConfig() {
/*   78 */     return this._factoryConfig;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract DeserializerFactory withConfig(DeserializerFactoryConfig paramDeserializerFactoryConfig);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final DeserializerFactory withAdditionalDeserializers(Deserializers additional) {
/*   95 */     return withConfig(this._factoryConfig.withAdditionalDeserializers(additional));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final DeserializerFactory withAdditionalKeyDeserializers(KeyDeserializers additional) {
/*  104 */     return withConfig(this._factoryConfig.withAdditionalKeyDeserializers(additional));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final DeserializerFactory withDeserializerModifier(BeanDeserializerModifier modifier) {
/*  113 */     return withConfig(this._factoryConfig.withDeserializerModifier(modifier));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final DeserializerFactory withAbstractTypeResolver(AbstractTypeResolver resolver) {
/*  122 */     return withConfig(this._factoryConfig.withAbstractTypeResolver(resolver));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final DeserializerFactory withValueInstantiators(ValueInstantiators instantiators) {
/*  131 */     return withConfig(this._factoryConfig.withValueInstantiators(instantiators));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType mapAbstractType(DeserializationConfig config, JavaType type) throws JsonMappingException {
/*      */     while (true) {
/*  145 */       JavaType next = _mapAbstractType2(config, type);
/*  146 */       if (next == null) {
/*  147 */         return type;
/*      */       }
/*      */ 
/*      */       
/*  151 */       Class<?> prevCls = type.getRawClass();
/*  152 */       Class<?> nextCls = next.getRawClass();
/*  153 */       if (prevCls == nextCls || !prevCls.isAssignableFrom(nextCls)) {
/*  154 */         throw new IllegalArgumentException("Invalid abstract type resolution from " + type + " to " + next + ": latter is not a subtype of former");
/*      */       }
/*  156 */       type = next;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JavaType _mapAbstractType2(DeserializationConfig config, JavaType type) throws JsonMappingException {
/*  167 */     Class<?> currClass = type.getRawClass();
/*  168 */     if (this._factoryConfig.hasAbstractTypeResolvers()) {
/*  169 */       for (AbstractTypeResolver resolver : this._factoryConfig.abstractTypeResolvers()) {
/*  170 */         JavaType concrete = resolver.findTypeMapping(config, type);
/*  171 */         if (concrete != null && !concrete.hasRawClass(currClass)) {
/*  172 */           return concrete;
/*      */         }
/*      */       } 
/*      */     }
/*  176 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ValueInstantiator findValueInstantiator(DeserializationContext ctxt, BeanDescription beanDesc) throws JsonMappingException {
/*  195 */     DeserializationConfig config = ctxt.getConfig();
/*      */     
/*  197 */     ValueInstantiator instantiator = null;
/*      */     
/*  199 */     AnnotatedClass ac = beanDesc.getClassInfo();
/*  200 */     Object instDef = config.getAnnotationIntrospector().findValueInstantiator(ac);
/*  201 */     if (instDef != null) {
/*  202 */       instantiator = _valueInstantiatorInstance(config, (Annotated)ac, instDef);
/*      */     }
/*  204 */     if (instantiator == null) {
/*      */ 
/*      */       
/*  207 */       instantiator = JDKValueInstantiators.findStdValueInstantiator(config, beanDesc.getBeanClass());
/*  208 */       if (instantiator == null) {
/*  209 */         instantiator = _constructDefaultValueInstantiator(ctxt, beanDesc);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  214 */     if (this._factoryConfig.hasValueInstantiators()) {
/*  215 */       for (ValueInstantiators insts : this._factoryConfig.valueInstantiators()) {
/*  216 */         instantiator = insts.findValueInstantiator(config, beanDesc, instantiator);
/*      */         
/*  218 */         if (instantiator == null) {
/*  219 */           ctxt.reportBadTypeDefinition(beanDesc, "Broken registered ValueInstantiators (of type %s): returned null ValueInstantiator", new Object[] { insts
/*      */                 
/*  221 */                 .getClass().getName() });
/*      */         }
/*      */       } 
/*      */     }
/*  225 */     if (instantiator != null) {
/*  226 */       instantiator = instantiator.createContextual(ctxt, beanDesc);
/*      */     }
/*      */     
/*  229 */     return instantiator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ValueInstantiator _constructDefaultValueInstantiator(DeserializationContext ctxt, BeanDescription beanDesc) throws JsonMappingException {
/*  240 */     DeserializationConfig deserializationConfig = ctxt.getConfig();
/*  241 */     PotentialCreators potentialCreators = beanDesc.getPotentialCreators();
/*  242 */     ConstructorDetector ctorDetector = deserializationConfig.getConstructorDetector();
/*      */     
/*  244 */     VisibilityChecker<?> vchecker = deserializationConfig.getDefaultVisibilityChecker(beanDesc.getBeanClass(), beanDesc
/*  245 */         .getClassInfo());
/*      */     
/*  247 */     CreatorCollector creators = new CreatorCollector(beanDesc, (MapperConfig)deserializationConfig);
/*      */ 
/*      */     
/*  250 */     if (potentialCreators.hasPropertiesBased()) {
/*  251 */       PotentialCreator primaryPropsBased = potentialCreators.propertiesBased;
/*      */ 
/*      */ 
/*      */       
/*  255 */       if (primaryPropsBased.paramCount() == 0) {
/*  256 */         creators.setDefaultCreator(primaryPropsBased.creator());
/*      */       } else {
/*      */         
/*  259 */         _addSelectedPropertiesBasedCreator(ctxt, beanDesc, creators, 
/*  260 */             CreatorCandidate.construct(deserializationConfig.getAnnotationIntrospector(), primaryPropsBased
/*  261 */               .creator(), primaryPropsBased.propertyDefs()));
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  266 */     boolean hasExplicitDelegating = _addExplicitDelegatingCreators(ctxt, beanDesc, creators, potentialCreators
/*      */         
/*  268 */         .getExplicitDelegating());
/*      */ 
/*      */     
/*  271 */     if (beanDesc.getType().isConcrete()) {
/*      */ 
/*      */ 
/*      */       
/*  275 */       boolean isNonStaticInnerClass = beanDesc.isNonStaticInnerClass();
/*  276 */       if (!isNonStaticInnerClass) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  283 */         if (!creators.hasDefaultCreator()) {
/*  284 */           AnnotatedConstructor defaultCtor = beanDesc.findDefaultConstructor();
/*  285 */           if (defaultCtor != null) {
/*  286 */             creators.setDefaultCreator((AnnotatedWithParams)defaultCtor);
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  292 */         boolean findImplicit = ctorDetector.shouldIntrospectorImplicitConstructors(beanDesc.getBeanClass());
/*  293 */         if (findImplicit) {
/*  294 */           _addImplicitDelegatingConstructors(ctxt, beanDesc, vchecker, creators, potentialCreators
/*      */               
/*  296 */               .getImplicitDelegatingConstructors());
/*      */         }
/*      */       } 
/*      */     } 
/*  300 */     if (!hasExplicitDelegating) {
/*  301 */       _addImplicitDelegatingFactories(ctxt, vchecker, creators, potentialCreators
/*      */           
/*  303 */           .getImplicitDelegatingFactories());
/*      */     }
/*      */     
/*  306 */     return creators.constructValueInstantiator(ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ValueInstantiator _valueInstantiatorInstance(DeserializationConfig config, Annotated annotated, Object instDef) throws JsonMappingException {
/*  313 */     if (instDef == null) {
/*  314 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  319 */     if (instDef instanceof ValueInstantiator) {
/*  320 */       return (ValueInstantiator)instDef;
/*      */     }
/*  322 */     if (!(instDef instanceof Class)) {
/*  323 */       throw new IllegalStateException("AnnotationIntrospector returned key deserializer definition of type " + instDef
/*  324 */           .getClass().getName() + "; expected type KeyDeserializer or Class<KeyDeserializer> instead");
/*      */     }
/*      */     
/*  327 */     Class<?> instClass = (Class)instDef;
/*  328 */     if (ClassUtil.isBogusClass(instClass)) {
/*  329 */       return null;
/*      */     }
/*  331 */     if (!ValueInstantiator.class.isAssignableFrom(instClass)) {
/*  332 */       throw new IllegalStateException("AnnotationIntrospector returned Class " + instClass.getName() + "; expected Class<ValueInstantiator>");
/*      */     }
/*      */     
/*  335 */     HandlerInstantiator hi = config.getHandlerInstantiator();
/*  336 */     if (hi != null) {
/*  337 */       ValueInstantiator inst = hi.valueInstantiatorInstance((MapperConfig)config, annotated, instClass);
/*  338 */       if (inst != null) {
/*  339 */         return inst;
/*      */       }
/*      */     } 
/*  342 */     return (ValueInstantiator)ClassUtil.createInstance(instClass, config
/*  343 */         .canOverrideAccessModifiers());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _addExplicitDelegatingCreators(DeserializationContext ctxt, BeanDescription beanDesc, CreatorCollector creators, List<PotentialCreator> potentials) throws JsonMappingException {
/*  358 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/*  359 */     boolean added = false;
/*      */     
/*  361 */     for (PotentialCreator ctor : potentials) {
/*  362 */       added |= _addExplicitDelegatingCreator(ctxt, beanDesc, creators, 
/*  363 */           CreatorCandidate.construct(intr, ctor.creator(), null));
/*      */     }
/*  365 */     return added;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _addImplicitDelegatingConstructors(DeserializationContext ctxt, BeanDescription beanDesc, VisibilityChecker<?> vchecker, CreatorCollector creators, List<PotentialCreator> potentials) throws JsonMappingException {
/*  374 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/*      */     
/*  376 */     for (PotentialCreator candidate : potentials) {
/*  377 */       int argCount = candidate.paramCount();
/*  378 */       AnnotatedWithParams ctor = candidate.creator();
/*      */       
/*  380 */       if (argCount == 1) {
/*  381 */         _handleSingleArgumentCreator(creators, ctor, false, vchecker
/*      */             
/*  383 */             .isCreatorVisible((AnnotatedMember)ctor));
/*      */ 
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  392 */       SettableBeanProperty[] properties = new SettableBeanProperty[argCount];
/*  393 */       int injectCount = 0;
/*      */       
/*  395 */       for (int i = 0; i < argCount; i++) {
/*  396 */         AnnotatedParameter param = ctor.getParameter(i);
/*  397 */         JacksonInject.Value injectable = intr.findInjectableValue((AnnotatedMember)param);
/*      */         
/*  399 */         if (injectable != null) {
/*  400 */           injectCount++;
/*  401 */           properties[i] = constructCreatorProperty(ctxt, beanDesc, null, i, param, injectable);
/*      */         } else {
/*      */           
/*  404 */           NameTransformer unwrapper = intr.findUnwrappingNameTransformer((AnnotatedMember)param);
/*  405 */           if (unwrapper != null) {
/*  406 */             properties[i] = constructCreatorProperty(ctxt, beanDesc, UnwrappedPropertyHandler.creatorParamName(i), i, param, null);
/*      */           }
/*      */         } 
/*      */       } 
/*  410 */       if (injectCount + 1 == argCount)
/*      */       {
/*  412 */         creators.addDelegatingCreator(ctor, false, properties, 0);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _addImplicitDelegatingFactories(DeserializationContext ctxt, VisibilityChecker<?> vchecker, CreatorCollector creators, List<PotentialCreator> potentials) throws JsonMappingException {
/*  430 */     for (PotentialCreator candidate : potentials) {
/*  431 */       int argCount = candidate.paramCount();
/*  432 */       AnnotatedWithParams factory = candidate.creator();
/*      */       
/*  434 */       if (argCount == 1) {
/*  435 */         _handleSingleArgumentCreator(creators, factory, false, vchecker
/*  436 */             .isCreatorVisible((AnnotatedMember)factory));
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _addExplicitDelegatingCreator(DeserializationContext ctxt, BeanDescription beanDesc, CreatorCollector creators, CreatorCandidate candidate) throws JsonMappingException {
/*  461 */     int ix = -1;
/*  462 */     int argCount = candidate.paramCount();
/*  463 */     SettableBeanProperty[] properties = new SettableBeanProperty[argCount];
/*      */ 
/*      */     
/*  466 */     if (argCount == 0) {
/*      */       
/*  468 */       creators.addPropertyCreator(candidate.creator(), true, properties);
/*  469 */       return true;
/*      */     } 
/*  471 */     for (int i = 0; i < argCount; i++) {
/*  472 */       AnnotatedParameter param = candidate.parameter(i);
/*  473 */       JacksonInject.Value injectId = candidate.injection(i);
/*  474 */       if (injectId != null) {
/*  475 */         properties[i] = constructCreatorProperty(ctxt, beanDesc, null, i, param, injectId);
/*      */       
/*      */       }
/*  478 */       else if (ix < 0) {
/*  479 */         ix = i;
/*      */       }
/*      */       else {
/*      */         
/*  483 */         ctxt.reportBadTypeDefinition(beanDesc, "More than one argument (#%d and #%d) left as delegating for Creator %s: only one allowed", new Object[] {
/*      */               
/*  485 */               Integer.valueOf(ix), Integer.valueOf(i), candidate });
/*      */       } 
/*      */     } 
/*  488 */     if (ix < 0) {
/*  489 */       ctxt.reportBadTypeDefinition(beanDesc, "No argument left as delegating for Creator %s: exactly one required", new Object[] { candidate });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  494 */     if (argCount == 1) {
/*  495 */       return _handleSingleArgumentCreator(creators, candidate.creator(), true, true);
/*      */     }
/*  497 */     creators.addDelegatingCreator(candidate.creator(), true, properties, ix);
/*  498 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _addSelectedPropertiesBasedCreator(DeserializationContext ctxt, BeanDescription beanDesc, CreatorCollector creators, CreatorCandidate candidate) throws JsonMappingException {
/*  509 */     int paramCount = candidate.paramCount();
/*  510 */     SettableBeanProperty[] properties = new SettableBeanProperty[paramCount];
/*  511 */     int anySetterIx = -1;
/*      */     
/*  513 */     for (int i = 0; i < paramCount; i++) {
/*  514 */       JacksonInject.Value injectId = candidate.injection(i);
/*  515 */       AnnotatedParameter param = candidate.parameter(i);
/*  516 */       PropertyName name = candidate.paramName(i);
/*  517 */       boolean isAnySetter = Boolean.TRUE.equals(ctxt.getAnnotationIntrospector().hasAnySetter((Annotated)param));
/*  518 */       if (isAnySetter) {
/*  519 */         if (anySetterIx >= 0) {
/*  520 */           ctxt.reportBadTypeDefinition(beanDesc, "More than one 'any-setter' specified (parameter #%d vs #%d)", new Object[] {
/*      */                 
/*  522 */                 Integer.valueOf(anySetterIx), Integer.valueOf(i) });
/*      */         } else {
/*  524 */           anySetterIx = i;
/*      */         } 
/*  526 */       } else if (name == null) {
/*      */ 
/*      */         
/*  529 */         NameTransformer unwrapper = ctxt.getAnnotationIntrospector().findUnwrappingNameTransformer((AnnotatedMember)param);
/*  530 */         if (unwrapper != null) {
/*  531 */           properties[i] = constructCreatorProperty(ctxt, beanDesc, UnwrappedPropertyHandler.creatorParamName(i), i, param, null);
/*      */         }
/*      */         
/*  534 */         if (name == null && injectId == null)
/*  535 */           ctxt.reportBadTypeDefinition(beanDesc, "Argument #%d of Creator %s has no property name (and is not Injectable): can not use as property-based Creator", new Object[] {
/*      */                 
/*  537 */                 Integer.valueOf(i), candidate
/*      */               }); 
/*      */       } 
/*  540 */       properties[i] = constructCreatorProperty(ctxt, beanDesc, name, i, param, injectId);
/*      */     } 
/*  542 */     creators.addPropertyCreator(candidate.creator(), true, properties);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _handleSingleArgumentCreator(CreatorCollector creators, AnnotatedWithParams ctor, boolean isCreator, boolean isVisible) {
/*  549 */     Class<?> type = ctor.getRawParameterType(0);
/*  550 */     if (type == String.class || type == CLASS_CHAR_SEQUENCE) {
/*  551 */       if (isCreator || isVisible) {
/*  552 */         creators.addStringCreator(ctor, isCreator);
/*      */       }
/*  554 */       return true;
/*      */     } 
/*  556 */     if (type == int.class || type == Integer.class) {
/*  557 */       if (isCreator || isVisible) {
/*  558 */         creators.addIntCreator(ctor, isCreator);
/*      */       }
/*  560 */       return true;
/*      */     } 
/*  562 */     if (type == long.class || type == Long.class) {
/*  563 */       if (isCreator || isVisible) {
/*  564 */         creators.addLongCreator(ctor, isCreator);
/*      */       }
/*  566 */       return true;
/*      */     } 
/*  568 */     if (type == double.class || type == Double.class) {
/*  569 */       if (isCreator || isVisible) {
/*  570 */         creators.addDoubleCreator(ctor, isCreator);
/*      */       }
/*  572 */       return true;
/*      */     } 
/*  574 */     if (type == boolean.class || type == Boolean.class) {
/*  575 */       if (isCreator || isVisible) {
/*  576 */         creators.addBooleanCreator(ctor, isCreator);
/*      */       }
/*  578 */       return true;
/*      */     } 
/*  580 */     if (type == BigInteger.class && (
/*  581 */       isCreator || isVisible)) {
/*  582 */       creators.addBigIntegerCreator(ctor, isCreator);
/*      */     }
/*      */     
/*  585 */     if (type == BigDecimal.class && (
/*  586 */       isCreator || isVisible)) {
/*  587 */       creators.addBigDecimalCreator(ctor, isCreator);
/*      */     }
/*      */ 
/*      */     
/*  591 */     if (isCreator) {
/*  592 */       creators.addDelegatingCreator(ctor, isCreator, null, 0);
/*  593 */       return true;
/*      */     } 
/*  595 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SettableBeanProperty constructCreatorProperty(DeserializationContext ctxt, BeanDescription beanDesc, PropertyName name, int index, AnnotatedParameter param, JacksonInject.Value injectable) throws JsonMappingException {
/*      */     PropertyName wrapperName;
/*  609 */     DeserializationConfig config = ctxt.getConfig();
/*  610 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/*      */ 
/*      */ 
/*      */     
/*  614 */     if (intr == null) {
/*  615 */       metadata = PropertyMetadata.STD_REQUIRED_OR_OPTIONAL;
/*  616 */       wrapperName = null;
/*      */     } else {
/*  618 */       Boolean b = intr.hasRequiredMarker((AnnotatedMember)param);
/*  619 */       String desc = intr.findPropertyDescription((Annotated)param);
/*  620 */       Integer idx = intr.findPropertyIndex((Annotated)param);
/*  621 */       String def = intr.findPropertyDefaultValue((Annotated)param);
/*  622 */       metadata = PropertyMetadata.construct(b, desc, idx, def);
/*  623 */       wrapperName = intr.findWrapperName((Annotated)param);
/*      */     } 
/*      */     
/*  626 */     JavaType type = resolveMemberAndTypeAnnotations(ctxt, (AnnotatedMember)param, param.getType());
/*  627 */     BeanProperty.Std property = new BeanProperty.Std(name, type, wrapperName, (AnnotatedMember)param, metadata);
/*      */ 
/*      */     
/*  630 */     TypeDeserializer typeDeser = (TypeDeserializer)type.getTypeHandler();
/*      */     
/*  632 */     if (typeDeser == null) {
/*  633 */       typeDeser = findTypeDeserializer(config, type);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  638 */     PropertyMetadata metadata = _getSetterInfo((MapperConfig<?>)config, (BeanProperty)property, metadata);
/*      */ 
/*      */ 
/*      */     
/*  642 */     SettableBeanProperty prop = CreatorProperty.construct(name, type, property.getWrapperName(), typeDeser, beanDesc
/*  643 */         .getClassAnnotations(), param, index, injectable, metadata);
/*      */     
/*  645 */     JsonDeserializer<?> deser = findDeserializerFromAnnotation(ctxt, (Annotated)param);
/*  646 */     if (deser == null) {
/*  647 */       deser = (JsonDeserializer)type.getValueHandler();
/*      */     }
/*  649 */     if (deser != null) {
/*      */       
/*  651 */       deser = ctxt.handlePrimaryContextualization(deser, (BeanProperty)prop, type);
/*  652 */       prop = prop.withValueDeserializer(deser);
/*      */     } 
/*  654 */     return prop;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PropertyMetadata _getSetterInfo(MapperConfig<?> config, BeanProperty prop, PropertyMetadata metadata) {
/*  666 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/*      */     
/*  668 */     boolean needMerge = true;
/*  669 */     Nulls valueNulls = null;
/*  670 */     Nulls contentNulls = null;
/*      */ 
/*      */ 
/*      */     
/*  674 */     AnnotatedMember prim = prop.getMember();
/*      */     
/*  676 */     if (prim != null) {
/*      */       
/*  678 */       if (intr != null) {
/*  679 */         JsonSetter.Value setterInfo = intr.findSetterInfo((Annotated)prim);
/*  680 */         if (setterInfo != null) {
/*  681 */           valueNulls = setterInfo.nonDefaultValueNulls();
/*  682 */           contentNulls = setterInfo.nonDefaultContentNulls();
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  687 */       if (needMerge || valueNulls == null || contentNulls == null) {
/*  688 */         ConfigOverride co = config.getConfigOverride(prop.getType().getRawClass());
/*  689 */         JsonSetter.Value setterInfo = co.getSetterInfo();
/*  690 */         if (setterInfo != null) {
/*  691 */           if (valueNulls == null) {
/*  692 */             valueNulls = setterInfo.nonDefaultValueNulls();
/*      */           }
/*  694 */           if (contentNulls == null) {
/*  695 */             contentNulls = setterInfo.nonDefaultContentNulls();
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*  700 */     if (needMerge || valueNulls == null || contentNulls == null) {
/*  701 */       JsonSetter.Value setterInfo = config.getDefaultSetterInfo();
/*  702 */       if (valueNulls == null) {
/*  703 */         valueNulls = setterInfo.nonDefaultValueNulls();
/*      */       }
/*  705 */       if (contentNulls == null) {
/*  706 */         contentNulls = setterInfo.nonDefaultContentNulls();
/*      */       }
/*      */     } 
/*  709 */     if (valueNulls != null || contentNulls != null) {
/*  710 */       metadata = metadata.withNulls(valueNulls, contentNulls);
/*      */     }
/*  712 */     return metadata;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<?> createArrayDeserializer(DeserializationContext ctxt, ArrayType type, BeanDescription beanDesc) throws JsonMappingException {
/*      */     ObjectArrayDeserializer objectArrayDeserializer;
/*      */     JsonDeserializer<?> jsonDeserializer1;
/*  726 */     DeserializationConfig config = ctxt.getConfig();
/*  727 */     JavaType elemType = type.getContentType();
/*      */ 
/*      */     
/*  730 */     JsonDeserializer<Object> contentDeser = (JsonDeserializer<Object>)elemType.getValueHandler();
/*      */     
/*  732 */     TypeDeserializer elemTypeDeser = (TypeDeserializer)elemType.getTypeHandler();
/*      */     
/*  734 */     if (elemTypeDeser == null) {
/*  735 */       elemTypeDeser = findTypeDeserializer(config, elemType);
/*      */     }
/*      */     
/*  738 */     JsonDeserializer<?> deser = _findCustomArrayDeserializer(type, config, beanDesc, elemTypeDeser, contentDeser);
/*      */     
/*  740 */     if (deser == null) {
/*  741 */       StringArrayDeserializer stringArrayDeserializer; if (contentDeser == null) {
/*  742 */         if (elemType.isPrimitive()) {
/*  743 */           deser = PrimitiveArrayDeserializers.forType(elemType.getRawClass());
/*  744 */         } else if (elemType.hasRawClass(String.class)) {
/*  745 */           stringArrayDeserializer = StringArrayDeserializer.instance;
/*      */         } 
/*      */       }
/*  748 */       if (stringArrayDeserializer == null) {
/*  749 */         objectArrayDeserializer = new ObjectArrayDeserializer((JavaType)type, contentDeser, elemTypeDeser);
/*      */       }
/*      */     } 
/*      */     
/*  753 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  754 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  755 */         jsonDeserializer1 = mod.modifyArrayDeserializer(config, type, beanDesc, (JsonDeserializer<?>)objectArrayDeserializer);
/*      */       }
/*      */     }
/*  758 */     return jsonDeserializer1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<?> createCollectionDeserializer(DeserializationContext ctxt, CollectionType type, BeanDescription beanDesc) throws JsonMappingException {
/*      */     EnumSetDeserializer enumSetDeserializer;
/*      */     CollectionDeserializer collectionDeserializer;
/*      */     JsonDeserializer<?> jsonDeserializer1;
/*  772 */     JavaType contentType = type.getContentType();
/*      */     
/*  774 */     JsonDeserializer<Object> contentDeser = (JsonDeserializer<Object>)contentType.getValueHandler();
/*  775 */     DeserializationConfig config = ctxt.getConfig();
/*      */ 
/*      */     
/*  778 */     TypeDeserializer contentTypeDeser = (TypeDeserializer)contentType.getTypeHandler();
/*      */     
/*  780 */     if (contentTypeDeser == null) {
/*  781 */       contentTypeDeser = findTypeDeserializer(config, contentType);
/*      */     }
/*      */     
/*  784 */     JsonDeserializer<?> deser = _findCustomCollectionDeserializer(type, config, beanDesc, contentTypeDeser, contentDeser);
/*      */     
/*  786 */     if (deser == null) {
/*  787 */       Class<?> collectionClass = type.getRawClass();
/*  788 */       if (contentDeser == null)
/*      */       {
/*  790 */         if (EnumSet.class.isAssignableFrom(collectionClass)) {
/*  791 */           enumSetDeserializer = new EnumSetDeserializer(contentType, null);
/*      */         }
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  805 */     if (enumSetDeserializer == null) {
/*  806 */       if (type.isInterface() || type.isAbstract()) {
/*  807 */         CollectionType implType = _mapAbstractCollectionType((JavaType)type, config);
/*  808 */         if (implType != null) {
/*  809 */           type = implType;
/*      */           
/*  811 */           beanDesc = config.introspectForCreation((JavaType)type);
/*      */         } 
/*      */       } 
/*  814 */       if (enumSetDeserializer == null) {
/*  815 */         ValueInstantiator inst = findValueInstantiator(ctxt, beanDesc);
/*  816 */         if (!inst.canCreateUsingDefault()) {
/*      */           
/*  818 */           if (type.hasRawClass(ArrayBlockingQueue.class)) {
/*  819 */             return (JsonDeserializer<?>)new ArrayBlockingQueueDeserializer((JavaType)type, contentDeser, contentTypeDeser, inst);
/*      */           }
/*      */           
/*  822 */           jsonDeserializer1 = JavaUtilCollectionsDeserializers.findForCollection(ctxt, (JavaType)type);
/*  823 */           if (jsonDeserializer1 != null) {
/*  824 */             return jsonDeserializer1;
/*      */           }
/*      */         } 
/*      */         
/*  828 */         if (contentType.hasRawClass(String.class)) {
/*      */           
/*  830 */           StringCollectionDeserializer stringCollectionDeserializer = new StringCollectionDeserializer((JavaType)type, contentDeser, inst);
/*      */         } else {
/*  832 */           collectionDeserializer = new CollectionDeserializer((JavaType)type, contentDeser, contentTypeDeser, inst);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  837 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  838 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  839 */         jsonDeserializer1 = mod.modifyCollectionDeserializer(config, type, beanDesc, (JsonDeserializer<?>)collectionDeserializer);
/*      */       }
/*      */     }
/*  842 */     return jsonDeserializer1;
/*      */   }
/*      */ 
/*      */   
/*      */   protected CollectionType _mapAbstractCollectionType(JavaType type, DeserializationConfig config) {
/*  847 */     Class<?> collectionClass = ContainerDefaultMappings.findCollectionFallback(type);
/*  848 */     if (collectionClass != null) {
/*  849 */       return (CollectionType)config.getTypeFactory()
/*  850 */         .constructSpecializedType(type, collectionClass, true);
/*      */     }
/*  852 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<?> createCollectionLikeDeserializer(DeserializationContext ctxt, CollectionLikeType type, BeanDescription beanDesc) throws JsonMappingException {
/*  861 */     JavaType contentType = type.getContentType();
/*      */     
/*  863 */     JsonDeserializer<Object> contentDeser = (JsonDeserializer<Object>)contentType.getValueHandler();
/*  864 */     DeserializationConfig config = ctxt.getConfig();
/*      */ 
/*      */     
/*  867 */     TypeDeserializer contentTypeDeser = (TypeDeserializer)contentType.getTypeHandler();
/*      */     
/*  869 */     if (contentTypeDeser == null) {
/*  870 */       contentTypeDeser = findTypeDeserializer(config, contentType);
/*      */     }
/*  872 */     JsonDeserializer<?> deser = _findCustomCollectionLikeDeserializer(type, config, beanDesc, contentTypeDeser, contentDeser);
/*      */     
/*  874 */     if (deser != null)
/*      */     {
/*  876 */       if (this._factoryConfig.hasDeserializerModifiers()) {
/*  877 */         for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  878 */           deser = mod.modifyCollectionLikeDeserializer(config, type, beanDesc, deser);
/*      */         }
/*      */       }
/*      */     }
/*  882 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<?> createMapDeserializer(DeserializationContext ctxt, MapType type, BeanDescription beanDesc) throws JsonMappingException {
/*      */     MapDeserializer mapDeserializer;
/*      */     JsonDeserializer<?> jsonDeserializer1;
/*  896 */     DeserializationConfig config = ctxt.getConfig();
/*  897 */     JavaType keyType = type.getKeyType();
/*  898 */     JavaType contentType = type.getContentType();
/*      */ 
/*      */ 
/*      */     
/*  902 */     JsonDeserializer<Object> contentDeser = (JsonDeserializer<Object>)contentType.getValueHandler();
/*      */ 
/*      */     
/*  905 */     KeyDeserializer keyDes = (KeyDeserializer)keyType.getValueHandler();
/*      */     
/*  907 */     TypeDeserializer contentTypeDeser = (TypeDeserializer)contentType.getTypeHandler();
/*      */     
/*  909 */     if (contentTypeDeser == null) {
/*  910 */       contentTypeDeser = findTypeDeserializer(config, contentType);
/*      */     }
/*      */ 
/*      */     
/*  914 */     JsonDeserializer<?> deser = _findCustomMapDeserializer(type, config, beanDesc, keyDes, contentTypeDeser, contentDeser);
/*      */ 
/*      */     
/*  917 */     if (deser == null) {
/*      */       EnumMapDeserializer enumMapDeserializer;
/*  919 */       Class<?> mapClass = type.getRawClass();
/*  920 */       if (EnumMap.class.isAssignableFrom(mapClass)) {
/*      */         ValueInstantiator inst;
/*      */ 
/*      */ 
/*      */         
/*  925 */         if (mapClass == EnumMap.class) {
/*  926 */           inst = null;
/*      */         } else {
/*  928 */           inst = findValueInstantiator(ctxt, beanDesc);
/*      */         } 
/*  930 */         if (!keyType.isEnumImplType()) {
/*  931 */           throw new IllegalArgumentException("Cannot construct EnumMap; generic (key) type not available");
/*      */         }
/*  933 */         enumMapDeserializer = new EnumMapDeserializer((JavaType)type, inst, null, contentDeser, contentTypeDeser, null);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  948 */       if (enumMapDeserializer == null) {
/*  949 */         if (type.isInterface() || type.isAbstract()) {
/*  950 */           MapType implType = _mapAbstractMapType((JavaType)type, config);
/*  951 */           if (implType != null) {
/*  952 */             type = implType;
/*  953 */             mapClass = type.getRawClass();
/*      */             
/*  955 */             beanDesc = config.introspectForCreation((JavaType)type);
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  961 */           jsonDeserializer1 = JavaUtilCollectionsDeserializers.findForMap(ctxt, (JavaType)type);
/*  962 */           if (jsonDeserializer1 != null) {
/*  963 */             return jsonDeserializer1;
/*      */           }
/*      */         } 
/*  966 */         if (jsonDeserializer1 == null) {
/*  967 */           ValueInstantiator inst = findValueInstantiator(ctxt, beanDesc);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  972 */           MapDeserializer md = new MapDeserializer((JavaType)type, inst, keyDes, contentDeser, contentTypeDeser);
/*  973 */           JsonIgnoreProperties.Value ignorals = config.getDefaultPropertyIgnorals(Map.class, beanDesc
/*  974 */               .getClassInfo());
/*      */           
/*  976 */           Set<String> ignored = (ignorals == null) ? null : ignorals.findIgnoredForDeserialization();
/*  977 */           md.setIgnorableProperties(ignored);
/*  978 */           JsonIncludeProperties.Value inclusions = config.getDefaultPropertyInclusions(Map.class, beanDesc
/*  979 */               .getClassInfo());
/*  980 */           Set<String> included = (inclusions == null) ? null : inclusions.getIncluded();
/*  981 */           md.setIncludableProperties(included);
/*  982 */           mapDeserializer = md;
/*      */         } 
/*      */       } 
/*      */     } 
/*  986 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/*  987 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/*  988 */         jsonDeserializer1 = mod.modifyMapDeserializer(config, type, beanDesc, (JsonDeserializer<?>)mapDeserializer);
/*      */       }
/*      */     }
/*  991 */     return jsonDeserializer1;
/*      */   }
/*      */ 
/*      */   
/*      */   protected MapType _mapAbstractMapType(JavaType type, DeserializationConfig config) {
/*  996 */     Class<?> mapClass = ContainerDefaultMappings.findMapFallback(type);
/*  997 */     if (mapClass != null) {
/*  998 */       return (MapType)config.getTypeFactory()
/*  999 */         .constructSpecializedType(type, mapClass, true);
/*      */     }
/* 1001 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<?> createMapLikeDeserializer(DeserializationContext ctxt, MapLikeType type, BeanDescription beanDesc) throws JsonMappingException {
/* 1010 */     JavaType keyType = type.getKeyType();
/* 1011 */     JavaType contentType = type.getContentType();
/* 1012 */     DeserializationConfig config = ctxt.getConfig();
/*      */ 
/*      */ 
/*      */     
/* 1016 */     JsonDeserializer<Object> contentDeser = (JsonDeserializer<Object>)contentType.getValueHandler();
/*      */ 
/*      */     
/* 1019 */     KeyDeserializer keyDes = (KeyDeserializer)keyType.getValueHandler();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1026 */     TypeDeserializer contentTypeDeser = (TypeDeserializer)contentType.getTypeHandler();
/*      */     
/* 1028 */     if (contentTypeDeser == null) {
/* 1029 */       contentTypeDeser = findTypeDeserializer(config, contentType);
/*      */     }
/* 1031 */     JsonDeserializer<?> deser = _findCustomMapLikeDeserializer(type, config, beanDesc, keyDes, contentTypeDeser, contentDeser);
/*      */     
/* 1033 */     if (deser != null)
/*      */     {
/* 1035 */       if (this._factoryConfig.hasDeserializerModifiers()) {
/* 1036 */         for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/* 1037 */           deser = mod.modifyMapLikeDeserializer(config, type, beanDesc, deser);
/*      */         }
/*      */       }
/*      */     }
/* 1041 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<?> createEnumDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/*      */     EnumDeserializer enumDeserializer;
/*      */     JsonDeserializer<?> jsonDeserializer1;
/* 1058 */     DeserializationConfig config = ctxt.getConfig();
/* 1059 */     Class<?> enumClass = type.getRawClass();
/*      */     
/* 1061 */     JsonDeserializer<?> deser = _findCustomEnumDeserializer(enumClass, config, beanDesc);
/*      */     
/* 1063 */     if (deser == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1069 */       if (enumClass == Enum.class) {
/* 1070 */         return AbstractDeserializer.constructForNonPOJO(beanDesc);
/*      */       }
/*      */       
/* 1073 */       ValueInstantiator valueInstantiator = _constructDefaultValueInstantiator(ctxt, beanDesc);
/*      */       
/* 1075 */       SettableBeanProperty[] creatorProps = (valueInstantiator == null) ? null : valueInstantiator.getFromObjectArguments(ctxt.getConfig());
/*      */       
/* 1077 */       for (AnnotatedMethod factory : beanDesc.getFactoryMethods()) {
/* 1078 */         if (_hasCreatorAnnotation((MapperConfig<?>)config, (Annotated)factory)) {
/* 1079 */           if (factory.getParameterCount() == 0) {
/* 1080 */             deser = EnumDeserializer.deserializerForNoArgsCreator(config, enumClass, factory);
/*      */             break;
/*      */           } 
/* 1083 */           Class<?> returnType = factory.getRawReturnType();
/*      */           
/* 1085 */           if (!returnType.isAssignableFrom(enumClass)) {
/* 1086 */             ctxt.reportBadDefinition(type, String.format("Invalid `@JsonCreator` annotated Enum factory method [%s]: needs to return compatible type", new Object[] { factory
/*      */                     
/* 1088 */                     .toString() }));
/*      */           }
/* 1090 */           deser = EnumDeserializer.deserializerForCreator(config, enumClass, factory, valueInstantiator, creatorProps, 
/*      */               
/* 1092 */               constructEnumResolver(enumClass, config, beanDesc));
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */       
/* 1098 */       if (deser == null)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 1103 */         enumDeserializer = new EnumDeserializer(constructEnumResolver(enumClass, config, beanDesc), config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_ENUMS), constructEnumNamingStrategyResolver(config, beanDesc.getClassInfo()), EnumResolver.constructUsingToString(config, beanDesc.getClassInfo()));
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1109 */     if (this._factoryConfig.hasDeserializerModifiers()) {
/* 1110 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/* 1111 */         jsonDeserializer1 = mod.modifyEnumDeserializer(config, type, beanDesc, (JsonDeserializer<?>)enumDeserializer);
/*      */       }
/*      */     }
/* 1114 */     return jsonDeserializer1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<?> createTreeDeserializer(DeserializationConfig config, JavaType nodeType, BeanDescription beanDesc) throws JsonMappingException {
/* 1123 */     Class<? extends JsonNode> nodeClass = nodeType.getRawClass();
/*      */     
/* 1125 */     JsonDeserializer<?> custom = _findCustomTreeNodeDeserializer(nodeClass, config, beanDesc);
/*      */     
/* 1127 */     if (custom != null) {
/* 1128 */       return custom;
/*      */     }
/* 1130 */     return JsonNodeDeserializer.getDeserializer(nodeClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<?> createReferenceDeserializer(DeserializationContext ctxt, ReferenceType type, BeanDescription beanDesc) throws JsonMappingException {
/* 1138 */     JavaType contentType = type.getContentType();
/*      */     
/* 1140 */     JsonDeserializer<Object> contentDeser = (JsonDeserializer<Object>)contentType.getValueHandler();
/* 1141 */     DeserializationConfig config = ctxt.getConfig();
/*      */     
/* 1143 */     TypeDeserializer contentTypeDeser = (TypeDeserializer)contentType.getTypeHandler();
/* 1144 */     if (contentTypeDeser == null) {
/* 1145 */       contentTypeDeser = findTypeDeserializer(config, contentType);
/*      */     }
/* 1147 */     JsonDeserializer<?> deser = _findCustomReferenceDeserializer(type, config, beanDesc, contentTypeDeser, contentDeser);
/*      */ 
/*      */     
/* 1150 */     if (deser == null)
/*      */     {
/* 1152 */       if (type.isTypeOrSubTypeOf(AtomicReference.class)) {
/* 1153 */         ValueInstantiator inst; Class<?> rawType = type.getRawClass();
/*      */         
/* 1155 */         if (rawType == AtomicReference.class) {
/* 1156 */           inst = null;
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 1162 */           inst = findValueInstantiator(ctxt, beanDesc);
/*      */         } 
/* 1164 */         return (JsonDeserializer<?>)new AtomicReferenceDeserializer((JavaType)type, inst, contentTypeDeser, contentDeser);
/*      */       } 
/*      */     }
/* 1167 */     if (deser != null)
/*      */     {
/* 1169 */       if (this._factoryConfig.hasDeserializerModifiers()) {
/* 1170 */         for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/* 1171 */           deser = mod.modifyReferenceDeserializer(config, type, beanDesc, deser);
/*      */         }
/*      */       }
/*      */     }
/* 1175 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeDeserializer findTypeDeserializer(DeserializationConfig config, JavaType baseType) throws JsonMappingException {
/* 1189 */     BeanDescription bean = config.introspectClassAnnotations(baseType.getRawClass());
/* 1190 */     AnnotatedClass ac = bean.getClassInfo();
/* 1191 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 1192 */     TypeResolverBuilder<?> b = ai.findTypeResolver((MapperConfig)config, ac, baseType);
/*      */ 
/*      */ 
/*      */     
/* 1196 */     if (b == null) {
/* 1197 */       b = config.getDefaultTyper(baseType);
/* 1198 */       if (b == null) {
/* 1199 */         return null;
/*      */       }
/*      */     } 
/* 1202 */     Collection<NamedType> subtypes = config.getSubtypeResolver().collectAndResolveSubtypesByTypeId((MapperConfig)config, ac);
/*      */ 
/*      */ 
/*      */     
/* 1206 */     if (b.getDefaultImpl() == null && baseType.isAbstract()) {
/* 1207 */       JavaType defaultType = mapAbstractType(config, baseType);
/*      */ 
/*      */       
/* 1210 */       if (defaultType != null && !defaultType.hasRawClass(baseType.getRawClass())) {
/* 1211 */         b = b.withDefaultImpl(defaultType.getRawClass());
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/* 1217 */       return b.buildTypeDeserializer(config, baseType, subtypes);
/* 1218 */     } catch (IllegalArgumentException|IllegalStateException e0) {
/* 1219 */       throw InvalidDefinitionException.from((JsonParser)null, 
/* 1220 */           ClassUtil.exceptionMessage(e0), baseType)
/* 1221 */         .withCause(e0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<?> findOptionalStdDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/* 1234 */     return OptionalHandlerFactory.instance.findDeserializer(type, ctxt.getConfig(), beanDesc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public KeyDeserializer createKeyDeserializer(DeserializationContext ctxt, JavaType type) throws JsonMappingException {
/* 1248 */     DeserializationConfig config = ctxt.getConfig();
/* 1249 */     BeanDescription beanDesc = config.introspectClassAnnotations(type);
/*      */ 
/*      */     
/* 1252 */     KeyDeserializer deser = findKeyDeserializerFromAnnotation(ctxt, (Annotated)beanDesc.getClassInfo());
/*      */     
/* 1254 */     if (deser == null && this._factoryConfig.hasKeyDeserializers()) {
/* 1255 */       for (KeyDeserializers d : this._factoryConfig.keyDeserializers()) {
/* 1256 */         deser = d.findKeyDeserializer(type, config, beanDesc);
/* 1257 */         if (deser != null) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1264 */     if (deser == null) {
/* 1265 */       if (type.isEnumType()) {
/* 1266 */         deser = _createEnumKeyDeserializer(ctxt, type);
/*      */       } else {
/* 1268 */         deser = StdKeyDeserializers.findStringBasedKeyDeserializer(config, type);
/*      */       } 
/*      */     }
/*      */     
/* 1272 */     if (deser != null && 
/* 1273 */       this._factoryConfig.hasDeserializerModifiers()) {
/* 1274 */       for (BeanDeserializerModifier mod : this._factoryConfig.deserializerModifiers()) {
/* 1275 */         deser = mod.modifyKeyDeserializer(config, type, deser);
/*      */       }
/*      */     }
/*      */     
/* 1279 */     return deser;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private KeyDeserializer _createEnumKeyDeserializer(DeserializationContext ctxt, JavaType type) throws JsonMappingException {
/* 1286 */     DeserializationConfig config = ctxt.getConfig();
/* 1287 */     Class<?> enumClass = type.getRawClass();
/*      */     
/* 1289 */     BeanDescription beanDesc = config.introspect(type);
/*      */     
/* 1291 */     KeyDeserializer des = findKeyDeserializerFromAnnotation(ctxt, (Annotated)beanDesc.getClassInfo());
/* 1292 */     if (des != null) {
/* 1293 */       return des;
/*      */     }
/*      */     
/* 1296 */     JsonDeserializer<?> custom = _findCustomEnumDeserializer(enumClass, config, beanDesc);
/* 1297 */     if (custom != null) {
/* 1298 */       return StdKeyDeserializers.constructDelegatingKeyDeserializer(config, type, custom);
/*      */     }
/* 1300 */     JsonDeserializer<?> valueDesForKey = findDeserializerFromAnnotation(ctxt, (Annotated)beanDesc.getClassInfo());
/* 1301 */     if (valueDesForKey != null) {
/* 1302 */       return StdKeyDeserializers.constructDelegatingKeyDeserializer(config, type, valueDesForKey);
/*      */     }
/*      */     
/* 1305 */     EnumResolver enumRes = constructEnumResolver(enumClass, config, beanDesc);
/* 1306 */     EnumResolver byEnumNamingResolver = constructEnumNamingStrategyResolver(config, beanDesc.getClassInfo());
/* 1307 */     EnumResolver byToStringResolver = EnumResolver.constructUsingToString(config, beanDesc.getClassInfo());
/* 1308 */     EnumResolver byIndexResolver = EnumResolver.constructUsingIndex(config, beanDesc.getClassInfo());
/*      */ 
/*      */     
/* 1311 */     for (AnnotatedMethod factory : beanDesc.getFactoryMethods()) {
/* 1312 */       if (_hasCreatorAnnotation((MapperConfig<?>)config, (Annotated)factory)) {
/* 1313 */         int argCount = factory.getParameterCount();
/* 1314 */         if (argCount == 1) {
/* 1315 */           Class<?> returnType = factory.getRawReturnType();
/*      */           
/* 1317 */           if (returnType.isAssignableFrom(enumClass)) {
/*      */             
/* 1319 */             if (factory.getRawParameterType(0) != String.class) {
/*      */               continue;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1326 */             if (config.canOverrideAccessModifiers()) {
/* 1327 */               ClassUtil.checkAndFixAccess(factory.getMember(), ctxt
/* 1328 */                   .isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*      */             }
/* 1330 */             return StdKeyDeserializers.constructEnumKeyDeserializer(enumRes, factory, byEnumNamingResolver, byToStringResolver, byIndexResolver);
/*      */           } 
/*      */         } 
/* 1333 */         throw new IllegalArgumentException("Unsuitable method (" + factory + ") decorated with @JsonCreator (for Enum type " + enumClass
/* 1334 */             .getName() + ")");
/*      */       } 
/*      */     } 
/*      */     
/* 1338 */     return StdKeyDeserializers.constructEnumKeyDeserializer(enumRes, byEnumNamingResolver, byToStringResolver, byIndexResolver);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasExplicitDeserializerFor(DeserializationConfig config, Class<?> valueType) {
/* 1355 */     while (valueType.isArray()) {
/* 1356 */       valueType = valueType.getComponentType();
/*      */     }
/*      */ 
/*      */     
/* 1360 */     if (Enum.class.isAssignableFrom(valueType)) {
/* 1361 */       return true;
/*      */     }
/*      */     
/* 1364 */     String clsName = valueType.getName();
/* 1365 */     if (clsName.startsWith("java.")) {
/* 1366 */       if (Collection.class.isAssignableFrom(valueType)) {
/* 1367 */         return true;
/*      */       }
/* 1369 */       if (Map.class.isAssignableFrom(valueType)) {
/* 1370 */         return true;
/*      */       }
/* 1372 */       if (Number.class.isAssignableFrom(valueType)) {
/* 1373 */         return (NumberDeserializers.find(valueType, clsName) != null);
/*      */       }
/* 1375 */       if (JdkDeserializers.hasDeserializerFor(valueType) || valueType == CLASS_STRING || valueType == Boolean.class || valueType == EnumMap.class || valueType == AtomicReference.class)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1381 */         return true;
/*      */       }
/* 1383 */       if (DateDeserializers.hasDeserializerFor(valueType))
/* 1384 */         return true; 
/*      */     } else {
/* 1386 */       if (clsName.startsWith("com.fasterxml.")) {
/* 1387 */         return (JsonNode.class.isAssignableFrom(valueType) || valueType == TokenBuffer.class);
/*      */       }
/*      */       
/* 1390 */       return OptionalHandlerFactory.instance.hasDeserializerFor(valueType);
/*      */     } 
/* 1392 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeDeserializer findPropertyTypeDeserializer(DeserializationConfig config, JavaType baseType, AnnotatedMember annotated) throws JsonMappingException {
/* 1418 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 1419 */     TypeResolverBuilder<?> b = ai.findPropertyTypeResolver((MapperConfig)config, annotated, baseType);
/*      */     
/* 1421 */     if (b == null) {
/* 1422 */       return findTypeDeserializer(config, baseType);
/*      */     }
/*      */     
/* 1425 */     Collection<NamedType> subtypes = config.getSubtypeResolver().collectAndResolveSubtypesByTypeId((MapperConfig)config, annotated, baseType);
/*      */     
/*      */     try {
/* 1428 */       return b.buildTypeDeserializer(config, baseType, subtypes);
/* 1429 */     } catch (IllegalArgumentException|IllegalStateException e0) {
/* 1430 */       throw InvalidDefinitionException.from((JsonParser)null, 
/* 1431 */           ClassUtil.exceptionMessage(e0), baseType)
/* 1432 */         .withCause(e0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeDeserializer findPropertyContentTypeDeserializer(DeserializationConfig config, JavaType containerType, AnnotatedMember propertyEntity) throws JsonMappingException {
/* 1451 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 1452 */     TypeResolverBuilder<?> b = ai.findPropertyContentTypeResolver((MapperConfig)config, propertyEntity, containerType);
/* 1453 */     JavaType contentType = containerType.getContentType();
/*      */     
/* 1455 */     if (b == null) {
/* 1456 */       return findTypeDeserializer(config, contentType);
/*      */     }
/*      */     
/* 1459 */     Collection<NamedType> subtypes = config.getSubtypeResolver().collectAndResolveSubtypesByTypeId((MapperConfig)config, propertyEntity, contentType);
/*      */     
/* 1461 */     return b.buildTypeDeserializer(config, contentType, subtypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<?> findDefaultDeserializer(DeserializationContext ctxt, JavaType type, BeanDescription beanDesc) throws JsonMappingException {
/* 1475 */     Class<?> rawType = type.getRawClass();
/*      */     
/* 1477 */     if (rawType == CLASS_OBJECT || rawType == CLASS_SERIALIZABLE) {
/*      */       JavaType lt, mt;
/* 1479 */       DeserializationConfig config = ctxt.getConfig();
/*      */ 
/*      */       
/* 1482 */       if (this._factoryConfig.hasAbstractTypeResolvers()) {
/* 1483 */         lt = _findRemappedType(config, List.class);
/* 1484 */         mt = _findRemappedType(config, Map.class);
/*      */       } else {
/* 1486 */         lt = mt = null;
/*      */       } 
/* 1488 */       return (JsonDeserializer<?>)new UntypedObjectDeserializer(lt, mt);
/*      */     } 
/*      */     
/* 1491 */     if (rawType == CLASS_STRING || rawType == CLASS_CHAR_SEQUENCE) {
/* 1492 */       return (JsonDeserializer<?>)StringDeserializer.instance;
/*      */     }
/* 1494 */     if (rawType == CLASS_ITERABLE) {
/*      */       
/* 1496 */       TypeFactory tf = ctxt.getTypeFactory();
/* 1497 */       JavaType[] tps = tf.findTypeParameters(type, CLASS_ITERABLE);
/* 1498 */       JavaType elemType = (tps == null || tps.length != 1) ? TypeFactory.unknownType() : tps[0];
/* 1499 */       CollectionType ct = tf.constructCollectionType(Collection.class, elemType);
/*      */       
/* 1501 */       return createCollectionDeserializer(ctxt, ct, beanDesc);
/*      */     } 
/* 1503 */     if (rawType == CLASS_MAP_ENTRY) {
/*      */       
/* 1505 */       JavaType kt = type.containedTypeOrUnknown(0);
/* 1506 */       JavaType vt = type.containedTypeOrUnknown(1);
/* 1507 */       TypeDeserializer vts = (TypeDeserializer)vt.getTypeHandler();
/* 1508 */       if (vts == null) {
/* 1509 */         vts = findTypeDeserializer(ctxt.getConfig(), vt);
/*      */       }
/* 1511 */       JsonDeserializer<Object> valueDeser = (JsonDeserializer<Object>)vt.getValueHandler();
/* 1512 */       KeyDeserializer keyDes = (KeyDeserializer)kt.getValueHandler();
/* 1513 */       return (JsonDeserializer<?>)new MapEntryDeserializer(type, keyDes, valueDeser, vts);
/*      */     } 
/* 1515 */     String clsName = rawType.getName();
/* 1516 */     if (rawType.isPrimitive() || clsName.startsWith("java.")) {
/*      */       
/* 1518 */       JsonDeserializer<?> jsonDeserializer = NumberDeserializers.find(rawType, clsName);
/* 1519 */       if (jsonDeserializer == null) {
/* 1520 */         jsonDeserializer = DateDeserializers.find(rawType, clsName);
/*      */       }
/* 1522 */       if (jsonDeserializer != null) {
/* 1523 */         return jsonDeserializer;
/*      */       }
/*      */     } 
/*      */     
/* 1527 */     if (rawType == TokenBuffer.class) {
/* 1528 */       return (JsonDeserializer<?>)new TokenBufferDeserializer();
/*      */     }
/* 1530 */     JsonDeserializer<?> deser = findOptionalStdDeserializer(ctxt, type, beanDesc);
/* 1531 */     if (deser != null) {
/* 1532 */       return deser;
/*      */     }
/* 1534 */     return JdkDeserializers.find(ctxt, rawType, clsName);
/*      */   }
/*      */   
/*      */   protected JavaType _findRemappedType(DeserializationConfig config, Class<?> rawType) throws JsonMappingException {
/* 1538 */     JavaType type = mapAbstractType(config, config.constructType(rawType));
/* 1539 */     return (type == null || type.hasRawClass(rawType)) ? null : type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<?> _findCustomTreeNodeDeserializer(Class<? extends JsonNode> type, DeserializationConfig config, BeanDescription beanDesc) throws JsonMappingException {
/* 1552 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 1553 */       JsonDeserializer<?> deser = d.findTreeNodeDeserializer(type, config, beanDesc);
/* 1554 */       if (deser != null) {
/* 1555 */         return deser;
/*      */       }
/*      */     } 
/* 1558 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<?> _findCustomReferenceDeserializer(ReferenceType type, DeserializationConfig config, BeanDescription beanDesc, TypeDeserializer contentTypeDeserializer, JsonDeserializer<?> contentDeserializer) throws JsonMappingException {
/* 1566 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 1567 */       JsonDeserializer<?> deser = d.findReferenceDeserializer(type, config, beanDesc, contentTypeDeserializer, contentDeserializer);
/*      */       
/* 1569 */       if (deser != null) {
/* 1570 */         return deser;
/*      */       }
/*      */     } 
/* 1573 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> _findCustomBeanDeserializer(JavaType type, DeserializationConfig config, BeanDescription beanDesc) throws JsonMappingException {
/* 1581 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 1582 */       JsonDeserializer<?> deser = d.findBeanDeserializer(type, config, beanDesc);
/* 1583 */       if (deser != null) {
/* 1584 */         return (JsonDeserializer)deser;
/*      */       }
/*      */     } 
/* 1587 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<?> _findCustomArrayDeserializer(ArrayType type, DeserializationConfig config, BeanDescription beanDesc, TypeDeserializer elementTypeDeserializer, JsonDeserializer<?> elementDeserializer) throws JsonMappingException {
/* 1595 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 1596 */       JsonDeserializer<?> deser = d.findArrayDeserializer(type, config, beanDesc, elementTypeDeserializer, elementDeserializer);
/*      */       
/* 1598 */       if (deser != null) {
/* 1599 */         return deser;
/*      */       }
/*      */     } 
/* 1602 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<?> _findCustomCollectionDeserializer(CollectionType type, DeserializationConfig config, BeanDescription beanDesc, TypeDeserializer elementTypeDeserializer, JsonDeserializer<?> elementDeserializer) throws JsonMappingException {
/* 1610 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 1611 */       JsonDeserializer<?> deser = d.findCollectionDeserializer(type, config, beanDesc, elementTypeDeserializer, elementDeserializer);
/*      */       
/* 1613 */       if (deser != null) {
/* 1614 */         return deser;
/*      */       }
/*      */     } 
/* 1617 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<?> _findCustomCollectionLikeDeserializer(CollectionLikeType type, DeserializationConfig config, BeanDescription beanDesc, TypeDeserializer elementTypeDeserializer, JsonDeserializer<?> elementDeserializer) throws JsonMappingException {
/* 1625 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 1626 */       JsonDeserializer<?> deser = d.findCollectionLikeDeserializer(type, config, beanDesc, elementTypeDeserializer, elementDeserializer);
/*      */       
/* 1628 */       if (deser != null) {
/* 1629 */         return deser;
/*      */       }
/*      */     } 
/* 1632 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<?> _findCustomEnumDeserializer(Class<?> type, DeserializationConfig config, BeanDescription beanDesc) throws JsonMappingException {
/* 1639 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 1640 */       JsonDeserializer<?> deser = d.findEnumDeserializer(type, config, beanDesc);
/* 1641 */       if (deser != null) {
/* 1642 */         return deser;
/*      */       }
/*      */     } 
/* 1645 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<?> _findCustomMapDeserializer(MapType type, DeserializationConfig config, BeanDescription beanDesc, KeyDeserializer keyDeserializer, TypeDeserializer elementTypeDeserializer, JsonDeserializer<?> elementDeserializer) throws JsonMappingException {
/* 1654 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 1655 */       JsonDeserializer<?> deser = d.findMapDeserializer(type, config, beanDesc, keyDeserializer, elementTypeDeserializer, elementDeserializer);
/*      */       
/* 1657 */       if (deser != null) {
/* 1658 */         return deser;
/*      */       }
/*      */     } 
/* 1661 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<?> _findCustomMapLikeDeserializer(MapLikeType type, DeserializationConfig config, BeanDescription beanDesc, KeyDeserializer keyDeserializer, TypeDeserializer elementTypeDeserializer, JsonDeserializer<?> elementDeserializer) throws JsonMappingException {
/* 1670 */     for (Deserializers d : this._factoryConfig.deserializers()) {
/* 1671 */       JsonDeserializer<?> deser = d.findMapLikeDeserializer(type, config, beanDesc, keyDeserializer, elementTypeDeserializer, elementDeserializer);
/*      */       
/* 1673 */       if (deser != null) {
/* 1674 */         return deser;
/*      */       }
/*      */     } 
/* 1677 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> findDeserializerFromAnnotation(DeserializationContext ctxt, Annotated ann) throws JsonMappingException {
/* 1698 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 1699 */     if (intr != null) {
/* 1700 */       Object deserDef = intr.findDeserializer(ann);
/* 1701 */       if (deserDef != null) {
/* 1702 */         return ctxt.deserializerInstance(ann, deserDef);
/*      */       }
/*      */     } 
/* 1705 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected KeyDeserializer findKeyDeserializerFromAnnotation(DeserializationContext ctxt, Annotated ann) throws JsonMappingException {
/* 1717 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 1718 */     if (intr != null) {
/* 1719 */       Object deserDef = intr.findKeyDeserializer(ann);
/* 1720 */       if (deserDef != null) {
/* 1721 */         return ctxt.keyDeserializerInstance(ann, deserDef);
/*      */       }
/*      */     } 
/* 1724 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonDeserializer<Object> findContentDeserializerFromAnnotation(DeserializationContext ctxt, Annotated ann) throws JsonMappingException {
/* 1734 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 1735 */     if (intr != null) {
/* 1736 */       Object deserDef = intr.findContentDeserializer(ann);
/* 1737 */       if (deserDef != null) {
/* 1738 */         return ctxt.deserializerInstance(ann, deserDef);
/*      */       }
/*      */     } 
/* 1741 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType resolveMemberAndTypeAnnotations(DeserializationContext ctxt, AnnotatedMember member, JavaType type) throws JsonMappingException {
/*      */     MapLikeType mapLikeType;
/* 1757 */     AnnotationIntrospector intr = ctxt.getAnnotationIntrospector();
/* 1758 */     if (intr == null) {
/* 1759 */       return type;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1765 */     if (type.isMapLikeType()) {
/* 1766 */       JavaType keyType = type.getKeyType();
/* 1767 */       if (keyType != null) {
/* 1768 */         Object kdDef = intr.findKeyDeserializer((Annotated)member);
/* 1769 */         KeyDeserializer kd = ctxt.keyDeserializerInstance((Annotated)member, kdDef);
/* 1770 */         if (kd != null) {
/* 1771 */           mapLikeType = ((MapLikeType)type).withKeyValueHandler(kd);
/* 1772 */           keyType = mapLikeType.getKeyType();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1777 */     if (mapLikeType.hasContentType()) {
/* 1778 */       Object cdDef = intr.findContentDeserializer((Annotated)member);
/* 1779 */       JsonDeserializer<?> cd = ctxt.deserializerInstance((Annotated)member, cdDef);
/* 1780 */       if (cd != null) {
/* 1781 */         javaType = mapLikeType.withContentValueHandler(cd);
/*      */       }
/* 1783 */       TypeDeserializer contentTypeDeser = findPropertyContentTypeDeserializer(ctxt
/* 1784 */           .getConfig(), javaType, member);
/* 1785 */       if (contentTypeDeser != null) {
/* 1786 */         javaType = javaType.withContentTypeHandler(contentTypeDeser);
/*      */       }
/*      */     } 
/* 1789 */     TypeDeserializer valueTypeDeser = findPropertyTypeDeserializer(ctxt.getConfig(), javaType, member);
/*      */     
/* 1791 */     if (valueTypeDeser != null) {
/* 1792 */       javaType = javaType.withTypeHandler(valueTypeDeser);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1800 */     JavaType javaType = intr.refineDeserializationType((MapperConfig)ctxt.getConfig(), (Annotated)member, javaType);
/* 1801 */     return javaType;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected EnumResolver constructEnumResolver(Class<?> enumClass, DeserializationConfig config, BeanDescription beanDesc) {
/* 1807 */     AnnotatedMember jvAcc = beanDesc.findJsonValueAccessor();
/* 1808 */     if (jvAcc != null) {
/* 1809 */       if (config.canOverrideAccessModifiers()) {
/* 1810 */         ClassUtil.checkAndFixAccess(jvAcc.getMember(), config
/* 1811 */             .isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*      */       }
/* 1813 */       return EnumResolver.constructUsingMethod(config, beanDesc.getClassInfo(), jvAcc);
/*      */     } 
/* 1815 */     return EnumResolver.constructFor(config, beanDesc.getClassInfo());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected EnumResolver constructEnumNamingStrategyResolver(DeserializationConfig config, AnnotatedClass annotatedClass) {
/* 1827 */     Object namingDef = config.getAnnotationIntrospector().findEnumNamingStrategy((MapperConfig)config, annotatedClass);
/* 1828 */     EnumNamingStrategy enumNamingStrategy = EnumNamingStrategyFactory.createEnumNamingStrategyInstance(namingDef, config
/* 1829 */         .canOverrideAccessModifiers(), config.getEnumNamingStrategy());
/* 1830 */     return (enumNamingStrategy == null) ? null : 
/* 1831 */       EnumResolver.constructUsingEnumNamingStrategy(config, annotatedClass, enumNamingStrategy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected EnumResolver constructEnumNamingStrategyResolver(DeserializationConfig config, Class<?> enumClass, AnnotatedClass annotatedClass) {
/* 1844 */     Object namingDef = config.getAnnotationIntrospector().findEnumNamingStrategy((MapperConfig)config, annotatedClass);
/* 1845 */     EnumNamingStrategy enumNamingStrategy = EnumNamingStrategyFactory.createEnumNamingStrategyInstance(namingDef, config
/* 1846 */         .canOverrideAccessModifiers(), config.getEnumNamingStrategy());
/* 1847 */     return (enumNamingStrategy == null) ? null : 
/* 1848 */       EnumResolver.constructUsingEnumNamingStrategy(config, enumClass, enumNamingStrategy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _hasCreatorAnnotation(MapperConfig<?> config, Annotated ann) {
/* 1856 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 1857 */     if (intr != null) {
/* 1858 */       JsonCreator.Mode mode = intr.findCreatorAnnotation(config, ann);
/* 1859 */       return (mode != null && mode != JsonCreator.Mode.DISABLED);
/*      */     } 
/* 1861 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static class ContainerDefaultMappings
/*      */   {
/*      */     static final HashMap<String, Class<? extends Collection>> _collectionFallbacks;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static final HashMap<String, Class<? extends Map>> _mapFallbacks;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     static {
/* 1884 */       HashMap<String, Class<? extends Collection>> hashMap = new HashMap<>();
/*      */       
/* 1886 */       Class<ArrayList> clazz1 = ArrayList.class;
/* 1887 */       Class<HashSet> clazz2 = HashSet.class;
/*      */       
/* 1889 */       hashMap.put(Collection.class.getName(), clazz1);
/* 1890 */       hashMap.put(List.class.getName(), clazz1);
/* 1891 */       hashMap.put(Set.class.getName(), clazz2);
/* 1892 */       hashMap.put(SortedSet.class.getName(), TreeSet.class);
/* 1893 */       hashMap.put(Queue.class.getName(), LinkedList.class);
/*      */ 
/*      */       
/* 1896 */       hashMap.put(AbstractList.class.getName(), clazz1);
/* 1897 */       hashMap.put(AbstractSet.class.getName(), clazz2);
/*      */ 
/*      */       
/* 1900 */       hashMap.put(Deque.class.getName(), LinkedList.class);
/* 1901 */       hashMap.put(NavigableSet.class.getName(), TreeSet.class);
/*      */ 
/*      */       
/* 1904 */       hashMap.put("java.util.SequencedCollection", clazz1);
/* 1905 */       hashMap.put("java.util.SequencedSet", LinkedHashSet.class);
/*      */       
/* 1907 */       _collectionFallbacks = hashMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1915 */       HashMap<String, Class<? extends Map>> fallbacks = new HashMap<>();
/*      */       
/* 1917 */       Class<LinkedHashMap> clazz = LinkedHashMap.class;
/* 1918 */       fallbacks.put(Map.class.getName(), clazz);
/* 1919 */       fallbacks.put(AbstractMap.class.getName(), clazz);
/* 1920 */       fallbacks.put(ConcurrentMap.class.getName(), ConcurrentHashMap.class);
/* 1921 */       fallbacks.put(SortedMap.class.getName(), TreeMap.class);
/*      */       
/* 1923 */       fallbacks.put(NavigableMap.class.getName(), TreeMap.class);
/* 1924 */       fallbacks.put(ConcurrentNavigableMap.class.getName(), ConcurrentSkipListMap.class);
/*      */ 
/*      */ 
/*      */       
/* 1928 */       fallbacks.put("java.util.SequencedMap", LinkedHashMap.class);
/*      */       
/* 1930 */       _mapFallbacks = fallbacks;
/*      */     }
/*      */     
/*      */     public static Class<?> findCollectionFallback(JavaType type) {
/* 1934 */       return _collectionFallbacks.get(type.getRawClass().getName());
/*      */     }
/*      */     
/*      */     public static Class<?> findMapFallback(JavaType type) {
/* 1938 */       return _mapFallbacks.get(type.getRawClass().getName());
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\BasicDeserializerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */