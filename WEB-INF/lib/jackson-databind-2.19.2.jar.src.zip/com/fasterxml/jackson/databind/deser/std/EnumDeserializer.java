/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.CompactStringObjectMap;
/*     */ import com.fasterxml.jackson.databind.util.EnumResolver;
/*     */ import java.io.IOException;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class EnumDeserializer
/*     */   extends StdScalarDeserializer<Object>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected Object[] _enumsByIndex;
/*     */   private final Enum<?> _enumDefaultValue;
/*     */   protected final CompactStringObjectMap _lookupByName;
/*     */   protected volatile CompactStringObjectMap _lookupByToString;
/*     */   protected final Boolean _caseInsensitive;
/*     */   private Boolean _useDefaultValueForUnknownEnum;
/*     */   private Boolean _useNullForUnknownEnum;
/*     */   protected final boolean _isFromIntValue;
/*     */   protected final CompactStringObjectMap _lookupByEnumNaming;
/*     */   
/*     */   @Deprecated
/*     */   public EnumDeserializer(EnumResolver byNameResolver, Boolean caseInsensitive) {
/*  85 */     this(byNameResolver, Boolean.TRUE.equals(caseInsensitive), (EnumResolver)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EnumDeserializer(EnumResolver byNameResolver, boolean caseInsensitive, EnumResolver byEnumNamingResolver) {
/*  96 */     super(byNameResolver.getEnumClass());
/*  97 */     this._lookupByName = byNameResolver.constructLookup();
/*  98 */     this._enumsByIndex = (Object[])byNameResolver.getRawEnums();
/*  99 */     this._enumDefaultValue = byNameResolver.getDefaultValue();
/* 100 */     this._caseInsensitive = Boolean.valueOf(caseInsensitive);
/* 101 */     this._isFromIntValue = byNameResolver.isFromIntValue();
/* 102 */     this._lookupByEnumNaming = (byEnumNamingResolver == null) ? null : byEnumNamingResolver.constructLookup();
/* 103 */     this._lookupByToString = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumDeserializer(EnumResolver byNameResolver, boolean caseInsensitive, EnumResolver byEnumNamingResolver, EnumResolver toStringResolver) {
/* 112 */     super(byNameResolver.getEnumClass());
/* 113 */     this._lookupByName = byNameResolver.constructLookup();
/* 114 */     this._enumsByIndex = (Object[])byNameResolver.getRawEnums();
/* 115 */     this._enumDefaultValue = byNameResolver.getDefaultValue();
/* 116 */     this._caseInsensitive = Boolean.valueOf(caseInsensitive);
/* 117 */     this._isFromIntValue = byNameResolver.isFromIntValue();
/* 118 */     this._lookupByEnumNaming = (byEnumNamingResolver == null) ? null : byEnumNamingResolver.constructLookup();
/* 119 */     this._lookupByToString = (toStringResolver == null) ? null : toStringResolver.constructLookup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected EnumDeserializer(EnumDeserializer base, Boolean caseInsensitive, Boolean useDefaultValueForUnknownEnum, Boolean useNullForUnknownEnum) {
/* 128 */     super(base);
/* 129 */     this._lookupByName = base._lookupByName;
/* 130 */     this._enumsByIndex = base._enumsByIndex;
/* 131 */     this._enumDefaultValue = base._enumDefaultValue;
/* 132 */     this._caseInsensitive = Boolean.valueOf(Boolean.TRUE.equals(caseInsensitive));
/* 133 */     this._isFromIntValue = base._isFromIntValue;
/* 134 */     this._useDefaultValueForUnknownEnum = useDefaultValueForUnknownEnum;
/* 135 */     this._useNullForUnknownEnum = useNullForUnknownEnum;
/* 136 */     this._lookupByEnumNaming = base._lookupByEnumNaming;
/* 137 */     this._lookupByToString = base._lookupByToString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected EnumDeserializer(EnumDeserializer base, Boolean caseInsensitive) {
/* 146 */     this(base, caseInsensitive, (Boolean)null, (Boolean)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static JsonDeserializer<?> deserializerForCreator(DeserializationConfig config, Class<?> enumClass, AnnotatedMethod factory, ValueInstantiator valueInstantiator, SettableBeanProperty[] creatorProps) {
/* 162 */     return deserializerForCreator(config, enumClass, factory, valueInstantiator, creatorProps, (EnumResolver)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonDeserializer<?> deserializerForCreator(DeserializationConfig config, Class<?> enumClass, AnnotatedMethod factory, ValueInstantiator valueInstantiator, SettableBeanProperty[] creatorProps, EnumResolver byNameResolver) {
/* 179 */     if (config.canOverrideAccessModifiers()) {
/* 180 */       ClassUtil.checkAndFixAccess(factory.getMember(), config
/* 181 */           .isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */     }
/* 183 */     return new FactoryBasedEnumDeserializer(enumClass, factory, factory.getParameterType(0), valueInstantiator, creatorProps, byNameResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonDeserializer<?> deserializerForNoArgsCreator(DeserializationConfig config, Class<?> enumClass, AnnotatedMethod factory) {
/* 198 */     if (config.canOverrideAccessModifiers()) {
/* 199 */       ClassUtil.checkAndFixAccess(factory.getMember(), config
/* 200 */           .isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */     }
/* 202 */     return new FactoryBasedEnumDeserializer(enumClass, factory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumDeserializer withResolved(Boolean caseInsensitive, Boolean useDefaultValueForUnknownEnum, Boolean useNullForUnknownEnum) {
/* 210 */     if (Objects.equals(this._caseInsensitive, caseInsensitive) && 
/* 211 */       Objects.equals(this._useDefaultValueForUnknownEnum, useDefaultValueForUnknownEnum) && 
/* 212 */       Objects.equals(this._useNullForUnknownEnum, useNullForUnknownEnum)) {
/* 213 */       return this;
/*     */     }
/* 215 */     return new EnumDeserializer(this, caseInsensitive, useDefaultValueForUnknownEnum, useNullForUnknownEnum);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public EnumDeserializer withResolved(Boolean caseInsensitive) {
/* 224 */     return withResolved(caseInsensitive, this._useDefaultValueForUnknownEnum, this._useNullForUnknownEnum);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 233 */     Boolean caseInsensitive = Optional.<Boolean>ofNullable(findFormatFeature(ctxt, property, handledType(), JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)).orElse(this._caseInsensitive);
/*     */     
/* 235 */     Boolean useDefaultValueForUnknownEnum = Optional.<Boolean>ofNullable(findFormatFeature(ctxt, property, handledType(), JsonFormat.Feature.READ_UNKNOWN_ENUM_VALUES_USING_DEFAULT_VALUE)).orElse(this._useDefaultValueForUnknownEnum);
/*     */     
/* 237 */     Boolean useNullForUnknownEnum = Optional.<Boolean>ofNullable(findFormatFeature(ctxt, property, handledType(), JsonFormat.Feature.READ_UNKNOWN_ENUM_VALUES_AS_NULL)).orElse(this._useNullForUnknownEnum);
/*     */     
/* 239 */     return withResolved(caseInsensitive, useDefaultValueForUnknownEnum, useNullForUnknownEnum);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/* 253 */     return true;
/*     */   }
/*     */   
/*     */   public LogicalType logicalType() {
/* 257 */     return LogicalType.Enum;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/* 262 */     return this._enumDefaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 271 */     if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 272 */       return _fromString(p, ctxt, p.getText());
/*     */     }
/*     */ 
/*     */     
/* 276 */     if (p.hasToken(JsonToken.VALUE_NUMBER_INT)) {
/*     */ 
/*     */       
/* 279 */       if (this._isFromIntValue)
/*     */       {
/*     */         
/* 282 */         return _fromString(p, ctxt, p.getText());
/*     */       }
/* 284 */       return _fromInteger(p, ctxt, p.getIntValue());
/*     */     } 
/*     */     
/* 287 */     if (p.isExpectedStartObjectToken()) {
/* 288 */       return _fromString(p, ctxt, ctxt
/* 289 */           .extractScalarFromObject(p, this, this._valueClass));
/*     */     }
/* 291 */     return _deserializeOther(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _fromString(JsonParser p, DeserializationContext ctxt, String text) throws IOException {
/* 298 */     CompactStringObjectMap lookup = _resolveCurrentLookup(ctxt);
/* 299 */     Object result = lookup.find(text);
/* 300 */     if (result == null) {
/* 301 */       String trimmed = text.trim();
/* 302 */       if (trimmed == text || (result = lookup.find(trimmed)) == null) {
/* 303 */         return _deserializeAltString(p, ctxt, lookup, trimmed);
/*     */       }
/*     */     } 
/* 306 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CompactStringObjectMap _resolveCurrentLookup(DeserializationContext ctxt) {
/* 313 */     if (this._lookupByEnumNaming != null) {
/* 314 */       return this._lookupByEnumNaming;
/*     */     }
/* 316 */     return ctxt.isEnabled(DeserializationFeature.READ_ENUMS_USING_TO_STRING) ? 
/* 317 */       _getToStringLookup(ctxt) : this._lookupByName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _fromInteger(JsonParser p, DeserializationContext ctxt, int index) throws IOException {
/* 325 */     CoercionAction act = ctxt.findCoercionAction(logicalType(), handledType(), CoercionInputShape.Integer);
/*     */ 
/*     */ 
/*     */     
/* 329 */     if (act == CoercionAction.Fail) {
/* 330 */       if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_NUMBERS_FOR_ENUMS)) {
/* 331 */         return ctxt.handleWeirdNumberValue(_enumClass(), Integer.valueOf(index), "not allowed to deserialize Enum value out of number: disable DeserializationConfig.DeserializationFeature.FAIL_ON_NUMBERS_FOR_ENUMS to allow", new Object[0]);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 336 */       _checkCoercionFail(ctxt, act, handledType(), Integer.valueOf(index), "Integer value (" + index + ")");
/*     */     } 
/*     */     
/* 339 */     switch (act) {
/*     */       case AsNull:
/* 341 */         return null;
/*     */       case AsEmpty:
/* 343 */         return getEmptyValue(ctxt);
/*     */     } 
/*     */ 
/*     */     
/* 347 */     if (index >= 0 && index < this._enumsByIndex.length) {
/* 348 */       return this._enumsByIndex[index];
/*     */     }
/* 350 */     if (useDefaultValueForUnknownEnum(ctxt)) {
/* 351 */       return this._enumDefaultValue;
/*     */     }
/* 353 */     if (!useNullForUnknownEnum(ctxt))
/* 354 */       return ctxt.handleWeirdNumberValue(_enumClass(), Integer.valueOf(index), "index value outside legal index range [0..%s]", new Object[] {
/*     */             
/* 356 */             Integer.valueOf(this._enumsByIndex.length - 1)
/*     */           }); 
/* 358 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Object _deserializeAltString(JsonParser p, DeserializationContext ctxt, CompactStringObjectMap lookup, String nameOrig) throws IOException {
/* 374 */     String name = nameOrig.trim();
/* 375 */     if (name.isEmpty()) {
/*     */       CoercionAction act;
/*     */       
/* 378 */       if (useDefaultValueForUnknownEnum(ctxt)) {
/* 379 */         return this._enumDefaultValue;
/*     */       }
/* 381 */       if (useNullForUnknownEnum(ctxt)) {
/* 382 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 386 */       if (nameOrig.isEmpty()) {
/* 387 */         act = _findCoercionFromEmptyString(ctxt);
/* 388 */         act = _checkCoercionFail(ctxt, act, handledType(), nameOrig, "empty String (\"\")");
/*     */       } else {
/*     */         
/* 391 */         act = _findCoercionFromBlankString(ctxt);
/* 392 */         act = _checkCoercionFail(ctxt, act, handledType(), nameOrig, "blank String (all whitespace)");
/*     */       } 
/*     */       
/* 395 */       switch (act) {
/*     */         case AsEmpty:
/*     */         case TryConvert:
/* 398 */           return getEmptyValue(ctxt);
/*     */       } 
/*     */ 
/*     */       
/* 402 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 406 */     if (Boolean.TRUE.equals(this._caseInsensitive)) {
/* 407 */       Object match = lookup.findCaseInsensitive(name);
/* 408 */       if (match != null) {
/* 409 */         return match;
/*     */       }
/*     */     } 
/* 412 */     if (!ctxt.isEnabled(DeserializationFeature.FAIL_ON_NUMBERS_FOR_ENUMS) && !this._isFromIntValue) {
/*     */ 
/*     */       
/* 415 */       char c = name.charAt(0);
/* 416 */       if (c >= '0' && c <= '9')
/*     */       {
/*     */ 
/*     */         
/* 420 */         if (c != '0' || name.length() <= 1) {
/*     */           
/*     */           try {
/*     */             
/* 424 */             int index = Integer.parseInt(name);
/* 425 */             if (!ctxt.isEnabled(MapperFeature.ALLOW_COERCION_OF_SCALARS)) {
/* 426 */               return ctxt.handleWeirdStringValue(_enumClass(), name, "value looks like quoted Enum index, but `MapperFeature.ALLOW_COERCION_OF_SCALARS` prevents use", new Object[0]);
/*     */             }
/*     */ 
/*     */             
/* 430 */             if (index >= 0 && index < this._enumsByIndex.length) {
/* 431 */               return this._enumsByIndex[index];
/*     */             }
/* 433 */           } catch (NumberFormatException numberFormatException) {}
/*     */         }
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 440 */     if (useDefaultValueForUnknownEnum(ctxt)) {
/* 441 */       return this._enumDefaultValue;
/*     */     }
/* 443 */     if (useNullForUnknownEnum(ctxt)) {
/* 444 */       return null;
/*     */     }
/* 446 */     return ctxt.handleWeirdStringValue(_enumClass(), name, "not one of the values accepted for Enum class: %s", new Object[] { lookup
/* 447 */           .keys() });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserializeOther(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 453 */     if (p.hasToken(JsonToken.START_ARRAY)) {
/* 454 */       return _deserializeFromArray(p, ctxt);
/*     */     }
/* 456 */     return ctxt.handleUnexpectedToken(_enumClass(), p);
/*     */   }
/*     */   
/*     */   protected Class<?> _enumClass() {
/* 460 */     return handledType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected CompactStringObjectMap _getToStringLookup(DeserializationContext ctxt) {
/* 472 */     CompactStringObjectMap lookup = this._lookupByToString;
/* 473 */     if (lookup == null) {
/* 474 */       synchronized (this) {
/* 475 */         lookup = this._lookupByToString;
/* 476 */         if (lookup == null) {
/*     */           
/* 478 */           lookup = EnumResolver.constructUsingToString(ctxt.getConfig(), _enumClass()).constructLookup();
/* 479 */           this._lookupByToString = lookup;
/*     */         } 
/*     */       } 
/*     */     }
/* 483 */     return lookup;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean useNullForUnknownEnum(DeserializationContext ctxt) {
/* 488 */     if (this._useNullForUnknownEnum != null) {
/* 489 */       return this._useNullForUnknownEnum.booleanValue();
/*     */     }
/* 491 */     return ctxt.isEnabled(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean useDefaultValueForUnknownEnum(DeserializationContext ctxt) {
/* 497 */     if (this._enumDefaultValue != null) {
/*     */       
/* 499 */       if (this._useDefaultValueForUnknownEnum != null) {
/* 500 */         return this._useDefaultValueForUnknownEnum.booleanValue();
/*     */       }
/*     */       
/* 503 */       return ctxt.isEnabled(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_USING_DEFAULT_VALUE);
/*     */     } 
/*     */     
/* 506 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\EnumDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */