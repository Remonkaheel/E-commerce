/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*     */ import com.fasterxml.jackson.databind.deser.impl.NullsConstantProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*     */ import com.fasterxml.jackson.databind.util.ObjectBuffer;
/*     */ import java.io.IOException;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public final class StringArrayDeserializer
/*     */   extends StdDeserializer<String[]>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*  36 */   private static final String[] NO_STRINGS = new String[0];
/*     */   
/*  38 */   public static final StringArrayDeserializer instance = new StringArrayDeserializer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final JsonDeserializer<String> _elementDeserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final NullValueProvider _nullProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Boolean _unwrapSingle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean _skipNullValues;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringArrayDeserializer() {
/*  70 */     this((JsonDeserializer<?>)null, (NullValueProvider)null, (Boolean)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private StringArrayDeserializer(JsonDeserializer<?> deser, NullValueProvider nuller, Boolean unwrapSingle) {
/*  76 */     super(String[].class);
/*  77 */     this._elementDeserializer = (JsonDeserializer)deser;
/*  78 */     this._nullProvider = nuller;
/*  79 */     this._unwrapSingle = unwrapSingle;
/*  80 */     this._skipNullValues = NullsConstantProvider.isSkipper(nuller);
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/*  85 */     return LogicalType.Array;
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/*  90 */     return Boolean.TRUE;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AccessPattern getEmptyAccessPattern() {
/*  96 */     return AccessPattern.CONSTANT;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/* 101 */     return NO_STRINGS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 112 */     JsonDeserializer<?> deser = this._elementDeserializer;
/*     */     
/* 114 */     deser = findConvertingContentDeserializer(ctxt, property, deser);
/* 115 */     JavaType type = ctxt.constructType(String.class);
/* 116 */     if (deser == null) {
/* 117 */       deser = ctxt.findContextualValueDeserializer(type, property);
/*     */     } else {
/* 119 */       deser = ctxt.handleSecondaryContextualization(deser, property, type);
/*     */     } 
/*     */     
/* 122 */     Boolean unwrapSingle = findFormatFeature(ctxt, property, String[].class, JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
/*     */     
/* 124 */     NullValueProvider nuller = findContentNullProvider(ctxt, property, deser);
/*     */     
/* 126 */     if (deser != null && isDefaultDeserializer(deser)) {
/* 127 */       deser = null;
/*     */     }
/* 129 */     if (this._elementDeserializer == deser && 
/* 130 */       Objects.equals(this._unwrapSingle, unwrapSingle) && this._nullProvider == nuller)
/*     */     {
/* 132 */       return this;
/*     */     }
/* 134 */     return new StringArrayDeserializer(deser, nuller, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 141 */     if (!p.isExpectedStartArrayToken()) {
/* 142 */       return handleNonArray(p, ctxt);
/*     */     }
/* 144 */     if (this._elementDeserializer != null) {
/* 145 */       return _deserializeCustom(p, ctxt, (String[])null);
/*     */     }
/*     */     
/* 148 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 149 */     Object[] chunk = buffer.resetAndStart();
/*     */     
/* 151 */     int ix = 0;
/*     */     
/*     */     try {
/*     */       while (true) {
/* 155 */         String value = p.nextTextValue();
/* 156 */         if (value == null) {
/* 157 */           JsonToken t = p.currentToken();
/* 158 */           if (t == JsonToken.END_ARRAY) {
/*     */             break;
/*     */           }
/* 161 */           if (t == JsonToken.VALUE_NULL) {
/* 162 */             if (this._skipNullValues) {
/*     */               continue;
/*     */             }
/*     */           } else {
/* 166 */             value = _parseString(p, ctxt, this._nullProvider);
/*     */           } 
/*     */           
/* 169 */           if (value == null) {
/* 170 */             value = (String)this._nullProvider.getNullValue(ctxt);
/*     */             
/* 172 */             if (value == null && this._skipNullValues) {
/*     */               continue;
/*     */             }
/*     */           } 
/*     */         } 
/* 177 */         if (ix >= chunk.length) {
/* 178 */           chunk = buffer.appendCompletedChunk(chunk);
/* 179 */           ix = 0;
/*     */         } 
/* 181 */         chunk[ix++] = value;
/*     */       } 
/* 183 */     } catch (Exception e) {
/* 184 */       throw JsonMappingException.wrapWithPath(e, chunk, buffer.bufferedSize() + ix);
/*     */     } 
/* 186 */     String[] result = (String[])buffer.completeAndClearBuffer(chunk, ix, String.class);
/* 187 */     ctxt.returnObjectBuffer(buffer);
/* 188 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] _deserializeCustom(JsonParser p, DeserializationContext ctxt, String[] old) throws IOException {
/*     */     int ix;
/*     */     Object[] chunk;
/* 197 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/*     */ 
/*     */ 
/*     */     
/* 201 */     if (old == null) {
/* 202 */       ix = 0;
/* 203 */       chunk = buffer.resetAndStart();
/*     */     } else {
/* 205 */       ix = old.length;
/* 206 */       chunk = buffer.resetAndStart((Object[])old, ix);
/*     */     } 
/*     */     
/* 209 */     JsonDeserializer<String> deser = this._elementDeserializer;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*     */       while (true) {
/*     */         String value;
/*     */ 
/*     */ 
/*     */         
/* 219 */         if (p.nextTextValue() == null) {
/* 220 */           JsonToken t = p.currentToken();
/* 221 */           if (t == JsonToken.END_ARRAY) {
/*     */             break;
/*     */           }
/*     */           
/* 225 */           if (t == JsonToken.VALUE_NULL) {
/* 226 */             if (this._skipNullValues) {
/*     */               continue;
/*     */             }
/* 229 */             value = null;
/*     */           } else {
/* 231 */             value = (String)deser.deserialize(p, ctxt);
/*     */           } 
/*     */         } else {
/* 234 */           value = (String)deser.deserialize(p, ctxt);
/*     */         } 
/*     */         
/* 237 */         if (value == null) {
/* 238 */           value = (String)this._nullProvider.getNullValue(ctxt);
/*     */           
/* 240 */           if (value == null && this._skipNullValues) {
/*     */             continue;
/*     */           }
/*     */         } 
/*     */         
/* 245 */         if (ix >= chunk.length) {
/* 246 */           chunk = buffer.appendCompletedChunk(chunk);
/* 247 */           ix = 0;
/*     */         } 
/* 249 */         chunk[ix++] = value;
/*     */       } 
/* 251 */     } catch (Exception e) {
/*     */       
/* 253 */       throw JsonMappingException.wrapWithPath(e, String.class, ix);
/*     */     } 
/* 255 */     String[] result = (String[])buffer.completeAndClearBuffer(chunk, ix, String.class);
/* 256 */     ctxt.returnObjectBuffer(buffer);
/* 257 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 262 */     return typeDeserializer.deserializeTypedFromArray(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] deserialize(JsonParser p, DeserializationContext ctxt, String[] intoValue) throws IOException {
/* 270 */     if (!p.isExpectedStartArrayToken()) {
/* 271 */       String[] arr = handleNonArray(p, ctxt);
/* 272 */       if (arr == null) {
/* 273 */         return intoValue;
/*     */       }
/* 275 */       int offset = intoValue.length;
/* 276 */       String[] arrayOfString1 = new String[offset + arr.length];
/* 277 */       System.arraycopy(intoValue, 0, arrayOfString1, 0, offset);
/* 278 */       System.arraycopy(arr, 0, arrayOfString1, offset, arr.length);
/* 279 */       return arrayOfString1;
/*     */     } 
/*     */     
/* 282 */     if (this._elementDeserializer != null) {
/* 283 */       return _deserializeCustom(p, ctxt, intoValue);
/*     */     }
/* 285 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 286 */     int ix = intoValue.length;
/* 287 */     Object[] chunk = buffer.resetAndStart((Object[])intoValue, ix);
/*     */     
/*     */     try {
/*     */       while (true) {
/* 291 */         String value = p.nextTextValue();
/* 292 */         if (value == null) {
/* 293 */           JsonToken t = p.currentToken();
/* 294 */           if (t == JsonToken.END_ARRAY) {
/*     */             break;
/*     */           }
/* 297 */           if (t == JsonToken.VALUE_NULL) {
/*     */             
/* 299 */             if (this._skipNullValues) {
/* 300 */               return NO_STRINGS;
/*     */             }
/*     */           } else {
/* 303 */             value = _parseString(p, ctxt, this._nullProvider);
/*     */           } 
/*     */           
/* 306 */           if (value == null) {
/* 307 */             value = (String)this._nullProvider.getNullValue(ctxt);
/*     */             
/* 309 */             if (value == null && this._skipNullValues) {
/*     */               continue;
/*     */             }
/*     */           } 
/*     */         } 
/* 314 */         if (ix >= chunk.length) {
/* 315 */           chunk = buffer.appendCompletedChunk(chunk);
/* 316 */           ix = 0;
/*     */         } 
/* 318 */         chunk[ix++] = value;
/*     */       } 
/* 320 */     } catch (Exception e) {
/* 321 */       throw JsonMappingException.wrapWithPath(e, chunk, buffer.bufferedSize() + ix);
/*     */     } 
/* 323 */     String[] result = (String[])buffer.completeAndClearBuffer(chunk, ix, String.class);
/* 324 */     ctxt.returnObjectBuffer(buffer);
/* 325 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String[] handleNonArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 333 */     boolean canWrap = (this._unwrapSingle == Boolean.TRUE || (this._unwrapSingle == null && ctxt.isEnabled(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)));
/* 334 */     if (canWrap) {
/*     */       String value;
/* 336 */       if (p.hasToken(JsonToken.VALUE_NULL)) {
/* 337 */         value = (String)this._nullProvider.getNullValue(ctxt);
/*     */       } else {
/* 339 */         if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 340 */           String textValue = p.getText();
/*     */           
/* 342 */           if (textValue.isEmpty()) {
/* 343 */             CoercionAction act = ctxt.findCoercionAction(logicalType(), handledType(), CoercionInputShape.EmptyString);
/*     */             
/* 345 */             if (act != CoercionAction.Fail) {
/* 346 */               return (String[])_deserializeFromEmptyString(p, ctxt, act, handledType(), "empty String (\"\")");
/*     */             }
/*     */           }
/* 349 */           else if (_isBlank(textValue)) {
/* 350 */             CoercionAction act = ctxt.findCoercionFromBlankString(logicalType(), handledType(), CoercionAction.Fail);
/*     */             
/* 352 */             if (act != CoercionAction.Fail) {
/* 353 */               return (String[])_deserializeFromEmptyString(p, ctxt, act, handledType(), "blank String (all whitespace)");
/*     */             }
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 360 */         value = _parseString(p, ctxt, this._nullProvider);
/*     */       } 
/* 362 */       return new String[] { value };
/*     */     } 
/* 364 */     if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 365 */       return _deserializeFromString(p, ctxt);
/*     */     }
/* 367 */     return (String[])ctxt.handleUnexpectedToken(this._valueClass, p);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\StringArrayDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */