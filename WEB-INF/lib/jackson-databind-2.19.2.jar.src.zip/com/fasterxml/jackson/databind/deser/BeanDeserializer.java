/*      */ package com.fasterxml.jackson.databind.deser;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.databind.BeanDescription;
/*      */ import com.fasterxml.jackson.databind.BeanProperty;
/*      */ import com.fasterxml.jackson.databind.DeserializationContext;
/*      */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*      */ import com.fasterxml.jackson.databind.deser.impl.BeanAsArrayDeserializer;
/*      */ import com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ObjectIdReader;
/*      */ import com.fasterxml.jackson.databind.deser.impl.PropertyBasedCreator;
/*      */ import com.fasterxml.jackson.databind.deser.impl.PropertyValueBuffer;
/*      */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
/*      */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*      */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class BeanDeserializer
/*      */   extends BeanDeserializerBase
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   private volatile transient NameTransformer _currentlyTransforming;
/*      */   
/*      */   @Deprecated
/*      */   public BeanDeserializer(BeanDeserializerBuilder builder, BeanDescription beanDesc, BeanPropertyMap properties, Map<String, SettableBeanProperty> backRefs, HashSet<String> ignorableProps, boolean ignoreAllUnknown, boolean hasViews) {
/*   51 */     super(builder, beanDesc, properties, backRefs, ignorableProps, ignoreAllUnknown, (Set<String>)null, hasViews);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDeserializer(BeanDeserializerBuilder builder, BeanDescription beanDesc, BeanPropertyMap properties, Map<String, SettableBeanProperty> backRefs, HashSet<String> ignorableProps, boolean ignoreAllUnknown, Set<String> includableProps, boolean hasViews) {
/*   65 */     super(builder, beanDesc, properties, backRefs, ignorableProps, ignoreAllUnknown, includableProps, hasViews);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BeanDeserializer(BeanDeserializerBase src) {
/*   74 */     super(src, src._ignoreAllUnknown);
/*      */   }
/*      */   
/*      */   protected BeanDeserializer(BeanDeserializerBase src, boolean ignoreAllUnknown) {
/*   78 */     super(src, ignoreAllUnknown);
/*      */   }
/*      */   
/*      */   protected BeanDeserializer(BeanDeserializerBase src, NameTransformer unwrapper) {
/*   82 */     super(src, unwrapper);
/*      */   }
/*      */   
/*      */   public BeanDeserializer(BeanDeserializerBase src, ObjectIdReader oir) {
/*   86 */     super(src, oir);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public BeanDeserializer(BeanDeserializerBase src, Set<String> ignorableProps) {
/*   94 */     super(src, ignorableProps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDeserializer(BeanDeserializerBase src, Set<String> ignorableProps, Set<String> includableProps) {
/*  101 */     super(src, ignorableProps, includableProps);
/*      */   }
/*      */   
/*      */   public BeanDeserializer(BeanDeserializerBase src, BeanPropertyMap props) {
/*  105 */     super(src, props);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonDeserializer<Object> unwrappingDeserializer(NameTransformer transformer) {
/*  113 */     if (getClass() != BeanDeserializer.class) {
/*  114 */       return (JsonDeserializer<Object>)this;
/*      */     }
/*      */ 
/*      */     
/*  118 */     if (this._currentlyTransforming == transformer) {
/*  119 */       return (JsonDeserializer<Object>)this;
/*      */     }
/*  121 */     this._currentlyTransforming = transformer;
/*      */     
/*  123 */     try { return (JsonDeserializer<Object>)new BeanDeserializer(this, transformer); }
/*  124 */     finally { this._currentlyTransforming = null; }
/*      */   
/*      */   }
/*      */   
/*      */   public BeanDeserializer withObjectIdReader(ObjectIdReader oir) {
/*  129 */     return new BeanDeserializer(this, oir);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BeanDeserializer withByNameInclusion(Set<String> ignorableProps, Set<String> includableProps) {
/*  135 */     return new BeanDeserializer(this, ignorableProps, includableProps);
/*      */   }
/*      */ 
/*      */   
/*      */   public BeanDeserializerBase withIgnoreAllUnknown(boolean ignoreUnknown) {
/*  140 */     return new BeanDeserializer(this, ignoreUnknown);
/*      */   }
/*      */ 
/*      */   
/*      */   public BeanDeserializerBase withBeanProperties(BeanPropertyMap props) {
/*  145 */     return new BeanDeserializer(this, props);
/*      */   }
/*      */ 
/*      */   
/*      */   protected BeanDeserializerBase asArrayDeserializer() {
/*  150 */     SettableBeanProperty[] props = this._beanProperties.getPropertiesInInsertionOrder();
/*  151 */     return (BeanDeserializerBase)new BeanAsArrayDeserializer(this, props);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  167 */     if (p.isExpectedStartObjectToken()) {
/*  168 */       if (this._vanillaProcessing) {
/*  169 */         return vanillaDeserialize(p, ctxt, p.nextToken());
/*      */       }
/*      */ 
/*      */       
/*  173 */       p.nextToken();
/*  174 */       if (this._objectIdReader != null) {
/*  175 */         return deserializeWithObjectId(p, ctxt);
/*      */       }
/*  177 */       return deserializeFromObject(p, ctxt);
/*      */     } 
/*  179 */     return _deserializeOther(p, ctxt, p.currentToken());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object _deserializeOther(JsonParser p, DeserializationContext ctxt, JsonToken t) throws IOException {
/*  186 */     if (t != null) {
/*  187 */       switch (t) {
/*      */         case AsEmpty:
/*  189 */           return deserializeFromString(p, ctxt);
/*      */         case AsNull:
/*  191 */           return deserializeFromNumber(p, ctxt);
/*      */         case TryConvert:
/*  193 */           return deserializeFromDouble(p, ctxt);
/*      */         case null:
/*  195 */           return deserializeFromEmbedded(p, ctxt);
/*      */         case null:
/*      */         case null:
/*  198 */           return deserializeFromBoolean(p, ctxt);
/*      */         case null:
/*  200 */           return deserializeFromNull(p, ctxt);
/*      */         
/*      */         case null:
/*  203 */           return _deserializeFromArray(p, ctxt);
/*      */         case null:
/*      */         case null:
/*  206 */           if (this._vanillaProcessing) {
/*  207 */             return vanillaDeserialize(p, ctxt, t);
/*      */           }
/*  209 */           if (this._objectIdReader != null) {
/*  210 */             return deserializeWithObjectId(p, ctxt);
/*      */           }
/*  212 */           return deserializeFromObject(p, ctxt);
/*      */       } 
/*      */     
/*      */     }
/*  216 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserialize(JsonParser p, DeserializationContext ctxt, Object bean) throws IOException {
/*      */     String propName;
/*  228 */     p.assignCurrentValue(bean);
/*  229 */     if (this._injectables != null) {
/*  230 */       injectValues(ctxt, bean);
/*      */     }
/*  232 */     if (this._unwrappedPropertyHandler != null) {
/*  233 */       return deserializeWithUnwrapped(p, ctxt, bean);
/*      */     }
/*  235 */     if (this._externalTypeIdHandler != null) {
/*  236 */       return deserializeWithExternalTypeId(p, ctxt, bean);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  241 */     if (p.isExpectedStartObjectToken()) {
/*  242 */       propName = p.nextFieldName();
/*  243 */       if (propName == null) {
/*  244 */         return bean;
/*      */       }
/*      */     }
/*  247 */     else if (p.hasTokenId(5)) {
/*  248 */       propName = p.currentName();
/*      */     } else {
/*  250 */       return bean;
/*      */     } 
/*      */     
/*  253 */     if (this._needViewProcesing) {
/*  254 */       Class<?> view = ctxt.getActiveView();
/*  255 */       if (view != null) {
/*  256 */         return deserializeWithView(p, ctxt, bean, view);
/*      */       }
/*      */     } 
/*      */     while (true) {
/*  260 */       p.nextToken();
/*  261 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*      */       
/*  263 */       if (prop != null) {
/*      */         try {
/*  265 */           prop.deserializeAndSet(p, ctxt, bean);
/*  266 */         } catch (Exception e) {
/*  267 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         } 
/*      */       } else {
/*      */         
/*  271 */         handleUnknownVanilla(p, ctxt, bean, propName);
/*  272 */       }  if ((propName = p.nextFieldName()) == null) {
/*  273 */         return bean;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Object vanillaDeserialize(JsonParser p, DeserializationContext ctxt, JsonToken t) throws IOException {
/*  290 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/*  291 */     if (p.hasTokenId(5)) {
/*      */ 
/*      */       
/*  294 */       p.assignCurrentValue(bean);
/*  295 */       String propName = p.currentName();
/*      */       do {
/*  297 */         p.nextToken();
/*  298 */         SettableBeanProperty prop = this._beanProperties.find(propName);
/*      */         
/*  300 */         if (prop != null)
/*      */         { try {
/*  302 */             prop.deserializeAndSet(p, ctxt, bean);
/*  303 */           } catch (Exception e) {
/*  304 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }  }
/*      */         else
/*      */         
/*  308 */         { handleUnknownVanilla(p, ctxt, bean, propName); } 
/*  309 */       } while ((propName = p.nextFieldName()) != null);
/*      */     } 
/*  311 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object deserializeFromObject(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  327 */     if (this._objectIdReader != null && this._objectIdReader.maySerializeAsObject() && 
/*  328 */       p.hasTokenId(5) && this._objectIdReader
/*  329 */       .isValidReferencePropertyName(p.currentName(), p)) {
/*  330 */       return deserializeFromObjectId(p, ctxt);
/*      */     }
/*      */     
/*  333 */     if (this._nonStandardCreation) {
/*  334 */       if (this._unwrappedPropertyHandler != null) {
/*  335 */         return deserializeWithUnwrapped(p, ctxt);
/*      */       }
/*  337 */       if (this._externalTypeIdHandler != null) {
/*  338 */         return deserializeWithExternalTypeId(p, ctxt);
/*      */       }
/*  340 */       Object object = deserializeFromObjectUsingNonDefault(p, ctxt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  353 */       return object;
/*      */     } 
/*  355 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/*      */ 
/*      */     
/*  358 */     if (p.canReadObjectId()) {
/*  359 */       Object id = p.getObjectId();
/*  360 */       if (id != null) {
/*  361 */         _handleTypedObjectId(p, ctxt, bean, id);
/*      */ 
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  367 */     else if (this._objectIdReader != null && p.hasTokenId(2)) {
/*      */       
/*  369 */       if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_UNRESOLVED_OBJECT_IDS)) {
/*  370 */         ctxt.reportUnresolvedObjectId(this._objectIdReader, bean);
/*      */       }
/*      */     } 
/*  373 */     if (this._injectables != null) {
/*  374 */       injectValues(ctxt, bean);
/*      */     }
/*  376 */     if (this._needViewProcesing) {
/*  377 */       Class<?> view = ctxt.getActiveView();
/*  378 */       if (view != null) {
/*  379 */         return deserializeWithView(p, ctxt, bean, view);
/*      */       }
/*      */     } 
/*  382 */     if (p.hasTokenId(5)) {
/*      */ 
/*      */       
/*  385 */       p.assignCurrentValue(bean);
/*  386 */       String propName = p.currentName();
/*      */       do {
/*  388 */         p.nextToken();
/*  389 */         SettableBeanProperty prop = this._beanProperties.find(propName);
/*  390 */         if (prop != null)
/*      */         { try {
/*  392 */             prop.deserializeAndSet(p, ctxt, bean);
/*  393 */           } catch (Exception e) {
/*  394 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }  }
/*      */         else
/*      */         
/*  398 */         { handleUnknownVanilla(p, ctxt, bean, propName); } 
/*  399 */       } while ((propName = p.nextFieldName()) != null);
/*      */     } 
/*  401 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _deserializeUsingPropertyBased(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     Object bean;
/*  416 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/*      */ 
/*      */     
/*  419 */     PropertyValueBuffer buffer = (this._anySetter != null) ? creator.startBuildingWithAnySetter(p, ctxt, this._objectIdReader, this._anySetter) : creator.startBuilding(p, ctxt, this._objectIdReader);
/*  420 */     TokenBuffer unknown = null;
/*  421 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*      */     
/*  423 */     JsonToken t = p.currentToken();
/*  424 */     List<BeanReferring> referrings = null;
/*  425 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/*  426 */       String propName = p.currentName();
/*  427 */       p.nextToken();
/*  428 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/*      */       
/*  430 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*      */       {
/*      */ 
/*      */         
/*  434 */         if (creatorProp != null) {
/*      */           
/*  436 */           if (activeView != null && !creatorProp.visibleInView(activeView)) {
/*  437 */             p.skipChildren();
/*      */           } else {
/*      */             
/*  440 */             Object value = _deserializeWithErrorWrapping(p, ctxt, creatorProp);
/*      */             
/*  442 */             if (buffer.assignParameter(creatorProp, value)) {
/*  443 */               Object object; p.nextToken();
/*      */               
/*      */               try {
/*  446 */                 object = creator.build(ctxt, buffer);
/*  447 */               } catch (Exception e) {
/*  448 */                 object = wrapInstantiationProblem(e, ctxt);
/*      */               } 
/*      */               
/*  451 */               p.assignCurrentValue(object);
/*      */ 
/*      */               
/*  454 */               if (object == null) {
/*  455 */                 _handleNullFromPropsBasedCreator(p, ctxt, unknown, referrings);
/*  456 */                 return null;
/*      */               } 
/*      */               
/*  459 */               if (object.getClass() != this._beanType.getRawClass()) {
/*  460 */                 return handlePolymorphic(p, ctxt, p.streamReadConstraints(), object, unknown);
/*      */               }
/*  462 */               if (unknown != null) {
/*  463 */                 object = handleUnknownProperties(ctxt, object, unknown);
/*      */               }
/*      */               
/*  466 */               return deserialize(p, ctxt, object);
/*      */             } 
/*      */           } 
/*      */         } else {
/*      */           
/*  471 */           SettableBeanProperty prop = this._beanProperties.find(propName);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  476 */           if (prop != null && (
/*      */             
/*  478 */             !this._beanType.isRecordType() || prop instanceof com.fasterxml.jackson.databind.deser.impl.MethodProperty)) {
/*      */             try {
/*  480 */               buffer.bufferProperty(prop, _deserializeWithErrorWrapping(p, ctxt, prop));
/*  481 */             } catch (UnresolvedForwardReference reference) {
/*      */ 
/*      */ 
/*      */               
/*  485 */               BeanReferring referring = handleUnresolvedReference(ctxt, prop, buffer, reference);
/*      */               
/*  487 */               if (referrings == null) {
/*  488 */                 referrings = new ArrayList<>();
/*      */               }
/*  490 */               referrings.add(referring);
/*      */             
/*      */             }
/*      */           
/*      */           }
/*  495 */           else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  496 */             handleIgnoredProperty(p, ctxt, handledType(), propName);
/*      */ 
/*      */           
/*      */           }
/*  500 */           else if (this._anySetter != null) {
/*      */             
/*      */             try {
/*  503 */               if (this._anySetter.isFieldType() || this._anySetter
/*      */                 
/*  505 */                 .isSetterType()) {
/*  506 */                 buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter.deserialize(p, ctxt));
/*      */               } else {
/*  508 */                 buffer.bufferAnyParameterProperty(this._anySetter, propName, this._anySetter.deserialize(p, ctxt));
/*      */               } 
/*  510 */             } catch (Exception e) {
/*  511 */               wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/*      */ 
/*      */             
/*      */             }
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  519 */           else if (this._ignoreAllUnknown) {
/*      */             
/*  521 */             p.skipChildren();
/*      */           }
/*      */           else {
/*      */             
/*  525 */             if (unknown == null) {
/*  526 */               unknown = ctxt.bufferForInputBuffering(p);
/*      */             }
/*  528 */             unknown.writeFieldName(propName);
/*  529 */             unknown.copyCurrentStructure(p);
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */     try {
/*  535 */       bean = creator.build(ctxt, buffer);
/*  536 */     } catch (Exception e) {
/*  537 */       return wrapInstantiationProblem(e, ctxt);
/*      */     } 
/*  539 */     p.assignCurrentValue(bean);
/*      */ 
/*      */     
/*  542 */     if (bean == null) {
/*  543 */       _handleNullFromPropsBasedCreator((JsonParser)null, ctxt, unknown, referrings);
/*  544 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  548 */     if (this._injectables != null) {
/*  549 */       injectValues(ctxt, bean);
/*      */     }
/*      */     
/*  552 */     if (referrings != null) {
/*  553 */       for (BeanReferring referring : referrings) {
/*  554 */         referring.setBean(bean);
/*      */       }
/*      */     }
/*  557 */     if (unknown != null) {
/*      */       
/*  559 */       if (bean.getClass() != this._beanType.getRawClass()) {
/*  560 */         return handlePolymorphic((JsonParser)null, ctxt, p.streamReadConstraints(), bean, unknown);
/*      */       }
/*      */       
/*  563 */       return handleUnknownProperties(ctxt, bean, unknown);
/*      */     } 
/*  565 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BeanReferring handleUnresolvedReference(DeserializationContext ctxt, SettableBeanProperty prop, PropertyValueBuffer buffer, UnresolvedForwardReference reference) throws JsonMappingException {
/*  577 */     BeanReferring referring = new BeanReferring(ctxt, reference, prop.getType(), buffer, prop);
/*  578 */     reference.getRoid().appendReferring(referring);
/*  579 */     return referring;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object _deserializeWithErrorWrapping(JsonParser p, DeserializationContext ctxt, SettableBeanProperty prop) throws IOException {
/*      */     try {
/*  587 */       return prop.deserialize(p, ctxt);
/*  588 */     } catch (Exception e) {
/*  589 */       return wrapAndThrow(e, this._beanType.getRawClass(), prop.getName(), ctxt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeFromNull(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  607 */     if (p.requiresCustomCodec()) {
/*      */       
/*  609 */       TokenBuffer tb = ctxt.bufferForInputBuffering(p);
/*  610 */       tb.writeEndObject();
/*  611 */       JsonParser p2 = tb.asParser(p);
/*  612 */       p2.nextToken();
/*      */ 
/*      */       
/*  615 */       Object ob = this._vanillaProcessing ? vanillaDeserialize(p2, ctxt, JsonToken.END_OBJECT) : deserializeFromObject(p2, ctxt);
/*  616 */       p2.close();
/*  617 */       return ob;
/*      */     } 
/*  619 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _deserializeFromArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  626 */     JsonDeserializer<Object> delegateDeser = this._arrayDelegateDeserializer;
/*      */     
/*  628 */     if (delegateDeser != null || (delegateDeser = this._delegateDeserializer) != null) {
/*  629 */       Object bean = this._valueInstantiator.createUsingArrayDelegate(ctxt, delegateDeser
/*  630 */           .deserialize(p, ctxt));
/*  631 */       if (this._injectables != null) {
/*  632 */         injectValues(ctxt, bean);
/*      */       }
/*  634 */       return bean;
/*      */     } 
/*  636 */     CoercionAction act = _findCoercionFromEmptyArray(ctxt);
/*  637 */     boolean unwrap = ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS);
/*      */     
/*  639 */     if (unwrap || act != CoercionAction.Fail) {
/*  640 */       JsonToken unwrappedToken = p.nextToken();
/*  641 */       if (unwrappedToken == JsonToken.END_ARRAY) {
/*  642 */         switch (act) {
/*      */           case AsEmpty:
/*  644 */             return getEmptyValue(ctxt);
/*      */           case AsNull:
/*      */           case TryConvert:
/*  647 */             return getNullValue(ctxt);
/*      */         } 
/*      */         
/*  650 */         return ctxt.handleUnexpectedToken(getValueType(ctxt), JsonToken.START_ARRAY, p, null, new Object[0]);
/*      */       } 
/*  652 */       if (unwrap) {
/*      */ 
/*      */         
/*  655 */         if (unwrappedToken == JsonToken.START_ARRAY) {
/*  656 */           JavaType targetType = getValueType(ctxt);
/*  657 */           return ctxt.handleUnexpectedToken(targetType, JsonToken.START_ARRAY, p, "Cannot deserialize value of type %s from deeply-nested Array: only single wrapper allowed with `%s`", new Object[] {
/*      */                 
/*  659 */                 ClassUtil.getTypeDescription(targetType), "DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS"
/*      */               });
/*      */         } 
/*  662 */         Object value = deserialize(p, ctxt);
/*  663 */         if (p.nextToken() != JsonToken.END_ARRAY) {
/*  664 */           handleMissingEndArrayForSingle(p, ctxt);
/*      */         }
/*  666 */         return value;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  671 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Object deserializeWithView(JsonParser p, DeserializationContext ctxt, Object bean, Class<?> activeView) throws IOException {
/*  684 */     if (p.hasTokenId(5)) {
/*      */ 
/*      */       
/*  687 */       p.assignCurrentValue(bean);
/*  688 */       String propName = p.currentName();
/*      */       do {
/*  690 */         p.nextToken();
/*      */         
/*  692 */         SettableBeanProperty prop = this._beanProperties.find(propName);
/*  693 */         if (prop != null)
/*  694 */         { if (!prop.visibleInView(activeView)) {
/*      */             
/*  696 */             if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_UNEXPECTED_VIEW_PROPERTIES))
/*  697 */               ctxt.reportInputMismatch(handledType(), 
/*  698 */                   String.format("Input mismatch while deserializing %s. Property '%s' is not part of current active view '%s' (disable 'DeserializationFeature.FAIL_ON_UNEXPECTED_VIEW_PROPERTIES' to allow)", new Object[] {
/*      */                       
/*  700 */                       ClassUtil.nameOf(handledType()), prop.getName(), activeView.getName()
/*      */                     }), new Object[0]); 
/*  702 */             p.skipChildren();
/*      */           } else {
/*      */             
/*      */             try {
/*  706 */               prop.deserializeAndSet(p, ctxt, bean);
/*  707 */             } catch (Exception e) {
/*  708 */               wrapAndThrow(e, bean, propName, ctxt);
/*      */             } 
/*      */           }  }
/*      */         else
/*  712 */         { handleUnknownVanilla(p, ctxt, bean, propName); } 
/*  713 */       } while ((propName = p.nextFieldName()) != null);
/*      */     } 
/*  715 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  732 */     if (this._delegateDeserializer != null) {
/*  733 */       return this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer.deserialize(p, ctxt));
/*      */     }
/*  735 */     if (this._propertyBasedCreator != null) {
/*  736 */       return deserializeUsingPropertyBasedWithUnwrapped(p, ctxt);
/*      */     }
/*  738 */     TokenBuffer tokens = ctxt.bufferForInputBuffering(p);
/*  739 */     tokens.writeStartObject();
/*  740 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/*      */ 
/*      */     
/*  743 */     p.assignCurrentValue(bean);
/*      */     
/*  745 */     if (this._injectables != null) {
/*  746 */       injectValues(ctxt, bean);
/*      */     }
/*  748 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*  749 */     String propName = p.hasTokenId(5) ? p.currentName() : null;
/*      */     
/*  751 */     for (; propName != null; propName = p.nextFieldName()) {
/*  752 */       p.nextToken();
/*  753 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*  754 */       if (prop != null) {
/*  755 */         if (activeView != null && !prop.visibleInView(activeView)) {
/*  756 */           p.skipChildren();
/*      */         } else {
/*      */           
/*      */           try {
/*  760 */             prop.deserializeAndSet(p, ctxt, bean);
/*  761 */           } catch (Exception e) {
/*  762 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         
/*      */         }
/*      */       
/*  767 */       } else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  768 */         handleIgnoredProperty(p, ctxt, bean, propName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  775 */       else if (this._anySetter == null) {
/*      */         
/*  777 */         tokens.writeFieldName(propName);
/*  778 */         tokens.copyCurrentStructure(p);
/*      */       }
/*      */       else {
/*      */         
/*  782 */         TokenBuffer b2 = ctxt.bufferAsCopyOfValue(p);
/*  783 */         tokens.writeFieldName(propName);
/*  784 */         tokens.append(b2);
/*      */         try {
/*  786 */           this._anySetter.deserializeAndSet(b2.asParserOnFirstToken(), ctxt, bean, propName);
/*  787 */         } catch (Exception e) {
/*  788 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         } 
/*      */       } 
/*  791 */     }  tokens.writeEndObject();
/*  792 */     this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, bean, tokens);
/*  793 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithUnwrapped(JsonParser p, DeserializationContext ctxt, Object bean) throws IOException {
/*  801 */     JsonToken t = p.currentToken();
/*  802 */     if (t == JsonToken.START_OBJECT) {
/*  803 */       t = p.nextToken();
/*      */     }
/*  805 */     TokenBuffer tokens = ctxt.bufferForInputBuffering(p);
/*  806 */     tokens.writeStartObject();
/*  807 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*  808 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/*  809 */       String propName = p.currentName();
/*  810 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*  811 */       p.nextToken();
/*  812 */       if (prop != null) {
/*  813 */         if (activeView != null && !prop.visibleInView(activeView)) {
/*  814 */           p.skipChildren();
/*      */         } else {
/*      */           
/*      */           try {
/*  818 */             prop.deserializeAndSet(p, ctxt, bean);
/*  819 */           } catch (Exception e) {
/*  820 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         
/*      */         } 
/*  824 */       } else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  825 */         handleIgnoredProperty(p, ctxt, bean, propName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  832 */       else if (this._anySetter == null) {
/*      */         
/*  834 */         tokens.writeFieldName(propName);
/*  835 */         tokens.copyCurrentStructure(p);
/*      */       } else {
/*      */         
/*  838 */         TokenBuffer b2 = ctxt.bufferAsCopyOfValue(p);
/*  839 */         tokens.writeFieldName(propName);
/*  840 */         tokens.append(b2);
/*      */         try {
/*  842 */           this._anySetter.deserializeAndSet(b2.asParserOnFirstToken(), ctxt, bean, propName);
/*  843 */         } catch (Exception e) {
/*  844 */           wrapAndThrow(e, bean, propName, ctxt);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  849 */     tokens.writeEndObject();
/*  850 */     this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, bean, tokens);
/*  851 */     return bean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeUsingPropertyBasedWithUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/*      */     Object bean;
/*  862 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/*  863 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, this._objectIdReader);
/*      */     
/*  865 */     TokenBuffer tokens = ctxt.bufferForInputBuffering(p);
/*  866 */     tokens.writeStartObject();
/*      */     
/*  868 */     JsonToken t = p.currentToken();
/*  869 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/*  870 */       String propName = p.currentName();
/*  871 */       p.nextToken();
/*      */       
/*  873 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/*      */       
/*  875 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*      */       {
/*      */         
/*  878 */         if (creatorProp != null) {
/*      */           
/*  880 */           if (buffer.assignParameter(creatorProp, 
/*  881 */               _deserializeWithErrorWrapping(p, ctxt, creatorProp))) {
/*  882 */             Object object; t = p.nextToken();
/*      */             
/*      */             try {
/*  885 */               object = creator.build(ctxt, buffer);
/*  886 */             } catch (Exception e) {
/*  887 */               object = wrapInstantiationProblem(e, ctxt);
/*      */             } 
/*      */             
/*  890 */             p.assignCurrentValue(object);
/*      */ 
/*      */             
/*  893 */             if (object == null) {
/*      */ 
/*      */ 
/*      */               
/*  897 */               _handleNullFromPropsBasedCreator(p, ctxt, (TokenBuffer)null, (List<BeanReferring>)null);
/*  898 */               return null;
/*      */             } 
/*      */ 
/*      */             
/*  902 */             while (t == JsonToken.FIELD_NAME) {
/*      */               
/*  904 */               tokens.copyCurrentStructure(p);
/*  905 */               t = p.nextToken();
/*      */             } 
/*      */ 
/*      */             
/*  909 */             if (t != JsonToken.END_OBJECT)
/*  910 */               ctxt.reportWrongTokenException((JsonDeserializer)this, JsonToken.END_OBJECT, "Attempted to unwrap '%s' value", new Object[] {
/*      */                     
/*  912 */                     handledType().getName()
/*      */                   }); 
/*  914 */             tokens.writeEndObject();
/*  915 */             if (object.getClass() != this._beanType.getRawClass())
/*      */             {
/*      */               
/*  918 */               return ctxt.reportInputMismatch((BeanProperty)creatorProp, "Cannot create polymorphic instances with unwrapped values", new Object[0]);
/*      */             }
/*      */             
/*  921 */             return this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, object, tokens);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  926 */           SettableBeanProperty prop = this._beanProperties.find(propName);
/*  927 */           if (prop != null) {
/*  928 */             buffer.bufferProperty(prop, _deserializeWithErrorWrapping(p, ctxt, prop));
/*      */ 
/*      */           
/*      */           }
/*  932 */           else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/*  933 */             handleIgnoredProperty(p, ctxt, handledType(), propName);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  940 */           else if (this._anySetter == null) {
/*      */             
/*  942 */             tokens.writeFieldName(propName);
/*  943 */             tokens.copyCurrentStructure(p);
/*      */           } else {
/*      */             
/*  946 */             TokenBuffer b2 = ctxt.bufferAsCopyOfValue(p);
/*  947 */             tokens.writeFieldName(propName);
/*  948 */             tokens.append(b2);
/*      */             try {
/*  950 */               buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter
/*  951 */                   .deserialize(b2.asParserOnFirstToken(), ctxt));
/*  952 */             } catch (Exception e) {
/*  953 */               wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  962 */     buffer = this._unwrappedPropertyHandler.processUnwrappedCreatorProperties(p, ctxt, buffer, tokens);
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  967 */       bean = creator.build(ctxt, buffer);
/*  968 */     } catch (Exception e) {
/*  969 */       return wrapInstantiationProblem(e, ctxt);
/*      */     } 
/*      */ 
/*      */     
/*  973 */     if (bean == null) {
/*      */       
/*  975 */       _handleNullFromPropsBasedCreator((JsonParser)null, ctxt, (TokenBuffer)null, (List<BeanReferring>)null);
/*  976 */       return null;
/*      */     } 
/*      */     
/*  979 */     return this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, bean, tokens);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithExternalTypeId(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  992 */     if (this._propertyBasedCreator != null) {
/*  993 */       return deserializeUsingPropertyBasedWithExternalTypeId(p, ctxt);
/*      */     }
/*  995 */     if (this._delegateDeserializer != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1001 */       return this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer
/* 1002 */           .deserialize(p, ctxt));
/*      */     }
/*      */     
/* 1005 */     return deserializeWithExternalTypeId(p, ctxt, this._valueInstantiator.createUsingDefault(ctxt));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeWithExternalTypeId(JsonParser p, DeserializationContext ctxt, Object bean) throws IOException {
/* 1012 */     return _deserializeWithExternalTypeId(p, ctxt, bean, this._externalTypeIdHandler
/* 1013 */         .start());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object _deserializeWithExternalTypeId(JsonParser p, DeserializationContext ctxt, Object bean, ExternalTypeHandler ext) throws IOException {
/* 1020 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/* 1021 */     for (JsonToken t = p.currentToken(); t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/* 1022 */       String propName = p.currentName();
/* 1023 */       t = p.nextToken();
/* 1024 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/* 1025 */       if (prop != null) {
/*      */         
/* 1027 */         if (t.isScalarValue()) {
/* 1028 */           ext.handleTypePropertyValue(p, ctxt, propName, bean);
/*      */         }
/* 1030 */         if (activeView != null && !prop.visibleInView(activeView)) {
/* 1031 */           p.skipChildren();
/*      */         } else {
/*      */           
/*      */           try {
/* 1035 */             prop.deserializeAndSet(p, ctxt, bean);
/* 1036 */           } catch (Exception e) {
/* 1037 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         
/*      */         }
/*      */       
/* 1042 */       } else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/* 1043 */         handleIgnoredProperty(p, ctxt, bean, propName);
/*      */ 
/*      */       
/*      */       }
/* 1047 */       else if (!ext.handlePropertyValue(p, ctxt, propName, bean)) {
/*      */ 
/*      */ 
/*      */         
/* 1051 */         if (this._anySetter != null) {
/*      */           try {
/* 1053 */             this._anySetter.deserializeAndSet(p, ctxt, bean, propName);
/* 1054 */           } catch (Exception e) {
/* 1055 */             wrapAndThrow(e, bean, propName, ctxt);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/* 1060 */           handleUnknownProperty(p, ctxt, bean, propName);
/*      */         } 
/*      */       } 
/* 1063 */     }  return ext.complete(p, ctxt, bean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object deserializeUsingPropertyBasedWithExternalTypeId(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 1071 */     ExternalTypeHandler ext = this._externalTypeIdHandler.start();
/* 1072 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/* 1073 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, this._objectIdReader);
/* 1074 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*      */     
/* 1076 */     JsonToken t = p.currentToken();
/* 1077 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/* 1078 */       String propName = p.currentName();
/* 1079 */       t = p.nextToken();
/*      */       
/* 1081 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/*      */       
/* 1083 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*      */       {
/*      */         
/* 1086 */         if (creatorProp != null) {
/*      */ 
/*      */ 
/*      */           
/* 1090 */           if (!ext.handlePropertyValue(p, ctxt, propName, null))
/*      */           {
/* 1092 */             if (buffer.assignParameter(creatorProp, 
/* 1093 */                 _deserializeWithErrorWrapping(p, ctxt, creatorProp))) {
/* 1094 */               Object bean; t = p.nextToken();
/*      */               
/*      */               try {
/* 1097 */                 bean = creator.build(ctxt, buffer);
/* 1098 */               } catch (Exception e) {
/* 1099 */                 wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/*      */               } 
/*      */               
/* 1102 */               if (bean.getClass() != this._beanType.getRawClass())
/*      */               {
/*      */                 
/* 1105 */                 return ctxt.reportBadDefinition(this._beanType, String.format("Cannot create polymorphic instances with external type ids (%s -> %s)", new Object[] { this._beanType, bean
/*      */                         
/* 1107 */                         .getClass() }));
/*      */               }
/* 1109 */               return _deserializeWithExternalTypeId(p, ctxt, bean, ext);
/*      */             }
/*      */           
/*      */           }
/*      */         } else {
/*      */           
/* 1115 */           SettableBeanProperty prop = this._beanProperties.find(propName);
/* 1116 */           if (prop != null) {
/*      */             
/* 1118 */             if (t.isScalarValue()) {
/* 1119 */               ext.handleTypePropertyValue(p, ctxt, propName, null);
/*      */             }
/*      */             
/* 1122 */             if (activeView != null && !prop.visibleInView(activeView)) {
/* 1123 */               p.skipChildren();
/*      */             } else {
/* 1125 */               buffer.bufferProperty(prop, prop.deserialize(p, ctxt));
/*      */             
/*      */             }
/*      */           
/*      */           }
/* 1130 */           else if (!ext.handlePropertyValue(p, ctxt, propName, null)) {
/*      */ 
/*      */ 
/*      */             
/* 1134 */             if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/* 1135 */               handleIgnoredProperty(p, ctxt, handledType(), propName);
/*      */ 
/*      */             
/*      */             }
/* 1139 */             else if (this._anySetter != null) {
/* 1140 */               buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter
/* 1141 */                   .deserialize(p, ctxt));
/*      */             }
/*      */             else {
/*      */               
/* 1145 */               handleUnknownProperty(p, ctxt, this._valueClass, propName);
/*      */             } 
/*      */           } 
/*      */         }  } 
/*      */     }  try {
/* 1150 */       return ext.complete(p, ctxt, buffer, creator);
/* 1151 */     } catch (Exception e) {
/* 1152 */       return wrapInstantiationProblem(e, ctxt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _handleNullFromPropsBasedCreator(JsonParser p, DeserializationContext ctxt, TokenBuffer unknown, List<BeanReferring> referrings) throws IOException {
/* 1161 */     if (p != null) {
/* 1162 */       JsonToken t = p.currentToken();
/* 1163 */       while (t == JsonToken.FIELD_NAME) {
/* 1164 */         p.nextToken();
/* 1165 */         p.skipChildren();
/* 1166 */         t = p.nextToken();
/*      */       } 
/*      */     } 
/* 1169 */     if (unknown != null) {
/* 1170 */       handleUnknownProperties(ctxt, (Object)null, unknown);
/*      */     }
/* 1172 */     if (referrings != null) {
/* 1173 */       for (BeanReferring referring : referrings) {
/* 1174 */         referring.setBean(null);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   static class BeanReferring
/*      */     extends ReadableObjectId.Referring
/*      */   {
/*      */     private final DeserializationContext _context;
/*      */     
/*      */     private final SettableBeanProperty _prop;
/*      */     
/*      */     private Object _bean;
/*      */ 
/*      */     
/*      */     BeanReferring(DeserializationContext ctxt, UnresolvedForwardReference ref, JavaType valueType, PropertyValueBuffer buffer, SettableBeanProperty prop) {
/* 1191 */       super(ref, valueType);
/* 1192 */       this._context = ctxt;
/* 1193 */       this._prop = prop;
/*      */     }
/*      */     
/*      */     public void setBean(Object bean) {
/* 1197 */       this._bean = bean;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void handleResolvedForwardReference(Object id, Object value) throws IOException {
/* 1203 */       if (this._bean == null) {
/* 1204 */         this._context.reportInputMismatch((BeanProperty)this._prop, "Cannot resolve ObjectId forward reference using property '%s' (of type %s): Bean not yet resolved", new Object[] { this._prop
/*      */               
/* 1206 */               .getName(), this._prop.getDeclaringClass().getName() });
/*      */       }
/* 1208 */       this._prop.set(this._bean, value);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\BeanDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */