/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanPropertyMap
/*     */   implements Iterable<SettableBeanProperty>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   protected final boolean _caseInsensitive;
/*     */   private int _hashMask;
/*     */   private int _size;
/*     */   private int _spillCount;
/*     */   private Object[] _hashArea;
/*     */   private final SettableBeanProperty[] _propsInOrder;
/*     */   private final Map<String, List<PropertyName>> _aliasDefs;
/*     */   private final Map<String, String> _aliasMapping;
/*     */   private final Locale _locale;
/*     */   
/*     */   public BeanPropertyMap(boolean caseInsensitive, Collection<SettableBeanProperty> props, Map<String, List<PropertyName>> aliasDefs, Locale locale) {
/*  94 */     this._caseInsensitive = caseInsensitive;
/*  95 */     this._propsInOrder = props.<SettableBeanProperty>toArray(new SettableBeanProperty[props.size()]);
/*  96 */     this._aliasDefs = aliasDefs;
/*  97 */     this._locale = locale;
/*  98 */     this._aliasMapping = _buildAliasMapping(aliasDefs, caseInsensitive, locale);
/*  99 */     init(props);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public BeanPropertyMap(boolean caseInsensitive, Collection<SettableBeanProperty> props, Map<String, List<PropertyName>> aliasDefs) {
/* 109 */     this(caseInsensitive, props, aliasDefs, Locale.getDefault());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanPropertyMap(BeanPropertyMap src, SettableBeanProperty newProp, int hashIndex, int orderedIndex) {
/* 120 */     this._caseInsensitive = src._caseInsensitive;
/* 121 */     this._locale = src._locale;
/* 122 */     this._hashMask = src._hashMask;
/* 123 */     this._size = src._size;
/* 124 */     this._spillCount = src._spillCount;
/* 125 */     this._aliasDefs = src._aliasDefs;
/* 126 */     this._aliasMapping = src._aliasMapping;
/*     */ 
/*     */     
/* 129 */     this._hashArea = Arrays.copyOf(src._hashArea, src._hashArea.length);
/* 130 */     this._propsInOrder = Arrays.<SettableBeanProperty>copyOf(src._propsInOrder, src._propsInOrder.length);
/* 131 */     this._hashArea[hashIndex] = newProp;
/* 132 */     this._propsInOrder[orderedIndex] = newProp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanPropertyMap(BeanPropertyMap src, SettableBeanProperty newProp, String key, int slot) {
/* 143 */     this._caseInsensitive = src._caseInsensitive;
/* 144 */     this._locale = src._locale;
/* 145 */     this._hashMask = src._hashMask;
/* 146 */     this._size = src._size;
/* 147 */     this._spillCount = src._spillCount;
/* 148 */     this._aliasDefs = src._aliasDefs;
/* 149 */     this._aliasMapping = src._aliasMapping;
/*     */ 
/*     */     
/* 152 */     this._hashArea = Arrays.copyOf(src._hashArea, src._hashArea.length);
/* 153 */     int last = src._propsInOrder.length;
/*     */     
/* 155 */     this._propsInOrder = Arrays.<SettableBeanProperty>copyOf(src._propsInOrder, last + 1);
/* 156 */     this._propsInOrder[last] = newProp;
/*     */     
/* 158 */     int hashSize = this._hashMask + 1;
/* 159 */     int ix = slot << 1;
/*     */ 
/*     */     
/* 162 */     if (this._hashArea[ix] != null) {
/*     */       
/* 164 */       ix = hashSize + (slot >> 1) << 1;
/* 165 */       if (this._hashArea[ix] != null) {
/*     */         
/* 167 */         ix = (hashSize + (hashSize >> 1) << 1) + this._spillCount;
/* 168 */         this._spillCount += 2;
/* 169 */         if (ix >= this._hashArea.length) {
/* 170 */           this._hashArea = Arrays.copyOf(this._hashArea, this._hashArea.length + 4);
/*     */         }
/*     */       } 
/*     */     } 
/* 174 */     this._hashArea[ix] = key;
/* 175 */     this._hashArea[ix + 1] = newProp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanPropertyMap(BeanPropertyMap base, boolean caseInsensitive) {
/* 183 */     this._caseInsensitive = caseInsensitive;
/* 184 */     this._locale = base._locale;
/* 185 */     this._aliasDefs = base._aliasDefs;
/* 186 */     this._aliasMapping = base._aliasMapping;
/*     */ 
/*     */     
/* 189 */     this._propsInOrder = Arrays.<SettableBeanProperty>copyOf(base._propsInOrder, base._propsInOrder.length);
/* 190 */     init(Arrays.asList(this._propsInOrder));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyMap withCaseInsensitivity(boolean state) {
/* 201 */     if (this._caseInsensitive == state) {
/* 202 */       return this;
/*     */     }
/* 204 */     return new BeanPropertyMap(this, state);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void init(Collection<SettableBeanProperty> props) {
/* 209 */     this._size = props.size();
/*     */ 
/*     */     
/* 212 */     int hashSize = findSize(this._size);
/* 213 */     this._hashMask = hashSize - 1;
/*     */ 
/*     */     
/* 216 */     int alloc = (hashSize + (hashSize >> 1)) * 2;
/* 217 */     Object[] hashed = new Object[alloc];
/* 218 */     int spillCount = 0;
/*     */     
/* 220 */     for (SettableBeanProperty prop : props) {
/*     */       
/* 222 */       if (prop == null) {
/*     */         continue;
/*     */       }
/*     */       
/* 226 */       String key = getPropertyName(prop);
/* 227 */       int slot = _hashCode(key);
/* 228 */       int ix = slot << 1;
/*     */ 
/*     */       
/* 231 */       if (hashed[ix] != null) {
/*     */         
/* 233 */         ix = hashSize + (slot >> 1) << 1;
/* 234 */         if (hashed[ix] != null) {
/*     */           
/* 236 */           ix = (hashSize + (hashSize >> 1) << 1) + spillCount;
/* 237 */           spillCount += 2;
/* 238 */           if (ix >= hashed.length) {
/* 239 */             hashed = Arrays.copyOf(hashed, hashed.length + 4);
/*     */           }
/*     */         } 
/*     */       } 
/* 243 */       hashed[ix] = key;
/* 244 */       hashed[ix + 1] = prop;
/*     */     } 
/*     */ 
/*     */     
/* 248 */     this._hashArea = hashed;
/* 249 */     this._spillCount = spillCount;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final int findSize(int size) {
/* 254 */     if (size <= 5) {
/* 255 */       return 8;
/*     */     }
/* 257 */     if (size <= 12) {
/* 258 */       return 16;
/*     */     }
/* 260 */     int needed = size + (size >> 2);
/* 261 */     int result = 32;
/* 262 */     while (result < needed) {
/* 263 */       result += result;
/*     */     }
/* 265 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BeanPropertyMap construct(MapperConfig<?> config, Collection<SettableBeanProperty> props, Map<String, List<PropertyName>> aliasMapping, boolean caseInsensitive) {
/* 275 */     return new BeanPropertyMap(caseInsensitive, props, aliasMapping, config
/*     */         
/* 277 */         .getLocale());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static BeanPropertyMap construct(MapperConfig<?> config, Collection<SettableBeanProperty> props, Map<String, List<PropertyName>> aliasMapping) {
/* 288 */     return new BeanPropertyMap(config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES), props, aliasMapping, config
/*     */         
/* 290 */         .getLocale());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static BeanPropertyMap construct(Collection<SettableBeanProperty> props, boolean caseInsensitive, Map<String, List<PropertyName>> aliasMapping) {
/* 299 */     return new BeanPropertyMap(caseInsensitive, props, aliasMapping);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyMap withProperty(SettableBeanProperty newProp) {
/* 312 */     String key = getPropertyName(newProp);
/*     */     
/* 314 */     for (int i = 1, end = this._hashArea.length; i < end; i += 2) {
/* 315 */       SettableBeanProperty prop = (SettableBeanProperty)this._hashArea[i];
/* 316 */       if (prop != null && prop.getName().equals(key)) {
/* 317 */         return new BeanPropertyMap(this, newProp, i, _findFromOrdered(prop));
/*     */       }
/*     */     } 
/*     */     
/* 321 */     int slot = _hashCode(key);
/*     */     
/* 323 */     return new BeanPropertyMap(this, newProp, key, slot);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyMap assignIndexes() {
/* 329 */     int index = 0;
/* 330 */     for (int i = 1, end = this._hashArea.length; i < end; i += 2) {
/* 331 */       SettableBeanProperty prop = (SettableBeanProperty)this._hashArea[i];
/* 332 */       if (prop != null) {
/* 333 */         prop.assignIndex(index++);
/*     */       }
/*     */     } 
/* 336 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyMap renameAll(NameTransformer transformer) {
/* 345 */     if (transformer == null || transformer == NameTransformer.NOP) {
/* 346 */       return this;
/*     */     }
/*     */     
/* 349 */     int len = this._propsInOrder.length;
/* 350 */     ArrayList<SettableBeanProperty> newProps = new ArrayList<>(len);
/*     */     
/* 352 */     for (int i = 0; i < len; i++) {
/* 353 */       SettableBeanProperty prop = this._propsInOrder[i];
/*     */ 
/*     */       
/* 356 */       if (prop == null) {
/* 357 */         newProps.add(prop);
/*     */       } else {
/*     */         
/* 360 */         newProps.add(prop.unwrapped(transformer));
/*     */       } 
/*     */     } 
/*     */     
/* 364 */     return new BeanPropertyMap(this._caseInsensitive, newProps, this._aliasDefs, this._locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyMap withoutProperties(Collection<String> toExclude) {
/* 382 */     return withoutProperties(toExclude, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanPropertyMap withoutProperties(Collection<String> toExclude, Collection<String> toInclude) {
/* 395 */     if ((toExclude == null || toExclude.isEmpty()) && toInclude == null) {
/* 396 */       return this;
/*     */     }
/* 398 */     int len = this._propsInOrder.length;
/* 399 */     ArrayList<SettableBeanProperty> newProps = new ArrayList<>(len);
/*     */     
/* 401 */     for (int i = 0; i < len; i++) {
/* 402 */       SettableBeanProperty prop = this._propsInOrder[i];
/*     */ 
/*     */ 
/*     */       
/* 406 */       if (prop != null && 
/* 407 */         !IgnorePropertiesUtil.shouldIgnore(prop.getName(), toExclude, toInclude)) {
/* 408 */         newProps.add(prop);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 413 */     return new BeanPropertyMap(this._caseInsensitive, newProps, this._aliasDefs, this._locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void replace(SettableBeanProperty origProp, SettableBeanProperty newProp) {
/* 425 */     int i = 1;
/* 426 */     int end = this._hashArea.length;
/*     */     
/* 428 */     for (;; i += 2) {
/* 429 */       if (i >= end) {
/* 430 */         throw new NoSuchElementException("No entry '" + origProp.getName() + "' found, can't replace");
/*     */       }
/* 432 */       if (this._hashArea[i] == origProp) {
/* 433 */         this._hashArea[i] = newProp;
/*     */         break;
/*     */       } 
/*     */     } 
/* 437 */     this._propsInOrder[_findFromOrdered(origProp)] = newProp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(SettableBeanProperty propToRm) {
/* 446 */     ArrayList<SettableBeanProperty> props = new ArrayList<>(this._size);
/* 447 */     String key = getPropertyName(propToRm);
/* 448 */     boolean found = false;
/*     */     
/* 450 */     for (int i = 1, end = this._hashArea.length; i < end; i += 2) {
/* 451 */       SettableBeanProperty prop = (SettableBeanProperty)this._hashArea[i];
/* 452 */       if (prop == null) {
/*     */         continue;
/*     */       }
/* 455 */       if (!found) {
/*     */ 
/*     */         
/* 458 */         found = key.equals(this._hashArea[i - 1]);
/* 459 */         if (found) {
/*     */           
/* 461 */           this._propsInOrder[_findFromOrdered(prop)] = null;
/*     */           continue;
/*     */         } 
/*     */       } 
/* 465 */       props.add(prop); continue;
/*     */     } 
/* 467 */     if (!found) {
/* 468 */       throw new NoSuchElementException("No entry '" + propToRm.getName() + "' found, can't remove");
/*     */     }
/* 470 */     init(props);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 479 */     return this._size;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCaseInsensitive() {
/* 485 */     return this._caseInsensitive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAliases() {
/* 492 */     return !this._aliasDefs.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<SettableBeanProperty> iterator() {
/* 500 */     return _properties().iterator();
/*     */   }
/*     */   
/*     */   private List<SettableBeanProperty> _properties() {
/* 504 */     ArrayList<SettableBeanProperty> p = new ArrayList<>(this._size);
/* 505 */     for (int i = 1, end = this._hashArea.length; i < end; i += 2) {
/* 506 */       SettableBeanProperty prop = (SettableBeanProperty)this._hashArea[i];
/* 507 */       if (prop != null) {
/* 508 */         p.add(prop);
/*     */       }
/*     */     } 
/* 511 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SettableBeanProperty[] getPropertiesInInsertionOrder() {
/* 523 */     return this._propsInOrder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String getPropertyName(SettableBeanProperty prop) {
/* 529 */     return this._caseInsensitive ? prop.getName().toLowerCase(this._locale) : prop.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SettableBeanProperty find(int index) {
/* 545 */     for (int i = 1, end = this._hashArea.length; i < end; i += 2) {
/* 546 */       SettableBeanProperty prop = (SettableBeanProperty)this._hashArea[i];
/* 547 */       if (prop != null && index == prop.getPropertyIndex()) {
/* 548 */         return prop;
/*     */       }
/*     */     } 
/* 551 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public SettableBeanProperty find(String key) {
/* 556 */     if (key == null) {
/* 557 */       throw new IllegalArgumentException("Cannot pass null property name");
/*     */     }
/* 559 */     if (this._caseInsensitive) {
/* 560 */       key = key.toLowerCase(this._locale);
/*     */     }
/*     */ 
/*     */     
/* 564 */     int slot = key.hashCode() & this._hashMask;
/*     */ 
/*     */ 
/*     */     
/* 568 */     int ix = slot << 1;
/* 569 */     Object match = this._hashArea[ix];
/* 570 */     if (match == key || key.equals(match)) {
/* 571 */       return (SettableBeanProperty)this._hashArea[ix + 1];
/*     */     }
/* 573 */     return _find2(key, slot, match);
/*     */   }
/*     */ 
/*     */   
/*     */   private final SettableBeanProperty _find2(String key, int slot, Object match) {
/* 578 */     if (match == null)
/*     */     {
/* 580 */       return _findWithAlias(this._aliasMapping.get(key));
/*     */     }
/*     */     
/* 583 */     int hashSize = this._hashMask + 1;
/* 584 */     int ix = hashSize + (slot >> 1) << 1;
/* 585 */     match = this._hashArea[ix];
/* 586 */     if (key.equals(match)) {
/* 587 */       return (SettableBeanProperty)this._hashArea[ix + 1];
/*     */     }
/* 589 */     if (match != null) {
/* 590 */       int i = hashSize + (hashSize >> 1) << 1;
/* 591 */       for (int end = i + this._spillCount; i < end; i += 2) {
/* 592 */         match = this._hashArea[i];
/* 593 */         if (match == key || key.equals(match)) {
/* 594 */           return (SettableBeanProperty)this._hashArea[i + 1];
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 599 */     return _findWithAlias(this._aliasMapping.get(key));
/*     */   }
/*     */ 
/*     */   
/*     */   private SettableBeanProperty _findWithAlias(String keyFromAlias) {
/* 604 */     if (keyFromAlias == null) {
/* 605 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 609 */     int slot = _hashCode(keyFromAlias);
/* 610 */     int ix = slot << 1;
/* 611 */     Object match = this._hashArea[ix];
/* 612 */     if (keyFromAlias.equals(match)) {
/* 613 */       return (SettableBeanProperty)this._hashArea[ix + 1];
/*     */     }
/* 615 */     if (match == null) {
/* 616 */       return null;
/*     */     }
/* 618 */     return _find2ViaAlias(keyFromAlias, slot, match);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private SettableBeanProperty _find2ViaAlias(String key, int slot, Object match) {
/* 624 */     int hashSize = this._hashMask + 1;
/* 625 */     int ix = hashSize + (slot >> 1) << 1;
/* 626 */     match = this._hashArea[ix];
/* 627 */     if (key.equals(match)) {
/* 628 */       return (SettableBeanProperty)this._hashArea[ix + 1];
/*     */     }
/* 630 */     if (match != null) {
/* 631 */       int i = hashSize + (hashSize >> 1) << 1;
/* 632 */       for (int end = i + this._spillCount; i < end; i += 2) {
/* 633 */         match = this._hashArea[i];
/* 634 */         if (match == key || key.equals(match)) {
/* 635 */           return (SettableBeanProperty)this._hashArea[i + 1];
/*     */         }
/*     */       } 
/*     */     } 
/* 639 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean findDeserializeAndSet(JsonParser p, DeserializationContext ctxt, Object bean, String key) throws IOException {
/* 660 */     SettableBeanProperty prop = find(key);
/* 661 */     if (prop == null) {
/* 662 */       return false;
/*     */     }
/*     */     try {
/* 665 */       prop.deserializeAndSet(p, ctxt, bean);
/* 666 */     } catch (Exception e) {
/* 667 */       wrapAndThrow(e, bean, key, ctxt);
/*     */     } 
/* 669 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 681 */     StringBuilder sb = new StringBuilder();
/* 682 */     sb.append("Properties=[");
/* 683 */     int count = 0;
/*     */     
/* 685 */     Iterator<SettableBeanProperty> it = iterator();
/* 686 */     while (it.hasNext()) {
/* 687 */       SettableBeanProperty prop = it.next();
/* 688 */       if (count++ > 0) {
/* 689 */         sb.append(", ");
/*     */       }
/* 691 */       sb.append(prop.getName());
/* 692 */       sb.append('(');
/* 693 */       sb.append(prop.getType());
/* 694 */       sb.append(')');
/*     */     } 
/* 696 */     sb.append(']');
/* 697 */     if (!this._aliasDefs.isEmpty()) {
/* 698 */       sb.append("(aliases: ");
/* 699 */       sb.append(this._aliasDefs);
/* 700 */       sb.append(")");
/*     */     } 
/* 702 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected SettableBeanProperty _rename(SettableBeanProperty prop, NameTransformer xf) {
/* 713 */     return prop.unwrapped(xf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void wrapAndThrow(Throwable t, Object bean, String fieldName, DeserializationContext ctxt) throws IOException {
/* 720 */     while (t instanceof java.lang.reflect.InvocationTargetException && t.getCause() != null) {
/* 721 */       t = t.getCause();
/*     */     }
/*     */     
/* 724 */     ClassUtil.throwIfError(t);
/*     */     
/* 726 */     boolean wrap = (ctxt == null || ctxt.isEnabled(DeserializationFeature.WRAP_EXCEPTIONS));
/*     */     
/* 728 */     if (t instanceof IOException) {
/* 729 */       if (!wrap || !(t instanceof com.fasterxml.jackson.core.JacksonException)) {
/* 730 */         throw (IOException)t;
/*     */       }
/* 732 */     } else if (!wrap) {
/* 733 */       ClassUtil.throwIfRTE(t);
/*     */     } 
/* 735 */     throw JsonMappingException.wrapWithPath(t, bean, fieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int _findFromOrdered(SettableBeanProperty prop) {
/* 774 */     for (int i = 0, end = this._propsInOrder.length; i < end; i++) {
/* 775 */       if (this._propsInOrder[i] == prop) {
/* 776 */         return i;
/*     */       }
/*     */     } 
/* 779 */     throw new IllegalStateException("Illegal state: property '" + prop.getName() + "' missing from _propsInOrder");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int _hashCode(String key) {
/* 793 */     return key.hashCode() & this._hashMask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, String> _buildAliasMapping(Map<String, List<PropertyName>> defs, boolean caseInsensitive, Locale loc) {
/* 800 */     if (defs == null || defs.isEmpty()) {
/* 801 */       return Collections.emptyMap();
/*     */     }
/* 803 */     Map<String, String> aliases = new HashMap<>();
/* 804 */     for (Map.Entry<String, List<PropertyName>> entry : defs.entrySet()) {
/* 805 */       String key = entry.getKey();
/* 806 */       if (caseInsensitive) {
/* 807 */         key = key.toLowerCase(loc);
/*     */       }
/* 809 */       for (PropertyName pn : entry.getValue()) {
/* 810 */         String mapped = pn.getSimpleName();
/* 811 */         if (caseInsensitive) {
/* 812 */           mapped = mapped.toLowerCase(loc);
/*     */         }
/* 814 */         aliases.put(mapped, key);
/*     */       } 
/*     */     } 
/* 817 */     return aliases;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\impl\BeanPropertyMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */