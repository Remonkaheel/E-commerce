/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.util.VersionUtil;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*     */ import com.fasterxml.jackson.databind.exc.InvalidFormatException;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Currency;
/*     */ import java.util.IllformedLocaleException;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FromStringDeserializer<T>
/*     */   extends StdScalarDeserializer<T>
/*     */ {
/*     */   public static Class<?>[] types() {
/*  62 */     return new Class[] { File.class, URL.class, URI.class, Class.class, JavaType.class, Currency.class, Pattern.class, Locale.class, Charset.class, TimeZone.class, InetAddress.class, InetSocketAddress.class, StringBuilder.class, StringBuffer.class };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FromStringDeserializer(Class<?> vc) {
/*  89 */     super(vc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FromStringDeserializer<?> findDeserializer(Class<?> rawType) {
/*  98 */     int kind = 0;
/*  99 */     if (rawType == File.class)
/* 100 */     { kind = 1; }
/* 101 */     else if (rawType == URL.class)
/* 102 */     { kind = 2; }
/* 103 */     else if (rawType == URI.class)
/* 104 */     { kind = 3; }
/* 105 */     else if (rawType == Class.class)
/* 106 */     { kind = 4; }
/* 107 */     else if (rawType == JavaType.class)
/* 108 */     { kind = 5; }
/* 109 */     else if (rawType == Currency.class)
/* 110 */     { kind = 6; }
/* 111 */     else if (rawType == Pattern.class)
/* 112 */     { kind = 7; }
/* 113 */     else if (rawType == Locale.class)
/* 114 */     { kind = 8; }
/* 115 */     else if (rawType == Charset.class)
/* 116 */     { kind = 9; }
/* 117 */     else if (rawType == TimeZone.class)
/* 118 */     { kind = 10; }
/* 119 */     else if (rawType == InetAddress.class)
/* 120 */     { kind = 11; }
/* 121 */     else if (rawType == InetSocketAddress.class)
/* 122 */     { kind = 12; }
/* 123 */     else { if (rawType == StringBuilder.class)
/* 124 */         return new StringBuilderDeserializer(); 
/* 125 */       if (rawType == StringBuffer.class) {
/* 126 */         return new StringBufferDeserializer();
/*     */       }
/* 128 */       return null; }
/*     */     
/* 130 */     return new Std(rawType, kind);
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 135 */     return LogicalType.OtherScalar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 149 */     String text = p.getValueAsString();
/* 150 */     if (text == null) {
/* 151 */       JsonToken t = p.currentToken();
/* 152 */       if (t != JsonToken.START_OBJECT) {
/* 153 */         return (T)_deserializeFromOther(p, ctxt, t);
/*     */       }
/*     */       
/* 156 */       text = ctxt.extractScalarFromObject(p, this, this._valueClass);
/*     */     } 
/* 158 */     if (text.isEmpty())
/*     */     {
/* 160 */       return (T)_deserializeFromEmptyString(ctxt);
/*     */     }
/* 162 */     if (_shouldTrim()) {
/* 163 */       String old = text;
/* 164 */       text = text.trim();
/* 165 */       if (text != old && 
/* 166 */         text.isEmpty()) {
/* 167 */         return (T)_deserializeFromEmptyString(ctxt);
/*     */       }
/*     */     } 
/*     */     
/* 171 */     Exception cause = null;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 176 */       return _deserialize(text, ctxt);
/* 177 */     } catch (IllegalArgumentException|java.net.MalformedURLException e) {
/* 178 */       cause = e;
/*     */ 
/*     */       
/* 181 */       String msg = "not a valid textual representation";
/* 182 */       String m2 = cause.getMessage();
/* 183 */       if (m2 != null) {
/* 184 */         msg = msg + ", problem: " + m2;
/*     */       }
/*     */       
/* 187 */       throw ctxt.weirdStringException(text, this._valueClass, msg)
/* 188 */         .withCause(cause);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract T _deserialize(String paramString, DeserializationContext paramDeserializationContext) throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _shouldTrim() {
/* 199 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserializeFromOther(JsonParser p, DeserializationContext ctxt, JsonToken t) throws IOException {
/* 207 */     if (t == JsonToken.START_ARRAY) {
/* 208 */       return _deserializeFromArray(p, ctxt);
/*     */     }
/* 210 */     if (t == JsonToken.VALUE_EMBEDDED_OBJECT) {
/*     */       
/* 212 */       Object ob = p.getEmbeddedObject();
/* 213 */       if (ob == null) {
/* 214 */         return null;
/*     */       }
/* 216 */       if (this._valueClass.isAssignableFrom(ob.getClass())) {
/* 217 */         return ob;
/*     */       }
/* 219 */       return _deserializeEmbedded(ob, ctxt);
/*     */     } 
/* 221 */     return ctxt.handleUnexpectedToken(this._valueClass, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T _deserializeEmbedded(Object ob, DeserializationContext ctxt) throws IOException {
/* 231 */     ctxt.reportInputMismatch(this, "Don't know how to convert embedded Object of type %s into %s", new Object[] { ob
/*     */           
/* 233 */           .getClass().getName(), this._valueClass.getName() });
/* 234 */     return null;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected final T _deserializeFromEmptyString() throws IOException {
/* 239 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserializeFromEmptyString(DeserializationContext ctxt) throws IOException {
/* 246 */     CoercionAction act = ctxt.findCoercionAction(logicalType(), this._valueClass, CoercionInputShape.EmptyString);
/*     */     
/* 248 */     if (act == CoercionAction.Fail)
/* 249 */       ctxt.reportInputMismatch(this, "Cannot coerce empty String (\"\") to %s (but could if enabling coercion using `CoercionConfig`)", new Object[] {
/*     */             
/* 251 */             _coercedTypeDesc()
/*     */           }); 
/* 253 */     if (act == CoercionAction.AsNull) {
/* 254 */       return getNullValue(ctxt);
/*     */     }
/* 256 */     if (act == CoercionAction.AsEmpty) {
/* 257 */       return getEmptyValue(ctxt);
/*     */     }
/*     */ 
/*     */     
/* 261 */     return _deserializeFromEmptyStringDefault(ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserializeFromEmptyStringDefault(DeserializationContext ctxt) throws IOException {
/* 269 */     return getNullValue(ctxt);
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Std
/*     */     extends FromStringDeserializer<Object>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     public static final int STD_FILE = 1;
/*     */     
/*     */     public static final int STD_URL = 2;
/*     */     
/*     */     public static final int STD_URI = 3;
/*     */     
/*     */     public static final int STD_CLASS = 4;
/*     */     
/*     */     public static final int STD_JAVA_TYPE = 5;
/*     */     
/*     */     public static final int STD_CURRENCY = 6;
/*     */     
/*     */     public static final int STD_PATTERN = 7;
/*     */     
/*     */     public static final int STD_LOCALE = 8;
/*     */     
/*     */     public static final int STD_CHARSET = 9;
/*     */     
/*     */     public static final int STD_TIME_ZONE = 10;
/*     */     
/*     */     public static final int STD_INET_ADDRESS = 11;
/*     */     
/*     */     public static final int STD_INET_SOCKET_ADDRESS = 12;
/*     */     
/*     */     protected static final String LOCALE_EXT_MARKER = "_#";
/*     */     
/*     */     protected final int _kind;
/*     */ 
/*     */     
/*     */     protected Std(Class<?> valueType, int kind) {
/* 308 */       super(valueType);
/* 309 */       this._kind = kind;
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object _deserialize(String value, DeserializationContext ctxt) throws IOException {
/*     */       int ix;
/* 315 */       switch (this._kind) {
/*     */         case 1:
/* 317 */           return new File(value);
/*     */         case 2:
/* 319 */           return new URL(value);
/*     */         case 3:
/* 321 */           return URI.create(value);
/*     */         case 4:
/*     */           try {
/* 324 */             return ctxt.findClass(value);
/* 325 */           } catch (Exception e) {
/* 326 */             return ctxt.handleInstantiationProblem(this._valueClass, value, 
/* 327 */                 ClassUtil.getRootCause(e));
/*     */           } 
/*     */         case 5:
/* 330 */           return ctxt.getTypeFactory().constructFromCanonical(value);
/*     */         
/*     */         case 6:
/*     */           try {
/* 334 */             return Currency.getInstance(value);
/* 335 */           } catch (IllegalArgumentException e) {
/*     */             
/* 337 */             return ctxt.handleWeirdStringValue(this._valueClass, value, "Unrecognized currency", new Object[0]);
/*     */           } 
/*     */         
/*     */         case 7:
/*     */           try {
/* 342 */             return Pattern.compile(value);
/* 343 */           } catch (PatternSyntaxException e) {
/* 344 */             return ctxt.handleWeirdStringValue(this._valueClass, value, "Invalid Pattern, problem: " + e
/* 345 */                 .getDescription(), new Object[0]);
/*     */           } 
/*     */         case 8:
/* 348 */           return _deserializeLocale(value, ctxt);
/*     */         case 9:
/* 350 */           return Charset.forName(value);
/*     */         case 10:
/* 352 */           return TimeZone.getTimeZone(value);
/*     */         case 11:
/* 354 */           return InetAddress.getByName(value);
/*     */         case 12:
/* 356 */           if (value.startsWith("[")) {
/*     */ 
/*     */             
/* 359 */             int i = value.lastIndexOf(']');
/* 360 */             if (i == -1) {
/* 361 */               throw new InvalidFormatException(ctxt.getParser(), "Bracketed IPv6 address must contain closing bracket", value, InetSocketAddress.class);
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 366 */             int j = value.indexOf(':', i);
/* 367 */             int port = (j > -1) ? Integer.parseInt(value.substring(j + 1)) : 0;
/* 368 */             return new InetSocketAddress(value.substring(0, i + 1), port);
/*     */           } 
/* 370 */           ix = value.indexOf(':');
/* 371 */           if (ix >= 0 && value.indexOf(':', ix + 1) < 0) {
/*     */             
/* 373 */             int port = Integer.parseInt(value.substring(ix + 1));
/* 374 */             return new InetSocketAddress(value.substring(0, ix), port);
/*     */           } 
/*     */           
/* 377 */           return new InetSocketAddress(value, 0);
/*     */       } 
/* 379 */       VersionUtil.throwInternal();
/* 380 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/* 387 */       switch (this._kind) {
/*     */         
/*     */         case 3:
/* 390 */           return URI.create("");
/*     */         
/*     */         case 8:
/* 393 */           return Locale.ROOT;
/*     */       } 
/* 395 */       return super.getEmptyValue(ctxt);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Object _deserializeFromEmptyStringDefault(DeserializationContext ctxt) throws IOException {
/* 403 */       return getEmptyValue(ctxt);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected boolean _shouldTrim() {
/* 410 */       return (this._kind != 7);
/*     */     }
/*     */ 
/*     */     
/*     */     protected int _firstHyphenOrUnderscore(String str) {
/* 415 */       for (int i = 0, end = str.length(); i < end; i++) {
/* 416 */         char c = str.charAt(i);
/* 417 */         if (c == '_' || c == '-') {
/* 418 */           return i;
/*     */         }
/*     */       } 
/* 421 */       return -1;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Locale _deserializeLocale(String value, DeserializationContext ctxt) throws IOException {
/* 427 */       int ix = _firstHyphenOrUnderscore(value);
/* 428 */       if (ix < 0) {
/* 429 */         return new Locale(value);
/*     */       }
/* 431 */       String first = value.substring(0, ix);
/* 432 */       value = value.substring(ix + 1);
/* 433 */       ix = _firstHyphenOrUnderscore(value);
/* 434 */       if (ix < 0) {
/* 435 */         return new Locale(first, value);
/*     */       }
/* 437 */       String second = value.substring(0, ix);
/*     */       
/* 439 */       int extMarkerIx = value.indexOf("_#");
/* 440 */       if (extMarkerIx < 0) {
/* 441 */         return new Locale(first, second, value.substring(ix + 1));
/*     */       }
/* 443 */       return _deSerializeBCP47Locale(value, ix, first, second, extMarkerIx);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Locale _deSerializeBCP47Locale(String value, int ix, String first, String second, int extMarkerIx) {
/* 449 */       String third = "";
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 454 */         if (extMarkerIx > 0 && extMarkerIx > ix) {
/* 455 */           third = value.substring(ix + 1, extMarkerIx);
/*     */         }
/* 457 */         value = value.substring(extMarkerIx + 2);
/*     */         
/* 459 */         int underscoreIx = value.indexOf('_');
/* 460 */         if (underscoreIx < 0) {
/* 461 */           int hyphenIx = value.indexOf('-');
/* 462 */           if (hyphenIx < 0) {
/* 463 */             return (new Locale.Builder()).setLanguage(first)
/* 464 */               .setRegion(second)
/* 465 */               .setVariant(third)
/* 466 */               .setScript(value)
/* 467 */               .build();
/*     */           }
/* 469 */           return (new Locale.Builder()).setLanguage(first)
/* 470 */             .setRegion(second).setVariant(third)
/* 471 */             .setExtension(value.charAt(0), value.substring(hyphenIx + 1))
/* 472 */             .build();
/*     */         } 
/* 474 */         int len = value.length();
/*     */ 
/*     */ 
/*     */         
/* 478 */         Locale.Builder b = (new Locale.Builder()).setLanguage(first).setRegion(second).setVariant(third).setScript(value.substring(0, underscoreIx));
/* 479 */         if (underscoreIx + 1 < len) {
/* 480 */           b = b.setExtension(value.charAt(underscoreIx + 1), value
/* 481 */               .substring(Math.min(len, underscoreIx + 3)));
/*     */         }
/* 483 */         return b.build();
/* 484 */       } catch (IllformedLocaleException ex) {
/*     */         
/* 486 */         return new Locale(first, second, third);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   static class StringBuilderDeserializer
/*     */     extends FromStringDeserializer<Object>
/*     */   {
/*     */     public StringBuilderDeserializer() {
/* 495 */       super(StringBuilder.class);
/*     */     }
/*     */ 
/*     */     
/*     */     public LogicalType logicalType() {
/* 500 */       return LogicalType.Textual;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/* 507 */       return new StringBuilder();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 513 */       String text = p.getValueAsString();
/* 514 */       if (text != null) {
/* 515 */         return _deserialize(text, ctxt);
/*     */       }
/* 517 */       return super.deserialize(p, ctxt);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Object _deserialize(String value, DeserializationContext ctxt) throws IOException {
/* 524 */       return new StringBuilder(value);
/*     */     }
/*     */   }
/*     */   
/*     */   static class StringBufferDeserializer
/*     */     extends FromStringDeserializer<Object> {
/*     */     public StringBufferDeserializer() {
/* 531 */       super(StringBuffer.class);
/*     */     }
/*     */     public LogicalType logicalType() {
/* 534 */       return LogicalType.Textual;
/*     */     }
/*     */     
/*     */     public Object getEmptyValue(DeserializationContext ctxt) {
/* 538 */       return new StringBuffer();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 544 */       String text = p.getValueAsString();
/* 545 */       if (text != null) {
/* 546 */         return _deserialize(text, ctxt);
/*     */       }
/* 548 */       return super.deserialize(p, ctxt);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Object _deserialize(String value, DeserializationContext ctxt) throws IOException {
/* 555 */       return new StringBuffer(value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\FromStringDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */