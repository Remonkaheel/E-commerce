/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DatabindException;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.deser.SettableAnyProperty;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import java.io.IOException;
/*     */ import java.util.BitSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyValueBuffer
/*     */ {
/*     */   protected final JsonParser _parser;
/*     */   protected final DeserializationContext _context;
/*     */   protected final ObjectIdReader _objectIdReader;
/*     */   protected final Object[] _creatorParameters;
/*     */   protected int _paramsNeeded;
/*     */   protected int _paramsSeen;
/*     */   protected final BitSet _paramsSeenBig;
/*     */   protected PropertyValue _buffered;
/*     */   protected Object _idValue;
/*     */   protected final SettableAnyProperty _anyParamSetter;
/*     */   protected PropertyValue _anyParamBuffered;
/*     */   
/*     */   public PropertyValueBuffer(JsonParser p, DeserializationContext ctxt, int paramCount, ObjectIdReader oir, SettableAnyProperty anyParamSetter) {
/* 104 */     this._parser = p;
/* 105 */     this._context = ctxt;
/* 106 */     this._paramsNeeded = paramCount;
/* 107 */     this._objectIdReader = oir;
/* 108 */     this._creatorParameters = new Object[paramCount];
/* 109 */     if (paramCount < 32) {
/* 110 */       this._paramsSeenBig = null;
/*     */     } else {
/* 112 */       this._paramsSeenBig = new BitSet();
/*     */     } 
/*     */     
/* 115 */     if (anyParamSetter == null || anyParamSetter.getParameterIndex() < 0) {
/* 116 */       this._anyParamSetter = null;
/*     */     } else {
/* 118 */       this._anyParamSetter = anyParamSetter;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public PropertyValueBuffer(JsonParser p, DeserializationContext ctxt, int paramCount, ObjectIdReader oir) {
/* 126 */     this(p, ctxt, paramCount, oir, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean hasParameter(SettableBeanProperty prop) {
/* 137 */     int ix = prop.getCreatorIndex();
/*     */     
/* 139 */     if (this._paramsSeenBig == null) {
/* 140 */       if ((this._paramsSeen >> ix & 0x1) == 1) {
/* 141 */         return true;
/*     */       }
/*     */     }
/* 144 */     else if (this._paramsSeenBig.get(ix)) {
/* 145 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 149 */     if (this._anyParamSetter != null && 
/* 150 */       ix == this._anyParamSetter.getParameterIndex()) {
/* 151 */       return true;
/*     */     }
/*     */     
/* 154 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getParameter(SettableBeanProperty prop) throws JsonMappingException {
/*     */     Object value;
/* 171 */     if (hasParameter(prop)) {
/* 172 */       value = this._creatorParameters[prop.getCreatorIndex()];
/*     */     } else {
/* 174 */       value = this._creatorParameters[prop.getCreatorIndex()] = _findMissing(prop);
/*     */     } 
/*     */     
/* 177 */     if (value == null && this._anyParamSetter != null && prop
/* 178 */       .getCreatorIndex() == this._anyParamSetter.getParameterIndex()) {
/* 179 */       value = _createAndSetAnySetterValue();
/*     */     }
/* 181 */     if (value == null && this._context.isEnabled(DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES)) {
/* 182 */       return this._context.reportInputMismatch((BeanProperty)prop, "Null value for creator property '%s' (index %d); `DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES` enabled", new Object[] { prop
/*     */             
/* 184 */             .getName(), Integer.valueOf(prop.getCreatorIndex()) });
/*     */     }
/* 186 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getParameters(SettableBeanProperty[] props) throws JsonMappingException, IOException {
/* 200 */     if (this._paramsNeeded > 0) {
/* 201 */       if (this._paramsSeenBig == null) {
/* 202 */         int mask = this._paramsSeen;
/*     */ 
/*     */         
/* 205 */         for (int ix = 0, len = this._creatorParameters.length; ix < len; ix++, mask >>= 1) {
/* 206 */           if ((mask & 0x1) == 0) {
/* 207 */             this._creatorParameters[ix] = _findMissing(props[ix]);
/*     */           }
/*     */         } 
/*     */       } else {
/* 211 */         int len = this._creatorParameters.length;
/* 212 */         for (int ix = 0; (ix = this._paramsSeenBig.nextClearBit(ix)) < len; ix++) {
/* 213 */           this._creatorParameters[ix] = _findMissing(props[ix]);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 218 */     if (this._anyParamSetter != null) {
/* 219 */       this._creatorParameters[this._anyParamSetter.getParameterIndex()] = _createAndSetAnySetterValue();
/*     */     }
/* 221 */     if (this._context.isEnabled(DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES)) {
/* 222 */       for (int ix = 0; ix < props.length; ix++) {
/* 223 */         if (this._creatorParameters[ix] == null) {
/* 224 */           SettableBeanProperty prop = props[ix];
/* 225 */           this._context.reportInputMismatch((BeanProperty)prop, "Null value for creator property '%s' (index %d); `DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES` enabled", new Object[] { prop
/*     */                 
/* 227 */                 .getName(), Integer.valueOf(props[ix].getCreatorIndex()) });
/*     */         } 
/*     */       } 
/*     */     }
/* 231 */     return this._creatorParameters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object _createAndSetAnySetterValue() throws JsonMappingException {
/* 239 */     Object anySetterParameterObject = this._anyParamSetter.createParameterObject();
/* 240 */     for (PropertyValue pv = this._anyParamBuffered; pv != null; pv = pv.next) {
/*     */       try {
/* 242 */         pv.setValue(anySetterParameterObject);
/*     */ 
/*     */       
/*     */       }
/* 246 */       catch (JsonMappingException e) {
/* 247 */         throw e;
/* 248 */       } catch (IOException e) {
/* 249 */         throw JsonMappingException.fromUnexpectedIOE(e);
/*     */       } 
/*     */     } 
/* 252 */     return anySetterParameterObject;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _findMissing(SettableBeanProperty prop) throws JsonMappingException {
/* 258 */     if (this._anyParamSetter != null && 
/* 259 */       prop.getCreatorIndex() == this._anyParamSetter.getParameterIndex())
/*     */     {
/* 261 */       if (this._anyParamBuffered != null)
/*     */       {
/* 263 */         return null;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 269 */     Object injectableValueId = prop.getInjectableValueId();
/* 270 */     if (injectableValueId != null) {
/* 271 */       return this._context.findInjectableValue(prop.getInjectableValueId(), (BeanProperty)prop, null);
/*     */     }
/*     */ 
/*     */     
/* 275 */     if (prop.isRequired()) {
/* 276 */       this._context.reportInputMismatch((BeanProperty)prop, "Missing required creator property '%s' (index %d)", new Object[] { prop
/* 277 */             .getName(), Integer.valueOf(prop.getCreatorIndex()) });
/*     */     }
/* 279 */     if (this._context.isEnabled(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES)) {
/* 280 */       this._context.reportInputMismatch((BeanProperty)prop, "Missing creator property '%s' (index %d); `DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES` enabled", new Object[] { prop
/*     */             
/* 282 */             .getName(), Integer.valueOf(prop.getCreatorIndex()) });
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 287 */       Object absentValue = prop.getNullValueProvider().getAbsentValue(this._context);
/* 288 */       if (absentValue != null) {
/* 289 */         return absentValue;
/*     */       }
/*     */ 
/*     */       
/* 293 */       JsonDeserializer<Object> deser = prop.getValueDeserializer();
/* 294 */       return deser.getAbsentValue(this._context);
/* 295 */     } catch (DatabindException e) {
/*     */       
/* 297 */       AnnotatedMember member = prop.getMember();
/* 298 */       if (member != null) {
/* 299 */         e.prependPath(member.getDeclaringClass(), prop.getName());
/*     */       }
/* 301 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean readIdProperty(String propName) throws IOException {
/* 319 */     if (this._objectIdReader != null && propName.equals(this._objectIdReader.propertyName.getSimpleName())) {
/* 320 */       this._idValue = this._objectIdReader.readObjectReference(this._parser, this._context);
/* 321 */       return true;
/*     */     } 
/* 323 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object handleIdValue(DeserializationContext ctxt, Object bean) throws IOException {
/* 331 */     if (this._objectIdReader != null) {
/* 332 */       if (this._idValue != null) {
/* 333 */         ReadableObjectId roid = ctxt.findObjectId(this._idValue, this._objectIdReader.generator, this._objectIdReader.resolver);
/* 334 */         roid.bindItem(bean);
/*     */         
/* 336 */         SettableBeanProperty idProp = this._objectIdReader.idProperty;
/* 337 */         if (idProp != null) {
/* 338 */           return idProp.setAndReturn(bean, this._idValue);
/*     */         }
/*     */       } else {
/*     */         
/* 342 */         ctxt.reportUnresolvedObjectId(this._objectIdReader, bean);
/*     */       } 
/*     */     }
/* 345 */     return bean;
/*     */   }
/*     */   protected PropertyValue buffered() {
/* 348 */     return this._buffered;
/*     */   } public boolean isComplete() {
/* 350 */     return (this._paramsNeeded <= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean assignParameter(SettableBeanProperty prop, Object value) {
/* 362 */     int ix = prop.getCreatorIndex();
/* 363 */     this._creatorParameters[ix] = value;
/* 364 */     if (this._paramsSeenBig == null) {
/* 365 */       int old = this._paramsSeen;
/* 366 */       int newValue = old | 1 << ix;
/*     */       
/* 368 */       this._paramsSeen = newValue;
/* 369 */       if (old != newValue && --this._paramsNeeded <= 0)
/*     */       {
/* 371 */         return (this._objectIdReader == null || this._idValue != null);
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 376 */       this._paramsSeenBig.set(ix);
/* 377 */       if (this._paramsSeenBig.get(ix) || --this._paramsNeeded <= 0);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 382 */     return false;
/*     */   }
/*     */   
/*     */   public void bufferProperty(SettableBeanProperty prop, Object value) {
/* 386 */     this._buffered = new PropertyValue.Regular(this._buffered, value, prop);
/*     */   }
/*     */   
/*     */   public void bufferAnyProperty(SettableAnyProperty prop, String propName, Object value) {
/* 390 */     this._buffered = new PropertyValue.Any(this._buffered, value, prop, propName);
/*     */   }
/*     */   
/*     */   public void bufferMapProperty(Object key, Object value) {
/* 394 */     this._buffered = new PropertyValue.Map(this._buffered, value, key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void bufferAnyParameterProperty(SettableAnyProperty prop, String propName, Object value) {
/* 399 */     this._anyParamBuffered = new PropertyValue.AnyParameter(this._anyParamBuffered, value, prop, propName);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\impl\PropertyValueBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */