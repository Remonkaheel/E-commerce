/*    */ package com.fasterxml.jackson.databind.deser.std;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JsonNode;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ThreadGroupDeserializer
/*    */   extends StdNodeBasedDeserializer<ThreadGroup>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   protected ThreadGroupDeserializer() {
/* 20 */     super(ThreadGroup.class);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ThreadGroup convert(JsonNode root, DeserializationContext ctxt) throws IOException {
/* 27 */     String name = root.path("name").asText();
/* 28 */     if (name == null) {
/* 29 */       name = "";
/*    */     }
/* 31 */     return new ThreadGroup(name);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\ThreadGroupDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */