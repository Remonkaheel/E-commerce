/*     */ package com.fasterxml.jackson.databind.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*     */ import java.io.Closeable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnresolvedForwardReference
/*     */   extends JsonMappingException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private ReadableObjectId _roid;
/*     */   private List<UnresolvedId> _unresolvedIds;
/*     */   
/*     */   public UnresolvedForwardReference(JsonParser p, String msg, JsonLocation loc, ReadableObjectId roid) {
/*  27 */     super((Closeable)p, msg, loc);
/*  28 */     this._roid = roid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnresolvedForwardReference(JsonParser p, String msg) {
/*  35 */     super((Closeable)p, msg);
/*  36 */     this._unresolvedIds = new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadableObjectId getRoid() {
/*  46 */     return this._roid;
/*     */   }
/*     */   
/*     */   public Object getUnresolvedId() {
/*  50 */     return (this._roid.getKey()).key;
/*     */   }
/*     */   
/*     */   public void addUnresolvedId(Object id, Class<?> type, JsonLocation where) {
/*  54 */     this._unresolvedIds.add(new UnresolvedId(id, type, where));
/*     */   }
/*     */   
/*     */   public List<UnresolvedId> getUnresolvedIds() {
/*  58 */     return this._unresolvedIds;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/*  64 */     String msg = super.getMessage();
/*  65 */     if (this._unresolvedIds == null) {
/*  66 */       return msg;
/*     */     }
/*     */     
/*  69 */     StringBuilder sb = new StringBuilder(msg);
/*  70 */     Iterator<UnresolvedId> iterator = this._unresolvedIds.iterator();
/*  71 */     while (iterator.hasNext()) {
/*  72 */       UnresolvedId unresolvedId = iterator.next();
/*  73 */       sb.append(unresolvedId.toString());
/*  74 */       if (iterator.hasNext()) {
/*  75 */         sb.append(", ");
/*     */       }
/*     */     } 
/*  78 */     sb.append('.');
/*  79 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized UnresolvedForwardReference fillInStackTrace() {
/*  93 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UnresolvedForwardReference withStackTrace() {
/* 103 */     super.fillInStackTrace();
/* 104 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\UnresolvedForwardReference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */