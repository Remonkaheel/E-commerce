/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.deser.std.StdValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedParameter;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedWithParams;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.lang.reflect.Member;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CreatorCollector
/*     */ {
/*     */   protected static final int C_DEFAULT = 0;
/*     */   protected static final int C_STRING = 1;
/*     */   protected static final int C_INT = 2;
/*     */   protected static final int C_LONG = 3;
/*     */   protected static final int C_BIG_INTEGER = 4;
/*  32 */   protected static final String[] TYPE_DESCS = new String[] { "default", "from-String", "from-int", "from-long", "from-big-integer", "from-double", "from-big-decimal", "from-boolean", "delegate", "property-based", "array-delegate" };
/*     */ 
/*     */   
/*     */   protected static final int C_DOUBLE = 5;
/*     */ 
/*     */   
/*     */   protected static final int C_BIG_DECIMAL = 6;
/*     */   
/*     */   protected static final int C_BOOLEAN = 7;
/*     */   
/*     */   protected static final int C_DELEGATE = 8;
/*     */   
/*     */   protected static final int C_PROPS = 9;
/*     */   
/*     */   protected static final int C_ARRAY_DELEGATE = 10;
/*     */   
/*     */   protected final BeanDescription _beanDesc;
/*     */   
/*     */   protected final boolean _canFixAccess;
/*     */   
/*     */   protected final boolean _forceAccess;
/*     */   
/*  54 */   protected final AnnotatedWithParams[] _creators = new AnnotatedWithParams[11];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   protected int _explicitCreators = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _hasNonDefaultCreator = false;
/*     */ 
/*     */   
/*     */   protected SettableBeanProperty[] _delegateArgs;
/*     */ 
/*     */   
/*     */   protected SettableBeanProperty[] _arrayDelegateArgs;
/*     */ 
/*     */   
/*     */   protected SettableBeanProperty[] _propertyBasedArgs;
/*     */ 
/*     */ 
/*     */   
/*     */   public CreatorCollector(BeanDescription beanDesc, MapperConfig<?> config) {
/*  81 */     this._beanDesc = beanDesc;
/*  82 */     this._canFixAccess = config.canOverrideAccessModifiers();
/*  83 */     this
/*  84 */       ._forceAccess = config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueInstantiator constructValueInstantiator(DeserializationContext ctxt) throws JsonMappingException {
/*  90 */     DeserializationConfig config = ctxt.getConfig();
/*  91 */     JavaType delegateType = _computeDelegateType(ctxt, this._creators[8], this._delegateArgs);
/*     */     
/*  93 */     JavaType arrayDelegateType = _computeDelegateType(ctxt, this._creators[10], this._arrayDelegateArgs);
/*     */     
/*  95 */     JavaType type = this._beanDesc.getType();
/*     */     
/*  97 */     StdValueInstantiator inst = new StdValueInstantiator(config, type);
/*  98 */     inst.configureFromObjectSettings(this._creators[0], this._creators[8], delegateType, this._delegateArgs, this._creators[9], this._propertyBasedArgs);
/*     */ 
/*     */     
/* 101 */     inst.configureFromArraySettings(this._creators[10], arrayDelegateType, this._arrayDelegateArgs);
/*     */     
/* 103 */     inst.configureFromStringCreator(this._creators[1]);
/* 104 */     inst.configureFromIntCreator(this._creators[2]);
/* 105 */     inst.configureFromLongCreator(this._creators[3]);
/* 106 */     inst.configureFromBigIntegerCreator(this._creators[4]);
/* 107 */     inst.configureFromDoubleCreator(this._creators[5]);
/* 108 */     inst.configureFromBigDecimalCreator(this._creators[6]);
/* 109 */     inst.configureFromBooleanCreator(this._creators[7]);
/* 110 */     return (ValueInstantiator)inst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultCreator(AnnotatedWithParams creator) {
/* 128 */     this._creators[0] = _fixAccess(creator);
/*     */   }
/*     */   
/*     */   public void addStringCreator(AnnotatedWithParams creator, boolean explicit) {
/* 132 */     verifyNonDup(creator, 1, explicit);
/*     */   }
/*     */   
/*     */   public void addIntCreator(AnnotatedWithParams creator, boolean explicit) {
/* 136 */     verifyNonDup(creator, 2, explicit);
/*     */   }
/*     */   
/*     */   public void addLongCreator(AnnotatedWithParams creator, boolean explicit) {
/* 140 */     verifyNonDup(creator, 3, explicit);
/*     */   }
/*     */   
/*     */   public void addBigIntegerCreator(AnnotatedWithParams creator, boolean explicit) {
/* 144 */     verifyNonDup(creator, 4, explicit);
/*     */   }
/*     */   
/*     */   public void addDoubleCreator(AnnotatedWithParams creator, boolean explicit) {
/* 148 */     verifyNonDup(creator, 5, explicit);
/*     */   }
/*     */   
/*     */   public void addBigDecimalCreator(AnnotatedWithParams creator, boolean explicit) {
/* 152 */     verifyNonDup(creator, 6, explicit);
/*     */   }
/*     */   
/*     */   public void addBooleanCreator(AnnotatedWithParams creator, boolean explicit) {
/* 156 */     verifyNonDup(creator, 7, explicit);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDelegatingCreator(AnnotatedWithParams creator, boolean explicit, SettableBeanProperty[] injectables, int delegateeIndex) {
/* 163 */     if (creator.getParameterType(delegateeIndex).isCollectionLikeType()) {
/* 164 */       if (verifyNonDup(creator, 10, explicit)) {
/* 165 */         this._arrayDelegateArgs = injectables;
/*     */       }
/*     */     }
/* 168 */     else if (verifyNonDup(creator, 8, explicit)) {
/* 169 */       this._delegateArgs = injectables;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPropertyCreator(AnnotatedWithParams creator, boolean explicit, SettableBeanProperty[] properties) {
/* 177 */     if (verifyNonDup(creator, 9, explicit)) {
/*     */       
/* 179 */       if (properties.length > 1) {
/* 180 */         HashMap<String, Integer> names = new HashMap<>();
/* 181 */         for (int i = 0, len = properties.length; i < len; i++) {
/* 182 */           String name = properties[i].getName();
/*     */ 
/*     */ 
/*     */           
/* 186 */           if (!name.isEmpty() || properties[i].getInjectableValueId() == null) {
/*     */ 
/*     */             
/* 189 */             Integer old = names.put(name, Integer.valueOf(i));
/* 190 */             if (old != null)
/* 191 */               throw new IllegalArgumentException(String.format("Duplicate creator property \"%s\" (index %s vs %d) for type %s ", new Object[] { name, old, 
/*     */                       
/* 193 */                       Integer.valueOf(i), ClassUtil.nameOf(this._beanDesc.getBeanClass()) })); 
/*     */           } 
/*     */         } 
/*     */       } 
/* 197 */       this._propertyBasedArgs = properties;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDefaultCreator() {
/* 211 */     return (this._creators[0] != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDelegatingCreator() {
/* 218 */     return (this._creators[8] != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasPropertyBasedCreator() {
/* 225 */     return (this._creators[9] != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JavaType _computeDelegateType(DeserializationContext ctxt, AnnotatedWithParams creator, SettableBeanProperty[] delegateArgs) throws JsonMappingException {
/* 238 */     if (!this._hasNonDefaultCreator || creator == null) {
/* 239 */       return null;
/*     */     }
/*     */     
/* 242 */     int ix = 0;
/* 243 */     if (delegateArgs != null) {
/* 244 */       for (int i = 0, len = delegateArgs.length; i < len; i++) {
/* 245 */         if (delegateArgs[i] == null) {
/* 246 */           ix = i;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/* 251 */     DeserializationConfig config = ctxt.getConfig();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 256 */     JavaType baseType = creator.getParameterType(ix);
/* 257 */     AnnotationIntrospector intr = config.getAnnotationIntrospector();
/* 258 */     if (intr != null) {
/* 259 */       AnnotatedParameter delegate = creator.getParameter(ix);
/*     */ 
/*     */       
/* 262 */       Object deserDef = intr.findDeserializer((Annotated)delegate);
/* 263 */       if (deserDef != null) {
/* 264 */         JsonDeserializer<Object> deser = ctxt.deserializerInstance((Annotated)delegate, deserDef);
/* 265 */         baseType = baseType.withValueHandler(deser);
/*     */       } else {
/*     */         
/* 268 */         baseType = intr.refineDeserializationType((MapperConfig)config, (Annotated)delegate, baseType);
/*     */       } 
/*     */     } 
/*     */     
/* 272 */     return baseType;
/*     */   }
/*     */   
/*     */   private <T extends com.fasterxml.jackson.databind.introspect.AnnotatedMember> T _fixAccess(T member) {
/* 276 */     if (member != null && this._canFixAccess) {
/* 277 */       ClassUtil.checkAndFixAccess((Member)member.getAnnotated(), this._forceAccess);
/*     */     }
/*     */     
/* 280 */     return member;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean verifyNonDup(AnnotatedWithParams newOne, int typeIndex, boolean explicit) {
/* 288 */     int mask = 1 << typeIndex;
/* 289 */     this._hasNonDefaultCreator = true;
/* 290 */     AnnotatedWithParams oldOne = this._creators[typeIndex];
/*     */     
/* 292 */     if (oldOne != null) {
/*     */       boolean verify;
/* 294 */       if ((this._explicitCreators & mask) != 0) {
/*     */         
/* 296 */         if (!explicit) {
/* 297 */           return false;
/*     */         }
/*     */         
/* 300 */         verify = true;
/*     */       } else {
/*     */         
/* 303 */         verify = !explicit;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 310 */       if (verify && oldOne.getClass() == newOne.getClass()) {
/*     */         
/* 312 */         Class<?> oldType = oldOne.getRawParameterType(0);
/* 313 */         Class<?> newType = newOne.getRawParameterType(0);
/*     */         
/* 315 */         if (oldType == newType) {
/*     */ 
/*     */ 
/*     */           
/* 319 */           if (_isEnumValueOf(newOne)) {
/* 320 */             return false;
/*     */           }
/* 322 */           if (!_isEnumValueOf(oldOne)) {
/* 323 */             _reportDuplicateCreator(typeIndex, explicit, oldOne, newOne);
/*     */           }
/*     */         } else {
/*     */           
/* 327 */           if (newType.isAssignableFrom(oldType))
/*     */           {
/* 329 */             return false; } 
/* 330 */           if (!oldType.isAssignableFrom(newType))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 337 */             if (oldType.isPrimitive() != newType.isPrimitive()) {
/*     */               
/* 339 */               if (oldType.isPrimitive()) {
/* 340 */                 return false;
/*     */               
/*     */               }
/*     */             }
/*     */             else {
/*     */               
/* 346 */               _reportDuplicateCreator(typeIndex, explicit, oldOne, newOne);
/*     */             }  } 
/*     */         } 
/*     */       } 
/* 350 */     }  if (explicit) {
/* 351 */       this._explicitCreators |= mask;
/*     */     }
/* 353 */     this._creators[typeIndex] = _fixAccess(newOne);
/* 354 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _reportDuplicateCreator(int typeIndex, boolean explicit, AnnotatedWithParams oldOne, AnnotatedWithParams newOne) {
/* 360 */     throw new IllegalArgumentException(String.format("Conflicting %s creators: already had %s creator %s, encountered another: %s", new Object[] { TYPE_DESCS[typeIndex], explicit ? "explicitly marked" : "implicitly discovered", oldOne, newOne }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _isEnumValueOf(AnnotatedWithParams creator) {
/* 374 */     return (ClassUtil.isEnumType(creator.getDeclaringClass()) && "valueOf"
/* 375 */       .equals(creator.getName()));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\impl\CreatorCollector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */