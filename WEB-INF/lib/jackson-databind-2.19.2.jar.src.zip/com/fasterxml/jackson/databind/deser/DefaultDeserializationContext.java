/*     */ package com.fasterxml.jackson.databind.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdResolver;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.InjectableValues;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.cfg.CacheProvider;
/*     */ import com.fasterxml.jackson.databind.cfg.HandlerInstantiator;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DefaultDeserializationContext
/*     */   extends DeserializationContext
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected transient LinkedHashMap<ObjectIdGenerator.IdKey, ReadableObjectId> _objectIds;
/*     */   private List<ObjectIdResolver> _objectIdResolvers;
/*     */   
/*     */   protected DefaultDeserializationContext(DeserializerFactory df, DeserializerCache cache) {
/*  46 */     super(df, cache);
/*     */   }
/*     */ 
/*     */   
/*     */   protected DefaultDeserializationContext(DefaultDeserializationContext src, DeserializationConfig config, JsonParser p, InjectableValues values) {
/*  51 */     super(src, config, p, values);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected DefaultDeserializationContext(DefaultDeserializationContext src, DeserializationConfig config) {
/*  57 */     super(src, config);
/*     */   }
/*     */ 
/*     */   
/*     */   protected DefaultDeserializationContext(DefaultDeserializationContext src, DeserializerFactory factory) {
/*  62 */     super(src, factory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DefaultDeserializationContext(DefaultDeserializationContext src) {
/*  71 */     super(src);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DefaultDeserializationContext(DefaultDeserializationContext src, CacheProvider cp) {
/*  79 */     super(src, new DeserializerCache(cp
/*  80 */           .forDeserializerCache(src._config)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultDeserializationContext copy() {
/*  92 */     throw new IllegalStateException("DefaultDeserializationContext sub-class not overriding copy()");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadableObjectId findObjectId(Object id, ObjectIdGenerator<?> gen, ObjectIdResolver resolverType) {
/* 106 */     if (id == null) {
/* 107 */       return null;
/*     */     }
/*     */     
/* 110 */     ObjectIdGenerator.IdKey key = gen.key(id);
/*     */     
/* 112 */     if (this._objectIds == null) {
/* 113 */       this._objectIds = new LinkedHashMap<>();
/*     */     } else {
/* 115 */       ReadableObjectId readableObjectId = this._objectIds.get(key);
/* 116 */       if (readableObjectId != null) {
/* 117 */         return readableObjectId;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 122 */     ObjectIdResolver resolver = null;
/*     */     
/* 124 */     if (this._objectIdResolvers == null) {
/* 125 */       this._objectIdResolvers = new ArrayList<>(8);
/*     */     } else {
/* 127 */       for (ObjectIdResolver res : this._objectIdResolvers) {
/* 128 */         if (res.canUseFor(resolverType)) {
/* 129 */           resolver = res;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 135 */     if (resolver == null) {
/* 136 */       resolver = resolverType.newForDeserialization(this);
/* 137 */       this._objectIdResolvers.add(resolver);
/*     */     } 
/*     */     
/* 140 */     ReadableObjectId entry = createReadableObjectId(key);
/* 141 */     entry.setResolver(resolver);
/* 142 */     this._objectIds.put(key, entry);
/* 143 */     return entry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ReadableObjectId createReadableObjectId(ObjectIdGenerator.IdKey key) {
/* 159 */     return new ReadableObjectId(key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkUnresolvedObjectId() throws UnresolvedForwardReference {
/* 165 */     if (this._objectIds == null) {
/*     */       return;
/*     */     }
/*     */     
/* 169 */     if (!isEnabled(DeserializationFeature.FAIL_ON_UNRESOLVED_OBJECT_IDS)) {
/*     */       return;
/*     */     }
/* 172 */     UnresolvedForwardReference exception = null;
/* 173 */     for (Map.Entry<ObjectIdGenerator.IdKey, ReadableObjectId> entry : this._objectIds.entrySet()) {
/* 174 */       ReadableObjectId roid = entry.getValue();
/* 175 */       if (!roid.hasReferringProperties()) {
/*     */         continue;
/*     */       }
/*     */       
/* 179 */       if (tryToResolveUnresolvedObjectId(roid)) {
/*     */         continue;
/*     */       }
/* 182 */       if (exception == null)
/*     */       {
/* 184 */         exception = (new UnresolvedForwardReference(getParser(), "Unresolved forward references for: ")).withStackTrace();
/*     */       }
/* 186 */       Object key = (roid.getKey()).key;
/* 187 */       for (Iterator<ReadableObjectId.Referring> iterator = roid.referringProperties(); iterator.hasNext(); ) {
/* 188 */         ReadableObjectId.Referring referring = iterator.next();
/* 189 */         exception.addUnresolvedId(key, referring.getBeanType(), referring.getLocation());
/*     */       } 
/*     */     } 
/* 192 */     if (exception != null) {
/* 193 */       throw exception;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean tryToResolveUnresolvedObjectId(ReadableObjectId roid) {
/* 209 */     return roid.tryToResolveUnresolved(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<Object> deserializerInstance(Annotated ann, Object deserDef) throws JsonMappingException {
/*     */     JsonDeserializer<?> deser;
/* 223 */     if (deserDef == null) {
/* 224 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 228 */     if (deserDef instanceof JsonDeserializer) {
/* 229 */       deser = (JsonDeserializer)deserDef;
/*     */     }
/*     */     else {
/*     */       
/* 233 */       if (!(deserDef instanceof Class)) {
/* 234 */         throw new IllegalStateException("AnnotationIntrospector returned deserializer definition of type " + deserDef.getClass().getName() + "; expected type JsonDeserializer or Class<JsonDeserializer> instead");
/*     */       }
/* 236 */       Class<?> deserClass = (Class)deserDef;
/*     */       
/* 238 */       if (deserClass == JsonDeserializer.None.class || ClassUtil.isBogusClass(deserClass)) {
/* 239 */         return null;
/*     */       }
/* 241 */       if (!JsonDeserializer.class.isAssignableFrom(deserClass)) {
/* 242 */         throw new IllegalStateException("AnnotationIntrospector returned Class " + deserClass.getName() + "; expected Class<JsonDeserializer>");
/*     */       }
/* 244 */       HandlerInstantiator hi = this._config.getHandlerInstantiator();
/* 245 */       deser = (hi == null) ? null : hi.deserializerInstance(this._config, ann, deserClass);
/* 246 */       if (deser == null) {
/* 247 */         deser = (JsonDeserializer)ClassUtil.createInstance(deserClass, this._config
/* 248 */             .canOverrideAccessModifiers());
/*     */       }
/*     */     } 
/*     */     
/* 252 */     if (deser instanceof ResolvableDeserializer) {
/* 253 */       ((ResolvableDeserializer)deser).resolve(this);
/*     */     }
/* 255 */     return (JsonDeserializer)deser;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final KeyDeserializer keyDeserializerInstance(Annotated ann, Object deserDef) throws JsonMappingException {
/*     */     KeyDeserializer deser;
/* 262 */     if (deserDef == null) {
/* 263 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 268 */     if (deserDef instanceof KeyDeserializer) {
/* 269 */       deser = (KeyDeserializer)deserDef;
/*     */     } else {
/* 271 */       if (!(deserDef instanceof Class)) {
/* 272 */         throw new IllegalStateException("AnnotationIntrospector returned key deserializer definition of type " + deserDef
/* 273 */             .getClass().getName() + "; expected type KeyDeserializer or Class<KeyDeserializer> instead");
/*     */       }
/*     */       
/* 276 */       Class<?> deserClass = (Class)deserDef;
/*     */       
/* 278 */       if (deserClass == KeyDeserializer.None.class || ClassUtil.isBogusClass(deserClass)) {
/* 279 */         return null;
/*     */       }
/* 281 */       if (!KeyDeserializer.class.isAssignableFrom(deserClass)) {
/* 282 */         throw new IllegalStateException("AnnotationIntrospector returned Class " + deserClass.getName() + "; expected Class<KeyDeserializer>");
/*     */       }
/*     */       
/* 285 */       HandlerInstantiator hi = this._config.getHandlerInstantiator();
/* 286 */       deser = (hi == null) ? null : hi.keyDeserializerInstance(this._config, ann, deserClass);
/* 287 */       if (deser == null) {
/* 288 */         deser = (KeyDeserializer)ClassUtil.createInstance(deserClass, this._config
/* 289 */             .canOverrideAccessModifiers());
/*     */       }
/*     */     } 
/*     */     
/* 293 */     if (deser instanceof ResolvableDeserializer) {
/* 294 */       ((ResolvableDeserializer)deser).resolve(this);
/*     */     }
/* 296 */     return deser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract DefaultDeserializationContext with(DeserializerFactory paramDeserializerFactory);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract DefaultDeserializationContext withCaches(CacheProvider paramCacheProvider);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract DefaultDeserializationContext createInstance(DeserializationConfig paramDeserializationConfig, JsonParser paramJsonParser, InjectableValues paramInjectableValues);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract DefaultDeserializationContext createDummyInstance(DeserializationConfig paramDeserializationConfig);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object readRootValue(JsonParser p, JavaType valueType, JsonDeserializer<Object> deser, Object valueToUpdate) throws IOException {
/* 338 */     if (this._config.useRootWrapping()) {
/* 339 */       return _unwrapAndDeserialize(p, valueType, deser, valueToUpdate);
/*     */     }
/* 341 */     if (valueToUpdate == null) {
/* 342 */       return deser.deserialize(p, this);
/*     */     }
/* 344 */     return deser.deserialize(p, this, valueToUpdate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _unwrapAndDeserialize(JsonParser p, JavaType rootType, JsonDeserializer<Object> deser, Object valueToUpdate) throws IOException {
/*     */     Object result;
/* 352 */     PropertyName expRootName = this._config.findRootName(rootType);
/*     */     
/* 354 */     String expSimpleName = expRootName.getSimpleName();
/* 355 */     if (p.currentToken() != JsonToken.START_OBJECT)
/* 356 */       reportWrongTokenException(rootType, JsonToken.START_OBJECT, "Current token not START_OBJECT (needed to unwrap root name %s), but %s", new Object[] {
/*     */             
/* 358 */             ClassUtil.name(expSimpleName), p.currentToken()
/*     */           }); 
/* 360 */     if (p.nextToken() != JsonToken.FIELD_NAME)
/* 361 */       reportWrongTokenException(rootType, JsonToken.FIELD_NAME, "Current token not FIELD_NAME (to contain expected root name %s), but %s", new Object[] {
/*     */             
/* 363 */             ClassUtil.name(expSimpleName), p.currentToken()
/*     */           }); 
/* 365 */     String actualName = p.currentName();
/* 366 */     if (!expSimpleName.equals(actualName)) {
/* 367 */       reportPropertyInputMismatch(rootType, actualName, "Root name (%s) does not match expected (%s) for type %s", new Object[] {
/*     */             
/* 369 */             ClassUtil.name(actualName), ClassUtil.name(expSimpleName), ClassUtil.getTypeDescription(rootType)
/*     */           });
/*     */     }
/* 372 */     p.nextToken();
/*     */     
/* 374 */     if (valueToUpdate == null) {
/* 375 */       result = deser.deserialize(p, this);
/*     */     } else {
/* 377 */       result = deser.deserialize(p, this, valueToUpdate);
/*     */     } 
/*     */     
/* 380 */     if (p.nextToken() != JsonToken.END_OBJECT)
/* 381 */       reportWrongTokenException(rootType, JsonToken.END_OBJECT, "Current token not END_OBJECT (to match wrapper object with root name %s), but %s", new Object[] {
/*     */             
/* 383 */             ClassUtil.name(expSimpleName), p.currentToken()
/*     */           }); 
/* 385 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Impl
/*     */     extends DefaultDeserializationContext
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Impl(DeserializerFactory df) {
/* 408 */       super(df, new DeserializerCache());
/*     */     }
/*     */ 
/*     */     
/*     */     private Impl(Impl src, DeserializationConfig config, JsonParser p, InjectableValues values) {
/* 413 */       super(src, config, p, values);
/*     */     }
/*     */     private Impl(Impl src) {
/* 416 */       super(src);
/*     */     }
/*     */     private Impl(Impl src, DeserializerFactory factory) {
/* 419 */       super(src, factory);
/*     */     }
/*     */     
/*     */     private Impl(Impl src, DeserializationConfig config) {
/* 423 */       super(src, config);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Impl(Impl src, CacheProvider cp) {
/* 430 */       super(src, cp);
/*     */     }
/*     */ 
/*     */     
/*     */     public DefaultDeserializationContext copy() {
/* 435 */       ClassUtil.verifyMustOverride(Impl.class, this, "copy");
/* 436 */       return new Impl(this);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public DefaultDeserializationContext createInstance(DeserializationConfig config, JsonParser p, InjectableValues values) {
/* 442 */       return new Impl(this, config, p, values);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public DefaultDeserializationContext createDummyInstance(DeserializationConfig config) {
/* 448 */       return new Impl(this, config);
/*     */     }
/*     */ 
/*     */     
/*     */     public DefaultDeserializationContext with(DeserializerFactory factory) {
/* 453 */       return new Impl(this, factory);
/*     */     }
/*     */ 
/*     */     
/*     */     public DefaultDeserializationContext withCaches(CacheProvider cp) {
/* 458 */       return new Impl(this, cp);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\DefaultDeserializationContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */