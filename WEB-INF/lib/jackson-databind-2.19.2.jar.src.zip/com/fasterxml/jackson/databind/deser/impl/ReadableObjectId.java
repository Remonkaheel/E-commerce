/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.ObjectIdGenerator;
/*     */ import com.fasterxml.jackson.annotation.ObjectIdResolver;
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.deser.UnresolvedForwardReference;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadableObjectId
/*     */ {
/*     */   protected Object _item;
/*     */   protected final ObjectIdGenerator.IdKey _key;
/*     */   protected LinkedList<Referring> _referringProperties;
/*     */   protected ObjectIdResolver _resolver;
/*     */   
/*     */   public ReadableObjectId(ObjectIdGenerator.IdKey key) {
/*  34 */     this._key = key;
/*     */   }
/*     */   
/*     */   public void setResolver(ObjectIdResolver resolver) {
/*  38 */     this._resolver = resolver;
/*     */   }
/*     */   
/*     */   public ObjectIdGenerator.IdKey getKey() {
/*  42 */     return this._key;
/*     */   }
/*     */   
/*     */   public void appendReferring(Referring currentReferring) {
/*  46 */     if (this._referringProperties == null) {
/*  47 */       this._referringProperties = new LinkedList<>();
/*     */     }
/*  49 */     this._referringProperties.add(currentReferring);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bindItem(Object ob) throws IOException {
/*  58 */     this._resolver.bindItem(this._key, ob);
/*  59 */     this._item = ob;
/*  60 */     Object id = this._key.key;
/*  61 */     if (this._referringProperties != null) {
/*  62 */       Iterator<Referring> it = this._referringProperties.iterator();
/*  63 */       this._referringProperties = null;
/*  64 */       while (it.hasNext()) {
/*  65 */         ((Referring)it.next()).handleResolvedForwardReference(id, ob);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public Object resolve() {
/*  71 */     return this._item = this._resolver.resolveId(this._key);
/*     */   }
/*     */   
/*     */   public boolean hasReferringProperties() {
/*  75 */     return (this._referringProperties != null && !this._referringProperties.isEmpty());
/*     */   }
/*     */   
/*     */   public Iterator<Referring> referringProperties() {
/*  79 */     if (this._referringProperties == null) {
/*  80 */       return Collections.<Referring>emptyList().iterator();
/*     */     }
/*  82 */     return this._referringProperties.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean tryToResolveUnresolved(DeserializationContext ctxt) {
/* 102 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectIdResolver getResolver() {
/* 115 */     return this._resolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 120 */     return String.valueOf(this._key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class Referring
/*     */   {
/*     */     private final UnresolvedForwardReference _reference;
/*     */ 
/*     */     
/*     */     private final Class<?> _beanType;
/*     */ 
/*     */     
/*     */     public Referring(UnresolvedForwardReference ref, Class<?> beanType) {
/* 134 */       this._reference = ref;
/* 135 */       this._beanType = beanType;
/*     */     }
/*     */     
/*     */     public Referring(UnresolvedForwardReference ref, JavaType beanType) {
/* 139 */       this._reference = ref;
/* 140 */       this._beanType = beanType.getRawClass();
/*     */     }
/*     */     
/* 143 */     public JsonLocation getLocation() { return this._reference.getLocation(); } public Class<?> getBeanType() {
/* 144 */       return this._beanType;
/*     */     }
/*     */     public abstract void handleResolvedForwardReference(Object param1Object1, Object param1Object2) throws IOException;
/*     */     public boolean hasId(Object id) {
/* 148 */       return id.equals(this._reference.getUnresolvedId());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\impl\ReadableObjectId.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */