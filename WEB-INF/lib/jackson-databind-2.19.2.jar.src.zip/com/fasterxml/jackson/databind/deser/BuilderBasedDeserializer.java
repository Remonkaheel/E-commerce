/*     */ package com.fasterxml.jackson.databind.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.deser.impl.BeanAsArrayBuilderDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ExternalTypeHandler;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ObjectIdReader;
/*     */ import com.fasterxml.jackson.databind.deser.impl.PropertyBasedCreator;
/*     */ import com.fasterxml.jackson.databind.deser.impl.PropertyValueBuffer;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BuilderBasedDeserializer
/*     */   extends BeanDeserializerBase
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final AnnotatedMethod _buildMethod;
/*     */   protected final JavaType _targetType;
/*     */   
/*     */   public BuilderBasedDeserializer(BeanDeserializerBuilder builder, BeanDescription beanDesc, JavaType targetType, BeanPropertyMap properties, Map<String, SettableBeanProperty> backRefs, Set<String> ignorableProps, boolean ignoreAllUnknown, boolean hasViews) {
/*  56 */     this(builder, beanDesc, targetType, properties, backRefs, ignorableProps, ignoreAllUnknown, (Set<String>)null, hasViews);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BuilderBasedDeserializer(BeanDeserializerBuilder builder, BeanDescription beanDesc, JavaType targetType, BeanPropertyMap properties, Map<String, SettableBeanProperty> backRefs, Set<String> ignorableProps, boolean ignoreAllUnknown, Set<String> includableProps, boolean hasViews) {
/*  68 */     super(builder, beanDesc, properties, backRefs, ignorableProps, ignoreAllUnknown, includableProps, hasViews);
/*     */     
/*  70 */     this._targetType = targetType;
/*  71 */     this._buildMethod = builder.getBuildMethod();
/*     */     
/*  73 */     if (this._objectIdReader != null) {
/*  74 */       throw new IllegalArgumentException("Cannot use Object Id with Builder-based deserialization (type " + beanDesc
/*  75 */           .getType() + ")");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public BuilderBasedDeserializer(BeanDeserializerBuilder builder, BeanDescription beanDesc, BeanPropertyMap properties, Map<String, SettableBeanProperty> backRefs, Set<String> ignorableProps, boolean ignoreAllUnknown, boolean hasViews) {
/*  89 */     this(builder, beanDesc, beanDesc
/*  90 */         .getType(), properties, backRefs, ignorableProps, ignoreAllUnknown, hasViews);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BuilderBasedDeserializer(BuilderBasedDeserializer src) {
/* 100 */     this(src, src._ignoreAllUnknown);
/*     */   }
/*     */ 
/*     */   
/*     */   protected BuilderBasedDeserializer(BuilderBasedDeserializer src, boolean ignoreAllUnknown) {
/* 105 */     super(src, ignoreAllUnknown);
/* 106 */     this._buildMethod = src._buildMethod;
/* 107 */     this._targetType = src._targetType;
/*     */   }
/*     */   
/*     */   protected BuilderBasedDeserializer(BuilderBasedDeserializer src, NameTransformer unwrapper) {
/* 111 */     super(src, unwrapper);
/* 112 */     this._buildMethod = src._buildMethod;
/* 113 */     this._targetType = src._targetType;
/*     */   }
/*     */   
/*     */   public BuilderBasedDeserializer(BuilderBasedDeserializer src, ObjectIdReader oir) {
/* 117 */     super(src, oir);
/* 118 */     this._buildMethod = src._buildMethod;
/* 119 */     this._targetType = src._targetType;
/*     */   }
/*     */   
/*     */   public BuilderBasedDeserializer(BuilderBasedDeserializer src, Set<String> ignorableProps) {
/* 123 */     this(src, ignorableProps, src._includableProps);
/*     */   }
/*     */   
/*     */   public BuilderBasedDeserializer(BuilderBasedDeserializer src, Set<String> ignorableProps, Set<String> includableProps) {
/* 127 */     super(src, ignorableProps, includableProps);
/* 128 */     this._buildMethod = src._buildMethod;
/* 129 */     this._targetType = src._targetType;
/*     */   }
/*     */   
/*     */   public BuilderBasedDeserializer(BuilderBasedDeserializer src, BeanPropertyMap props) {
/* 133 */     super(src, props);
/* 134 */     this._buildMethod = src._buildMethod;
/* 135 */     this._targetType = src._targetType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<Object> unwrappingDeserializer(NameTransformer unwrapper) {
/* 145 */     return (JsonDeserializer<Object>)new BuilderBasedDeserializer(this, unwrapper);
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanDeserializerBase withObjectIdReader(ObjectIdReader oir) {
/* 150 */     return new BuilderBasedDeserializer(this, oir);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDeserializerBase withByNameInclusion(Set<String> ignorableProps, Set<String> includableProps) {
/* 156 */     return new BuilderBasedDeserializer(this, ignorableProps, includableProps);
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanDeserializerBase withIgnoreAllUnknown(boolean ignoreUnknown) {
/* 161 */     return new BuilderBasedDeserializer(this, ignoreUnknown);
/*     */   }
/*     */ 
/*     */   
/*     */   public BeanDeserializerBase withBeanProperties(BeanPropertyMap props) {
/* 166 */     return new BuilderBasedDeserializer(this, props);
/*     */   }
/*     */ 
/*     */   
/*     */   protected BeanDeserializerBase asArrayDeserializer() {
/* 171 */     SettableBeanProperty[] props = this._beanProperties.getPropertiesInInsertionOrder();
/* 172 */     return (BeanDeserializerBase)new BeanAsArrayBuilderDeserializer(this, this._targetType, props, this._buildMethod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 184 */     return Boolean.FALSE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object finishBuild(DeserializationContext ctxt, Object builder) throws IOException {
/* 197 */     if (null == this._buildMethod) {
/* 198 */       return builder;
/*     */     }
/*     */     try {
/* 201 */       return this._buildMethod.getMember().invoke(builder, (Object[])null);
/* 202 */     } catch (Exception e) {
/* 203 */       return wrapInstantiationProblem(e, ctxt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 215 */     if (p.isExpectedStartObjectToken()) {
/* 216 */       JsonToken t = p.nextToken();
/* 217 */       if (this._vanillaProcessing) {
/* 218 */         return finishBuild(ctxt, vanillaDeserialize(p, ctxt, t));
/*     */       }
/* 220 */       return finishBuild(ctxt, deserializeFromObject(p, ctxt));
/*     */     } 
/*     */     
/* 223 */     switch (p.currentTokenId()) {
/*     */       case 6:
/* 225 */         return finishBuild(ctxt, deserializeFromString(p, ctxt));
/*     */       case 7:
/* 227 */         return finishBuild(ctxt, deserializeFromNumber(p, ctxt));
/*     */       case 8:
/* 229 */         return finishBuild(ctxt, deserializeFromDouble(p, ctxt));
/*     */       case 12:
/* 231 */         return p.getEmbeddedObject();
/*     */       case 9:
/*     */       case 10:
/* 234 */         return finishBuild(ctxt, deserializeFromBoolean(p, ctxt));
/*     */ 
/*     */       
/*     */       case 3:
/* 238 */         return _deserializeFromArray(p, ctxt);
/*     */       case 2:
/*     */       case 5:
/* 241 */         return finishBuild(ctxt, deserializeFromObject(p, ctxt));
/*     */     } 
/*     */     
/* 244 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt, Object value) throws IOException {
/* 258 */     JavaType valueType = this._targetType;
/*     */     
/* 260 */     Class<?> builderRawType = handledType();
/* 261 */     Class<?> instRawType = value.getClass();
/* 262 */     if (builderRawType.isAssignableFrom(instRawType)) {
/* 263 */       return ctxt.reportBadDefinition(valueType, String.format("Deserialization of %s by passing existing Builder (%s) instance not supported", new Object[] { valueType, builderRawType
/*     */               
/* 265 */               .getName() }));
/*     */     }
/* 267 */     return ctxt.reportBadDefinition(valueType, String.format("Deserialization of %s by passing existing instance (of %s) not supported", new Object[] { valueType, instRawType
/*     */             
/* 269 */             .getName() }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Object vanillaDeserialize(JsonParser p, DeserializationContext ctxt, JsonToken t) throws IOException {
/* 286 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/* 287 */     for (; p.currentToken() == JsonToken.FIELD_NAME; p.nextToken()) {
/* 288 */       String propName = p.currentName();
/*     */       
/* 290 */       p.nextToken();
/* 291 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/* 292 */       if (prop != null) {
/*     */         try {
/* 294 */           bean = prop.deserializeSetAndReturn(p, ctxt, bean);
/* 295 */         } catch (Exception e) {
/* 296 */           wrapAndThrow(e, bean, propName, ctxt);
/*     */         } 
/*     */       } else {
/* 299 */         handleUnknownVanilla(p, ctxt, bean, propName);
/*     */       } 
/*     */     } 
/* 302 */     return bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeFromObject(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 313 */     if (this._nonStandardCreation) {
/* 314 */       if (this._unwrappedPropertyHandler != null) {
/* 315 */         return deserializeWithUnwrapped(p, ctxt);
/*     */       }
/* 317 */       if (this._externalTypeIdHandler != null) {
/* 318 */         return deserializeWithExternalTypeId(p, ctxt);
/*     */       }
/* 320 */       return deserializeFromObjectUsingNonDefault(p, ctxt);
/*     */     } 
/* 322 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/* 323 */     if (this._injectables != null) {
/* 324 */       injectValues(ctxt, bean);
/*     */     }
/* 326 */     if (this._needViewProcesing) {
/* 327 */       Class<?> view = ctxt.getActiveView();
/* 328 */       if (view != null) {
/* 329 */         return deserializeWithView(p, ctxt, bean, view);
/*     */       }
/*     */     } 
/* 332 */     for (; p.currentToken() == JsonToken.FIELD_NAME; p.nextToken()) {
/* 333 */       String propName = p.currentName();
/*     */       
/* 335 */       p.nextToken();
/* 336 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/* 337 */       if (prop != null) {
/*     */         try {
/* 339 */           bean = prop.deserializeSetAndReturn(p, ctxt, bean);
/* 340 */         } catch (Exception e) {
/* 341 */           wrapAndThrow(e, bean, propName, ctxt);
/*     */         } 
/*     */       } else {
/*     */         
/* 345 */         handleUnknownVanilla(p, ctxt, bean, propName);
/*     */       } 
/* 347 */     }  return bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserializeUsingPropertyBased(JsonParser p, DeserializationContext ctxt) throws IOException {
/*     */     Object builder;
/* 365 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/* 366 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, this._objectIdReader);
/* 367 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/*     */ 
/*     */     
/* 370 */     TokenBuffer unknown = null;
/*     */     
/* 372 */     JsonToken t = p.currentToken();
/* 373 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/* 374 */       String propName = p.currentName();
/* 375 */       p.nextToken();
/*     */       
/* 377 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/*     */       
/* 379 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*     */       {
/*     */         
/* 382 */         if (creatorProp != null) {
/* 383 */           if (activeView != null && !creatorProp.visibleInView(activeView)) {
/* 384 */             p.skipChildren();
/*     */ 
/*     */           
/*     */           }
/* 388 */           else if (buffer.assignParameter(creatorProp, creatorProp.deserialize(p, ctxt))) {
/* 389 */             Object object; p.nextToken();
/*     */             
/*     */             try {
/* 392 */               object = creator.build(ctxt, buffer);
/* 393 */             } catch (Exception e) {
/* 394 */               wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/*     */             } 
/*     */ 
/*     */             
/* 398 */             if (object.getClass() != this._beanType.getRawClass()) {
/* 399 */               return handlePolymorphic(p, ctxt, p.streamReadConstraints(), object, unknown);
/*     */             }
/* 401 */             if (unknown != null) {
/* 402 */               object = handleUnknownProperties(ctxt, object, unknown);
/*     */             }
/*     */             
/* 405 */             return _deserialize(p, ctxt, object);
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 410 */           SettableBeanProperty prop = this._beanProperties.find(propName);
/* 411 */           if (prop != null) {
/* 412 */             buffer.bufferProperty(prop, prop.deserialize(p, ctxt));
/*     */ 
/*     */ 
/*     */           
/*     */           }
/* 417 */           else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/* 418 */             handleIgnoredProperty(p, ctxt, handledType(), propName);
/*     */ 
/*     */           
/*     */           }
/* 422 */           else if (this._anySetter != null) {
/* 423 */             buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter.deserialize(p, ctxt));
/*     */           }
/*     */           else {
/*     */             
/* 427 */             if (unknown == null) {
/* 428 */               unknown = ctxt.bufferForInputBuffering(p);
/*     */             }
/* 430 */             unknown.writeFieldName(propName);
/* 431 */             unknown.copyCurrentStructure(p);
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */     try {
/* 437 */       builder = creator.build(ctxt, buffer);
/* 438 */     } catch (Exception e) {
/* 439 */       builder = wrapInstantiationProblem(e, ctxt);
/*     */     } 
/* 441 */     if (unknown != null) {
/*     */       
/* 443 */       if (builder.getClass() != this._beanType.getRawClass()) {
/* 444 */         return handlePolymorphic((JsonParser)null, ctxt, p.streamReadConstraints(), builder, unknown);
/*     */       }
/*     */       
/* 447 */       return handleUnknownProperties(ctxt, builder, unknown);
/*     */     } 
/* 449 */     return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Object _deserialize(JsonParser p, DeserializationContext ctxt, Object builder) throws IOException {
/* 455 */     if (this._injectables != null) {
/* 456 */       injectValues(ctxt, builder);
/*     */     }
/* 458 */     if (this._unwrappedPropertyHandler != null) {
/* 459 */       if (p.hasToken(JsonToken.START_OBJECT)) {
/* 460 */         p.nextToken();
/*     */       }
/* 462 */       TokenBuffer tokens = ctxt.bufferForInputBuffering(p);
/* 463 */       tokens.writeStartObject();
/* 464 */       return deserializeWithUnwrapped(p, ctxt, builder, tokens);
/*     */     } 
/* 466 */     if (this._externalTypeIdHandler != null) {
/* 467 */       return deserializeWithExternalTypeId(p, ctxt, builder);
/*     */     }
/* 469 */     if (this._needViewProcesing) {
/* 470 */       Class<?> view = ctxt.getActiveView();
/* 471 */       if (view != null) {
/* 472 */         return deserializeWithView(p, ctxt, builder, view);
/*     */       }
/*     */     } 
/* 475 */     JsonToken t = p.currentToken();
/*     */     
/* 477 */     if (t == JsonToken.START_OBJECT) {
/* 478 */       t = p.nextToken();
/*     */     }
/* 480 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/* 481 */       String propName = p.currentName();
/*     */       
/* 483 */       p.nextToken();
/* 484 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/*     */       
/* 486 */       if (prop != null) {
/*     */         try {
/* 488 */           builder = prop.deserializeSetAndReturn(p, ctxt, builder);
/* 489 */         } catch (Exception e) {
/* 490 */           wrapAndThrow(e, builder, propName, ctxt);
/*     */         } 
/*     */       } else {
/*     */         
/* 494 */         handleUnknownVanilla(p, ctxt, builder, propName);
/*     */       } 
/* 496 */     }  return builder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserializeFromArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 503 */     JsonDeserializer<Object> delegateDeser = this._arrayDelegateDeserializer;
/*     */     
/* 505 */     if (delegateDeser != null || (delegateDeser = this._delegateDeserializer) != null) {
/* 506 */       Object builder = this._valueInstantiator.createUsingArrayDelegate(ctxt, delegateDeser
/* 507 */           .deserialize(p, ctxt));
/* 508 */       if (this._injectables != null) {
/* 509 */         injectValues(ctxt, builder);
/*     */       }
/* 511 */       return finishBuild(ctxt, builder);
/*     */     } 
/* 513 */     CoercionAction act = _findCoercionFromEmptyArray(ctxt);
/* 514 */     boolean unwrap = ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS);
/*     */     
/* 516 */     if (unwrap || act != CoercionAction.Fail) {
/* 517 */       JsonToken t = p.nextToken();
/* 518 */       if (t == JsonToken.END_ARRAY) {
/* 519 */         switch (act) {
/*     */           case AsEmpty:
/* 521 */             return getEmptyValue(ctxt);
/*     */           case AsNull:
/*     */           case TryConvert:
/* 524 */             return getNullValue(ctxt);
/*     */         } 
/*     */         
/* 527 */         return ctxt.handleUnexpectedToken(getValueType(ctxt), JsonToken.START_ARRAY, p, null, new Object[0]);
/*     */       } 
/* 529 */       if (unwrap) {
/* 530 */         Object value = deserialize(p, ctxt);
/* 531 */         if (p.nextToken() != JsonToken.END_ARRAY) {
/* 532 */           handleMissingEndArrayForSingle(p, ctxt);
/*     */         }
/* 534 */         return value;
/*     */       } 
/*     */     } 
/* 537 */     return ctxt.handleUnexpectedToken(getValueType(ctxt), p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Object deserializeWithView(JsonParser p, DeserializationContext ctxt, Object bean, Class<?> activeView) throws IOException {
/* 550 */     JsonToken t = p.currentToken();
/* 551 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/* 552 */       String propName = p.currentName();
/*     */       
/* 554 */       p.nextToken();
/* 555 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/* 556 */       if (prop != null) {
/* 557 */         if (!prop.visibleInView(activeView)) {
/*     */           
/* 559 */           if (ctxt.isEnabled(DeserializationFeature.FAIL_ON_UNEXPECTED_VIEW_PROPERTIES))
/* 560 */             ctxt.reportInputMismatch(handledType(), 
/* 561 */                 String.format("Input mismatch while deserializing %s. Property '%s' is not part of current active view '%s' (disable 'DeserializationFeature.FAIL_ON_UNEXPECTED_VIEW_PROPERTIES' to allow)", new Object[] {
/*     */                     
/* 563 */                     ClassUtil.nameOf(handledType()), prop.getName(), activeView.getName()
/*     */                   }), new Object[0]); 
/* 565 */           p.skipChildren();
/*     */         } else {
/*     */           
/*     */           try {
/* 569 */             bean = prop.deserializeSetAndReturn(p, ctxt, bean);
/* 570 */           } catch (Exception e) {
/* 571 */             wrapAndThrow(e, bean, propName, ctxt);
/*     */           } 
/*     */         } 
/*     */       } else {
/* 575 */         handleUnknownVanilla(p, ctxt, bean, propName);
/*     */       } 
/* 577 */     }  return bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object deserializeWithUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 594 */     if (this._delegateDeserializer != null) {
/* 595 */       return this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer.deserialize(p, ctxt));
/*     */     }
/* 597 */     if (this._propertyBasedCreator != null) {
/* 598 */       return deserializeUsingPropertyBasedWithUnwrapped(p, ctxt);
/*     */     }
/* 600 */     TokenBuffer tokens = ctxt.bufferForInputBuffering(p);
/* 601 */     tokens.writeStartObject();
/* 602 */     Object bean = this._valueInstantiator.createUsingDefault(ctxt);
/*     */     
/* 604 */     if (this._injectables != null) {
/* 605 */       injectValues(ctxt, bean);
/*     */     }
/*     */     
/* 608 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/* 609 */     for (; p.currentToken() == JsonToken.FIELD_NAME; p.nextToken()) {
/* 610 */       String propName = p.currentName();
/* 611 */       p.nextToken();
/* 612 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/* 613 */       if (prop != null) {
/* 614 */         if (activeView != null && !prop.visibleInView(activeView)) {
/* 615 */           p.skipChildren();
/*     */         } else {
/*     */           
/*     */           try {
/* 619 */             bean = prop.deserializeSetAndReturn(p, ctxt, bean);
/* 620 */           } catch (Exception e) {
/* 621 */             wrapAndThrow(e, bean, propName, ctxt);
/*     */           }
/*     */         
/*     */         }
/*     */       
/* 626 */       } else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/* 627 */         handleIgnoredProperty(p, ctxt, bean, propName);
/*     */       }
/*     */       else {
/*     */         
/* 631 */         tokens.writeFieldName(propName);
/* 632 */         tokens.copyCurrentStructure(p);
/*     */         
/* 634 */         if (this._anySetter != null) {
/*     */           try {
/* 636 */             this._anySetter.deserializeAndSet(p, ctxt, bean, propName);
/* 637 */           } catch (Exception e) {
/* 638 */             wrapAndThrow(e, bean, propName, ctxt);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 643 */     tokens.writeEndObject();
/* 644 */     return this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, bean, tokens);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object deserializeUsingPropertyBasedWithUnwrapped(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 652 */     PropertyBasedCreator creator = this._propertyBasedCreator;
/* 653 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, this._objectIdReader);
/*     */     
/* 655 */     TokenBuffer tokens = ctxt.bufferForInputBuffering(p);
/* 656 */     tokens.writeStartObject();
/* 657 */     Object builder = null;
/*     */     
/* 659 */     JsonToken t = p.currentToken();
/* 660 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/* 661 */       String propName = p.currentName();
/* 662 */       p.nextToken();
/*     */       
/* 664 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/*     */       
/* 666 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*     */       {
/*     */         
/* 669 */         if (creatorProp != null) {
/*     */           
/* 671 */           if (buffer.assignParameter(creatorProp, creatorProp.deserialize(p, ctxt))) {
/* 672 */             t = p.nextToken();
/*     */             try {
/* 674 */               builder = creator.build(ctxt, buffer);
/* 675 */             } catch (Exception e) {
/* 676 */               wrapAndThrow(e, this._beanType.getRawClass(), propName, ctxt);
/*     */             } 
/*     */             
/* 679 */             if (builder.getClass() != this._beanType.getRawClass()) {
/* 680 */               return handlePolymorphic(p, ctxt, p.streamReadConstraints(), builder, tokens);
/*     */             }
/* 682 */             return deserializeWithUnwrapped(p, ctxt, builder, tokens);
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 687 */           SettableBeanProperty prop = this._beanProperties.find(propName);
/* 688 */           if (prop != null) {
/* 689 */             buffer.bufferProperty(prop, prop.deserialize(p, ctxt));
/*     */           
/*     */           }
/* 692 */           else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/* 693 */             handleIgnoredProperty(p, ctxt, handledType(), propName);
/*     */           } else {
/*     */             
/* 696 */             tokens.writeFieldName(propName);
/* 697 */             tokens.copyCurrentStructure(p);
/*     */             
/* 699 */             if (this._anySetter != null)
/* 700 */               buffer.bufferAnyProperty(this._anySetter, propName, this._anySetter.deserialize(p, ctxt)); 
/*     */           } 
/*     */         }  } 
/* 703 */     }  tokens.writeEndObject();
/*     */ 
/*     */     
/* 706 */     if (builder == null) {
/*     */       try {
/* 708 */         builder = creator.build(ctxt, buffer);
/* 709 */       } catch (Exception e) {
/* 710 */         return wrapInstantiationProblem(e, ctxt);
/*     */       } 
/*     */     }
/* 713 */     return this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, builder, tokens);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object deserializeWithUnwrapped(JsonParser p, DeserializationContext ctxt, Object builder, TokenBuffer tokens) throws IOException {
/* 720 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/* 721 */     for (JsonToken t = p.currentToken(); t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/* 722 */       String propName = p.currentName();
/* 723 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/* 724 */       p.nextToken();
/* 725 */       if (prop != null) {
/* 726 */         if (activeView != null && !prop.visibleInView(activeView)) {
/* 727 */           p.skipChildren();
/*     */         } else {
/*     */           
/*     */           try {
/* 731 */             builder = prop.deserializeSetAndReturn(p, ctxt, builder);
/* 732 */           } catch (Exception e) {
/* 733 */             wrapAndThrow(e, builder, propName, ctxt);
/*     */           }
/*     */         
/*     */         } 
/* 737 */       } else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/* 738 */         handleIgnoredProperty(p, ctxt, builder, propName);
/*     */       }
/*     */       else {
/*     */         
/* 742 */         tokens.writeFieldName(propName);
/* 743 */         tokens.copyCurrentStructure(p);
/*     */         
/* 745 */         if (this._anySetter != null)
/* 746 */           this._anySetter.deserializeAndSet(p, ctxt, builder, propName); 
/*     */       } 
/*     */     } 
/* 749 */     tokens.writeEndObject();
/* 750 */     return this._unwrappedPropertyHandler.processUnwrapped(p, ctxt, builder, tokens);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object deserializeWithExternalTypeId(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 763 */     if (this._propertyBasedCreator != null) {
/* 764 */       return deserializeUsingPropertyBasedWithExternalTypeId(p, ctxt);
/*     */     }
/* 766 */     return deserializeWithExternalTypeId(p, ctxt, this._valueInstantiator.createUsingDefault(ctxt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object deserializeWithExternalTypeId(JsonParser p, DeserializationContext ctxt, Object bean) throws IOException {
/* 773 */     Class<?> activeView = this._needViewProcesing ? ctxt.getActiveView() : null;
/* 774 */     ExternalTypeHandler ext = this._externalTypeIdHandler.start();
/*     */     
/* 776 */     for (JsonToken t = p.currentToken(); t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/* 777 */       String propName = p.currentName();
/* 778 */       t = p.nextToken();
/* 779 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/* 780 */       if (prop != null) {
/*     */         
/* 782 */         if (t.isScalarValue()) {
/* 783 */           ext.handleTypePropertyValue(p, ctxt, propName, bean);
/*     */         }
/* 785 */         if (activeView != null && !prop.visibleInView(activeView)) {
/* 786 */           p.skipChildren();
/*     */         } else {
/*     */           
/*     */           try {
/* 790 */             bean = prop.deserializeSetAndReturn(p, ctxt, bean);
/* 791 */           } catch (Exception e) {
/* 792 */             wrapAndThrow(e, bean, propName, ctxt);
/*     */           }
/*     */         
/*     */         }
/*     */       
/* 797 */       } else if (IgnorePropertiesUtil.shouldIgnore(propName, this._ignorableProps, this._includableProps)) {
/* 798 */         handleIgnoredProperty(p, ctxt, bean, propName);
/*     */ 
/*     */       
/*     */       }
/* 802 */       else if (!ext.handlePropertyValue(p, ctxt, propName, bean)) {
/*     */ 
/*     */ 
/*     */         
/* 806 */         if (this._anySetter != null) {
/*     */           try {
/* 808 */             this._anySetter.deserializeAndSet(p, ctxt, bean, propName);
/* 809 */           } catch (Exception e) {
/* 810 */             wrapAndThrow(e, bean, propName, ctxt);
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 815 */           handleUnknownProperty(p, ctxt, bean, propName);
/*     */         } 
/*     */       } 
/*     */     } 
/* 819 */     return ext.complete(p, ctxt, bean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object deserializeUsingPropertyBasedWithExternalTypeId(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 827 */     JavaType t = this._targetType;
/* 828 */     return ctxt.reportBadDefinition(t, String.format("Deserialization (of %s) with Builder, External type id, @JsonCreator not yet implemented", new Object[] { t }));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\BuilderBasedDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */