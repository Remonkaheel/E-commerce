/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.ResolvableDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.ObjectBuffer;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class UntypedObjectDeserializer
/*     */   extends StdDeserializer<Object>
/*     */   implements ResolvableDeserializer, ContextualDeserializer {
/*     */   private static final long serialVersionUID = 1L;
/*  34 */   protected static final Object[] NO_OBJECTS = new Object[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> _mapDeserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> _listDeserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> _stringDeserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> _numberDeserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private KeyDeserializer _customKeyDeserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JavaType _listType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JavaType _mapType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _nonMerging;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public UntypedObjectDeserializer() {
/*  83 */     this((JavaType)null, (JavaType)null);
/*     */   }
/*     */   
/*     */   public UntypedObjectDeserializer(JavaType listType, JavaType mapType) {
/*  87 */     super(Object.class);
/*  88 */     this._listType = listType;
/*  89 */     this._mapType = mapType;
/*  90 */     this._nonMerging = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UntypedObjectDeserializer(UntypedObjectDeserializer base, JsonDeserializer<?> mapDeser, JsonDeserializer<?> listDeser, JsonDeserializer<?> stringDeser, JsonDeserializer<?> numberDeser) {
/*  98 */     super(Object.class);
/*  99 */     this._mapDeserializer = (JsonDeserializer)mapDeser;
/* 100 */     this._listDeserializer = (JsonDeserializer)listDeser;
/* 101 */     this._stringDeserializer = (JsonDeserializer)stringDeser;
/* 102 */     this._numberDeserializer = (JsonDeserializer)numberDeser;
/* 103 */     this._listType = base._listType;
/* 104 */     this._mapType = base._mapType;
/* 105 */     this._customKeyDeserializer = base._customKeyDeserializer;
/* 106 */     this._nonMerging = base._nonMerging;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UntypedObjectDeserializer(UntypedObjectDeserializer base, boolean nonMerging) {
/* 115 */     super(Object.class);
/* 116 */     this._mapDeserializer = base._mapDeserializer;
/* 117 */     this._listDeserializer = base._listDeserializer;
/* 118 */     this._stringDeserializer = base._stringDeserializer;
/* 119 */     this._numberDeserializer = base._numberDeserializer;
/* 120 */     this._listType = base._listType;
/* 121 */     this._mapType = base._mapType;
/* 122 */     this._customKeyDeserializer = base._customKeyDeserializer;
/* 123 */     this._nonMerging = nonMerging;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UntypedObjectDeserializer(UntypedObjectDeserializer base, KeyDeserializer keyDeser) {
/* 132 */     super(Object.class);
/* 133 */     this._mapDeserializer = base._mapDeserializer;
/* 134 */     this._listDeserializer = base._listDeserializer;
/* 135 */     this._stringDeserializer = base._stringDeserializer;
/* 136 */     this._numberDeserializer = base._numberDeserializer;
/* 137 */     this._listType = base._listType;
/* 138 */     this._mapType = base._mapType;
/* 139 */     this._nonMerging = base._nonMerging;
/* 140 */     this._customKeyDeserializer = keyDeser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(DeserializationContext ctxt) throws JsonMappingException {
/* 158 */     JavaType obType = ctxt.constructType(Object.class);
/* 159 */     JavaType stringType = ctxt.constructType(String.class);
/* 160 */     TypeFactory tf = ctxt.getTypeFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 172 */     if (this._listType == null) {
/* 173 */       this._listDeserializer = _clearIfStdImpl(_findCustomDeser(ctxt, (JavaType)tf.constructCollectionType(List.class, obType)));
/*     */     } else {
/*     */       
/* 176 */       this._listDeserializer = _findCustomDeser(ctxt, this._listType);
/*     */     } 
/* 178 */     if (this._mapType == null) {
/* 179 */       this._mapDeserializer = _clearIfStdImpl(_findCustomDeser(ctxt, (JavaType)tf.constructMapType(Map.class, stringType, obType)));
/*     */     } else {
/*     */       
/* 182 */       this._mapDeserializer = _findCustomDeser(ctxt, this._mapType);
/*     */     } 
/* 184 */     this._stringDeserializer = _clearIfStdImpl(_findCustomDeser(ctxt, stringType));
/* 185 */     this._numberDeserializer = _clearIfStdImpl(_findCustomDeser(ctxt, tf.constructType(Number.class)));
/*     */ 
/*     */ 
/*     */     
/* 189 */     JavaType unknown = TypeFactory.unknownType();
/* 190 */     this._mapDeserializer = ctxt.handleSecondaryContextualization(this._mapDeserializer, null, unknown);
/* 191 */     this._listDeserializer = ctxt.handleSecondaryContextualization(this._listDeserializer, null, unknown);
/* 192 */     this._stringDeserializer = ctxt.handleSecondaryContextualization(this._stringDeserializer, null, unknown);
/* 193 */     this._numberDeserializer = ctxt.handleSecondaryContextualization(this._numberDeserializer, null, unknown);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<Object> _findCustomDeser(DeserializationContext ctxt, JavaType type) throws JsonMappingException {
/* 201 */     return ctxt.findNonContextualValueDeserializer(type);
/*     */   }
/*     */   
/*     */   protected JsonDeserializer<Object> _clearIfStdImpl(JsonDeserializer<Object> deser) {
/* 205 */     return ClassUtil.isJacksonStdImpl(deser) ? null : deser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 218 */     boolean preventMerge = (property == null && Boolean.FALSE.equals(ctxt.getConfig().getDefaultMergeable(Object.class)));
/*     */     
/* 220 */     KeyDeserializer customKeyDeser = ctxt.findKeyDeserializer(ctxt.constructType(Object.class), property);
/*     */     
/* 222 */     if (customKeyDeser != null && 
/* 223 */       ClassUtil.isJacksonStdImpl(customKeyDeser)) {
/* 224 */       customKeyDeser = null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 229 */     if (this._stringDeserializer == null && this._numberDeserializer == null && this._mapDeserializer == null && this._listDeserializer == null && customKeyDeser == null && 
/*     */ 
/*     */       
/* 232 */       getClass() == UntypedObjectDeserializer.class) {
/* 233 */       return UntypedObjectDeserializerNR.instance(preventMerge);
/*     */     }
/*     */     
/* 236 */     UntypedObjectDeserializer deser = this;
/* 237 */     if (preventMerge != this._nonMerging) {
/* 238 */       deser = new UntypedObjectDeserializer(deser, preventMerge);
/*     */     }
/*     */     
/* 241 */     if (customKeyDeser != null) {
/* 242 */       deser = new UntypedObjectDeserializer(deser, customKeyDeser);
/*     */     }
/* 244 */     return deser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/* 262 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 267 */     return LogicalType.Untyped;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 273 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 279 */     switch (p.currentTokenId()) {
/*     */ 
/*     */       
/*     */       case 1:
/*     */       case 2:
/*     */       case 5:
/* 285 */         if (this._mapDeserializer != null) {
/* 286 */           return this._mapDeserializer.deserialize(p, ctxt);
/*     */         }
/* 288 */         return mapObject(p, ctxt);
/*     */       case 3:
/* 290 */         if (ctxt.isEnabled(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY)) {
/* 291 */           return mapArrayToArray(p, ctxt);
/*     */         }
/* 293 */         if (this._listDeserializer != null) {
/* 294 */           return this._listDeserializer.deserialize(p, ctxt);
/*     */         }
/* 296 */         return mapArray(p, ctxt);
/*     */       case 12:
/* 298 */         return p.getEmbeddedObject();
/*     */       case 6:
/* 300 */         if (this._stringDeserializer != null) {
/* 301 */           return this._stringDeserializer.deserialize(p, ctxt);
/*     */         }
/* 303 */         return p.getText();
/*     */       
/*     */       case 7:
/* 306 */         if (this._numberDeserializer != null) {
/* 307 */           return this._numberDeserializer.deserialize(p, ctxt);
/*     */         }
/*     */ 
/*     */         
/* 311 */         if (ctxt.hasSomeOfFeatures(F_MASK_INT_COERCIONS)) {
/* 312 */           return _coerceIntegral(p, ctxt);
/*     */         }
/* 314 */         return p.getNumberValue();
/*     */       
/*     */       case 8:
/* 317 */         if (this._numberDeserializer != null) {
/* 318 */           return this._numberDeserializer.deserialize(p, ctxt);
/*     */         }
/* 320 */         return _deserializeFP(p, ctxt);
/*     */       case 9:
/* 322 */         return Boolean.TRUE;
/*     */       case 10:
/* 324 */         return Boolean.FALSE;
/*     */       
/*     */       case 11:
/* 327 */         return null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 332 */     return ctxt.handleUnexpectedToken(Object.class, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 339 */     switch (p.currentTokenId()) {
/*     */ 
/*     */       
/*     */       case 1:
/*     */       case 3:
/*     */       case 5:
/* 345 */         return typeDeserializer.deserializeTypedFromAny(p, ctxt);
/*     */       
/*     */       case 12:
/* 348 */         return p.getEmbeddedObject();
/*     */ 
/*     */ 
/*     */       
/*     */       case 6:
/* 353 */         if (this._stringDeserializer != null) {
/* 354 */           return this._stringDeserializer.deserialize(p, ctxt);
/*     */         }
/* 356 */         return p.getText();
/*     */       
/*     */       case 7:
/* 359 */         if (this._numberDeserializer != null) {
/* 360 */           return this._numberDeserializer.deserialize(p, ctxt);
/*     */         }
/*     */         
/* 363 */         if (ctxt.hasSomeOfFeatures(F_MASK_INT_COERCIONS)) {
/* 364 */           return _coerceIntegral(p, ctxt);
/*     */         }
/* 366 */         return p.getNumberValue();
/*     */       
/*     */       case 8:
/* 369 */         if (this._numberDeserializer != null) {
/* 370 */           return this._numberDeserializer.deserialize(p, ctxt);
/*     */         }
/* 372 */         return _deserializeFP(p, ctxt);
/*     */       
/*     */       case 9:
/* 375 */         return Boolean.TRUE;
/*     */       case 10:
/* 377 */         return Boolean.FALSE;
/*     */       
/*     */       case 11:
/* 380 */         return null;
/*     */     } 
/*     */     
/* 383 */     return ctxt.handleUnexpectedToken(Object.class, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt, Object intoValue) throws IOException {
/* 391 */     if (this._nonMerging) {
/* 392 */       return deserialize(p, ctxt);
/*     */     }
/*     */     
/* 395 */     switch (p.currentTokenId()) {
/*     */ 
/*     */       
/*     */       case 1:
/*     */       case 2:
/*     */       case 5:
/* 401 */         if (this._mapDeserializer != null) {
/* 402 */           return this._mapDeserializer.deserialize(p, ctxt, intoValue);
/*     */         }
/* 404 */         if (intoValue instanceof Map) {
/* 405 */           return mapObject(p, ctxt, (Map<Object, Object>)intoValue);
/*     */         }
/* 407 */         return mapObject(p, ctxt);
/*     */       case 3:
/* 409 */         if (this._listDeserializer != null) {
/* 410 */           return this._listDeserializer.deserialize(p, ctxt, intoValue);
/*     */         }
/* 412 */         if (intoValue instanceof Collection) {
/* 413 */           return mapArray(p, ctxt, (Collection<Object>)intoValue);
/*     */         }
/* 415 */         if (ctxt.isEnabled(DeserializationFeature.USE_JAVA_ARRAY_FOR_JSON_ARRAY)) {
/* 416 */           return mapArrayToArray(p, ctxt);
/*     */         }
/* 418 */         return mapArray(p, ctxt);
/*     */       case 12:
/* 420 */         return p.getEmbeddedObject();
/*     */       case 6:
/* 422 */         if (this._stringDeserializer != null) {
/* 423 */           return this._stringDeserializer.deserialize(p, ctxt, intoValue);
/*     */         }
/* 425 */         return p.getText();
/*     */       
/*     */       case 7:
/* 428 */         if (this._numberDeserializer != null) {
/* 429 */           return this._numberDeserializer.deserialize(p, ctxt, intoValue);
/*     */         }
/* 431 */         if (ctxt.hasSomeOfFeatures(F_MASK_INT_COERCIONS)) {
/* 432 */           return _coerceIntegral(p, ctxt);
/*     */         }
/* 434 */         return p.getNumberValue();
/*     */       
/*     */       case 8:
/* 437 */         if (this._numberDeserializer != null) {
/* 438 */           return this._numberDeserializer.deserialize(p, ctxt, intoValue);
/*     */         }
/* 440 */         return _deserializeFP(p, ctxt);
/*     */       case 9:
/* 442 */         return Boolean.TRUE;
/*     */       case 10:
/* 444 */         return Boolean.FALSE;
/*     */ 
/*     */       
/*     */       case 11:
/* 448 */         return null;
/*     */     } 
/*     */ 
/*     */     
/* 452 */     return deserialize(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object mapArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 467 */     if (p.nextToken() == JsonToken.END_ARRAY) {
/* 468 */       return new ArrayList(2);
/*     */     }
/* 470 */     Object value = deserialize(p, ctxt);
/* 471 */     if (p.nextToken() == JsonToken.END_ARRAY) {
/* 472 */       ArrayList<Object> l = new ArrayList(2);
/* 473 */       l.add(value);
/* 474 */       return l;
/*     */     } 
/* 476 */     Object value2 = deserialize(p, ctxt);
/* 477 */     if (p.nextToken() == JsonToken.END_ARRAY) {
/* 478 */       ArrayList<Object> l = new ArrayList(2);
/* 479 */       l.add(value);
/* 480 */       l.add(value2);
/* 481 */       return l;
/*     */     } 
/* 483 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 484 */     Object[] values = buffer.resetAndStart();
/* 485 */     int ptr = 0;
/* 486 */     values[ptr++] = value;
/* 487 */     values[ptr++] = value2;
/* 488 */     int totalSize = ptr;
/*     */     do {
/* 490 */       value = deserialize(p, ctxt);
/* 491 */       totalSize++;
/* 492 */       if (ptr >= values.length) {
/* 493 */         values = buffer.appendCompletedChunk(values);
/* 494 */         ptr = 0;
/*     */       } 
/* 496 */       values[ptr++] = value;
/* 497 */     } while (p.nextToken() != JsonToken.END_ARRAY);
/*     */     
/* 499 */     ArrayList<Object> result = new ArrayList(totalSize);
/* 500 */     buffer.completeAndClearBuffer(values, ptr, result);
/* 501 */     ctxt.returnObjectBuffer(buffer);
/* 502 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object mapArray(JsonParser p, DeserializationContext ctxt, Collection<Object> result) throws IOException {
/* 510 */     while (p.nextToken() != JsonToken.END_ARRAY) {
/* 511 */       result.add(deserialize(p, ctxt));
/*     */     }
/* 513 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object mapObject(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 522 */     JsonToken t = p.currentToken();
/*     */     
/* 524 */     if (t == JsonToken.START_OBJECT) {
/* 525 */       key1 = p.nextFieldName();
/* 526 */     } else if (t == JsonToken.FIELD_NAME) {
/* 527 */       key1 = p.currentName();
/*     */     } else {
/* 529 */       if (t != JsonToken.END_OBJECT) {
/* 530 */         return ctxt.handleUnexpectedToken(handledType(), p);
/*     */       }
/* 532 */       key1 = null;
/*     */     } 
/* 534 */     if (key1 == null)
/*     */     {
/* 536 */       return new LinkedHashMap<>(2);
/*     */     }
/* 538 */     String key1 = _customDeserializeKey(key1, ctxt);
/*     */ 
/*     */ 
/*     */     
/* 542 */     p.nextToken();
/* 543 */     Object value1 = deserialize(p, ctxt);
/* 544 */     String key2 = p.nextFieldName();
/* 545 */     if (key2 == null) {
/*     */       
/* 547 */       LinkedHashMap<String, Object> linkedHashMap = new LinkedHashMap<>(2);
/* 548 */       linkedHashMap.put(key1, value1);
/* 549 */       return linkedHashMap;
/*     */     } 
/* 551 */     key2 = _customDeserializeKey(key2, ctxt);
/*     */     
/* 553 */     p.nextToken();
/* 554 */     Object value2 = deserialize(p, ctxt);
/*     */     
/* 556 */     String key = p.nextFieldName();
/* 557 */     if (key == null) {
/* 558 */       LinkedHashMap<String, Object> linkedHashMap = new LinkedHashMap<>(4);
/* 559 */       linkedHashMap.put(key1, value1);
/* 560 */       if (linkedHashMap.put(key2, value2) != null)
/*     */       {
/* 562 */         return _mapObjectWithDups(p, ctxt, linkedHashMap, key1, value1, value2, key);
/*     */       }
/* 564 */       return linkedHashMap;
/*     */     } 
/* 566 */     key = _customDeserializeKey(key, ctxt);
/*     */ 
/*     */     
/* 569 */     LinkedHashMap<String, Object> result = new LinkedHashMap<>();
/* 570 */     result.put(key1, value1);
/* 571 */     if (result.put(key2, value2) != null)
/*     */     {
/* 573 */       return _mapObjectWithDups(p, ctxt, result, key1, value1, value2, key);
/*     */     }
/*     */     
/*     */     while (true) {
/* 577 */       p.nextToken();
/* 578 */       Object newValue = deserialize(p, ctxt);
/* 579 */       Object oldValue = result.put(key, newValue);
/* 580 */       if (oldValue != null) {
/* 581 */         return _mapObjectWithDups(p, ctxt, result, key, oldValue, newValue, 
/* 582 */             _customDeserializeNullableKey(p.nextFieldName(), ctxt));
/*     */       }
/* 584 */       if ((key = _customDeserializeNullableKey(p.nextFieldName(), ctxt)) == null) {
/* 585 */         return result;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _mapObjectWithDups(JsonParser p, DeserializationContext ctxt, Map<String, Object> result, String key, Object oldValue, Object newValue, String nextKey) throws IOException {
/* 593 */     boolean squashDups = ctxt.isEnabled(StreamReadCapability.DUPLICATE_PROPERTIES);
/*     */     
/* 595 */     if (squashDups) {
/* 596 */       _squashDups(result, key, oldValue, newValue);
/*     */     }
/*     */     
/* 599 */     while (nextKey != null) {
/* 600 */       p.nextToken();
/* 601 */       newValue = deserialize(p, ctxt);
/* 602 */       oldValue = result.put(nextKey, newValue);
/* 603 */       if (oldValue != null && squashDups) {
/* 604 */         _squashDups(result, key, oldValue, newValue);
/*     */       }
/* 606 */       nextKey = _customDeserializeNullableKey(p.nextFieldName(), ctxt);
/*     */     } 
/*     */     
/* 609 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String _customDeserializeKey(String key, DeserializationContext ctxt) throws IOException {
/* 621 */     if (this._customKeyDeserializer != null) {
/* 622 */       return (String)this._customKeyDeserializer.deserializeKey(key, ctxt);
/*     */     }
/* 624 */     return key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String _customDeserializeNullableKey(String key, DeserializationContext ctxt) throws IOException {
/* 636 */     if (this._customKeyDeserializer != null && 
/* 637 */       key != null) {
/* 638 */       return (String)this._customKeyDeserializer.deserializeKey(key, ctxt);
/*     */     }
/*     */     
/* 641 */     return key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _squashDups(Map<String, Object> result, String key, Object oldValue, Object newValue) {
/* 648 */     if (oldValue instanceof List) {
/* 649 */       ((List<Object>)oldValue).add(newValue);
/* 650 */       result.put(key, oldValue);
/*     */     } else {
/* 652 */       ArrayList<Object> l = new ArrayList();
/* 653 */       l.add(oldValue);
/* 654 */       l.add(newValue);
/* 655 */       result.put(key, l);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object[] mapArrayToArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 665 */     if (p.nextToken() == JsonToken.END_ARRAY) {
/* 666 */       return NO_OBJECTS;
/*     */     }
/* 668 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 669 */     Object[] values = buffer.resetAndStart();
/* 670 */     int ptr = 0;
/*     */     while (true) {
/* 672 */       Object value = deserialize(p, ctxt);
/* 673 */       if (ptr >= values.length) {
/* 674 */         values = buffer.appendCompletedChunk(values);
/* 675 */         ptr = 0;
/*     */       } 
/* 677 */       values[ptr++] = value;
/* 678 */       if (p.nextToken() == JsonToken.END_ARRAY) {
/* 679 */         Object[] result = buffer.completeAndClearBuffer(values, ptr);
/* 680 */         ctxt.returnObjectBuffer(buffer);
/* 681 */         return result;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Object mapObject(JsonParser p, DeserializationContext ctxt, Map<Object, Object> m) throws IOException {
/* 687 */     JsonToken t = p.currentToken();
/* 688 */     if (t == JsonToken.START_OBJECT) {
/* 689 */       t = p.nextToken();
/*     */     }
/* 691 */     if (t == JsonToken.END_OBJECT) {
/* 692 */       return m;
/*     */     }
/*     */     
/* 695 */     String key = p.currentName(); while (true) {
/*     */       Object newV;
/* 697 */       p.nextToken();
/*     */       
/* 699 */       Object old = m.get(key);
/*     */ 
/*     */       
/* 702 */       if (old != null) {
/* 703 */         newV = deserialize(p, ctxt, old);
/*     */       } else {
/* 705 */         newV = deserialize(p, ctxt);
/*     */       } 
/* 707 */       if (newV != old) {
/* 708 */         m.put(key, newV);
/*     */       }
/* 710 */       if ((key = p.nextFieldName()) == null) {
/* 711 */         return m;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Object _deserializeFP(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 717 */     JsonParser.NumberTypeFP nt = p.getNumberTypeFP();
/* 718 */     if (nt == JsonParser.NumberTypeFP.BIG_DECIMAL) {
/* 719 */       return p.getDecimalValue();
/*     */     }
/* 721 */     if (!p.isNaN() && 
/* 722 */       ctxt.isEnabled(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)) {
/* 723 */       return p.getDecimalValue();
/*     */     }
/*     */     
/* 726 */     if (nt == JsonParser.NumberTypeFP.FLOAT32) {
/* 727 */       return Float.valueOf(p.getFloatValue());
/*     */     }
/* 729 */     return Double.valueOf(p.getDoubleValue());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\UntypedObjectDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */