/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedField;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.util.Annotations;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FieldProperty
/*     */   extends SettableBeanProperty
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final AnnotatedField _annotated;
/*     */   protected final transient Field _field;
/*     */   protected final boolean _skipNulls;
/*     */   
/*     */   public FieldProperty(BeanPropertyDefinition propDef, JavaType type, TypeDeserializer typeDeser, Annotations contextAnnotations, AnnotatedField field) {
/*  45 */     super(propDef, type, typeDeser, contextAnnotations);
/*  46 */     this._annotated = field;
/*  47 */     this._field = field.getAnnotated();
/*  48 */     this._skipNulls = NullsConstantProvider.isSkipper(this._nullProvider);
/*     */   }
/*     */ 
/*     */   
/*     */   protected FieldProperty(FieldProperty src, JsonDeserializer<?> deser, NullValueProvider nva) {
/*  53 */     super(src, deser, nva);
/*  54 */     this._annotated = src._annotated;
/*  55 */     this._field = src._field;
/*  56 */     this._skipNulls = NullsConstantProvider.isSkipper(nva);
/*     */   }
/*     */   
/*     */   protected FieldProperty(FieldProperty src, PropertyName newName) {
/*  60 */     super(src, newName);
/*  61 */     this._annotated = src._annotated;
/*  62 */     this._field = src._field;
/*  63 */     this._skipNulls = src._skipNulls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FieldProperty(FieldProperty src) {
/*  71 */     super(src);
/*  72 */     this._annotated = src._annotated;
/*  73 */     Field f = this._annotated.getAnnotated();
/*  74 */     if (f == null) {
/*  75 */       throw new IllegalArgumentException("Missing field (broken JDK (de)serialization?)");
/*     */     }
/*  77 */     this._field = f;
/*  78 */     this._skipNulls = src._skipNulls;
/*     */   }
/*     */ 
/*     */   
/*     */   public SettableBeanProperty withName(PropertyName newName) {
/*  83 */     return new FieldProperty(this, newName);
/*     */   }
/*     */ 
/*     */   
/*     */   public SettableBeanProperty withValueDeserializer(JsonDeserializer<?> deser) {
/*  88 */     if (this._valueDeserializer == deser) {
/*  89 */       return this;
/*     */     }
/*     */     
/*  92 */     NullValueProvider nvp = (this._valueDeserializer == this._nullProvider) ? (NullValueProvider)deser : this._nullProvider;
/*  93 */     return new FieldProperty(this, deser, nvp);
/*     */   }
/*     */ 
/*     */   
/*     */   public SettableBeanProperty withNullProvider(NullValueProvider nva) {
/*  98 */     return new FieldProperty(this, this._valueDeserializer, nva);
/*     */   }
/*     */ 
/*     */   
/*     */   public void fixAccess(DeserializationConfig config) {
/* 103 */     ClassUtil.checkAndFixAccess(this._field, config
/* 104 */         .isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <A extends java.lang.annotation.Annotation> A getAnnotation(Class<A> acls) {
/* 115 */     return (this._annotated == null) ? null : (A)this._annotated.getAnnotation(acls);
/*     */   }
/*     */   public AnnotatedMember getMember() {
/* 118 */     return (AnnotatedMember)this._annotated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deserializeAndSet(JsonParser p, DeserializationContext ctxt, Object instance) throws IOException {
/*     */     Object value;
/* 131 */     if (p.hasToken(JsonToken.VALUE_NULL)) {
/* 132 */       if (this._skipNulls) {
/*     */         return;
/*     */       }
/* 135 */       value = this._nullProvider.getNullValue(ctxt);
/* 136 */     } else if (this._valueTypeDeserializer == null) {
/* 137 */       value = this._valueDeserializer.deserialize(p, ctxt);
/*     */       
/* 139 */       if (value == null) {
/* 140 */         if (this._skipNulls) {
/*     */           return;
/*     */         }
/* 143 */         value = this._nullProvider.getNullValue(ctxt);
/*     */       } 
/*     */     } else {
/* 146 */       value = this._valueDeserializer.deserializeWithType(p, ctxt, this._valueTypeDeserializer);
/*     */     } 
/*     */     try {
/* 149 */       this._field.set(instance, value);
/* 150 */     } catch (Exception e) {
/* 151 */       _throwAsIOE(p, e, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeSetAndReturn(JsonParser p, DeserializationContext ctxt, Object instance) throws IOException {
/*     */     Object value;
/* 160 */     if (p.hasToken(JsonToken.VALUE_NULL)) {
/* 161 */       if (this._skipNulls) {
/* 162 */         return instance;
/*     */       }
/* 164 */       value = this._nullProvider.getNullValue(ctxt);
/* 165 */     } else if (this._valueTypeDeserializer == null) {
/* 166 */       value = this._valueDeserializer.deserialize(p, ctxt);
/*     */       
/* 168 */       if (value == null) {
/* 169 */         if (this._skipNulls) {
/* 170 */           return instance;
/*     */         }
/* 172 */         value = this._nullProvider.getNullValue(ctxt);
/*     */       } 
/*     */     } else {
/* 175 */       value = this._valueDeserializer.deserializeWithType(p, ctxt, this._valueTypeDeserializer);
/*     */     } 
/*     */     try {
/* 178 */       this._field.set(instance, value);
/* 179 */     } catch (Exception e) {
/* 180 */       _throwAsIOE(p, e, value);
/*     */     } 
/* 182 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(Object instance, Object value) throws IOException {
/* 188 */     if (value == null && 
/* 189 */       this._skipNulls) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 194 */       this._field.set(instance, value);
/* 195 */     } catch (Exception e) {
/*     */       
/* 197 */       _throwAsIOE(e, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object setAndReturn(Object instance, Object value) throws IOException {
/* 204 */     if (value == null && 
/* 205 */       this._skipNulls) {
/* 206 */       return instance;
/*     */     }
/*     */     
/*     */     try {
/* 210 */       this._field.set(instance, value);
/* 211 */     } catch (Exception e) {
/*     */       
/* 213 */       _throwAsIOE(e, value);
/*     */     } 
/* 215 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object readResolve() {
/* 225 */     return new FieldProperty(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\impl\FieldProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */