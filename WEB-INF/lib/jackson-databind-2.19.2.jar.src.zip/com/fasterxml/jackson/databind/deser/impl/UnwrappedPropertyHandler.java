/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnwrappedPropertyHandler
/*     */ {
/*     */   public static final String JSON_UNWRAPPED_NAME_PREFIX = "@JsonUnwrapped/";
/*     */   protected final List<SettableBeanProperty> _creatorProperties;
/*     */   protected final List<SettableBeanProperty> _properties;
/*     */   
/*     */   public UnwrappedPropertyHandler() {
/*  32 */     this._creatorProperties = new ArrayList<>();
/*  33 */     this._properties = new ArrayList<>();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected UnwrappedPropertyHandler(List<SettableBeanProperty> props) {
/*  38 */     this(new ArrayList<>(), props);
/*     */   }
/*     */ 
/*     */   
/*     */   protected UnwrappedPropertyHandler(List<SettableBeanProperty> creatorProps, List<SettableBeanProperty> props) {
/*  43 */     this._creatorProperties = creatorProps;
/*  44 */     this._properties = props;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCreatorProperty(SettableBeanProperty property) {
/*  51 */     this._creatorProperties.add(property);
/*     */   }
/*     */   
/*     */   public void addProperty(SettableBeanProperty property) {
/*  55 */     this._properties.add(property);
/*     */   }
/*     */   
/*     */   public UnwrappedPropertyHandler renameAll(NameTransformer transformer) {
/*  59 */     return new UnwrappedPropertyHandler(
/*  60 */         renameProperties(this._creatorProperties, transformer), 
/*  61 */         renameProperties(this._properties, transformer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<SettableBeanProperty> renameProperties(Collection<SettableBeanProperty> properties, NameTransformer transformer) {
/*  69 */     List<SettableBeanProperty> newProps = new ArrayList<>(properties.size());
/*  70 */     for (SettableBeanProperty prop : properties) {
/*  71 */       if (prop == null) {
/*  72 */         newProps.add(null);
/*     */         
/*     */         continue;
/*     */       } 
/*  76 */       newProps.add(prop.unwrapped(transformer));
/*     */     } 
/*  78 */     return newProps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyValueBuffer processUnwrappedCreatorProperties(JsonParser originalParser, DeserializationContext ctxt, PropertyValueBuffer values, TokenBuffer buffered) throws IOException {
/*  88 */     for (SettableBeanProperty prop : this._creatorProperties) {
/*  89 */       JsonParser p = buffered.asParser(originalParser.streamReadConstraints());
/*  90 */       p.nextToken();
/*  91 */       values.assignParameter(prop, prop.deserialize(p, ctxt));
/*     */     } 
/*     */     
/*  94 */     return values;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object processUnwrapped(JsonParser originalParser, DeserializationContext ctxt, Object bean, TokenBuffer buffered) throws IOException {
/* 102 */     for (SettableBeanProperty prop : this._properties) {
/* 103 */       JsonParser p = buffered.asParser(originalParser.streamReadConstraints());
/* 104 */       p.nextToken();
/* 105 */       prop.deserializeAndSet(p, ctxt, bean);
/*     */     } 
/* 107 */     return bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyName creatorParamName(int index) {
/* 117 */     return new PropertyName("@JsonUnwrapped/" + index);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\impl\UnwrappedPropertyHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */