/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Base64Variants;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.exc.InvalidFormatException;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.UUID;
/*     */ 
/*     */ 
/*     */ public class UUIDDeserializer
/*     */   extends FromStringDeserializer<UUID>
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  16 */   static final int[] HEX_DIGITS = new int[127];
/*     */   static {
/*  18 */     Arrays.fill(HEX_DIGITS, -1); int i;
/*  19 */     for (i = 0; i < 10; ) { HEX_DIGITS[48 + i] = i; i++; }
/*  20 */      for (i = 0; i < 6; i++) {
/*  21 */       HEX_DIGITS[97 + i] = 10 + i;
/*  22 */       HEX_DIGITS[65 + i] = 10 + i;
/*     */     } 
/*     */   }
/*     */   public UUIDDeserializer() {
/*  26 */     super(UUID.class);
/*     */   }
/*     */   
/*     */   public Object getEmptyValue(DeserializationContext ctxt) {
/*  30 */     return new UUID(0L, 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UUID _deserialize(String id, DeserializationContext ctxt) throws IOException {
/*  38 */     if (id.length() != 36) {
/*     */ 
/*     */       
/*  41 */       if (id.length() == 24) {
/*     */         
/*  43 */         id = convertFromUrlSafe(id);
/*  44 */         byte[] stuff = Base64Variants.getDefaultVariant().decode(id);
/*  45 */         return _fromBytes(stuff, ctxt);
/*     */       } 
/*     */ 
/*     */       
/*  49 */       if (id.length() == 22) {
/*     */         
/*  51 */         id = convertToUrlSafe(id);
/*  52 */         byte[] stuff = Base64Variants.MODIFIED_FOR_URL.decode(id);
/*  53 */         return _fromBytes(stuff, ctxt);
/*     */       } 
/*  55 */       return _badFormat(id, ctxt);
/*     */     } 
/*     */ 
/*     */     
/*  59 */     if (id.charAt(8) != '-' || id.charAt(13) != '-' || id
/*  60 */       .charAt(18) != '-' || id.charAt(23) != '-') {
/*  61 */       _badFormat(id, ctxt);
/*     */     }
/*  63 */     long l1 = intFromChars(id, 0, ctxt);
/*  64 */     l1 <<= 32L;
/*  65 */     long l2 = shortFromChars(id, 9, ctxt) << 16L;
/*  66 */     l2 |= shortFromChars(id, 14, ctxt);
/*  67 */     long hi = l1 + l2;
/*     */     
/*  69 */     int i1 = shortFromChars(id, 19, ctxt) << 16 | shortFromChars(id, 24, ctxt);
/*  70 */     l1 = i1;
/*  71 */     l1 <<= 32L;
/*  72 */     l2 = intFromChars(id, 28, ctxt);
/*  73 */     l2 = l2 << 32L >>> 32L;
/*  74 */     long lo = l1 | l2;
/*     */     
/*  76 */     return new UUID(hi, lo);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected UUID _deserializeEmbedded(Object ob, DeserializationContext ctxt) throws IOException {
/*  82 */     if (ob instanceof byte[]) {
/*  83 */       return _fromBytes((byte[])ob, ctxt);
/*     */     }
/*  85 */     return super._deserializeEmbedded(ob, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private UUID _badFormat(String uuidStr, DeserializationContext ctxt) throws IOException {
/*  91 */     return (UUID)ctxt.handleWeirdStringValue(handledType(), uuidStr, "UUID has to be represented by standard 36-char representation", new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   int intFromChars(String str, int index, DeserializationContext ctxt) throws JsonMappingException {
/*  96 */     return (byteFromChars(str, index, ctxt) << 24) + (
/*  97 */       byteFromChars(str, index + 2, ctxt) << 16) + (
/*  98 */       byteFromChars(str, index + 4, ctxt) << 8) + 
/*  99 */       byteFromChars(str, index + 6, ctxt);
/*     */   }
/*     */   
/*     */   int shortFromChars(String str, int index, DeserializationContext ctxt) throws JsonMappingException {
/* 103 */     return (byteFromChars(str, index, ctxt) << 8) + byteFromChars(str, index + 2, ctxt);
/*     */   }
/*     */ 
/*     */   
/*     */   int byteFromChars(String str, int index, DeserializationContext ctxt) throws JsonMappingException {
/* 108 */     char c1 = str.charAt(index);
/* 109 */     char c2 = str.charAt(index + 1);
/*     */     
/* 111 */     if (c1 <= '' && c2 <= '') {
/* 112 */       int hex = HEX_DIGITS[c1] << 4 | HEX_DIGITS[c2];
/* 113 */       if (hex >= 0) {
/* 114 */         return hex;
/*     */       }
/*     */     } 
/* 117 */     if (c1 > '' || HEX_DIGITS[c1] < 0) {
/* 118 */       return _badChar(str, index, ctxt, c1);
/*     */     }
/* 120 */     return _badChar(str, index + 1, ctxt, c2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int _badChar(String uuidStr, int index, DeserializationContext ctxt, char c) throws JsonMappingException {
/* 126 */     throw ctxt.weirdStringException(uuidStr, handledType(), 
/* 127 */         String.format("Non-hex character '%c' (value 0x%s), not valid for UUID String", new Object[] {
/*     */             
/* 129 */             Character.valueOf(c), Integer.toHexString(c) }));
/*     */   }
/*     */   
/*     */   private UUID _fromBytes(byte[] bytes, DeserializationContext ctxt) throws JsonMappingException {
/* 133 */     if (bytes.length != 16) {
/* 134 */       throw InvalidFormatException.from(ctxt.getParser(), "Can only construct UUIDs from byte[16]; got " + bytes.length + " bytes", bytes, 
/*     */           
/* 136 */           handledType());
/*     */     }
/* 138 */     return new UUID(_long(bytes, 0), _long(bytes, 8));
/*     */   }
/*     */   
/*     */   private String convertToUrlSafe(String base64) {
/* 142 */     return base64
/* 143 */       .replace('+', '-')
/* 144 */       .replace('/', '_');
/*     */   }
/*     */   
/*     */   private String convertFromUrlSafe(String base64) {
/* 148 */     return base64
/* 149 */       .replace('-', '+')
/* 150 */       .replace('_', '/');
/*     */   }
/*     */   
/*     */   private static long _long(byte[] b, int offset) {
/* 154 */     long l1 = _int(b, offset) << 32L;
/* 155 */     long l2 = _int(b, offset + 4);
/*     */     
/* 157 */     l2 = l2 << 32L >>> 32L;
/* 158 */     return l1 | l2;
/*     */   }
/*     */   
/*     */   private static int _int(byte[] b, int offset) {
/* 162 */     return b[offset] << 24 | (b[offset + 1] & 0xFF) << 16 | (b[offset + 2] & 0xFF) << 8 | b[offset + 3] & 0xFF;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\UUIDDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */