/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.StdDateFormat;
/*     */ import java.io.IOException;
/*     */ import java.sql.Date;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.HashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public class DateDeserializers {
/*  26 */   private static final HashSet<String> _utilClasses = new HashSet<>();
/*     */   static {
/*  28 */     _utilClasses.add("java.util.Calendar");
/*  29 */     _utilClasses.add("java.util.GregorianCalendar");
/*  30 */     _utilClasses.add("java.util.Date");
/*     */   }
/*     */ 
/*     */   
/*     */   public static JsonDeserializer<?> find(Class<?> rawType, String clsName) {
/*  35 */     if (_utilClasses.contains(clsName)) {
/*     */       
/*  37 */       if (rawType == Calendar.class) {
/*  38 */         return new CalendarDeserializer();
/*     */       }
/*  40 */       if (rawType == Date.class) {
/*  41 */         return DateDeserializer.instance;
/*     */       }
/*  43 */       if (rawType == GregorianCalendar.class) {
/*  44 */         return new CalendarDeserializer((Class)GregorianCalendar.class);
/*     */       }
/*     */     } 
/*  47 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean hasDeserializerFor(Class<?> rawType) {
/*  52 */     return _utilClasses.contains(rawType.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static abstract class DateBasedDeserializer<T>
/*     */     extends StdScalarDeserializer<T>
/*     */     implements ContextualDeserializer
/*     */   {
/*     */     protected final DateFormat _customFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final String _formatString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected DateBasedDeserializer(Class<?> clz) {
/*  77 */       super(clz);
/*  78 */       this._customFormat = null;
/*  79 */       this._formatString = null;
/*     */     }
/*     */ 
/*     */     
/*     */     protected DateBasedDeserializer(DateBasedDeserializer<T> base, DateFormat format, String formatStr) {
/*  84 */       super(base._valueClass);
/*  85 */       this._customFormat = format;
/*  86 */       this._formatString = formatStr;
/*     */     }
/*     */ 
/*     */     
/*     */     protected abstract DateBasedDeserializer<T> withDateFormat(DateFormat param1DateFormat, String param1String);
/*     */     
/*     */     public LogicalType logicalType() {
/*  93 */       return LogicalType.DateTime;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 101 */       JsonFormat.Value format = findFormatOverrides(ctxt, property, 
/* 102 */           handledType());
/*     */       
/* 104 */       if (format != null) {
/* 105 */         TimeZone tz = format.getTimeZone();
/* 106 */         Boolean lenient = format.getLenient();
/*     */ 
/*     */         
/* 109 */         if (format.hasPattern()) {
/* 110 */           String pattern = format.getPattern();
/* 111 */           Locale loc = format.hasLocale() ? format.getLocale() : ctxt.getLocale();
/* 112 */           SimpleDateFormat df = new SimpleDateFormat(pattern, loc);
/* 113 */           if (tz == null) {
/* 114 */             tz = ctxt.getTimeZone();
/*     */           }
/* 116 */           df.setTimeZone(tz);
/* 117 */           if (lenient != null) {
/* 118 */             df.setLenient(lenient.booleanValue());
/*     */           }
/* 120 */           return withDateFormat(df, pattern);
/*     */         } 
/*     */         
/* 123 */         if (tz != null) {
/* 124 */           StdDateFormat stdDateFormat; DateFormat dateFormat1, df = ctxt.getConfig().getDateFormat();
/*     */           
/* 126 */           if (df.getClass() == StdDateFormat.class) {
/* 127 */             Locale loc = format.hasLocale() ? format.getLocale() : ctxt.getLocale();
/* 128 */             StdDateFormat std = (StdDateFormat)df;
/* 129 */             std = std.withTimeZone(tz);
/* 130 */             std = std.withLocale(loc);
/* 131 */             if (lenient != null) {
/* 132 */               std = std.withLenient(lenient);
/*     */             }
/* 134 */             stdDateFormat = std;
/*     */           } else {
/*     */             
/* 137 */             dateFormat1 = (DateFormat)stdDateFormat.clone();
/* 138 */             dateFormat1.setTimeZone(tz);
/* 139 */             if (lenient != null) {
/* 140 */               dateFormat1.setLenient(lenient.booleanValue());
/*     */             }
/*     */           } 
/* 143 */           return withDateFormat(dateFormat1, this._formatString);
/*     */         } 
/*     */         
/* 146 */         if (lenient != null) {
/* 147 */           StdDateFormat stdDateFormat; DateFormat dateFormat1, df = ctxt.getConfig().getDateFormat();
/* 148 */           String pattern = this._formatString;
/*     */           
/* 150 */           if (df.getClass() == StdDateFormat.class) {
/* 151 */             StdDateFormat std = (StdDateFormat)df;
/* 152 */             std = std.withLenient(lenient);
/* 153 */             stdDateFormat = std;
/* 154 */             pattern = std.toPattern();
/*     */           } else {
/*     */             
/* 157 */             dateFormat1 = (DateFormat)stdDateFormat.clone();
/* 158 */             dateFormat1.setLenient(lenient.booleanValue());
/* 159 */             if (dateFormat1 instanceof SimpleDateFormat) {
/* 160 */               ((SimpleDateFormat)dateFormat1).toPattern();
/*     */             }
/*     */           } 
/* 163 */           if (pattern == null) {
/* 164 */             pattern = "[unknown]";
/*     */           }
/* 166 */           return withDateFormat(dateFormat1, pattern);
/*     */         } 
/*     */       } 
/* 169 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Date _parseDate(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 176 */       if (this._customFormat != null && 
/* 177 */         p.hasToken(JsonToken.VALUE_STRING)) {
/* 178 */         String str = p.getText().trim();
/* 179 */         if (str.isEmpty()) {
/* 180 */           CoercionAction act = _checkFromStringCoercion(ctxt, str);
/* 181 */           switch (act) {
/*     */             case AsEmpty:
/* 183 */               return new Date(0L);
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 188 */           return null;
/*     */         } 
/* 190 */         synchronized (this._customFormat) {
/*     */           
/* 192 */           return this._customFormat.parse(str);
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 200 */       return super._parseDate(p, ctxt);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JacksonStdImpl
/*     */   public static class CalendarDeserializer
/*     */     extends DateBasedDeserializer<Calendar>
/*     */   {
/*     */     protected final Constructor<Calendar> _defaultCtor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CalendarDeserializer() {
/* 222 */       super(Calendar.class);
/* 223 */       this._defaultCtor = null;
/*     */     }
/*     */ 
/*     */     
/*     */     public CalendarDeserializer(Class<? extends Calendar> cc) {
/* 228 */       super(cc);
/* 229 */       this._defaultCtor = ClassUtil.findConstructor(cc, false);
/*     */     }
/*     */     
/*     */     public CalendarDeserializer(CalendarDeserializer src, DateFormat df, String formatString) {
/* 233 */       super(src, df, formatString);
/* 234 */       this._defaultCtor = src._defaultCtor;
/*     */     }
/*     */ 
/*     */     
/*     */     protected CalendarDeserializer withDateFormat(DateFormat df, String formatString) {
/* 239 */       return new CalendarDeserializer(this, df, formatString);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getEmptyValue(DeserializationContext ctxt) {
/* 244 */       GregorianCalendar cal = new GregorianCalendar();
/* 245 */       cal.setTimeInMillis(0L);
/* 246 */       return cal;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Calendar deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 252 */       Date d = _parseDate(p, ctxt);
/* 253 */       if (d == null) {
/* 254 */         return null;
/*     */       }
/* 256 */       if (this._defaultCtor == null) {
/* 257 */         return ctxt.constructCalendar(d);
/*     */       }
/*     */       try {
/* 260 */         Calendar c = this._defaultCtor.newInstance(new Object[0]);
/* 261 */         c.setTimeInMillis(d.getTime());
/* 262 */         TimeZone tz = ctxt.getTimeZone();
/* 263 */         if (tz != null) {
/* 264 */           c.setTimeZone(tz);
/*     */         }
/* 266 */         return c;
/* 267 */       } catch (Exception e) {
/* 268 */         return (Calendar)ctxt.handleInstantiationProblem(handledType(), d, e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JacksonStdImpl
/*     */   public static class DateDeserializer
/*     */     extends DateBasedDeserializer<Date>
/*     */   {
/* 283 */     public static final DateDeserializer instance = new DateDeserializer();
/*     */     public DateDeserializer() {
/* 285 */       super(Date.class);
/*     */     } public DateDeserializer(DateDeserializer base, DateFormat df, String formatString) {
/* 287 */       super(base, df, formatString);
/*     */     }
/*     */ 
/*     */     
/*     */     protected DateDeserializer withDateFormat(DateFormat df, String formatString) {
/* 292 */       return new DateDeserializer(this, df, formatString);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getEmptyValue(DeserializationContext ctxt) {
/* 297 */       return new Date(0L);
/*     */     }
/*     */ 
/*     */     
/*     */     public Date deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 302 */       return _parseDate(p, ctxt);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class SqlDateDeserializer
/*     */     extends DateBasedDeserializer<Date>
/*     */   {
/*     */     public SqlDateDeserializer() {
/* 313 */       super(Date.class);
/*     */     } public SqlDateDeserializer(SqlDateDeserializer src, DateFormat df, String formatString) {
/* 315 */       super(src, df, formatString);
/*     */     }
/*     */ 
/*     */     
/*     */     protected SqlDateDeserializer withDateFormat(DateFormat df, String formatString) {
/* 320 */       return new SqlDateDeserializer(this, df, formatString);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getEmptyValue(DeserializationContext ctxt) {
/* 325 */       return new Date(0L);
/*     */     }
/*     */ 
/*     */     
/*     */     public Date deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 330 */       Date d = _parseDate(p, ctxt);
/* 331 */       return (d == null) ? null : new Date(d.getTime());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TimestampDeserializer
/*     */     extends DateBasedDeserializer<Timestamp>
/*     */   {
/*     */     public TimestampDeserializer() {
/* 344 */       super(Timestamp.class);
/*     */     } public TimestampDeserializer(TimestampDeserializer src, DateFormat df, String formatString) {
/* 346 */       super(src, df, formatString);
/*     */     }
/*     */ 
/*     */     
/*     */     protected TimestampDeserializer withDateFormat(DateFormat df, String formatString) {
/* 351 */       return new TimestampDeserializer(this, df, formatString);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getEmptyValue(DeserializationContext ctxt) {
/* 356 */       return new Timestamp(0L);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Timestamp deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 362 */       Date d = _parseDate(p, ctxt);
/* 363 */       return (d == null) ? null : new Timestamp(d.getTime());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\DateDeserializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */