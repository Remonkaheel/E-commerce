/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*     */ import com.fasterxml.jackson.databind.deser.UnresolvedForwardReference;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ReadableObjectId;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class CollectionDeserializer
/*     */   extends ContainerDeserializerBase<Collection<Object>>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = -1L;
/*     */   protected final JsonDeserializer<Object> _valueDeserializer;
/*     */   protected final TypeDeserializer _valueTypeDeserializer;
/*     */   protected final ValueInstantiator _valueInstantiator;
/*     */   protected final JsonDeserializer<Object> _delegateDeserializer;
/*     */   
/*     */   public CollectionDeserializer(JavaType collectionType, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser, ValueInstantiator valueInstantiator) {
/*  75 */     this(collectionType, valueDeser, valueTypeDeser, valueInstantiator, (JsonDeserializer<Object>)null, (NullValueProvider)null, (Boolean)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CollectionDeserializer(JavaType collectionType, JsonDeserializer<Object> valueDeser, TypeDeserializer valueTypeDeser, ValueInstantiator valueInstantiator, JsonDeserializer<Object> delegateDeser, NullValueProvider nuller, Boolean unwrapSingle) {
/*  88 */     super(collectionType, nuller, unwrapSingle);
/*  89 */     this._valueDeserializer = valueDeser;
/*  90 */     this._valueTypeDeserializer = valueTypeDeser;
/*  91 */     this._valueInstantiator = valueInstantiator;
/*  92 */     this._delegateDeserializer = delegateDeser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CollectionDeserializer(CollectionDeserializer src) {
/* 101 */     super(src);
/* 102 */     this._valueDeserializer = src._valueDeserializer;
/* 103 */     this._valueTypeDeserializer = src._valueTypeDeserializer;
/* 104 */     this._valueInstantiator = src._valueInstantiator;
/* 105 */     this._delegateDeserializer = src._delegateDeserializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CollectionDeserializer withResolved(JsonDeserializer<?> dd, JsonDeserializer<?> vd, TypeDeserializer vtd, NullValueProvider nuller, Boolean unwrapSingle) {
/* 118 */     return new CollectionDeserializer(this._containerType, (JsonDeserializer)vd, vtd, this._valueInstantiator, (JsonDeserializer)dd, nuller, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/* 128 */     return (this._valueDeserializer == null && this._valueTypeDeserializer == null && this._delegateDeserializer == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 136 */     return LogicalType.Collection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionDeserializer createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 155 */     JsonDeserializer<Object> delegateDeser = null;
/* 156 */     if (this._valueInstantiator != null) {
/* 157 */       if (this._valueInstantiator.canCreateUsingDelegate()) {
/* 158 */         JavaType delegateType = this._valueInstantiator.getDelegateType(ctxt.getConfig());
/* 159 */         if (delegateType == null) {
/* 160 */           ctxt.reportBadDefinition(this._containerType, String.format("Invalid delegate-creator definition for %s: value instantiator (%s) returned true for 'canCreateUsingDelegate()', but null for 'getDelegateType()'", new Object[] { this._containerType, this._valueInstantiator
/*     */ 
/*     */                   
/* 163 */                   .getClass().getName() }));
/*     */         }
/* 165 */         delegateDeser = findDeserializer(ctxt, delegateType, property);
/* 166 */       } else if (this._valueInstantiator.canCreateUsingArrayDelegate()) {
/* 167 */         JavaType delegateType = this._valueInstantiator.getArrayDelegateType(ctxt.getConfig());
/* 168 */         if (delegateType == null) {
/* 169 */           ctxt.reportBadDefinition(this._containerType, String.format("Invalid delegate-creator definition for %s: value instantiator (%s) returned true for 'canCreateUsingArrayDelegate()', but null for 'getArrayDelegateType()'", new Object[] { this._containerType, this._valueInstantiator
/*     */ 
/*     */                   
/* 172 */                   .getClass().getName() }));
/*     */         }
/* 174 */         delegateDeser = findDeserializer(ctxt, delegateType, property);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 180 */     Boolean unwrapSingle = findFormatFeature(ctxt, property, Collection.class, JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
/*     */ 
/*     */     
/* 183 */     JsonDeserializer<?> valueDeser = this._valueDeserializer;
/*     */ 
/*     */     
/* 186 */     valueDeser = findConvertingContentDeserializer(ctxt, property, valueDeser);
/* 187 */     JavaType vt = this._containerType.getContentType();
/* 188 */     if (valueDeser == null) {
/* 189 */       valueDeser = ctxt.findContextualValueDeserializer(vt, property);
/*     */     } else {
/* 191 */       valueDeser = ctxt.handleSecondaryContextualization(valueDeser, property, vt);
/*     */     } 
/*     */     
/* 194 */     TypeDeserializer valueTypeDeser = this._valueTypeDeserializer;
/* 195 */     if (valueTypeDeser != null) {
/* 196 */       valueTypeDeser = valueTypeDeser.forProperty(property);
/*     */     }
/* 198 */     NullValueProvider nuller = findContentNullProvider(ctxt, property, valueDeser);
/* 199 */     if (!Objects.equals(unwrapSingle, this._unwrapSingle) || nuller != this._nullProvider || delegateDeser != this._delegateDeserializer || valueDeser != this._valueDeserializer || valueTypeDeser != this._valueTypeDeserializer)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 205 */       return withResolved(delegateDeser, valueDeser, valueTypeDeser, nuller, unwrapSingle);
/*     */     }
/*     */     
/* 208 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<Object> getContentDeserializer() {
/* 219 */     return this._valueDeserializer;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueInstantiator getValueInstantiator() {
/* 224 */     return this._valueInstantiator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<Object> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 238 */     if (this._delegateDeserializer != null) {
/* 239 */       return (Collection<Object>)this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer
/* 240 */           .deserialize(p, ctxt));
/*     */     }
/*     */ 
/*     */     
/* 244 */     if (p.isExpectedStartArrayToken()) {
/* 245 */       return _deserializeFromArray(p, ctxt, createDefaultInstance(ctxt));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 250 */     if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 251 */       return _deserializeFromString(p, ctxt, p.getText());
/*     */     }
/* 253 */     return handleNonArray(p, ctxt, createDefaultInstance(ctxt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<Object> createDefaultInstance(DeserializationContext ctxt) throws IOException {
/* 263 */     return (Collection<Object>)this._valueInstantiator.createUsingDefault(ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<Object> deserialize(JsonParser p, DeserializationContext ctxt, Collection<Object> result) throws IOException {
/* 272 */     if (p.isExpectedStartArrayToken()) {
/* 273 */       return _deserializeFromArray(p, ctxt, result);
/*     */     }
/* 275 */     return handleNonArray(p, ctxt, result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 284 */     return typeDeserializer.deserializeTypedFromArray(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<Object> _deserializeFromString(JsonParser p, DeserializationContext ctxt, String value) throws IOException {
/* 297 */     Class<?> rawTargetType = handledType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 306 */     if (value.isEmpty()) {
/* 307 */       CoercionAction act = ctxt.findCoercionAction(logicalType(), rawTargetType, CoercionInputShape.EmptyString);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 312 */       if (act != null && act != CoercionAction.Fail) {
/* 313 */         return (Collection<Object>)_deserializeFromEmptyString(p, ctxt, act, rawTargetType, "empty String (\"\")");
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 321 */     else if (_isBlank(value)) {
/* 322 */       CoercionAction act = ctxt.findCoercionFromBlankString(logicalType(), rawTargetType, CoercionAction.Fail);
/*     */       
/* 324 */       if (act != CoercionAction.Fail) {
/* 325 */         return (Collection<Object>)_deserializeFromEmptyString(p, ctxt, act, rawTargetType, "blank String (all whitespace)");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 331 */     return handleNonArray(p, ctxt, createDefaultInstance(ctxt));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<Object> _deserializeFromArray(JsonParser p, DeserializationContext ctxt, Collection<Object> result) throws IOException {
/* 342 */     p.assignCurrentValue(result);
/*     */ 
/*     */     
/* 345 */     if (this._valueDeserializer.getObjectIdReader() != null) {
/* 346 */       return _deserializeWithObjectId(p, ctxt, result);
/*     */     }
/*     */     JsonToken t;
/* 349 */     while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/*     */       try {
/*     */         Object value;
/* 352 */         if (t == JsonToken.VALUE_NULL) {
/* 353 */           if (this._skipNullValues) {
/*     */             continue;
/*     */           }
/* 356 */           value = null;
/*     */         } else {
/* 358 */           value = _deserializeNoNullChecks(p, ctxt);
/*     */         } 
/*     */         
/* 361 */         if (value == null) {
/* 362 */           value = this._nullProvider.getNullValue(ctxt);
/*     */ 
/*     */           
/* 365 */           if (value == null) {
/* 366 */             _tryToAddNull(p, ctxt, result);
/*     */             
/*     */             continue;
/*     */           } 
/*     */         } 
/* 371 */         result.add(value);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 378 */       catch (Exception e) {
/* 379 */         boolean wrap = (ctxt == null || ctxt.isEnabled(DeserializationFeature.WRAP_EXCEPTIONS));
/* 380 */         if (!wrap) {
/* 381 */           ClassUtil.throwIfRTE(e);
/*     */         }
/* 383 */         throw JsonMappingException.wrapWithPath(e, result, result.size());
/*     */       } 
/*     */     } 
/* 386 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Collection<Object> handleNonArray(JsonParser p, DeserializationContext ctxt, Collection<Object> result) throws IOException {
/*     */     Object value;
/* 402 */     boolean canWrap = (this._unwrapSingle == Boolean.TRUE || (this._unwrapSingle == null && ctxt.isEnabled(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)));
/* 403 */     if (!canWrap) {
/* 404 */       return (Collection<Object>)ctxt.handleUnexpectedToken(this._containerType, p);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 410 */       if (p.hasToken(JsonToken.VALUE_NULL)) {
/*     */         
/* 412 */         if (this._skipNullValues) {
/* 413 */           return result;
/*     */         }
/* 415 */         value = null;
/*     */       } else {
/* 417 */         value = _deserializeNoNullChecks(p, ctxt);
/*     */       } 
/*     */       
/* 420 */       if (value == null) {
/* 421 */         value = this._nullProvider.getNullValue(ctxt);
/*     */ 
/*     */         
/* 424 */         if (value == null) {
/* 425 */           _tryToAddNull(p, ctxt, result);
/* 426 */           return result;
/*     */         } 
/*     */       } 
/* 429 */     } catch (Exception e) {
/* 430 */       boolean wrap = ctxt.isEnabled(DeserializationFeature.WRAP_EXCEPTIONS);
/* 431 */       if (!wrap) {
/* 432 */         ClassUtil.throwIfRTE(e);
/*     */       }
/*     */       
/* 435 */       throw JsonMappingException.wrapWithPath(e, Object.class, result.size());
/*     */     } 
/* 437 */     result.add(value);
/* 438 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<Object> _deserializeWithObjectId(JsonParser p, DeserializationContext ctxt, Collection<Object> result) throws IOException {
/* 446 */     if (!p.isExpectedStartArrayToken()) {
/* 447 */       return handleNonArray(p, ctxt, result);
/*     */     }
/*     */     
/* 450 */     p.assignCurrentValue(result);
/*     */ 
/*     */     
/* 453 */     CollectionReferringAccumulator referringAccumulator = new CollectionReferringAccumulator(this._containerType.getContentType().getRawClass(), result);
/*     */     
/*     */     JsonToken t;
/* 456 */     while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/*     */       try {
/*     */         Object value;
/*     */         
/* 460 */         if (t == JsonToken.VALUE_NULL) {
/* 461 */           if (this._skipNullValues) {
/*     */             continue;
/*     */           }
/* 464 */           value = null;
/*     */         } else {
/* 466 */           value = _deserializeNoNullChecks(p, ctxt);
/*     */         } 
/*     */         
/* 469 */         if (value == null) {
/* 470 */           value = this._nullProvider.getNullValue(ctxt);
/* 471 */           if (value == null && this._skipNullValues) {
/*     */             continue;
/*     */           }
/*     */         } 
/* 475 */         referringAccumulator.add(value);
/* 476 */       } catch (UnresolvedForwardReference reference) {
/* 477 */         ReadableObjectId.Referring ref = referringAccumulator.handleUnresolvedReference(reference);
/* 478 */         reference.getRoid().appendReferring(ref);
/* 479 */       } catch (Exception e) {
/* 480 */         boolean wrap = (ctxt == null || ctxt.isEnabled(DeserializationFeature.WRAP_EXCEPTIONS));
/* 481 */         if (!wrap) {
/* 482 */           ClassUtil.throwIfRTE(e);
/*     */         }
/* 484 */         throw JsonMappingException.wrapWithPath(e, result, result.size());
/*     */       } 
/*     */     } 
/* 487 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserializeNoNullChecks(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 500 */     if (this._valueTypeDeserializer == null) {
/* 501 */       return this._valueDeserializer.deserialize(p, ctxt);
/*     */     }
/* 503 */     return this._valueDeserializer.deserializeWithType(p, ctxt, this._valueTypeDeserializer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _tryToAddNull(JsonParser p, DeserializationContext ctxt, Collection<?> set) throws IOException {
/* 515 */     if (this._skipNullValues) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 522 */       set.add(null);
/* 523 */     } catch (NullPointerException e) {
/* 524 */       ctxt.handleUnexpectedToken(this._valueType, JsonToken.VALUE_NULL, p, "`java.util.Collection` of type %s does not accept `null` values", new Object[] {
/*     */             
/* 526 */             ClassUtil.getTypeDescription(getValueType(ctxt))
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class CollectionReferringAccumulator
/*     */   {
/*     */     private final Class<?> _elementType;
/*     */ 
/*     */     
/*     */     private final Collection<Object> _result;
/*     */     
/* 540 */     private List<CollectionDeserializer.CollectionReferring> _accumulator = new ArrayList<>();
/*     */     
/*     */     public CollectionReferringAccumulator(Class<?> elementType, Collection<Object> result) {
/* 543 */       this._elementType = elementType;
/* 544 */       this._result = result;
/*     */     }
/*     */ 
/*     */     
/*     */     public void add(Object value) {
/* 549 */       if (this._accumulator.isEmpty()) {
/* 550 */         this._result.add(value);
/*     */       } else {
/* 552 */         CollectionDeserializer.CollectionReferring ref = this._accumulator.get(this._accumulator.size() - 1);
/* 553 */         ref.next.add(value);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public ReadableObjectId.Referring handleUnresolvedReference(UnresolvedForwardReference reference) {
/* 559 */       CollectionDeserializer.CollectionReferring id = new CollectionDeserializer.CollectionReferring(this, reference, this._elementType);
/* 560 */       this._accumulator.add(id);
/* 561 */       return id;
/*     */     }
/*     */ 
/*     */     
/*     */     public void resolveForwardReference(Object id, Object value) throws IOException {
/* 566 */       Iterator<CollectionDeserializer.CollectionReferring> iterator = this._accumulator.iterator();
/*     */ 
/*     */ 
/*     */       
/* 570 */       Collection<Object> previous = this._result;
/* 571 */       while (iterator.hasNext()) {
/* 572 */         CollectionDeserializer.CollectionReferring ref = iterator.next();
/* 573 */         if (ref.hasId(id)) {
/* 574 */           iterator.remove();
/* 575 */           previous.add(value);
/* 576 */           previous.addAll(ref.next);
/*     */           return;
/*     */         } 
/* 579 */         previous = ref.next;
/*     */       } 
/*     */       
/* 582 */       throw new IllegalArgumentException("Trying to resolve a forward reference with id [" + id + "] that wasn't previously seen as unresolved.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class CollectionReferring
/*     */     extends ReadableObjectId.Referring
/*     */   {
/*     */     private final CollectionDeserializer.CollectionReferringAccumulator _parent;
/*     */ 
/*     */     
/* 594 */     public final List<Object> next = new ArrayList();
/*     */ 
/*     */ 
/*     */     
/*     */     CollectionReferring(CollectionDeserializer.CollectionReferringAccumulator parent, UnresolvedForwardReference reference, Class<?> contentType) {
/* 599 */       super(reference, contentType);
/* 600 */       this._parent = parent;
/*     */     }
/*     */ 
/*     */     
/*     */     public void handleResolvedForwardReference(Object id, Object value) throws IOException {
/* 605 */       this._parent.resolveForwardReference(id, value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\CollectionDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */