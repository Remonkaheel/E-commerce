/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.ResolvableDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.Converter;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StdDelegatingDeserializer<T>
/*     */   extends StdDeserializer<T>
/*     */   implements ContextualDeserializer, ResolvableDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final Converter<Object, T> _converter;
/*     */   protected final JavaType _delegateType;
/*     */   protected final JsonDeserializer<Object> _delegateDeserializer;
/*     */   
/*     */   public StdDelegatingDeserializer(Converter<?, T> converter) {
/*  71 */     super(Object.class);
/*  72 */     this._converter = (Converter)converter;
/*  73 */     this._delegateType = null;
/*  74 */     this._delegateDeserializer = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StdDelegatingDeserializer(Converter<Object, T> converter, JavaType delegateType, JsonDeserializer<?> delegateDeserializer) {
/*  81 */     super(delegateType);
/*  82 */     this._converter = converter;
/*  83 */     this._delegateType = delegateType;
/*  84 */     this._delegateDeserializer = (JsonDeserializer)delegateDeserializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StdDelegatingDeserializer(StdDelegatingDeserializer<T> src) {
/*  92 */     super(src);
/*  93 */     this._converter = src._converter;
/*  94 */     this._delegateType = src._delegateType;
/*  95 */     this._delegateDeserializer = src._delegateDeserializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StdDelegatingDeserializer<T> withDelegate(Converter<Object, T> converter, JavaType delegateType, JsonDeserializer<?> delegateDeserializer) {
/* 105 */     ClassUtil.verifyMustOverride(StdDelegatingDeserializer.class, this, "withDelegate");
/* 106 */     return new StdDelegatingDeserializer(converter, delegateType, delegateDeserializer);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonDeserializer<T> unwrappingDeserializer(NameTransformer unwrapper) {
/* 111 */     ClassUtil.verifyMustOverride(StdDelegatingDeserializer.class, this, "unwrappingDeserializer");
/* 112 */     return replaceDelegatee(this._delegateDeserializer.unwrappingDeserializer(unwrapper));
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonDeserializer<T> replaceDelegatee(JsonDeserializer<?> delegatee) {
/* 117 */     ClassUtil.verifyMustOverride(StdDelegatingDeserializer.class, this, "replaceDelegatee");
/* 118 */     if (delegatee == this._delegateDeserializer) {
/* 119 */       return this;
/*     */     }
/* 121 */     return new StdDelegatingDeserializer(this._converter, this._delegateType, delegatee);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resolve(DeserializationContext ctxt) throws JsonMappingException {
/* 136 */     if (this._delegateDeserializer != null && this._delegateDeserializer instanceof ResolvableDeserializer) {
/* 137 */       ((ResolvableDeserializer)this._delegateDeserializer).resolve(ctxt);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 146 */     if (this._delegateDeserializer != null) {
/* 147 */       JsonDeserializer<?> deser = ctxt.handleSecondaryContextualization(this._delegateDeserializer, property, this._delegateType);
/*     */       
/* 149 */       if (deser != this._delegateDeserializer) {
/* 150 */         return withDelegate(this._converter, this._delegateType, deser);
/*     */       }
/* 152 */       return this;
/*     */     } 
/*     */     
/* 155 */     JavaType delegateType = this._converter.getInputType(ctxt.getTypeFactory());
/* 156 */     return withDelegate(this._converter, delegateType, ctxt
/* 157 */         .findContextualValueDeserializer(delegateType, property));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 169 */     Object delegateValue = this._delegateDeserializer.deserialize(p, ctxt);
/* 170 */     if (delegateValue == null) {
/* 171 */       return null;
/*     */     }
/* 173 */     return convertValue(ctxt, delegateValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 191 */     Object delegateValue = this._delegateDeserializer.deserialize(p, ctxt);
/* 192 */     if (delegateValue == null) {
/* 193 */       return null;
/*     */     }
/* 195 */     return convertValue(ctxt, delegateValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T deserialize(JsonParser p, DeserializationContext ctxt, Object intoValue) throws IOException {
/* 203 */     if (this._delegateType.getRawClass().isAssignableFrom(intoValue.getClass())) {
/* 204 */       return (T)this._delegateDeserializer.deserialize(p, ctxt, intoValue);
/*     */     }
/* 206 */     return (T)_handleIncompatibleUpdateValue(p, ctxt, intoValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer, T intoValue) throws IOException, JacksonException {
/* 219 */     if (!this._delegateType.getRawClass().isAssignableFrom(intoValue.getClass())) {
/* 220 */       return _handleIncompatibleUpdateValue(p, ctxt, intoValue);
/*     */     }
/* 222 */     return this._delegateDeserializer.deserialize(p, ctxt, intoValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _handleIncompatibleUpdateValue(JsonParser p, DeserializationContext ctxt, Object intoValue) throws IOException {
/* 238 */     throw new UnsupportedOperationException(
/* 239 */         String.format("Cannot update object of type %s (using deserializer for type %s)", new Object[] {
/* 240 */             intoValue.getClass().getName(), this._delegateType
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> handledType() {
/* 251 */     return this._delegateDeserializer.handledType();
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 256 */     return this._delegateDeserializer.logicalType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/* 262 */     return (this._delegateDeserializer != null && this._delegateDeserializer.isCachable());
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> getDelegatee() {
/* 267 */     return this._delegateDeserializer;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<Object> getKnownPropertyNames() {
/* 272 */     return this._delegateDeserializer.getKnownPropertyNames();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getNullValue(DeserializationContext ctxt) throws JsonMappingException {
/* 283 */     return _convertIfNonNull(this._delegateDeserializer.getNullValue(ctxt));
/*     */   }
/*     */ 
/*     */   
/*     */   public AccessPattern getNullAccessPattern() {
/* 288 */     return this._delegateDeserializer.getNullAccessPattern();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getAbsentValue(DeserializationContext ctxt) throws JsonMappingException {
/* 293 */     return _convertIfNonNull(this._delegateDeserializer.getAbsentValue(ctxt));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/* 298 */     return _convertIfNonNull(this._delegateDeserializer.getEmptyValue(ctxt));
/*     */   }
/*     */ 
/*     */   
/*     */   public AccessPattern getEmptyAccessPattern() {
/* 303 */     return this._delegateDeserializer.getEmptyAccessPattern();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 314 */     return this._delegateDeserializer.supportsUpdate(config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected T convertValue(Object delegateValue) {
/* 339 */     return (T)this._converter.convert(delegateValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T convertValue(DeserializationContext ctxt, Object delegateValue) {
/* 358 */     return (T)this._converter.convert(ctxt, delegateValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected T _convertIfNonNull(Object delegateValue) {
/* 369 */     return (delegateValue == null) ? null : (T)this._converter
/* 370 */       .convert(delegateValue);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\StdDelegatingDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */