/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.deser.std.JsonLocationInstantiator;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ public abstract class JDKValueInstantiators
/*     */ {
/*     */   public static ValueInstantiator findStdValueInstantiator(DeserializationConfig config, Class<?> raw) {
/*  25 */     if (raw == JsonLocation.class) {
/*  26 */       return (ValueInstantiator)new JsonLocationInstantiator();
/*     */     }
/*     */ 
/*     */     
/*  30 */     if (Collection.class.isAssignableFrom(raw)) {
/*  31 */       if (raw == ArrayList.class) {
/*  32 */         return (ValueInstantiator)ArrayListInstantiator.INSTANCE;
/*     */       }
/*  34 */       if (raw == HashSet.class) {
/*  35 */         return (ValueInstantiator)HashSetInstantiator.INSTANCE;
/*     */       }
/*  37 */       if (raw == LinkedList.class) {
/*  38 */         return (ValueInstantiator)new LinkedListInstantiator();
/*     */       }
/*  40 */       if (raw == TreeSet.class) {
/*  41 */         return (ValueInstantiator)new TreeSetInstantiator();
/*     */       }
/*  43 */       if (raw == Collections.emptySet().getClass()) {
/*  44 */         return (ValueInstantiator)new ConstantValueInstantiator(Collections.emptySet());
/*     */       }
/*  46 */       if (raw == Collections.emptyList().getClass()) {
/*  47 */         return (ValueInstantiator)new ConstantValueInstantiator(Collections.emptyList());
/*     */       }
/*  49 */     } else if (Map.class.isAssignableFrom(raw)) {
/*  50 */       if (raw == LinkedHashMap.class) {
/*  51 */         return (ValueInstantiator)LinkedHashMapInstantiator.INSTANCE;
/*     */       }
/*  53 */       if (raw == HashMap.class) {
/*  54 */         return (ValueInstantiator)HashMapInstantiator.INSTANCE;
/*     */       }
/*  56 */       if (raw == ConcurrentHashMap.class) {
/*  57 */         return (ValueInstantiator)new ConcurrentHashMapInstantiator();
/*     */       }
/*  59 */       if (raw == TreeMap.class) {
/*  60 */         return (ValueInstantiator)new TreeMapInstantiator();
/*     */       }
/*  62 */       if (raw == Collections.emptyMap().getClass()) {
/*  63 */         return (ValueInstantiator)new ConstantValueInstantiator(Collections.emptyMap());
/*     */       }
/*     */     } 
/*  66 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static abstract class JDKValueInstantiator
/*     */     extends ValueInstantiator.Base
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     
/*     */     public JDKValueInstantiator(Class<?> type) {
/*  77 */       super(type);
/*     */     }
/*     */     
/*     */     public final boolean canInstantiate() {
/*  81 */       return true;
/*     */     }
/*     */     public final boolean canCreateUsingDefault() {
/*  84 */       return true;
/*     */     }
/*     */ 
/*     */     
/*     */     public abstract Object createUsingDefault(DeserializationContext param1DeserializationContext) throws IOException;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ArrayListInstantiator
/*     */     extends JDKValueInstantiator
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*  96 */     static final ArrayListInstantiator INSTANCE = new ArrayListInstantiator();
/*     */     
/*     */     public ArrayListInstantiator() {
/*  99 */       super(ArrayList.class);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException {
/* 104 */       return new ArrayList();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class LinkedListInstantiator
/*     */     extends JDKValueInstantiator
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     
/*     */     public LinkedListInstantiator() {
/* 115 */       super(LinkedList.class);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException {
/* 120 */       return new LinkedList();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class HashSetInstantiator
/*     */     extends JDKValueInstantiator
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     
/* 130 */     static final HashSetInstantiator INSTANCE = new HashSetInstantiator();
/*     */     
/*     */     public HashSetInstantiator() {
/* 133 */       super(HashSet.class);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException {
/* 138 */       return new HashSet();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class TreeSetInstantiator
/*     */     extends JDKValueInstantiator
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     
/*     */     public TreeSetInstantiator() {
/* 149 */       super(TreeSet.class);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException {
/* 154 */       return new TreeSet();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ConcurrentHashMapInstantiator
/*     */     extends JDKValueInstantiator
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     
/*     */     public ConcurrentHashMapInstantiator() {
/* 165 */       super(ConcurrentHashMap.class);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException {
/* 170 */       return new ConcurrentHashMap<>();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class HashMapInstantiator
/*     */     extends JDKValueInstantiator
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/* 179 */     static final HashMapInstantiator INSTANCE = new HashMapInstantiator();
/*     */     
/*     */     public HashMapInstantiator() {
/* 182 */       super(HashMap.class);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException {
/* 187 */       return new HashMap<>();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class LinkedHashMapInstantiator
/*     */     extends JDKValueInstantiator
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/* 196 */     static final LinkedHashMapInstantiator INSTANCE = new LinkedHashMapInstantiator();
/*     */     
/*     */     public LinkedHashMapInstantiator() {
/* 199 */       super(LinkedHashMap.class);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException {
/* 204 */       return new LinkedHashMap<>();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class TreeMapInstantiator
/*     */     extends JDKValueInstantiator
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     
/*     */     public TreeMapInstantiator() {
/* 215 */       super(TreeMap.class);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object createUsingDefault(DeserializationContext ctxt) throws IOException {
/* 220 */       return new TreeMap<>();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static class ConstantValueInstantiator
/*     */     extends JDKValueInstantiator
/*     */   {
/*     */     private static final long serialVersionUID = 2L;
/*     */     protected final Object _value;
/*     */     
/*     */     public ConstantValueInstantiator(Object value) {
/* 232 */       super(value.getClass());
/* 233 */       this._value = value;
/*     */     }
/*     */ 
/*     */     
/*     */     public final Object createUsingDefault(DeserializationContext ctxt) throws IOException {
/* 238 */       return this._value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\impl\JDKValueInstantiators.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */