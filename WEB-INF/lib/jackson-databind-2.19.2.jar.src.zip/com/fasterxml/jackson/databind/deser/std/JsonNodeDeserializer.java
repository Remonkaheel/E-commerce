/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.node.ArrayNode;
/*     */ import com.fasterxml.jackson.databind.node.ContainerNode;
/*     */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*     */ import com.fasterxml.jackson.databind.node.ObjectNode;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonNodeDeserializer
/*     */   extends BaseNodeDeserializer<JsonNode>
/*     */ {
/*  32 */   private static final JsonNodeDeserializer instance = new JsonNodeDeserializer();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonNodeDeserializer() {
/*  38 */     super(JsonNode.class, null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JsonNodeDeserializer(JsonNodeDeserializer base, boolean mergeArrays, boolean mergeObjects) {
/*  43 */     super(base, mergeArrays, mergeObjects);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<?> _createWithMerge(boolean mergeArrays, boolean mergeObjects) {
/*  49 */     return new JsonNodeDeserializer(this, mergeArrays, mergeObjects);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonDeserializer<? extends JsonNode> getDeserializer(Class<?> nodeClass) {
/*  57 */     if (nodeClass == ObjectNode.class) {
/*  58 */       return ObjectDeserializer.getInstance();
/*     */     }
/*  60 */     if (nodeClass == ArrayNode.class) {
/*  61 */       return ArrayDeserializer.getInstance();
/*     */     }
/*     */     
/*  64 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonNode getNullValue(DeserializationContext ctxt) {
/*  75 */     return (JsonNode)ctxt.getNodeFactory().nullNode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getAbsentValue(DeserializationContext ctxt) {
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonNode deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  95 */     BaseNodeDeserializer.ContainerStack stack = new BaseNodeDeserializer.ContainerStack();
/*  96 */     JsonNodeFactory nodeF = ctxt.getNodeFactory();
/*  97 */     switch (p.currentTokenId()) {
/*     */       case 1:
/*  99 */         return (JsonNode)_deserializeContainerNoRecursion(p, ctxt, nodeF, stack, (ContainerNode<?>)nodeF.objectNode());
/*     */       case 2:
/* 101 */         return (JsonNode)nodeF.objectNode();
/*     */       case 3:
/* 103 */         return (JsonNode)_deserializeContainerNoRecursion(p, ctxt, nodeF, stack, (ContainerNode<?>)nodeF.arrayNode());
/*     */       case 5:
/* 105 */         return (JsonNode)_deserializeObjectAtName(p, ctxt, nodeF, stack);
/*     */     } 
/*     */     
/* 108 */     return _deserializeAnyScalar(p, ctxt);
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 113 */     return this._supportsUpdates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ObjectDeserializer
/*     */     extends BaseNodeDeserializer<ObjectNode>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     protected static final ObjectDeserializer _instance = new ObjectDeserializer();
/*     */     protected ObjectDeserializer() {
/* 132 */       super(ObjectNode.class, Boolean.valueOf(true));
/*     */     } public static ObjectDeserializer getInstance() {
/* 134 */       return _instance;
/*     */     }
/*     */     
/*     */     protected ObjectDeserializer(ObjectDeserializer base, boolean mergeArrays, boolean mergeObjects) {
/* 138 */       super(base, mergeArrays, mergeObjects);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected JsonDeserializer<?> _createWithMerge(boolean mergeArrays, boolean mergeObjects) {
/* 144 */       return new ObjectDeserializer(this, mergeArrays, mergeObjects);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ObjectNode deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 150 */       JsonNodeFactory nodeF = ctxt.getNodeFactory();
/* 151 */       if (p.isExpectedStartObjectToken()) {
/* 152 */         ObjectNode root = nodeF.objectNode();
/* 153 */         _deserializeContainerNoRecursion(p, ctxt, nodeF, new BaseNodeDeserializer.ContainerStack(), (ContainerNode<?>)root);
/* 154 */         return root;
/*     */       } 
/* 156 */       if (p.hasToken(JsonToken.FIELD_NAME)) {
/* 157 */         return _deserializeObjectAtName(p, ctxt, nodeF, new BaseNodeDeserializer.ContainerStack());
/*     */       }
/*     */ 
/*     */       
/* 161 */       if (p.hasToken(JsonToken.END_OBJECT)) {
/* 162 */         return nodeF.objectNode();
/*     */       }
/* 164 */       return (ObjectNode)ctxt.handleUnexpectedToken(ObjectNode.class, p);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ObjectNode deserialize(JsonParser p, DeserializationContext ctxt, ObjectNode node) throws IOException {
/* 176 */       if (p.isExpectedStartObjectToken() || p.hasToken(JsonToken.FIELD_NAME)) {
/* 177 */         return (ObjectNode)updateObject(p, ctxt, node, new BaseNodeDeserializer.ContainerStack());
/*     */       }
/*     */       
/* 180 */       return (ObjectNode)ctxt.handleUnexpectedToken(ObjectNode.class, p);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ArrayDeserializer
/*     */     extends BaseNodeDeserializer<ArrayNode>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/* 192 */     protected static final ArrayDeserializer _instance = new ArrayDeserializer();
/*     */     protected ArrayDeserializer() {
/* 194 */       super(ArrayNode.class, Boolean.valueOf(true));
/*     */     } public static ArrayDeserializer getInstance() {
/* 196 */       return _instance;
/*     */     }
/*     */     
/*     */     protected ArrayDeserializer(ArrayDeserializer base, boolean mergeArrays, boolean mergeObjects) {
/* 200 */       super(base, mergeArrays, mergeObjects);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected JsonDeserializer<?> _createWithMerge(boolean mergeArrays, boolean mergeObjects) {
/* 206 */       return new ArrayDeserializer(this, mergeArrays, mergeObjects);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public ArrayNode deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 212 */       if (p.isExpectedStartArrayToken()) {
/* 213 */         JsonNodeFactory nodeF = ctxt.getNodeFactory();
/* 214 */         ArrayNode arrayNode = nodeF.arrayNode();
/* 215 */         _deserializeContainerNoRecursion(p, ctxt, nodeF, new BaseNodeDeserializer.ContainerStack(), (ContainerNode<?>)arrayNode);
/*     */         
/* 217 */         return arrayNode;
/*     */       } 
/* 219 */       return (ArrayNode)ctxt.handleUnexpectedToken(ArrayNode.class, p);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ArrayNode deserialize(JsonParser p, DeserializationContext ctxt, ArrayNode arrayNode) throws IOException {
/* 229 */       if (p.isExpectedStartArrayToken()) {
/* 230 */         _deserializeContainerNoRecursion(p, ctxt, ctxt.getNodeFactory(), new BaseNodeDeserializer.ContainerStack(), (ContainerNode<?>)arrayNode);
/*     */         
/* 232 */         return arrayNode;
/*     */       } 
/* 234 */       return (ArrayNode)ctxt.handleUnexpectedToken(ArrayNode.class, p);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\JsonNodeDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */