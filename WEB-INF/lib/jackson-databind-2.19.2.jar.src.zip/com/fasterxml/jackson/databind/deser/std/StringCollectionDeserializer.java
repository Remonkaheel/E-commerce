/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedWithParams;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public final class StringCollectionDeserializer
/*     */   extends ContainerDeserializerBase<Collection<String>>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final JsonDeserializer<String> _valueDeserializer;
/*     */   private final ValueInstantiator _valueInstantiator;
/*     */   private final JsonDeserializer<Object> _delegateDeserializer;
/*     */   
/*     */   public StringCollectionDeserializer(JavaType collectionType, JsonDeserializer<?> valueDeser, ValueInstantiator valueInstantiator) {
/*  66 */     this(collectionType, valueInstantiator, (JsonDeserializer<?>)null, valueDeser, (NullValueProvider)valueDeser, (Boolean)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StringCollectionDeserializer(JavaType collectionType, ValueInstantiator valueInstantiator, JsonDeserializer<?> delegateDeser, JsonDeserializer<?> valueDeser, NullValueProvider nuller, Boolean unwrapSingle) {
/*  75 */     super(collectionType, nuller, unwrapSingle);
/*  76 */     this._valueDeserializer = (JsonDeserializer)valueDeser;
/*  77 */     this._valueInstantiator = valueInstantiator;
/*  78 */     this._delegateDeserializer = (JsonDeserializer)delegateDeser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StringCollectionDeserializer withResolved(JsonDeserializer<?> delegateDeser, JsonDeserializer<?> valueDeser, NullValueProvider nuller, Boolean unwrapSingle) {
/*  85 */     if (Objects.equals(this._unwrapSingle, unwrapSingle) && this._nullProvider == nuller && this._valueDeserializer == valueDeser && this._delegateDeserializer == delegateDeser)
/*     */     {
/*  87 */       return this;
/*     */     }
/*  89 */     return new StringCollectionDeserializer(this._containerType, this._valueInstantiator, delegateDeser, valueDeser, nuller, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/*  97 */     return (this._valueDeserializer == null && this._delegateDeserializer == null);
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 102 */     return LogicalType.Collection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 116 */     JsonDeserializer<Object> delegate = null;
/* 117 */     if (this._valueInstantiator != null) {
/*     */       
/* 119 */       AnnotatedWithParams delegateCreator = this._valueInstantiator.getArrayDelegateCreator();
/* 120 */       if (delegateCreator != null) {
/* 121 */         JavaType delegateType = this._valueInstantiator.getArrayDelegateType(ctxt.getConfig());
/* 122 */         delegate = findDeserializer(ctxt, delegateType, property);
/* 123 */       } else if ((delegateCreator = this._valueInstantiator.getDelegateCreator()) != null) {
/* 124 */         JavaType delegateType = this._valueInstantiator.getDelegateType(ctxt.getConfig());
/* 125 */         delegate = findDeserializer(ctxt, delegateType, property);
/*     */       } 
/*     */     } 
/* 128 */     JsonDeserializer<?> valueDeser = this._valueDeserializer;
/* 129 */     JavaType valueType = this._containerType.getContentType();
/* 130 */     if (valueDeser == null) {
/*     */       
/* 132 */       valueDeser = findConvertingContentDeserializer(ctxt, property, valueDeser);
/* 133 */       if (valueDeser == null)
/*     */       {
/* 135 */         valueDeser = ctxt.findContextualValueDeserializer(valueType, property);
/*     */       }
/*     */     } else {
/* 138 */       valueDeser = ctxt.handleSecondaryContextualization(valueDeser, property, valueType);
/*     */     } 
/*     */ 
/*     */     
/* 142 */     Boolean unwrapSingle = findFormatFeature(ctxt, property, Collection.class, JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
/*     */     
/* 144 */     NullValueProvider nuller = findContentNullProvider(ctxt, property, valueDeser);
/* 145 */     if (isDefaultDeserializer(valueDeser)) {
/* 146 */       valueDeser = null;
/*     */     }
/* 148 */     return withResolved(delegate, valueDeser, nuller, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<Object> getContentDeserializer() {
/* 160 */     JsonDeserializer<?> deser = this._valueDeserializer;
/* 161 */     return (JsonDeserializer)deser;
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueInstantiator getValueInstantiator() {
/* 166 */     return this._valueInstantiator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 179 */     if (this._delegateDeserializer != null) {
/* 180 */       return castToCollection(this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer
/* 181 */             .deserialize(p, ctxt)));
/*     */     }
/* 183 */     Collection<String> result = castToCollection(this._valueInstantiator.createUsingDefault(ctxt));
/* 184 */     return deserialize(p, ctxt, result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> deserialize(JsonParser p, DeserializationContext ctxt, Collection<String> result) throws IOException {
/* 193 */     if (!p.isExpectedStartArrayToken()) {
/* 194 */       return handleNonArray(p, ctxt, result);
/*     */     }
/*     */     
/* 197 */     if (this._valueDeserializer != null) {
/* 198 */       return deserializeUsingCustom(p, ctxt, result, this._valueDeserializer);
/*     */     }
/*     */     
/*     */     try {
/*     */       while (true) {
/* 203 */         String value = p.nextTextValue();
/* 204 */         if (value != null) {
/* 205 */           result.add(value);
/*     */           continue;
/*     */         } 
/* 208 */         JsonToken t = p.currentToken();
/* 209 */         if (t == JsonToken.END_ARRAY) {
/*     */           break;
/*     */         }
/* 212 */         if (t == JsonToken.VALUE_NULL) {
/* 213 */           if (this._skipNullValues) {
/*     */             continue;
/*     */           }
/*     */         } else {
/* 217 */           value = _parseString(p, ctxt, this._nullProvider);
/*     */         } 
/*     */         
/* 220 */         if (value == null) {
/* 221 */           value = (String)this._nullProvider.getNullValue(ctxt);
/*     */           
/* 223 */           if (value == null && this._skipNullValues) {
/*     */             continue;
/*     */           }
/*     */         } 
/*     */         
/* 228 */         result.add(value);
/*     */       } 
/* 230 */     } catch (Exception e) {
/* 231 */       throw JsonMappingException.wrapWithPath(e, result, result.size());
/*     */     } 
/* 233 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<String> deserializeUsingCustom(JsonParser p, DeserializationContext ctxt, Collection<String> result, JsonDeserializer<String> deser) throws IOException {
/*     */     try {
/*     */       while (true) {
/*     */         String value;
/* 247 */         if (p.nextTextValue() == null) {
/* 248 */           JsonToken t = p.currentToken();
/* 249 */           if (t == JsonToken.END_ARRAY) {
/*     */             break;
/*     */           }
/*     */           
/* 253 */           if (t == JsonToken.VALUE_NULL) {
/* 254 */             if (this._skipNullValues) {
/*     */               continue;
/*     */             }
/* 257 */             value = null;
/*     */           } else {
/* 259 */             value = (String)deser.deserialize(p, ctxt);
/*     */           } 
/*     */         } else {
/* 262 */           value = (String)deser.deserialize(p, ctxt);
/*     */         } 
/*     */         
/* 265 */         if (value == null) {
/* 266 */           value = (String)this._nullProvider.getNullValue(ctxt);
/*     */           
/* 268 */           if (value == null && this._skipNullValues) {
/*     */             continue;
/*     */           }
/*     */         } 
/*     */         
/* 273 */         result.add(value);
/*     */       } 
/* 275 */     } catch (Exception e) {
/* 276 */       throw JsonMappingException.wrapWithPath(e, result, result.size());
/*     */     } 
/* 278 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 285 */     return typeDeserializer.deserializeTypedFromArray(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Collection<String> handleNonArray(JsonParser p, DeserializationContext ctxt, Collection<String> result) throws IOException {
/*     */     String value;
/* 299 */     boolean canWrap = (this._unwrapSingle == Boolean.TRUE || (this._unwrapSingle == null && ctxt.isEnabled(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)));
/* 300 */     if (!canWrap) {
/* 301 */       if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 302 */         return _deserializeFromString(p, ctxt);
/*     */       }
/* 304 */       return castToCollection(ctxt.handleUnexpectedToken(this._containerType, p));
/*     */     } 
/*     */     
/* 307 */     JsonDeserializer<String> valueDes = this._valueDeserializer;
/* 308 */     JsonToken t = p.currentToken();
/*     */ 
/*     */ 
/*     */     
/* 312 */     if (t == JsonToken.VALUE_NULL) {
/*     */       
/* 314 */       if (this._skipNullValues) {
/* 315 */         return result;
/*     */       }
/* 317 */       value = null;
/*     */     } else {
/* 319 */       if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 320 */         String textValue = p.getText();
/*     */         
/* 322 */         if (textValue.isEmpty()) {
/* 323 */           CoercionAction act = ctxt.findCoercionAction(logicalType(), handledType(), CoercionInputShape.EmptyString);
/*     */           
/* 325 */           if (act != CoercionAction.Fail) {
/* 326 */             return castToCollection(_deserializeFromEmptyString(p, ctxt, act, handledType(), "empty String (\"\")"));
/*     */           }
/*     */         }
/* 329 */         else if (_isBlank(textValue)) {
/* 330 */           CoercionAction act = ctxt.findCoercionFromBlankString(logicalType(), handledType(), CoercionAction.Fail);
/*     */           
/* 332 */           if (act != CoercionAction.Fail) {
/* 333 */             return castToCollection(_deserializeFromEmptyString(p, ctxt, act, handledType(), "blank String (all whitespace)"));
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 341 */         value = (valueDes == null) ? _parseString(p, ctxt, this._nullProvider) : (String)valueDes.deserialize(p, ctxt);
/* 342 */       } catch (Exception e) {
/* 343 */         throw JsonMappingException.wrapWithPath(e, result, result.size());
/*     */       } 
/*     */     } 
/*     */     
/* 347 */     if (value == null) {
/* 348 */       value = (String)this._nullProvider.getNullValue(ctxt);
/*     */       
/* 350 */       if (value == null && this._skipNullValues) {
/* 351 */         return result;
/*     */       }
/*     */     } 
/*     */     
/* 355 */     result.add(value);
/* 356 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Collection<String> castToCollection(Object o) {
/* 366 */     if (o != null) {
/*     */ 
/*     */       
/* 369 */       if (o.getClass() == ArrayList.class) {
/* 370 */         return (ArrayList)o;
/*     */       }
/* 372 */       if (o.getClass() == HashSet.class) {
/* 373 */         return (HashSet)o;
/*     */       }
/*     */     } 
/* 376 */     return (Collection<String>)o;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\StringCollectionDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */