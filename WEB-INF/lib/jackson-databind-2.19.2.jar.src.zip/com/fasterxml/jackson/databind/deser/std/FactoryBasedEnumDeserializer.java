/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.deser.impl.PropertyBasedCreator;
/*     */ import com.fasterxml.jackson.databind.deser.impl.PropertyValueBuffer;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.EnumResolver;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FactoryBasedEnumDeserializer
/*     */   extends StdDeserializer<Object>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JavaType _inputType;
/*     */   protected final AnnotatedMethod _factory;
/*     */   protected final JsonDeserializer<?> _deser;
/*     */   protected final ValueInstantiator _valueInstantiator;
/*     */   protected final SettableBeanProperty[] _creatorProps;
/*     */   protected final Enum<?> _defaultValue;
/*     */   protected final boolean _hasArgs;
/*     */   private volatile transient PropertyBasedCreator _propCreator;
/*     */   
/*     */   @Deprecated
/*     */   public FactoryBasedEnumDeserializer(Class<?> cls, AnnotatedMethod f, JavaType paramType, ValueInstantiator valueInstantiator, SettableBeanProperty[] creatorProps) {
/*  59 */     this(cls, f, paramType, valueInstantiator, creatorProps, (EnumResolver)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FactoryBasedEnumDeserializer(Class<?> cls, AnnotatedMethod f, JavaType paramType, ValueInstantiator valueInstantiator, SettableBeanProperty[] creatorProps, EnumResolver enumResolver) {
/*  69 */     super(cls);
/*  70 */     this._factory = f;
/*  71 */     this._hasArgs = true;
/*     */     
/*  73 */     this._inputType = (paramType.hasRawClass(String.class) || paramType.hasRawClass(CharSequence.class)) ? null : paramType;
/*     */     
/*  75 */     this._deser = null;
/*  76 */     this._valueInstantiator = valueInstantiator;
/*  77 */     this._creatorProps = creatorProps;
/*  78 */     this._defaultValue = (enumResolver == null) ? null : enumResolver.getDefaultValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FactoryBasedEnumDeserializer(Class<?> cls, AnnotatedMethod f) {
/*  86 */     super(cls);
/*  87 */     this._factory = f;
/*  88 */     this._hasArgs = false;
/*  89 */     this._inputType = null;
/*  90 */     this._deser = null;
/*  91 */     this._valueInstantiator = null;
/*  92 */     this._creatorProps = null;
/*  93 */     this._defaultValue = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected FactoryBasedEnumDeserializer(FactoryBasedEnumDeserializer base, JsonDeserializer<?> deser) {
/*  98 */     super(base._valueClass);
/*  99 */     this._inputType = base._inputType;
/* 100 */     this._factory = base._factory;
/* 101 */     this._hasArgs = base._hasArgs;
/* 102 */     this._valueInstantiator = base._valueInstantiator;
/* 103 */     this._creatorProps = base._creatorProps;
/* 104 */     this._defaultValue = base._defaultValue;
/*     */     
/* 106 */     this._deser = deser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 117 */     if (this._deser == null && this._inputType != null && this._creatorProps == null) {
/* 118 */       return new FactoryBasedEnumDeserializer(this, ctxt
/* 119 */           .findContextualValueDeserializer(this._inputType, property));
/*     */     }
/* 121 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 126 */     return Boolean.FALSE;
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 131 */     return LogicalType.Enum;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/* 136 */     return true;
/*     */   }
/*     */   public ValueInstantiator getValueInstantiator() {
/* 139 */     return this._valueInstantiator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*     */     Object value;
/* 148 */     if (this._deser != null) {
/* 149 */       value = this._deser.deserialize(p, ctxt);
/*     */     
/*     */     }
/* 152 */     else if (this._hasArgs) {
/*     */ 
/*     */       
/* 155 */       if (this._creatorProps != null) {
/* 156 */         if (p.isExpectedStartObjectToken()) {
/* 157 */           PropertyBasedCreator pc = this._propCreator;
/* 158 */           if (pc == null) {
/* 159 */             this._propCreator = pc = PropertyBasedCreator.construct(ctxt, this._valueInstantiator, this._creatorProps, ctxt
/*     */                 
/* 161 */                 .isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES));
/*     */           }
/* 163 */           p.nextToken();
/* 164 */           return deserializeEnumUsingPropertyBased(p, ctxt, pc);
/*     */         } 
/*     */         
/* 167 */         if (!this._valueInstantiator.canCreateFromString()) {
/* 168 */           JavaType targetType = getValueType(ctxt);
/* 169 */           JsonToken jsonToken = p.currentToken();
/* 170 */           return ctxt.reportInputMismatch(targetType, "Input mismatch reading Enum %s: properties-based `@JsonCreator` (%s) expects Object Value, got %s (`JsonToken.%s`)", new Object[] {
/*     */                 
/* 172 */                 ClassUtil.getTypeDescription(targetType), this._factory, 
/* 173 */                 JsonToken.valueDescFor(jsonToken), jsonToken.name()
/*     */               });
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 183 */       JsonToken t = p.currentToken();
/*     */       
/* 185 */       boolean unwrapping = (t == JsonToken.START_ARRAY && ctxt.isEnabled(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS));
/* 186 */       if (unwrapping) {
/* 187 */         t = p.nextToken();
/*     */       }
/*     */ 
/*     */       
/* 191 */       if (t == JsonToken.START_OBJECT)
/* 192 */       { value = ctxt.extractScalarFromObject(p, this, this._valueClass); }
/* 193 */       else { if (t == null || !t.isScalarValue()) {
/*     */ 
/*     */           
/* 196 */           JavaType targetType = getValueType(ctxt);
/* 197 */           return ctxt.reportInputMismatch(targetType, "Input mismatch reading Enum %s: properties-based `@JsonCreator` (%s) expects String Value, got %s (`JsonToken.%s`)", new Object[] {
/*     */                 
/* 199 */                 ClassUtil.getTypeDescription(targetType), this._factory, 
/* 200 */                 JsonToken.valueDescFor(t), t.name() });
/*     */         } 
/* 202 */         value = p.getValueAsString(); }
/*     */       
/* 204 */       if (unwrapping && 
/* 205 */         p.nextToken() != JsonToken.END_ARRAY) {
/* 206 */         handleMissingEndArrayForSingle(p, ctxt);
/*     */       }
/*     */     } else {
/*     */       
/* 210 */       p.skipChildren();
/*     */       try {
/* 212 */         return this._factory.call();
/* 213 */       } catch (Exception e) {
/* 214 */         Throwable t = ClassUtil.throwRootCauseIfIOE(e);
/* 215 */         return ctxt.handleInstantiationProblem(this._valueClass, null, t);
/*     */       } 
/*     */     } 
/*     */     try {
/* 219 */       return this._factory.callOnWith(this._valueClass, new Object[] { value });
/* 220 */     } catch (Exception e) {
/* 221 */       Throwable t = ClassUtil.throwRootCauseIfIOE(e);
/* 222 */       if (t instanceof IllegalArgumentException) {
/*     */         
/* 224 */         if (ctxt.isEnabled(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_USING_DEFAULT_VALUE))
/*     */         {
/* 226 */           if (this._defaultValue != null) {
/* 227 */             return this._defaultValue;
/*     */           }
/*     */         }
/*     */         
/* 231 */         if (ctxt.isEnabled(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL)) {
/* 232 */           return null;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 237 */       return ctxt.handleInstantiationProblem(this._valueClass, value, t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 246 */     return typeDeserializer.deserializeTypedFromAny(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object deserializeEnumUsingPropertyBased(JsonParser p, DeserializationContext ctxt, PropertyBasedCreator creator) throws IOException {
/* 253 */     PropertyValueBuffer buffer = creator.startBuilding(p, ctxt, null);
/*     */     
/* 255 */     JsonToken t = p.currentToken();
/* 256 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/* 257 */       String propName = p.currentName();
/* 258 */       p.nextToken();
/*     */       
/* 260 */       SettableBeanProperty creatorProp = creator.findCreatorProperty(propName);
/* 261 */       if (!buffer.readIdProperty(propName) || creatorProp != null)
/*     */       {
/*     */         
/* 264 */         if (creatorProp != null) {
/* 265 */           buffer.assignParameter(creatorProp, _deserializeWithErrorWrapping(p, ctxt, creatorProp));
/*     */         }
/*     */         else {
/*     */           
/* 269 */           p.skipChildren();
/*     */         }  } 
/* 271 */     }  return creator.build(ctxt, buffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Object _deserializeWithErrorWrapping(JsonParser p, DeserializationContext ctxt, SettableBeanProperty prop) throws IOException {
/*     */     try {
/* 280 */       return prop.deserialize(p, ctxt);
/* 281 */     } catch (Exception e) {
/* 282 */       return wrapAndThrow(e, handledType(), prop.getName(), ctxt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object wrapAndThrow(Throwable t, Object bean, String fieldName, DeserializationContext ctxt) throws IOException {
/* 289 */     throw JsonMappingException.wrapWithPath(throwOrReturnThrowable(t, ctxt), bean, fieldName);
/*     */   }
/*     */ 
/*     */   
/*     */   private Throwable throwOrReturnThrowable(Throwable t, DeserializationContext ctxt) throws IOException {
/* 294 */     t = ClassUtil.getRootCause(t);
/*     */     
/* 296 */     ClassUtil.throwIfError(t);
/* 297 */     boolean wrap = (ctxt == null || ctxt.isEnabled(DeserializationFeature.WRAP_EXCEPTIONS));
/*     */     
/* 299 */     if (t instanceof IOException) {
/* 300 */       if (!wrap || !(t instanceof com.fasterxml.jackson.core.JacksonException)) {
/* 301 */         throw (IOException)t;
/*     */       }
/* 303 */     } else if (!wrap) {
/* 304 */       ClassUtil.throwIfRTE(t);
/*     */     } 
/* 306 */     return t;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\FactoryBasedEnumDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */