/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.deser.SettableAnyProperty;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PropertyBasedCreator
/*     */ {
/*     */   protected final int _propertyCount;
/*     */   protected final ValueInstantiator _valueInstantiator;
/*     */   protected final HashMap<String, SettableBeanProperty> _propertyLookup;
/*     */   protected final SettableBeanProperty[] _allProperties;
/*     */   
/*     */   protected PropertyBasedCreator(DeserializationContext ctxt, ValueInstantiator valueInstantiator, SettableBeanProperty[] creatorProps, boolean caseInsensitive, boolean addAliases) {
/*  60 */     this._valueInstantiator = valueInstantiator;
/*  61 */     if (caseInsensitive) {
/*  62 */       this._propertyLookup = CaseInsensitiveMap.construct(ctxt.getConfig().getLocale());
/*     */     } else {
/*  64 */       this._propertyLookup = new HashMap<>();
/*     */     } 
/*  66 */     int len = creatorProps.length;
/*  67 */     this._propertyCount = len;
/*  68 */     this._allProperties = new SettableBeanProperty[len];
/*     */ 
/*     */ 
/*     */     
/*  72 */     if (addAliases) {
/*  73 */       DeserializationConfig config = ctxt.getConfig();
/*  74 */       for (SettableBeanProperty prop : creatorProps) {
/*     */         
/*  76 */         if (!prop.isIgnorable()) {
/*  77 */           List<PropertyName> aliases = prop.findAliases((MapperConfig)config);
/*  78 */           if (!aliases.isEmpty()) {
/*  79 */             for (PropertyName pn : aliases) {
/*  80 */               this._propertyLookup.put(pn.getSimpleName(), prop);
/*     */             }
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*  86 */     for (int i = 0; i < len; i++) {
/*  87 */       SettableBeanProperty prop = creatorProps[i];
/*  88 */       this._allProperties[i] = prop;
/*     */       
/*  90 */       if (!prop.isIgnorable()) {
/*  91 */         this._propertyLookup.put(prop.getName(), prop);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PropertyBasedCreator(PropertyBasedCreator base, HashMap<String, SettableBeanProperty> propertyLookup, SettableBeanProperty[] allProperties) {
/* 103 */     this._propertyCount = base._propertyCount;
/* 104 */     this._valueInstantiator = base._valueInstantiator;
/* 105 */     this._propertyLookup = propertyLookup;
/* 106 */     this._allProperties = allProperties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyBasedCreator construct(DeserializationContext ctxt, ValueInstantiator valueInstantiator, SettableBeanProperty[] srcCreatorProps, BeanPropertyMap allProperties) throws JsonMappingException {
/* 120 */     int len = srcCreatorProps.length;
/* 121 */     SettableBeanProperty[] creatorProps = new SettableBeanProperty[len];
/* 122 */     for (int i = 0; i < len; i++) {
/* 123 */       SettableBeanProperty prop = srcCreatorProps[i];
/* 124 */       if (!prop.hasValueDeserializer())
/*     */       {
/*     */         
/* 127 */         if (!prop.isInjectionOnly()) {
/* 128 */           prop = prop.withValueDeserializer(ctxt.findContextualValueDeserializer(prop.getType(), (BeanProperty)prop));
/*     */         }
/*     */       }
/* 131 */       creatorProps[i] = prop;
/*     */     } 
/* 133 */     return new PropertyBasedCreator(ctxt, valueInstantiator, creatorProps, allProperties
/* 134 */         .isCaseInsensitive(), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyBasedCreator construct(DeserializationContext ctxt, ValueInstantiator valueInstantiator, SettableBeanProperty[] srcCreatorProps, boolean caseInsensitive) throws JsonMappingException {
/* 153 */     int len = srcCreatorProps.length;
/* 154 */     SettableBeanProperty[] creatorProps = new SettableBeanProperty[len];
/* 155 */     for (int i = 0; i < len; i++) {
/* 156 */       SettableBeanProperty prop = srcCreatorProps[i];
/* 157 */       if (!prop.hasValueDeserializer()) {
/* 158 */         prop = prop.withValueDeserializer(ctxt.findContextualValueDeserializer(prop.getType(), (BeanProperty)prop));
/*     */       }
/* 160 */       creatorProps[i] = prop;
/*     */     } 
/* 162 */     return new PropertyBasedCreator(ctxt, valueInstantiator, creatorProps, caseInsensitive, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static PropertyBasedCreator construct(DeserializationContext ctxt, ValueInstantiator valueInstantiator, SettableBeanProperty[] srcCreatorProps) throws JsonMappingException {
/* 171 */     return construct(ctxt, valueInstantiator, srcCreatorProps, ctxt
/* 172 */         .isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyBasedCreator renameAll(NameTransformer transformer) {
/* 183 */     if (transformer == null || transformer == NameTransformer.NOP) {
/* 184 */       return this;
/*     */     }
/*     */     
/* 187 */     int len = this._allProperties.length;
/* 188 */     HashMap<String, SettableBeanProperty> newLookup = new HashMap<>(this._propertyLookup);
/* 189 */     List<SettableBeanProperty> newProps = new ArrayList<>(len);
/*     */     
/* 191 */     for (SettableBeanProperty prop : this._allProperties) {
/* 192 */       if (prop == null) {
/* 193 */         newProps.add(null);
/*     */       }
/*     */       else {
/*     */         
/* 197 */         SettableBeanProperty renamedProperty = prop.unwrapped(transformer);
/* 198 */         String oldName = prop.getName();
/* 199 */         String newName = renamedProperty.getName();
/*     */         
/* 201 */         newProps.add(renamedProperty);
/*     */         
/* 203 */         if (!oldName.equals(newName) && newLookup.containsKey(oldName)) {
/* 204 */           newLookup.remove(oldName);
/* 205 */           newLookup.put(newName, renamedProperty);
/*     */         } 
/*     */       } 
/*     */     } 
/* 209 */     return new PropertyBasedCreator(this, newLookup, newProps
/*     */         
/* 211 */         .<SettableBeanProperty>toArray(new SettableBeanProperty[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<SettableBeanProperty> properties() {
/* 222 */     return this._propertyLookup.values();
/*     */   }
/*     */   
/*     */   public SettableBeanProperty findCreatorProperty(String name) {
/* 226 */     return this._propertyLookup.get(name);
/*     */   }
/*     */   
/*     */   public SettableBeanProperty findCreatorProperty(int propertyIndex) {
/* 230 */     for (SettableBeanProperty prop : this._propertyLookup.values()) {
/* 231 */       if (prop.getPropertyIndex() == propertyIndex) {
/* 232 */         return prop;
/*     */       }
/*     */     } 
/* 235 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyValueBuffer startBuilding(JsonParser p, DeserializationContext ctxt, ObjectIdReader oir) {
/* 251 */     return new PropertyValueBuffer(p, ctxt, this._propertyCount, oir, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyValueBuffer startBuildingWithAnySetter(JsonParser p, DeserializationContext ctxt, ObjectIdReader oir, SettableAnyProperty anySetter) {
/* 262 */     return new PropertyValueBuffer(p, ctxt, this._propertyCount, oir, anySetter);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object build(DeserializationContext ctxt, PropertyValueBuffer buffer) throws IOException {
/* 267 */     Object bean = this._valueInstantiator.createFromObjectWith(ctxt, this._allProperties, buffer);
/*     */ 
/*     */     
/* 270 */     if (bean != null) {
/*     */       
/* 272 */       bean = buffer.handleIdValue(ctxt, bean);
/*     */ 
/*     */       
/* 275 */       for (PropertyValue pv = buffer.buffered(); pv != null; pv = pv.next) {
/* 276 */         pv.assign(bean);
/*     */       }
/*     */     } 
/* 279 */     return bean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class CaseInsensitiveMap
/*     */     extends HashMap<String, SettableBeanProperty>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final Locale _locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public CaseInsensitiveMap() {
/* 307 */       this(Locale.getDefault());
/*     */     }
/*     */ 
/*     */     
/*     */     public CaseInsensitiveMap(Locale l) {
/* 312 */       this._locale = l;
/*     */     }
/*     */ 
/*     */     
/*     */     public static CaseInsensitiveMap construct(Locale l) {
/* 317 */       return new CaseInsensitiveMap(l);
/*     */     }
/*     */ 
/*     */     
/*     */     public SettableBeanProperty get(Object key0) {
/* 322 */       return super.get(((String)key0).toLowerCase(this._locale));
/*     */     }
/*     */ 
/*     */     
/*     */     public SettableBeanProperty put(String key, SettableBeanProperty value) {
/* 327 */       key = key.toLowerCase(this._locale);
/* 328 */       return super.put(key, value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\impl\PropertyBasedCreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */