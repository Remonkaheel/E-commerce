/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionAction;
/*     */ import com.fasterxml.jackson.databind.cfg.CoercionInputShape;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.NullValueProvider;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.ArrayType;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*     */ import com.fasterxml.jackson.databind.util.ObjectBuffer;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class ObjectArrayDeserializer
/*     */   extends ContainerDeserializerBase<Object>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final boolean _untyped;
/*     */   protected final Class<?> _elementClass;
/*     */   protected JsonDeserializer<Object> _elementDeserializer;
/*     */   protected final TypeDeserializer _elementTypeDeserializer;
/*     */   protected final Object[] _emptyValue;
/*     */   
/*     */   public ObjectArrayDeserializer(JavaType arrayType0, JsonDeserializer<Object> elemDeser, TypeDeserializer elemTypeDeser) {
/*  73 */     super(arrayType0, (NullValueProvider)null, (Boolean)null);
/*  74 */     ArrayType arrayType = (ArrayType)arrayType0;
/*  75 */     this._elementClass = arrayType.getContentType().getRawClass();
/*  76 */     this._untyped = (this._elementClass == Object.class);
/*  77 */     this._elementDeserializer = elemDeser;
/*  78 */     this._elementTypeDeserializer = elemTypeDeser;
/*  79 */     this._emptyValue = arrayType.getEmptyArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectArrayDeserializer(ObjectArrayDeserializer base, JsonDeserializer<Object> elemDeser, TypeDeserializer elemTypeDeser, NullValueProvider nuller, Boolean unwrapSingle) {
/*  86 */     super(base, nuller, unwrapSingle);
/*  87 */     this._elementClass = base._elementClass;
/*  88 */     this._untyped = base._untyped;
/*  89 */     this._emptyValue = base._emptyValue;
/*     */     
/*  91 */     this._elementDeserializer = elemDeser;
/*  92 */     this._elementTypeDeserializer = elemTypeDeser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectArrayDeserializer withDeserializer(TypeDeserializer elemTypeDeser, JsonDeserializer<?> elemDeser) {
/* 101 */     return withResolved(elemTypeDeser, elemDeser, this._nullProvider, this._unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjectArrayDeserializer withResolved(TypeDeserializer elemTypeDeser, JsonDeserializer<?> elemDeser, NullValueProvider nuller, Boolean unwrapSingle) {
/* 112 */     if (Objects.equals(unwrapSingle, this._unwrapSingle) && nuller == this._nullProvider && elemDeser == this._elementDeserializer && elemTypeDeser == this._elementTypeDeserializer)
/*     */     {
/*     */       
/* 115 */       return this;
/*     */     }
/* 117 */     return new ObjectArrayDeserializer(this, (JsonDeserializer)elemDeser, elemTypeDeser, nuller, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCachable() {
/* 126 */     return (this._elementDeserializer == null && this._elementTypeDeserializer == null);
/*     */   }
/*     */ 
/*     */   
/*     */   public LogicalType logicalType() {
/* 131 */     return LogicalType.Array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/* 138 */     JsonDeserializer<?> valueDeser = this._elementDeserializer;
/*     */ 
/*     */ 
/*     */     
/* 142 */     Boolean unwrapSingle = findFormatFeature(ctxt, property, this._containerType.getRawClass(), JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
/*     */ 
/*     */     
/* 145 */     valueDeser = findConvertingContentDeserializer(ctxt, property, valueDeser);
/* 146 */     JavaType vt = this._containerType.getContentType();
/* 147 */     if (valueDeser == null) {
/* 148 */       valueDeser = ctxt.findContextualValueDeserializer(vt, property);
/*     */     } else {
/* 150 */       valueDeser = ctxt.handleSecondaryContextualization(valueDeser, property, vt);
/*     */     } 
/* 152 */     TypeDeserializer elemTypeDeser = this._elementTypeDeserializer;
/* 153 */     if (elemTypeDeser != null) {
/* 154 */       elemTypeDeser = elemTypeDeser.forProperty(property);
/*     */     }
/* 156 */     NullValueProvider nuller = findContentNullProvider(ctxt, property, valueDeser);
/* 157 */     return withResolved(elemTypeDeser, valueDeser, nuller, unwrapSingle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<Object> getContentDeserializer() {
/* 168 */     return this._elementDeserializer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public AccessPattern getEmptyAccessPattern() {
/* 174 */     return AccessPattern.CONSTANT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/* 182 */     return this._emptyValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*     */     Object[] result;
/* 196 */     if (!p.isExpectedStartArrayToken()) {
/* 197 */       return handleNonArray(p, ctxt);
/*     */     }
/*     */     
/* 200 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 201 */     Object[] chunk = buffer.resetAndStart();
/* 202 */     int ix = 0;
/*     */     
/*     */     try {
/*     */       JsonToken t;
/* 206 */       while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/*     */         Object value;
/*     */ 
/*     */         
/* 210 */         if (t == JsonToken.VALUE_NULL) {
/* 211 */           if (this._skipNullValues) {
/*     */             continue;
/*     */           }
/* 214 */           value = null;
/*     */         } else {
/* 216 */           value = _deserializeNoNullChecks(p, ctxt);
/*     */         } 
/*     */         
/* 219 */         if (value == null) {
/* 220 */           value = this._nullProvider.getNullValue(ctxt);
/*     */           
/* 222 */           if (value == null && this._skipNullValues) {
/*     */             continue;
/*     */           }
/*     */         } 
/*     */         
/* 227 */         if (ix >= chunk.length) {
/* 228 */           chunk = buffer.appendCompletedChunk(chunk);
/* 229 */           ix = 0;
/*     */         } 
/* 231 */         chunk[ix++] = value;
/*     */       } 
/* 233 */     } catch (Exception e) {
/* 234 */       throw JsonMappingException.wrapWithPath(e, chunk, buffer.bufferedSize() + ix);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 239 */     if (this._untyped) {
/* 240 */       result = buffer.completeAndClearBuffer(chunk, ix);
/*     */     } else {
/* 242 */       result = buffer.completeAndClearBuffer(chunk, ix, this._elementClass);
/*     */     } 
/* 244 */     ctxt.returnObjectBuffer(buffer);
/* 245 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 255 */     return typeDeserializer.deserializeTypedFromArray(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserialize(JsonParser p, DeserializationContext ctxt, Object intoValue0) throws IOException {
/* 262 */     Object[] result, intoValue = (Object[])intoValue0;
/* 263 */     if (!p.isExpectedStartArrayToken()) {
/* 264 */       Object[] arr = (Object[])handleNonArray(p, ctxt);
/* 265 */       if (arr == null) {
/* 266 */         return intoValue;
/*     */       }
/* 268 */       int offset = intoValue.length;
/* 269 */       Object[] arrayOfObject1 = Arrays.copyOf(intoValue, offset + arr.length);
/* 270 */       System.arraycopy(arr, 0, arrayOfObject1, offset, arr.length);
/* 271 */       return arrayOfObject1;
/*     */     } 
/*     */     
/* 274 */     ObjectBuffer buffer = ctxt.leaseObjectBuffer();
/* 275 */     int ix = intoValue.length;
/* 276 */     Object[] chunk = buffer.resetAndStart(intoValue, ix);
/*     */     
/*     */     try {
/*     */       JsonToken t;
/* 280 */       while ((t = p.nextToken()) != JsonToken.END_ARRAY) {
/*     */         Object value;
/*     */         
/* 283 */         if (t == JsonToken.VALUE_NULL) {
/* 284 */           if (this._skipNullValues) {
/*     */             continue;
/*     */           }
/* 287 */           value = null;
/*     */         } else {
/* 289 */           value = _deserializeNoNullChecks(p, ctxt);
/*     */         } 
/*     */         
/* 292 */         if (value == null) {
/* 293 */           value = this._nullProvider.getNullValue(ctxt);
/*     */           
/* 295 */           if (value == null && this._skipNullValues) {
/*     */             continue;
/*     */           }
/*     */         } 
/*     */         
/* 300 */         if (ix >= chunk.length) {
/* 301 */           chunk = buffer.appendCompletedChunk(chunk);
/* 302 */           ix = 0;
/*     */         } 
/* 304 */         chunk[ix++] = value;
/*     */       } 
/* 306 */     } catch (Exception e) {
/* 307 */       throw JsonMappingException.wrapWithPath(e, chunk, buffer.bufferedSize() + ix);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 312 */     if (this._untyped) {
/* 313 */       result = buffer.completeAndClearBuffer(chunk, ix);
/*     */     } else {
/* 315 */       result = buffer.completeAndClearBuffer(chunk, ix, this._elementClass);
/*     */     } 
/* 317 */     ctxt.returnObjectBuffer(buffer);
/* 318 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Byte[] deserializeFromBase64(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 331 */     byte[] b = p.getBinaryValue(ctxt.getBase64Variant());
/*     */     
/* 333 */     Byte[] result = new Byte[b.length];
/* 334 */     for (int i = 0, len = b.length; i < len; i++) {
/* 335 */       result[i] = Byte.valueOf(b[i]);
/*     */     }
/* 337 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object handleNonArray(JsonParser p, DeserializationContext ctxt) throws IOException {
/*     */     Object value, result[];
/* 346 */     boolean canWrap = (this._unwrapSingle == Boolean.TRUE || (this._unwrapSingle == null && ctxt.isEnabled(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)));
/* 347 */     if (!canWrap) {
/*     */       
/* 349 */       if (p.hasToken(JsonToken.VALUE_STRING)) {
/*     */ 
/*     */         
/* 352 */         if (this._elementClass == Byte.class) {
/* 353 */           return deserializeFromBase64(p, ctxt);
/*     */         }
/*     */         
/* 356 */         return _deserializeFromString(p, ctxt);
/*     */       } 
/* 358 */       return ctxt.handleUnexpectedToken(this._containerType, p);
/*     */     } 
/*     */ 
/*     */     
/* 362 */     if (p.hasToken(JsonToken.VALUE_NULL)) {
/*     */       
/* 364 */       if (this._skipNullValues) {
/* 365 */         return this._emptyValue;
/*     */       }
/* 367 */       value = null;
/*     */     } else {
/* 369 */       if (p.hasToken(JsonToken.VALUE_STRING)) {
/* 370 */         String textValue = p.getText();
/*     */         
/* 372 */         if (textValue.isEmpty()) {
/* 373 */           CoercionAction act = ctxt.findCoercionAction(logicalType(), handledType(), CoercionInputShape.EmptyString);
/*     */           
/* 375 */           if (act != CoercionAction.Fail) {
/* 376 */             return _deserializeFromEmptyString(p, ctxt, act, handledType(), "empty String (\"\")");
/*     */           }
/*     */         }
/* 379 */         else if (_isBlank(textValue)) {
/* 380 */           CoercionAction act = ctxt.findCoercionFromBlankString(logicalType(), handledType(), CoercionAction.Fail);
/*     */           
/* 382 */           if (act != CoercionAction.Fail) {
/* 383 */             return _deserializeFromEmptyString(p, ctxt, act, handledType(), "blank String (all whitespace)");
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 390 */       value = _deserializeNoNullChecks(p, ctxt);
/*     */     } 
/*     */     
/* 393 */     if (value == null) {
/* 394 */       value = this._nullProvider.getNullValue(ctxt);
/*     */       
/* 396 */       if (value == null && this._skipNullValues) {
/* 397 */         return this._emptyValue;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 404 */     if (this._untyped) {
/* 405 */       result = new Object[1];
/*     */     } else {
/* 407 */       result = (Object[])Array.newInstance(this._elementClass, 1);
/*     */     } 
/* 409 */     result[0] = value;
/* 410 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserializeNoNullChecks(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 423 */     if (this._elementTypeDeserializer == null) {
/* 424 */       return this._elementDeserializer.deserialize(p, ctxt);
/*     */     }
/* 426 */     return this._elementDeserializer.deserializeWithType(p, ctxt, this._elementTypeDeserializer);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\ObjectArrayDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */