/*     */ package com.fasterxml.jackson.databind.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DatabindException;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.deser.impl.BeanPropertyMap;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ObjectIdReader;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ObjectIdValueProperty;
/*     */ import com.fasterxml.jackson.databind.deser.impl.ValueInjector;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.util.Annotations;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.IgnorePropertiesUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanDeserializerBuilder
/*     */ {
/*     */   protected final DeserializationConfig _config;
/*     */   protected final DeserializationContext _context;
/*     */   protected final BeanDescription _beanDesc;
/*  58 */   protected final Map<String, SettableBeanProperty> _properties = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SettableBeanProperty[] _propsBasedCreatorParams;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<ValueInjector> _injectables;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HashMap<String, SettableBeanProperty> _backRefProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HashSet<String> _ignorableProps;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HashSet<String> _includableProps;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ValueInstantiator _valueInstantiator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectIdReader _objectIdReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SettableAnyProperty _anySetter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _ignoreAllUnknown;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AnnotatedMethod _buildMethod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonPOJOBuilder.Value _builderConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BeanDeserializerBuilder(BeanDescription beanDesc, DeserializationContext ctxt) {
/* 134 */     this._beanDesc = beanDesc;
/* 135 */     this._context = ctxt;
/* 136 */     this._config = ctxt.getConfig();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BeanDeserializerBuilder(BeanDeserializerBuilder src) {
/* 145 */     this._beanDesc = src._beanDesc;
/* 146 */     this._context = src._context;
/* 147 */     this._config = src._config;
/*     */ 
/*     */     
/* 150 */     this._properties.putAll(src._properties);
/* 151 */     this._injectables = _copy(src._injectables);
/* 152 */     this._backRefProperties = _copy(src._backRefProperties);
/*     */     
/* 154 */     this._ignorableProps = src._ignorableProps;
/* 155 */     this._includableProps = src._includableProps;
/* 156 */     this._valueInstantiator = src._valueInstantiator;
/* 157 */     this._propsBasedCreatorParams = src._propsBasedCreatorParams;
/* 158 */     this._objectIdReader = src._objectIdReader;
/*     */     
/* 160 */     this._anySetter = src._anySetter;
/* 161 */     this._ignoreAllUnknown = src._ignoreAllUnknown;
/*     */     
/* 163 */     this._buildMethod = src._buildMethod;
/* 164 */     this._builderConfig = src._builderConfig;
/*     */   }
/*     */   
/*     */   private static HashMap<String, SettableBeanProperty> _copy(HashMap<String, SettableBeanProperty> src) {
/* 168 */     return (src == null) ? null : new HashMap<>(src);
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T> List<T> _copy(List<T> src) {
/* 173 */     return (src == null) ? null : new ArrayList<>(src);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addOrReplaceProperty(SettableBeanProperty prop, boolean allowOverride) {
/* 186 */     SettableBeanProperty oldProp = this._properties.put(prop.getName(), prop);
/* 187 */     if (oldProp != null && this._propsBasedCreatorParams != null) {
/* 188 */       for (int i = 0, len = this._propsBasedCreatorParams.length; i < len; i++) {
/* 189 */         if (this._propsBasedCreatorParams[i] == oldProp) {
/* 190 */           this._propsBasedCreatorParams[i] = prop;
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addProperty(SettableBeanProperty prop) {
/* 203 */     SettableBeanProperty old = this._properties.put(prop.getName(), prop);
/* 204 */     if (old != null && old != prop) {
/* 205 */       throw new IllegalArgumentException("Duplicate property '" + prop.getName() + "' for " + this._beanDesc.getType());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addBackReferenceProperty(String referenceName, SettableBeanProperty prop) throws JsonMappingException {
/* 217 */     if (this._backRefProperties == null) {
/* 218 */       this._backRefProperties = new HashMap<>(4);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 223 */     if (this._config.canOverrideAccessModifiers()) {
/*     */       try {
/* 225 */         prop.fixAccess(this._config);
/* 226 */       } catch (IllegalArgumentException e) {
/* 227 */         _handleBadAccess(e);
/*     */       } 
/*     */     }
/* 230 */     this._backRefProperties.put(referenceName, prop);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addInjectable(PropertyName propName, JavaType propType, Annotations contextAnnotations, AnnotatedMember member, Object valueId) throws JsonMappingException {
/* 247 */     if (this._injectables == null) {
/* 248 */       this._injectables = new ArrayList<>();
/*     */     }
/* 250 */     if (this._config.canOverrideAccessModifiers()) {
/*     */       try {
/* 252 */         member.fixAccess(this._config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/* 253 */       } catch (IllegalArgumentException e) {
/* 254 */         _handleBadAccess(e);
/*     */       } 
/*     */     }
/* 257 */     this._injectables.add(new ValueInjector(propName, propType, member, valueId));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addIgnorable(String propName) {
/* 266 */     if (this._ignorableProps == null) {
/* 267 */       this._ignorableProps = new HashSet<>();
/*     */     }
/* 269 */     this._ignorableProps.add(propName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addIncludable(String propName) {
/* 279 */     if (this._includableProps == null) {
/* 280 */       this._includableProps = new HashSet<>();
/*     */     }
/* 282 */     this._includableProps.add(propName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCreatorProperty(SettableBeanProperty prop) {
/* 297 */     addProperty(prop);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAnySetter(SettableAnyProperty s) {
/* 302 */     if (this._anySetter != null && s != null) {
/* 303 */       throw new IllegalStateException("_anySetter already set to non-null");
/*     */     }
/* 305 */     this._anySetter = s;
/*     */   }
/*     */   
/*     */   public void setIgnoreUnknownProperties(boolean ignore) {
/* 309 */     this._ignoreAllUnknown = ignore;
/*     */   }
/*     */   
/*     */   public void setValueInstantiator(ValueInstantiator inst) {
/* 313 */     this._valueInstantiator = inst;
/* 314 */     this._propsBasedCreatorParams = inst.getFromObjectArguments(this._config);
/*     */   }
/*     */   
/*     */   public void setObjectIdReader(ObjectIdReader r) {
/* 318 */     this._objectIdReader = r;
/*     */   }
/*     */   
/*     */   public void setPOJOBuilder(AnnotatedMethod buildMethod, JsonPOJOBuilder.Value config) {
/* 322 */     this._buildMethod = buildMethod;
/* 323 */     this._builderConfig = config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<SettableBeanProperty> getProperties() {
/* 341 */     return this._properties.values().iterator();
/*     */   }
/*     */   
/*     */   public SettableBeanProperty findProperty(PropertyName propertyName) {
/* 345 */     return this._properties.get(propertyName.getSimpleName());
/*     */   }
/*     */   
/*     */   public boolean hasProperty(PropertyName propertyName) {
/* 349 */     return (findProperty(propertyName) != null);
/*     */   }
/*     */   
/*     */   public SettableBeanProperty removeProperty(PropertyName name) {
/* 353 */     return this._properties.remove(name.getSimpleName());
/*     */   }
/*     */   
/*     */   public SettableAnyProperty getAnySetter() {
/* 357 */     return this._anySetter;
/*     */   }
/*     */   
/*     */   public ValueInstantiator getValueInstantiator() {
/* 361 */     return this._valueInstantiator;
/*     */   }
/*     */   
/*     */   public List<ValueInjector> getInjectables() {
/* 365 */     return this._injectables;
/*     */   }
/*     */   
/*     */   public ObjectIdReader getObjectIdReader() {
/* 369 */     return this._objectIdReader;
/*     */   }
/*     */   
/*     */   public AnnotatedMethod getBuildMethod() {
/* 373 */     return this._buildMethod;
/*     */   }
/*     */   
/*     */   public JsonPOJOBuilder.Value getBuilderConfig() {
/* 377 */     return this._builderConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasIgnorable(String name) {
/* 384 */     return IgnorePropertiesUtil.shouldIgnore(name, this._ignorableProps, this._includableProps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> build() throws JsonMappingException {
/* 400 */     Collection<SettableBeanProperty> props = this._properties.values();
/* 401 */     _fixAccess(props);
/* 402 */     BeanPropertyMap propertyMap = BeanPropertyMap.construct((MapperConfig)this._config, props, 
/* 403 */         _collectAliases(props), 
/* 404 */         _findCaseInsensitivity());
/* 405 */     propertyMap.assignIndexes();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 410 */     boolean anyViews = !this._config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION);
/* 411 */     if (!anyViews) {
/* 412 */       for (SettableBeanProperty prop : props) {
/* 413 */         if (prop.hasViews()) {
/* 414 */           anyViews = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 421 */     if (this._objectIdReader != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 426 */       ObjectIdValueProperty prop = new ObjectIdValueProperty(this._objectIdReader, PropertyMetadata.STD_REQUIRED);
/* 427 */       propertyMap = propertyMap.withProperty((SettableBeanProperty)prop);
/*     */     } 
/*     */     
/* 430 */     return (JsonDeserializer<?>)new BeanDeserializer(this, this._beanDesc, propertyMap, this._backRefProperties, this._ignorableProps, this._ignoreAllUnknown, this._includableProps, anyViews);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractDeserializer buildAbstract() {
/* 443 */     return new AbstractDeserializer(this, this._beanDesc, this._backRefProperties, this._properties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> buildBuilderBased(JavaType valueType, String expBuildMethodName) throws JsonMappingException {
/* 454 */     if (this._buildMethod == null) {
/*     */       
/* 456 */       if (!expBuildMethodName.isEmpty()) {
/* 457 */         this._context.reportBadDefinition(this._beanDesc.getType(), 
/* 458 */             String.format("Builder class %s does not have build method (name: '%s')", new Object[] {
/* 459 */                 ClassUtil.getTypeDescription(this._beanDesc.getType()), expBuildMethodName
/*     */               }));
/*     */       }
/*     */     } else {
/*     */       
/* 464 */       Class<?> rawBuildType = this._buildMethod.getRawReturnType();
/* 465 */       Class<?> rawValueType = valueType.getRawClass();
/* 466 */       if (rawBuildType != rawValueType && 
/* 467 */         !rawBuildType.isAssignableFrom(rawValueType) && 
/* 468 */         !rawValueType.isAssignableFrom(rawBuildType)) {
/* 469 */         this._context.reportBadDefinition(this._beanDesc.getType(), 
/* 470 */             String.format("Build method `%s` has wrong return type (%s), not compatible with POJO type (%s)", new Object[] {
/* 471 */                 this._buildMethod.getFullName(), 
/* 472 */                 ClassUtil.getClassDescription(rawBuildType), 
/* 473 */                 ClassUtil.getTypeDescription(valueType)
/*     */               }));
/*     */       }
/*     */     } 
/* 477 */     Collection<SettableBeanProperty> props = this._properties.values();
/* 478 */     _fixAccess(props);
/* 479 */     BeanPropertyMap propertyMap = BeanPropertyMap.construct((MapperConfig)this._config, props, 
/* 480 */         _collectAliases(props), 
/* 481 */         _findCaseInsensitivity());
/* 482 */     propertyMap.assignIndexes();
/*     */     
/* 484 */     boolean anyViews = !this._config.isEnabled(MapperFeature.DEFAULT_VIEW_INCLUSION);
/*     */     
/* 486 */     if (!anyViews) {
/* 487 */       for (SettableBeanProperty prop : props) {
/* 488 */         if (prop.hasViews()) {
/* 489 */           anyViews = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/* 495 */     if (this._objectIdReader != null) {
/*     */ 
/*     */       
/* 498 */       ObjectIdValueProperty prop = new ObjectIdValueProperty(this._objectIdReader, PropertyMetadata.STD_REQUIRED);
/*     */       
/* 500 */       propertyMap = propertyMap.withProperty((SettableBeanProperty)prop);
/*     */     } 
/*     */     
/* 503 */     return createBuilderBasedDeserializer(valueType, propertyMap, anyViews);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonDeserializer<?> createBuilderBasedDeserializer(JavaType valueType, BeanPropertyMap propertyMap, boolean anyViews) {
/* 513 */     return (JsonDeserializer<?>)new BuilderBasedDeserializer(this, this._beanDesc, valueType, propertyMap, this._backRefProperties, this._ignorableProps, this._ignoreAllUnknown, this._includableProps, anyViews);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _fixAccess(Collection<SettableBeanProperty> mainProps) throws JsonMappingException {
/* 543 */     if (this._config.canOverrideAccessModifiers()) {
/* 544 */       for (SettableBeanProperty prop : mainProps) {
/*     */ 
/*     */         
/*     */         try {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 552 */           prop.fixAccess(this._config);
/* 553 */         } catch (IllegalArgumentException e) {
/* 554 */           _handleBadAccess(e);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 577 */     if (this._anySetter != null) {
/*     */       try {
/* 579 */         this._anySetter.fixAccess(this._config);
/* 580 */       } catch (IllegalArgumentException e) {
/* 581 */         _handleBadAccess(e);
/*     */       } 
/*     */     }
/* 584 */     if (this._buildMethod != null) {
/*     */       try {
/* 586 */         this._buildMethod.fixAccess(this._config.isEnabled(MapperFeature.OVERRIDE_PUBLIC_ACCESS_MODIFIERS));
/* 587 */       } catch (IllegalArgumentException e) {
/* 588 */         _handleBadAccess(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Map<String, List<PropertyName>> _collectAliases(Collection<SettableBeanProperty> props) {
/* 595 */     Map<String, List<PropertyName>> mapping = null;
/* 596 */     for (SettableBeanProperty prop : props) {
/* 597 */       List<PropertyName> aliases = prop.findAliases((MapperConfig)this._config);
/* 598 */       if (aliases == null || aliases.isEmpty()) {
/*     */         continue;
/*     */       }
/* 601 */       if (mapping == null) {
/* 602 */         mapping = new HashMap<>();
/*     */       }
/* 604 */       mapping.put(prop.getName(), aliases);
/*     */     } 
/* 606 */     if (mapping == null) {
/* 607 */       return Collections.emptyMap();
/*     */     }
/* 609 */     return mapping;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _findCaseInsensitivity() {
/* 616 */     JsonFormat.Value format = this._beanDesc.findExpectedFormat();
/*     */     
/* 618 */     Boolean B = format.getFeature(JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES);
/* 619 */     return (B == null) ? this._config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES) : B
/* 620 */       .booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _handleBadAccess(IllegalArgumentException e0) throws JsonMappingException {
/*     */     try {
/* 634 */       this._context.reportBadTypeDefinition(this._beanDesc, e0.getMessage(), new Object[0]);
/* 635 */     } catch (DatabindException e) {
/* 636 */       if (e.getCause() == null) {
/* 637 */         e.initCause(e0);
/*     */       }
/* 639 */       throw e;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\BeanDeserializerBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */