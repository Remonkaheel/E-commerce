/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.BeanDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.BeanDeserializerBase;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThrowableDeserializer
/*     */   extends BeanDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected static final String PROP_NAME_MESSAGE = "message";
/*     */   protected static final String PROP_NAME_SUPPRESSED = "suppressed";
/*     */   protected static final String PROP_NAME_LOCALIZED_MESSAGE = "localizedMessage";
/*     */   
/*     */   protected ThrowableDeserializer(BeanDeserializer src, NameTransformer unwrapper) {
/*  36 */     super((BeanDeserializerBase)src, unwrapper);
/*     */     
/*  38 */     this._vanillaProcessing = false;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public ThrowableDeserializer(BeanDeserializer baseDeserializer) {
/*  43 */     this(baseDeserializer, (NameTransformer)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ThrowableDeserializer construct(DeserializationContext ctxt, BeanDeserializer baseDeserializer) {
/*  57 */     return new ThrowableDeserializer(baseDeserializer, (NameTransformer)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<Object> unwrappingDeserializer(NameTransformer unwrapper) {
/*  64 */     if (getClass() != ThrowableDeserializer.class) {
/*  65 */       return (JsonDeserializer<Object>)this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  70 */     return (JsonDeserializer<Object>)new ThrowableDeserializer(this, unwrapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeFromObject(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  83 */     if (this._propertyBasedCreator != null) {
/*  84 */       return _deserializeUsingPropertyBased(p, ctxt);
/*     */     }
/*  86 */     if (this._delegateDeserializer != null) {
/*  87 */       return this._valueInstantiator.createUsingDelegate(ctxt, this._delegateDeserializer
/*  88 */           .deserialize(p, ctxt));
/*     */     }
/*  90 */     if (this._beanType.isAbstract()) {
/*  91 */       return ctxt.handleMissingInstantiator(handledType(), getValueInstantiator(), p, "abstract type (need to add/enable type information?)", new Object[0]);
/*     */     }
/*     */     
/*  94 */     boolean hasStringCreator = this._valueInstantiator.canCreateFromString();
/*  95 */     boolean hasDefaultCtor = this._valueInstantiator.canCreateUsingDefault();
/*     */     
/*  97 */     if (!hasStringCreator && !hasDefaultCtor) {
/*  98 */       return ctxt.handleMissingInstantiator(handledType(), getValueInstantiator(), p, "Throwable needs a default constructor, a single-String-arg constructor; or explicit @JsonCreator", new Object[0]);
/*     */     }
/*     */     
/* 101 */     Throwable throwable = null;
/* 102 */     Object[] pending = null;
/* 103 */     Throwable[] suppressed = null;
/* 104 */     int pendingIx = 0;
/* 105 */     for (; !p.hasToken(JsonToken.END_OBJECT); p.nextToken()) {
/* 106 */       String propName = p.currentName();
/* 107 */       SettableBeanProperty prop = this._beanProperties.find(propName);
/* 108 */       p.nextToken();
/*     */       
/* 110 */       if (prop != null) {
/*     */ 
/*     */         
/* 113 */         if (!"cause".equals(prop.getName()) || 
/* 114 */           !p.hasToken(JsonToken.VALUE_NULL))
/*     */         {
/*     */           
/* 117 */           if (throwable != null) {
/* 118 */             prop.deserializeAndSet(p, ctxt, throwable);
/*     */           }
/*     */           else {
/*     */             
/* 122 */             if (pending == null) {
/* 123 */               int len = this._beanProperties.size();
/* 124 */               pending = new Object[len + len];
/* 125 */             } else if (pendingIx == pending.length) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 131 */               pending = Arrays.copyOf(pending, pendingIx + 16);
/*     */             } 
/* 133 */             pending[pendingIx++] = prop;
/* 134 */             pending[pendingIx++] = prop.deserialize(p, ctxt);
/*     */ 
/*     */           
/*     */           }
/*     */ 
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 143 */       else if ("message".equalsIgnoreCase(propName)) {
/* 144 */         throwable = _instantiate(ctxt, hasStringCreator, p.getValueAsString());
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 149 */       else if (this._ignorableProps != null && this._ignorableProps.contains(propName)) {
/* 150 */         p.skipChildren();
/*     */       
/*     */       }
/* 153 */       else if ("suppressed".equalsIgnoreCase(propName)) {
/*     */ 
/*     */         
/* 156 */         if (p.hasToken(JsonToken.VALUE_NULL)) {
/* 157 */           suppressed = null;
/*     */         } else {
/*     */           
/* 160 */           JsonDeserializer<Object> deser = ctxt.findRootValueDeserializer(ctxt
/* 161 */               .constructType(Throwable[].class));
/* 162 */           suppressed = (Throwable[])deser.deserialize(p, ctxt);
/*     */         }
/*     */       
/*     */       }
/* 166 */       else if ("localizedMessage".equalsIgnoreCase(propName)) {
/* 167 */         p.skipChildren();
/*     */       
/*     */       }
/* 170 */       else if (this._anySetter != null) {
/*     */         
/* 172 */         if (throwable == null) {
/* 173 */           throwable = _instantiate(ctxt, hasStringCreator, (String)null);
/*     */         }
/* 175 */         this._anySetter.deserializeAndSet(p, ctxt, throwable, propName);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 182 */       else if ("message".equalsIgnoreCase(propName)) {
/* 183 */         p.skipChildren();
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 188 */         handleUnknownProperty(p, ctxt, throwable, propName);
/*     */       } 
/*     */     } 
/* 191 */     if (throwable == null) {
/* 192 */       throwable = _instantiate(ctxt, hasStringCreator, (String)null);
/*     */     }
/*     */ 
/*     */     
/* 196 */     if (pending != null) {
/* 197 */       for (int i = 0, len = pendingIx; i < len; i += 2) {
/* 198 */         SettableBeanProperty prop = (SettableBeanProperty)pending[i];
/* 199 */         prop.set(throwable, pending[i + 1]);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 204 */     if (suppressed != null) {
/* 205 */       for (Throwable s : suppressed) {
/*     */         
/* 207 */         if (s != null) {
/* 208 */           throwable.addSuppressed(s);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 213 */     return throwable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Throwable _instantiate(DeserializationContext ctxt, boolean hasStringCreator, String valueAsString) throws IOException {
/* 236 */     if (hasStringCreator) {
/* 237 */       if (valueAsString != null) {
/* 238 */         return (Throwable)this._valueInstantiator.createFromString(ctxt, valueAsString);
/*     */       }
/* 240 */       return (Throwable)this._valueInstantiator.createFromString(ctxt, null);
/*     */     } 
/*     */     
/* 243 */     return (Throwable)this._valueInstantiator.createUsingDefault(ctxt);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\ThrowableDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */