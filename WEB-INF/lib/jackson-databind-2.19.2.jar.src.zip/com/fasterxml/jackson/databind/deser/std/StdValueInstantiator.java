/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedWithParams;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class StdValueInstantiator
/*     */   extends ValueInstantiator
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final String _valueTypeDesc;
/*     */   protected final Class<?> _valueClass;
/*     */   protected AnnotatedWithParams _defaultCreator;
/*     */   protected AnnotatedWithParams _withArgsCreator;
/*     */   protected SettableBeanProperty[] _constructorArguments;
/*     */   protected JavaType _delegateType;
/*     */   protected AnnotatedWithParams _delegateCreator;
/*     */   protected SettableBeanProperty[] _delegateArguments;
/*     */   protected JavaType _arrayDelegateType;
/*     */   protected AnnotatedWithParams _arrayDelegateCreator;
/*     */   protected SettableBeanProperty[] _arrayDelegateArguments;
/*     */   protected AnnotatedWithParams _fromStringCreator;
/*     */   protected AnnotatedWithParams _fromIntCreator;
/*     */   protected AnnotatedWithParams _fromLongCreator;
/*     */   protected AnnotatedWithParams _fromBigIntegerCreator;
/*     */   protected AnnotatedWithParams _fromDoubleCreator;
/*     */   protected AnnotatedWithParams _fromBigDecimalCreator;
/*     */   protected AnnotatedWithParams _fromBooleanCreator;
/*     */   
/*     */   @Deprecated
/*     */   public StdValueInstantiator(DeserializationConfig config, Class<?> valueType) {
/*  83 */     this._valueTypeDesc = ClassUtil.nameOf(valueType);
/*  84 */     this._valueClass = (valueType == null) ? Object.class : valueType;
/*     */   }
/*     */   
/*     */   public StdValueInstantiator(DeserializationConfig config, JavaType valueType) {
/*  88 */     this._valueTypeDesc = (valueType == null) ? "UNKNOWN TYPE" : valueType.toString();
/*  89 */     this._valueClass = (valueType == null) ? Object.class : valueType.getRawClass();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StdValueInstantiator(StdValueInstantiator src) {
/*  98 */     this._valueTypeDesc = src._valueTypeDesc;
/*  99 */     this._valueClass = src._valueClass;
/*     */     
/* 101 */     this._defaultCreator = src._defaultCreator;
/*     */     
/* 103 */     this._constructorArguments = src._constructorArguments;
/* 104 */     this._withArgsCreator = src._withArgsCreator;
/*     */     
/* 106 */     this._delegateType = src._delegateType;
/* 107 */     this._delegateCreator = src._delegateCreator;
/* 108 */     this._delegateArguments = src._delegateArguments;
/*     */     
/* 110 */     this._arrayDelegateType = src._arrayDelegateType;
/* 111 */     this._arrayDelegateCreator = src._arrayDelegateCreator;
/* 112 */     this._arrayDelegateArguments = src._arrayDelegateArguments;
/*     */     
/* 114 */     this._fromStringCreator = src._fromStringCreator;
/* 115 */     this._fromIntCreator = src._fromIntCreator;
/* 116 */     this._fromLongCreator = src._fromLongCreator;
/* 117 */     this._fromBigIntegerCreator = src._fromBigIntegerCreator;
/* 118 */     this._fromDoubleCreator = src._fromDoubleCreator;
/* 119 */     this._fromBigDecimalCreator = src._fromBigDecimalCreator;
/* 120 */     this._fromBooleanCreator = src._fromBooleanCreator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configureFromObjectSettings(AnnotatedWithParams defaultCreator, AnnotatedWithParams delegateCreator, JavaType delegateType, SettableBeanProperty[] delegateArgs, AnnotatedWithParams withArgsCreator, SettableBeanProperty[] constructorArgs) {
/* 132 */     this._defaultCreator = defaultCreator;
/* 133 */     this._delegateCreator = delegateCreator;
/* 134 */     this._delegateType = delegateType;
/* 135 */     this._delegateArguments = delegateArgs;
/* 136 */     this._withArgsCreator = withArgsCreator;
/* 137 */     this._constructorArguments = constructorArgs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configureFromArraySettings(AnnotatedWithParams arrayDelegateCreator, JavaType arrayDelegateType, SettableBeanProperty[] arrayDelegateArgs) {
/* 145 */     this._arrayDelegateCreator = arrayDelegateCreator;
/* 146 */     this._arrayDelegateType = arrayDelegateType;
/* 147 */     this._arrayDelegateArguments = arrayDelegateArgs;
/*     */   }
/*     */   
/*     */   public void configureFromStringCreator(AnnotatedWithParams creator) {
/* 151 */     this._fromStringCreator = creator;
/*     */   }
/*     */   
/*     */   public void configureFromIntCreator(AnnotatedWithParams creator) {
/* 155 */     this._fromIntCreator = creator;
/*     */   }
/*     */   
/*     */   public void configureFromLongCreator(AnnotatedWithParams creator) {
/* 159 */     this._fromLongCreator = creator;
/*     */   }
/*     */   public void configureFromBigIntegerCreator(AnnotatedWithParams creator) {
/* 162 */     this._fromBigIntegerCreator = creator;
/*     */   }
/*     */   public void configureFromDoubleCreator(AnnotatedWithParams creator) {
/* 165 */     this._fromDoubleCreator = creator;
/*     */   }
/*     */   public void configureFromBigDecimalCreator(AnnotatedWithParams creator) {
/* 168 */     this._fromBigDecimalCreator = creator;
/*     */   }
/*     */   public void configureFromBooleanCreator(AnnotatedWithParams creator) {
/* 171 */     this._fromBooleanCreator = creator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValueTypeDesc() {
/* 182 */     return this._valueTypeDesc;
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> getValueClass() {
/* 187 */     return this._valueClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCreateFromString() {
/* 192 */     return (this._fromStringCreator != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCreateFromInt() {
/* 197 */     return (this._fromIntCreator != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCreateFromLong() {
/* 202 */     return (this._fromLongCreator != null);
/*     */   }
/*     */   
/*     */   public boolean canCreateFromBigInteger() {
/* 206 */     return (this._fromBigIntegerCreator != null);
/*     */   }
/*     */   
/*     */   public boolean canCreateFromDouble() {
/* 210 */     return (this._fromDoubleCreator != null);
/*     */   }
/*     */   
/*     */   public boolean canCreateFromBigDecimal() {
/* 214 */     return (this._fromBigDecimalCreator != null);
/*     */   }
/*     */   
/*     */   public boolean canCreateFromBoolean() {
/* 218 */     return (this._fromBooleanCreator != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCreateUsingDefault() {
/* 223 */     return (this._defaultCreator != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCreateUsingDelegate() {
/* 228 */     return (this._delegateType != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCreateUsingArrayDelegate() {
/* 233 */     return (this._arrayDelegateType != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canCreateFromObjectWith() {
/* 238 */     return (this._withArgsCreator != null);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canInstantiate() {
/* 243 */     return (canCreateUsingDefault() || 
/* 244 */       canCreateUsingDelegate() || canCreateUsingArrayDelegate() || 
/* 245 */       canCreateFromObjectWith() || canCreateFromString() || 
/* 246 */       canCreateFromInt() || canCreateFromLong() || 
/* 247 */       canCreateFromDouble() || canCreateFromBoolean());
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType getDelegateType(DeserializationConfig config) {
/* 252 */     return this._delegateType;
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType getArrayDelegateType(DeserializationConfig config) {
/* 257 */     return this._arrayDelegateType;
/*     */   }
/*     */ 
/*     */   
/*     */   public SettableBeanProperty[] getFromObjectArguments(DeserializationConfig config) {
/* 262 */     return this._constructorArguments;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createUsingDefault(DeserializationContext ctxt) throws IOException {
/* 274 */     if (this._defaultCreator == null) {
/* 275 */       return super.createUsingDefault(ctxt);
/*     */     }
/*     */     try {
/* 278 */       return this._defaultCreator.call();
/* 279 */     } catch (Exception e) {
/* 280 */       return ctxt.handleInstantiationProblem(this._valueClass, null, (Throwable)rewrapCtorProblem(ctxt, e));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createFromObjectWith(DeserializationContext ctxt, Object[] args) throws IOException {
/* 287 */     if (this._withArgsCreator == null) {
/* 288 */       return super.createFromObjectWith(ctxt, args);
/*     */     }
/*     */     try {
/* 291 */       return this._withArgsCreator.call(args);
/* 292 */     } catch (Exception e) {
/* 293 */       return ctxt.handleInstantiationProblem(this._valueClass, args, (Throwable)rewrapCtorProblem(ctxt, e));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Object createUsingDefaultOrWithoutArguments(DeserializationContext ctxt) throws IOException {
/* 299 */     if (this._defaultCreator != null) {
/* 300 */       return createUsingDefault(ctxt);
/*     */     }
/* 302 */     if (this._withArgsCreator != null) {
/* 303 */       return createFromObjectWith(ctxt, new Object[this._constructorArguments.length]);
/*     */     }
/* 305 */     return super.createUsingDefaultOrWithoutArguments(ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createUsingDelegate(DeserializationContext ctxt, Object delegate) throws IOException {
/* 312 */     if (this._delegateCreator == null && 
/* 313 */       this._arrayDelegateCreator != null) {
/* 314 */       return _createUsingDelegate(this._arrayDelegateCreator, this._arrayDelegateArguments, ctxt, delegate);
/*     */     }
/*     */     
/* 317 */     return _createUsingDelegate(this._delegateCreator, this._delegateArguments, ctxt, delegate);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createUsingArrayDelegate(DeserializationContext ctxt, Object delegate) throws IOException {
/* 323 */     if (this._arrayDelegateCreator == null && 
/* 324 */       this._delegateCreator != null)
/*     */     {
/* 326 */       return createUsingDelegate(ctxt, delegate);
/*     */     }
/*     */     
/* 329 */     return _createUsingDelegate(this._arrayDelegateCreator, this._arrayDelegateArguments, ctxt, delegate);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createFromString(DeserializationContext ctxt, String value) throws IOException {
/* 341 */     if (this._fromStringCreator != null) {
/*     */       try {
/* 343 */         return this._fromStringCreator.call1(value);
/* 344 */       } catch (Exception t) {
/* 345 */         return ctxt.handleInstantiationProblem(this._fromStringCreator.getDeclaringClass(), value, (Throwable)
/* 346 */             rewrapCtorProblem(ctxt, t));
/*     */       } 
/*     */     }
/* 349 */     return super.createFromString(ctxt, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createFromInt(DeserializationContext ctxt, int value) throws IOException {
/* 356 */     if (this._fromIntCreator != null) {
/* 357 */       Object arg = Integer.valueOf(value);
/*     */       try {
/* 359 */         return this._fromIntCreator.call1(arg);
/* 360 */       } catch (Exception t0) {
/* 361 */         return ctxt.handleInstantiationProblem(this._fromIntCreator.getDeclaringClass(), arg, (Throwable)
/* 362 */             rewrapCtorProblem(ctxt, t0));
/*     */       } 
/*     */     } 
/*     */     
/* 366 */     if (this._fromLongCreator != null) {
/* 367 */       Object arg = Long.valueOf(value);
/*     */       try {
/* 369 */         return this._fromLongCreator.call1(arg);
/* 370 */       } catch (Exception t0) {
/* 371 */         return ctxt.handleInstantiationProblem(this._fromLongCreator.getDeclaringClass(), arg, (Throwable)
/* 372 */             rewrapCtorProblem(ctxt, t0));
/*     */       } 
/*     */     } 
/*     */     
/* 376 */     if (this._fromBigIntegerCreator != null) {
/* 377 */       Object arg = BigInteger.valueOf(value);
/*     */       try {
/* 379 */         return this._fromBigIntegerCreator.call1(arg);
/* 380 */       } catch (Exception t0) {
/* 381 */         return ctxt.handleInstantiationProblem(this._fromBigIntegerCreator.getDeclaringClass(), arg, (Throwable)
/* 382 */             rewrapCtorProblem(ctxt, t0));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 387 */     if (this._fromDoubleCreator != null) {
/* 388 */       Object arg = Double.valueOf(value);
/*     */       try {
/* 390 */         return this._fromDoubleCreator.call1(arg);
/* 391 */       } catch (Exception t0) {
/* 392 */         return ctxt.handleInstantiationProblem(this._fromDoubleCreator.getDeclaringClass(), arg, (Throwable)
/* 393 */             rewrapCtorProblem(ctxt, t0));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 398 */     return super.createFromInt(ctxt, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createFromLong(DeserializationContext ctxt, long value) throws IOException {
/* 404 */     if (this._fromLongCreator != null) {
/* 405 */       Long arg = Long.valueOf(value);
/*     */       try {
/* 407 */         return this._fromLongCreator.call1(arg);
/* 408 */       } catch (Exception t0) {
/* 409 */         return ctxt.handleInstantiationProblem(this._fromLongCreator.getDeclaringClass(), arg, (Throwable)
/* 410 */             rewrapCtorProblem(ctxt, t0));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 415 */     if (this._fromBigIntegerCreator != null) {
/* 416 */       BigInteger arg = BigInteger.valueOf(value);
/*     */       try {
/* 418 */         return this._fromBigIntegerCreator.call1(arg);
/* 419 */       } catch (Exception t0) {
/* 420 */         return ctxt.handleInstantiationProblem(this._fromBigIntegerCreator.getDeclaringClass(), arg, (Throwable)
/* 421 */             rewrapCtorProblem(ctxt, t0));
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 428 */     if (this._fromDoubleCreator != null) {
/* 429 */       Object arg = Double.valueOf(value);
/*     */       try {
/* 431 */         return this._fromDoubleCreator.call1(arg);
/* 432 */       } catch (Exception t0) {
/* 433 */         return ctxt.handleInstantiationProblem(this._fromDoubleCreator.getDeclaringClass(), arg, (Throwable)
/* 434 */             rewrapCtorProblem(ctxt, t0));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 439 */     return super.createFromLong(ctxt, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createFromBigInteger(DeserializationContext ctxt, BigInteger value) throws IOException {
/* 445 */     if (this._fromBigIntegerCreator != null) {
/*     */       try {
/* 447 */         return this._fromBigIntegerCreator.call1(value);
/* 448 */       } catch (Exception t) {
/* 449 */         return ctxt.handleInstantiationProblem(this._fromBigIntegerCreator.getDeclaringClass(), value, (Throwable)
/* 450 */             rewrapCtorProblem(ctxt, t));
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 455 */     return super.createFromBigInteger(ctxt, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createFromDouble(DeserializationContext ctxt, double value) throws IOException {
/* 461 */     if (this._fromDoubleCreator != null) {
/* 462 */       Double arg = Double.valueOf(value);
/*     */       try {
/* 464 */         return this._fromDoubleCreator.call1(arg);
/* 465 */       } catch (Exception t0) {
/* 466 */         return ctxt.handleInstantiationProblem(this._fromDoubleCreator.getDeclaringClass(), arg, (Throwable)
/* 467 */             rewrapCtorProblem(ctxt, t0));
/*     */       } 
/*     */     } 
/*     */     
/* 471 */     if (this._fromBigDecimalCreator != null) {
/* 472 */       BigDecimal arg = BigDecimal.valueOf(value);
/*     */       try {
/* 474 */         return this._fromBigDecimalCreator.call1(arg);
/* 475 */       } catch (Exception t0) {
/* 476 */         return ctxt.handleInstantiationProblem(this._fromBigDecimalCreator.getDeclaringClass(), arg, (Throwable)
/* 477 */             rewrapCtorProblem(ctxt, t0));
/*     */       } 
/*     */     } 
/*     */     
/* 481 */     return super.createFromDouble(ctxt, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createFromBigDecimal(DeserializationContext ctxt, BigDecimal value) throws IOException {
/* 487 */     if (this._fromBigDecimalCreator != null) {
/*     */       try {
/* 489 */         return this._fromBigDecimalCreator.call1(value);
/* 490 */       } catch (Exception t) {
/* 491 */         return ctxt.handleInstantiationProblem(this._fromBigDecimalCreator.getDeclaringClass(), value, (Throwable)
/* 492 */             rewrapCtorProblem(ctxt, t));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 501 */     if (this._fromDoubleCreator != null) {
/* 502 */       Double dbl = tryConvertToDouble(value);
/* 503 */       if (dbl != null) {
/*     */         try {
/* 505 */           return this._fromDoubleCreator.call1(dbl);
/* 506 */         } catch (Exception t0) {
/* 507 */           return ctxt.handleInstantiationProblem(this._fromDoubleCreator.getDeclaringClass(), dbl, (Throwable)
/* 508 */               rewrapCtorProblem(ctxt, t0));
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 513 */     return super.createFromBigDecimal(ctxt, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Double tryConvertToDouble(BigDecimal value) {
/* 521 */     double doubleValue = value.doubleValue();
/* 522 */     return Double.isInfinite(doubleValue) ? null : Double.valueOf(doubleValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createFromBoolean(DeserializationContext ctxt, boolean value) throws IOException {
/* 528 */     if (this._fromBooleanCreator == null) {
/* 529 */       return super.createFromBoolean(ctxt, value);
/*     */     }
/* 531 */     Boolean arg = Boolean.valueOf(value);
/*     */     try {
/* 533 */       return this._fromBooleanCreator.call1(arg);
/* 534 */     } catch (Exception t0) {
/* 535 */       return ctxt.handleInstantiationProblem(this._fromBooleanCreator.getDeclaringClass(), arg, (Throwable)
/* 536 */           rewrapCtorProblem(ctxt, t0));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AnnotatedWithParams getDelegateCreator() {
/* 548 */     return this._delegateCreator;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedWithParams getArrayDelegateCreator() {
/* 553 */     return this._arrayDelegateCreator;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedWithParams getDefaultCreator() {
/* 558 */     return this._defaultCreator;
/*     */   }
/*     */ 
/*     */   
/*     */   public AnnotatedWithParams getWithArgsCreator() {
/* 563 */     return this._withArgsCreator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected JsonMappingException wrapException(Throwable t) {
/* 581 */     for (Throwable curr = t; curr != null; curr = curr.getCause()) {
/* 582 */       if (curr instanceof JsonMappingException) {
/* 583 */         return (JsonMappingException)curr;
/*     */       }
/*     */     } 
/* 586 */     return new JsonMappingException(null, "Instantiation of " + 
/* 587 */         getValueTypeDesc() + " value failed: " + ClassUtil.exceptionMessage(t), t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected JsonMappingException unwrapAndWrapException(DeserializationContext ctxt, Throwable t) {
/* 599 */     for (Throwable curr = t; curr != null; curr = curr.getCause()) {
/* 600 */       if (curr instanceof JsonMappingException) {
/* 601 */         return (JsonMappingException)curr;
/*     */       }
/*     */     } 
/* 604 */     return ctxt.instantiationException(getValueClass(), t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonMappingException wrapAsJsonMappingException(DeserializationContext ctxt, Throwable t) {
/* 619 */     if (t instanceof JsonMappingException) {
/* 620 */       return (JsonMappingException)t;
/*     */     }
/* 622 */     return ctxt.instantiationException(getValueClass(), t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonMappingException rewrapCtorProblem(DeserializationContext ctxt, Throwable t) {
/* 637 */     if (t instanceof ExceptionInInitializerError || t instanceof java.lang.reflect.InvocationTargetException) {
/*     */ 
/*     */       
/* 640 */       Throwable cause = t.getCause();
/* 641 */       if (cause != null) {
/* 642 */         t = cause;
/*     */       }
/*     */     } 
/* 645 */     return wrapAsJsonMappingException(ctxt, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object _createUsingDelegate(AnnotatedWithParams delegateCreator, SettableBeanProperty[] delegateArguments, DeserializationContext ctxt, Object delegate) throws IOException {
/* 660 */     if (delegateCreator == null) {
/* 661 */       throw new IllegalStateException("No delegate constructor for " + getValueTypeDesc());
/*     */     }
/*     */     
/*     */     try {
/* 665 */       if (delegateArguments == null) {
/* 666 */         return delegateCreator.call1(delegate);
/*     */       }
/*     */       
/* 669 */       int len = delegateArguments.length;
/* 670 */       Object[] args = new Object[len];
/* 671 */       for (int i = 0; i < len; i++) {
/* 672 */         SettableBeanProperty prop = delegateArguments[i];
/* 673 */         if (prop == null) {
/* 674 */           args[i] = delegate;
/*     */         } else {
/* 676 */           args[i] = ctxt.findInjectableValue(prop.getInjectableValueId(), (BeanProperty)prop, null);
/*     */         } 
/*     */       } 
/*     */       
/* 680 */       return delegateCreator.call(args);
/* 681 */     } catch (Exception t) {
/* 682 */       throw rewrapCtorProblem(ctxt, t);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\StdValueInstantiator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */