/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.io.NumberInput;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.KeyDeserializer;
/*     */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*     */ import com.fasterxml.jackson.databind.cfg.DatatypeFeature;
/*     */ import com.fasterxml.jackson.databind.cfg.EnumFeature;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.EnumResolver;
/*     */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.Calendar;
/*     */ import java.util.Currency;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @JacksonStdImpl
/*     */ public class StdKeyDeserializer
/*     */   extends KeyDeserializer
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final int TYPE_BOOLEAN = 1;
/*     */   public static final int TYPE_BYTE = 2;
/*     */   public static final int TYPE_SHORT = 3;
/*     */   public static final int TYPE_CHAR = 4;
/*     */   public static final int TYPE_INT = 5;
/*     */   public static final int TYPE_LONG = 6;
/*     */   public static final int TYPE_FLOAT = 7;
/*     */   public static final int TYPE_DOUBLE = 8;
/*     */   public static final int TYPE_LOCALE = 9;
/*     */   public static final int TYPE_DATE = 10;
/*     */   public static final int TYPE_CALENDAR = 11;
/*     */   public static final int TYPE_UUID = 12;
/*     */   public static final int TYPE_URI = 13;
/*     */   public static final int TYPE_URL = 14;
/*     */   public static final int TYPE_CLASS = 15;
/*     */   public static final int TYPE_CURRENCY = 16;
/*     */   public static final int TYPE_BYTE_ARRAY = 17;
/*     */   protected final int _kind;
/*     */   protected final Class<?> _keyClass;
/*     */   protected final FromStringDeserializer<?> _deser;
/*     */   
/*     */   protected StdKeyDeserializer(int kind, Class<?> cls) {
/*  62 */     this(kind, cls, null);
/*     */   }
/*     */   
/*     */   protected StdKeyDeserializer(int kind, Class<?> cls, FromStringDeserializer<?> deser) {
/*  66 */     this._kind = kind;
/*  67 */     this._keyClass = cls;
/*  68 */     this._deser = deser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StdKeyDeserializer forType(Class<?> raw) {
/*     */     int kind;
/*  76 */     if (raw == String.class || raw == Object.class || raw == CharSequence.class || raw == Serializable.class)
/*     */     {
/*     */ 
/*     */       
/*  80 */       return StringKD.forType(raw);
/*     */     }
/*  82 */     if (raw == UUID.class)
/*  83 */     { kind = 12; }
/*  84 */     else if (raw == Integer.class)
/*  85 */     { kind = 5; }
/*  86 */     else if (raw == Long.class)
/*  87 */     { kind = 6; }
/*  88 */     else if (raw == Date.class)
/*  89 */     { kind = 10; }
/*  90 */     else if (raw == Calendar.class)
/*  91 */     { kind = 11; }
/*     */     
/*  93 */     else if (raw == Boolean.class)
/*  94 */     { kind = 1; }
/*  95 */     else if (raw == Byte.class)
/*  96 */     { kind = 2; }
/*  97 */     else if (raw == Character.class)
/*  98 */     { kind = 4; }
/*  99 */     else if (raw == Short.class)
/* 100 */     { kind = 3; }
/* 101 */     else if (raw == Float.class)
/* 102 */     { kind = 7; }
/* 103 */     else if (raw == Double.class)
/* 104 */     { kind = 8; }
/* 105 */     else if (raw == URI.class)
/* 106 */     { kind = 13; }
/* 107 */     else if (raw == URL.class)
/* 108 */     { kind = 14; }
/* 109 */     else if (raw == Class.class)
/* 110 */     { kind = 15; }
/* 111 */     else { if (raw == Locale.class) {
/* 112 */         FromStringDeserializer<?> deser = FromStringDeserializer.findDeserializer(Locale.class);
/* 113 */         return new StdKeyDeserializer(9, raw, deser);
/* 114 */       }  if (raw == Currency.class) {
/* 115 */         FromStringDeserializer<?> deser = FromStringDeserializer.findDeserializer(Currency.class);
/* 116 */         return new StdKeyDeserializer(16, raw, deser);
/* 117 */       }  if (raw == byte[].class) {
/* 118 */         kind = 17;
/*     */       } else {
/* 120 */         return null;
/*     */       }  }
/* 122 */      return new StdKeyDeserializer(kind, raw);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeKey(String key, DeserializationContext ctxt) throws IOException {
/* 129 */     if (key == null) {
/* 130 */       return null;
/*     */     }
/*     */     try {
/* 133 */       Object result = _parse(key, ctxt);
/* 134 */       if (result != null) {
/* 135 */         return result;
/*     */       }
/* 137 */     } catch (Exception re) {
/* 138 */       return ctxt.handleWeirdKey(this._keyClass, key, "not a valid representation, problem: (%s) %s", new Object[] { re
/* 139 */             .getClass().getName(), 
/* 140 */             ClassUtil.exceptionMessage(re) });
/*     */     } 
/* 142 */     if (ClassUtil.isEnumType(this._keyClass) && ctxt
/* 143 */       .getConfig().isEnabled(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL)) {
/* 144 */       return null;
/*     */     }
/* 146 */     return ctxt.handleWeirdKey(this._keyClass, key, "not a valid representation", new Object[0]);
/*     */   }
/*     */   public Class<?> getKeyClass() {
/* 149 */     return this._keyClass;
/*     */   }
/*     */   protected Object _parse(String key, DeserializationContext ctxt) throws Exception {
/*     */     int value;
/* 153 */     switch (this._kind) {
/*     */       case 1:
/* 155 */         if ("true".equals(key)) {
/* 156 */           return Boolean.TRUE;
/*     */         }
/* 158 */         if ("false".equals(key)) {
/* 159 */           return Boolean.FALSE;
/*     */         }
/* 161 */         return ctxt.handleWeirdKey(this._keyClass, key, "value not 'true' or 'false'", new Object[0]);
/*     */       
/*     */       case 2:
/* 164 */         value = _parseInt(key);
/*     */         
/* 166 */         if (value < -128 || value > 255) {
/* 167 */           return ctxt.handleWeirdKey(this._keyClass, key, "overflow, value cannot be represented as 8-bit value", new Object[0]);
/*     */         }
/* 169 */         return Byte.valueOf((byte)value);
/*     */ 
/*     */       
/*     */       case 3:
/* 173 */         value = _parseInt(key);
/* 174 */         if (value < -32768 || value > 32767) {
/* 175 */           return ctxt.handleWeirdKey(this._keyClass, key, "overflow, value cannot be represented as 16-bit value", new Object[0]);
/*     */         }
/*     */         
/* 178 */         return Short.valueOf((short)value);
/*     */       
/*     */       case 4:
/* 181 */         if (key.length() == 1) {
/* 182 */           return Character.valueOf(key.charAt(0));
/*     */         }
/* 184 */         return ctxt.handleWeirdKey(this._keyClass, key, "can only convert 1-character Strings", new Object[0]);
/*     */       case 5:
/* 186 */         return Integer.valueOf(_parseInt(key));
/*     */       
/*     */       case 6:
/* 189 */         return Long.valueOf(_parseLong(key));
/*     */ 
/*     */       
/*     */       case 7:
/* 193 */         return Float.valueOf((float)_parseDouble(key));
/*     */       case 8:
/* 195 */         return Double.valueOf(_parseDouble(key));
/*     */       case 9:
/*     */       case 16:
/*     */         try {
/* 199 */           return this._deser._deserialize(key, ctxt);
/* 200 */         } catch (IllegalArgumentException e) {
/* 201 */           return _weirdKey(ctxt, key, e);
/*     */         } 
/*     */       case 10:
/* 204 */         return ctxt.parseDate(key);
/*     */       case 11:
/* 206 */         return ctxt.constructCalendar(ctxt.parseDate(key));
/*     */       case 12:
/*     */         try {
/* 209 */           return UUID.fromString(key);
/* 210 */         } catch (Exception e) {
/* 211 */           return _weirdKey(ctxt, key, e);
/*     */         } 
/*     */       case 13:
/*     */         try {
/* 215 */           return URI.create(key);
/* 216 */         } catch (Exception e) {
/* 217 */           return _weirdKey(ctxt, key, e);
/*     */         } 
/*     */       case 14:
/*     */         try {
/* 221 */           return new URL(key);
/* 222 */         } catch (MalformedURLException e) {
/* 223 */           return _weirdKey(ctxt, key, e);
/*     */         } 
/*     */       case 15:
/*     */         try {
/* 227 */           return ctxt.findClass(key);
/* 228 */         } catch (Exception e) {
/* 229 */           return ctxt.handleWeirdKey(this._keyClass, key, "unable to parse key as Class", new Object[0]);
/*     */         } 
/*     */       case 17:
/*     */         try {
/* 233 */           return ctxt.getConfig().getBase64Variant().decode(key);
/* 234 */         } catch (IllegalArgumentException e) {
/* 235 */           return _weirdKey(ctxt, key, e);
/*     */         } 
/*     */     } 
/* 238 */     throw new IllegalStateException("Internal error: unknown key type " + this._keyClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _parseInt(String key) throws IllegalArgumentException {
/* 249 */     return NumberInput.parseInt(key);
/*     */   }
/*     */   
/*     */   protected long _parseLong(String key) throws IllegalArgumentException {
/* 253 */     return NumberInput.parseLong(key);
/*     */   }
/*     */   
/*     */   protected double _parseDouble(String key) throws IllegalArgumentException {
/* 257 */     return NumberInput.parseDouble(key, false);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object _weirdKey(DeserializationContext ctxt, String key, Exception e) throws IOException {
/* 262 */     return ctxt.handleWeirdKey(this._keyClass, key, "problem: %s", new Object[] {
/* 263 */           ClassUtil.exceptionMessage(e)
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @JacksonStdImpl
/*     */   static final class StringKD
/*     */     extends StdKeyDeserializer
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/* 276 */     private static final StringKD sString = new StringKD(String.class);
/* 277 */     private static final StringKD sObject = new StringKD(Object.class);
/*     */     private StringKD(Class<?> nominalType) {
/* 279 */       super(-1, nominalType);
/*     */     }
/*     */     
/*     */     public static StringKD forType(Class<?> nominalType) {
/* 283 */       if (nominalType == String.class) {
/* 284 */         return sString;
/*     */       }
/* 286 */       if (nominalType == Object.class) {
/* 287 */         return sObject;
/*     */       }
/* 289 */       return new StringKD(nominalType);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object deserializeKey(String key, DeserializationContext ctxt) throws IOException {
/* 294 */       return key;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class DelegatingKD
/*     */     extends KeyDeserializer
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final Class<?> _keyClass;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final JsonDeserializer<?> _delegate;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected DelegatingKD(Class<?> cls, JsonDeserializer<?> deser) {
/* 320 */       this._keyClass = cls;
/* 321 */       this._delegate = deser;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Object deserializeKey(String key, DeserializationContext ctxt) throws IOException {
/* 329 */       if (key == null) {
/* 330 */         return null;
/*     */       }
/* 332 */       TokenBuffer tb = ctxt.bufferForInputBuffering();
/* 333 */       tb.writeString(key);
/*     */       
/*     */       try {
/* 336 */         JsonParser p = tb.asParser();
/* 337 */         p.nextToken();
/* 338 */         Object result = this._delegate.deserialize(p, ctxt);
/* 339 */         if (result != null) {
/* 340 */           return result;
/*     */         }
/* 342 */         return ctxt.handleWeirdKey(this._keyClass, key, "not a valid representation", new Object[0]);
/* 343 */       } catch (Exception re) {
/* 344 */         return ctxt.handleWeirdKey(this._keyClass, key, "not a valid representation: %s", new Object[] { re.getMessage() });
/*     */       } 
/*     */     }
/*     */     public Class<?> getKeyClass() {
/* 348 */       return this._keyClass;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @JacksonStdImpl
/*     */   static final class EnumKD
/*     */     extends StdKeyDeserializer
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final EnumResolver _byNameResolver;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final AnnotatedMethod _factory;
/*     */ 
/*     */ 
/*     */     
/*     */     protected volatile EnumResolver _byToStringResolver;
/*     */ 
/*     */ 
/*     */     
/*     */     protected volatile EnumResolver _byIndexResolver;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final EnumResolver _byEnumNamingResolver;
/*     */ 
/*     */ 
/*     */     
/*     */     protected final Enum<?> _enumDefaultValue;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected EnumKD(EnumResolver er, AnnotatedMethod factory) {
/* 390 */       super(-1, er.getEnumClass());
/* 391 */       this._byNameResolver = er;
/* 392 */       this._factory = factory;
/* 393 */       this._enumDefaultValue = er.getDefaultValue();
/* 394 */       this._byEnumNamingResolver = null;
/* 395 */       this._byToStringResolver = null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected EnumKD(EnumResolver er, AnnotatedMethod factory, EnumResolver byEnumNamingResolver, EnumResolver byToStringResolver, EnumResolver byIndexResolver) {
/* 404 */       super(-1, er.getEnumClass());
/* 405 */       this._byNameResolver = er;
/* 406 */       this._factory = factory;
/* 407 */       this._enumDefaultValue = er.getDefaultValue();
/* 408 */       this._byEnumNamingResolver = byEnumNamingResolver;
/* 409 */       this._byToStringResolver = byToStringResolver;
/* 410 */       this._byIndexResolver = byIndexResolver;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object _parse(String key, DeserializationContext ctxt) throws IOException {
/* 417 */       if (this._factory != null) {
/*     */         try {
/* 419 */           return this._factory.call1(key);
/* 420 */         } catch (Exception exception) {
/* 421 */           ClassUtil.unwrapAndThrowAsIAE(exception);
/*     */         } 
/*     */       }
/*     */       
/* 425 */       EnumResolver res = _resolveCurrentResolver(ctxt);
/* 426 */       Enum<?> e = res.findEnum(key);
/*     */       
/* 428 */       if (e == null && ctxt.isEnabled((DatatypeFeature)EnumFeature.READ_ENUM_KEYS_USING_INDEX)) {
/* 429 */         res = _getIndexResolver(ctxt);
/* 430 */         e = res.findEnum(key);
/*     */       } 
/* 432 */       if (e == null) {
/* 433 */         if (this._enumDefaultValue != null && ctxt
/* 434 */           .isEnabled(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_USING_DEFAULT_VALUE)) {
/* 435 */           e = this._enumDefaultValue;
/* 436 */         } else if (!ctxt.isEnabled(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL)) {
/* 437 */           return ctxt.handleWeirdKey(this._keyClass, key, "not one of the values accepted for Enum class: %s", new Object[] { res
/* 438 */                 .getEnumIds() });
/*     */         } 
/*     */       }
/*     */       
/* 442 */       return e;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected EnumResolver _resolveCurrentResolver(DeserializationContext ctxt) {
/* 449 */       if (this._byEnumNamingResolver != null) {
/* 450 */         return this._byEnumNamingResolver;
/*     */       }
/* 452 */       return ctxt.isEnabled(DeserializationFeature.READ_ENUMS_USING_TO_STRING) ? 
/* 453 */         _getToStringResolver(ctxt) : this._byNameResolver;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     private EnumResolver _getToStringResolver(DeserializationContext ctxt) {
/* 467 */       EnumResolver res = this._byToStringResolver;
/* 468 */       if (res == null) {
/* 469 */         synchronized (this) {
/* 470 */           res = this._byToStringResolver;
/* 471 */           if (res == null) {
/* 472 */             res = EnumResolver.constructUsingToString(ctxt.getConfig(), this._byNameResolver
/* 473 */                 .getEnumClass());
/* 474 */             this._byToStringResolver = res;
/*     */           } 
/*     */         } 
/*     */       }
/* 478 */       return res;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     private EnumResolver _getIndexResolver(DeserializationContext ctxt) {
/* 490 */       EnumResolver res = this._byIndexResolver;
/* 491 */       if (res == null) {
/* 492 */         synchronized (this) {
/* 493 */           res = this._byIndexResolver;
/* 494 */           if (res == null) {
/* 495 */             res = EnumResolver.constructUsingIndex(ctxt.getConfig(), this._byNameResolver
/* 496 */                 .getEnumClass());
/* 497 */             this._byIndexResolver = res;
/*     */           } 
/*     */         } 
/*     */       }
/* 501 */       return res;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class StringCtorKeyDeserializer
/*     */     extends StdKeyDeserializer
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     protected final Constructor<?> _ctor;
/*     */ 
/*     */     
/*     */     public StringCtorKeyDeserializer(Constructor<?> ctor) {
/* 516 */       super(-1, ctor.getDeclaringClass());
/* 517 */       this._ctor = ctor;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object _parse(String key, DeserializationContext ctxt) throws Exception {
/* 523 */       return this._ctor.newInstance(new Object[] { key });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class StringFactoryKeyDeserializer
/*     */     extends StdKeyDeserializer
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     final Method _factoryMethod;
/*     */ 
/*     */     
/*     */     public StringFactoryKeyDeserializer(Method fm) {
/* 538 */       super(-1, fm.getDeclaringClass());
/* 539 */       this._factoryMethod = fm;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object _parse(String key, DeserializationContext ctxt) throws Exception {
/* 545 */       return this._factoryMethod.invoke(null, new Object[] { key });
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\StdKeyDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */