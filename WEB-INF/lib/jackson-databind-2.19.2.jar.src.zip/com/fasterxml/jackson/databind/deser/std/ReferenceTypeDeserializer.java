/*     */ package com.fasterxml.jackson.databind.deser.std;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.ValueInstantiator;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.util.AccessPattern;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ReferenceTypeDeserializer<T>
/*     */   extends StdDeserializer<T>
/*     */   implements ContextualDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   protected final JavaType _fullType;
/*     */   protected final ValueInstantiator _valueInstantiator;
/*     */   protected final TypeDeserializer _valueTypeDeserializer;
/*     */   protected final JsonDeserializer<Object> _valueDeserializer;
/*     */   
/*     */   public ReferenceTypeDeserializer(JavaType fullType, ValueInstantiator vi, TypeDeserializer typeDeser, JsonDeserializer<?> deser) {
/*  49 */     super(fullType);
/*  50 */     this._valueInstantiator = vi;
/*  51 */     this._fullType = fullType;
/*  52 */     this._valueDeserializer = (JsonDeserializer)deser;
/*  53 */     this._valueTypeDeserializer = typeDeser;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ReferenceTypeDeserializer(JavaType fullType, TypeDeserializer typeDeser, JsonDeserializer<?> deser) {
/*  60 */     this(fullType, null, typeDeser, deser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
/*  67 */     JsonDeserializer<?> deser = this._valueDeserializer;
/*     */     
/*  69 */     deser = findConvertingContentDeserializer(ctxt, property, deser);
/*  70 */     if (deser == null) {
/*  71 */       deser = ctxt.findContextualValueDeserializer(this._fullType.getReferencedType(), property);
/*     */     } else {
/*  73 */       deser = ctxt.handleSecondaryContextualization(deser, property, this._fullType.getReferencedType());
/*     */     } 
/*     */     
/*  76 */     TypeDeserializer typeDeser = this._valueTypeDeserializer;
/*  77 */     if (typeDeser != null) {
/*  78 */       typeDeser = typeDeser.forProperty(property);
/*     */     }
/*     */     
/*  81 */     if (deser == this._valueDeserializer && typeDeser == this._valueTypeDeserializer) {
/*  82 */       return this;
/*     */     }
/*  84 */     return withResolved(typeDeser, deser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AccessPattern getNullAccessPattern() {
/*  99 */     return AccessPattern.DYNAMIC;
/*     */   }
/*     */ 
/*     */   
/*     */   public AccessPattern getEmptyAccessPattern() {
/* 104 */     return AccessPattern.DYNAMIC;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract ReferenceTypeDeserializer<T> withResolved(TypeDeserializer paramTypeDeserializer, JsonDeserializer<?> paramJsonDeserializer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract T getNullValue(DeserializationContext paramDeserializationContext) throws JsonMappingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getEmptyValue(DeserializationContext ctxt) throws JsonMappingException {
/* 128 */     return getNullValue(ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract T referenceValue(Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract T updateReference(T paramT, Object paramObject);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Object getReferenced(T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ValueInstantiator getValueInstantiator() {
/* 166 */     return this._valueInstantiator;
/*     */   }
/*     */   public JavaType getValueType() {
/* 169 */     return this._fullType;
/*     */   }
/*     */   
/*     */   public LogicalType logicalType() {
/* 173 */     if (this._valueDeserializer != null) {
/* 174 */       return this._valueDeserializer.logicalType();
/*     */     }
/* 176 */     return super.logicalType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean supportsUpdate(DeserializationConfig config) {
/* 186 */     return (this._valueDeserializer == null) ? null : this._valueDeserializer
/* 187 */       .supportsUpdate(config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 200 */     if (this._valueInstantiator != null) {
/*     */       
/* 202 */       T value = (T)this._valueInstantiator.createUsingDefault(ctxt);
/* 203 */       return deserialize(p, ctxt, value);
/*     */     } 
/*     */ 
/*     */     
/* 207 */     Object contents = (this._valueTypeDeserializer == null) ? this._valueDeserializer.deserialize(p, ctxt) : this._valueDeserializer.deserializeWithType(p, ctxt, this._valueTypeDeserializer);
/* 208 */     return referenceValue(contents);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T deserialize(JsonParser p, DeserializationContext ctxt, T reference) throws IOException {
/*     */     Object contents;
/* 216 */     Boolean B = this._valueDeserializer.supportsUpdate(ctxt.getConfig());
/*     */     
/* 218 */     if (B.equals(Boolean.FALSE) || this._valueTypeDeserializer != null) {
/*     */ 
/*     */       
/* 221 */       contents = (this._valueTypeDeserializer == null) ? this._valueDeserializer.deserialize(p, ctxt) : this._valueDeserializer.deserializeWithType(p, ctxt, this._valueTypeDeserializer);
/*     */     } else {
/*     */       
/* 224 */       contents = getReferenced(reference);
/*     */       
/* 226 */       if (contents == null) {
/*     */ 
/*     */         
/* 229 */         contents = (this._valueTypeDeserializer == null) ? this._valueDeserializer.deserialize(p, ctxt) : this._valueDeserializer.deserializeWithType(p, ctxt, this._valueTypeDeserializer);
/* 230 */         return referenceValue(contents);
/*     */       } 
/* 232 */       contents = this._valueDeserializer.deserialize(p, ctxt, contents);
/*     */     } 
/*     */     
/* 235 */     return updateReference(reference, contents);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeWithType(JsonParser p, DeserializationContext ctxt, TypeDeserializer typeDeserializer) throws IOException {
/* 242 */     if (p.hasToken(JsonToken.VALUE_NULL)) {
/* 243 */       return getNullValue(ctxt);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 257 */     if (this._valueTypeDeserializer == null) {
/* 258 */       return deserialize(p, ctxt);
/*     */     }
/* 260 */     return referenceValue(this._valueTypeDeserializer.deserializeTypedFromAny(p, ctxt));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\std\ReferenceTypeDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */