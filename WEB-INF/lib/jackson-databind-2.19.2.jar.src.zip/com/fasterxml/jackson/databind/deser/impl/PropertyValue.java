/*     */ package com.fasterxml.jackson.databind.deser.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.deser.SettableAnyProperty;
/*     */ import com.fasterxml.jackson.databind.deser.SettableBeanProperty;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PropertyValue
/*     */ {
/*     */   public final PropertyValue next;
/*     */   public final Object value;
/*     */   
/*     */   protected PropertyValue(PropertyValue next, Object value) {
/*  23 */     this.next = next;
/*  24 */     this.value = value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void assign(Object paramObject) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(Object parameterObject) throws IOException {
/*  43 */     throw new UnsupportedOperationException("Should not be called by this type " + getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class Regular
/*     */     extends PropertyValue
/*     */   {
/*     */     final SettableBeanProperty _property;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Regular(PropertyValue next, Object value, SettableBeanProperty prop) {
/*  64 */       super(next, value);
/*  65 */       this._property = prop;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void assign(Object bean) throws IOException {
/*  72 */       this._property.set(bean, this.value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class Any
/*     */     extends PropertyValue
/*     */   {
/*     */     final SettableAnyProperty _property;
/*     */ 
/*     */ 
/*     */     
/*     */     final String _propertyName;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Any(PropertyValue next, Object value, SettableAnyProperty prop, String propName) {
/*  92 */       super(next, value);
/*  93 */       this._property = prop;
/*  94 */       this._propertyName = propName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void assign(Object bean) throws IOException {
/* 101 */       this._property.set(bean, this._propertyName, this.value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class Map
/*     */     extends PropertyValue
/*     */   {
/*     */     final Object _key;
/*     */ 
/*     */ 
/*     */     
/*     */     public Map(PropertyValue next, Object value, Object key) {
/* 116 */       super(next, value);
/* 117 */       this._key = key;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void assign(Object bean) throws IOException {
/* 125 */       ((java.util.Map<Object, Object>)bean).put(this._key, this.value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class AnyParameter
/*     */     extends PropertyValue
/*     */   {
/*     */     final SettableAnyProperty _property;
/*     */ 
/*     */ 
/*     */     
/*     */     final String _propertyName;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public AnyParameter(PropertyValue next, Object value, SettableAnyProperty prop, String propName) {
/* 145 */       super(next, value);
/* 146 */       this._property = prop;
/* 147 */       this._propertyName = propName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void assign(Object bean) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setValue(Object parameterObject) throws IOException {
/* 163 */       this._property.set(parameterObject, this._propertyName, this.value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\impl\PropertyValue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */