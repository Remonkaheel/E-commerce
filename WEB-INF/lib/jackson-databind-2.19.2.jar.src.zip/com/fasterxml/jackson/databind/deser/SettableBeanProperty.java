/*     */ package com.fasterxml.jackson.databind.deser;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.PropertyMetadata;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.deser.impl.FailingDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.impl.NullsConstantProvider;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMember;
/*     */ import com.fasterxml.jackson.databind.introspect.BeanPropertyDefinition;
/*     */ import com.fasterxml.jackson.databind.introspect.ConcreteBeanPropertyBase;
/*     */ import com.fasterxml.jackson.databind.introspect.ObjectIdInfo;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonObjectFormatVisitor;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.util.Annotations;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.NameTransformer;
/*     */ import com.fasterxml.jackson.databind.util.ViewMatcher;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SettableBeanProperty
/*     */   extends ConcreteBeanPropertyBase
/*     */   implements Serializable
/*     */ {
/*  36 */   protected static final JsonDeserializer<Object> MISSING_VALUE_DESERIALIZER = (JsonDeserializer<Object>)new FailingDeserializer("No _valueDeserializer assigned");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final PropertyName _propName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JavaType _type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final PropertyName _wrapperName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final transient Annotations _contextAnnotations;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonDeserializer<Object> _valueDeserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final TypeDeserializer _valueTypeDeserializer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final NullValueProvider _nullProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String _managedReferenceName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectIdInfo _objectIdInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ViewMatcher _viewMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _propertyIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SettableBeanProperty(BeanPropertyDefinition propDef, JavaType type, TypeDeserializer typeDeser, Annotations contextAnnotations) {
/* 136 */     this(propDef.getFullName(), type, propDef.getWrapperName(), typeDeser, contextAnnotations, propDef
/* 137 */         .getMetadata());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SettableBeanProperty(PropertyName propName, JavaType type, PropertyName wrapper, TypeDeserializer typeDeser, Annotations contextAnnotations, PropertyMetadata metadata) {
/* 144 */     super(metadata);
/*     */ 
/*     */     
/*     */     this._propertyIndex = -1;
/*     */ 
/*     */     
/* 150 */     if (propName == null) {
/* 151 */       this._propName = PropertyName.NO_NAME;
/*     */     } else {
/* 153 */       this._propName = propName.internSimpleName();
/*     */     } 
/* 155 */     this._type = type;
/* 156 */     this._wrapperName = wrapper;
/* 157 */     this._contextAnnotations = contextAnnotations;
/* 158 */     this._viewMatcher = null;
/*     */ 
/*     */     
/* 161 */     if (typeDeser != null) {
/* 162 */       typeDeser = typeDeser.forProperty((BeanProperty)this);
/*     */     }
/* 164 */     this._valueTypeDeserializer = typeDeser;
/* 165 */     this._valueDeserializer = MISSING_VALUE_DESERIALIZER;
/* 166 */     this._nullProvider = (NullValueProvider)MISSING_VALUE_DESERIALIZER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SettableBeanProperty(PropertyName propName, JavaType type, PropertyMetadata metadata, JsonDeserializer<Object> valueDeser) {
/* 177 */     super(metadata);
/*     */     this._propertyIndex = -1;
/* 179 */     if (propName == null) {
/* 180 */       this._propName = PropertyName.NO_NAME;
/*     */     } else {
/* 182 */       this._propName = propName.internSimpleName();
/*     */     } 
/* 184 */     this._type = type;
/* 185 */     this._wrapperName = null;
/* 186 */     this._contextAnnotations = null;
/* 187 */     this._viewMatcher = null;
/* 188 */     this._valueTypeDeserializer = null;
/* 189 */     this._valueDeserializer = valueDeser;
/*     */     
/* 191 */     this._nullProvider = (NullValueProvider)valueDeser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SettableBeanProperty(SettableBeanProperty src) {
/* 199 */     super(src); this._propertyIndex = -1;
/* 200 */     this._propName = src._propName;
/* 201 */     this._type = src._type;
/* 202 */     this._wrapperName = src._wrapperName;
/* 203 */     this._contextAnnotations = src._contextAnnotations;
/* 204 */     this._valueDeserializer = src._valueDeserializer;
/* 205 */     this._valueTypeDeserializer = src._valueTypeDeserializer;
/* 206 */     this._managedReferenceName = src._managedReferenceName;
/* 207 */     this._propertyIndex = src._propertyIndex;
/* 208 */     this._viewMatcher = src._viewMatcher;
/* 209 */     this._objectIdInfo = src._objectIdInfo;
/* 210 */     this._nullProvider = src._nullProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SettableBeanProperty(SettableBeanProperty src, JsonDeserializer<?> deser, NullValueProvider nuller) {
/* 220 */     super(src); JsonDeserializer<Object> jsonDeserializer; this._propertyIndex = -1;
/* 221 */     this._propName = src._propName;
/* 222 */     this._type = src._type;
/* 223 */     this._wrapperName = src._wrapperName;
/* 224 */     this._contextAnnotations = src._contextAnnotations;
/* 225 */     this._valueTypeDeserializer = src._valueTypeDeserializer;
/* 226 */     this._managedReferenceName = src._managedReferenceName;
/* 227 */     this._propertyIndex = src._propertyIndex;
/*     */     
/* 229 */     if (deser == null) {
/* 230 */       this._valueDeserializer = MISSING_VALUE_DESERIALIZER;
/*     */     } else {
/* 232 */       this._valueDeserializer = (JsonDeserializer)deser;
/*     */     } 
/* 234 */     this._viewMatcher = src._viewMatcher;
/* 235 */     this._objectIdInfo = src._objectIdInfo;
/*     */     
/* 237 */     if (nuller == MISSING_VALUE_DESERIALIZER) {
/* 238 */       jsonDeserializer = this._valueDeserializer;
/*     */     }
/* 240 */     this._nullProvider = (NullValueProvider)jsonDeserializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SettableBeanProperty(SettableBeanProperty src, PropertyName newName) {
/* 248 */     super(src); this._propertyIndex = -1;
/* 249 */     this._propName = newName;
/* 250 */     this._type = src._type;
/* 251 */     this._wrapperName = src._wrapperName;
/* 252 */     this._contextAnnotations = src._contextAnnotations;
/* 253 */     this._valueDeserializer = src._valueDeserializer;
/* 254 */     this._valueTypeDeserializer = src._valueTypeDeserializer;
/* 255 */     this._managedReferenceName = src._managedReferenceName;
/* 256 */     this._propertyIndex = src._propertyIndex;
/* 257 */     this._viewMatcher = src._viewMatcher;
/* 258 */     this._objectIdInfo = src._objectIdInfo;
/* 259 */     this._nullProvider = src._nullProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract SettableBeanProperty withValueDeserializer(JsonDeserializer<?> paramJsonDeserializer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract SettableBeanProperty withName(PropertyName paramPropertyName);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SettableBeanProperty withSimpleName(String simpleName) {
/* 291 */     PropertyName n = (this._propName == null) ? new PropertyName(simpleName) : this._propName.withSimpleName(simpleName);
/* 292 */     return (n == this._propName) ? this : withName(n);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract SettableBeanProperty withNullProvider(NullValueProvider paramNullValueProvider);
/*     */ 
/*     */   
/*     */   public void setManagedReferenceName(String n) {
/* 301 */     this._managedReferenceName = n;
/*     */   }
/*     */   
/*     */   public void setObjectIdInfo(ObjectIdInfo objectIdInfo) {
/* 305 */     this._objectIdInfo = objectIdInfo;
/*     */   }
/*     */   
/*     */   public void setViews(Class<?>[] views) {
/* 309 */     if (views == null) {
/* 310 */       this._viewMatcher = null;
/*     */     } else {
/* 312 */       this._viewMatcher = ViewMatcher.construct(views);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void assignIndex(int index) {
/* 320 */     if (this._propertyIndex != -1) {
/* 321 */       throw new IllegalStateException("Property '" + getName() + "' already had index (" + this._propertyIndex + "), trying to assign " + index);
/*     */     }
/* 323 */     this._propertyIndex = index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fixAccess(DeserializationConfig config) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markAsIgnorable() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIgnorable() {
/* 343 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getName() {
/* 353 */     return this._propName.getSimpleName();
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyName getFullName() {
/* 358 */     return this._propName;
/*     */   }
/*     */   
/*     */   public JavaType getType() {
/* 362 */     return this._type;
/*     */   }
/*     */   
/*     */   public PropertyName getWrapperName() {
/* 366 */     return this._wrapperName;
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract AnnotatedMember getMember();
/*     */ 
/*     */   
/*     */   public abstract <A extends java.lang.annotation.Annotation> A getAnnotation(Class<A> paramClass);
/*     */ 
/*     */   
/*     */   public <A extends java.lang.annotation.Annotation> A getContextAnnotation(Class<A> acls) {
/* 377 */     return (A)this._contextAnnotations.get(acls);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void depositSchemaProperty(JsonObjectFormatVisitor objectVisitor, SerializerProvider provider) throws JsonMappingException {
/* 385 */     if (isRequired()) {
/* 386 */       objectVisitor.property((BeanProperty)this);
/*     */     } else {
/* 388 */       objectVisitor.optionalProperty((BeanProperty)this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Class<?> getDeclaringClass() {
/* 399 */     return getMember().getDeclaringClass();
/*     */   }
/*     */   public String getManagedReferenceName() {
/* 402 */     return this._managedReferenceName;
/*     */   } public ObjectIdInfo getObjectIdInfo() {
/* 404 */     return this._objectIdInfo;
/*     */   }
/*     */   public boolean hasValueDeserializer() {
/* 407 */     return (this._valueDeserializer != null && this._valueDeserializer != MISSING_VALUE_DESERIALIZER);
/*     */   }
/*     */   public boolean hasValueTypeDeserializer() {
/* 410 */     return (this._valueTypeDeserializer != null);
/*     */   }
/*     */   public JsonDeserializer<Object> getValueDeserializer() {
/* 413 */     JsonDeserializer<Object> deser = this._valueDeserializer;
/* 414 */     if (deser == MISSING_VALUE_DESERIALIZER) {
/* 415 */       return null;
/*     */     }
/* 417 */     return deser;
/*     */   }
/*     */   public TypeDeserializer getValueTypeDeserializer() {
/* 420 */     return this._valueTypeDeserializer;
/*     */   }
/*     */ 
/*     */   
/*     */   public NullValueProvider getNullValueProvider() {
/* 425 */     return this._nullProvider;
/*     */   }
/*     */   public boolean visibleInView(Class<?> activeView) {
/* 428 */     return (this._viewMatcher == null || this._viewMatcher.isVisibleForView(activeView));
/*     */   }
/*     */   public boolean hasViews() {
/* 431 */     return (this._viewMatcher != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPropertyIndex() {
/* 440 */     return this._propertyIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCreatorIndex() {
/* 450 */     throw new IllegalStateException(String.format("Internal error: no creator index for property '%s' (of type %s)", new Object[] {
/*     */             
/* 452 */             getName(), getClass().getName()
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getInjectableValueId() {
/* 459 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInjectionOnly() {
/* 471 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void deserializeAndSet(JsonParser paramJsonParser, DeserializationContext paramDeserializationContext, Object paramObject) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Object deserializeSetAndReturn(JsonParser paramJsonParser, DeserializationContext paramDeserializationContext, Object paramObject) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void set(Object paramObject1, Object paramObject2) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Object setAndReturn(Object paramObject1, Object paramObject2) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 536 */     if (p.hasToken(JsonToken.VALUE_NULL)) {
/* 537 */       return this._nullProvider.getNullValue(ctxt);
/*     */     }
/* 539 */     if (this._valueTypeDeserializer != null) {
/* 540 */       return this._valueDeserializer.deserializeWithType(p, ctxt, this._valueTypeDeserializer);
/*     */     }
/*     */     
/* 543 */     Object value = this._valueDeserializer.deserialize(p, ctxt);
/* 544 */     if (value == null) {
/* 545 */       value = this._nullProvider.getNullValue(ctxt);
/*     */     }
/* 547 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object deserializeWith(JsonParser p, DeserializationContext ctxt, Object toUpdate) throws IOException {
/* 558 */     if (p.hasToken(JsonToken.VALUE_NULL)) {
/*     */       
/* 560 */       if (NullsConstantProvider.isSkipper(this._nullProvider)) {
/* 561 */         return toUpdate;
/*     */       }
/* 563 */       return this._nullProvider.getNullValue(ctxt);
/*     */     } 
/* 565 */     if (this._valueTypeDeserializer != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 572 */       JavaType subType = ctxt.getTypeFactory().constructType(toUpdate.getClass());
/* 573 */       JsonDeserializer<Object> subTypeValueDeserializer = ctxt.findContextualValueDeserializer(subType, (BeanProperty)this);
/* 574 */       return subTypeValueDeserializer.deserialize(p, ctxt, toUpdate);
/*     */     } 
/*     */     
/* 577 */     Object value = this._valueDeserializer.deserialize(p, ctxt, toUpdate);
/* 578 */     if (value == null) {
/* 579 */       if (NullsConstantProvider.isSkipper(this._nullProvider)) {
/* 580 */         return toUpdate;
/*     */       }
/* 582 */       value = this._nullProvider.getNullValue(ctxt);
/*     */     } 
/* 584 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SettableBeanProperty unwrapped(NameTransformer xf) {
/* 594 */     String newName = xf.transform(getName());
/* 595 */     SettableBeanProperty renamed = withSimpleName(newName);
/* 596 */     JsonDeserializer<?> deser = renamed.getValueDeserializer();
/* 597 */     if (deser != null) {
/*     */ 
/*     */       
/* 600 */       JsonDeserializer<Object> newDeser = deser.unwrappingDeserializer(xf);
/* 601 */       if (newDeser != deser) {
/* 602 */         renamed = renamed.withValueDeserializer(newDeser);
/*     */       }
/*     */     } 
/* 605 */     return renamed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _throwAsIOE(JsonParser p, Exception e, Object value) throws IOException {
/* 620 */     if (e instanceof IllegalArgumentException) {
/* 621 */       String actType = ClassUtil.classNameOf(value);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 627 */       StringBuilder msg = (new StringBuilder("Problem deserializing property '")).append(getName()).append("' (expected type: ").append(getType()).append("; actual type: ").append(actType).append(")");
/* 628 */       String origMsg = ClassUtil.exceptionMessage(e);
/* 629 */       if (origMsg != null) {
/* 630 */         msg.append(", problem: ")
/* 631 */           .append(origMsg);
/*     */       } else {
/* 633 */         msg.append(" (no error message provided)");
/*     */       } 
/* 635 */       throw JsonMappingException.from(p, msg.toString(), e);
/*     */     } 
/* 637 */     _throwAsIOE(p, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IOException _throwAsIOE(JsonParser p, Exception e) throws IOException {
/* 645 */     ClassUtil.throwIfIOE(e);
/* 646 */     ClassUtil.throwIfRTE(e);
/*     */     
/* 648 */     Throwable th = ClassUtil.getRootCause(e);
/* 649 */     throw JsonMappingException.from(p, ClassUtil.exceptionMessage(th), th);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected IOException _throwAsIOE(Exception e) throws IOException {
/* 654 */     return _throwAsIOE((JsonParser)null, e);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _throwAsIOE(Exception e, Object value) throws IOException {
/* 660 */     _throwAsIOE((JsonParser)null, e, value);
/*     */   }
/*     */   public String toString() {
/* 663 */     return "[property '" + getName() + "']";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class Delegating
/*     */     extends SettableBeanProperty
/*     */   {
/*     */     protected final SettableBeanProperty delegate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Delegating(SettableBeanProperty d) {
/* 687 */       super(d);
/* 688 */       this.delegate = d;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected abstract SettableBeanProperty withDelegate(SettableBeanProperty param1SettableBeanProperty);
/*     */ 
/*     */ 
/*     */     
/*     */     protected SettableBeanProperty _with(SettableBeanProperty newDelegate) {
/* 698 */       if (newDelegate == this.delegate) {
/* 699 */         return this;
/*     */       }
/* 701 */       return withDelegate(newDelegate);
/*     */     }
/*     */ 
/*     */     
/*     */     public SettableBeanProperty withValueDeserializer(JsonDeserializer<?> deser) {
/* 706 */       return _with(this.delegate.withValueDeserializer(deser));
/*     */     }
/*     */ 
/*     */     
/*     */     public SettableBeanProperty withName(PropertyName newName) {
/* 711 */       return _with(this.delegate.withName(newName));
/*     */     }
/*     */ 
/*     */     
/*     */     public SettableBeanProperty withNullProvider(NullValueProvider nva) {
/* 716 */       return _with(this.delegate.withNullProvider(nva));
/*     */     }
/*     */ 
/*     */     
/*     */     public void assignIndex(int index) {
/* 721 */       this.delegate.assignIndex(index);
/*     */     }
/*     */ 
/*     */     
/*     */     public void fixAccess(DeserializationConfig config) {
/* 726 */       this.delegate.fixAccess(config);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Class<?> getDeclaringClass() {
/* 736 */       return this.delegate.getDeclaringClass();
/*     */     }
/*     */     public String getManagedReferenceName() {
/* 739 */       return this.delegate.getManagedReferenceName();
/*     */     }
/*     */     public ObjectIdInfo getObjectIdInfo() {
/* 742 */       return this.delegate.getObjectIdInfo();
/*     */     }
/*     */     public boolean hasValueDeserializer() {
/* 745 */       return this.delegate.hasValueDeserializer();
/*     */     }
/*     */     public boolean hasValueTypeDeserializer() {
/* 748 */       return this.delegate.hasValueTypeDeserializer();
/*     */     }
/*     */     public JsonDeserializer<Object> getValueDeserializer() {
/* 751 */       return this.delegate.getValueDeserializer();
/*     */     }
/*     */     public TypeDeserializer getValueTypeDeserializer() {
/* 754 */       return this.delegate.getValueTypeDeserializer();
/*     */     }
/*     */     public boolean visibleInView(Class<?> activeView) {
/* 757 */       return this.delegate.visibleInView(activeView);
/*     */     }
/*     */     public boolean hasViews() {
/* 760 */       return this.delegate.hasViews();
/*     */     }
/*     */     public int getPropertyIndex() {
/* 763 */       return this.delegate.getPropertyIndex();
/*     */     }
/*     */     public int getCreatorIndex() {
/* 766 */       return this.delegate.getCreatorIndex();
/*     */     }
/*     */     public Object getInjectableValueId() {
/* 769 */       return this.delegate.getInjectableValueId();
/*     */     }
/*     */     public boolean isInjectionOnly() {
/* 772 */       return this.delegate.isInjectionOnly();
/*     */     }
/*     */     
/*     */     public AnnotatedMember getMember() {
/* 776 */       return this.delegate.getMember();
/*     */     }
/*     */ 
/*     */     
/*     */     public <A extends java.lang.annotation.Annotation> A getAnnotation(Class<A> acls) {
/* 781 */       return this.delegate.getAnnotation(acls);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SettableBeanProperty getDelegate() {
/* 791 */       return this.delegate;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void deserializeAndSet(JsonParser p, DeserializationContext ctxt, Object instance) throws IOException {
/* 803 */       this.delegate.deserializeAndSet(p, ctxt, instance);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object deserializeSetAndReturn(JsonParser p, DeserializationContext ctxt, Object instance) throws IOException {
/* 810 */       return this.delegate.deserializeSetAndReturn(p, ctxt, instance);
/*     */     }
/*     */ 
/*     */     
/*     */     public void set(Object instance, Object value) throws IOException {
/* 815 */       this.delegate.set(instance, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public Object setAndReturn(Object instance, Object value) throws IOException {
/* 820 */       return this.delegate.setAndReturn(instance, value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\deser\SettableBeanProperty.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */