package com.fasterxml.jackson.databind.cfg;

import com.fasterxml.jackson.core.util.JacksonFeature;

public interface DatatypeFeature extends JacksonFeature {
  int featureIndex();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\cfg\DatatypeFeature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */