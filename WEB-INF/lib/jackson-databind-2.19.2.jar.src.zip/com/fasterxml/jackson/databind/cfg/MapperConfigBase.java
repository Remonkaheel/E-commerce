/*     */ package com.fasterxml.jackson.databind.cfg;
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.annotation.JsonSetter;
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.EnumNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.PropertyName;
/*     */ import com.fasterxml.jackson.databind.PropertyNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.introspect.AccessorNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.ClassIntrospector;
/*     */ import com.fasterxml.jackson.databind.introspect.SimpleMixInResolver;
/*     */ import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
/*     */ import com.fasterxml.jackson.databind.jsontype.SubtypeResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.RootNameLookup;
/*     */ import java.io.Serializable;
/*     */ import java.text.DateFormat;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public abstract class MapperConfigBase<CFG extends ConfigFeature, T extends MapperConfigBase<CFG, T>> extends MapperConfig<T> implements Serializable {
/*  32 */   protected static final ConfigOverride EMPTY_OVERRIDE = ConfigOverride.empty();
/*     */   
/*  34 */   private static final long DEFAULT_MAPPER_FEATURES = MapperFeature.collectLongDefaults();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   private static final long AUTO_DETECT_MASK = MapperFeature.AUTO_DETECT_FIELDS
/*  40 */     .getLongMask() | MapperFeature.AUTO_DETECT_GETTERS
/*  41 */     .getLongMask() | MapperFeature.AUTO_DETECT_IS_GETTERS
/*  42 */     .getLongMask() | MapperFeature.AUTO_DETECT_SETTERS
/*  43 */     .getLongMask() | MapperFeature.AUTO_DETECT_CREATORS
/*  44 */     .getLongMask();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final SimpleMixInResolver _mixIns;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final SubtypeResolver _subtypeResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final PropertyName _rootName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Class<?> _view;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ContextAttributes _attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final RootNameLookup _rootNames;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ConfigOverrides _configOverrides;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final DatatypeFeatures _datatypeFeatures;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(BaseSettings base, SubtypeResolver str, SimpleMixInResolver mixins, RootNameLookup rootNames, ConfigOverrides configOverrides, DatatypeFeatures datatypeFeatures) {
/* 134 */     super(base, DEFAULT_MAPPER_FEATURES);
/* 135 */     this._mixIns = mixins;
/* 136 */     this._subtypeResolver = str;
/* 137 */     this._rootNames = rootNames;
/* 138 */     this._rootName = null;
/* 139 */     this._view = null;
/*     */     
/* 141 */     this._attributes = ContextAttributes.getEmpty();
/* 142 */     this._configOverrides = configOverrides;
/* 143 */     this._datatypeFeatures = datatypeFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, SubtypeResolver str, SimpleMixInResolver mixins, RootNameLookup rootNames, ConfigOverrides configOverrides) {
/* 158 */     super(src, src._base.copy());
/* 159 */     this._mixIns = mixins;
/* 160 */     this._subtypeResolver = str;
/* 161 */     this._rootNames = rootNames;
/* 162 */     this._rootName = src._rootName;
/* 163 */     this._view = src._view;
/* 164 */     this._attributes = src._attributes;
/* 165 */     this._configOverrides = configOverrides;
/* 166 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src) {
/* 175 */     super(src);
/* 176 */     this._mixIns = src._mixIns;
/* 177 */     this._subtypeResolver = src._subtypeResolver;
/* 178 */     this._rootNames = src._rootNames;
/* 179 */     this._rootName = src._rootName;
/* 180 */     this._view = src._view;
/* 181 */     this._attributes = src._attributes;
/* 182 */     this._configOverrides = src._configOverrides;
/* 183 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, BaseSettings base) {
/* 188 */     super(src, base);
/* 189 */     this._mixIns = src._mixIns;
/* 190 */     this._subtypeResolver = src._subtypeResolver;
/* 191 */     this._rootNames = src._rootNames;
/* 192 */     this._rootName = src._rootName;
/* 193 */     this._view = src._view;
/* 194 */     this._attributes = src._attributes;
/* 195 */     this._configOverrides = src._configOverrides;
/* 196 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, long mapperFeatures) {
/* 201 */     super(src, mapperFeatures);
/* 202 */     this._mixIns = src._mixIns;
/* 203 */     this._subtypeResolver = src._subtypeResolver;
/* 204 */     this._rootNames = src._rootNames;
/* 205 */     this._rootName = src._rootName;
/* 206 */     this._view = src._view;
/* 207 */     this._attributes = src._attributes;
/* 208 */     this._configOverrides = src._configOverrides;
/* 209 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, SubtypeResolver str) {
/* 213 */     super(src);
/* 214 */     this._mixIns = src._mixIns;
/* 215 */     this._subtypeResolver = str;
/* 216 */     this._rootNames = src._rootNames;
/* 217 */     this._rootName = src._rootName;
/* 218 */     this._view = src._view;
/* 219 */     this._attributes = src._attributes;
/* 220 */     this._configOverrides = src._configOverrides;
/* 221 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, PropertyName rootName) {
/* 225 */     super(src);
/* 226 */     this._mixIns = src._mixIns;
/* 227 */     this._subtypeResolver = src._subtypeResolver;
/* 228 */     this._rootNames = src._rootNames;
/* 229 */     this._rootName = rootName;
/* 230 */     this._view = src._view;
/* 231 */     this._attributes = src._attributes;
/* 232 */     this._configOverrides = src._configOverrides;
/* 233 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, Class<?> view) {
/* 238 */     super(src);
/* 239 */     this._mixIns = src._mixIns;
/* 240 */     this._subtypeResolver = src._subtypeResolver;
/* 241 */     this._rootNames = src._rootNames;
/* 242 */     this._rootName = src._rootName;
/* 243 */     this._view = view;
/* 244 */     this._attributes = src._attributes;
/* 245 */     this._configOverrides = src._configOverrides;
/* 246 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, SimpleMixInResolver mixins) {
/* 254 */     super(src);
/* 255 */     this._mixIns = mixins;
/* 256 */     this._subtypeResolver = src._subtypeResolver;
/* 257 */     this._rootNames = src._rootNames;
/* 258 */     this._rootName = src._rootName;
/* 259 */     this._view = src._view;
/* 260 */     this._attributes = src._attributes;
/* 261 */     this._configOverrides = src._configOverrides;
/* 262 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, ContextAttributes attr) {
/* 270 */     super(src);
/* 271 */     this._mixIns = src._mixIns;
/* 272 */     this._subtypeResolver = src._subtypeResolver;
/* 273 */     this._rootNames = src._rootNames;
/* 274 */     this._rootName = src._rootName;
/* 275 */     this._view = src._view;
/* 276 */     this._attributes = attr;
/* 277 */     this._configOverrides = src._configOverrides;
/* 278 */     this._datatypeFeatures = src._datatypeFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapperConfigBase(MapperConfigBase<CFG, T> src, DatatypeFeatures datatypeFeatures) {
/* 286 */     super(src);
/* 287 */     this._mixIns = src._mixIns;
/* 288 */     this._subtypeResolver = src._subtypeResolver;
/* 289 */     this._rootNames = src._rootNames;
/* 290 */     this._rootName = src._rootName;
/* 291 */     this._view = src._view;
/* 292 */     this._attributes = src._attributes;
/* 293 */     this._configOverrides = src._configOverrides;
/* 294 */     this._datatypeFeatures = datatypeFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DatatypeFeatures _datatypeFeatures() {
/* 322 */     return this._datatypeFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(MapperFeature... features) {
/* 339 */     long newMapperFlags = this._mapperFeatures;
/* 340 */     for (MapperFeature f : features) {
/* 341 */       newMapperFlags |= f.getLongMask();
/*     */     }
/* 343 */     if (newMapperFlags == this._mapperFeatures) {
/* 344 */       return (T)this;
/*     */     }
/* 346 */     return _withMapperFeatures(newMapperFlags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T without(MapperFeature... features) {
/* 357 */     long newMapperFlags = this._mapperFeatures;
/* 358 */     for (MapperFeature f : features) {
/* 359 */       newMapperFlags &= f.getLongMask() ^ 0xFFFFFFFFFFFFFFFFL;
/*     */     }
/* 361 */     if (newMapperFlags == this._mapperFeatures) {
/* 362 */       return (T)this;
/*     */     }
/* 364 */     return _withMapperFeatures(newMapperFlags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(MapperFeature feature, boolean state) {
/*     */     long newMapperFlags;
/* 372 */     if (state) {
/* 373 */       newMapperFlags = this._mapperFeatures | feature.getLongMask();
/*     */     } else {
/* 375 */       newMapperFlags = this._mapperFeatures & (feature.getLongMask() ^ 0xFFFFFFFFFFFFFFFFL);
/*     */     } 
/* 377 */     if (newMapperFlags == this._mapperFeatures) {
/* 378 */       return (T)this;
/*     */     }
/* 380 */     return _withMapperFeatures(newMapperFlags);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(DatatypeFeature feature) {
/* 396 */     return _with(_datatypeFeatures().with(feature));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T withFeatures(DatatypeFeature... features) {
/* 406 */     return _with(_datatypeFeatures().withFeatures(features));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T without(DatatypeFeature feature) {
/* 416 */     return _with(_datatypeFeatures().without(feature));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T withoutFeatures(DatatypeFeature... features) {
/* 426 */     return _with(_datatypeFeatures().withoutFeatures(features));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(DatatypeFeature feature, boolean state) {
/* 436 */     DatatypeFeatures features = _datatypeFeatures();
/* 437 */     features = state ? features.with(feature) : features.without(feature);
/* 438 */     return _with(features);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(AnnotationIntrospector ai) {
/* 455 */     return _withBase(this._base.withAnnotationIntrospector(ai));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T withAppendedAnnotationIntrospector(AnnotationIntrospector ai) {
/* 463 */     return _withBase(this._base.withAppendedAnnotationIntrospector(ai));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T withInsertedAnnotationIntrospector(AnnotationIntrospector ai) {
/* 471 */     return _withBase(this._base.withInsertedAnnotationIntrospector(ai));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(ClassIntrospector ci) {
/* 483 */     return _withBase(this._base.withClassIntrospector(ci));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T withAttributes(Map<?, ?> attributes) {
/* 507 */     return with(getAttributes().withSharedAttributes(attributes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T withAttribute(Object key, Object value) {
/* 517 */     return with(getAttributes().withSharedAttribute(key, value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T withoutAttribute(Object key) {
/* 527 */     return with(getAttributes().withoutSharedAttribute(key));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(TypeFactory tf) {
/* 542 */     return _withBase(this._base.withTypeFactory(tf));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(TypeResolverBuilder<?> trb) {
/* 550 */     return _withBase(this._base.withTypeResolverBuilder(trb));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(PropertyNamingStrategy pns) {
/* 562 */     return _withBase(this._base.withPropertyNamingStrategy(pns));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(EnumNamingStrategy ens) {
/* 576 */     return _withBase(this._base.withEnumNamingStrategy(ens));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(AccessorNamingStrategy.Provider p) {
/* 587 */     return _withBase(this._base.withAccessorNaming(p));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(HandlerInstantiator hi) {
/* 599 */     return _withBase(this._base.withHandlerInstantiator(hi));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T with(CacheProvider provider) {
/* 606 */     return _withBase(this._base.with(Objects.<CacheProvider>requireNonNull(provider)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(Base64Variant base64) {
/* 620 */     return _withBase(this._base.with(base64));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T with(DateFormat df) {
/* 631 */     return _withBase(this._base.withDateFormat(df));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(Locale l) {
/* 639 */     return _withBase(this._base.with(l));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final T with(TimeZone tz) {
/* 647 */     return _withBase(this._base.with(tz));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T withRootName(String rootName) {
/* 669 */     if (rootName == null) {
/* 670 */       return withRootName((PropertyName)null);
/*     */     }
/* 672 */     return withRootName(PropertyName.construct(rootName));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DatatypeFeatures getDatatypeFeatures() {
/* 699 */     return this._datatypeFeatures;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SubtypeResolver getSubtypeResolver() {
/* 709 */     return this._subtypeResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final String getRootName() {
/* 717 */     return (this._rootName == null) ? null : this._rootName.getSimpleName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final PropertyName getFullRootName() {
/* 724 */     return this._rootName;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Class<?> getActiveView() {
/* 729 */     return this._view;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ContextAttributes getAttributes() {
/* 734 */     return this._attributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ConfigOverride getConfigOverride(Class<?> type) {
/* 745 */     ConfigOverride override = this._configOverrides.findOverride(type);
/* 746 */     return (override == null) ? EMPTY_OVERRIDE : override;
/*     */   }
/*     */ 
/*     */   
/*     */   public final ConfigOverride findConfigOverride(Class<?> type) {
/* 751 */     return this._configOverrides.findOverride(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public final JsonInclude.Value getDefaultPropertyInclusion() {
/* 756 */     return this._configOverrides.getDefaultInclusion();
/*     */   }
/*     */ 
/*     */   
/*     */   public final JsonInclude.Value getDefaultPropertyInclusion(Class<?> baseType) {
/* 761 */     JsonInclude.Value v = getConfigOverride(baseType).getInclude();
/* 762 */     JsonInclude.Value def = getDefaultPropertyInclusion();
/* 763 */     if (def == null) {
/* 764 */       return v;
/*     */     }
/* 766 */     return def.withOverrides(v);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final JsonInclude.Value getDefaultInclusion(Class<?> baseType, Class<?> propertyType) {
/* 772 */     JsonInclude.Value v = getConfigOverride(propertyType).getIncludeAsProperty();
/* 773 */     JsonInclude.Value def = getDefaultPropertyInclusion(baseType);
/* 774 */     if (def == null) {
/* 775 */       return v;
/*     */     }
/* 777 */     return def.withOverrides(v);
/*     */   }
/*     */ 
/*     */   
/*     */   public final JsonFormat.Value getDefaultPropertyFormat(Class<?> type) {
/* 782 */     return this._configOverrides.findFormatDefaults(type);
/*     */   }
/*     */ 
/*     */   
/*     */   public final JsonIgnoreProperties.Value getDefaultPropertyIgnorals(Class<?> type) {
/* 787 */     ConfigOverride overrides = this._configOverrides.findOverride(type);
/* 788 */     if (overrides != null) {
/* 789 */       JsonIgnoreProperties.Value v = overrides.getIgnorals();
/* 790 */       if (v != null) {
/* 791 */         return v;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 796 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final JsonIgnoreProperties.Value getDefaultPropertyIgnorals(Class<?> baseType, AnnotatedClass actualClass) {
/* 803 */     AnnotationIntrospector intr = getAnnotationIntrospector();
/*     */     
/* 805 */     JsonIgnoreProperties.Value base = (intr == null) ? null : intr.findPropertyIgnoralByName(this, (Annotated)actualClass);
/* 806 */     JsonIgnoreProperties.Value overrides = getDefaultPropertyIgnorals(baseType);
/* 807 */     return JsonIgnoreProperties.Value.merge(base, overrides);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final JsonIncludeProperties.Value getDefaultPropertyInclusions(Class<?> baseType, AnnotatedClass actualClass) {
/* 814 */     AnnotationIntrospector intr = getAnnotationIntrospector();
/* 815 */     return (intr == null) ? null : intr.findPropertyInclusionByName(this, (Annotated)actualClass);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final VisibilityChecker<?> getDefaultVisibilityChecker() {
/* 821 */     VisibilityChecker<?> vchecker = this._configOverrides.getDefaultVisibility();
/*     */ 
/*     */     
/* 824 */     if ((this._mapperFeatures & AUTO_DETECT_MASK) != AUTO_DETECT_MASK) {
/* 825 */       if (!isEnabled(MapperFeature.AUTO_DETECT_FIELDS)) {
/* 826 */         vchecker = vchecker.withFieldVisibility(JsonAutoDetect.Visibility.NONE);
/*     */       }
/* 828 */       if (!isEnabled(MapperFeature.AUTO_DETECT_GETTERS)) {
/* 829 */         vchecker = vchecker.withGetterVisibility(JsonAutoDetect.Visibility.NONE);
/*     */       }
/* 831 */       if (!isEnabled(MapperFeature.AUTO_DETECT_IS_GETTERS)) {
/* 832 */         vchecker = vchecker.withIsGetterVisibility(JsonAutoDetect.Visibility.NONE);
/*     */       }
/* 834 */       if (!isEnabled(MapperFeature.AUTO_DETECT_SETTERS)) {
/* 835 */         vchecker = vchecker.withSetterVisibility(JsonAutoDetect.Visibility.NONE);
/*     */       }
/* 837 */       if (!isEnabled(MapperFeature.AUTO_DETECT_CREATORS)) {
/* 838 */         vchecker = vchecker.withCreatorVisibility(JsonAutoDetect.Visibility.NONE);
/*     */       }
/*     */     } 
/* 841 */     return vchecker;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final VisibilityChecker<?> getDefaultVisibilityChecker(Class<?> baseType, AnnotatedClass actualClass) {
/*     */     VisibilityChecker<?> vc;
/* 852 */     if (ClassUtil.isJDKClass(baseType)) {
/* 853 */       VisibilityChecker.Std std = VisibilityChecker.Std.allPublicInstance();
/*     */     } else {
/* 855 */       vc = getDefaultVisibilityChecker();
/*     */ 
/*     */       
/* 858 */       if (ClassUtil.isRecordType(baseType))
/*     */       {
/* 860 */         if (isEnabled(MapperFeature.AUTO_DETECT_CREATORS))
/*     */         {
/* 862 */           vc = vc.withCreatorVisibility(JsonAutoDetect.Visibility.DEFAULT);
/*     */         }
/*     */       }
/*     */     } 
/* 866 */     AnnotationIntrospector intr = getAnnotationIntrospector();
/* 867 */     if (intr != null) {
/* 868 */       vc = intr.findAutoDetectVisibility(actualClass, vc);
/*     */     }
/* 870 */     ConfigOverride overrides = this._configOverrides.findOverride(baseType);
/* 871 */     if (overrides != null) {
/* 872 */       vc = vc.withOverrides(overrides.getVisibility());
/*     */     }
/* 874 */     return vc;
/*     */   }
/*     */ 
/*     */   
/*     */   public final JsonSetter.Value getDefaultSetterInfo() {
/* 879 */     return this._configOverrides.getDefaultSetterInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean getDefaultMergeable() {
/* 884 */     return this._configOverrides.getDefaultMergeable();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getDefaultMergeable(Class<?> baseType) {
/* 890 */     ConfigOverride cfg = this._configOverrides.findOverride(baseType);
/* 891 */     if (cfg != null) {
/* 892 */       Boolean b = cfg.getMergeable();
/* 893 */       if (b != null) {
/* 894 */         return b;
/*     */       }
/*     */     } 
/* 897 */     return this._configOverrides.getDefaultMergeable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyName findRootName(JavaType rootType) {
/* 908 */     if (this._rootName != null) {
/* 909 */       return this._rootName;
/*     */     }
/* 911 */     return this._rootNames.findRootName(rootType, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyName findRootName(Class<?> rawRootType) {
/* 916 */     if (this._rootName != null) {
/* 917 */       return this._rootName;
/*     */     }
/* 919 */     return this._rootNames.findRootName(rawRootType, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Class<?> findMixInClassFor(Class<?> cls) {
/* 934 */     return this._mixIns.findMixInClassFor(cls);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassIntrospector.MixInResolver copy() {
/* 940 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int mixInCount() {
/* 948 */     return this._mixIns.localSize();
/*     */   }
/*     */   
/*     */   protected abstract T _withBase(BaseSettings paramBaseSettings);
/*     */   
/*     */   protected abstract T _withMapperFeatures(long paramLong);
/*     */   
/*     */   protected abstract T _with(DatatypeFeatures paramDatatypeFeatures);
/*     */   
/*     */   public abstract T with(ContextAttributes paramContextAttributes);
/*     */   
/*     */   public abstract T withRootName(PropertyName paramPropertyName);
/*     */   
/*     */   public abstract T with(SubtypeResolver paramSubtypeResolver);
/*     */   
/*     */   public abstract T withView(Class<?> paramClass);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\cfg\MapperConfigBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */