/*    */ package com.fasterxml.jackson.databind.cfg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum CoercionAction
/*    */ {
/* 21 */   Fail,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 26 */   TryConvert,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 31 */   AsNull,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   AsEmpty;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\cfg\CoercionAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */