/*     */ package com.fasterxml.jackson.databind.cfg;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.annotation.JsonSetter;
/*     */ import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigOverrides
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected Map<Class<?>, MutableConfigOverride> _overrides;
/*     */   protected JsonInclude.Value _defaultInclusion;
/*     */   protected JsonSetter.Value _defaultSetterInfo;
/*     */   protected VisibilityChecker<?> _visibilityChecker;
/*     */   protected Boolean _defaultMergeable;
/*     */   protected Boolean _defaultLeniency;
/*     */   
/*     */   public ConfigOverrides() {
/*  65 */     this(null, 
/*     */         
/*  67 */         JsonInclude.Value.empty(), 
/*  68 */         JsonSetter.Value.empty(), 
/*  69 */         (VisibilityChecker<?>)VisibilityChecker.Std.defaultInstance(), null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ConfigOverrides(Map<Class<?>, MutableConfigOverride> overrides, JsonInclude.Value defIncl, JsonSetter.Value defSetter, VisibilityChecker<?> defVisibility, Boolean defMergeable, Boolean defLeniency) {
/*  81 */     this._overrides = overrides;
/*  82 */     this._defaultInclusion = defIncl;
/*  83 */     this._defaultSetterInfo = defSetter;
/*  84 */     this._visibilityChecker = defVisibility;
/*  85 */     this._defaultMergeable = defMergeable;
/*  86 */     this._defaultLeniency = defLeniency;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected ConfigOverrides(Map<Class<?>, MutableConfigOverride> overrides, JsonInclude.Value defIncl, JsonSetter.Value defSetter, VisibilityChecker<?> defVisibility, Boolean defMergeable) {
/*  96 */     this(overrides, defIncl, defSetter, defVisibility, defMergeable, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigOverrides copy() {
/*     */     Map<Class<?>, MutableConfigOverride> newOverrides;
/* 102 */     if (this._overrides == null) {
/* 103 */       newOverrides = null;
/*     */     } else {
/* 105 */       newOverrides = _newMap();
/* 106 */       for (Map.Entry<Class<?>, MutableConfigOverride> entry : this._overrides.entrySet()) {
/* 107 */         newOverrides.put(entry.getKey(), ((MutableConfigOverride)entry.getValue()).copy());
/*     */       }
/*     */     } 
/* 110 */     return new ConfigOverrides(newOverrides, this._defaultInclusion, this._defaultSetterInfo, this._visibilityChecker, this._defaultMergeable, this._defaultLeniency);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConfigOverride findOverride(Class<?> type) {
/* 122 */     if (this._overrides == null) {
/* 123 */       return null;
/*     */     }
/* 125 */     return this._overrides.get(type);
/*     */   }
/*     */   
/*     */   public MutableConfigOverride findOrCreateOverride(Class<?> type) {
/* 129 */     if (this._overrides == null) {
/* 130 */       this._overrides = _newMap();
/*     */     }
/* 132 */     MutableConfigOverride override = this._overrides.get(type);
/* 133 */     if (override == null) {
/* 134 */       override = new MutableConfigOverride();
/* 135 */       this._overrides.put(type, override);
/*     */     } 
/* 137 */     return override;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonFormat.Value findFormatDefaults(Class<?> type) {
/* 150 */     if (this._overrides != null) {
/* 151 */       ConfigOverride override = this._overrides.get(type);
/* 152 */       if (override != null) {
/* 153 */         JsonFormat.Value format = override.getFormat();
/* 154 */         if (format != null) {
/* 155 */           if (!format.hasLenient()) {
/* 156 */             return format.withLenient(this._defaultLeniency);
/*     */           }
/* 158 */           return format;
/*     */         } 
/*     */       } 
/*     */     } 
/* 162 */     if (this._defaultLeniency == null) {
/* 163 */       return JsonFormat.Value.empty();
/*     */     }
/* 165 */     return JsonFormat.Value.forLeniency(this._defaultLeniency.booleanValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonInclude.Value getDefaultInclusion() {
/* 175 */     return this._defaultInclusion;
/*     */   }
/*     */   
/*     */   public JsonSetter.Value getDefaultSetterInfo() {
/* 179 */     return this._defaultSetterInfo;
/*     */   }
/*     */   
/*     */   public Boolean getDefaultMergeable() {
/* 183 */     return this._defaultMergeable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getDefaultLeniency() {
/* 190 */     return this._defaultLeniency;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VisibilityChecker<?> getDefaultVisibility() {
/* 197 */     return this._visibilityChecker;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultInclusion(JsonInclude.Value v) {
/* 204 */     this._defaultInclusion = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultSetterInfo(JsonSetter.Value v) {
/* 211 */     this._defaultSetterInfo = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultMergeable(Boolean v) {
/* 218 */     this._defaultMergeable = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultLeniency(Boolean v) {
/* 225 */     this._defaultLeniency = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultVisibility(VisibilityChecker<?> v) {
/* 232 */     this._visibilityChecker = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<Class<?>, MutableConfigOverride> _newMap() {
/* 242 */     return new HashMap<>();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\cfg\ConfigOverrides.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */