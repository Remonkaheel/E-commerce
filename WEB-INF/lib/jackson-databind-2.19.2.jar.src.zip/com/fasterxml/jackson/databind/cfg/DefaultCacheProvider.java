/*     */ package com.fasterxml.jackson.databind.cfg;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.util.LRUMap;
/*     */ import com.fasterxml.jackson.databind.util.LookupCache;
/*     */ import com.fasterxml.jackson.databind.util.TypeKey;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultCacheProvider
/*     */   implements CacheProvider
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  24 */   private static final DefaultCacheProvider DEFAULT = new DefaultCacheProvider(2000, 4000, 200);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _maxDeserializerCacheSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _maxSerializerCacheSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _maxTypeFactoryCacheSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DefaultCacheProvider(int maxDeserializerCacheSize, int maxSerializerCacheSize, int maxTypeFactoryCacheSize) {
/*  56 */     this._maxDeserializerCacheSize = maxDeserializerCacheSize;
/*  57 */     this._maxSerializerCacheSize = maxSerializerCacheSize;
/*  58 */     this._maxTypeFactoryCacheSize = maxTypeFactoryCacheSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CacheProvider defaultInstance() {
/*  71 */     return DEFAULT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LookupCache<JavaType, JsonDeserializer<Object>> forDeserializerCache(DeserializationConfig config) {
/*  88 */     return _buildCache(this._maxDeserializerCacheSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public LookupCache<TypeKey, JsonSerializer<Object>> forSerializerCache(SerializationConfig config) {
/*  93 */     return _buildCache(this._maxSerializerCacheSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public LookupCache<Object, JavaType> forTypeFactory() {
/*  98 */     return _buildCache(this._maxTypeFactoryCacheSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <K, V> LookupCache<K, V> _buildCache(int maxSize) {
/* 110 */     int initialSize = Math.min(64, maxSize >> 2);
/* 111 */     return (LookupCache<K, V>)new LRUMap(initialSize, maxSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder builder() {
/* 124 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     private int _maxDeserializerCacheSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int _maxSerializerCacheSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int _maxTypeFactoryCacheSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder maxDeserializerCacheSize(int maxDeserializerCacheSize) {
/* 164 */       if (maxDeserializerCacheSize < 0) {
/* 165 */         throw new IllegalArgumentException("Cannot set maxDeserializerCacheSize to a negative value");
/*     */       }
/* 167 */       this._maxDeserializerCacheSize = maxDeserializerCacheSize;
/* 168 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder maxSerializerCacheSize(int maxSerializerCacheSize) {
/* 183 */       if (maxSerializerCacheSize < 0) {
/* 184 */         throw new IllegalArgumentException("Cannot set maxSerializerCacheSize to a negative value");
/*     */       }
/* 186 */       this._maxSerializerCacheSize = maxSerializerCacheSize;
/* 187 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder maxTypeFactoryCacheSize(int maxTypeFactoryCacheSize) {
/* 201 */       if (maxTypeFactoryCacheSize < 0) {
/* 202 */         throw new IllegalArgumentException("Cannot set maxTypeFactoryCacheSize to a negative value");
/*     */       }
/* 204 */       this._maxTypeFactoryCacheSize = maxTypeFactoryCacheSize;
/* 205 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DefaultCacheProvider build() {
/* 214 */       return new DefaultCacheProvider(this._maxDeserializerCacheSize, this._maxSerializerCacheSize, this._maxTypeFactoryCacheSize);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\cfg\DefaultCacheProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */