/*    */ package com.fasterxml.jackson.databind.cfg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum EnumFeature
/*    */   implements DatatypeFeature
/*    */ {
/* 25 */   READ_ENUM_KEYS_USING_INDEX(false),
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   WRITE_ENUMS_TO_LOWERCASE(false);
/*    */ 
/*    */   
/*    */   private static final int FEATURE_INDEX = 0;
/*    */ 
/*    */   
/*    */   private final boolean _enabledByDefault;
/*    */   
/*    */   private final int _mask;
/*    */ 
/*    */   
/*    */   EnumFeature(boolean enabledByDefault) {
/* 51 */     this._enabledByDefault = enabledByDefault;
/* 52 */     this._mask = 1 << ordinal();
/*    */   }
/*    */   
/*    */   public boolean enabledByDefault() {
/* 56 */     return this._enabledByDefault;
/*    */   } public boolean enabledIn(int flags) {
/* 58 */     return ((flags & this._mask) != 0);
/*    */   } public int getMask() {
/* 60 */     return this._mask;
/*    */   }
/*    */   
/*    */   public int featureIndex() {
/* 64 */     return 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\cfg\EnumFeature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */