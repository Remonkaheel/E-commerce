/*     */ package com.fasterxml.jackson.databind.cfg;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonAutoDetect;
/*     */ import com.fasterxml.jackson.annotation.JsonInclude;
/*     */ import com.fasterxml.jackson.annotation.JsonSetter;
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.annotation.PropertyAccessor;
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.PrettyPrinter;
/*     */ import com.fasterxml.jackson.core.StreamReadFeature;
/*     */ import com.fasterxml.jackson.core.StreamWriteFeature;
/*     */ import com.fasterxml.jackson.core.TokenStreamFactory;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.EnumNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.InjectableValues;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.Module;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.PropertyNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.SerializationFeature;
/*     */ import com.fasterxml.jackson.databind.deser.DeserializationProblemHandler;
/*     */ import com.fasterxml.jackson.databind.introspect.AccessorNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.introspect.DefaultAccessorNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
/*     */ import com.fasterxml.jackson.databind.jsontype.SubtypeResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import com.fasterxml.jackson.databind.node.JsonNodeFactory;
/*     */ import com.fasterxml.jackson.databind.ser.FilterProvider;
/*     */ import com.fasterxml.jackson.databind.ser.SerializerFactory;
/*     */ import com.fasterxml.jackson.databind.type.LogicalType;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.text.DateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.ServiceLoader;
/*     */ import java.util.TimeZone;
/*     */ import java.util.function.Consumer;
/*     */ 
/*     */ public abstract class MapperBuilder<M extends ObjectMapper, B extends MapperBuilder<M, B>> {
/*     */   protected final M _mapper;
/*     */   
/*     */   protected MapperBuilder(M mapper) {
/*  52 */     this._mapper = mapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public M build() {
/*  63 */     return this._mapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(MapperFeature f) {
/*  73 */     return this._mapper.isEnabled(f);
/*     */   }
/*     */   public boolean isEnabled(DeserializationFeature f) {
/*  76 */     return this._mapper.isEnabled(f);
/*     */   }
/*     */   public boolean isEnabled(SerializationFeature f) {
/*  79 */     return this._mapper.isEnabled(f);
/*     */   }
/*     */   
/*     */   public boolean isEnabled(JsonParser.Feature f) {
/*  83 */     return this._mapper.isEnabled(f);
/*     */   }
/*     */   public boolean isEnabled(JsonGenerator.Feature f) {
/*  86 */     return this._mapper.isEnabled(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenStreamFactory streamFactory() {
/*  96 */     return (TokenStreamFactory)this._mapper.tokenStreamFactory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B enable(MapperFeature... features) {
/* 107 */     this._mapper.enable(features);
/* 108 */     return _this();
/*     */   }
/*     */ 
/*     */   
/*     */   public B disable(MapperFeature... features) {
/* 113 */     this._mapper.disable(features);
/* 114 */     return _this();
/*     */   }
/*     */ 
/*     */   
/*     */   public B configure(MapperFeature feature, boolean state) {
/* 119 */     this._mapper.configure(feature, state);
/* 120 */     return _this();
/*     */   }
/*     */   
/*     */   public B enable(SerializationFeature... features) {
/* 124 */     for (SerializationFeature f : features) {
/* 125 */       this._mapper.enable(f);
/*     */     }
/* 127 */     return _this();
/*     */   }
/*     */   
/*     */   public B disable(SerializationFeature... features) {
/* 131 */     for (SerializationFeature f : features) {
/* 132 */       this._mapper.disable(f);
/*     */     }
/* 134 */     return _this();
/*     */   }
/*     */   
/*     */   public B configure(SerializationFeature feature, boolean state) {
/* 138 */     this._mapper.configure(feature, state);
/* 139 */     return _this();
/*     */   }
/*     */   
/*     */   public B enable(DeserializationFeature... features) {
/* 143 */     for (DeserializationFeature f : features) {
/* 144 */       this._mapper.enable(f);
/*     */     }
/* 146 */     return _this();
/*     */   }
/*     */   
/*     */   public B disable(DeserializationFeature... features) {
/* 150 */     for (DeserializationFeature f : features) {
/* 151 */       this._mapper.disable(f);
/*     */     }
/* 153 */     return _this();
/*     */   }
/*     */   
/*     */   public B configure(DeserializationFeature feature, boolean state) {
/* 157 */     this._mapper.configure(feature, state);
/* 158 */     return _this();
/*     */   }
/*     */   
/*     */   public B enable(DatatypeFeature... features) {
/* 162 */     for (DatatypeFeature f : features) {
/* 163 */       this._mapper.configure(f, true);
/*     */     }
/* 165 */     return _this();
/*     */   }
/*     */   
/*     */   public B disable(DatatypeFeature... features) {
/* 169 */     for (DatatypeFeature f : features) {
/* 170 */       this._mapper.configure(f, false);
/*     */     }
/* 172 */     return _this();
/*     */   }
/*     */   
/*     */   public B configure(DatatypeFeature feature, boolean state) {
/* 176 */     this._mapper.configure(feature, state);
/* 177 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B enable(JsonParser.Feature... features) {
/* 187 */     this._mapper.enable(features);
/* 188 */     return _this();
/*     */   }
/*     */   
/*     */   public B disable(JsonParser.Feature... features) {
/* 192 */     this._mapper.disable(features);
/* 193 */     return _this();
/*     */   }
/*     */   
/*     */   public B configure(JsonParser.Feature feature, boolean state) {
/* 197 */     this._mapper.configure(feature, state);
/* 198 */     return _this();
/*     */   }
/*     */   
/*     */   public B enable(JsonGenerator.Feature... features) {
/* 202 */     this._mapper.enable(features);
/* 203 */     return _this();
/*     */   }
/*     */   
/*     */   public B disable(JsonGenerator.Feature... features) {
/* 207 */     this._mapper.disable(features);
/* 208 */     return _this();
/*     */   }
/*     */   
/*     */   public B configure(JsonGenerator.Feature feature, boolean state) {
/* 212 */     this._mapper.configure(feature, state);
/* 213 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B enable(StreamReadFeature... features) {
/* 223 */     for (StreamReadFeature f : features) {
/* 224 */       this._mapper.enable(new JsonParser.Feature[] { f.mappedFeature() });
/*     */     } 
/* 226 */     return _this();
/*     */   }
/*     */   
/*     */   public B disable(StreamReadFeature... features) {
/* 230 */     for (StreamReadFeature f : features) {
/* 231 */       this._mapper.disable(new JsonParser.Feature[] { f.mappedFeature() });
/*     */     } 
/* 233 */     return _this();
/*     */   }
/*     */   
/*     */   public B configure(StreamReadFeature feature, boolean state) {
/* 237 */     this._mapper.configure(feature.mappedFeature(), state);
/* 238 */     return _this();
/*     */   }
/*     */   
/*     */   public B enable(StreamWriteFeature... features) {
/* 242 */     for (StreamWriteFeature f : features) {
/* 243 */       this._mapper.enable(new JsonGenerator.Feature[] { f.mappedFeature() });
/*     */     } 
/* 245 */     return _this();
/*     */   }
/*     */   
/*     */   public B disable(StreamWriteFeature... features) {
/* 249 */     for (StreamWriteFeature f : features) {
/* 250 */       this._mapper.disable(new JsonGenerator.Feature[] { f.mappedFeature() });
/*     */     } 
/* 252 */     return _this();
/*     */   }
/*     */   
/*     */   public B configure(StreamWriteFeature feature, boolean state) {
/* 256 */     this._mapper.configure(feature.mappedFeature(), state);
/* 257 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B withConfigOverride(Class<?> forType, Consumer<MutableConfigOverride> handler) {
/* 278 */     handler.accept(this._mapper.configOverride(forType));
/* 279 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B withCoercionConfig(LogicalType forType, Consumer<MutableCoercionConfig> handler) {
/* 306 */     handler.accept(this._mapper.coercionConfigFor(forType));
/* 307 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B withCoercionConfig(Class<?> forType, Consumer<MutableCoercionConfig> handler) {
/* 318 */     handler.accept(this._mapper.coercionConfigFor(forType));
/* 319 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B withCoercionConfigDefaults(Consumer<MutableCoercionConfig> handler) {
/* 328 */     handler.accept(this._mapper.coercionConfigDefaults());
/* 329 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B addModule(Module module) {
/* 347 */     this._mapper.registerModule(module);
/* 348 */     return _this();
/*     */   }
/*     */ 
/*     */   
/*     */   public B addModules(Module... modules) {
/* 353 */     for (Module module : modules) {
/* 354 */       addModule(module);
/*     */     }
/* 356 */     return _this();
/*     */   }
/*     */ 
/*     */   
/*     */   public B addModules(Iterable<? extends Module> modules) {
/* 361 */     for (Module module : modules) {
/* 362 */       addModule(module);
/*     */     }
/* 364 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Module> findModules() {
/* 375 */     return findModules(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Module> findModules(ClassLoader classLoader) {
/* 387 */     ArrayList<Module> modules = new ArrayList<>();
/* 388 */     ServiceLoader<Module> loader = secureGetServiceLoader(Module.class, classLoader);
/* 389 */     for (Module module : loader) {
/* 390 */       modules.add(module);
/*     */     }
/* 392 */     return modules;
/*     */   }
/*     */   
/*     */   private static <T> ServiceLoader<T> secureGetServiceLoader(final Class<T> clazz, final ClassLoader classLoader) {
/* 396 */     SecurityManager sm = System.getSecurityManager();
/* 397 */     if (sm == null) {
/* 398 */       return (classLoader == null) ? 
/* 399 */         ServiceLoader.<T>load(clazz) : ServiceLoader.<T>load(clazz, classLoader);
/*     */     }
/* 401 */     return AccessController.<ServiceLoader<T>>doPrivileged((PrivilegedAction)new PrivilegedAction<ServiceLoader<ServiceLoader<T>>>()
/*     */         {
/*     */           public ServiceLoader<T> run() {
/* 404 */             return (classLoader == null) ? 
/* 405 */               ServiceLoader.<T>load(clazz) : ServiceLoader.<T>load(clazz, classLoader);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B findAndAddModules() {
/* 421 */     return addModules(findModules());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B annotationIntrospector(AnnotationIntrospector intr) {
/* 441 */     this._mapper.setAnnotationIntrospector(intr);
/* 442 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B defaultAttributes(ContextAttributes attrs) {
/* 458 */     this._mapper.setDefaultAttributes(attrs);
/* 459 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B typeFactory(TypeFactory f) {
/* 469 */     this._mapper.setTypeFactory(f);
/* 470 */     return _this();
/*     */   }
/*     */   
/*     */   public B subtypeResolver(SubtypeResolver r) {
/* 474 */     this._mapper.setSubtypeResolver(r);
/* 475 */     return _this();
/*     */   }
/*     */   
/*     */   public B visibility(VisibilityChecker<?> vc) {
/* 479 */     this._mapper.setVisibility(vc);
/* 480 */     return _this();
/*     */   }
/*     */   
/*     */   public B visibility(PropertyAccessor forMethod, JsonAutoDetect.Visibility visibility) {
/* 484 */     this._mapper.setVisibility(forMethod, visibility);
/* 485 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B handlerInstantiator(HandlerInstantiator hi) {
/* 498 */     this._mapper.setHandlerInstantiator(hi);
/* 499 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B propertyNamingStrategy(PropertyNamingStrategy s) {
/* 511 */     this._mapper.setPropertyNamingStrategy(s);
/* 512 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B enumNamingStrategy(EnumNamingStrategy s) {
/* 526 */     this._mapper.setEnumNamingStrategy(s);
/* 527 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B accessorNaming(AccessorNamingStrategy.Provider s) {
/*     */     DefaultAccessorNamingStrategy.Provider provider;
/* 542 */     if (s == null) {
/* 543 */       provider = new DefaultAccessorNamingStrategy.Provider();
/*     */     }
/* 545 */     this._mapper.setAccessorNaming((AccessorNamingStrategy.Provider)provider);
/* 546 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B serializerFactory(SerializerFactory f) {
/* 556 */     this._mapper.setSerializerFactory(f);
/* 557 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B filterProvider(FilterProvider prov) {
/* 569 */     this._mapper.setFilterProvider(prov);
/* 570 */     return _this();
/*     */   }
/*     */   
/*     */   public B defaultPrettyPrinter(PrettyPrinter pp) {
/* 574 */     this._mapper.setDefaultPrettyPrinter(pp);
/* 575 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B injectableValues(InjectableValues v) {
/* 585 */     this._mapper.setInjectableValues(v);
/* 586 */     return _this();
/*     */   }
/*     */   
/*     */   public B nodeFactory(JsonNodeFactory f) {
/* 590 */     this._mapper.setNodeFactory(f);
/* 591 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B constructorDetector(ConstructorDetector cd) {
/* 603 */     this._mapper.setConstructorDetector(cd);
/* 604 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B cacheProvider(CacheProvider cacheProvider) {
/* 611 */     this._mapper.setCacheProvider(cacheProvider);
/* 612 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B addHandler(DeserializationProblemHandler h) {
/* 621 */     this._mapper.addHandler(h);
/* 622 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B clearProblemHandlers() {
/* 630 */     this._mapper.clearProblemHandlers();
/* 631 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B defaultSetterInfo(JsonSetter.Value v) {
/* 641 */     this._mapper.setDefaultSetterInfo(v);
/* 642 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B defaultMergeable(Boolean b) {
/* 651 */     this._mapper.setDefaultMergeable(b);
/* 652 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B defaultLeniency(Boolean b) {
/* 661 */     this._mapper.setDefaultLeniency(b);
/* 662 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B defaultDateFormat(DateFormat df) {
/* 678 */     this._mapper.setDateFormat(df);
/* 679 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B defaultTimeZone(TimeZone tz) {
/* 687 */     this._mapper.setTimeZone(tz);
/* 688 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B defaultLocale(Locale locale) {
/* 696 */     this._mapper.setLocale(locale);
/* 697 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B defaultBase64Variant(Base64Variant v) {
/* 715 */     this._mapper.setBase64Variant(v);
/* 716 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B serializationInclusion(JsonInclude.Include incl) {
/* 727 */     this._mapper.setSerializationInclusion(incl);
/* 728 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B defaultPropertyInclusion(JsonInclude.Value incl) {
/* 741 */     this._mapper.setDefaultPropertyInclusion(incl);
/* 742 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B addMixIn(Class<?> target, Class<?> mixinSource) {
/* 773 */     this._mapper.addMixIn(target, mixinSource);
/* 774 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B removeMixIn(Class<?> target) {
/* 794 */     this._mapper.addMixIn(target, null);
/* 795 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B registerSubtypes(Class<?>... subtypes) {
/* 805 */     this._mapper.registerSubtypes(subtypes);
/* 806 */     return _this();
/*     */   }
/*     */   
/*     */   public B registerSubtypes(NamedType... subtypes) {
/* 810 */     this._mapper.registerSubtypes(subtypes);
/* 811 */     return _this();
/*     */   }
/*     */   
/*     */   public B registerSubtypes(Collection<Class<?>> subtypes) {
/* 815 */     this._mapper.registerSubtypes(subtypes);
/* 816 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B polymorphicTypeValidator(PolymorphicTypeValidator ptv) {
/* 833 */     this._mapper.setPolymorphicTypeValidator(ptv);
/* 834 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B activateDefaultTyping(PolymorphicTypeValidator subtypeValidator) {
/* 853 */     this._mapper.activateDefaultTyping(subtypeValidator);
/* 854 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B activateDefaultTyping(PolymorphicTypeValidator subtypeValidator, ObjectMapper.DefaultTyping dti) {
/* 868 */     this._mapper.activateDefaultTyping(subtypeValidator, dti);
/* 869 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B activateDefaultTyping(PolymorphicTypeValidator subtypeValidator, ObjectMapper.DefaultTyping applicability, JsonTypeInfo.As includeAs) {
/* 890 */     this._mapper.activateDefaultTyping(subtypeValidator, applicability, includeAs);
/* 891 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B activateDefaultTypingAsProperty(PolymorphicTypeValidator subtypeValidator, ObjectMapper.DefaultTyping applicability, String propertyName) {
/* 908 */     this._mapper.activateDefaultTypingAsProperty(subtypeValidator, applicability, propertyName);
/* 909 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B deactivateDefaultTyping() {
/* 919 */     this._mapper.deactivateDefaultTyping();
/* 920 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B setDefaultTyping(TypeResolverBuilder<?> typer) {
/* 941 */     this._mapper.setDefaultTyping(typer);
/* 942 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final B _this() {
/* 953 */     return (B)this;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\cfg\MapperBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */