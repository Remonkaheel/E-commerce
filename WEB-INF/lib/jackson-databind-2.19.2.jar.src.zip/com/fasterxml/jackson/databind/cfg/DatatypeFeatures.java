/*     */ package com.fasterxml.jackson.databind.cfg;
/*     */ 
/*     */ import com.fasterxml.jackson.core.util.VersionUtil;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatatypeFeatures
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected static final int FEATURE_INDEX_ENUM = 0;
/*     */   protected static final int FEATURE_INDEX_JSON_NODE = 1;
/*     */   private final int _enabledFor1;
/*     */   private final int _enabledFor2;
/*     */   private final int _explicitFor1;
/*     */   private final int _explicitFor2;
/*     */   
/*     */   protected DatatypeFeatures(int enabledFor1, int explicitFor1, int enabledFor2, int explicitFor2) {
/*  26 */     this._enabledFor1 = enabledFor1;
/*  27 */     this._explicitFor1 = explicitFor1;
/*  28 */     this._enabledFor2 = enabledFor2;
/*  29 */     this._explicitFor2 = explicitFor2;
/*     */   }
/*     */   
/*     */   public static DatatypeFeatures defaultFeatures() {
/*  33 */     return DefaultHolder.getDefault();
/*     */   }
/*     */ 
/*     */   
/*     */   private DatatypeFeatures _with(int enabledFor1, int explicitFor1, int enabledFor2, int explicitFor2) {
/*  38 */     if (this._enabledFor1 == enabledFor1 && this._explicitFor1 == explicitFor1 && this._enabledFor2 == enabledFor2 && this._explicitFor2 == explicitFor2)
/*     */     {
/*  40 */       return this;
/*     */     }
/*  42 */     return new DatatypeFeatures(enabledFor1, explicitFor1, enabledFor2, explicitFor2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatatypeFeatures with(DatatypeFeature f) {
/*  62 */     int mask = f.getMask();
/*  63 */     switch (f.featureIndex()) {
/*     */       case 0:
/*  65 */         return _with(this._enabledFor1 | mask, this._explicitFor1 | mask, this._enabledFor2, this._explicitFor2);
/*     */       
/*     */       case 1:
/*  68 */         return _with(this._enabledFor1, this._explicitFor1, this._enabledFor2 | mask, this._explicitFor2 | mask);
/*     */     } 
/*     */     
/*  71 */     VersionUtil.throwInternal();
/*  72 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatatypeFeatures withFeatures(DatatypeFeature... features) {
/*  86 */     int mask = _calcMask(features);
/*  87 */     if (mask == 0) {
/*  88 */       return this;
/*     */     }
/*  90 */     switch (features[0].featureIndex()) {
/*     */       case 0:
/*  92 */         return _with(this._enabledFor1 | mask, this._explicitFor1 | mask, this._enabledFor2, this._explicitFor2);
/*     */       
/*     */       case 1:
/*  95 */         return _with(this._enabledFor1, this._explicitFor1, this._enabledFor2 | mask, this._explicitFor2 | mask);
/*     */     } 
/*     */     
/*  98 */     VersionUtil.throwInternal();
/*  99 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatatypeFeatures without(DatatypeFeature f) {
/* 113 */     int mask = f.getMask();
/* 114 */     switch (f.featureIndex()) {
/*     */       case 0:
/* 116 */         return _with(this._enabledFor1 & (mask ^ 0xFFFFFFFF), this._explicitFor1 | mask, this._enabledFor2, this._explicitFor2);
/*     */       
/*     */       case 1:
/* 119 */         return _with(this._enabledFor1, this._explicitFor1, this._enabledFor2 & (mask ^ 0xFFFFFFFF), this._explicitFor2 | mask);
/*     */     } 
/*     */     
/* 122 */     VersionUtil.throwInternal();
/* 123 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatatypeFeatures withoutFeatures(DatatypeFeature... features) {
/* 137 */     int mask = _calcMask(features);
/* 138 */     if (mask == 0) {
/* 139 */       return this;
/*     */     }
/* 141 */     switch (features[0].featureIndex()) {
/*     */       case 0:
/* 143 */         return _with(this._enabledFor1 & (mask ^ 0xFFFFFFFF), this._explicitFor1 | mask, this._enabledFor2, this._explicitFor2);
/*     */       
/*     */       case 1:
/* 146 */         return _with(this._enabledFor1, this._explicitFor1, this._enabledFor2 & (mask ^ 0xFFFFFFFF), this._explicitFor2 | mask);
/*     */     } 
/*     */     
/* 149 */     VersionUtil.throwInternal();
/* 150 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final int _calcMask(DatatypeFeature... features) {
/* 155 */     int mask = 0;
/* 156 */     for (DatatypeFeature f : features) {
/* 157 */       mask |= f.getMask();
/*     */     }
/* 159 */     return mask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(DatatypeFeature f) {
/* 179 */     switch (f.featureIndex()) {
/*     */       case 0:
/* 181 */         return f.enabledIn(this._enabledFor1);
/*     */       case 1:
/* 183 */         return f.enabledIn(this._enabledFor2);
/*     */     } 
/* 185 */     VersionUtil.throwInternal();
/* 186 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExplicitlySet(DatatypeFeature f) {
/* 200 */     switch (f.featureIndex()) {
/*     */       case 0:
/* 202 */         return f.enabledIn(this._explicitFor1);
/*     */       case 1:
/* 204 */         return f.enabledIn(this._explicitFor2);
/*     */     } 
/* 206 */     VersionUtil.throwInternal();
/* 207 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExplicitlyEnabled(DatatypeFeature f) {
/* 224 */     switch (f.featureIndex()) {
/*     */       case 0:
/* 226 */         return f.enabledIn(this._explicitFor1 & this._enabledFor1);
/*     */       case 1:
/* 228 */         return f.enabledIn(this._explicitFor2 & this._enabledFor2);
/*     */     } 
/* 230 */     VersionUtil.throwInternal();
/* 231 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isExplicitlyDisabled(DatatypeFeature f) {
/* 248 */     switch (f.featureIndex()) {
/*     */       case 0:
/* 250 */         return f.enabledIn(this._explicitFor1 & (this._enabledFor1 ^ 0xFFFFFFFF));
/*     */       case 1:
/* 252 */         return f.enabledIn(this._explicitFor2 & (this._enabledFor2 ^ 0xFFFFFFFF));
/*     */     } 
/* 254 */     VersionUtil.throwInternal();
/* 255 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getExplicitState(DatatypeFeature f) {
/* 270 */     switch (f.featureIndex()) {
/*     */       case 0:
/* 272 */         if (f.enabledIn(this._explicitFor1)) {
/* 273 */           return Boolean.valueOf(f.enabledIn(this._enabledFor1));
/*     */         }
/* 275 */         return null;
/*     */       case 1:
/* 277 */         if (f.enabledIn(this._explicitFor2)) {
/* 278 */           return Boolean.valueOf(f.enabledIn(this._enabledFor2));
/*     */         }
/* 280 */         return null;
/*     */     } 
/* 282 */     VersionUtil.throwInternal();
/* 283 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class DefaultHolder
/*     */   {
/* 301 */     private static final DatatypeFeatures DEFAULT_FEATURES = new DatatypeFeatures(
/* 302 */         collectDefaults(EnumFeature.values()), 0, 
/* 303 */         collectDefaults(JsonNodeFeature.values()), 0);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private static <F extends Enum<F> & com.fasterxml.jackson.core.util.JacksonFeature> int collectDefaults(F[] features) {
/* 309 */       int flags = 0;
/* 310 */       for (F f : features) {
/* 311 */         if (f.enabledByDefault()) {
/* 312 */           flags |= f.getMask();
/*     */         }
/*     */       } 
/* 315 */       return flags;
/*     */     }
/*     */     
/*     */     public static DatatypeFeatures getDefault() {
/* 319 */       return DEFAULT_FEATURES;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\cfg\DatatypeFeatures.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */