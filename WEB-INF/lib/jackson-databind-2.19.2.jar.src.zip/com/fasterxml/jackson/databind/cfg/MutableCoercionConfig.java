/*    */ package com.fasterxml.jackson.databind.cfg;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MutableCoercionConfig
/*    */   extends CoercionConfig
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public MutableCoercionConfig() {}
/*    */   
/*    */   protected MutableCoercionConfig(MutableCoercionConfig src) {
/* 24 */     super(src);
/*    */   }
/*    */   
/*    */   public MutableCoercionConfig copy() {
/* 28 */     return new MutableCoercionConfig(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MutableCoercionConfig setCoercion(CoercionInputShape shape, CoercionAction action) {
/* 42 */     this._coercionsByShape[shape.ordinal()] = action;
/* 43 */     return this;
/*    */   }
/*    */   
/*    */   public MutableCoercionConfig setAcceptBlankAsEmpty(Boolean state) {
/* 47 */     this._acceptBlankAsEmpty = state;
/* 48 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\cfg\MutableCoercionConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */