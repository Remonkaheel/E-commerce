/*     */ package com.fasterxml.jackson.databind.cfg;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.EnumNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.PropertyNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.introspect.AccessorNamingStrategy;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotationIntrospectorPair;
/*     */ import com.fasterxml.jackson.databind.introspect.ClassIntrospector;
/*     */ import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.StdDateFormat;
/*     */ import java.io.Serializable;
/*     */ import java.text.DateFormat;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BaseSettings
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  36 */   private static final TimeZone DEFAULT_TIMEZONE = TimeZone.getTimeZone("UTC");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final TypeFactory _typeFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ClassIntrospector _classIntrospector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AnnotationIntrospector _annotationIntrospector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final PropertyNamingStrategy _propertyNamingStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final EnumNamingStrategy _enumNamingStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AccessorNamingStrategy.Provider _accessorNaming;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final TypeResolverBuilder<?> _typeResolverBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final PolymorphicTypeValidator _typeValidator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final DateFormat _dateFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final HandlerInstantiator _handlerInstantiator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Locale _locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final TimeZone _timeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Base64Variant _defaultBase64;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final CacheProvider _cacheProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings(ClassIntrospector ci, AnnotationIntrospector ai, PropertyNamingStrategy pns, EnumNamingStrategy ens, TypeFactory tf, TypeResolverBuilder<?> typer, DateFormat dateFormat, HandlerInstantiator hi, Locale locale, TimeZone tz, Base64Variant defaultBase64, PolymorphicTypeValidator ptv, AccessorNamingStrategy.Provider accNaming, CacheProvider cacheProvider) {
/* 174 */     this._classIntrospector = ci;
/* 175 */     this._annotationIntrospector = ai;
/* 176 */     this._propertyNamingStrategy = pns;
/* 177 */     this._enumNamingStrategy = ens;
/* 178 */     this._typeFactory = tf;
/* 179 */     this._typeResolverBuilder = typer;
/* 180 */     this._dateFormat = dateFormat;
/* 181 */     this._handlerInstantiator = hi;
/* 182 */     this._locale = locale;
/* 183 */     this._timeZone = tz;
/* 184 */     this._defaultBase64 = defaultBase64;
/* 185 */     this._typeValidator = ptv;
/* 186 */     this._accessorNaming = accNaming;
/* 187 */     this._cacheProvider = cacheProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public BaseSettings(ClassIntrospector ci, AnnotationIntrospector ai, PropertyNamingStrategy pns, TypeFactory tf, TypeResolverBuilder<?> typer, DateFormat dateFormat, HandlerInstantiator hi, Locale locale, TimeZone tz, Base64Variant defaultBase64, PolymorphicTypeValidator ptv, AccessorNamingStrategy.Provider accNaming, CacheProvider cacheProvider) {
/* 202 */     this(ci, ai, pns, null, tf, typer, dateFormat, hi, locale, tz, defaultBase64, ptv, accNaming, cacheProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public BaseSettings(ClassIntrospector ci, AnnotationIntrospector ai, PropertyNamingStrategy pns, TypeFactory tf, TypeResolverBuilder<?> typer, DateFormat dateFormat, HandlerInstantiator hi, Locale locale, TimeZone tz, Base64Variant defaultBase64, PolymorphicTypeValidator ptv, AccessorNamingStrategy.Provider accNaming) {
/* 216 */     this(ci, ai, pns, tf, typer, dateFormat, hi, locale, tz, defaultBase64, ptv, accNaming, 
/* 217 */         DefaultCacheProvider.defaultInstance());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings copy() {
/* 227 */     return new BaseSettings(this._classIntrospector.copy(), this._annotationIntrospector, this._propertyNamingStrategy, this._enumNamingStrategy, this._typeFactory, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator, this._locale, this._timeZone, this._defaultBase64, this._typeValidator, this._accessorNaming, this._cacheProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings withClassIntrospector(ClassIntrospector ci) {
/* 250 */     if (this._classIntrospector == ci) {
/* 251 */       return this;
/*     */     }
/* 253 */     return new BaseSettings(ci, this._annotationIntrospector, this._propertyNamingStrategy, this._enumNamingStrategy, this._typeFactory, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator, this._locale, this._timeZone, this._defaultBase64, this._typeValidator, this._accessorNaming, this._cacheProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings withAnnotationIntrospector(AnnotationIntrospector ai) {
/* 259 */     if (this._annotationIntrospector == ai) {
/* 260 */       return this;
/*     */     }
/* 262 */     return new BaseSettings(this._classIntrospector, ai, this._propertyNamingStrategy, this._enumNamingStrategy, this._typeFactory, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator, this._locale, this._timeZone, this._defaultBase64, this._typeValidator, this._accessorNaming, this._cacheProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings withInsertedAnnotationIntrospector(AnnotationIntrospector ai) {
/* 268 */     return withAnnotationIntrospector(AnnotationIntrospectorPair.create(ai, this._annotationIntrospector));
/*     */   }
/*     */   
/*     */   public BaseSettings withAppendedAnnotationIntrospector(AnnotationIntrospector ai) {
/* 272 */     return withAnnotationIntrospector(AnnotationIntrospectorPair.create(this._annotationIntrospector, ai));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings withPropertyNamingStrategy(PropertyNamingStrategy pns) {
/* 286 */     if (this._propertyNamingStrategy == pns) {
/* 287 */       return this;
/*     */     }
/* 289 */     return new BaseSettings(this._classIntrospector, this._annotationIntrospector, pns, this._enumNamingStrategy, this._typeFactory, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator, this._locale, this._timeZone, this._defaultBase64, this._typeValidator, this._accessorNaming, this._cacheProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings withEnumNamingStrategy(EnumNamingStrategy ens) {
/* 298 */     if (this._enumNamingStrategy == ens) {
/* 299 */       return this;
/*     */     }
/* 301 */     return new BaseSettings(this._classIntrospector, this._annotationIntrospector, this._propertyNamingStrategy, ens, this._typeFactory, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator, this._locale, this._timeZone, this._defaultBase64, this._typeValidator, this._accessorNaming, this._cacheProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings withAccessorNaming(AccessorNamingStrategy.Provider p) {
/* 308 */     if (this._accessorNaming == p) {
/* 309 */       return this;
/*     */     }
/* 311 */     return new BaseSettings(this._classIntrospector, this._annotationIntrospector, this._propertyNamingStrategy, this._enumNamingStrategy, this._typeFactory, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator, this._locale, this._timeZone, this._defaultBase64, this._typeValidator, p, this._cacheProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings withTypeFactory(TypeFactory tf) {
/* 317 */     if (this._typeFactory == tf) {
/* 318 */       return this;
/*     */     }
/* 320 */     return new BaseSettings(this._classIntrospector, this._annotationIntrospector, this._propertyNamingStrategy, this._enumNamingStrategy, tf, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator, this._locale, this._timeZone, this._defaultBase64, this._typeValidator, this._accessorNaming, this._cacheProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings withTypeResolverBuilder(TypeResolverBuilder<?> typer) {
/* 326 */     if (this._typeResolverBuilder == typer) {
/* 327 */       return this;
/*     */     }
/* 329 */     return new BaseSettings(this._classIntrospector, this._annotationIntrospector, this._propertyNamingStrategy, this._enumNamingStrategy, this._typeFactory, typer, this._dateFormat, this._handlerInstantiator, this._locale, this._timeZone, this._defaultBase64, this._typeValidator, this._accessorNaming, this._cacheProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings withDateFormat(DateFormat df) {
/* 335 */     if (this._dateFormat == df) {
/* 336 */       return this;
/*     */     }
/*     */ 
/*     */     
/* 340 */     if (df != null && hasExplicitTimeZone()) {
/* 341 */       df = _force(df, this._timeZone);
/*     */     }
/* 343 */     return new BaseSettings(this._classIntrospector, this._annotationIntrospector, this._propertyNamingStrategy, this._enumNamingStrategy, this._typeFactory, this._typeResolverBuilder, df, this._handlerInstantiator, this._locale, this._timeZone, this._defaultBase64, this._typeValidator, this._accessorNaming, this._cacheProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings withHandlerInstantiator(HandlerInstantiator hi) {
/* 349 */     if (this._handlerInstantiator == hi) {
/* 350 */       return this;
/*     */     }
/* 352 */     return new BaseSettings(this._classIntrospector, this._annotationIntrospector, this._propertyNamingStrategy, this._enumNamingStrategy, this._typeFactory, this._typeResolverBuilder, this._dateFormat, hi, this._locale, this._timeZone, this._defaultBase64, this._typeValidator, this._accessorNaming, this._cacheProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings with(Locale l) {
/* 358 */     if (this._locale == l) {
/* 359 */       return this;
/*     */     }
/* 361 */     return new BaseSettings(this._classIntrospector, this._annotationIntrospector, this._propertyNamingStrategy, this._enumNamingStrategy, this._typeFactory, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator, l, this._timeZone, this._defaultBase64, this._typeValidator, this._accessorNaming, this._cacheProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings with(TimeZone tz) {
/* 373 */     if (tz == this._timeZone) {
/* 374 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 382 */     DateFormat df = _force(this._dateFormat, (tz == null) ? DEFAULT_TIMEZONE : tz);
/* 383 */     return new BaseSettings(this._classIntrospector, this._annotationIntrospector, this._propertyNamingStrategy, this._enumNamingStrategy, this._typeFactory, this._typeResolverBuilder, df, this._handlerInstantiator, this._locale, tz, this._defaultBase64, this._typeValidator, this._accessorNaming, this._cacheProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings with(Base64Variant base64) {
/* 393 */     if (base64 == this._defaultBase64) {
/* 394 */       return this;
/*     */     }
/* 396 */     return new BaseSettings(this._classIntrospector, this._annotationIntrospector, this._propertyNamingStrategy, this._enumNamingStrategy, this._typeFactory, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator, this._locale, this._timeZone, base64, this._typeValidator, this._accessorNaming, this._cacheProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings with(PolymorphicTypeValidator v) {
/* 406 */     if (v == this._typeValidator) {
/* 407 */       return this;
/*     */     }
/* 409 */     return new BaseSettings(this._classIntrospector, this._annotationIntrospector, this._propertyNamingStrategy, this._enumNamingStrategy, this._typeFactory, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator, this._locale, this._timeZone, this._defaultBase64, v, this._accessorNaming, this._cacheProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseSettings with(CacheProvider cacheProvider) {
/* 422 */     if (cacheProvider == this._cacheProvider) {
/* 423 */       return this;
/*     */     }
/* 425 */     return new BaseSettings(this._classIntrospector, this._annotationIntrospector, this._propertyNamingStrategy, this._enumNamingStrategy, this._typeFactory, this._typeResolverBuilder, this._dateFormat, this._handlerInstantiator, this._locale, this._timeZone, this._defaultBase64, this._typeValidator, this._accessorNaming, cacheProvider);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassIntrospector getClassIntrospector() {
/* 438 */     return this._classIntrospector;
/*     */   }
/*     */   
/*     */   public AnnotationIntrospector getAnnotationIntrospector() {
/* 442 */     return this._annotationIntrospector;
/*     */   }
/*     */   
/*     */   public PropertyNamingStrategy getPropertyNamingStrategy() {
/* 446 */     return this._propertyNamingStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumNamingStrategy getEnumNamingStrategy() {
/* 453 */     return this._enumNamingStrategy;
/*     */   }
/*     */   
/*     */   public AccessorNamingStrategy.Provider getAccessorNaming() {
/* 457 */     return this._accessorNaming;
/*     */   }
/*     */   
/*     */   public TypeFactory getTypeFactory() {
/* 461 */     return this._typeFactory;
/*     */   }
/*     */   
/*     */   public TypeResolverBuilder<?> getTypeResolverBuilder() {
/* 465 */     return this._typeResolverBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PolymorphicTypeValidator getPolymorphicTypeValidator() {
/* 472 */     return this._typeValidator;
/*     */   }
/*     */   
/*     */   public DateFormat getDateFormat() {
/* 476 */     return this._dateFormat;
/*     */   }
/*     */   
/*     */   public HandlerInstantiator getHandlerInstantiator() {
/* 480 */     return this._handlerInstantiator;
/*     */   }
/*     */   
/*     */   public Locale getLocale() {
/* 484 */     return this._locale;
/*     */   }
/*     */   
/*     */   public TimeZone getTimeZone() {
/* 488 */     TimeZone tz = this._timeZone;
/* 489 */     return (tz == null) ? DEFAULT_TIMEZONE : tz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasExplicitTimeZone() {
/* 500 */     return (this._timeZone != null);
/*     */   }
/*     */   
/*     */   public Base64Variant getBase64Variant() {
/* 504 */     return this._defaultBase64;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheProvider getCacheProvider() {
/* 511 */     return this._cacheProvider;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DateFormat _force(DateFormat df, TimeZone tz) {
/* 522 */     if (df instanceof StdDateFormat) {
/* 523 */       return (DateFormat)((StdDateFormat)df).withTimeZone(tz);
/*     */     }
/*     */     
/* 526 */     df = (DateFormat)df.clone();
/* 527 */     df.setTimeZone(tz);
/* 528 */     return df;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\cfg\BaseSettings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */