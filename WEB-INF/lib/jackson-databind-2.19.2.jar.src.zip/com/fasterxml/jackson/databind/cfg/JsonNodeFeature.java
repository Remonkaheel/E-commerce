/*     */ package com.fasterxml.jackson.databind.cfg;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum JsonNodeFeature
/*     */   implements DatatypeFeature
/*     */ {
/*  20 */   READ_NULL_PROPERTIES(true),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  28 */   WRITE_NULL_PROPERTIES(true),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   WRITE_PROPERTIES_SORTED(false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   STRIP_TRAILING_BIGDECIMAL_ZEROES(true),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   FAIL_ON_NAN_TO_BIG_DECIMAL_COERCION(false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   USE_BIG_DECIMAL_FOR_FLOATS(false);
/*     */ 
/*     */   
/*     */   private static final int FEATURE_INDEX = 1;
/*     */ 
/*     */   
/*     */   private final boolean _enabledByDefault;
/*     */ 
/*     */   
/*     */   private final int _mask;
/*     */ 
/*     */   
/*     */   JsonNodeFeature(boolean enabledByDefault) {
/* 118 */     this._enabledByDefault = enabledByDefault;
/* 119 */     this._mask = 1 << ordinal();
/*     */   }
/*     */   
/*     */   public boolean enabledByDefault() {
/* 123 */     return this._enabledByDefault;
/*     */   } public boolean enabledIn(int flags) {
/* 125 */     return ((flags & this._mask) != 0);
/*     */   } public int getMask() {
/* 127 */     return this._mask;
/*     */   }
/*     */   
/*     */   public int featureIndex() {
/* 131 */     return 1;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\cfg\JsonNodeFeature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */