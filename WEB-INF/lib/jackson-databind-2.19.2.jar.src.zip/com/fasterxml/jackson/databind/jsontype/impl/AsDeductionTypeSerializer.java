/*    */ package com.fasterxml.jackson.databind.jsontype.impl;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.core.JsonToken;
/*    */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*    */ import com.fasterxml.jackson.databind.BeanProperty;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AsDeductionTypeSerializer
/*    */   extends TypeSerializerBase
/*    */ {
/* 17 */   private static final AsDeductionTypeSerializer INSTANCE = new AsDeductionTypeSerializer();
/*    */   
/*    */   protected AsDeductionTypeSerializer() {
/* 20 */     super(null, null);
/*    */   }
/*    */   
/*    */   public static AsDeductionTypeSerializer instance() {
/* 24 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   
/*    */   public AsDeductionTypeSerializer forProperty(BeanProperty prop) {
/* 29 */     return this;
/*    */   }
/*    */ 
/*    */   
/*    */   public JsonTypeInfo.As getTypeInclusion() {
/* 34 */     return JsonTypeInfo.As.EXISTING_PROPERTY;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WritableTypeId writeTypePrefix(JsonGenerator g, WritableTypeId idMetadata) throws IOException {
/* 44 */     if (idMetadata.valueShape.isStructStart()) {
/*    */ 
/*    */       
/* 47 */       if (g.canWriteTypeId()) {
/* 48 */         idMetadata.wrapperWritten = false;
/* 49 */         if (idMetadata.valueShape == JsonToken.START_OBJECT) {
/* 50 */           g.writeStartObject(idMetadata.forValue);
/* 51 */         } else if (idMetadata.valueShape == JsonToken.START_ARRAY) {
/* 52 */           g.writeStartArray(idMetadata.forValue);
/*    */         } 
/* 54 */         return idMetadata;
/*    */       } 
/*    */       
/* 57 */       return g.writeTypePrefix(idMetadata);
/*    */     } 
/* 59 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WritableTypeId writeTypeSuffix(JsonGenerator g, WritableTypeId idMetadata) throws IOException {
/* 66 */     return (idMetadata == null) ? null : g
/* 67 */       .writeTypeSuffix(idMetadata);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jsontype\impl\AsDeductionTypeSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */