/*    */ package com.fasterxml.jackson.databind.jsontype.impl;
/*    */ 
/*    */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.databind.BeanProperty;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AsExternalTypeSerializer
/*    */   extends TypeSerializerBase
/*    */ {
/*    */   protected final String _typePropertyName;
/*    */   
/*    */   public AsExternalTypeSerializer(TypeIdResolver idRes, BeanProperty property, String propName) {
/* 30 */     super(idRes, property);
/* 31 */     this._typePropertyName = propName;
/*    */   }
/*    */ 
/*    */   
/*    */   public AsExternalTypeSerializer forProperty(BeanProperty prop) {
/* 36 */     return (this._property == prop) ? this : new AsExternalTypeSerializer(this._idResolver, prop, this._typePropertyName);
/*    */   }
/*    */   
/*    */   public String getPropertyName() {
/* 40 */     return this._typePropertyName;
/*    */   }
/*    */   public JsonTypeInfo.As getTypeInclusion() {
/* 43 */     return JsonTypeInfo.As.EXTERNAL_PROPERTY;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final void _writeScalarPrefix(Object value, JsonGenerator g) throws IOException {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final void _writeObjectPrefix(Object value, JsonGenerator g) throws IOException {
/* 55 */     g.writeStartObject();
/*    */   }
/*    */   
/*    */   protected final void _writeArrayPrefix(Object value, JsonGenerator g) throws IOException {
/* 59 */     g.writeStartArray();
/*    */   }
/*    */   
/*    */   protected final void _writeScalarSuffix(Object value, JsonGenerator g, String typeId) throws IOException {
/* 63 */     if (typeId != null) {
/* 64 */       g.writeStringField(this._typePropertyName, typeId);
/*    */     }
/*    */   }
/*    */   
/*    */   protected final void _writeObjectSuffix(Object value, JsonGenerator g, String typeId) throws IOException {
/* 69 */     g.writeEndObject();
/* 70 */     if (typeId != null) {
/* 71 */       g.writeStringField(this._typePropertyName, typeId);
/*    */     }
/*    */   }
/*    */   
/*    */   protected final void _writeArraySuffix(Object value, JsonGenerator g, String typeId) throws IOException {
/* 76 */     g.writeEndArray();
/* 77 */     if (typeId != null)
/* 78 */       g.writeStringField(this._typePropertyName, typeId); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jsontype\impl\AsExternalTypeSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */