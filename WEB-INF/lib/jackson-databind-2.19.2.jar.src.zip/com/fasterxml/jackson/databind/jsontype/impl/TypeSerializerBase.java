/*     */ package com.fasterxml.jackson.databind.jsontype.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TypeSerializerBase
/*     */   extends TypeSerializer
/*     */ {
/*     */   protected final TypeIdResolver _idResolver;
/*     */   protected final BeanProperty _property;
/*     */   
/*     */   protected TypeSerializerBase(TypeIdResolver idRes, BeanProperty property) {
/*  22 */     this._idResolver = idRes;
/*  23 */     this._property = property;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonTypeInfo.As getTypeInclusion();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getPropertyName() {
/*  36 */     return null;
/*     */   }
/*     */   public TypeIdResolver getTypeIdResolver() {
/*  39 */     return this._idResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableTypeId writeTypePrefix(JsonGenerator g, WritableTypeId idMetadata) throws IOException {
/*  45 */     _generateTypeId(idMetadata);
/*     */ 
/*     */ 
/*     */     
/*  49 */     if (idMetadata.id == null) {
/*  50 */       return _writeTypePrefixForNull(g, idMetadata);
/*     */     }
/*  52 */     return g.writeTypePrefix(idMetadata);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableTypeId writeTypeSuffix(JsonGenerator g, WritableTypeId idMetadata) throws IOException {
/*  61 */     if (idMetadata == null) {
/*  62 */       return _writeTypeSuffixfixForNull(g, idMetadata);
/*     */     }
/*  64 */     return g.writeTypeSuffix(idMetadata);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WritableTypeId _writeTypePrefixForNull(JsonGenerator g, WritableTypeId typeIdDef) throws IOException {
/*  71 */     JsonToken valueShape = typeIdDef.valueShape;
/*  72 */     typeIdDef.wrapperWritten = false;
/*  73 */     if (valueShape == JsonToken.START_OBJECT) {
/*  74 */       g.writeStartObject(typeIdDef.forValue);
/*  75 */     } else if (valueShape == JsonToken.START_ARRAY) {
/*     */       
/*  77 */       g.writeStartArray(typeIdDef.forValue);
/*     */     } 
/*     */     
/*  80 */     return typeIdDef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WritableTypeId _writeTypeSuffixfixForNull(JsonGenerator g, WritableTypeId typeIdDef) throws IOException {
/*  87 */     JsonToken valueShape = typeIdDef.valueShape;
/*     */     
/*  89 */     if (valueShape == JsonToken.START_OBJECT) {
/*  90 */       g.writeEndObject();
/*  91 */     } else if (valueShape == JsonToken.START_ARRAY) {
/*  92 */       g.writeEndArray();
/*     */     } 
/*  94 */     return typeIdDef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _generateTypeId(WritableTypeId idMetadata) {
/* 103 */     Object id = idMetadata.id;
/* 104 */     if (id == null) {
/* 105 */       Object value = idMetadata.forValue;
/* 106 */       Class<?> typeForId = idMetadata.forValueType;
/* 107 */       if (typeForId == null) {
/* 108 */         id = idFromValue(value);
/*     */       } else {
/* 110 */         id = idFromValueAndType(value, typeForId);
/*     */       } 
/* 112 */       idMetadata.id = id;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String idFromValue(Object value) {
/* 123 */     String id = this._idResolver.idFromValue(value);
/* 124 */     if (id == null) {
/* 125 */       handleMissingId(value);
/*     */     }
/* 127 */     return id;
/*     */   }
/*     */   
/*     */   protected String idFromValueAndType(Object value, Class<?> type) {
/* 131 */     String id = this._idResolver.idFromValueAndType(value, type);
/* 132 */     if (id == null) {
/* 133 */       handleMissingId(value);
/*     */     }
/* 135 */     return id;
/*     */   }
/*     */   
/*     */   protected void handleMissingId(Object value) {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jsontype\impl\TypeSerializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */