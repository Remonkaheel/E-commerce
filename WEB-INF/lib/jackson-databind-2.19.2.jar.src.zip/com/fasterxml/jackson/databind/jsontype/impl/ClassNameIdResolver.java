/*     */ package com.fasterxml.jackson.databind.jsontype.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.databind.DatabindContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.EnumMap;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassNameIdResolver
/*     */   extends TypeIdResolverBase
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String JAVA_UTIL_PKG = "java.util.";
/*     */   protected final PolymorphicTypeValidator _subTypeValidator;
/*     */   protected final Set<String> _allowedSubtypes;
/*     */   
/*     */   @Deprecated
/*     */   protected ClassNameIdResolver(JavaType baseType, TypeFactory typeFactory) {
/*  40 */     this(baseType, typeFactory, (PolymorphicTypeValidator)LaissezFaireSubTypeValidator.instance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public ClassNameIdResolver(JavaType baseType, TypeFactory typeFactory, PolymorphicTypeValidator ptv) {
/*  50 */     this(baseType, typeFactory, (Collection<NamedType>)null, ptv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ClassNameIdResolver(JavaType baseType, TypeFactory typeFactory, Collection<NamedType> subtypes, PolymorphicTypeValidator ptv) {
/*  58 */     super(baseType, typeFactory);
/*  59 */     this._subTypeValidator = ptv;
/*  60 */     Set<String> allowedSubtypes = null;
/*  61 */     if (subtypes != null) {
/*  62 */       for (NamedType t : subtypes) {
/*  63 */         if (allowedSubtypes == null) {
/*  64 */           allowedSubtypes = new HashSet<>();
/*     */         }
/*  66 */         allowedSubtypes.add(t.getType().getName());
/*     */       } 
/*     */     }
/*  69 */     this._allowedSubtypes = (allowedSubtypes == null) ? Collections.<String>emptySet() : allowedSubtypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static ClassNameIdResolver construct(JavaType baseType, MapperConfig<?> config, PolymorphicTypeValidator ptv) {
/*  78 */     return new ClassNameIdResolver(baseType, config.getTypeFactory(), ptv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ClassNameIdResolver construct(JavaType baseType, MapperConfig<?> config, Collection<NamedType> subtypes, PolymorphicTypeValidator ptv) {
/*  87 */     return new ClassNameIdResolver(baseType, config.getTypeFactory(), subtypes, ptv);
/*     */   }
/*     */   
/*     */   public JsonTypeInfo.Id getMechanism() {
/*  91 */     return JsonTypeInfo.Id.CLASS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void registerSubtype(Class<?> type, String name) {}
/*     */ 
/*     */   
/*     */   public String idFromValue(Object value) {
/* 101 */     return _idFrom(value, value.getClass(), this._typeFactory);
/*     */   }
/*     */ 
/*     */   
/*     */   public String idFromValueAndType(Object value, Class<?> type) {
/* 106 */     return _idFrom(value, type, this._typeFactory);
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType typeFromId(DatabindContext context, String id) throws IOException {
/* 111 */     return _typeFromId(id, context);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JavaType _typeFromId(String id, DatabindContext ctxt) throws IOException {
/* 116 */     DeserializationContext deserializationContext = null;
/* 117 */     if (ctxt instanceof DeserializationContext) {
/* 118 */       deserializationContext = (DeserializationContext)ctxt;
/*     */     }
/* 120 */     if (this._allowedSubtypes != null && deserializationContext != null && deserializationContext
/* 121 */       .isEnabled(DeserializationFeature.FAIL_ON_SUBTYPE_CLASS_NOT_REGISTERED))
/*     */     {
/* 123 */       if (!this._allowedSubtypes.contains(id)) {
/* 124 */         throw deserializationContext.invalidTypeIdException(this._baseType, id, "`DeserializationFeature.FAIL_ON_SUBTYPE_CLASS_NOT_REGISTERED` is enabled and the input class is not registered using `@JsonSubTypes` annotation");
/*     */       }
/*     */     }
/*     */     
/* 128 */     JavaType t = ctxt.resolveAndValidateSubType(this._baseType, id, this._subTypeValidator);
/* 129 */     if (t == null && deserializationContext != null) {
/* 130 */       return deserializationContext.handleUnknownTypeId(this._baseType, id, this, "no such class found");
/*     */     }
/* 132 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String _idFrom(Object value, Class<?> cls, TypeFactory typeFactory) {
/* 143 */     cls = _resolveToParentAsNecessary(cls);
/* 144 */     String str = cls.getName();
/* 145 */     if (str.startsWith("java.util.")) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 152 */       if (value instanceof EnumSet) {
/* 153 */         Class<?> enumClass = ClassUtil.findEnumType((EnumSet)value);
/*     */         
/* 155 */         str = typeFactory.constructCollectionType(EnumSet.class, enumClass).toCanonical();
/* 156 */       } else if (value instanceof EnumMap) {
/* 157 */         Class<?> enumClass = ClassUtil.findEnumType((EnumMap)value);
/* 158 */         Class<?> valueClass = Object.class;
/*     */         
/* 160 */         str = typeFactory.constructMapType(EnumMap.class, enumClass, valueClass).toCanonical();
/*     */       }
/*     */     
/*     */     }
/* 164 */     else if (str.indexOf('$') >= 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 172 */       Class<?> outer = ClassUtil.getOuterClass(cls);
/* 173 */       if (outer != null) {
/*     */ 
/*     */         
/* 176 */         Class<?> staticType = this._baseType.getRawClass();
/* 177 */         if (ClassUtil.getOuterClass(staticType) == null) {
/*     */           
/* 179 */           cls = this._baseType.getRawClass();
/* 180 */           str = cls.getName();
/*     */         } 
/*     */       } 
/*     */     } 
/* 184 */     return str;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescForKnownTypeIds() {
/* 189 */     return "class name used as type id";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jsontype\impl\ClassNameIdResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */