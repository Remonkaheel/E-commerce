/*     */ package com.fasterxml.jackson.databind.jsontype.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.util.JsonParserSequence;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsWrapperTypeDeserializer
/*     */   extends TypeDeserializerBase
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public AsWrapperTypeDeserializer(JavaType bt, TypeIdResolver idRes, String typePropertyName, boolean typeIdVisible, JavaType defaultImpl) {
/*  33 */     super(bt, idRes, typePropertyName, typeIdVisible, defaultImpl);
/*     */   }
/*     */   
/*     */   protected AsWrapperTypeDeserializer(AsWrapperTypeDeserializer src, BeanProperty property) {
/*  37 */     super(src, property);
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeDeserializer forProperty(BeanProperty prop) {
/*  42 */     return (prop == this._property) ? this : new AsWrapperTypeDeserializer(this, prop);
/*     */   }
/*     */   
/*     */   public JsonTypeInfo.As getTypeInclusion() {
/*  46 */     return JsonTypeInfo.As.WRAPPER_OBJECT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeTypedFromObject(JsonParser jp, DeserializationContext ctxt) throws IOException {
/*  53 */     return _deserialize(jp, ctxt);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object deserializeTypedFromArray(JsonParser jp, DeserializationContext ctxt) throws IOException {
/*  58 */     return _deserialize(jp, ctxt);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object deserializeTypedFromScalar(JsonParser jp, DeserializationContext ctxt) throws IOException {
/*  63 */     return _deserialize(jp, ctxt);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object deserializeTypedFromAny(JsonParser jp, DeserializationContext ctxt) throws IOException {
/*  68 */     return _deserialize(jp, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*     */     JsonParserSequence jsonParserSequence;
/*  86 */     if (p.canReadTypeId()) {
/*  87 */       Object object = p.getTypeId();
/*  88 */       if (object != null) {
/*  89 */         return _deserializeWithNativeTypeId(p, ctxt, object);
/*     */       }
/*     */     } 
/*     */     
/*  93 */     JsonToken t = p.currentToken();
/*  94 */     if (t == JsonToken.START_OBJECT) {
/*     */       
/*  96 */       if (p.nextToken() != JsonToken.FIELD_NAME) {
/*  97 */         ctxt.reportWrongTokenException(baseType(), JsonToken.FIELD_NAME, "need JSON String that contains type id (for subtype of " + 
/*  98 */             baseTypeName() + ")", new Object[0]);
/*     */       }
/* 100 */     } else if (t != JsonToken.FIELD_NAME) {
/* 101 */       ctxt.reportWrongTokenException(baseType(), JsonToken.START_OBJECT, "need JSON Object to contain As.WRAPPER_OBJECT type information for class " + 
/* 102 */           baseTypeName(), new Object[0]);
/*     */     } 
/* 104 */     String typeId = p.getText();
/* 105 */     JsonDeserializer<Object> deser = _findDeserializer(ctxt, typeId);
/* 106 */     p.nextToken();
/*     */ 
/*     */     
/* 109 */     if (this._typeIdVisible && p.hasToken(JsonToken.START_OBJECT)) {
/*     */       
/* 111 */       TokenBuffer tb = ctxt.bufferForInputBuffering(p);
/* 112 */       tb.writeStartObject();
/* 113 */       tb.writeFieldName(this._typePropertyName);
/* 114 */       tb.writeString(typeId);
/*     */ 
/*     */       
/* 117 */       p.clearCurrentToken();
/* 118 */       jsonParserSequence = JsonParserSequence.createFlattened(false, tb.asParser(p), p);
/* 119 */       jsonParserSequence.nextToken();
/*     */     } 
/*     */     
/* 122 */     Object value = deser.deserialize((JsonParser)jsonParserSequence, ctxt);
/*     */     
/* 124 */     if (jsonParserSequence.nextToken() != JsonToken.END_OBJECT) {
/* 125 */       ctxt.reportWrongTokenException(baseType(), JsonToken.END_OBJECT, "expected closing END_OBJECT after type information and deserialized value", new Object[0]);
/*     */     }
/*     */     
/* 128 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jsontype\impl\AsWrapperTypeDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */