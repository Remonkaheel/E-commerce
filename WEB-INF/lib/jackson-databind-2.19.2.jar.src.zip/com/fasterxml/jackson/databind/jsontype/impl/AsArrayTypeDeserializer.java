/*     */ package com.fasterxml.jackson.databind.jsontype.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.util.JsonParserSequence;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsArrayTypeDeserializer
/*     */   extends TypeDeserializerBase
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   public AsArrayTypeDeserializer(JavaType bt, TypeIdResolver idRes, String typePropertyName, boolean typeIdVisible, JavaType defaultImpl) {
/*  34 */     super(bt, idRes, typePropertyName, typeIdVisible, defaultImpl);
/*     */   }
/*     */   
/*     */   public AsArrayTypeDeserializer(AsArrayTypeDeserializer src, BeanProperty property) {
/*  38 */     super(src, property);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDeserializer forProperty(BeanProperty prop) {
/*  44 */     return (prop == this._property) ? this : new AsArrayTypeDeserializer(this, prop);
/*     */   }
/*     */   
/*     */   public JsonTypeInfo.As getTypeInclusion() {
/*  48 */     return JsonTypeInfo.As.WRAPPER_ARRAY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeTypedFromArray(JsonParser jp, DeserializationContext ctxt) throws IOException {
/*  55 */     return _deserialize(jp, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeTypedFromObject(JsonParser jp, DeserializationContext ctxt) throws IOException {
/*  63 */     return _deserialize(jp, ctxt);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object deserializeTypedFromScalar(JsonParser jp, DeserializationContext ctxt) throws IOException {
/*  68 */     return _deserialize(jp, ctxt);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object deserializeTypedFromAny(JsonParser jp, DeserializationContext ctxt) throws IOException {
/*  73 */     return _deserialize(jp, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*     */     JsonParserSequence jsonParserSequence;
/*  91 */     if (p.canReadTypeId()) {
/*  92 */       Object object = p.getTypeId();
/*  93 */       if (object != null) {
/*  94 */         return _deserializeWithNativeTypeId(p, ctxt, object);
/*     */       }
/*     */     } 
/*  97 */     boolean hadStartArray = p.isExpectedStartArrayToken();
/*  98 */     String typeId = _locateTypeId(p, ctxt);
/*  99 */     JsonDeserializer<Object> deser = _findDeserializer(ctxt, typeId);
/*     */     
/* 101 */     if (this._typeIdVisible && 
/*     */ 
/*     */ 
/*     */       
/* 105 */       !_usesExternalId() && p
/* 106 */       .hasToken(JsonToken.START_OBJECT)) {
/*     */       
/* 108 */       TokenBuffer tb = ctxt.bufferForInputBuffering(p);
/* 109 */       tb.writeStartObject();
/* 110 */       tb.writeFieldName(this._typePropertyName);
/* 111 */       tb.writeString(typeId);
/*     */ 
/*     */       
/* 114 */       p.clearCurrentToken();
/* 115 */       jsonParserSequence = JsonParserSequence.createFlattened(false, tb.asParser(p), p);
/* 116 */       jsonParserSequence.nextToken();
/*     */     } 
/*     */     
/* 119 */     if (hadStartArray && jsonParserSequence.currentToken() == JsonToken.END_ARRAY) {
/* 120 */       return deser.getNullValue(ctxt);
/*     */     }
/* 122 */     Object value = deser.deserialize((JsonParser)jsonParserSequence, ctxt);
/*     */     
/* 124 */     if (hadStartArray && jsonParserSequence.nextToken() != JsonToken.END_ARRAY) {
/* 125 */       ctxt.reportWrongTokenException(baseType(), JsonToken.END_ARRAY, "expected closing `JsonToken.END_ARRAY` after type information and deserialized value", new Object[0]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String _locateTypeId(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 137 */     if (!p.isExpectedStartArrayToken()) {
/*     */ 
/*     */       
/* 140 */       if (this._defaultImpl != null) {
/* 141 */         String id = this._idResolver.idFromBaseType();
/* 142 */         if (id == null) {
/* 143 */           ctxt.reportBadDefinition(this._idResolver.getClass(), "`idFromBaseType()` (of " + 
/*     */               
/* 145 */               ClassUtil.classNameOf(this._idResolver) + ") returned `null`");
/*     */         }
/* 147 */         return id;
/*     */       } 
/* 149 */       ctxt.reportWrongTokenException(baseType(), JsonToken.START_ARRAY, "need Array value to contain `As.WRAPPER_ARRAY` type information for class " + 
/* 150 */           baseTypeName(), new Object[0]);
/* 151 */       return null;
/*     */     } 
/*     */     
/* 154 */     JsonToken t = p.nextToken();
/* 155 */     if (t == JsonToken.VALUE_STRING || (t != null && t
/*     */       
/* 157 */       .isScalarValue())) {
/* 158 */       String result = p.getText();
/* 159 */       p.nextToken();
/* 160 */       return result;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     ctxt.reportWrongTokenException(baseType(), JsonToken.VALUE_STRING, "need String, Number of Boolean value that contains type id (for subtype of %s)", new Object[] {
/*     */           
/* 176 */           baseTypeName() });
/* 177 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _usesExternalId() {
/* 184 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jsontype\impl\AsArrayTypeDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */