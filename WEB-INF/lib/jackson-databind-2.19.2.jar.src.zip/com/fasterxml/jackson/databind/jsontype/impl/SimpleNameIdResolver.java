/*     */ package com.fasterxml.jackson.databind.jsontype.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DatabindContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleNameIdResolver
/*     */   extends TypeIdResolverBase
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final MapperConfig<?> _config;
/*     */   protected final ConcurrentHashMap<String, String> _typeToId;
/*     */   protected final Map<String, JavaType> _idToType;
/*     */   protected final boolean _caseInsensitive;
/*     */   
/*     */   protected SimpleNameIdResolver(MapperConfig<?> config, JavaType baseType, ConcurrentHashMap<String, String> typeToId, HashMap<String, JavaType> idToType) {
/*  51 */     super(baseType, config.getTypeFactory());
/*  52 */     this._config = config;
/*  53 */     this._typeToId = typeToId;
/*  54 */     this._idToType = idToType;
/*  55 */     this._caseInsensitive = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_VALUES);
/*     */   }
/*     */ 
/*     */   
/*     */   public static SimpleNameIdResolver construct(MapperConfig<?> config, JavaType baseType, Collection<NamedType> subtypes, boolean forSer, boolean forDeser) {
/*     */     ConcurrentHashMap<String, String> typeToId;
/*     */     HashMap<String, JavaType> idToType;
/*  62 */     if (forSer == forDeser) throw new IllegalArgumentException();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     if (forSer) {
/*     */ 
/*     */       
/*  70 */       typeToId = new ConcurrentHashMap<>();
/*  71 */       idToType = null;
/*     */     } else {
/*  73 */       idToType = new HashMap<>();
/*     */ 
/*     */ 
/*     */       
/*  77 */       typeToId = new ConcurrentHashMap<>(4);
/*     */     } 
/*  79 */     boolean caseInsensitive = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_VALUES);
/*     */     
/*  81 */     if (subtypes != null) {
/*  82 */       for (NamedType t : subtypes) {
/*     */ 
/*     */         
/*  85 */         Class<?> cls = t.getType();
/*  86 */         String id = t.hasName() ? t.getName() : _defaultTypeId(cls);
/*  87 */         if (forSer) {
/*  88 */           typeToId.put(cls.getName(), id);
/*     */         }
/*  90 */         if (forDeser) {
/*     */           
/*  92 */           if (caseInsensitive) {
/*  93 */             id = id.toLowerCase();
/*     */           }
/*     */ 
/*     */           
/*  97 */           JavaType prev = idToType.get(id);
/*  98 */           if (prev != null && 
/*  99 */             cls.isAssignableFrom(prev.getRawClass())) {
/*     */             continue;
/*     */           }
/*     */           
/* 103 */           idToType.put(id, config.constructType(cls));
/*     */         } 
/*     */       } 
/*     */     }
/* 107 */     return new SimpleNameIdResolver(config, baseType, typeToId, idToType);
/*     */   }
/*     */   
/*     */   public JsonTypeInfo.Id getMechanism() {
/* 111 */     return JsonTypeInfo.Id.SIMPLE_NAME;
/*     */   }
/*     */   
/*     */   public String idFromValue(Object value) {
/* 115 */     return idFromClass(value.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   protected String idFromClass(Class<?> clazz) {
/* 120 */     if (clazz == null) {
/* 121 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 125 */     clazz = _resolveToParentAsNecessary(clazz);
/*     */ 
/*     */ 
/*     */     
/* 129 */     String key = clazz.getName();
/* 130 */     String name = this._typeToId.get(key);
/*     */     
/* 132 */     if (name == null) {
/*     */ 
/*     */       
/* 135 */       Class<?> cls = this._typeFactory.constructType(clazz).getRawClass();
/*     */ 
/*     */       
/* 138 */       if (this._config.isAnnotationProcessingEnabled()) {
/* 139 */         BeanDescription beanDesc = this._config.introspectClassAnnotations(cls);
/* 140 */         name = this._config.getAnnotationIntrospector().findTypeName(beanDesc.getClassInfo());
/*     */       } 
/* 142 */       if (name == null)
/*     */       {
/* 144 */         name = _defaultTypeId(cls);
/*     */       }
/* 146 */       this._typeToId.put(key, name);
/*     */     } 
/* 148 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String idFromValueAndType(Object value, Class<?> type) {
/* 155 */     if (value == null) {
/* 156 */       return idFromClass(type);
/*     */     }
/* 158 */     return idFromValue(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType typeFromId(DatabindContext context, String id) {
/* 163 */     return _typeFromId(id);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JavaType _typeFromId(String id) {
/* 168 */     if (this._caseInsensitive) {
/* 169 */       id = id.toLowerCase();
/*     */     }
/* 171 */     return this._idToType.get(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescForKnownTypeIds() {
/* 178 */     TreeSet<String> ids = new TreeSet<>();
/* 179 */     for (Map.Entry<String, JavaType> entry : this._idToType.entrySet()) {
/* 180 */       if (((JavaType)entry.getValue()).isConcrete()) {
/* 181 */         ids.add(entry.getKey());
/*     */       }
/*     */     } 
/* 184 */     return ids.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 189 */     return String.format("[%s; id-to-type=%s]", new Object[] { getClass().getName(), this._idToType });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String _defaultTypeId(Class<?> cls) {
/* 204 */     String n = cls.getName();
/* 205 */     int ix = Math.max(n.lastIndexOf('.'), n.lastIndexOf('$'));
/* 206 */     return (ix < 0) ? n : n.substring(ix + 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jsontype\impl\SimpleNameIdResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */