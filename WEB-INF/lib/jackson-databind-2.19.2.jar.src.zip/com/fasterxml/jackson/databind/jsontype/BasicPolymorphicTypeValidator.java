/*     */ package com.fasterxml.jackson.databind.jsontype;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicPolymorphicTypeValidator
/*     */   extends PolymorphicTypeValidator.Base
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final Set<Class<?>> _invalidBaseTypes;
/*     */   protected final TypeMatcher[] _baseTypeMatchers;
/*     */   protected final NameMatcher[] _subTypeNameMatchers;
/*     */   protected final TypeMatcher[] _subClassMatchers;
/*     */   
/*     */   public static abstract class TypeMatcher
/*     */   {
/*     */     public abstract boolean match(MapperConfig<?> param1MapperConfig, Class<?> param1Class);
/*     */   }
/*     */   
/*     */   public static abstract class NameMatcher
/*     */   {
/*     */     public abstract boolean match(MapperConfig<?> param1MapperConfig, String param1String);
/*     */   }
/*     */   
/*     */   public static class Builder
/*     */   {
/*     */     protected Set<Class<?>> _invalidBaseTypes;
/*     */     protected List<BasicPolymorphicTypeValidator.TypeMatcher> _baseTypeMatchers;
/*     */     protected List<BasicPolymorphicTypeValidator.NameMatcher> _subTypeNameMatchers;
/*     */     protected List<BasicPolymorphicTypeValidator.TypeMatcher> _subTypeClassMatchers;
/*     */     
/*     */     public Builder allowIfBaseType(final Class<?> baseOfBase) {
/* 106 */       return _appendBaseMatcher(new BasicPolymorphicTypeValidator.TypeMatcher()
/*     */           {
/*     */             public boolean match(MapperConfig<?> config, Class<?> clazz) {
/* 109 */               return baseOfBase.isAssignableFrom(clazz);
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder allowIfBaseType(final Pattern patternForBase) {
/* 132 */       return _appendBaseMatcher(new BasicPolymorphicTypeValidator.TypeMatcher()
/*     */           {
/*     */             public boolean match(MapperConfig<?> config, Class<?> clazz) {
/* 135 */               return patternForBase.matcher(clazz.getName()).matches();
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder allowIfBaseType(final String prefixForBase) {
/* 152 */       return _appendBaseMatcher(new BasicPolymorphicTypeValidator.TypeMatcher()
/*     */           {
/*     */             public boolean match(MapperConfig<?> config, Class<?> clazz) {
/* 155 */               return clazz.getName().startsWith(prefixForBase);
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder allowIfBaseType(BasicPolymorphicTypeValidator.TypeMatcher matcher) {
/* 172 */       return _appendBaseMatcher(matcher);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder denyForExactBaseType(Class<?> baseTypeToDeny) {
/* 188 */       if (this._invalidBaseTypes == null) {
/* 189 */         this._invalidBaseTypes = new HashSet<>();
/*     */       }
/* 191 */       this._invalidBaseTypes.add(baseTypeToDeny);
/* 192 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder allowIfSubType(final Class<?> subTypeBase) {
/* 209 */       return _appendSubClassMatcher(new BasicPolymorphicTypeValidator.TypeMatcher()
/*     */           {
/*     */             public boolean match(MapperConfig<?> config, Class<?> clazz) {
/* 212 */               return subTypeBase.isAssignableFrom(clazz);
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder allowIfSubType(final Pattern patternForSubType) {
/* 234 */       return _appendSubNameMatcher(new BasicPolymorphicTypeValidator.NameMatcher()
/*     */           {
/*     */             public boolean match(MapperConfig<?> config, String clazzName) {
/* 237 */               return patternForSubType.matcher(clazzName).matches();
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder allowIfSubType(final String prefixForSubType) {
/* 254 */       return _appendSubNameMatcher(new BasicPolymorphicTypeValidator.NameMatcher()
/*     */           {
/*     */             public boolean match(MapperConfig<?> config, String clazzName) {
/* 257 */               return clazzName.startsWith(prefixForSubType);
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder allowIfSubType(BasicPolymorphicTypeValidator.TypeMatcher matcher) {
/* 274 */       return _appendSubClassMatcher(matcher);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder allowIfSubTypeIsArray() {
/* 292 */       return _appendSubClassMatcher(new BasicPolymorphicTypeValidator.TypeMatcher()
/*     */           {
/*     */             public boolean match(MapperConfig<?> config, Class<?> clazz) {
/* 295 */               return clazz.isArray();
/*     */             }
/*     */           });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BasicPolymorphicTypeValidator build() {
/* 320 */       return new BasicPolymorphicTypeValidator(this._invalidBaseTypes, (this._baseTypeMatchers == null) ? null : this._baseTypeMatchers
/* 321 */           .<BasicPolymorphicTypeValidator.TypeMatcher>toArray(new BasicPolymorphicTypeValidator.TypeMatcher[0]), (this._subTypeNameMatchers == null) ? null : this._subTypeNameMatchers
/* 322 */           .<BasicPolymorphicTypeValidator.NameMatcher>toArray(new BasicPolymorphicTypeValidator.NameMatcher[0]), (this._subTypeClassMatchers == null) ? null : this._subTypeClassMatchers
/* 323 */           .<BasicPolymorphicTypeValidator.TypeMatcher>toArray(new BasicPolymorphicTypeValidator.TypeMatcher[0]));
/*     */     }
/*     */ 
/*     */     
/*     */     protected Builder _appendBaseMatcher(BasicPolymorphicTypeValidator.TypeMatcher matcher) {
/* 328 */       if (this._baseTypeMatchers == null) {
/* 329 */         this._baseTypeMatchers = new ArrayList<>();
/*     */       }
/* 331 */       this._baseTypeMatchers.add(matcher);
/* 332 */       return this;
/*     */     }
/*     */     
/*     */     protected Builder _appendSubNameMatcher(BasicPolymorphicTypeValidator.NameMatcher matcher) {
/* 336 */       if (this._subTypeNameMatchers == null) {
/* 337 */         this._subTypeNameMatchers = new ArrayList<>();
/*     */       }
/* 339 */       this._subTypeNameMatchers.add(matcher);
/* 340 */       return this;
/*     */     }
/*     */     
/*     */     protected Builder _appendSubClassMatcher(BasicPolymorphicTypeValidator.TypeMatcher matcher) {
/* 344 */       if (this._subTypeClassMatchers == null) {
/* 345 */         this._subTypeClassMatchers = new ArrayList<>();
/*     */       }
/* 347 */       this._subTypeClassMatchers.add(matcher);
/* 348 */       return this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BasicPolymorphicTypeValidator(Set<Class<?>> invalidBaseTypes, TypeMatcher[] baseTypeMatchers, NameMatcher[] subTypeNameMatchers, TypeMatcher[] subClassMatchers) {
/* 386 */     this._invalidBaseTypes = invalidBaseTypes;
/* 387 */     this._baseTypeMatchers = baseTypeMatchers;
/* 388 */     this._subTypeNameMatchers = subTypeNameMatchers;
/* 389 */     this._subClassMatchers = subClassMatchers;
/*     */   }
/*     */   
/*     */   public static Builder builder() {
/* 393 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PolymorphicTypeValidator.Validity validateBaseType(MapperConfig<?> ctxt, JavaType baseType) {
/* 399 */     Class<?> rawBase = baseType.getRawClass();
/* 400 */     if (this._invalidBaseTypes != null && 
/* 401 */       this._invalidBaseTypes.contains(rawBase)) {
/* 402 */       return PolymorphicTypeValidator.Validity.DENIED;
/*     */     }
/*     */     
/* 405 */     if (this._baseTypeMatchers != null) {
/* 406 */       for (TypeMatcher m : this._baseTypeMatchers) {
/* 407 */         if (m.match(ctxt, rawBase)) {
/* 408 */           return PolymorphicTypeValidator.Validity.ALLOWED;
/*     */         }
/*     */       } 
/*     */     }
/* 412 */     return PolymorphicTypeValidator.Validity.INDETERMINATE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PolymorphicTypeValidator.Validity validateSubClassName(MapperConfig<?> ctxt, JavaType baseType, String subClassName) throws JsonMappingException {
/* 421 */     if (this._subTypeNameMatchers != null) {
/* 422 */       for (NameMatcher m : this._subTypeNameMatchers) {
/* 423 */         if (m.match(ctxt, subClassName)) {
/* 424 */           return PolymorphicTypeValidator.Validity.ALLOWED;
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 429 */     return PolymorphicTypeValidator.Validity.INDETERMINATE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PolymorphicTypeValidator.Validity validateSubType(MapperConfig<?> ctxt, JavaType baseType, JavaType subType) throws JsonMappingException {
/* 437 */     if (this._subClassMatchers != null) {
/* 438 */       Class<?> subClass = subType.getRawClass();
/* 439 */       for (TypeMatcher m : this._subClassMatchers) {
/* 440 */         if (m.match(ctxt, subClass)) {
/* 441 */           return PolymorphicTypeValidator.Validity.ALLOWED;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 446 */     return PolymorphicTypeValidator.Validity.INDETERMINATE;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jsontype\BasicPolymorphicTypeValidator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */