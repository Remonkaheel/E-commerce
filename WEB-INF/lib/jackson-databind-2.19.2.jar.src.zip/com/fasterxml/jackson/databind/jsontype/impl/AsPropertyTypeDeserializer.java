/*     */ package com.fasterxml.jackson.databind.jsontype.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.util.JsonParserSequence;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import com.fasterxml.jackson.databind.util.TokenBuffer;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsPropertyTypeDeserializer
/*     */   extends AsArrayTypeDeserializer
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JsonTypeInfo.As _inclusion;
/*     */   protected final boolean _strictTypeIdHandling;
/*  38 */   protected final String _msgForMissingId = (this._property == null) ? 
/*  39 */     String.format("missing type id property '%s'", new Object[] { this._typePropertyName
/*  40 */       }) : String.format("missing type id property '%s' (for POJO property '%s')", new Object[] { this._typePropertyName, this._property.getName() });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public AsPropertyTypeDeserializer(JavaType bt, TypeIdResolver idRes, String typePropertyName, boolean typeIdVisible, JavaType defaultImpl) {
/*  51 */     this(bt, idRes, typePropertyName, typeIdVisible, defaultImpl, JsonTypeInfo.As.PROPERTY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public AsPropertyTypeDeserializer(JavaType bt, TypeIdResolver idRes, String typePropertyName, boolean typeIdVisible, JavaType defaultImpl, JsonTypeInfo.As inclusion) {
/*  64 */     this(bt, idRes, typePropertyName, typeIdVisible, defaultImpl, inclusion, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public AsPropertyTypeDeserializer(AsPropertyTypeDeserializer src, BeanProperty property) {
/*  69 */     super(src, property);
/*  70 */     this._inclusion = src._inclusion;
/*  71 */     this._strictTypeIdHandling = src._strictTypeIdHandling;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AsPropertyTypeDeserializer(JavaType bt, TypeIdResolver idRes, String typePropertyName, boolean typeIdVisible, JavaType defaultImpl, JsonTypeInfo.As inclusion, boolean strictTypeIdHandling) {
/*  81 */     super(bt, idRes, typePropertyName, typeIdVisible, defaultImpl);
/*  82 */     this._inclusion = inclusion;
/*  83 */     this._strictTypeIdHandling = strictTypeIdHandling;
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeDeserializer forProperty(BeanProperty prop) {
/*  88 */     return (prop == this._property) ? this : new AsPropertyTypeDeserializer(this, prop);
/*     */   }
/*     */   
/*     */   public JsonTypeInfo.As getTypeInclusion() {
/*  92 */     return this._inclusion;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeTypedFromObject(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 102 */     if (p.canReadTypeId()) {
/* 103 */       Object typeId = p.getTypeId();
/* 104 */       if (typeId != null) {
/* 105 */         return _deserializeWithNativeTypeId(p, ctxt, typeId);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 110 */     JsonToken t = p.currentToken();
/* 111 */     if (t == JsonToken.START_OBJECT) {
/* 112 */       t = p.nextToken();
/* 113 */     } else if (t != JsonToken.FIELD_NAME) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 121 */       return _deserializeTypedUsingDefaultImpl(p, ctxt, (TokenBuffer)null, this._msgForMissingId);
/*     */     } 
/*     */     
/* 124 */     TokenBuffer tb = null;
/* 125 */     boolean ignoreCase = ctxt.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES);
/*     */     
/* 127 */     for (; t == JsonToken.FIELD_NAME; t = p.nextToken()) {
/* 128 */       String name = p.currentName();
/* 129 */       p.nextToken();
/* 130 */       if (name.equals(this._typePropertyName) || (ignoreCase && name
/* 131 */         .equalsIgnoreCase(this._typePropertyName))) {
/*     */         
/* 133 */         String typeId = p.getValueAsString();
/* 134 */         if (typeId != null) {
/* 135 */           return _deserializeTypedForId(p, ctxt, tb, typeId);
/*     */         }
/*     */       } 
/* 138 */       if (tb == null) {
/* 139 */         tb = ctxt.bufferForInputBuffering(p);
/*     */       }
/* 141 */       tb.writeFieldName(name);
/* 142 */       tb.copyCurrentStructure(p);
/*     */     } 
/* 144 */     return _deserializeTypedUsingDefaultImpl(p, ctxt, tb, this._msgForMissingId);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object _deserializeTypedForId(JsonParser p, DeserializationContext ctxt, TokenBuffer tb, String typeId) throws IOException {
/*     */     JsonParserSequence jsonParserSequence;
/* 150 */     JsonDeserializer<Object> deser = _findDeserializer(ctxt, typeId);
/* 151 */     if (this._typeIdVisible) {
/* 152 */       if (tb == null) {
/* 153 */         tb = ctxt.bufferForInputBuffering(p);
/*     */       }
/* 155 */       tb.writeFieldName(p.currentName());
/* 156 */       tb.writeString(typeId);
/*     */     } 
/* 158 */     if (tb != null) {
/*     */ 
/*     */       
/* 161 */       p.clearCurrentToken();
/* 162 */       jsonParserSequence = JsonParserSequence.createFlattened(false, tb.asParser(p), p);
/*     */     } 
/* 164 */     if (jsonParserSequence.currentToken() != JsonToken.END_OBJECT)
/*     */     {
/* 166 */       jsonParserSequence.nextToken();
/*     */     }
/*     */     
/* 169 */     return deser.deserialize((JsonParser)jsonParserSequence, ctxt);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected Object _deserializeTypedUsingDefaultImpl(JsonParser p, DeserializationContext ctxt, TokenBuffer tb) throws IOException {
/* 175 */     return _deserializeTypedUsingDefaultImpl(p, ctxt, tb, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserializeTypedUsingDefaultImpl(JsonParser p, DeserializationContext ctxt, TokenBuffer tb, String priorFailureMsg) throws IOException {
/* 187 */     if (!hasDefaultImpl()) {
/*     */       
/* 189 */       Object result = TypeDeserializer.deserializeIfNatural(p, ctxt, this._baseType);
/* 190 */       if (result != null) {
/* 191 */         return result;
/*     */       }
/*     */       
/* 194 */       if (p.isExpectedStartArrayToken()) {
/* 195 */         return super.deserializeTypedFromAny(p, ctxt);
/*     */       }
/* 197 */       if (p.hasToken(JsonToken.VALUE_STRING) && 
/* 198 */         ctxt.isEnabled(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)) {
/* 199 */         String str = p.getText().trim();
/* 200 */         if (str.isEmpty()) {
/* 201 */           return null;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 208 */     JsonDeserializer<Object> deser = _findDefaultImplDeserializer(ctxt);
/* 209 */     if (deser == null) {
/* 210 */       JavaType t = this._strictTypeIdHandling ? _handleMissingTypeId(ctxt, priorFailureMsg) : this._baseType;
/*     */       
/* 212 */       if (t == null)
/*     */       {
/* 214 */         return null;
/*     */       }
/*     */       
/* 217 */       deser = ctxt.findContextualValueDeserializer(t, this._property);
/*     */     } 
/* 219 */     if (tb != null) {
/* 220 */       tb.writeEndObject();
/* 221 */       p = tb.asParser(p);
/*     */       
/* 223 */       p.nextToken();
/*     */     } 
/* 225 */     return deser.deserialize(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object deserializeTypedFromAny(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 236 */     if (p.hasToken(JsonToken.START_ARRAY)) {
/* 237 */       return deserializeTypedFromArray(p, ctxt);
/*     */     }
/* 239 */     return deserializeTypedFromObject(p, ctxt);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jsontype\impl\AsPropertyTypeDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */