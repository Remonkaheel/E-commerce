/*     */ package com.fasterxml.jackson.databind.jsontype.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DatabindContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeNameIdResolver
/*     */   extends TypeIdResolverBase
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final MapperConfig<?> _config;
/*     */   protected final ConcurrentHashMap<String, String> _typeToId;
/*     */   protected final Map<String, JavaType> _idToType;
/*     */   protected final boolean _caseInsensitive;
/*     */   
/*     */   protected TypeNameIdResolver(MapperConfig<?> config, JavaType baseType, ConcurrentHashMap<String, String> typeToId, HashMap<String, JavaType> idToType) {
/*  52 */     super(baseType, config.getTypeFactory());
/*  53 */     this._config = config;
/*  54 */     this._typeToId = typeToId;
/*  55 */     this._idToType = idToType;
/*  56 */     this._caseInsensitive = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_VALUES);
/*     */   }
/*     */ 
/*     */   
/*     */   public static TypeNameIdResolver construct(MapperConfig<?> config, JavaType baseType, Collection<NamedType> subtypes, boolean forSer, boolean forDeser) {
/*     */     ConcurrentHashMap<String, String> typeToId;
/*     */     HashMap<String, JavaType> idToType;
/*  63 */     if (forSer == forDeser) throw new IllegalArgumentException();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  68 */     if (forSer) {
/*     */ 
/*     */       
/*  71 */       typeToId = new ConcurrentHashMap<>();
/*  72 */       idToType = null;
/*     */     } else {
/*  74 */       idToType = new HashMap<>();
/*     */ 
/*     */ 
/*     */       
/*  78 */       typeToId = new ConcurrentHashMap<>(4);
/*     */     } 
/*  80 */     boolean caseInsensitive = config.isEnabled(MapperFeature.ACCEPT_CASE_INSENSITIVE_VALUES);
/*     */     
/*  82 */     if (subtypes != null) {
/*  83 */       for (NamedType t : subtypes) {
/*     */ 
/*     */         
/*  86 */         Class<?> cls = t.getType();
/*  87 */         String id = t.hasName() ? t.getName() : _defaultTypeId(cls);
/*  88 */         if (forSer) {
/*  89 */           typeToId.put(cls.getName(), id);
/*     */         }
/*  91 */         if (forDeser) {
/*     */           
/*  93 */           if (caseInsensitive) {
/*  94 */             id = id.toLowerCase();
/*     */           }
/*     */ 
/*     */           
/*  98 */           JavaType prev = idToType.get(id);
/*  99 */           if (prev != null && 
/* 100 */             cls.isAssignableFrom(prev.getRawClass())) {
/*     */             continue;
/*     */           }
/*     */           
/* 104 */           idToType.put(id, config.constructType(cls));
/*     */         } 
/*     */       } 
/*     */     }
/* 108 */     return new TypeNameIdResolver(config, baseType, typeToId, idToType);
/*     */   }
/*     */   
/*     */   public JsonTypeInfo.Id getMechanism() {
/* 112 */     return JsonTypeInfo.Id.NAME;
/*     */   }
/*     */   
/*     */   public String idFromValue(Object value) {
/* 116 */     return idFromClass(value.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   protected String idFromClass(Class<?> clazz) {
/* 121 */     if (clazz == null) {
/* 122 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 126 */     clazz = _resolveToParentAsNecessary(clazz);
/*     */ 
/*     */ 
/*     */     
/* 130 */     String key = clazz.getName();
/* 131 */     String name = this._typeToId.get(key);
/*     */     
/* 133 */     if (name == null) {
/*     */ 
/*     */       
/* 136 */       Class<?> cls = this._typeFactory.constructType(clazz).getRawClass();
/*     */ 
/*     */       
/* 139 */       if (this._config.isAnnotationProcessingEnabled()) {
/* 140 */         BeanDescription beanDesc = this._config.introspectClassAnnotations(cls);
/* 141 */         name = this._config.getAnnotationIntrospector().findTypeName(beanDesc.getClassInfo());
/*     */       } 
/* 143 */       if (name == null)
/*     */       {
/* 145 */         name = _defaultTypeId(cls);
/*     */       }
/* 147 */       this._typeToId.put(key, name);
/*     */     } 
/* 149 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String idFromValueAndType(Object value, Class<?> type) {
/* 156 */     if (value == null) {
/* 157 */       return idFromClass(type);
/*     */     }
/* 159 */     return idFromValue(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType typeFromId(DatabindContext context, String id) {
/* 164 */     return _typeFromId(id);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JavaType _typeFromId(String id) {
/* 169 */     if (this._caseInsensitive) {
/* 170 */       id = id.toLowerCase();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     return this._idToType.get(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescForKnownTypeIds() {
/* 183 */     TreeSet<String> ids = new TreeSet<>();
/* 184 */     for (Map.Entry<String, JavaType> entry : this._idToType.entrySet()) {
/* 185 */       if (((JavaType)entry.getValue()).isConcrete()) {
/* 186 */         ids.add(entry.getKey());
/*     */       }
/*     */     } 
/* 189 */     return ids.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 194 */     return String.format("[%s; id-to-type=%s]", new Object[] { getClass().getName(), this._idToType });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String _defaultTypeId(Class<?> cls) {
/* 209 */     String n = cls.getName();
/* 210 */     int ix = n.lastIndexOf('.');
/* 211 */     return (ix < 0) ? n : n.substring(ix + 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jsontype\impl\TypeNameIdResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */