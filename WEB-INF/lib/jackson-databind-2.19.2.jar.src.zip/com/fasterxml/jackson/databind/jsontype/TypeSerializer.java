/*     */ package com.fasterxml.jackson.databind.jsontype;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.core.util.VersionUtil;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TypeSerializer
/*     */ {
/*     */   public abstract TypeSerializer forProperty(BeanProperty paramBeanProperty);
/*     */   
/*     */   public abstract JsonTypeInfo.As getTypeInclusion();
/*     */   
/*     */   public abstract String getPropertyName();
/*     */   
/*     */   public abstract TypeIdResolver getTypeIdResolver();
/*     */   
/*     */   public WritableTypeId typeId(Object value, JsonToken valueShape) {
/*  81 */     WritableTypeId typeIdDef = new WritableTypeId(value, valueShape);
/*  82 */     switch (getTypeInclusion())
/*     */     { case EXISTING_PROPERTY:
/*  84 */         typeIdDef.include = WritableTypeId.Inclusion.PAYLOAD_PROPERTY;
/*  85 */         typeIdDef.asProperty = getPropertyName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 104 */         return typeIdDef;case EXTERNAL_PROPERTY: typeIdDef.include = WritableTypeId.Inclusion.PARENT_PROPERTY; typeIdDef.asProperty = getPropertyName(); return typeIdDef;case PROPERTY: typeIdDef.include = WritableTypeId.Inclusion.METADATA_PROPERTY; typeIdDef.asProperty = getPropertyName(); return typeIdDef;case WRAPPER_ARRAY: typeIdDef.include = WritableTypeId.Inclusion.WRAPPER_ARRAY; return typeIdDef;case WRAPPER_OBJECT: typeIdDef.include = WritableTypeId.Inclusion.WRAPPER_OBJECT; return typeIdDef; }  VersionUtil.throwInternal(); return typeIdDef;
/*     */   }
/*     */ 
/*     */   
/*     */   public WritableTypeId typeId(Object value, JsonToken valueShape, Object id) {
/* 109 */     WritableTypeId typeId = typeId(value, valueShape);
/* 110 */     typeId.id = id;
/* 111 */     return typeId;
/*     */   }
/*     */ 
/*     */   
/*     */   public WritableTypeId typeId(Object value, Class<?> typeForId, JsonToken valueShape) {
/* 116 */     WritableTypeId typeId = typeId(value, valueShape);
/* 117 */     typeId.forValueType = typeForId;
/* 118 */     return typeId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract WritableTypeId writeTypePrefix(JsonGenerator paramJsonGenerator, WritableTypeId paramWritableTypeId) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract WritableTypeId writeTypeSuffix(JsonGenerator paramJsonGenerator, WritableTypeId paramWritableTypeId) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void writeTypePrefixForScalar(Object value, JsonGenerator g) throws IOException {
/* 180 */     writeTypePrefix(g, typeId(value, JsonToken.VALUE_STRING));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void writeTypePrefixForObject(Object value, JsonGenerator g) throws IOException {
/* 192 */     writeTypePrefix(g, typeId(value, JsonToken.START_OBJECT));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void writeTypePrefixForArray(Object value, JsonGenerator g) throws IOException {
/* 204 */     writeTypePrefix(g, typeId(value, JsonToken.START_ARRAY));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void writeTypeSuffixForScalar(Object value, JsonGenerator g) throws IOException {
/* 216 */     _writeLegacySuffix(g, typeId(value, JsonToken.VALUE_STRING));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void writeTypeSuffixForObject(Object value, JsonGenerator g) throws IOException {
/* 228 */     _writeLegacySuffix(g, typeId(value, JsonToken.START_OBJECT));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void writeTypeSuffixForArray(Object value, JsonGenerator g) throws IOException {
/* 240 */     _writeLegacySuffix(g, typeId(value, JsonToken.START_ARRAY));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void writeTypePrefixForScalar(Object value, JsonGenerator g, Class<?> type) throws IOException {
/* 252 */     writeTypePrefix(g, typeId(value, type, JsonToken.VALUE_STRING));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void writeTypePrefixForObject(Object value, JsonGenerator g, Class<?> type) throws IOException {
/* 264 */     writeTypePrefix(g, typeId(value, type, JsonToken.START_OBJECT));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void writeTypePrefixForArray(Object value, JsonGenerator g, Class<?> type) throws IOException {
/* 276 */     writeTypePrefix(g, typeId(value, type, JsonToken.START_ARRAY));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void writeCustomTypePrefixForScalar(Object value, JsonGenerator g, String typeId) throws IOException {
/* 294 */     writeTypePrefix(g, typeId(value, JsonToken.VALUE_STRING, typeId));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void writeCustomTypePrefixForObject(Object value, JsonGenerator g, String typeId) throws IOException {
/* 306 */     writeTypePrefix(g, typeId(value, JsonToken.START_OBJECT, typeId));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void writeCustomTypePrefixForArray(Object value, JsonGenerator g, String typeId) throws IOException {
/* 318 */     writeTypePrefix(g, typeId(value, JsonToken.START_ARRAY, typeId));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void writeCustomTypeSuffixForScalar(Object value, JsonGenerator g, String typeId) throws IOException {
/* 326 */     _writeLegacySuffix(g, typeId(value, JsonToken.VALUE_STRING, typeId));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void writeCustomTypeSuffixForObject(Object value, JsonGenerator g, String typeId) throws IOException {
/* 334 */     _writeLegacySuffix(g, typeId(value, JsonToken.START_OBJECT, typeId));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void writeCustomTypeSuffixForArray(Object value, JsonGenerator g, String typeId) throws IOException {
/* 342 */     _writeLegacySuffix(g, typeId(value, JsonToken.START_ARRAY, typeId));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void _writeLegacySuffix(JsonGenerator g, WritableTypeId typeId) throws IOException {
/* 356 */     typeId.wrapperWritten = !g.canWriteTypeId();
/* 357 */     writeTypeSuffix(g, typeId);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jsontype\TypeSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */