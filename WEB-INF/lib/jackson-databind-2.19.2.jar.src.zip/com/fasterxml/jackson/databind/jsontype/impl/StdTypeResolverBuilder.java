/*     */ package com.fasterxml.jackson.databind.jsontype.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.databind.AnnotationIntrospector;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.MapperFeature;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.annotation.NoClass;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClass;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedClassResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.util.Collection;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StdTypeResolverBuilder
/*     */   implements TypeResolverBuilder<StdTypeResolverBuilder>
/*     */ {
/*     */   protected JsonTypeInfo.Id _idType;
/*     */   protected JsonTypeInfo.As _includeAs;
/*     */   protected String _typeProperty;
/*     */   protected boolean _typeIdVisible = false;
/*     */   protected Boolean _requireTypeIdForSubtypes;
/*     */   protected Class<?> _defaultImpl;
/*     */   protected TypeIdResolver _customIdResolver;
/*     */   
/*     */   protected StdTypeResolverBuilder(JsonTypeInfo.Id idType, JsonTypeInfo.As idAs, String propName) {
/*  68 */     this._idType = idType;
/*  69 */     this._includeAs = idAs;
/*  70 */     this._typeProperty = _propName(propName, idType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StdTypeResolverBuilder(StdTypeResolverBuilder base, Class<?> defaultImpl) {
/*  81 */     this._idType = base._idType;
/*  82 */     this._includeAs = base._includeAs;
/*  83 */     this._typeProperty = base._typeProperty;
/*  84 */     this._typeIdVisible = base._typeIdVisible;
/*  85 */     this._customIdResolver = base._customIdResolver;
/*     */     
/*  87 */     this._defaultImpl = defaultImpl;
/*  88 */     this._requireTypeIdForSubtypes = base._requireTypeIdForSubtypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder(JsonTypeInfo.Value settings) {
/*  95 */     if (settings != null) {
/*  96 */       withSettings(settings);
/*     */     }
/*     */   }
/*     */   
/*     */   public static StdTypeResolverBuilder noTypeInfoBuilder() {
/* 101 */     JsonTypeInfo.Value typeInfo = JsonTypeInfo.Value.construct(JsonTypeInfo.Id.NONE, null, null, null, false, null);
/*     */     
/* 103 */     return (new StdTypeResolverBuilder()).withSettings(typeInfo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeSerializer buildTypeSerializer(SerializationConfig config, JavaType baseType, Collection<NamedType> subtypes) {
/* 110 */     if (this._idType == JsonTypeInfo.Id.NONE) return null;
/*     */ 
/*     */     
/* 113 */     if (baseType.isPrimitive())
/*     */     {
/* 115 */       if (!allowPrimitiveTypes((MapperConfig<?>)config, baseType)) {
/* 116 */         return null;
/*     */       }
/*     */     }
/* 119 */     if (this._idType == JsonTypeInfo.Id.DEDUCTION)
/*     */     {
/*     */       
/* 122 */       return AsDeductionTypeSerializer.instance();
/*     */     }
/*     */     
/* 125 */     TypeIdResolver idRes = idResolver((MapperConfig<?>)config, baseType, subTypeValidator((MapperConfig<?>)config), subtypes, true, false);
/*     */     
/* 127 */     switch (this._includeAs) {
/*     */       case DEDUCTION:
/* 129 */         return new AsArrayTypeSerializer(idRes, null);
/*     */       case CLASS:
/* 131 */         return new AsPropertyTypeSerializer(idRes, null, this._typeProperty);
/*     */       case MINIMAL_CLASS:
/* 133 */         return new AsWrapperTypeSerializer(idRes, null);
/*     */       case SIMPLE_NAME:
/* 135 */         return new AsExternalTypeSerializer(idRes, null, this._typeProperty);
/*     */       
/*     */       case NAME:
/* 138 */         return new AsExistingPropertyTypeSerializer(idRes, null, this._typeProperty);
/*     */     } 
/* 140 */     throw new IllegalStateException("Do not know how to construct standard type serializer for inclusion type: " + this._includeAs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDeserializer buildTypeDeserializer(DeserializationConfig config, JavaType baseType, Collection<NamedType> subtypes) {
/* 153 */     if (this._idType == JsonTypeInfo.Id.NONE) return null;
/*     */ 
/*     */     
/* 156 */     if (baseType.isPrimitive())
/*     */     {
/* 158 */       if (!allowPrimitiveTypes((MapperConfig<?>)config, baseType)) {
/* 159 */         return null;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 165 */     PolymorphicTypeValidator subTypeValidator = verifyBaseTypeValidity((MapperConfig<?>)config, baseType);
/*     */     
/* 167 */     TypeIdResolver idRes = idResolver((MapperConfig<?>)config, baseType, subTypeValidator, subtypes, false, true);
/*     */     
/* 169 */     JavaType defaultImpl = defineDefaultImpl(config, baseType);
/*     */     
/* 171 */     if (this._idType == JsonTypeInfo.Id.DEDUCTION)
/*     */     {
/* 173 */       return new AsDeductionTypeDeserializer(baseType, idRes, defaultImpl, config, subtypes);
/*     */     }
/*     */ 
/*     */     
/* 177 */     switch (this._includeAs) {
/*     */       case DEDUCTION:
/* 179 */         return new AsArrayTypeDeserializer(baseType, idRes, this._typeProperty, this._typeIdVisible, defaultImpl);
/*     */       
/*     */       case CLASS:
/*     */       case NAME:
/* 183 */         return new AsPropertyTypeDeserializer(baseType, idRes, this._typeProperty, this._typeIdVisible, defaultImpl, this._includeAs, 
/*     */             
/* 185 */             _strictTypeIdHandling(config, baseType));
/*     */       case MINIMAL_CLASS:
/* 187 */         return new AsWrapperTypeDeserializer(baseType, idRes, this._typeProperty, this._typeIdVisible, defaultImpl);
/*     */       
/*     */       case SIMPLE_NAME:
/* 190 */         return new AsExternalTypeDeserializer(baseType, idRes, this._typeProperty, this._typeIdVisible, defaultImpl);
/*     */     } 
/*     */     
/* 193 */     throw new IllegalStateException("Do not know how to construct standard type serializer for inclusion type: " + this._includeAs);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JavaType defineDefaultImpl(DeserializationConfig config, JavaType baseType) {
/* 198 */     if (this._defaultImpl != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 205 */       if (this._defaultImpl == Void.class || this._defaultImpl == NoClass.class)
/*     */       {
/*     */         
/* 208 */         return config.getTypeFactory().constructType(this._defaultImpl);
/*     */       }
/* 210 */       if (baseType.hasRawClass(this._defaultImpl)) {
/* 211 */         return baseType;
/*     */       }
/* 213 */       if (baseType.isTypeOrSuperTypeOf(this._defaultImpl))
/*     */       {
/* 215 */         return config.getTypeFactory()
/* 216 */           .constructSpecializedType(baseType, this._defaultImpl);
/*     */       }
/* 218 */       if (baseType.hasRawClass(this._defaultImpl)) {
/* 219 */         return baseType;
/*     */       }
/*     */     } 
/*     */     
/* 223 */     if (config.isEnabled(MapperFeature.USE_BASE_TYPE_AS_DEFAULT_IMPL) && 
/* 224 */       !baseType.isAbstract())
/*     */     {
/* 226 */       return baseType;
/*     */     }
/* 228 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder init(JsonTypeInfo.Id idType, TypeIdResolver idRes) {
/* 241 */     if (idType == null) {
/* 242 */       throw new IllegalArgumentException("idType cannot be null");
/*     */     }
/* 244 */     this._idType = idType;
/* 245 */     this._customIdResolver = idRes;
/*     */     
/* 247 */     this._typeProperty = _propName(null, idType);
/* 248 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder init(JsonTypeInfo.Value settings, TypeIdResolver idRes) {
/* 255 */     this._customIdResolver = idRes;
/*     */     
/* 257 */     if (settings != null) {
/* 258 */       withSettings(settings);
/*     */     }
/* 260 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder inclusion(JsonTypeInfo.As includeAs) {
/* 265 */     if (includeAs == null) {
/* 266 */       throw new IllegalArgumentException("includeAs cannot be null");
/*     */     }
/* 268 */     this._includeAs = includeAs;
/* 269 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder typeProperty(String typeIdPropName) {
/* 279 */     this._typeProperty = _propName(typeIdPropName, this._idType);
/* 280 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder defaultImpl(Class<?> defaultImpl) {
/* 285 */     this._defaultImpl = defaultImpl;
/* 286 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder typeIdVisibility(boolean isVisible) {
/* 291 */     this._typeIdVisible = isVisible;
/* 292 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder withDefaultImpl(Class<?> defaultImpl) {
/* 297 */     if (this._defaultImpl == defaultImpl) {
/* 298 */       return this;
/*     */     }
/* 300 */     ClassUtil.verifyMustOverride(StdTypeResolverBuilder.class, this, "withDefaultImpl");
/*     */ 
/*     */     
/* 303 */     return new StdTypeResolverBuilder(this, defaultImpl);
/*     */   }
/*     */ 
/*     */   
/*     */   public StdTypeResolverBuilder withSettings(JsonTypeInfo.Value settings) {
/* 308 */     this._idType = Objects.<JsonTypeInfo.Id>requireNonNull(settings.getIdType());
/* 309 */     this._includeAs = settings.getInclusionType();
/* 310 */     this._typeProperty = _propName(settings.getPropertyName(), this._idType);
/* 311 */     this._defaultImpl = settings.getDefaultImpl();
/* 312 */     this._typeIdVisible = settings.getIdVisible();
/* 313 */     this._requireTypeIdForSubtypes = settings.getRequireTypeIdForSubtypes();
/* 314 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String _propName(String propName, JsonTypeInfo.Id idType) {
/* 321 */     if (propName == null || propName.isEmpty()) {
/* 322 */       propName = idType.getDefaultPropertyName();
/*     */     }
/* 324 */     return propName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getDefaultImpl() {
/* 333 */     return this._defaultImpl;
/*     */   }
/* 335 */   public String getTypeProperty() { return this._typeProperty; } public boolean isTypeIdVisible() {
/* 336 */     return this._typeIdVisible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeIdResolver idResolver(MapperConfig<?> config, JavaType baseType, PolymorphicTypeValidator subtypeValidator, Collection<NamedType> subtypes, boolean forSer, boolean forDeser) {
/* 354 */     if (this._customIdResolver != null) return this._customIdResolver; 
/* 355 */     if (this._idType == null) throw new IllegalStateException("Cannot build, 'init()' not yet called"); 
/* 356 */     switch (this._idType) {
/*     */       case DEDUCTION:
/*     */       case CLASS:
/* 359 */         return ClassNameIdResolver.construct(baseType, config, subtypes, subtypeValidator);
/*     */       case MINIMAL_CLASS:
/* 361 */         return MinimalClassNameIdResolver.construct(baseType, config, subtypes, subtypeValidator);
/*     */       case SIMPLE_NAME:
/* 363 */         return SimpleNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);
/*     */       case NAME:
/* 365 */         return TypeNameIdResolver.construct(config, baseType, subtypes, forSer, forDeser);
/*     */       case NONE:
/* 367 */         return null;
/*     */     } 
/*     */     
/* 370 */     throw new IllegalStateException("Do not know how to construct standard type id resolver for idType: " + this._idType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PolymorphicTypeValidator subTypeValidator(MapperConfig<?> config) {
/* 389 */     return config.getPolymorphicTypeValidator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PolymorphicTypeValidator verifyBaseTypeValidity(MapperConfig<?> config, JavaType baseType) {
/* 402 */     PolymorphicTypeValidator ptv = subTypeValidator(config);
/* 403 */     if (this._idType == JsonTypeInfo.Id.CLASS || this._idType == JsonTypeInfo.Id.MINIMAL_CLASS) {
/* 404 */       PolymorphicTypeValidator.Validity validity = ptv.validateBaseType(config, baseType);
/*     */       
/* 406 */       if (validity == PolymorphicTypeValidator.Validity.DENIED) {
/* 407 */         return reportInvalidBaseType(config, baseType, ptv);
/*     */       }
/*     */       
/* 410 */       if (validity == PolymorphicTypeValidator.Validity.ALLOWED) {
/* 411 */         return (PolymorphicTypeValidator)LaissezFaireSubTypeValidator.instance;
/*     */       }
/*     */     } 
/*     */     
/* 415 */     return ptv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PolymorphicTypeValidator reportInvalidBaseType(MapperConfig<?> config, JavaType baseType, PolymorphicTypeValidator ptv) {
/* 424 */     throw new IllegalArgumentException(String.format("Configured `PolymorphicTypeValidator` (of type %s) denied resolution of all subtypes of base type %s", new Object[] {
/*     */             
/* 426 */             ClassUtil.classNameOf(ptv), ClassUtil.classNameOf(baseType.getRawClass())
/*     */           }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean allowPrimitiveTypes(MapperConfig<?> config, JavaType baseType) {
/* 454 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _strictTypeIdHandling(DeserializationConfig config, JavaType baseType) {
/* 476 */     if (this._requireTypeIdForSubtypes != null && baseType.isConcrete()) {
/* 477 */       return this._requireTypeIdForSubtypes.booleanValue();
/*     */     }
/* 479 */     if (config.isEnabled(MapperFeature.REQUIRE_TYPE_ID_FOR_SUBTYPES)) {
/* 480 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 484 */     return _hasTypeResolver(config, baseType);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _hasTypeResolver(DeserializationConfig config, JavaType baseType) {
/* 500 */     AnnotatedClass ac = AnnotatedClassResolver.resolveWithoutSuperTypes((MapperConfig)config, baseType.getRawClass());
/* 501 */     AnnotationIntrospector ai = config.getAnnotationIntrospector();
/* 502 */     return (ai.findPolymorphicTypeInfo((MapperConfig)config, (Annotated)ac) != null);
/*     */   }
/*     */   
/*     */   public StdTypeResolverBuilder() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jsontype\impl\StdTypeResolverBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */