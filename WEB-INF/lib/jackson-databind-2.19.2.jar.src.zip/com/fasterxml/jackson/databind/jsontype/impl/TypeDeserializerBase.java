/*     */ package com.fasterxml.jackson.databind.jsontype.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.DatabindContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.deser.std.NullifyingDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeDeserializer;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TypeDeserializerBase
/*     */   extends TypeDeserializer
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final TypeIdResolver _idResolver;
/*     */   protected final JavaType _baseType;
/*     */   protected final BeanProperty _property;
/*     */   protected final JavaType _defaultImpl;
/*     */   protected final String _typePropertyName;
/*     */   protected final boolean _typeIdVisible;
/*     */   protected final Map<String, JsonDeserializer<Object>> _deserializers;
/*     */   protected JsonDeserializer<Object> _defaultImplDeserializer;
/*     */   
/*     */   protected TypeDeserializerBase(JavaType baseType, TypeIdResolver idRes, String typePropertyName, boolean typeIdVisible, JavaType defaultImpl) {
/*  72 */     this._baseType = baseType;
/*  73 */     this._idResolver = idRes;
/*  74 */     this._typePropertyName = ClassUtil.nonNullString(typePropertyName);
/*  75 */     this._typeIdVisible = typeIdVisible;
/*     */     
/*  77 */     this._deserializers = new ConcurrentHashMap<>(16, 0.75F, 2);
/*  78 */     this._defaultImpl = defaultImpl;
/*  79 */     this._property = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected TypeDeserializerBase(TypeDeserializerBase src, BeanProperty property) {
/*  84 */     this._baseType = src._baseType;
/*  85 */     this._idResolver = src._idResolver;
/*  86 */     this._typePropertyName = src._typePropertyName;
/*  87 */     this._typeIdVisible = src._typeIdVisible;
/*  88 */     this._deserializers = src._deserializers;
/*  89 */     this._defaultImpl = src._defaultImpl;
/*  90 */     this._defaultImplDeserializer = src._defaultImplDeserializer;
/*  91 */     this._property = property;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract TypeDeserializer forProperty(BeanProperty paramBeanProperty);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonTypeInfo.As getTypeInclusion();
/*     */ 
/*     */ 
/*     */   
/*     */   public String baseTypeName() {
/* 106 */     return this._baseType.getRawClass().getName();
/*     */   }
/*     */   public final String getPropertyName() {
/* 109 */     return this._typePropertyName;
/*     */   }
/*     */   public TypeIdResolver getTypeIdResolver() {
/* 112 */     return this._idResolver;
/*     */   }
/*     */   
/*     */   public Class<?> getDefaultImpl() {
/* 116 */     return ClassUtil.rawClass(this._defaultImpl);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasDefaultImpl() {
/* 121 */     return (this._defaultImpl != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType baseType() {
/* 128 */     return this._baseType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 134 */     StringBuilder sb = new StringBuilder();
/* 135 */     sb.append('[').append(getClass().getName());
/* 136 */     sb.append("; base-type:").append(this._baseType);
/* 137 */     sb.append("; id-resolver: ").append(this._idResolver);
/* 138 */     sb.append(']');
/* 139 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonDeserializer<Object> _findDeserializer(DeserializationContext ctxt, String typeId) throws IOException {
/* 151 */     JsonDeserializer<Object> deser = this._deserializers.get(typeId);
/* 152 */     if (deser == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 158 */       JavaType type = this._idResolver.typeFromId((DatabindContext)ctxt, typeId);
/* 159 */       if (type == null) {
/*     */         
/* 161 */         deser = _findDefaultImplDeserializer(ctxt);
/* 162 */         if (deser == null)
/*     */         {
/* 164 */           JavaType actual = _handleUnknownTypeId(ctxt, typeId);
/* 165 */           if (actual == null)
/*     */           {
/* 167 */             return (JsonDeserializer<Object>)NullifyingDeserializer.instance;
/*     */           }
/*     */           
/* 170 */           deser = ctxt.findContextualValueDeserializer(actual, this._property);
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 181 */         if (this._baseType != null && this._baseType
/* 182 */           .getClass() == type.getClass())
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 192 */           if (!type.hasGenericTypes()) {
/*     */             try {
/* 194 */               type = ctxt.constructSpecializedType(this._baseType, type.getRawClass());
/* 195 */             } catch (IllegalArgumentException e) {
/*     */ 
/*     */               
/* 198 */               throw ctxt.invalidTypeIdException(this._baseType, typeId, e.getMessage());
/*     */             } 
/*     */           }
/*     */         }
/* 202 */         deser = ctxt.findContextualValueDeserializer(type, this._property);
/*     */       } 
/* 204 */       this._deserializers.put(typeId, deser);
/*     */     } 
/* 206 */     return deser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonDeserializer<Object> _findDefaultImplDeserializer(DeserializationContext ctxt) throws IOException {
/* 214 */     if (this._defaultImpl == null) {
/* 215 */       if (!ctxt.isEnabled(DeserializationFeature.FAIL_ON_INVALID_SUBTYPE)) {
/* 216 */         return (JsonDeserializer<Object>)NullifyingDeserializer.instance;
/*     */       }
/* 218 */       return null;
/*     */     } 
/* 220 */     Class<?> raw = this._defaultImpl.getRawClass();
/* 221 */     if (ClassUtil.isBogusClass(raw)) {
/* 222 */       return (JsonDeserializer<Object>)NullifyingDeserializer.instance;
/*     */     }
/*     */     
/* 225 */     if (this._defaultImplDeserializer == null) {
/* 226 */       synchronized (this._defaultImpl) {
/* 227 */         if (this._defaultImplDeserializer == null) {
/* 228 */           this._defaultImplDeserializer = ctxt.findContextualValueDeserializer(this._defaultImpl, this._property);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 233 */     return this._defaultImplDeserializer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected Object _deserializeWithNativeTypeId(JsonParser jp, DeserializationContext ctxt) throws IOException {
/* 245 */     return _deserializeWithNativeTypeId(jp, ctxt, jp.getTypeId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object _deserializeWithNativeTypeId(JsonParser p, DeserializationContext ctxt, Object typeId) throws IOException {
/*     */     JsonDeserializer<Object> deser;
/* 258 */     if (typeId == null) {
/*     */ 
/*     */       
/* 261 */       deser = _findDefaultImplDeserializer(ctxt);
/* 262 */       if (deser == null) {
/* 263 */         return ctxt.reportInputMismatch(baseType(), "No (native) type id found when one was expected for polymorphic type handling", new Object[0]);
/*     */       }
/*     */     } else {
/*     */       
/* 267 */       String typeIdStr = (typeId instanceof String) ? (String)typeId : String.valueOf(typeId);
/* 268 */       deser = _findDeserializer(ctxt, typeIdStr);
/*     */     } 
/* 270 */     return deser.deserialize(p, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JavaType _handleUnknownTypeId(DeserializationContext ctxt, String typeId) throws IOException {
/* 289 */     String extraDesc = this._idResolver.getDescForKnownTypeIds();
/* 290 */     if (extraDesc == null) {
/* 291 */       extraDesc = "type ids are not statically known";
/*     */     } else {
/* 293 */       extraDesc = "known type ids = " + extraDesc;
/*     */     } 
/* 295 */     if (this._property != null) {
/* 296 */       extraDesc = String.format("%s (for POJO property '%s')", new Object[] { extraDesc, this._property
/* 297 */             .getName() });
/*     */     }
/* 299 */     return ctxt.handleUnknownTypeId(this._baseType, typeId, this._idResolver, extraDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JavaType _handleMissingTypeId(DeserializationContext ctxt, String extraDesc) throws IOException {
/* 308 */     return ctxt.handleMissingTypeId(this._baseType, this._idResolver, extraDesc);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jsontype\impl\TypeDeserializerBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */