/*     */ package com.fasterxml.jackson.databind.jsontype.impl;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.databind.DatabindContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
/*     */ import com.fasterxml.jackson.databind.type.TypeFactory;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MinimalClassNameIdResolver
/*     */   extends ClassNameIdResolver
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final String _basePackageName;
/*     */   protected final String _basePackagePrefix;
/*     */   
/*     */   @Deprecated
/*     */   protected MinimalClassNameIdResolver(JavaType baseType, TypeFactory typeFactory, PolymorphicTypeValidator ptv) {
/*  44 */     this(baseType, typeFactory, null, ptv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MinimalClassNameIdResolver(JavaType baseType, TypeFactory typeFactory, Collection<NamedType> subtypes, PolymorphicTypeValidator ptv) {
/*  54 */     super(baseType, typeFactory, subtypes, ptv);
/*  55 */     String base = baseType.getRawClass().getName();
/*  56 */     int ix = base.lastIndexOf('.');
/*  57 */     if (ix < 0) {
/*  58 */       this._basePackageName = "";
/*  59 */       this._basePackagePrefix = ".";
/*     */     } else {
/*  61 */       this._basePackagePrefix = base.substring(0, ix + 1);
/*  62 */       this._basePackageName = base.substring(0, ix);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static MinimalClassNameIdResolver construct(JavaType baseType, MapperConfig<?> config, PolymorphicTypeValidator ptv) {
/*  72 */     return new MinimalClassNameIdResolver(baseType, config.getTypeFactory(), ptv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MinimalClassNameIdResolver construct(JavaType baseType, MapperConfig<?> config, Collection<NamedType> subtypes, PolymorphicTypeValidator ptv) {
/*  81 */     return new MinimalClassNameIdResolver(baseType, config.getTypeFactory(), subtypes, ptv);
/*     */   }
/*     */   
/*     */   public JsonTypeInfo.Id getMechanism() {
/*  85 */     return JsonTypeInfo.Id.MINIMAL_CLASS;
/*     */   }
/*     */ 
/*     */   
/*     */   public String idFromValue(Object value) {
/*  90 */     return idFromValueAndType(value, value.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String idFromValueAndType(Object value, Class<?> rawType) {
/*  97 */     rawType = _resolveToParentAsNecessary(rawType);
/*  98 */     String n = rawType.getName();
/*  99 */     if (n.startsWith(this._basePackagePrefix))
/*     */     {
/* 101 */       return n.substring(this._basePackagePrefix.length() - 1);
/*     */     }
/* 103 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JavaType _typeFromId(String id, DatabindContext ctxt) throws IOException {
/* 110 */     if (id.startsWith(".")) {
/* 111 */       StringBuilder sb = new StringBuilder(id.length() + this._basePackageName.length());
/* 112 */       if (this._basePackageName.isEmpty()) {
/*     */         
/* 114 */         sb.append(id.substring(1));
/*     */       } else {
/*     */         
/* 117 */         sb.append(this._basePackageName).append(id);
/*     */       } 
/* 119 */       id = sb.toString();
/*     */     } 
/* 121 */     return super._typeFromId(id, ctxt);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\jsontype\impl\MinimalClassNameIdResolver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */