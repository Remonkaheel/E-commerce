/*     */ package com.fasterxml.jackson.databind.type;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CollectionType
/*     */   extends CollectionLikeType
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   private CollectionType(Class<?> collT, TypeBindings bindings, JavaType superClass, JavaType[] superInts, JavaType elemT, Object valueHandler, Object typeHandler, boolean asStatic) {
/*  25 */     super(collT, bindings, superClass, superInts, elemT, valueHandler, typeHandler, asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CollectionType(TypeBase base, JavaType elemT) {
/*  32 */     super(base, elemT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CollectionType construct(Class<?> rawType, TypeBindings bindings, JavaType superClass, JavaType[] superInts, JavaType elemT) {
/*  40 */     return new CollectionType(rawType, bindings, superClass, superInts, elemT, null, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static CollectionType construct(Class<?> rawType, JavaType elemT) {
/*     */     TypeBindings bindings;
/*  51 */     TypeVariable[] arrayOfTypeVariable = (TypeVariable[])rawType.getTypeParameters();
/*     */     
/*  53 */     if (arrayOfTypeVariable == null || arrayOfTypeVariable.length != 1) {
/*  54 */       bindings = TypeBindings.emptyBindings();
/*     */     } else {
/*  56 */       bindings = TypeBindings.create(rawType, elemT);
/*     */     } 
/*  58 */     return new CollectionType(rawType, bindings, 
/*     */         
/*  60 */         _bogusSuperClass(rawType), null, elemT, null, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType withContentType(JavaType contentType) {
/*  66 */     if (this._elementType == contentType) {
/*  67 */       return this;
/*     */     }
/*  69 */     return new CollectionType(this._class, this._bindings, this._superClass, this._superInterfaces, contentType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionType withTypeHandler(Object h) {
/*  75 */     return new CollectionType(this._class, this._bindings, this._superClass, this._superInterfaces, this._elementType, this._valueHandler, h, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionType withContentTypeHandler(Object h) {
/*  82 */     return new CollectionType(this._class, this._bindings, this._superClass, this._superInterfaces, this._elementType
/*  83 */         .withTypeHandler(h), this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionType withValueHandler(Object h) {
/*  89 */     return new CollectionType(this._class, this._bindings, this._superClass, this._superInterfaces, this._elementType, h, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionType withContentValueHandler(Object h) {
/*  95 */     return new CollectionType(this._class, this._bindings, this._superClass, this._superInterfaces, this._elementType
/*  96 */         .withValueHandler(h), this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionType withStaticTyping() {
/* 102 */     if (this._asStatic) {
/* 103 */       return this;
/*     */     }
/* 105 */     return new CollectionType(this._class, this._bindings, this._superClass, this._superInterfaces, this._elementType
/* 106 */         .withStaticTyping(), this._valueHandler, this._typeHandler, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType refine(Class<?> rawType, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/* 113 */     return new CollectionType(rawType, bindings, superClass, superInterfaces, this._elementType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 127 */     return "[collection type; class " + this._class.getName() + ", contains " + this._elementType + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\type\CollectionType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */