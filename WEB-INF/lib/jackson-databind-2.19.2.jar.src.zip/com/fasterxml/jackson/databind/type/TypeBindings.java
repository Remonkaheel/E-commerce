/*     */ package com.fasterxml.jackson.databind.type;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.util.AbstractList;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class TypeBindings implements Serializable {
/*  17 */   private static final String[] NO_STRINGS = new String[0];
/*     */   private static final long serialVersionUID = 1L;
/*  19 */   private static final JavaType[] NO_TYPES = new JavaType[0];
/*     */   
/*  21 */   private static final TypeBindings EMPTY = new TypeBindings(NO_STRINGS, NO_TYPES, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String[] _names;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final JavaType[] _types;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String[] _unboundVariables;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int _hashCode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeBindings(String[] names, JavaType[] types, String[] uvars) {
/*  54 */     this._names = (names == null) ? NO_STRINGS : names;
/*  55 */     this._types = (types == null) ? NO_TYPES : types;
/*  56 */     if (this._names.length != this._types.length) {
/*  57 */       throw new IllegalArgumentException("Mismatching names (" + this._names.length + "), types (" + this._types.length + ")");
/*     */     }
/*  59 */     this._unboundVariables = uvars;
/*     */     
/*  61 */     this._hashCode = Arrays.hashCode((Object[])this._types);
/*     */   }
/*     */   
/*     */   public static TypeBindings emptyBindings() {
/*  65 */     return EMPTY;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Object readResolve() {
/*  70 */     if (this._names == null || this._names.length == 0) {
/*  71 */       return EMPTY;
/*     */     }
/*  73 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeBindings create(Class<?> erasedType, List<JavaType> typeList) {
/*  83 */     JavaType[] types = (typeList == null || typeList.isEmpty()) ? NO_TYPES : typeList.<JavaType>toArray(NO_TYPES);
/*  84 */     return create(erasedType, types);
/*     */   }
/*     */   
/*     */   public static TypeBindings create(Class<?> erasedType, JavaType[] types) {
/*     */     String[] names;
/*  89 */     if (types == null)
/*  90 */     { types = NO_TYPES; }
/*  91 */     else { switch (types.length) {
/*     */         case 1:
/*  93 */           return create(erasedType, types[0]);
/*     */         case 2:
/*  95 */           return create(erasedType, types[0], types[1]);
/*     */       }  }
/*  97 */      TypeVariable[] arrayOfTypeVariable = (TypeVariable[])erasedType.getTypeParameters();
/*     */     
/*  99 */     if (arrayOfTypeVariable == null || arrayOfTypeVariable.length == 0) {
/* 100 */       names = NO_STRINGS;
/*     */     } else {
/* 102 */       int len = arrayOfTypeVariable.length;
/* 103 */       names = new String[len];
/* 104 */       for (int i = 0; i < len; i++) {
/* 105 */         names[i] = arrayOfTypeVariable[i].getName();
/*     */       }
/*     */     } 
/*     */     
/* 109 */     if (names.length != types.length) {
/* 110 */       throw new IllegalArgumentException("Cannot create TypeBindings for class " + erasedType.getName() + " with " + types.length + " type parameter" + ((types.length == 1) ? "" : "s") + ": class expects " + names.length);
/*     */     }
/*     */ 
/*     */     
/* 114 */     return new TypeBindings(names, types, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeBindings create(Class<?> erasedType, JavaType typeArg1) {
/* 120 */     TypeVariable[] arrayOfTypeVariable = (TypeVariable[])TypeParamStash.paramsFor1(erasedType);
/* 121 */     int varLen = (arrayOfTypeVariable == null) ? 0 : arrayOfTypeVariable.length;
/* 122 */     if (varLen != 1) {
/* 123 */       throw new IllegalArgumentException("Cannot create TypeBindings for class " + erasedType.getName() + " with 1 type parameter: class expects " + varLen);
/*     */     }
/*     */     
/* 126 */     return new TypeBindings(new String[] { arrayOfTypeVariable[0].getName() }, new JavaType[] { typeArg1 }, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeBindings create(Class<?> erasedType, JavaType typeArg1, JavaType typeArg2) {
/* 133 */     TypeVariable[] arrayOfTypeVariable = (TypeVariable[])TypeParamStash.paramsFor2(erasedType);
/* 134 */     int varLen = (arrayOfTypeVariable == null) ? 0 : arrayOfTypeVariable.length;
/* 135 */     if (varLen != 2) {
/* 136 */       throw new IllegalArgumentException("Cannot create TypeBindings for class " + erasedType.getName() + " with 2 type parameters: class expects " + varLen);
/*     */     }
/*     */     
/* 139 */     return new TypeBindings(new String[] { arrayOfTypeVariable[0].getName(), arrayOfTypeVariable[1].getName() }, new JavaType[] { typeArg1, typeArg2 }, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeBindings create(List<String> names, List<JavaType> types) {
/* 148 */     if (names == null || names.isEmpty() || types == null || types.isEmpty()) {
/* 149 */       return EMPTY;
/*     */     }
/* 151 */     return new TypeBindings(names.<String>toArray(NO_STRINGS), types.<JavaType>toArray(NO_TYPES), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeBindings createIfNeeded(Class<?> erasedType, JavaType typeArg1) {
/* 161 */     TypeVariable[] arrayOfTypeVariable = (TypeVariable[])erasedType.getTypeParameters();
/* 162 */     int varLen = (arrayOfTypeVariable == null) ? 0 : arrayOfTypeVariable.length;
/* 163 */     if (varLen == 0) {
/* 164 */       return EMPTY;
/*     */     }
/* 166 */     if (varLen != 1) {
/* 167 */       throw new IllegalArgumentException("Cannot create TypeBindings for class " + erasedType.getName() + " with 1 type parameter: class expects " + varLen);
/*     */     }
/*     */     
/* 170 */     return new TypeBindings(new String[] { arrayOfTypeVariable[0].getName() }, new JavaType[] { typeArg1 }, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TypeBindings createIfNeeded(Class<?> erasedType, JavaType[] types) {
/* 181 */     TypeVariable[] arrayOfTypeVariable = (TypeVariable[])erasedType.getTypeParameters();
/* 182 */     if (arrayOfTypeVariable == null || arrayOfTypeVariable.length == 0) {
/* 183 */       return EMPTY;
/*     */     }
/* 185 */     if (types == null) {
/* 186 */       types = NO_TYPES;
/*     */     }
/* 188 */     int len = arrayOfTypeVariable.length;
/* 189 */     String[] names = new String[len];
/* 190 */     for (int i = 0; i < len; i++) {
/* 191 */       names[i] = arrayOfTypeVariable[i].getName();
/*     */     }
/*     */     
/* 194 */     if (names.length != types.length) {
/* 195 */       throw new IllegalArgumentException("Cannot create TypeBindings for class " + erasedType.getName() + " with " + types.length + " type parameter" + ((types.length == 1) ? "" : "s") + ": class expects " + names.length);
/*     */     }
/*     */ 
/*     */     
/* 199 */     return new TypeBindings(names, types, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBindings withUnboundVariable(String name) {
/* 209 */     int len = (this._unboundVariables == null) ? 0 : this._unboundVariables.length;
/*     */     
/* 211 */     String[] names = (len == 0) ? new String[1] : Arrays.<String>copyOf(this._unboundVariables, len + 1);
/* 212 */     names[len] = name;
/* 213 */     return new TypeBindings(this._names, this._types, names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeBindings withoutVariable(String name) {
/* 225 */     int index = Arrays.<String>asList(this._names).indexOf(name);
/* 226 */     if (index == -1) {
/* 227 */       return this;
/*     */     }
/* 229 */     JavaType[] newTypes = (JavaType[])this._types.clone();
/* 230 */     newTypes[index] = null;
/* 231 */     return new TypeBindings(this._names, newTypes, this._unboundVariables);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType findBoundType(String name) {
/* 245 */     for (int i = 0, len = this._names.length; i < len; i++) {
/* 246 */       if (name.equals(this._names[i])) {
/* 247 */         JavaType t = this._types[i];
/* 248 */         if (t instanceof ResolvedRecursiveType) {
/* 249 */           ResolvedRecursiveType rrt = (ResolvedRecursiveType)t;
/* 250 */           JavaType t2 = rrt.getSelfReferencedType();
/* 251 */           if (t2 != null) {
/* 252 */             t = t2;
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 265 */         return t;
/*     */       } 
/*     */     } 
/* 268 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean invalidCacheKey() {
/* 281 */     for (JavaType type : this._types) {
/* 282 */       if (type instanceof IdentityEqualityType) {
/* 283 */         return true;
/*     */       }
/*     */     } 
/* 286 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isEmpty() {
/* 290 */     return (this._types.length == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 297 */     return this._types.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getBoundName(int index) {
/* 302 */     if (index < 0 || index >= this._names.length) {
/* 303 */       return null;
/*     */     }
/* 305 */     return this._names[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType getBoundType(int index) {
/* 315 */     if (index < 0 || index >= this._types.length) {
/* 316 */       return null;
/*     */     }
/* 318 */     JavaType type = this._types[index];
/* 319 */     if (type == null) {
/* 320 */       type = TypeFactory.unknownType();
/*     */     }
/* 322 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType getBoundTypeOrNull(int index) {
/* 333 */     if (index < 0 || index >= this._types.length) {
/* 334 */       return null;
/*     */     }
/* 336 */     return this._types[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<JavaType> getTypeParameters() {
/* 344 */     if (this._types.length == 0) {
/* 345 */       return Collections.emptyList();
/*     */     }
/* 347 */     List<JavaType> list = Arrays.asList(this._types);
/* 348 */     if (list.contains(null)) {
/*     */       
/* 350 */       list = new ArrayList<>(list);
/* 351 */       for (int i = 0; i < list.size(); i++) {
/* 352 */         if (list.get(i) == null) {
/* 353 */           list.set(i, TypeFactory.unknownType());
/*     */         }
/*     */       } 
/*     */     } 
/* 357 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasUnbound(String name) {
/* 364 */     if (this._unboundVariables != null) {
/* 365 */       for (int i = this._unboundVariables.length; --i >= 0;) {
/* 366 */         if (name.equals(this._unboundVariables[i])) {
/* 367 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/* 371 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object asKey(Class<?> rawBase) {
/* 385 */     if (invalidCacheKey())
/*     */     {
/* 387 */       return null;
/*     */     }
/* 389 */     return new AsKey(rawBase, this._types, this._hashCode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 400 */     if (this._types.length == 0) {
/* 401 */       return "<>";
/*     */     }
/* 403 */     StringBuilder sb = new StringBuilder();
/* 404 */     sb.append('<');
/* 405 */     for (int i = 0, len = this._types.length; i < len; i++) {
/* 406 */       if (i > 0) {
/* 407 */         sb.append(',');
/*     */       }
/*     */       
/* 410 */       JavaType type = this._types[i];
/* 411 */       if (type == null) {
/* 412 */         sb.append("?");
/*     */       } else {
/* 414 */         sb.append(type.getGenericSignature());
/*     */       } 
/*     */     } 
/* 417 */     sb.append('>');
/* 418 */     return sb.toString();
/*     */   }
/*     */   public int hashCode() {
/* 421 */     return this._hashCode;
/*     */   }
/*     */   
/*     */   public boolean equals(Object o) {
/* 425 */     if (o == this) return true; 
/* 426 */     if (!ClassUtil.hasClass(o, getClass())) {
/* 427 */       return false;
/*     */     }
/* 429 */     TypeBindings other = (TypeBindings)o;
/*     */     
/* 431 */     return (this._hashCode == other._hashCode && Arrays.equals((Object[])this._types, (Object[])other._types));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JavaType[] typeParameterArray() {
/* 441 */     return this._types;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class TypeParamStash
/*     */   {
/* 462 */     private static final TypeVariable<?>[] VARS_ABSTRACT_LIST = (TypeVariable<?>[])AbstractList.class.getTypeParameters();
/* 463 */     private static final TypeVariable<?>[] VARS_COLLECTION = (TypeVariable<?>[])Collection.class.getTypeParameters();
/* 464 */     private static final TypeVariable<?>[] VARS_ITERABLE = (TypeVariable<?>[])Iterable.class.getTypeParameters();
/* 465 */     private static final TypeVariable<?>[] VARS_LIST = (TypeVariable<?>[])List.class.getTypeParameters();
/* 466 */     private static final TypeVariable<?>[] VARS_ARRAY_LIST = (TypeVariable<?>[])ArrayList.class.getTypeParameters();
/*     */     
/* 468 */     private static final TypeVariable<?>[] VARS_MAP = (TypeVariable<?>[])Map.class.getTypeParameters();
/* 469 */     private static final TypeVariable<?>[] VARS_HASH_MAP = (TypeVariable<?>[])HashMap.class.getTypeParameters();
/* 470 */     private static final TypeVariable<?>[] VARS_LINKED_HASH_MAP = (TypeVariable<?>[])LinkedHashMap.class.getTypeParameters();
/*     */ 
/*     */     
/*     */     public static TypeVariable<?>[] paramsFor1(Class<?> erasedType) {
/* 474 */       if (erasedType == Collection.class) {
/* 475 */         return VARS_COLLECTION;
/*     */       }
/* 477 */       if (erasedType == List.class) {
/* 478 */         return VARS_LIST;
/*     */       }
/* 480 */       if (erasedType == ArrayList.class) {
/* 481 */         return VARS_ARRAY_LIST;
/*     */       }
/* 483 */       if (erasedType == AbstractList.class) {
/* 484 */         return VARS_ABSTRACT_LIST;
/*     */       }
/* 486 */       if (erasedType == Iterable.class) {
/* 487 */         return VARS_ITERABLE;
/*     */       }
/* 489 */       return (TypeVariable<?>[])erasedType.getTypeParameters();
/*     */     }
/*     */ 
/*     */     
/*     */     public static TypeVariable<?>[] paramsFor2(Class<?> erasedType) {
/* 494 */       if (erasedType == Map.class) {
/* 495 */         return VARS_MAP;
/*     */       }
/* 497 */       if (erasedType == HashMap.class) {
/* 498 */         return VARS_HASH_MAP;
/*     */       }
/* 500 */       if (erasedType == LinkedHashMap.class) {
/* 501 */         return VARS_LINKED_HASH_MAP;
/*     */       }
/* 503 */       return (TypeVariable<?>[])erasedType.getTypeParameters();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class AsKey
/*     */   {
/*     */     private final Class<?> _raw;
/*     */     
/*     */     private final JavaType[] _params;
/*     */     
/*     */     private final int _hash;
/*     */ 
/*     */     
/*     */     public AsKey(Class<?> raw, JavaType[] params, int hash) {
/* 518 */       this._raw = raw;
/* 519 */       this._params = params;
/* 520 */       this._hash = 31 * raw.hashCode() + hash;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 524 */       return this._hash;
/*     */     }
/*     */     
/*     */     public boolean equals(Object o) {
/* 528 */       if (o == this) return true; 
/* 529 */       if (o == null) return false; 
/* 530 */       if (o.getClass() != getClass()) return false; 
/* 531 */       AsKey other = (AsKey)o;
/*     */       
/* 533 */       if (this._hash == other._hash && this._raw == other._raw) {
/* 534 */         JavaType[] otherParams = other._params;
/* 535 */         int len = this._params.length;
/*     */         
/* 537 */         if (len == otherParams.length) {
/* 538 */           for (int i = 0; i < len; i++) {
/* 539 */             if (!Objects.equals(this._params[i], otherParams[i])) {
/* 540 */               return false;
/*     */             }
/*     */           } 
/* 543 */           return true;
/*     */         } 
/*     */       } 
/* 546 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 551 */       return this._raw.getName() + "<>";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\type\TypeBindings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */