/*    */ package com.fasterxml.jackson.databind.type;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class IdentityEqualityType
/*    */   extends TypeBase
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   protected IdentityEqualityType(Class<?> raw, TypeBindings bindings, JavaType superClass, JavaType[] superInts, int hash, Object valueHandler, Object typeHandler, boolean asStatic) {
/* 18 */     super(raw, bindings, superClass, superInts, hash, valueHandler, typeHandler, asStatic);
/*    */   }
/*    */ 
/*    */   
/*    */   public final boolean equals(Object o) {
/* 23 */     return (o == this);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public final int hashCode() {
/* 29 */     return System.identityHashCode(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\type\IdentityEqualityType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */