/*     */ package com.fasterxml.jackson.databind.type;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeParser
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected static final int MAX_TYPE_LENGTH = 64000;
/*     */   protected static final int MAX_TYPE_NESTING = 1000;
/*     */   protected final TypeFactory _factory;
/*     */   
/*     */   public TypeParser(TypeFactory f) {
/*  36 */     this._factory = f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeParser withFactory(TypeFactory f) {
/*  43 */     return (f == this._factory) ? this : new TypeParser(f);
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType parse(String canonical) throws IllegalArgumentException {
/*  48 */     if (canonical.length() > 64000) {
/*  49 */       throw new IllegalArgumentException(String.format("Failed to parse type %s: too long (%d characters), maximum length allowed: %d", new Object[] {
/*     */               
/*  51 */               _quoteTruncated(canonical), 
/*  52 */               Integer.valueOf(canonical.length()), 
/*  53 */               Integer.valueOf(64000)
/*     */             }));
/*     */     }
/*  56 */     MyTokenizer tokens = new MyTokenizer(canonical.trim());
/*  57 */     JavaType type = parseType(tokens, 1000);
/*     */     
/*  59 */     if (tokens.hasMoreTokens()) {
/*  60 */       throw _problem(tokens, "Unexpected tokens after complete type");
/*     */     }
/*  62 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected JavaType parseType(MyTokenizer tokens, int nestingAllowed) throws IllegalArgumentException {
/*  68 */     if (!tokens.hasMoreTokens()) {
/*  69 */       throw _problem(tokens, "Unexpected end-of-string");
/*     */     }
/*  71 */     Class<?> base = findClass(tokens.nextToken(), tokens);
/*     */ 
/*     */     
/*  74 */     if (tokens.hasMoreTokens()) {
/*  75 */       String token = tokens.nextToken();
/*  76 */       if ("<".equals(token)) {
/*  77 */         List<JavaType> parameterTypes = parseTypes(tokens, nestingAllowed - 1);
/*  78 */         TypeBindings b = TypeBindings.create(base, parameterTypes);
/*  79 */         return this._factory._fromClass(null, base, b);
/*     */       } 
/*     */       
/*  82 */       tokens.pushBack(token);
/*     */     } 
/*  84 */     return this._factory._fromClass(null, base, TypeBindings.emptyBindings());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<JavaType> parseTypes(MyTokenizer tokens, int nestingAllowed) throws IllegalArgumentException {
/*  90 */     if (nestingAllowed < 0) {
/*  91 */       throw _problem(tokens, "too deeply nested; exceeds maximum of 1000 nesting levels");
/*     */     }
/*     */     
/*  94 */     ArrayList<JavaType> types = new ArrayList<>();
/*  95 */     while (tokens.hasMoreTokens()) {
/*  96 */       types.add(parseType(tokens, nestingAllowed));
/*  97 */       if (!tokens.hasMoreTokens())
/*  98 */         break;  String token = tokens.nextToken();
/*  99 */       if (">".equals(token)) return types; 
/* 100 */       if (!",".equals(token)) {
/* 101 */         throw _problem(tokens, "Unexpected token '" + token + "', expected ',' or '>')");
/*     */       }
/*     */     } 
/* 104 */     throw _problem(tokens, "Unexpected end-of-string");
/*     */   }
/*     */ 
/*     */   
/*     */   protected Class<?> findClass(String className, MyTokenizer tokens) {
/*     */     try {
/* 110 */       return this._factory.findClass(className);
/* 111 */     } catch (Exception e) {
/* 112 */       ClassUtil.throwIfRTE(e);
/* 113 */       throw _problem(tokens, "Cannot locate class '" + className + "', problem: " + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected IllegalArgumentException _problem(MyTokenizer tokens, String msg) {
/* 119 */     return new IllegalArgumentException(String.format("Failed to parse type %s (remaining: %s): %s", new Object[] {
/* 120 */             _quoteTruncated(tokens.getAllInput()), 
/* 121 */             _quoteTruncated(tokens.getRemainingInput()), msg
/*     */           }));
/*     */   }
/*     */   
/*     */   private static String _quoteTruncated(String str) {
/* 126 */     if (str.length() <= 1000) {
/* 127 */       return "'" + str + "'";
/*     */     }
/* 129 */     return String.format("'%s...'[truncated %d charaters]", new Object[] { str
/* 130 */           .substring(0, 1000), Integer.valueOf(str.length() - 1000) });
/*     */   }
/*     */ 
/*     */   
/*     */   protected static final class MyTokenizer
/*     */     extends StringTokenizer
/*     */   {
/*     */     protected final String _input;
/*     */     protected int _index;
/*     */     protected String _pushbackToken;
/*     */     
/*     */     public MyTokenizer(String str) {
/* 142 */       super(str, "<,>", true);
/* 143 */       this._input = str;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean hasMoreTokens() {
/* 148 */       return (this._pushbackToken != null || super.hasMoreTokens());
/*     */     }
/*     */ 
/*     */     
/*     */     public String nextToken() {
/*     */       String token;
/* 154 */       if (this._pushbackToken != null) {
/* 155 */         token = this._pushbackToken;
/* 156 */         this._pushbackToken = null;
/*     */       } else {
/* 158 */         token = super.nextToken();
/* 159 */         this._index += token.length();
/* 160 */         token = token.trim();
/*     */       } 
/* 162 */       return token;
/*     */     }
/*     */     
/*     */     public void pushBack(String token) {
/* 166 */       this._pushbackToken = token;
/*     */     }
/*     */     
/*     */     public String getAllInput() {
/* 170 */       return this._input;
/*     */     } public String getRemainingInput() {
/* 172 */       return this._input.substring(this._index);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\type\TypeParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */