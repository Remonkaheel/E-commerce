/*     */ package com.fasterxml.jackson.databind.type;
/*     */ 
/*     */ import com.fasterxml.jackson.core.type.ResolvedType;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IterationType
/*     */   extends SimpleType
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JavaType _iteratedType;
/*     */   
/*     */   protected IterationType(Class<?> cls, TypeBindings bindings, JavaType superClass, JavaType[] superInts, JavaType iteratedType, Object valueHandler, Object typeHandler, boolean asStatic) {
/*  25 */     super(cls, bindings, superClass, superInts, Objects.hashCode(iteratedType), valueHandler, typeHandler, asStatic);
/*     */     
/*  27 */     this._iteratedType = iteratedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IterationType(TypeBase base, JavaType iteratedType) {
/*  37 */     super(base);
/*  38 */     this._iteratedType = iteratedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IterationType upgradeFrom(JavaType baseType, JavaType iteratedType) {
/*  49 */     Objects.requireNonNull(iteratedType);
/*     */ 
/*     */     
/*  52 */     if (baseType instanceof TypeBase) {
/*  53 */       return new IterationType((TypeBase)baseType, iteratedType);
/*     */     }
/*  55 */     throw new IllegalArgumentException("Cannot upgrade from an instance of " + baseType.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static IterationType construct(Class<?> cls, TypeBindings bindings, JavaType superClass, JavaType[] superInts, JavaType iteratedType) {
/*  61 */     return new IterationType(cls, bindings, superClass, superInts, iteratedType, null, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType withContentType(JavaType contentType) {
/*  67 */     if (this._iteratedType == contentType) {
/*  68 */       return this;
/*     */     }
/*  70 */     return new IterationType(this._class, this._bindings, this._superClass, this._superInterfaces, contentType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IterationType withTypeHandler(Object h) {
/*  77 */     if (h == this._typeHandler) {
/*  78 */       return this;
/*     */     }
/*  80 */     return new IterationType(this._class, this._bindings, this._superClass, this._superInterfaces, this._iteratedType, this._valueHandler, h, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IterationType withContentTypeHandler(Object h) {
/*  87 */     if (h == this._iteratedType.getTypeHandler()) {
/*  88 */       return this;
/*     */     }
/*  90 */     return new IterationType(this._class, this._bindings, this._superClass, this._superInterfaces, this._iteratedType
/*  91 */         .withTypeHandler(h), this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IterationType withValueHandler(Object h) {
/*  97 */     if (h == this._valueHandler) {
/*  98 */       return this;
/*     */     }
/* 100 */     return new IterationType(this._class, this._bindings, this._superClass, this._superInterfaces, this._iteratedType, h, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IterationType withContentValueHandler(Object h) {
/* 107 */     if (h == this._iteratedType.getValueHandler()) {
/* 108 */       return this;
/*     */     }
/* 110 */     return new IterationType(this._class, this._bindings, this._superClass, this._superInterfaces, this._iteratedType
/* 111 */         .withValueHandler(h), this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IterationType withStaticTyping() {
/* 117 */     if (this._asStatic) {
/* 118 */       return this;
/*     */     }
/* 120 */     return new IterationType(this._class, this._bindings, this._superClass, this._superInterfaces, this._iteratedType
/* 121 */         .withStaticTyping(), this._valueHandler, this._typeHandler, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType refine(Class<?> rawType, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/* 128 */     return new IterationType(rawType, this._bindings, superClass, superInterfaces, this._iteratedType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String buildCanonicalName() {
/* 136 */     StringBuilder sb = new StringBuilder();
/* 137 */     sb.append(this._class.getName());
/* 138 */     if (this._iteratedType != null && _hasNTypeParameters(1)) {
/* 139 */       sb.append('<');
/* 140 */       sb.append(this._iteratedType.toCanonical());
/* 141 */       sb.append('>');
/*     */     } 
/* 143 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType getContentType() {
/* 154 */     return this._iteratedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasContentType() {
/* 159 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isIterationType() {
/* 164 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder getErasedSignature(StringBuilder sb) {
/* 169 */     return _classSignature(this._class, sb, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder getGenericSignature(StringBuilder sb) {
/* 175 */     _classSignature(this._class, sb, false);
/* 176 */     sb.append('<');
/* 177 */     sb = this._iteratedType.getGenericSignature(sb);
/* 178 */     sb.append(">;");
/* 179 */     return sb;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\type\IterationType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */