/*     */ package com.fasterxml.jackson.databind.type;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MapType
/*     */   extends MapLikeType
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   private MapType(Class<?> mapType, TypeBindings bindings, JavaType superClass, JavaType[] superInts, JavaType keyT, JavaType valueT, Object valueHandler, Object typeHandler, boolean asStatic) {
/*  23 */     super(mapType, bindings, superClass, superInts, keyT, valueT, valueHandler, typeHandler, asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapType(TypeBase base, JavaType keyT, JavaType valueT) {
/*  31 */     super(base, keyT, valueT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MapType construct(Class<?> rawType, TypeBindings bindings, JavaType superClass, JavaType[] superInts, JavaType keyT, JavaType valueT) {
/*  40 */     return new MapType(rawType, bindings, superClass, superInts, keyT, valueT, null, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static MapType construct(Class<?> rawType, JavaType keyT, JavaType valueT) {
/*     */     TypeBindings bindings;
/*  48 */     TypeVariable[] arrayOfTypeVariable = (TypeVariable[])rawType.getTypeParameters();
/*     */     
/*  50 */     if (arrayOfTypeVariable == null || arrayOfTypeVariable.length != 2) {
/*  51 */       bindings = TypeBindings.emptyBindings();
/*     */     } else {
/*  53 */       bindings = TypeBindings.create(rawType, keyT, valueT);
/*     */     } 
/*     */     
/*  56 */     return new MapType(rawType, bindings, _bogusSuperClass(rawType), null, keyT, valueT, null, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MapType withTypeHandler(Object h) {
/*  62 */     return new MapType(this._class, this._bindings, this._superClass, this._superInterfaces, this._keyType, this._valueType, this._valueHandler, h, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapType withContentTypeHandler(Object h) {
/*  69 */     return new MapType(this._class, this._bindings, this._superClass, this._superInterfaces, this._keyType, this._valueType
/*  70 */         .withTypeHandler(h), this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MapType withValueHandler(Object h) {
/*  76 */     return new MapType(this._class, this._bindings, this._superClass, this._superInterfaces, this._keyType, this._valueType, h, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MapType withContentValueHandler(Object h) {
/*  82 */     return new MapType(this._class, this._bindings, this._superClass, this._superInterfaces, this._keyType, this._valueType
/*  83 */         .withValueHandler(h), this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MapType withStaticTyping() {
/*  89 */     if (this._asStatic) {
/*  90 */       return this;
/*     */     }
/*  92 */     return new MapType(this._class, this._bindings, this._superClass, this._superInterfaces, this._keyType
/*  93 */         .withStaticTyping(), this._valueType.withStaticTyping(), this._valueHandler, this._typeHandler, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType withContentType(JavaType contentType) {
/*  99 */     if (this._valueType == contentType) {
/* 100 */       return this;
/*     */     }
/* 102 */     return new MapType(this._class, this._bindings, this._superClass, this._superInterfaces, this._keyType, contentType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MapType withKeyType(JavaType keyType) {
/* 108 */     if (keyType == this._keyType) {
/* 109 */       return this;
/*     */     }
/* 111 */     return new MapType(this._class, this._bindings, this._superClass, this._superInterfaces, keyType, this._valueType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType refine(Class<?> rawType, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/* 118 */     return new MapType(rawType, bindings, superClass, superInterfaces, this._keyType, this._valueType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapType withKeyTypeHandler(Object h) {
/* 132 */     return new MapType(this._class, this._bindings, this._superClass, this._superInterfaces, this._keyType
/* 133 */         .withTypeHandler(h), this._valueType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MapType withKeyValueHandler(Object h) {
/* 139 */     return new MapType(this._class, this._bindings, this._superClass, this._superInterfaces, this._keyType
/* 140 */         .withValueHandler(h), this._valueType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 153 */     return "[map type; class " + this._class.getName() + ", " + this._keyType + " -> " + this._valueType + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\type\MapType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */