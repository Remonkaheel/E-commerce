/*     */ package com.fasterxml.jackson.databind.type;
/*     */ 
/*     */ import com.fasterxml.jackson.core.type.ResolvedType;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReferenceType
/*     */   extends SimpleType
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JavaType _referencedType;
/*     */   @Deprecated
/*     */   protected final JavaType _anchorType;
/*     */   
/*     */   protected ReferenceType(Class<?> cls, TypeBindings bindings, JavaType superClass, JavaType[] superInts, JavaType refType, JavaType anchorType, Object valueHandler, Object typeHandler, boolean asStatic) {
/*  39 */     super(cls, bindings, superClass, superInts, Objects.hashCode(refType), valueHandler, typeHandler, asStatic);
/*     */     
/*  41 */     this._referencedType = refType;
/*  42 */     this._anchorType = (anchorType == null) ? this : anchorType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ReferenceType(TypeBase base, JavaType refType) {
/*  54 */     super(base);
/*  55 */     this._referencedType = refType;
/*     */     
/*  57 */     this._anchorType = this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReferenceType upgradeFrom(JavaType baseType, JavaType refdType) {
/*  70 */     if (refdType == null) {
/*  71 */       throw new IllegalArgumentException("Missing referencedType");
/*     */     }
/*     */ 
/*     */     
/*  75 */     if (baseType instanceof TypeBase) {
/*  76 */       return new ReferenceType((TypeBase)baseType, refdType);
/*     */     }
/*  78 */     throw new IllegalArgumentException("Cannot upgrade from an instance of " + baseType.getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ReferenceType construct(Class<?> cls, TypeBindings bindings, JavaType superClass, JavaType[] superInts, JavaType refType) {
/*  87 */     return new ReferenceType(cls, bindings, superClass, superInts, refType, null, null, null, false);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static ReferenceType construct(Class<?> cls, JavaType refType) {
/*  93 */     return new ReferenceType(cls, TypeBindings.emptyBindings(), null, null, null, refType, null, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType withContentType(JavaType contentType) {
/* 100 */     if (this._referencedType == contentType) {
/* 101 */       return this;
/*     */     }
/* 103 */     return new ReferenceType(this._class, this._bindings, this._superClass, this._superInterfaces, contentType, this._anchorType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceType withTypeHandler(Object h) {
/* 110 */     if (h == this._typeHandler) {
/* 111 */       return this;
/*     */     }
/* 113 */     return new ReferenceType(this._class, this._bindings, this._superClass, this._superInterfaces, this._referencedType, this._anchorType, this._valueHandler, h, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceType withContentTypeHandler(Object h) {
/* 120 */     if (h == this._referencedType.getTypeHandler()) {
/* 121 */       return this;
/*     */     }
/* 123 */     return new ReferenceType(this._class, this._bindings, this._superClass, this._superInterfaces, this._referencedType
/* 124 */         .withTypeHandler(h), this._anchorType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceType withValueHandler(Object h) {
/* 130 */     if (h == this._valueHandler) {
/* 131 */       return this;
/*     */     }
/* 133 */     return new ReferenceType(this._class, this._bindings, this._superClass, this._superInterfaces, this._referencedType, this._anchorType, h, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceType withContentValueHandler(Object h) {
/* 140 */     if (h == this._referencedType.getValueHandler()) {
/* 141 */       return this;
/*     */     }
/* 143 */     return new ReferenceType(this._class, this._bindings, this._superClass, this._superInterfaces, this._referencedType
/* 144 */         .withValueHandler(h), this._anchorType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ReferenceType withStaticTyping() {
/* 150 */     if (this._asStatic) {
/* 151 */       return this;
/*     */     }
/* 153 */     return new ReferenceType(this._class, this._bindings, this._superClass, this._superInterfaces, this._referencedType
/* 154 */         .withStaticTyping(), this._anchorType, this._valueHandler, this._typeHandler, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType refine(Class<?> rawType, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/* 161 */     return new ReferenceType(rawType, this._bindings, superClass, superInterfaces, this._referencedType, this._anchorType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String buildCanonicalName() {
/* 169 */     StringBuilder sb = new StringBuilder();
/* 170 */     sb.append(this._class.getName());
/* 171 */     if (this._referencedType != null && _hasNTypeParameters(1)) {
/* 172 */       sb.append('<');
/* 173 */       sb.append(this._referencedType.toCanonical());
/* 174 */       sb.append('>');
/*     */     } 
/* 176 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType getContentType() {
/* 187 */     return this._referencedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType getReferencedType() {
/* 192 */     return this._referencedType;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasContentType() {
/* 197 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReferenceType() {
/* 202 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder getErasedSignature(StringBuilder sb) {
/* 207 */     return _classSignature(this._class, sb, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder getGenericSignature(StringBuilder sb) {
/* 213 */     _classSignature(this._class, sb, false);
/* 214 */     sb.append('<');
/* 215 */     sb = this._referencedType.getGenericSignature(sb);
/* 216 */     sb.append(">;");
/* 217 */     return sb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JavaType getAnchorType() {
/* 231 */     return this._anchorType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean isAnchorType() {
/* 242 */     return (this._anchorType == this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 254 */     return (new StringBuilder(40))
/* 255 */       .append("[reference type, class ")
/* 256 */       .append(buildCanonicalName())
/* 257 */       .append('<')
/* 258 */       .append(this._referencedType)
/* 259 */       .append('>')
/* 260 */       .append(']')
/* 261 */       .toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 267 */     if (o == this) return true; 
/* 268 */     if (o == null) return false; 
/* 269 */     if (o.getClass() != getClass()) return false;
/*     */     
/* 271 */     ReferenceType other = (ReferenceType)o;
/*     */     
/* 273 */     if (other._class != this._class) return false;
/*     */ 
/*     */     
/* 276 */     return this._referencedType.equals(other._referencedType);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\type\ReferenceType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */