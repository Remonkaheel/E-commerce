/*      */ package com.fasterxml.jackson.databind.type;
/*      */ 
/*      */ import com.fasterxml.jackson.core.type.TypeReference;
/*      */ import com.fasterxml.jackson.databind.JavaType;
/*      */ import com.fasterxml.jackson.databind.JsonNode;
/*      */ import com.fasterxml.jackson.databind.util.ArrayBuilders;
/*      */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*      */ import com.fasterxml.jackson.databind.util.LRUMap;
/*      */ import com.fasterxml.jackson.databind.util.LookupCache;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.GenericArrayType;
/*      */ import java.lang.reflect.ParameterizedType;
/*      */ import java.lang.reflect.Type;
/*      */ import java.lang.reflect.TypeVariable;
/*      */ import java.lang.reflect.WildcardType;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import java.util.Properties;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ import java.util.stream.BaseStream;
/*      */ import java.util.stream.DoubleStream;
/*      */ import java.util.stream.IntStream;
/*      */ import java.util.stream.LongStream;
/*      */ import java.util.stream.Stream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TypeFactory
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 1L;
/*      */   public static final int DEFAULT_MAX_CACHE_SIZE = 200;
/*   76 */   private static final JavaType[] NO_TYPES = new JavaType[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   83 */   protected static final TypeFactory instance = new TypeFactory();
/*      */   
/*   85 */   protected static final TypeBindings EMPTY_BINDINGS = TypeBindings.emptyBindings();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   97 */   private static final Class<?> CLS_STRING = String.class;
/*   98 */   private static final Class<?> CLS_OBJECT = Object.class;
/*      */   
/*  100 */   private static final Class<?> CLS_COMPARABLE = Comparable.class;
/*  101 */   private static final Class<?> CLS_ENUM = Enum.class;
/*  102 */   private static final Class<?> CLS_JSON_NODE = JsonNode.class;
/*      */   
/*  104 */   private static final Class<?> CLS_BOOL = boolean.class;
/*  105 */   private static final Class<?> CLS_DOUBLE = double.class;
/*  106 */   private static final Class<?> CLS_INT = int.class;
/*  107 */   private static final Class<?> CLS_LONG = long.class;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  116 */   protected static final SimpleType CORE_TYPE_BOOL = new SimpleType(CLS_BOOL);
/*  117 */   protected static final SimpleType CORE_TYPE_DOUBLE = new SimpleType(CLS_DOUBLE);
/*  118 */   protected static final SimpleType CORE_TYPE_INT = new SimpleType(CLS_INT);
/*  119 */   protected static final SimpleType CORE_TYPE_LONG = new SimpleType(CLS_LONG);
/*      */ 
/*      */   
/*  122 */   protected static final SimpleType CORE_TYPE_STRING = new SimpleType(CLS_STRING);
/*      */ 
/*      */   
/*  125 */   protected static final SimpleType CORE_TYPE_OBJECT = new SimpleType(CLS_OBJECT);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  133 */   protected static final SimpleType CORE_TYPE_COMPARABLE = new SimpleType(CLS_COMPARABLE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  141 */   protected static final SimpleType CORE_TYPE_ENUM = new SimpleType(CLS_ENUM);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  149 */   protected static final SimpleType CORE_TYPE_JSON_NODE = new SimpleType(CLS_JSON_NODE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final LookupCache<Object, JavaType> _typeCache;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final TypeModifier[] _modifiers;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final TypeParser _parser;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ClassLoader _classLoader;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TypeFactory() {
/*  184 */     this((LookupCache<Object, JavaType>)new LRUMap(16, 200));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TypeFactory(LookupCache<Object, JavaType> typeCache) {
/*  191 */     this._typeCache = Objects.<LookupCache<Object, JavaType>>requireNonNull(typeCache);
/*  192 */     this._parser = new TypeParser(this);
/*  193 */     this._modifiers = null;
/*  194 */     this._classLoader = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected TypeFactory(LookupCache<Object, JavaType> typeCache, TypeParser p, TypeModifier[] mods, ClassLoader classLoader) {
/*      */     LRUMap lRUMap;
/*  203 */     if (typeCache == null) {
/*  204 */       lRUMap = new LRUMap(16, 200);
/*      */     }
/*  206 */     this._typeCache = (LookupCache<Object, JavaType>)lRUMap;
/*      */     
/*  208 */     this._parser = p.withFactory(this);
/*  209 */     this._modifiers = mods;
/*  210 */     this._classLoader = classLoader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TypeFactory createDefaultInstance() {
/*  219 */     return new TypeFactory();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeFactory withModifier(TypeModifier mod) {
/*      */     TypeModifier[] mods;
/*  228 */     LookupCache<Object, JavaType> typeCache = this._typeCache;
/*      */     
/*  230 */     if (mod == null) {
/*  231 */       mods = null;
/*      */ 
/*      */       
/*  234 */       typeCache = null;
/*  235 */     } else if (this._modifiers == null) {
/*  236 */       mods = new TypeModifier[] { mod };
/*      */ 
/*      */       
/*  239 */       typeCache = null;
/*      */     } else {
/*      */       
/*  242 */       mods = (TypeModifier[])ArrayBuilders.insertInListNoDup((Object[])this._modifiers, mod);
/*      */     } 
/*  244 */     return new TypeFactory(typeCache, this._parser, mods, this._classLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeFactory withClassLoader(ClassLoader classLoader) {
/*  252 */     return new TypeFactory(this._typeCache, this._parser, this._modifiers, classLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public TypeFactory withCache(LRUMap<Object, JavaType> cache) {
/*  265 */     return new TypeFactory((LookupCache<Object, JavaType>)cache, this._parser, this._modifiers, this._classLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TypeFactory withCache(LookupCache<Object, JavaType> cache) {
/*  275 */     return new TypeFactory(cache, this._parser, this._modifiers, this._classLoader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TypeFactory defaultInstance() {
/*  283 */     return instance;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearCache() {
/*  296 */     this._typeCache.clear();
/*      */   }
/*      */   
/*      */   public ClassLoader getClassLoader() {
/*  300 */     return this._classLoader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static JavaType unknownType() {
/*  317 */     return CORE_TYPE_OBJECT;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> rawClass(Type t) {
/*  327 */     if (t instanceof Class)
/*  328 */       return (Class)t; 
/*  329 */     if (t instanceof JavaType)
/*  330 */       return ((JavaType)t).getRawClass(); 
/*  331 */     if (t instanceof GenericArrayType)
/*  332 */       return Array.newInstance(rawClass(((GenericArrayType)t).getGenericComponentType()), 0).getClass(); 
/*  333 */     if (t instanceof ParameterizedType)
/*  334 */       return rawClass(((ParameterizedType)t).getRawType()); 
/*  335 */     if (t instanceof TypeVariable)
/*  336 */       return rawClass(((TypeVariable)t).getBounds()[0]); 
/*  337 */     if (t instanceof WildcardType) {
/*  338 */       return rawClass(((WildcardType)t).getUpperBounds()[0]);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  343 */     return defaultInstance().constructType(t).getRawClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<?> findClass(String className) throws ClassNotFoundException {
/*  360 */     if (className.indexOf('.') < 0) {
/*  361 */       Class<?> prim = _findPrimitive(className);
/*  362 */       if (prim != null) {
/*  363 */         return prim;
/*      */       }
/*      */     } 
/*      */     
/*  367 */     Throwable prob = null;
/*  368 */     ClassLoader loader = getClassLoader();
/*  369 */     if (loader == null) {
/*  370 */       loader = Thread.currentThread().getContextClassLoader();
/*      */     }
/*  372 */     if (loader != null) {
/*      */       try {
/*  374 */         return classForName(className, true, loader);
/*  375 */       } catch (Exception e) {
/*  376 */         prob = ClassUtil.getRootCause(e);
/*      */       } 
/*      */     }
/*      */     try {
/*  380 */       return classForName(className);
/*  381 */     } catch (Exception e) {
/*  382 */       if (prob == null) {
/*  383 */         prob = ClassUtil.getRootCause(e);
/*      */       }
/*      */       
/*  386 */       ClassUtil.throwIfRTE(prob);
/*  387 */       throw new ClassNotFoundException(prob.getMessage(), prob);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected Class<?> classForName(String name, boolean initialize, ClassLoader loader) throws ClassNotFoundException {
/*  392 */     return Class.forName(name, true, loader);
/*      */   }
/*      */   
/*      */   protected Class<?> classForName(String name) throws ClassNotFoundException {
/*  396 */     return Class.forName(name);
/*      */   }
/*      */ 
/*      */   
/*      */   protected Class<?> _findPrimitive(String className) {
/*  401 */     if ("int".equals(className)) return int.class; 
/*  402 */     if ("long".equals(className)) return long.class; 
/*  403 */     if ("float".equals(className)) return float.class; 
/*  404 */     if ("double".equals(className)) return double.class; 
/*  405 */     if ("boolean".equals(className)) return boolean.class; 
/*  406 */     if ("byte".equals(className)) return byte.class; 
/*  407 */     if ("char".equals(className)) return char.class; 
/*  408 */     if ("short".equals(className)) return short.class; 
/*  409 */     if ("void".equals(className)) return void.class; 
/*  410 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructSpecializedType(JavaType baseType, Class<?> subclass) throws IllegalArgumentException {
/*  435 */     return constructSpecializedType(baseType, subclass, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructSpecializedType(JavaType baseType, Class<?> subclass, boolean relaxedCompatibilityCheck) throws IllegalArgumentException {
/*      */     // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: invokevirtual getRawClass : ()Ljava/lang/Class;
/*      */     //   4: astore #4
/*      */     //   6: aload #4
/*      */     //   8: aload_2
/*      */     //   9: if_acmpne -> 14
/*      */     //   12: aload_1
/*      */     //   13: areturn
/*      */     //   14: aload #4
/*      */     //   16: ldc java/lang/Object
/*      */     //   18: if_acmpne -> 35
/*      */     //   21: aload_0
/*      */     //   22: aconst_null
/*      */     //   23: aload_2
/*      */     //   24: getstatic com/fasterxml/jackson/databind/type/TypeFactory.EMPTY_BINDINGS : Lcom/fasterxml/jackson/databind/type/TypeBindings;
/*      */     //   27: invokevirtual _fromClass : (Lcom/fasterxml/jackson/databind/type/ClassStack;Ljava/lang/Class;Lcom/fasterxml/jackson/databind/type/TypeBindings;)Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   30: astore #5
/*      */     //   32: goto -> 266
/*      */     //   35: aload #4
/*      */     //   37: aload_2
/*      */     //   38: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
/*      */     //   41: ifne -> 75
/*      */     //   44: new java/lang/IllegalArgumentException
/*      */     //   47: dup
/*      */     //   48: ldc 'Class %s not subtype of %s'
/*      */     //   50: iconst_2
/*      */     //   51: anewarray java/lang/Object
/*      */     //   54: dup
/*      */     //   55: iconst_0
/*      */     //   56: aload_2
/*      */     //   57: invokestatic nameOf : (Ljava/lang/Class;)Ljava/lang/String;
/*      */     //   60: aastore
/*      */     //   61: dup
/*      */     //   62: iconst_1
/*      */     //   63: aload_1
/*      */     //   64: invokestatic getTypeDescription : (Lcom/fasterxml/jackson/databind/JavaType;)Ljava/lang/String;
/*      */     //   67: aastore
/*      */     //   68: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   71: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   74: athrow
/*      */     //   75: aload_1
/*      */     //   76: invokevirtual isContainerType : ()Z
/*      */     //   79: ifeq -> 195
/*      */     //   82: aload_1
/*      */     //   83: invokevirtual isMapLikeType : ()Z
/*      */     //   86: ifeq -> 136
/*      */     //   89: aload_2
/*      */     //   90: ldc java/util/HashMap
/*      */     //   92: if_acmpeq -> 113
/*      */     //   95: aload_2
/*      */     //   96: ldc java/util/LinkedHashMap
/*      */     //   98: if_acmpeq -> 113
/*      */     //   101: aload_2
/*      */     //   102: ldc java/util/EnumMap
/*      */     //   104: if_acmpeq -> 113
/*      */     //   107: aload_2
/*      */     //   108: ldc java/util/TreeMap
/*      */     //   110: if_acmpne -> 195
/*      */     //   113: aload_0
/*      */     //   114: aconst_null
/*      */     //   115: aload_2
/*      */     //   116: aload_2
/*      */     //   117: aload_1
/*      */     //   118: invokevirtual getKeyType : ()Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   121: aload_1
/*      */     //   122: invokevirtual getContentType : ()Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   125: invokestatic create : (Ljava/lang/Class;Lcom/fasterxml/jackson/databind/JavaType;Lcom/fasterxml/jackson/databind/JavaType;)Lcom/fasterxml/jackson/databind/type/TypeBindings;
/*      */     //   128: invokevirtual _fromClass : (Lcom/fasterxml/jackson/databind/type/ClassStack;Ljava/lang/Class;Lcom/fasterxml/jackson/databind/type/TypeBindings;)Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   131: astore #5
/*      */     //   133: goto -> 266
/*      */     //   136: aload_1
/*      */     //   137: invokevirtual isCollectionLikeType : ()Z
/*      */     //   140: ifeq -> 195
/*      */     //   143: aload_2
/*      */     //   144: ldc java/util/ArrayList
/*      */     //   146: if_acmpeq -> 167
/*      */     //   149: aload_2
/*      */     //   150: ldc java/util/LinkedList
/*      */     //   152: if_acmpeq -> 167
/*      */     //   155: aload_2
/*      */     //   156: ldc java/util/HashSet
/*      */     //   158: if_acmpeq -> 167
/*      */     //   161: aload_2
/*      */     //   162: ldc java/util/TreeSet
/*      */     //   164: if_acmpne -> 186
/*      */     //   167: aload_0
/*      */     //   168: aconst_null
/*      */     //   169: aload_2
/*      */     //   170: aload_2
/*      */     //   171: aload_1
/*      */     //   172: invokevirtual getContentType : ()Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   175: invokestatic create : (Ljava/lang/Class;Lcom/fasterxml/jackson/databind/JavaType;)Lcom/fasterxml/jackson/databind/type/TypeBindings;
/*      */     //   178: invokevirtual _fromClass : (Lcom/fasterxml/jackson/databind/type/ClassStack;Ljava/lang/Class;Lcom/fasterxml/jackson/databind/type/TypeBindings;)Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   181: astore #5
/*      */     //   183: goto -> 266
/*      */     //   186: aload #4
/*      */     //   188: ldc java/util/EnumSet
/*      */     //   190: if_acmpne -> 195
/*      */     //   193: aload_1
/*      */     //   194: areturn
/*      */     //   195: aload_1
/*      */     //   196: invokevirtual getBindings : ()Lcom/fasterxml/jackson/databind/type/TypeBindings;
/*      */     //   199: invokevirtual isEmpty : ()Z
/*      */     //   202: ifeq -> 219
/*      */     //   205: aload_0
/*      */     //   206: aconst_null
/*      */     //   207: aload_2
/*      */     //   208: getstatic com/fasterxml/jackson/databind/type/TypeFactory.EMPTY_BINDINGS : Lcom/fasterxml/jackson/databind/type/TypeBindings;
/*      */     //   211: invokevirtual _fromClass : (Lcom/fasterxml/jackson/databind/type/ClassStack;Ljava/lang/Class;Lcom/fasterxml/jackson/databind/type/TypeBindings;)Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   214: astore #5
/*      */     //   216: goto -> 266
/*      */     //   219: aload_2
/*      */     //   220: invokevirtual getTypeParameters : ()[Ljava/lang/reflect/TypeVariable;
/*      */     //   223: arraylength
/*      */     //   224: istore #6
/*      */     //   226: iload #6
/*      */     //   228: ifne -> 245
/*      */     //   231: aload_0
/*      */     //   232: aconst_null
/*      */     //   233: aload_2
/*      */     //   234: getstatic com/fasterxml/jackson/databind/type/TypeFactory.EMPTY_BINDINGS : Lcom/fasterxml/jackson/databind/type/TypeBindings;
/*      */     //   237: invokevirtual _fromClass : (Lcom/fasterxml/jackson/databind/type/ClassStack;Ljava/lang/Class;Lcom/fasterxml/jackson/databind/type/TypeBindings;)Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   240: astore #5
/*      */     //   242: goto -> 266
/*      */     //   245: aload_0
/*      */     //   246: aload_1
/*      */     //   247: iload #6
/*      */     //   249: aload_2
/*      */     //   250: iload_3
/*      */     //   251: invokespecial _bindingsForSubtype : (Lcom/fasterxml/jackson/databind/JavaType;ILjava/lang/Class;Z)Lcom/fasterxml/jackson/databind/type/TypeBindings;
/*      */     //   254: astore #7
/*      */     //   256: aload_0
/*      */     //   257: aconst_null
/*      */     //   258: aload_2
/*      */     //   259: aload #7
/*      */     //   261: invokevirtual _fromClass : (Lcom/fasterxml/jackson/databind/type/ClassStack;Ljava/lang/Class;Lcom/fasterxml/jackson/databind/type/TypeBindings;)Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   264: astore #5
/*      */     //   266: aload #5
/*      */     //   268: aload_1
/*      */     //   269: invokevirtual withHandlersFrom : (Lcom/fasterxml/jackson/databind/JavaType;)Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   272: astore #5
/*      */     //   274: aload #5
/*      */     //   276: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #460	-> 0
/*      */     //   #461	-> 6
/*      */     //   #462	-> 12
/*      */     //   #468	-> 14
/*      */     //   #469	-> 21
/*      */     //   #470	-> 32
/*      */     //   #472	-> 35
/*      */     //   #473	-> 44
/*      */     //   #474	-> 57
/*      */     //   #473	-> 68
/*      */     //   #480	-> 75
/*      */     //   #481	-> 82
/*      */     //   #482	-> 89
/*      */     //   #486	-> 113
/*      */     //   #487	-> 118
/*      */     //   #486	-> 128
/*      */     //   #488	-> 133
/*      */     //   #490	-> 136
/*      */     //   #491	-> 143
/*      */     //   #495	-> 167
/*      */     //   #496	-> 172
/*      */     //   #495	-> 178
/*      */     //   #497	-> 183
/*      */     //   #501	-> 186
/*      */     //   #502	-> 193
/*      */     //   #507	-> 195
/*      */     //   #508	-> 205
/*      */     //   #509	-> 216
/*      */     //   #513	-> 219
/*      */     //   #514	-> 226
/*      */     //   #515	-> 231
/*      */     //   #516	-> 242
/*      */     //   #519	-> 245
/*      */     //   #521	-> 256
/*      */     //   #527	-> 266
/*      */     //   #528	-> 274
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   32	3	5	newType	Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   133	3	5	newType	Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   183	3	5	newType	Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   216	3	5	newType	Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   242	3	5	newType	Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   226	40	6	typeParamCount	I
/*      */     //   256	10	7	tb	Lcom/fasterxml/jackson/databind/type/TypeBindings;
/*      */     //   0	277	0	this	Lcom/fasterxml/jackson/databind/type/TypeFactory;
/*      */     //   0	277	1	baseType	Lcom/fasterxml/jackson/databind/JavaType;
/*      */     //   0	277	2	subclass	Ljava/lang/Class;
/*      */     //   0	277	3	relaxedCompatibilityCheck	Z
/*      */     //   6	271	4	rawBase	Ljava/lang/Class;
/*      */     //   266	11	5	newType	Lcom/fasterxml/jackson/databind/JavaType;
/*      */     // Local variable type table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	277	2	subclass	Ljava/lang/Class<*>;
/*      */     //   6	271	4	rawBase	Ljava/lang/Class<*>;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TypeBindings _bindingsForSubtype(JavaType baseType, int typeParamCount, Class<?> subclass, boolean relaxedCompatibilityCheck) {
/*  534 */     PlaceholderForType[] placeholders = new PlaceholderForType[typeParamCount];
/*  535 */     for (int i = 0; i < typeParamCount; i++) {
/*  536 */       placeholders[i] = new PlaceholderForType(i);
/*      */     }
/*  538 */     TypeBindings b = TypeBindings.create(subclass, (JavaType[])placeholders);
/*      */     
/*  540 */     JavaType tmpSub = _fromClass(null, subclass, b);
/*      */     
/*  542 */     JavaType baseWithPlaceholders = tmpSub.findSuperType(baseType.getRawClass());
/*  543 */     if (baseWithPlaceholders == null) {
/*  544 */       throw new IllegalArgumentException(String.format("Internal error: unable to locate supertype (%s) from resolved subtype %s", new Object[] { baseType
/*  545 */               .getRawClass().getName(), subclass
/*  546 */               .getName() }));
/*      */     }
/*      */     
/*  549 */     String error = _resolveTypePlaceholders(baseType, baseWithPlaceholders);
/*  550 */     if (error != null)
/*      */     {
/*      */       
/*  553 */       if (!relaxedCompatibilityCheck) {
/*  554 */         throw new IllegalArgumentException("Failed to specialize base type " + baseType.toCanonical() + " as " + subclass
/*  555 */             .getName() + ", problem: " + error);
/*      */       }
/*      */     }
/*      */     
/*  559 */     JavaType[] typeParams = new JavaType[typeParamCount];
/*  560 */     for (int j = 0; j < typeParamCount; j++) {
/*  561 */       JavaType t = placeholders[j].actualType();
/*      */ 
/*      */ 
/*      */       
/*  565 */       if (t == null) {
/*  566 */         t = unknownType();
/*      */       }
/*  568 */       typeParams[j] = t;
/*      */     } 
/*  570 */     return TypeBindings.create(subclass, typeParams);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private String _resolveTypePlaceholders(JavaType sourceType, JavaType actualType) throws IllegalArgumentException {
/*  576 */     List<JavaType> expectedTypes = sourceType.getBindings().getTypeParameters();
/*  577 */     List<JavaType> actualTypes = actualType.getBindings().getTypeParameters();
/*      */     
/*  579 */     int actCount = actualTypes.size();
/*      */     
/*  581 */     for (int i = 0, expCount = expectedTypes.size(); i < expCount; i++) {
/*  582 */       JavaType exp = expectedTypes.get(i);
/*  583 */       JavaType act = (i < actCount) ? actualTypes.get(i) : unknownType();
/*      */       
/*  585 */       if (!_verifyAndResolvePlaceholders(exp, act))
/*      */       {
/*      */ 
/*      */         
/*  589 */         if (!exp.hasRawClass(Object.class))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  598 */           if (i != 0 || 
/*  599 */             !sourceType.isMapLikeType() || 
/*  600 */             !act.hasRawClass(Object.class))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  606 */             if (!exp.isInterface() || 
/*  607 */               !exp.isTypeOrSuperTypeOf(act.getRawClass()))
/*      */             {
/*      */ 
/*      */               
/*  611 */               return String.format("Type parameter #%d/%d differs; can not specialize %s with %s", new Object[] {
/*  612 */                     Integer.valueOf(i + 1), Integer.valueOf(expCount), exp.toCanonical(), act.toCanonical()
/*      */                   }); }  }  }  } 
/*      */     } 
/*  615 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _verifyAndResolvePlaceholders(JavaType exp, JavaType act) {
/*  621 */     if (act instanceof PlaceholderForType) {
/*  622 */       ((PlaceholderForType)act).actualType(exp);
/*  623 */       return true;
/*      */     } 
/*      */ 
/*      */     
/*  627 */     if (exp.getRawClass() != act.getRawClass()) {
/*  628 */       return false;
/*      */     }
/*      */     
/*  631 */     List<JavaType> expectedTypes = exp.getBindings().getTypeParameters();
/*  632 */     List<JavaType> actualTypes = act.getBindings().getTypeParameters();
/*  633 */     for (int i = 0, len = expectedTypes.size(); i < len; i++) {
/*  634 */       JavaType exp2 = expectedTypes.get(i);
/*  635 */       JavaType act2 = actualTypes.get(i);
/*  636 */       if (!_verifyAndResolvePlaceholders(exp2, act2)) {
/*  637 */         return false;
/*      */       }
/*      */     } 
/*  640 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructGeneralizedType(JavaType baseType, Class<?> superClass) {
/*  656 */     Class<?> rawBase = baseType.getRawClass();
/*  657 */     if (rawBase == superClass) {
/*  658 */       return baseType;
/*      */     }
/*  660 */     JavaType superType = baseType.findSuperType(superClass);
/*  661 */     if (superType == null) {
/*      */       
/*  663 */       if (!superClass.isAssignableFrom(rawBase)) {
/*  664 */         throw new IllegalArgumentException(String.format("Class %s not a super-type of %s", new Object[] { superClass
/*  665 */                 .getName(), baseType }));
/*      */       }
/*      */       
/*  668 */       throw new IllegalArgumentException(String.format("Internal error: class %s not included as super-type for %s", new Object[] { superClass
/*      */               
/*  670 */               .getName(), baseType }));
/*      */     } 
/*  672 */     return superType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructFromCanonical(String canonical) throws IllegalArgumentException {
/*  687 */     return this._parser.parse(canonical);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType[] findTypeParameters(JavaType type, Class<?> expType) {
/*  701 */     JavaType match = type.findSuperType(expType);
/*  702 */     if (match == null) {
/*  703 */       return NO_TYPES;
/*      */     }
/*  705 */     return match.getBindings().typeParameterArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType findFirstTypeParameter(JavaType type, Class<?> expType) {
/*  715 */     JavaType match = type.findSuperType(expType);
/*  716 */     if (match != null) {
/*  717 */       JavaType t = match.getBindings().getBoundTypeOrNull(0);
/*  718 */       if (t != null) {
/*  719 */         return t;
/*      */       }
/*      */     } 
/*  722 */     return _unknownType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType[] findTypeParameters(Class<?> clz, Class<?> expType, TypeBindings bindings) {
/*  730 */     return findTypeParameters(constructType(clz, bindings), expType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType[] findTypeParameters(Class<?> clz, Class<?> expType) {
/*  738 */     return findTypeParameters(constructType(clz), expType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType moreSpecificType(JavaType type1, JavaType type2) {
/*  753 */     if (type1 == null) {
/*  754 */       return type2;
/*      */     }
/*  756 */     if (type2 == null) {
/*  757 */       return type1;
/*      */     }
/*  759 */     Class<?> raw1 = type1.getRawClass();
/*  760 */     Class<?> raw2 = type2.getRawClass();
/*  761 */     if (raw1 == raw2) {
/*  762 */       return type1;
/*      */     }
/*      */     
/*  765 */     if (raw1.isAssignableFrom(raw2)) {
/*  766 */       return type2;
/*      */     }
/*  768 */     return type1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructType(Type type) {
/*  778 */     return _fromAny(null, type, EMPTY_BINDINGS);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructType(TypeReference<?> typeRef) {
/*  784 */     return _fromAny(null, typeRef.getType(), EMPTY_BINDINGS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType resolveMemberType(Type type, TypeBindings contextBindings) {
/*  822 */     return _fromAny(null, type, contextBindings);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType constructType(Type type, TypeBindings bindings) {
/*  845 */     if (type instanceof Class) {
/*  846 */       JavaType resultType = _fromClass(null, (Class)type, bindings);
/*  847 */       return _applyModifiers(type, resultType);
/*      */     } 
/*  849 */     return _fromAny(null, type, bindings);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType constructType(Type type, Class<?> contextClass) {
/*  857 */     JavaType contextType = (contextClass == null) ? null : constructType(contextClass);
/*  858 */     return constructType(type, contextType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType constructType(Type type, JavaType contextType) {
/*      */     TypeBindings bindings;
/*  867 */     if (contextType == null) {
/*  868 */       bindings = EMPTY_BINDINGS;
/*      */     } else {
/*  870 */       bindings = contextType.getBindings();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  875 */       if (type.getClass() != Class.class)
/*      */       {
/*      */         
/*  878 */         while (bindings.isEmpty()) {
/*  879 */           contextType = contextType.getSuperClass();
/*  880 */           if (contextType == null) {
/*      */             break;
/*      */           }
/*  883 */           bindings = contextType.getBindings();
/*      */         } 
/*      */       }
/*      */     } 
/*  887 */     return _fromAny(null, type, bindings);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayType constructArrayType(Class<?> elementType) {
/*  903 */     return ArrayType.construct(_fromAny(null, elementType, null), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ArrayType constructArrayType(JavaType elementType) {
/*  913 */     return ArrayType.construct(elementType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CollectionType constructCollectionType(Class<? extends Collection> collectionClass, Class<?> elementClass) {
/*  925 */     return constructCollectionType(collectionClass, 
/*  926 */         _fromClass(null, elementClass, EMPTY_BINDINGS));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CollectionType constructCollectionType(Class<? extends Collection> collectionClass, JavaType elementType) {
/*  939 */     TypeBindings bindings = TypeBindings.createIfNeeded(collectionClass, elementType);
/*  940 */     CollectionType result = (CollectionType)_fromClass(null, collectionClass, bindings);
/*      */ 
/*      */     
/*  943 */     if (bindings.isEmpty() && elementType != null) {
/*  944 */       JavaType t = result.findSuperType(Collection.class);
/*  945 */       JavaType realET = t.getContentType();
/*  946 */       if (!realET.equals(elementType))
/*  947 */         throw new IllegalArgumentException(String.format("Non-generic Collection class %s did not resolve to something with element type %s but %s ", new Object[] {
/*      */                 
/*  949 */                 ClassUtil.nameOf(collectionClass), elementType, realET
/*      */               })); 
/*      */     } 
/*  952 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CollectionLikeType constructCollectionLikeType(Class<?> collectionClass, Class<?> elementClass) {
/*  962 */     return constructCollectionLikeType(collectionClass, 
/*  963 */         _fromClass(null, elementClass, EMPTY_BINDINGS));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CollectionLikeType constructCollectionLikeType(Class<?> collectionClass, JavaType elementType) {
/*  973 */     JavaType type = _fromClass(null, collectionClass, 
/*  974 */         TypeBindings.createIfNeeded(collectionClass, elementType));
/*  975 */     if (type instanceof CollectionLikeType) {
/*  976 */       return (CollectionLikeType)type;
/*      */     }
/*  978 */     return CollectionLikeType.upgradeFrom(type, elementType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapType constructMapType(Class<? extends Map> mapClass, Class<?> keyClass, Class<?> valueClass) {
/*      */     JavaType kt;
/*      */     JavaType vt;
/*  991 */     if (mapClass == Properties.class) {
/*  992 */       kt = vt = CORE_TYPE_STRING;
/*      */     } else {
/*  994 */       kt = _fromClass(null, keyClass, EMPTY_BINDINGS);
/*  995 */       vt = _fromClass(null, valueClass, EMPTY_BINDINGS);
/*      */     } 
/*  997 */     return constructMapType(mapClass, kt, vt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapType constructMapType(Class<? extends Map> mapClass, JavaType keyType, JavaType valueType) {
/* 1007 */     TypeBindings bindings = TypeBindings.createIfNeeded(mapClass, new JavaType[] { keyType, valueType });
/* 1008 */     MapType result = (MapType)_fromClass(null, mapClass, bindings);
/*      */ 
/*      */     
/* 1011 */     if (bindings.isEmpty()) {
/* 1012 */       JavaType t = result.findSuperType(Map.class);
/* 1013 */       JavaType realKT = t.getKeyType();
/* 1014 */       if (!realKT.equals(keyType))
/* 1015 */         throw new IllegalArgumentException(String.format("Non-generic Map class %s did not resolve to something with key type %s but %s ", new Object[] {
/*      */                 
/* 1017 */                 ClassUtil.nameOf(mapClass), keyType, realKT
/*      */               })); 
/* 1019 */       JavaType realVT = t.getContentType();
/* 1020 */       if (!realVT.equals(valueType))
/* 1021 */         throw new IllegalArgumentException(String.format("Non-generic Map class %s did not resolve to something with value type %s but %s ", new Object[] {
/*      */                 
/* 1023 */                 ClassUtil.nameOf(mapClass), valueType, realVT
/*      */               })); 
/*      */     } 
/* 1026 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapLikeType constructMapLikeType(Class<?> mapClass, Class<?> keyClass, Class<?> valueClass) {
/* 1041 */     return constructMapLikeType(mapClass, 
/* 1042 */         _fromClass(null, keyClass, EMPTY_BINDINGS), 
/* 1043 */         _fromClass(null, valueClass, EMPTY_BINDINGS));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapLikeType constructMapLikeType(Class<?> mapClass, JavaType keyType, JavaType valueType) {
/* 1059 */     JavaType type = _fromClass(null, mapClass, 
/* 1060 */         TypeBindings.createIfNeeded(mapClass, new JavaType[] { keyType, valueType }));
/* 1061 */     if (type instanceof MapLikeType) {
/* 1062 */       return (MapLikeType)type;
/*      */     }
/* 1064 */     return MapLikeType.upgradeFrom(type, keyType, valueType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructSimpleType(Class<?> rawType, JavaType[] parameterTypes) {
/* 1073 */     return _fromClass(null, rawType, TypeBindings.create(rawType, parameterTypes));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType constructSimpleType(Class<?> rawType, Class<?> parameterTarget, JavaType[] parameterTypes) {
/* 1087 */     return constructSimpleType(rawType, parameterTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructReferenceType(Class<?> rawType, JavaType referredType) {
/* 1100 */     return ReferenceType.construct(rawType, 
/* 1101 */         TypeBindings.create(rawType, referredType), null, null, referredType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType uncheckedSimpleType(Class<?> cls) {
/* 1120 */     return _constructSimple(cls, EMPTY_BINDINGS, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructParametricType(Class<?> parametrized, Class<?>... parameterClasses) {
/* 1140 */     int len = parameterClasses.length;
/* 1141 */     JavaType[] pt = new JavaType[len];
/* 1142 */     for (int i = 0; i < len; i++) {
/* 1143 */       pt[i] = _fromClass(null, parameterClasses[i], EMPTY_BINDINGS);
/*      */     }
/* 1145 */     return constructParametricType(parametrized, pt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructParametricType(Class<?> rawType, JavaType... parameterTypes) {
/* 1166 */     return constructParametricType(rawType, TypeBindings.create(rawType, parameterTypes));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JavaType constructParametricType(Class<?> rawType, TypeBindings parameterTypes) {
/* 1190 */     JavaType resultType = _fromClass(null, rawType, parameterTypes);
/* 1191 */     return _applyModifiers(rawType, resultType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType constructParametrizedType(Class<?> parametrized, Class<?> parametersFor, JavaType... parameterTypes) {
/* 1202 */     return constructParametricType(parametrized, parameterTypes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JavaType constructParametrizedType(Class<?> parametrized, Class<?> parametersFor, Class<?>... parameterClasses) {
/* 1213 */     return constructParametricType(parametrized, parameterClasses);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CollectionType constructRawCollectionType(Class<? extends Collection> collectionClass) {
/* 1236 */     return constructCollectionType(collectionClass, unknownType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CollectionLikeType constructRawCollectionLikeType(Class<?> collectionClass) {
/* 1251 */     return constructCollectionLikeType(collectionClass, unknownType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapType constructRawMapType(Class<? extends Map> mapClass) {
/* 1267 */     return constructMapType(mapClass, unknownType(), unknownType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MapLikeType constructRawMapLikeType(Class<?> mapClass) {
/* 1282 */     return constructMapLikeType(mapClass, unknownType(), unknownType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JavaType _mapType(Class<?> rawClass, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/*      */     JavaType kt;
/*      */     JavaType vt;
/* 1297 */     if (rawClass == Properties.class)
/* 1298 */     { kt = vt = CORE_TYPE_STRING; }
/*      */     else
/* 1300 */     { List<JavaType> typeParams = bindings.getTypeParameters();
/*      */       
/* 1302 */       int pc = typeParams.size();
/* 1303 */       switch (pc)
/*      */       { case 0:
/* 1305 */           kt = vt = _unknownType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1317 */           return MapType.construct(rawClass, bindings, superClass, superInterfaces, kt, vt);case 2: kt = typeParams.get(0); vt = typeParams.get(1); return MapType.construct(rawClass, bindings, superClass, superInterfaces, kt, vt); }  throw new IllegalArgumentException(String.format("Strange Map type %s with %d type parameter%s (%s), can not resolve", new Object[] { ClassUtil.nameOf(rawClass), Integer.valueOf(pc), (pc == 1) ? "" : "s", bindings })); }  return MapType.construct(rawClass, bindings, superClass, superInterfaces, kt, vt);
/*      */   }
/*      */ 
/*      */   
/*      */   private JavaType _collectionType(Class<?> rawClass, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/*      */     JavaType ct;
/* 1323 */     List<JavaType> typeParams = bindings.getTypeParameters();
/*      */ 
/*      */     
/* 1326 */     if (typeParams.isEmpty()) {
/* 1327 */       ct = _unknownType();
/* 1328 */     } else if (typeParams.size() == 1) {
/* 1329 */       ct = typeParams.get(0);
/*      */     } else {
/* 1331 */       throw new IllegalArgumentException("Strange Collection type " + rawClass.getName() + ": cannot determine type parameters");
/*      */     } 
/* 1333 */     return CollectionType.construct(rawClass, bindings, superClass, superInterfaces, ct);
/*      */   }
/*      */ 
/*      */   
/*      */   private JavaType _referenceType(Class<?> rawClass, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/*      */     JavaType ct;
/* 1339 */     List<JavaType> typeParams = bindings.getTypeParameters();
/*      */ 
/*      */     
/* 1342 */     if (typeParams.isEmpty()) {
/* 1343 */       ct = _unknownType();
/* 1344 */     } else if (typeParams.size() == 1) {
/* 1345 */       ct = typeParams.get(0);
/*      */     } else {
/* 1347 */       throw new IllegalArgumentException("Strange Reference type " + rawClass.getName() + ": cannot determine type parameters");
/*      */     } 
/* 1349 */     return ReferenceType.construct(rawClass, bindings, superClass, superInterfaces, ct);
/*      */   }
/*      */ 
/*      */   
/*      */   private JavaType _iterationType(Class<?> rawClass, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/*      */     JavaType ct;
/* 1355 */     List<JavaType> typeParams = bindings.getTypeParameters();
/*      */ 
/*      */     
/* 1358 */     if (typeParams.isEmpty()) {
/* 1359 */       ct = _unknownType();
/* 1360 */     } else if (typeParams.size() == 1) {
/* 1361 */       ct = typeParams.get(0);
/*      */     } else {
/* 1363 */       throw new IllegalArgumentException("Strange Iteration type " + rawClass.getName() + ": cannot determine type parameters");
/*      */     } 
/* 1365 */     return _iterationType(rawClass, bindings, superClass, superInterfaces, ct);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JavaType _iterationType(Class<?> rawClass, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces, JavaType iteratedType) {
/* 1372 */     return IterationType.construct(rawClass, bindings, superClass, superInterfaces, iteratedType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _constructSimple(Class<?> raw, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/* 1387 */     if (bindings.isEmpty()) {
/* 1388 */       JavaType result = _findWellKnownSimple(raw);
/* 1389 */       if (result != null) {
/* 1390 */         return result;
/*      */       }
/*      */     } 
/* 1393 */     return _newSimpleType(raw, bindings, superClass, superInterfaces);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _newSimpleType(Class<?> raw, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/* 1406 */     return new SimpleType(raw, bindings, superClass, superInterfaces);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _unknownType() {
/* 1414 */     return CORE_TYPE_OBJECT;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _findWellKnownSimple(Class<?> clz) {
/* 1425 */     if (clz.isPrimitive()) {
/* 1426 */       if (clz == CLS_BOOL) return CORE_TYPE_BOOL; 
/* 1427 */       if (clz == CLS_INT) return CORE_TYPE_INT; 
/* 1428 */       if (clz == CLS_LONG) return CORE_TYPE_LONG; 
/* 1429 */       if (clz == CLS_DOUBLE) return CORE_TYPE_DOUBLE; 
/*      */     } else {
/* 1431 */       if (clz == CLS_STRING) return CORE_TYPE_STRING; 
/* 1432 */       if (clz == CLS_OBJECT) return CORE_TYPE_OBJECT; 
/* 1433 */       if (clz == CLS_JSON_NODE) return CORE_TYPE_JSON_NODE; 
/*      */     } 
/* 1435 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _fromAny(ClassStack context, Type srcType, TypeBindings bindings) {
/*      */     JavaType resultType;
/* 1454 */     if (srcType instanceof Class) {
/*      */       
/* 1456 */       resultType = _fromClass(context, (Class)srcType, EMPTY_BINDINGS);
/*      */     
/*      */     }
/* 1459 */     else if (srcType instanceof ParameterizedType) {
/* 1460 */       resultType = _fromParamType(context, (ParameterizedType)srcType, bindings);
/*      */     } else {
/* 1462 */       if (srcType instanceof JavaType)
/*      */       {
/* 1464 */         return (JavaType)srcType;
/*      */       }
/* 1466 */       if (srcType instanceof GenericArrayType) {
/* 1467 */         resultType = _fromArrayType(context, (GenericArrayType)srcType, bindings);
/*      */       }
/* 1469 */       else if (srcType instanceof TypeVariable) {
/* 1470 */         resultType = _fromVariable(context, (TypeVariable)srcType, bindings);
/*      */       }
/* 1472 */       else if (srcType instanceof WildcardType) {
/* 1473 */         resultType = _fromWildcard(context, (WildcardType)srcType, bindings);
/*      */       } else {
/*      */         
/* 1476 */         throw new IllegalArgumentException("Unrecognized Type: " + ((srcType == null) ? "[null]" : srcType.toString()));
/*      */       } 
/*      */     } 
/*      */     
/* 1480 */     return _applyModifiers(srcType, resultType);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JavaType _applyModifiers(Type srcType, JavaType resolvedType) {
/* 1485 */     if (this._modifiers == null) {
/* 1486 */       return resolvedType;
/*      */     }
/* 1488 */     JavaType resultType = resolvedType;
/* 1489 */     TypeBindings b = resultType.getBindings();
/* 1490 */     if (b == null) {
/* 1491 */       b = EMPTY_BINDINGS;
/*      */     }
/* 1493 */     for (TypeModifier mod : this._modifiers) {
/* 1494 */       JavaType t = mod.modifyType(resultType, srcType, b, this);
/* 1495 */       if (t == null) {
/* 1496 */         throw new IllegalStateException(String.format("TypeModifier %s (of type %s) return null for type %s", new Object[] { mod, mod
/*      */                 
/* 1498 */                 .getClass().getName(), resultType }));
/*      */       }
/* 1500 */       resultType = t;
/*      */     } 
/* 1502 */     return resultType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _fromClass(ClassStack context, Class<?> rawType, TypeBindings bindings) {
/*      */     Object key;
/* 1512 */     JavaType result = _findWellKnownSimple(rawType);
/* 1513 */     if (result != null) {
/* 1514 */       return result;
/*      */     }
/*      */ 
/*      */     
/* 1518 */     if (bindings == null || bindings.isEmpty()) {
/* 1519 */       key = rawType;
/*      */     } else {
/* 1521 */       key = bindings.asKey(rawType);
/*      */     } 
/* 1523 */     result = (key == null) ? null : (JavaType)this._typeCache.get(key);
/* 1524 */     if (result != null) {
/* 1525 */       return result;
/*      */     }
/*      */ 
/*      */     
/* 1529 */     if (context == null) {
/* 1530 */       context = new ClassStack(rawType);
/*      */     } else {
/* 1532 */       ClassStack prev = context.find(rawType);
/* 1533 */       if (prev != null) {
/*      */         
/* 1535 */         ResolvedRecursiveType selfRef = new ResolvedRecursiveType(rawType, EMPTY_BINDINGS);
/* 1536 */         prev.addSelfReference(selfRef);
/* 1537 */         return selfRef;
/*      */       } 
/*      */       
/* 1540 */       context = context.child(rawType);
/*      */     } 
/*      */ 
/*      */     
/* 1544 */     if (rawType.isArray()) {
/* 1545 */       result = ArrayType.construct(_fromAny(context, rawType.getComponentType(), bindings), bindings);
/*      */     } else {
/*      */       JavaType superClass;
/*      */ 
/*      */       
/*      */       JavaType[] superInterfaces;
/*      */ 
/*      */       
/* 1553 */       if (rawType.isInterface()) {
/* 1554 */         superClass = null;
/* 1555 */         superInterfaces = _resolveSuperInterfaces(context, rawType, bindings);
/*      */       } else {
/*      */         
/* 1558 */         superClass = _resolveSuperClass(context, rawType, bindings);
/* 1559 */         superInterfaces = _resolveSuperInterfaces(context, rawType, bindings);
/*      */       } 
/*      */ 
/*      */       
/* 1563 */       if (rawType == Properties.class) {
/* 1564 */         result = MapType.construct(rawType, bindings, superClass, superInterfaces, CORE_TYPE_STRING, CORE_TYPE_STRING);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1569 */       else if (superClass != null) {
/* 1570 */         result = superClass.refine(rawType, bindings, superClass, superInterfaces);
/*      */       } 
/*      */       
/* 1573 */       if (result == null) {
/* 1574 */         result = _fromWellKnownClass(context, rawType, bindings, superClass, superInterfaces);
/* 1575 */         if (result == null) {
/* 1576 */           result = _fromWellKnownInterface(context, rawType, bindings, superClass, superInterfaces);
/* 1577 */           if (result == null)
/*      */           {
/* 1579 */             result = _newSimpleType(rawType, bindings, superClass, superInterfaces);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 1584 */     context.resolveSelfReferences(result);
/*      */ 
/*      */     
/* 1587 */     if (key != null && !result.hasHandlers()) {
/* 1588 */       this._typeCache.putIfAbsent(key, result);
/*      */     }
/* 1590 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JavaType _resolveSuperClass(ClassStack context, Class<?> rawType, TypeBindings parentBindings) {
/* 1595 */     Type parent = ClassUtil.getGenericSuperclass(rawType);
/* 1596 */     if (parent == null) {
/* 1597 */       return null;
/*      */     }
/* 1599 */     return _fromAny(context, parent, parentBindings);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JavaType[] _resolveSuperInterfaces(ClassStack context, Class<?> rawType, TypeBindings parentBindings) {
/* 1604 */     Type[] types = ClassUtil.getGenericInterfaces(rawType);
/* 1605 */     if (types == null || types.length == 0) {
/* 1606 */       return NO_TYPES;
/*      */     }
/* 1608 */     int len = types.length;
/* 1609 */     JavaType[] resolved = new JavaType[len];
/* 1610 */     for (int i = 0; i < len; i++) {
/* 1611 */       Type type = types[i];
/* 1612 */       resolved[i] = _fromAny(context, type, parentBindings);
/*      */     } 
/* 1614 */     return resolved;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _fromWellKnownClass(ClassStack context, Class<?> rawType, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/* 1625 */     if (bindings == null) {
/* 1626 */       bindings = EMPTY_BINDINGS;
/*      */     }
/*      */     
/* 1629 */     if (rawType == Map.class) {
/* 1630 */       return _mapType(rawType, bindings, superClass, superInterfaces);
/*      */     }
/* 1632 */     if (rawType == Collection.class) {
/* 1633 */       return _collectionType(rawType, bindings, superClass, superInterfaces);
/*      */     }
/*      */     
/* 1636 */     if (rawType == AtomicReference.class) {
/* 1637 */       return _referenceType(rawType, bindings, superClass, superInterfaces);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1644 */     if (rawType == Iterator.class || rawType == Stream.class)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1651 */       return _iterationType(rawType, bindings, superClass, superInterfaces);
/*      */     }
/* 1653 */     if (BaseStream.class.isAssignableFrom(rawType)) {
/* 1654 */       if (DoubleStream.class.isAssignableFrom(rawType)) {
/* 1655 */         return _iterationType(rawType, bindings, superClass, superInterfaces, CORE_TYPE_DOUBLE);
/*      */       }
/* 1657 */       if (IntStream.class.isAssignableFrom(rawType)) {
/* 1658 */         return _iterationType(rawType, bindings, superClass, superInterfaces, CORE_TYPE_INT);
/*      */       }
/* 1660 */       if (LongStream.class.isAssignableFrom(rawType)) {
/* 1661 */         return _iterationType(rawType, bindings, superClass, superInterfaces, CORE_TYPE_LONG);
/*      */       }
/*      */     } 
/*      */     
/* 1665 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _fromWellKnownInterface(ClassStack context, Class<?> rawType, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/* 1673 */     int intCount = superInterfaces.length;
/*      */     
/* 1675 */     for (int i = 0; i < intCount; i++) {
/* 1676 */       JavaType result = superInterfaces[i].refine(rawType, bindings, superClass, superInterfaces);
/* 1677 */       if (result != null) {
/* 1678 */         return result;
/*      */       }
/*      */     } 
/* 1681 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _fromParamType(ClassStack context, ParameterizedType ptype, TypeBindings parentBindings) {
/*      */     TypeBindings newBindings;
/* 1692 */     Class<?> rawType = (Class)ptype.getRawType();
/*      */ 
/*      */ 
/*      */     
/* 1696 */     if (rawType == CLS_ENUM) {
/* 1697 */       return CORE_TYPE_ENUM;
/*      */     }
/* 1699 */     if (rawType == CLS_COMPARABLE) {
/* 1700 */       return CORE_TYPE_COMPARABLE;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1706 */     Type[] args = ptype.getActualTypeArguments();
/* 1707 */     int paramCount = (args == null) ? 0 : args.length;
/*      */ 
/*      */     
/* 1710 */     if (paramCount == 0) {
/* 1711 */       newBindings = EMPTY_BINDINGS;
/*      */     } else {
/* 1713 */       JavaType[] pt = new JavaType[paramCount];
/* 1714 */       for (int i = 0; i < paramCount; i++) {
/* 1715 */         pt[i] = _fromAny(context, args[i], parentBindings);
/*      */       }
/* 1717 */       newBindings = TypeBindings.create(rawType, pt);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1735 */     return _fromClass(context, rawType, newBindings);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JavaType _fromArrayType(ClassStack context, GenericArrayType type, TypeBindings bindings) {
/* 1740 */     JavaType elementType = _fromAny(context, type.getGenericComponentType(), bindings);
/* 1741 */     return ArrayType.construct(elementType, bindings);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JavaType _fromVariable(ClassStack context, TypeVariable<?> var, TypeBindings bindings) {
/*      */     Type[] bounds;
/* 1747 */     String name = var.getName();
/* 1748 */     if (bindings == null) {
/* 1749 */       throw new IllegalArgumentException("Null `bindings` passed (type variable \"" + name + "\")");
/*      */     }
/* 1751 */     JavaType type = bindings.findBoundType(name);
/* 1752 */     if (type != null) {
/* 1753 */       return type;
/*      */     }
/*      */ 
/*      */     
/* 1757 */     if (bindings.hasUnbound(name)) {
/* 1758 */       return CORE_TYPE_OBJECT;
/*      */     }
/* 1760 */     bindings = bindings.withUnboundVariable(name);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1771 */     synchronized (var) {
/* 1772 */       bounds = var.getBounds();
/*      */     } 
/* 1774 */     return _fromAny(context, bounds[0], bindings);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JavaType _fromWildcard(ClassStack context, WildcardType type, TypeBindings bindings) {
/* 1784 */     return _fromAny(context, type.getUpperBounds()[0], bindings);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\type\TypeFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */