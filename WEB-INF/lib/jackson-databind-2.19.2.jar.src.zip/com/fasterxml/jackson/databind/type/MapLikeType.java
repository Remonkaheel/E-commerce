/*     */ package com.fasterxml.jackson.databind.type;
/*     */ 
/*     */ import com.fasterxml.jackson.core.type.ResolvedType;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapLikeType
/*     */   extends TypeBase
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JavaType _keyType;
/*     */   protected final JavaType _valueType;
/*     */   
/*     */   protected MapLikeType(Class<?> mapType, TypeBindings bindings, JavaType superClass, JavaType[] superInts, JavaType keyT, JavaType valueT, Object valueHandler, Object typeHandler, boolean asStatic) {
/*  39 */     super(mapType, bindings, superClass, superInts, 31 * keyT
/*  40 */         .hashCode() + valueT.hashCode(), valueHandler, typeHandler, asStatic);
/*     */     
/*  42 */     this._keyType = keyT;
/*  43 */     this._valueType = valueT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MapLikeType(TypeBase base, JavaType keyT, JavaType valueT) {
/*  50 */     super(base);
/*  51 */     this._keyType = keyT;
/*  52 */     this._valueType = valueT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MapLikeType upgradeFrom(JavaType baseType, JavaType keyT, JavaType valueT) {
/*  66 */     if (baseType instanceof TypeBase) {
/*  67 */       return new MapLikeType((TypeBase)baseType, keyT, valueT);
/*     */     }
/*  69 */     throw new IllegalArgumentException("Cannot upgrade from an instance of " + baseType
/*  70 */         .getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static MapLikeType construct(Class<?> rawType, JavaType keyT, JavaType valueT) {
/*     */     TypeBindings bindings;
/*  79 */     TypeVariable[] arrayOfTypeVariable = (TypeVariable[])rawType.getTypeParameters();
/*     */     
/*  81 */     if (arrayOfTypeVariable == null || arrayOfTypeVariable.length != 2) {
/*  82 */       bindings = TypeBindings.emptyBindings();
/*     */     } else {
/*  84 */       bindings = TypeBindings.create(rawType, keyT, valueT);
/*     */     } 
/*  86 */     return new MapLikeType(rawType, bindings, _bogusSuperClass(rawType), null, keyT, valueT, null, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapLikeType withKeyType(JavaType keyType) {
/*  94 */     if (keyType == this._keyType) {
/*  95 */       return this;
/*     */     }
/*  97 */     return new MapLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, keyType, this._valueType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType withContentType(JavaType contentType) {
/* 104 */     if (this._valueType == contentType) {
/* 105 */       return this;
/*     */     }
/* 107 */     return new MapLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._keyType, contentType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapLikeType withTypeHandler(Object h) {
/* 114 */     return new MapLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._keyType, this._valueType, this._valueHandler, h, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapLikeType withContentTypeHandler(Object h) {
/* 121 */     return new MapLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._keyType, this._valueType
/* 122 */         .withTypeHandler(h), this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MapLikeType withValueHandler(Object h) {
/* 128 */     return new MapLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._keyType, this._valueType, h, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapLikeType withContentValueHandler(Object h) {
/* 135 */     return new MapLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._keyType, this._valueType
/* 136 */         .withValueHandler(h), this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType withHandlersFrom(JavaType src) {
/* 142 */     JavaType type = super.withHandlersFrom(src);
/* 143 */     JavaType srcKeyType = src.getKeyType();
/*     */     
/* 145 */     if (type instanceof MapLikeType && 
/* 146 */       srcKeyType != null) {
/* 147 */       JavaType ct = this._keyType.withHandlersFrom(srcKeyType);
/* 148 */       if (ct != this._keyType) {
/* 149 */         type = ((MapLikeType)type).withKeyType(ct);
/*     */       }
/*     */     } 
/*     */     
/* 153 */     JavaType srcCt = src.getContentType();
/* 154 */     if (srcCt != null) {
/* 155 */       JavaType ct = this._valueType.withHandlersFrom(srcCt);
/* 156 */       if (ct != this._valueType) {
/* 157 */         type = type.withContentType(ct);
/*     */       }
/*     */     } 
/* 160 */     return type;
/*     */   }
/*     */ 
/*     */   
/*     */   public MapLikeType withStaticTyping() {
/* 165 */     if (this._asStatic) {
/* 166 */       return this;
/*     */     }
/* 168 */     return new MapLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._keyType, this._valueType
/* 169 */         .withStaticTyping(), this._valueHandler, this._typeHandler, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType refine(Class<?> rawType, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/* 176 */     return new MapLikeType(rawType, bindings, superClass, superInterfaces, this._keyType, this._valueType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String buildCanonicalName() {
/* 182 */     StringBuilder sb = new StringBuilder();
/* 183 */     sb.append(this._class.getName());
/*     */ 
/*     */     
/* 186 */     if (this._keyType != null && _hasNTypeParameters(2)) {
/* 187 */       sb.append('<');
/* 188 */       sb.append(this._keyType.toCanonical());
/* 189 */       sb.append(',');
/* 190 */       sb.append(this._valueType.toCanonical());
/* 191 */       sb.append('>');
/*     */     } 
/* 193 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isContainerType() {
/* 204 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMapLikeType() {
/* 209 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType getKeyType() {
/* 214 */     return this._keyType;
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType getContentType() {
/* 219 */     return this._valueType;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getContentValueHandler() {
/* 224 */     return this._valueType.getValueHandler();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getContentTypeHandler() {
/* 229 */     return this._valueType.getTypeHandler();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasHandlers() {
/* 234 */     return (super.hasHandlers() || this._valueType.hasHandlers() || this._keyType
/* 235 */       .hasHandlers());
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder getErasedSignature(StringBuilder sb) {
/* 240 */     return _classSignature(this._class, sb, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder getGenericSignature(StringBuilder sb) {
/* 245 */     _classSignature(this._class, sb, false);
/* 246 */     sb.append('<');
/* 247 */     this._keyType.getGenericSignature(sb);
/* 248 */     this._valueType.getGenericSignature(sb);
/* 249 */     sb.append(">;");
/* 250 */     return sb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapLikeType withKeyTypeHandler(Object h) {
/* 260 */     return new MapLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._keyType
/* 261 */         .withTypeHandler(h), this._valueType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */   
/*     */   public MapLikeType withKeyValueHandler(Object h) {
/* 266 */     return new MapLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._keyType
/* 267 */         .withValueHandler(h), this._valueType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean isTrueMapType() {
/* 280 */     return Map.class.isAssignableFrom(this._class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 291 */     return String.format("[map-like type; class %s, %s -> %s]", new Object[] { this._class
/* 292 */           .getName(), this._keyType, this._valueType });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 297 */     if (o == this) return true; 
/* 298 */     if (o == null) return false; 
/* 299 */     if (o.getClass() != getClass()) return false;
/*     */     
/* 301 */     MapLikeType other = (MapLikeType)o;
/* 302 */     return (this._class == other._class && this._keyType.equals(other._keyType) && this._valueType
/* 303 */       .equals(other._valueType));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\type\MapLikeType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */