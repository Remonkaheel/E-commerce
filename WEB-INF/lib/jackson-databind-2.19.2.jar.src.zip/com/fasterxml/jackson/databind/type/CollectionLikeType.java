/*     */ package com.fasterxml.jackson.databind.type;
/*     */ 
/*     */ import com.fasterxml.jackson.core.type.ResolvedType;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CollectionLikeType
/*     */   extends TypeBase
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected final JavaType _elementType;
/*     */   
/*     */   protected CollectionLikeType(Class<?> collT, TypeBindings bindings, JavaType superClass, JavaType[] superInts, JavaType elemT, Object valueHandler, Object typeHandler, boolean asStatic) {
/*  34 */     super(collT, bindings, superClass, superInts, elemT
/*  35 */         .hashCode(), valueHandler, typeHandler, asStatic);
/*  36 */     this._elementType = elemT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CollectionLikeType(TypeBase base, JavaType elemT) {
/*  44 */     super(base);
/*  45 */     this._elementType = elemT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CollectionLikeType construct(Class<?> rawType, TypeBindings bindings, JavaType superClass, JavaType[] superInts, JavaType elemT) {
/*  53 */     return new CollectionLikeType(rawType, bindings, superClass, superInts, elemT, null, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static CollectionLikeType construct(Class<?> rawType, JavaType elemT) {
/*     */     TypeBindings bindings;
/*  65 */     TypeVariable[] arrayOfTypeVariable = (TypeVariable[])rawType.getTypeParameters();
/*     */     
/*  67 */     if (arrayOfTypeVariable == null || arrayOfTypeVariable.length != 1) {
/*  68 */       bindings = TypeBindings.emptyBindings();
/*     */     } else {
/*  70 */       bindings = TypeBindings.create(rawType, elemT);
/*     */     } 
/*  72 */     return new CollectionLikeType(rawType, bindings, 
/*  73 */         _bogusSuperClass(rawType), null, elemT, null, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CollectionLikeType upgradeFrom(JavaType baseType, JavaType elementType) {
/*  86 */     if (baseType instanceof TypeBase) {
/*  87 */       return new CollectionLikeType((TypeBase)baseType, elementType);
/*     */     }
/*  89 */     throw new IllegalArgumentException("Cannot upgrade from an instance of " + baseType.getClass());
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType withContentType(JavaType contentType) {
/*  94 */     if (this._elementType == contentType) {
/*  95 */       return this;
/*     */     }
/*  97 */     return new CollectionLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, contentType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionLikeType withTypeHandler(Object h) {
/* 103 */     return new CollectionLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._elementType, this._valueHandler, h, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionLikeType withContentTypeHandler(Object h) {
/* 110 */     return new CollectionLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._elementType
/* 111 */         .withTypeHandler(h), this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionLikeType withValueHandler(Object h) {
/* 117 */     return new CollectionLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._elementType, h, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public CollectionLikeType withContentValueHandler(Object h) {
/* 123 */     return new CollectionLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._elementType
/* 124 */         .withValueHandler(h), this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType withHandlersFrom(JavaType src) {
/* 130 */     JavaType type = super.withHandlersFrom(src);
/* 131 */     JavaType srcCt = src.getContentType();
/* 132 */     if (srcCt != null) {
/* 133 */       JavaType ct = this._elementType.withHandlersFrom(srcCt);
/* 134 */       if (ct != this._elementType) {
/* 135 */         type = type.withContentType(ct);
/*     */       }
/*     */     } 
/* 138 */     return type;
/*     */   }
/*     */ 
/*     */   
/*     */   public CollectionLikeType withStaticTyping() {
/* 143 */     if (this._asStatic) {
/* 144 */       return this;
/*     */     }
/* 146 */     return new CollectionLikeType(this._class, this._bindings, this._superClass, this._superInterfaces, this._elementType
/* 147 */         .withStaticTyping(), this._valueHandler, this._typeHandler, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType refine(Class<?> rawType, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/* 154 */     return new CollectionLikeType(rawType, bindings, superClass, superInterfaces, this._elementType, this._valueHandler, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isContainerType() {
/* 166 */     return true;
/*     */   }
/*     */   public boolean isCollectionLikeType() {
/* 169 */     return true;
/*     */   }
/*     */   public JavaType getContentType() {
/* 172 */     return this._elementType;
/*     */   }
/*     */   
/*     */   public Object getContentValueHandler() {
/* 176 */     return this._elementType.getValueHandler();
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getContentTypeHandler() {
/* 181 */     return this._elementType.getTypeHandler();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasHandlers() {
/* 186 */     return (super.hasHandlers() || this._elementType.hasHandlers());
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder getErasedSignature(StringBuilder sb) {
/* 191 */     return _classSignature(this._class, sb, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public StringBuilder getGenericSignature(StringBuilder sb) {
/* 196 */     _classSignature(this._class, sb, false);
/* 197 */     sb.append('<');
/* 198 */     this._elementType.getGenericSignature(sb);
/* 199 */     sb.append(">;");
/* 200 */     return sb;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String buildCanonicalName() {
/* 205 */     StringBuilder sb = new StringBuilder();
/* 206 */     sb.append(this._class.getName());
/*     */ 
/*     */     
/* 209 */     if (this._elementType != null && _hasNTypeParameters(1)) {
/* 210 */       sb.append('<');
/* 211 */       sb.append(this._elementType.toCanonical());
/* 212 */       sb.append('>');
/*     */     } 
/* 214 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean isTrueCollectionType() {
/* 233 */     return Collection.class.isAssignableFrom(this._class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 245 */     if (o == this) return true; 
/* 246 */     if (o == null) return false; 
/* 247 */     if (o.getClass() != getClass()) return false;
/*     */     
/* 249 */     CollectionLikeType other = (CollectionLikeType)o;
/* 250 */     return (this._class == other._class && this._elementType.equals(other._elementType));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 256 */     return "[collection-like type; class " + this._class.getName() + ", contains " + this._elementType + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\type\CollectionLikeType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */