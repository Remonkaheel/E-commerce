/*     */ package com.fasterxml.jackson.databind.type;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleType
/*     */   extends TypeBase
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */   protected SimpleType(Class<?> cls) {
/*  33 */     this(cls, TypeBindings.emptyBindings(), (JavaType)null, (JavaType[])null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected SimpleType(Class<?> cls, TypeBindings bindings, JavaType superClass, JavaType[] superInts) {
/*  38 */     this(cls, bindings, superClass, superInts, (Object)null, (Object)null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SimpleType(TypeBase base) {
/*  48 */     super(base);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SimpleType(Class<?> cls, TypeBindings bindings, JavaType superClass, JavaType[] superInts, Object valueHandler, Object typeHandler, boolean asStatic) {
/*  55 */     super(cls, bindings, superClass, superInts, ((bindings == null) ? 
/*     */ 
/*     */ 
/*     */         
/*  59 */         TypeBindings.emptyBindings() : bindings).hashCode(), valueHandler, typeHandler, asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SimpleType(Class<?> cls, TypeBindings bindings, JavaType superClass, JavaType[] superInts, int extraHash, Object valueHandler, Object typeHandler, boolean asStatic) {
/*  72 */     super(cls, bindings, superClass, superInts, extraHash, valueHandler, typeHandler, asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SimpleType constructUnsafe(Class<?> raw) {
/*  86 */     return new SimpleType(raw, null, null, null, null, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static SimpleType construct(Class<?> cls) {
/* 110 */     if (Map.class.isAssignableFrom(cls)) {
/* 111 */       throw new IllegalArgumentException("Cannot construct SimpleType for a Map (class: " + cls.getName() + ")");
/*     */     }
/* 113 */     if (Collection.class.isAssignableFrom(cls)) {
/* 114 */       throw new IllegalArgumentException("Cannot construct SimpleType for a Collection (class: " + cls.getName() + ")");
/*     */     }
/*     */     
/* 117 */     if (cls.isArray()) {
/* 118 */       throw new IllegalArgumentException("Cannot construct SimpleType for an array (class: " + cls.getName() + ")");
/*     */     }
/* 120 */     TypeBindings b = TypeBindings.emptyBindings();
/* 121 */     return new SimpleType(cls, b, 
/* 122 */         _buildSuperClass(cls.getSuperclass(), b), null, null, null, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType withContentType(JavaType contentType) {
/* 127 */     throw new IllegalArgumentException("Simple types have no content types; cannot call withContentType()");
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleType withTypeHandler(Object h) {
/* 132 */     if (this._typeHandler == h) {
/* 133 */       return this;
/*     */     }
/* 135 */     return new SimpleType(this._class, this._bindings, this._superClass, this._superInterfaces, this._valueHandler, h, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType withContentTypeHandler(Object h) {
/* 141 */     throw new IllegalArgumentException("Simple types have no content types; cannot call withContenTypeHandler()");
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleType withValueHandler(Object h) {
/* 146 */     if (h == this._valueHandler) {
/* 147 */       return this;
/*     */     }
/* 149 */     return new SimpleType(this._class, this._bindings, this._superClass, this._superInterfaces, h, this._typeHandler, this._asStatic);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SimpleType withContentValueHandler(Object h) {
/* 155 */     throw new IllegalArgumentException("Simple types have no content types; cannot call withContenValueHandler()");
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleType withStaticTyping() {
/* 160 */     return this._asStatic ? this : new SimpleType(this._class, this._bindings, this._superClass, this._superInterfaces, this._valueHandler, this._typeHandler, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JavaType refine(Class<?> rawType, TypeBindings bindings, JavaType superClass, JavaType[] superInterfaces) {
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String buildCanonicalName() {
/* 174 */     StringBuilder sb = new StringBuilder();
/* 175 */     sb.append(this._class.getName());
/*     */     
/* 177 */     int count = this._bindings.size();
/*     */ 
/*     */ 
/*     */     
/* 181 */     if (count > 0 && _hasNTypeParameters(count)) {
/* 182 */       sb.append('<');
/* 183 */       for (int i = 0; i < count; i++) {
/* 184 */         JavaType t = containedType(i);
/* 185 */         if (i > 0) {
/* 186 */           sb.append(',');
/*     */         }
/* 188 */         sb.append(t.toCanonical());
/*     */       } 
/* 190 */       sb.append('>');
/*     */     } 
/* 192 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isContainerType() {
/* 202 */     return false;
/*     */   }
/*     */   public boolean hasContentType() {
/* 205 */     return false;
/*     */   }
/*     */   
/*     */   public StringBuilder getErasedSignature(StringBuilder sb) {
/* 209 */     return _classSignature(this._class, sb, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder getGenericSignature(StringBuilder sb) {
/* 215 */     _classSignature(this._class, sb, false);
/*     */     
/* 217 */     int count = this._bindings.size();
/* 218 */     if (count > 0) {
/* 219 */       sb.append('<');
/* 220 */       for (int i = 0; i < count; i++) {
/* 221 */         sb = containedType(i).getGenericSignature(sb);
/*     */       }
/* 223 */       sb.append('>');
/*     */     } 
/* 225 */     sb.append(';');
/* 226 */     return sb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static JavaType _buildSuperClass(Class<?> superClass, TypeBindings b) {
/* 243 */     if (superClass == null) {
/* 244 */       return null;
/*     */     }
/* 246 */     if (superClass == Object.class) {
/* 247 */       return TypeFactory.unknownType();
/*     */     }
/* 249 */     JavaType superSuper = _buildSuperClass(superClass.getSuperclass(), b);
/* 250 */     return new SimpleType(superClass, b, superSuper, null, null, null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 263 */     StringBuilder sb = new StringBuilder(40);
/* 264 */     sb.append("[simple type, class ").append(buildCanonicalName()).append(']');
/* 265 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 271 */     if (o == this) return true; 
/* 272 */     if (o == null) return false; 
/* 273 */     if (o.getClass() != getClass()) return false;
/*     */     
/* 275 */     SimpleType other = (SimpleType)o;
/*     */ 
/*     */     
/* 278 */     if (other._class != this._class) return false;
/*     */ 
/*     */     
/* 281 */     TypeBindings b1 = this._bindings;
/* 282 */     TypeBindings b2 = other._bindings;
/* 283 */     return b1.equals(b2);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\type\SimpleType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */