/*    */ package com.fasterxml.jackson.databind.ext;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ import java.nio.file.Path;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Java7HandlersImpl
/*    */   extends Java7Handlers
/*    */ {
/* 20 */   private final Class<?> _pathClass = Path.class;
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getClassJavaNioFilePath() {
/* 25 */     return this._pathClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public JsonDeserializer<?> getDeserializerForJavaNioFilePath(Class<?> rawType) {
/* 30 */     if (rawType == this._pathClass) {
/* 31 */       return (JsonDeserializer<?>)new NioPathDeserializer();
/*    */     }
/* 33 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public JsonSerializer<?> getSerializerForJavaNioFilePath(Class<?> rawType) {
/* 38 */     if (this._pathClass.isAssignableFrom(rawType)) {
/* 39 */       return (JsonSerializer<?>)new NioPathSerializer();
/*    */     }
/* 41 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ext\Java7HandlersImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */