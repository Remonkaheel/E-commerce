/*    */ package com.fasterxml.jackson.databind.ext;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.deser.std.FromStringDeserializer;
/*    */ import java.io.StringReader;
/*    */ import javax.xml.parsers.DocumentBuilder;
/*    */ import javax.xml.parsers.DocumentBuilderFactory;
/*    */ import javax.xml.parsers.ParserConfigurationException;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Node;
/*    */ import org.xml.sax.InputSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DOMDeserializer<T>
/*    */   extends FromStringDeserializer<T>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final DocumentBuilderFactory DEFAULT_PARSER_FACTORY;
/*    */   
/*    */   static {
/* 27 */     DocumentBuilderFactory parserFactory = DocumentBuilderFactory.newInstance();
/*    */     
/* 29 */     parserFactory.setNamespaceAware(true);
/*    */     
/* 31 */     parserFactory.setExpandEntityReferences(false);
/*    */     
/*    */     try {
/* 34 */       parserFactory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
/* 35 */     } catch (ParserConfigurationException parserConfigurationException) {}
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 41 */       parserFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
/* 42 */     } catch (Exception exception) {}
/*    */     try {
/* 44 */       parserFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
/* 45 */     } catch (Exception exception) {}
/* 46 */     DEFAULT_PARSER_FACTORY = parserFactory;
/*    */   }
/*    */   protected DOMDeserializer(Class<T> cls) {
/* 49 */     super(cls);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected final Document parse(String value) throws IllegalArgumentException {
/*    */     try {
/* 56 */       return documentBuilder().parse(new InputSource(new StringReader(value)));
/* 57 */     } catch (Exception e) {
/* 58 */       throw new IllegalArgumentException("Failed to parse JSON String as XML: " + e.getMessage(), e);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected DocumentBuilder documentBuilder() throws ParserConfigurationException {
/* 69 */     return DEFAULT_PARSER_FACTORY.newDocumentBuilder();
/*    */   }
/*    */   
/*    */   public abstract T _deserialize(String paramString, DeserializationContext paramDeserializationContext);
/*    */   
/*    */   public static class NodeDeserializer
/*    */     extends DOMDeserializer<Node>
/*    */   {
/*    */     private static final long serialVersionUID = 1L;
/*    */     
/*    */     public NodeDeserializer() {
/* 80 */       super(Node.class);
/*    */     }
/*    */     public Node _deserialize(String value, DeserializationContext ctxt) throws IllegalArgumentException {
/* 83 */       return parse(value);
/*    */     }
/*    */   }
/*    */   
/*    */   public static class DocumentDeserializer extends DOMDeserializer<Document> {
/*    */     public DocumentDeserializer() {
/* 89 */       super(Document.class);
/*    */     } private static final long serialVersionUID = 1L;
/*    */     public Document _deserialize(String value, DeserializationContext ctxt) throws IllegalArgumentException {
/* 92 */       return parse(value);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ext\DOMDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */