/*    */ package com.fasterxml.jackson.databind.ext;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.PropertyName;
/*    */ import com.fasterxml.jackson.databind.introspect.Annotated;
/*    */ import com.fasterxml.jackson.databind.introspect.AnnotatedParameter;
/*    */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*    */ import com.fasterxml.jackson.databind.util.ExceptionUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Java7Support
/*    */ {
/*    */   private static final Java7Support IMPL;
/*    */   
/*    */   static {
/* 21 */     Java7Support impl = null;
/*    */     try {
/* 23 */       Class<?> cls = Class.forName("com.fasterxml.jackson.databind.ext.Java7SupportImpl");
/* 24 */       impl = (Java7Support)ClassUtil.createInstance(cls, false);
/* 25 */     } catch (IllegalAccessError illegalAccessError) {
/*    */ 
/*    */     
/* 28 */     } catch (Throwable t) {
/*    */ 
/*    */ 
/*    */       
/* 32 */       ExceptionUtil.rethrowIfFatal(t);
/*    */     } 
/* 34 */     IMPL = impl;
/*    */   }
/*    */   
/*    */   public static Java7Support instance() {
/* 38 */     return IMPL;
/*    */   }
/*    */   
/*    */   public abstract PropertyName findConstructorName(AnnotatedParameter paramAnnotatedParameter);
/*    */   
/*    */   public abstract Boolean hasCreatorAnnotation(Annotated paramAnnotated);
/*    */   
/*    */   public abstract Boolean findTransient(Annotated paramAnnotated);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ext\Java7Support.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */