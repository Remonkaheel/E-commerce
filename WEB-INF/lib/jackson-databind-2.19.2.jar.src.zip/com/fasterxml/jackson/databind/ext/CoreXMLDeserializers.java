/*     */ package com.fasterxml.jackson.databind.ext;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.deser.Deserializers;
/*     */ import java.io.IOException;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.TimeZone;
/*     */ import javax.xml.datatype.DatatypeConfigurationException;
/*     */ import javax.xml.datatype.DatatypeFactory;
/*     */ import javax.xml.datatype.Duration;
/*     */ import javax.xml.datatype.XMLGregorianCalendar;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ public class CoreXMLDeserializers extends Deserializers.Base {
/*  21 */   protected static final QName EMPTY_QNAME = QName.valueOf("");
/*     */   
/*     */   static final DatatypeFactory _dataTypeFactory;
/*     */   
/*     */   protected static final int TYPE_DURATION = 1;
/*     */   protected static final int TYPE_G_CALENDAR = 2;
/*     */   protected static final int TYPE_QNAME = 3;
/*     */   
/*     */   static {
/*     */     try {
/*  31 */       _dataTypeFactory = DatatypeFactory.newInstance();
/*  32 */     } catch (DatatypeConfigurationException e) {
/*  33 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> findBeanDeserializer(JavaType type, DeserializationConfig config, BeanDescription beanDesc) {
/*  41 */     Class<?> raw = type.getRawClass();
/*  42 */     if (raw == QName.class) {
/*  43 */       return (JsonDeserializer<?>)new Std(raw, 3);
/*     */     }
/*  45 */     if (raw == XMLGregorianCalendar.class) {
/*  46 */       return (JsonDeserializer<?>)new Std(raw, 2);
/*     */     }
/*  48 */     if (raw == Duration.class) {
/*  49 */       return (JsonDeserializer<?>)new Std(raw, 1);
/*     */     }
/*  51 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasDeserializerFor(DeserializationConfig config, Class<?> valueType) {
/*  56 */     return (valueType == QName.class || valueType == XMLGregorianCalendar.class || valueType == Duration.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Std
/*     */     extends FromStringDeserializer<Object>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected final int _kind;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Std(Class<?> raw, int kind) {
/*  87 */       super(raw);
/*  88 */       this._kind = kind;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*  97 */       if (this._kind == 2 && 
/*  98 */         p.hasToken(JsonToken.VALUE_NUMBER_INT)) {
/*  99 */         return _gregorianFromDate(ctxt, _parseDate(p, ctxt));
/*     */       }
/*     */ 
/*     */       
/* 103 */       if (this._kind == 3 && 
/* 104 */         p.hasToken(JsonToken.START_OBJECT)) {
/* 105 */         return _parseQNameObject(p, ctxt);
/*     */       }
/*     */       
/* 108 */       return super.deserialize(p, ctxt);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private QName _parseQNameObject(JsonParser p, DeserializationContext ctxt) throws IOException {
/* 114 */       JsonNode tree = ctxt.readTree(p);
/*     */       
/* 116 */       JsonNode localPart = tree.get("localPart");
/* 117 */       if (localPart == null) {
/* 118 */         ctxt.reportInputMismatch((JsonDeserializer)this, "Object value for `QName` is missing required property 'localPart'", new Object[0]);
/*     */       }
/*     */ 
/*     */       
/* 122 */       if (!localPart.isTextual()) {
/* 123 */         ctxt.reportInputMismatch((JsonDeserializer)this, "Object value property 'localPart' for `QName` must be of type STRING, not %s", new Object[] { localPart
/*     */               
/* 125 */               .getNodeType() });
/*     */       }
/*     */       
/* 128 */       JsonNode namespaceURI = tree.get("namespaceURI");
/* 129 */       if (namespaceURI != null) {
/* 130 */         if (tree.has("prefix")) {
/* 131 */           JsonNode prefix = tree.get("prefix");
/* 132 */           return new QName(namespaceURI.asText(), localPart.asText(), prefix.asText());
/*     */         } 
/* 134 */         return new QName(namespaceURI.asText(), localPart.asText());
/*     */       } 
/* 136 */       return new QName(localPart.asText());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected Object _deserialize(String value, DeserializationContext ctxt) throws IOException {
/*     */       Date d;
/* 143 */       switch (this._kind) {
/*     */         case 1:
/* 145 */           return CoreXMLDeserializers._dataTypeFactory.newDuration(value);
/*     */         case 3:
/* 147 */           return QName.valueOf(value);
/*     */         
/*     */         case 2:
/*     */           try {
/* 151 */             d = _parseDate(value, ctxt);
/*     */           }
/* 153 */           catch (JsonMappingException e) {
/*     */ 
/*     */             
/* 156 */             return CoreXMLDeserializers._dataTypeFactory.newXMLGregorianCalendar(value);
/*     */           } 
/* 158 */           return _gregorianFromDate(ctxt, d);
/*     */       } 
/* 160 */       throw new IllegalStateException();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object _deserializeFromEmptyString(DeserializationContext ctxt) throws IOException {
/* 165 */       if (this._kind == 3) {
/* 166 */         return CoreXMLDeserializers.EMPTY_QNAME;
/*     */       }
/* 168 */       return super._deserializeFromEmptyString(ctxt);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected XMLGregorianCalendar _gregorianFromDate(DeserializationContext ctxt, Date d) {
/* 174 */       if (d == null) {
/* 175 */         return null;
/*     */       }
/* 177 */       GregorianCalendar calendar = new GregorianCalendar();
/* 178 */       calendar.setTime(d);
/* 179 */       TimeZone tz = ctxt.getTimeZone();
/* 180 */       if (tz != null) {
/* 181 */         calendar.setTimeZone(tz);
/*     */       }
/* 183 */       return CoreXMLDeserializers._dataTypeFactory.newXMLGregorianCalendar(calendar);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ext\CoreXMLDeserializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */