/*     */ package com.fasterxml.jackson.databind.ext;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.deser.Deserializers;
/*     */ import com.fasterxml.jackson.databind.ser.Serializers;
/*     */ import com.fasterxml.jackson.databind.ser.std.DateSerializer;
/*     */ import com.fasterxml.jackson.databind.util.ClassUtil;
/*     */ import com.fasterxml.jackson.databind.util.ExceptionUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OptionalHandlerFactory
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String PACKAGE_PREFIX_JAVAX_XML = "javax.xml.";
/*     */   private static final String SERIALIZERS_FOR_JAVAX_XML = "com.fasterxml.jackson.databind.ext.CoreXMLSerializers";
/*     */   private static final String DESERIALIZERS_FOR_JAVAX_XML = "com.fasterxml.jackson.databind.ext.CoreXMLDeserializers";
/*     */   private static final String SERIALIZER_FOR_DOM_NODE = "com.fasterxml.jackson.databind.ext.DOMSerializer";
/*     */   private static final String DESERIALIZER_FOR_DOM_DOCUMENT = "com.fasterxml.jackson.databind.ext.DOMDeserializer$DocumentDeserializer";
/*     */   private static final String DESERIALIZER_FOR_DOM_NODE = "com.fasterxml.jackson.databind.ext.DOMDeserializer$NodeDeserializer";
/*     */   private static final Class<?> CLASS_DOM_NODE;
/*     */   private static final Class<?> CLASS_DOM_DOCUMENT;
/*     */   private static final Java7Handlers _jdk7Helper;
/*     */   
/*     */   static {
/*  54 */     Class<?> doc = null, node = null;
/*     */     try {
/*  56 */       node = Node.class;
/*  57 */       doc = Document.class;
/*  58 */     } catch (Throwable e) {
/*  59 */       ExceptionUtil.rethrowIfFatal(e);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     CLASS_DOM_NODE = node;
/*  66 */     CLASS_DOM_DOCUMENT = doc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     Java7Handlers x = null;
/*     */     try {
/*  77 */       x = Java7Handlers.instance();
/*  78 */     } catch (Throwable t) {
/*  79 */       ExceptionUtil.rethrowIfFatal(t);
/*     */     } 
/*  81 */     _jdk7Helper = x;
/*     */   }
/*     */   
/*  84 */   public static final OptionalHandlerFactory instance = new OptionalHandlerFactory();
/*     */   
/*     */   private final Map<String, String> _sqlDeserializers;
/*     */   
/*     */   private final Map<String, Object> _sqlSerializers;
/*     */   
/*     */   private static final String CLS_NAME_JAVA_SQL_TIMESTAMP = "java.sql.Timestamp";
/*     */   
/*     */   private static final String CLS_NAME_JAVA_SQL_DATE = "java.sql.Date";
/*     */   private static final String CLS_NAME_JAVA_SQL_TIME = "java.sql.Time";
/*     */   private static final String CLS_NAME_JAVA_SQL_BLOB = "java.sql.Blob";
/*     */   private static final String CLS_NAME_JAVA_SQL_SERIALBLOB = "javax.sql.rowset.serial.SerialBlob";
/*     */   
/*     */   protected OptionalHandlerFactory() {
/*  98 */     this._sqlDeserializers = new HashMap<>();
/*  99 */     this._sqlDeserializers.put("java.sql.Date", "com.fasterxml.jackson.databind.deser.std.DateDeserializers$SqlDateDeserializer");
/*     */     
/* 101 */     this._sqlDeserializers.put("java.sql.Timestamp", "com.fasterxml.jackson.databind.deser.std.DateDeserializers$TimestampDeserializer");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     this._sqlSerializers = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     this._sqlSerializers.put("java.sql.Timestamp", DateSerializer.instance);
/* 112 */     this._sqlSerializers.put("java.sql.Date", "com.fasterxml.jackson.databind.ser.std.SqlDateSerializer");
/* 113 */     this._sqlSerializers.put("java.sql.Time", "com.fasterxml.jackson.databind.ser.std.SqlTimeSerializer");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     this._sqlSerializers.put("java.sql.Blob", "com.fasterxml.jackson.databind.ext.SqlBlobSerializer");
/* 120 */     this._sqlSerializers.put("javax.sql.rowset.serial.SerialBlob", "com.fasterxml.jackson.databind.ext.SqlBlobSerializer");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonSerializer<?> findSerializer(SerializationConfig config, JavaType type, BeanDescription beanDesc) {
/*     */     String factoryName;
/* 132 */     Class<?> rawType = type.getRawClass();
/*     */     
/* 134 */     if (_IsXOfY(rawType, CLASS_DOM_NODE)) {
/* 135 */       return (JsonSerializer)instantiate("com.fasterxml.jackson.databind.ext.DOMSerializer", type);
/*     */     }
/*     */     
/* 138 */     if (_jdk7Helper != null) {
/* 139 */       JsonSerializer<?> ser = _jdk7Helper.getSerializerForJavaNioFilePath(rawType);
/* 140 */       if (ser != null) {
/* 141 */         return ser;
/*     */       }
/*     */     } 
/*     */     
/* 145 */     String className = rawType.getName();
/* 146 */     Object sqlHandler = this._sqlSerializers.get(className);
/*     */     
/* 148 */     if (sqlHandler != null) {
/* 149 */       if (sqlHandler instanceof JsonSerializer) {
/* 150 */         return (JsonSerializer)sqlHandler;
/*     */       }
/*     */       
/* 153 */       return (JsonSerializer)instantiate((String)sqlHandler, type);
/*     */     } 
/*     */ 
/*     */     
/* 157 */     if (className.startsWith("javax.xml.") || hasSuperClassStartingWith(rawType, "javax.xml.")) {
/* 158 */       factoryName = "com.fasterxml.jackson.databind.ext.CoreXMLSerializers";
/*     */     } else {
/* 160 */       return null;
/*     */     } 
/*     */     
/* 163 */     Object ob = instantiate(factoryName, type);
/* 164 */     if (ob == null) {
/* 165 */       return null;
/*     */     }
/* 167 */     return ((Serializers)ob).findSerializer(config, type, beanDesc);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonDeserializer<?> findDeserializer(JavaType type, DeserializationConfig config, BeanDescription beanDesc) throws JsonMappingException {
/*     */     String factoryName;
/* 174 */     Class<?> rawType = type.getRawClass();
/*     */     
/* 176 */     if (_jdk7Helper != null) {
/* 177 */       JsonDeserializer<?> deser = _jdk7Helper.getDeserializerForJavaNioFilePath(rawType);
/* 178 */       if (deser != null) {
/* 179 */         return deser;
/*     */       }
/*     */     } 
/* 182 */     if (_IsXOfY(rawType, CLASS_DOM_NODE)) {
/* 183 */       return (JsonDeserializer)instantiate("com.fasterxml.jackson.databind.ext.DOMDeserializer$NodeDeserializer", type);
/*     */     }
/* 185 */     if (_IsXOfY(rawType, CLASS_DOM_DOCUMENT)) {
/* 186 */       return (JsonDeserializer)instantiate("com.fasterxml.jackson.databind.ext.DOMDeserializer$DocumentDeserializer", type);
/*     */     }
/* 188 */     String className = rawType.getName();
/* 189 */     String deserName = this._sqlDeserializers.get(className);
/* 190 */     if (deserName != null) {
/* 191 */       return (JsonDeserializer)instantiate(deserName, type);
/*     */     }
/*     */     
/* 194 */     if (className.startsWith("javax.xml.") || 
/* 195 */       hasSuperClassStartingWith(rawType, "javax.xml.")) {
/* 196 */       factoryName = "com.fasterxml.jackson.databind.ext.CoreXMLDeserializers";
/*     */     } else {
/* 198 */       return null;
/*     */     } 
/* 200 */     Object ob = instantiate(factoryName, type);
/* 201 */     if (ob == null) {
/* 202 */       return null;
/*     */     }
/* 204 */     return ((Deserializers)ob).findBeanDeserializer(type, config, beanDesc);
/*     */   }
/*     */   
/*     */   public boolean hasDeserializerFor(Class<?> valueType) {
/* 208 */     if (_IsXOfY(valueType, CLASS_DOM_NODE)) {
/* 209 */       return true;
/*     */     }
/* 211 */     if (_IsXOfY(valueType, CLASS_DOM_DOCUMENT)) {
/* 212 */       return true;
/*     */     }
/* 214 */     String className = valueType.getName();
/* 215 */     if (className.startsWith("javax.xml.") || 
/* 216 */       hasSuperClassStartingWith(valueType, "javax.xml.")) {
/* 217 */       return true;
/*     */     }
/*     */     
/* 220 */     return this._sqlDeserializers.containsKey(className);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean _IsXOfY(Class<?> valueType, Class<?> expType) {
/* 225 */     return (expType != null && expType.isAssignableFrom(valueType));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object instantiate(String className, JavaType valueType) {
/*     */     try {
/* 237 */       return instantiate(Class.forName(className), valueType);
/* 238 */     } catch (Throwable e) {
/* 239 */       ExceptionUtil.rethrowIfFatal(e);
/* 240 */       throw new IllegalStateException("Failed to find class `" + className + "` for handling values of type " + 
/* 241 */           ClassUtil.getTypeDescription(valueType) + ", problem: (" + e
/* 242 */           .getClass().getName() + ") " + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Object instantiate(Class<?> handlerClass, JavaType valueType) {
/*     */     try {
/* 249 */       return ClassUtil.createInstance(handlerClass, false);
/* 250 */     } catch (Throwable e) {
/* 251 */       ExceptionUtil.rethrowIfFatal(e);
/* 252 */       throw new IllegalStateException("Failed to create instance of `" + handlerClass
/* 253 */           .getName() + "` for handling values of type " + ClassUtil.getTypeDescription(valueType) + ", problem: (" + e
/* 254 */           .getClass().getName() + ") " + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean hasSuperClassStartingWith(Class<?> rawType, String prefix) {
/* 268 */     for (Class<?> supertype = rawType.getSuperclass(); supertype != null; supertype = supertype.getSuperclass()) {
/* 269 */       if (supertype == Object.class) {
/* 270 */         return false;
/*     */       }
/* 272 */       if (supertype.getName().startsWith(prefix)) {
/* 273 */         return true;
/*     */       }
/*     */     } 
/* 276 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ext\OptionalHandlerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */