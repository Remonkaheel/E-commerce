/*    */ package com.fasterxml.jackson.databind.ext;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.JsonSerializer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Java7Handlers
/*    */ {
/* 17 */   private static final Java7Handlers IMPL = new Java7HandlersImpl();
/*    */   
/*    */   public static Java7Handlers instance() {
/* 20 */     return IMPL;
/*    */   }
/*    */   
/*    */   public abstract Class<?> getClassJavaNioFilePath();
/*    */   
/*    */   public abstract JsonDeserializer<?> getDeserializerForJavaNioFilePath(Class<?> paramClass);
/*    */   
/*    */   public abstract JsonSerializer<?> getSerializerForJavaNioFilePath(Class<?> paramClass);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ext\Java7Handlers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */