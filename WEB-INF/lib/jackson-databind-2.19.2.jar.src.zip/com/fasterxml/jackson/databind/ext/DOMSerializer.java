/*    */ package com.fasterxml.jackson.databind.ext;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import com.fasterxml.jackson.databind.JsonNode;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*    */ import com.fasterxml.jackson.databind.ser.std.StdSerializer;
/*    */ import java.io.IOException;
/*    */ import java.io.StringWriter;
/*    */ import java.lang.reflect.Type;
/*    */ import javax.xml.transform.Transformer;
/*    */ import javax.xml.transform.TransformerConfigurationException;
/*    */ import javax.xml.transform.TransformerException;
/*    */ import javax.xml.transform.TransformerFactory;
/*    */ import javax.xml.transform.dom.DOMSource;
/*    */ import javax.xml.transform.stream.StreamResult;
/*    */ import org.w3c.dom.Node;
/*    */ 
/*    */ public class DOMSerializer
/*    */   extends StdSerializer<Node> {
/*    */   protected final TransformerFactory transformerFactory;
/*    */   
/*    */   public DOMSerializer() {
/* 26 */     super(Node.class);
/*    */     try {
/* 28 */       this.transformerFactory = TransformerFactory.newInstance();
/* 29 */       this.transformerFactory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
/*    */       
/* 31 */       setTransformerFactoryAttribute(this.transformerFactory, "http://javax.xml.XMLConstants/property/accessExternalDTD", "");
/* 32 */       setTransformerFactoryAttribute(this.transformerFactory, "http://javax.xml.XMLConstants/property/accessExternalStylesheet", "");
/* 33 */     } catch (Exception e) {
/* 34 */       throw new IllegalStateException("Could not instantiate `TransformerFactory`: " + e.getMessage(), e);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serialize(Node value, JsonGenerator g, SerializerProvider provider) throws IOException {
/*    */     try {
/* 43 */       Transformer transformer = this.transformerFactory.newTransformer();
/* 44 */       transformer.setOutputProperty("omit-xml-declaration", "yes");
/* 45 */       transformer.setOutputProperty("indent", "no");
/* 46 */       StreamResult result = new StreamResult(new StringWriter());
/* 47 */       transformer.transform(new DOMSource(value), result);
/* 48 */       g.writeString(result.getWriter().toString());
/* 49 */     } catch (TransformerConfigurationException e) {
/* 50 */       throw new IllegalStateException("Could not create XML Transformer for writing DOM `Node` value: " + e.getMessage(), e);
/* 51 */     } catch (TransformerException e) {
/* 52 */       provider.reportMappingProblem(e, "DOM `Node` value serialization failed: %s", new Object[] { e.getMessage() });
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public JsonNode getSchema(SerializerProvider provider, Type typeHint) {
/* 63 */     return (JsonNode)createSchemaNode("string", true);
/*    */   }
/*    */ 
/*    */   
/*    */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 68 */     if (visitor != null) visitor.expectAnyFormat(typeHint);
/*    */   
/*    */   }
/*    */   
/*    */   private static void setTransformerFactoryAttribute(TransformerFactory transformerFactory, String name, Object value) {
/*    */     try {
/* 74 */       transformerFactory.setAttribute(name, value);
/* 75 */     } catch (Exception e) {
/* 76 */       System.err.println("[DOMSerializer] Failed to set TransformerFactory attribute: " + name);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ext\DOMSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */