/*    */ package com.fasterxml.jackson.databind.ext;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonGenerator;
/*    */ import com.fasterxml.jackson.core.JsonToken;
/*    */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*    */ import com.fasterxml.jackson.databind.JavaType;
/*    */ import com.fasterxml.jackson.databind.JsonMappingException;
/*    */ import com.fasterxml.jackson.databind.SerializerProvider;
/*    */ import com.fasterxml.jackson.databind.annotation.JacksonStdImpl;
/*    */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonArrayFormatVisitor;
/*    */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatTypes;
/*    */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*    */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*    */ import com.fasterxml.jackson.databind.ser.std.StdScalarSerializer;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.sql.Blob;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @JacksonStdImpl
/*    */ public class SqlBlobSerializer
/*    */   extends StdScalarSerializer<Blob>
/*    */ {
/*    */   public SqlBlobSerializer() {
/* 34 */     super(Blob.class);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isEmpty(SerializerProvider provider, Blob value) {
/* 40 */     return (value == null);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void serialize(Blob value, JsonGenerator gen, SerializerProvider ctxt) throws IOException {
/* 46 */     _writeValue(value, gen, ctxt);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void serializeWithType(Blob value, JsonGenerator gen, SerializerProvider ctxt, TypeSerializer typeSer) throws IOException {
/* 56 */     WritableTypeId typeIdDef = typeSer.writeTypePrefix(gen, typeSer
/* 57 */         .typeId(value, JsonToken.VALUE_EMBEDDED_OBJECT));
/* 58 */     _writeValue(value, gen, ctxt);
/* 59 */     typeSer.writeTypeSuffix(gen, typeIdDef);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void _writeValue(Blob value, JsonGenerator gen, SerializerProvider ctxt) throws IOException {
/* 65 */     InputStream in = null;
/*    */     try {
/* 67 */       in = value.getBinaryStream();
/* 68 */     } catch (SQLException e) {
/* 69 */       ctxt.reportMappingProblem(e, "Failed to access `java.sql.Blob` value to write as binary value", new Object[0]);
/*    */     } 
/*    */     
/* 72 */     gen.writeBinary(ctxt.getConfig().getBase64Variant(), in, -1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 83 */     JsonArrayFormatVisitor v2 = visitor.expectArrayFormat(typeHint);
/* 84 */     if (v2 != null)
/* 85 */       v2.itemsFormat(JsonFormatTypes.INTEGER); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ext\SqlBlobSerializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */