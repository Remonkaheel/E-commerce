/*    */ package com.fasterxml.jackson.databind.ext;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JacksonException;
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.core.JsonToken;
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.deser.std.StdScalarDeserializer;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ import java.nio.file.FileSystemNotFoundException;
/*    */ import java.nio.file.Path;
/*    */ import java.nio.file.Paths;
/*    */ import java.nio.file.spi.FileSystemProvider;
/*    */ import java.util.ServiceConfigurationError;
/*    */ import java.util.ServiceLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NioPathDeserializer
/*    */   extends StdScalarDeserializer<Path>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final boolean areWindowsFilePathsSupported;
/*    */   
/*    */   static {
/* 30 */     boolean isWindowsRootFound = false;
/* 31 */     for (File file : File.listRoots()) {
/* 32 */       String path = file.getPath();
/* 33 */       if (path.length() >= 2 && Character.isLetter(path.charAt(0)) && path.charAt(1) == ':') {
/* 34 */         isWindowsRootFound = true;
/*    */         break;
/*    */       } 
/*    */     } 
/* 38 */     areWindowsFilePathsSupported = isWindowsRootFound;
/*    */   }
/*    */   public NioPathDeserializer() {
/* 41 */     super(Path.class);
/*    */   }
/*    */   public Path deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
/*    */     URI uri;
/* 45 */     if (!p.hasToken(JsonToken.VALUE_STRING)) {
/* 46 */       return (Path)ctxt.handleUnexpectedToken(Path.class, p);
/*    */     }
/*    */     
/* 49 */     String value = p.getText();
/*    */ 
/*    */ 
/*    */     
/* 53 */     if (value.indexOf(':') < 0) {
/* 54 */       return Paths.get(value, new String[0]);
/*    */     }
/*    */     
/* 57 */     if (areWindowsFilePathsSupported && 
/* 58 */       value.length() >= 2 && Character.isLetter(value.charAt(0)) && value.charAt(1) == ':') {
/* 59 */       return Paths.get(value, new String[0]);
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 65 */       uri = new URI(value);
/* 66 */     } catch (URISyntaxException e) {
/* 67 */       return (Path)ctxt.handleInstantiationProblem(handledType(), value, e);
/*    */     } 
/*    */     try {
/* 70 */       return Paths.get(uri);
/* 71 */     } catch (FileSystemNotFoundException cause) {
/*    */       try {
/* 73 */         String scheme = uri.getScheme();
/*    */         
/* 75 */         for (FileSystemProvider provider : ServiceLoader.<FileSystemProvider>load(FileSystemProvider.class)) {
/* 76 */           if (provider.getScheme().equalsIgnoreCase(scheme)) {
/* 77 */             return provider.getPath(uri);
/*    */           }
/*    */         } 
/* 80 */         return (Path)ctxt.handleInstantiationProblem(handledType(), value, cause);
/* 81 */       } catch (ServiceConfigurationError e) {
/* 82 */         e.addSuppressed(cause);
/* 83 */         return (Path)ctxt.handleInstantiationProblem(handledType(), value, e);
/*    */       } 
/* 85 */     } catch (Exception e) {
/* 86 */       return (Path)ctxt.handleInstantiationProblem(handledType(), value, e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ext\NioPathDeserializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */