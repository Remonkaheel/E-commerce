/*     */ package com.fasterxml.jackson.databind.ext;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JsonFormat;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*     */ import com.fasterxml.jackson.databind.BeanDescription;
/*     */ import com.fasterxml.jackson.databind.BeanProperty;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonSerializer;
/*     */ import com.fasterxml.jackson.databind.SerializationConfig;
/*     */ import com.fasterxml.jackson.databind.SerializerProvider;
/*     */ import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatVisitorWrapper;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.ContextualSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.Serializers;
/*     */ import com.fasterxml.jackson.databind.ser.std.CalendarSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.std.StdSerializer;
/*     */ import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
/*     */ import java.io.IOException;
/*     */ import java.util.Calendar;
/*     */ import javax.xml.datatype.Duration;
/*     */ import javax.xml.datatype.XMLGregorianCalendar;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CoreXMLSerializers
/*     */   extends Serializers.Base
/*     */ {
/*     */   public JsonSerializer<?> findSerializer(SerializationConfig config, JavaType type, BeanDescription beanDesc) {
/*  37 */     Class<?> raw = type.getRawClass();
/*  38 */     if (Duration.class.isAssignableFrom(raw)) {
/*  39 */       return (JsonSerializer<?>)ToStringSerializer.instance;
/*     */     }
/*  41 */     if (QName.class.isAssignableFrom(raw)) {
/*  42 */       return QNameSerializer.instance;
/*     */     }
/*  44 */     if (XMLGregorianCalendar.class.isAssignableFrom(raw)) {
/*  45 */       return (JsonSerializer<?>)XMLGregorianCalendarSerializer.instance;
/*     */     }
/*  47 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class XMLGregorianCalendarSerializer
/*     */     extends StdSerializer<XMLGregorianCalendar>
/*     */     implements ContextualSerializer
/*     */   {
/*  55 */     static final XMLGregorianCalendarSerializer instance = new XMLGregorianCalendarSerializer();
/*     */     
/*     */     final JsonSerializer<Object> _delegate;
/*     */     
/*     */     public XMLGregorianCalendarSerializer() {
/*  60 */       this((JsonSerializer<?>)CalendarSerializer.instance);
/*     */     }
/*     */ 
/*     */     
/*     */     protected XMLGregorianCalendarSerializer(JsonSerializer<?> del) {
/*  65 */       super(XMLGregorianCalendar.class);
/*  66 */       this._delegate = (JsonSerializer)del;
/*     */     }
/*     */ 
/*     */     
/*     */     public JsonSerializer<?> getDelegatee() {
/*  71 */       return this._delegate;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isEmpty(SerializerProvider provider, XMLGregorianCalendar value) {
/*  76 */       return this._delegate.isEmpty(provider, _convert(value));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void serialize(XMLGregorianCalendar value, JsonGenerator gen, SerializerProvider provider) throws IOException {
/*  82 */       this._delegate.serialize(_convert(value), gen, provider);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void serializeWithType(XMLGregorianCalendar value, JsonGenerator g, SerializerProvider provider, TypeSerializer typeSer) throws IOException {
/*  96 */       WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/*     */           
/*  98 */           .typeId(value, XMLGregorianCalendar.class, JsonToken.VALUE_STRING));
/*     */       
/* 100 */       serialize(value, g, provider);
/* 101 */       typeSer.writeTypeSuffix(g, typeIdDef);
/*     */     }
/*     */ 
/*     */     
/*     */     public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 106 */       this._delegate.acceptJsonFormatVisitor(visitor, null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonSerializer<?> createContextual(SerializerProvider prov, BeanProperty property) throws JsonMappingException {
/* 112 */       JsonSerializer<?> ser = prov.handlePrimaryContextualization(this._delegate, property);
/* 113 */       if (ser != this._delegate) {
/* 114 */         return (JsonSerializer<?>)new XMLGregorianCalendarSerializer(ser);
/*     */       }
/* 116 */       return (JsonSerializer<?>)this;
/*     */     }
/*     */     
/*     */     protected Calendar _convert(XMLGregorianCalendar input) {
/* 120 */       return (input == null) ? null : input.toGregorianCalendar();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class QNameSerializer
/*     */     extends StdSerializer<QName>
/*     */     implements ContextualSerializer
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/* 133 */     public static final JsonSerializer<?> instance = (JsonSerializer<?>)new QNameSerializer();
/*     */     
/*     */     public QNameSerializer() {
/* 136 */       super(QName.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public JsonSerializer<?> createContextual(SerializerProvider serializers, BeanProperty property) throws JsonMappingException {
/* 143 */       JsonFormat.Value format = findFormatOverrides(serializers, property, handledType());
/* 144 */       if (format != null) {
/* 145 */         JsonFormat.Shape shape = format.getShape();
/* 146 */         if (shape == JsonFormat.Shape.OBJECT) {
/* 147 */           return (JsonSerializer<?>)this;
/*     */         }
/*     */       } 
/* 150 */       return (JsonSerializer<?>)ToStringSerializer.instance;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void serialize(QName value, JsonGenerator g, SerializerProvider ctxt) throws IOException {
/* 157 */       g.writeStartObject(value);
/* 158 */       serializeProperties(value, g, ctxt);
/* 159 */       g.writeEndObject();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final void serializeWithType(QName value, JsonGenerator g, SerializerProvider ctxt, TypeSerializer typeSer) throws IOException {
/* 167 */       WritableTypeId typeIdDef = typeSer.writeTypePrefix(g, typeSer
/* 168 */           .typeId(value, JsonToken.START_OBJECT));
/* 169 */       serializeProperties(value, g, ctxt);
/* 170 */       typeSer.writeTypeSuffix(g, typeIdDef);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private void serializeProperties(QName value, JsonGenerator g, SerializerProvider ctxt) throws IOException {
/* 176 */       g.writeStringField("localPart", value.getLocalPart());
/* 177 */       if (!value.getNamespaceURI().isEmpty()) {
/* 178 */         g.writeStringField("namespaceURI", value.getNamespaceURI());
/*     */       }
/* 180 */       if (!value.getPrefix().isEmpty()) {
/* 181 */         g.writeStringField("prefix", value.getPrefix());
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void acceptJsonFormatVisitor(JsonFormatVisitorWrapper visitor, JavaType typeHint) throws JsonMappingException {
/* 188 */       visitor.expectObjectFormat(typeHint);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\ext\CoreXMLSerializers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */