/*     */ package com.fasterxml.jackson.databind;
/*     */ 
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedField;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;
/*     */ import com.fasterxml.jackson.databind.introspect.AnnotatedParameter;
/*     */ import java.io.Serializable;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyNamingStrategy
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   @Deprecated
/*  52 */   public static final PropertyNamingStrategy LOWER_CAMEL_CASE = new PropertyNamingStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  61 */   public static final PropertyNamingStrategy UPPER_CAMEL_CASE = new UpperCamelCaseStrategy(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  70 */   public static final PropertyNamingStrategy SNAKE_CASE = new SnakeCaseStrategy(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  79 */   public static final PropertyNamingStrategy LOWER_CASE = new LowerCaseStrategy(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  88 */   public static final PropertyNamingStrategy KEBAB_CASE = new KebabCaseStrategy(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*  97 */   public static final PropertyNamingStrategy LOWER_DOT_CASE = new LowerDotCaseStrategy(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nameForField(MapperConfig<?> config, AnnotatedField field, String defaultName) {
/* 121 */     return defaultName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nameForGetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName) {
/* 142 */     return defaultName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nameForSetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName) {
/* 162 */     return defaultName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nameForConstructorParameter(MapperConfig<?> config, AnnotatedParameter ctorParam, String defaultName) {
/* 180 */     return defaultName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static abstract class PropertyNamingStrategyBase
/*     */     extends PropertyNamingStrategy
/*     */   {
/*     */     protected PropertyNamingStrategyBase() {
/* 201 */       this(true);
/*     */     }
/*     */ 
/*     */     
/*     */     protected PropertyNamingStrategyBase(boolean logWarning) {
/* 206 */       if (logWarning) {
/* 207 */         String simple = getClass().getSimpleName();
/* 208 */         Logger.getLogger(getClass().getName())
/* 209 */           .warning("PropertyNamingStrategy." + simple + " is used but it has been deprecated due to risk of deadlock. Consider using PropertyNamingStrategies." + simple + " instead. See https://github.com/FasterXML/jackson-databind/issues/2715 for more details.");
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String nameForField(MapperConfig<?> config, AnnotatedField field, String defaultName) {
/* 219 */       return translate(defaultName);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String nameForGetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName) {
/* 225 */       return translate(defaultName);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String nameForSetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName) {
/* 231 */       return translate(defaultName);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String nameForConstructorParameter(MapperConfig<?> config, AnnotatedParameter ctorParam, String defaultName) {
/* 238 */       return translate(defaultName);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract String translate(String param1String);
/*     */ 
/*     */ 
/*     */     
/*     */     protected static String translateLowerCaseWithSeparator(String input, char separator) {
/* 248 */       if (input == null) {
/* 249 */         return input;
/*     */       }
/* 251 */       int length = input.length();
/* 252 */       if (length == 0) {
/* 253 */         return input;
/*     */       }
/*     */       
/* 256 */       StringBuilder result = new StringBuilder(length + (length >> 1));
/* 257 */       int upperCount = 0;
/* 258 */       for (int i = 0; i < length; i++) {
/* 259 */         char ch = input.charAt(i);
/* 260 */         char lc = Character.toLowerCase(ch);
/*     */         
/* 262 */         if (lc == ch) {
/*     */ 
/*     */           
/* 265 */           if (upperCount > 1)
/*     */           {
/* 267 */             result.insert(result.length() - 1, separator);
/*     */           }
/* 269 */           upperCount = 0;
/*     */         } else {
/*     */           
/* 272 */           if (upperCount == 0 && i > 0) {
/* 273 */             result.append(separator);
/*     */           }
/* 275 */           upperCount++;
/*     */         } 
/* 277 */         result.append(lc);
/*     */       } 
/* 279 */       return result.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static class SnakeCaseStrategy
/*     */     extends PropertyNamingStrategyBase
/*     */   {
/*     */     public SnakeCaseStrategy() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected SnakeCaseStrategy(boolean logWarning) {
/* 299 */       super(logWarning);
/*     */     }
/*     */ 
/*     */     
/*     */     public String translate(String input) {
/* 304 */       if (input == null) return input; 
/* 305 */       int length = input.length();
/* 306 */       StringBuilder result = new StringBuilder(length * 2);
/* 307 */       int resultLength = 0;
/* 308 */       boolean wasPrevTranslated = false;
/* 309 */       for (int i = 0; i < length; i++) {
/*     */         
/* 311 */         char c = input.charAt(i);
/* 312 */         if (i > 0 || c != '_') {
/*     */           
/* 314 */           if (Character.isUpperCase(c)) {
/*     */             
/* 316 */             if (!wasPrevTranslated && resultLength > 0 && result.charAt(resultLength - 1) != '_') {
/*     */               
/* 318 */               result.append('_');
/* 319 */               resultLength++;
/*     */             } 
/* 321 */             c = Character.toLowerCase(c);
/* 322 */             wasPrevTranslated = true;
/*     */           }
/*     */           else {
/*     */             
/* 326 */             wasPrevTranslated = false;
/*     */           } 
/* 328 */           result.append(c);
/* 329 */           resultLength++;
/*     */         } 
/*     */       } 
/* 332 */       return (resultLength > 0) ? result.toString() : input;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static class UpperCamelCaseStrategy
/*     */     extends PropertyNamingStrategyBase
/*     */   {
/*     */     public UpperCamelCaseStrategy() {}
/*     */ 
/*     */     
/*     */     protected UpperCamelCaseStrategy(boolean logWarning) {
/* 346 */       super(logWarning);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String translate(String input) {
/* 358 */       if (input == null || input.isEmpty()) {
/* 359 */         return input;
/*     */       }
/*     */       
/* 362 */       char c = input.charAt(0);
/* 363 */       char uc = Character.toUpperCase(c);
/* 364 */       if (c == uc) {
/* 365 */         return input;
/*     */       }
/* 367 */       StringBuilder sb = new StringBuilder(input);
/* 368 */       sb.setCharAt(0, uc);
/* 369 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static class LowerCaseStrategy
/*     */     extends PropertyNamingStrategyBase
/*     */   {
/*     */     public LowerCaseStrategy() {}
/*     */ 
/*     */     
/*     */     protected LowerCaseStrategy(boolean logWarning) {
/* 383 */       super(logWarning);
/*     */     }
/*     */     
/*     */     public String translate(String input) {
/* 387 */       return input.toLowerCase();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static class KebabCaseStrategy
/*     */     extends PropertyNamingStrategyBase
/*     */   {
/*     */     public KebabCaseStrategy() {}
/*     */ 
/*     */     
/*     */     protected KebabCaseStrategy(boolean logWarning) {
/* 401 */       super(logWarning);
/*     */     }
/*     */     
/*     */     public String translate(String input) {
/* 405 */       return translateLowerCaseWithSeparator(input, '-');
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static class LowerDotCaseStrategy
/*     */     extends PropertyNamingStrategyBase
/*     */   {
/*     */     public LowerDotCaseStrategy() {}
/*     */ 
/*     */     
/*     */     protected LowerDotCaseStrategy(boolean logWarning) {
/* 419 */       super(logWarning);
/*     */     }
/*     */     
/*     */     public String translate(String input) {
/* 423 */       return translateLowerCaseWithSeparator(input, '.');
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-databind-2.19.2.jar!\com\fasterxml\jackson\databind\PropertyNamingStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */