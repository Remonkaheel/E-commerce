package org.thymeleaf.spring6;

import java.nio.charset.Charset;
import java.util.Set;
import org.reactivestreams.Publisher;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferFactory;
import org.springframework.http.MediaType;
import org.thymeleaf.context.IContext;

public interface ISpringWebFluxTemplateEngine extends ISpringTemplateEngine {
  Publisher<DataBuffer> processStream(String paramString, Set<String> paramSet, IContext paramIContext, DataBufferFactory paramDataBufferFactory, MediaType paramMediaType, Charset paramCharset);
  
  Publisher<DataBuffer> processStream(String paramString, Set<String> paramSet, IContext paramIContext, DataBufferFactory paramDataBufferFactory, MediaType paramMediaType, Charset paramCharset, int paramInt);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\ISpringWebFluxTemplateEngine.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */