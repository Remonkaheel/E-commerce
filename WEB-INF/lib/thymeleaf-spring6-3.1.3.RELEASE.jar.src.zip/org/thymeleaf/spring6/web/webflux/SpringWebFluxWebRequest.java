/*    */ package org.thymeleaf.spring6.web.webflux;
/*    */ 
/*    */ import java.net.URI;
/*    */ import org.springframework.http.HttpCookie;
/*    */ import org.springframework.http.server.reactive.ServerHttpRequest;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SpringWebFluxWebRequest
/*    */   implements ISpringWebFluxWebRequest
/*    */ {
/*    */   private final ServerHttpRequest request;
/*    */   
/*    */   SpringWebFluxWebRequest(ServerHttpRequest request) {
/* 44 */     Validate.notNull(request, "Server HTTP Request cannot be null");
/* 45 */     this.request = request;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getMethod() {
/* 51 */     return this.request.getMethod().name();
/*    */   }
/*    */ 
/*    */   
/*    */   public URI getURI() {
/* 56 */     return this.request.getURI();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getApplicationPath() {
/* 61 */     return this.request.getPath().contextPath().value();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPathWithinApplication() {
/* 66 */     return this.request.getPath().pathWithinApplication().value();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public MultiValueMap<String, String> getHeaderMultiValueMap() {
/* 72 */     return (MultiValueMap<String, String>)this.request.getHeaders();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public MultiValueMap<String, String> getParameterMultiValueMap() {
/* 78 */     return this.request.getQueryParams();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public MultiValueMap<String, HttpCookie> getCookieMultiValueMap() {
/* 84 */     return this.request.getCookies();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getNativeRequestObject() {
/* 90 */     return this.request;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\web\webflux\SpringWebFluxWebRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */