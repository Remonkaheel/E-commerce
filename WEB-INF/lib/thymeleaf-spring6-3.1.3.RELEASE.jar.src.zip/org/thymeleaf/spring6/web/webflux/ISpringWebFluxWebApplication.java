/*    */ package org.thymeleaf.spring6.web.webflux;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.ReactiveAdapterRegistry;
/*    */ import org.thymeleaf.util.Validate;
/*    */ import org.thymeleaf.web.IWebApplication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ISpringWebFluxWebApplication
/*    */   extends IWebApplication
/*    */ {
/*    */   ReactiveAdapterRegistry getReactiveAdapterRegistry();
/*    */   
/*    */   Map<String, Object> getAttributes();
/*    */   
/*    */   default boolean containsAttribute(String name) {
/* 46 */     Validate.notNull(name, "Name cannot be null");
/* 47 */     Map<String, Object> attributes = getAttributes();
/* 48 */     return (attributes != null && attributes.containsKey(name));
/*    */   }
/*    */ 
/*    */   
/*    */   default int getAttributeCount() {
/* 53 */     Map<String, Object> attributes = getAttributes();
/* 54 */     return (attributes == null) ? 0 : attributes.size();
/*    */   }
/*    */ 
/*    */   
/*    */   default Set<String> getAllAttributeNames() {
/* 59 */     Map<String, Object> attributes = getAttributes();
/* 60 */     return (attributes == null) ? Collections.<String>emptySet() : attributes.keySet();
/*    */   }
/*    */ 
/*    */   
/*    */   default Map<String, Object> getAttributeMap() {
/* 65 */     return getAttributes();
/*    */   }
/*    */ 
/*    */   
/*    */   default Object getAttributeValue(String name) {
/* 70 */     Validate.notNull(name, "Name cannot be null");
/* 71 */     Map<String, Object> attributes = getAttributes();
/* 72 */     return (attributes == null) ? null : attributes.get(name);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\web\webflux\ISpringWebFluxWebApplication.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */