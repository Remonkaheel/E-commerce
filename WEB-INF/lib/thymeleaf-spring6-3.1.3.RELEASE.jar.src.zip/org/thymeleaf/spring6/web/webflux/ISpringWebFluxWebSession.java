/*    */ package org.thymeleaf.spring6.web.webflux;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.thymeleaf.util.Validate;
/*    */ import org.thymeleaf.web.IWebSession;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ISpringWebFluxWebSession
/*    */   extends IWebSession
/*    */ {
/*    */   Map<String, Object> getAttributes();
/*    */   
/*    */   default boolean containsAttribute(String name) {
/* 43 */     Validate.notNull(name, "Name cannot be null");
/* 44 */     Map<String, Object> attributes = getAttributes();
/* 45 */     return (attributes != null && attributes.containsKey(name));
/*    */   }
/*    */ 
/*    */   
/*    */   default int getAttributeCount() {
/* 50 */     Map<String, Object> attributes = getAttributes();
/* 51 */     return (attributes == null) ? 0 : attributes.size();
/*    */   }
/*    */ 
/*    */   
/*    */   default Set<String> getAllAttributeNames() {
/* 56 */     Map<String, Object> attributes = getAttributes();
/* 57 */     return (attributes == null) ? Collections.<String>emptySet() : attributes.keySet();
/*    */   }
/*    */ 
/*    */   
/*    */   default Map<String, Object> getAttributeMap() {
/* 62 */     return getAttributes();
/*    */   }
/*    */ 
/*    */   
/*    */   default Object getAttributeValue(String name) {
/* 67 */     Validate.notNull(name, "Name cannot be null");
/* 68 */     Map<String, Object> attributes = getAttributes();
/* 69 */     return (attributes == null) ? null : attributes.get(name);
/*    */   }
/*    */   
/*    */   Object getNativeSessionObject();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\web\webflux\ISpringWebFluxWebSession.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */