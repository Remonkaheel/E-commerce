/*     */ package org.thymeleaf.spring6.web.webflux;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.security.Principal;
/*     */ import java.util.Collections;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.springframework.web.server.WebSession;
/*     */ import org.thymeleaf.util.Validate;
/*     */ import org.thymeleaf.web.IWebApplication;
/*     */ import org.thymeleaf.web.IWebRequest;
/*     */ import org.thymeleaf.web.IWebSession;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SpringWebFluxWebExchange
/*     */   implements ISpringWebFluxWebExchange
/*     */ {
/*     */   private final SpringWebFluxWebRequest webRequest;
/*     */   private final SpringWebFluxWebApplication webApplication;
/*     */   private SpringWebFluxWebSession webSession;
/*     */   private boolean webSessionInitialized;
/*     */   private final ServerWebExchange exchange;
/*     */   private final Locale locale;
/*     */   private final MediaType mediaType;
/*     */   private final Charset charset;
/*     */   
/*     */   SpringWebFluxWebExchange(SpringWebFluxWebRequest webRequest, SpringWebFluxWebApplication webApplication, ServerWebExchange exchange, Locale locale, MediaType mediaType, Charset charset) {
/*  63 */     Validate.notNull(webRequest, "Request cannot be null");
/*  64 */     Validate.notNull(webApplication, "Application cannot be null");
/*  65 */     Validate.notNull(exchange, "Server Web Exchange cannot be null");
/*  66 */     Validate.notNull(locale, "Locale cannot be null");
/*  67 */     Validate.notNull(mediaType, "Media Type cannot be null");
/*  68 */     Validate.notNull(charset, "Charset cannot be null");
/*  69 */     this.webRequest = webRequest;
/*  70 */     this.webApplication = webApplication;
/*  71 */     this.exchange = exchange;
/*  72 */     this.locale = locale;
/*  73 */     this.mediaType = mediaType;
/*  74 */     this.charset = charset;
/*     */     
/*  76 */     this.webSession = null;
/*  77 */     this.webSessionInitialized = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ISpringWebFluxWebRequest getRequest() {
/*  83 */     return this.webRequest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ISpringWebFluxWebSession getSession() {
/*  91 */     if (!this.webSessionInitialized) {
/*  92 */       WebSession session = (WebSession)this.exchange.getAttribute("thymeleafWebSession");
/*  93 */       if (session != null) {
/*  94 */         this.webSession = new SpringWebFluxWebSession(session);
/*  95 */         this.webSessionInitialized = true;
/*     */       } 
/*     */     } 
/*  98 */     return this.webSession;
/*     */   }
/*     */ 
/*     */   
/*     */   public ISpringWebFluxWebApplication getApplication() {
/* 103 */     return this.webApplication;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Principal getPrincipal() {
/* 112 */     return (Principal)this.exchange.getAttribute("thymeleafWebExchangePrincipal");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Locale getLocale() {
/* 120 */     return this.locale;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContentType() {
/* 125 */     return this.mediaType.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCharacterEncoding() {
/* 130 */     return this.charset.name();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getAttributes() {
/* 136 */     return Collections.unmodifiableMap(this.exchange.getAttributes());
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getAttributeValue(String name) {
/* 141 */     Validate.notNull(name, "Name cannot be null");
/* 142 */     return this.exchange.getAttribute(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttributeValue(String name, Object value) {
/* 147 */     Validate.notNull(name, "Name cannot be null");
/* 148 */     if (value == null) {
/* 149 */       this.exchange.getAttributes().remove(name);
/*     */     } else {
/* 151 */       this.exchange.getAttributes().put(name, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAttribute(String name) {
/* 157 */     Validate.notNull(name, "Name cannot be null");
/* 158 */     this.exchange.getAttributes().remove(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getNativeExchangeObject() {
/* 163 */     return this.exchange;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String transformURL(String url) {
/* 169 */     return this.exchange.transformUrl(url);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\web\webflux\SpringWebFluxWebExchange.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */