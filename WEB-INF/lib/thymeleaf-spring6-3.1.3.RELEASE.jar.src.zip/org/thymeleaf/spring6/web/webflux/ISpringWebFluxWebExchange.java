/*    */ package org.thymeleaf.spring6.web.webflux;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.thymeleaf.util.Validate;
/*    */ import org.thymeleaf.web.IWebApplication;
/*    */ import org.thymeleaf.web.IWebExchange;
/*    */ import org.thymeleaf.web.IWebRequest;
/*    */ import org.thymeleaf.web.IWebSession;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ISpringWebFluxWebExchange
/*    */   extends IWebExchange
/*    */ {
/*    */   default boolean containsAttribute(String name) {
/* 57 */     Validate.notNull(name, "Name cannot be null");
/* 58 */     Map<String, Object> attributes = getAttributes();
/*    */ 
/*    */     
/* 61 */     return (attributes != null && attributes.containsKey(name));
/*    */   }
/*    */ 
/*    */   
/*    */   default int getAttributeCount() {
/* 66 */     Map<String, Object> attributes = getAttributes();
/* 67 */     return (attributes == null) ? 0 : attributes.size();
/*    */   }
/*    */ 
/*    */   
/*    */   default Set<String> getAllAttributeNames() {
/* 72 */     Map<String, Object> attributes = getAttributes();
/* 73 */     return (attributes == null) ? Collections.<String>emptySet() : attributes.keySet();
/*    */   }
/*    */ 
/*    */   
/*    */   default Map<String, Object> getAttributeMap() {
/* 78 */     return getAttributes();
/*    */   }
/*    */ 
/*    */   
/*    */   default Object getAttributeValue(String name) {
/* 83 */     Validate.notNull(name, "Name cannot be null");
/* 84 */     Map<String, Object> attributes = getAttributes();
/* 85 */     return (attributes == null) ? null : attributes.get(name);
/*    */   }
/*    */   
/*    */   ISpringWebFluxWebRequest getRequest();
/*    */   
/*    */   ISpringWebFluxWebSession getSession();
/*    */   
/*    */   ISpringWebFluxWebApplication getApplication();
/*    */   
/*    */   Map<String, Object> getAttributes();
/*    */   
/*    */   Object getNativeExchangeObject();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\web\webflux\ISpringWebFluxWebExchange.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */