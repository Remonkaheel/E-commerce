/*    */ package org.thymeleaf.spring6.web.webflux;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.http.HttpCookie;
/*    */ import org.springframework.util.MultiValueMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MultiValueMapUtil
/*    */ {
/* 40 */   static String[] EMPTY_VALUES = new String[0];
/*    */ 
/*    */   
/*    */   static Map<String, String[]> stringToStringArrayMultiMap(MultiValueMap<String, String> multiValueMap) {
/* 44 */     if (multiValueMap == null) {
/* 45 */       return null;
/*    */     }
/*    */     
/* 48 */     Map<String, String[]> stringArrayMap = (Map)new LinkedHashMap<>(multiValueMap.size() + 1, 1.0F);
/* 49 */     for (Map.Entry<String, List<String>> multiValueMapEntry : (Iterable<Map.Entry<String, List<String>>>)multiValueMap.entrySet()) {
/* 50 */       List<String> multiValueMapEntryValue = multiValueMapEntry.getValue();
/* 51 */       stringArrayMap.put(multiValueMapEntry
/* 52 */           .getKey(), (String[])((List)multiValueMapEntry
/* 53 */           .getValue()).toArray((Object[])new String[multiValueMapEntryValue.size()]));
/*    */     } 
/* 55 */     return (Map)Collections.unmodifiableMap((Map)stringArrayMap);
/*    */   }
/*    */ 
/*    */   
/*    */   static Map<String, String[]> cookieToStringArrayMultiMap(MultiValueMap<String, HttpCookie> multiValueMap) {
/* 60 */     if (multiValueMap == null) {
/* 61 */       return null;
/*    */     }
/*    */     
/* 64 */     Map<String, String[]> stringArrayMap = (Map)new LinkedHashMap<>(multiValueMap.size() + 1, 1.0F);
/* 65 */     for (Map.Entry<String, List<HttpCookie>> multiValueMapEntry : (Iterable<Map.Entry<String, List<HttpCookie>>>)multiValueMap.entrySet()) {
/* 66 */       stringArrayMap.put(multiValueMapEntry
/* 67 */           .getKey(), (String[])((List)multiValueMapEntry
/* 68 */           .getValue()).stream().map(HttpCookie::getValue).toArray(x$0 -> new String[x$0]));
/*    */     }
/* 70 */     return (Map)Collections.unmodifiableMap((Map)stringArrayMap);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\web\webflux\MultiValueMapUtil.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */