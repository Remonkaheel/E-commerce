/*     */ package org.thymeleaf.spring6.web.webflux;
/*     */ 
/*     */ import java.net.URI;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.http.HttpCookie;
/*     */ import org.springframework.util.MultiValueMap;
/*     */ import org.thymeleaf.util.Validate;
/*     */ import org.thymeleaf.web.IWebRequest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ISpringWebFluxWebRequest
/*     */   extends IWebRequest
/*     */ {
/*     */   URI getURI();
/*     */   
/*     */   default String getScheme() {
/*  46 */     URI uri = getURI();
/*  47 */     return (uri == null) ? null : uri.getScheme();
/*     */   }
/*     */ 
/*     */   
/*     */   default String getServerName() {
/*  52 */     URI uri = getURI();
/*  53 */     return (uri == null) ? null : uri.getHost();
/*     */   }
/*     */ 
/*     */   
/*     */   default Integer getServerPort() {
/*  58 */     URI uri = getURI();
/*  59 */     return (uri == null) ? null : Integer.valueOf(uri.getPort());
/*     */   }
/*     */ 
/*     */   
/*     */   default String getQueryString() {
/*  64 */     URI uri = getURI();
/*  65 */     return (uri == null) ? null : uri.getRawQuery();
/*     */   }
/*     */ 
/*     */   
/*     */   MultiValueMap<String, String> getHeaderMultiValueMap();
/*     */ 
/*     */   
/*     */   default boolean containsHeader(String name) {
/*  73 */     Validate.notNull(name, "Name cannot be null");
/*  74 */     MultiValueMap<String, String> headerMultiValueMap = getHeaderMultiValueMap();
/*  75 */     return (headerMultiValueMap != null && headerMultiValueMap.containsKey(name));
/*     */   }
/*     */ 
/*     */   
/*     */   default int getHeaderCount() {
/*  80 */     MultiValueMap<String, String> headerMultiValueMap = getHeaderMultiValueMap();
/*  81 */     return (headerMultiValueMap == null) ? 0 : headerMultiValueMap.size();
/*     */   }
/*     */ 
/*     */   
/*     */   default Set<String> getAllHeaderNames() {
/*  86 */     MultiValueMap<String, String> headerMultiValueMap = getHeaderMultiValueMap();
/*  87 */     return (headerMultiValueMap == null) ? Collections.<String>emptySet() : headerMultiValueMap.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   default Map<String, String[]> getHeaderMap() {
/*  92 */     MultiValueMap<String, String> headerMultiValueMap = getHeaderMultiValueMap();
/*  93 */     if (headerMultiValueMap == null) {
/*  94 */       return (Map)Collections.emptyMap();
/*     */     }
/*  96 */     return MultiValueMapUtil.stringToStringArrayMultiMap(headerMultiValueMap);
/*     */   }
/*     */ 
/*     */   
/*     */   default String getHeaderValue(String name) {
/* 101 */     Validate.notNull(name, "Name cannot be null");
/* 102 */     MultiValueMap<String, String> headerMultiValueMap = getHeaderMultiValueMap();
/* 103 */     return (headerMultiValueMap == null) ? null : (String)headerMultiValueMap.getFirst(name);
/*     */   }
/*     */ 
/*     */   
/*     */   default String[] getHeaderValues(String name) {
/* 108 */     Validate.notNull(name, "Name cannot be null");
/* 109 */     MultiValueMap<String, String> headerMultiValueMap = getHeaderMultiValueMap();
/* 110 */     if (headerMultiValueMap == null) {
/* 111 */       return MultiValueMapUtil.EMPTY_VALUES;
/*     */     }
/* 113 */     List<String> headerValueList = (List<String>)headerMultiValueMap.get(name);
/* 114 */     if (headerValueList == null) {
/* 115 */       return MultiValueMapUtil.EMPTY_VALUES;
/*     */     }
/* 117 */     return headerValueList.<String>toArray(new String[headerValueList.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   MultiValueMap<String, String> getParameterMultiValueMap();
/*     */ 
/*     */   
/*     */   default boolean containsParameter(String name) {
/* 125 */     Validate.notNull(name, "Name cannot be null");
/* 126 */     MultiValueMap<String, String> parameterMultiValueMap = getParameterMultiValueMap();
/* 127 */     return (parameterMultiValueMap != null && parameterMultiValueMap.containsKey(name));
/*     */   }
/*     */ 
/*     */   
/*     */   default int getParameterCount() {
/* 132 */     MultiValueMap<String, String> parameterMultiValueMap = getParameterMultiValueMap();
/* 133 */     return (parameterMultiValueMap == null) ? 0 : parameterMultiValueMap.size();
/*     */   }
/*     */ 
/*     */   
/*     */   default Set<String> getAllParameterNames() {
/* 138 */     MultiValueMap<String, String> parameterMultiValueMap = getParameterMultiValueMap();
/* 139 */     return (parameterMultiValueMap == null) ? null : parameterMultiValueMap.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   default Map<String, String[]> getParameterMap() {
/* 144 */     MultiValueMap<String, String> parameterMultiValueMap = getParameterMultiValueMap();
/* 145 */     if (parameterMultiValueMap == null) {
/* 146 */       return (Map)Collections.emptyMap();
/*     */     }
/* 148 */     return MultiValueMapUtil.stringToStringArrayMultiMap(parameterMultiValueMap);
/*     */   }
/*     */ 
/*     */   
/*     */   default String getParameterValue(String name) {
/* 153 */     Validate.notNull(name, "Name cannot be null");
/* 154 */     MultiValueMap<String, String> parameterMultiValueMap = getParameterMultiValueMap();
/* 155 */     return (parameterMultiValueMap == null) ? null : (String)parameterMultiValueMap.getFirst(name);
/*     */   }
/*     */ 
/*     */   
/*     */   default String[] getParameterValues(String name) {
/* 160 */     Validate.notNull(name, "Name cannot be null");
/* 161 */     MultiValueMap<String, String> parameterMultiValueMap = getParameterMultiValueMap();
/* 162 */     if (parameterMultiValueMap == null) {
/* 163 */       return MultiValueMapUtil.EMPTY_VALUES;
/*     */     }
/* 165 */     List<String> parameterValueList = (List<String>)parameterMultiValueMap.get(name);
/* 166 */     if (parameterValueList == null) {
/* 167 */       return MultiValueMapUtil.EMPTY_VALUES;
/*     */     }
/* 169 */     return parameterValueList.<String>toArray(new String[parameterValueList.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   MultiValueMap<String, HttpCookie> getCookieMultiValueMap();
/*     */ 
/*     */   
/*     */   default boolean containsCookie(String name) {
/* 177 */     Validate.notNull(name, "Name cannot be null");
/* 178 */     MultiValueMap<String, HttpCookie> cookieMultiValueMap = getCookieMultiValueMap();
/* 179 */     return (cookieMultiValueMap != null && cookieMultiValueMap.containsKey(name));
/*     */   }
/*     */ 
/*     */   
/*     */   default int getCookieCount() {
/* 184 */     MultiValueMap<String, HttpCookie> cookieMultiValueMap = getCookieMultiValueMap();
/* 185 */     return (cookieMultiValueMap == null) ? 0 : cookieMultiValueMap.size();
/*     */   }
/*     */ 
/*     */   
/*     */   default Set<String> getAllCookieNames() {
/* 190 */     MultiValueMap<String, HttpCookie> cookieMultiValueMap = getCookieMultiValueMap();
/* 191 */     return (cookieMultiValueMap == null) ? Collections.<String>emptySet() : cookieMultiValueMap.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   default Map<String, String[]> getCookieMap() {
/* 196 */     MultiValueMap<String, HttpCookie> cookieMultiValueMap = getCookieMultiValueMap();
/* 197 */     if (cookieMultiValueMap == null) {
/* 198 */       return (Map)Collections.emptyMap();
/*     */     }
/* 200 */     return MultiValueMapUtil.cookieToStringArrayMultiMap(cookieMultiValueMap);
/*     */   }
/*     */ 
/*     */   
/*     */   default String getCookieValue(String name) {
/* 205 */     Validate.notNull(name, "Name cannot be null");
/* 206 */     MultiValueMap<String, HttpCookie> cookieMultiValueMap = getCookieMultiValueMap();
/* 207 */     if (cookieMultiValueMap == null) {
/* 208 */       return null;
/*     */     }
/* 210 */     HttpCookie cookie = (HttpCookie)cookieMultiValueMap.getFirst(name);
/* 211 */     return (cookie == null) ? null : cookie.getValue();
/*     */   }
/*     */ 
/*     */   
/*     */   default String[] getCookieValues(String name) {
/* 216 */     Validate.notNull(name, "Name cannot be null");
/* 217 */     MultiValueMap<String, HttpCookie> cookieMultiValueMap = getCookieMultiValueMap();
/* 218 */     if (cookieMultiValueMap == null) {
/* 219 */       return MultiValueMapUtil.EMPTY_VALUES;
/*     */     }
/* 221 */     List<HttpCookie> cookieList = (List<HttpCookie>)cookieMultiValueMap.get(name);
/* 222 */     if (cookieList == null) {
/* 223 */       return MultiValueMapUtil.EMPTY_VALUES;
/*     */     }
/* 225 */     return (String[])cookieList.stream().map(HttpCookie::getValue).toArray(x$0 -> new String[x$0]);
/*     */   }
/*     */   
/*     */   Object getNativeRequestObject();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\web\webflux\ISpringWebFluxWebRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */