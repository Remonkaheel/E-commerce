/*    */ package org.thymeleaf.spring6.web.webflux;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import org.springframework.web.server.WebSession;
/*    */ import org.thymeleaf.util.Validate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SpringWebFluxWebSession
/*    */   implements ISpringWebFluxWebSession
/*    */ {
/*    */   private final WebSession session;
/*    */   
/*    */   SpringWebFluxWebSession(WebSession session) {
/* 43 */     Validate.notNull(session, "Session cannot be null");
/* 44 */     this.session = session;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean exists() {
/* 49 */     return this.session.isStarted();
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, Object> getAttributes() {
/* 54 */     return Collections.unmodifiableMap(this.session.getAttributes());
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getAttributeValue(String name) {
/* 59 */     Validate.notNull(name, "Name cannot be null");
/* 60 */     return this.session.getAttribute(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setAttributeValue(String name, Object value) {
/* 65 */     Validate.notNull(name, "Name cannot be null");
/* 66 */     if (value == null) {
/* 67 */       this.session.getAttributes().remove(name);
/*    */     } else {
/* 69 */       this.session.getAttributes().put(name, value);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void removeAttribute(String name) {
/* 75 */     Validate.notNull(name, "Name cannot be null");
/* 76 */     this.session.getAttributes().remove(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getNativeSessionObject() {
/* 81 */     return this.session;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\web\webflux\SpringWebFluxWebSession.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */