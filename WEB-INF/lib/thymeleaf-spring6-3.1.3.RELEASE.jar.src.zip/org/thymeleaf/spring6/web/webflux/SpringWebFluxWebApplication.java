/*     */ package org.thymeleaf.spring6.web.webflux;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Collections;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringWebFluxWebApplication
/*     */   implements ISpringWebFluxWebApplication
/*     */ {
/*     */   private final ReactiveAdapterRegistry reactiveAdapterRegistry;
/*     */   
/*     */   SpringWebFluxWebApplication(ReactiveAdapterRegistry reactiveAdapterRegistry) {
/*  55 */     this.reactiveAdapterRegistry = reactiveAdapterRegistry;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static SpringWebFluxWebApplication buildApplication(ReactiveAdapterRegistry reactiveAdapterRegistry) {
/*  61 */     return new SpringWebFluxWebApplication(reactiveAdapterRegistry);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ISpringWebFluxWebExchange buildExchange(ServerWebExchange exchange, Locale locale, MediaType mediaType, Charset charset) {
/*  67 */     Validate.notNull(exchange, "ServerWebExchange cannot be null");
/*  68 */     Validate.notNull(locale, "Locale cannot be null");
/*  69 */     Validate.notNull(mediaType, "Media Type cannot be null");
/*  70 */     Validate.notNull(charset, "Charset cannot be null");
/*     */     
/*  72 */     SpringWebFluxWebRequest request = new SpringWebFluxWebRequest(exchange.getRequest());
/*     */     
/*  74 */     return new SpringWebFluxWebExchange(request, this, exchange, locale, mediaType, charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactiveAdapterRegistry getReactiveAdapterRegistry() {
/*  81 */     return this.reactiveAdapterRegistry;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> getAttributes() {
/*  86 */     return Collections.emptyMap();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAttributeValue(String name, Object value) {
/*  91 */     Validate.notNull(name, "Name cannot be null");
/*  92 */     throw new UnsupportedOperationException("No support for application-level attributes in Spring WebFlux");
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeAttribute(String name) {
/*  97 */     Validate.notNull(name, "Name cannot be null");
/*  98 */     throw new UnsupportedOperationException("No support for application-level attributes in Spring WebFlux");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean resourceExists(String path) {
/* 104 */     Validate.notNull(path, "Path cannot be null");
/* 105 */     throw new UnsupportedOperationException("No support for webapplication-based resource resolution in Spring WebFlux");
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getResourceAsStream(String path) {
/* 110 */     Validate.notNull(path, "Path cannot be null");
/* 111 */     throw new UnsupportedOperationException("No support for webapplication-based resource resolution in Spring WebFlux");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\web\webflux\SpringWebFluxWebApplication.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */