package org.thymeleaf.spring6.naming;

public final class SpringContextVariableNames {
  public static final String SPRING_REQUEST_CONTEXT = "springRequestContext";
  
  public static final String THYMELEAF_REQUEST_CONTEXT = "thymeleafRequestContext";
  
  public static final String THYMELEAF_FIELD_BIND_STATUS = "thymeleafFieldBindStatus";
  
  public static final String SPRING_BOUND_OBJECT_EXPRESSION = "springBoundObjectExpression";
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\naming\SpringContextVariableNames.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */