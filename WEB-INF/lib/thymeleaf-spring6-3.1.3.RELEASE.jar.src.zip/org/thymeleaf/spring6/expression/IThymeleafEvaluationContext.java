package org.thymeleaf.spring6.expression;

import org.springframework.expression.EvaluationContext;
import org.thymeleaf.expression.IExpressionObjects;

public interface IThymeleafEvaluationContext extends EvaluationContext {
  boolean isVariableAccessRestricted();
  
  void setVariableAccessRestricted(boolean paramBoolean);
  
  IExpressionObjects getExpressionObjects();
  
  void setExpressionObjects(IExpressionObjects paramIExpressionObjects);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\expression\IThymeleafEvaluationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */