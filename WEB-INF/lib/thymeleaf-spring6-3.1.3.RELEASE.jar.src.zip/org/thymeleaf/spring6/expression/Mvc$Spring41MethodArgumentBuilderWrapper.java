/*     */ package org.thymeleaf.spring6.expression;
/*     */ 
/*     */ import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;
/*     */ import org.thymeleaf.spring6.util.SpringVersionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Spring41MethodArgumentBuilderWrapper
/*     */   implements Mvc.MethodArgumentBuilderWrapper
/*     */ {
/*     */   private final MvcUriComponentsBuilder.MethodArgumentBuilder builder;
/*     */   
/*     */   private Spring41MethodArgumentBuilderWrapper(MvcUriComponentsBuilder.MethodArgumentBuilder builder) {
/* 127 */     this.builder = builder;
/*     */   }
/*     */   
/*     */   public Mvc.MethodArgumentBuilderWrapper arg(int index, Object value) {
/* 131 */     return new Spring41MethodArgumentBuilderWrapper(this.builder.arg(index, value));
/*     */   }
/*     */   
/*     */   public Mvc.MethodArgumentBuilderWrapper encode() {
/* 135 */     if (!SpringVersionUtils.isSpringAtLeast(5, 0, 8))
/* 136 */       throw new IllegalStateException(String.format("At least Spring version 5.0.8.RELEASE is needed for executing MvcUriComponentsBuilder#encode() but detected Spring version is %s.", new Object[] {
/*     */ 
/*     */               
/* 139 */               SpringVersionUtils.getSpringVersion()
/*     */             })); 
/* 141 */     return new Spring41MethodArgumentBuilderWrapper(this.builder.encode());
/*     */   }
/*     */   
/*     */   public String build() {
/* 145 */     return this.builder.build();
/*     */   }
/*     */   
/*     */   public String buildAndExpand(Object... uriVariables) {
/* 149 */     return this.builder.buildAndExpand(uriVariables);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\expression\Mvc$Spring41MethodArgumentBuilderWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */