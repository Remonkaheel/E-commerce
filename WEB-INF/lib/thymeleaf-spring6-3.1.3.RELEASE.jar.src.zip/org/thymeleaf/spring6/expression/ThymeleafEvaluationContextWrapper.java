/*     */ package org.thymeleaf.spring6.expression;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.context.expression.MapAccessor;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.expression.ConstructorResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.MethodResolver;
/*     */ import org.springframework.expression.OperatorOverloader;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.TypeComparator;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.TypeLocator;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.springframework.expression.spel.support.ReflectiveMethodResolver;
/*     */ import org.springframework.expression.spel.support.ReflectivePropertyAccessor;
/*     */ import org.thymeleaf.expression.IExpressionObjects;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ThymeleafEvaluationContextWrapper
/*     */   implements IThymeleafEvaluationContext
/*     */ {
/*  67 */   private static final MapAccessor MAP_ACCESSOR_INSTANCE = new MapAccessor();
/*     */   
/*     */   private final EvaluationContext delegate;
/*     */   
/*     */   private final List<PropertyAccessor> propertyAccessors;
/*     */   
/*     */   private final TypeLocator typeLocator;
/*     */   private final List<MethodResolver> methodResolvers;
/*  75 */   private IExpressionObjects expressionObjects = null;
/*     */   private boolean requestParametersRestricted = false;
/*  77 */   private Map<String, Object> additionalVariables = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ThymeleafEvaluationContextWrapper(EvaluationContext delegate) {
/*  86 */     Validate.notNull(delegate, "Evaluation context delegate cannot be null");
/*     */     
/*  88 */     this.delegate = delegate;
/*     */     
/*  90 */     if (this.delegate instanceof ThymeleafEvaluationContext) {
/*     */       
/*  92 */       this.propertyAccessors = null;
/*  93 */       this.typeLocator = null;
/*  94 */       this.methodResolvers = null;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  99 */       this
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 105 */         .propertyAccessors = (List<PropertyAccessor>)Stream.concat(Stream.of((Object[])new PropertyAccessor[] { SPELContextPropertyAccessor.INSTANCE, (PropertyAccessor)MAP_ACCESSOR_INSTANCE }, ), this.delegate.getPropertyAccessors().stream().map(pa -> (pa instanceof ReflectivePropertyAccessor) ? (PropertyAccessor)new ThymeleafEvaluationContext.ThymeleafEvaluationContextACLPropertyAccessor((ReflectivePropertyAccessor)pa) : pa)).collect(Collectors.toList());
/*     */ 
/*     */       
/* 108 */       this
/* 109 */         .typeLocator = new ThymeleafEvaluationContext.ThymeleafEvaluationContextACLTypeLocator(this.delegate.getTypeLocator());
/*     */ 
/*     */       
/* 112 */       this
/*     */ 
/*     */ 
/*     */         
/* 116 */         .methodResolvers = (List<MethodResolver>)this.delegate.getMethodResolvers().stream().map(mr -> (mr instanceof ReflectiveMethodResolver) ? (MethodResolver)new ThymeleafEvaluationContext.ThymeleafEvaluationContextACLMethodResolver((ReflectiveMethodResolver)mr) : mr).collect(Collectors.toList());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue getRootObject() {
/* 124 */     return this.delegate.getRootObject();
/*     */   }
/*     */   
/*     */   public List<ConstructorResolver> getConstructorResolvers() {
/* 128 */     return this.delegate.getConstructorResolvers();
/*     */   }
/*     */   
/*     */   public List<MethodResolver> getMethodResolvers() {
/* 132 */     return (this.methodResolvers == null) ? this.delegate.getMethodResolvers() : this.methodResolvers;
/*     */   }
/*     */   
/*     */   public List<PropertyAccessor> getPropertyAccessors() {
/* 136 */     return (this.propertyAccessors == null) ? this.delegate.getPropertyAccessors() : this.propertyAccessors;
/*     */   }
/*     */   
/*     */   public TypeLocator getTypeLocator() {
/* 140 */     return (this.typeLocator == null) ? this.delegate.getTypeLocator() : this.typeLocator;
/*     */   }
/*     */   
/*     */   public TypeConverter getTypeConverter() {
/* 144 */     return this.delegate.getTypeConverter();
/*     */   }
/*     */   
/*     */   public TypeComparator getTypeComparator() {
/* 148 */     return this.delegate.getTypeComparator();
/*     */   }
/*     */   
/*     */   public OperatorOverloader getOperatorOverloader() {
/* 152 */     return this.delegate.getOperatorOverloader();
/*     */   }
/*     */   
/*     */   public BeanResolver getBeanResolver() {
/* 156 */     return this.delegate.getBeanResolver();
/*     */   }
/*     */   
/*     */   public void setVariable(String name, Object value) {
/* 160 */     if (this.additionalVariables == null) {
/* 161 */       this.additionalVariables = new HashMap<>(5, 1.0F);
/*     */     }
/* 163 */     this.additionalVariables.put(name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object lookupVariable(String name) {
/* 168 */     if (this.expressionObjects != null && this.expressionObjects.containsObject(name)) {
/* 169 */       Object result = this.expressionObjects.getObject(name);
/* 170 */       if (result != null) {
/* 171 */         return result;
/*     */       }
/*     */     } 
/*     */     
/* 175 */     if (this.additionalVariables != null && this.additionalVariables.containsKey(name)) {
/* 176 */       Object result = this.additionalVariables.get(name);
/* 177 */       if (result != null) {
/* 178 */         return result;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 183 */     return this.delegate.lookupVariable(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVariableAccessRestricted() {
/* 189 */     return this.requestParametersRestricted;
/*     */   }
/*     */   
/*     */   public void setVariableAccessRestricted(boolean restricted) {
/* 193 */     this.requestParametersRestricted = restricted;
/*     */   }
/*     */   
/*     */   public IExpressionObjects getExpressionObjects() {
/* 197 */     return this.expressionObjects;
/*     */   }
/*     */   
/*     */   public void setExpressionObjects(IExpressionObjects expressionObjects) {
/* 201 */     this.expressionObjects = expressionObjects;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\expression\ThymeleafEvaluationContextWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */