/*     */ package org.thymeleaf.spring6.expression;
/*     */ 
/*     */ import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;
/*     */ import org.thymeleaf.exceptions.ConfigurationException;
/*     */ import org.thymeleaf.spring6.util.SpringVersionUtils;
/*     */ import org.thymeleaf.util.ClassLoaderUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Mvc
/*     */ {
/*     */   private static final MvcUriComponentsBuilderDelegate mvcUriComponentsBuilderDelegate;
/*  44 */   private static final String SPRING41_MVC_URI_COMPONENTS_BUILDER_DELEGATE_CLASS_NAME = Mvc.class.getName() + "$Spring41MvcUriComponentsBuilderDelegate";
/*  45 */   private static final String NON_SPRING41_MVC_URI_COMPONENTS_BUILDER_DELEGATE_CLASS_NAME = Mvc.class.getName() + "$NonSpring41MvcUriComponentsBuilderDelegate";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  53 */     String delegateClassName = SpringVersionUtils.isSpring41AtLeast() ? SPRING41_MVC_URI_COMPONENTS_BUILDER_DELEGATE_CLASS_NAME : NON_SPRING41_MVC_URI_COMPONENTS_BUILDER_DELEGATE_CLASS_NAME;
/*     */     
/*     */     try {
/*  56 */       Class<?> implClass = ClassLoaderUtils.loadClass(delegateClassName);
/*  57 */       mvcUriComponentsBuilderDelegate = implClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
/*  58 */     } catch (Exception e) {
/*  59 */       throw new ExceptionInInitializerError(new ConfigurationException("Thymeleaf could not initialize a delegate of class \"" + delegateClassName + "\" for taking care of the mvc expression utility object", e));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodArgumentBuilderWrapper url(String mappingName) {
/*  69 */     return mvcUriComponentsBuilderDelegate.fromMappingName(mappingName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class Spring41MvcUriComponentsBuilderDelegate
/*     */     implements MvcUriComponentsBuilderDelegate
/*     */   {
/*     */     public Mvc.MethodArgumentBuilderWrapper fromMappingName(String mappingName) {
/*  88 */       return new Mvc.Spring41MethodArgumentBuilderWrapper(MvcUriComponentsBuilder.fromMappingName(mappingName));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class NonSpring41MvcUriComponentsBuilderDelegate
/*     */     implements MvcUriComponentsBuilderDelegate
/*     */   {
/*     */     public Mvc.MethodArgumentBuilderWrapper fromMappingName(String mappingName) {
/* 101 */       throw new UnsupportedOperationException("MVC URI component building is only supported in Spring versions 4.1 or newer");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class Spring41MethodArgumentBuilderWrapper
/*     */     implements MethodArgumentBuilderWrapper
/*     */   {
/*     */     private final MvcUriComponentsBuilder.MethodArgumentBuilder builder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Spring41MethodArgumentBuilderWrapper(MvcUriComponentsBuilder.MethodArgumentBuilder builder) {
/* 127 */       this.builder = builder;
/*     */     }
/*     */     
/*     */     public Mvc.MethodArgumentBuilderWrapper arg(int index, Object value) {
/* 131 */       return new Spring41MethodArgumentBuilderWrapper(this.builder.arg(index, value));
/*     */     }
/*     */     
/*     */     public Mvc.MethodArgumentBuilderWrapper encode() {
/* 135 */       if (!SpringVersionUtils.isSpringAtLeast(5, 0, 8))
/* 136 */         throw new IllegalStateException(String.format("At least Spring version 5.0.8.RELEASE is needed for executing MvcUriComponentsBuilder#encode() but detected Spring version is %s.", new Object[] {
/*     */ 
/*     */                 
/* 139 */                 SpringVersionUtils.getSpringVersion()
/*     */               })); 
/* 141 */       return new Spring41MethodArgumentBuilderWrapper(this.builder.encode());
/*     */     }
/*     */     
/*     */     public String build() {
/* 145 */       return this.builder.build();
/*     */     }
/*     */     
/*     */     public String buildAndExpand(Object... uriVariables) {
/* 149 */       return this.builder.buildAndExpand(uriVariables);
/*     */     }
/*     */   }
/*     */   
/*     */   public static interface MethodArgumentBuilderWrapper {
/*     */     MethodArgumentBuilderWrapper arg(int param1Int, Object param1Object);
/*     */     
/*     */     MethodArgumentBuilderWrapper encode();
/*     */     
/*     */     String build();
/*     */     
/*     */     String buildAndExpand(Object... param1VarArgs);
/*     */   }
/*     */   
/*     */   static interface MvcUriComponentsBuilderDelegate {
/*     */     Mvc.MethodArgumentBuilderWrapper fromMappingName(String param1String);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\expression\Mvc.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */