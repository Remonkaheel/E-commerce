/*     */ package org.thymeleaf.spring6.expression;
/*     */ 
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.TypeLocator;
/*     */ import org.springframework.expression.spel.support.StandardTypeLocator;
/*     */ import org.thymeleaf.util.ExpressionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ThymeleafEvaluationContextACLTypeLocator
/*     */   implements TypeLocator
/*     */ {
/*     */   private final TypeLocator typeLocator;
/*     */   
/*     */   ThymeleafEvaluationContextACLTypeLocator() {
/* 169 */     this((TypeLocator)new StandardTypeLocator());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ThymeleafEvaluationContextACLTypeLocator(TypeLocator typeLocator) {
/* 175 */     this.typeLocator = typeLocator;
/* 176 */     if (this.typeLocator instanceof StandardTypeLocator)
/*     */     {
/*     */       
/* 179 */       ((StandardTypeLocator)this.typeLocator).removeImport("java.lang");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Class<?> findType(String typeName) throws EvaluationException {
/* 185 */     if (this.typeLocator == null) {
/* 186 */       throw new EvaluationException("Type could not be located (no type locator configured): " + typeName);
/*     */     }
/* 188 */     if (!ExpressionUtils.isTypeAllowed(typeName)) {
/* 189 */       throw new EvaluationException(
/* 190 */           String.format("Access is forbidden for type '%s' in this expression context.", new Object[] { typeName }));
/*     */     }
/* 192 */     return this.typeLocator.findType(typeName);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\expression\ThymeleafEvaluationContext$ThymeleafEvaluationContextACLTypeLocator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */