/*     */ package org.thymeleaf.spring6.expression;
/*     */ 
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.spel.SpelCompilerMode;
/*     */ import org.springframework.expression.spel.SpelParserConfiguration;
/*     */ import org.springframework.expression.spel.standard.SpelExpression;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.cache.ExpressionCacheKey;
/*     */ import org.thymeleaf.cache.ICache;
/*     */ import org.thymeleaf.cache.ICacheManager;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.expression.IExpressionObjects;
/*     */ import org.thymeleaf.spring6.context.IThymeleafBindStatus;
/*     */ import org.thymeleaf.spring6.util.FieldUtils;
/*     */ import org.thymeleaf.spring6.util.SpringStandardExpressionUtils;
/*     */ import org.thymeleaf.spring6.util.SpringValueFormatter;
/*     */ import org.thymeleaf.spring6.util.SpringVersionUtils;
/*     */ import org.thymeleaf.standard.expression.IStandardConversionService;
/*     */ import org.thymeleaf.standard.expression.IStandardVariableExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardVariableExpressionEvaluator;
/*     */ import org.thymeleaf.standard.expression.SelectionVariableExpression;
/*     */ import org.thymeleaf.standard.expression.StandardExpressionExecutionContext;
/*     */ import org.thymeleaf.standard.expression.StandardExpressions;
/*     */ import org.thymeleaf.standard.expression.VariableExpression;
/*     */ import org.thymeleaf.standard.util.StandardExpressionUtils;
/*     */ import org.thymeleaf.util.ClassLoaderUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SPELVariableExpressionEvaluator
/*     */   implements IStandardVariableExpressionEvaluator
/*     */ {
/*  75 */   public static final SPELVariableExpressionEvaluator INSTANCE = new SPELVariableExpressionEvaluator();
/*     */ 
/*     */   
/*     */   private static final String EXPRESSION_CACHE_TYPE_SPEL = "spel";
/*     */   
/*  80 */   private static final Logger logger = LoggerFactory.getLogger(SPELVariableExpressionEvaluator.class);
/*     */   
/*  82 */   private static final SpelExpressionParser PARSER_WITHOUT_COMPILED_SPEL = new SpelExpressionParser();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final SpelExpressionParser PARSER_WITH_COMPILED_SPEL;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  93 */     SpelExpressionParser spelCompilerExpressionParser = null;
/*  94 */     if (SpringVersionUtils.isSpring41AtLeast()) {
/*     */       
/*     */       try {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 101 */         SpelParserConfiguration spelParserConfiguration = new SpelParserConfiguration(SpelCompilerMode.MIXED, ClassLoaderUtils.getClassLoader(SPELVariableExpressionEvaluator.class));
/* 102 */         spelCompilerExpressionParser = new SpelExpressionParser(spelParserConfiguration);
/* 103 */       } catch (Throwable t) {
/* 104 */         if (logger.isDebugEnabled()) {
/*     */ 
/*     */           
/* 107 */           logger.warn("An error happened during the initialization of the Spring EL expression compiler. However, initialization was completed anyway. Note that compilation of SpEL expressions will not be available even if you configure your Spring dialect to use them.", t);
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 112 */           logger.warn("An error happened during the initialization of the Spring EL expression compiler. However, initialization was completed anyway. Note that compilation of SpEL expressions will not be available even if you configure your Spring dialect to use them. For more info, set your log to at least DEBUG level: " + t
/*     */ 
/*     */ 
/*     */               
/* 116 */               .getMessage());
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 121 */     PARSER_WITH_COMPILED_SPEL = spelCompilerExpressionParser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object evaluate(IExpressionContext context, IStandardVariableExpression expression, StandardExpressionExecutionContext expContext) {
/* 138 */     if (logger.isTraceEnabled()) {
/* 139 */       logger.trace("[THYMELEAF][{}] SpringEL expression: evaluating expression \"{}\" on target", TemplateEngine.threadIndex(), expression.getExpression());
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 144 */       String spelExpression = expression.getExpression();
/* 145 */       boolean useSelectionAsRoot = expression.getUseSelectionAsRoot();
/*     */       
/* 147 */       if (spelExpression == null) {
/* 148 */         throw new TemplateProcessingException("Expression content is null, which is not allowed");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 154 */       if (expContext.getPerformTypeConversion())
/*     */       {
/*     */         
/* 157 */         if (useSelectionAsRoot || !isLocalVariableOverriding(context, spelExpression)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 164 */           IThymeleafBindStatus bindStatus = FieldUtils.getBindStatusFromParsedExpression(context, true, useSelectionAsRoot, spelExpression);
/*     */           
/* 166 */           if (bindStatus != null)
/*     */           {
/* 168 */             return SpringValueFormatter.getDisplayString(bindStatus.getValue(), bindStatus.getEditor(), false);
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 175 */       IEngineConfiguration configuration = context.getConfiguration();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 182 */       ComputedSpelExpression exp = obtainComputedSpelExpression(configuration, expression, spelExpression, expContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 192 */       IExpressionObjects expressionObjects = exp.mightNeedExpressionObjects ? context.getExpressionObjects() : null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 200 */       EvaluationContext evaluationContext = (EvaluationContext)context.getVariable("thymeleaf::EvaluationContext");
/*     */       
/* 202 */       if (evaluationContext == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 214 */         evaluationContext = new ThymeleafEvaluationContextWrapper((EvaluationContext)new StandardEvaluationContext());
/*     */         
/* 216 */         if (context instanceof IEngineContext) {
/* 217 */           ((IEngineContext)context).setVariable("thymeleaf::EvaluationContext", evaluationContext);
/*     */         
/*     */         }
/*     */       }
/* 221 */       else if (!(evaluationContext instanceof IThymeleafEvaluationContext)) {
/*     */         
/* 223 */         evaluationContext = new ThymeleafEvaluationContextWrapper(evaluationContext);
/*     */         
/* 225 */         if (context instanceof IEngineContext) {
/* 226 */           ((IEngineContext)context).setVariable("thymeleaf::EvaluationContext", evaluationContext);
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 239 */       IThymeleafEvaluationContext thymeleafEvaluationContext = (IThymeleafEvaluationContext)evaluationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 248 */       thymeleafEvaluationContext.setExpressionObjects(expressionObjects);
/* 249 */       thymeleafEvaluationContext.setVariableAccessRestricted(expContext.getRestrictVariableAccess());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 255 */       ITemplateContext templateContext = (context instanceof ITemplateContext) ? (ITemplateContext)context : null;
/*     */ 
/*     */       
/* 258 */       Object evaluationRoot = (useSelectionAsRoot && templateContext != null && templateContext.hasSelectionTarget()) ? templateContext.getSelectionTarget() : new SPELContextMapWrapper((IContext)context, thymeleafEvaluationContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 264 */       if (!expContext.getPerformTypeConversion()) {
/* 265 */         return exp.expression.getValue(thymeleafEvaluationContext, evaluationRoot);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 273 */       IStandardConversionService conversionService = StandardExpressions.getConversionService(configuration);
/*     */       
/* 275 */       if (conversionService instanceof SpringStandardConversionService)
/*     */       {
/*     */ 
/*     */         
/* 279 */         return exp.expression.getValue(thymeleafEvaluationContext, evaluationRoot, String.class);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 284 */       Object result = exp.expression.getValue(thymeleafEvaluationContext, evaluationRoot);
/* 285 */       return conversionService.convert(context, result, String.class);
/*     */     
/*     */     }
/* 288 */     catch (TemplateProcessingException e) {
/* 289 */       throw e;
/* 290 */     } catch (Exception e) {
/* 291 */       throw new TemplateProcessingException("Exception evaluating SpringEL expression: \"" + expression
/* 292 */           .getExpression() + "\"", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ComputedSpelExpression obtainComputedSpelExpression(IEngineConfiguration configuration, IStandardVariableExpression expression, String spelExpression, StandardExpressionExecutionContext expContext) {
/* 307 */     if (expContext.getRestrictInstantiationAndStatic() && 
/* 308 */       SpringStandardExpressionUtils.containsSpELInstantiationOrStaticOrParam(spelExpression)) {
/* 309 */       throw new TemplateProcessingException("Instantiation of new objects and access to static classes or parameters is forbidden in this context");
/*     */     }
/*     */ 
/*     */     
/* 313 */     if (expression instanceof VariableExpression) {
/*     */       
/* 315 */       VariableExpression vexpression = (VariableExpression)expression;
/*     */       
/* 317 */       Object cachedExpression = vexpression.getCachedExpression();
/* 318 */       if (cachedExpression != null && cachedExpression instanceof ComputedSpelExpression) {
/* 319 */         return (ComputedSpelExpression)cachedExpression;
/*     */       }
/* 321 */       cachedExpression = getExpression(configuration, spelExpression);
/* 322 */       if (cachedExpression != null) {
/* 323 */         vexpression.setCachedExpression(cachedExpression);
/*     */       }
/* 325 */       return (ComputedSpelExpression)cachedExpression;
/*     */     } 
/*     */ 
/*     */     
/* 329 */     if (expression instanceof SelectionVariableExpression) {
/*     */       
/* 331 */       SelectionVariableExpression vexpression = (SelectionVariableExpression)expression;
/*     */       
/* 333 */       Object cachedExpression = vexpression.getCachedExpression();
/* 334 */       if (cachedExpression != null && cachedExpression instanceof ComputedSpelExpression) {
/* 335 */         return (ComputedSpelExpression)cachedExpression;
/*     */       }
/* 337 */       cachedExpression = getExpression(configuration, spelExpression);
/* 338 */       if (cachedExpression != null) {
/* 339 */         vexpression.setCachedExpression(cachedExpression);
/*     */       }
/* 341 */       return (ComputedSpelExpression)cachedExpression;
/*     */     } 
/*     */ 
/*     */     
/* 345 */     return getExpression(configuration, spelExpression);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ComputedSpelExpression getExpression(IEngineConfiguration configuration, String spelExpression) {
/* 353 */     ComputedSpelExpression exp = null;
/* 354 */     ICache<ExpressionCacheKey, Object> cache = null;
/*     */     
/* 356 */     ICacheManager cacheManager = configuration.getCacheManager();
/* 357 */     if (cacheManager != null) {
/* 358 */       cache = cacheManager.getExpressionCache();
/* 359 */       if (cache != null) {
/* 360 */         exp = (ComputedSpelExpression)cache.get(new ExpressionCacheKey("spel", spelExpression));
/*     */       }
/*     */     } 
/*     */     
/* 364 */     if (exp == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 369 */       SpelExpressionParser spelExpressionParser = (PARSER_WITH_COMPILED_SPEL != null && SpringStandardExpressions.isSpringELCompilerEnabled(configuration)) ? PARSER_WITH_COMPILED_SPEL : PARSER_WITHOUT_COMPILED_SPEL;
/*     */       
/* 371 */       boolean mightNeedExpressionObjects = StandardExpressionUtils.mightNeedExpressionObjects(spelExpression);
/*     */       
/* 373 */       SpelExpression spelExpressionObject = (SpelExpression)spelExpressionParser.parseExpression(spelExpression);
/*     */       
/* 375 */       exp = new ComputedSpelExpression(spelExpressionObject, mightNeedExpressionObjects);
/*     */       
/* 377 */       if (cache != null && null != exp) {
/* 378 */         cache.put(new ExpressionCacheKey("spel", spelExpression), exp);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 383 */     return exp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isLocalVariableOverriding(IExpressionContext context, String expression) {
/* 391 */     if (!(context instanceof IEngineContext))
/*     */     {
/* 393 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 397 */     IEngineContext engineContext = (IEngineContext)context;
/*     */     
/* 399 */     int dotPos = expression.indexOf('.');
/* 400 */     if (dotPos == -1) {
/* 401 */       return false;
/*     */     }
/*     */     
/* 404 */     String expressionFirstComponent = expression.substring(0, dotPos);
/* 405 */     return engineContext.isVariableLocal(expressionFirstComponent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 414 */     return "SpringEL";
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class ComputedSpelExpression
/*     */   {
/*     */     final SpelExpression expression;
/*     */     
/*     */     final boolean mightNeedExpressionObjects;
/*     */ 
/*     */     
/*     */     ComputedSpelExpression(SpelExpression expression, boolean mightNeedExpressionObjects) {
/* 426 */       this.expression = expression;
/* 427 */       this.mightNeedExpressionObjects = mightNeedExpressionObjects;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\expression\SPELVariableExpressionEvaluator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */