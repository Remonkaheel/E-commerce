package org.thymeleaf.spring6.expression;

public interface MethodArgumentBuilderWrapper {
  MethodArgumentBuilderWrapper arg(int paramInt, Object paramObject);
  
  MethodArgumentBuilderWrapper encode();
  
  String build();
  
  String buildAndExpand(Object... paramVarArgs);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\expression\Mvc$MethodArgumentBuilderWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */