/*     */ package org.thymeleaf.spring6.expression;
/*     */ 
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.TypedValue;
/*     */ import org.thymeleaf.context.IContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SPELContextPropertyAccessor
/*     */   implements PropertyAccessor
/*     */ {
/*  50 */   private static final Logger LOGGER = LoggerFactory.getLogger(SPELContextPropertyAccessor.class);
/*     */   
/*  52 */   static final SPELContextPropertyAccessor INSTANCE = new SPELContextPropertyAccessor();
/*     */   
/*     */   private static final String REQUEST_PARAMETERS_RESTRICTED_VARIABLE_NAME = "param";
/*  55 */   private static final Class<?>[] TARGET_CLASSES = new Class[] { IContext.class };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?>[] getSpecificTargetClasses() {
/*  66 */     return TARGET_CLASSES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRead(EvaluationContext context, Object target, String name) throws AccessException {
/*  73 */     if (context instanceof IThymeleafEvaluationContext && (
/*  74 */       (IThymeleafEvaluationContext)context).isVariableAccessRestricted() && 
/*  75 */       "param".equals(name)) {
/*  76 */       throw new AccessException("Access to variable \"" + name + "\" is forbidden in this context. Note some restrictions apply to variable access. For example, direct access to request parameters is forbidden in preprocessing and unescaped expressions, in TEXT template mode, in fragment insertion specifications and in some specific attribute processors.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     return (target != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypedValue read(EvaluationContext evaluationContext, Object target, String name) throws AccessException {
/*  92 */     if (target == null) {
/*  93 */       throw new AccessException("Cannot read property of null target");
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  98 */       IContext context = (IContext)target;
/*  99 */       return new TypedValue(context.getVariable(name));
/*     */     }
/* 101 */     catch (ClassCastException e) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 106 */       throw new AccessException("Cannot read target of class " + target.getClass().getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canWrite(EvaluationContext context, Object target, String name) throws AccessException {
/* 118 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(EvaluationContext context, Object target, String name, Object newValue) throws AccessException {
/* 127 */     throw new AccessException("Cannot write to " + IContext.class.getName());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\expression\SPELContextPropertyAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */