/*    */ package org.thymeleaf.spring6.expression;
/*    */ 
/*    */ import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Spring41MvcUriComponentsBuilderDelegate
/*    */   implements Mvc.MvcUriComponentsBuilderDelegate
/*    */ {
/*    */   public Mvc.MethodArgumentBuilderWrapper fromMappingName(String mappingName) {
/* 88 */     return new Mvc.Spring41MethodArgumentBuilderWrapper(MvcUriComponentsBuilder.fromMappingName(mappingName));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\expression\Mvc$Spring41MvcUriComponentsBuilderDelegate.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */