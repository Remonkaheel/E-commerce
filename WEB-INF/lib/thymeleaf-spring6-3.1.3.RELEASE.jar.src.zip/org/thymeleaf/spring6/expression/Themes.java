/*    */ package org.thymeleaf.spring6.expression;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.springframework.ui.context.Theme;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ import org.thymeleaf.spring6.context.IThymeleafRequestContext;
/*    */ import org.thymeleaf.spring6.context.SpringContextUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class Themes
/*    */ {
/*    */   private final Theme theme;
/*    */   private final Locale locale;
/*    */   
/*    */   public Themes(IExpressionContext context) {
/* 55 */     this.locale = context.getLocale();
/* 56 */     IThymeleafRequestContext requestContext = SpringContextUtils.getRequestContext(context);
/* 57 */     this.theme = (requestContext != null) ? requestContext.getTheme() : null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String code(String code) {
/* 69 */     if (this.theme == null) {
/* 70 */       throw new TemplateProcessingException("Theme cannot be resolved because RequestContext was not found. Are you using a Context object without a RequestContext variable?");
/*    */     }
/*    */     
/* 73 */     return this.theme.getMessageSource().getMessage(code, null, "", this.locale);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\expression\Themes.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */