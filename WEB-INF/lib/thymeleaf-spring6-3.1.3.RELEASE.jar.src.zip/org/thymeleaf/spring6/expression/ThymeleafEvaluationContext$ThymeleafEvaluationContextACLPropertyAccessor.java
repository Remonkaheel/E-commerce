/*     */ package org.thymeleaf.spring6.expression;
/*     */ 
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.spel.support.ReflectivePropertyAccessor;
/*     */ import org.thymeleaf.util.ExpressionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ThymeleafEvaluationContextACLPropertyAccessor
/*     */   extends ReflectivePropertyAccessor
/*     */ {
/*     */   private final ReflectivePropertyAccessor propertyAccessor;
/*     */   
/*     */   ThymeleafEvaluationContextACLPropertyAccessor() {
/* 204 */     this(null);
/*     */   }
/*     */   
/*     */   ThymeleafEvaluationContextACLPropertyAccessor(ReflectivePropertyAccessor propertyAccessor) {
/* 208 */     super(false);
/*     */     
/* 210 */     this.propertyAccessor = propertyAccessor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canRead(EvaluationContext context, Object targetObject, String name) throws AccessException {
/*     */     boolean canRead;
/* 218 */     if (this.propertyAccessor != null) {
/* 219 */       canRead = this.propertyAccessor.canRead(context, targetObject, name);
/*     */     } else {
/* 221 */       canRead = super.canRead(context, targetObject, name);
/*     */     } 
/*     */     
/* 224 */     if (canRead) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 229 */       String methodEquiv = ("empty".equals(name) || "blank".equals(name)) ? ("is" + Character.toUpperCase(name.charAt(0)) + name.substring(1)) : ("get" + Character.toUpperCase(name.charAt(0)) + name.substring(1));
/*     */       
/* 231 */       if (!ExpressionUtils.isMemberAllowed(targetObject, methodEquiv)) {
/* 232 */         throw new EvaluationException(
/* 233 */             String.format("Accessing member '%s' is forbidden for type '%s' in this expression context.", new Object[] {
/*     */                 
/* 235 */                 name, targetObject.getClass()
/*     */               }));
/*     */       }
/*     */     } 
/* 239 */     return canRead;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\expression\ThymeleafEvaluationContext$ThymeleafEvaluationContextACLPropertyAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */