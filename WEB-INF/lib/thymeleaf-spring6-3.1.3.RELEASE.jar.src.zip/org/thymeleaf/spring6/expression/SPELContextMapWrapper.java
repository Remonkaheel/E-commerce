/*     */ package org.thymeleaf.spring6.expression;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SPELContextMapWrapper
/*     */   implements Map
/*     */ {
/*     */   private static final String REQUEST_PARAMETERS_RESTRICTED_VARIABLE_NAME = "param";
/*     */   private final IContext context;
/*     */   private final IThymeleafEvaluationContext evaluationContext;
/*     */   
/*     */   SPELContextMapWrapper(IContext context, IThymeleafEvaluationContext evaluationContext) {
/*  53 */     this.context = context;
/*  54 */     this.evaluationContext = evaluationContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  66 */     throw new TemplateProcessingException("Cannot call #size() on an " + IContext.class
/*  67 */         .getSimpleName() + " implementation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/*  74 */     throw new TemplateProcessingException("Cannot call #isEmpty() on an " + IContext.class
/*  75 */         .getSimpleName() + " implementation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsKey(Object key) {
/*  82 */     if (this.evaluationContext.isVariableAccessRestricted() && 
/*  83 */       "param".equals(key)) {
/*  84 */       throw new TemplateProcessingException("Access to variable \"" + key + "\" is forbidden in this context. Note some restrictions apply to variable access. For example, direct access to request parameters is forbidden in preprocessing and unescaped expressions, in TEXT template mode, in fragment insertion specifications and in some specific attribute processors.");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     return (this.context != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsValue(Object value) {
/* 101 */     throw new TemplateProcessingException("Cannot call #containsValue(value) on an " + IContext.class
/* 102 */         .getSimpleName() + " implementation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object get(Object key) {
/* 110 */     if (this.context == null) {
/* 111 */       throw new TemplateProcessingException("Cannot read property on null target");
/*     */     }
/*     */     
/* 114 */     return this.context.getVariable((key == null) ? null : key.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object put(Object key, Object value) {
/* 122 */     throw new TemplateProcessingException("Cannot call #put(key,value) on an " + IContext.class
/* 123 */         .getSimpleName() + " implementation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object remove(Object key) {
/* 130 */     throw new TemplateProcessingException("Cannot call #remove(key) on an " + IContext.class
/* 131 */         .getSimpleName() + " implementation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putAll(Map m) {
/* 138 */     throw new TemplateProcessingException("Cannot call #putAll(m) on an " + IContext.class
/* 139 */         .getSimpleName() + " implementation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 146 */     throw new TemplateProcessingException("Cannot call #clear() on an " + IContext.class
/* 147 */         .getSimpleName() + " implementation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set keySet() {
/* 154 */     throw new TemplateProcessingException("Cannot call #keySet() on an " + IContext.class
/* 155 */         .getSimpleName() + " implementation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection values() {
/* 162 */     throw new TemplateProcessingException("Cannot call #values() on an " + IContext.class
/* 163 */         .getSimpleName() + " implementation");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<Map.Entry> entrySet() {
/* 170 */     throw new TemplateProcessingException("Cannot call #entrySet() on an " + IContext.class
/* 171 */         .getSimpleName() + " implementation");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\expression\SPELContextMapWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */