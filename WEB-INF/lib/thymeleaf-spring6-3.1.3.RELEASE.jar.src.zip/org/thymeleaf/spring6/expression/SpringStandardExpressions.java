/*    */ package org.thymeleaf.spring6.expression;
/*    */ 
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringStandardExpressions
/*    */ {
/*    */   public static final String ENABLE_SPRING_EL_COMPILER_ATTRIBUTE_NAME = "EnableSpringELCompiler";
/*    */   
/*    */   public static boolean isSpringELCompilerEnabled(IEngineConfiguration configuration) {
/* 68 */     Object enableSpringELCompiler = configuration.getExecutionAttributes().get("EnableSpringELCompiler");
/* 69 */     if (enableSpringELCompiler == null) {
/* 70 */       return false;
/*    */     }
/* 72 */     if (!(enableSpringELCompiler instanceof Boolean)) {
/* 73 */       throw new TemplateProcessingException("A value for the \"EnableSpringELCompiler\" execution attribute has been specified, but it is not of the required type Boolean. (" + enableSpringELCompiler
/*    */ 
/*    */           
/* 76 */           .getClass().getName() + ")");
/*    */     }
/* 78 */     return ((Boolean)enableSpringELCompiler).booleanValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\expression\SpringStandardExpressions.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */