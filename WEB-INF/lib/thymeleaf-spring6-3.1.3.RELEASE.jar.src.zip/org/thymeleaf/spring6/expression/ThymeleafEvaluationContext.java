/*     */ package org.thymeleaf.spring6.expression;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.expression.BeanFactoryResolver;
/*     */ import org.springframework.context.expression.MapAccessor;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.expression.AccessException;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.EvaluationException;
/*     */ import org.springframework.expression.MethodExecutor;
/*     */ import org.springframework.expression.MethodResolver;
/*     */ import org.springframework.expression.PropertyAccessor;
/*     */ import org.springframework.expression.TypeConverter;
/*     */ import org.springframework.expression.TypeLocator;
/*     */ import org.springframework.expression.spel.support.ReflectiveMethodResolver;
/*     */ import org.springframework.expression.spel.support.ReflectivePropertyAccessor;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.expression.spel.support.StandardTypeConverter;
/*     */ import org.springframework.expression.spel.support.StandardTypeLocator;
/*     */ import org.thymeleaf.expression.IExpressionObjects;
/*     */ import org.thymeleaf.util.ExpressionUtils;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ThymeleafEvaluationContext
/*     */   extends StandardEvaluationContext
/*     */   implements IThymeleafEvaluationContext
/*     */ {
/*     */   public static final String THYMELEAF_EVALUATION_CONTEXT_CONTEXT_VARIABLE_NAME = "thymeleaf::EvaluationContext";
/*  82 */   private static final ReflectivePropertyAccessor REFLECTIVE_PROPERTY_ACCESSOR_INSTANCE = new ThymeleafEvaluationContextACLPropertyAccessor();
/*     */   
/*  84 */   private static final MapAccessor MAP_ACCESSOR_INSTANCE = new MapAccessor();
/*  85 */   private static final TypeLocator TYPE_LOCATOR = new ThymeleafEvaluationContextACLTypeLocator();
/*     */   
/*  87 */   private static final List<MethodResolver> METHOD_RESOLVERS = (List)Collections.singletonList(new ThymeleafEvaluationContextACLMethodResolver());
/*     */ 
/*     */   
/*     */   private final ApplicationContext applicationContext;
/*     */   
/*  92 */   private IExpressionObjects expressionObjects = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean variableAccessRestricted = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ThymeleafEvaluationContext(ApplicationContext applicationContext, ConversionService conversionService) {
/* 102 */     Validate.notNull(applicationContext, "Application Context cannot be null");
/*     */ 
/*     */     
/* 105 */     this.applicationContext = applicationContext;
/* 106 */     setBeanResolver((BeanResolver)new BeanFactoryResolver((BeanFactory)applicationContext));
/* 107 */     if (conversionService != null) {
/* 108 */       setTypeConverter((TypeConverter)new StandardTypeConverter(conversionService));
/*     */     }
/*     */     
/* 111 */     List<PropertyAccessor> propertyAccessors = new ArrayList<>(5);
/* 112 */     propertyAccessors.add(SPELContextPropertyAccessor.INSTANCE);
/* 113 */     propertyAccessors.add(MAP_ACCESSOR_INSTANCE);
/* 114 */     propertyAccessors.add(REFLECTIVE_PROPERTY_ACCESSOR_INSTANCE);
/* 115 */     setPropertyAccessors(propertyAccessors);
/*     */ 
/*     */     
/* 118 */     setTypeLocator(TYPE_LOCATOR);
/*     */ 
/*     */     
/* 121 */     setMethodResolvers(METHOD_RESOLVERS);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ApplicationContext getApplicationContext() {
/* 127 */     return this.applicationContext;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object lookupVariable(String name) {
/* 133 */     if (this.expressionObjects != null && this.expressionObjects.containsObject(name)) {
/* 134 */       Object result = this.expressionObjects.getObject(name);
/* 135 */       if (result != null) {
/* 136 */         return result;
/*     */       }
/*     */     } 
/*     */     
/* 140 */     return super.lookupVariable(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVariableAccessRestricted() {
/* 147 */     return this.variableAccessRestricted;
/*     */   }
/*     */   
/*     */   public void setVariableAccessRestricted(boolean restricted) {
/* 151 */     this.variableAccessRestricted = restricted;
/*     */   }
/*     */   
/*     */   public IExpressionObjects getExpressionObjects() {
/* 155 */     return this.expressionObjects;
/*     */   }
/*     */   
/*     */   public void setExpressionObjects(IExpressionObjects expressionObjects) {
/* 159 */     this.expressionObjects = expressionObjects;
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ThymeleafEvaluationContextACLTypeLocator
/*     */     implements TypeLocator
/*     */   {
/*     */     private final TypeLocator typeLocator;
/*     */     
/*     */     ThymeleafEvaluationContextACLTypeLocator() {
/* 169 */       this((TypeLocator)new StandardTypeLocator());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     ThymeleafEvaluationContextACLTypeLocator(TypeLocator typeLocator) {
/* 175 */       this.typeLocator = typeLocator;
/* 176 */       if (this.typeLocator instanceof StandardTypeLocator)
/*     */       {
/*     */         
/* 179 */         ((StandardTypeLocator)this.typeLocator).removeImport("java.lang");
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public Class<?> findType(String typeName) throws EvaluationException {
/* 185 */       if (this.typeLocator == null) {
/* 186 */         throw new EvaluationException("Type could not be located (no type locator configured): " + typeName);
/*     */       }
/* 188 */       if (!ExpressionUtils.isTypeAllowed(typeName)) {
/* 189 */         throw new EvaluationException(
/* 190 */             String.format("Access is forbidden for type '%s' in this expression context.", new Object[] { typeName }));
/*     */       }
/* 192 */       return this.typeLocator.findType(typeName);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static final class ThymeleafEvaluationContextACLPropertyAccessor
/*     */     extends ReflectivePropertyAccessor
/*     */   {
/*     */     private final ReflectivePropertyAccessor propertyAccessor;
/*     */ 
/*     */     
/*     */     ThymeleafEvaluationContextACLPropertyAccessor() {
/* 204 */       this(null);
/*     */     }
/*     */     
/*     */     ThymeleafEvaluationContextACLPropertyAccessor(ReflectivePropertyAccessor propertyAccessor) {
/* 208 */       super(false);
/*     */       
/* 210 */       this.propertyAccessor = propertyAccessor;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean canRead(EvaluationContext context, Object targetObject, String name) throws AccessException {
/*     */       boolean canRead;
/* 218 */       if (this.propertyAccessor != null) {
/* 219 */         canRead = this.propertyAccessor.canRead(context, targetObject, name);
/*     */       } else {
/* 221 */         canRead = super.canRead(context, targetObject, name);
/*     */       } 
/*     */       
/* 224 */       if (canRead) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 229 */         String methodEquiv = ("empty".equals(name) || "blank".equals(name)) ? ("is" + Character.toUpperCase(name.charAt(0)) + name.substring(1)) : ("get" + Character.toUpperCase(name.charAt(0)) + name.substring(1));
/*     */         
/* 231 */         if (!ExpressionUtils.isMemberAllowed(targetObject, methodEquiv)) {
/* 232 */           throw new EvaluationException(
/* 233 */               String.format("Accessing member '%s' is forbidden for type '%s' in this expression context.", new Object[] {
/*     */                   
/* 235 */                   name, targetObject.getClass()
/*     */                 }));
/*     */         }
/*     */       } 
/* 239 */       return canRead;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class ThymeleafEvaluationContextACLMethodResolver
/*     */     extends ReflectiveMethodResolver
/*     */   {
/*     */     private final ReflectiveMethodResolver methodResolver;
/*     */ 
/*     */     
/*     */     ThymeleafEvaluationContextACLMethodResolver() {
/* 252 */       this(null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     ThymeleafEvaluationContextACLMethodResolver(ReflectiveMethodResolver methodResolver) {
/* 258 */       this.methodResolver = methodResolver;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MethodExecutor resolve(EvaluationContext context, Object targetObject, String name, List<TypeDescriptor> argumentTypes) throws AccessException {
/*     */       MethodExecutor methodExecutor;
/* 267 */       if (this.methodResolver != null) {
/* 268 */         methodExecutor = this.methodResolver.resolve(context, targetObject, name, argumentTypes);
/*     */       } else {
/* 270 */         methodExecutor = super.resolve(context, targetObject, name, argumentTypes);
/*     */       } 
/*     */       
/* 273 */       if (methodExecutor != null && 
/* 274 */         !ExpressionUtils.isMemberAllowed(targetObject, name)) {
/* 275 */         throw new EvaluationException(
/* 276 */             String.format("Calling method '%s' is forbidden for type '%s' in this expression context.", new Object[] {
/*     */                 
/* 278 */                 name, targetObject.getClass()
/*     */               }));
/*     */       }
/*     */       
/* 282 */       return methodExecutor;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\expression\ThymeleafEvaluationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */