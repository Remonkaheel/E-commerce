/*    */ package org.thymeleaf.spring6.templateresolver;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.thymeleaf.IEngineConfiguration;
/*    */ import org.thymeleaf.spring6.templateresource.SpringResourceTemplateResource;
/*    */ import org.thymeleaf.templateresolver.AbstractConfigurableTemplateResolver;
/*    */ import org.thymeleaf.templateresource.ITemplateResource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringResourceTemplateResolver
/*    */   extends AbstractConfigurableTemplateResolver
/*    */   implements ApplicationContextAware
/*    */ {
/* 50 */   private ApplicationContext applicationContext = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/* 61 */     this.applicationContext = applicationContext;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ITemplateResource computeTemplateResource(IEngineConfiguration configuration, String ownerTemplate, String template, String resourceName, String characterEncoding, Map<String, Object> templateResolutionAttributes) {
/* 69 */     return (ITemplateResource)new SpringResourceTemplateResource(this.applicationContext, resourceName, characterEncoding);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\templateresolver\SpringResourceTemplateResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */