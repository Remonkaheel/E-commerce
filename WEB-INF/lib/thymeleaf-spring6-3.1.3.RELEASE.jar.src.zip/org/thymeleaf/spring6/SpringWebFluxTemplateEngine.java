/*     */ package org.thymeleaf.spring6;
/*     */ 
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.core.io.buffer.DataBufferFactory;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.thymeleaf.IThrottledTemplateProcessor;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.TemplateSpec;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.context.IEngineContext;
/*     */ import org.thymeleaf.context.IWebContext;
/*     */ import org.thymeleaf.engine.DataDrivenTemplateIterator;
/*     */ import org.thymeleaf.engine.IThrottledTemplateWriterControl;
/*     */ import org.thymeleaf.engine.ThrottledTemplateProcessor;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.spring6.context.Contexts;
/*     */ import org.thymeleaf.spring6.context.webflux.IReactiveDataDriverContextVariable;
/*     */ import org.thymeleaf.spring6.context.webflux.IReactiveSSEDataDriverContextVariable;
/*     */ import org.thymeleaf.util.LoggingUtils;
/*     */ import org.thymeleaf.web.IWebExchange;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.MonoSink;
/*     */ import reactor.core.publisher.SynchronousSink;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringWebFluxTemplateEngine
/*     */   extends SpringTemplateEngine
/*     */   implements ISpringWebFluxTemplateEngine
/*     */ {
/*  79 */   private static final Logger logger = LoggerFactory.getLogger(SpringWebFluxTemplateEngine.class);
/*  80 */   private static final String LOG_CATEGORY_FULL_OUTPUT = SpringWebFluxTemplateEngine.class.getName() + ".DOWNSTREAM.FULL";
/*  81 */   private static final String LOG_CATEGORY_CHUNKED_OUTPUT = SpringWebFluxTemplateEngine.class.getName() + ".DOWNSTREAM.CHUNKED";
/*  82 */   private static final String LOG_CATEGORY_DATADRIVEN_INPUT = SpringWebFluxTemplateEngine.class.getName() + ".UPSTREAM.DATA-DRIVEN";
/*  83 */   private static final String LOG_CATEGORY_DATADRIVEN_OUTPUT = SpringWebFluxTemplateEngine.class.getName() + ".DOWNSTREAM.DATA-DRIVEN";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Publisher<DataBuffer> processStream(String template, Set<String> markupSelectors, IContext context, DataBufferFactory bufferFactory, MediaType mediaType, Charset charset) {
/*  99 */     return processStream(template, markupSelectors, context, bufferFactory, mediaType, charset, 2147483647);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Publisher<DataBuffer> processStream(String template, Set<String> markupSelectors, IContext context, DataBufferFactory bufferFactory, MediaType mediaType, Charset charset, int responseMaxChunkSizeBytes) {
/* 112 */     if (template == null) {
/* 113 */       return (Publisher<DataBuffer>)Flux.error(new IllegalArgumentException("Template cannot be null"));
/*     */     }
/* 115 */     if (context == null) {
/* 116 */       return (Publisher<DataBuffer>)Flux.error(new IllegalArgumentException("Context cannot be null"));
/*     */     }
/* 118 */     if (bufferFactory == null) {
/* 119 */       return (Publisher<DataBuffer>)Flux.error(new IllegalArgumentException("Buffer Factory cannot be null"));
/*     */     }
/* 121 */     if (mediaType == null) {
/* 122 */       return (Publisher<DataBuffer>)Flux.error(new IllegalArgumentException("Media Type cannot be null"));
/*     */     }
/* 124 */     if (charset == null) {
/* 125 */       return (Publisher<DataBuffer>)Flux.error(new IllegalArgumentException("Charset cannot be null"));
/*     */     }
/*     */     
/* 128 */     if (responseMaxChunkSizeBytes == 0) {
/* 129 */       return (Publisher<DataBuffer>)Flux.error(new IllegalArgumentException("Max Chunk Size cannot be zero"));
/*     */     }
/*     */ 
/*     */     
/* 133 */     int chunkSizeBytes = (responseMaxChunkSizeBytes < 0) ? Integer.MAX_VALUE : responseMaxChunkSizeBytes;
/*     */ 
/*     */     
/* 136 */     boolean sse = MediaType.TEXT_EVENT_STREAM.includes(mediaType);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 142 */       String dataDriverVariableName = findDataDriverInModel(context);
/* 143 */       if (dataDriverVariableName != null)
/*     */       {
/* 145 */         return (Publisher<DataBuffer>)createDataDrivenStream(template, markupSelectors, context, dataDriverVariableName, bufferFactory, charset, chunkSizeBytes, sse);
/*     */       }
/*     */     }
/* 148 */     catch (Throwable t) {
/* 149 */       return (Publisher<DataBuffer>)Flux.error(t);
/*     */     } 
/*     */ 
/*     */     
/* 153 */     if (sse) {
/* 154 */       return (Publisher<DataBuffer>)Flux.error((Throwable)new TemplateProcessingException("SSE mode has been requested ('Accept: text/event-stream') but no data-driver variable has been added to the model/context. In order to perform SSE rendering, a variable implementing the " + IReactiveDataDriverContextVariable.class
/*     */ 
/*     */             
/* 157 */             .getName() + " interface is required."));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     if (chunkSizeBytes == Integer.MAX_VALUE)
/*     */     {
/* 165 */       return (Publisher<DataBuffer>)createFullStream(template, markupSelectors, context, bufferFactory, charset);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 171 */     return (Publisher<DataBuffer>)createChunkedStream(template, markupSelectors, context, bufferFactory, charset, responseMaxChunkSizeBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Mono<DataBuffer> createFullStream(String templateName, Set<String> markupSelectors, IContext context, DataBufferFactory bufferFactory, Charset charset) {
/* 184 */     Mono<DataBuffer> stream = Mono.create(subscriber -> {
/*     */           if (logger.isTraceEnabled()) {
/*     */             logger.trace("[THYMELEAF][{}] STARTING STREAM PROCESS (FULL MODE) OF TEMPLATE \"{}\" WITH LOCALE {}", new Object[] { TemplateEngine.threadIndex(), LoggingUtils.loggifyTemplateName(templateName), context.getLocale() });
/*     */           }
/*     */ 
/*     */ 
/*     */           
/*     */           DataBuffer dataBuffer = bufferFactory.allocateBuffer(1024);
/*     */ 
/*     */ 
/*     */           
/*     */           OutputStreamWriter writer = new OutputStreamWriter(dataBuffer.asOutputStream(), charset);
/*     */ 
/*     */           
/*     */           try {
/*     */             process(templateName, markupSelectors, context, writer);
/* 200 */           } catch (Throwable t) {
/*     */             logger.error(String.format("[THYMELEAF][%s] Exception processing template \"%s\": %s", new Object[] { TemplateEngine.threadIndex(), LoggingUtils.loggifyTemplateName(templateName), t.getMessage() }), t);
/*     */ 
/*     */ 
/*     */             
/*     */             subscriber.error(t);
/*     */ 
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/*     */           int bytesProduced = dataBuffer.readableByteCount();
/*     */ 
/*     */           
/*     */           if (logger.isTraceEnabled()) {
/*     */             logger.trace("[THYMELEAF][{}] FINISHED STREAM PROCESS (FULL MODE) OF TEMPLATE \"{}\" WITH LOCALE {}. PRODUCED {} BYTES", new Object[] { TemplateEngine.threadIndex(), LoggingUtils.loggifyTemplateName(templateName), context.getLocale(), Integer.valueOf(bytesProduced) });
/*     */           }
/*     */ 
/*     */           
/*     */           subscriber.success(dataBuffer);
/*     */         });
/*     */ 
/*     */     
/* 226 */     return stream.log(LOG_CATEGORY_FULL_OUTPUT, Level.FINEST, new reactor.core.publisher.SignalType[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Flux<DataBuffer> createChunkedStream(String templateName, Set<String> markupSelectors, IContext context, DataBufferFactory bufferFactory, Charset charset, int responseMaxChunkSizeBytes) {
/* 237 */     Flux<DataBuffer> stream = Flux.generate(() -> new StreamThrottledTemplateProcessor(processThrottled(templateName, markupSelectors, context), null, null, 0L, false), (throttledProcessor, emitter) -> {
/*     */           int bytesProduced;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           throttledProcessor.startChunk();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           if (logger.isTraceEnabled()) {
/*     */             logger.trace("[THYMELEAF][{}][{}] STARTING PARTIAL STREAM PROCESS (CHUNKED MODE, THROTTLER ID \"{}\", CHUNK {}) FOR TEMPLATE \"{}\" WITH LOCALE {}", new Object[] { TemplateEngine.threadIndex(), throttledProcessor.getProcessorIdentifier(), throttledProcessor.getProcessorIdentifier(), Integer.valueOf(throttledProcessor.getChunkCount()), LoggingUtils.loggifyTemplateName(templateName), context.getLocale() });
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           DataBuffer buffer = bufferFactory.allocateBuffer(responseMaxChunkSizeBytes);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/*     */             bytesProduced = throttledProcessor.process(responseMaxChunkSizeBytes, buffer.asOutputStream(), charset);
/* 270 */           } catch (Throwable t) {
/*     */             emitter.error(t);
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             return null;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           if (logger.isTraceEnabled()) {
/*     */             logger.trace("[THYMELEAF][{}][{}] FINISHED PARTIAL STREAM PROCESS (CHUNKED MODE, THROTTLER ID \"{}\", CHUNK {}) FOR TEMPLATE \"{}\" WITH LOCALE {}. PRODUCED {} BYTES", new Object[] { TemplateEngine.threadIndex(), throttledProcessor.getProcessorIdentifier(), throttledProcessor.getProcessorIdentifier(), Integer.valueOf(throttledProcessor.getChunkCount()), LoggingUtils.loggifyTemplateName(templateName), context.getLocale(), Integer.valueOf(bytesProduced) });
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           emitter.next(buffer);
/*     */ 
/*     */ 
/*     */           
/*     */           if (throttledProcessor.isFinished()) {
/*     */             if (logger.isTraceEnabled()) {
/*     */               logger.trace("[THYMELEAF][{}][{}] FINISHED ALL STREAM PROCESS (CHUNKED MODE, THROTTLER ID \"{}\") FOR TEMPLATE \"{}\" WITH LOCALE {}. PRODUCED A TOTAL OF {} BYTES IN {} CHUNKS", new Object[] { TemplateEngine.threadIndex(), throttledProcessor.getProcessorIdentifier(), throttledProcessor.getProcessorIdentifier(), LoggingUtils.loggifyTemplateName(templateName), context.getLocale(), Long.valueOf(throttledProcessor.getTotalBytesProduced()), Integer.valueOf(throttledProcessor.getChunkCount() + 1) });
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             emitter.complete();
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/*     */           return throttledProcessor;
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 310 */     return stream.log(LOG_CATEGORY_CHUNKED_OUTPUT, Level.FINEST, new reactor.core.publisher.SignalType[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Flux<DataBuffer> createDataDrivenStream(String templateName, Set<String> markupSelectors, IContext context, String dataDriverVariableName, DataBufferFactory bufferFactory, Charset charset, int responseMaxChunkSizeBytes, boolean sse) {
/*     */     ReactiveAdapterRegistry reactiveAdapterRegistry;
/* 324 */     IReactiveDataDriverContextVariable dataDriver = (IReactiveDataDriverContextVariable)context.getVariable(dataDriverVariableName);
/* 325 */     int bufferSizeElements = dataDriver.getBufferSizeElements();
/*     */ 
/*     */     
/* 328 */     String sseEventsPrefix = (dataDriver instanceof IReactiveSSEDataDriverContextVariable) ? ((IReactiveSSEDataDriverContextVariable)dataDriver).getSseEventsPrefix() : null;
/*     */ 
/*     */     
/* 331 */     long sseEventsID = (dataDriver instanceof IReactiveSSEDataDriverContextVariable) ? ((IReactiveSSEDataDriverContextVariable)dataDriver).getSseEventsFirstID() : 0L;
/*     */     
/* 333 */     if (Contexts.isSpringWebFluxWebContext(context)) {
/*     */       
/* 335 */       reactiveAdapterRegistry = Contexts.getSpringWebFluxWebExchange(context).getApplication().getReactiveAdapterRegistry();
/*     */     } else {
/* 337 */       reactiveAdapterRegistry = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 342 */     DataDrivenTemplateIterator dataDrivenIterator = new DataDrivenTemplateIterator();
/* 343 */     IContext wrappedContext = applyDataDriverWrapper(context, dataDriverVariableName, dataDrivenIterator);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 350 */     Flux<List<Object>> dataDrivenBufferedStream = Flux.from(dataDriver.getDataStream(reactiveAdapterRegistry)).buffer(bufferSizeElements).log(LOG_CATEGORY_DATADRIVEN_INPUT, Level.FINEST, new reactor.core.publisher.SignalType[0]);
/*     */ 
/*     */ 
/*     */     
/* 354 */     Flux<DataDrivenFluxStep> dataDrivenWithContextStream = Flux.using(() -> {
/*     */           String outputContentType = sse ? "text/event-stream" : null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           TemplateSpec templateSpec = new TemplateSpec(templateName, markupSelectors, outputContentType, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           return new StreamThrottledTemplateProcessor(processThrottled(templateSpec, wrappedContext), dataDrivenIterator, sseEventsPrefix, sseEventsID, sse);
/*     */         }throttledProcessor -> Flux.concat((Publisher)Flux.generate((), ())), throttledProcessor -> {
/*     */         
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 421 */     Flux<DataBuffer> stream = dataDrivenWithContextStream.concatMap(step -> Flux.generate((), ()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 589 */     return stream.log(LOG_CATEGORY_DATADRIVEN_OUTPUT, Level.FINEST, new reactor.core.publisher.SignalType[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static IContext applyDataDriverWrapper(IContext context, String dataDriverVariableName, DataDrivenTemplateIterator dataDrivenTemplateIterator) {
/* 608 */     if (context instanceof IEngineContext) {
/* 609 */       ((IEngineContext)context).setVariable(dataDriverVariableName, dataDrivenTemplateIterator);
/* 610 */       return context;
/*     */     } 
/*     */ 
/*     */     
/* 614 */     if (Contexts.isWebContext(context)) {
/* 615 */       return new DataDrivenWebContextWrapper(
/* 616 */           Contexts.asWebContext(context), dataDriverVariableName, dataDrivenTemplateIterator);
/*     */     }
/*     */ 
/*     */     
/* 620 */     return new DataDrivenContextWrapper(context, dataDriverVariableName, dataDrivenTemplateIterator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String findDataDriverInModel(IContext context) {
/* 634 */     String dataDriverVariableName = null;
/* 635 */     Set<String> contextVariableNames = context.getVariableNames();
/*     */     
/* 637 */     for (String contextVariableName : contextVariableNames) {
/*     */       
/* 639 */       Object contextVariableValue = context.getVariable(contextVariableName);
/* 640 */       if (contextVariableValue instanceof IReactiveDataDriverContextVariable) {
/* 641 */         if (dataDriverVariableName != null) {
/* 642 */           throw new TemplateProcessingException("Only one data-driver variable is allowed to be specified as a model attribute, but at least two have been identified: '" + dataDriverVariableName + "' and '" + contextVariableName + "'");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 647 */         dataDriverVariableName = contextVariableName;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 652 */     return dataDriverVariableName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class StreamThrottledTemplateProcessor
/*     */   {
/*     */     private final IThrottledTemplateProcessor throttledProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final DataDrivenTemplateIterator dataDrivenTemplateIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int chunkCount;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private long totalBytesProduced;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     StreamThrottledTemplateProcessor(IThrottledTemplateProcessor throttledProcessor, DataDrivenTemplateIterator dataDrivenTemplateIterator, String sseEventsPrefix, long sseEventsFirstID, boolean sse) {
/*     */       IThrottledTemplateWriterControl writerControl;
/* 683 */       this.throttledProcessor = throttledProcessor;
/* 684 */       this.dataDrivenTemplateIterator = dataDrivenTemplateIterator;
/*     */ 
/*     */       
/* 687 */       if (this.throttledProcessor instanceof ThrottledTemplateProcessor) {
/* 688 */         writerControl = ((ThrottledTemplateProcessor)this.throttledProcessor).getThrottledTemplateWriterControl();
/*     */       } else {
/* 690 */         writerControl = null;
/*     */       } 
/*     */       
/* 693 */       if (sse) {
/* 694 */         if (writerControl == null || !(writerControl instanceof org.thymeleaf.engine.ISSEThrottledTemplateWriterControl)) {
/* 695 */           throw new TemplateProcessingException("Cannot process template in Server-Sent Events (SSE) mode: template writer is not SSE capable. Either SSE content type has not been declared at the " + TemplateSpec.class
/*     */               
/* 697 */               .getSimpleName() + " or an implementation of " + IThrottledTemplateProcessor.class
/* 698 */               .getName() + " other than " + ThrottledTemplateProcessor.class
/* 699 */               .getName() + " is being used.");
/*     */         }
/* 701 */         if (this.dataDrivenTemplateIterator == null) {
/* 702 */           throw new TemplateProcessingException("Cannot process template in Server-Sent Events (SSE) mode: a data-driven template iterator is required in context in order to apply SSE.");
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 708 */       if (this.dataDrivenTemplateIterator != null) {
/* 709 */         this.dataDrivenTemplateIterator.setWriterControl(writerControl);
/* 710 */         this.dataDrivenTemplateIterator.setSseEventsPrefix(sseEventsPrefix);
/* 711 */         this.dataDrivenTemplateIterator.setSseEventsFirstID(sseEventsFirstID);
/*     */       } 
/*     */       
/* 714 */       this.chunkCount = -1;
/* 715 */       this.totalBytesProduced = 0L;
/*     */     }
/*     */ 
/*     */     
/*     */     int process(int maxOutputInBytes, OutputStream outputStream, Charset charset) {
/* 720 */       int chunkBytes = this.throttledProcessor.process(maxOutputInBytes, outputStream, charset);
/* 721 */       this.totalBytesProduced += chunkBytes;
/* 722 */       return chunkBytes;
/*     */     }
/*     */     
/*     */     String getProcessorIdentifier() {
/* 726 */       return this.throttledProcessor.getProcessorIdentifier();
/*     */     }
/*     */     
/*     */     boolean isFinished() {
/* 730 */       return this.throttledProcessor.isFinished();
/*     */     }
/*     */     
/*     */     void startChunk() {
/* 734 */       this.chunkCount++;
/*     */     }
/*     */     
/*     */     int getChunkCount() {
/* 738 */       return this.chunkCount;
/*     */     }
/*     */     
/*     */     long getTotalBytesProduced() {
/* 742 */       return this.totalBytesProduced;
/*     */     }
/*     */     
/*     */     DataDrivenTemplateIterator getDataDrivenTemplateIterator() {
/* 746 */       return this.dataDrivenTemplateIterator;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final class DataDrivenFluxStep
/*     */   {
/*     */     private final SpringWebFluxTemplateEngine.StreamThrottledTemplateProcessor throttledProcessor;
/*     */ 
/*     */     
/*     */     private final List<Object> values;
/*     */     
/*     */     private final FluxStepPhase phase;
/*     */ 
/*     */     
/*     */     enum FluxStepPhase
/*     */     {
/* 764 */       DATA_DRIVEN_PHASE_HEAD, DATA_DRIVEN_PHASE_BUFFER, DATA_DRIVEN_PHASE_TAIL;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static DataDrivenFluxStep forHead(SpringWebFluxTemplateEngine.StreamThrottledTemplateProcessor throttledProcessor) {
/* 772 */       return new DataDrivenFluxStep(throttledProcessor, null, FluxStepPhase.DATA_DRIVEN_PHASE_HEAD);
/*     */     }
/*     */     
/*     */     static DataDrivenFluxStep forBuffer(SpringWebFluxTemplateEngine.StreamThrottledTemplateProcessor throttledProcessor, List<Object> values) {
/* 776 */       return new DataDrivenFluxStep(throttledProcessor, values, FluxStepPhase.DATA_DRIVEN_PHASE_BUFFER);
/*     */     }
/*     */     
/*     */     static DataDrivenFluxStep forTail(SpringWebFluxTemplateEngine.StreamThrottledTemplateProcessor throttledProcessor) {
/* 780 */       return new DataDrivenFluxStep(throttledProcessor, null, FluxStepPhase.DATA_DRIVEN_PHASE_TAIL);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private DataDrivenFluxStep(SpringWebFluxTemplateEngine.StreamThrottledTemplateProcessor throttledProcessor, List<Object> values, FluxStepPhase phase) {
/* 787 */       this.throttledProcessor = throttledProcessor;
/* 788 */       this.values = values;
/* 789 */       this.phase = phase;
/*     */     }
/*     */     
/*     */     SpringWebFluxTemplateEngine.StreamThrottledTemplateProcessor getThrottledProcessor() {
/* 793 */       return this.throttledProcessor;
/*     */     }
/*     */     
/*     */     List<Object> getValues() {
/* 797 */       return this.values;
/*     */     }
/*     */     
/*     */     boolean isHead() {
/* 801 */       return (this.phase == FluxStepPhase.DATA_DRIVEN_PHASE_HEAD);
/*     */     }
/*     */     
/*     */     boolean isDataBuffer() {
/* 805 */       return (this.phase == FluxStepPhase.DATA_DRIVEN_PHASE_BUFFER);
/*     */     }
/*     */     
/*     */     boolean isTail() {
/* 809 */       return (this.phase == FluxStepPhase.DATA_DRIVEN_PHASE_TAIL);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   enum FluxStepPhase
/*     */   {
/*     */     DATA_DRIVEN_PHASE_HEAD, DATA_DRIVEN_PHASE_BUFFER, DATA_DRIVEN_PHASE_TAIL;
/*     */   }
/*     */ 
/*     */   
/*     */   static class DataDrivenWebContextWrapper
/*     */     extends DataDrivenContextWrapper
/*     */     implements IWebContext
/*     */   {
/*     */     private final IWebContext context;
/*     */ 
/*     */     
/*     */     DataDrivenWebContextWrapper(IWebContext context, String dataDriverVariableName, DataDrivenTemplateIterator dataDrivenTemplateIterator) {
/* 828 */       super((IContext)context, dataDriverVariableName, dataDrivenTemplateIterator);
/* 829 */       this.context = context;
/*     */     }
/*     */ 
/*     */     
/*     */     public IWebExchange getExchange() {
/* 834 */       return this.context.getExchange();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class DataDrivenContextWrapper
/*     */     implements IContext
/*     */   {
/*     */     private final IContext context;
/*     */ 
/*     */ 
/*     */     
/*     */     private final String dataDriverVariableName;
/*     */ 
/*     */     
/*     */     private final DataDrivenTemplateIterator dataDrivenTemplateIterator;
/*     */ 
/*     */ 
/*     */     
/*     */     DataDrivenContextWrapper(IContext context, String dataDriverVariableName, DataDrivenTemplateIterator dataDrivenTemplateIterator) {
/* 856 */       this.context = context;
/* 857 */       this.dataDriverVariableName = dataDriverVariableName;
/* 858 */       this.dataDrivenTemplateIterator = dataDrivenTemplateIterator;
/*     */     }
/*     */     
/*     */     public IContext getWrappedContext() {
/* 862 */       return this.context;
/*     */     }
/*     */ 
/*     */     
/*     */     public Locale getLocale() {
/* 867 */       return this.context.getLocale();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean containsVariable(String name) {
/* 872 */       return this.context.containsVariable(name);
/*     */     }
/*     */ 
/*     */     
/*     */     public Set<String> getVariableNames() {
/* 877 */       return this.context.getVariableNames();
/*     */     }
/*     */ 
/*     */     
/*     */     public Object getVariable(String name) {
/* 882 */       if (this.dataDriverVariableName.equals(name)) {
/* 883 */         return this.dataDrivenTemplateIterator;
/*     */       }
/* 885 */       return this.context.getVariable(name);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\SpringWebFluxTemplateEngine.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */