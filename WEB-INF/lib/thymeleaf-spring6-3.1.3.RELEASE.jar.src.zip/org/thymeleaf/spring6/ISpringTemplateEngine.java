package org.thymeleaf.spring6;

import org.springframework.context.MessageSource;
import org.thymeleaf.ITemplateEngine;

public interface ISpringTemplateEngine extends ITemplateEngine {
  void setTemplateEngineMessageSource(MessageSource paramMessageSource);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\ISpringTemplateEngine.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */