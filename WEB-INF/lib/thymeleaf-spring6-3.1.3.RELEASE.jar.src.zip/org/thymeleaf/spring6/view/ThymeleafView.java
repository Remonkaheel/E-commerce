/*     */ package org.thymeleaf.spring6.view;
/*     */ 
/*     */ import jakarta.servlet.ServletContext;
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.Field;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.web.servlet.View;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.WebExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.spring6.ISpringTemplateEngine;
/*     */ import org.thymeleaf.spring6.context.webmvc.SpringWebMvcThymeleafRequestContext;
/*     */ import org.thymeleaf.spring6.expression.ThymeleafEvaluationContext;
/*     */ import org.thymeleaf.spring6.util.SpringContentTypeUtils;
/*     */ import org.thymeleaf.spring6.util.SpringRequestUtils;
/*     */ import org.thymeleaf.standard.expression.FragmentExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*     */ import org.thymeleaf.standard.expression.StandardExpressions;
/*     */ import org.thymeleaf.util.FastStringWriter;
/*     */ import org.thymeleaf.web.IWebExchange;
/*     */ import org.thymeleaf.web.servlet.IServletWebExchange;
/*     */ import org.thymeleaf.web.servlet.JakartaServletWebApplication;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThymeleafView
/*     */   extends AbstractThymeleafView
/*     */ {
/*     */   private static final String pathVariablesSelector;
/*  86 */   private Set<String> markupSelectors = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  97 */     String pathVariablesSelectorValue = null;
/*     */     
/*     */     try {
/* 100 */       Field pathVariablesField = View.class.getDeclaredField("PATH_VARIABLES");
/* 101 */       pathVariablesSelectorValue = (String)pathVariablesField.get(null);
/* 102 */     } catch (NoSuchFieldException ignored) {
/* 103 */       pathVariablesSelectorValue = null;
/* 104 */     } catch (IllegalAccessException ignored) {
/* 105 */       pathVariablesSelectorValue = null;
/*     */     } 
/* 107 */     pathVariablesSelector = pathVariablesSelectorValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ThymeleafView(String templateName) {
/* 132 */     super(templateName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMarkupSelector() {
/* 157 */     return (this.markupSelectors == null || this.markupSelectors.size() == 0) ? null : this.markupSelectors.iterator().next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMarkupSelector(String markupSelector) {
/* 180 */     this
/* 181 */       .markupSelectors = (markupSelector == null || markupSelector.trim().length() == 0) ? null : Collections.<String>singleton(markupSelector.trim());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(Map<String, ?> model, HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 192 */     renderFragment(this.markupSelectors, model, request, response);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void renderFragment(Set<String> markupSelectorsToRender, Map<String, ?> model, HttpServletRequest request, HttpServletResponse response) throws Exception {
/*     */     String templateName;
/*     */     Set<String> markupSelectors, processMarkupSelectors;
/* 201 */     ServletContext servletContext = getServletContext();
/*     */ 
/*     */     
/* 204 */     IServletWebExchange iServletWebExchange = JakartaServletWebApplication.buildApplication(servletContext).buildExchange(request, response);
/*     */     
/* 206 */     String viewTemplateName = getTemplateName();
/* 207 */     ISpringTemplateEngine viewTemplateEngine = getTemplateEngine();
/*     */     
/* 209 */     if (viewTemplateName == null) {
/* 210 */       throw new IllegalArgumentException("Property 'templateName' is required");
/*     */     }
/* 212 */     if (getLocale() == null) {
/* 213 */       throw new IllegalArgumentException("Property 'locale' is required");
/*     */     }
/* 215 */     if (viewTemplateEngine == null) {
/* 216 */       throw new IllegalArgumentException("Property 'templateEngine' is required");
/*     */     }
/*     */     
/* 219 */     Map<String, Object> mergedModel = new HashMap<>(30);
/* 220 */     Map<String, Object> templateStaticVariables = getStaticVariables();
/* 221 */     if (templateStaticVariables != null) {
/* 222 */       mergedModel.putAll(templateStaticVariables);
/*     */     }
/* 224 */     if (pathVariablesSelector != null) {
/*     */       
/* 226 */       Map<String, Object> pathVars = (Map<String, Object>)request.getAttribute(pathVariablesSelector);
/* 227 */       if (pathVars != null) {
/* 228 */         mergedModel.putAll(pathVars);
/*     */       }
/*     */     } 
/* 231 */     if (model != null) {
/* 232 */       mergedModel.putAll(model);
/*     */     }
/*     */     
/* 235 */     ApplicationContext applicationContext = getApplicationContext();
/*     */ 
/*     */     
/* 238 */     RequestContext requestContext = new RequestContext(request, response, getServletContext(), mergedModel);
/* 239 */     SpringWebMvcThymeleafRequestContext thymeleafRequestContext = new SpringWebMvcThymeleafRequestContext(requestContext, request);
/*     */ 
/*     */ 
/*     */     
/* 243 */     addRequestContextAsVariable(mergedModel, "springRequestContext", requestContext);
/*     */     
/* 245 */     addRequestContextAsVariable(mergedModel, "springMacroRequestContext", requestContext);
/*     */ 
/*     */     
/* 248 */     mergedModel.put("thymeleafRequestContext", thymeleafRequestContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 257 */     ConversionService conversionService = (ConversionService)request.getAttribute(ConversionService.class.getName());
/* 258 */     ThymeleafEvaluationContext evaluationContext = new ThymeleafEvaluationContext(applicationContext, conversionService);
/*     */     
/* 260 */     mergedModel.put("thymeleaf::EvaluationContext", evaluationContext);
/*     */ 
/*     */     
/* 263 */     IEngineConfiguration configuration = viewTemplateEngine.getConfiguration();
/*     */     
/* 265 */     WebExpressionContext context = new WebExpressionContext(configuration, (IWebExchange)iServletWebExchange, getLocale(), mergedModel);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 270 */     if (!viewTemplateName.contains("::")) {
/*     */ 
/*     */       
/* 273 */       templateName = viewTemplateName;
/* 274 */       markupSelectors = null;
/*     */     } else {
/*     */       FragmentExpression fragmentExpression;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 281 */       SpringRequestUtils.checkViewNameNotInRequest(viewTemplateName, iServletWebExchange.getRequest());
/*     */       
/* 283 */       IStandardExpressionParser parser = StandardExpressions.getExpressionParser(configuration);
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 288 */         fragmentExpression = (FragmentExpression)parser.parseExpression((IExpressionContext)context, "~{" + viewTemplateName + "}");
/* 289 */       } catch (TemplateProcessingException e) {
/* 290 */         throw new IllegalArgumentException("Invalid template name specification: '" + viewTemplateName + "'");
/*     */       } 
/*     */ 
/*     */       
/* 294 */       FragmentExpression.ExecutedFragmentExpression fragment = FragmentExpression.createExecutedFragmentExpression((IExpressionContext)context, fragmentExpression);
/*     */       
/* 296 */       templateName = FragmentExpression.resolveTemplateName(fragment);
/* 297 */       markupSelectors = FragmentExpression.resolveFragments(fragment);
/* 298 */       Map<String, Object> nameFragmentParameters = fragment.getFragmentParameters();
/*     */       
/* 300 */       if (nameFragmentParameters != null) {
/*     */         
/* 302 */         if (fragment.hasSyntheticParameters())
/*     */         {
/*     */           
/* 305 */           throw new IllegalArgumentException("Parameters in a view specification must be named (non-synthetic): '" + viewTemplateName + "'");
/*     */         }
/*     */ 
/*     */         
/* 309 */         context.setVariables(nameFragmentParameters);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 317 */     String templateContentType = getContentType();
/* 318 */     Locale templateLocale = getLocale();
/* 319 */     String templateCharacterEncoding = getCharacterEncoding();
/*     */ 
/*     */ 
/*     */     
/* 323 */     if (markupSelectors != null && markupSelectors.size() > 0) {
/* 324 */       if (markupSelectorsToRender != null && markupSelectorsToRender.size() > 0) {
/* 325 */         throw new IllegalArgumentException("A markup selector has been specified (" + 
/* 326 */             Arrays.asList(new Set[] { markupSelectors
/* 327 */               }) + ") for a view that was already being executed as a fragment (" + Arrays.asList(new Set[] { markupSelectorsToRender }) + "). Only one fragment selection is allowed.");
/*     */       }
/*     */       
/* 330 */       processMarkupSelectors = markupSelectors;
/*     */     }
/* 332 */     else if (markupSelectorsToRender != null && markupSelectorsToRender.size() > 0) {
/* 333 */       processMarkupSelectors = markupSelectorsToRender;
/*     */     } else {
/* 335 */       processMarkupSelectors = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 340 */     response.setLocale(templateLocale);
/*     */     
/* 342 */     if (!getForceContentType()) {
/*     */ 
/*     */       
/* 345 */       String computedContentType = SpringContentTypeUtils.computeViewContentType((IWebExchange)iServletWebExchange, 
/*     */           
/* 347 */           (templateContentType != null) ? templateContentType : "text/html;charset=ISO-8859-1", 
/* 348 */           (templateCharacterEncoding != null) ? Charset.forName(templateCharacterEncoding) : null);
/*     */       
/* 350 */       response.setContentType(computedContentType);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 355 */       if (templateContentType != null) {
/* 356 */         response.setContentType(templateContentType);
/*     */       } else {
/* 358 */         response.setContentType("text/html;charset=ISO-8859-1");
/*     */       } 
/* 360 */       if (templateCharacterEncoding != null) {
/* 361 */         response.setCharacterEncoding(templateCharacterEncoding);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 366 */     boolean producePartialOutputWhileProcessing = getProducePartialOutputWhileProcessing();
/*     */ 
/*     */ 
/*     */     
/* 370 */     Writer templateWriter = producePartialOutputWhileProcessing ? response.getWriter() : (Writer)new FastStringWriter(1024);
/*     */     
/* 372 */     viewTemplateEngine.process(templateName, processMarkupSelectors, (IContext)context, templateWriter);
/*     */ 
/*     */     
/* 375 */     if (!producePartialOutputWhileProcessing) {
/* 376 */       response.getWriter().write(templateWriter.toString());
/* 377 */       response.getWriter().flush();
/*     */     } 
/*     */   }
/*     */   
/*     */   public ThymeleafView() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\view\ThymeleafView.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */