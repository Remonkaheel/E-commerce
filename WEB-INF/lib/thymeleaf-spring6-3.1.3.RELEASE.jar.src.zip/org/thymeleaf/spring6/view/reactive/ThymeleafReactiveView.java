/*     */ package org.thymeleaf.spring6.view.reactive;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import java.util.function.Supplier;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.io.buffer.DataBuffer;
/*     */ import org.springframework.http.HttpHeaders;
/*     */ import org.springframework.http.MediaType;
/*     */ import org.springframework.http.server.reactive.ServerHttpResponse;
/*     */ import org.springframework.web.reactive.HandlerMapping;
/*     */ import org.springframework.web.reactive.result.view.AbstractView;
/*     */ import org.springframework.web.reactive.result.view.RequestContext;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.thymeleaf.IEngineConfiguration;
/*     */ import org.thymeleaf.context.IContext;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.WebExpressionContext;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.spring6.ISpringWebFluxTemplateEngine;
/*     */ import org.thymeleaf.spring6.context.webflux.SpringWebFluxThymeleafRequestContext;
/*     */ import org.thymeleaf.spring6.expression.ThymeleafEvaluationContext;
/*     */ import org.thymeleaf.spring6.util.SpringReactiveModelAdditionsUtils;
/*     */ import org.thymeleaf.spring6.web.webflux.ISpringWebFluxWebExchange;
/*     */ import org.thymeleaf.spring6.web.webflux.SpringWebFluxWebApplication;
/*     */ import org.thymeleaf.standard.expression.FragmentExpression;
/*     */ import org.thymeleaf.standard.expression.IStandardExpressionParser;
/*     */ import org.thymeleaf.standard.expression.StandardExpressions;
/*     */ import org.thymeleaf.web.IWebExchange;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThymeleafReactiveView
/*     */   extends AbstractView
/*     */   implements BeanNameAware
/*     */ {
/* 104 */   protected static final Logger logger = LoggerFactory.getLogger(ThymeleafReactiveView.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_RESPONSE_CHUNK_SIZE_BYTES = 2147483647;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String WEBFLUX_CONVERSION_SERVICE_NAME = "webFluxConversionService";
/*     */ 
/*     */   
/* 115 */   private String beanName = null;
/* 116 */   private ISpringWebFluxTemplateEngine templateEngine = null;
/* 117 */   private String templateName = null;
/* 118 */   private Locale locale = null;
/* 119 */   private Map<String, Object> staticVariables = null;
/*     */ 
/*     */   
/*     */   private boolean defaultCharsetSet = false;
/*     */ 
/*     */   
/*     */   private boolean supportedMediaTypesSet = false;
/*     */   
/* 127 */   private Set<String> markupSelectors = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   private Integer responseMaxChunkSizeBytes = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMarkupSelector() {
/* 150 */     return (this.markupSelectors == null || this.markupSelectors.size() == 0) ? null : this.markupSelectors.iterator().next();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMarkupSelector(String markupSelector) {
/* 155 */     this
/* 156 */       .markupSelectors = (markupSelector == null || markupSelector.trim().length() == 0) ? null : Collections.<String>singleton(markupSelector.trim());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isDefaultCharsetSet() {
/* 164 */     return this.defaultCharsetSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultCharset(Charset defaultCharset) {
/* 171 */     super.setDefaultCharset(defaultCharset);
/* 172 */     this.defaultCharsetSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isSupportedMediaTypesSet() {
/* 181 */     return this.supportedMediaTypesSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSupportedMediaTypes(List<MediaType> supportedMediaTypes) {
/* 188 */     super.setSupportedMediaTypes(supportedMediaTypes);
/* 189 */     this.supportedMediaTypesSet = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getBeanName() {
/* 196 */     return this.beanName;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanName(String beanName) {
/* 201 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTemplateName() {
/* 208 */     return this.templateName;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTemplateName(String templateName) {
/* 213 */     this.templateName = templateName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Locale getLocale() {
/* 220 */     return this.locale;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setLocale(Locale locale) {
/* 225 */     this.locale = locale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getResponseMaxChunkSizeBytes() {
/* 236 */     return (this.responseMaxChunkSizeBytes == null) ? Integer
/* 237 */       .MAX_VALUE : this.responseMaxChunkSizeBytes.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Integer getNullableResponseMaxChunkSize() {
/* 243 */     return this.responseMaxChunkSizeBytes;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setResponseMaxChunkSizeBytes(int responseMaxBufferSizeBytes) {
/* 248 */     this.responseMaxChunkSizeBytes = Integer.valueOf(responseMaxBufferSizeBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ISpringWebFluxTemplateEngine getTemplateEngine() {
/* 255 */     return this.templateEngine;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setTemplateEngine(ISpringWebFluxTemplateEngine templateEngine) {
/* 260 */     this.templateEngine = templateEngine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getStaticVariables() {
/* 267 */     if (this.staticVariables == null) {
/* 268 */       return Collections.emptyMap();
/*     */     }
/* 270 */     return Collections.unmodifiableMap(this.staticVariables);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addStaticVariable(String name, Object value) {
/* 275 */     if (this.staticVariables == null) {
/* 276 */       this.staticVariables = new HashMap<>(3, 1.0F);
/*     */     }
/* 278 */     this.staticVariables.put(name, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStaticVariables(Map<String, ?> variables) {
/* 283 */     if (variables != null) {
/* 284 */       if (this.staticVariables == null) {
/* 285 */         this.staticVariables = new HashMap<>(3, 1.0F);
/*     */       }
/* 287 */       this.staticVariables.putAll(variables);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Void> render(Map<String, ?> model, MediaType contentType, ServerWebExchange exchange) {
/* 300 */     ISpringWebFluxTemplateEngine viewTemplateEngine = getTemplateEngine();
/*     */     
/* 302 */     if (viewTemplateEngine == null) {
/* 303 */       return Mono.error(new IllegalArgumentException("Property 'thymeleafTemplateEngine' is required"));
/*     */     }
/*     */     
/* 306 */     IEngineConfiguration configuration = viewTemplateEngine.getConfiguration();
/* 307 */     Map<String, Object> executionAttributes = configuration.getExecutionAttributes();
/*     */ 
/*     */ 
/*     */     
/* 311 */     Map<String, Object> enrichedModel = null;
/* 312 */     for (String executionAttributeName : executionAttributes.keySet()) {
/*     */       
/* 314 */       if (SpringReactiveModelAdditionsUtils.isReactiveModelAdditionName(executionAttributeName)) {
/*     */ 
/*     */ 
/*     */         
/* 318 */         Object executionAttributeValue = executionAttributes.get(executionAttributeName);
/* 319 */         String modelAttributeName = SpringReactiveModelAdditionsUtils.fromReactiveModelAdditionName(executionAttributeName);
/* 320 */         Publisher<?> modelAttributeValue = null;
/*     */         
/* 322 */         if (executionAttributeValue != null) {
/* 323 */           if (executionAttributeValue instanceof Publisher) {
/* 324 */             modelAttributeValue = (Publisher)executionAttributeValue;
/* 325 */           } else if (executionAttributeValue instanceof Supplier) {
/* 326 */             Supplier<Publisher<?>> supplier = (Supplier<Publisher<?>>)executionAttributeValue;
/* 327 */             modelAttributeValue = supplier.get();
/* 328 */           } else if (executionAttributeValue instanceof Function) {
/* 329 */             Function<ServerWebExchange, Publisher<?>> function = (Function<ServerWebExchange, Publisher<?>>)executionAttributeValue;
/* 330 */             modelAttributeValue = function.apply(exchange);
/*     */           } 
/*     */         }
/*     */         
/* 334 */         if (enrichedModel == null) {
/* 335 */           enrichedModel = new LinkedHashMap<>(model);
/*     */         }
/* 337 */         enrichedModel.put(modelAttributeName, modelAttributeValue);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 343 */     Map<String, ?> map = (enrichedModel != null) ? enrichedModel : model;
/*     */     
/* 345 */     return super.render(map, contentType, exchange);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<Void> renderInternal(Map<String, Object> renderAttributes, MediaType contentType, ServerWebExchange exchange) {
/* 354 */     return renderFragmentInternal(this.markupSelectors, renderAttributes, contentType, exchange);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Mono<Void> renderFragmentInternal(Set<String> markupSelectorsToRender, Map<String, Object> renderAttributes, MediaType contentType, ServerWebExchange exchange) {
/*     */     String templateName;
/*     */     Set<String> markupSelectors, processMarkupSelectors;
/* 362 */     String viewTemplateName = getTemplateName();
/* 363 */     ISpringWebFluxTemplateEngine viewTemplateEngine = getTemplateEngine();
/*     */     
/* 365 */     if (viewTemplateName == null) {
/* 366 */       return Mono.error(new IllegalArgumentException("Property 'templateName' is required"));
/*     */     }
/* 368 */     if (getLocale() == null) {
/* 369 */       return Mono.error(new IllegalArgumentException("Property 'locale' is required"));
/*     */     }
/* 371 */     if (viewTemplateEngine == null) {
/* 372 */       return Mono.error(new IllegalArgumentException("Property 'thymeleafTemplateEngine' is required"));
/*     */     }
/*     */     
/* 375 */     ServerHttpResponse response = exchange.getResponse();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 388 */     Map<String, Object> mergedModel = new HashMap<>(30);
/*     */     
/* 390 */     Map<String, Object> templateStaticVariables = getStaticVariables();
/* 391 */     if (templateStaticVariables != null) {
/* 392 */       mergedModel.putAll(templateStaticVariables);
/*     */     }
/*     */ 
/*     */     
/* 396 */     Map<String, Object> pathVars = (Map<String, Object>)exchange.getAttributes().get(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
/* 397 */     if (pathVars != null) {
/* 398 */       mergedModel.putAll(pathVars);
/*     */     }
/*     */     
/* 401 */     if (renderAttributes != null) {
/* 402 */       mergedModel.putAll(renderAttributes);
/*     */     }
/*     */     
/* 405 */     ApplicationContext applicationContext = getApplicationContext();
/*     */ 
/*     */ 
/*     */     
/* 409 */     RequestContext requestContext = createRequestContext(exchange, mergedModel);
/* 410 */     SpringWebFluxThymeleafRequestContext thymeleafRequestContext = new SpringWebFluxThymeleafRequestContext(requestContext, exchange);
/*     */ 
/*     */     
/* 413 */     mergedModel.put("springRequestContext", requestContext);
/*     */ 
/*     */     
/* 416 */     mergedModel.put("thymeleafRequestContext", thymeleafRequestContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 426 */     ConversionService conversionService = applicationContext.containsBean("webFluxConversionService") ? (ConversionService)applicationContext.getBean("webFluxConversionService") : null;
/* 427 */     ThymeleafEvaluationContext evaluationContext = new ThymeleafEvaluationContext(applicationContext, conversionService);
/*     */     
/* 429 */     mergedModel.put("thymeleaf::EvaluationContext", evaluationContext);
/*     */ 
/*     */ 
/*     */     
/* 433 */     boolean dataDriven = isDataDriven(mergedModel);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 443 */     Locale templateLocale = getLocale();
/*     */     
/* 445 */     Charset charset = getCharset(contentType).orElse(getDefaultCharset());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 458 */     ISpringWebFluxWebExchange iSpringWebFluxWebExchange = SpringWebFluxWebApplication.buildApplication(getReactiveAdapterRegistry()).buildExchange(exchange, templateLocale, contentType, charset);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 474 */     IEngineConfiguration configuration = viewTemplateEngine.getConfiguration();
/*     */     
/* 476 */     WebExpressionContext context = new WebExpressionContext(configuration, (IWebExchange)iSpringWebFluxWebExchange, getLocale(), mergedModel);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 490 */     if (!viewTemplateName.contains("::")) {
/*     */ 
/*     */       
/* 493 */       templateName = viewTemplateName;
/* 494 */       markupSelectors = null;
/*     */     } else {
/*     */       FragmentExpression fragmentExpression;
/*     */ 
/*     */       
/* 499 */       IStandardExpressionParser parser = StandardExpressions.getExpressionParser(configuration);
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 504 */         fragmentExpression = (FragmentExpression)parser.parseExpression((IExpressionContext)context, "~{" + viewTemplateName + "}");
/* 505 */       } catch (TemplateProcessingException e) {
/* 506 */         return Mono.error(new IllegalArgumentException("Invalid template name specification: '" + viewTemplateName + "'"));
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 511 */       FragmentExpression.ExecutedFragmentExpression fragment = FragmentExpression.createExecutedFragmentExpression((IExpressionContext)context, fragmentExpression);
/*     */       
/* 513 */       templateName = FragmentExpression.resolveTemplateName(fragment);
/* 514 */       markupSelectors = FragmentExpression.resolveFragments(fragment);
/* 515 */       Map<String, Object> nameFragmentParameters = fragment.getFragmentParameters();
/*     */       
/* 517 */       if (nameFragmentParameters != null) {
/*     */         
/* 519 */         if (fragment.hasSyntheticParameters())
/*     */         {
/*     */           
/* 522 */           return Mono.error(new IllegalArgumentException("Parameters in a view specification must be named (non-synthetic): '" + viewTemplateName + "'"));
/*     */         }
/*     */ 
/*     */         
/* 526 */         context.setVariables(nameFragmentParameters);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 533 */     if (markupSelectors != null && markupSelectors.size() > 0) {
/* 534 */       if (markupSelectorsToRender != null && markupSelectorsToRender.size() > 0) {
/* 535 */         return Mono.error(new IllegalArgumentException("A markup selector has been specified (" + 
/* 536 */               Arrays.<Set>asList(new Set[] { markupSelectors
/* 537 */                 }) + ") for a view that was already being executed as a fragment (" + Arrays.<Set>asList(new Set[] { markupSelectorsToRender }) + "). Only one fragment selection is allowed."));
/*     */       }
/*     */       
/* 540 */       processMarkupSelectors = markupSelectors;
/*     */     }
/* 542 */     else if (markupSelectorsToRender != null && markupSelectorsToRender.size() > 0) {
/* 543 */       processMarkupSelectors = markupSelectorsToRender;
/*     */     } else {
/* 545 */       processMarkupSelectors = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 559 */     int templateResponseMaxChunkSizeBytes = getResponseMaxChunkSizeBytes();
/*     */     
/* 561 */     HttpHeaders responseHeaders = exchange.getResponse().getHeaders();
/* 562 */     if (templateLocale != null)
/*     */     {
/* 564 */       responseHeaders.setContentLanguage(templateLocale);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 608 */     Publisher<DataBuffer> stream = viewTemplateEngine.processStream(templateName, processMarkupSelectors, (IContext)context, response
/* 609 */         .bufferFactory(), contentType, charset, templateResponseMaxChunkSizeBytes);
/*     */ 
/*     */     
/* 612 */     if (templateResponseMaxChunkSizeBytes == Integer.MAX_VALUE && !dataDriven)
/*     */     {
/*     */ 
/*     */       
/* 616 */       return response.writeWith(stream);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 622 */     return response.writeAndFlushWith((Publisher)Flux.from(stream).window(1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Optional<Charset> getCharset(MediaType mediaType) {
/* 630 */     return (mediaType != null) ? Optional.<Charset>ofNullable(mediaType.getCharset()) : Optional.<Charset>empty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isDataDriven(Map<String, Object> mergedModel) {
/* 637 */     if (mergedModel == null || mergedModel.size() == 0) {
/* 638 */       return false;
/*     */     }
/* 640 */     for (Object value : mergedModel.values()) {
/* 641 */       if (value instanceof org.thymeleaf.spring6.context.webflux.IReactiveDataDriverContextVariable) {
/* 642 */         return true;
/*     */       }
/*     */     } 
/* 645 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ReactiveAdapterRegistry getReactiveAdapterRegistry() {
/* 653 */     ApplicationContext applicationContext = getApplicationContext();
/* 654 */     if (applicationContext == null) {
/* 655 */       return null;
/*     */     }
/*     */     
/* 658 */     if (applicationContext != null) {
/*     */       try {
/* 660 */         return (ReactiveAdapterRegistry)applicationContext.getBean(ReactiveAdapterRegistry.class);
/* 661 */       } catch (NoSuchBeanDefinitionException noSuchBeanDefinitionException) {}
/*     */     }
/*     */ 
/*     */     
/* 665 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\view\reactive\ThymeleafReactiveView.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */