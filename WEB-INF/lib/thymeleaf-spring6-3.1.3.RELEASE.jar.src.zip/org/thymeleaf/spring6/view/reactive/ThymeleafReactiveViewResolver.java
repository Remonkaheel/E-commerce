/*      */ package org.thymeleaf.spring6.view.reactive;
/*      */ 
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.function.Function;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ import org.springframework.beans.BeanUtils;
/*      */ import org.springframework.beans.BeansException;
/*      */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*      */ import org.springframework.beans.factory.config.BeanDefinition;
/*      */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*      */ import org.springframework.context.ApplicationContext;
/*      */ import org.springframework.context.ApplicationContextAware;
/*      */ import org.springframework.http.MediaType;
/*      */ import org.springframework.util.PatternMatchUtils;
/*      */ import org.springframework.web.reactive.result.view.RedirectView;
/*      */ import org.springframework.web.reactive.result.view.View;
/*      */ import org.springframework.web.reactive.result.view.ViewResolver;
/*      */ import org.springframework.web.reactive.result.view.ViewResolverSupport;
/*      */ import org.thymeleaf.spring6.ISpringWebFluxTemplateEngine;
/*      */ import org.thymeleaf.util.Validate;
/*      */ import reactor.core.publisher.Mono;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ThymeleafReactiveViewResolver
/*      */   extends ViewResolverSupport
/*      */   implements ViewResolver, ApplicationContextAware
/*      */ {
/*  122 */   private static final Logger vrlogger = LoggerFactory.getLogger(ThymeleafReactiveViewResolver.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String REDIRECT_URL_PREFIX = "redirect:";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String FORWARD_URL_PREFIX = "forward:";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  145 */   private static final List<MediaType> SUPPORTED_MEDIA_TYPES = Arrays.asList(new MediaType[] { 
/*      */         MediaType.TEXT_HTML, MediaType.APPLICATION_XHTML_XML, MediaType.APPLICATION_XML, MediaType.TEXT_XML, MediaType.APPLICATION_RSS_XML, MediaType.APPLICATION_ATOM_XML, new MediaType("application", "javascript"), new MediaType("application", "ecmascript"), new MediaType("text", "javascript"), new MediaType("text", "ecmascript"), 
/*      */         MediaType.APPLICATION_JSON, new MediaType("text", "css"), MediaType.TEXT_PLAIN, MediaType.TEXT_EVENT_STREAM });
/*      */   
/*      */   private ApplicationContext applicationContext;
/*      */   private Function<String, RedirectView> redirectViewProvider;
/*      */   private boolean alwaysProcessRedirectAndForward;
/*      */   private Class<? extends ThymeleafReactiveView> viewClass;
/*      */   private String[] viewNames;
/*      */   private String[] excludedViewNames;
/*      */   private int order;
/*      */   private final Map<String, Object> staticVariables;
/*      */   private int responseMaxChunkSizeBytes;
/*      */   private String[] fullModeViewNames;
/*      */   private String[] chunkedModeViewNames;
/*      */   private ISpringWebFluxTemplateEngine templateEngine;
/*      */   
/*      */   public ThymeleafReactiveViewResolver() {
/*  163 */     this.redirectViewProvider = (url -> new RedirectView(url));
/*      */     
/*  165 */     this.alwaysProcessRedirectAndForward = true;
/*      */     
/*  167 */     this.viewClass = ThymeleafReactiveView.class;
/*  168 */     this.viewNames = null;
/*  169 */     this.excludedViewNames = null;
/*  170 */     this.order = Integer.MAX_VALUE;
/*      */     
/*  172 */     this.staticVariables = new LinkedHashMap<>(10);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  180 */     this.responseMaxChunkSizeBytes = Integer.MAX_VALUE;
/*      */     
/*  182 */     this.fullModeViewNames = null;
/*  183 */     this.chunkedModeViewNames = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  199 */     setSupportedMediaTypes(SUPPORTED_MEDIA_TYPES);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
/*  207 */     this.applicationContext = applicationContext;
/*      */   }
/*      */ 
/*      */   
/*      */   public ApplicationContext getApplicationContext() {
/*  212 */     return this.applicationContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setViewClass(Class<? extends ThymeleafReactiveView> viewClass) {
/*  228 */     if (viewClass == null || !ThymeleafReactiveView.class.isAssignableFrom(viewClass)) {
/*  229 */       throw new IllegalArgumentException("Given view class [" + (
/*  230 */           (viewClass != null) ? viewClass.getName() : null) + "] is not of type [" + ThymeleafReactiveView.class
/*  231 */           .getName() + "]");
/*      */     }
/*  233 */     this.viewClass = viewClass;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Class<? extends ThymeleafReactiveView> getViewClass() {
/*  238 */     return this.viewClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ISpringWebFluxTemplateEngine getTemplateEngine() {
/*  254 */     return this.templateEngine;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTemplateEngine(ISpringWebFluxTemplateEngine templateEngine) {
/*  267 */     this.templateEngine = templateEngine;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, Object> getStaticVariables() {
/*  288 */     return Collections.unmodifiableMap(this.staticVariables);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addStaticVariable(String name, Object value) {
/*  307 */     this.staticVariables.put(name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStaticVariables(Map<String, ?> variables) {
/*  331 */     if (variables != null) {
/*  332 */       for (Map.Entry<String, ?> entry : variables.entrySet()) {
/*  333 */         addStaticVariable(entry.getKey(), entry.getValue());
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOrder(int order) {
/*  355 */     this.order = order;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getOrder() {
/*  372 */     return this.order;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRedirectViewProvider(Function<String, RedirectView> redirectViewProvider) {
/*  391 */     Validate.notNull(redirectViewProvider, "RedirectView provider cannot be null");
/*  392 */     this.redirectViewProvider = redirectViewProvider;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Function<String, RedirectView> getRedirectViewProvider() {
/*  410 */     return this.redirectViewProvider;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAlwaysProcessRedirectAndForward(boolean alwaysProcessRedirectAndForward) {
/*  439 */     this.alwaysProcessRedirectAndForward = alwaysProcessRedirectAndForward;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAlwaysProcessRedirectAndForward() {
/*  467 */     return this.alwaysProcessRedirectAndForward;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResponseMaxChunkSizeBytes(int responseMaxChunkSizeBytes) {
/*  529 */     this.responseMaxChunkSizeBytes = responseMaxChunkSizeBytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getResponseMaxChunkSizeBytes() {
/*  595 */     return this.responseMaxChunkSizeBytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setViewNames(String[] viewNames) {
/*  627 */     this.viewNames = viewNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getViewNames() {
/*  657 */     return this.viewNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExcludedViewNames(String[] excludedViewNames) {
/*  678 */     this.excludedViewNames = excludedViewNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getExcludedViewNames() {
/*  697 */     return this.excludedViewNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFullModeViewNames(String[] fullModeViewNames) {
/*  752 */     this.fullModeViewNames = fullModeViewNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getFullModeViewNames() {
/*  805 */     return this.fullModeViewNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setChunkedModeViewNames(String[] chunkedModeViewNames) {
/*  857 */     this.chunkedModeViewNames = chunkedModeViewNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getChunkedModeViewNames() {
/*  907 */     return this.chunkedModeViewNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean canHandle(String viewName, Locale locale) {
/*  914 */     String[] viewNamesToBeProcessed = getViewNames();
/*  915 */     String[] viewNamesNotToBeProcessed = getExcludedViewNames();
/*  916 */     return ((viewNamesToBeProcessed == null || PatternMatchUtils.simpleMatch(viewNamesToBeProcessed, viewName)) && (viewNamesNotToBeProcessed == null || 
/*  917 */       !PatternMatchUtils.simpleMatch(viewNamesNotToBeProcessed, viewName)));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean shouldUseChunkedExecution(String viewName) {
/*  923 */     int viewResponseMaxChunkSizeBytes = getResponseMaxChunkSizeBytes();
/*  924 */     String[] viewChunkedModeViewNames = getChunkedModeViewNames();
/*  925 */     String[] viewFullModeViewNames = getFullModeViewNames();
/*      */     
/*  927 */     if (viewResponseMaxChunkSizeBytes == Integer.MAX_VALUE) {
/*      */       
/*  929 */       if (viewChunkedModeViewNames != null) {
/*  930 */         vrlogger.warn("[THYMELEAF] A set of view names to be executed in CHUNKED mode has been specified, but no response max chunk size has been specified, so this configuration parameter has no practical effect (no way to configure CHUNKED mode from the ViewResolver). Please fix your configuration.");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  935 */       if (viewFullModeViewNames != null) {
/*  936 */         vrlogger.warn("[THYMELEAF] A set of view names to be executed in FULL mode has been specified, but no response max chunk size has been specified, so the former configuration parameter has no practical effect (all templates will actually be executed as FULL). Please fix your configuration.");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  941 */       return false;
/*      */     } 
/*      */     
/*  944 */     if (viewChunkedModeViewNames != null)
/*      */     {
/*      */       
/*  947 */       return PatternMatchUtils.simpleMatch(viewChunkedModeViewNames, viewName);
/*      */     }
/*      */     
/*  950 */     if (viewFullModeViewNames != null)
/*      */     {
/*      */       
/*  953 */       return !PatternMatchUtils.simpleMatch(viewFullModeViewNames, viewName);
/*      */     }
/*      */     
/*  956 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Mono<View> resolveViewName(String viewName, Locale locale) {
/*  967 */     if (!this.alwaysProcessRedirectAndForward && !canHandle(viewName, locale)) {
/*  968 */       vrlogger.trace("[THYMELEAF] View \"{}\" cannot be handled by ThymeleafReactiveViewResolver. Passing on to the next resolver in the chain.", viewName);
/*  969 */       return Mono.empty();
/*      */     } 
/*      */     
/*  972 */     if (viewName.startsWith("redirect:")) {
/*  973 */       vrlogger.trace("[THYMELEAF] View \"{}\" is a redirect, and will not be handled directly by ThymeleafReactiveViewResolver.", viewName);
/*  974 */       String redirectUrl = viewName.substring("redirect:".length());
/*  975 */       RedirectView view = this.redirectViewProvider.apply(redirectUrl);
/*      */       
/*  977 */       RedirectView initializedView = (RedirectView)getApplicationContext().getAutowireCapableBeanFactory().initializeBean(view, "redirect:");
/*  978 */       return Mono.just(initializedView);
/*      */     } 
/*      */     
/*  981 */     if (viewName.startsWith("forward:")) {
/*  982 */       vrlogger.trace("[THYMELEAF] View \"{}\" is a forward, and will not be handled directly by ThymeleafReactiveViewResolver.", viewName);
/*      */       
/*  984 */       return Mono.error(new UnsupportedOperationException("Forwards are not currently supported by ThymeleafReactiveViewResolver"));
/*      */     } 
/*      */     
/*  987 */     if (this.alwaysProcessRedirectAndForward && !canHandle(viewName, locale)) {
/*  988 */       vrlogger.trace("[THYMELEAF] View \"{}\" cannot be handled by ThymeleafReactiveViewResolver. Passing on to the next resolver in the chain.", viewName);
/*  989 */       return Mono.empty();
/*      */     } 
/*  991 */     vrlogger.trace("[THYMELEAF] View {} will be handled by ThymeleafReactiveViewResolver and a {} instance will be created for it", viewName, 
/*  992 */         getViewClass().getSimpleName());
/*  993 */     return loadView(viewName, locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Mono<View> loadView(String viewName, Locale locale) {
/*      */     ThymeleafReactiveView view;
/* 1005 */     AutowireCapableBeanFactory beanFactory = getApplicationContext().getAutowireCapableBeanFactory();
/*      */     
/* 1007 */     boolean viewBeanExists = beanFactory.containsBean(viewName);
/* 1008 */     Class<?> viewBeanType = viewBeanExists ? beanFactory.getType(viewName) : null;
/*      */ 
/*      */     
/* 1011 */     if (viewBeanExists && viewBeanType != null && ThymeleafReactiveView.class.isAssignableFrom(viewBeanType)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1024 */       BeanDefinition viewBeanDefinition = (beanFactory instanceof ConfigurableListableBeanFactory) ? ((ConfigurableListableBeanFactory)beanFactory).getBeanDefinition(viewName) : null;
/*      */       
/* 1026 */       if (viewBeanDefinition == null || !viewBeanDefinition.isPrototype()) {
/*      */         
/* 1028 */         ThymeleafReactiveView viewInstance = (ThymeleafReactiveView)BeanUtils.instantiateClass(getViewClass());
/* 1029 */         view = (ThymeleafReactiveView)beanFactory.configureBean(viewInstance, viewName);
/*      */       } else {
/*      */         
/* 1032 */         view = (ThymeleafReactiveView)beanFactory.getBean(viewName);
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1037 */       ThymeleafReactiveView viewInstance = (ThymeleafReactiveView)BeanUtils.instantiateClass(getViewClass());
/*      */       
/* 1039 */       if (viewBeanExists && viewBeanType == null) {
/*      */ 
/*      */ 
/*      */         
/* 1043 */         beanFactory.autowireBeanProperties(viewInstance, 0, false);
/*      */         
/* 1045 */         beanFactory.applyBeanPropertyValues(viewInstance, viewName);
/*      */         
/* 1047 */         view = (ThymeleafReactiveView)beanFactory.initializeBean(viewInstance, viewName);
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1053 */         beanFactory.autowireBeanProperties(viewInstance, 0, false);
/*      */         
/* 1055 */         view = (ThymeleafReactiveView)beanFactory.initializeBean(viewInstance, viewName);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1061 */     view.setTemplateEngine(getTemplateEngine());
/* 1062 */     view.setStaticVariables(getStaticVariables());
/*      */ 
/*      */     
/* 1065 */     if (view.getTemplateName() == null) {
/* 1066 */       view.setTemplateName(viewName);
/*      */     }
/*      */ 
/*      */     
/* 1070 */     if (!view.isSupportedMediaTypesSet()) {
/* 1071 */       view.setSupportedMediaTypes(getSupportedMediaTypes());
/*      */     }
/*      */ 
/*      */     
/* 1075 */     if (!view.isDefaultCharsetSet()) {
/* 1076 */       view.setDefaultCharset(getDefaultCharset());
/*      */     }
/*      */ 
/*      */     
/* 1080 */     if (locale != null && view.getLocale() == null) {
/* 1081 */       view.setLocale(locale);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1090 */     boolean shouldUseChunkedExecution = shouldUseChunkedExecution(viewName);
/*      */     
/* 1092 */     if (shouldUseChunkedExecution && view.getNullableResponseMaxChunkSize() == null) {
/* 1093 */       view.setResponseMaxChunkSizeBytes(getResponseMaxChunkSizeBytes());
/*      */     }
/*      */     
/* 1096 */     return Mono.just(view);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\view\reactive\ThymeleafReactiveViewResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */