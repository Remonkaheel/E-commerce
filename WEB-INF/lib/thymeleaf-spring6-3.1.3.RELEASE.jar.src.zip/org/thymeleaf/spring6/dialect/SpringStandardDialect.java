/*     */ package org.thymeleaf.spring6.dialect;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.web.server.ServerWebExchange;
/*     */ import org.thymeleaf.expression.IExpressionObjectFactory;
/*     */ import org.thymeleaf.processor.IProcessor;
/*     */ import org.thymeleaf.spring6.expression.SPELVariableExpressionEvaluator;
/*     */ import org.thymeleaf.spring6.expression.SpringStandardConversionService;
/*     */ import org.thymeleaf.spring6.expression.SpringStandardExpressionObjectFactory;
/*     */ import org.thymeleaf.spring6.processor.SpringActionTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringErrorClassTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringErrorsTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringHrefTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringInputCheckboxFieldTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringInputFileFieldTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringInputGeneralFieldTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringInputPasswordFieldTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringInputRadioFieldTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringMethodTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringObjectTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringOptionFieldTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringOptionInSelectFieldTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringSelectFieldTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringSrcTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringTextareaFieldTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringUErrorsTagProcessor;
/*     */ import org.thymeleaf.spring6.processor.SpringValueTagProcessor;
/*     */ import org.thymeleaf.spring6.util.SpringReactiveModelAdditionsUtils;
/*     */ import org.thymeleaf.spring6.util.SpringVersionUtils;
/*     */ import org.thymeleaf.standard.StandardDialect;
/*     */ import org.thymeleaf.standard.expression.IStandardConversionService;
/*     */ import org.thymeleaf.standard.expression.IStandardVariableExpressionEvaluator;
/*     */ import org.thymeleaf.templatemode.TemplateMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringStandardDialect
/*     */   extends StandardDialect
/*     */ {
/*     */   public static final String NAME = "SpringStandard";
/*     */   public static final String PREFIX = "th";
/*     */   public static final int PROCESSOR_PRECEDENCE = 1000;
/*     */   public static final boolean DEFAULT_ENABLE_SPRING_EL_COMPILER = false;
/*     */   public static final boolean DEFAULT_RENDER_HIDDEN_MARKERS_BEFORE_CHECKBOXES = false;
/*     */   private boolean enableSpringELCompiler = false;
/*     */   private boolean renderHiddenMarkersBeforeCheckboxes = false;
/*     */   private static final Map<String, Object> REACTIVE_MODEL_ADDITIONS_EXECUTION_ATTRIBUTES;
/* 111 */   private static final String REACTIVE_MODEL_ADDITIONS_WEB_SESSION_NAME = SpringReactiveModelAdditionsUtils.toReactiveModelAdditionName("thymeleafWebSession");
/*     */   
/* 113 */   private static final String REACTIVE_MODEL_ADDITIONS_WEB_EXCHANGE_PRINCIPAL_NAME = SpringReactiveModelAdditionsUtils.toReactiveModelAdditionName("thymeleafWebExchangePrincipal");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 136 */     if (!SpringVersionUtils.isSpringWebFluxPresent()) {
/*     */       
/* 138 */       REACTIVE_MODEL_ADDITIONS_EXECUTION_ATTRIBUTES = Collections.emptyMap();
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 143 */       Function<ServerWebExchange, Object> webSessionInitializer = exchange -> exchange.getSession();
/*     */       
/* 145 */       Function<ServerWebExchange, Object> webExchangePrincipalInitializer = exchange -> exchange.getPrincipal();
/*     */       
/* 147 */       REACTIVE_MODEL_ADDITIONS_EXECUTION_ATTRIBUTES = new HashMap<>();
/* 148 */       REACTIVE_MODEL_ADDITIONS_EXECUTION_ATTRIBUTES.put(REACTIVE_MODEL_ADDITIONS_WEB_SESSION_NAME, webSessionInitializer);
/*     */       
/* 150 */       REACTIVE_MODEL_ADDITIONS_EXECUTION_ATTRIBUTES.put(REACTIVE_MODEL_ADDITIONS_WEB_EXCHANGE_PRINCIPAL_NAME, webExchangePrincipalInitializer);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringStandardDialect() {
/* 159 */     super("SpringStandard", "th", 1000);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getEnableSpringELCompiler() {
/* 187 */     return this.enableSpringELCompiler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnableSpringELCompiler(boolean enableSpringELCompiler) {
/* 213 */     this.enableSpringELCompiler = enableSpringELCompiler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getRenderHiddenMarkersBeforeCheckboxes() {
/* 245 */     return this.renderHiddenMarkersBeforeCheckboxes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRenderHiddenMarkersBeforeCheckboxes(boolean renderHiddenMarkersBeforeCheckboxes) {
/* 276 */     this.renderHiddenMarkersBeforeCheckboxes = renderHiddenMarkersBeforeCheckboxes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStandardVariableExpressionEvaluator getVariableExpressionEvaluator() {
/* 284 */     return (IStandardVariableExpressionEvaluator)SPELVariableExpressionEvaluator.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVariableExpressionEvaluator(IStandardVariableExpressionEvaluator variableExpressionEvaluator) {
/* 289 */     throw new UnsupportedOperationException("Variable Expression Evaluator cannot be modified in SpringStandardDialect");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IStandardConversionService getConversionService() {
/* 297 */     if (this.conversionService == null) {
/* 298 */       this.conversionService = (IStandardConversionService)new SpringStandardConversionService();
/*     */     }
/* 300 */     return this.conversionService;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IExpressionObjectFactory getExpressionObjectFactory() {
/* 306 */     if (this.expressionObjectFactory == null) {
/* 307 */       this.expressionObjectFactory = (IExpressionObjectFactory)new SpringStandardExpressionObjectFactory();
/*     */     }
/* 309 */     return this.expressionObjectFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<IProcessor> getProcessors(String dialectPrefix) {
/* 317 */     return createSpringStandardProcessorsSet(dialectPrefix, this.renderHiddenMarkersBeforeCheckboxes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Object> getExecutionAttributes() {
/* 325 */     Map<String, Object> executionAttributes = super.getExecutionAttributes();
/* 326 */     executionAttributes.putAll(REACTIVE_MODEL_ADDITIONS_EXECUTION_ATTRIBUTES);
/* 327 */     executionAttributes.put("EnableSpringELCompiler", 
/* 328 */         Boolean.valueOf(getEnableSpringELCompiler()));
/*     */     
/* 330 */     return executionAttributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<IProcessor> createSpringStandardProcessorsSet(String dialectPrefix) {
/* 347 */     return createSpringStandardProcessorsSet(dialectPrefix, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set<IProcessor> createSpringStandardProcessorsSet(String dialectPrefix, boolean renderHiddenMarkersBeforeCheckboxes) {
/* 373 */     Set<IProcessor> standardProcessors = StandardDialect.createStandardProcessorsSet(dialectPrefix);
/*     */     
/* 375 */     Set<IProcessor> processors = new LinkedHashSet<>(40);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 381 */     for (IProcessor standardProcessor : standardProcessors) {
/*     */       
/* 383 */       if (!(standardProcessor instanceof org.thymeleaf.standard.processor.StandardObjectTagProcessor) && !(standardProcessor instanceof org.thymeleaf.standard.processor.StandardActionTagProcessor) && !(standardProcessor instanceof org.thymeleaf.standard.processor.StandardHrefTagProcessor) && !(standardProcessor instanceof org.thymeleaf.standard.processor.StandardMethodTagProcessor) && !(standardProcessor instanceof org.thymeleaf.standard.processor.StandardSrcTagProcessor) && !(standardProcessor instanceof org.thymeleaf.standard.processor.StandardValueTagProcessor)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 390 */         processors.add(standardProcessor); continue;
/*     */       } 
/* 392 */       if (standardProcessor.getTemplateMode() != TemplateMode.HTML)
/*     */       {
/* 394 */         processors.add(standardProcessor);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 402 */     processors.add(new SpringActionTagProcessor(dialectPrefix));
/* 403 */     processors.add(new SpringHrefTagProcessor(dialectPrefix));
/* 404 */     processors.add(new SpringMethodTagProcessor(dialectPrefix));
/* 405 */     processors.add(new SpringSrcTagProcessor(dialectPrefix));
/* 406 */     processors.add(new SpringValueTagProcessor(dialectPrefix));
/* 407 */     processors.add(new SpringObjectTagProcessor(dialectPrefix));
/* 408 */     processors.add(new SpringErrorsTagProcessor(dialectPrefix));
/* 409 */     processors.add(new SpringUErrorsTagProcessor(dialectPrefix));
/* 410 */     processors.add(new SpringInputGeneralFieldTagProcessor(dialectPrefix));
/* 411 */     processors.add(new SpringInputPasswordFieldTagProcessor(dialectPrefix));
/* 412 */     processors.add(new SpringInputCheckboxFieldTagProcessor(dialectPrefix, renderHiddenMarkersBeforeCheckboxes));
/* 413 */     processors.add(new SpringInputRadioFieldTagProcessor(dialectPrefix));
/* 414 */     processors.add(new SpringInputFileFieldTagProcessor(dialectPrefix));
/* 415 */     processors.add(new SpringSelectFieldTagProcessor(dialectPrefix));
/* 416 */     processors.add(new SpringOptionInSelectFieldTagProcessor(dialectPrefix));
/* 417 */     processors.add(new SpringOptionFieldTagProcessor(dialectPrefix));
/* 418 */     processors.add(new SpringTextareaFieldTagProcessor(dialectPrefix));
/* 419 */     processors.add(new SpringErrorClassTagProcessor(dialectPrefix));
/*     */     
/* 421 */     return processors;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\dialect\SpringStandardDialect.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */