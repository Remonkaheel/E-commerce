/*    */ package org.thymeleaf.spring6.context.webmvc;
/*    */ 
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import java.util.Map;
/*    */ import org.springframework.web.servlet.support.RequestDataValueProcessor;
/*    */ import org.thymeleaf.spring6.context.IThymeleafRequestDataValueProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SpringWebMvcThymeleafRequestDataValueProcessor
/*    */   implements IThymeleafRequestDataValueProcessor
/*    */ {
/*    */   private final RequestDataValueProcessor requestDataValueProcessor;
/*    */   private final HttpServletRequest httpServletRequest;
/*    */   
/*    */   SpringWebMvcThymeleafRequestDataValueProcessor(RequestDataValueProcessor requestDataValueProcessor, HttpServletRequest httpServletRequest) {
/* 52 */     this.requestDataValueProcessor = requestDataValueProcessor;
/* 53 */     this.httpServletRequest = httpServletRequest;
/*    */   }
/*    */ 
/*    */   
/*    */   public String processAction(String action, String httpMethod) {
/* 58 */     if (this.requestDataValueProcessor == null)
/*    */     {
/* 60 */       return action;
/*    */     }
/* 62 */     return this.requestDataValueProcessor.processAction(this.httpServletRequest, action, httpMethod);
/*    */   }
/*    */ 
/*    */   
/*    */   public String processFormFieldValue(String name, String value, String type) {
/* 67 */     if (this.requestDataValueProcessor == null)
/*    */     {
/* 69 */       return value;
/*    */     }
/* 71 */     return this.requestDataValueProcessor.processFormFieldValue(this.httpServletRequest, name, value, type);
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, String> getExtraHiddenFields() {
/* 76 */     if (this.requestDataValueProcessor == null)
/*    */     {
/* 78 */       return null;
/*    */     }
/* 80 */     return this.requestDataValueProcessor.getExtraHiddenFields(this.httpServletRequest);
/*    */   }
/*    */ 
/*    */   
/*    */   public String processUrl(String url) {
/* 85 */     if (this.requestDataValueProcessor == null)
/*    */     {
/* 87 */       return url;
/*    */     }
/* 89 */     return this.requestDataValueProcessor.processUrl(this.httpServletRequest, url);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\context\webmvc\SpringWebMvcThymeleafRequestDataValueProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */