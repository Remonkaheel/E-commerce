/*     */ package org.thymeleaf.spring6.context.webmvc;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.TimeZone;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceResolvable;
/*     */ import org.springframework.context.NoSuchMessageException;
/*     */ import org.springframework.ui.context.Theme;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.web.servlet.support.BindStatus;
/*     */ import org.springframework.web.servlet.support.RequestContext;
/*     */ import org.thymeleaf.spring6.context.IThymeleafBindStatus;
/*     */ import org.thymeleaf.spring6.context.IThymeleafRequestContext;
/*     */ import org.thymeleaf.spring6.context.IThymeleafRequestDataValueProcessor;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringWebMvcThymeleafRequestContext
/*     */   implements IThymeleafRequestContext
/*     */ {
/*     */   private final RequestContext requestContext;
/*     */   private final HttpServletRequest httpServletRequest;
/*     */   private final SpringWebMvcThymeleafRequestDataValueProcessor thymeleafRequestDataValueProcessor;
/*     */   
/*     */   public SpringWebMvcThymeleafRequestContext(RequestContext requestContext, HttpServletRequest httpServletRequest) {
/*  64 */     Validate.notNull(requestContext, "Spring WebMVC RequestContext cannot be null");
/*  65 */     Validate.notNull(httpServletRequest, "HttpServletRequest cannot be null");
/*  66 */     this.requestContext = requestContext;
/*  67 */     this.httpServletRequest = httpServletRequest;
/*  68 */     this
/*     */       
/*  70 */       .thymeleafRequestDataValueProcessor = new SpringWebMvcThymeleafRequestDataValueProcessor(this.requestContext.getRequestDataValueProcessor(), httpServletRequest);
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpServletRequest getHttpServletRequest() {
/*  75 */     return this.httpServletRequest;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MessageSource getMessageSource() {
/*  81 */     return this.requestContext.getMessageSource();
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> getModel() {
/*  86 */     return this.requestContext.getModel();
/*     */   }
/*     */ 
/*     */   
/*     */   public Locale getLocale() {
/*  91 */     return this.requestContext.getLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public TimeZone getTimeZone() {
/*  96 */     return this.requestContext.getTimeZone();
/*     */   }
/*     */ 
/*     */   
/*     */   public void changeLocale(Locale locale) {
/* 101 */     this.requestContext.changeLocale(locale);
/*     */   }
/*     */ 
/*     */   
/*     */   public void changeLocale(Locale locale, TimeZone timeZone) {
/* 106 */     this.requestContext.changeLocale(locale, timeZone);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDefaultHtmlEscape(boolean defaultHtmlEscape) {
/* 111 */     this.requestContext.setDefaultHtmlEscape(defaultHtmlEscape);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDefaultHtmlEscape() {
/* 116 */     return this.requestContext.isDefaultHtmlEscape();
/*     */   }
/*     */ 
/*     */   
/*     */   public Boolean getDefaultHtmlEscape() {
/* 121 */     return this.requestContext.getDefaultHtmlEscape();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContextPath() {
/* 126 */     return this.requestContext.getContextPath();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContextUrl(String relativeUrl) {
/* 131 */     return this.requestContext.getContextUrl(relativeUrl);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContextUrl(String relativeUrl, Map<String, ?> params) {
/* 136 */     return this.requestContext.getContextUrl(relativeUrl, params);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRequestPath() {
/* 141 */     return this.requestContext.getRequestUri();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getQueryString() {
/* 146 */     return this.requestContext.getQueryString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage(String code, String defaultMessage) {
/* 151 */     return this.requestContext.getMessage(code, defaultMessage);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage(String code, Object[] args, String defaultMessage) {
/* 156 */     return this.requestContext.getMessage(code, args, defaultMessage);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage(String code, List<?> args, String defaultMessage) {
/* 161 */     return this.requestContext.getMessage(code, args, defaultMessage);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage(String code, Object[] args, String defaultMessage, boolean htmlEscape) {
/* 166 */     return this.requestContext.getMessage(code, args, defaultMessage, htmlEscape);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage(String code) throws NoSuchMessageException {
/* 171 */     return this.requestContext.getMessage(code);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage(String code, Object[] args) throws NoSuchMessageException {
/* 176 */     return this.requestContext.getMessage(code, args);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage(String code, List<?> args) throws NoSuchMessageException {
/* 181 */     return this.requestContext.getMessage(code, args);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage(String code, Object[] args, boolean htmlEscape) throws NoSuchMessageException {
/* 186 */     return this.requestContext.getMessage(code, args, htmlEscape);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage(MessageSourceResolvable resolvable) throws NoSuchMessageException {
/* 191 */     return this.requestContext.getMessage(resolvable);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage(MessageSourceResolvable resolvable, boolean htmlEscape) throws NoSuchMessageException {
/* 196 */     return this.requestContext.getMessage(resolvable, htmlEscape);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<Errors> getErrors(String name) {
/* 201 */     return Optional.ofNullable(this.requestContext.getErrors(name));
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<Errors> getErrors(String name, boolean htmlEscape) {
/* 206 */     return Optional.ofNullable(this.requestContext.getErrors(name, htmlEscape));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Theme getTheme() {
/* 216 */     return this.requestContext.getTheme();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public IThymeleafRequestDataValueProcessor getRequestDataValueProcessor() {
/* 222 */     return this.thymeleafRequestDataValueProcessor;
/*     */   }
/*     */ 
/*     */   
/*     */   public IThymeleafBindStatus getBindStatus(String path) throws IllegalStateException {
/* 227 */     return Optional.<BindStatus>ofNullable(this.requestContext.getBindStatus(path)).map(SpringWebMvcThymeleafBindStatus::new).orElse(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public IThymeleafBindStatus getBindStatus(String path, boolean htmlEscape) throws IllegalStateException {
/* 232 */     return Optional.<BindStatus>ofNullable(this.requestContext.getBindStatus(path, htmlEscape)).map(SpringWebMvcThymeleafBindStatus::new).orElse(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 240 */     return this.requestContext.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\context\webmvc\SpringWebMvcThymeleafRequestContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */