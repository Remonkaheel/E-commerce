package org.thymeleaf.spring6.context.webflux;

import org.reactivestreams.Publisher;
import org.springframework.core.ReactiveAdapterRegistry;

public interface IReactiveDataDriverContextVariable {
  Publisher<Object> getDataStream(ReactiveAdapterRegistry paramReactiveAdapterRegistry);
  
  int getBufferSizeElements();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\context\webflux\IReactiveDataDriverContextVariable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */