/*    */ package org.thymeleaf.spring6.context.webflux;
/*    */ 
/*    */ import org.reactivestreams.Publisher;
/*    */ import org.springframework.core.ReactiveAdapter;
/*    */ import org.springframework.core.ReactiveAdapterRegistry;
/*    */ import org.thymeleaf.spring6.view.reactive.ThymeleafReactiveView;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReactiveContextVariableUtils
/*    */ {
/*    */   static Publisher<Object> computePublisherValue(Object asyncObj, ReactiveAdapterRegistry reactiveAdapterRegistry) {
/* 66 */     if (asyncObj instanceof Flux || asyncObj instanceof Mono)
/*    */     {
/*    */ 
/*    */       
/* 70 */       return (Publisher<Object>)asyncObj;
/*    */     }
/*    */ 
/*    */     
/* 74 */     if (reactiveAdapterRegistry == null) {
/* 75 */       throw new IllegalArgumentException("Could not initialize lazy reactive context variable (data driver or explicitly-set reactive wrapper):  Value is of class " + asyncObj
/*    */           
/* 77 */           .getClass().getName() + ", but no ReactiveAdapterRegistry has been set. This can happen if this context variable is used for rendering a template without going through a " + ThymeleafReactiveView.class
/*    */ 
/*    */           
/* 80 */           .getSimpleName() + " or if there is no ReactiveAdapterRegistry bean registered at the application context. In such cases, it is required that the wrapped lazy variable values are instances of either " + Flux.class
/*    */ 
/*    */           
/* 83 */           .getName() + " or " + Mono.class.getName() + ".");
/*    */     }
/*    */     
/* 86 */     ReactiveAdapter adapter = reactiveAdapterRegistry.getAdapter(null, asyncObj);
/* 87 */     if (adapter != null) {
/* 88 */       Publisher<Object> publisher = adapter.toPublisher(asyncObj);
/* 89 */       if (adapter.isMultiValue()) {
/* 90 */         return (Publisher<Object>)Flux.from(publisher);
/*    */       }
/* 92 */       return (Publisher<Object>)Mono.from(publisher);
/*    */     } 
/*    */ 
/*    */     
/* 96 */     throw new IllegalArgumentException("Reactive context variable (data driver or explicitly-set reactive wrapper) is of class " + asyncObj
/*    */         
/* 98 */         .getClass().getName() + ", but the ReactiveAdapterRegistry does not contain a valid adapter able to convert it into a supported reactive data stream.");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\context\webflux\ReactiveContextVariableUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */