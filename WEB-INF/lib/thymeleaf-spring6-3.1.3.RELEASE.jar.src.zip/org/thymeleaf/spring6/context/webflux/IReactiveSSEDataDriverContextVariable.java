package org.thymeleaf.spring6.context.webflux;

public interface IReactiveSSEDataDriverContextVariable extends IReactiveDataDriverContextVariable {
  String getSseEventsPrefix();
  
  long getSseEventsFirstID();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\context\webflux\IReactiveSSEDataDriverContextVariable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */