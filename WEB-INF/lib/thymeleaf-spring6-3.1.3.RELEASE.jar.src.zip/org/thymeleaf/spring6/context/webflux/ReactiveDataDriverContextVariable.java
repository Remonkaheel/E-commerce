/*     */ package org.thymeleaf.spring6.context.webflux;
/*     */ 
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReactiveDataDriverContextVariable
/*     */   implements IReactiveSSEDataDriverContextVariable
/*     */ {
/*     */   public static final int DEFAULT_DATA_DRIVER_BUFFER_SIZE_ELEMENTS = 10;
/*     */   public static final long DEFAULT_FIRST_EVENT_ID = 0L;
/*     */   private final Object dataStream;
/*     */   private final int dataStreamBufferSizeElements;
/*     */   private final String sseEventsPrefix;
/*     */   private final long sseEventsFirstID;
/*     */   
/*     */   public ReactiveDataDriverContextVariable(Object dataStream) {
/* 136 */     this(dataStream, 10, null, 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactiveDataDriverContextVariable(Object dataStream, int dataStreamBufferSizeElements) {
/* 167 */     this(dataStream, dataStreamBufferSizeElements, null, 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactiveDataDriverContextVariable(Object dataStream, int dataStreamBufferSizeElements, String sseEventsPrefix) {
/* 204 */     this(dataStream, dataStreamBufferSizeElements, sseEventsPrefix, 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactiveDataDriverContextVariable(Object dataStream, int dataStreamBufferSizeElements, long sseEventsFirstID) {
/* 240 */     this(dataStream, dataStreamBufferSizeElements, null, sseEventsFirstID);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReactiveDataDriverContextVariable(Object dataStream, int dataStreamBufferSizeElements, String sseEventsPrefix, long sseEventsFirstID) {
/* 280 */     Validate.notNull(dataStream, "Data stream cannot be null");
/* 281 */     Validate.isTrue((dataStreamBufferSizeElements > 0), "Data Buffer Size cannot be <= 0");
/*     */     
/* 283 */     Validate.isTrue((sseEventsFirstID >= 0L), "First Event ID cannot be < 0");
/* 284 */     this.dataStream = dataStream;
/* 285 */     this.dataStreamBufferSizeElements = dataStreamBufferSizeElements;
/* 286 */     this.sseEventsPrefix = sseEventsPrefix;
/* 287 */     this.sseEventsFirstID = sseEventsFirstID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Publisher<Object> getDataStream(ReactiveAdapterRegistry reactiveAdapterRegistry) {
/* 294 */     Publisher<Object> publisher = ReactiveContextVariableUtils.computePublisherValue(this.dataStream, reactiveAdapterRegistry);
/* 295 */     if (!(publisher instanceof reactor.core.publisher.Flux)) {
/* 296 */       throw new IllegalArgumentException("Reactive Data Driver context variable was set single-valued asynchronous object. But data driver variables must wrap multi-valued data streams (so that they can be iterated at the template");
/*     */     }
/*     */ 
/*     */     
/* 300 */     return publisher;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getBufferSizeElements() {
/* 306 */     return this.dataStreamBufferSizeElements;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getSseEventsPrefix() {
/* 312 */     return this.sseEventsPrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final long getSseEventsFirstID() {
/* 318 */     return this.sseEventsFirstID;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\context\webflux\ReactiveDataDriverContextVariable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */