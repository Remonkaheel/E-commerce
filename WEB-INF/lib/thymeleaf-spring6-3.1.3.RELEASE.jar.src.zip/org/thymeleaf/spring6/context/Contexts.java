/*    */ package org.thymeleaf.spring6.context;
/*    */ 
/*    */ import org.thymeleaf.context.IContext;
/*    */ import org.thymeleaf.context.IEngineContext;
/*    */ import org.thymeleaf.context.IWebContext;
/*    */ import org.thymeleaf.spring6.web.webflux.ISpringWebFluxWebExchange;
/*    */ import org.thymeleaf.web.IWebExchange;
/*    */ import org.thymeleaf.web.servlet.IServletWebExchange;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Contexts
/*    */ {
/*    */   public static boolean isEngineContext(IContext context) {
/* 38 */     return org.thymeleaf.context.Contexts.isEngineContext(context);
/*    */   }
/*    */   
/*    */   public static IEngineContext asEngineContext(IContext context) {
/* 42 */     return org.thymeleaf.context.Contexts.asEngineContext(context);
/*    */   }
/*    */   
/*    */   public static boolean isWebContext(IContext context) {
/* 46 */     return org.thymeleaf.context.Contexts.isWebContext(context);
/*    */   }
/*    */   
/*    */   public static IWebContext asWebContext(IContext context) {
/* 50 */     return org.thymeleaf.context.Contexts.asWebContext(context);
/*    */   }
/*    */   
/*    */   public static IWebExchange getWebExchange(IContext context) {
/* 54 */     return org.thymeleaf.context.Contexts.getWebExchange(context);
/*    */   }
/*    */   
/*    */   public static boolean isServletWebContext(IContext context) {
/* 58 */     return org.thymeleaf.context.Contexts.isServletWebContext(context);
/*    */   }
/*    */   
/*    */   public static IServletWebExchange getServletWebExchange(IContext context) {
/* 62 */     return org.thymeleaf.context.Contexts.getServletWebExchange(context);
/*    */   }
/*    */   
/*    */   public static boolean isSpringWebFluxWebContext(IContext context) {
/* 66 */     return (isWebContext(context) && asWebContext(context).getExchange() instanceof ISpringWebFluxWebExchange);
/*    */   }
/*    */   
/*    */   public static ISpringWebFluxWebExchange getSpringWebFluxWebExchange(IContext context) {
/* 70 */     return (ISpringWebFluxWebExchange)asWebContext(context).getExchange();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\context\Contexts.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */