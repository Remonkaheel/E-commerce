package org.thymeleaf.spring6.context;

import java.util.Map;

public interface IThymeleafRequestDataValueProcessor {
  String processAction(String paramString1, String paramString2);
  
  String processFormFieldValue(String paramString1, String paramString2, String paramString3);
  
  Map<String, String> getExtraHiddenFields();
  
  String processUrl(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\context\IThymeleafRequestDataValueProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */