package org.thymeleaf.spring6.context;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.NoSuchMessageException;
import org.springframework.ui.context.Theme;
import org.springframework.validation.Errors;

public interface IThymeleafRequestContext {
  MessageSource getMessageSource();
  
  Map<String, Object> getModel();
  
  Locale getLocale();
  
  TimeZone getTimeZone();
  
  void changeLocale(Locale paramLocale);
  
  void changeLocale(Locale paramLocale, TimeZone paramTimeZone);
  
  void setDefaultHtmlEscape(boolean paramBoolean);
  
  boolean isDefaultHtmlEscape();
  
  Boolean getDefaultHtmlEscape();
  
  String getContextPath();
  
  String getContextUrl(String paramString);
  
  String getContextUrl(String paramString, Map<String, ?> paramMap);
  
  String getRequestPath();
  
  String getQueryString();
  
  String getMessage(String paramString1, String paramString2);
  
  String getMessage(String paramString1, Object[] paramArrayOfObject, String paramString2);
  
  String getMessage(String paramString1, List<?> paramList, String paramString2);
  
  String getMessage(String paramString1, Object[] paramArrayOfObject, String paramString2, boolean paramBoolean);
  
  String getMessage(String paramString) throws NoSuchMessageException;
  
  String getMessage(String paramString, Object[] paramArrayOfObject) throws NoSuchMessageException;
  
  String getMessage(String paramString, List<?> paramList) throws NoSuchMessageException;
  
  String getMessage(String paramString, Object[] paramArrayOfObject, boolean paramBoolean) throws NoSuchMessageException;
  
  String getMessage(MessageSourceResolvable paramMessageSourceResolvable) throws NoSuchMessageException;
  
  String getMessage(MessageSourceResolvable paramMessageSourceResolvable, boolean paramBoolean) throws NoSuchMessageException;
  
  Optional<Errors> getErrors(String paramString);
  
  Optional<Errors> getErrors(String paramString, boolean paramBoolean);
  
  @Deprecated
  Theme getTheme();
  
  IThymeleafRequestDataValueProcessor getRequestDataValueProcessor();
  
  IThymeleafBindStatus getBindStatus(String paramString) throws IllegalStateException;
  
  IThymeleafBindStatus getBindStatus(String paramString, boolean paramBoolean) throws IllegalStateException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\context\IThymeleafRequestContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */