package org.thymeleaf.spring6.context;

import java.beans.PropertyEditor;
import org.springframework.validation.Errors;

public interface IThymeleafBindStatus {
  String getPath();
  
  String getExpression();
  
  Object getValue();
  
  Class<?> getValueType();
  
  Object getActualValue();
  
  String getDisplayValue();
  
  boolean isError();
  
  String[] getErrorCodes();
  
  String getErrorCode();
  
  String[] getErrorMessages();
  
  String getErrorMessage();
  
  String getErrorMessagesAsString(String paramString);
  
  Errors getErrors();
  
  PropertyEditor getEditor();
  
  PropertyEditor findEditor(Class<?> paramClass);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\context\IThymeleafBindStatus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */