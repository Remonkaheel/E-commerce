/*     */ package org.thymeleaf.spring6.context;
/*     */ 
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.thymeleaf.context.IExpressionContext;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.spring6.expression.IThymeleafEvaluationContext;
/*     */ import org.thymeleaf.spring6.expression.ThymeleafEvaluationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringContextUtils
/*     */ {
/*     */   public static final String WEB_SESSION_ATTRIBUTE_NAME = "thymeleafWebSession";
/*     */   public static final String WEB_EXCHANGE_PRINCIPAL_ATTRIBUTE_NAME = "thymeleafWebExchangePrincipal";
/*     */   
/*     */   public static ApplicationContext getApplicationContext(ITemplateContext context) {
/*  96 */     if (context == null) {
/*  97 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 101 */     IThymeleafEvaluationContext evaluationContext = (IThymeleafEvaluationContext)context.getVariable("thymeleaf::EvaluationContext");
/* 102 */     if (evaluationContext == null || !(evaluationContext instanceof ThymeleafEvaluationContext)) {
/* 103 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     return ((ThymeleafEvaluationContext)evaluationContext).getApplicationContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IThymeleafRequestContext getRequestContext(IExpressionContext context) {
/* 132 */     if (context == null) {
/* 133 */       return null;
/*     */     }
/* 135 */     return (IThymeleafRequestContext)context.getVariable("thymeleafRequestContext");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\context\SpringContextUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */