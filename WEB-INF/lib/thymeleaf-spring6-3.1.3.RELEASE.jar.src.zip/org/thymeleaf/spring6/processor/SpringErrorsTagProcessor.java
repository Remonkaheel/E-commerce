/*    */ package org.thymeleaf.spring6.processor;
/*    */ 
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.spring6.context.IThymeleafBindStatus;
/*    */ import org.thymeleaf.spring6.util.FieldUtils;
/*    */ import org.thymeleaf.spring6.util.SpringValueFormatter;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.unbescape.html.HtmlEscape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringErrorsTagProcessor
/*    */   extends AbstractAttributeTagProcessor
/*    */ {
/*    */   private static final String ERROR_DELIMITER = "<br />";
/*    */   public static final int ATTR_PRECEDENCE = 1700;
/*    */   public static final String ATTR_NAME = "errors";
/*    */   
/*    */   public SpringErrorsTagProcessor(String dialectPrefix) {
/* 53 */     super(TemplateMode.HTML, dialectPrefix, null, false, "errors", true, 1700, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler) {
/* 65 */     IThymeleafBindStatus bindStatus = FieldUtils.getBindStatus((IExpressionContext)context, attributeValue);
/*    */     
/* 67 */     if (bindStatus.isError()) {
/*    */       
/* 69 */       StringBuilder strBuilder = new StringBuilder();
/* 70 */       String[] errorMsgs = bindStatus.getErrorMessages();
/*    */       
/* 72 */       for (int i = 0; i < errorMsgs.length; i++) {
/* 73 */         if (i > 0) {
/* 74 */           strBuilder.append("<br />");
/*    */         }
/* 76 */         String displayString = SpringValueFormatter.getDisplayString(errorMsgs[i], false);
/* 77 */         strBuilder.append(HtmlEscape.escapeHtml4Xml(displayString));
/*    */       } 
/*    */       
/* 80 */       structureHandler.setBody(strBuilder.toString(), false);
/*    */ 
/*    */       
/* 83 */       structureHandler.setLocalVariable("thymeleafFieldBindStatus", bindStatus);
/*    */     }
/*    */     else {
/*    */       
/* 87 */       structureHandler.removeElement();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\processor\SpringErrorsTagProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */