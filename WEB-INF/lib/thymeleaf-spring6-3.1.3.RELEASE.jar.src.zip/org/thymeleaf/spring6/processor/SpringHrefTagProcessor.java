/*    */ package org.thymeleaf.spring6.processor;
/*    */ 
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeDefinition;
/*    */ import org.thymeleaf.engine.AttributeDefinitions;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.engine.IAttributeDefinitionsAware;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.spring6.requestdata.RequestDataValueProcessorUtils;
/*    */ import org.thymeleaf.standard.processor.AbstractStandardExpressionAttributeTagProcessor;
/*    */ import org.thymeleaf.standard.util.StandardProcessorUtils;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ import org.thymeleaf.util.Validate;
/*    */ import org.unbescape.html.HtmlEscape;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringHrefTagProcessor
/*    */   extends AbstractStandardExpressionAttributeTagProcessor
/*    */   implements IAttributeDefinitionsAware
/*    */ {
/*    */   public static final int ATTR_PRECEDENCE = 1000;
/*    */   public static final String ATTR_NAME = "href";
/* 52 */   private static final TemplateMode TEMPLATE_MODE = TemplateMode.HTML;
/*    */ 
/*    */   
/*    */   private AttributeDefinition targetAttributeDefinition;
/*    */ 
/*    */ 
/*    */   
/*    */   public SpringHrefTagProcessor(String dialectPrefix) {
/* 60 */     super(TEMPLATE_MODE, dialectPrefix, "href", 1000, false, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAttributeDefinitions(AttributeDefinitions attributeDefinitions) {
/* 67 */     Validate.notNull(attributeDefinitions, "Attribute Definitions cannot be null");
/*    */ 
/*    */     
/* 70 */     this.targetAttributeDefinition = attributeDefinitions.forName(TEMPLATE_MODE, "href");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected final void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, Object expressionResult, IElementTagStructureHandler structureHandler) {
/* 84 */     String newAttributeValue = HtmlEscape.escapeHtml4Xml((expressionResult == null) ? "" : expressionResult.toString());
/*    */ 
/*    */     
/* 87 */     newAttributeValue = RequestDataValueProcessorUtils.processUrl(context, newAttributeValue);
/*    */ 
/*    */     
/* 90 */     StandardProcessorUtils.replaceAttribute(structureHandler, attributeName, this.targetAttributeDefinition, "href", (newAttributeValue == null) ? "" : newAttributeValue);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\processor\SpringHrefTagProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */