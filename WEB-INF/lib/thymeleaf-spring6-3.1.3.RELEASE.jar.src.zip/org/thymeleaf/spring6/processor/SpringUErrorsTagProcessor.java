/*    */ package org.thymeleaf.spring6.processor;
/*    */ 
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.engine.AttributeName;
/*    */ import org.thymeleaf.model.IProcessableElementTag;
/*    */ import org.thymeleaf.processor.element.AbstractAttributeTagProcessor;
/*    */ import org.thymeleaf.processor.element.IElementTagStructureHandler;
/*    */ import org.thymeleaf.spring6.context.IThymeleafBindStatus;
/*    */ import org.thymeleaf.spring6.util.FieldUtils;
/*    */ import org.thymeleaf.spring6.util.SpringValueFormatter;
/*    */ import org.thymeleaf.templatemode.TemplateMode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringUErrorsTagProcessor
/*    */   extends AbstractAttributeTagProcessor
/*    */ {
/*    */   private static final String ERROR_DELIMITER = "<br />";
/*    */   public static final int ATTR_PRECEDENCE = 1700;
/*    */   public static final String ATTR_NAME = "uerrors";
/*    */   
/*    */   public SpringUErrorsTagProcessor(String dialectPrefix) {
/* 52 */     super(TemplateMode.HTML, dialectPrefix, null, false, "uerrors", true, 1700, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doProcess(ITemplateContext context, IProcessableElementTag tag, AttributeName attributeName, String attributeValue, IElementTagStructureHandler structureHandler) {
/* 64 */     IThymeleafBindStatus bindStatus = FieldUtils.getBindStatus((IExpressionContext)context, attributeValue);
/*    */     
/* 66 */     if (bindStatus.isError()) {
/*    */       
/* 68 */       StringBuilder strBuilder = new StringBuilder();
/* 69 */       String[] errorMsgs = bindStatus.getErrorMessages();
/*    */       
/* 71 */       for (int i = 0; i < errorMsgs.length; i++) {
/* 72 */         if (i > 0) {
/* 73 */           strBuilder.append("<br />");
/*    */         }
/* 75 */         String displayString = SpringValueFormatter.getDisplayString(errorMsgs[i], false);
/* 76 */         strBuilder.append(displayString);
/*    */       } 
/*    */       
/* 79 */       structureHandler.setBody(strBuilder.toString(), false);
/*    */ 
/*    */       
/* 82 */       structureHandler.setLocalVariable("thymeleafFieldBindStatus", bindStatus);
/*    */     }
/*    */     else {
/*    */       
/* 86 */       structureHandler.removeElement();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\processor\SpringUErrorsTagProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */