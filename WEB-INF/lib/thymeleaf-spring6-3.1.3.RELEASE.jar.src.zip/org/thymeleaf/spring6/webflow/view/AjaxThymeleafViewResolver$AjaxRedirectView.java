/*     */ package org.thymeleaf.spring6.webflow.view;
/*     */ 
/*     */ import jakarta.servlet.http.HttpServletRequest;
/*     */ import jakarta.servlet.http.HttpServletResponse;
/*     */ import java.io.IOException;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.web.servlet.view.RedirectView;
/*     */ import org.springframework.webflow.context.servlet.AjaxHandler;
/*     */ import org.springframework.webflow.context.servlet.DefaultAjaxHandler;
/*     */ import org.thymeleaf.exceptions.ConfigurationException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AjaxRedirectView
/*     */   extends RedirectView
/*     */ {
/* 150 */   private static final Logger vlogger = LoggerFactory.getLogger(AjaxRedirectView.class);
/*     */   
/* 152 */   private AjaxHandler ajaxHandler = (AjaxHandler)new DefaultAjaxHandler();
/*     */ 
/*     */   
/*     */   AjaxRedirectView(AjaxHandler ajaxHandler, String redirectUrl, boolean redirectContextRelative, boolean redirectHttp10Compatible) {
/* 156 */     super(redirectUrl, redirectContextRelative, redirectHttp10Compatible);
/* 157 */     this.ajaxHandler = ajaxHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendRedirect(HttpServletRequest request, HttpServletResponse response, String targetUrl, boolean http10Compatible) throws IOException {
/* 165 */     if (this.ajaxHandler == null) {
/* 166 */       throw new ConfigurationException("[THYMELEAF] AJAX Handler set into " + AjaxThymeleafViewResolver.class
/* 167 */           .getSimpleName() + " instance is null.");
/*     */     }
/*     */     
/* 170 */     if (this.ajaxHandler.isAjaxRequest(request, response)) {
/* 171 */       if (vlogger.isTraceEnabled()) {
/* 172 */         vlogger.trace("[THYMELEAF] RedirectView for URL \"{}\" is an AJAX request. AjaxHandler of class {} will be in charge of processing the request.", targetUrl, this.ajaxHandler
/*     */             
/* 174 */             .getClass().getName());
/*     */       }
/* 176 */       this.ajaxHandler.sendAjaxRedirect(targetUrl, request, response, false);
/*     */     } else {
/* 178 */       vlogger.trace("[THYMELEAF] RedirectView for URL \"{}\" is not an AJAX request. Request will be handled as a normal redirect", targetUrl);
/*     */ 
/*     */       
/* 181 */       super.sendRedirect(request, response, targetUrl, http10Compatible);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\webflow\view\AjaxThymeleafViewResolver$AjaxRedirectView.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */