package org.thymeleaf.spring6.webflow.view;

import org.springframework.web.servlet.View;
import org.springframework.webflow.context.servlet.AjaxHandler;

public interface AjaxEnabledView extends View {
  AjaxHandler getAjaxHandler();
  
  void setAjaxHandler(AjaxHandler paramAjaxHandler);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\webflow\view\AjaxEnabledView.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */