/*    */ package org.thymeleaf.spring6.requestdata;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.thymeleaf.context.IExpressionContext;
/*    */ import org.thymeleaf.context.ITemplateContext;
/*    */ import org.thymeleaf.spring6.context.IThymeleafRequestContext;
/*    */ import org.thymeleaf.spring6.context.SpringContextUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RequestDataValueProcessorUtils
/*    */ {
/*    */   public static String processAction(ITemplateContext context, String action, String httpMethod) {
/* 47 */     IThymeleafRequestContext thymeleafRequestContext = SpringContextUtils.getRequestContext((IExpressionContext)context);
/* 48 */     if (thymeleafRequestContext == null) {
/* 49 */       return action;
/*    */     }
/*    */     
/* 52 */     return thymeleafRequestContext.getRequestDataValueProcessor().processAction(action, httpMethod);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String processFormFieldValue(ITemplateContext context, String name, String value, String type) {
/* 61 */     IThymeleafRequestContext thymeleafRequestContext = SpringContextUtils.getRequestContext((IExpressionContext)context);
/* 62 */     if (thymeleafRequestContext == null) {
/* 63 */       return value;
/*    */     }
/*    */     
/* 66 */     return thymeleafRequestContext.getRequestDataValueProcessor().processFormFieldValue(name, value, type);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Map<String, String> getExtraHiddenFields(ITemplateContext context) {
/* 74 */     IThymeleafRequestContext thymeleafRequestContext = SpringContextUtils.getRequestContext((IExpressionContext)context);
/* 75 */     if (thymeleafRequestContext == null) {
/* 76 */       return null;
/*    */     }
/*    */     
/* 79 */     return thymeleafRequestContext.getRequestDataValueProcessor().getExtraHiddenFields();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String processUrl(ITemplateContext context, String url) {
/* 87 */     IThymeleafRequestContext thymeleafRequestContext = SpringContextUtils.getRequestContext((IExpressionContext)context);
/* 88 */     if (thymeleafRequestContext == null) {
/* 89 */       return url;
/*    */     }
/*    */     
/* 92 */     return thymeleafRequestContext.getRequestDataValueProcessor().processUrl(url);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\requestdata\RequestDataValueProcessorUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */