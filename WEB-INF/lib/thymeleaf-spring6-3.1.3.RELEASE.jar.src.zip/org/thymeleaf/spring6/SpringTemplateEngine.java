/*     */ package org.thymeleaf.spring6;
/*     */ 
/*     */ import java.util.Set;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.dialect.IDialect;
/*     */ import org.thymeleaf.messageresolver.IMessageResolver;
/*     */ import org.thymeleaf.messageresolver.StandardMessageResolver;
/*     */ import org.thymeleaf.spring6.dialect.SpringStandardDialect;
/*     */ import org.thymeleaf.spring6.messageresolver.SpringMessageResolver;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringTemplateEngine
/*     */   extends TemplateEngine
/*     */   implements ISpringTemplateEngine, MessageSourceAware
/*     */ {
/*  59 */   private static final SpringStandardDialect SPRINGSTANDARD_DIALECT = new SpringStandardDialect();
/*     */   
/*  61 */   private MessageSource messageSource = null;
/*  62 */   private MessageSource templateEngineMessageSource = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SpringTemplateEngine() {
/*  70 */     setDialect((IDialect)SPRINGSTANDARD_DIALECT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/*  95 */     this.messageSource = messageSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTemplateEngineMessageSource(MessageSource templateEngineMessageSource) {
/* 111 */     this.templateEngineMessageSource = templateEngineMessageSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getEnableSpringELCompiler() {
/* 145 */     Set<IDialect> dialects = getDialects();
/* 146 */     for (IDialect dialect : dialects) {
/* 147 */       if (dialect instanceof SpringStandardDialect) {
/* 148 */         return ((SpringStandardDialect)dialect).getEnableSpringELCompiler();
/*     */       }
/*     */     } 
/* 151 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnableSpringELCompiler(boolean enableSpringELCompiler) {
/* 183 */     Set<IDialect> dialects = getDialects();
/* 184 */     for (IDialect dialect : dialects) {
/* 185 */       if (dialect instanceof SpringStandardDialect) {
/* 186 */         ((SpringStandardDialect)dialect).setEnableSpringELCompiler(enableSpringELCompiler);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getRenderHiddenMarkersBeforeCheckboxes() {
/* 226 */     Set<IDialect> dialects = getDialects();
/* 227 */     for (IDialect dialect : dialects) {
/* 228 */       if (dialect instanceof SpringStandardDialect) {
/* 229 */         return ((SpringStandardDialect)dialect).getRenderHiddenMarkersBeforeCheckboxes();
/*     */       }
/*     */     } 
/* 232 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRenderHiddenMarkersBeforeCheckboxes(boolean renderHiddenMarkersBeforeCheckboxes) {
/* 269 */     Set<IDialect> dialects = getDialects();
/* 270 */     for (IDialect dialect : dialects) {
/* 271 */       if (dialect instanceof SpringStandardDialect) {
/* 272 */         ((SpringStandardDialect)dialect).setRenderHiddenMarkersBeforeCheckboxes(renderHiddenMarkersBeforeCheckboxes);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void initializeSpecific() {
/*     */     StandardMessageResolver standardMessageResolver;
/* 284 */     MessageSource messageSource = (this.templateEngineMessageSource == null) ? this.messageSource : this.templateEngineMessageSource;
/*     */ 
/*     */     
/* 287 */     if (messageSource != null) {
/* 288 */       SpringMessageResolver springMessageResolver = new SpringMessageResolver();
/* 289 */       springMessageResolver.setMessageSource(messageSource);
/* 290 */       SpringMessageResolver springMessageResolver1 = springMessageResolver;
/*     */     } else {
/* 292 */       standardMessageResolver = new StandardMessageResolver();
/*     */     } 
/*     */     
/* 295 */     setMessageResolver((IMessageResolver)standardMessageResolver);
/*     */ 
/*     */     
/* 298 */     initializeSpringSpecific();
/*     */   }
/*     */   
/*     */   protected void initializeSpringSpecific() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\SpringTemplateEngine.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */