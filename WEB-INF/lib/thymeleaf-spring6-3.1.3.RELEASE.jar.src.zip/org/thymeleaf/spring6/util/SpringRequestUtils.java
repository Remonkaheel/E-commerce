/*     */ package org.thymeleaf.spring6.util;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.thymeleaf.exceptions.TemplateProcessingException;
/*     */ import org.thymeleaf.util.StringUtils;
/*     */ import org.thymeleaf.web.IWebRequest;
/*     */ import org.unbescape.uri.UriEscape;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringRequestUtils
/*     */ {
/*     */   public static void checkViewNameNotInRequest(String viewName, IWebRequest request) {
/*  42 */     String vn = StringUtils.pack(viewName);
/*     */     
/*  44 */     if (!containsExpression(vn)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  50 */     boolean found = false;
/*     */ 
/*     */     
/*  53 */     String pathWithinApplication = StringUtils.pack(UriEscape.unescapeUriPath(request.getPathWithinApplication()));
/*  54 */     if (pathWithinApplication != null && containsExpression(pathWithinApplication))
/*     */     {
/*  56 */       found = true;
/*     */     }
/*     */     
/*  59 */     if (!found) {
/*  60 */       Map<String, String[]> parameterMap = request.getParameterMap();
/*  61 */       if (parameterMap != null && !parameterMap.isEmpty()) {
/*  62 */         for (String[] parameterValues : parameterMap.values()) {
/*  63 */           for (int i = 0; !found && i < parameterValues.length; i++) {
/*  64 */             String parameterValue = StringUtils.pack(parameterValues[i]);
/*  65 */             if (parameterValue != null && containsExpression(parameterValue) && vn.contains(parameterValue))
/*     */             {
/*  67 */               found = true;
/*     */             }
/*     */           } 
/*  70 */           if (found) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/*  77 */     if (found) {
/*  78 */       throw new TemplateProcessingException("View name contains an expression and so does either the URL path or one of the request parameters. This is forbidden in order to reduce the possibilities that direct user input is executed as a part of the view name.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean containsExpression(String text) {
/*  88 */     int textLen = text.length();
/*     */     
/*  90 */     boolean expInit = false;
/*  91 */     for (int i = 0; i < textLen; i++) {
/*  92 */       char c = text.charAt(i);
/*  93 */       if (!expInit) {
/*  94 */         if (c == '$' || c == '*' || c == '#' || c == '@' || c == '~') {
/*  95 */           expInit = true;
/*     */         }
/*     */       } else {
/*  98 */         if (c == '{')
/*  99 */           return true; 
/* 100 */         if (!Character.isWhitespace(c)) {
/* 101 */           expInit = false;
/*     */         }
/*     */       } 
/*     */     } 
/* 105 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring\\util\SpringRequestUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */