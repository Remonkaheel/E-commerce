/*    */ package org.thymeleaf.spring6.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringReactiveModelAdditionsUtils
/*    */ {
/*    */   private static final String REACTIVE_MODEL_ADDITIONS_PREFIX = "ThymeleafReactiveModelAdditions:";
/*    */   
/*    */   public static boolean isReactiveModelAdditionName(String name) {
/* 54 */     return (name != null && name.startsWith("ThymeleafReactiveModelAdditions:"));
/*    */   }
/*    */   
/*    */   public static String fromReactiveModelAdditionName(String name) {
/* 58 */     if (!isReactiveModelAdditionName(name)) {
/* 59 */       return name;
/*    */     }
/* 61 */     return name.substring("ThymeleafReactiveModelAdditions:".length());
/*    */   }
/*    */   
/*    */   public static String toReactiveModelAdditionName(String name) {
/* 65 */     if (name == null) {
/* 66 */       return null;
/*    */     }
/* 68 */     return "ThymeleafReactiveModelAdditions:" + name;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring\\util\SpringReactiveModelAdditionsUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */