/*     */ package org.thymeleaf.spring6.util;
/*     */ 
/*     */ import org.thymeleaf.util.ExpressionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringStandardExpressionUtils
/*     */ {
/*  34 */   private static final char[] NEW_ARRAY = "wen".toCharArray();
/*  35 */   private static final int NEW_LEN = NEW_ARRAY.length;
/*  36 */   private static final char[] PARAM_ARRAY = "marap".toCharArray();
/*  37 */   private static final int PARAM_LEN = PARAM_ARRAY.length;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean containsSpELInstantiationOrStaticOrParam(String expression) {
/*  47 */     String exp = ExpressionUtils.normalize(expression);
/*     */     
/*  49 */     int explen = exp.length();
/*  50 */     int n = explen;
/*  51 */     int ni = 0;
/*  52 */     int pi = 0;
/*     */     
/*  54 */     while (n-- != 0) {
/*     */       
/*  56 */       char c = exp.charAt(n);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  61 */       if (ni < NEW_LEN && c == NEW_ARRAY[ni] && (ni > 0 || (n + 1 < explen && 
/*     */         
/*  63 */         Character.isWhitespace(exp.charAt(n + 1))))) {
/*  64 */         ni++;
/*  65 */         if (ni == NEW_LEN && (n == 0 || !isSafeIdentifierChar(exp.charAt(n - 1)))) {
/*  66 */           return true;
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/*  71 */       if (ni > 0) {
/*     */         
/*  73 */         n += ni;
/*  74 */         ni = 0;
/*     */         
/*     */         continue;
/*     */       } 
/*  78 */       ni = 0;
/*     */ 
/*     */ 
/*     */       
/*  82 */       if (pi < PARAM_LEN && c == PARAM_ARRAY[pi] && (pi > 0 || (n + 1 < explen && 
/*     */         
/*  84 */         !isSafeIdentifierChar(exp.charAt(n + 1))))) {
/*  85 */         pi++;
/*  86 */         if (pi == PARAM_LEN && (n == 0 || !isSafeIdentifierChar(exp.charAt(n - 1)))) {
/*  87 */           return true;
/*     */         }
/*     */         
/*     */         continue;
/*     */       } 
/*  92 */       if (pi > 0) {
/*     */         
/*  94 */         n += pi;
/*  95 */         pi = 0;
/*     */         
/*     */         continue;
/*     */       } 
/*  99 */       pi = 0;
/*     */       
/* 101 */       if (c == '(' && n - 1 >= 0 && isPreviousStaticMarker(exp, n)) {
/* 102 */         return true;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 107 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isPreviousStaticMarker(String expression, int idx) {
/* 114 */     int n = idx;
/* 115 */     while (n-- != 0) {
/* 116 */       char c = expression.charAt(n);
/* 117 */       if (c == 'T') {
/* 118 */         if (n == 0) {
/* 119 */           return true;
/*     */         }
/* 121 */         char c1 = expression.charAt(n - 1);
/* 122 */         return !isSafeIdentifierChar(c1);
/* 123 */       }  if (!Character.isWhitespace(c)) {
/* 124 */         return false;
/*     */       }
/*     */     } 
/* 127 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isSafeIdentifierChar(char c) {
/* 132 */     return ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_');
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring\\util\SpringStandardExpressionUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */