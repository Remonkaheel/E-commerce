/*    */ package org.thymeleaf.spring6.util;
/*    */ 
/*    */ import java.beans.PropertyEditor;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ import org.springframework.web.util.HtmlUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringValueFormatter
/*    */ {
/*    */   public static String getDisplayString(Object value, boolean htmlEscape) {
/* 51 */     String displayValue = ObjectUtils.getDisplayString(value);
/* 52 */     return htmlEscape ? HtmlUtils.htmlEscape(displayValue) : displayValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public static String getDisplayString(Object value, PropertyEditor propertyEditor, boolean htmlEscape) {
/* 57 */     if (propertyEditor != null && !(value instanceof String)) {
/*    */       try {
/* 59 */         propertyEditor.setValue(value);
/* 60 */         String text = propertyEditor.getAsText();
/* 61 */         if (text != null) {
/* 62 */           return getDisplayString(text, htmlEscape);
/*    */         }
/* 64 */       } catch (Throwable throwable) {}
/*    */     }
/*    */ 
/*    */     
/* 68 */     return getDisplayString(value, htmlEscape);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring\\util\SpringValueFormatter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */