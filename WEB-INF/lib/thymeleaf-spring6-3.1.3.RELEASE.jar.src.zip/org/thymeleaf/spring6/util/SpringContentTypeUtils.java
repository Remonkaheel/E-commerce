/*    */ package org.thymeleaf.spring6.util;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import org.springframework.http.MediaType;
/*    */ import org.springframework.web.servlet.View;
/*    */ import org.thymeleaf.util.ContentTypeUtils;
/*    */ import org.thymeleaf.web.IWebExchange;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringContentTypeUtils
/*    */ {
/*    */   public static String computeViewContentType(IWebExchange webExchange, String defaultContentType, Charset defaultCharset) {
/* 49 */     if (webExchange == null) {
/* 50 */       throw new IllegalArgumentException("Request cannot be null");
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 56 */     MediaType negotiatedMediaType = (MediaType)webExchange.getAttributeValue(View.SELECTED_CONTENT_TYPE);
/* 57 */     if (negotiatedMediaType != null && negotiatedMediaType.isConcrete()) {
/* 58 */       Charset negotiatedCharset = negotiatedMediaType.getCharset();
/* 59 */       if (negotiatedCharset != null) {
/* 60 */         return negotiatedMediaType.toString();
/*    */       }
/* 62 */       return ContentTypeUtils.combineContentTypeAndCharset(negotiatedMediaType.toString(), defaultCharset);
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 70 */     String combinedContentType = ContentTypeUtils.combineContentTypeAndCharset(defaultContentType, defaultCharset);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 75 */     Charset combinedCharset = ContentTypeUtils.computeCharsetFromContentType(combinedContentType);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 80 */     String requestPathContentType = ContentTypeUtils.computeContentTypeForRequestPath(webExchange.getRequest().getRequestPath(), combinedCharset);
/* 81 */     if (requestPathContentType != null) {
/* 82 */       return requestPathContentType;
/*    */     }
/*    */ 
/*    */     
/* 86 */     return combinedContentType;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring\\util\SpringContentTypeUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */