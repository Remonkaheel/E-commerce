/*     */ package org.thymeleaf.spring6.messageresolver;
/*     */ 
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.NoSuchMessageException;
/*     */ import org.thymeleaf.TemplateEngine;
/*     */ import org.thymeleaf.context.ITemplateContext;
/*     */ import org.thymeleaf.exceptions.ConfigurationException;
/*     */ import org.thymeleaf.messageresolver.AbstractMessageResolver;
/*     */ import org.thymeleaf.messageresolver.StandardMessageResolver;
/*     */ import org.thymeleaf.util.Validate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpringMessageResolver
/*     */   extends AbstractMessageResolver
/*     */   implements MessageSourceAware
/*     */ {
/*  60 */   private static final Logger logger = LoggerFactory.getLogger(SpringMessageResolver.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private final StandardMessageResolver standardMessageResolver = new StandardMessageResolver();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MessageSource messageSource;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkMessageSourceInitialized() {
/*  80 */     if (this.messageSource == null) {
/*  81 */       throw new ConfigurationException("Cannot initialize " + SpringMessageResolver.class
/*  82 */           .getSimpleName() + ": MessageSource has not been set. Either define this object as a Spring bean (which will automatically set the MessageSource) or, if you instance it directly, set the MessageSource manually using its corresponding setter method.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MessageSource getMessageSource() {
/* 103 */     return this.messageSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setMessageSource(MessageSource messageSource) {
/* 115 */     this.messageSource = messageSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String resolveMessage(ITemplateContext context, Class<?> origin, String key, Object[] messageParameters) {
/* 125 */     Validate.notNull(context.getLocale(), "Locale in context cannot be null");
/* 126 */     Validate.notNull(key, "Message key cannot be null");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     if (context != null) {
/*     */       
/* 133 */       checkMessageSourceInitialized();
/*     */       
/* 135 */       if (logger.isTraceEnabled()) {
/* 136 */         logger.trace("[THYMELEAF][{}] Resolving message with key \"{}\" for template \"{}\" and locale \"{}\". Messages will be retrieved from Spring's MessageSource infrastructure.", new Object[] {
/*     */ 
/*     */               
/* 139 */               TemplateEngine.threadIndex(), key, context.getTemplateData().getTemplate(), context.getLocale()
/*     */             });
/*     */       }
/*     */       try {
/* 143 */         return this.messageSource.getMessage(key, messageParameters, context.getLocale());
/* 144 */       } catch (NoSuchMessageException noSuchMessageException) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     if (origin != null) {
/*     */ 
/*     */       
/* 156 */       String message = this.standardMessageResolver.resolveMessage(context, origin, key, messageParameters, false, true, true);
/* 157 */       if (message != null) {
/* 158 */         return message;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 166 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String createAbsentMessageRepresentation(ITemplateContext context, Class<?> origin, String key, Object[] messageParameters) {
/* 175 */     return this.standardMessageResolver.createAbsentMessageRepresentation(context, origin, key, messageParameters);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\messageresolver\SpringMessageResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */