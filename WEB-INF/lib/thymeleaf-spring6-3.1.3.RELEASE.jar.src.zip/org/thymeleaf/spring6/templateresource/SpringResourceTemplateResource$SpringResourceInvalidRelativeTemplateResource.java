/*     */ package org.thymeleaf.spring6.templateresource;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import org.thymeleaf.templateresource.ITemplateResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SpringResourceInvalidRelativeTemplateResource
/*     */   implements ITemplateResource
/*     */ {
/*     */   private final String originalResourceDescription;
/*     */   private final String relativeLocation;
/*     */   private final IOException ioException;
/*     */   
/*     */   SpringResourceInvalidRelativeTemplateResource(String originalResourceDescription, String relativeLocation, IOException ioException) {
/* 170 */     this.originalResourceDescription = originalResourceDescription;
/* 171 */     this.relativeLocation = relativeLocation;
/* 172 */     this.ioException = ioException;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 178 */     return "Invalid relative resource for relative location \"" + this.relativeLocation + "\" and original resource " + this.originalResourceDescription + ": " + this.ioException
/* 179 */       .getMessage();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getBaseName() {
/* 184 */     return "Invalid relative resource for relative location \"" + this.relativeLocation + "\" and original resource " + this.originalResourceDescription + ": " + this.ioException
/* 185 */       .getMessage();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean exists() {
/* 190 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Reader reader() throws IOException {
/* 195 */     throw new IOException("Invalid relative resource", this.ioException);
/*     */   }
/*     */ 
/*     */   
/*     */   public ITemplateResource relative(String relativeLocation) {
/* 200 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 205 */     return getDescription();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\thymeleaf-spring6-3.1.3.RELEASE.jar!\org\thymeleaf\spring6\templateresource\SpringResourceTemplateResource$SpringResourceInvalidRelativeTemplateResource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */