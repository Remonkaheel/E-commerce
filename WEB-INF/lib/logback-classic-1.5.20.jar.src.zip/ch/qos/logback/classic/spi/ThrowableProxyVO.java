/*     */ package ch.qos.logback.classic.spi;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThrowableProxyVO
/*     */   implements IThrowableProxy, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -773438177285807139L;
/*     */   private String className;
/*     */   private String message;
/*     */   private int commonFramesCount;
/*     */   private StackTraceElementProxy[] stackTraceElementProxyArray;
/*     */   private IThrowableProxy cause;
/*     */   private IThrowableProxy[] suppressed;
/*     */   private boolean cyclic;
/*     */   
/*     */   public String getMessage() {
/*  32 */     return this.message;
/*     */   }
/*     */   
/*     */   public String getClassName() {
/*  36 */     return this.className;
/*     */   }
/*     */   
/*     */   public int getCommonFrames() {
/*  40 */     return this.commonFramesCount;
/*     */   }
/*     */   
/*     */   public IThrowableProxy getCause() {
/*  44 */     return this.cause;
/*     */   }
/*     */   
/*     */   public StackTraceElementProxy[] getStackTraceElementProxyArray() {
/*  48 */     return this.stackTraceElementProxyArray;
/*     */   }
/*     */   
/*     */   public IThrowableProxy[] getSuppressed() {
/*  52 */     return this.suppressed;
/*     */   }
/*     */   
/*     */   public boolean isCyclic() {
/*  56 */     return this.cyclic;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  61 */     int prime = 31;
/*  62 */     int result = 1;
/*  63 */     result = 31 * result + ((this.className == null) ? 0 : this.className.hashCode());
/*  64 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  69 */     if (this == obj)
/*  70 */       return true; 
/*  71 */     if (obj == null)
/*  72 */       return false; 
/*  73 */     if (getClass() != obj.getClass())
/*  74 */       return false; 
/*  75 */     ThrowableProxyVO other = (ThrowableProxyVO)obj;
/*     */     
/*  77 */     if (this.className == null) {
/*  78 */       if (other.className != null)
/*  79 */         return false; 
/*  80 */     } else if (!this.className.equals(other.className)) {
/*  81 */       return false;
/*     */     } 
/*  83 */     if (!Arrays.equals((Object[])this.stackTraceElementProxyArray, (Object[])other.stackTraceElementProxyArray)) {
/*  84 */       return false;
/*     */     }
/*  86 */     if (!Arrays.equals((Object[])this.suppressed, (Object[])other.suppressed)) {
/*  87 */       return false;
/*     */     }
/*  89 */     if (this.cause == null) {
/*  90 */       if (other.cause != null)
/*  91 */         return false; 
/*  92 */     } else if (!this.cause.equals(other.cause)) {
/*  93 */       return false;
/*     */     } 
/*  95 */     return true;
/*     */   }
/*     */   
/*     */   public static ThrowableProxyVO build(IThrowableProxy throwableProxy) {
/*  99 */     if (throwableProxy == null) {
/* 100 */       return null;
/*     */     }
/* 102 */     ThrowableProxyVO tpvo = new ThrowableProxyVO();
/* 103 */     tpvo.className = throwableProxy.getClassName();
/* 104 */     tpvo.message = throwableProxy.getMessage();
/* 105 */     tpvo.commonFramesCount = throwableProxy.getCommonFrames();
/* 106 */     tpvo.stackTraceElementProxyArray = throwableProxy.getStackTraceElementProxyArray();
/* 107 */     tpvo.cyclic = throwableProxy.isCyclic();
/*     */     
/* 109 */     IThrowableProxy cause = throwableProxy.getCause();
/* 110 */     if (cause != null) {
/* 111 */       tpvo.cause = build(cause);
/*     */     }
/* 113 */     IThrowableProxy[] suppressed = throwableProxy.getSuppressed();
/* 114 */     if (suppressed != null) {
/* 115 */       tpvo.suppressed = new IThrowableProxy[suppressed.length];
/* 116 */       for (int i = 0; i < suppressed.length; i++) {
/* 117 */         tpvo.suppressed[i] = build(suppressed[i]);
/*     */       }
/*     */     } 
/*     */     
/* 121 */     return tpvo;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\spi\ThrowableProxyVO.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */