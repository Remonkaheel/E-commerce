/*    */ package ch.qos.logback.classic.spi;
/*    */ 
/*    */ import ch.qos.logback.classic.LoggerContext;
/*    */ import java.io.Serializable;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggerContextVO
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 5488023392483144387L;
/*    */   protected String name;
/*    */   protected Map<String, String> propertyMap;
/*    */   protected long birthTime;
/*    */   
/*    */   public LoggerContextVO(LoggerContext lc) {
/* 45 */     this.name = lc.getName();
/* 46 */     this.propertyMap = lc.getCopyOfPropertyMap();
/* 47 */     this.birthTime = lc.getBirthTime();
/*    */   }
/*    */   
/*    */   public LoggerContextVO(String name, Map<String, String> propertyMap, long birthTime) {
/* 51 */     this.name = name;
/* 52 */     this.propertyMap = propertyMap;
/* 53 */     this.birthTime = birthTime;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 57 */     return this.name;
/*    */   }
/*    */   
/*    */   public Map<String, String> getPropertyMap() {
/* 61 */     return this.propertyMap;
/*    */   }
/*    */   
/*    */   public long getBirthTime() {
/* 65 */     return this.birthTime;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 70 */     return "LoggerContextVO{name='" + this.name + "', propertyMap=" + String.valueOf(this.propertyMap) + ", birthTime=" + this.birthTime + "}";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object o) {
/* 76 */     if (this == o)
/* 77 */       return true; 
/* 78 */     if (!(o instanceof LoggerContextVO)) {
/* 79 */       return false;
/*    */     }
/* 81 */     LoggerContextVO that = (LoggerContextVO)o;
/*    */     
/* 83 */     if (this.birthTime != that.birthTime)
/* 84 */       return false; 
/* 85 */     if ((this.name != null) ? !this.name.equals(that.name) : (that.name != null))
/* 86 */       return false; 
/* 87 */     if ((this.propertyMap != null) ? !this.propertyMap.equals(that.propertyMap) : (that.propertyMap != null)) {
/* 88 */       return false;
/*    */     }
/* 90 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 95 */     int result = (this.name != null) ? this.name.hashCode() : 0;
/* 96 */     result = 31 * result + ((this.propertyMap != null) ? this.propertyMap.hashCode() : 0);
/* 97 */     result = 31 * result + (int)(this.birthTime ^ this.birthTime >>> 32L);
/*    */     
/* 99 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\spi\LoggerContextVO.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */