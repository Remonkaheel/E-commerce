/*    */ package ch.qos.logback.classic.spi;
/*    */ 
/*    */ import ch.qos.logback.classic.LoggerContext;
/*    */ import ch.qos.logback.classic.util.ContextInitializer;
/*    */ import ch.qos.logback.classic.util.LogbackMDCAdapter;
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.joran.spi.JoranException;
/*    */ import ch.qos.logback.core.status.StatusUtil;
/*    */ import ch.qos.logback.core.util.StatusPrinter;
/*    */ import org.slf4j.ILoggerFactory;
/*    */ import org.slf4j.IMarkerFactory;
/*    */ import org.slf4j.helpers.BasicMarkerFactory;
/*    */ import org.slf4j.helpers.Util;
/*    */ import org.slf4j.spi.MDCAdapter;
/*    */ import org.slf4j.spi.SLF4JServiceProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogbackServiceProvider
/*    */   implements SLF4JServiceProvider
/*    */ {
/*    */   static final String NULL_CS_URL = "https://logback.qos.ch/codes.html#null_CS";
/* 27 */   public static String REQUESTED_API_VERSION = "2.0.99";
/*    */   
/* 29 */   private LoggerContext defaultLoggerContext = new LoggerContext();
/*    */ 
/*    */ 
/*    */   
/* 33 */   private IMarkerFactory markerFactory = (IMarkerFactory)new BasicMarkerFactory();
/*    */ 
/*    */ 
/*    */   
/* 37 */   private LogbackMDCAdapter mdcAdapter = new LogbackMDCAdapter();
/*    */ 
/*    */   
/*    */   public void initialize() {
/* 41 */     this.defaultLoggerContext.setName("default");
/*    */     
/* 43 */     this.defaultLoggerContext.setMDCAdapter((MDCAdapter)this.mdcAdapter);
/* 44 */     initializeLoggerContext();
/* 45 */     this.defaultLoggerContext.start();
/*    */   }
/*    */   
/*    */   private void initializeLoggerContext() {
/*    */     try {
/*    */       try {
/* 51 */         (new ContextInitializer(this.defaultLoggerContext)).autoConfig();
/* 52 */       } catch (JoranException je) {
/* 53 */         Util.report("Failed to auto configure default logger context", (Throwable)je);
/*    */       } 
/*    */       
/* 56 */       if (!StatusUtil.contextHasStatusListener((Context)this.defaultLoggerContext)) {
/* 57 */         StatusPrinter.printInCaseOfErrorsOrWarnings((Context)this.defaultLoggerContext);
/*    */       
/*    */       }
/*    */     }
/* 61 */     catch (Exception t) {
/* 62 */       Util.report("Failed to instantiate [" + LoggerContext.class.getName() + "]", t);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ILoggerFactory getLoggerFactory() {
/* 69 */     return (ILoggerFactory)this.defaultLoggerContext;
/*    */   }
/*    */ 
/*    */   
/*    */   public IMarkerFactory getMarkerFactory() {
/* 74 */     return this.markerFactory;
/*    */   }
/*    */ 
/*    */   
/*    */   public MDCAdapter getMDCAdapter() {
/* 79 */     return (MDCAdapter)this.mdcAdapter;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getRequestedApiVersion() {
/* 84 */     return REQUESTED_API_VERSION;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\spi\LogbackServiceProvider.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */