/*    */ package ch.qos.logback.classic.spi;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ClassPackagingData
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -804643281218337001L;
/*    */   String codeLocation;
/*    */   String version;
/*    */   boolean exact;
/*    */   
/*    */   public ClassPackagingData() {}
/*    */   
/*    */   public ClassPackagingData(String codeLocation, String version) {
/* 31 */     this.codeLocation = codeLocation;
/* 32 */     this.version = version;
/* 33 */     this.exact = true;
/*    */   }
/*    */   
/*    */   public ClassPackagingData(String classLocation, String version, boolean exact) {
/* 37 */     this.codeLocation = classLocation;
/* 38 */     this.version = version;
/* 39 */     this.exact = exact;
/*    */   }
/*    */   
/*    */   public String getCodeLocation() {
/* 43 */     return this.codeLocation;
/*    */   }
/*    */   
/*    */   public String getVersion() {
/* 47 */     return this.version;
/*    */   }
/*    */   
/*    */   public boolean isExact() {
/* 51 */     return this.exact;
/*    */   }
/*    */   
/*    */   public void setCodeLocation(String codeLocation) {
/* 55 */     this.codeLocation = codeLocation;
/*    */   }
/*    */   
/*    */   public void setVersion(String version) {
/* 59 */     this.version = version;
/*    */   }
/*    */   
/*    */   public void setExact(boolean exact) {
/* 63 */     this.exact = exact;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 68 */     int PRIME = 31;
/* 69 */     int result = 1;
/* 70 */     result = 31 * result + ((this.codeLocation == null) ? 0 : this.codeLocation.hashCode());
/* 71 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 76 */     if (this == obj)
/* 77 */       return true; 
/* 78 */     if (obj == null)
/* 79 */       return false; 
/* 80 */     if (getClass() != obj.getClass())
/* 81 */       return false; 
/* 82 */     ClassPackagingData other = (ClassPackagingData)obj;
/* 83 */     if (this.codeLocation == null) {
/* 84 */       if (other.codeLocation != null)
/* 85 */         return false; 
/* 86 */     } else if (!this.codeLocation.equals(other.codeLocation)) {
/* 87 */       return false;
/* 88 */     }  if (this.exact != other.exact)
/* 89 */       return false; 
/* 90 */     if (this.version == null) {
/* 91 */       if (other.version != null)
/* 92 */         return false; 
/* 93 */     } else if (!this.version.equals(other.version)) {
/* 94 */       return false;
/* 95 */     }  return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\spi\ClassPackagingData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */