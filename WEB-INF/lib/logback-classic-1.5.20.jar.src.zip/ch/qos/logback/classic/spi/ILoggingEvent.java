/*     */ package ch.qos.logback.classic.spi;
/*     */ 
/*     */ import ch.qos.logback.classic.Level;
/*     */ import ch.qos.logback.core.spi.DeferredProcessingAware;
/*     */ import java.time.Instant;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.slf4j.Marker;
/*     */ import org.slf4j.event.KeyValuePair;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface ILoggingEvent
/*     */   extends DeferredProcessingAware
/*     */ {
/*     */   String getThreadName();
/*     */   
/*     */   Level getLevel();
/*     */   
/*     */   String getMessage();
/*     */   
/*     */   Object[] getArgumentArray();
/*     */   
/*     */   String getFormattedMessage();
/*     */   
/*     */   String getLoggerName();
/*     */   
/*     */   LoggerContextVO getLoggerContextVO();
/*     */   
/*     */   IThrowableProxy getThrowableProxy();
/*     */   
/*     */   StackTraceElement[] getCallerData();
/*     */   
/*     */   boolean hasCallerData();
/*     */   
/*     */   default Marker getMarker() {
/*  87 */     List<Marker> markers = getMarkerList();
/*  88 */     if (markers == null || markers.isEmpty()) {
/*  89 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  94 */     return markers.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<Marker> getMarkerList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map<String, String> getMDCPropertyMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map<String, String> getMdc();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getTimeStamp();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getNanoseconds();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default Instant getInstant() {
/* 147 */     return Instant.ofEpochMilli(getTimeStamp());
/*     */   }
/*     */   
/*     */   long getSequenceNumber();
/*     */   
/*     */   List<KeyValuePair> getKeyValuePairs();
/*     */   
/*     */   void prepareForDeferredProcessing();
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\spi\ILoggingEvent.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */