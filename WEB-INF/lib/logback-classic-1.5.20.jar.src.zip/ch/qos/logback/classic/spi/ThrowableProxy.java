/*     */ package ch.qos.logback.classic.spi;
/*     */ 
/*     */ import ch.qos.logback.core.CoreConstants;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ThrowableProxy
/*     */   implements IThrowableProxy
/*     */ {
/*  27 */   static final StackTraceElementProxy[] EMPTY_STEP = new StackTraceElementProxy[0];
/*     */   
/*     */   private Throwable throwable;
/*     */   
/*     */   private String className;
/*     */   
/*     */   private String message;
/*     */   StackTraceElementProxy[] stackTraceElementProxyArray;
/*     */   int commonFrames;
/*     */   private ThrowableProxy cause;
/*  37 */   private ThrowableProxy[] suppressed = NO_SUPPRESSED;
/*     */ 
/*     */   
/*     */   private transient PackagingDataCalculator packagingDataCalculator;
/*     */ 
/*     */   
/*     */   private boolean calculatedPackageData = false;
/*     */   
/*     */   private boolean cyclic;
/*     */   
/*  47 */   private static final ThrowableProxy[] NO_SUPPRESSED = new ThrowableProxy[0];
/*     */ 
/*     */   
/*     */   public ThrowableProxy(Throwable throwable) {
/*  51 */     this(throwable, Collections.newSetFromMap(new IdentityHashMap<>()));
/*     */   }
/*     */ 
/*     */   
/*     */   private ThrowableProxy(Throwable circular, boolean isCyclic) {
/*  56 */     this.throwable = circular;
/*  57 */     this.className = circular.getClass().getName();
/*  58 */     this.message = circular.getMessage();
/*  59 */     this.stackTraceElementProxyArray = EMPTY_STEP;
/*  60 */     this.cyclic = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public ThrowableProxy(Throwable throwable, Set<Throwable> alreadyProcessedSet) {
/*  65 */     this.throwable = throwable;
/*  66 */     this.className = throwable.getClass().getName();
/*  67 */     this.message = throwable.getMessage();
/*  68 */     this.stackTraceElementProxyArray = ThrowableProxyUtil.steArrayToStepArray(throwable.getStackTrace());
/*  69 */     this.cyclic = false;
/*     */     
/*  71 */     alreadyProcessedSet.add(throwable);
/*     */     
/*  73 */     Throwable nested = throwable.getCause();
/*  74 */     if (nested != null) {
/*  75 */       if (alreadyProcessedSet.contains(nested)) {
/*  76 */         this.cause = new ThrowableProxy(nested, true);
/*     */       } else {
/*  78 */         this.cause = new ThrowableProxy(nested, alreadyProcessedSet);
/*  79 */         this.cause.commonFrames = ThrowableProxyUtil.findNumberOfCommonFrames(nested.getStackTrace(), this.stackTraceElementProxyArray);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*  84 */     Throwable[] throwableSuppressed = throwable.getSuppressed();
/*     */ 
/*     */     
/*  87 */     if (OptionHelper.isNotEmtpy((Object[])throwableSuppressed)) {
/*  88 */       List<ThrowableProxy> suppressedList = new ArrayList<>(throwableSuppressed.length);
/*  89 */       for (Throwable sup : throwableSuppressed) {
/*  90 */         if (alreadyProcessedSet.contains(sup)) {
/*  91 */           ThrowableProxy throwableProxy = new ThrowableProxy(sup, true);
/*  92 */           suppressedList.add(throwableProxy);
/*     */         } else {
/*  94 */           ThrowableProxy throwableProxy = new ThrowableProxy(sup, alreadyProcessedSet);
/*  95 */           throwableProxy.commonFrames = ThrowableProxyUtil.findNumberOfCommonFrames(sup.getStackTrace(), this.stackTraceElementProxyArray);
/*     */           
/*  97 */           suppressedList.add(throwableProxy);
/*     */         } 
/*     */       } 
/* 100 */       this.suppressed = suppressedList.<ThrowableProxy>toArray(new ThrowableProxy[suppressedList.size()]);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Throwable getThrowable() {
/* 105 */     return this.throwable;
/*     */   }
/*     */   
/*     */   public String getMessage() {
/* 109 */     return this.message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 118 */     return this.className;
/*     */   }
/*     */   
/*     */   public StackTraceElementProxy[] getStackTraceElementProxyArray() {
/* 122 */     return this.stackTraceElementProxyArray;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCyclic() {
/* 127 */     return this.cyclic;
/*     */   }
/*     */   
/*     */   public int getCommonFrames() {
/* 131 */     return this.commonFrames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IThrowableProxy getCause() {
/* 140 */     return this.cause;
/*     */   }
/*     */   
/*     */   public IThrowableProxy[] getSuppressed() {
/* 144 */     return (IThrowableProxy[])this.suppressed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PackagingDataCalculator getPackagingDataCalculator() {
/* 151 */     if (this.throwable != null && this.packagingDataCalculator == null) {
/* 152 */       this.packagingDataCalculator = new PackagingDataCalculator();
/*     */     }
/* 154 */     return this.packagingDataCalculator;
/*     */   }
/*     */   
/*     */   public void calculatePackagingData() {
/* 158 */     if (this.calculatedPackageData) {
/*     */       return;
/*     */     }
/* 161 */     PackagingDataCalculator pdc = getPackagingDataCalculator();
/* 162 */     if (pdc != null) {
/* 163 */       this.calculatedPackageData = true;
/* 164 */       pdc.calculate(this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void fullDump() {
/* 169 */     StringBuilder builder = new StringBuilder();
/* 170 */     for (StackTraceElementProxy step : this.stackTraceElementProxyArray) {
/* 171 */       String string = step.toString();
/* 172 */       builder.append('\t').append(string);
/* 173 */       ThrowableProxyUtil.subjoinPackagingData(builder, step);
/* 174 */       builder.append(CoreConstants.LINE_SEPARATOR);
/*     */     } 
/* 176 */     System.out.println(builder.toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\spi\ThrowableProxy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */