/*     */ package ch.qos.logback.classic.spi;
/*     */ 
/*     */ import ch.qos.logback.classic.Level;
/*     */ import ch.qos.logback.classic.Logger;
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.classic.util.LogbackMDCAdapter;
/*     */ import ch.qos.logback.core.spi.SequenceNumberGenerator;
/*     */ import ch.qos.logback.core.util.EnvUtil;
/*     */ import ch.qos.logback.core.util.StringUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.time.Clock;
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.slf4j.Marker;
/*     */ import org.slf4j.event.KeyValuePair;
/*     */ import org.slf4j.helpers.MessageFormatter;
/*     */ import org.slf4j.spi.MDCAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggingEvent
/*     */   implements ILoggingEvent
/*     */ {
/*     */   public static final String VIRTUAL_THREAD_NAME_PREFIX = "virtual-";
/*     */   public static final String REGULAR_UNNAMED_THREAD_PREFIX = "unnamed-";
/*     */   transient String fqnOfLoggerClass;
/*     */   private String threadName;
/*     */   private String loggerName;
/*     */   private LoggerContext loggerContext;
/*     */   private LoggerContextVO loggerContextVO;
/*     */   private transient Level level;
/*     */   private String message;
/*     */   transient String formattedMessage;
/*     */   private transient Object[] argumentArray;
/*     */   private ThrowableProxy throwableProxy;
/*     */   private StackTraceElement[] callerDataArray;
/*     */   private List<Marker> markerList;
/*     */   private Map<String, String> mdcPropertyMap;
/*     */   List<KeyValuePair> keyValuePairs;
/*     */   private Instant instant;
/*     */   private long timeStamp;
/*     */   private int nanoseconds;
/*     */   private long sequenceNumber;
/*     */   
/*     */   public LoggingEvent() {}
/*     */   
/*     */   public LoggingEvent(String fqcn, Logger logger, Level level, String message, Throwable throwable, Object[] argArray) {
/* 122 */     this.fqnOfLoggerClass = fqcn;
/* 123 */     this.loggerName = logger.getName();
/* 124 */     this.loggerContext = logger.getLoggerContext();
/* 125 */     this.loggerContextVO = this.loggerContext.getLoggerContextRemoteView();
/* 126 */     this.level = level;
/*     */     
/* 128 */     this.message = message;
/* 129 */     this.argumentArray = argArray;
/*     */     
/* 131 */     Instant instant = Clock.systemUTC().instant();
/* 132 */     initTmestampFields(instant);
/*     */     
/* 134 */     if (this.loggerContext != null) {
/* 135 */       SequenceNumberGenerator sequenceNumberGenerator = this.loggerContext.getSequenceNumberGenerator();
/* 136 */       if (sequenceNumberGenerator != null) {
/* 137 */         this.sequenceNumber = sequenceNumberGenerator.nextSequenceNumber();
/*     */       }
/*     */     } 
/* 140 */     if (throwable == null) {
/* 141 */       throwable = extractThrowableAndRearrangeArguments(argArray);
/*     */     }
/*     */     
/* 144 */     if (throwable != null) {
/* 145 */       this.throwableProxy = new ThrowableProxy(throwable);
/*     */       
/* 147 */       if (this.loggerContext != null && this.loggerContext.isPackagingDataEnabled()) {
/* 148 */         this.throwableProxy.calculatePackagingData();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   void initTmestampFields(Instant instant) {
/* 154 */     this.instant = instant;
/* 155 */     long epochSecond = instant.getEpochSecond();
/* 156 */     this.nanoseconds = instant.getNano();
/* 157 */     long milliseconds = (this.nanoseconds / 1000000);
/* 158 */     this.timeStamp = epochSecond * 1000L + milliseconds;
/*     */   }
/*     */   
/*     */   private Throwable extractThrowableAndRearrangeArguments(Object[] argArray) {
/* 162 */     Throwable extractedThrowable = EventArgUtil.extractThrowable(argArray);
/* 163 */     if (EventArgUtil.successfulExtraction(extractedThrowable)) {
/* 164 */       this.argumentArray = EventArgUtil.trimmedCopy(argArray);
/*     */     }
/* 166 */     return extractedThrowable;
/*     */   }
/*     */   
/*     */   public void setArgumentArray(Object[] argArray) {
/* 170 */     if (this.argumentArray != null) {
/* 171 */       throw new IllegalStateException("argArray has been already set");
/*     */     }
/* 173 */     this.argumentArray = argArray;
/*     */   }
/*     */   
/*     */   public Object[] getArgumentArray() {
/* 177 */     return this.argumentArray;
/*     */   }
/*     */   
/*     */   public void addKeyValuePair(KeyValuePair kvp) {
/* 181 */     if (this.keyValuePairs == null) {
/* 182 */       this.keyValuePairs = new ArrayList<>(4);
/*     */     }
/* 184 */     this.keyValuePairs.add(kvp);
/*     */   }
/*     */   
/*     */   public void setKeyValuePairs(List<KeyValuePair> kvpList) {
/* 188 */     this.keyValuePairs = kvpList;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<KeyValuePair> getKeyValuePairs() {
/* 193 */     return this.keyValuePairs;
/*     */   }
/*     */   
/*     */   public Level getLevel() {
/* 197 */     return this.level;
/*     */   }
/*     */   
/*     */   public String getLoggerName() {
/* 201 */     return this.loggerName;
/*     */   }
/*     */   
/*     */   public void setLoggerName(String loggerName) {
/* 205 */     this.loggerName = loggerName;
/*     */   }
/*     */   
/*     */   public String getThreadName() {
/* 209 */     if (this.threadName == null) {
/* 210 */       this.threadName = extractThreadName(Thread.currentThread());
/*     */     }
/* 212 */     return this.threadName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String extractThreadName(Thread aThread) {
/* 225 */     if (aThread == null) {
/* 226 */       return "?";
/*     */     }
/* 228 */     String threadName = aThread.getName();
/* 229 */     if (StringUtil.notNullNorEmpty(threadName))
/* 230 */       return threadName; 
/* 231 */     Long virtualThreadId = getVirtualThreadId(aThread);
/* 232 */     return (virtualThreadId != null) ? ("virtual-" + 
/* 233 */       virtualThreadId) : ("unnamed-" + 
/*     */       
/* 235 */       aThread.getId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Long getVirtualThreadId(Thread aThread) {
/* 247 */     if (EnvUtil.isJDK21OrHigher()) {
/*     */       try {
/* 249 */         Method isVirtualMethod = Thread.class.getMethod("isVirtual", new Class[0]);
/* 250 */         boolean isVirtual = ((Boolean)isVirtualMethod.invoke(aThread, new Object[0])).booleanValue();
/* 251 */         if (isVirtual)
/* 252 */           return Long.valueOf(aThread.getId()); 
/* 253 */       } catch (NoSuchMethodException|IllegalAccessException|java.lang.reflect.InvocationTargetException e) {
/* 254 */         return null;
/*     */       } 
/*     */     }
/* 257 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setThreadName(String threadName) throws IllegalStateException {
/* 265 */     if (this.threadName != null) {
/* 266 */       throw new IllegalStateException("threadName has been already set");
/*     */     }
/* 268 */     this.threadName = threadName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IThrowableProxy getThrowableProxy() {
/* 276 */     return this.throwableProxy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setThrowableProxy(ThrowableProxy tp) {
/* 283 */     if (this.throwableProxy != null) {
/* 284 */       throw new IllegalStateException("ThrowableProxy has been already set.");
/*     */     }
/* 286 */     this.throwableProxy = tp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void prepareForDeferredProcessing() {
/* 299 */     getFormattedMessage();
/* 300 */     getThreadName();
/*     */     
/* 302 */     getMDCPropertyMap();
/*     */   }
/*     */   
/*     */   public void setLoggerContext(LoggerContext lc) {
/* 306 */     this.loggerContext = lc;
/*     */   }
/*     */   
/*     */   public LoggerContextVO getLoggerContextVO() {
/* 310 */     return this.loggerContextVO;
/*     */   }
/*     */   
/*     */   public void setLoggerContextRemoteView(LoggerContextVO loggerContextVO) {
/* 314 */     this.loggerContextVO = loggerContextVO;
/*     */   }
/*     */   
/*     */   public String getMessage() {
/* 318 */     return this.message;
/*     */   }
/*     */   
/*     */   public void setMessage(String message) {
/* 322 */     if (this.message != null) {
/* 323 */       throw new IllegalStateException("The message for this event has been set already.");
/*     */     }
/* 325 */     this.message = message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Instant getInstant() {
/* 335 */     return this.instant;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInstant(Instant instant) {
/* 344 */     initTmestampFields(instant);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getTimeStamp() {
/* 351 */     return this.timeStamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNanoseconds() {
/* 361 */     return this.nanoseconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeStamp(long timeStamp) {
/* 371 */     Instant instant = Instant.ofEpochMilli(timeStamp);
/* 372 */     setInstant(instant);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getSequenceNumber() {
/* 377 */     return this.sequenceNumber;
/*     */   }
/*     */   
/*     */   public void setSequenceNumber(long sn) {
/* 381 */     this.sequenceNumber = sn;
/*     */   }
/*     */   
/*     */   public void setLevel(Level level) {
/* 385 */     if (this.level != null) {
/* 386 */       throw new IllegalStateException("The level has been already set for this event.");
/*     */     }
/* 388 */     this.level = level;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StackTraceElement[] getCallerData() {
/* 400 */     if (this.callerDataArray == null) {
/* 401 */       this.callerDataArray = CallerData.extract(new Throwable(), this.fqnOfLoggerClass, this.loggerContext
/* 402 */           .getMaxCallerDataDepth(), this.loggerContext.getFrameworkPackages());
/*     */     }
/* 404 */     return this.callerDataArray;
/*     */   }
/*     */   
/*     */   public boolean hasCallerData() {
/* 408 */     return (this.callerDataArray != null);
/*     */   }
/*     */   
/*     */   public void setCallerData(StackTraceElement[] callerDataArray) {
/* 412 */     this.callerDataArray = callerDataArray;
/*     */   }
/*     */   
/*     */   public List<Marker> getMarkerList() {
/* 416 */     return this.markerList;
/*     */   }
/*     */   
/*     */   public void addMarker(Marker marker) {
/* 420 */     if (marker == null) {
/*     */       return;
/*     */     }
/* 423 */     if (this.markerList == null) {
/* 424 */       this.markerList = new ArrayList<>(4);
/*     */     }
/* 426 */     this.markerList.add(marker);
/*     */   }
/*     */   
/*     */   public long getContextBirthTime() {
/* 430 */     return this.loggerContextVO.getBirthTime();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFormattedMessage() {
/* 435 */     if (this.formattedMessage != null) {
/* 436 */       return this.formattedMessage;
/*     */     }
/* 438 */     if (this.argumentArray != null) {
/* 439 */       if (this.throwableProxy == null) {
/* 440 */         this.formattedMessage = MessageFormatter.arrayFormat(this.message, this.argumentArray).getMessage();
/*     */       }
/*     */       else {
/*     */         
/* 444 */         this.formattedMessage = MessageFormatter.arrayFormat(this.message, this.argumentArray, null).getMessage();
/*     */       } 
/*     */     } else {
/* 447 */       this.formattedMessage = this.message;
/*     */     } 
/*     */     
/* 450 */     return this.formattedMessage;
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getMDCPropertyMap() {
/* 455 */     if (this.mdcPropertyMap == null) {
/* 456 */       MDCAdapter mdcAdapter = this.loggerContext.getMDCAdapter();
/* 457 */       if (mdcAdapter instanceof LogbackMDCAdapter) {
/* 458 */         this.mdcPropertyMap = ((LogbackMDCAdapter)mdcAdapter).getPropertyMap();
/*     */       } else {
/* 460 */         this.mdcPropertyMap = mdcAdapter.getCopyOfContextMap();
/*     */       } 
/*     */     } 
/* 463 */     if (this.mdcPropertyMap == null) {
/* 464 */       this.mdcPropertyMap = Collections.emptyMap();
/*     */     }
/* 466 */     return this.mdcPropertyMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMDCPropertyMap(Map<String, String> map) {
/* 476 */     if (this.mdcPropertyMap != null) {
/* 477 */       throw new IllegalStateException("The MDCPropertyMap has been already set for this event.");
/*     */     }
/* 479 */     this.mdcPropertyMap = map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getMdc() {
/* 489 */     return getMDCPropertyMap();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 494 */     StringBuilder sb = new StringBuilder();
/* 495 */     sb.append('[');
/* 496 */     sb.append(this.level).append("] ");
/* 497 */     sb.append(getFormattedMessage());
/* 498 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 508 */     throw new UnsupportedOperationException(String.valueOf(getClass()) + " does not support serialization. Use LoggerEventVO instance instead. See also LoggerEventVO.build method.");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\spi\LoggingEvent.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */