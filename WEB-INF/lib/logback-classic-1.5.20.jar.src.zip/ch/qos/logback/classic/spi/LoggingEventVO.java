/*     */ package ch.qos.logback.classic.spi;
/*     */ 
/*     */ import ch.qos.logback.classic.Level;
/*     */ import java.io.IOException;
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.slf4j.Marker;
/*     */ import org.slf4j.event.KeyValuePair;
/*     */ import org.slf4j.helpers.MessageFormatter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggingEventVO
/*     */   implements ILoggingEvent, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 6553722650255690312L;
/*     */   private static final int NULL_ARGUMENT_ARRAY = -1;
/*     */   private static final String NULL_ARGUMENT_ARRAY_ELEMENT = "NULL_ARGUMENT_ARRAY_ELEMENT";
/*     */   private static final int ARGUMENT_ARRAY_DESERIALIZATION_LIMIT = 128;
/*     */   private String threadName;
/*     */   private String loggerName;
/*     */   private LoggerContextVO loggerContextVO;
/*     */   private transient Level level;
/*     */   private String message;
/*     */   private transient String formattedMessage;
/*     */   private transient Object[] argumentArray;
/*     */   private ThrowableProxyVO throwableProxy;
/*     */   private StackTraceElement[] callerDataArray;
/*     */   private List<Marker> markerList;
/*     */   private List<KeyValuePair> keyValuePairList;
/*     */   private Map<String, String> mdcPropertyMap;
/*     */   private long timestamp;
/*     */   private int nanoseconds;
/*     */   private long sequenceNumber;
/*     */   
/*     */   public static LoggingEventVO build(ILoggingEvent le) {
/*  74 */     LoggingEventVO ledo = new LoggingEventVO();
/*  75 */     ledo.loggerName = le.getLoggerName();
/*  76 */     ledo.loggerContextVO = le.getLoggerContextVO();
/*  77 */     ledo.threadName = le.getThreadName();
/*  78 */     ledo.level = le.getLevel();
/*  79 */     ledo.message = le.getMessage();
/*  80 */     ledo.argumentArray = le.getArgumentArray();
/*  81 */     ledo.markerList = le.getMarkerList();
/*  82 */     ledo.keyValuePairList = le.getKeyValuePairs();
/*  83 */     ledo.mdcPropertyMap = le.getMDCPropertyMap();
/*  84 */     ledo.timestamp = le.getTimeStamp();
/*  85 */     ledo.nanoseconds = le.getNanoseconds();
/*  86 */     ledo.sequenceNumber = le.getSequenceNumber();
/*  87 */     ledo.throwableProxy = ThrowableProxyVO.build(le.getThrowableProxy());
/*     */ 
/*     */     
/*  90 */     if (le.hasCallerData()) {
/*  91 */       ledo.callerDataArray = le.getCallerData();
/*     */     }
/*  93 */     return ledo;
/*     */   }
/*     */   
/*     */   public String getThreadName() {
/*  97 */     return this.threadName;
/*     */   }
/*     */   
/*     */   public LoggerContextVO getLoggerContextVO() {
/* 101 */     return this.loggerContextVO;
/*     */   }
/*     */   
/*     */   public String getLoggerName() {
/* 105 */     return this.loggerName;
/*     */   }
/*     */   
/*     */   public Level getLevel() {
/* 109 */     return this.level;
/*     */   }
/*     */   
/*     */   public String getMessage() {
/* 113 */     return this.message;
/*     */   }
/*     */   
/*     */   public String getFormattedMessage() {
/* 117 */     if (this.formattedMessage != null) {
/* 118 */       return this.formattedMessage;
/*     */     }
/*     */     
/* 121 */     if (this.argumentArray != null) {
/* 122 */       this.formattedMessage = MessageFormatter.arrayFormat(this.message, this.argumentArray).getMessage();
/*     */     } else {
/* 124 */       this.formattedMessage = this.message;
/*     */     } 
/*     */     
/* 127 */     return this.formattedMessage;
/*     */   }
/*     */   
/*     */   public Object[] getArgumentArray() {
/* 131 */     return this.argumentArray;
/*     */   }
/*     */   
/*     */   public IThrowableProxy getThrowableProxy() {
/* 135 */     return this.throwableProxy;
/*     */   }
/*     */   
/*     */   public StackTraceElement[] getCallerData() {
/* 139 */     return this.callerDataArray;
/*     */   }
/*     */   
/*     */   public boolean hasCallerData() {
/* 143 */     return (this.callerDataArray != null);
/*     */   }
/*     */   
/*     */   public List<Marker> getMarkerList() {
/* 147 */     return this.markerList;
/*     */   }
/*     */   
/*     */   public long getTimeStamp() {
/* 151 */     return this.timestamp;
/*     */   }
/*     */   public int getNanoseconds() {
/* 154 */     return this.nanoseconds;
/*     */   }
/*     */   public long getSequenceNumber() {
/* 157 */     return this.sequenceNumber;
/*     */   }
/*     */   
/*     */   public long getContextBirthTime() {
/* 161 */     return this.loggerContextVO.getBirthTime();
/*     */   }
/*     */   
/*     */   public LoggerContextVO getContextLoggerRemoteView() {
/* 165 */     return this.loggerContextVO;
/*     */   }
/*     */   
/*     */   public Map<String, String> getMDCPropertyMap() {
/* 169 */     return this.mdcPropertyMap;
/*     */   }
/*     */   
/*     */   public Map<String, String> getMdc() {
/* 173 */     return this.mdcPropertyMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<KeyValuePair> getKeyValuePairs() {
/* 178 */     return this.keyValuePairList;
/*     */   }
/*     */ 
/*     */   
/*     */   public void prepareForDeferredProcessing() {}
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/* 185 */     out.defaultWriteObject();
/* 186 */     out.writeInt(this.level.levelInt);
/* 187 */     if (this.argumentArray != null) {
/* 188 */       int len = this.argumentArray.length;
/* 189 */       out.writeInt(len);
/* 190 */       for (int i = 0; i < this.argumentArray.length; i++) {
/* 191 */         if (this.argumentArray[i] != null) {
/* 192 */           out.writeObject(this.argumentArray[i].toString());
/*     */         } else {
/* 194 */           out.writeObject("NULL_ARGUMENT_ARRAY_ELEMENT");
/*     */         } 
/*     */       } 
/*     */     } else {
/* 198 */       out.writeInt(-1);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 204 */     in.defaultReadObject();
/* 205 */     int levelInt = in.readInt();
/* 206 */     this.level = Level.toLevel(levelInt);
/*     */     
/* 208 */     int argArrayLen = in.readInt();
/*     */ 
/*     */     
/* 211 */     if (argArrayLen < -1 || argArrayLen > 128) {
/* 212 */       throw new InvalidObjectException("Argument array length is invalid: " + argArrayLen);
/*     */     }
/*     */     
/* 215 */     if (argArrayLen != -1) {
/* 216 */       this.argumentArray = (Object[])new String[argArrayLen];
/* 217 */       for (int i = 0; i < argArrayLen; i++) {
/* 218 */         Object val = in.readObject();
/* 219 */         if (!"NULL_ARGUMENT_ARRAY_ELEMENT".equals(val)) {
/* 220 */           this.argumentArray[i] = val;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 228 */     int prime = 31;
/* 229 */     long millis = getTimeStamp();
/*     */     
/* 231 */     int result = 1;
/* 232 */     result = 31 * result + ((this.message == null) ? 0 : this.message.hashCode());
/* 233 */     result = 31 * result + ((this.threadName == null) ? 0 : this.threadName.hashCode());
/* 234 */     result = 31 * result + (int)(millis ^ millis >>> 32L);
/* 235 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 240 */     if (this == obj)
/* 241 */       return true; 
/* 242 */     if (obj == null)
/* 243 */       return false; 
/* 244 */     if (getClass() != obj.getClass())
/* 245 */       return false; 
/* 246 */     LoggingEventVO other = (LoggingEventVO)obj;
/* 247 */     if (this.message == null) {
/* 248 */       if (other.message != null)
/* 249 */         return false; 
/* 250 */     } else if (!this.message.equals(other.message)) {
/* 251 */       return false;
/*     */     } 
/* 253 */     if (this.loggerName == null) {
/* 254 */       if (other.loggerName != null)
/* 255 */         return false; 
/* 256 */     } else if (!this.loggerName.equals(other.loggerName)) {
/* 257 */       return false;
/*     */     } 
/* 259 */     if (this.threadName == null) {
/* 260 */       if (other.threadName != null)
/* 261 */         return false; 
/* 262 */     } else if (!this.threadName.equals(other.threadName)) {
/* 263 */       return false;
/* 264 */     }  if (getTimeStamp() != other.getTimeStamp()) {
/* 265 */       return false;
/*     */     }
/* 267 */     if (this.markerList == null) {
/* 268 */       if (other.markerList != null)
/* 269 */         return false; 
/* 270 */     } else if (!this.markerList.equals(other.markerList)) {
/* 271 */       return false;
/*     */     } 
/* 273 */     if (this.mdcPropertyMap == null) {
/* 274 */       if (other.mdcPropertyMap != null)
/* 275 */         return false; 
/* 276 */     } else if (!this.mdcPropertyMap.equals(other.mdcPropertyMap)) {
/* 277 */       return false;
/* 278 */     }  return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\spi\LoggingEventVO.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */