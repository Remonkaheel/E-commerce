/*    */ package ch.qos.logback.classic.spi;
/*    */ 
/*    */ import ch.qos.logback.classic.LoggerContext;
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggerContextAwareBase
/*    */   extends ContextAwareBase
/*    */   implements LoggerContextAware
/*    */ {
/*    */   public void setLoggerContext(LoggerContext context) {
/* 26 */     super.setContext((Context)context);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setContext(Context context) {
/* 33 */     if (context instanceof LoggerContext || context == null) {
/* 34 */       super.setContext(context);
/*    */     } else {
/* 36 */       throw new IllegalArgumentException("LoggerContextAwareBase only accepts contexts of type c.l.classic.LoggerContext");
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public LoggerContext getLoggerContext() {
/* 47 */     return (LoggerContext)this.context;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\spi\LoggerContextAwareBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */