/*    */ package ch.qos.logback.classic.spi;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StackTraceElementProxy
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -2374374378980555982L;
/*    */   final StackTraceElement ste;
/*    */   private transient String steAsString;
/*    */   @Deprecated
/*    */   ClassPackagingData classPackagingData;
/*    */   
/*    */   public StackTraceElementProxy(StackTraceElement ste) {
/* 31 */     if (ste == null) {
/* 32 */       throw new IllegalArgumentException("ste cannot be null");
/*    */     }
/* 34 */     this.ste = ste;
/*    */   }
/*    */   
/*    */   public String getSTEAsString() {
/* 38 */     if (this.steAsString == null) {
/* 39 */       this.steAsString = "at " + this.ste.toString();
/*    */     }
/* 41 */     return this.steAsString;
/*    */   }
/*    */   
/*    */   public StackTraceElement getStackTraceElement() {
/* 45 */     return this.ste;
/*    */   }
/*    */   
/*    */   public void setClassPackagingData(ClassPackagingData cpd) {
/* 49 */     if (this.classPackagingData != null) {
/* 50 */       throw new IllegalStateException("Packaging data has been already set");
/*    */     }
/* 52 */     this.classPackagingData = cpd;
/*    */   }
/*    */   
/*    */   public ClassPackagingData getClassPackagingData() {
/* 56 */     return this.classPackagingData;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 61 */     return this.ste.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 66 */     if (this == obj)
/* 67 */       return true; 
/* 68 */     if (obj == null)
/* 69 */       return false; 
/* 70 */     if (getClass() != obj.getClass())
/* 71 */       return false; 
/* 72 */     StackTraceElementProxy other = (StackTraceElementProxy)obj;
/*    */     
/* 74 */     if (!this.ste.equals(other.ste)) {
/* 75 */       return false;
/*    */     }
/* 77 */     if (this.classPackagingData == null) {
/* 78 */       if (other.classPackagingData != null) {
/* 79 */         return false;
/*    */       }
/* 81 */     } else if (!this.classPackagingData.equals(other.classPackagingData)) {
/* 82 */       return false;
/*    */     } 
/* 84 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 89 */     return getSTEAsString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\spi\StackTraceElementProxy.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */