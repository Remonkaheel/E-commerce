/*    */ package ch.qos.logback.classic.spi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EventArgUtil
/*    */ {
/*    */   public static final Throwable extractThrowable(Object[] argArray) {
/* 19 */     if (argArray == null || argArray.length == 0) {
/* 20 */       return null;
/*    */     }
/*    */     
/* 23 */     Object lastEntry = argArray[argArray.length - 1];
/* 24 */     if (lastEntry instanceof Throwable) {
/* 25 */       return (Throwable)lastEntry;
/*    */     }
/* 27 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Object[] trimmedCopy(Object[] argArray) {
/* 38 */     if (argArray == null || argArray.length == 0) {
/* 39 */       throw new IllegalStateException("non-sensical empty or null argument array");
/*    */     }
/* 41 */     int trimemdLen = argArray.length - 1;
/* 42 */     Object[] trimmed = new Object[trimemdLen];
/* 43 */     System.arraycopy(argArray, 0, trimmed, 0, trimemdLen);
/* 44 */     return trimmed;
/*    */   }
/*    */   
/*    */   public static Object[] arrangeArguments(Object[] argArray) {
/* 48 */     return argArray;
/*    */   }
/*    */   
/*    */   public static boolean successfulExtraction(Throwable throwable) {
/* 52 */     return (throwable != null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\spi\EventArgUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */