/*     */ package ch.qos.logback.classic.spi;
/*     */ 
/*     */ import ch.qos.logback.core.CoreConstants;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CallerData
/*     */ {
/*     */   private static final String LOG4J_CATEGORY = "org.apache.log4j.Category";
/*     */   private static final String SLF4J_BOUNDARY = "org.slf4j.Logger";
/*     */   public static final int LINE_NA = -1;
/*  41 */   public static final String CALLER_DATA_NA = "?#?:?" + CoreConstants.LINE_SEPARATOR;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final StackTraceElement[] EMPTY_CALLER_DATA_ARRAY = new StackTraceElement[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackTraceElement[] extract(Throwable t, String fqnOfInvokingClass, int maxDepth, List<String> frameworkPackageList) {
/*  54 */     if (t == null) {
/*  55 */       return null;
/*     */     }
/*     */     
/*  58 */     StackTraceElement[] steArray = t.getStackTrace();
/*     */ 
/*     */     
/*  61 */     int found = -1;
/*  62 */     for (int i = 0; i < steArray.length; i++) {
/*  63 */       if (isInFrameworkSpace(steArray[i].getClassName(), fqnOfInvokingClass, frameworkPackageList)) {
/*     */         
/*  65 */         found = i + 1;
/*     */       }
/*  67 */       else if (found != -1) {
/*     */         break;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  74 */     if (found == -1) {
/*  75 */       return EMPTY_CALLER_DATA_ARRAY;
/*     */     }
/*     */     
/*  78 */     int availableDepth = steArray.length - found;
/*  79 */     int desiredDepth = (maxDepth < availableDepth) ? maxDepth : availableDepth;
/*     */     
/*  81 */     StackTraceElement[] callerDataArray = new StackTraceElement[desiredDepth];
/*  82 */     for (int j = 0; j < desiredDepth; j++) {
/*  83 */       callerDataArray[j] = steArray[found + j];
/*     */     }
/*  85 */     return callerDataArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean isInFrameworkSpace(String currentClass, String fqnOfInvokingClass, List<String> frameworkPackageList) {
/*  92 */     if (currentClass.equals(fqnOfInvokingClass) || currentClass.equals("org.apache.log4j.Category") || currentClass
/*  93 */       .startsWith("org.slf4j.Logger") || 
/*  94 */       isInFrameworkSpaceList(currentClass, frameworkPackageList)) {
/*  95 */       return true;
/*     */     }
/*  97 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isInFrameworkSpaceList(String currentClass, List<String> frameworkPackageList) {
/* 106 */     if (frameworkPackageList == null) {
/* 107 */       return false;
/*     */     }
/* 109 */     for (String s : frameworkPackageList) {
/* 110 */       if (currentClass.startsWith(s))
/* 111 */         return true; 
/*     */     } 
/* 113 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StackTraceElement naInstance() {
/* 124 */     return new StackTraceElement("?", "?", "?", -1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\spi\CallerData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */