/*    */ package ch.qos.logback.classic.spi;
/*    */ 
/*    */ import ch.qos.logback.classic.LoggerContext;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggerRemoteView
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 5028223666108713696L;
/*    */   final LoggerContextVO loggerContextView;
/*    */   final String name;
/*    */   
/*    */   public LoggerRemoteView(String name, LoggerContext lc) {
/* 37 */     this.name = name;
/* 38 */     assert lc.getLoggerContextRemoteView() != null;
/* 39 */     this.loggerContextView = lc.getLoggerContextRemoteView();
/*    */   }
/*    */   
/*    */   public LoggerContextVO getLoggerContextView() {
/* 43 */     return this.loggerContextView;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 47 */     return this.name;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\spi\LoggerRemoteView.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */