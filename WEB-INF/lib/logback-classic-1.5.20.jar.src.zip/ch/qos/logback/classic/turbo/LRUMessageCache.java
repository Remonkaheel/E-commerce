/*    */ package ch.qos.logback.classic.turbo;
/*    */ 
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LRUMessageCache
/*    */   extends LinkedHashMap<String, Integer>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   final int cacheSize;
/*    */   
/*    */   LRUMessageCache(int cacheSize) {
/* 30 */     super((int)(cacheSize * 1.3333334F), 0.75F, true);
/* 31 */     if (cacheSize < 1) {
/* 32 */       throw new IllegalArgumentException("Cache size cannot be smaller than 1");
/*    */     }
/* 34 */     this.cacheSize = cacheSize;
/*    */   }
/*    */   
/*    */   int getMessageCountAndThenIncrement(String msg) {
/*    */     Integer i;
/* 39 */     if (msg == null) {
/* 40 */       return 0;
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 45 */     synchronized (this) {
/* 46 */       i = (Integer)get(msg);
/* 47 */       if (i == null) {
/* 48 */         i = Integer.valueOf(0);
/*    */       } else {
/* 50 */         i = Integer.valueOf(i.intValue() + 1);
/*    */       } 
/* 52 */       put((K)msg, (V)i);
/*    */     } 
/* 54 */     return i.intValue();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean removeEldestEntry(Map.Entry<String, Integer> eldest) {
/* 60 */     return (size() > this.cacheSize);
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void clear() {
/* 65 */     super.clear();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\turbo\LRUMessageCache.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */