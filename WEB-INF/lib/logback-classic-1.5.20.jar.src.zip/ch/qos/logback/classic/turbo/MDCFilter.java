/*    */ package ch.qos.logback.classic.turbo;
/*    */ 
/*    */ import ch.qos.logback.classic.Level;
/*    */ import ch.qos.logback.classic.Logger;
/*    */ import ch.qos.logback.core.spi.FilterReply;
/*    */ import org.slf4j.MDC;
/*    */ import org.slf4j.Marker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MDCFilter
/*    */   extends MatchingFilter
/*    */ {
/*    */   String MDCKey;
/*    */   String value;
/*    */   
/*    */   public void start() {
/* 50 */     int errorCount = 0;
/* 51 */     if (this.value == null) {
/* 52 */       addError("'value' parameter is mandatory. Cannot start.");
/* 53 */       errorCount++;
/*    */     } 
/* 55 */     if (this.MDCKey == null) {
/* 56 */       addError("'MDCKey' parameter is mandatory. Cannot start.");
/* 57 */       errorCount++;
/*    */     } 
/*    */     
/* 60 */     if (errorCount == 0) {
/* 61 */       this.start = true;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public FilterReply decide(Marker marker, Logger logger, Level level, String format, Object[] params, Throwable t) {
/* 67 */     if (!isStarted()) {
/* 68 */       return FilterReply.NEUTRAL;
/*    */     }
/*    */     
/* 71 */     String value = MDC.get(this.MDCKey);
/* 72 */     if (this.value.equals(value)) {
/* 73 */       return this.onMatch;
/*    */     }
/* 75 */     return this.onMismatch;
/*    */   }
/*    */   
/*    */   public void setValue(String value) {
/* 79 */     this.value = value;
/*    */   }
/*    */   
/*    */   public void setMDCKey(String MDCKey) {
/* 83 */     this.MDCKey = MDCKey;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\turbo\MDCFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */