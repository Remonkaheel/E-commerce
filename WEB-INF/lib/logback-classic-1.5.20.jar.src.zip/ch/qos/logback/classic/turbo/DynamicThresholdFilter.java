/*     */ package ch.qos.logback.classic.turbo;
/*     */ 
/*     */ import ch.qos.logback.classic.Level;
/*     */ import ch.qos.logback.classic.Logger;
/*     */ import ch.qos.logback.core.spi.FilterReply;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.slf4j.MDC;
/*     */ import org.slf4j.Marker;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DynamicThresholdFilter
/*     */   extends TurboFilter
/*     */ {
/* 131 */   private Map<String, Level> valueLevelMap = new HashMap<>();
/* 132 */   private Level defaultThreshold = Level.ERROR;
/*     */   
/*     */   private String key;
/* 135 */   private FilterReply onHigherOrEqual = FilterReply.NEUTRAL;
/* 136 */   private FilterReply onLower = FilterReply.DENY;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getKey() {
/* 144 */     return this.key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKey(String key) {
/* 151 */     this.key = key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Level getDefaultThreshold() {
/* 160 */     return this.defaultThreshold;
/*     */   }
/*     */   
/*     */   public void setDefaultThreshold(Level defaultThreshold) {
/* 164 */     this.defaultThreshold = defaultThreshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FilterReply getOnHigherOrEqual() {
/* 174 */     return this.onHigherOrEqual;
/*     */   }
/*     */   
/*     */   public void setOnHigherOrEqual(FilterReply onHigherOrEqual) {
/* 178 */     this.onHigherOrEqual = onHigherOrEqual;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FilterReply getOnLower() {
/* 188 */     return this.onLower;
/*     */   }
/*     */   
/*     */   public void setOnLower(FilterReply onLower) {
/* 192 */     this.onLower = onLower;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMDCValueLevelPair(MDCValueLevelPair mdcValueLevelPair) {
/* 199 */     if (this.valueLevelMap.containsKey(mdcValueLevelPair.getValue())) {
/* 200 */       addError(mdcValueLevelPair.getValue() + " has been already set");
/*     */     } else {
/* 202 */       this.valueLevelMap.put(mdcValueLevelPair.getValue(), mdcValueLevelPair.getLevel());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 211 */     if (this.key == null) {
/* 212 */       addError("No key name was specified");
/*     */     }
/* 214 */     super.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FilterReply decide(Marker marker, Logger logger, Level level, String s, Object[] objects, Throwable throwable) {
/* 241 */     String mdcValue = MDC.get(this.key);
/* 242 */     if (!isStarted()) {
/* 243 */       return FilterReply.NEUTRAL;
/*     */     }
/*     */     
/* 246 */     Level levelAssociatedWithMDCValue = null;
/* 247 */     if (mdcValue != null) {
/* 248 */       levelAssociatedWithMDCValue = this.valueLevelMap.get(mdcValue);
/*     */     }
/* 250 */     if (levelAssociatedWithMDCValue == null) {
/* 251 */       levelAssociatedWithMDCValue = this.defaultThreshold;
/*     */     }
/* 253 */     if (level.isGreaterOrEqual(levelAssociatedWithMDCValue)) {
/* 254 */       return this.onHigherOrEqual;
/*     */     }
/* 256 */     return this.onLower;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\turbo\DynamicThresholdFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */