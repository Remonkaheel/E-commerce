/*     */ package ch.qos.logback.classic.net;
/*     */ 
/*     */ import ch.qos.logback.classic.Logger;
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.classic.net.server.HardenedLoggingEventInputStream;
/*     */ import ch.qos.logback.classic.spi.ILoggingEvent;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketAddress;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SocketNode
/*     */   implements Runnable
/*     */ {
/*     */   Socket socket;
/*     */   LoggerContext context;
/*     */   HardenedLoggingEventInputStream hardenedLoggingEventInputStream;
/*     */   SocketAddress remoteSocketAddress;
/*     */   Logger logger;
/*     */   boolean closed = false;
/*     */   SimpleSocketServer socketServer;
/*     */   
/*     */   public SocketNode(SimpleSocketServer socketServer, Socket socket, LoggerContext context) {
/*  54 */     this.socketServer = socketServer;
/*  55 */     this.socket = socket;
/*  56 */     this.remoteSocketAddress = socket.getRemoteSocketAddress();
/*  57 */     this.context = context;
/*  58 */     this.logger = context.getLogger(SocketNode.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/*  70 */       this
/*  71 */         .hardenedLoggingEventInputStream = new HardenedLoggingEventInputStream(new BufferedInputStream(this.socket.getInputStream()));
/*  72 */     } catch (Exception e) {
/*  73 */       this.logger.error("Could not open ObjectInputStream to " + String.valueOf(this.socket), e);
/*  74 */       this.closed = true;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  81 */     while (!this.closed) {
/*     */       
/*  83 */       ILoggingEvent event = (ILoggingEvent)this.hardenedLoggingEventInputStream.readObject();
/*     */ 
/*     */       
/*  86 */       Logger remoteLogger = this.context.getLogger(event.getLoggerName());
/*     */       
/*  88 */       if (remoteLogger.isEnabledFor(event.getLevel()))
/*     */       {
/*  90 */         remoteLogger.callAppenders(event);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     this.socketServer.socketNodeClosing(this);
/* 105 */     close();
/*     */   }
/*     */   
/*     */   void close() {
/* 109 */     if (this.closed) {
/*     */       return;
/*     */     }
/* 112 */     this.closed = true;
/* 113 */     if (this.hardenedLoggingEventInputStream != null) {
/*     */       try {
/* 115 */         this.hardenedLoggingEventInputStream.close();
/* 116 */       } catch (IOException e) {
/* 117 */         this.logger.warn("Could not close connection.", e);
/*     */       } finally {
/* 119 */         this.hardenedLoggingEventInputStream = null;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 126 */     return getClass().getName() + getClass().getName();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\net\SocketNode.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */