/*     */ package ch.qos.logback.classic.net;
/*     */ 
/*     */ import ch.qos.logback.classic.PatternLayout;
/*     */ import ch.qos.logback.classic.spi.ILoggingEvent;
/*     */ import ch.qos.logback.classic.spi.IThrowableProxy;
/*     */ import ch.qos.logback.classic.spi.StackTraceElementProxy;
/*     */ import ch.qos.logback.classic.util.LevelToSyslogSeverity;
/*     */ import ch.qos.logback.core.Layout;
/*     */ import ch.qos.logback.core.net.SyslogAppenderBase;
/*     */ import ch.qos.logback.core.net.SyslogOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.SocketException;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SyslogAppender
/*     */   extends SyslogAppenderBase<ILoggingEvent>
/*     */ {
/*     */   public static final String DEFAULT_SUFFIX_PATTERN = "[%thread] %logger %msg";
/*     */   public static final String DEFAULT_STACKTRACE_PATTERN = "\t";
/*  45 */   PatternLayout stackTraceLayout = new PatternLayout();
/*  46 */   String stackTracePattern = "\t";
/*     */   
/*     */   boolean throwableExcluded = false;
/*     */   
/*     */   public void start() {
/*  51 */     super.start();
/*  52 */     setupStackTraceLayout();
/*     */   }
/*     */   
/*     */   String getPrefixPattern() {
/*  56 */     return "%syslogStart{" + getFacility() + "}%nopex{}";
/*     */   }
/*     */ 
/*     */   
/*     */   public SyslogOutputStream createOutputStream() throws SocketException, UnknownHostException {
/*  61 */     return new SyslogOutputStream(getSyslogHost(), getPort());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSeverityForEvent(Object eventObject) {
/*  72 */     ILoggingEvent event = (ILoggingEvent)eventObject;
/*  73 */     return LevelToSyslogSeverity.convert(event);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void postProcess(Object eventObject, OutputStream sw) {
/*  78 */     if (this.throwableExcluded) {
/*     */       return;
/*     */     }
/*  81 */     ILoggingEvent event = (ILoggingEvent)eventObject;
/*  82 */     IThrowableProxy tp = event.getThrowableProxy();
/*     */     
/*  84 */     if (tp == null) {
/*     */       return;
/*     */     }
/*  87 */     String stackTracePrefix = this.stackTraceLayout.doLayout(event);
/*  88 */     boolean isRootException = true;
/*  89 */     while (tp != null) {
/*  90 */       StackTraceElementProxy[] stepArray = tp.getStackTraceElementProxyArray();
/*     */       try {
/*  92 */         handleThrowableFirstLine(sw, tp, stackTracePrefix, isRootException);
/*  93 */         isRootException = false;
/*  94 */         for (StackTraceElementProxy step : stepArray) {
/*  95 */           StringBuilder sb = new StringBuilder();
/*  96 */           sb.append(stackTracePrefix).append(step);
/*  97 */           sw.write(sb.toString().getBytes());
/*  98 */           sw.flush();
/*     */         } 
/* 100 */       } catch (IOException e) {
/*     */         break;
/*     */       } 
/* 103 */       tp = tp.getCause();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleThrowableFirstLine(OutputStream sw, IThrowableProxy tp, String stackTracePrefix, boolean isRootException) throws IOException {
/* 110 */     StringBuilder sb = (new StringBuilder()).append(stackTracePrefix);
/*     */     
/* 112 */     if (!isRootException) {
/* 113 */       sb.append("Caused by: ");
/*     */     }
/* 115 */     sb.append(tp.getClassName()).append(": ").append(tp.getMessage());
/* 116 */     sw.write(sb.toString().getBytes());
/* 117 */     sw.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   boolean stackTraceHeaderLine(StringBuilder sb, boolean topException) {
/* 122 */     return false;
/*     */   }
/*     */   
/*     */   public Layout<ILoggingEvent> buildLayout() {
/* 126 */     PatternLayout layout = new PatternLayout();
/* 127 */     layout.getInstanceConverterMap().put("syslogStart", ch.qos.logback.classic.pattern.SyslogStartConverter::new);
/* 128 */     if (this.suffixPattern == null) {
/* 129 */       this.suffixPattern = "[%thread] %logger %msg";
/*     */     }
/* 131 */     layout.setPattern(getPrefixPattern() + getPrefixPattern());
/* 132 */     layout.setContext(getContext());
/* 133 */     layout.start();
/* 134 */     return (Layout<ILoggingEvent>)layout;
/*     */   }
/*     */   
/*     */   private void setupStackTraceLayout() {
/* 138 */     this.stackTraceLayout.getInstanceConverterMap().put("syslogStart", ch.qos.logback.classic.pattern.SyslogStartConverter::new);
/*     */     
/* 140 */     this.stackTraceLayout.setPattern(getPrefixPattern() + getPrefixPattern());
/* 141 */     this.stackTraceLayout.setContext(getContext());
/* 142 */     this.stackTraceLayout.start();
/*     */   }
/*     */   
/*     */   public boolean isThrowableExcluded() {
/* 146 */     return this.throwableExcluded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setThrowableExcluded(boolean throwableExcluded) {
/* 158 */     this.throwableExcluded = throwableExcluded;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStackTracePattern() {
/* 168 */     return this.stackTracePattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStackTracePattern(String stackTracePattern) {
/* 182 */     this.stackTracePattern = stackTracePattern;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\net\SyslogAppender.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */