/*     */ package ch.qos.logback.classic.net.server;
/*     */ 
/*     */ import ch.qos.logback.classic.Logger;
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.classic.spi.ILoggingEvent;
/*     */ import ch.qos.logback.core.net.HardenedObjectInputStream;
/*     */ import ch.qos.logback.core.util.CloseUtil;
/*     */ import java.io.Closeable;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.Socket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RemoteAppenderStreamClient
/*     */   implements RemoteAppenderClient
/*     */ {
/*     */   private final String id;
/*     */   private final Socket socket;
/*     */   private final InputStream inputStream;
/*     */   private LoggerContext lc;
/*     */   private Logger logger;
/*     */   
/*     */   public RemoteAppenderStreamClient(String id, Socket socket) {
/*  49 */     this.id = id;
/*  50 */     this.socket = socket;
/*  51 */     this.inputStream = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RemoteAppenderStreamClient(String id, InputStream inputStream) {
/*  64 */     this.id = id;
/*  65 */     this.socket = null;
/*  66 */     this.inputStream = inputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoggerContext(LoggerContext lc) {
/*  73 */     this.lc = lc;
/*  74 */     this.logger = lc.getLogger(getClass().getPackage().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*  81 */     if (this.socket == null)
/*     */       return; 
/*  83 */     CloseUtil.closeQuietly(this.socket);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  90 */     this.logger.info(String.valueOf(this) + ": connected");
/*  91 */     HardenedObjectInputStream ois = null;
/*     */     try {
/*  93 */       ois = createObjectInputStream();
/*     */       
/*     */       while (true) {
/*  96 */         ILoggingEvent event = (ILoggingEvent)ois.readObject();
/*     */ 
/*     */         
/*  99 */         Logger remoteLogger = this.lc.getLogger(event.getLoggerName());
/*     */         
/* 101 */         if (remoteLogger.isEnabledFor(event.getLevel()))
/*     */         {
/* 103 */           remoteLogger.callAppenders(event);
/*     */         }
/*     */       } 
/* 106 */     } catch (EOFException eOFException) {
/*     */ 
/*     */     
/* 109 */     } catch (IOException ex) {
/* 110 */       this.logger.info(String.valueOf(this) + ": " + String.valueOf(this));
/* 111 */     } catch (ClassNotFoundException ex) {
/* 112 */       this.logger.error(String.valueOf(this) + ": unknown event class");
/* 113 */     } catch (RuntimeException ex) {
/* 114 */       this.logger.error(String.valueOf(this) + ": " + String.valueOf(this));
/*     */     } finally {
/* 116 */       if (ois != null) {
/* 117 */         CloseUtil.closeQuietly((Closeable)ois);
/*     */       }
/* 119 */       close();
/* 120 */       this.logger.info(String.valueOf(this) + ": connection closed");
/*     */     } 
/*     */   }
/*     */   
/*     */   private HardenedObjectInputStream createObjectInputStream() throws IOException {
/* 125 */     if (this.inputStream != null) {
/* 126 */       return new HardenedLoggingEventInputStream(this.inputStream);
/*     */     }
/* 128 */     return new HardenedLoggingEventInputStream(this.socket.getInputStream());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 136 */     return "client " + this.id;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\net\server\RemoteAppenderStreamClient.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */