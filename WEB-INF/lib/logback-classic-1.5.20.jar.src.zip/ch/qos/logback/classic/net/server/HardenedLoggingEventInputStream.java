/*    */ package ch.qos.logback.classic.net.server;
/*    */ 
/*    */ import ch.qos.logback.classic.Level;
/*    */ import ch.qos.logback.classic.Logger;
/*    */ import ch.qos.logback.classic.spi.ClassPackagingData;
/*    */ import ch.qos.logback.classic.spi.IThrowableProxy;
/*    */ import ch.qos.logback.classic.spi.LoggerContextVO;
/*    */ import ch.qos.logback.classic.spi.LoggerRemoteView;
/*    */ import ch.qos.logback.classic.spi.LoggingEventVO;
/*    */ import ch.qos.logback.classic.spi.StackTraceElementProxy;
/*    */ import ch.qos.logback.classic.spi.ThrowableProxy;
/*    */ import ch.qos.logback.classic.spi.ThrowableProxyVO;
/*    */ import ch.qos.logback.core.net.HardenedObjectInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.slf4j.helpers.BasicMarker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HardenedLoggingEventInputStream
/*    */   extends HardenedObjectInputStream
/*    */ {
/*    */   static final String ARRAY_PREFIX = "[L";
/*    */   
/*    */   public static List<String> getWhilelist() {
/* 40 */     List<String> whitelist = new ArrayList<>();
/* 41 */     whitelist.add(LoggingEventVO.class.getName());
/* 42 */     whitelist.add(LoggerContextVO.class.getName());
/* 43 */     whitelist.add(LoggerRemoteView.class.getName());
/* 44 */     whitelist.add(ThrowableProxyVO.class.getName());
/* 45 */     whitelist.add(BasicMarker.class.getName());
/* 46 */     whitelist.add(Level.class.getName());
/* 47 */     whitelist.add(Logger.class.getName());
/* 48 */     whitelist.add(StackTraceElement.class.getName());
/* 49 */     whitelist.add(StackTraceElement[].class.getName());
/* 50 */     whitelist.add(ThrowableProxy.class.getName());
/* 51 */     whitelist.add(ThrowableProxy[].class.getName());
/* 52 */     whitelist.add(IThrowableProxy.class.getName());
/* 53 */     whitelist.add(IThrowableProxy[].class.getName());
/* 54 */     whitelist.add(StackTraceElementProxy.class.getName());
/* 55 */     whitelist.add(StackTraceElementProxy[].class.getName());
/* 56 */     whitelist.add(ClassPackagingData.class.getName());
/*    */     
/* 58 */     return whitelist;
/*    */   }
/*    */   
/*    */   public HardenedLoggingEventInputStream(InputStream is) throws IOException {
/* 62 */     super(is, getWhilelist());
/*    */   }
/*    */ 
/*    */   
/*    */   public HardenedLoggingEventInputStream(InputStream is, List<String> additionalAuthorizedClasses) throws IOException {
/* 67 */     this(is);
/* 68 */     addToWhitelist(additionalAuthorizedClasses);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\net\server\HardenedLoggingEventInputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */