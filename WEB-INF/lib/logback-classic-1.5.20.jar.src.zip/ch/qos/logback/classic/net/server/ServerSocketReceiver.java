/*     */ package ch.qos.logback.classic.net.server;
/*     */ 
/*     */ import ch.qos.logback.classic.net.ReceiverBase;
/*     */ import ch.qos.logback.core.net.server.ServerListener;
/*     */ import ch.qos.logback.core.net.server.ServerRunner;
/*     */ import ch.qos.logback.core.util.CloseUtil;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.concurrent.Executor;
/*     */ import javax.net.ServerSocketFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerSocketReceiver
/*     */   extends ReceiverBase
/*     */ {
/*     */   public static final int DEFAULT_BACKLOG = 50;
/*  42 */   private int port = 4560;
/*  43 */   private int backlog = 50;
/*     */ 
/*     */   
/*     */   private String address;
/*     */ 
/*     */   
/*     */   private ServerSocket serverSocket;
/*     */   
/*     */   private ServerRunner runner;
/*     */ 
/*     */   
/*     */   protected boolean shouldStart() {
/*     */     try {
/*  56 */       ServerSocket serverSocket = getServerSocketFactory().createServerSocket(getPort(), getBacklog(), 
/*  57 */           getInetAddress());
/*     */       
/*  59 */       ServerListener<RemoteAppenderClient> listener = createServerListener(serverSocket);
/*     */       
/*  61 */       this.runner = createServerRunner(listener, getContext().getExecutorService());
/*  62 */       this.runner.setContext(getContext());
/*  63 */       return true;
/*  64 */     } catch (Exception ex) {
/*  65 */       addError("server startup error: " + String.valueOf(ex), ex);
/*  66 */       CloseUtil.closeQuietly(this.serverSocket);
/*  67 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected ServerListener<RemoteAppenderClient> createServerListener(ServerSocket socket) {
/*  72 */     return (ServerListener<RemoteAppenderClient>)new RemoteAppenderServerListener(socket);
/*     */   }
/*     */ 
/*     */   
/*     */   protected ServerRunner createServerRunner(ServerListener<RemoteAppenderClient> listener, Executor executor) {
/*  77 */     return (ServerRunner)new RemoteAppenderServerRunner(listener, executor);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Runnable getRunnableTask() {
/*  82 */     return (Runnable)this.runner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onStop() {
/*     */     try {
/*  90 */       if (this.runner == null)
/*     */         return; 
/*  92 */       this.runner.stop();
/*  93 */     } catch (IOException ex) {
/*  94 */       addError("server shutdown error: " + String.valueOf(ex), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ServerSocketFactory getServerSocketFactory() throws Exception {
/* 107 */     return ServerSocketFactory.getDefault();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InetAddress getInetAddress() throws UnknownHostException {
/* 117 */     if (getAddress() == null)
/* 118 */       return null; 
/* 119 */     return InetAddress.getByName(getAddress());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPort() {
/* 128 */     return this.port;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPort(int port) {
/* 137 */     this.port = port;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBacklog() {
/* 150 */     return this.backlog;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBacklog(int backlog) {
/* 163 */     this.backlog = backlog;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAddress() {
/* 172 */     return this.address;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAddress(String address) {
/* 181 */     this.address = address;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\net\server\ServerSocketReceiver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */