/*     */ package ch.qos.logback.classic.net;
/*     */ 
/*     */ import ch.qos.logback.classic.Logger;
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.classic.net.server.HardenedLoggingEventInputStream;
/*     */ import ch.qos.logback.classic.spi.ILoggingEvent;
/*     */ import ch.qos.logback.core.net.DefaultSocketConnector;
/*     */ import ch.qos.logback.core.net.SocketConnector;
/*     */ import ch.qos.logback.core.util.CloseUtil;
/*     */ import java.io.Closeable;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import javax.net.SocketFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SocketReceiver
/*     */   extends ReceiverBase
/*     */   implements Runnable, SocketConnector.ExceptionHandler
/*     */ {
/*     */   private static final int DEFAULT_ACCEPT_CONNECTION_DELAY = 5000;
/*     */   private String remoteHost;
/*     */   private InetAddress address;
/*     */   private int port;
/*     */   private int reconnectionDelay;
/*  52 */   private int acceptConnectionTimeout = 5000;
/*     */   
/*     */   private String receiverId;
/*     */   
/*     */   private volatile Socket socket;
/*     */   
/*     */   private Future<Socket> connectorTask;
/*     */ 
/*     */   
/*     */   protected boolean shouldStart() {
/*  62 */     int errorCount = 0;
/*  63 */     if (this.port == 0) {
/*  64 */       errorCount++;
/*  65 */       addError("No port was configured for receiver. For more information, please visit http://logback.qos.ch/codes.html#receiver_no_port");
/*     */     } 
/*     */ 
/*     */     
/*  69 */     if (this.remoteHost == null) {
/*  70 */       errorCount++;
/*  71 */       addError("No host name or address was configured for receiver. For more information, please visit http://logback.qos.ch/codes.html#receiver_no_host");
/*     */     } 
/*     */ 
/*     */     
/*  75 */     if (this.reconnectionDelay == 0) {
/*  76 */       this.reconnectionDelay = 30000;
/*     */     }
/*     */     
/*  79 */     if (errorCount == 0) {
/*     */       try {
/*  81 */         this.address = InetAddress.getByName(this.remoteHost);
/*  82 */       } catch (UnknownHostException ex) {
/*  83 */         addError("unknown host: " + this.remoteHost);
/*  84 */         errorCount++;
/*     */       } 
/*     */     }
/*     */     
/*  88 */     if (errorCount == 0) {
/*  89 */       this.receiverId = "receiver " + this.remoteHost + ":" + this.port + ": ";
/*     */     }
/*     */     
/*  92 */     return (errorCount == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void onStop() {
/*  99 */     if (this.socket != null) {
/* 100 */       CloseUtil.closeQuietly(this.socket);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected Runnable getRunnableTask() {
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/* 114 */       LoggerContext lc = (LoggerContext)getContext();
/* 115 */       while (!Thread.currentThread().isInterrupted()) {
/* 116 */         SocketConnector connector = createConnector(this.address, this.port, 0, this.reconnectionDelay);
/* 117 */         this.connectorTask = activateConnector(connector);
/* 118 */         if (this.connectorTask == null) {
/*     */           break;
/*     */         }
/* 121 */         this.socket = waitForConnectorToReturnASocket();
/* 122 */         if (this.socket == null)
/*     */           break; 
/* 124 */         dispatchEvents(lc);
/*     */       } 
/* 126 */     } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */     
/* 129 */     addInfo("shutting down");
/*     */   }
/*     */   
/*     */   private SocketConnector createConnector(InetAddress address, int port, int initialDelay, int retryDelay) {
/* 133 */     SocketConnector connector = newConnector(address, port, initialDelay, retryDelay);
/* 134 */     connector.setExceptionHandler(this);
/* 135 */     connector.setSocketFactory(getSocketFactory());
/* 136 */     return connector;
/*     */   }
/*     */   
/*     */   private Future<Socket> activateConnector(SocketConnector connector) {
/*     */     try {
/* 141 */       return getContext().getScheduledExecutorService().submit((Callable<Socket>)connector);
/* 142 */     } catch (RejectedExecutionException ex) {
/* 143 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Socket waitForConnectorToReturnASocket() throws InterruptedException {
/*     */     try {
/* 149 */       Socket s = this.connectorTask.get();
/* 150 */       this.connectorTask = null;
/* 151 */       return s;
/* 152 */     } catch (ExecutionException e) {
/* 153 */       return null;
/*     */     } 
/*     */   }
/*     */   private void dispatchEvents(LoggerContext lc) {
/*     */     HardenedLoggingEventInputStream hardenedLoggingEventInputStream;
/* 158 */     ObjectInputStream ois = null;
/*     */     try {
/* 160 */       this.socket.setSoTimeout(this.acceptConnectionTimeout);
/* 161 */       hardenedLoggingEventInputStream = new HardenedLoggingEventInputStream(this.socket.getInputStream());
/* 162 */       this.socket.setSoTimeout(0);
/* 163 */       addInfo(this.receiverId + "connection established");
/*     */       while (true) {
/* 165 */         ILoggingEvent event = (ILoggingEvent)hardenedLoggingEventInputStream.readObject();
/* 166 */         Logger remoteLogger = lc.getLogger(event.getLoggerName());
/* 167 */         if (remoteLogger.isEnabledFor(event.getLevel())) {
/* 168 */           remoteLogger.callAppenders(event);
/*     */         }
/*     */       } 
/* 171 */     } catch (EOFException ex) {
/* 172 */       addInfo(this.receiverId + "end-of-stream detected");
/* 173 */     } catch (IOException ex) {
/* 174 */       addInfo(this.receiverId + "connection failed: " + this.receiverId);
/* 175 */     } catch (ClassNotFoundException ex) {
/* 176 */       addInfo(this.receiverId + "unknown event class: " + this.receiverId);
/*     */     } finally {
/* 178 */       CloseUtil.closeQuietly((Closeable)hardenedLoggingEventInputStream);
/* 179 */       CloseUtil.closeQuietly(this.socket);
/* 180 */       this.socket = null;
/* 181 */       addInfo(this.receiverId + "connection closed");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectionFailed(SocketConnector connector, Exception ex) {
/* 189 */     if (ex instanceof InterruptedException) {
/* 190 */       addInfo("connector interrupted");
/* 191 */     } else if (ex instanceof java.net.ConnectException) {
/* 192 */       addInfo(this.receiverId + "connection refused");
/*     */     } else {
/* 194 */       addInfo(this.receiverId + this.receiverId);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected SocketConnector newConnector(InetAddress address, int port, int initialDelay, int retryDelay) {
/* 199 */     return (SocketConnector)new DefaultSocketConnector(address, port, initialDelay, retryDelay);
/*     */   }
/*     */   
/*     */   protected SocketFactory getSocketFactory() {
/* 203 */     return SocketFactory.getDefault();
/*     */   }
/*     */   
/*     */   public void setRemoteHost(String remoteHost) {
/* 207 */     this.remoteHost = remoteHost;
/*     */   }
/*     */   
/*     */   public void setPort(int port) {
/* 211 */     this.port = port;
/*     */   }
/*     */   
/*     */   public void setReconnectionDelay(int reconnectionDelay) {
/* 215 */     this.reconnectionDelay = reconnectionDelay;
/*     */   }
/*     */   
/*     */   public void setAcceptConnectionTimeout(int acceptConnectionTimeout) {
/* 219 */     this.acceptConnectionTimeout = acceptConnectionTimeout;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\net\SocketReceiver.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */