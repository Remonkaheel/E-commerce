/*     */ package ch.qos.logback.classic.tyler;
/*     */ 
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.action.ActionUtil;
/*     */ import ch.qos.logback.core.model.PropertyModel;
/*     */ import ch.qos.logback.core.model.util.PropertyModelHandlerHelper;
/*     */ import ch.qos.logback.core.model.util.VariableSubstitutionsHelper;
/*     */ import ch.qos.logback.core.spi.ContextAware;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.util.ContextUtil;
/*     */ import ch.qos.logback.core.util.Loader;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VariableModelHelper
/*     */   extends ContextAwareBase
/*     */ {
/*     */   TylerConfiguratorBase tylerConfiguratorBase;
/*     */   VariableSubstitutionsHelper variableSubstitutionsHelper;
/*     */   
/*     */   VariableModelHelper(Context context, TylerConfiguratorBase tylerConfiguratorBase) {
/*  41 */     super((ContextAware)tylerConfiguratorBase);
/*  42 */     this.context = context;
/*  43 */     this.tylerConfiguratorBase = tylerConfiguratorBase;
/*  44 */     this.variableSubstitutionsHelper = new VariableSubstitutionsHelper(context);
/*     */   }
/*     */ 
/*     */   
/*     */   void updateProperties(PropertyModel propertyModel) {
/*  49 */     ActionUtil.Scope scope = ActionUtil.stringToScope(propertyModel.getScopeStr());
/*  50 */     if (PropertyModelHandlerHelper.checkFileAttributeSanity(propertyModel)) {
/*  51 */       String file = propertyModel.getFile();
/*  52 */       file = this.tylerConfiguratorBase.subst(file); 
/*  53 */       try { FileInputStream istream = new FileInputStream(file); 
/*  54 */         try { loadAndSetProperties(istream, scope);
/*  55 */           istream.close(); } catch (Throwable throwable) { try { istream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  } catch (FileNotFoundException e)
/*  56 */       { addError("Could not find properties file [" + file + "]."); }
/*  57 */       catch (IOException|IllegalArgumentException e1)
/*     */       
/*  59 */       { addError("Could not read properties file [" + file + "].", e1); }
/*     */     
/*  61 */     } else if (PropertyModelHandlerHelper.checkResourceAttributeSanity(propertyModel)) {
/*  62 */       String resource = propertyModel.getResource();
/*  63 */       resource = this.tylerConfiguratorBase.subst(resource);
/*  64 */       URL resourceURL = Loader.getResourceBySelfClassLoader(resource);
/*  65 */       if (resourceURL == null)
/*  66 */       { addError("Could not find resource [" + resource + "]."); }
/*     */       else { 
/*  68 */         try { InputStream istream = resourceURL.openStream(); 
/*  69 */           try { loadAndSetProperties(istream, scope);
/*  70 */             if (istream != null) istream.close();  } catch (Throwable throwable) { if (istream != null) try { istream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/*  71 */         { addError("Could not read resource file [" + resource + "].", e); }
/*     */          }
/*     */     
/*  74 */     } else if (PropertyModelHandlerHelper.checkValueNameAttributesSanity(propertyModel)) {
/*     */ 
/*     */       
/*  77 */       String value = propertyModel.getValue();
/*     */ 
/*     */       
/*  80 */       value = value.trim();
/*  81 */       value = this.tylerConfiguratorBase.subst(value);
/*  82 */       setProperty(propertyModel.getName(), value, scope);
/*     */     } else {
/*     */       
/*  85 */       addError("In <property> element, either the \"file\" attribute alone, or the \"resource\" element alone, or both the \"name\" and \"value\" attributes must be set.");
/*     */     } 
/*     */   }
/*     */   
/*     */   void loadAndSetProperties(InputStream istream, ActionUtil.Scope scope) throws IOException {
/*  90 */     Properties props = new Properties();
/*  91 */     props.load(istream);
/*  92 */     setProperties(props, scope);
/*     */   }
/*     */   
/*     */   public void setProperties(Properties props, ActionUtil.Scope scope) {
/*     */     ContextUtil cu;
/*  97 */     switch (scope) {
/*     */       case LOCAL:
/*  99 */         this.variableSubstitutionsHelper.addSubstitutionProperties(props);
/*     */         break;
/*     */       case CONTEXT:
/* 102 */         cu = new ContextUtil(getContext());
/* 103 */         cu.addProperties(props);
/*     */         break;
/*     */       case SYSTEM:
/* 106 */         OptionHelper.setSystemProperties((ContextAware)this, props);
/*     */         break;
/*     */     } 
/*     */   }
/*     */   public void setProperty(String key, String value, ActionUtil.Scope scope) {
/* 111 */     switch (scope) {
/*     */       case LOCAL:
/* 113 */         this.variableSubstitutionsHelper.addSubstitutionProperty(key, value);
/*     */         break;
/*     */       case CONTEXT:
/* 116 */         getContext().putProperty(key, value);
/*     */         break;
/*     */       case SYSTEM:
/* 119 */         OptionHelper.setSystemProperty((ContextAware)this, key, value);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\tyler\VariableModelHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */