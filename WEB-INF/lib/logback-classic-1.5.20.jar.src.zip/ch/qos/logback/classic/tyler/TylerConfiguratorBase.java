/*     */ package ch.qos.logback.classic.tyler;
/*     */ 
/*     */ import ch.qos.logback.classic.Level;
/*     */ import ch.qos.logback.classic.Logger;
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.classic.joran.JoranConfigurator;
/*     */ import ch.qos.logback.classic.model.ConfigurationModel;
/*     */ import ch.qos.logback.classic.util.LevelUtil;
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.GenericXMLConfigurator;
/*     */ import ch.qos.logback.core.model.Model;
/*     */ import ch.qos.logback.core.model.util.PropertyModelHandlerHelper;
/*     */ import ch.qos.logback.core.model.util.VariableSubstitutionsHelper;
/*     */ import ch.qos.logback.core.spi.ContextAware;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.spi.ContextAwarePropertyContainer;
/*     */ import ch.qos.logback.core.spi.PropertyContainer;
/*     */ import ch.qos.logback.core.status.OnConsoleStatusListener;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import ch.qos.logback.core.util.StatusListenerConfigHelper;
/*     */ import ch.qos.logback.core.util.StringUtil;
/*     */ import java.util.Map;
/*     */ import java.util.function.Supplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TylerConfiguratorBase
/*     */   extends ContextAwareBase
/*     */   implements ContextAwarePropertyContainer
/*     */ {
/*     */   public static final String SET_CONTEXT_METHOD_NAME = "setContext";
/*     */   public static final String SET_CONTEXT_NAME_METHOD_NAME = "setContextName";
/*     */   public static final String SETUP_LOGGER_METHOD_NAME = "setupLogger";
/*     */   public static final String VARIABLE_SUBSTITUTIONS_HELPER_FIELD_NAME = "variableSubstitutionsHelper";
/*     */   public static final String PROPERTY_MODEL_HANDLER_HELPER_FIELD_NAME = "propertyModelHandlerHelper";
/*     */   protected VariableSubstitutionsHelper variableSubstitutionsHelper;
/*  49 */   protected PropertyModelHandlerHelper propertyModelHandlerHelper = new PropertyModelHandlerHelper((ContextAware)this);
/*     */   
/*     */   protected Logger setupLogger(String loggerName, String levelString, Boolean additivity) {
/*  52 */     LoggerContext loggerContext = (LoggerContext)this.context;
/*  53 */     Logger logger = loggerContext.getLogger(loggerName);
/*  54 */     if (!OptionHelper.isNullOrEmptyOrAllSpaces(levelString)) {
/*  55 */       Level level = LevelUtil.levelStringToLevel(levelString);
/*  56 */       logger.setLevel(level);
/*     */     } 
/*  58 */     if (additivity != null) {
/*  59 */       logger.setAdditive(additivity.booleanValue());
/*     */     }
/*  61 */     return logger;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setContext(Context context) {
/*  66 */     super.setContext(context);
/*  67 */     this.variableSubstitutionsHelper = new VariableSubstitutionsHelper(context);
/*  68 */     this.propertyModelHandlerHelper.setContext(context);
/*     */   }
/*     */   
/*     */   protected void setContextName(String name) {
/*  72 */     if (StringUtil.isNullOrEmpty(name)) {
/*  73 */       addError("Cannot set context name to null or empty string");
/*     */       return;
/*     */     } 
/*     */     try {
/*  77 */       String substName = subst(name);
/*  78 */       addInfo("Setting context name to [" + substName + "]");
/*  79 */       this.context.setName(substName);
/*  80 */     } catch (IllegalStateException e) {
/*  81 */       addError("Failed to rename context as [" + name + "]");
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void addOnConsoleStatusListener() {
/*  86 */     StatusListenerConfigHelper.addOnConsoleListenerInstance(this.context, new OnConsoleStatusListener());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String subst(String ref) {
/*  97 */     return this.variableSubstitutionsHelper.subst(ref);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addSubstitutionProperty(String key, String value) {
/* 102 */     this.variableSubstitutionsHelper.addSubstitutionProperty(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getProperty(String key) {
/* 110 */     return this.variableSubstitutionsHelper.getProperty(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, String> getCopyOfPropertyMap() {
/* 115 */     return this.variableSubstitutionsHelper.getCopyOfPropertyMap();
/*     */   }
/*     */   
/*     */   public boolean isNull(String k) {
/* 119 */     String val = OptionHelper.propertyLookup(k, (PropertyContainer)this, (PropertyContainer)this.context);
/* 120 */     return (val == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefined(String k) {
/* 131 */     String val = OptionHelper.propertyLookup(k, (PropertyContainer)this, (PropertyContainer)this.context);
/* 132 */     return (val != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String p(String k) {
/* 143 */     return property(k);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String property(String k) {
/* 155 */     String val = OptionHelper.propertyLookup(k, (PropertyContainer)this, (PropertyContainer)this.context);
/* 156 */     if (val != null) {
/* 157 */       return val;
/*     */     }
/* 159 */     return "";
/*     */   }
/*     */   
/*     */   private JoranConfigurator makeAnotherInstance() {
/* 163 */     JoranConfigurator jc = new JoranConfigurator();
/* 164 */     jc.setContext(this.context);
/* 165 */     return jc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Supplier<? extends GenericXMLConfigurator> getConfiguratorSupplier() {
/* 175 */     Supplier<? extends GenericXMLConfigurator> supplier = () -> makeAnotherInstance();
/* 176 */     return supplier;
/*     */   }
/*     */   
/*     */   protected void processModelFromIncludedFile(Model modelFromIncludedFile) {
/* 180 */     Supplier<? extends GenericXMLConfigurator> configuratorSupplier = getConfiguratorSupplier();
/* 181 */     GenericXMLConfigurator genericXMLConfigurator = configuratorSupplier.get();
/* 182 */     ConfigurationModel configururationModel = new ConfigurationModel();
/* 183 */     configururationModel.addSubModel(modelFromIncludedFile);
/* 184 */     genericXMLConfigurator.processModel((Model)configururationModel);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\tyler\TylerConfiguratorBase.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */