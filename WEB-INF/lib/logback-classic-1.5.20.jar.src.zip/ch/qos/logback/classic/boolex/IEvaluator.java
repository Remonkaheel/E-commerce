package ch.qos.logback.classic.boolex;

import ch.qos.logback.classic.spi.ILoggingEvent;

public interface IEvaluator {
  boolean doEvaluate(ILoggingEvent paramILoggingEvent);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\boolex\IEvaluator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */