/*    */ package ch.qos.logback.classic.boolex;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.slf4j.Marker;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MarkerList
/*    */ {
/*    */   List<Marker> markers;
/*    */   
/*    */   public MarkerList(List<Marker> markers) {
/* 31 */     this.markers = markers;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean contains(String markerName) {
/* 41 */     if (markerName == null || markerName.trim().length() == 0) {
/* 42 */       return false;
/*    */     }
/* 44 */     if (this.markers == null || this.markers.isEmpty()) {
/* 45 */       return false;
/*    */     }
/* 47 */     boolean result = this.markers.stream().anyMatch(m -> m.contains(markerName));
/* 48 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Marker getFirstMarker() {
/* 58 */     if (this.markers == null || this.markers.isEmpty()) {
/* 59 */       return null;
/*    */     }
/* 61 */     return this.markers.get(0);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\boolex\MarkerList.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */