/*    */ package ch.qos.logback.classic.selector.servlet;
/*    */ 
/*    */ import ch.qos.logback.classic.LoggerContext;
/*    */ import ch.qos.logback.classic.selector.ContextJNDISelector;
/*    */ import ch.qos.logback.classic.selector.ContextSelector;
/*    */ import ch.qos.logback.classic.util.ContextSelectorStaticBinder;
/*    */ import jakarta.servlet.Filter;
/*    */ import jakarta.servlet.FilterChain;
/*    */ import jakarta.servlet.FilterConfig;
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.ServletRequest;
/*    */ import jakarta.servlet.ServletResponse;
/*    */ import java.io.IOException;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggerContextFilter
/*    */   implements Filter
/*    */ {
/*    */   public void destroy() {}
/*    */   
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 55 */     LoggerContext lc = (LoggerContext)LoggerFactory.getILoggerFactory();
/* 56 */     ContextSelector selector = ContextSelectorStaticBinder.getSingleton().getContextSelector();
/* 57 */     ContextJNDISelector sel = null;
/*    */     
/* 59 */     if (selector instanceof ContextJNDISelector) {
/* 60 */       sel = (ContextJNDISelector)selector;
/* 61 */       sel.setLocalContext(lc);
/*    */     } 
/*    */     
/*    */     try {
/* 65 */       chain.doFilter(request, response);
/*    */     } finally {
/* 67 */       if (sel != null)
/* 68 */         sel.removeLocalContext(); 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void init(FilterConfig arg0) throws ServletException {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\selector\servlet\LoggerContextFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */