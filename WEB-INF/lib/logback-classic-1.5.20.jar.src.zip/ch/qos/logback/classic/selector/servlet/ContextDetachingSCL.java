/*    */ package ch.qos.logback.classic.selector.servlet;
/*    */ 
/*    */ import ch.qos.logback.classic.Logger;
/*    */ import ch.qos.logback.classic.LoggerContext;
/*    */ import ch.qos.logback.classic.selector.ContextSelector;
/*    */ import ch.qos.logback.classic.util.ContextSelectorStaticBinder;
/*    */ import ch.qos.logback.core.util.JNDIUtil;
/*    */ import jakarta.servlet.ServletContextEvent;
/*    */ import jakarta.servlet.ServletContextListener;
/*    */ import javax.naming.Context;
/*    */ import javax.naming.NamingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ContextDetachingSCL
/*    */   implements ServletContextListener
/*    */ {
/*    */   public void contextInitialized(ServletContextEvent arg0) {}
/*    */   
/*    */   public void contextDestroyed(ServletContextEvent servletContextEvent) {
/* 37 */     String loggerContextName = null;
/*    */     
/*    */     try {
/* 40 */       Context ctx = JNDIUtil.getInitialContext();
/* 41 */       loggerContextName = JNDIUtil.lookupString(ctx, "java:comp/env/logback/context-name");
/* 42 */     } catch (NamingException namingException) {}
/*    */ 
/*    */     
/* 45 */     if (loggerContextName != null) {
/* 46 */       System.out.println("About to detach context named " + loggerContextName);
/*    */       
/* 48 */       ContextSelector selector = ContextSelectorStaticBinder.getSingleton().getContextSelector();
/* 49 */       if (selector == null) {
/* 50 */         System.out.println("Selector is null, cannot detach context. Skipping.");
/*    */         return;
/*    */       } 
/* 53 */       LoggerContext context = selector.getLoggerContext(loggerContextName);
/* 54 */       if (context != null) {
/* 55 */         Logger logger = context.getLogger("ROOT");
/* 56 */         logger.warn("Stopping logger context " + loggerContextName);
/* 57 */         selector.detachLoggerContext(loggerContextName);
/*    */         
/* 59 */         context.stop();
/*    */       } else {
/* 61 */         System.out.println("No context named " + loggerContextName + " was found.");
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\selector\servlet\ContextDetachingSCL.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */