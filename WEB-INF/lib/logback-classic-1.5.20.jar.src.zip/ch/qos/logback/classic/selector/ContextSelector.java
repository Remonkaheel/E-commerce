package ch.qos.logback.classic.selector;

import ch.qos.logback.classic.LoggerContext;
import java.util.List;

public interface ContextSelector {
  LoggerContext getLoggerContext();
  
  LoggerContext getLoggerContext(String paramString);
  
  LoggerContext getDefaultLoggerContext();
  
  LoggerContext detachLoggerContext(String paramString);
  
  List<String> getContextNames();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\selector\ContextSelector.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */