/*     */ package ch.qos.logback.classic.selector;
/*     */ 
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.classic.joran.JoranConfigurator;
/*     */ import ch.qos.logback.classic.util.ContextInitializer;
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.spi.JoranException;
/*     */ import ch.qos.logback.core.status.InfoStatus;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import ch.qos.logback.core.status.StatusManager;
/*     */ import ch.qos.logback.core.status.StatusUtil;
/*     */ import ch.qos.logback.core.status.WarnStatus;
/*     */ import ch.qos.logback.core.util.JNDIUtil;
/*     */ import ch.qos.logback.core.util.Loader;
/*     */ import ch.qos.logback.core.util.StatusPrinter;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.NamingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContextJNDISelector
/*     */   implements ContextSelector
/*     */ {
/*     */   private final Map<String, LoggerContext> synchronizedContextMap;
/*     */   private final LoggerContext defaultContext;
/*  57 */   private static final ThreadLocal<LoggerContext> threadLocal = new ThreadLocal<>();
/*     */   
/*     */   public ContextJNDISelector(LoggerContext context) {
/*  60 */     this.synchronizedContextMap = Collections.synchronizedMap(new HashMap<>());
/*  61 */     this.defaultContext = context;
/*     */   }
/*     */   
/*     */   public LoggerContext getDefaultLoggerContext() {
/*  65 */     return this.defaultContext;
/*     */   }
/*     */   
/*     */   public LoggerContext detachLoggerContext(String loggerContextName) {
/*  69 */     return this.synchronizedContextMap.remove(loggerContextName);
/*     */   }
/*     */   
/*     */   public LoggerContext getLoggerContext() {
/*  73 */     String contextName = null;
/*  74 */     Context ctx = null;
/*     */ 
/*     */     
/*  77 */     LoggerContext lc = threadLocal.get();
/*  78 */     if (lc != null) {
/*  79 */       return lc;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  85 */       ctx = JNDIUtil.getInitialContext();
/*  86 */       contextName = JNDIUtil.lookupString(ctx, "java:comp/env/logback/context-name");
/*  87 */     } catch (NamingException namingException) {}
/*     */ 
/*     */ 
/*     */     
/*  91 */     if (contextName == null)
/*     */     {
/*  93 */       return this.defaultContext;
/*     */     }
/*     */     
/*  96 */     LoggerContext loggerContext = this.synchronizedContextMap.get(contextName);
/*     */     
/*  98 */     if (loggerContext == null) {
/*     */       
/* 100 */       loggerContext = new LoggerContext();
/* 101 */       loggerContext.setName(contextName);
/* 102 */       this.synchronizedContextMap.put(contextName, loggerContext);
/* 103 */       URL url = findConfigFileURL(ctx, loggerContext);
/* 104 */       if (url != null) {
/* 105 */         configureLoggerContextByURL(loggerContext, url);
/*     */       } else {
/*     */         try {
/* 108 */           (new ContextInitializer(loggerContext)).autoConfig();
/* 109 */         } catch (JoranException joranException) {}
/*     */       } 
/*     */ 
/*     */       
/* 113 */       if (!StatusUtil.contextHasStatusListener((Context)loggerContext))
/* 114 */         StatusPrinter.printInCaseOfErrorsOrWarnings((Context)loggerContext); 
/*     */     } 
/* 116 */     return loggerContext;
/*     */   }
/*     */ 
/*     */   
/*     */   private String conventionalConfigFileName(String contextName) {
/* 121 */     return "logback-" + contextName + ".xml";
/*     */   }
/*     */   
/*     */   private URL findConfigFileURL(Context ctx, LoggerContext loggerContext) {
/* 125 */     StatusManager sm = loggerContext.getStatusManager();
/*     */     
/* 127 */     String jndiEntryForConfigResource = null;
/*     */     
/*     */     try {
/* 130 */       jndiEntryForConfigResource = JNDIUtil.lookupString(ctx, "java:comp/env/logback/configuration-resource");
/* 131 */     } catch (NamingException e) {
/* 132 */       sm.add((Status)new WarnStatus("JNDI lookup failed", this, e));
/*     */     } 
/*     */     
/* 135 */     if (jndiEntryForConfigResource != null) {
/* 136 */       sm.add((Status)new InfoStatus("Searching for [" + jndiEntryForConfigResource + "]", this));
/* 137 */       URL url = urlByResourceName(sm, jndiEntryForConfigResource);
/* 138 */       if (url == null) {
/*     */         
/* 140 */         String msg = "The jndi resource [" + jndiEntryForConfigResource + "] for context [" + loggerContext.getName() + "] does not lead to a valid file";
/* 141 */         sm.add((Status)new WarnStatus(msg, this));
/*     */       } 
/* 143 */       return url;
/*     */     } 
/* 145 */     String resourceByConvention = conventionalConfigFileName(loggerContext.getName());
/* 146 */     return urlByResourceName(sm, resourceByConvention);
/*     */   }
/*     */ 
/*     */   
/*     */   private URL urlByResourceName(StatusManager sm, String resourceName) {
/* 151 */     sm.add((Status)new InfoStatus("Searching for [" + resourceName + "]", this));
/* 152 */     URL url = Loader.getResource(resourceName, Loader.getTCL());
/* 153 */     if (url != null) {
/* 154 */       return url;
/*     */     }
/* 156 */     return Loader.getResourceBySelfClassLoader(resourceName);
/*     */   }
/*     */   
/*     */   private void configureLoggerContextByURL(LoggerContext context, URL url) {
/*     */     try {
/* 161 */       JoranConfigurator configurator = new JoranConfigurator();
/* 162 */       context.reset();
/* 163 */       configurator.setContext((Context)context);
/* 164 */       configurator.doConfigure(url);
/* 165 */     } catch (JoranException joranException) {}
/*     */     
/* 167 */     StatusPrinter.printInCaseOfErrorsOrWarnings((Context)context);
/*     */   }
/*     */   
/*     */   public List<String> getContextNames() {
/* 171 */     List<String> list = new ArrayList<>();
/* 172 */     list.addAll(this.synchronizedContextMap.keySet());
/* 173 */     return list;
/*     */   }
/*     */   
/*     */   public LoggerContext getLoggerContext(String name) {
/* 177 */     return this.synchronizedContextMap.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCount() {
/* 186 */     return this.synchronizedContextMap.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocalContext(LoggerContext context) {
/* 198 */     threadLocal.set(context);
/*     */   }
/*     */   
/*     */   public void removeLocalContext() {
/* 202 */     threadLocal.remove();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\selector\ContextJNDISelector.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */