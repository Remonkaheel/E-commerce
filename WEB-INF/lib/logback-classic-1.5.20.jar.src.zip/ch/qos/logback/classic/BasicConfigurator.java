/*    */ package ch.qos.logback.classic;
/*    */ 
/*    */ import ch.qos.logback.classic.layout.TTLLLayout;
/*    */ import ch.qos.logback.classic.spi.Configurator;
/*    */ import ch.qos.logback.classic.spi.ConfiguratorRank;
/*    */ import ch.qos.logback.classic.spi.ILoggingEvent;
/*    */ import ch.qos.logback.core.Appender;
/*    */ import ch.qos.logback.core.ConsoleAppender;
/*    */ import ch.qos.logback.core.Layout;
/*    */ import ch.qos.logback.core.encoder.Encoder;
/*    */ import ch.qos.logback.core.encoder.LayoutWrappingEncoder;
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @ConfiguratorRank(-10)
/*    */ public class BasicConfigurator
/*    */   extends ContextAwareBase
/*    */   implements Configurator
/*    */ {
/*    */   public Configurator.ExecutionStatus configure(LoggerContext loggerContext) {
/* 39 */     addInfo("Setting up default configuration.");
/*    */     
/* 41 */     ConsoleAppender<ILoggingEvent> ca = new ConsoleAppender();
/* 42 */     ca.setContext(this.context);
/* 43 */     ca.setName("console");
/* 44 */     LayoutWrappingEncoder<ILoggingEvent> encoder = new LayoutWrappingEncoder();
/* 45 */     encoder.setContext(this.context);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 51 */     TTLLLayout layout = new TTLLLayout();
/*    */     
/* 53 */     layout.setContext(this.context);
/* 54 */     layout.start();
/* 55 */     encoder.setLayout((Layout)layout);
/*    */     
/* 57 */     ca.setEncoder((Encoder)encoder);
/* 58 */     ca.start();
/*    */     
/* 60 */     Logger rootLogger = loggerContext.getLogger("ROOT");
/* 61 */     rootLogger.addAppender((Appender<ILoggingEvent>)ca);
/*    */ 
/*    */     
/* 64 */     return Configurator.ExecutionStatus.NEUTRAL;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\BasicConfigurator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */