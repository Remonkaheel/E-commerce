/*    */ package ch.qos.logback.classic.pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ThrowableHandlingConverter
/*    */   extends ClassicConverter
/*    */ {
/*    */   boolean handlesThrowable() {
/* 23 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\pattern\ThrowableHandlingConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */