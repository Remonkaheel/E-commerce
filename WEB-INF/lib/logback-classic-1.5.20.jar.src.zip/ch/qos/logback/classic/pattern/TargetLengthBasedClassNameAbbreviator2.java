/*     */ package ch.qos.logback.classic.pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TargetLengthBasedClassNameAbbreviator2
/*     */   implements Abbreviator
/*     */ {
/*     */   final int targetLength;
/*     */   
/*     */   public TargetLengthBasedClassNameAbbreviator2(int targetLength) {
/*  24 */     this.targetLength = targetLength;
/*     */   }
/*     */   
/*     */   public String abbreviate(String fqClassName) {
/*  28 */     StringBuilder buf = new StringBuilder(this.targetLength);
/*  29 */     if (fqClassName == null) {
/*  30 */       throw new IllegalArgumentException("Class name may not be null");
/*     */     }
/*     */     
/*  33 */     int inLen = fqClassName.length();
/*  34 */     if (inLen < this.targetLength) {
/*  35 */       return fqClassName;
/*     */     }
/*     */     
/*  38 */     int[] dotIndexesArray = new int[16];
/*     */ 
/*     */     
/*  41 */     int[] lengthArray = new int[17];
/*     */     
/*  43 */     int dotCount = computeDotIndexes(fqClassName, dotIndexesArray);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  48 */     if (dotCount == 0) {
/*  49 */       return fqClassName;
/*     */     }
/*     */     
/*  52 */     computeLengthArray(fqClassName, dotIndexesArray, lengthArray, dotCount);
/*     */     
/*  54 */     for (int i = 0; i <= dotCount; i++) {
/*  55 */       if (i == 0) {
/*  56 */         buf.append(fqClassName.substring(0, lengthArray[i] - 1));
/*     */       } else {
/*  58 */         buf.append(fqClassName.substring(dotIndexesArray[i - 1], dotIndexesArray[i - 1] + lengthArray[i]));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  63 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int computeDotIndexes(String className, int[] dotArray) {
/*  75 */     int dotCount = 0;
/*  76 */     int k = 0;
/*     */ 
/*     */     
/*     */     while (true) {
/*  80 */       k = className.indexOf('.', k);
/*  81 */       if (k != -1 && dotCount < 16) {
/*  82 */         dotArray[dotCount] = k;
/*  83 */         dotCount++;
/*  84 */         k++;
/*     */         continue;
/*     */       } 
/*     */       break;
/*     */     } 
/*  89 */     return dotCount;
/*     */   }
/*     */   
/*     */   void computeLengthArray(String className, int[] dotArray, int[] lengthArray, int dotCount) {
/*  93 */     int toTrim = className.length() - this.targetLength;
/*     */ 
/*     */ 
/*     */     
/*  97 */     for (int i = 0; i < dotCount; i++) {
/*     */ 
/*     */ 
/*     */       
/* 101 */       int len, previousDotPosition = (i == 0) ? -1 : dotArray[i - 1];
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 106 */       int charactersInSegment = dotArray[i] - previousDotPosition - 1;
/*     */ 
/*     */ 
/*     */       
/* 110 */       if (toTrim > 0) {
/* 111 */         len = (charactersInSegment < 1) ? charactersInSegment : 1;
/*     */       } else {
/* 113 */         len = charactersInSegment;
/*     */       } 
/*     */ 
/*     */       
/* 117 */       toTrim -= charactersInSegment - len;
/* 118 */       lengthArray[i] = len + 1;
/*     */     } 
/*     */     
/* 121 */     int lastDotIndex = dotCount - 1;
/* 122 */     lengthArray[dotCount] = className.length() - dotArray[lastDotIndex];
/*     */   }
/*     */   
/*     */   static void printArray(String msg, int[] ia) {
/* 126 */     System.out.print(msg);
/* 127 */     for (int i = 0; i < ia.length; i++) {
/* 128 */       if (i == 0) {
/* 129 */         System.out.print(ia[i]);
/*     */       } else {
/* 131 */         System.out.print(", " + ia[i]);
/*     */       } 
/*     */     } 
/* 134 */     System.out.println();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\pattern\TargetLengthBasedClassNameAbbreviator2.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */