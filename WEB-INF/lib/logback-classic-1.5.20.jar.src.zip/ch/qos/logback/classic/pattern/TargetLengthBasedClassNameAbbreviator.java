/*    */ package ch.qos.logback.classic.pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TargetLengthBasedClassNameAbbreviator
/*    */   implements Abbreviator
/*    */ {
/*    */   final int targetLength;
/*    */   
/*    */   public TargetLengthBasedClassNameAbbreviator(int targetLength) {
/* 23 */     this.targetLength = targetLength;
/*    */   }
/*    */   
/*    */   public String abbreviate(String fqClassName) {
/* 27 */     if (fqClassName == null) {
/* 28 */       throw new IllegalArgumentException("Class name may not be null");
/*    */     }
/*    */     
/* 31 */     int inLen = fqClassName.length();
/* 32 */     if (inLen < this.targetLength) {
/* 33 */       return fqClassName;
/*    */     }
/*    */     
/* 36 */     StringBuilder buf = new StringBuilder(inLen);
/*    */     
/* 38 */     int rightMostDotIndex = fqClassName.lastIndexOf('.');
/*    */     
/* 40 */     if (rightMostDotIndex == -1) {
/* 41 */       return fqClassName;
/*    */     }
/*    */     
/* 44 */     int lastSegmentLength = inLen - rightMostDotIndex;
/*    */     
/* 46 */     int leftSegments_TargetLen = this.targetLength - lastSegmentLength;
/* 47 */     if (leftSegments_TargetLen < 0) {
/* 48 */       leftSegments_TargetLen = 0;
/*    */     }
/* 50 */     int leftSegmentsLen = inLen - lastSegmentLength;
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 55 */     int maxPossibleTrim = leftSegmentsLen - leftSegments_TargetLen;
/*    */     
/* 57 */     int trimmed = 0;
/* 58 */     boolean inDotState = true;
/*    */     
/* 60 */     int i = 0;
/* 61 */     for (; i < rightMostDotIndex; i++) {
/* 62 */       char c = fqClassName.charAt(i);
/* 63 */       if (c == '.') {
/*    */         
/* 65 */         if (trimmed >= maxPossibleTrim)
/*    */           break; 
/* 67 */         buf.append(c);
/* 68 */         inDotState = true;
/*    */       }
/* 70 */       else if (inDotState) {
/* 71 */         buf.append(c);
/* 72 */         inDotState = false;
/*    */       } else {
/* 74 */         trimmed++;
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 79 */     buf.append(fqClassName.substring(i));
/* 80 */     return buf.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\pattern\TargetLengthBasedClassNameAbbreviator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */