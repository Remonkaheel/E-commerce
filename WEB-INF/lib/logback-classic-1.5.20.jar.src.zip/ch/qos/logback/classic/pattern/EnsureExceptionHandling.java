/*    */ package ch.qos.logback.classic.pattern;
/*    */ 
/*    */ import ch.qos.logback.classic.LoggerContext;
/*    */ import ch.qos.logback.classic.spi.ILoggingEvent;
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.pattern.CompositeConverter;
/*    */ import ch.qos.logback.core.pattern.Converter;
/*    */ import ch.qos.logback.core.pattern.ConverterUtil;
/*    */ import ch.qos.logback.core.pattern.PostCompileProcessor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EnsureExceptionHandling
/*    */   implements PostCompileProcessor<ILoggingEvent>
/*    */ {
/*    */   public void process(Context context, Converter<ILoggingEvent> head) {
/* 41 */     if (head == null)
/*    */     {
/* 43 */       throw new IllegalArgumentException("cannot process empty chain");
/*    */     }
/* 45 */     if (!chainHandlesThrowable(head)) {
/* 46 */       ThrowableProxyConverter throwableProxyConverter; Converter<ILoggingEvent> tail = ConverterUtil.findTail(head);
/* 47 */       Converter<ILoggingEvent> exConverter = null;
/* 48 */       LoggerContext loggerContext = (LoggerContext)context;
/* 49 */       if (loggerContext.isPackagingDataEnabled()) {
/* 50 */         throwableProxyConverter = new ExtendedThrowableProxyConverter();
/*    */       } else {
/* 52 */         throwableProxyConverter = new ThrowableProxyConverter();
/*    */       } 
/* 54 */       tail.setNext((Converter)throwableProxyConverter);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean chainHandlesThrowable(Converter<ILoggingEvent> head) {
/* 65 */     Converter<ILoggingEvent> c = head;
/* 66 */     while (c != null) {
/* 67 */       if (c instanceof ThrowableHandlingConverter)
/* 68 */         return true; 
/* 69 */       if (c instanceof CompositeConverter && 
/* 70 */         compositeHandlesThrowable((CompositeConverter<ILoggingEvent>)c)) {
/* 71 */         return true;
/*    */       }
/*    */       
/* 74 */       c = c.getNext();
/*    */     } 
/* 76 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean compositeHandlesThrowable(CompositeConverter<ILoggingEvent> compositeConverter) {
/* 86 */     Converter<ILoggingEvent> childConverter = compositeConverter.getChildConverter();
/*    */     
/* 88 */     for (Converter<ILoggingEvent> c = childConverter; c != null; c = c.getNext()) {
/* 89 */       if (c instanceof ThrowableHandlingConverter)
/* 90 */         return true; 
/* 91 */       if (c instanceof CompositeConverter) {
/* 92 */         boolean r = compositeHandlesThrowable((CompositeConverter<ILoggingEvent>)c);
/* 93 */         if (r) {
/* 94 */           return true;
/*    */         }
/*    */       } 
/*    */     } 
/* 98 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\pattern\EnsureExceptionHandling.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */