package ch.qos.logback.classic.pattern;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.pattern.DynamicConverter;

public abstract class ClassicConverter extends DynamicConverter<ILoggingEvent> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\pattern\ClassicConverter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */