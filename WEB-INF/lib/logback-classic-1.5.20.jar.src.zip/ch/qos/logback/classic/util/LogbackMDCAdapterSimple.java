/*     */ package ch.qos.logback.classic.util;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Deque;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.slf4j.helpers.ThreadLocalMapOfStacks;
/*     */ import org.slf4j.spi.MDCAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogbackMDCAdapterSimple
/*     */   implements MDCAdapter
/*     */ {
/*  57 */   final ThreadLocal<Map<String, String>> threadLocalUnmodifiableMap = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   private final ThreadLocalMapOfStacks threadLocalMapOfDeques = new ThreadLocalMapOfStacks();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, String> duplicateMap(Map<String, String> oldMap) {
/*  84 */     if (oldMap != null) {
/*  85 */       return new HashMap<>(oldMap);
/*     */     }
/*  87 */     return new HashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String key, String val) throws IllegalArgumentException {
/* 102 */     if (key == null) {
/* 103 */       throw new IllegalArgumentException("key cannot be null");
/*     */     }
/*     */     
/* 106 */     Map<String, String> oldMap = this.threadLocalUnmodifiableMap.get();
/* 107 */     Map<String, String> newMap = duplicateMap(oldMap);
/* 108 */     newMap.put(key, val);
/* 109 */     makeUnmodifiableAndThreadLocalSet(newMap);
/*     */   }
/*     */   
/*     */   private void makeUnmodifiableAndThreadLocalSet(Map<String, String> aMap) {
/* 113 */     Map<String, String> unmodifiable = Collections.unmodifiableMap(aMap);
/* 114 */     this.threadLocalUnmodifiableMap.set(unmodifiable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(String key) {
/* 122 */     if (key == null) {
/*     */       return;
/*     */     }
/* 125 */     Map<String, String> oldMap = this.threadLocalUnmodifiableMap.get();
/* 126 */     if (oldMap == null) {
/*     */       return;
/*     */     }
/* 129 */     Map<String, String> newMap = duplicateMap(oldMap);
/* 130 */     newMap.remove(key);
/* 131 */     makeUnmodifiableAndThreadLocalSet(newMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 138 */     this.threadLocalUnmodifiableMap.remove();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String get(String key) {
/* 146 */     Map<String, String> map = this.threadLocalUnmodifiableMap.get();
/* 147 */     if (map != null && key != null) {
/* 148 */       return map.get(key);
/*     */     }
/* 150 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getPropertyMap() {
/* 159 */     return this.threadLocalUnmodifiableMap.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getKeys() {
/* 166 */     Map<String, String> map = getPropertyMap();
/*     */     
/* 168 */     if (map != null) {
/* 169 */       return map.keySet();
/*     */     }
/* 171 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getCopyOfContextMap() {
/* 180 */     Map<String, String> hashMap = this.threadLocalUnmodifiableMap.get();
/* 181 */     return duplicateMap(hashMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContextMap(Map<String, String> contextMap) {
/* 190 */     duplicateMap(contextMap);
/*     */   }
/*     */ 
/*     */   
/*     */   public void pushByKey(String key, String value) {
/* 195 */     this.threadLocalMapOfDeques.pushByKey(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String popByKey(String key) {
/* 200 */     return this.threadLocalMapOfDeques.popByKey(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Deque<String> getCopyOfDequeByKey(String key) {
/* 205 */     return this.threadLocalMapOfDeques.getCopyOfDequeByKey(key);
/*     */   }
/*     */   
/*     */   public void clearDequeByKey(String key) {
/* 209 */     this.threadLocalMapOfDeques.clearDequeByKey(key);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classi\\util\LogbackMDCAdapterSimple.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */