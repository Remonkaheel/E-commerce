/*    */ package ch.qos.logback.classic.util;
/*    */ 
/*    */ import ch.qos.logback.classic.Level;
/*    */ import ch.qos.logback.core.joran.JoranConstants;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LevelUtil
/*    */ {
/*    */   public static boolean isInheritedLevelString(String levelStr) {
/* 33 */     if ("INHERITED".equalsIgnoreCase(levelStr) || JoranConstants.NULL.equalsIgnoreCase(levelStr)) {
/* 34 */       return true;
/*    */     }
/* 36 */     return false;
/*    */   }
/*    */   
/*    */   public static Level levelStringToLevel(String levelStr) {
/* 40 */     if (!OptionHelper.isNullOrEmptyOrAllSpaces(levelStr)) {
/* 41 */       if (isInheritedLevelString(levelStr)) {
/* 42 */         return null;
/*    */       }
/* 44 */       Level level = Level.toLevel(levelStr);
/* 45 */       return level;
/*    */     } 
/*    */     
/* 48 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classi\\util\LevelUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */