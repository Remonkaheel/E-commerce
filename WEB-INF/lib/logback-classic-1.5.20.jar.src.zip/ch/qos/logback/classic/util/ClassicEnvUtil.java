/*    */ package ch.qos.logback.classic.util;
/*    */ 
/*    */ import ch.qos.logback.core.util.EnvUtil;
/*    */ import java.lang.module.ModuleDescriptor;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Optional;
/*    */ import java.util.ServiceLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassicEnvUtil
/*    */ {
/*    */   public static boolean isGroovyAvailable() {
/* 35 */     return EnvUtil.isClassAvailable(ClassicEnvUtil.class, "groovy.lang.Binding");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> List<T> loadFromServiceLoader(Class<T> c, ClassLoader classLoader) {
/* 44 */     ServiceLoader<T> loader = ServiceLoader.load(c, classLoader);
/* 45 */     List<T> listOfT = new ArrayList<>();
/* 46 */     Iterator<T> it = loader.iterator();
/* 47 */     while (it.hasNext()) {
/* 48 */       T t = it.next();
/* 49 */       listOfT.add(t);
/*    */     } 
/* 51 */     return listOfT;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getVersionOfLogbackClassic() {
/* 63 */     String moduleVersion = getVersionOfLogbackClassicByModule();
/* 64 */     if (moduleVersion != null) {
/* 65 */       return moduleVersion;
/*    */     }
/* 67 */     Package pkg = ClassicEnvUtil.class.getPackage();
/* 68 */     if (pkg == null) {
/* 69 */       return null;
/*    */     }
/* 71 */     return pkg.getImplementationVersion();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static String getVersionOfLogbackClassicByModule() {
/* 83 */     Module module = ClassicEnvUtil.class.getModule();
/* 84 */     if (module == null) {
/* 85 */       return null;
/*    */     }
/* 87 */     ModuleDescriptor md = module.getDescriptor();
/* 88 */     if (md == null)
/* 89 */       return null; 
/* 90 */     Optional<String> opt = md.rawVersion();
/* 91 */     return opt.orElse(null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classi\\util\ClassicEnvUtil.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */