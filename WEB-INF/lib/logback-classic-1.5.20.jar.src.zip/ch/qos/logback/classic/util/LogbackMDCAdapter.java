/*     */ package ch.qos.logback.classic.util;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Deque;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.slf4j.helpers.ThreadLocalMapOfStacks;
/*     */ import org.slf4j.spi.MDCAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LogbackMDCAdapter
/*     */   implements MDCAdapter
/*     */ {
/*  47 */   final ThreadLocal<Map<String, String>> readWriteThreadLocalMap = new ThreadLocal<>();
/*  48 */   final ThreadLocal<Map<String, String>> readOnlyThreadLocalMap = new ThreadLocal<>();
/*  49 */   private final ThreadLocalMapOfStacks threadLocalMapOfDeques = new ThreadLocalMapOfStacks();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String key, String val) throws IllegalArgumentException {
/*  69 */     if (key == null) {
/*  70 */       throw new IllegalArgumentException("key cannot be null");
/*     */     }
/*  72 */     Map<String, String> current = this.readWriteThreadLocalMap.get();
/*  73 */     if (current == null) {
/*  74 */       current = new HashMap<>();
/*  75 */       this.readWriteThreadLocalMap.set(current);
/*     */     } 
/*     */     
/*  78 */     current.put(key, val);
/*  79 */     nullifyReadOnlyThreadLocalMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String get(String key) {
/*  90 */     Map<String, String> hashMap = this.readWriteThreadLocalMap.get();
/*     */     
/*  92 */     if (hashMap != null && key != null) {
/*  93 */       return hashMap.get(key);
/*     */     }
/*  95 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(String key) {
/* 105 */     if (key == null) {
/*     */       return;
/*     */     }
/*     */     
/* 109 */     Map<String, String> current = this.readWriteThreadLocalMap.get();
/* 110 */     if (current != null) {
/* 111 */       current.remove(key);
/* 112 */       nullifyReadOnlyThreadLocalMap();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void nullifyReadOnlyThreadLocalMap() {
/* 117 */     this.readOnlyThreadLocalMap.set(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 125 */     this.readWriteThreadLocalMap.set(null);
/* 126 */     nullifyReadOnlyThreadLocalMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getPropertyMap() {
/* 137 */     Map<String, String> readOnlyMap = this.readOnlyThreadLocalMap.get();
/* 138 */     if (readOnlyMap == null) {
/* 139 */       Map<String, String> current = this.readWriteThreadLocalMap.get();
/* 140 */       if (current != null) {
/* 141 */         Map<String, String> tempMap = new HashMap<>(current);
/* 142 */         readOnlyMap = Collections.unmodifiableMap(tempMap);
/* 143 */         this.readOnlyThreadLocalMap.set(readOnlyMap);
/*     */       } 
/*     */     } 
/* 146 */     return readOnlyMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map getCopyOfContextMap() {
/* 154 */     Map<String, String> readOnlyMap = getPropertyMap();
/* 155 */     if (readOnlyMap == null) {
/* 156 */       return null;
/*     */     }
/* 158 */     return new HashMap<>(readOnlyMap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getKeys() {
/* 167 */     Map<String, String> readOnlyMap = getPropertyMap();
/*     */     
/* 169 */     if (readOnlyMap != null) {
/* 170 */       return readOnlyMap.keySet();
/*     */     }
/* 172 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContextMap(Map<? extends String, ? extends String> contextMap) {
/* 178 */     if (contextMap != null) {
/* 179 */       this.readWriteThreadLocalMap.set(new HashMap<>(contextMap));
/*     */     } else {
/* 181 */       this.readWriteThreadLocalMap.set(null);
/*     */     } 
/* 183 */     nullifyReadOnlyThreadLocalMap();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushByKey(String key, String value) {
/* 189 */     this.threadLocalMapOfDeques.pushByKey(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String popByKey(String key) {
/* 194 */     return this.threadLocalMapOfDeques.popByKey(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public Deque<String> getCopyOfDequeByKey(String key) {
/* 199 */     return this.threadLocalMapOfDeques.getCopyOfDequeByKey(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearDequeByKey(String key) {
/* 204 */     this.threadLocalMapOfDeques.clearDequeByKey(key);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classi\\util\LogbackMDCAdapter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */