/*    */ package ch.qos.logback.classic.util;
/*    */ 
/*    */ import ch.qos.logback.classic.LoggerContext;
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ import ch.qos.logback.core.status.ErrorStatus;
/*    */ import ch.qos.logback.core.status.InfoStatus;
/*    */ import ch.qos.logback.core.status.Status;
/*    */ import org.slf4j.ILoggerFactory;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatusViaSLF4JLoggerFactory
/*    */ {
/*    */   public static void addInfo(String msg, Object o) {
/* 22 */     addStatus((Status)new InfoStatus(msg, o));
/*    */   }
/*    */   
/*    */   public static void addError(String msg, Object o) {
/* 26 */     addStatus((Status)new ErrorStatus(msg, o));
/*    */   }
/*    */   
/*    */   public static void addError(String msg, Object o, Throwable t) {
/* 30 */     addStatus((Status)new ErrorStatus(msg, o, t));
/*    */   }
/*    */   
/*    */   public static void addStatus(Status status) {
/* 34 */     ILoggerFactory iLoggerFactory = LoggerFactory.getILoggerFactory();
/* 35 */     if (iLoggerFactory instanceof LoggerContext) {
/* 36 */       ContextAwareBase contextAwareBase = new ContextAwareBase();
/* 37 */       LoggerContext loggerContext = (LoggerContext)iLoggerFactory;
/* 38 */       contextAwareBase.setContext((Context)loggerContext);
/* 39 */       contextAwareBase.addStatus(status);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classi\\util\StatusViaSLF4JLoggerFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */