/*     */ package ch.qos.logback.classic.util;
/*     */ 
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.classic.joran.JoranConfigurator;
/*     */ import ch.qos.logback.classic.spi.Configurator;
/*     */ import ch.qos.logback.classic.spi.ConfiguratorRank;
/*     */ import ch.qos.logback.core.LogbackException;
/*     */ import ch.qos.logback.core.joran.spi.JoranException;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.status.InfoStatus;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import ch.qos.logback.core.status.StatusManager;
/*     */ import ch.qos.logback.core.util.Loader;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfiguratorRank(0)
/*     */ public class DefaultJoranConfigurator
/*     */   extends ContextAwareBase
/*     */   implements Configurator
/*     */ {
/*     */   public Configurator.ExecutionStatus configure(LoggerContext context) {
/*  32 */     URL url = performMultiStepConfigurationFileSearch(true);
/*  33 */     if (url != null) {
/*     */       try {
/*  35 */         configureByResource(url);
/*  36 */       } catch (JoranException e) {
/*  37 */         e.printStackTrace();
/*     */       } 
/*     */       
/*  40 */       return Configurator.ExecutionStatus.DO_NOT_INVOKE_NEXT_IF_ANY;
/*     */     } 
/*  42 */     return Configurator.ExecutionStatus.INVOKE_NEXT_IF_ANY;
/*     */   }
/*     */ 
/*     */   
/*     */   private URL performMultiStepConfigurationFileSearch(boolean updateStatus) {
/*  47 */     ClassLoader myClassLoader = Loader.getClassLoaderOfObject(this);
/*  48 */     URL url = findConfigFileURLFromSystemProperties(myClassLoader, updateStatus);
/*  49 */     if (url != null) {
/*  50 */       return url;
/*     */     }
/*     */     
/*  53 */     url = getResource("logback-test.xml", myClassLoader, updateStatus);
/*  54 */     if (url != null) {
/*  55 */       return url;
/*     */     }
/*     */     
/*  58 */     return getResource("logback.xml", myClassLoader, updateStatus);
/*     */   }
/*     */   public void configureByResource(URL url) throws JoranException {
/*  61 */     if (url == null) {
/*  62 */       throw new IllegalArgumentException("URL argument cannot be null");
/*     */     }
/*  64 */     String urlString = url.toString();
/*  65 */     if (urlString.endsWith("xml")) {
/*  66 */       JoranConfigurator configurator = new JoranConfigurator();
/*  67 */       configurator.setContext(this.context);
/*  68 */       configurator.doConfigure(url);
/*     */     } else {
/*  70 */       throw new LogbackException("Unexpected filename extension of file [" + url
/*  71 */           .toString() + "]. Should be .xml");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL findURLOfDefaultConfigurationFile(boolean updateStatus) {
/*  84 */     return performMultiStepConfigurationFileSearch(updateStatus);
/*     */   }
/*     */   
/*     */   private URL findConfigFileURLFromSystemProperties(ClassLoader classLoader, boolean updateStatus) {
/*  88 */     String logbackConfigFile = OptionHelper.getSystemProperty("logback.configurationFile");
/*  89 */     if (logbackConfigFile != null) {
/*  90 */       URL result = null;
/*     */       try {
/*  92 */         result = new URL(logbackConfigFile);
/*  93 */         return result;
/*  94 */       } catch (MalformedURLException e) {
/*     */ 
/*     */         
/*  97 */         result = Loader.getResource(logbackConfigFile, classLoader);
/*  98 */         if (result != null) {
/*  99 */           return result;
/*     */         }
/*     */         
/* 102 */         File f = new File(logbackConfigFile);
/* 103 */         if (f.exists() && f.isFile()) {
/*     */           try {
/* 105 */             result = f.toURI().toURL();
/* 106 */             return result;
/* 107 */           } catch (MalformedURLException malformedURLException) {}
/*     */         }
/*     */       } finally {
/*     */         
/* 111 */         if (updateStatus) {
/* 112 */           statusOnResourceSearch(logbackConfigFile, classLoader, result);
/*     */         }
/*     */       } 
/*     */     } 
/* 116 */     return null;
/*     */   }
/*     */   
/*     */   private URL getResource(String filename, ClassLoader myClassLoader, boolean updateStatus) {
/* 120 */     URL url = Loader.getResource(filename, myClassLoader);
/* 121 */     if (updateStatus) {
/* 122 */       statusOnResourceSearch(filename, myClassLoader, url);
/*     */     }
/* 124 */     return url;
/*     */   }
/*     */   
/*     */   private void statusOnResourceSearch(String resourceName, ClassLoader classLoader, URL url) {
/* 128 */     StatusManager sm = this.context.getStatusManager();
/* 129 */     if (url == null) {
/* 130 */       sm.add((Status)new InfoStatus("Could NOT find resource [" + resourceName + "]", this.context));
/*     */     } else {
/* 132 */       sm.add((Status)new InfoStatus("Found resource [" + resourceName + "] at [" + url.toString() + "]", this.context));
/* 133 */       multiplicityWarning(resourceName, classLoader);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void multiplicityWarning(String resourceName, ClassLoader classLoader) {
/* 138 */     Set<URL> urlSet = null;
/*     */     try {
/* 140 */       urlSet = Loader.getResources(resourceName, classLoader);
/* 141 */     } catch (IOException e) {
/* 142 */       addError("Failed to get url list for resource [" + resourceName + "]", e);
/*     */     } 
/* 144 */     if (urlSet != null && urlSet.size() > 1) {
/* 145 */       addWarn("Resource [" + resourceName + "] occurs multiple times on the classpath.");
/* 146 */       for (URL url : urlSet)
/* 147 */         addWarn("Resource [" + resourceName + "] occurs at [" + url.toString() + "]"); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classi\\util\DefaultJoranConfigurator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */