/*    */ package ch.qos.logback.classic.helpers;
/*    */ 
/*    */ import jakarta.servlet.Filter;
/*    */ import jakarta.servlet.FilterChain;
/*    */ import jakarta.servlet.FilterConfig;
/*    */ import jakarta.servlet.ServletException;
/*    */ import jakarta.servlet.ServletRequest;
/*    */ import jakarta.servlet.ServletResponse;
/*    */ import jakarta.servlet.http.HttpServletRequest;
/*    */ import java.io.IOException;
/*    */ import org.slf4j.MDC;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MDCInsertingServletFilter
/*    */   implements Filter
/*    */ {
/*    */   public void destroy() {}
/*    */   
/*    */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
/* 48 */     insertIntoMDC(request);
/*    */     try {
/* 50 */       chain.doFilter(request, response);
/*    */     } finally {
/* 52 */       clearMDC();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   void insertIntoMDC(ServletRequest request) {
/* 58 */     MDC.put("req.remoteHost", request.getRemoteHost());
/*    */     
/* 60 */     if (request instanceof HttpServletRequest) {
/* 61 */       HttpServletRequest httpServletRequest = (HttpServletRequest)request;
/* 62 */       MDC.put("req.requestURI", httpServletRequest.getRequestURI());
/* 63 */       StringBuffer requestURL = httpServletRequest.getRequestURL();
/* 64 */       if (requestURL != null) {
/* 65 */         MDC.put("req.requestURL", requestURL.toString());
/*    */       }
/* 67 */       MDC.put("req.method", httpServletRequest.getMethod());
/* 68 */       MDC.put("req.queryString", httpServletRequest.getQueryString());
/* 69 */       MDC.put("req.userAgent", httpServletRequest.getHeader("User-Agent"));
/* 70 */       MDC.put("req.xForwardedFor", httpServletRequest.getHeader("X-Forwarded-For"));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   void clearMDC() {
/* 76 */     MDC.remove("req.remoteHost");
/* 77 */     MDC.remove("req.requestURI");
/* 78 */     MDC.remove("req.queryString");
/*    */     
/* 80 */     MDC.remove("req.requestURL");
/* 81 */     MDC.remove("req.method");
/* 82 */     MDC.remove("req.userAgent");
/* 83 */     MDC.remove("req.xForwardedFor");
/*    */   }
/*    */   
/*    */   public void init(FilterConfig arg0) throws ServletException {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\helpers\MDCInsertingServletFilter.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */