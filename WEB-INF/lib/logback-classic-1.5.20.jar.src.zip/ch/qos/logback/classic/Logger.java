/*     */ package ch.qos.logback.classic;
/*     */ 
/*     */ import ch.qos.logback.classic.spi.ILoggingEvent;
/*     */ import ch.qos.logback.classic.spi.LoggingEvent;
/*     */ import ch.qos.logback.classic.util.LoggerNameUtil;
/*     */ import ch.qos.logback.core.Appender;
/*     */ import ch.qos.logback.core.spi.AppenderAttachable;
/*     */ import ch.qos.logback.core.spi.AppenderAttachableImpl;
/*     */ import ch.qos.logback.core.spi.FilterReply;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.slf4j.Marker;
/*     */ import org.slf4j.event.Level;
/*     */ import org.slf4j.event.LoggingEvent;
/*     */ import org.slf4j.spi.DefaultLoggingEventBuilder;
/*     */ import org.slf4j.spi.LocationAwareLogger;
/*     */ import org.slf4j.spi.LoggingEventAware;
/*     */ import org.slf4j.spi.LoggingEventBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Logger
/*     */   implements Logger, LocationAwareLogger, LoggingEventAware, AppenderAttachable<ILoggingEvent>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 5454405123156820674L;
/*  47 */   public static final String FQCN = Logger.class.getName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient Level level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient int effectiveLevelInt;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient Logger parent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient List<Logger> childrenList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient AppenderAttachableImpl<ILoggingEvent> aai;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient boolean additive = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final transient LoggerContext loggerContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Logger(String name, Logger parent, LoggerContext loggerContext) {
/* 106 */     this.name = name;
/* 107 */     this.parent = parent;
/* 108 */     this.loggerContext = loggerContext;
/*     */   }
/*     */   
/*     */   public Level getEffectiveLevel() {
/* 112 */     return Level.toLevel(this.effectiveLevelInt);
/*     */   }
/*     */   
/*     */   int getEffectiveLevelInt() {
/* 116 */     return this.effectiveLevelInt;
/*     */   }
/*     */   
/*     */   public Level getLevel() {
/* 120 */     return this.level;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 124 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isRootLogger() {
/* 129 */     return (this.parent == null);
/*     */   }
/*     */   
/*     */   Logger getChildByName(String childName) {
/* 133 */     if (this.childrenList == null) {
/* 134 */       return null;
/*     */     }
/* 136 */     int len = this.childrenList.size();
/* 137 */     for (int i = 0; i < len; i++) {
/* 138 */       Logger childLogger_i = this.childrenList.get(i);
/* 139 */       String childName_i = childLogger_i.getName();
/*     */       
/* 141 */       if (childName.equals(childName_i)) {
/* 142 */         return childLogger_i;
/*     */       }
/*     */     } 
/*     */     
/* 146 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void setLevel(Level newLevel) {
/* 151 */     if (this.level == newLevel) {
/*     */       return;
/*     */     }
/*     */     
/* 155 */     if (newLevel == null && isRootLogger()) {
/* 156 */       throw new IllegalArgumentException("The level of the root logger cannot be set to null");
/*     */     }
/*     */     
/* 159 */     this.level = newLevel;
/* 160 */     if (newLevel == null) {
/* 161 */       this.effectiveLevelInt = this.parent.effectiveLevelInt;
/* 162 */       newLevel = this.parent.getEffectiveLevel();
/*     */     } else {
/* 164 */       this.effectiveLevelInt = newLevel.levelInt;
/*     */     } 
/*     */     
/* 167 */     if (this.childrenList != null) {
/* 168 */       int len = this.childrenList.size();
/* 169 */       for (int i = 0; i < len; i++) {
/* 170 */         Logger child = this.childrenList.get(i);
/*     */         
/* 172 */         child.handleParentLevelChange(this.effectiveLevelInt);
/*     */       } 
/*     */     } 
/*     */     
/* 176 */     this.loggerContext.fireOnLevelChange(this, newLevel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void handleParentLevelChange(int newParentLevelInt) {
/* 188 */     if (this.level == null) {
/* 189 */       this.effectiveLevelInt = newParentLevelInt;
/*     */ 
/*     */       
/* 192 */       if (this.childrenList != null) {
/* 193 */         int len = this.childrenList.size();
/* 194 */         for (int i = 0; i < len; i++) {
/* 195 */           Logger child = this.childrenList.get(i);
/* 196 */           child.handleParentLevelChange(newParentLevelInt);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void detachAndStopAllAppenders() {
/* 208 */     if (this.aai != null) {
/* 209 */       this.aai.detachAndStopAllAppenders();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean detachAppender(String name) {
/* 214 */     if (this.aai == null) {
/* 215 */       return false;
/*     */     }
/* 217 */     return this.aai.detachAppender(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addAppender(Appender<ILoggingEvent> newAppender) {
/* 223 */     if (this.aai == null) {
/* 224 */       this.aai = new AppenderAttachableImpl();
/*     */     }
/* 226 */     this.aai.addAppender(newAppender);
/*     */   }
/*     */   
/*     */   public boolean isAttached(Appender<ILoggingEvent> appender) {
/* 230 */     if (this.aai == null) {
/* 231 */       return false;
/*     */     }
/* 233 */     return this.aai.isAttached(appender);
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<Appender<ILoggingEvent>> iteratorForAppenders() {
/* 238 */     if (this.aai == null) {
/* 239 */       return Collections.EMPTY_LIST.iterator();
/*     */     }
/* 241 */     return this.aai.iteratorForAppenders();
/*     */   }
/*     */   
/*     */   public Appender<ILoggingEvent> getAppender(String name) {
/* 245 */     if (this.aai == null) {
/* 246 */       return null;
/*     */     }
/* 248 */     return this.aai.getAppender(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void callAppenders(ILoggingEvent event) {
/* 257 */     int writes = 0;
/* 258 */     for (Logger l = this; l != null; l = l.parent) {
/* 259 */       writes += l.appendLoopOnAppenders(event);
/* 260 */       if (!l.additive) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 265 */     if (writes == 0) {
/* 266 */       this.loggerContext.noAppenderDefinedWarning(this);
/*     */     }
/*     */   }
/*     */   
/*     */   private int appendLoopOnAppenders(ILoggingEvent event) {
/* 271 */     if (this.aai != null) {
/* 272 */       return this.aai.appendLoopOnAppenders(event);
/*     */     }
/* 274 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean detachAppender(Appender<ILoggingEvent> appender) {
/* 282 */     if (this.aai == null) {
/* 283 */       return false;
/*     */     }
/* 285 */     return this.aai.detachAppender(appender);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Logger createChildByLastNamePart(String lastPart) {
/*     */     Logger childLogger;
/* 303 */     int i_index = LoggerNameUtil.getFirstSeparatorIndexOf(lastPart);
/* 304 */     if (i_index != -1) {
/* 305 */       throw new IllegalArgumentException("Child name [" + lastPart + " passed as parameter, may not include [.]");
/*     */     }
/*     */ 
/*     */     
/* 309 */     if (this.childrenList == null) {
/* 310 */       this.childrenList = new CopyOnWriteArrayList<>();
/*     */     }
/*     */     
/* 313 */     if (isRootLogger()) {
/* 314 */       childLogger = new Logger(lastPart, this, this.loggerContext);
/*     */     } else {
/* 316 */       childLogger = new Logger(this.name + "." + this.name, this, this.loggerContext);
/*     */     } 
/* 318 */     this.childrenList.add(childLogger);
/* 319 */     childLogger.effectiveLevelInt = this.effectiveLevelInt;
/* 320 */     return childLogger;
/*     */   }
/*     */   
/*     */   private void localLevelReset() {
/* 324 */     this.effectiveLevelInt = 10000;
/* 325 */     if (isRootLogger()) {
/* 326 */       this.level = Level.DEBUG;
/*     */     } else {
/* 328 */       this.level = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   void recursiveReset() {
/* 333 */     detachAndStopAllAppenders();
/* 334 */     localLevelReset();
/* 335 */     this.additive = true;
/* 336 */     if (this.childrenList == null) {
/*     */       return;
/*     */     }
/* 339 */     for (Logger childLogger : this.childrenList) {
/* 340 */       childLogger.recursiveReset();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Logger createChildByName(String childName) {
/* 350 */     int i_index = LoggerNameUtil.getSeparatorIndexOf(childName, this.name.length() + 1);
/* 351 */     if (i_index != -1) {
/* 352 */       throw new IllegalArgumentException("For logger [" + this.name + "] child name [" + childName + " passed as parameter, may not include '.' after index" + this.name
/* 353 */           .length() + 1);
/*     */     }
/*     */     
/* 356 */     if (this.childrenList == null) {
/* 357 */       this.childrenList = new CopyOnWriteArrayList<>();
/*     */     }
/*     */     
/* 360 */     Logger childLogger = new Logger(childName, this, this.loggerContext);
/* 361 */     this.childrenList.add(childLogger);
/* 362 */     childLogger.effectiveLevelInt = this.effectiveLevelInt;
/* 363 */     return childLogger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void filterAndLog_0_Or3Plus(String localFQCN, Marker marker, Level level, String msg, Object[] params, Throwable t) {
/* 375 */     FilterReply decision = this.loggerContext.getTurboFilterChainDecision_0_3OrMore(marker, this, level, msg, params, t);
/*     */ 
/*     */     
/* 378 */     if (decision == FilterReply.NEUTRAL) {
/* 379 */       if (this.effectiveLevelInt > level.levelInt) {
/*     */         return;
/*     */       }
/* 382 */     } else if (decision == FilterReply.DENY) {
/*     */       return;
/*     */     } 
/*     */     
/* 386 */     buildLoggingEventAndAppend(localFQCN, marker, level, msg, params, t);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void filterAndLog_1(String localFQCN, Marker marker, Level level, String msg, Object param, Throwable t) {
/* 392 */     FilterReply decision = this.loggerContext.getTurboFilterChainDecision_1(marker, this, level, msg, param, t);
/*     */     
/* 394 */     if (decision == FilterReply.NEUTRAL) {
/* 395 */       if (this.effectiveLevelInt > level.levelInt) {
/*     */         return;
/*     */       }
/* 398 */     } else if (decision == FilterReply.DENY) {
/*     */       return;
/*     */     } 
/*     */     
/* 402 */     buildLoggingEventAndAppend(localFQCN, marker, level, msg, new Object[] { param }, t);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void filterAndLog_2(String localFQCN, Marker marker, Level level, String msg, Object param1, Object param2, Throwable t) {
/* 408 */     FilterReply decision = this.loggerContext.getTurboFilterChainDecision_2(marker, this, level, msg, param1, param2, t);
/*     */ 
/*     */     
/* 411 */     if (decision == FilterReply.NEUTRAL) {
/* 412 */       if (this.effectiveLevelInt > level.levelInt) {
/*     */         return;
/*     */       }
/* 415 */     } else if (decision == FilterReply.DENY) {
/*     */       return;
/*     */     } 
/*     */     
/* 419 */     buildLoggingEventAndAppend(localFQCN, marker, level, msg, new Object[] { param1, param2 }, t);
/*     */   }
/*     */ 
/*     */   
/*     */   private void buildLoggingEventAndAppend(String localFQCN, Marker marker, Level level, String msg, Object[] params, Throwable t) {
/* 424 */     LoggingEvent le = new LoggingEvent(localFQCN, this, level, msg, t, params);
/* 425 */     le.addMarker(marker);
/* 426 */     callAppenders((ILoggingEvent)le);
/*     */   }
/*     */   
/*     */   public void trace(String msg) {
/* 430 */     filterAndLog_0_Or3Plus(FQCN, null, Level.TRACE, msg, null, null);
/*     */   }
/*     */   
/*     */   public void trace(String format, Object arg) {
/* 434 */     filterAndLog_1(FQCN, null, Level.TRACE, format, arg, null);
/*     */   }
/*     */   
/*     */   public void trace(String format, Object arg1, Object arg2) {
/* 438 */     filterAndLog_2(FQCN, null, Level.TRACE, format, arg1, arg2, null);
/*     */   }
/*     */   
/*     */   public void trace(String format, Object... argArray) {
/* 442 */     filterAndLog_0_Or3Plus(FQCN, null, Level.TRACE, format, argArray, null);
/*     */   }
/*     */   
/*     */   public void trace(String msg, Throwable t) {
/* 446 */     filterAndLog_0_Or3Plus(FQCN, null, Level.TRACE, msg, null, t);
/*     */   }
/*     */   
/*     */   public void trace(Marker marker, String msg) {
/* 450 */     filterAndLog_0_Or3Plus(FQCN, marker, Level.TRACE, msg, null, null);
/*     */   }
/*     */   
/*     */   public void trace(Marker marker, String format, Object arg) {
/* 454 */     filterAndLog_1(FQCN, marker, Level.TRACE, format, arg, null);
/*     */   }
/*     */   
/*     */   public void trace(Marker marker, String format, Object arg1, Object arg2) {
/* 458 */     filterAndLog_2(FQCN, marker, Level.TRACE, format, arg1, arg2, null);
/*     */   }
/*     */   
/*     */   public void trace(Marker marker, String format, Object... argArray) {
/* 462 */     filterAndLog_0_Or3Plus(FQCN, marker, Level.TRACE, format, argArray, null);
/*     */   }
/*     */   
/*     */   public void trace(Marker marker, String msg, Throwable t) {
/* 466 */     filterAndLog_0_Or3Plus(FQCN, marker, Level.TRACE, msg, null, t);
/*     */   }
/*     */   
/*     */   public boolean isDebugEnabled() {
/* 470 */     return isDebugEnabled(null);
/*     */   }
/*     */   
/*     */   public boolean isDebugEnabled(Marker marker) {
/* 474 */     FilterReply decision = callTurboFilters(marker, Level.DEBUG);
/* 475 */     if (decision == FilterReply.NEUTRAL)
/* 476 */       return (this.effectiveLevelInt <= 10000); 
/* 477 */     if (decision == FilterReply.DENY)
/* 478 */       return false; 
/* 479 */     if (decision == FilterReply.ACCEPT) {
/* 480 */       return true;
/*     */     }
/* 482 */     throw new IllegalStateException("Unknown FilterReply value: " + String.valueOf(decision));
/*     */   }
/*     */ 
/*     */   
/*     */   public void debug(String msg) {
/* 487 */     filterAndLog_0_Or3Plus(FQCN, null, Level.DEBUG, msg, null, null);
/*     */   }
/*     */   
/*     */   public void debug(String format, Object arg) {
/* 491 */     filterAndLog_1(FQCN, null, Level.DEBUG, format, arg, null);
/*     */   }
/*     */   
/*     */   public void debug(String format, Object arg1, Object arg2) {
/* 495 */     filterAndLog_2(FQCN, null, Level.DEBUG, format, arg1, arg2, null);
/*     */   }
/*     */   
/*     */   public void debug(String format, Object... argArray) {
/* 499 */     filterAndLog_0_Or3Plus(FQCN, null, Level.DEBUG, format, argArray, null);
/*     */   }
/*     */   
/*     */   public void debug(String msg, Throwable t) {
/* 503 */     filterAndLog_0_Or3Plus(FQCN, null, Level.DEBUG, msg, null, t);
/*     */   }
/*     */   
/*     */   public void debug(Marker marker, String msg) {
/* 507 */     filterAndLog_0_Or3Plus(FQCN, marker, Level.DEBUG, msg, null, null);
/*     */   }
/*     */   
/*     */   public void debug(Marker marker, String format, Object arg) {
/* 511 */     filterAndLog_1(FQCN, marker, Level.DEBUG, format, arg, null);
/*     */   }
/*     */   
/*     */   public void debug(Marker marker, String format, Object arg1, Object arg2) {
/* 515 */     filterAndLog_2(FQCN, marker, Level.DEBUG, format, arg1, arg2, null);
/*     */   }
/*     */   
/*     */   public void debug(Marker marker, String format, Object... argArray) {
/* 519 */     filterAndLog_0_Or3Plus(FQCN, marker, Level.DEBUG, format, argArray, null);
/*     */   }
/*     */   
/*     */   public void debug(Marker marker, String msg, Throwable t) {
/* 523 */     filterAndLog_0_Or3Plus(FQCN, marker, Level.DEBUG, msg, null, t);
/*     */   }
/*     */   
/*     */   public void error(String msg) {
/* 527 */     filterAndLog_0_Or3Plus(FQCN, null, Level.ERROR, msg, null, null);
/*     */   }
/*     */   
/*     */   public void error(String format, Object arg) {
/* 531 */     filterAndLog_1(FQCN, null, Level.ERROR, format, arg, null);
/*     */   }
/*     */   
/*     */   public void error(String format, Object arg1, Object arg2) {
/* 535 */     filterAndLog_2(FQCN, null, Level.ERROR, format, arg1, arg2, null);
/*     */   }
/*     */   
/*     */   public void error(String format, Object... argArray) {
/* 539 */     filterAndLog_0_Or3Plus(FQCN, null, Level.ERROR, format, argArray, null);
/*     */   }
/*     */   
/*     */   public void error(String msg, Throwable t) {
/* 543 */     filterAndLog_0_Or3Plus(FQCN, null, Level.ERROR, msg, null, t);
/*     */   }
/*     */   
/*     */   public void error(Marker marker, String msg) {
/* 547 */     filterAndLog_0_Or3Plus(FQCN, marker, Level.ERROR, msg, null, null);
/*     */   }
/*     */   
/*     */   public void error(Marker marker, String format, Object arg) {
/* 551 */     filterAndLog_1(FQCN, marker, Level.ERROR, format, arg, null);
/*     */   }
/*     */   
/*     */   public void error(Marker marker, String format, Object arg1, Object arg2) {
/* 555 */     filterAndLog_2(FQCN, marker, Level.ERROR, format, arg1, arg2, null);
/*     */   }
/*     */   
/*     */   public void error(Marker marker, String format, Object... argArray) {
/* 559 */     filterAndLog_0_Or3Plus(FQCN, marker, Level.ERROR, format, argArray, null);
/*     */   }
/*     */   
/*     */   public void error(Marker marker, String msg, Throwable t) {
/* 563 */     filterAndLog_0_Or3Plus(FQCN, marker, Level.ERROR, msg, null, t);
/*     */   }
/*     */   
/*     */   public boolean isInfoEnabled() {
/* 567 */     return isInfoEnabled(null);
/*     */   }
/*     */   
/*     */   public boolean isInfoEnabled(Marker marker) {
/* 571 */     FilterReply decision = callTurboFilters(marker, Level.INFO);
/* 572 */     if (decision == FilterReply.NEUTRAL)
/* 573 */       return (this.effectiveLevelInt <= 20000); 
/* 574 */     if (decision == FilterReply.DENY)
/* 575 */       return false; 
/* 576 */     if (decision == FilterReply.ACCEPT) {
/* 577 */       return true;
/*     */     }
/* 579 */     throw new IllegalStateException("Unknown FilterReply value: " + String.valueOf(decision));
/*     */   }
/*     */ 
/*     */   
/*     */   public void info(String msg) {
/* 584 */     filterAndLog_0_Or3Plus(FQCN, null, Level.INFO, msg, null, null);
/*     */   }
/*     */   
/*     */   public void info(String format, Object arg) {
/* 588 */     filterAndLog_1(FQCN, null, Level.INFO, format, arg, null);
/*     */   }
/*     */   
/*     */   public void info(String format, Object arg1, Object arg2) {
/* 592 */     filterAndLog_2(FQCN, null, Level.INFO, format, arg1, arg2, null);
/*     */   }
/*     */   
/*     */   public void info(String format, Object... argArray) {
/* 596 */     filterAndLog_0_Or3Plus(FQCN, null, Level.INFO, format, argArray, null);
/*     */   }
/*     */   
/*     */   public void info(String msg, Throwable t) {
/* 600 */     filterAndLog_0_Or3Plus(FQCN, null, Level.INFO, msg, null, t);
/*     */   }
/*     */   
/*     */   public void info(Marker marker, String msg) {
/* 604 */     filterAndLog_0_Or3Plus(FQCN, marker, Level.INFO, msg, null, null);
/*     */   }
/*     */   
/*     */   public void info(Marker marker, String format, Object arg) {
/* 608 */     filterAndLog_1(FQCN, marker, Level.INFO, format, arg, null);
/*     */   }
/*     */   
/*     */   public void info(Marker marker, String format, Object arg1, Object arg2) {
/* 612 */     filterAndLog_2(FQCN, marker, Level.INFO, format, arg1, arg2, null);
/*     */   }
/*     */   
/*     */   public void info(Marker marker, String format, Object... argArray) {
/* 616 */     filterAndLog_0_Or3Plus(FQCN, marker, Level.INFO, format, argArray, null);
/*     */   }
/*     */   
/*     */   public void info(Marker marker, String msg, Throwable t) {
/* 620 */     filterAndLog_0_Or3Plus(FQCN, marker, Level.INFO, msg, null, t);
/*     */   }
/*     */   
/*     */   public boolean isTraceEnabled() {
/* 624 */     return isTraceEnabled(null);
/*     */   }
/*     */   
/*     */   public boolean isTraceEnabled(Marker marker) {
/* 628 */     FilterReply decision = callTurboFilters(marker, Level.TRACE);
/* 629 */     if (decision == FilterReply.NEUTRAL)
/* 630 */       return (this.effectiveLevelInt <= 5000); 
/* 631 */     if (decision == FilterReply.DENY)
/* 632 */       return false; 
/* 633 */     if (decision == FilterReply.ACCEPT) {
/* 634 */       return true;
/*     */     }
/* 636 */     throw new IllegalStateException("Unknown FilterReply value: " + String.valueOf(decision));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isErrorEnabled() {
/* 641 */     return isErrorEnabled(null);
/*     */   }
/*     */   
/*     */   public boolean isErrorEnabled(Marker marker) {
/* 645 */     FilterReply decision = callTurboFilters(marker, Level.ERROR);
/* 646 */     if (decision == FilterReply.NEUTRAL)
/* 647 */       return (this.effectiveLevelInt <= 40000); 
/* 648 */     if (decision == FilterReply.DENY)
/* 649 */       return false; 
/* 650 */     if (decision == FilterReply.ACCEPT) {
/* 651 */       return true;
/*     */     }
/* 653 */     throw new IllegalStateException("Unknown FilterReply value: " + String.valueOf(decision));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWarnEnabled() {
/* 658 */     return isWarnEnabled(null);
/*     */   }
/*     */   
/*     */   public boolean isWarnEnabled(Marker marker) {
/* 662 */     FilterReply decision = callTurboFilters(marker, Level.WARN);
/* 663 */     if (decision == FilterReply.NEUTRAL)
/* 664 */       return (this.effectiveLevelInt <= 30000); 
/* 665 */     if (decision == FilterReply.DENY)
/* 666 */       return false; 
/* 667 */     if (decision == FilterReply.ACCEPT) {
/* 668 */       return true;
/*     */     }
/* 670 */     throw new IllegalStateException("Unknown FilterReply value: " + String.valueOf(decision));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabledFor(Marker marker, Level level) {
/* 676 */     FilterReply decision = callTurboFilters(marker, level);
/* 677 */     if (decision == FilterReply.NEUTRAL)
/* 678 */       return (this.effectiveLevelInt <= level.levelInt); 
/* 679 */     if (decision == FilterReply.DENY)
/* 680 */       return false; 
/* 681 */     if (decision == FilterReply.ACCEPT) {
/* 682 */       return true;
/*     */     }
/* 684 */     throw new IllegalStateException("Unknown FilterReply value: " + String.valueOf(decision));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabledFor(Level level) {
/* 689 */     return isEnabledFor(null, level);
/*     */   }
/*     */   
/*     */   public void warn(String msg) {
/* 693 */     filterAndLog_0_Or3Plus(FQCN, null, Level.WARN, msg, null, null);
/*     */   }
/*     */   
/*     */   public void warn(String msg, Throwable t) {
/* 697 */     filterAndLog_0_Or3Plus(FQCN, null, Level.WARN, msg, null, t);
/*     */   }
/*     */   
/*     */   public void warn(String format, Object arg) {
/* 701 */     filterAndLog_1(FQCN, null, Level.WARN, format, arg, null);
/*     */   }
/*     */   
/*     */   public void warn(String format, Object arg1, Object arg2) {
/* 705 */     filterAndLog_2(FQCN, null, Level.WARN, format, arg1, arg2, null);
/*     */   }
/*     */   
/*     */   public void warn(String format, Object... argArray) {
/* 709 */     filterAndLog_0_Or3Plus(FQCN, null, Level.WARN, format, argArray, null);
/*     */   }
/*     */   
/*     */   public void warn(Marker marker, String msg) {
/* 713 */     filterAndLog_0_Or3Plus(FQCN, marker, Level.WARN, msg, null, null);
/*     */   }
/*     */   
/*     */   public void warn(Marker marker, String format, Object arg) {
/* 717 */     filterAndLog_1(FQCN, marker, Level.WARN, format, arg, null);
/*     */   }
/*     */   
/*     */   public void warn(Marker marker, String format, Object... argArray) {
/* 721 */     filterAndLog_0_Or3Plus(FQCN, marker, Level.WARN, format, argArray, null);
/*     */   }
/*     */   
/*     */   public void warn(Marker marker, String format, Object arg1, Object arg2) {
/* 725 */     filterAndLog_2(FQCN, marker, Level.WARN, format, arg1, arg2, null);
/*     */   }
/*     */   
/*     */   public void warn(Marker marker, String msg, Throwable t) {
/* 729 */     filterAndLog_0_Or3Plus(FQCN, marker, Level.WARN, msg, null, t);
/*     */   }
/*     */   
/*     */   public boolean isAdditive() {
/* 733 */     return this.additive;
/*     */   }
/*     */   
/*     */   public void setAdditive(boolean additive) {
/* 737 */     this.additive = additive;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 741 */     return "Logger[" + this.name + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FilterReply callTurboFilters(Marker marker, Level level) {
/* 756 */     return this.loggerContext.getTurboFilterChainDecision_0_3OrMore(marker, this, level, null, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoggerContext getLoggerContext() {
/* 765 */     return this.loggerContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoggingEventBuilder makeLoggingEventBuilder(Level level) {
/* 775 */     return (LoggingEventBuilder)new DefaultLoggingEventBuilder(this, level);
/*     */   }
/*     */   
/*     */   public void log(Marker marker, String fqcn, int levelInt, String message, Object[] argArray, Throwable t) {
/* 779 */     Level level = Level.fromLocationAwareLoggerInteger(levelInt);
/* 780 */     filterAndLog_0_Or3Plus(fqcn, marker, level, message, argArray, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log(LoggingEvent slf4jEvent) {
/* 791 */     Level slf4jLevel = slf4jEvent.getLevel();
/* 792 */     Level logbackLevel = Level.convertAnSLF4JLevel(slf4jLevel);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 799 */     String callerBoundary = slf4jEvent.getCallerBoundary();
/* 800 */     if (callerBoundary == null) {
/* 801 */       callerBoundary = FQCN;
/*     */     }
/*     */ 
/*     */     
/* 805 */     LoggingEvent lle = new LoggingEvent(callerBoundary, this, logbackLevel, slf4jEvent.getMessage(), slf4jEvent.getThrowable(), slf4jEvent.getArgumentArray());
/* 806 */     List<Marker> markers = slf4jEvent.getMarkers();
/*     */     
/* 808 */     if (markers != null) {
/* 809 */       markers.forEach(m -> lle.addMarker(m));
/*     */     }
/*     */     
/* 812 */     lle.setKeyValuePairs(slf4jEvent.getKeyValuePairs());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 817 */     callAppenders((ILoggingEvent)lle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object readResolve() throws ObjectStreamException {
/* 829 */     return LoggerFactory.getLogger(getName());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\Logger.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */