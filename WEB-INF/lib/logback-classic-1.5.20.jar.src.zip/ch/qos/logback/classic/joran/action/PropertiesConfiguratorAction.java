/*    */ package ch.qos.logback.classic.joran.action;
/*    */ 
/*    */ import ch.qos.logback.classic.model.PropertiesConfiguratorModel;
/*    */ import ch.qos.logback.core.joran.action.ResourceAction;
/*    */ import ch.qos.logback.core.model.ResourceModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertiesConfiguratorAction
/*    */   extends ResourceAction
/*    */ {
/*    */   protected PropertiesConfiguratorModel makeNewResourceModel() {
/* 29 */     return new PropertiesConfiguratorModel();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\joran\action\PropertiesConfiguratorAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */