/*    */ package ch.qos.logback.classic.joran.action;
/*    */ 
/*    */ import ch.qos.logback.classic.model.ConfigurationModel;
/*    */ import ch.qos.logback.core.joran.action.BaseModelAction;
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigurationAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   static final String INTERNAL_DEBUG_ATTR = "debug";
/*    */   static final String SCAN_ATTR = "scan";
/*    */   static final String SCAN_PERIOD_ATTR = "scanPeriod";
/*    */   static final String PACKAGING_DATA_ATTR = "packagingData";
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 32 */     ConfigurationModel configurationModel = new ConfigurationModel();
/* 33 */     configurationModel.setDebugStr(attributes.getValue("debug"));
/* 34 */     configurationModel.setScanStr(attributes.getValue("scan"));
/* 35 */     configurationModel.setScanPeriodStr(attributes.getValue("scanPeriod"));
/* 36 */     configurationModel.setPackagingDataStr(attributes.getValue("packagingData"));
/* 37 */     return (Model)configurationModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\joran\action\ConfigurationAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */