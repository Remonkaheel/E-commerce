/*    */ package ch.qos.logback.classic.joran.action;
/*    */ 
/*    */ import ch.qos.logback.classic.model.LevelModel;
/*    */ import ch.qos.logback.core.joran.action.Action;
/*    */ import ch.qos.logback.core.joran.action.BaseModelAction;
/*    */ import ch.qos.logback.core.joran.action.PreconditionValidator;
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LevelAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext interpcont, String name, Attributes attributes) {
/* 39 */     PreconditionValidator pv = new PreconditionValidator((ContextAware)this, interpcont, name, attributes);
/* 40 */     pv.validateValueAttribute();
/* 41 */     addWarn("<level> element is deprecated. Near [" + name + "] on line " + Action.getLineNumber(interpcont));
/* 42 */     addWarn("Please use \"level\" attribute within <logger> or <root> elements instead.");
/* 43 */     return pv.isValid();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 49 */     LevelModel lm = new LevelModel();
/* 50 */     String value = attributes.getValue("value");
/* 51 */     lm.setValue(value);
/*    */     
/* 53 */     return (Model)lm;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\joran\action\LevelAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */