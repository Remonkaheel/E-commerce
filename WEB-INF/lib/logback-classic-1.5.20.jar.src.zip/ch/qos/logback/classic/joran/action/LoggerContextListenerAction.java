/*    */ package ch.qos.logback.classic.joran.action;
/*    */ 
/*    */ import ch.qos.logback.classic.model.LoggerContextListenerModel;
/*    */ import ch.qos.logback.classic.spi.LoggerContextListener;
/*    */ import ch.qos.logback.core.joran.action.BaseModelAction;
/*    */ import ch.qos.logback.core.joran.action.PreconditionValidator;
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggerContextListenerAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   boolean inError = false;
/*    */   LoggerContextListener lcl;
/*    */   
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext ic, String name, Attributes attributes) {
/* 31 */     PreconditionValidator pv = new PreconditionValidator((ContextAware)this, ic, name, attributes);
/* 32 */     pv.validateClassAttribute();
/* 33 */     return pv.isValid();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 39 */     LoggerContextListenerModel loggerContextListenerModel = new LoggerContextListenerModel();
/* 40 */     loggerContextListenerModel.setClassName(attributes.getValue("class"));
/* 41 */     return (Model)loggerContextListenerModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\joran\action\LoggerContextListenerAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */