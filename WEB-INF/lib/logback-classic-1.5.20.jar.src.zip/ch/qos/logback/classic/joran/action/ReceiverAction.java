/*    */ package ch.qos.logback.classic.joran.action;
/*    */ 
/*    */ import ch.qos.logback.classic.model.ReceiverModel;
/*    */ import ch.qos.logback.core.joran.action.BaseModelAction;
/*    */ import ch.qos.logback.core.joran.action.PreconditionValidator;
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReceiverAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 37 */     ReceiverModel rm = new ReceiverModel();
/* 38 */     rm.setClassName(attributes.getValue("class"));
/* 39 */     return (Model)rm;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext seic, String name, Attributes attributes) {
/* 44 */     PreconditionValidator validator = new PreconditionValidator((ContextAware)this, seic, name, attributes);
/* 45 */     validator.validateClassAttribute();
/* 46 */     return validator.isValid();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\joran\action\ReceiverAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */