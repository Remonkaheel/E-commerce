/*     */ package ch.qos.logback.classic.joran;
/*     */ 
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.core.joran.spi.ConfigurationWatchList;
/*     */ import ch.qos.logback.core.joran.spi.JoranException;
/*     */ import ch.qos.logback.core.joran.util.ConfigurationWatchListUtil;
/*     */ import ch.qos.logback.core.model.Model;
/*     */ import ch.qos.logback.core.model.ModelUtil;
/*     */ import ch.qos.logback.core.spi.ConfigurationEvent;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.status.StatusUtil;
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReconfigureOnChangeTask
/*     */   extends ContextAwareBase
/*     */   implements Runnable
/*     */ {
/*     */   public static final String DETECTED_CHANGE_IN_CONFIGURATION_FILES = "Detected change in configuration files.";
/*     */   public static final String RE_REGISTERING_PREVIOUS_SAFE_CONFIGURATION = "Re-registering previous fallback configuration once more as a fallback configuration point";
/*     */   public static final String FALLING_BACK_TO_SAFE_CONFIGURATION = "Given previous errors, falling back to previously registered safe configuration.";
/*  41 */   long birthdate = System.currentTimeMillis();
/*  42 */   List<ReconfigureOnChangeTaskListener> listeners = null;
/*     */   
/*     */   ScheduledFuture<?> scheduledFuture;
/*     */ 
/*     */   
/*     */   public void run() {
/*  48 */     this.context.fireConfigurationEvent(ConfigurationEvent.newConfigurationChangeDetectorRunningEvent(this));
/*     */     
/*  50 */     ConfigurationWatchList configurationWatchList = ConfigurationWatchListUtil.getConfigurationWatchList(this.context);
/*  51 */     if (configurationWatchList == null) {
/*  52 */       addWarn("Empty ConfigurationWatchList in context");
/*     */       
/*     */       return;
/*     */     } 
/*  56 */     if (configurationWatchList.emptyWatchLists()) {
/*  57 */       addInfo("Both watch lists are empty. Disabling ");
/*     */       
/*     */       return;
/*     */     } 
/*  61 */     File changedFile = configurationWatchList.changeDetectedInFile();
/*  62 */     URL changedURL = configurationWatchList.changeDetectedInURL();
/*     */     
/*  64 */     if (changedFile == null && changedURL == null) {
/*     */       return;
/*     */     }
/*     */     
/*  68 */     this.context.fireConfigurationEvent(ConfigurationEvent.newConfigurationChangeDetectedEvent(this));
/*  69 */     addInfo("Detected change in configuration files.");
/*     */     
/*  71 */     if (changedFile != null) {
/*  72 */       changeInFile(changedFile, configurationWatchList);
/*     */     }
/*     */     
/*  75 */     if (changedURL != null) {
/*  76 */       changeInURL(changedURL);
/*     */     }
/*     */   }
/*     */   
/*     */   private void changeInURL(URL url) {
/*  81 */     String path = url.getPath();
/*  82 */     if (path.endsWith(".properties"))
/*  83 */       runPropertiesConfigurator(url); 
/*     */   }
/*     */   
/*     */   private void changeInFile(File changedFile, ConfigurationWatchList configurationWatchList) {
/*  87 */     if (changedFile.getName().endsWith(".properties")) {
/*  88 */       runPropertiesConfigurator(changedFile);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  93 */     addInfo("Will reset and reconfigure context named [" + this.context.getName() + "]");
/*  94 */     cancelFutureInvocationsOfThisTaskInstance();
/*  95 */     URL mainConfigurationURL = configurationWatchList.getMainURL();
/*     */     
/*  97 */     LoggerContext lc = (LoggerContext)this.context;
/*  98 */     if (mainConfigurationURL.toString().endsWith("xml")) {
/*  99 */       performXMLConfiguration(lc, mainConfigurationURL);
/* 100 */     } else if (mainConfigurationURL.toString().endsWith("groovy")) {
/* 101 */       addError("Groovy configuration disabled due to Java 9 compilation issues.");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void runPropertiesConfigurator(Object changedObject) {
/* 106 */     addInfo("Will run PropertyConfigurator on " + String.valueOf(changedObject));
/* 107 */     PropertiesConfigurator propertiesConfigurator = new PropertiesConfigurator();
/* 108 */     propertiesConfigurator.setContext(this.context);
/*     */     try {
/* 110 */       if (changedObject instanceof File) {
/* 111 */         File changedFile = (File)changedObject;
/* 112 */         propertiesConfigurator.doConfigure(changedFile);
/* 113 */       } else if (changedObject instanceof URL) {
/* 114 */         URL changedURL = (URL)changedObject;
/* 115 */         propertiesConfigurator.doConfigure(changedURL);
/*     */       } 
/* 117 */       this.context.fireConfigurationEvent(ConfigurationEvent.newPartialConfigurationEndedSuccessfullyEvent(this));
/* 118 */     } catch (JoranException e) {
/* 119 */       addError("Failed to reload " + String.valueOf(changedObject));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void cancelFutureInvocationsOfThisTaskInstance() {
/* 124 */     boolean result = this.scheduledFuture.cancel(false);
/* 125 */     if (!result) {
/* 126 */       addWarn("could not cancel " + toString());
/*     */     }
/*     */   }
/*     */   
/*     */   private void performXMLConfiguration(LoggerContext lc, URL mainConfigurationURL) {
/* 131 */     JoranConfigurator jc = new JoranConfigurator();
/* 132 */     jc.setContext(this.context);
/* 133 */     StatusUtil statusUtil = new StatusUtil(this.context);
/* 134 */     Model failsafeTop = jc.recallSafeConfiguration();
/* 135 */     URL mainURL = ConfigurationWatchListUtil.getMainWatchURL(this.context);
/* 136 */     addInfo("Resetting loggerContext [" + lc.getName() + "]");
/* 137 */     lc.reset();
/* 138 */     long threshold = System.currentTimeMillis();
/*     */     try {
/* 140 */       jc.doConfigure(mainConfigurationURL);
/*     */       
/* 142 */       if (statusUtil.hasXMLParsingErrors(threshold)) {
/* 143 */         fallbackConfiguration(lc, failsafeTop, mainURL);
/*     */       }
/* 145 */     } catch (JoranException e) {
/* 146 */       addWarn("Exception occurred during reconfiguration", (Throwable)e);
/* 147 */       fallbackConfiguration(lc, failsafeTop, mainURL);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void fallbackConfiguration(LoggerContext lc, Model failsafeTop, URL mainURL) {
/* 156 */     JoranConfigurator joranConfigurator = new JoranConfigurator();
/* 157 */     joranConfigurator.setContext(this.context);
/* 158 */     ConfigurationWatchList oldCWL = ConfigurationWatchListUtil.getConfigurationWatchList(this.context);
/* 159 */     ConfigurationWatchList newCWL = oldCWL.buildClone();
/*     */     
/* 161 */     if (failsafeTop == null) {
/* 162 */       addWarn("No previous configuration to fall back on.");
/*     */       return;
/*     */     } 
/* 165 */     addWarn("Given previous errors, falling back to previously registered safe configuration.");
/* 166 */     addInfo("Safe model " + String.valueOf(failsafeTop));
/*     */     try {
/* 168 */       lc.reset();
/* 169 */       ConfigurationWatchListUtil.registerConfigurationWatchList(this.context, newCWL);
/* 170 */       ModelUtil.resetForReuse(failsafeTop);
/* 171 */       joranConfigurator.processModel(failsafeTop);
/* 172 */       addInfo("Re-registering previous fallback configuration once more as a fallback configuration point");
/* 173 */       joranConfigurator.registerSafeConfiguration(failsafeTop);
/* 174 */       this.context.fireConfigurationEvent(ConfigurationEvent.newConfigurationEndedSuccessfullyEvent(this));
/* 175 */     } catch (Exception e) {
/* 176 */       addError("Unexpected exception thrown by a configuration considered safe.", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 183 */     return "ReconfigureOnChangeTask(born:" + this.birthdate + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setScheduredFuture(ScheduledFuture<?> aScheduledFuture) {
/* 193 */     setScheduledFuture(aScheduledFuture);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScheduledFuture(ScheduledFuture<?> aScheduledFuture) {
/* 202 */     this.scheduledFuture = aScheduledFuture;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\joran\ReconfigureOnChangeTask.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */