package ch.qos.logback.classic.joran;

class ReconfigureOnChangeTaskListener {
  void enteredRunMethod() {}
  
  void changeDetected() {}
  
  void doneReconfiguring() {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\joran\ReconfigureOnChangeTaskListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */