/*     */ package ch.qos.logback.classic.joran;
/*     */ 
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.classic.joran.serializedModel.HardenedModelInputStream;
/*     */ import ch.qos.logback.classic.model.processor.LogbackClassicDefaultNestedComponentRules;
/*     */ import ch.qos.logback.classic.spi.Configurator;
/*     */ import ch.qos.logback.classic.spi.ConfiguratorRank;
/*     */ import ch.qos.logback.core.LogbackException;
/*     */ import ch.qos.logback.core.model.Model;
/*     */ import ch.qos.logback.core.model.ModelUtil;
/*     */ import ch.qos.logback.core.model.processor.DefaultProcessor;
/*     */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*     */ import ch.qos.logback.core.spi.ContextAwareBase;
/*     */ import ch.qos.logback.core.status.InfoStatus;
/*     */ import ch.qos.logback.core.status.Status;
/*     */ import ch.qos.logback.core.status.StatusManager;
/*     */ import ch.qos.logback.core.util.Loader;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ConfiguratorRank(10)
/*     */ public class SerializedModelConfigurator
/*     */   extends ContextAwareBase
/*     */   implements Configurator
/*     */ {
/*     */   public static final String AUTOCONFIG_MODEL_FILE = "logback.scmo";
/*     */   public static final String TEST_AUTOCONFIG_MODEL_FILE = "logback-test.scmo";
/*     */   protected ModelInterpretationContext modelInterpretationContext;
/*     */   
/*     */   public Configurator.ExecutionStatus configure(LoggerContext loggerContext) {
/*  60 */     URL url = performMultiStepModelFileSearch(true);
/*  61 */     if (url != null) {
/*  62 */       addWarn("Replaced by logback-tyler, SerializedModelConfigurator has been deprecated and will be removed on 2025-07-01.");
/*  63 */       configureByResource(url);
/*  64 */       return Configurator.ExecutionStatus.DO_NOT_INVOKE_NEXT_IF_ANY;
/*     */     } 
/*  66 */     return Configurator.ExecutionStatus.INVOKE_NEXT_IF_ANY;
/*     */   }
/*     */ 
/*     */   
/*     */   private void configureByResource(URL url) {
/*  71 */     String urlString = url.toString();
/*  72 */     if (urlString.endsWith(".scmo")) {
/*  73 */       Model model = retrieveModel(url);
/*  74 */       if (model == null) {
/*  75 */         addWarn("Empty model. Abandoning.");
/*     */         return;
/*     */       } 
/*  78 */       ModelUtil.resetForReuse(model);
/*  79 */       buildModelInterpretationContext(model);
/*     */       
/*  81 */       DefaultProcessor defaultProcessor = new DefaultProcessor(this.context, this.modelInterpretationContext);
/*  82 */       ModelClassToModelHandlerLinker mc2mhl = new ModelClassToModelHandlerLinker(this.context);
/*  83 */       mc2mhl.link(defaultProcessor);
/*     */ 
/*     */       
/*  86 */       ReentrantLock configurationLock = this.context.getConfigurationLock();
/*     */       try {
/*  88 */         configurationLock.lock();
/*  89 */         defaultProcessor.process(model);
/*     */       } finally {
/*  91 */         configurationLock.unlock();
/*     */       } 
/*     */     } else {
/*  94 */       throw new LogbackException("Unexpected filename extension of file [" + url
/*  95 */           .toString() + "]. Should be .scmo");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void buildModelInterpretationContext(Model topModel) {
/* 100 */     this.modelInterpretationContext = new ModelInterpretationContext(this.context, this);
/* 101 */     this.modelInterpretationContext.setTopModel(topModel);
/* 102 */     LogbackClassicDefaultNestedComponentRules.addDefaultNestedComponentRegistryRules(this.modelInterpretationContext
/* 103 */         .getDefaultNestedComponentRegistry());
/* 104 */     this.modelInterpretationContext.createAppenderBags();
/*     */   }
/*     */   
/*     */   private Model retrieveModel(URL url) {
/* 108 */     long start = System.currentTimeMillis(); 
/* 109 */     try { InputStream is = url.openStream(); 
/* 110 */       try { HardenedModelInputStream hmis = new HardenedModelInputStream(is);
/*     */         
/* 112 */         Model model = (Model)hmis.readObject();
/* 113 */         long diff = System.currentTimeMillis() - start;
/* 114 */         addInfo("Model at [" + String.valueOf(url) + "] read in " + diff + " milliseconds");
/* 115 */         Model model1 = model;
/* 116 */         if (is != null) is.close();  return model1; } catch (Throwable throwable) { if (is != null) try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException e)
/* 117 */     { addError("Failed to open " + String.valueOf(url), e); }
/* 118 */     catch (ClassNotFoundException e)
/* 119 */     { addError("Failed read model object in " + String.valueOf(url), e); }
/*     */     
/* 121 */     return null;
/*     */   }
/*     */   
/*     */   private URL performMultiStepModelFileSearch(boolean updateState) {
/* 125 */     ClassLoader myClassLoader = Loader.getClassLoaderOfObject(this);
/* 126 */     URL url = findModelConfigFileURLFromSystemProperties(myClassLoader);
/* 127 */     if (url != null) {
/* 128 */       return url;
/*     */     }
/*     */     
/* 131 */     url = getResource("logback-test.scmo", myClassLoader, updateState);
/* 132 */     if (url != null) {
/* 133 */       return url;
/*     */     }
/*     */     
/* 136 */     url = getResource("logback.scmo", myClassLoader, updateState);
/* 137 */     return url;
/*     */   }
/*     */   
/*     */   URL findModelConfigFileURLFromSystemProperties(ClassLoader classLoader) {
/* 141 */     String logbackModelFile = OptionHelper.getSystemProperty("logback.scmoFile");
/*     */     
/* 143 */     if (logbackModelFile != null) {
/* 144 */       URL result = null;
/*     */       try {
/* 146 */         result = new URL(logbackModelFile);
/* 147 */         return result;
/* 148 */       } catch (MalformedURLException e) {
/*     */ 
/*     */         
/* 151 */         result = Loader.getResource(logbackModelFile, classLoader);
/* 152 */         if (result != null) {
/* 153 */           return result;
/*     */         }
/* 155 */         File f = new File(logbackModelFile);
/* 156 */         if (f.exists() && f.isFile()) {
/*     */           try {
/* 158 */             result = f.toURI().toURL();
/* 159 */             return result;
/* 160 */           } catch (MalformedURLException malformedURLException) {}
/*     */         }
/*     */       } finally {
/*     */         
/* 164 */         statusOnResourceSearch(logbackModelFile, result);
/*     */       } 
/*     */     } 
/* 167 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private URL getResource(String filename, ClassLoader classLoader, boolean updateStatus) {
/* 172 */     URL url = Loader.getResource(filename, classLoader);
/* 173 */     if (updateStatus) {
/* 174 */       statusOnResourceSearch(filename, url);
/*     */     }
/* 176 */     return url;
/*     */   }
/*     */   
/*     */   private void statusOnResourceSearch(String resourceName, URL url) {
/* 180 */     StatusManager sm = this.context.getStatusManager();
/* 181 */     if (url == null) {
/* 182 */       sm.add((Status)new InfoStatus("Could NOT find resource [" + resourceName + "]", this.context));
/*     */     } else {
/* 184 */       sm.add((Status)new InfoStatus("Found resource [" + resourceName + "] at [" + url.toString() + "]", this.context));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\joran\SerializedModelConfigurator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */