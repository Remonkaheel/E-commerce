/*    */ package ch.qos.logback.classic.joran.action;
/*    */ 
/*    */ import ch.qos.logback.classic.Logger;
/*    */ import ch.qos.logback.classic.LoggerContext;
/*    */ import ch.qos.logback.classic.net.SocketAppender;
/*    */ import ch.qos.logback.core.Appender;
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.joran.action.Action;
/*    */ import ch.qos.logback.core.joran.spi.ActionException;
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConsolePluginAction
/*    */   extends Action
/*    */ {
/*    */   private static final String PORT_ATTR = "port";
/* 28 */   private static final Integer DEFAULT_PORT = Integer.valueOf(4321);
/*    */ 
/*    */   
/*    */   public void begin(SaxEventInterpretationContext ec, String name, Attributes attributes) throws ActionException {
/* 32 */     String portStr = attributes.getValue("port");
/* 33 */     Integer port = null;
/*    */     
/* 35 */     if (portStr == null) {
/* 36 */       port = DEFAULT_PORT;
/*    */     } else {
/*    */       try {
/* 39 */         port = Integer.valueOf(portStr);
/* 40 */       } catch (NumberFormatException ex) {
/* 41 */         addError("Port " + portStr + " in ConsolePlugin config is not a correct number");
/* 42 */         addError("Abandoning configuration of ConsolePlugin.");
/*    */         
/*    */         return;
/*    */       } 
/*    */     } 
/* 47 */     LoggerContext lc = (LoggerContext)ec.getContext();
/* 48 */     SocketAppender appender = new SocketAppender();
/* 49 */     appender.setContext((Context)lc);
/* 50 */     appender.setIncludeCallerData(true);
/* 51 */     appender.setRemoteHost("localhost");
/* 52 */     appender.setPort(port.intValue());
/* 53 */     appender.start();
/* 54 */     Logger root = lc.getLogger("ROOT");
/* 55 */     root.addAppender((Appender)appender);
/*    */     
/* 57 */     addInfo("Sending LoggingEvents to the plugin using port " + port);
/*    */   }
/*    */   
/*    */   public void end(SaxEventInterpretationContext ec, String name) throws ActionException {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\joran\action\ConsolePluginAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */