/*    */ package ch.qos.logback.classic.joran.serializedModel;
/*    */ import ch.qos.logback.classic.model.ConfigurationModel;
/*    */ import ch.qos.logback.classic.model.ContextNameModel;
/*    */ import ch.qos.logback.classic.model.LoggerContextListenerModel;
/*    */ import ch.qos.logback.classic.model.LoggerModel;
/*    */ import ch.qos.logback.classic.model.RootLoggerModel;
/*    */ import ch.qos.logback.core.model.ComponentModel;
/*    */ import ch.qos.logback.core.model.DefineModel;
/*    */ import ch.qos.logback.core.model.ImplicitModel;
/*    */ import ch.qos.logback.core.model.ImportModel;
/*    */ import ch.qos.logback.core.model.IncludeModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.NamedComponentModel;
/*    */ import ch.qos.logback.core.model.ParamModel;
/*    */ import ch.qos.logback.core.model.PropertyModel;
/*    */ import ch.qos.logback.core.model.SequenceNumberGeneratorModel;
/*    */ import ch.qos.logback.core.model.SerializeModelModel;
/*    */ import ch.qos.logback.core.model.ShutdownHookModel;
/*    */ import ch.qos.logback.core.model.conditional.ElseModel;
/*    */ import ch.qos.logback.core.model.conditional.IfModel;
/*    */ import ch.qos.logback.core.net.HardenedObjectInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class HardenedModelInputStream extends HardenedObjectInputStream {
/*    */   public static List<String> getWhilelist() {
/* 29 */     List<String> whitelist = new ArrayList<>();
/* 30 */     whitelist.add(Model.class.getName());
/* 31 */     whitelist.add(Model.class.getName());
/* 32 */     whitelist.add(IncludeModel.class.getName());
/* 33 */     whitelist.add(InsertFromJNDIModel.class.getName());
/* 34 */     whitelist.add(RootLoggerModel.class.getName());
/* 35 */     whitelist.add(ImportModel.class.getName());
/* 36 */     whitelist.add(AppenderRefModel.class.getName());
/* 37 */     whitelist.add(ComponentModel.class.getName());
/* 38 */     whitelist.add(StatusListenerModel.class.getName());
/* 39 */     whitelist.add(ShutdownHookModel.class.getName());
/* 40 */     whitelist.add(NamedComponentModel.class.getName());
/* 41 */     whitelist.add(AppenderModel.class.getName());
/* 42 */     whitelist.add(EventEvaluatorModel.class.getName());
/* 43 */     whitelist.add(DefineModel.class.getName());
/* 44 */     whitelist.add(SequenceNumberGeneratorModel.class.getName());
/* 45 */     whitelist.add(ImplicitModel.class.getName());
/* 46 */     whitelist.add(ReceiverModel.class.getName());
/* 47 */     whitelist.add(LoggerContextListenerModel.class.getName());
/* 48 */     whitelist.add(ThenModel.class.getName());
/* 49 */     whitelist.add(IfModel.class.getName());
/* 50 */     whitelist.add(NamedModel.class.getName());
/* 51 */     whitelist.add(ContextNameModel.class.getName());
/* 52 */     whitelist.add(ParamModel.class.getName());
/* 53 */     whitelist.add(TimestampModel.class.getName());
/* 54 */     whitelist.add(PropertyModel.class.getName());
/* 55 */     whitelist.add(ElseModel.class.getName());
/* 56 */     whitelist.add(ConfigurationModel.class.getName());
/* 57 */     whitelist.add(SiftModel.class.getName());
/* 58 */     whitelist.add(LoggerModel.class.getName());
/* 59 */     whitelist.add(SerializeModelModel.class.getName());
/*    */ 
/*    */     
/* 62 */     return whitelist;
/*    */   }
/*    */   public HardenedModelInputStream(InputStream is) throws IOException {
/* 65 */     super(is, getWhilelist());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\joran\serializedModel\HardenedModelInputStream.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */