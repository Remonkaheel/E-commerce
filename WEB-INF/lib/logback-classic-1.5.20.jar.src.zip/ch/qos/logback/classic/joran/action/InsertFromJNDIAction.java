/*    */ package ch.qos.logback.classic.joran.action;
/*    */ 
/*    */ import ch.qos.logback.core.joran.action.BaseModelAction;
/*    */ import ch.qos.logback.core.joran.action.PreconditionValidator;
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.InsertFromJNDIModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InsertFromJNDIAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   public static final String ENV_ENTRY_NAME_ATTR = "env-entry-name";
/*    */   public static final String AS_ATTR = "as";
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 38 */     InsertFromJNDIModel ifjm = new InsertFromJNDIModel();
/* 39 */     ifjm.setEnvEntryName(attributes.getValue("env-entry-name"));
/* 40 */     ifjm.setAs(attributes.getValue("as"));
/* 41 */     ifjm.setScopeStr(attributes.getValue("scope"));
/*    */     
/* 43 */     return (Model)ifjm;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext seic, String name, Attributes attributes) {
/* 48 */     PreconditionValidator validator = new PreconditionValidator((ContextAware)this, seic, name, attributes);
/* 49 */     validator.validateGivenAttribute("env-entry-name");
/* 50 */     validator.validateGivenAttribute("as");
/*    */     
/* 52 */     return validator.isValid();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\joran\action\InsertFromJNDIAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */