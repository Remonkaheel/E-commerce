/*    */ package ch.qos.logback.classic.joran.sanity;
/*    */ 
/*    */ import ch.qos.logback.classic.model.LoggerModel;
/*    */ import ch.qos.logback.classic.model.RootLoggerModel;
/*    */ import ch.qos.logback.core.joran.sanity.Pair;
/*    */ import ch.qos.logback.core.joran.sanity.SanityChecker;
/*    */ import ch.qos.logback.core.model.AppenderModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.conditional.IfModel;
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IfNestedWithinSecondPhaseElementSC
/*    */   extends ContextAwareBase
/*    */   implements SanityChecker
/*    */ {
/*    */   public static final String NESTED_IF_WARNING_URL = "https://logback.qos.ch/codes.html#nested_if_element";
/*    */   
/*    */   public void check(Model model) {
/* 23 */     if (model == null) {
/*    */       return;
/*    */     }
/* 26 */     List<Model> secondPhaseModels = new ArrayList<>();
/* 27 */     deepFindAllModelsOfType(AppenderModel.class, secondPhaseModels, model);
/* 28 */     deepFindAllModelsOfType(LoggerModel.class, secondPhaseModels, model);
/* 29 */     deepFindAllModelsOfType(RootLoggerModel.class, secondPhaseModels, model);
/*    */     
/* 31 */     List<Pair<Model, Model>> nestedPairs = deepFindNestedSubModelsOfType(IfModel.class, secondPhaseModels);
/*    */     
/* 33 */     if (nestedPairs.isEmpty()) {
/*    */       return;
/*    */     }
/* 36 */     addWarn("<if> elements cannot be nested within an <appender>, <logger> or <root> element");
/* 37 */     addWarn("See also https://logback.qos.ch/codes.html#nested_if_element");
/* 38 */     for (Pair<Model, Model> pair : nestedPairs) {
/* 39 */       Model p = (Model)pair.first;
/* 40 */       int pLine = p.getLineNumber();
/* 41 */       Model s = (Model)pair.second;
/* 42 */       int sLine = s.getLineNumber();
/* 43 */       addWarn("Element <" + p.getTag() + "> at line " + pLine + " contains a nested <" + s.getTag() + "> element at line " + sLine);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 49 */     return "IfNestedWithinSecondPhaseElementSC";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\joran\sanity\IfNestedWithinSecondPhaseElementSC.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */