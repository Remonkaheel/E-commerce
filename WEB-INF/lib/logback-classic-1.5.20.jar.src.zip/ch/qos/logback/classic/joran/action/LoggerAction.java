/*    */ package ch.qos.logback.classic.joran.action;
/*    */ 
/*    */ import ch.qos.logback.classic.model.LoggerModel;
/*    */ import ch.qos.logback.core.joran.action.BaseModelAction;
/*    */ import ch.qos.logback.core.joran.action.PreconditionValidator;
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggerAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext ic, String name, Attributes attributes) {
/* 34 */     PreconditionValidator validator = new PreconditionValidator((ContextAware)this, ic, name, attributes);
/* 35 */     validator.validateNameAttribute();
/* 36 */     return validator.isValid();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 43 */     LoggerModel loggerModel = new LoggerModel();
/*    */     
/* 45 */     String nameStr = attributes.getValue("name");
/* 46 */     loggerModel.setName(nameStr);
/*    */     
/* 48 */     String levelStr = attributes.getValue("level");
/* 49 */     loggerModel.setLevel(levelStr);
/*    */     
/* 51 */     String additivityStr = attributes.getValue("additivity");
/* 52 */     loggerModel.setAdditivity(additivityStr);
/*    */     
/* 54 */     return (Model)loggerModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\joran\action\LoggerAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */