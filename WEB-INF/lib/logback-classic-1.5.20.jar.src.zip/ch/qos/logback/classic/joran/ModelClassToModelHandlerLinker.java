/*    */ package ch.qos.logback.classic.joran;
/*    */ 
/*    */ import ch.qos.logback.classic.model.ConfigurationModel;
/*    */ import ch.qos.logback.classic.model.ContextNameModel;
/*    */ import ch.qos.logback.classic.model.LevelModel;
/*    */ import ch.qos.logback.classic.model.LoggerContextListenerModel;
/*    */ import ch.qos.logback.classic.model.LoggerModel;
/*    */ import ch.qos.logback.classic.model.PropertiesConfiguratorModel;
/*    */ import ch.qos.logback.classic.model.RootLoggerModel;
/*    */ import ch.qos.logback.classic.model.processor.ConfigurationModelHandler;
/*    */ import ch.qos.logback.classic.model.processor.ContextNameModelHandler;
/*    */ import ch.qos.logback.classic.model.processor.LevelModelHandler;
/*    */ import ch.qos.logback.classic.model.processor.LoggerContextListenerModelHandler;
/*    */ import ch.qos.logback.classic.model.processor.LoggerModelHandler;
/*    */ import ch.qos.logback.classic.model.processor.PropertiesConfiguratorModelHandler;
/*    */ import ch.qos.logback.classic.model.processor.RootLoggerModelHandler;
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.joran.ModelClassToModelHandlerLinkerBase;
/*    */ import ch.qos.logback.core.model.AppenderModel;
/*    */ import ch.qos.logback.core.model.AppenderRefModel;
/*    */ import ch.qos.logback.core.model.InsertFromJNDIModel;
/*    */ import ch.qos.logback.core.model.ModelHandlerFactoryMethod;
/*    */ import ch.qos.logback.core.model.processor.AppenderModelHandler;
/*    */ import ch.qos.logback.core.model.processor.AppenderRefDependencyAnalyser;
/*    */ import ch.qos.logback.core.model.processor.AppenderRefModelHandler;
/*    */ import ch.qos.logback.core.model.processor.DefaultProcessor;
/*    */ import ch.qos.logback.core.model.processor.InsertFromJNDIModelHandler;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerBase;
/*    */ import ch.qos.logback.core.model.processor.RefContainerDependencyAnalyser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModelClassToModelHandlerLinker
/*    */   extends ModelClassToModelHandlerLinkerBase
/*    */ {
/*    */   ModelHandlerFactoryMethod configurationModelHandlerFactoryMethod;
/*    */   
/*    */   public ModelClassToModelHandlerLinker(Context context) {
/* 44 */     super(context);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void link(DefaultProcessor defaultProcessor) {
/* 51 */     super.link(defaultProcessor);
/* 52 */     defaultProcessor.addHandler(ConfigurationModel.class, getConfigurationModelHandlerFactoryMethod());
/* 53 */     defaultProcessor.addHandler(ContextNameModel.class, ContextNameModelHandler::makeInstance);
/* 54 */     defaultProcessor.addHandler(LoggerContextListenerModel.class, LoggerContextListenerModelHandler::makeInstance);
/*    */     
/* 56 */     defaultProcessor.addHandler(PropertiesConfiguratorModel.class, PropertiesConfiguratorModelHandler::makeInstance);
/* 57 */     defaultProcessor.addHandler(InsertFromJNDIModel.class, InsertFromJNDIModelHandler::makeInstance);
/*    */     
/* 59 */     defaultProcessor.addHandler(AppenderModel.class, AppenderModelHandler::makeInstance);
/* 60 */     defaultProcessor.addHandler(AppenderRefModel.class, AppenderRefModelHandler::makeInstance);
/* 61 */     defaultProcessor.addHandler(RootLoggerModel.class, RootLoggerModelHandler::makeInstance);
/* 62 */     defaultProcessor.addHandler(LoggerModel.class, LoggerModelHandler::makeInstance);
/* 63 */     defaultProcessor.addHandler(LevelModel.class, LevelModelHandler::makeInstance);
/*    */     
/* 65 */     defaultProcessor.addAnalyser(LoggerModel.class, () -> new RefContainerDependencyAnalyser(this.context, LoggerModel.class));
/*    */ 
/*    */     
/* 68 */     defaultProcessor.addAnalyser(RootLoggerModel.class, () -> new RefContainerDependencyAnalyser(this.context, RootLoggerModel.class));
/*    */ 
/*    */     
/* 71 */     defaultProcessor.addAnalyser(AppenderModel.class, () -> new RefContainerDependencyAnalyser(this.context, AppenderModel.class));
/*    */ 
/*    */     
/* 74 */     defaultProcessor.addAnalyser(AppenderRefModel.class, () -> new AppenderRefDependencyAnalyser(this.context));
/*    */     
/* 76 */     sealModelFilters(defaultProcessor);
/*    */   }
/*    */ 
/*    */   
/*    */   public ModelHandlerFactoryMethod getConfigurationModelHandlerFactoryMethod() {
/* 81 */     if (this.configurationModelHandlerFactoryMethod == null)
/*    */     {
/* 83 */       return ConfigurationModelHandler::makeInstance;
/*    */     }
/*    */     
/* 86 */     return this.configurationModelHandlerFactoryMethod;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setConfigurationModelHandlerFactoryMethod(ModelHandlerFactoryMethod cmhfm) {
/* 97 */     this.configurationModelHandlerFactoryMethod = cmhfm;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\joran\ModelClassToModelHandlerLinker.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */