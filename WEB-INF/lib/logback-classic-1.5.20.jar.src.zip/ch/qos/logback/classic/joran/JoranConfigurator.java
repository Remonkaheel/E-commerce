/*     */ package ch.qos.logback.classic.joran;
/*     */ 
/*     */ import ch.qos.logback.classic.joran.action.ConfigurationAction;
/*     */ import ch.qos.logback.classic.joran.action.ConsolePluginAction;
/*     */ import ch.qos.logback.classic.joran.action.ContextNameAction;
/*     */ import ch.qos.logback.classic.joran.action.InsertFromJNDIAction;
/*     */ import ch.qos.logback.classic.joran.action.LevelAction;
/*     */ import ch.qos.logback.classic.joran.action.LoggerAction;
/*     */ import ch.qos.logback.classic.joran.action.LoggerContextListenerAction;
/*     */ import ch.qos.logback.classic.joran.action.PropertiesConfiguratorAction;
/*     */ import ch.qos.logback.classic.joran.action.ReceiverAction;
/*     */ import ch.qos.logback.classic.joran.action.RootLoggerAction;
/*     */ import ch.qos.logback.classic.joran.sanity.IfNestedWithinSecondPhaseElementSC;
/*     */ import ch.qos.logback.classic.model.processor.ConfigurationModelHandlerFull;
/*     */ import ch.qos.logback.classic.model.processor.LogbackClassicDefaultNestedComponentRules;
/*     */ import ch.qos.logback.classic.spi.ILoggingEvent;
/*     */ import ch.qos.logback.core.joran.GenericXMLConfigurator;
/*     */ import ch.qos.logback.core.joran.JoranConfiguratorBase;
/*     */ import ch.qos.logback.core.joran.action.Action;
/*     */ import ch.qos.logback.core.joran.action.AppenderRefAction;
/*     */ import ch.qos.logback.core.joran.action.IncludeAction;
/*     */ import ch.qos.logback.core.joran.sanity.SanityChecker;
/*     */ import ch.qos.logback.core.joran.spi.DefaultNestedComponentRegistry;
/*     */ import ch.qos.logback.core.joran.spi.ElementSelector;
/*     */ import ch.qos.logback.core.joran.spi.RuleStore;
/*     */ import ch.qos.logback.core.model.Model;
/*     */ import ch.qos.logback.core.model.processor.DefaultProcessor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JoranConfigurator
/*     */   extends JoranConfiguratorBase<ILoggingEvent>
/*     */ {
/*     */   public void addElementSelectorAndActionAssociations(RuleStore rs) {
/*  42 */     super.addElementSelectorAndActionAssociations(rs);
/*     */     
/*  44 */     rs.addRule(new ElementSelector("configuration"), () -> new ConfigurationAction());
/*     */     
/*  46 */     rs.addRule(new ElementSelector("configuration/contextName"), () -> new ContextNameAction());
/*  47 */     rs.addRule(new ElementSelector("configuration/contextListener"), () -> new LoggerContextListenerAction());
/*  48 */     rs.addRule(new ElementSelector("configuration/insertFromJNDI"), () -> new InsertFromJNDIAction());
/*     */     
/*  50 */     rs.addRule(new ElementSelector("configuration/logger"), () -> new LoggerAction());
/*  51 */     rs.addRule(new ElementSelector("configuration/logger/level"), () -> new LevelAction());
/*     */     
/*  53 */     rs.addRule(new ElementSelector("configuration/root"), () -> new RootLoggerAction());
/*  54 */     rs.addRule(new ElementSelector("configuration/root/level"), () -> new LevelAction());
/*  55 */     rs.addRule(new ElementSelector("configuration/logger/appender-ref"), () -> new AppenderRefAction());
/*  56 */     rs.addRule(new ElementSelector("configuration/root/appender-ref"), () -> new AppenderRefAction());
/*     */     
/*  58 */     rs.addRule(new ElementSelector("configuration/include"), () -> new IncludeAction());
/*  59 */     rs.addRule(new ElementSelector("configuration/propertiesConfigurator"), () -> new PropertiesConfiguratorAction());
/*     */     
/*  61 */     rs.addRule(new ElementSelector("configuration/consolePlugin"), () -> new ConsolePluginAction());
/*     */     
/*  63 */     rs.addRule(new ElementSelector("configuration/receiver"), () -> new ReceiverAction());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sanityCheck(Model topModel) {
/*  71 */     super.sanityCheck(topModel);
/*  72 */     performCheck((SanityChecker)new IfNestedWithinSecondPhaseElementSC(), topModel);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addDefaultNestedComponentRegistryRules(DefaultNestedComponentRegistry registry) {
/*  77 */     LogbackClassicDefaultNestedComponentRules.addDefaultNestedComponentRegistryRules(registry);
/*     */   }
/*     */   
/*     */   private JoranConfigurator makeAnotherInstance() {
/*  81 */     JoranConfigurator jc = new JoranConfigurator();
/*  82 */     jc.setContext(this.context);
/*  83 */     return jc;
/*     */   }
/*     */   
/*     */   public void buildModelInterpretationContext() {
/*  87 */     super.buildModelInterpretationContext();
/*  88 */     this.modelInterpretationContext.setConfiguratorSupplier(() -> makeAnotherInstance());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void addModelHandlerAssociations(DefaultProcessor defaultProcessor) {
/*  93 */     ModelClassToModelHandlerLinker m = new ModelClassToModelHandlerLinker(this.context);
/*  94 */     m.setConfigurationModelHandlerFactoryMethod(ConfigurationModelHandlerFull::makeInstance2);
/*  95 */     m.link(defaultProcessor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void sealModelFilters(DefaultProcessor defaultProcessor) {
/* 104 */     defaultProcessor.getPhaseOneFilter().denyAll();
/* 105 */     defaultProcessor.getPhaseTwoFilter().allowAll();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\joran\JoranConfigurator.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */