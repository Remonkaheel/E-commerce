/*    */ package ch.qos.logback.classic.joran.action;
/*    */ 
/*    */ import ch.qos.logback.classic.Logger;
/*    */ import ch.qos.logback.classic.model.RootLoggerModel;
/*    */ import ch.qos.logback.core.joran.JoranConstants;
/*    */ import ch.qos.logback.core.joran.action.BaseModelAction;
/*    */ import ch.qos.logback.core.joran.spi.SaxEventInterpretationContext;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RootLoggerAction
/*    */   extends BaseModelAction
/*    */ {
/*    */   Logger root;
/*    */   boolean inError = false;
/*    */   
/*    */   protected boolean validPreconditions(SaxEventInterpretationContext interpcont, String name, Attributes attributes) {
/* 37 */     String levelStr = attributes.getValue("level");
/* 38 */     if (JoranConstants.NULL.equalsIgnoreCase(levelStr) || "INHERITED".equalsIgnoreCase(levelStr)) {
/* 39 */       addError("The level for the ROOT logger cannot be set to NULL or INHERITED. Ignoring.");
/* 40 */       return false;
/*    */     } 
/* 42 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Model buildCurrentModel(SaxEventInterpretationContext interpretationContext, String name, Attributes attributes) {
/* 47 */     RootLoggerModel rootLoggerModel = new RootLoggerModel();
/* 48 */     String levelStr = attributes.getValue("level");
/* 49 */     rootLoggerModel.setLevel(levelStr);
/*    */     
/* 51 */     return (Model)rootLoggerModel;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\joran\action\RootLoggerAction.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */