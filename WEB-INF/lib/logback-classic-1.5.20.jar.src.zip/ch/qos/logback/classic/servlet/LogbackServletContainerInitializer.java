/*    */ package ch.qos.logback.classic.servlet;
/*    */ 
/*    */ import ch.qos.logback.classic.util.StatusViaSLF4JLoggerFactory;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ import jakarta.servlet.ServletContainerInitializer;
/*    */ import jakarta.servlet.ServletContext;
/*    */ import jakarta.servlet.ServletException;
/*    */ import java.util.EventListener;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogbackServletContainerInitializer
/*    */   implements ServletContainerInitializer
/*    */ {
/*    */   public void onStartup(Set<Class<?>> c, ServletContext ctx) throws ServletException {
/* 26 */     if (isDisabledByConfiguration(ctx)) {
/* 27 */       StatusViaSLF4JLoggerFactory.addInfo("Due to deployment instructions will NOT register an instance of " + String.valueOf(LogbackServletContextListener.class) + " to the current web-app", this);
/*    */ 
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 33 */     StatusViaSLF4JLoggerFactory.addInfo("Adding an instance of  " + String.valueOf(LogbackServletContextListener.class) + " to the current web-app", this);
/*    */     
/* 35 */     LogbackServletContextListener lscl = new LogbackServletContextListener();
/* 36 */     ctx.addListener((EventListener)lscl);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean isDisabledByConfiguration(ServletContext ctx) {
/* 48 */     String disableAttributeStr = null;
/* 49 */     Object disableAttribute = ctx.getInitParameter("logbackDisableServletContainerInitializer");
/* 50 */     if (disableAttribute instanceof String) {
/* 51 */       disableAttributeStr = (String)disableAttribute;
/*    */     }
/*    */     
/* 54 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(disableAttributeStr)) {
/* 55 */       disableAttributeStr = OptionHelper.getSystemProperty("logbackDisableServletContainerInitializer");
/*    */     }
/*    */     
/* 58 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(disableAttributeStr)) {
/* 59 */       disableAttributeStr = OptionHelper.getEnv("logbackDisableServletContainerInitializer");
/*    */     }
/*    */     
/* 62 */     return Boolean.parseBoolean(disableAttributeStr);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\servlet\LogbackServletContainerInitializer.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */