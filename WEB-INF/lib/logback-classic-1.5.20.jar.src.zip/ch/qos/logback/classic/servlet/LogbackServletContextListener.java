/*    */ package ch.qos.logback.classic.servlet;
/*    */ 
/*    */ import ch.qos.logback.classic.LoggerContext;
/*    */ import ch.qos.logback.classic.util.StatusViaSLF4JLoggerFactory;
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.spi.ContextAwareBase;
/*    */ import jakarta.servlet.ServletContextEvent;
/*    */ import jakarta.servlet.ServletContextListener;
/*    */ import org.slf4j.ILoggerFactory;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogbackServletContextListener
/*    */   implements ServletContextListener
/*    */ {
/* 22 */   ContextAwareBase contextAwareBase = new ContextAwareBase();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void contextInitialized(ServletContextEvent sce) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void contextDestroyed(ServletContextEvent sce) {
/* 32 */     ILoggerFactory iLoggerFactory = LoggerFactory.getILoggerFactory();
/* 33 */     if (iLoggerFactory instanceof LoggerContext) {
/* 34 */       LoggerContext loggerContext = (LoggerContext)iLoggerFactory;
/* 35 */       this.contextAwareBase.setContext((Context)loggerContext);
/* 36 */       StatusViaSLF4JLoggerFactory.addInfo("About to stop " + loggerContext.getClass().getCanonicalName() + " [" + loggerContext
/* 37 */           .getName() + "]", this);
/* 38 */       loggerContext.stop();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\servlet\LogbackServletContextListener.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */