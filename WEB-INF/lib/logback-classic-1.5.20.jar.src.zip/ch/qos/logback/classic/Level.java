/*     */ package ch.qos.logback.classic;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Level
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -814092767334282137L;
/*     */   public static final int OFF_INT = 2147483647;
/*     */   public static final int ERROR_INT = 40000;
/*     */   public static final int WARN_INT = 30000;
/*     */   public static final int INFO_INT = 20000;
/*     */   public static final int DEBUG_INT = 10000;
/*     */   public static final int TRACE_INT = 5000;
/*     */   public static final int ALL_INT = -2147483648;
/*  39 */   public static final Integer OFF_INTEGER = Integer.valueOf(2147483647);
/*  40 */   public static final Integer ERROR_INTEGER = Integer.valueOf(40000);
/*  41 */   public static final Integer WARN_INTEGER = Integer.valueOf(30000);
/*  42 */   public static final Integer INFO_INTEGER = Integer.valueOf(20000);
/*  43 */   public static final Integer DEBUG_INTEGER = Integer.valueOf(10000);
/*  44 */   public static final Integer TRACE_INTEGER = Integer.valueOf(5000);
/*  45 */   public static final Integer ALL_INTEGER = Integer.valueOf(-2147483648);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final Level OFF = new Level(2147483647, "OFF");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public static final Level ERROR = new Level(40000, "ERROR");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public static final Level WARN = new Level(30000, "WARN");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public static final Level INFO = new Level(20000, "INFO");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   public static final Level DEBUG = new Level(10000, "DEBUG");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public static final Level TRACE = new Level(5000, "TRACE");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public static final Level ALL = new Level(-2147483648, "ALL");
/*     */ 
/*     */   
/*     */   public final int levelInt;
/*     */   
/*     */   public final String levelStr;
/*     */ 
/*     */   
/*     */   private Level(int levelInt, String levelStr) {
/* 108 */     this.levelInt = levelInt;
/* 109 */     this.levelStr = levelStr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 116 */     return this.levelStr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int toInt() {
/* 123 */     return this.levelInt;
/*     */   }
/*     */   
/*     */   public static Level convertAnSLF4JLevel(org.slf4j.event.Level slf4jLevel) {
/* 127 */     int levelInt = slf4jLevel.toInt();
/* 128 */     return fromLocationAwareLoggerInteger(levelInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer toInteger() {
/* 137 */     switch (this.levelInt) {
/*     */       case -2147483648:
/* 139 */         return ALL_INTEGER;
/*     */       case 5000:
/* 141 */         return TRACE_INTEGER;
/*     */       case 10000:
/* 143 */         return DEBUG_INTEGER;
/*     */       case 20000:
/* 145 */         return INFO_INTEGER;
/*     */       case 30000:
/* 147 */         return WARN_INTEGER;
/*     */       case 40000:
/* 149 */         return ERROR_INTEGER;
/*     */       case 2147483647:
/* 151 */         return OFF_INTEGER;
/*     */     } 
/* 153 */     throw new IllegalStateException("Level " + this.levelStr + ", " + this.levelInt + " is unknown.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGreaterOrEqual(Level r) {
/* 162 */     return (this.levelInt >= r.levelInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Level toLevel(String sArg) {
/* 170 */     return toLevel(sArg, DEBUG);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Level valueOf(String sArg) {
/* 180 */     return toLevel(sArg, DEBUG);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Level toLevel(int val) {
/* 188 */     return toLevel(val, DEBUG);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Level toLevel(int val, Level defaultLevel) {
/* 196 */     switch (val) {
/*     */       case -2147483648:
/* 198 */         return ALL;
/*     */       case 5000:
/* 200 */         return TRACE;
/*     */       case 10000:
/* 202 */         return DEBUG;
/*     */       case 20000:
/* 204 */         return INFO;
/*     */       case 30000:
/* 206 */         return WARN;
/*     */       case 40000:
/* 208 */         return ERROR;
/*     */       case 2147483647:
/* 210 */         return OFF;
/*     */     } 
/* 212 */     return defaultLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Level toLevel(String sArg, Level defaultLevel) {
/* 221 */     if (sArg == null) {
/* 222 */       return defaultLevel;
/*     */     }
/*     */ 
/*     */     
/* 226 */     String in = sArg.trim();
/*     */     
/* 228 */     if (in.equalsIgnoreCase("ALL")) {
/* 229 */       return ALL;
/*     */     }
/* 231 */     if (in.equalsIgnoreCase("TRACE")) {
/* 232 */       return TRACE;
/*     */     }
/* 234 */     if (in.equalsIgnoreCase("DEBUG")) {
/* 235 */       return DEBUG;
/*     */     }
/* 237 */     if (in.equalsIgnoreCase("INFO")) {
/* 238 */       return INFO;
/*     */     }
/* 240 */     if (in.equalsIgnoreCase("WARN")) {
/* 241 */       return WARN;
/*     */     }
/* 243 */     if (in.equalsIgnoreCase("ERROR")) {
/* 244 */       return ERROR;
/*     */     }
/* 246 */     if (in.equalsIgnoreCase("OFF")) {
/* 247 */       return OFF;
/*     */     }
/* 249 */     return defaultLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object readResolve() {
/* 259 */     return toLevel(this.levelInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Level fromLocationAwareLoggerInteger(int levelInt) {
/*     */     Level level;
/* 273 */     switch (levelInt) {
/*     */       case 0:
/* 275 */         level = TRACE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 292 */         return level;case 10: level = DEBUG; return level;case 20: level = INFO; return level;case 30: level = WARN; return level;case 40: level = ERROR; return level;
/*     */     } 
/*     */     throw new IllegalArgumentException("" + levelInt + " not a valid level value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toLocationAwareLoggerInteger(Level level) {
/* 305 */     if (level == null)
/* 306 */       throw new IllegalArgumentException("null level parameter is not admitted"); 
/* 307 */     switch (level.toInt()) {
/*     */       case 5000:
/* 309 */         return 0;
/*     */       case 10000:
/* 311 */         return 10;
/*     */       case 20000:
/* 313 */         return 20;
/*     */       case 30000:
/* 315 */         return 30;
/*     */       case 40000:
/* 317 */         return 40;
/*     */     } 
/* 319 */     throw new IllegalArgumentException(String.valueOf(level) + " not a valid level value");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\Level.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */