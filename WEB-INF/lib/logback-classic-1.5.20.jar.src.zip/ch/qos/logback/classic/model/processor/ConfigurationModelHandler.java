/*     */ package ch.qos.logback.classic.model.processor;
/*     */ 
/*     */ import ch.qos.logback.classic.LoggerContext;
/*     */ import ch.qos.logback.classic.model.ConfigurationModel;
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.model.Model;
/*     */ import ch.qos.logback.core.model.processor.ModelHandlerBase;
/*     */ import ch.qos.logback.core.model.processor.ModelHandlerException;
/*     */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*     */ import ch.qos.logback.core.status.OnConsoleStatusListener;
/*     */ import ch.qos.logback.core.util.ContextUtil;
/*     */ import ch.qos.logback.core.util.Duration;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import ch.qos.logback.core.util.StatusListenerConfigHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationModelHandler
/*     */   extends ModelHandlerBase
/*     */ {
/*  45 */   static final Duration SCAN_PERIOD_DEFAULT = Duration.buildByMinutes(1.0D);
/*     */   
/*     */   public ConfigurationModelHandler(Context context) {
/*  48 */     super(context);
/*     */   }
/*     */   
/*     */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext mic) {
/*  52 */     return new ConfigurationModelHandler(context);
/*     */   }
/*     */   
/*     */   protected Class<ConfigurationModel> getSupportedModelClass() {
/*  56 */     return ConfigurationModel.class;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void handle(ModelInterpretationContext mic, Model model) {
/*  62 */     ConfigurationModel configurationModel = (ConfigurationModel)model;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     String debugAttrib = OptionHelper.getSystemProperty("logback.debug", null);
/*  68 */     if (debugAttrib == null) {
/*  69 */       debugAttrib = mic.subst(configurationModel.getDebugStr());
/*     */     }
/*     */ 
/*     */     
/*  73 */     if (!OptionHelper.isNullOrEmptyOrAllSpaces(debugAttrib) && !debugAttrib.equalsIgnoreCase(Boolean.FALSE.toString()) && 
/*  74 */       !debugAttrib.equalsIgnoreCase("null")) {
/*  75 */       StatusListenerConfigHelper.addOnConsoleListenerInstance(this.context, new OnConsoleStatusListener());
/*     */     }
/*     */     
/*  78 */     processScanAttrib(mic, configurationModel);
/*     */     
/*  80 */     LoggerContext lc = (LoggerContext)this.context;
/*  81 */     boolean packagingData = OptionHelper.toBoolean(mic.subst(configurationModel.getPackagingDataStr()), false);
/*     */     
/*  83 */     lc.setPackagingDataEnabled(packagingData);
/*     */     
/*  85 */     ContextUtil contextUtil = new ContextUtil(this.context);
/*  86 */     contextUtil.addGroovyPackages(lc.getFrameworkPackages());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processScanAttrib(ModelInterpretationContext mic, ConfigurationModel configurationModel) {
/*  92 */     String scanStr = mic.subst(configurationModel.getScanStr());
/*  93 */     if (!OptionHelper.isNullOrEmptyOrAllSpaces(scanStr) && !"false".equalsIgnoreCase(scanStr)) {
/*  94 */       addInfo("Skipping ReconfigureOnChangeTask registration");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void postProcessScanAttrib(ModelInterpretationContext mic, ConfigurationModel configurationModel) {}
/*     */ 
/*     */   
/*     */   public void postHandle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 104 */     ConfigurationModel configurationModel = (ConfigurationModel)model;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\processor\ConfigurationModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */