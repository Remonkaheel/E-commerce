/*    */ package ch.qos.logback.classic.model.util;
/*    */ 
/*    */ import ch.qos.logback.classic.model.processor.LogbackClassicDefaultNestedComponentRules;
/*    */ import ch.qos.logback.core.joran.util.ParentTag_Tag_Class_Tuple;
/*    */ import ch.qos.logback.core.model.ImplicitModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.util.TagUtil;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultClassNameHelper
/*    */ {
/* 32 */   List<ParentTag_Tag_Class_Tuple> tupleList = LogbackClassicDefaultNestedComponentRules.TUPLES_LIST;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void injectDefaultComponentClasses(Model aModel, Model parent) {
/* 44 */     applyInjectionRules(aModel, parent);
/*    */     
/* 46 */     for (Model sub : aModel.getSubModels()) {
/* 47 */       injectDefaultComponentClasses(sub, aModel);
/*    */     }
/*    */   }
/*    */   
/*    */   private void applyInjectionRules(Model aModel, Model parent) {
/* 52 */     if (parent == null) {
/*    */       return;
/*    */     }
/* 55 */     String parentTag = TagUtil.unifiedTag(parent);
/* 56 */     String modelTag = TagUtil.unifiedTag(aModel);
/*    */     
/* 58 */     if (aModel instanceof ImplicitModel) {
/* 59 */       ImplicitModel implicitModel = (ImplicitModel)aModel;
/* 60 */       String className = implicitModel.getClassName();
/*    */       
/* 62 */       if (className == null || className.isEmpty())
/* 63 */         for (ParentTag_Tag_Class_Tuple ruleTuple : this.tupleList) {
/* 64 */           if (ruleTuple.parentTag.equals(parentTag) && ruleTuple.tag.equals(modelTag)) {
/* 65 */             implicitModel.setClassName(ruleTuple.className);
/*    */             break;
/*    */           } 
/*    */         }  
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\mode\\util\DefaultClassNameHelper.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */