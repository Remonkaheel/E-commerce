/*    */ package ch.qos.logback.classic.model.processor;
/*    */ 
/*    */ import ch.qos.logback.classic.Level;
/*    */ import ch.qos.logback.classic.Logger;
/*    */ import ch.qos.logback.classic.LoggerContext;
/*    */ import ch.qos.logback.classic.model.RootLoggerModel;
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerBase;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerException;
/*    */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ 
/*    */ public class RootLoggerModelHandler
/*    */   extends ModelHandlerBase {
/*    */   Logger root;
/*    */   boolean inError = false;
/*    */   
/*    */   public RootLoggerModelHandler(Context context) {
/* 20 */     super(context);
/*    */   }
/*    */   
/*    */   public static RootLoggerModelHandler makeInstance(Context context, ModelInterpretationContext ic) {
/* 24 */     return new RootLoggerModelHandler(context);
/*    */   }
/*    */   
/*    */   protected Class<RootLoggerModel> getSupportedModelClass() {
/* 28 */     return RootLoggerModel.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 33 */     this.inError = false;
/*    */     
/* 35 */     RootLoggerModel rootLoggerModel = (RootLoggerModel)model;
/*    */     
/* 37 */     LoggerContext loggerContext = (LoggerContext)this.context;
/* 38 */     this.root = loggerContext.getLogger("ROOT");
/*    */     
/* 40 */     String levelStr = mic.subst(rootLoggerModel.getLevel());
/* 41 */     if (!OptionHelper.isNullOrEmptyOrAllSpaces(levelStr)) {
/* 42 */       Level level = Level.toLevel(levelStr);
/* 43 */       addInfo("Setting level of ROOT logger to " + String.valueOf(level));
/* 44 */       this.root.setLevel(level);
/*    */     } 
/*    */     
/* 47 */     mic.pushObject(this.root);
/*    */   }
/*    */ 
/*    */   
/*    */   public void postHandle(ModelInterpretationContext mic, Model model) {
/* 52 */     if (this.inError) {
/*    */       return;
/*    */     }
/* 55 */     Object o = mic.peekObject();
/* 56 */     if (o != this.root) {
/* 57 */       addWarn("The object [" + String.valueOf(o) + "] on the top the of the stack is not the root logger");
/*    */     } else {
/* 59 */       mic.popObject();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\processor\RootLoggerModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */