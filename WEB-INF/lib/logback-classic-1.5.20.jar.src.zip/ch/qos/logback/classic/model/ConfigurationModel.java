/*    */ package ch.qos.logback.classic.model;
/*    */ 
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigurationModel
/*    */   extends Model
/*    */ {
/*    */   private static final long serialVersionUID = 1286156598561818515L;
/*    */   String debugStr;
/*    */   String scanStr;
/*    */   String scanPeriodStr;
/*    */   String packagingDataStr;
/*    */   
/*    */   protected ConfigurationModel makeNewInstance() {
/* 19 */     return new ConfigurationModel();
/*    */   }
/*    */   
/*    */   protected void mirror(Model that) {
/* 23 */     ConfigurationModel actual = (ConfigurationModel)that;
/* 24 */     super.mirror(that);
/* 25 */     this.debugStr = actual.debugStr;
/* 26 */     this.scanStr = actual.scanStr;
/* 27 */     this.scanPeriodStr = actual.scanPeriodStr;
/* 28 */     this.packagingDataStr = actual.packagingDataStr;
/*    */   }
/*    */   
/*    */   public String getDebugStr() {
/* 32 */     return this.debugStr;
/*    */   }
/*    */   
/*    */   public void setDebugStr(String debugStr) {
/* 36 */     this.debugStr = debugStr;
/*    */   }
/*    */   
/*    */   public String getScanStr() {
/* 40 */     return this.scanStr;
/*    */   }
/*    */   
/*    */   public void setScanStr(String scanStr) {
/* 44 */     this.scanStr = scanStr;
/*    */   }
/*    */   
/*    */   public String getScanPeriodStr() {
/* 48 */     return this.scanPeriodStr;
/*    */   }
/*    */   
/*    */   public void setScanPeriodStr(String scanPeriodStr) {
/* 52 */     this.scanPeriodStr = scanPeriodStr;
/*    */   }
/*    */   
/*    */   public String getPackagingDataStr() {
/* 56 */     return this.packagingDataStr;
/*    */   }
/*    */   
/*    */   public void setPackagingDataStr(String packagingDataStr) {
/* 60 */     this.packagingDataStr = packagingDataStr;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 65 */     int prime = 31;
/* 66 */     int result = super.hashCode();
/* 67 */     result = 31 * result + Objects.hash(new Object[] { this.debugStr, this.packagingDataStr, this.scanPeriodStr, this.scanStr });
/* 68 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 73 */     if (this == obj)
/* 74 */       return true; 
/* 75 */     if (!super.equals(obj))
/* 76 */       return false; 
/* 77 */     if (getClass() != obj.getClass())
/* 78 */       return false; 
/* 79 */     ConfigurationModel other = (ConfigurationModel)obj;
/* 80 */     return (Objects.equals(this.debugStr, other.debugStr) && Objects.equals(this.packagingDataStr, other.packagingDataStr) && 
/* 81 */       Objects.equals(this.scanPeriodStr, other.scanPeriodStr) && Objects.equals(this.scanStr, other.scanStr));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\ConfigurationModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */