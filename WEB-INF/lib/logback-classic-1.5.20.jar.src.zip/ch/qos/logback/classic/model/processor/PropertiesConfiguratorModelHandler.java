/*    */ package ch.qos.logback.classic.model.processor;
/*    */ 
/*    */ import ch.qos.logback.classic.joran.PropertiesConfigurator;
/*    */ import ch.qos.logback.classic.model.PropertiesConfiguratorModel;
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.joran.spi.JoranException;
/*    */ import ch.qos.logback.core.joran.util.ConfigurationWatchListUtil;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.ResourceModel;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerException;
/*    */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*    */ import ch.qos.logback.core.model.processor.ResourceHandlerBase;
/*    */ import ch.qos.logback.core.spi.ContextAwarePropertyContainer;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertiesConfiguratorModelHandler
/*    */   extends ResourceHandlerBase
/*    */ {
/*    */   boolean inError = false;
/*    */   static final boolean CREATE_CWL_IF_NOT_ALREADY_CREATED = true;
/*    */   
/*    */   public PropertiesConfiguratorModelHandler(Context context) {
/* 39 */     super(context);
/*    */   }
/*    */   
/*    */   public static PropertiesConfiguratorModelHandler makeInstance(Context context, ModelInterpretationContext mic) {
/* 43 */     return new PropertiesConfiguratorModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 48 */     detachedHandle((ContextAwarePropertyContainer)mic, model);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void detachedHandle(ContextAwarePropertyContainer capc, Model model) throws ModelHandlerException {
/* 63 */     PropertiesConfiguratorModel propertyConfiguratorModel = (PropertiesConfiguratorModel)model;
/*    */     
/* 65 */     this.optional = OptionHelper.toBoolean(propertyConfiguratorModel.getOptional(), false);
/*    */     
/* 67 */     if (!checkAttributes((ResourceModel)propertyConfiguratorModel)) {
/* 68 */       this.inError = true;
/*    */       
/*    */       return;
/*    */     } 
/* 72 */     InputStream in = getInputStream(capc, (ResourceModel)propertyConfiguratorModel);
/* 73 */     if (in == null) {
/* 74 */       this.inError = true;
/*    */       
/*    */       return;
/*    */     } 
/* 78 */     addInfo("Reading configuration from [" + getAttribureInUse() + "]");
/*    */     
/* 80 */     PropertiesConfigurator propertiesConfigurator = new PropertiesConfigurator();
/* 81 */     propertiesConfigurator.setContext(capc.getContext());
/*    */     try {
/* 83 */       propertiesConfigurator.doConfigure(in);
/* 84 */     } catch (JoranException e) {
/* 85 */       addError("Could not configure from " + getAttribureInUse());
/* 86 */       throw new ModelHandlerException(e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected InputStream getInputStream(ContextAwarePropertyContainer capc, ResourceModel resourceModel) {
/* 92 */     URL inputURL = getInputURL(capc, resourceModel);
/* 93 */     if (inputURL == null) {
/* 94 */       return null;
/*    */     }
/* 96 */     ConfigurationWatchListUtil.addToWatchList(this.context, inputURL, true);
/* 97 */     return openURL(inputURL);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\processor\PropertiesConfiguratorModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */