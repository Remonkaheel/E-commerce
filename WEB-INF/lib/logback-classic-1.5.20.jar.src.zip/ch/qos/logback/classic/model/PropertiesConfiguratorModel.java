package ch.qos.logback.classic.model;

import ch.qos.logback.core.model.ResourceModel;

public class PropertiesConfiguratorModel extends ResourceModel {
  private static final long serialVersionUID = -2009536798661734346L;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\PropertiesConfiguratorModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */