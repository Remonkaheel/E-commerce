/*    */ package ch.qos.logback.classic.model.processor;
/*    */ 
/*    */ import ch.qos.logback.classic.PatternLayout;
/*    */ import ch.qos.logback.classic.boolex.StubEventEvaluator;
/*    */ import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
/*    */ import ch.qos.logback.core.AppenderBase;
/*    */ import ch.qos.logback.core.UnsynchronizedAppenderBase;
/*    */ import ch.qos.logback.core.filter.EvaluatorFilter;
/*    */ import ch.qos.logback.core.joran.spi.DefaultNestedComponentRegistry;
/*    */ import ch.qos.logback.core.joran.util.ParentTag_Tag_Class_Tuple;
/*    */ import ch.qos.logback.core.net.ssl.KeyManagerFactoryFactoryBean;
/*    */ import ch.qos.logback.core.net.ssl.KeyStoreFactoryBean;
/*    */ import ch.qos.logback.core.net.ssl.SSLConfiguration;
/*    */ import ch.qos.logback.core.net.ssl.SSLNestedComponentRegistryRules;
/*    */ import ch.qos.logback.core.net.ssl.SSLParametersConfiguration;
/*    */ import ch.qos.logback.core.net.ssl.SecureRandomFactoryBean;
/*    */ import ch.qos.logback.core.net.ssl.TrustManagerFactoryFactoryBean;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogbackClassicDefaultNestedComponentRules
/*    */ {
/* 44 */   public static List<ParentTag_Tag_Class_Tuple> TUPLES_LIST = createTuplesList();
/*    */   
/*    */   public static void addDefaultNestedComponentRegistryRules(DefaultNestedComponentRegistry registry) {
/* 47 */     registry.add(AppenderBase.class, "layout", PatternLayout.class);
/* 48 */     registry.add(UnsynchronizedAppenderBase.class, "layout", PatternLayout.class);
/*    */     
/* 50 */     registry.add(AppenderBase.class, "encoder", PatternLayoutEncoder.class);
/* 51 */     registry.add(UnsynchronizedAppenderBase.class, "encoder", PatternLayoutEncoder.class);
/* 52 */     registry.add(EvaluatorFilter.class, "evaluator", StubEventEvaluator.class);
/*    */     
/* 54 */     SSLNestedComponentRegistryRules.addDefaultNestedComponentRegistryRules(registry);
/*    */   }
/*    */ 
/*    */   
/*    */   public static List<ParentTag_Tag_Class_Tuple> createTuplesList() {
/* 59 */     List<ParentTag_Tag_Class_Tuple> tupleList = new ArrayList<>();
/*    */     
/* 61 */     tupleList.add(new ParentTag_Tag_Class_Tuple("appender", "encoder", PatternLayoutEncoder.class.getName()));
/* 62 */     tupleList.add(new ParentTag_Tag_Class_Tuple("appender", "layout", PatternLayout.class.getName()));
/* 63 */     tupleList.add(new ParentTag_Tag_Class_Tuple("receiver", "ssl", SSLConfiguration.class.getName()));
/* 64 */     tupleList.add(new ParentTag_Tag_Class_Tuple("ssl", "parameters", SSLParametersConfiguration.class.getName()));
/* 65 */     tupleList.add(new ParentTag_Tag_Class_Tuple("ssl", "keyStore", KeyStoreFactoryBean.class.getName()));
/* 66 */     tupleList.add(new ParentTag_Tag_Class_Tuple("ssl", "trustStore", KeyManagerFactoryFactoryBean.class.getName()));
/* 67 */     tupleList.add(new ParentTag_Tag_Class_Tuple("ssl", "keyManagerFactory", SSLParametersConfiguration.class.getName()));
/* 68 */     tupleList.add(new ParentTag_Tag_Class_Tuple("ssl", "trustManagerFactory", TrustManagerFactoryFactoryBean.class.getName()));
/* 69 */     tupleList.add(new ParentTag_Tag_Class_Tuple("ssl", "secureRandom", SecureRandomFactoryBean.class.getName()));
/* 70 */     return tupleList;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\processor\LogbackClassicDefaultNestedComponentRules.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */