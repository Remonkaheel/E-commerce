/*    */ package ch.qos.logback.classic.model.processor;
/*    */ 
/*    */ import ch.qos.logback.classic.Level;
/*    */ import ch.qos.logback.classic.Logger;
/*    */ import ch.qos.logback.classic.model.LevelModel;
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.joran.JoranConstants;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerBase;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerException;
/*    */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LevelModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   boolean inError = false;
/*    */   
/*    */   public LevelModelHandler(Context context) {
/* 21 */     super(context);
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext ic) {
/* 25 */     return new LevelModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<? extends LevelModel> getSupportedModelClass() {
/* 30 */     return LevelModel.class;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 36 */     Object o = mic.peekObject();
/*    */     
/* 38 */     if (!(o instanceof Logger)) {
/* 39 */       this.inError = true;
/* 40 */       addError("For element <level>, could not find a logger at the top of execution stack.");
/*    */       
/*    */       return;
/*    */     } 
/* 44 */     Logger l = (Logger)o;
/* 45 */     String loggerName = l.getName();
/*    */     
/* 47 */     LevelModel levelModel = (LevelModel)model;
/* 48 */     String levelStr = mic.subst(levelModel.getValue());
/* 49 */     if ("INHERITED".equalsIgnoreCase(levelStr) || JoranConstants.NULL.equalsIgnoreCase(levelStr))
/* 50 */     { if ("ROOT".equalsIgnoreCase(loggerName)) {
/* 51 */         addError("The level for the ROOT logger cannot be set to NULL or INHERITED. Ignoring.");
/*    */       } else {
/* 53 */         l.setLevel(null);
/*    */       }  }
/* 55 */     else { l.setLevel(Level.toLevel(levelStr, Level.DEBUG)); }
/*    */ 
/*    */     
/* 58 */     addInfo(loggerName + " level set to " + loggerName);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\processor\LevelModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */