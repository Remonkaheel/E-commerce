/*     */ package ch.qos.logback.classic.model.processor;
/*     */ 
/*     */ import ch.qos.logback.classic.joran.ReconfigureOnChangeTask;
/*     */ import ch.qos.logback.classic.model.ConfigurationModel;
/*     */ import ch.qos.logback.core.Context;
/*     */ import ch.qos.logback.core.joran.spi.ConfigurationWatchList;
/*     */ import ch.qos.logback.core.joran.util.ConfigurationWatchListUtil;
/*     */ import ch.qos.logback.core.model.Model;
/*     */ import ch.qos.logback.core.model.processor.ModelHandlerBase;
/*     */ import ch.qos.logback.core.model.processor.ModelHandlerException;
/*     */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*     */ import ch.qos.logback.core.spi.ConfigurationEvent;
/*     */ import ch.qos.logback.core.util.Duration;
/*     */ import ch.qos.logback.core.util.OptionHelper;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationModelHandlerFull
/*     */   extends ConfigurationModelHandler
/*     */ {
/*  39 */   public static String FAILED_WATCH_PREDICATE_MESSAGE_1 = "Missing watchable .xml or .properties files.";
/*  40 */   public static String FAILED_WATCH_PREDICATE_MESSAGE_2 = "Watching .xml files requires that the main configuration file is reachable as a URL";
/*     */   
/*     */   public ConfigurationModelHandlerFull(Context context) {
/*  43 */     super(context);
/*     */   }
/*     */   
/*     */   public static ModelHandlerBase makeInstance2(Context context, ModelInterpretationContext mic) {
/*  47 */     return new ConfigurationModelHandlerFull(context);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void processScanAttrib(ModelInterpretationContext mic, ConfigurationModel configurationModel) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void postHandle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/*  57 */     ConfigurationModel configurationModel = (ConfigurationModel)model;
/*     */ 
/*     */     
/*  60 */     postProcessScanAttrib(mic, configurationModel);
/*     */     
/*  62 */     ConfigurationWatchList cwl = ConfigurationWatchListUtil.getConfigurationWatchList(getContext());
/*  63 */     if (cwl != null) {
/*     */       try {
/*  65 */         addInfo("Main configuration file URL: " + String.valueOf(cwl.getMainURL()));
/*  66 */         addInfo("FileWatchList= {" + cwl.getFileWatchListAsStr() + "}");
/*  67 */         addInfo("URLWatchList= {" + cwl.getUrlWatchListAsStr() + "}");
/*  68 */       } catch (NoSuchMethodError e) {
/*  69 */         addWarn("It looks like the version of logback-classic is more recent than");
/*  70 */         addWarn("the version of logback-core. Please align the two versions.");
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   protected void postProcessScanAttrib(ModelInterpretationContext mic, ConfigurationModel configurationModel) {
/*  76 */     String scanStr = mic.subst(configurationModel.getScanStr());
/*  77 */     String scanPeriodStr = mic.subst(configurationModel.getScanPeriodStr());
/*  78 */     detachedPostProcess(scanStr, scanPeriodStr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void detachedPostProcess(String scanStr, String scanPeriodStr) {
/*  92 */     if (!OptionHelper.isNullOrEmptyOrAllSpaces(scanStr) && !"false".equalsIgnoreCase(scanStr)) {
/*  93 */       ScheduledExecutorService scheduledExecutorService = this.context.getScheduledExecutorService();
/*  94 */       boolean watchPredicateFulfilled = ConfigurationWatchListUtil.watchPredicateFulfilled(this.context);
/*  95 */       if (!watchPredicateFulfilled) {
/*  96 */         addWarn(FAILED_WATCH_PREDICATE_MESSAGE_1);
/*  97 */         addWarn(FAILED_WATCH_PREDICATE_MESSAGE_2);
/*     */         return;
/*     */       } 
/* 100 */       ReconfigureOnChangeTask rocTask = new ReconfigureOnChangeTask();
/* 101 */       rocTask.setContext(this.context);
/*     */       
/* 103 */       addInfo("Registering a new ReconfigureOnChangeTask " + String.valueOf(rocTask));
/*     */       
/* 105 */       this.context.fireConfigurationEvent(ConfigurationEvent.newConfigurationChangeDetectorRegisteredEvent(rocTask));
/*     */       
/* 107 */       Duration duration = getDurationOfScanPeriodAttribute(scanPeriodStr, SCAN_PERIOD_DEFAULT);
/*     */       
/* 109 */       addInfo("Will scan for changes in [" + String.valueOf(ConfigurationWatchListUtil.getConfigurationWatchList(this.context)) + "] ");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 114 */       addInfo("Setting ReconfigureOnChangeTask scanning period to " + String.valueOf(duration));
/*     */       
/* 116 */       ScheduledFuture<?> scheduledFuture = scheduledExecutorService.scheduleAtFixedRate((Runnable)rocTask, duration.getMilliseconds(), duration.getMilliseconds(), TimeUnit.MILLISECONDS);
/*     */       
/* 118 */       rocTask.setScheduledFuture(scheduledFuture);
/* 119 */       this.context.addScheduledFuture(scheduledFuture);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Duration getDurationOfScanPeriodAttribute(String scanPeriodAttrib, Duration defaultDuration) {
/* 125 */     Duration duration = null;
/*     */     
/* 127 */     if (!OptionHelper.isNullOrEmptyOrAllSpaces(scanPeriodAttrib)) {
/*     */       try {
/* 129 */         duration = Duration.valueOf(scanPeriodAttrib);
/* 130 */       } catch (IllegalStateException|IllegalArgumentException e) {
/* 131 */         addWarn("Failed to parse 'scanPeriod' attribute [" + scanPeriodAttrib + "]", e);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 136 */     if (duration == null) {
/* 137 */       addInfo("No 'scanPeriod' specified. Defaulting to " + defaultDuration.toString());
/* 138 */       duration = defaultDuration;
/*     */     } 
/* 140 */     return duration;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\processor\ConfigurationModelHandlerFull.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */