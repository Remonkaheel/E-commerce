/*    */ package ch.qos.logback.classic.model;
/*    */ 
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ public class LevelModel
/*    */   extends Model
/*    */ {
/*    */   private static final long serialVersionUID = -7287549849308062148L;
/*    */   String value;
/*    */   
/*    */   protected LevelModel makeNewInstance() {
/* 14 */     return new LevelModel();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void mirror(Model that) {
/* 19 */     LevelModel actual = (LevelModel)that;
/* 20 */     super.mirror(actual);
/* 21 */     this.value = actual.value;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 25 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setValue(String value) {
/* 29 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 34 */     int prime = 31;
/* 35 */     int result = super.hashCode();
/* 36 */     result = 31 * result + Objects.hash(new Object[] { this.value });
/* 37 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 42 */     if (this == obj)
/* 43 */       return true; 
/* 44 */     if (!super.equals(obj))
/* 45 */       return false; 
/* 46 */     if (getClass() != obj.getClass())
/* 47 */       return false; 
/* 48 */     LevelModel other = (LevelModel)obj;
/* 49 */     return Objects.equals(this.value, other.value);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\LevelModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */