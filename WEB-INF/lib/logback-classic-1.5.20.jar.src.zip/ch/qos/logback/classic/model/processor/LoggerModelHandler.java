/*    */ package ch.qos.logback.classic.model.processor;
/*    */ 
/*    */ import ch.qos.logback.classic.Level;
/*    */ import ch.qos.logback.classic.Logger;
/*    */ import ch.qos.logback.classic.LoggerContext;
/*    */ import ch.qos.logback.classic.model.LoggerModel;
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.joran.JoranConstants;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerBase;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerException;
/*    */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggerModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   Logger logger;
/*    */   boolean inError = false;
/*    */   
/*    */   public LoggerModelHandler(Context context) {
/* 24 */     super(context);
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext mic) {
/* 28 */     return new LoggerModelHandler(context);
/*    */   }
/*    */   
/*    */   protected Class<LoggerModel> getSupportedModelClass() {
/* 32 */     return LoggerModel.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 37 */     this.inError = false;
/*    */     
/* 39 */     LoggerModel loggerModel = (LoggerModel)model;
/*    */     
/* 41 */     String finalLoggerName = mic.subst(loggerModel.getName());
/*    */     
/* 43 */     LoggerContext loggerContext = (LoggerContext)this.context;
/*    */     
/* 45 */     this.logger = loggerContext.getLogger(finalLoggerName);
/*    */     
/* 47 */     String levelStr = mic.subst(loggerModel.getLevel());
/* 48 */     if (!OptionHelper.isNullOrEmptyOrAllSpaces(levelStr)) {
/* 49 */       if ("INHERITED".equalsIgnoreCase(levelStr) || JoranConstants.NULL.equalsIgnoreCase(levelStr)) {
/* 50 */         if ("ROOT".equalsIgnoreCase(finalLoggerName)) {
/* 51 */           addError("The level for the ROOT logger cannot be set to NULL or INHERITED. Ignoring.");
/*    */         } else {
/* 53 */           addInfo("Setting level of logger [" + finalLoggerName + "] to null, i.e. INHERITED");
/* 54 */           this.logger.setLevel(null);
/*    */         } 
/*    */       } else {
/* 57 */         Level level = Level.toLevel(levelStr);
/* 58 */         addInfo("Setting level of logger [" + finalLoggerName + "] to " + String.valueOf(level));
/* 59 */         this.logger.setLevel(level);
/*    */       } 
/*    */     }
/*    */     
/* 63 */     String additivityStr = mic.subst(loggerModel.getAdditivity());
/* 64 */     if (!OptionHelper.isNullOrEmptyOrAllSpaces(additivityStr)) {
/* 65 */       boolean additive = OptionHelper.toBoolean(additivityStr, true);
/* 66 */       addInfo("Setting additivity of logger [" + finalLoggerName + "] to " + additive);
/* 67 */       this.logger.setAdditive(additive);
/*    */     } 
/*    */     
/* 70 */     mic.pushObject(this.logger);
/*    */   }
/*    */ 
/*    */   
/*    */   public void postHandle(ModelInterpretationContext mic, Model model) {
/* 75 */     if (this.inError) {
/*    */       return;
/*    */     }
/* 78 */     Object o = mic.peekObject();
/* 79 */     if (o != this.logger) {
/* 80 */       LoggerModel loggerModel = (LoggerModel)model;
/* 81 */       addWarn("The object [" + String.valueOf(o) + "] on the top the of the stack is not the expected logger named " + loggerModel
/* 82 */           .getName());
/*    */     } else {
/* 84 */       mic.popObject();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\processor\LoggerModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */