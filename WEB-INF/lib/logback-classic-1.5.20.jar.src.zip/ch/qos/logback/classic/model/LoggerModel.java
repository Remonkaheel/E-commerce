/*    */ package ch.qos.logback.classic.model;
/*    */ 
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.processor.PhaseIndicator;
/*    */ import ch.qos.logback.core.model.processor.ProcessingPhase;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PhaseIndicator(phase = ProcessingPhase.SECOND)
/*    */ public class LoggerModel
/*    */   extends Model
/*    */ {
/*    */   private static final long serialVersionUID = 5326913660697375316L;
/*    */   String name;
/*    */   String level;
/*    */   String additivity;
/*    */   
/*    */   protected LoggerModel makeNewInstance() {
/* 33 */     return new LoggerModel();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void mirror(Model that) {
/* 38 */     LoggerModel actual = (LoggerModel)that;
/* 39 */     super.mirror(actual);
/* 40 */     this.name = actual.name;
/* 41 */     this.level = actual.level;
/* 42 */     this.additivity = actual.additivity;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 46 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 50 */     this.name = name;
/*    */   }
/*    */   
/*    */   public String getLevel() {
/* 54 */     return this.level;
/*    */   }
/*    */   
/*    */   public void setLevel(String level) {
/* 58 */     this.level = level;
/*    */   }
/*    */   
/*    */   public String getAdditivity() {
/* 62 */     return this.additivity;
/*    */   }
/*    */   
/*    */   public void setAdditivity(String additivity) {
/* 66 */     this.additivity = additivity;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 71 */     return getClass().getSimpleName() + " name=" + getClass().getSimpleName() + "]";
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 76 */     int prime = 31;
/* 77 */     int result = super.hashCode();
/* 78 */     result = 31 * result + Objects.hash(new Object[] { this.additivity, this.level, this.name });
/* 79 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 84 */     if (this == obj)
/* 85 */       return true; 
/* 86 */     if (!super.equals(obj))
/* 87 */       return false; 
/* 88 */     if (getClass() != obj.getClass())
/* 89 */       return false; 
/* 90 */     LoggerModel other = (LoggerModel)obj;
/* 91 */     return (Objects.equals(this.additivity, other.additivity) && Objects.equals(this.level, other.level) && 
/* 92 */       Objects.equals(this.name, other.name));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\LoggerModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */