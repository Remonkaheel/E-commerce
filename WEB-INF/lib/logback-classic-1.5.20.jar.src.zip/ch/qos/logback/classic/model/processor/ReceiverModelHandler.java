/*    */ package ch.qos.logback.classic.model.processor;
/*    */ 
/*    */ import ch.qos.logback.classic.model.ReceiverModel;
/*    */ import ch.qos.logback.classic.net.ReceiverBase;
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerBase;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerException;
/*    */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*    */ import ch.qos.logback.core.spi.LifeCycle;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReceiverModelHandler
/*    */   extends ModelHandlerBase
/*    */ {
/*    */   private ReceiverBase receiver;
/*    */   private boolean inError;
/*    */   
/*    */   public ReceiverModelHandler(Context context) {
/* 37 */     super(context);
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext ic) {
/* 41 */     return new ReceiverModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<ReceiverModel> getSupportedModelClass() {
/* 46 */     return ReceiverModel.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 51 */     ReceiverModel receiverModel = (ReceiverModel)model;
/* 52 */     String className = receiverModel.getClassName();
/*    */     
/* 54 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(className)) {
/* 55 */       addError("Missing class name for receiver. ");
/* 56 */       this.inError = true;
/*    */       return;
/*    */     } 
/* 59 */     className = mic.getImport(className);
/*    */ 
/*    */     
/*    */     try {
/* 63 */       addInfo("About to instantiate receiver of type [" + className + "]");
/*    */       
/* 65 */       this.receiver = (ReceiverBase)OptionHelper.instantiateByClassName(className, ReceiverBase.class, this.context);
/* 66 */       this.receiver.setContext(this.context);
/*    */       
/* 68 */       mic.pushObject(this.receiver);
/* 69 */     } catch (Exception ex) {
/* 70 */       this.inError = true;
/* 71 */       addError("Could not create a receiver of type [" + className + "].", ex);
/* 72 */       throw new ModelHandlerException(ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void postHandle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 79 */     if (this.inError) {
/*    */       return;
/*    */     }
/*    */     
/* 83 */     Object o = mic.peekObject();
/* 84 */     if (o != this.receiver) {
/* 85 */       addWarn("The object at the of the stack is not the receiver pushed earlier.");
/*    */     } else {
/* 87 */       mic.popObject();
/* 88 */       addInfo("Registering receiver with context.");
/* 89 */       mic.getContext().register((LifeCycle)this.receiver);
/* 90 */       this.receiver.start();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\processor\ReceiverModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */