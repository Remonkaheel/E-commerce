/*    */ package ch.qos.logback.classic.model;
/*    */ 
/*    */ import ch.qos.logback.core.model.ComponentModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggerContextListenerModel
/*    */   extends ComponentModel
/*    */ {
/*    */   private static final long serialVersionUID = 8200534537519733363L;
/*    */   
/*    */   protected LoggerContextListenerModel makeNewInstance() {
/* 24 */     return new LoggerContextListenerModel();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\LoggerContextListenerModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */