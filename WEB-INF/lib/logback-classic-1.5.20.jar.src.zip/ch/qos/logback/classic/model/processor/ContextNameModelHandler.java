/*    */ package ch.qos.logback.classic.model.processor;
/*    */ 
/*    */ import ch.qos.logback.classic.model.ContextNameModel;
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerBase;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerException;
/*    */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*    */ 
/*    */ public class ContextNameModelHandler
/*    */   extends ModelHandlerBase {
/*    */   public ContextNameModelHandler(Context context) {
/* 13 */     super(context);
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext ic) {
/* 17 */     return new ContextNameModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<ContextNameModel> getSupportedModelClass() {
/* 22 */     return ContextNameModel.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 27 */     ContextNameModel contextNameModel = (ContextNameModel)model;
/*    */     
/* 29 */     String finalBody = mic.subst(contextNameModel.getBodyText());
/* 30 */     addInfo("Setting logger context name as [" + finalBody + "]");
/*    */     try {
/* 32 */       this.context.setName(finalBody);
/* 33 */     } catch (IllegalStateException e) {
/* 34 */       addError("Failed to rename context [" + this.context.getName() + "] as [" + finalBody + "]", e);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\processor\ContextNameModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */