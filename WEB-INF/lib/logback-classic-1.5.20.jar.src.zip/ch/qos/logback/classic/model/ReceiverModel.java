/*    */ package ch.qos.logback.classic.model;
/*    */ 
/*    */ import ch.qos.logback.core.model.ComponentModel;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReceiverModel
/*    */   extends ComponentModel
/*    */ {
/*    */   private static final long serialVersionUID = -3161852321892056675L;
/*    */   
/*    */   protected ReceiverModel makeNewInstance() {
/* 24 */     return new ReceiverModel();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\ReceiverModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */