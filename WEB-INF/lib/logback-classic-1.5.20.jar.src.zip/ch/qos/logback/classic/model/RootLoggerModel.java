/*    */ package ch.qos.logback.classic.model;
/*    */ 
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.processor.PhaseIndicator;
/*    */ import ch.qos.logback.core.model.processor.ProcessingPhase;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @PhaseIndicator(phase = ProcessingPhase.SECOND)
/*    */ public class RootLoggerModel
/*    */   extends Model
/*    */ {
/*    */   private static final long serialVersionUID = -2811453129653502831L;
/*    */   String level;
/*    */   
/*    */   protected RootLoggerModel makeNewInstance() {
/* 30 */     return new RootLoggerModel();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void mirror(Model that) {
/* 35 */     RootLoggerModel actual = (RootLoggerModel)that;
/* 36 */     super.mirror(actual);
/* 37 */     this.level = actual.level;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getLevel() {
/* 42 */     return this.level;
/*    */   }
/*    */   
/*    */   public void setLevel(String level) {
/* 46 */     this.level = level;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 51 */     int prime = 31;
/* 52 */     int result = super.hashCode();
/* 53 */     result = 31 * result + Objects.hash(new Object[] { this.level });
/* 54 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 59 */     if (this == obj)
/* 60 */       return true; 
/* 61 */     if (!super.equals(obj))
/* 62 */       return false; 
/* 63 */     if (getClass() != obj.getClass())
/* 64 */       return false; 
/* 65 */     RootLoggerModel other = (RootLoggerModel)obj;
/* 66 */     return Objects.equals(this.level, other.level);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\RootLoggerModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */