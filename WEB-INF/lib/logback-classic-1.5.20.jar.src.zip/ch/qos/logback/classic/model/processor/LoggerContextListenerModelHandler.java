/*    */ package ch.qos.logback.classic.model.processor;
/*    */ 
/*    */ import ch.qos.logback.classic.LoggerContext;
/*    */ import ch.qos.logback.classic.model.LoggerContextListenerModel;
/*    */ import ch.qos.logback.classic.spi.LoggerContextListener;
/*    */ import ch.qos.logback.core.Context;
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerBase;
/*    */ import ch.qos.logback.core.model.processor.ModelHandlerException;
/*    */ import ch.qos.logback.core.model.processor.ModelInterpretationContext;
/*    */ import ch.qos.logback.core.spi.ContextAware;
/*    */ import ch.qos.logback.core.spi.LifeCycle;
/*    */ import ch.qos.logback.core.util.OptionHelper;
/*    */ 
/*    */ public class LoggerContextListenerModelHandler extends ModelHandlerBase {
/*    */   boolean inError = false;
/*    */   LoggerContextListener lcl;
/*    */   
/*    */   public LoggerContextListenerModelHandler(Context context) {
/* 20 */     super(context);
/*    */   }
/*    */   
/*    */   public static ModelHandlerBase makeInstance(Context context, ModelInterpretationContext ic) {
/* 24 */     return new LoggerContextListenerModelHandler(context);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Class<LoggerContextListenerModel> getSupportedModelClass() {
/* 29 */     return LoggerContextListenerModel.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public void handle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 34 */     LoggerContextListenerModel lclModel = (LoggerContextListenerModel)model;
/*    */     
/* 36 */     String className = lclModel.getClassName();
/* 37 */     if (OptionHelper.isNullOrEmptyOrAllSpaces(className)) {
/* 38 */       addError("Empty class name for LoggerContextListener");
/* 39 */       this.inError = true;
/*    */     } else {
/* 41 */       className = mic.getImport(className);
/*    */     } 
/*    */     
/*    */     try {
/* 45 */       this.lcl = (LoggerContextListener)OptionHelper.instantiateByClassName(className, LoggerContextListener.class, this.context);
/*    */ 
/*    */       
/* 48 */       if (this.lcl instanceof ContextAware) {
/* 49 */         ((ContextAware)this.lcl).setContext(this.context);
/*    */       }
/*    */       
/* 52 */       mic.pushObject(this.lcl);
/* 53 */       addInfo("Adding LoggerContextListener of type [" + className + "] to the object stack");
/*    */     }
/* 55 */     catch (Exception oops) {
/* 56 */       this.inError = true;
/* 57 */       addError("Could not create LoggerContextListener of type " + className + "].", oops);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void postHandle(ModelInterpretationContext mic, Model model) throws ModelHandlerException {
/* 63 */     if (this.inError) {
/*    */       return;
/*    */     }
/* 66 */     Object o = mic.peekObject();
/*    */     
/* 68 */     if (o != this.lcl) {
/* 69 */       addWarn("The object on the top the of the stack is not the LoggerContextListener pushed earlier.");
/*    */     } else {
/* 71 */       if (this.lcl instanceof LifeCycle) {
/* 72 */         ((LifeCycle)this.lcl).start();
/* 73 */         addInfo("Starting LoggerContextListener");
/*    */       } 
/* 75 */       ((LoggerContext)this.context).addListener(this.lcl);
/* 76 */       mic.popObject();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\processor\LoggerContextListenerModelHandler.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */