/*    */ package ch.qos.logback.classic.model;
/*    */ 
/*    */ import ch.qos.logback.core.model.Model;
/*    */ import ch.qos.logback.core.model.NamedModel;
/*    */ 
/*    */ public class ContextNameModel
/*    */   extends NamedModel {
/*    */   private static final long serialVersionUID = -1635653921915985666L;
/*    */   
/*    */   protected ContextNameModel makeNewInstance() {
/* 11 */     return new ContextNameModel();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\ch\qos\logback\classic\model\ContextNameModel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */