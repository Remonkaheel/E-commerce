module ch.qos.logback.classic {
  requires java.base;
  requires java.management;
  requires java.naming;
  requires java.logging;
  requires jakarta.servlet;
  requires jakarta.mail;
  requires org.slf4j;
  requires ch.qos.logback.core;
  
  exports ch.qos.logback.classic;
  exports ch.qos.logback.classic.boolex;
  exports ch.qos.logback.classic.encoder;
  exports ch.qos.logback.classic.filter;
  exports ch.qos.logback.classic.helpers;
  exports ch.qos.logback.classic.html;
  exports ch.qos.logback.classic.joran;
  exports ch.qos.logback.classic.joran.action;
  exports ch.qos.logback.classic.jul;
  exports ch.qos.logback.classic.layout;
  exports ch.qos.logback.classic.log4j;
  exports ch.qos.logback.classic.model;
  exports ch.qos.logback.classic.model.processor;
  exports ch.qos.logback.classic.net;
  exports ch.qos.logback.classic.net.server;
  exports ch.qos.logback.classic.pattern;
  exports ch.qos.logback.classic.pattern.color;
  exports ch.qos.logback.classic.selector;
  exports ch.qos.logback.classic.selector.servlet;
  exports ch.qos.logback.classic.servlet;
  exports ch.qos.logback.classic.sift;
  exports ch.qos.logback.classic.spi;
  exports ch.qos.logback.classic.turbo;
  exports ch.qos.logback.classic.tyler;
  exports ch.qos.logback.classic.util;
  
  uses ch.qos.logback.classic.spi.Configurator;
  
  provides org.slf4j.spi.SLF4JServiceProvider with ch.qos.logback.classic.spi.LogbackServiceProvider;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\logback-classic-1.5.20.jar!\module-info.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */