package org.springframework.security.access;

import java.util.Collection;
import org.springframework.aop.framework.AopInfrastructureBean;

@Deprecated
public interface SecurityMetadataSource extends AopInfrastructureBean {
  Collection<ConfigAttribute> getAttributes(Object paramObject) throws IllegalArgumentException;
  
  Collection<ConfigAttribute> getAllConfigAttributes();
  
  boolean supports(Class<?> paramClass);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\SecurityMetadataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */