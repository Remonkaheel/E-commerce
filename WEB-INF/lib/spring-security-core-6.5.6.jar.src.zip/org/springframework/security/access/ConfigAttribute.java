package org.springframework.security.access;

import java.io.Serializable;

@Deprecated
public interface ConfigAttribute extends Serializable {
  String getAttribute();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\ConfigAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */