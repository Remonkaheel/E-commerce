/*    */ package org.springframework.security.access;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class SecurityConfig
/*    */   implements ConfigAttribute
/*    */ {
/*    */   private static final long serialVersionUID = -7138084564199804304L;
/*    */   private final String attrib;
/*    */   
/*    */   public SecurityConfig(String config) {
/* 48 */     Assert.hasText(config, "You must provide a configuration attribute");
/* 49 */     this.attrib = config;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 54 */     if (obj instanceof ConfigAttribute) { ConfigAttribute attr = (ConfigAttribute)obj;
/* 55 */       return this.attrib.equals(attr.getAttribute()); }
/*    */     
/* 57 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAttribute() {
/* 62 */     return this.attrib;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 67 */     return this.attrib.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 72 */     return this.attrib;
/*    */   }
/*    */   
/*    */   public static List<ConfigAttribute> createListFromCommaDelimitedString(String access) {
/* 76 */     return createList(StringUtils.commaDelimitedListToStringArray(access));
/*    */   }
/*    */   
/*    */   public static List<ConfigAttribute> createList(String... attributeNames) {
/* 80 */     Assert.notNull(attributeNames, "You must supply an array of attribute names");
/* 81 */     List<ConfigAttribute> attributes = new ArrayList<>(attributeNames.length);
/* 82 */     for (String attribute : attributeNames) {
/* 83 */       attributes.add(new SecurityConfig(attribute.trim()));
/*    */     }
/* 85 */     return attributes;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\SecurityConfig.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */