/*     */ package org.springframework.security.access.prepost;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import kotlinx.coroutines.reactive.ReactiveFlowKt;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ReactiveAdapter;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.access.method.MethodSecurityMetadataSource;
/*     */ import org.springframework.security.authentication.AnonymousAuthenticationToken;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.security.core.context.ReactiveSecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.Exceptions;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class PrePostAdviceReactiveMethodInterceptor
/*     */   implements MethodInterceptor
/*     */ {
/*  60 */   private Authentication anonymous = (Authentication)new AnonymousAuthenticationToken("key", "anonymous", 
/*  61 */       AuthorityUtils.createAuthorityList(new String[] { "ROLE_ANONYMOUS" }));
/*     */ 
/*     */ 
/*     */   
/*     */   private final MethodSecurityMetadataSource attributeSource;
/*     */ 
/*     */   
/*     */   private final PreInvocationAuthorizationAdvice preInvocationAdvice;
/*     */ 
/*     */   
/*     */   private final PostInvocationAuthorizationAdvice postAdvice;
/*     */ 
/*     */   
/*     */   private static final String COROUTINES_FLOW_CLASS_NAME = "kotlinx.coroutines.flow.Flow";
/*     */ 
/*     */   
/*     */   private static final int RETURN_TYPE_METHOD_PARAMETER_INDEX = -1;
/*     */ 
/*     */ 
/*     */   
/*     */   public PrePostAdviceReactiveMethodInterceptor(MethodSecurityMetadataSource attributeSource, PreInvocationAuthorizationAdvice preInvocationAdvice, PostInvocationAuthorizationAdvice postInvocationAdvice) {
/*  82 */     Assert.notNull(attributeSource, "attributeSource cannot be null");
/*  83 */     Assert.notNull(preInvocationAdvice, "preInvocationAdvice cannot be null");
/*  84 */     Assert.notNull(postInvocationAdvice, "postInvocationAdvice cannot be null");
/*  85 */     this.attributeSource = attributeSource;
/*  86 */     this.preInvocationAdvice = preInvocationAdvice;
/*  87 */     this.postAdvice = postInvocationAdvice;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object invoke(MethodInvocation invocation) {
/*  92 */     Method method = invocation.getMethod();
/*  93 */     Class<?> returnType = method.getReturnType();
/*     */     
/*  95 */     boolean isSuspendingFunction = KotlinDetector.isSuspendingFunction(method);
/*     */     
/*  97 */     boolean hasFlowReturnType = "kotlinx.coroutines.flow.Flow".equals((new MethodParameter(method, -1)).getParameterType().getName());
/*  98 */     boolean hasReactiveReturnType = (Publisher.class.isAssignableFrom(returnType) || isSuspendingFunction || hasFlowReturnType);
/*     */ 
/*     */     
/* 101 */     Assert.state(hasReactiveReturnType, () -> "The returnType " + String.valueOf(returnType) + " on " + String.valueOf(method) + " must return an instance of org.reactivestreams.Publisher (i.e. Mono / Flux) or the function must be a Kotlin coroutine function in order to support Reactor Context");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     Class<?> targetClass = invocation.getThis().getClass();
/* 107 */     Collection<ConfigAttribute> attributes = this.attributeSource.getAttributes(method, targetClass);
/* 108 */     PreInvocationAttribute preAttr = findPreInvocationAttribute(attributes);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 114 */     Mono<Authentication> toInvoke = ReactiveSecurityContextHolder.getContext().map(SecurityContext::getAuthentication).defaultIfEmpty(this.anonymous).filter(auth -> this.preInvocationAdvice.before(auth, invocation, preAttr)).switchIfEmpty(Mono.defer(() -> Mono.error((Throwable)new AccessDeniedException("Denied"))));
/*     */     
/* 116 */     PostInvocationAttribute attr = findPostInvocationAttribute(attributes);
/* 117 */     if (Mono.class.isAssignableFrom(returnType)) {
/* 118 */       return toInvoke.flatMap(auth -> ((Mono)proceed(invocation)).map(()));
/*     */     }
/*     */     
/* 121 */     if (Flux.class.isAssignableFrom(returnType)) {
/* 122 */       return toInvoke.flatMapMany(auth -> ((Flux)proceed(invocation)).map(()));
/*     */     }
/*     */     
/* 125 */     if (hasFlowReturnType) {
/* 126 */       if (isSuspendingFunction) {
/* 127 */         return toInvoke
/* 128 */           .flatMapMany(auth -> Flux.from(proceed(invocation)).map(()));
/*     */       }
/*     */ 
/*     */       
/* 132 */       ReactiveAdapter adapter = ReactiveAdapterRegistry.getSharedInstance().getAdapter(returnType);
/* 133 */       Assert.state((adapter != null), () -> "The returnType " + String.valueOf(returnType) + " on " + String.valueOf(method) + " must have a org.springframework.core.ReactiveAdapter registered");
/*     */       
/* 135 */       Flux<?> response = toInvoke.flatMapMany(auth -> Flux.from(adapter.toPublisher(flowProceed(invocation))).map(()));
/*     */ 
/*     */       
/* 138 */       return KotlinDelegate.asFlow((Publisher<?>)response);
/*     */     } 
/*     */     
/* 141 */     return toInvoke.flatMap(auth -> Mono.from(proceed(invocation)).map(()));
/*     */   }
/*     */ 
/*     */   
/*     */   private static <T extends Publisher<?>> T proceed(MethodInvocation invocation) {
/*     */     try {
/* 147 */       return (T)invocation.proceed();
/*     */     }
/* 149 */     catch (Throwable throwable) {
/* 150 */       throw Exceptions.propagate(throwable);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Object flowProceed(MethodInvocation invocation) {
/*     */     try {
/* 156 */       return invocation.proceed();
/*     */     }
/* 158 */     catch (Throwable throwable) {
/* 159 */       throw Exceptions.propagate(throwable);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static PostInvocationAttribute findPostInvocationAttribute(Collection<ConfigAttribute> config) {
/* 164 */     for (ConfigAttribute attribute : config) {
/* 165 */       if (attribute instanceof PostInvocationAttribute) {
/* 166 */         return (PostInvocationAttribute)attribute;
/*     */       }
/*     */     } 
/* 169 */     return null;
/*     */   }
/*     */   
/*     */   private static PreInvocationAttribute findPreInvocationAttribute(Collection<ConfigAttribute> config) {
/* 173 */     for (ConfigAttribute attribute : config) {
/* 174 */       if (attribute instanceof PreInvocationAttribute) {
/* 175 */         return (PreInvocationAttribute)attribute;
/*     */       }
/*     */     } 
/* 178 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class KotlinDelegate
/*     */   {
/*     */     private static Object asFlow(Publisher<?> publisher) {
/* 187 */       return ReactiveFlowKt.asFlow(publisher);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\prepost\PrePostAdviceReactiveMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */