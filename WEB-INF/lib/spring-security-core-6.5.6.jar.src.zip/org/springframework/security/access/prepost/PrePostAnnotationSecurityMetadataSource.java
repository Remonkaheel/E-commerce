/*     */ package org.springframework.security.access.prepost;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.access.method.AbstractMethodSecurityMetadataSource;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class PrePostAnnotationSecurityMetadataSource
/*     */   extends AbstractMethodSecurityMetadataSource
/*     */ {
/*     */   private final PrePostInvocationAttributeFactory attributeFactory;
/*     */   
/*     */   public PrePostAnnotationSecurityMetadataSource(PrePostInvocationAttributeFactory attributeFactory) {
/*  63 */     this.attributeFactory = attributeFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ConfigAttribute> getAttributes(Method method, Class<?> targetClass) {
/*  68 */     if (method.getDeclaringClass() == Object.class) {
/*  69 */       return Collections.emptyList();
/*     */     }
/*  71 */     PreFilter preFilter = findAnnotation(method, targetClass, PreFilter.class);
/*  72 */     PreAuthorize preAuthorize = findAnnotation(method, targetClass, PreAuthorize.class);
/*  73 */     PostFilter postFilter = findAnnotation(method, targetClass, PostFilter.class);
/*     */     
/*  75 */     PostAuthorize postAuthorize = findAnnotation(method, targetClass, PostAuthorize.class);
/*  76 */     if (preFilter == null && preAuthorize == null && postFilter == null && postAuthorize == null)
/*     */     {
/*  78 */       return Collections.emptyList();
/*     */     }
/*  80 */     String preFilterAttribute = (preFilter != null) ? preFilter.value() : null;
/*  81 */     String filterObject = (preFilter != null) ? preFilter.filterTarget() : null;
/*  82 */     String preAuthorizeAttribute = (preAuthorize != null) ? preAuthorize.value() : null;
/*  83 */     String postFilterAttribute = (postFilter != null) ? postFilter.value() : null;
/*  84 */     String postAuthorizeAttribute = (postAuthorize != null) ? postAuthorize.value() : null;
/*  85 */     ArrayList<ConfigAttribute> attrs = new ArrayList<>(2);
/*  86 */     PreInvocationAttribute pre = this.attributeFactory.createPreInvocationAttribute(preFilterAttribute, filterObject, preAuthorizeAttribute);
/*     */     
/*  88 */     if (pre != null) {
/*  89 */       attrs.add(pre);
/*     */     }
/*  91 */     PostInvocationAttribute post = this.attributeFactory.createPostInvocationAttribute(postFilterAttribute, postAuthorizeAttribute);
/*     */     
/*  93 */     if (post != null) {
/*  94 */       attrs.add(post);
/*     */     }
/*  96 */     attrs.trimToSize();
/*  97 */     return attrs;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ConfigAttribute> getAllConfigAttributes() {
/* 102 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <A extends Annotation> A findAnnotation(Method method, Class<?> targetClass, Class<A> annotationClass) {
/* 115 */     Method specificMethod = ClassUtils.getMostSpecificMethod(method, targetClass);
/* 116 */     Annotation annotation = AnnotationUtils.findAnnotation(specificMethod, annotationClass);
/* 117 */     if (annotation != null) {
/* 118 */       this.logger.debug(LogMessage.format("%s found on specific method: %s", annotation, specificMethod));
/* 119 */       return (A)annotation;
/*     */     } 
/*     */     
/* 122 */     if (specificMethod != method) {
/* 123 */       annotation = AnnotationUtils.findAnnotation(method, annotationClass);
/* 124 */       if (annotation != null) {
/* 125 */         this.logger.debug(LogMessage.format("%s found on: %s", annotation, method));
/* 126 */         return (A)annotation;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 131 */     annotation = AnnotationUtils.findAnnotation(specificMethod.getDeclaringClass(), annotationClass);
/* 132 */     if (annotation != null) {
/* 133 */       this.logger
/* 134 */         .debug(LogMessage.format("%s found on: %s", annotation, specificMethod.getDeclaringClass().getName()));
/* 135 */       return (A)annotation;
/*     */     } 
/* 137 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\prepost\PrePostAnnotationSecurityMetadataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */