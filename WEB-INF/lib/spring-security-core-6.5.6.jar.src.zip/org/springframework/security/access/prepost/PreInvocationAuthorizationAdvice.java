package org.springframework.security.access.prepost;

import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.framework.AopInfrastructureBean;
import org.springframework.security.core.Authentication;

@Deprecated
public interface PreInvocationAuthorizationAdvice extends AopInfrastructureBean {
  boolean before(Authentication paramAuthentication, MethodInvocation paramMethodInvocation, PreInvocationAttribute paramPreInvocationAttribute);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\prepost\PreInvocationAuthorizationAdvice.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */