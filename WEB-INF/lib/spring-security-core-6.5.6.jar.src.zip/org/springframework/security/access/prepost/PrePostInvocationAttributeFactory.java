package org.springframework.security.access.prepost;

import org.springframework.aop.framework.AopInfrastructureBean;

@Deprecated
public interface PrePostInvocationAttributeFactory extends AopInfrastructureBean {
  PreInvocationAttribute createPreInvocationAttribute(String paramString1, String paramString2, String paramString3);
  
  PostInvocationAttribute createPostInvocationAttribute(String paramString1, String paramString2);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\prepost\PrePostInvocationAttributeFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */