package org.springframework.security.access.prepost;

import org.springframework.security.access.ConfigAttribute;

@Deprecated
public interface PreInvocationAttribute extends ConfigAttribute {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\prepost\PreInvocationAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */