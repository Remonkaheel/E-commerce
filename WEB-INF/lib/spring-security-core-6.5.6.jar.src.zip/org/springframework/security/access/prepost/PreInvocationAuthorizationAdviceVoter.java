/*    */ package org.springframework.security.access.prepost;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.security.access.AccessDecisionVoter;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class PreInvocationAuthorizationAdviceVoter
/*    */   implements AccessDecisionVoter<MethodInvocation>
/*    */ {
/* 48 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   private final PreInvocationAuthorizationAdvice preAdvice;
/*    */   
/*    */   public PreInvocationAuthorizationAdviceVoter(PreInvocationAuthorizationAdvice pre) {
/* 53 */     this.preAdvice = pre;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(ConfigAttribute attribute) {
/* 58 */     return attribute instanceof PreInvocationAttribute;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(Class<?> clazz) {
/* 63 */     return MethodInvocation.class.isAssignableFrom(clazz);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int vote(Authentication authentication, MethodInvocation method, Collection<ConfigAttribute> attributes) {
/* 70 */     PreInvocationAttribute preAttr = findPreInvocationAttribute(attributes);
/* 71 */     if (preAttr == null)
/*    */     {
/* 73 */       return 0;
/*    */     }
/* 75 */     return this.preAdvice.before(authentication, method, preAttr) ? 1 : -1;
/*    */   }
/*    */   
/*    */   private PreInvocationAttribute findPreInvocationAttribute(Collection<ConfigAttribute> config) {
/* 79 */     for (ConfigAttribute attribute : config) {
/* 80 */       if (attribute instanceof PreInvocationAttribute) {
/* 81 */         return (PreInvocationAttribute)attribute;
/*    */       }
/*    */     } 
/* 84 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\prepost\PreInvocationAuthorizationAdviceVoter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */