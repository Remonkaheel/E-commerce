package org.springframework.security.access.prepost;

import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.framework.AopInfrastructureBean;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;

@Deprecated
public interface PostInvocationAuthorizationAdvice extends AopInfrastructureBean {
  Object after(Authentication paramAuthentication, MethodInvocation paramMethodInvocation, PostInvocationAttribute paramPostInvocationAttribute, Object paramObject) throws AccessDeniedException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\prepost\PostInvocationAuthorizationAdvice.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */