/*    */ package org.springframework.security.access.prepost;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.security.access.AfterInvocationProvider;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class PostInvocationAdviceProvider
/*    */   implements AfterInvocationProvider
/*    */ {
/* 46 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   private final PostInvocationAuthorizationAdvice postAdvice;
/*    */   
/*    */   public PostInvocationAdviceProvider(PostInvocationAuthorizationAdvice postAdvice) {
/* 51 */     this.postAdvice = postAdvice;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object decide(Authentication authentication, Object object, Collection<ConfigAttribute> config, Object returnedObject) throws AccessDeniedException {
/* 57 */     PostInvocationAttribute postInvocationAttribute = findPostInvocationAttribute(config);
/* 58 */     if (postInvocationAttribute == null) {
/* 59 */       return returnedObject;
/*    */     }
/* 61 */     return this.postAdvice.after(authentication, (MethodInvocation)object, postInvocationAttribute, returnedObject);
/*    */   }
/*    */ 
/*    */   
/*    */   private PostInvocationAttribute findPostInvocationAttribute(Collection<ConfigAttribute> config) {
/* 66 */     for (ConfigAttribute attribute : config) {
/* 67 */       if (attribute instanceof PostInvocationAttribute) {
/* 68 */         return (PostInvocationAttribute)attribute;
/*    */       }
/*    */     } 
/* 71 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(ConfigAttribute attribute) {
/* 76 */     return attribute instanceof PostInvocationAttribute;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(Class<?> clazz) {
/* 81 */     return MethodInvocation.class.isAssignableFrom(clazz);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\prepost\PostInvocationAdviceProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */