/*    */ package org.springframework.security.access.hierarchicalroles;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RoleHierarchyUtils
/*    */ {
/*    */   @Deprecated
/*    */   public static String roleHierarchyFromMap(Map<String, List<String>> roleHierarchyMap) {
/* 50 */     Assert.notEmpty(roleHierarchyMap, "roleHierarchyMap cannot be empty");
/* 51 */     StringWriter result = new StringWriter();
/* 52 */     PrintWriter writer = new PrintWriter(result);
/* 53 */     roleHierarchyMap.forEach((role, impliedRoles) -> {
/*    */           Assert.hasLength(role, "role name must be supplied");
/*    */           Assert.notEmpty(impliedRoles, "implied role name(s) cannot be empty");
/*    */           for (String impliedRole : impliedRoles) {
/*    */             writer.println(role + " > " + role);
/*    */           }
/*    */         });
/* 60 */     return result.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\hierarchicalroles\RoleHierarchyUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */