/*    */ package org.springframework.security.access.hierarchicalroles;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CycleInRoleHierarchyException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -4970510612118296707L;
/*    */   
/*    */   public CycleInRoleHierarchyException() {
/* 29 */     super("Exception thrown because of a cycle in the role hierarchy definition!");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\hierarchicalroles\CycleInRoleHierarchyException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */