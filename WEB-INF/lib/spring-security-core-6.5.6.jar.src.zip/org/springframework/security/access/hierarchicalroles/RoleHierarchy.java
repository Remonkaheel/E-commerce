package org.springframework.security.access.hierarchicalroles;

import java.util.Collection;
import org.springframework.security.core.GrantedAuthority;

public interface RoleHierarchy {
  Collection<? extends GrantedAuthority> getReachableGrantedAuthorities(Collection<? extends GrantedAuthority> paramCollection);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\hierarchicalroles\RoleHierarchy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */