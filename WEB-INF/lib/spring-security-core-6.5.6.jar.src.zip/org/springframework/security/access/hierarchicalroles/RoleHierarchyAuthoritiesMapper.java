/*    */ package org.springframework.security.access.hierarchicalroles;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RoleHierarchyAuthoritiesMapper
/*    */   implements GrantedAuthoritiesMapper
/*    */ {
/*    */   private final RoleHierarchy roleHierarchy;
/*    */   
/*    */   public RoleHierarchyAuthoritiesMapper(RoleHierarchy roleHierarchy) {
/* 32 */     this.roleHierarchy = roleHierarchy;
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<? extends GrantedAuthority> mapAuthorities(Collection<? extends GrantedAuthority> authorities) {
/* 37 */     return this.roleHierarchy.getReachableGrantedAuthorities(authorities);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\hierarchicalroles\RoleHierarchyAuthoritiesMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */