/*     */ package org.springframework.security.access.hierarchicalroles;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RoleHierarchyImpl
/*     */   implements RoleHierarchy
/*     */ {
/*  83 */   private static final Log logger = LogFactory.getLog(RoleHierarchyImpl.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   private Map<String, Set<GrantedAuthority>> rolesReachableInOneOrMoreStepsMap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public RoleHierarchyImpl() {}
/*     */ 
/*     */ 
/*     */   
/*     */   private RoleHierarchyImpl(Map<String, Set<GrantedAuthority>> hierarchy) {
/* 100 */     this.rolesReachableInOneOrMoreStepsMap = buildRolesReachableInOneOrMoreStepsMap(hierarchy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RoleHierarchyImpl fromHierarchy(String hierarchy) {
/* 116 */     return new RoleHierarchyImpl(buildRolesReachableInOneStepMap(hierarchy));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder withDefaultRolePrefix() {
/* 126 */     return withRolePrefix("ROLE_");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Builder withRolePrefix(String rolePrefix) {
/* 138 */     Assert.notNull(rolePrefix, "rolePrefix must not be null");
/* 139 */     return new Builder(rolePrefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setHierarchy(String roleHierarchyStringRepresentation) {
/* 153 */     logger.debug(LogMessage.format("setHierarchy() - The following role hierarchy was set: %s", roleHierarchyStringRepresentation));
/*     */     
/* 155 */     Map<String, Set<GrantedAuthority>> hierarchy = buildRolesReachableInOneStepMap(roleHierarchyStringRepresentation);
/*     */     
/* 157 */     this.rolesReachableInOneOrMoreStepsMap = buildRolesReachableInOneOrMoreStepsMap(hierarchy);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<GrantedAuthority> getReachableGrantedAuthorities(Collection<? extends GrantedAuthority> authorities) {
/* 163 */     if (authorities == null || authorities.isEmpty()) {
/* 164 */       return AuthorityUtils.NO_AUTHORITIES;
/*     */     }
/* 166 */     Set<GrantedAuthority> reachableRoles = new HashSet<>();
/* 167 */     Set<String> processedNames = new HashSet<>();
/* 168 */     for (GrantedAuthority authority : authorities) {
/*     */       
/* 170 */       if (authority.getAuthority() == null) {
/* 171 */         reachableRoles.add(authority);
/*     */         
/*     */         continue;
/*     */       } 
/* 175 */       if (!processedNames.add(authority.getAuthority())) {
/*     */         continue;
/*     */       }
/*     */       
/* 179 */       reachableRoles.add(authority);
/*     */       
/* 181 */       Set<GrantedAuthority> lowerRoles = this.rolesReachableInOneOrMoreStepsMap.get(authority.getAuthority());
/* 182 */       if (lowerRoles == null) {
/*     */         continue;
/*     */       }
/* 185 */       for (GrantedAuthority role : lowerRoles) {
/* 186 */         if (processedNames.add(role.getAuthority())) {
/* 187 */           reachableRoles.add(role);
/*     */         }
/*     */       } 
/*     */     } 
/* 191 */     logger.debug(LogMessage.format("getReachableGrantedAuthorities() - From the roles %s one can reach %s in zero or more steps.", authorities, reachableRoles));
/*     */ 
/*     */     
/* 194 */     return new ArrayList<>(reachableRoles);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<String, Set<GrantedAuthority>> buildRolesReachableInOneStepMap(String hierarchy) {
/* 202 */     Map<String, Set<GrantedAuthority>> rolesReachableInOneStepMap = new HashMap<>();
/* 203 */     for (String line : hierarchy.split("\n")) {
/*     */       
/* 205 */       String[] roles = line.trim().split("\\s+>\\s+");
/* 206 */       for (int i = 1; i < roles.length; i++) {
/* 207 */         Set<GrantedAuthority> rolesReachableInOneStepSet; String higherRole = roles[i - 1];
/* 208 */         SimpleGrantedAuthority simpleGrantedAuthority = new SimpleGrantedAuthority(roles[i]);
/*     */         
/* 210 */         if (!rolesReachableInOneStepMap.containsKey(higherRole)) {
/* 211 */           rolesReachableInOneStepSet = new HashSet<>();
/* 212 */           rolesReachableInOneStepMap.put(higherRole, rolesReachableInOneStepSet);
/*     */         } else {
/*     */           
/* 215 */           rolesReachableInOneStepSet = rolesReachableInOneStepMap.get(higherRole);
/*     */         } 
/* 217 */         rolesReachableInOneStepSet.add(simpleGrantedAuthority);
/* 218 */         logger.debug(LogMessage.format("buildRolesReachableInOneStepMap() - From role %s one can reach role %s in one step.", higherRole, simpleGrantedAuthority));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 223 */     return rolesReachableInOneStepMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<String, Set<GrantedAuthority>> buildRolesReachableInOneOrMoreStepsMap(Map<String, Set<GrantedAuthority>> hierarchy) {
/* 234 */     Map<String, Set<GrantedAuthority>> rolesReachableInOneOrMoreStepsMap = new HashMap<>();
/*     */     
/* 236 */     for (String roleName : hierarchy.keySet()) {
/* 237 */       Set<GrantedAuthority> rolesToVisitSet = new HashSet<>(hierarchy.get(roleName));
/* 238 */       Set<GrantedAuthority> visitedRolesSet = new HashSet<>();
/* 239 */       while (!rolesToVisitSet.isEmpty()) {
/*     */         
/* 241 */         GrantedAuthority lowerRole = rolesToVisitSet.iterator().next();
/* 242 */         rolesToVisitSet.remove(lowerRole);
/* 243 */         if (!visitedRolesSet.add(lowerRole) || !hierarchy.containsKey(lowerRole.getAuthority())) {
/*     */           continue;
/*     */         }
/* 246 */         if (roleName.equals(lowerRole.getAuthority())) {
/* 247 */           throw new CycleInRoleHierarchyException();
/*     */         }
/* 249 */         rolesToVisitSet.addAll(hierarchy.get(lowerRole.getAuthority()));
/*     */       } 
/* 251 */       rolesReachableInOneOrMoreStepsMap.put(roleName, visitedRolesSet);
/* 252 */       logger.debug(LogMessage.format("buildRolesReachableInOneOrMoreStepsMap() - From role %s one can reach %s in one or more steps.", roleName, visitedRolesSet));
/*     */     } 
/*     */ 
/*     */     
/* 256 */     return rolesReachableInOneOrMoreStepsMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private final String rolePrefix;
/*     */ 
/*     */ 
/*     */     
/*     */     private final Map<String, Set<GrantedAuthority>> hierarchy;
/*     */ 
/*     */ 
/*     */     
/*     */     private Builder(String rolePrefix) {
/* 273 */       this.rolePrefix = rolePrefix;
/* 274 */       this.hierarchy = new LinkedHashMap<>();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ImpliedRoles role(String role) {
/* 284 */       Assert.hasText(role, "role must not be empty");
/* 285 */       return new ImpliedRoles(role);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public RoleHierarchyImpl build() {
/* 294 */       return new RoleHierarchyImpl(this.hierarchy);
/*     */     }
/*     */     
/*     */     private Builder addHierarchy(String role, String... impliedRoles) {
/* 298 */       Set<GrantedAuthority> withPrefix = this.hierarchy.computeIfAbsent(this.rolePrefix.concat(role), r -> new HashSet());
/*     */       
/* 300 */       for (String impliedRole : impliedRoles) {
/* 301 */         withPrefix.add(new SimpleGrantedAuthority(this.rolePrefix.concat(impliedRole)));
/*     */       }
/* 303 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final class ImpliedRoles
/*     */     {
/*     */       private final String role;
/*     */ 
/*     */       
/*     */       private ImpliedRoles(String role) {
/* 314 */         this.role = role;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public RoleHierarchyImpl.Builder implies(String... impliedRoles)
/*     */       {
/* 325 */         Assert.notEmpty((Object[])impliedRoles, "at least one implied role must be provided");
/* 326 */         Assert.noNullElements((Object[])impliedRoles, "implied role name(s) cannot be empty");
/* 327 */         return RoleHierarchyImpl.Builder.this.addHierarchy(this.role, impliedRoles); } } } public final class ImpliedRoles { public RoleHierarchyImpl.Builder implies(String... impliedRoles) { Assert.notEmpty((Object[])impliedRoles, "at least one implied role must be provided"); Assert.noNullElements((Object[])impliedRoles, "implied role name(s) cannot be empty"); return RoleHierarchyImpl.Builder.this.addHierarchy(this.role, impliedRoles); }
/*     */ 
/*     */     
/*     */     private final String role;
/*     */     
/*     */     private ImpliedRoles(String role) {
/*     */       this.role = role;
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\hierarchicalroles\RoleHierarchyImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */