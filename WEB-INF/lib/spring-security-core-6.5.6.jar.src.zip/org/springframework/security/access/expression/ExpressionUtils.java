/*    */ package org.springframework.security.access.expression;
/*    */ 
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.EvaluationException;
/*    */ import org.springframework.expression.Expression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ExpressionUtils
/*    */ {
/*    */   public static boolean evaluateAsBoolean(Expression expr, EvaluationContext ctx) {
/*    */     try {
/* 30 */       return ((Boolean)expr.getValue(ctx, Boolean.class)).booleanValue();
/*    */     }
/* 32 */     catch (EvaluationException ex) {
/* 33 */       throw new IllegalArgumentException("Failed to evaluate expression '" + expr.getExpressionString() + "'", ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\expression\ExpressionUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */