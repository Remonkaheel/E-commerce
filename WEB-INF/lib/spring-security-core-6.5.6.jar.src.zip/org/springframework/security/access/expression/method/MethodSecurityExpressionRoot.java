/*    */ package org.springframework.security.access.expression.method;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.security.access.expression.SecurityExpressionRoot;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MethodSecurityExpressionRoot
/*    */   extends SecurityExpressionRoot
/*    */   implements MethodSecurityExpressionOperations
/*    */ {
/*    */   private Object filterObject;
/*    */   private Object returnObject;
/*    */   private Object target;
/*    */   
/*    */   MethodSecurityExpressionRoot(Authentication a) {
/* 40 */     super(a);
/*    */   }
/*    */   
/*    */   MethodSecurityExpressionRoot(Supplier<Authentication> authentication) {
/* 44 */     super(authentication);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setFilterObject(Object filterObject) {
/* 49 */     this.filterObject = filterObject;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getFilterObject() {
/* 54 */     return this.filterObject;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setReturnObject(Object returnObject) {
/* 59 */     this.returnObject = returnObject;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getReturnObject() {
/* 64 */     return this.returnObject;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void setThis(Object target) {
/* 74 */     this.target = target;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getThis() {
/* 79 */     return this.target;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\expression\method\MethodSecurityExpressionRoot.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */