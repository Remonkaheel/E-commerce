package org.springframework.security.access.expression.method;

import org.springframework.security.access.expression.SecurityExpressionOperations;

public interface MethodSecurityExpressionOperations extends SecurityExpressionOperations {
  void setFilterObject(Object paramObject);
  
  Object getFilterObject();
  
  void setReturnObject(Object paramObject);
  
  Object getReturnObject();
  
  Object getThis();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\expression\method\MethodSecurityExpressionOperations.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */