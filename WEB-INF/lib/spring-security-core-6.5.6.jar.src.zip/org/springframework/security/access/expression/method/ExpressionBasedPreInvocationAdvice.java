/*    */ package org.springframework.security.access.expression.method;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.security.access.expression.ExpressionUtils;
/*    */ import org.springframework.security.access.prepost.PreInvocationAttribute;
/*    */ import org.springframework.security.access.prepost.PreInvocationAuthorizationAdvice;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ExpressionBasedPreInvocationAdvice
/*    */   implements PreInvocationAuthorizationAdvice
/*    */ {
/* 43 */   private MethodSecurityExpressionHandler expressionHandler = new DefaultMethodSecurityExpressionHandler();
/*    */ 
/*    */   
/*    */   public boolean before(Authentication authentication, MethodInvocation mi, PreInvocationAttribute attr) {
/* 47 */     PreInvocationExpressionAttribute preAttr = (PreInvocationExpressionAttribute)attr;
/* 48 */     EvaluationContext ctx = this.expressionHandler.createEvaluationContext(authentication, mi);
/* 49 */     Expression preFilter = preAttr.getFilterExpression();
/* 50 */     Expression preAuthorize = preAttr.getAuthorizeExpression();
/* 51 */     if (preFilter != null) {
/* 52 */       Object filterTarget = findFilterTarget(preAttr.getFilterTarget(), ctx, mi);
/* 53 */       this.expressionHandler.filter(filterTarget, preFilter, ctx);
/*    */     } 
/* 55 */     return (preAuthorize != null) ? ExpressionUtils.evaluateAsBoolean(preAuthorize, ctx) : true;
/*    */   }
/*    */   
/*    */   private Object findFilterTarget(String filterTargetName, EvaluationContext ctx, MethodInvocation invocation) {
/* 59 */     Object filterTarget = null;
/* 60 */     if (filterTargetName.length() > 0) {
/* 61 */       filterTarget = ctx.lookupVariable(filterTargetName);
/* 62 */       Assert.notNull(filterTarget, () -> "Filter target was null, or no argument with name " + filterTargetName + " found in method");
/*    */     
/*    */     }
/* 65 */     else if ((invocation.getArguments()).length == 1) {
/* 66 */       Object arg = invocation.getArguments()[0];
/* 67 */       if (arg.getClass().isArray() || arg instanceof java.util.Collection) {
/* 68 */         filterTarget = arg;
/*    */       }
/* 70 */       Assert.notNull(filterTarget, () -> "A PreFilter expression was set but the method argument type" + String.valueOf(arg.getClass()) + " is not filterable");
/*    */     
/*    */     }
/* 73 */     else if ((invocation.getArguments()).length > 1) {
/* 74 */       throw new IllegalArgumentException("Unable to determine the method argument for filtering. Specify the filter target.");
/*    */     } 
/*    */     
/* 77 */     Assert.isTrue(!filterTarget.getClass().isArray(), "Pre-filtering on array types is not supported. Using a Collection will solve this problem");
/*    */     
/* 79 */     return filterTarget;
/*    */   }
/*    */   
/*    */   public void setExpressionHandler(MethodSecurityExpressionHandler expressionHandler) {
/* 83 */     this.expressionHandler = expressionHandler;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\expression\method\ExpressionBasedPreInvocationAdvice.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */