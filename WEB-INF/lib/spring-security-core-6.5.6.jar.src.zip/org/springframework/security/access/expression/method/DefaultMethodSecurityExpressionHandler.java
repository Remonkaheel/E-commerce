/*     */ package org.springframework.security.access.expression.method;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.security.access.PermissionCacheOptimizer;
/*     */ import org.springframework.security.access.expression.AbstractSecurityExpressionHandler;
/*     */ import org.springframework.security.access.expression.ExpressionUtils;
/*     */ import org.springframework.security.access.expression.SecurityExpressionOperations;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.parameters.DefaultSecurityParameterNameDiscoverer;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultMethodSecurityExpressionHandler
/*     */   extends AbstractSecurityExpressionHandler<MethodInvocation>
/*     */   implements MethodSecurityExpressionHandler
/*     */ {
/*  61 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  63 */   private AuthenticationTrustResolver trustResolver = (AuthenticationTrustResolver)new AuthenticationTrustResolverImpl();
/*     */   
/*  65 */   private ParameterNameDiscoverer parameterNameDiscoverer = (ParameterNameDiscoverer)new DefaultSecurityParameterNameDiscoverer();
/*     */   
/*  67 */   private PermissionCacheOptimizer permissionCacheOptimizer = null;
/*     */   
/*  69 */   private String defaultRolePrefix = "ROLE_";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StandardEvaluationContext createEvaluationContextInternal(Authentication auth, MethodInvocation mi) {
/*  80 */     return (StandardEvaluationContext)new MethodSecurityEvaluationContext(auth, mi, getParameterNameDiscoverer());
/*     */   }
/*     */ 
/*     */   
/*     */   public EvaluationContext createEvaluationContext(Supplier<Authentication> authentication, MethodInvocation mi) {
/*  85 */     MethodSecurityExpressionOperations root = createSecurityExpressionRoot(authentication, mi);
/*     */     
/*  87 */     MethodSecurityEvaluationContext ctx = new MethodSecurityEvaluationContext(root, mi, getParameterNameDiscoverer());
/*  88 */     ctx.setBeanResolver(getBeanResolver());
/*  89 */     return (EvaluationContext)ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MethodSecurityExpressionOperations createSecurityExpressionRoot(Authentication authentication, MethodInvocation invocation) {
/*  98 */     return createSecurityExpressionRoot(() -> authentication, invocation);
/*     */   }
/*     */ 
/*     */   
/*     */   private MethodSecurityExpressionOperations createSecurityExpressionRoot(Supplier<Authentication> authentication, MethodInvocation invocation) {
/* 103 */     MethodSecurityExpressionRoot root = new MethodSecurityExpressionRoot(authentication);
/* 104 */     root.setThis(invocation.getThis());
/* 105 */     root.setPermissionEvaluator(getPermissionEvaluator());
/* 106 */     root.setTrustResolver(getTrustResolver());
/* 107 */     root.setRoleHierarchy(getRoleHierarchy());
/* 108 */     root.setDefaultRolePrefix(getDefaultRolePrefix());
/* 109 */     return root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object filter(Object filterTarget, Expression filterExpression, EvaluationContext ctx) {
/* 124 */     MethodSecurityExpressionOperations rootObject = (MethodSecurityExpressionOperations)ctx.getRootObject().getValue();
/* 125 */     this.logger.debug(LogMessage.format("Filtering with expression: %s", filterExpression.getExpressionString()));
/* 126 */     if (filterTarget instanceof Collection) {
/* 127 */       return filterCollection((Collection)filterTarget, filterExpression, ctx, rootObject);
/*     */     }
/* 129 */     if (filterTarget.getClass().isArray()) {
/* 130 */       return filterArray((Object[])filterTarget, filterExpression, ctx, rootObject);
/*     */     }
/* 132 */     if (filterTarget instanceof Map) {
/* 133 */       return filterMap((Map<?, ?>)filterTarget, filterExpression, ctx, rootObject);
/*     */     }
/* 135 */     if (filterTarget instanceof Stream) {
/* 136 */       return filterStream((Stream)filterTarget, filterExpression, ctx, rootObject);
/*     */     }
/* 138 */     throw new IllegalArgumentException("Filter target must be a collection, array, map or stream type, but was " + String.valueOf(filterTarget));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private <T> Object filterCollection(Collection<T> filterTarget, Expression filterExpression, EvaluationContext ctx, MethodSecurityExpressionOperations rootObject) {
/* 144 */     this.logger.debug(LogMessage.format("Filtering collection with %s elements", Integer.valueOf(filterTarget.size())));
/* 145 */     List<T> retain = new ArrayList<>(filterTarget.size());
/* 146 */     if (this.permissionCacheOptimizer != null) {
/* 147 */       this.permissionCacheOptimizer.cachePermissionsFor(rootObject.getAuthentication(), filterTarget);
/*     */     }
/* 149 */     for (T filterObject : filterTarget) {
/* 150 */       rootObject.setFilterObject(filterObject);
/* 151 */       if (ExpressionUtils.evaluateAsBoolean(filterExpression, ctx)) {
/* 152 */         retain.add(filterObject);
/*     */       }
/*     */     } 
/* 155 */     this.logger.debug(LogMessage.format("Retaining elements: %s", retain));
/*     */     try {
/* 157 */       filterTarget.clear();
/* 158 */       filterTarget.addAll(retain);
/* 159 */       return filterTarget;
/*     */     }
/* 161 */     catch (UnsupportedOperationException readonly) {
/* 162 */       this.logger.trace(LogMessage.format("Collection threw exception: %s. Will return a new instance instead of mutating its state.", readonly
/*     */             
/* 164 */             .getMessage()));
/* 165 */       return retain;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Object filterArray(Object[] filterTarget, Expression filterExpression, EvaluationContext ctx, MethodSecurityExpressionOperations rootObject) {
/* 171 */     List<Object> retain = new ArrayList(filterTarget.length);
/* 172 */     this.logger.debug(LogMessage.format("Filtering array with %s elements", Integer.valueOf(filterTarget.length)));
/* 173 */     if (this.permissionCacheOptimizer != null) {
/* 174 */       this.permissionCacheOptimizer.cachePermissionsFor(rootObject.getAuthentication(), 
/* 175 */           Arrays.asList(filterTarget));
/*     */     }
/* 177 */     for (Object filterObject : filterTarget) {
/* 178 */       rootObject.setFilterObject(filterObject);
/* 179 */       if (ExpressionUtils.evaluateAsBoolean(filterExpression, ctx)) {
/* 180 */         retain.add(filterObject);
/*     */       }
/*     */     } 
/* 183 */     this.logger.debug(LogMessage.format("Retaining elements: %s", retain));
/* 184 */     Object[] filtered = (Object[])Array.newInstance(filterTarget.getClass().getComponentType(), retain.size());
/* 185 */     for (int i = 0; i < retain.size(); i++) {
/* 186 */       filtered[i] = retain.get(i);
/*     */     }
/* 188 */     return filtered;
/*     */   }
/*     */ 
/*     */   
/*     */   private <K, V> Object filterMap(Map<K, V> filterTarget, Expression filterExpression, EvaluationContext ctx, MethodSecurityExpressionOperations rootObject) {
/* 193 */     Map<K, V> retain = new LinkedHashMap<>(filterTarget.size());
/* 194 */     this.logger.debug(LogMessage.format("Filtering map with %s elements", Integer.valueOf(filterTarget.size())));
/* 195 */     for (Map.Entry<K, V> filterObject : filterTarget.entrySet()) {
/* 196 */       rootObject.setFilterObject(filterObject);
/* 197 */       if (ExpressionUtils.evaluateAsBoolean(filterExpression, ctx)) {
/* 198 */         retain.put(filterObject.getKey(), filterObject.getValue());
/*     */       }
/*     */     } 
/* 201 */     this.logger.debug(LogMessage.format("Retaining elements: %s", retain));
/*     */     try {
/* 203 */       filterTarget.clear();
/* 204 */       filterTarget.putAll(retain);
/* 205 */       return filterTarget;
/*     */     }
/* 207 */     catch (UnsupportedOperationException readonly) {
/* 208 */       this.logger.trace(LogMessage.format("Map threw exception: %s. Will return a new instance instead of mutating its state.", readonly
/*     */             
/* 210 */             .getMessage()));
/* 211 */       return retain;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object filterStream(Stream<?> filterTarget, Expression filterExpression, EvaluationContext ctx, MethodSecurityExpressionOperations rootObject) {
/* 220 */     Objects.requireNonNull(filterTarget); return filterTarget.filter(filterObject -> { rootObject.setFilterObject(filterObject); return ExpressionUtils.evaluateAsBoolean(filterExpression, ctx); }).onClose(filterTarget::close);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrustResolver(AuthenticationTrustResolver trustResolver) {
/* 230 */     Assert.notNull(trustResolver, "trustResolver cannot be null");
/* 231 */     this.trustResolver = trustResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AuthenticationTrustResolver getTrustResolver() {
/* 238 */     return this.trustResolver;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameterNameDiscoverer(ParameterNameDiscoverer parameterNameDiscoverer) {
/* 247 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ParameterNameDiscoverer getParameterNameDiscoverer() {
/* 254 */     return this.parameterNameDiscoverer;
/*     */   }
/*     */   
/*     */   public void setPermissionCacheOptimizer(PermissionCacheOptimizer permissionCacheOptimizer) {
/* 258 */     this.permissionCacheOptimizer = permissionCacheOptimizer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setReturnObject(Object returnObject, EvaluationContext ctx) {
/* 263 */     ((MethodSecurityExpressionOperations)ctx.getRootObject().getValue()).setReturnObject(returnObject);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultRolePrefix(String defaultRolePrefix) {
/* 282 */     this.defaultRolePrefix = defaultRolePrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDefaultRolePrefix() {
/* 289 */     return this.defaultRolePrefix;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\expression\method\DefaultMethodSecurityExpressionHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */