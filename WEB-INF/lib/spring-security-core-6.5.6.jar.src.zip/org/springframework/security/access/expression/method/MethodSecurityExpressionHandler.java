package org.springframework.security.access.expression.method;

import org.aopalliance.intercept.MethodInvocation;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.security.access.expression.SecurityExpressionHandler;

public interface MethodSecurityExpressionHandler extends SecurityExpressionHandler<MethodInvocation> {
  Object filter(Object paramObject, Expression paramExpression, EvaluationContext paramEvaluationContext);
  
  void setReturnObject(Object paramObject, EvaluationContext paramEvaluationContext);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\expression\method\MethodSecurityExpressionHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */