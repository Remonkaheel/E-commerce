/*     */ package org.springframework.security.access.expression;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.security.access.PermissionEvaluator;
/*     */ import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.function.SingletonSupplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SecurityExpressionRoot
/*     */   implements SecurityExpressionOperations
/*     */ {
/*     */   private final Supplier<Authentication> authentication;
/*     */   private AuthenticationTrustResolver trustResolver;
/*     */   private RoleHierarchy roleHierarchy;
/*     */   private Set<String> roles;
/*  50 */   private String defaultRolePrefix = "ROLE_";
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean permitAll = true;
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean denyAll = false;
/*     */ 
/*     */   
/*     */   private PermissionEvaluator permissionEvaluator;
/*     */ 
/*     */   
/*  64 */   public final String read = "read";
/*     */   
/*  66 */   public final String write = "write";
/*     */   
/*  68 */   public final String create = "create";
/*     */   
/*  70 */   public final String delete = "delete";
/*     */   
/*  72 */   public final String admin = "administration";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SecurityExpressionRoot(Authentication authentication) {
/*  79 */     this(() -> authentication);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SecurityExpressionRoot(Supplier<Authentication> authentication) {
/*  90 */     this.authentication = (Supplier<Authentication>)SingletonSupplier.of(() -> {
/*     */           Authentication value = authentication.get();
/*     */           Assert.notNull(value, "Authentication object cannot be null");
/*     */           return value;
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean hasAuthority(String authority) {
/*  99 */     return hasAnyAuthority(new String[] { authority });
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean hasAnyAuthority(String... authorities) {
/* 104 */     return hasAnyAuthorityName(null, authorities);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean hasRole(String role) {
/* 109 */     return hasAnyRole(new String[] { role });
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean hasAnyRole(String... roles) {
/* 114 */     return hasAnyAuthorityName(this.defaultRolePrefix, roles);
/*     */   }
/*     */   
/*     */   private boolean hasAnyAuthorityName(String prefix, String... roles) {
/* 118 */     Set<String> roleSet = getAuthoritySet();
/* 119 */     for (String role : roles) {
/* 120 */       String defaultedRole = getRoleWithDefaultPrefix(prefix, role);
/* 121 */       if (roleSet.contains(defaultedRole)) {
/* 122 */         return true;
/*     */       }
/*     */     } 
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public final Authentication getAuthentication() {
/* 130 */     return this.authentication.get();
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean permitAll() {
/* 135 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean denyAll() {
/* 140 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isAnonymous() {
/* 145 */     return this.trustResolver.isAnonymous(getAuthentication());
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isAuthenticated() {
/* 150 */     return this.trustResolver.isAuthenticated(getAuthentication());
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isRememberMe() {
/* 155 */     return this.trustResolver.isRememberMe(getAuthentication());
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isFullyAuthenticated() {
/* 160 */     Authentication authentication = getAuthentication();
/* 161 */     return this.trustResolver.isFullyAuthenticated(authentication);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getPrincipal() {
/* 170 */     return getAuthentication().getPrincipal();
/*     */   }
/*     */   
/*     */   public void setTrustResolver(AuthenticationTrustResolver trustResolver) {
/* 174 */     this.trustResolver = trustResolver;
/*     */   }
/*     */   
/*     */   public void setRoleHierarchy(RoleHierarchy roleHierarchy) {
/* 178 */     this.roleHierarchy = roleHierarchy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultRolePrefix(String defaultRolePrefix) {
/* 195 */     this.defaultRolePrefix = defaultRolePrefix;
/*     */   }
/*     */   
/*     */   private Set<String> getAuthoritySet() {
/* 199 */     if (this.roles == null) {
/* 200 */       Collection<? extends GrantedAuthority> userAuthorities = getAuthentication().getAuthorities();
/* 201 */       if (this.roleHierarchy != null) {
/* 202 */         userAuthorities = this.roleHierarchy.getReachableGrantedAuthorities(userAuthorities);
/*     */       }
/* 204 */       this.roles = AuthorityUtils.authorityListToSet(userAuthorities);
/*     */     } 
/* 206 */     return this.roles;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasPermission(Object target, Object permission) {
/* 211 */     return this.permissionEvaluator.hasPermission(getAuthentication(), target, permission);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasPermission(Object targetId, String targetType, Object permission) {
/* 216 */     return this.permissionEvaluator.hasPermission(getAuthentication(), (Serializable)targetId, targetType, permission);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPermissionEvaluator(PermissionEvaluator permissionEvaluator) {
/* 221 */     this.permissionEvaluator = permissionEvaluator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getRoleWithDefaultPrefix(String defaultRolePrefix, String role) {
/* 232 */     if (role == null) {
/* 233 */       return role;
/*     */     }
/* 235 */     if (defaultRolePrefix == null || defaultRolePrefix.length() == 0) {
/* 236 */       return role;
/*     */     }
/* 238 */     if (role.startsWith(defaultRolePrefix)) {
/* 239 */       return role;
/*     */     }
/* 241 */     return defaultRolePrefix + defaultRolePrefix;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\expression\SecurityExpressionRoot.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */