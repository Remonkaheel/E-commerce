/*    */ package org.springframework.security.access.expression.method;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.security.access.expression.ExpressionUtils;
/*    */ import org.springframework.security.access.prepost.PostInvocationAttribute;
/*    */ import org.springframework.security.access.prepost.PostInvocationAuthorizationAdvice;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ExpressionBasedPostInvocationAdvice
/*    */   implements PostInvocationAuthorizationAdvice
/*    */ {
/* 42 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   private final MethodSecurityExpressionHandler expressionHandler;
/*    */   
/*    */   public ExpressionBasedPostInvocationAdvice(MethodSecurityExpressionHandler expressionHandler) {
/* 47 */     this.expressionHandler = expressionHandler;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object after(Authentication authentication, MethodInvocation mi, PostInvocationAttribute postAttr, Object returnedObject) throws AccessDeniedException {
/* 53 */     PostInvocationExpressionAttribute pia = (PostInvocationExpressionAttribute)postAttr;
/* 54 */     EvaluationContext ctx = this.expressionHandler.createEvaluationContext(authentication, mi);
/* 55 */     Expression postFilter = pia.getFilterExpression();
/* 56 */     Expression postAuthorize = pia.getAuthorizeExpression();
/* 57 */     if (postFilter != null) {
/* 58 */       this.logger.debug(LogMessage.format("Applying PostFilter expression %s", postFilter));
/* 59 */       if (returnedObject != null) {
/* 60 */         returnedObject = this.expressionHandler.filter(returnedObject, postFilter, ctx);
/*    */       } else {
/*    */         
/* 63 */         this.logger.debug("Return object is null, filtering will be skipped");
/*    */       } 
/*    */     } 
/* 66 */     this.expressionHandler.setReturnObject(returnedObject, ctx);
/* 67 */     if (postAuthorize != null && !ExpressionUtils.evaluateAsBoolean(postAuthorize, ctx)) {
/* 68 */       this.logger.debug("PostAuthorize expression rejected access");
/* 69 */       throw new AccessDeniedException("Access is denied");
/*    */     } 
/* 71 */     return returnedObject;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\expression\method\ExpressionBasedPostInvocationAdvice.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */