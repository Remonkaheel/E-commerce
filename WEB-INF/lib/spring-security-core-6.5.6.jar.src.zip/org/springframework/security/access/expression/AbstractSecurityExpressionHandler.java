/*     */ package org.springframework.security.access.expression;
/*     */ 
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.expression.BeanFactoryResolver;
/*     */ import org.springframework.expression.BeanResolver;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.security.access.PermissionEvaluator;
/*     */ import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractSecurityExpressionHandler<T>
/*     */   implements SecurityExpressionHandler<T>, ApplicationContextAware
/*     */ {
/*  44 */   private ExpressionParser expressionParser = (ExpressionParser)new SpelExpressionParser();
/*     */   
/*     */   private BeanResolver beanResolver;
/*     */   
/*     */   private RoleHierarchy roleHierarchy;
/*     */   
/*  50 */   private PermissionEvaluator permissionEvaluator = new DenyAllPermissionEvaluator();
/*     */ 
/*     */   
/*     */   public final ExpressionParser getExpressionParser() {
/*  54 */     return this.expressionParser;
/*     */   }
/*     */   
/*     */   public final void setExpressionParser(ExpressionParser expressionParser) {
/*  58 */     Assert.notNull(expressionParser, "expressionParser cannot be null");
/*  59 */     this.expressionParser = expressionParser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final EvaluationContext createEvaluationContext(Authentication authentication, T invocation) {
/*  72 */     SecurityExpressionOperations root = createSecurityExpressionRoot(authentication, invocation);
/*  73 */     StandardEvaluationContext ctx = createEvaluationContextInternal(authentication, invocation);
/*  74 */     ctx.setBeanResolver(this.beanResolver);
/*  75 */     ctx.setRootObject(root);
/*  76 */     return (EvaluationContext)ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StandardEvaluationContext createEvaluationContextInternal(Authentication authentication, T invocation) {
/*  91 */     return new StandardEvaluationContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract SecurityExpressionOperations createSecurityExpressionRoot(Authentication paramAuthentication, T paramT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RoleHierarchy getRoleHierarchy() {
/* 105 */     return this.roleHierarchy;
/*     */   }
/*     */   
/*     */   public void setRoleHierarchy(RoleHierarchy roleHierarchy) {
/* 109 */     this.roleHierarchy = roleHierarchy;
/*     */   }
/*     */   
/*     */   protected PermissionEvaluator getPermissionEvaluator() {
/* 113 */     return this.permissionEvaluator;
/*     */   }
/*     */   
/*     */   public void setPermissionEvaluator(PermissionEvaluator permissionEvaluator) {
/* 117 */     this.permissionEvaluator = permissionEvaluator;
/*     */   }
/*     */   
/*     */   protected BeanResolver getBeanResolver() {
/* 121 */     return this.beanResolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext applicationContext) {
/* 126 */     this.beanResolver = (BeanResolver)new BeanFactoryResolver((BeanFactory)applicationContext);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\expression\AbstractSecurityExpressionHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */