/*    */ package org.springframework.security.access.expression;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.aop.framework.AopInfrastructureBean;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.ExpressionParser;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SecurityExpressionHandler<T>
/*    */   extends AopInfrastructureBean
/*    */ {
/*    */   ExpressionParser getExpressionParser();
/*    */   
/*    */   EvaluationContext createEvaluationContext(Authentication paramAuthentication, T paramT);
/*    */   
/*    */   default EvaluationContext createEvaluationContext(Supplier<Authentication> authentication, T invocation) {
/* 59 */     return createEvaluationContext(authentication.get(), invocation);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\expression\SecurityExpressionHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */