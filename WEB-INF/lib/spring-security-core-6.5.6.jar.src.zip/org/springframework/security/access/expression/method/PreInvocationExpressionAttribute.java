/*    */ package org.springframework.security.access.expression.method;
/*    */ 
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.expression.ParseException;
/*    */ import org.springframework.security.access.prepost.PreInvocationAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ class PreInvocationExpressionAttribute
/*    */   extends AbstractExpressionBasedMethodConfigAttribute
/*    */   implements PreInvocationAttribute
/*    */ {
/*    */   private final String filterTarget;
/*    */   
/*    */   PreInvocationExpressionAttribute(String filterExpression, String filterTarget, String authorizeExpression) throws ParseException {
/* 39 */     super(filterExpression, authorizeExpression);
/* 40 */     this.filterTarget = filterTarget;
/*    */   }
/*    */ 
/*    */   
/*    */   PreInvocationExpressionAttribute(Expression filterExpression, String filterTarget, Expression authorizeExpression) throws ParseException {
/* 45 */     super(filterExpression, authorizeExpression);
/* 46 */     this.filterTarget = filterTarget;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getFilterTarget() {
/* 55 */     return this.filterTarget;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 60 */     StringBuilder sb = new StringBuilder();
/* 61 */     Expression authorize = getAuthorizeExpression();
/* 62 */     Expression filter = getFilterExpression();
/* 63 */     sb.append("[authorize: '").append((authorize != null) ? authorize.getExpressionString() : "null");
/* 64 */     sb.append("', filter: '").append((filter != null) ? filter.getExpressionString() : "null");
/* 65 */     sb.append("', filterTarget: '").append(this.filterTarget).append("']");
/* 66 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\expression\method\PreInvocationExpressionAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */