/*    */ package org.springframework.security.access.expression.method;
/*    */ 
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.expression.ParseException;
/*    */ import org.springframework.security.access.prepost.PostInvocationAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ class PostInvocationExpressionAttribute
/*    */   extends AbstractExpressionBasedMethodConfigAttribute
/*    */   implements PostInvocationAttribute
/*    */ {
/*    */   PostInvocationExpressionAttribute(String filterExpression, String authorizeExpression) throws ParseException {
/* 36 */     super(filterExpression, authorizeExpression);
/*    */   }
/*    */ 
/*    */   
/*    */   PostInvocationExpressionAttribute(Expression filterExpression, Expression authorizeExpression) throws ParseException {
/* 41 */     super(filterExpression, authorizeExpression);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 46 */     StringBuilder sb = new StringBuilder();
/* 47 */     Expression authorize = getAuthorizeExpression();
/* 48 */     Expression filter = getFilterExpression();
/* 49 */     sb.append("[authorize: '").append((authorize != null) ? authorize.getExpressionString() : "null");
/* 50 */     sb.append("', filter: '").append((filter != null) ? filter.getExpressionString() : "null").append("']");
/* 51 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\expression\method\PostInvocationExpressionAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */