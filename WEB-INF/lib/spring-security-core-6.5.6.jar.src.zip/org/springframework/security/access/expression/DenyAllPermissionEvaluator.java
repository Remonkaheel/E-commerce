/*    */ package org.springframework.security.access.expression;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.security.access.PermissionEvaluator;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DenyAllPermissionEvaluator
/*    */   implements PermissionEvaluator
/*    */ {
/* 37 */   private final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasPermission(Authentication authentication, Object target, Object permission) {
/* 44 */     this.logger.warn(LogMessage.format("Denying user %s permission '%s' on object %s", authentication.getName(), permission, target));
/*    */     
/* 46 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasPermission(Authentication authentication, Serializable targetId, String targetType, Object permission) {
/* 55 */     this.logger.warn(LogMessage.format("Denying user %s permission '%s' on object with Id %s", authentication
/* 56 */           .getName(), permission, targetId));
/* 57 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\expression\DenyAllPermissionEvaluator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */