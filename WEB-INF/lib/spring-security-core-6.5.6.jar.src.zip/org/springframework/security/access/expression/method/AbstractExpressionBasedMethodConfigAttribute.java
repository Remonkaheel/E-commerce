/*    */ package org.springframework.security.access.expression.method;
/*    */ 
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.expression.ParseException;
/*    */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ abstract class AbstractExpressionBasedMethodConfigAttribute
/*    */   implements ConfigAttribute
/*    */ {
/*    */   private final Expression filterExpression;
/*    */   private final Expression authorizeExpression;
/*    */   
/*    */   AbstractExpressionBasedMethodConfigAttribute(String filterExpression, String authorizeExpression) throws ParseException {
/* 50 */     Assert.isTrue((filterExpression != null || authorizeExpression != null), "Filter and authorization Expressions cannot both be null");
/*    */     
/* 52 */     SpelExpressionParser parser = new SpelExpressionParser();
/* 53 */     this.filterExpression = (filterExpression != null) ? parser.parseExpression(filterExpression) : null;
/* 54 */     this.authorizeExpression = (authorizeExpression != null) ? parser.parseExpression(authorizeExpression) : null;
/*    */   }
/*    */ 
/*    */   
/*    */   AbstractExpressionBasedMethodConfigAttribute(Expression filterExpression, Expression authorizeExpression) throws ParseException {
/* 59 */     Assert.isTrue((filterExpression != null || authorizeExpression != null), "Filter and authorization Expressions cannot both be null");
/*    */     
/* 61 */     this.filterExpression = (filterExpression != null) ? filterExpression : null;
/* 62 */     this.authorizeExpression = (authorizeExpression != null) ? authorizeExpression : null;
/*    */   }
/*    */   
/*    */   Expression getFilterExpression() {
/* 66 */     return this.filterExpression;
/*    */   }
/*    */   
/*    */   Expression getAuthorizeExpression() {
/* 70 */     return this.authorizeExpression;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAttribute() {
/* 75 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\expression\method\AbstractExpressionBasedMethodConfigAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */