/*    */ package org.springframework.security.access.expression.method;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.aop.framework.AopProxyUtils;
/*    */ import org.springframework.aop.support.AopUtils;
/*    */ import org.springframework.context.expression.MethodBasedEvaluationContext;
/*    */ import org.springframework.core.ParameterNameDiscoverer;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.parameters.DefaultSecurityParameterNameDiscoverer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MethodSecurityEvaluationContext
/*    */   extends MethodBasedEvaluationContext
/*    */ {
/*    */   MethodSecurityEvaluationContext(Authentication user, MethodInvocation mi) {
/* 48 */     this(user, mi, (ParameterNameDiscoverer)new DefaultSecurityParameterNameDiscoverer());
/*    */   }
/*    */ 
/*    */   
/*    */   MethodSecurityEvaluationContext(Authentication user, MethodInvocation mi, ParameterNameDiscoverer parameterNameDiscoverer) {
/* 53 */     super(mi.getThis(), getSpecificMethod(mi), mi.getArguments(), parameterNameDiscoverer);
/*    */   }
/*    */ 
/*    */   
/*    */   MethodSecurityEvaluationContext(MethodSecurityExpressionOperations root, MethodInvocation mi, ParameterNameDiscoverer parameterNameDiscoverer) {
/* 58 */     super(root, getSpecificMethod(mi), mi.getArguments(), parameterNameDiscoverer);
/*    */   }
/*    */   
/*    */   private static Method getSpecificMethod(MethodInvocation mi) {
/* 62 */     return AopUtils.getMostSpecificMethod(mi.getMethod(), AopProxyUtils.ultimateTargetClass(mi.getThis()));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\expression\method\MethodSecurityEvaluationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */