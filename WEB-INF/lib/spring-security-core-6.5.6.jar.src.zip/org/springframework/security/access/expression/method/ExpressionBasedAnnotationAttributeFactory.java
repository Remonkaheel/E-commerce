/*    */ package org.springframework.security.access.expression.method;
/*    */ 
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.expression.ExpressionParser;
/*    */ import org.springframework.expression.ParseException;
/*    */ import org.springframework.security.access.prepost.PostInvocationAttribute;
/*    */ import org.springframework.security.access.prepost.PreInvocationAttribute;
/*    */ import org.springframework.security.access.prepost.PrePostInvocationAttributeFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ExpressionBasedAnnotationAttributeFactory
/*    */   implements PrePostInvocationAttributeFactory
/*    */ {
/* 39 */   private final Object parserLock = new Object();
/*    */   
/*    */   private ExpressionParser parser;
/*    */   
/*    */   private MethodSecurityExpressionHandler handler;
/*    */   
/*    */   public ExpressionBasedAnnotationAttributeFactory(MethodSecurityExpressionHandler handler) {
/* 46 */     this.handler = handler;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PreInvocationAttribute createPreInvocationAttribute(String preFilterAttribute, String filterObject, String preAuthorizeAttribute) {
/*    */     try {
/* 54 */       ExpressionParser parser = getParser();
/*    */       
/* 56 */       Expression preAuthorizeExpression = (preAuthorizeAttribute != null) ? parser.parseExpression(preAuthorizeAttribute) : parser.parseExpression("permitAll");
/*    */       
/* 58 */       Expression preFilterExpression = (preFilterAttribute != null) ? parser.parseExpression(preFilterAttribute) : null;
/* 59 */       return new PreInvocationExpressionAttribute(preFilterExpression, filterObject, preAuthorizeExpression);
/*    */     }
/* 61 */     catch (ParseException ex) {
/* 62 */       throw new IllegalArgumentException("Failed to parse expression '" + ex.getExpressionString() + "'", ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public PostInvocationAttribute createPostInvocationAttribute(String postFilterAttribute, String postAuthorizeAttribute) {
/*    */     try {
/* 70 */       ExpressionParser parser = getParser();
/*    */       
/* 72 */       Expression postAuthorizeExpression = (postAuthorizeAttribute != null) ? parser.parseExpression(postAuthorizeAttribute) : null;
/*    */       
/* 74 */       Expression postFilterExpression = (postFilterAttribute != null) ? parser.parseExpression(postFilterAttribute) : null;
/* 75 */       if (postFilterExpression != null || postAuthorizeExpression != null) {
/* 76 */         return new PostInvocationExpressionAttribute(postFilterExpression, postAuthorizeExpression);
/*    */       }
/*    */     }
/* 79 */     catch (ParseException ex) {
/* 80 */       throw new IllegalArgumentException("Failed to parse expression '" + ex.getExpressionString() + "'", ex);
/*    */     } 
/*    */     
/* 83 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private ExpressionParser getParser() {
/* 91 */     if (this.parser != null) {
/* 92 */       return this.parser;
/*    */     }
/* 94 */     synchronized (this.parserLock) {
/* 95 */       this.parser = this.handler.getExpressionParser();
/* 96 */       this.handler = null;
/*    */     } 
/* 98 */     return this.parser;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\expression\method\ExpressionBasedAnnotationAttributeFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */