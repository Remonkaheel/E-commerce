package org.springframework.security.access;

import java.util.Collection;
import org.springframework.security.core.Authentication;

@Deprecated
public interface AccessDecisionVoter<S> {
  public static final int ACCESS_GRANTED = 1;
  
  public static final int ACCESS_ABSTAIN = 0;
  
  public static final int ACCESS_DENIED = -1;
  
  boolean supports(ConfigAttribute paramConfigAttribute);
  
  boolean supports(Class<?> paramClass);
  
  int vote(Authentication paramAuthentication, S paramS, Collection<ConfigAttribute> paramCollection);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\AccessDecisionVoter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */