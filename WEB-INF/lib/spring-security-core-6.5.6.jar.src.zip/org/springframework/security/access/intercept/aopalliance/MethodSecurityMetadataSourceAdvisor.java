/*     */ package org.springframework.security.access.intercept.aopalliance;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.support.AbstractPointcutAdvisor;
/*     */ import org.springframework.aop.support.StaticMethodMatcherPointcut;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.security.access.method.MethodSecurityMetadataSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class MethodSecurityMetadataSourceAdvisor
/*     */   extends AbstractPointcutAdvisor
/*     */   implements BeanFactoryAware
/*     */ {
/*     */   private transient MethodSecurityMetadataSource attributeSource;
/*     */   private transient MethodInterceptor interceptor;
/*  64 */   private final Pointcut pointcut = (Pointcut)new MethodSecurityMetadataSourcePointcut();
/*     */   
/*     */   private BeanFactory beanFactory;
/*     */   
/*     */   private final String adviceBeanName;
/*     */   
/*     */   private final String metadataSourceBeanName;
/*     */   
/*  72 */   private volatile transient Object adviceMonitor = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodSecurityMetadataSourceAdvisor(String adviceBeanName, MethodSecurityMetadataSource attributeSource, String attributeSourceBeanName) {
/*  88 */     Assert.notNull(adviceBeanName, "The adviceBeanName cannot be null");
/*  89 */     Assert.notNull(attributeSource, "The attributeSource cannot be null");
/*  90 */     Assert.notNull(attributeSourceBeanName, "The attributeSourceBeanName cannot be null");
/*  91 */     this.adviceBeanName = adviceBeanName;
/*  92 */     this.attributeSource = attributeSource;
/*  93 */     this.metadataSourceBeanName = attributeSourceBeanName;
/*     */   }
/*     */ 
/*     */   
/*     */   public Pointcut getPointcut() {
/*  98 */     return this.pointcut;
/*     */   }
/*     */ 
/*     */   
/*     */   public Advice getAdvice() {
/* 103 */     synchronized (this.adviceMonitor) {
/* 104 */       if (this.interceptor == null) {
/* 105 */         Assert.notNull(this.adviceBeanName, "'adviceBeanName' must be set for use with bean factory lookup.");
/* 106 */         Assert.state((this.beanFactory != null), "BeanFactory must be set to resolve 'adviceBeanName'");
/* 107 */         this.interceptor = (MethodInterceptor)this.beanFactory.getBean(this.adviceBeanName, MethodInterceptor.class);
/*     */       } 
/* 109 */       return (Advice)this.interceptor;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 115 */     this.beanFactory = beanFactory;
/*     */   }
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 119 */     ois.defaultReadObject();
/* 120 */     this.adviceMonitor = new Object();
/* 121 */     this.attributeSource = (MethodSecurityMetadataSource)this.beanFactory.getBean(this.metadataSourceBeanName, MethodSecurityMetadataSource.class);
/*     */   }
/*     */   
/*     */   class MethodSecurityMetadataSourcePointcut
/*     */     extends StaticMethodMatcherPointcut
/*     */     implements Serializable
/*     */   {
/*     */     public boolean matches(Method m, Class<?> targetClass) {
/* 129 */       MethodSecurityMetadataSource source = MethodSecurityMetadataSourceAdvisor.this.attributeSource;
/* 130 */       return !CollectionUtils.isEmpty(source.getAttributes(m, targetClass));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\intercept\aopalliance\MethodSecurityMetadataSourceAdvisor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */