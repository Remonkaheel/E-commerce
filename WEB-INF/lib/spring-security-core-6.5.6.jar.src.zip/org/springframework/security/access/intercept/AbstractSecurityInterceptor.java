/*     */ package org.springframework.security.access.intercept;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.access.AccessDecisionManager;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.access.SecurityMetadataSource;
/*     */ import org.springframework.security.access.event.AuthenticationCredentialsNotFoundEvent;
/*     */ import org.springframework.security.access.event.AuthorizationFailureEvent;
/*     */ import org.springframework.security.access.event.AuthorizedEvent;
/*     */ import org.springframework.security.access.event.PublicInvocationEvent;
/*     */ import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.AuthenticationServiceException;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class AbstractSecurityInterceptor
/*     */   implements InitializingBean, ApplicationEventPublisherAware, MessageSourceAware
/*     */ {
/* 121 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/* 123 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */ 
/*     */   
/* 126 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/*     */   private ApplicationEventPublisher eventPublisher;
/*     */   
/*     */   private AccessDecisionManager accessDecisionManager;
/*     */   
/*     */   private AfterInvocationManager afterInvocationManager;
/*     */   
/* 134 */   private AuthenticationManager authenticationManager = new NoOpAuthenticationManager();
/*     */   
/* 136 */   private RunAsManager runAsManager = new NullRunAsManager();
/*     */   
/*     */   private boolean alwaysReauthenticate = false;
/*     */   
/*     */   private boolean rejectPublicInvocations = false;
/*     */   
/*     */   private boolean validateConfigAttributes = true;
/*     */   
/*     */   private boolean publishAuthorizationSuccess = false;
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 148 */     Assert.notNull(getSecureObjectClass(), "Subclass must provide a non-null response to getSecureObjectClass()");
/* 149 */     Assert.notNull(this.messages, "A message source must be set");
/* 150 */     Assert.notNull(this.authenticationManager, "An AuthenticationManager is required");
/* 151 */     Assert.notNull(this.accessDecisionManager, "An AccessDecisionManager is required");
/* 152 */     Assert.notNull(this.runAsManager, "A RunAsManager is required");
/* 153 */     Assert.notNull(obtainSecurityMetadataSource(), "An SecurityMetadataSource is required");
/* 154 */     Assert.isTrue(obtainSecurityMetadataSource().supports(getSecureObjectClass()), () -> "SecurityMetadataSource does not support secure object class: " + String.valueOf(getSecureObjectClass()));
/*     */     
/* 156 */     Assert.isTrue(this.runAsManager.supports(getSecureObjectClass()), () -> "RunAsManager does not support secure object class: " + String.valueOf(getSecureObjectClass()));
/*     */     
/* 158 */     Assert.isTrue(this.accessDecisionManager.supports(getSecureObjectClass()), () -> "AccessDecisionManager does not support secure object class: " + String.valueOf(getSecureObjectClass()));
/*     */     
/* 160 */     if (this.afterInvocationManager != null) {
/* 161 */       Assert.isTrue(this.afterInvocationManager.supports(getSecureObjectClass()), () -> "AfterInvocationManager does not support secure object class: " + String.valueOf(getSecureObjectClass()));
/*     */     }
/*     */     
/* 164 */     if (this.validateConfigAttributes) {
/* 165 */       Collection<ConfigAttribute> attributeDefs = obtainSecurityMetadataSource().getAllConfigAttributes();
/* 166 */       if (attributeDefs == null) {
/* 167 */         this.logger.warn("Could not validate configuration attributes as the SecurityMetadataSource did not return any attributes from getAllConfigAttributes()");
/*     */         
/*     */         return;
/*     */       } 
/* 171 */       validateAttributeDefs(attributeDefs);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void validateAttributeDefs(Collection<ConfigAttribute> attributeDefs) {
/* 176 */     Set<ConfigAttribute> unsupportedAttrs = new HashSet<>();
/* 177 */     for (ConfigAttribute attr : attributeDefs) {
/* 178 */       if (!this.runAsManager.supports(attr) && !this.accessDecisionManager.supports(attr) && (this.afterInvocationManager == null || 
/* 179 */         !this.afterInvocationManager.supports(attr))) {
/* 180 */         unsupportedAttrs.add(attr);
/*     */       }
/*     */     } 
/* 183 */     if (unsupportedAttrs.size() != 0) {
/* 184 */       this.logger
/* 185 */         .trace("Did not validate configuration attributes since validateConfigurationAttributes is false");
/* 186 */       throw new IllegalArgumentException("Unsupported configuration attributes: " + String.valueOf(unsupportedAttrs));
/*     */     } 
/*     */     
/* 189 */     this.logger.trace("Validated configuration attributes");
/*     */   }
/*     */ 
/*     */   
/*     */   protected InterceptorStatusToken beforeInvocation(Object object) {
/* 194 */     Assert.notNull(object, "Object was null");
/* 195 */     if (!getSecureObjectClass().isAssignableFrom(object.getClass())) {
/* 196 */       throw new IllegalArgumentException("Security invocation attempted for object " + object.getClass().getName() + " but AbstractSecurityInterceptor only configured to support secure objects of type: " + 
/*     */           
/* 198 */           String.valueOf(getSecureObjectClass()));
/*     */     }
/* 200 */     Collection<ConfigAttribute> attributes = obtainSecurityMetadataSource().getAttributes(object);
/* 201 */     if (CollectionUtils.isEmpty(attributes)) {
/* 202 */       Assert.isTrue(!this.rejectPublicInvocations, () -> "Secure object invocation " + String.valueOf(object) + " was denied as public invocations are not allowed via this interceptor. This indicates a configuration error because the rejectPublicInvocations property is set to 'true'");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 207 */       if (this.logger.isDebugEnabled()) {
/* 208 */         this.logger.debug(LogMessage.format("Authorized public object %s", object));
/*     */       }
/* 210 */       publishEvent((ApplicationEvent)new PublicInvocationEvent(object));
/* 211 */       return null;
/*     */     } 
/* 213 */     if (this.securityContextHolderStrategy.getContext().getAuthentication() == null) {
/* 214 */       credentialsNotFound(this.messages.getMessage("AbstractSecurityInterceptor.authenticationNotFound", "An Authentication object was not found in the SecurityContext"), object, attributes);
/*     */     }
/*     */     
/* 217 */     Authentication authenticated = authenticateIfRequired();
/* 218 */     if (this.logger.isTraceEnabled()) {
/* 219 */       this.logger.trace(LogMessage.format("Authorizing %s with attributes %s", object, attributes));
/*     */     }
/*     */     
/* 222 */     attemptAuthorization(object, attributes, authenticated);
/* 223 */     if (this.logger.isDebugEnabled()) {
/* 224 */       this.logger.debug(LogMessage.format("Authorized %s with attributes %s", object, attributes));
/*     */     }
/* 226 */     if (this.publishAuthorizationSuccess) {
/* 227 */       publishEvent((ApplicationEvent)new AuthorizedEvent(object, attributes, authenticated));
/*     */     }
/*     */ 
/*     */     
/* 231 */     Authentication runAs = this.runAsManager.buildRunAs(authenticated, object, attributes);
/* 232 */     if (runAs != null) {
/* 233 */       SecurityContext origCtx = this.securityContextHolderStrategy.getContext();
/* 234 */       SecurityContext newCtx = this.securityContextHolderStrategy.createEmptyContext();
/* 235 */       newCtx.setAuthentication(runAs);
/* 236 */       this.securityContextHolderStrategy.setContext(newCtx);
/*     */       
/* 238 */       if (this.logger.isDebugEnabled()) {
/* 239 */         this.logger.debug(LogMessage.format("Switched to RunAs authentication %s", runAs));
/*     */       }
/*     */       
/* 242 */       return new InterceptorStatusToken(origCtx, true, attributes, object);
/*     */     } 
/* 244 */     this.logger.trace("Did not switch RunAs authentication since RunAsManager returned null");
/*     */     
/* 246 */     return new InterceptorStatusToken(this.securityContextHolderStrategy.getContext(), false, attributes, object);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void attemptAuthorization(Object object, Collection<ConfigAttribute> attributes, Authentication authenticated) {
/*     */     try {
/* 253 */       this.accessDecisionManager.decide(authenticated, object, attributes);
/*     */     }
/* 255 */     catch (AccessDeniedException ex) {
/* 256 */       if (this.logger.isTraceEnabled()) {
/* 257 */         this.logger.trace(LogMessage.format("Failed to authorize %s with attributes %s using %s", object, attributes, this.accessDecisionManager));
/*     */       
/*     */       }
/* 260 */       else if (this.logger.isDebugEnabled()) {
/* 261 */         this.logger.debug(LogMessage.format("Failed to authorize %s with attributes %s", object, attributes));
/*     */       } 
/* 263 */       publishEvent((ApplicationEvent)new AuthorizationFailureEvent(object, attributes, authenticated, ex));
/* 264 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void finallyInvocation(InterceptorStatusToken token) {
/* 276 */     if (token != null && token.isContextHolderRefreshRequired()) {
/* 277 */       this.securityContextHolderStrategy.setContext(token.getSecurityContext());
/* 278 */       if (this.logger.isDebugEnabled()) {
/* 279 */         this.logger.debug(
/* 280 */             LogMessage.of(() -> "Reverted to original authentication " + String.valueOf(token.getSecurityContext().getAuthentication())));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object afterInvocation(InterceptorStatusToken token, Object returnedObject) {
/* 295 */     if (token == null)
/*     */     {
/* 297 */       return returnedObject;
/*     */     }
/* 299 */     finallyInvocation(token);
/* 300 */     if (this.afterInvocationManager != null) {
/*     */       
/*     */       try {
/* 303 */         returnedObject = this.afterInvocationManager.decide(token.getSecurityContext().getAuthentication(), token
/* 304 */             .getSecureObject(), token.getAttributes(), returnedObject);
/*     */       }
/* 306 */       catch (AccessDeniedException ex) {
/* 307 */         publishEvent((ApplicationEvent)new AuthorizationFailureEvent(token.getSecureObject(), token.getAttributes(), token
/* 308 */               .getSecurityContext().getAuthentication(), ex));
/* 309 */         throw ex;
/*     */       } 
/*     */     }
/* 312 */     return returnedObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Authentication authenticateIfRequired() {
/* 322 */     Authentication authentication = this.securityContextHolderStrategy.getContext().getAuthentication();
/* 323 */     if (authentication.isAuthenticated() && !this.alwaysReauthenticate) {
/* 324 */       if (this.logger.isTraceEnabled()) {
/* 325 */         this.logger.trace(LogMessage.format("Did not re-authenticate %s before authorizing", authentication));
/*     */       }
/* 327 */       return authentication;
/*     */     } 
/* 329 */     authentication = this.authenticationManager.authenticate(authentication);
/*     */     
/* 331 */     if (this.logger.isDebugEnabled()) {
/* 332 */       this.logger.debug(LogMessage.format("Re-authenticated %s before authorizing", authentication));
/*     */     }
/* 334 */     SecurityContext context = this.securityContextHolderStrategy.createEmptyContext();
/* 335 */     context.setAuthentication(authentication);
/* 336 */     this.securityContextHolderStrategy.setContext(context);
/* 337 */     return authentication;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void credentialsNotFound(String reason, Object secureObject, Collection<ConfigAttribute> configAttribs) {
/* 350 */     AuthenticationCredentialsNotFoundException exception = new AuthenticationCredentialsNotFoundException(reason);
/* 351 */     AuthenticationCredentialsNotFoundEvent event = new AuthenticationCredentialsNotFoundEvent(secureObject, configAttribs, exception);
/*     */     
/* 353 */     publishEvent((ApplicationEvent)event);
/* 354 */     throw exception;
/*     */   }
/*     */   
/*     */   public AccessDecisionManager getAccessDecisionManager() {
/* 358 */     return this.accessDecisionManager;
/*     */   }
/*     */   
/*     */   public AfterInvocationManager getAfterInvocationManager() {
/* 362 */     return this.afterInvocationManager;
/*     */   }
/*     */   
/*     */   public AuthenticationManager getAuthenticationManager() {
/* 366 */     return this.authenticationManager;
/*     */   }
/*     */   
/*     */   public RunAsManager getRunAsManager() {
/* 370 */     return this.runAsManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAlwaysReauthenticate() {
/* 382 */     return this.alwaysReauthenticate;
/*     */   }
/*     */   
/*     */   public boolean isRejectPublicInvocations() {
/* 386 */     return this.rejectPublicInvocations;
/*     */   }
/*     */   
/*     */   public boolean isValidateConfigAttributes() {
/* 390 */     return this.validateConfigAttributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 402 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 403 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */   
/*     */   public void setAccessDecisionManager(AccessDecisionManager accessDecisionManager) {
/* 407 */     this.accessDecisionManager = accessDecisionManager;
/*     */   }
/*     */   
/*     */   public void setAfterInvocationManager(AfterInvocationManager afterInvocationManager) {
/* 411 */     this.afterInvocationManager = afterInvocationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlwaysReauthenticate(boolean alwaysReauthenticate) {
/* 426 */     this.alwaysReauthenticate = alwaysReauthenticate;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
/* 431 */     this.eventPublisher = applicationEventPublisher;
/*     */   }
/*     */   
/*     */   public void setAuthenticationManager(AuthenticationManager newManager) {
/* 435 */     this.authenticationManager = newManager;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 440 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPublishAuthorizationSuccess(boolean publishAuthorizationSuccess) {
/* 449 */     this.publishAuthorizationSuccess = publishAuthorizationSuccess;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRejectPublicInvocations(boolean rejectPublicInvocations) {
/* 467 */     this.rejectPublicInvocations = rejectPublicInvocations;
/*     */   }
/*     */   
/*     */   public void setRunAsManager(RunAsManager runAsManager) {
/* 471 */     this.runAsManager = runAsManager;
/*     */   }
/*     */   
/*     */   public void setValidateConfigAttributes(boolean validateConfigAttributes) {
/* 475 */     this.validateConfigAttributes = validateConfigAttributes;
/*     */   }
/*     */   public abstract Class<?> getSecureObjectClass();
/*     */   private void publishEvent(ApplicationEvent event) {
/* 479 */     if (this.eventPublisher != null)
/* 480 */       this.eventPublisher.publishEvent(event); 
/*     */   }
/*     */   
/*     */   public abstract SecurityMetadataSource obtainSecurityMetadataSource();
/*     */   
/*     */   private static class NoOpAuthenticationManager
/*     */     implements AuthenticationManager {
/*     */     public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 488 */       throw new AuthenticationServiceException("Cannot authenticate " + String.valueOf(authentication));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\intercept\AbstractSecurityInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */