/*     */ package org.springframework.security.access.intercept.aspectj;
/*     */ 
/*     */ import java.lang.reflect.AccessibleObject;
/*     */ import java.lang.reflect.Method;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.aspectj.lang.JoinPoint;
/*     */ import org.aspectj.lang.ProceedingJoinPoint;
/*     */ import org.aspectj.lang.reflect.CodeSignature;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class MethodInvocationAdapter
/*     */   implements MethodInvocation
/*     */ {
/*     */   private final ProceedingJoinPoint jp;
/*     */   private final Method method;
/*     */   private final Object target;
/*     */   
/*     */   MethodInvocationAdapter(JoinPoint jp) {
/*  48 */     this.jp = (ProceedingJoinPoint)jp;
/*  49 */     if (jp.getTarget() != null) {
/*  50 */       this.target = jp.getTarget();
/*     */     }
/*     */     else {
/*     */       
/*  54 */       this.target = jp.getSignature().getDeclaringType();
/*     */     } 
/*  56 */     String targetMethodName = jp.getStaticPart().getSignature().getName();
/*  57 */     Class<?>[] types = ((CodeSignature)jp.getStaticPart().getSignature()).getParameterTypes();
/*  58 */     Class<?> declaringType = jp.getStaticPart().getSignature().getDeclaringType();
/*  59 */     this.method = findMethod(targetMethodName, declaringType, types);
/*  60 */     Assert.notNull(this.method, () -> "Could not obtain target method from JoinPoint: '" + String.valueOf(jp) + "'");
/*     */   }
/*     */   
/*     */   private Method findMethod(String name, Class<?> declaringType, Class<?>[] params) {
/*  64 */     Method method = null;
/*     */     try {
/*  66 */       method = declaringType.getMethod(name, params);
/*     */     }
/*  68 */     catch (NoSuchMethodException noSuchMethodException) {}
/*     */     
/*  70 */     if (method == null) {
/*     */       try {
/*  72 */         method = declaringType.getDeclaredMethod(name, params);
/*     */       }
/*  74 */       catch (NoSuchMethodException noSuchMethodException) {}
/*     */     }
/*     */     
/*  77 */     return method;
/*     */   }
/*     */ 
/*     */   
/*     */   public Method getMethod() {
/*  82 */     return this.method;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object[] getArguments() {
/*  87 */     return this.jp.getArgs();
/*     */   }
/*     */ 
/*     */   
/*     */   public AccessibleObject getStaticPart() {
/*  92 */     return this.method;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getThis() {
/*  97 */     return this.target;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object proceed() throws Throwable {
/* 102 */     return this.jp.proceed();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\intercept\aspectj\MethodInvocationAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */