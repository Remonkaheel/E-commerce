/*    */ package org.springframework.security.access.intercept;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ final class NullRunAsManager
/*    */   implements RunAsManager
/*    */ {
/*    */   public Authentication buildRunAs(Authentication authentication, Object object, Collection<ConfigAttribute> config) {
/* 38 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(ConfigAttribute attribute) {
/* 43 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(Class<?> clazz) {
/* 48 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\intercept\NullRunAsManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */