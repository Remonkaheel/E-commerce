/*    */ package org.springframework.security.access.intercept;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class MethodInvocationPrivilegeEvaluator
/*    */   implements InitializingBean
/*    */ {
/* 52 */   protected static final Log logger = LogFactory.getLog(MethodInvocationPrivilegeEvaluator.class);
/*    */   
/*    */   private AbstractSecurityInterceptor securityInterceptor;
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() {
/* 58 */     Assert.notNull(this.securityInterceptor, "SecurityInterceptor required");
/*    */   }
/*    */   
/*    */   public boolean isAllowed(MethodInvocation invocation, Authentication authentication) {
/* 62 */     Assert.notNull(invocation, "MethodInvocation required");
/* 63 */     Assert.notNull(invocation.getMethod(), "MethodInvocation must provide a non-null getMethod()");
/*    */     
/* 65 */     Collection<ConfigAttribute> attrs = this.securityInterceptor.obtainSecurityMetadataSource().getAttributes(invocation);
/* 66 */     if (attrs == null) {
/* 67 */       return !this.securityInterceptor.isRejectPublicInvocations();
/*    */     }
/* 69 */     if (authentication == null || authentication.getAuthorities().isEmpty()) {
/* 70 */       return false;
/*    */     }
/*    */     try {
/* 73 */       this.securityInterceptor.getAccessDecisionManager().decide(authentication, invocation, attrs);
/* 74 */       return true;
/*    */     }
/* 76 */     catch (AccessDeniedException unauthorized) {
/* 77 */       logger.debug(LogMessage.format("%s denied for %s", invocation, authentication), (Throwable)unauthorized);
/* 78 */       return false;
/*    */     } 
/*    */   }
/*    */   
/*    */   public void setSecurityInterceptor(AbstractSecurityInterceptor securityInterceptor) {
/* 83 */     Assert.notNull(securityInterceptor, "AbstractSecurityInterceptor cannot be null");
/* 84 */     Assert.isTrue(MethodInvocation.class.equals(securityInterceptor.getSecureObjectClass()), "AbstractSecurityInterceptor does not support MethodInvocations");
/*    */     
/* 86 */     Assert.notNull(securityInterceptor.getAccessDecisionManager(), "AbstractSecurityInterceptor must provide a non-null AccessDecisionManager");
/*    */     
/* 88 */     this.securityInterceptor = securityInterceptor;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\intercept\MethodInvocationPrivilegeEvaluator.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */