/*    */ package org.springframework.security.access.intercept.aopalliance;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.security.access.SecurityMetadataSource;
/*    */ import org.springframework.security.access.intercept.AbstractSecurityInterceptor;
/*    */ import org.springframework.security.access.intercept.InterceptorStatusToken;
/*    */ import org.springframework.security.access.method.MethodSecurityMetadataSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class MethodSecurityInterceptor
/*    */   extends AbstractSecurityInterceptor
/*    */   implements MethodInterceptor
/*    */ {
/*    */   private MethodSecurityMetadataSource securityMetadataSource;
/*    */   
/*    */   public Class<?> getSecureObjectClass() {
/* 52 */     return MethodInvocation.class;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object invoke(MethodInvocation mi) throws Throwable {
/*    */     Object result;
/* 64 */     InterceptorStatusToken token = beforeInvocation(mi);
/*    */     
/*    */     try {
/* 67 */       result = mi.proceed();
/*    */     } finally {
/*    */       
/* 70 */       finallyInvocation(token);
/*    */     } 
/* 72 */     return afterInvocation(token, result);
/*    */   }
/*    */   
/*    */   public MethodSecurityMetadataSource getSecurityMetadataSource() {
/* 76 */     return this.securityMetadataSource;
/*    */   }
/*    */ 
/*    */   
/*    */   public SecurityMetadataSource obtainSecurityMetadataSource() {
/* 81 */     return (SecurityMetadataSource)this.securityMetadataSource;
/*    */   }
/*    */   
/*    */   public void setSecurityMetadataSource(MethodSecurityMetadataSource newSource) {
/* 85 */     this.securityMetadataSource = newSource;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\intercept\aopalliance\MethodSecurityInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */