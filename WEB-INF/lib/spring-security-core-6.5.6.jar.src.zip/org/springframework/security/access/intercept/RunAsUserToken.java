/*    */ package org.springframework.security.access.intercept;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.authentication.AbstractAuthenticationToken;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class RunAsUserToken
/*    */   extends AbstractAuthenticationToken
/*    */ {
/*    */   private static final long serialVersionUID = 620L;
/*    */   private final Class<? extends Authentication> originalAuthentication;
/*    */   private final Object credentials;
/*    */   private final Object principal;
/*    */   private final int keyHash;
/*    */   
/*    */   public RunAsUserToken(String key, Object principal, Object credentials, Collection<? extends GrantedAuthority> authorities, Class<? extends Authentication> originalAuthentication) {
/* 51 */     super(authorities);
/* 52 */     this.keyHash = key.hashCode();
/* 53 */     this.principal = principal;
/* 54 */     this.credentials = credentials;
/* 55 */     this.originalAuthentication = originalAuthentication;
/* 56 */     setAuthenticated(true);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getCredentials() {
/* 61 */     return this.credentials;
/*    */   }
/*    */   
/*    */   public int getKeyHash() {
/* 65 */     return this.keyHash;
/*    */   }
/*    */   
/*    */   public Class<? extends Authentication> getOriginalAuthentication() {
/* 69 */     return this.originalAuthentication;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getPrincipal() {
/* 74 */     return this.principal;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 79 */     StringBuilder sb = new StringBuilder(super.toString());
/* 80 */     String className = (this.originalAuthentication != null) ? this.originalAuthentication.getName() : null;
/* 81 */     sb.append("; Original Class: ").append(className);
/* 82 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\intercept\RunAsUserToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */