/*    */ package org.springframework.security.access.intercept;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class InterceptorStatusToken
/*    */ {
/*    */   private SecurityContext securityContext;
/*    */   private Collection<ConfigAttribute> attr;
/*    */   private Object secureObject;
/*    */   private boolean contextHolderRefreshRequired;
/*    */   
/*    */   public InterceptorStatusToken(SecurityContext securityContext, boolean contextHolderRefreshRequired, Collection<ConfigAttribute> attributes, Object secureObject) {
/* 50 */     this.securityContext = securityContext;
/* 51 */     this.contextHolderRefreshRequired = contextHolderRefreshRequired;
/* 52 */     this.attr = attributes;
/* 53 */     this.secureObject = secureObject;
/*    */   }
/*    */   
/*    */   public Collection<ConfigAttribute> getAttributes() {
/* 57 */     return this.attr;
/*    */   }
/*    */   
/*    */   public SecurityContext getSecurityContext() {
/* 61 */     return this.securityContext;
/*    */   }
/*    */   
/*    */   public Object getSecureObject() {
/* 65 */     return this.secureObject;
/*    */   }
/*    */   
/*    */   public boolean isContextHolderRefreshRequired() {
/* 69 */     return this.contextHolderRefreshRequired;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\intercept\InterceptorStatusToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */