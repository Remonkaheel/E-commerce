package org.springframework.security.access.intercept;

import java.util.Collection;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.core.Authentication;

@Deprecated
public interface RunAsManager {
  Authentication buildRunAs(Authentication paramAuthentication, Object paramObject, Collection<ConfigAttribute> paramCollection);
  
  boolean supports(ConfigAttribute paramConfigAttribute);
  
  boolean supports(Class<?> paramClass);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\intercept\RunAsManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */