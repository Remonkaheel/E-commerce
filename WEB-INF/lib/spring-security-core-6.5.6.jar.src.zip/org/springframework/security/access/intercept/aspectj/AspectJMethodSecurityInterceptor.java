/*    */ package org.springframework.security.access.intercept.aspectj;
/*    */ 
/*    */ import org.aspectj.lang.JoinPoint;
/*    */ import org.springframework.security.access.intercept.InterceptorStatusToken;
/*    */ import org.springframework.security.access.intercept.aopalliance.MethodSecurityInterceptor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class AspectJMethodSecurityInterceptor
/*    */   extends MethodSecurityInterceptor
/*    */ {
/*    */   public Object invoke(JoinPoint jp) throws Throwable {
/* 50 */     return invoke(new MethodInvocationAdapter(jp));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object invoke(JoinPoint jp, AspectJCallback advisorProceed) {
/*    */     Object result;
/* 61 */     InterceptorStatusToken token = beforeInvocation(new MethodInvocationAdapter(jp));
/*    */     
/*    */     try {
/* 64 */       result = advisorProceed.proceedWithObject();
/*    */     } finally {
/*    */       
/* 67 */       finallyInvocation(token);
/*    */     } 
/* 69 */     return afterInvocation(token, result);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\intercept\aspectj\AspectJMethodSecurityInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */