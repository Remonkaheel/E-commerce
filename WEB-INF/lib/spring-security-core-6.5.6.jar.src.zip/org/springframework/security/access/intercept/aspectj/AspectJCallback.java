package org.springframework.security.access.intercept.aspectj;

@Deprecated
public interface AspectJCallback {
  Object proceedWithObject();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\intercept\aspectj\AspectJCallback.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */