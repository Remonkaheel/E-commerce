/*     */ package org.springframework.security.access.intercept;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.access.AfterInvocationProvider;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class AfterInvocationProviderManager
/*     */   implements AfterInvocationManager, InitializingBean
/*     */ {
/*  58 */   protected static final Log logger = LogFactory.getLog(AfterInvocationProviderManager.class);
/*     */   
/*     */   private List<AfterInvocationProvider> providers;
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  64 */     checkIfValidList(this.providers);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object decide(Authentication authentication, Object object, Collection<ConfigAttribute> config, Object returnedObject) throws AccessDeniedException {
/*  70 */     Object result = returnedObject;
/*  71 */     for (AfterInvocationProvider provider : this.providers) {
/*  72 */       result = provider.decide(authentication, object, config, result);
/*     */     }
/*  74 */     return result;
/*     */   }
/*     */   
/*     */   public List<AfterInvocationProvider> getProviders() {
/*  78 */     return this.providers;
/*     */   }
/*     */   
/*     */   public void setProviders(List<?> newList) {
/*  82 */     checkIfValidList(newList);
/*  83 */     this.providers = new ArrayList<>(newList.size());
/*  84 */     for (Object currentObject : newList) {
/*  85 */       Assert.isInstanceOf(AfterInvocationProvider.class, currentObject, () -> "AfterInvocationProvider " + currentObject.getClass().getName() + " must implement AfterInvocationProvider");
/*     */       
/*  87 */       this.providers.add((AfterInvocationProvider)currentObject);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkIfValidList(List<?> listToCheck) {
/*  92 */     Assert.isTrue(!CollectionUtils.isEmpty(listToCheck), "A list of AfterInvocationProviders is required");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supports(ConfigAttribute attribute) {
/*  97 */     for (AfterInvocationProvider provider : this.providers) {
/*  98 */       logger.debug(LogMessage.format("Evaluating %s against %s", attribute, provider));
/*  99 */       if (provider.supports(attribute)) {
/* 100 */         return true;
/*     */       }
/*     */     } 
/* 103 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(Class<?> clazz) {
/* 119 */     for (AfterInvocationProvider provider : this.providers) {
/* 120 */       if (!provider.supports(clazz)) {
/* 121 */         return false;
/*     */       }
/*     */     } 
/* 124 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\intercept\AfterInvocationProviderManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */