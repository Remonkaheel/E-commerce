/*    */ package org.springframework.security.access.intercept;
/*    */ 
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.context.MessageSourceAware;
/*    */ import org.springframework.context.support.MessageSourceAccessor;
/*    */ import org.springframework.security.authentication.AuthenticationProvider;
/*    */ import org.springframework.security.authentication.BadCredentialsException;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.core.SpringSecurityMessageSource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class RunAsImplAuthenticationProvider
/*    */   implements InitializingBean, AuthenticationProvider, MessageSourceAware
/*    */ {
/* 50 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*    */   
/*    */   private String key;
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() {
/* 56 */     Assert.notNull(this.key, "A Key is required and should match that configured for the RunAsManagerImpl");
/*    */   }
/*    */ 
/*    */   
/*    */   public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 61 */     RunAsUserToken token = (RunAsUserToken)authentication;
/* 62 */     if (token.getKeyHash() != this.key.hashCode()) {
/* 63 */       throw new BadCredentialsException(this.messages.getMessage("RunAsImplAuthenticationProvider.incorrectKey", "The presented RunAsUserToken does not contain the expected key"));
/*    */     }
/*    */     
/* 66 */     return authentication;
/*    */   }
/*    */   
/*    */   public String getKey() {
/* 70 */     return this.key;
/*    */   }
/*    */   
/*    */   public void setKey(String key) {
/* 74 */     this.key = key;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setMessageSource(MessageSource messageSource) {
/* 79 */     this.messages = new MessageSourceAccessor(messageSource);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(Class<?> authentication) {
/* 84 */     return RunAsUserToken.class.isAssignableFrom(authentication);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\intercept\RunAsImplAuthenticationProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */