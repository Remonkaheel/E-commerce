/*     */ package org.springframework.security.access.intercept;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class RunAsManagerImpl
/*     */   implements RunAsManager, InitializingBean
/*     */ {
/*     */   private String key;
/*  64 */   private String rolePrefix = "ROLE_";
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  68 */     Assert.notNull(this.key, "A Key is required and should match that configured for the RunAsImplAuthenticationProvider");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Authentication buildRunAs(Authentication authentication, Object object, Collection<ConfigAttribute> attributes) {
/*  75 */     List<GrantedAuthority> newAuthorities = new ArrayList<>();
/*  76 */     for (ConfigAttribute attribute : attributes) {
/*  77 */       if (supports(attribute)) {
/*     */         
/*  79 */         SimpleGrantedAuthority simpleGrantedAuthority = new SimpleGrantedAuthority(getRolePrefix() + getRolePrefix());
/*  80 */         newAuthorities.add(simpleGrantedAuthority);
/*     */       } 
/*     */     } 
/*  83 */     if (newAuthorities.isEmpty()) {
/*  84 */       return null;
/*     */     }
/*     */     
/*  87 */     newAuthorities.addAll(authentication.getAuthorities());
/*  88 */     return (Authentication)new RunAsUserToken(this.key, authentication.getPrincipal(), authentication.getCredentials(), newAuthorities, (Class)authentication
/*  89 */         .getClass());
/*     */   }
/*     */   
/*     */   public String getKey() {
/*  93 */     return this.key;
/*     */   }
/*     */   
/*     */   public String getRolePrefix() {
/*  97 */     return this.rolePrefix;
/*     */   }
/*     */   
/*     */   public void setKey(String key) {
/* 101 */     this.key = key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRolePrefix(String rolePrefix) {
/* 110 */     this.rolePrefix = rolePrefix;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supports(ConfigAttribute attribute) {
/* 115 */     return (attribute.getAttribute() != null && attribute.getAttribute().startsWith("RUN_AS_"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(Class<?> clazz) {
/* 126 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\intercept\RunAsManagerImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */