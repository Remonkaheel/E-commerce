/*    */ package org.springframework.security.access.event;
/*    */ 
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class AbstractAuthorizationEvent
/*    */   extends ApplicationEvent
/*    */ {
/*    */   public AbstractAuthorizationEvent(Object secureObject) {
/* 37 */     super(secureObject);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\event\AbstractAuthorizationEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */