/*    */ package org.springframework.security.access.event;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class AuthorizedEvent
/*    */   extends AbstractAuthorizationEvent
/*    */ {
/*    */   private final Authentication authentication;
/*    */   private final Collection<ConfigAttribute> configAttributes;
/*    */   
/*    */   public AuthorizedEvent(Object secureObject, Collection<ConfigAttribute> attributes, Authentication authentication) {
/* 52 */     super(secureObject);
/* 53 */     Assert.isTrue((attributes != null && authentication != null), "All parameters are required and cannot be null");
/* 54 */     this.configAttributes = attributes;
/* 55 */     this.authentication = authentication;
/*    */   }
/*    */   
/*    */   public Authentication getAuthentication() {
/* 59 */     return this.authentication;
/*    */   }
/*    */   
/*    */   public Collection<ConfigAttribute> getConfigAttributes() {
/* 63 */     return this.configAttributes;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\event\AuthorizedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */