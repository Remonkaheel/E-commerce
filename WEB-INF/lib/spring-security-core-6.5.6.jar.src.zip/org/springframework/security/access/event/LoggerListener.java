/*    */ package org.springframework.security.access.event;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class LoggerListener
/*    */   implements ApplicationListener<AbstractAuthorizationEvent>
/*    */ {
/* 39 */   private static final Log logger = LogFactory.getLog(LoggerListener.class);
/*    */ 
/*    */   
/*    */   public void onApplicationEvent(AbstractAuthorizationEvent event) {
/* 43 */     if (event instanceof AuthenticationCredentialsNotFoundEvent) {
/* 44 */       onAuthenticationCredentialsNotFoundEvent((AuthenticationCredentialsNotFoundEvent)event);
/*    */     }
/* 46 */     if (event instanceof AuthorizationFailureEvent) {
/* 47 */       onAuthorizationFailureEvent((AuthorizationFailureEvent)event);
/*    */     }
/* 49 */     if (event instanceof AuthorizedEvent) {
/* 50 */       onAuthorizedEvent((AuthorizedEvent)event);
/*    */     }
/* 52 */     if (event instanceof PublicInvocationEvent) {
/* 53 */       onPublicInvocationEvent((PublicInvocationEvent)event);
/*    */     }
/*    */   }
/*    */   
/*    */   private void onAuthenticationCredentialsNotFoundEvent(AuthenticationCredentialsNotFoundEvent authEvent) {
/* 58 */     logger.warn(LogMessage.format("Security interception failed due to: %s; secure object: %s; configuration attributes: %s", authEvent
/*    */           
/* 60 */           .getCredentialsNotFoundException(), authEvent.getSource(), authEvent.getConfigAttributes()));
/*    */   }
/*    */   
/*    */   private void onPublicInvocationEvent(PublicInvocationEvent event) {
/* 64 */     logger.info(LogMessage.format("Security interception not required for public secure object: %s", event
/* 65 */           .getSource()));
/*    */   }
/*    */   
/*    */   private void onAuthorizedEvent(AuthorizedEvent authEvent) {
/* 69 */     logger.info(LogMessage.format("Security authorized for authenticated principal: %s; secure object: %s; configuration attributes: %s", authEvent
/*    */           
/* 71 */           .getAuthentication(), authEvent.getSource(), authEvent.getConfigAttributes()));
/*    */   }
/*    */   
/*    */   private void onAuthorizationFailureEvent(AuthorizationFailureEvent authEvent) {
/* 75 */     logger.warn(LogMessage.format("Security authorization failed due to: %s; authenticated principal: %s; secure object: %s; configuration attributes: %s", authEvent
/*    */           
/* 77 */           .getAccessDeniedException(), authEvent.getAuthentication(), authEvent.getSource(), authEvent
/* 78 */           .getConfigAttributes()));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\event\LoggerListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */