/*    */ package org.springframework.security.access.event;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class AuthorizationFailureEvent
/*    */   extends AbstractAuthorizationEvent
/*    */ {
/*    */   private final AccessDeniedException accessDeniedException;
/*    */   private final Authentication authentication;
/*    */   private final Collection<ConfigAttribute> configAttributes;
/*    */   
/*    */   public AuthorizationFailureEvent(Object secureObject, Collection<ConfigAttribute> attributes, Authentication authentication, AccessDeniedException accessDeniedException) {
/* 62 */     super(secureObject);
/* 63 */     Assert.isTrue((attributes != null && authentication != null && accessDeniedException != null), "All parameters are required and cannot be null");
/*    */     
/* 65 */     this.configAttributes = attributes;
/* 66 */     this.authentication = authentication;
/* 67 */     this.accessDeniedException = accessDeniedException;
/*    */   }
/*    */   
/*    */   public AccessDeniedException getAccessDeniedException() {
/* 71 */     return this.accessDeniedException;
/*    */   }
/*    */   
/*    */   public Authentication getAuthentication() {
/* 75 */     return this.authentication;
/*    */   }
/*    */   
/*    */   public Collection<ConfigAttribute> getConfigAttributes() {
/* 79 */     return this.configAttributes;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\event\AuthorizationFailureEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */