/*    */ package org.springframework.security.access.event;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class AuthenticationCredentialsNotFoundEvent
/*    */   extends AbstractAuthorizationEvent
/*    */ {
/*    */   private final AuthenticationCredentialsNotFoundException credentialsNotFoundException;
/*    */   private final Collection<ConfigAttribute> configAttribs;
/*    */   
/*    */   public AuthenticationCredentialsNotFoundEvent(Object secureObject, Collection<ConfigAttribute> attributes, AuthenticationCredentialsNotFoundException credentialsNotFoundException) {
/* 52 */     super(secureObject);
/* 53 */     Assert.isTrue((attributes != null && credentialsNotFoundException != null), "All parameters are required and cannot be null");
/*    */     
/* 55 */     this.configAttribs = attributes;
/* 56 */     this.credentialsNotFoundException = credentialsNotFoundException;
/*    */   }
/*    */   
/*    */   public Collection<ConfigAttribute> getConfigAttributes() {
/* 60 */     return this.configAttribs;
/*    */   }
/*    */   
/*    */   public AuthenticationCredentialsNotFoundException getCredentialsNotFoundException() {
/* 64 */     return this.credentialsNotFoundException;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\event\AuthenticationCredentialsNotFoundEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */