/*     */ package org.springframework.security.access.vote;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.springframework.security.access.AccessDecisionVoter;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class RoleVoter
/*     */   implements AccessDecisionVoter<Object>
/*     */ {
/*  58 */   private String rolePrefix = "ROLE_";
/*     */   
/*     */   public String getRolePrefix() {
/*  61 */     return this.rolePrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRolePrefix(String rolePrefix) {
/*  70 */     this.rolePrefix = rolePrefix;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supports(ConfigAttribute attribute) {
/*  75 */     return (attribute.getAttribute() != null && attribute.getAttribute().startsWith(getRolePrefix()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(Class<?> clazz) {
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int vote(Authentication authentication, Object object, Collection<ConfigAttribute> attributes) {
/*  91 */     if (authentication == null) {
/*  92 */       return -1;
/*     */     }
/*  94 */     int result = 0;
/*  95 */     Collection<? extends GrantedAuthority> authorities = extractAuthorities(authentication);
/*  96 */     for (ConfigAttribute attribute : attributes) {
/*  97 */       if (supports(attribute)) {
/*  98 */         result = -1;
/*     */         
/* 100 */         for (GrantedAuthority authority : authorities) {
/* 101 */           if (attribute.getAttribute().equals(authority.getAuthority())) {
/* 102 */             return 1;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 107 */     return result;
/*     */   }
/*     */   
/*     */   Collection<? extends GrantedAuthority> extractAuthorities(Authentication authentication) {
/* 111 */     return authentication.getAuthorities();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\vote\RoleVoter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */