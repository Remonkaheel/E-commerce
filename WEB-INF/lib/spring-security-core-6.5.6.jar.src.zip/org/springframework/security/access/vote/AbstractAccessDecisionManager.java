/*     */ package org.springframework.security.access.vote;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.security.access.AccessDecisionManager;
/*     */ import org.springframework.security.access.AccessDecisionVoter;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class AbstractAccessDecisionManager
/*     */   implements AccessDecisionManager, InitializingBean, MessageSourceAware
/*     */ {
/*  50 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private List<AccessDecisionVoter<?>> decisionVoters;
/*     */   
/*  54 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */   
/*     */   private boolean allowIfAllAbstainDecisions = false;
/*     */   
/*     */   protected AbstractAccessDecisionManager(List<AccessDecisionVoter<?>> decisionVoters) {
/*  59 */     Assert.notEmpty(decisionVoters, "A list of AccessDecisionVoters is required");
/*  60 */     this.decisionVoters = decisionVoters;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  65 */     Assert.notEmpty(this.decisionVoters, "A list of AccessDecisionVoters is required");
/*  66 */     Assert.notNull(this.messages, "A message source must be set");
/*     */   }
/*     */   
/*     */   protected final void checkAllowIfAllAbstainDecisions() {
/*  70 */     if (!isAllowIfAllAbstainDecisions()) {
/*  71 */       throw new AccessDeniedException(this.messages
/*  72 */           .getMessage("AbstractAccessDecisionManager.accessDenied", "Access is denied"));
/*     */     }
/*     */   }
/*     */   
/*     */   public List<AccessDecisionVoter<?>> getDecisionVoters() {
/*  77 */     return this.decisionVoters;
/*     */   }
/*     */   
/*     */   public boolean isAllowIfAllAbstainDecisions() {
/*  81 */     return this.allowIfAllAbstainDecisions;
/*     */   }
/*     */   
/*     */   public void setAllowIfAllAbstainDecisions(boolean allowIfAllAbstainDecisions) {
/*  85 */     this.allowIfAllAbstainDecisions = allowIfAllAbstainDecisions;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/*  90 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supports(ConfigAttribute attribute) {
/*  95 */     for (AccessDecisionVoter<?> voter : this.decisionVoters) {
/*  96 */       if (voter.supports(attribute)) {
/*  97 */         return true;
/*     */       }
/*     */     } 
/* 100 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(Class<?> clazz) {
/* 114 */     for (AccessDecisionVoter<?> voter : this.decisionVoters) {
/* 115 */       if (!voter.supports(clazz)) {
/* 116 */         return false;
/*     */       }
/*     */     } 
/* 119 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 124 */     return getClass().getSimpleName() + " [DecisionVoters=" + getClass().getSimpleName() + ", AllowIfAllAbstainDecisions=" + String.valueOf(this.decisionVoters) + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\vote\AbstractAccessDecisionManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */