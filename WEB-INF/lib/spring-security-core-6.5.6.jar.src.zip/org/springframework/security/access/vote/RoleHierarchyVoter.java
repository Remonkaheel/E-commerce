/*    */ package org.springframework.security.access.vote;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class RoleHierarchyVoter
/*    */   extends RoleVoter
/*    */ {
/* 39 */   private RoleHierarchy roleHierarchy = null;
/*    */   
/*    */   public RoleHierarchyVoter(RoleHierarchy roleHierarchy) {
/* 42 */     Assert.notNull(roleHierarchy, "RoleHierarchy must not be null");
/* 43 */     this.roleHierarchy = roleHierarchy;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Collection<? extends GrantedAuthority> extractAuthorities(Authentication authentication) {
/* 51 */     return this.roleHierarchy.getReachableGrantedAuthorities(authentication.getAuthorities());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\vote\RoleHierarchyVoter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */