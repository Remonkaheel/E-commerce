/*    */ package org.springframework.security.access.vote;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.springframework.security.access.AccessDecisionVoter;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class UnanimousBased
/*    */   extends AbstractAccessDecisionManager
/*    */ {
/*    */   public UnanimousBased(List<AccessDecisionVoter<?>> decisionVoters) {
/* 40 */     super(decisionVoters);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void decide(Authentication authentication, Object object, Collection<ConfigAttribute> attributes) throws AccessDeniedException {
/* 66 */     int grant = 0;
/* 67 */     List<ConfigAttribute> singleAttributeList = new ArrayList<>(1);
/* 68 */     singleAttributeList.add(null);
/* 69 */     for (ConfigAttribute attribute : attributes) {
/* 70 */       singleAttributeList.set(0, attribute);
/* 71 */       for (AccessDecisionVoter<?> voter : getDecisionVoters()) {
/* 72 */         int result = voter.vote(authentication, object, singleAttributeList);
/* 73 */         switch (result) {
/*    */           case 1:
/* 75 */             grant++;
/*    */           
/*    */           case -1:
/* 78 */             throw new AccessDeniedException(this.messages
/* 79 */                 .getMessage("AbstractAccessDecisionManager.accessDenied", "Access is denied"));
/*    */         } 
/*    */ 
/*    */ 
/*    */       
/*    */       } 
/*    */     } 
/* 86 */     if (grant > 0) {
/*    */       return;
/*    */     }
/*    */     
/* 90 */     checkAllowIfAllAbstainDecisions();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\vote\UnanimousBased.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */