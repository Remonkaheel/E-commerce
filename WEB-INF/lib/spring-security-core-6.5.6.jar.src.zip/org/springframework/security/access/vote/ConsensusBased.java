/*     */ package org.springframework.security.access.vote;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.springframework.security.access.AccessDecisionVoter;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.core.Authentication;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class ConsensusBased
/*     */   extends AbstractAccessDecisionManager
/*     */ {
/*     */   private boolean allowIfEqualGrantedDeniedDecisions = true;
/*     */   
/*     */   public ConsensusBased(List<AccessDecisionVoter<?>> decisionVoters) {
/*  45 */     super(decisionVoters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decide(Authentication authentication, Object object, Collection<ConfigAttribute> configAttributes) throws AccessDeniedException {
/*  69 */     int grant = 0;
/*  70 */     int deny = 0;
/*  71 */     for (AccessDecisionVoter<?> voter : getDecisionVoters()) {
/*  72 */       int result = voter.vote(authentication, object, configAttributes);
/*  73 */       switch (result) { case 1:
/*  74 */           grant++;
/*  75 */         case -1: deny++; }
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/*  80 */     if (grant > deny) {
/*     */       return;
/*     */     }
/*  83 */     if (deny > grant) {
/*  84 */       throw new AccessDeniedException(this.messages
/*  85 */           .getMessage("AbstractAccessDecisionManager.accessDenied", "Access is denied"));
/*     */     }
/*  87 */     if (grant == deny && grant != 0) {
/*  88 */       if (this.allowIfEqualGrantedDeniedDecisions) {
/*     */         return;
/*     */       }
/*  91 */       throw new AccessDeniedException(this.messages
/*  92 */           .getMessage("AbstractAccessDecisionManager.accessDenied", "Access is denied"));
/*     */     } 
/*     */     
/*  95 */     checkAllowIfAllAbstainDecisions();
/*     */   }
/*     */   
/*     */   public boolean isAllowIfEqualGrantedDeniedDecisions() {
/*  99 */     return this.allowIfEqualGrantedDeniedDecisions;
/*     */   }
/*     */   
/*     */   public void setAllowIfEqualGrantedDeniedDecisions(boolean allowIfEqualGrantedDeniedDecisions) {
/* 103 */     this.allowIfEqualGrantedDeniedDecisions = allowIfEqualGrantedDeniedDecisions;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\vote\ConsensusBased.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */