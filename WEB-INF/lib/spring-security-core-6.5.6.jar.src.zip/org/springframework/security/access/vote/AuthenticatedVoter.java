/*     */ package org.springframework.security.access.vote;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.springframework.security.access.AccessDecisionVoter;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class AuthenticatedVoter
/*     */   implements AccessDecisionVoter<Object>
/*     */ {
/*     */   public static final String IS_AUTHENTICATED_FULLY = "IS_AUTHENTICATED_FULLY";
/*     */   public static final String IS_AUTHENTICATED_REMEMBERED = "IS_AUTHENTICATED_REMEMBERED";
/*     */   public static final String IS_AUTHENTICATED_ANONYMOUSLY = "IS_AUTHENTICATED_ANONYMOUSLY";
/*  61 */   private AuthenticationTrustResolver authenticationTrustResolver = (AuthenticationTrustResolver)new AuthenticationTrustResolverImpl();
/*     */   
/*     */   private boolean isFullyAuthenticated(Authentication authentication) {
/*  64 */     return this.authenticationTrustResolver.isFullyAuthenticated(authentication);
/*     */   }
/*     */   
/*     */   public void setAuthenticationTrustResolver(AuthenticationTrustResolver authenticationTrustResolver) {
/*  68 */     Assert.notNull(authenticationTrustResolver, "AuthenticationTrustResolver cannot be set to null");
/*  69 */     this.authenticationTrustResolver = authenticationTrustResolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supports(ConfigAttribute attribute) {
/*  74 */     return (attribute.getAttribute() != null && ("IS_AUTHENTICATED_FULLY".equals(attribute.getAttribute()) || "IS_AUTHENTICATED_REMEMBERED"
/*  75 */       .equals(attribute.getAttribute()) || "IS_AUTHENTICATED_ANONYMOUSLY"
/*  76 */       .equals(attribute.getAttribute())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supports(Class<?> clazz) {
/*  87 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int vote(Authentication authentication, Object object, Collection<ConfigAttribute> attributes) {
/*  92 */     int result = 0;
/*  93 */     for (ConfigAttribute attribute : attributes) {
/*  94 */       if (supports(attribute)) {
/*  95 */         result = -1;
/*  96 */         if ("IS_AUTHENTICATED_FULLY".equals(attribute.getAttribute()) && 
/*  97 */           isFullyAuthenticated(authentication)) {
/*  98 */           return 1;
/*     */         }
/*     */         
/* 101 */         if ("IS_AUTHENTICATED_REMEMBERED".equals(attribute.getAttribute()) && (
/* 102 */           this.authenticationTrustResolver.isRememberMe(authentication) || 
/* 103 */           isFullyAuthenticated(authentication))) {
/* 104 */           return 1;
/*     */         }
/*     */         
/* 107 */         if ("IS_AUTHENTICATED_ANONYMOUSLY".equals(attribute.getAttribute()) && (
/* 108 */           this.authenticationTrustResolver.isAnonymous(authentication) || 
/* 109 */           isFullyAuthenticated(authentication) || this.authenticationTrustResolver
/* 110 */           .isRememberMe(authentication))) {
/* 111 */           return 1;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 116 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\vote\AuthenticatedVoter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */