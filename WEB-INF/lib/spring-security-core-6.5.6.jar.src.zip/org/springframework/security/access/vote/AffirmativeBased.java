/*    */ package org.springframework.security.access.vote;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.springframework.security.access.AccessDecisionVoter;
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class AffirmativeBased
/*    */   extends AbstractAccessDecisionManager
/*    */ {
/*    */   public AffirmativeBased(List<AccessDecisionVoter<?>> decisionVoters) {
/* 39 */     super(decisionVoters);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void decide(Authentication authentication, Object object, Collection<ConfigAttribute> configAttributes) throws AccessDeniedException {
/* 62 */     int deny = 0;
/* 63 */     for (AccessDecisionVoter<?> voter : getDecisionVoters()) {
/* 64 */       int result = voter.vote(authentication, object, configAttributes);
/* 65 */       switch (result) {
/*    */         case 1:
/*    */           return;
/*    */         case -1:
/* 69 */           deny++;
/*    */       } 
/*    */ 
/*    */ 
/*    */     
/*    */     } 
/* 75 */     if (deny > 0) {
/* 76 */       throw new AccessDeniedException(this.messages
/* 77 */           .getMessage("AbstractAccessDecisionManager.accessDenied", "Access is denied"));
/*    */     }
/*    */     
/* 80 */     checkAllowIfAllAbstainDecisions();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\vote\AffirmativeBased.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */