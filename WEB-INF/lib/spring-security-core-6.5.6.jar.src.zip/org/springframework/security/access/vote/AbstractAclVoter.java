/*    */ package org.springframework.security.access.vote;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.security.access.AccessDecisionVoter;
/*    */ import org.springframework.security.access.AuthorizationServiceException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class AbstractAclVoter
/*    */   implements AccessDecisionVoter<MethodInvocation>
/*    */ {
/*    */   private Class<?> processDomainObjectClass;
/*    */   
/*    */   protected Object getDomainObjectInstance(MethodInvocation invocation) {
/* 39 */     Object[] args = invocation.getArguments();
/* 40 */     Class<?>[] params = invocation.getMethod().getParameterTypes();
/* 41 */     for (int i = 0; i < params.length; i++) {
/* 42 */       if (this.processDomainObjectClass.isAssignableFrom(params[i])) {
/* 43 */         return args[i];
/*    */       }
/*    */     } 
/* 46 */     throw new AuthorizationServiceException("MethodInvocation: " + String.valueOf(invocation) + " did not provide any argument of type: " + String.valueOf(this.processDomainObjectClass));
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<?> getProcessDomainObjectClass() {
/* 51 */     return this.processDomainObjectClass;
/*    */   }
/*    */   
/*    */   public void setProcessDomainObjectClass(Class<?> processDomainObjectClass) {
/* 55 */     Assert.notNull(processDomainObjectClass, "processDomainObjectClass cannot be set to null");
/* 56 */     this.processDomainObjectClass = processDomainObjectClass;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean supports(Class<?> clazz) {
/* 68 */     return MethodInvocation.class.isAssignableFrom(clazz);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\vote\AbstractAclVoter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */