/*     */ package org.springframework.security.access.method;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultCacheKey
/*     */ {
/*     */   private final Method method;
/*     */   private final Class<?> targetClass;
/*     */   
/*     */   DefaultCacheKey(Method method, Class<?> targetClass) {
/* 110 */     this.method = method;
/* 111 */     this.targetClass = targetClass;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 116 */     DefaultCacheKey otherKey = (DefaultCacheKey)other;
/* 117 */     return (this.method.equals(otherKey.method) && 
/* 118 */       ObjectUtils.nullSafeEquals(this.targetClass, otherKey.targetClass));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 123 */     return this.method.hashCode() * 21 + ((this.targetClass != null) ? this.targetClass.hashCode() : 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 128 */     String targetClassName = (this.targetClass != null) ? this.targetClass.getName() : "-";
/* 129 */     return "CacheKey[" + targetClassName + "; " + String.valueOf(this.method) + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\method\DelegatingMethodSecurityMetadataSource$DefaultCacheKey.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */