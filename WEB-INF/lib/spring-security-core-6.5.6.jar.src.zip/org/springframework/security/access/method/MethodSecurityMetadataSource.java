package org.springframework.security.access.method;

import java.lang.reflect.Method;
import java.util.Collection;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityMetadataSource;

@Deprecated
public interface MethodSecurityMetadataSource extends SecurityMetadataSource {
  Collection<ConfigAttribute> getAttributes(Method paramMethod, Class<?> paramClass);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\method\MethodSecurityMetadataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */