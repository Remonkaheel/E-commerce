/*    */ package org.springframework.security.access.method;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.aop.framework.AopProxyUtils;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class AbstractMethodSecurityMetadataSource
/*    */   implements MethodSecurityMetadataSource
/*    */ {
/* 42 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */   
/*    */   public final Collection<ConfigAttribute> getAttributes(Object object) {
/* 46 */     if (object instanceof MethodInvocation) { MethodInvocation mi = (MethodInvocation)object;
/* 47 */       Object target = mi.getThis();
/* 48 */       Class<?> targetClass = null;
/* 49 */       if (target != null)
/*    */       {
/* 51 */         targetClass = (target instanceof Class) ? (Class)target : AopProxyUtils.ultimateTargetClass(target);
/*    */       }
/* 53 */       Collection<ConfigAttribute> attrs = getAttributes(mi.getMethod(), targetClass);
/* 54 */       if (attrs != null && !attrs.isEmpty()) {
/* 55 */         return attrs;
/*    */       }
/* 57 */       if (target != null && !(target instanceof Class)) {
/* 58 */         attrs = getAttributes(mi.getMethod(), target.getClass());
/*    */       }
/* 60 */       return attrs; }
/*    */     
/* 62 */     throw new IllegalArgumentException("Object must be a non-null MethodInvocation");
/*    */   }
/*    */ 
/*    */   
/*    */   public final boolean supports(Class<?> clazz) {
/* 67 */     return MethodInvocation.class.isAssignableFrom(clazz);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\method\AbstractMethodSecurityMetadataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */