/*     */ package org.springframework.security.access.method;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class DelegatingMethodSecurityMetadataSource
/*     */   extends AbstractMethodSecurityMetadataSource
/*     */ {
/*  48 */   private static final List<ConfigAttribute> NULL_CONFIG_ATTRIBUTE = Collections.emptyList();
/*     */   
/*     */   private final List<MethodSecurityMetadataSource> methodSecurityMetadataSources;
/*     */   
/*  52 */   private final Map<DefaultCacheKey, Collection<ConfigAttribute>> attributeCache = new HashMap<>();
/*     */   
/*     */   public DelegatingMethodSecurityMetadataSource(List<MethodSecurityMetadataSource> methodSecurityMetadataSources) {
/*  55 */     Assert.notNull(methodSecurityMetadataSources, "MethodSecurityMetadataSources cannot be null");
/*  56 */     this.methodSecurityMetadataSources = methodSecurityMetadataSources;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ConfigAttribute> getAttributes(Method method, Class<?> targetClass) {
/*  61 */     DefaultCacheKey cacheKey = new DefaultCacheKey(method, targetClass);
/*  62 */     synchronized (this.attributeCache) {
/*  63 */       Collection<ConfigAttribute> cached = this.attributeCache.get(cacheKey);
/*     */       
/*  65 */       if (cached != null) {
/*  66 */         return cached;
/*     */       }
/*     */       
/*  69 */       Collection<ConfigAttribute> attributes = null;
/*  70 */       for (MethodSecurityMetadataSource s : this.methodSecurityMetadataSources) {
/*  71 */         attributes = s.getAttributes(method, targetClass);
/*  72 */         if (attributes != null && !attributes.isEmpty()) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */       
/*  77 */       if (attributes == null || attributes.isEmpty()) {
/*  78 */         this.attributeCache.put(cacheKey, NULL_CONFIG_ATTRIBUTE);
/*  79 */         return NULL_CONFIG_ATTRIBUTE;
/*     */       } 
/*  81 */       this.logger.debug(LogMessage.format("Caching method [%s] with attributes %s", cacheKey, attributes));
/*  82 */       this.attributeCache.put(cacheKey, attributes);
/*  83 */       return attributes;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ConfigAttribute> getAllConfigAttributes() {
/*  89 */     Set<ConfigAttribute> set = new HashSet<>();
/*  90 */     for (MethodSecurityMetadataSource s : this.methodSecurityMetadataSources) {
/*  91 */       Collection<ConfigAttribute> attrs = s.getAllConfigAttributes();
/*  92 */       if (attrs != null) {
/*  93 */         set.addAll(attrs);
/*     */       }
/*     */     } 
/*  96 */     return set;
/*     */   }
/*     */   
/*     */   public List<MethodSecurityMetadataSource> getMethodSecurityMetadataSources() {
/* 100 */     return this.methodSecurityMetadataSources;
/*     */   }
/*     */ 
/*     */   
/*     */   private static class DefaultCacheKey
/*     */   {
/*     */     private final Method method;
/*     */     private final Class<?> targetClass;
/*     */     
/*     */     DefaultCacheKey(Method method, Class<?> targetClass) {
/* 110 */       this.method = method;
/* 111 */       this.targetClass = targetClass;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object other) {
/* 116 */       DefaultCacheKey otherKey = (DefaultCacheKey)other;
/* 117 */       return (this.method.equals(otherKey.method) && 
/* 118 */         ObjectUtils.nullSafeEquals(this.targetClass, otherKey.targetClass));
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 123 */       return this.method.hashCode() * 21 + ((this.targetClass != null) ? this.targetClass.hashCode() : 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 128 */       String targetClassName = (this.targetClass != null) ? this.targetClass.getName() : "-";
/* 129 */       return "CacheKey[" + targetClassName + "; " + String.valueOf(this.method) + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\method\DelegatingMethodSecurityMetadataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */