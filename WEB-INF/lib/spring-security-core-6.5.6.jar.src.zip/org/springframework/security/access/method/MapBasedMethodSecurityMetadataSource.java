/*     */ package org.springframework.security.access.method;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class MapBasedMethodSecurityMetadataSource
/*     */   extends AbstractFallbackMethodSecurityMetadataSource
/*     */   implements BeanClassLoaderAware
/*     */ {
/*  54 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   protected final Map<RegisteredMethod, List<ConfigAttribute>> methodMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private final Map<RegisteredMethod, String> nameMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MapBasedMethodSecurityMetadataSource(Map<String, List<ConfigAttribute>> methodMap) {
/*  74 */     for (Map.Entry<String, List<ConfigAttribute>> entry : methodMap.entrySet()) {
/*  75 */       addSecureMethod(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<ConfigAttribute> findAttributes(Class<?> clazz) {
/*  84 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Collection<ConfigAttribute> findAttributes(Method method, Class<?> targetClass) {
/*  93 */     if (targetClass == null) {
/*  94 */       return null;
/*     */     }
/*  96 */     return findAttributesSpecifiedAgainst(method, targetClass);
/*     */   }
/*     */   
/*     */   private List<ConfigAttribute> findAttributesSpecifiedAgainst(Method method, Class<?> clazz) {
/* 100 */     RegisteredMethod registeredMethod = new RegisteredMethod(method, clazz);
/* 101 */     if (this.methodMap.containsKey(registeredMethod)) {
/* 102 */       return this.methodMap.get(registeredMethod);
/*     */     }
/*     */     
/* 105 */     if (clazz.getSuperclass() != null) {
/* 106 */       return findAttributesSpecifiedAgainst(method, clazz.getSuperclass());
/*     */     }
/* 108 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addSecureMethod(String name, List<ConfigAttribute> attr) {
/* 118 */     int lastDotIndex = name.lastIndexOf(".");
/* 119 */     Assert.isTrue((lastDotIndex != -1), () -> "'" + name + "' is not a valid method name: format is FQN.methodName");
/* 120 */     String methodName = name.substring(lastDotIndex + 1);
/* 121 */     Assert.hasText(methodName, () -> "Method not found for '" + name + "'");
/* 122 */     String typeName = name.substring(0, lastDotIndex);
/* 123 */     Class<?> type = ClassUtils.resolveClassName(typeName, this.beanClassLoader);
/* 124 */     addSecureMethod(type, methodName, attr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSecureMethod(Class<?> javaType, String mappedName, List<ConfigAttribute> attr) {
/* 136 */     String name = javaType.getName() + "." + javaType.getName();
/* 137 */     this.logger.debug(LogMessage.format("Request to add secure method [%s] with attributes [%s]", name, attr));
/* 138 */     Method[] methods = javaType.getMethods();
/* 139 */     List<Method> matchingMethods = new ArrayList<>();
/* 140 */     for (Method method : methods) {
/* 141 */       if (method.getName().equals(mappedName) || isMatch(method.getName(), mappedName)) {
/* 142 */         matchingMethods.add(method);
/*     */       }
/*     */     } 
/* 145 */     Assert.notEmpty(matchingMethods, () -> "Couldn't find method '" + mappedName + "' on '" + String.valueOf(javaType) + "'");
/* 146 */     registerAllMatchingMethods(javaType, attr, name, matchingMethods);
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerAllMatchingMethods(Class<?> javaType, List<ConfigAttribute> attr, String name, List<Method> matchingMethods) {
/* 151 */     for (Method method : matchingMethods) {
/* 152 */       RegisteredMethod registeredMethod = new RegisteredMethod(method, javaType);
/* 153 */       String regMethodName = this.nameMap.get(registeredMethod);
/* 154 */       if (regMethodName == null || (!regMethodName.equals(name) && regMethodName.length() <= name.length())) {
/*     */ 
/*     */         
/* 157 */         if (regMethodName != null) {
/* 158 */           this.logger.debug(LogMessage.format("Replacing attributes for secure method [%s]: current name [%s] is more specific than [%s]", method, name, regMethodName));
/*     */         }
/*     */ 
/*     */         
/* 162 */         this.nameMap.put(registeredMethod, name);
/* 163 */         addSecureMethod(registeredMethod, attr);
/*     */         continue;
/*     */       } 
/* 166 */       this.logger.debug(LogMessage.format("Keeping attributes for secure method [%s]: current name [%s] is not more specific than [%s]", method, name, regMethodName));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSecureMethod(Class<?> javaType, Method method, List<ConfigAttribute> attr) {
/* 183 */     RegisteredMethod key = new RegisteredMethod(method, javaType);
/* 184 */     if (this.methodMap.containsKey(key)) {
/* 185 */       this.logger.debug(LogMessage.format("Method [%s] is already registered with attributes [%s]", method, this.methodMap
/* 186 */             .get(key)));
/*     */       return;
/*     */     } 
/* 189 */     this.methodMap.put(key, attr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addSecureMethod(RegisteredMethod method, List<ConfigAttribute> attr) {
/* 198 */     Assert.notNull(method, "RegisteredMethod required");
/* 199 */     Assert.notNull(attr, "Configuration attribute required");
/* 200 */     this.logger.info(LogMessage.format("Adding secure method [%s] with attributes [%s]", method, attr));
/* 201 */     this.methodMap.put(method, attr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<ConfigAttribute> getAllConfigAttributes() {
/* 210 */     Set<ConfigAttribute> allAttributes = new HashSet<>();
/* 211 */     Objects.requireNonNull(allAttributes); this.methodMap.values().forEach(allAttributes::addAll);
/* 212 */     return allAttributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMatch(String methodName, String mappedName) {
/* 223 */     return ((mappedName.endsWith("*") && methodName.startsWith(mappedName.substring(0, mappedName.length() - 1))) || (mappedName
/* 224 */       .startsWith("*") && methodName.endsWith(mappedName.substring(1, mappedName.length()))));
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader) {
/* 229 */     Assert.notNull(beanClassLoader, "Bean class loader required");
/* 230 */     this.beanClassLoader = beanClassLoader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMethodMapSize() {
/* 237 */     return this.methodMap.size();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MapBasedMethodSecurityMetadataSource() {}
/*     */ 
/*     */ 
/*     */   
/*     */   private static class RegisteredMethod
/*     */   {
/*     */     private final Method method;
/*     */ 
/*     */     
/*     */     private final Class<?> registeredJavaType;
/*     */ 
/*     */ 
/*     */     
/*     */     RegisteredMethod(Method method, Class<?> registeredJavaType) {
/* 256 */       Assert.notNull(method, "Method required");
/* 257 */       Assert.notNull(registeredJavaType, "Registered Java Type required");
/* 258 */       this.method = method;
/* 259 */       this.registeredJavaType = registeredJavaType;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 264 */       if (this == obj) {
/* 265 */         return true;
/*     */       }
/* 267 */       if (obj instanceof RegisteredMethod) { RegisteredMethod rhs = (RegisteredMethod)obj;
/* 268 */         return (this.method.equals(rhs.method) && this.registeredJavaType.equals(rhs.registeredJavaType)); }
/*     */       
/* 270 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 275 */       return this.method.hashCode() * this.registeredJavaType.hashCode();
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 280 */       return "RegisteredMethod[" + this.registeredJavaType.getName() + "; " + String.valueOf(this.method) + "]";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\method\MapBasedMethodSecurityMetadataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */