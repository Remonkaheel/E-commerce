/*    */ package org.springframework.security.access.method;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import org.springframework.aop.support.AopUtils;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class AbstractFallbackMethodSecurityMetadataSource
/*    */   extends AbstractMethodSecurityMetadataSource
/*    */ {
/*    */   public Collection<ConfigAttribute> getAttributes(Method method, Class<?> targetClass) {
/* 59 */     Method specificMethod = AopUtils.getMostSpecificMethod(method, targetClass);
/*    */     
/* 61 */     Collection<ConfigAttribute> attr = findAttributes(specificMethod, targetClass);
/* 62 */     if (attr != null) {
/* 63 */       return attr;
/*    */     }
/*    */     
/* 66 */     attr = findAttributes(specificMethod.getDeclaringClass());
/* 67 */     if (attr != null) {
/* 68 */       return attr;
/*    */     }
/* 70 */     if (specificMethod != method || targetClass == null) {
/*    */       
/* 72 */       attr = findAttributes(method, method.getDeclaringClass());
/* 73 */       if (attr != null) {
/* 74 */         return attr;
/*    */       }
/*    */       
/* 77 */       return findAttributes(method.getDeclaringClass());
/*    */     } 
/* 79 */     return Collections.emptyList();
/*    */   }
/*    */   
/*    */   protected abstract Collection<ConfigAttribute> findAttributes(Method paramMethod, Class<?> paramClass);
/*    */   
/*    */   protected abstract Collection<ConfigAttribute> findAttributes(Class<?> paramClass);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\method\AbstractFallbackMethodSecurityMetadataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */