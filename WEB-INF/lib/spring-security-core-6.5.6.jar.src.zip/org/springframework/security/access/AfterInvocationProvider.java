package org.springframework.security.access;

import java.util.Collection;
import org.springframework.security.core.Authentication;

@Deprecated
public interface AfterInvocationProvider {
  Object decide(Authentication paramAuthentication, Object paramObject1, Collection<ConfigAttribute> paramCollection, Object paramObject2) throws AccessDeniedException;
  
  boolean supports(ConfigAttribute paramConfigAttribute);
  
  boolean supports(Class<?> paramClass);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\AfterInvocationProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */