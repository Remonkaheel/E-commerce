package org.springframework.security.access.annotation;

import java.util.Collection;
import org.springframework.security.access.ConfigAttribute;

@Deprecated
public interface AnnotationMetadataExtractor<A extends java.lang.annotation.Annotation> {
  Collection<? extends ConfigAttribute> extractAttributes(A paramA);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\annotation\AnnotationMetadataExtractor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */