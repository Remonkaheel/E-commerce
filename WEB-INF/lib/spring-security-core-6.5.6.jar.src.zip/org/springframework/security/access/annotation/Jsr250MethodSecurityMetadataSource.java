/*     */ package org.springframework.security.access.annotation;
/*     */ 
/*     */ import jakarta.annotation.security.RolesAllowed;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.security.access.ConfigAttribute;
/*     */ import org.springframework.security.access.method.AbstractFallbackMethodSecurityMetadataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class Jsr250MethodSecurityMetadataSource
/*     */   extends AbstractFallbackMethodSecurityMetadataSource
/*     */ {
/*  45 */   private String defaultRolePrefix = "ROLE_";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultRolePrefix(String defaultRolePrefix) {
/*  60 */     this.defaultRolePrefix = defaultRolePrefix;
/*     */   }
/*     */ 
/*     */   
/*     */   protected Collection<ConfigAttribute> findAttributes(Class<?> clazz) {
/*  65 */     return processAnnotations(clazz.getAnnotations());
/*     */   }
/*     */ 
/*     */   
/*     */   protected Collection<ConfigAttribute> findAttributes(Method method, Class<?> targetClass) {
/*  70 */     return processAnnotations(AnnotationUtils.getAnnotations(method));
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<ConfigAttribute> getAllConfigAttributes() {
/*  75 */     return null;
/*     */   }
/*     */   
/*     */   private List<ConfigAttribute> processAnnotations(Annotation[] annotations) {
/*  79 */     if (annotations == null || annotations.length == 0) {
/*  80 */       return null;
/*     */     }
/*  82 */     List<ConfigAttribute> attributes = new ArrayList<>();
/*  83 */     for (Annotation annotation : annotations) {
/*  84 */       if (annotation instanceof jakarta.annotation.security.DenyAll) {
/*  85 */         attributes.add(Jsr250SecurityConfig.DENY_ALL_ATTRIBUTE);
/*  86 */         return attributes;
/*     */       } 
/*  88 */       if (annotation instanceof jakarta.annotation.security.PermitAll) {
/*  89 */         attributes.add(Jsr250SecurityConfig.PERMIT_ALL_ATTRIBUTE);
/*  90 */         return attributes;
/*     */       } 
/*  92 */       if (annotation instanceof RolesAllowed) { RolesAllowed ra = (RolesAllowed)annotation;
/*     */         
/*  94 */         for (String allowed : ra.value()) {
/*  95 */           String defaultedAllowed = getRoleWithDefaultPrefix(allowed);
/*  96 */           attributes.add(new Jsr250SecurityConfig(defaultedAllowed));
/*     */         } 
/*  98 */         return attributes; }
/*     */     
/*     */     } 
/* 101 */     return null;
/*     */   }
/*     */   
/*     */   private String getRoleWithDefaultPrefix(String role) {
/* 105 */     if (role == null) {
/* 106 */       return role;
/*     */     }
/* 108 */     if (this.defaultRolePrefix == null || this.defaultRolePrefix.length() == 0) {
/* 109 */       return role;
/*     */     }
/* 111 */     if (role.startsWith(this.defaultRolePrefix)) {
/* 112 */       return role;
/*     */     }
/* 114 */     return this.defaultRolePrefix + this.defaultRolePrefix;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\annotation\Jsr250MethodSecurityMetadataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */