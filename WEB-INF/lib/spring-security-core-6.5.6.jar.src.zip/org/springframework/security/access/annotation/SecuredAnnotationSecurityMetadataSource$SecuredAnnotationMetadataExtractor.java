/*    */ package org.springframework.security.access.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.access.SecurityConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SecuredAnnotationMetadataExtractor
/*    */   implements AnnotationMetadataExtractor<Secured>
/*    */ {
/*    */   public Collection<ConfigAttribute> extractAttributes(Secured secured) {
/* 88 */     String[] attributeTokens = secured.value();
/* 89 */     List<ConfigAttribute> attributes = new ArrayList<>(attributeTokens.length);
/* 90 */     for (String token : attributeTokens) {
/* 91 */       attributes.add(new SecurityConfig(token));
/*    */     }
/* 93 */     return attributes;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\annotation\SecuredAnnotationSecurityMetadataSource$SecuredAnnotationMetadataExtractor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */