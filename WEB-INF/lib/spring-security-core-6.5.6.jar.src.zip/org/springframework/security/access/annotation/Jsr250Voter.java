/*    */ package org.springframework.security.access.annotation;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.access.AccessDecisionVoter;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class Jsr250Voter
/*    */   implements AccessDecisionVoter<Object>
/*    */ {
/*    */   public boolean supports(ConfigAttribute configAttribute) {
/* 46 */     return configAttribute instanceof Jsr250SecurityConfig;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean supports(Class<?> clazz) {
/* 56 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int vote(Authentication authentication, Object object, Collection<ConfigAttribute> definition) {
/* 71 */     boolean jsr250AttributeFound = false;
/* 72 */     for (ConfigAttribute attribute : definition) {
/* 73 */       if (Jsr250SecurityConfig.PERMIT_ALL_ATTRIBUTE.equals(attribute)) {
/* 74 */         return 1;
/*    */       }
/* 76 */       if (Jsr250SecurityConfig.DENY_ALL_ATTRIBUTE.equals(attribute)) {
/* 77 */         return -1;
/*    */       }
/* 79 */       if (supports(attribute)) {
/* 80 */         jsr250AttributeFound = true;
/*    */         
/* 82 */         for (GrantedAuthority authority : authentication.getAuthorities()) {
/* 83 */           if (attribute.getAttribute().equals(authority.getAuthority())) {
/* 84 */             return 1;
/*    */           }
/*    */         } 
/*    */       } 
/*    */     } 
/* 89 */     return jsr250AttributeFound ? -1 : 0;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\annotation\Jsr250Voter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */