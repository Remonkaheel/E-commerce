/*    */ package org.springframework.security.access.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.springframework.core.GenericTypeResolver;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.security.access.ConfigAttribute;
/*    */ import org.springframework.security.access.SecurityConfig;
/*    */ import org.springframework.security.access.method.AbstractFallbackMethodSecurityMetadataSource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class SecuredAnnotationSecurityMetadataSource
/*    */   extends AbstractFallbackMethodSecurityMetadataSource
/*    */ {
/*    */   private AnnotationMetadataExtractor annotationExtractor;
/*    */   private Class<? extends Annotation> annotationType;
/*    */   
/*    */   public SecuredAnnotationSecurityMetadataSource() {
/* 53 */     this(new SecuredAnnotationMetadataExtractor());
/*    */   }
/*    */   
/*    */   public SecuredAnnotationSecurityMetadataSource(AnnotationMetadataExtractor annotationMetadataExtractor) {
/* 57 */     Assert.notNull(annotationMetadataExtractor, "annotationMetadataExtractor cannot be null");
/* 58 */     this.annotationExtractor = annotationMetadataExtractor;
/* 59 */     this
/* 60 */       .annotationType = GenericTypeResolver.resolveTypeArgument(this.annotationExtractor.getClass(), AnnotationMetadataExtractor.class);
/* 61 */     Assert.notNull(this.annotationType, () -> this.annotationExtractor.getClass().getName() + " must supply a generic parameter for AnnotationMetadataExtractor");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected Collection<ConfigAttribute> findAttributes(Class<?> clazz) {
/* 67 */     return processAnnotation(AnnotationUtils.findAnnotation(clazz, this.annotationType));
/*    */   }
/*    */ 
/*    */   
/*    */   protected Collection<ConfigAttribute> findAttributes(Method method, Class<?> targetClass) {
/* 72 */     return processAnnotation(AnnotationUtils.findAnnotation(method, this.annotationType));
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<ConfigAttribute> getAllConfigAttributes() {
/* 77 */     return null;
/*    */   }
/*    */   
/*    */   private Collection<ConfigAttribute> processAnnotation(Annotation annotation) {
/* 81 */     return (annotation != null) ? (Collection)this.annotationExtractor.extractAttributes(annotation) : null;
/*    */   }
/*    */   
/*    */   static class SecuredAnnotationMetadataExtractor
/*    */     implements AnnotationMetadataExtractor<Secured>
/*    */   {
/*    */     public Collection<ConfigAttribute> extractAttributes(Secured secured) {
/* 88 */       String[] attributeTokens = secured.value();
/* 89 */       List<ConfigAttribute> attributes = new ArrayList<>(attributeTokens.length);
/* 90 */       for (String token : attributeTokens) {
/* 91 */         attributes.add(new SecurityConfig(token));
/*    */       }
/* 93 */       return attributes;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\annotation\SecuredAnnotationSecurityMetadataSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */