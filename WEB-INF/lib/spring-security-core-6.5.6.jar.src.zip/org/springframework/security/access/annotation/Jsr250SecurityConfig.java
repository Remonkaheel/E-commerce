/*    */ package org.springframework.security.access.annotation;
/*    */ 
/*    */ import jakarta.annotation.security.DenyAll;
/*    */ import jakarta.annotation.security.PermitAll;
/*    */ import org.springframework.security.access.SecurityConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class Jsr250SecurityConfig
/*    */   extends SecurityConfig
/*    */ {
/* 36 */   public static final Jsr250SecurityConfig PERMIT_ALL_ATTRIBUTE = new Jsr250SecurityConfig(PermitAll.class.getName());
/*    */   
/* 38 */   public static final Jsr250SecurityConfig DENY_ALL_ATTRIBUTE = new Jsr250SecurityConfig(DenyAll.class.getName());
/*    */   
/*    */   public Jsr250SecurityConfig(String role) {
/* 41 */     super(role);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\annotation\Jsr250SecurityConfig.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */