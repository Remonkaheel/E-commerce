package org.springframework.security.access;

import java.util.Collection;
import org.springframework.aop.framework.AopInfrastructureBean;
import org.springframework.security.core.Authentication;

public interface PermissionCacheOptimizer extends AopInfrastructureBean {
  void cachePermissionsFor(Authentication paramAuthentication, Collection<?> paramCollection);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\access\PermissionCacheOptimizer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */