/*    */ package org.springframework.security.provisioning;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MutableUser
/*    */   implements MutableUserDetails
/*    */ {
/*    */   private static final long serialVersionUID = 620L;
/*    */   private String password;
/*    */   private final UserDetails delegate;
/*    */   
/*    */   MutableUser(UserDetails user) {
/* 38 */     this.delegate = user;
/* 39 */     this.password = user.getPassword();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPassword() {
/* 44 */     return this.password;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setPassword(String password) {
/* 49 */     this.password = password;
/*    */   }
/*    */ 
/*    */   
/*    */   public Collection<? extends GrantedAuthority> getAuthorities() {
/* 54 */     return this.delegate.getAuthorities();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getUsername() {
/* 59 */     return this.delegate.getUsername();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isAccountNonExpired() {
/* 64 */     return this.delegate.isAccountNonExpired();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isAccountNonLocked() {
/* 69 */     return this.delegate.isAccountNonLocked();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isCredentialsNonExpired() {
/* 74 */     return this.delegate.isCredentialsNonExpired();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEnabled() {
/* 79 */     return this.delegate.isEnabled();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\provisioning\MutableUser.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */