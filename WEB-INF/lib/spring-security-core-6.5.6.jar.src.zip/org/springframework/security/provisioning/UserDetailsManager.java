package org.springframework.security.provisioning;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserDetailsManager extends UserDetailsService {
  void createUser(UserDetails paramUserDetails);
  
  void updateUser(UserDetails paramUserDetails);
  
  void deleteUser(String paramString);
  
  void changePassword(String paramString1, String paramString2);
  
  boolean userExists(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\provisioning\UserDetailsManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */