/*     */ package org.springframework.security.provisioning;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.core.userdetails.User;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UserDetailsPasswordService;
/*     */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*     */ import org.springframework.security.core.userdetails.memory.UserAttribute;
/*     */ import org.springframework.security.core.userdetails.memory.UserAttributeEditor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InMemoryUserDetailsManager
/*     */   implements UserDetailsManager, UserDetailsPasswordService
/*     */ {
/*  57 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  59 */   private final Map<String, MutableUserDetails> users = new HashMap<>();
/*     */ 
/*     */   
/*  62 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */ 
/*     */   
/*     */   private AuthenticationManager authenticationManager;
/*     */ 
/*     */ 
/*     */   
/*     */   public InMemoryUserDetailsManager(Collection<UserDetails> users) {
/*  70 */     for (UserDetails user : users) {
/*  71 */       createUser(user);
/*     */     }
/*     */   }
/*     */   
/*     */   public InMemoryUserDetailsManager(UserDetails... users) {
/*  76 */     for (UserDetails user : users) {
/*  77 */       createUser(user);
/*     */     }
/*     */   }
/*     */   
/*     */   public InMemoryUserDetailsManager(Properties users) {
/*  82 */     Enumeration<?> names = users.propertyNames();
/*  83 */     UserAttributeEditor editor = new UserAttributeEditor();
/*  84 */     while (names.hasMoreElements()) {
/*  85 */       String name = (String)names.nextElement();
/*  86 */       editor.setAsText(users.getProperty(name));
/*  87 */       UserAttribute attr = (UserAttribute)editor.getValue();
/*  88 */       Assert.notNull(attr, () -> "The entry with username '" + name + "' could not be converted to an UserDetails");
/*     */       
/*  90 */       createUser((UserDetails)createUserDetails(name, attr));
/*     */     } 
/*     */   }
/*     */   
/*     */   private User createUserDetails(String name, UserAttribute attr) {
/*  95 */     return new User(name, attr.getPassword(), attr.isEnabled(), true, true, true, attr.getAuthorities());
/*     */   }
/*     */ 
/*     */   
/*     */   public void createUser(UserDetails user) {
/* 100 */     Assert.isTrue(!userExists(user.getUsername()), "user should not exist");
/* 101 */     if (user instanceof MutableUserDetails) { MutableUserDetails mutable = (MutableUserDetails)user;
/* 102 */       this.users.put(user.getUsername().toLowerCase(Locale.ROOT), mutable); }
/*     */     else
/*     */     
/* 105 */     { this.users.put(user.getUsername().toLowerCase(Locale.ROOT), new MutableUser(user)); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void deleteUser(String username) {
/* 111 */     this.users.remove(username.toLowerCase(Locale.ROOT));
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateUser(UserDetails user) {
/* 116 */     Assert.isTrue(userExists(user.getUsername()), "user should exist");
/* 117 */     if (user instanceof MutableUserDetails) { MutableUserDetails mutable = (MutableUserDetails)user;
/* 118 */       this.users.put(user.getUsername().toLowerCase(Locale.ROOT), mutable); }
/*     */     else
/*     */     
/* 121 */     { this.users.put(user.getUsername().toLowerCase(Locale.ROOT), new MutableUser(user)); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean userExists(String username) {
/* 127 */     return this.users.containsKey(username.toLowerCase(Locale.ROOT));
/*     */   }
/*     */ 
/*     */   
/*     */   public void changePassword(String oldPassword, String newPassword) {
/* 132 */     Authentication currentUser = this.securityContextHolderStrategy.getContext().getAuthentication();
/* 133 */     if (currentUser == null)
/*     */     {
/* 135 */       throw new AccessDeniedException("Can't change password as no Authentication object found in context for current user.");
/*     */     }
/*     */     
/* 138 */     String username = currentUser.getName();
/* 139 */     this.logger.debug(LogMessage.format("Changing password for user '%s'", username));
/*     */ 
/*     */     
/* 142 */     if (this.authenticationManager != null) {
/* 143 */       this.logger.debug(LogMessage.format("Reauthenticating user '%s' for password change request.", username));
/* 144 */       this.authenticationManager
/* 145 */         .authenticate((Authentication)UsernamePasswordAuthenticationToken.unauthenticated(username, oldPassword));
/*     */     } else {
/*     */       
/* 148 */       this.logger.debug("No authentication manager set. Password won't be re-checked.");
/*     */     } 
/* 150 */     MutableUserDetails user = this.users.get(username);
/* 151 */     Assert.state((user != null), "Current user doesn't exist in database.");
/* 152 */     user.setPassword(newPassword);
/*     */   }
/*     */ 
/*     */   
/*     */   public UserDetails updatePassword(UserDetails user, String newPassword) {
/* 157 */     String username = user.getUsername();
/* 158 */     MutableUserDetails mutableUser = this.users.get(username.toLowerCase(Locale.ROOT));
/* 159 */     mutableUser.setPassword(newPassword);
/* 160 */     return mutableUser;
/*     */   }
/*     */ 
/*     */   
/*     */   public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
/* 165 */     UserDetails user = this.users.get(username.toLowerCase(Locale.ROOT));
/* 166 */     if (user == null) {
/* 167 */       throw new UsernameNotFoundException("user '" + username + "' not found");
/*     */     }
/* 169 */     if (user instanceof org.springframework.security.core.CredentialsContainer) {
/* 170 */       return user;
/*     */     }
/* 172 */     return (UserDetails)new User(user.getUsername(), user.getPassword(), user.isEnabled(), user.isAccountNonExpired(), user
/* 173 */         .isCredentialsNonExpired(), user.isAccountNonLocked(), user.getAuthorities());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 183 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 184 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */   
/*     */   public void setAuthenticationManager(AuthenticationManager authenticationManager) {
/* 188 */     this.authenticationManager = authenticationManager;
/*     */   }
/*     */   
/*     */   public InMemoryUserDetailsManager() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\provisioning\InMemoryUserDetailsManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */