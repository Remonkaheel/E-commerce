/*     */ package org.springframework.security.provisioning;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.dao.IncorrectResultSizeDataAccessException;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.PreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.authentication.AuthenticationManager;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.security.core.userdetails.User;
/*     */ import org.springframework.security.core.userdetails.UserCache;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.cache.NullUserCache;
/*     */ import org.springframework.security.core.userdetails.jdbc.JdbcDaoImpl;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdbcUserDetailsManager
/*     */   extends JdbcDaoImpl
/*     */   implements UserDetailsManager, GroupManager
/*     */ {
/*     */   public static final String DEF_CREATE_USER_SQL = "insert into users (username, password, enabled) values (?,?,?)";
/*     */   public static final String DEF_DELETE_USER_SQL = "delete from users where username = ?";
/*     */   public static final String DEF_UPDATE_USER_SQL = "update users set password = ?, enabled = ? where username = ?";
/*     */   public static final String DEF_INSERT_AUTHORITY_SQL = "insert into authorities (username, authority) values (?,?)";
/*     */   public static final String DEF_DELETE_USER_AUTHORITIES_SQL = "delete from authorities where username = ?";
/*     */   public static final String DEF_USER_EXISTS_SQL = "select username from users where username = ?";
/*     */   public static final String DEF_CHANGE_PASSWORD_SQL = "update users set password = ? where username = ?";
/*     */   public static final String DEF_FIND_GROUPS_SQL = "select group_name from groups";
/*     */   public static final String DEF_FIND_USERS_IN_GROUP_SQL = "select username from group_members gm, groups g where gm.group_id = g.id and g.group_name = ?";
/*     */   public static final String DEF_INSERT_GROUP_SQL = "insert into groups (group_name) values (?)";
/*     */   public static final String DEF_FIND_GROUP_ID_SQL = "select id from groups where group_name = ?";
/*     */   public static final String DEF_INSERT_GROUP_AUTHORITY_SQL = "insert into group_authorities (group_id, authority) values (?,?)";
/*     */   public static final String DEF_DELETE_GROUP_SQL = "delete from groups where id = ?";
/*     */   public static final String DEF_DELETE_GROUP_AUTHORITIES_SQL = "delete from group_authorities where group_id = ?";
/*     */   public static final String DEF_DELETE_GROUP_MEMBERS_SQL = "delete from group_members where group_id = ?";
/*     */   public static final String DEF_RENAME_GROUP_SQL = "update groups set group_name = ? where group_name = ?";
/*     */   public static final String DEF_INSERT_GROUP_MEMBER_SQL = "insert into group_members (group_id, username) values (?,?)";
/*     */   public static final String DEF_DELETE_GROUP_MEMBER_SQL = "delete from group_members where group_id = ? and username = ?";
/*     */   public static final String DEF_GROUP_AUTHORITIES_QUERY_SQL = "select g.id, g.group_name, ga.authority from groups g, group_authorities ga where g.group_name = ? and g.id = ga.group_id ";
/*     */   public static final String DEF_DELETE_GROUP_AUTHORITY_SQL = "delete from group_authorities where group_id = ? and authority = ?";
/* 112 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*     */   
/* 115 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */   
/* 117 */   private String createUserSql = "insert into users (username, password, enabled) values (?,?,?)";
/*     */   
/* 119 */   private String deleteUserSql = "delete from users where username = ?";
/*     */   
/* 121 */   private String updateUserSql = "update users set password = ?, enabled = ? where username = ?";
/*     */   
/* 123 */   private String createAuthoritySql = "insert into authorities (username, authority) values (?,?)";
/*     */   
/* 125 */   private String deleteUserAuthoritiesSql = "delete from authorities where username = ?";
/*     */   
/* 127 */   private String userExistsSql = "select username from users where username = ?";
/*     */   
/* 129 */   private String changePasswordSql = "update users set password = ? where username = ?";
/*     */   
/* 131 */   private String findAllGroupsSql = "select group_name from groups";
/*     */   
/* 133 */   private String findUsersInGroupSql = "select username from group_members gm, groups g where gm.group_id = g.id and g.group_name = ?";
/*     */   
/* 135 */   private String insertGroupSql = "insert into groups (group_name) values (?)";
/*     */   
/* 137 */   private String findGroupIdSql = "select id from groups where group_name = ?";
/*     */   
/* 139 */   private String insertGroupAuthoritySql = "insert into group_authorities (group_id, authority) values (?,?)";
/*     */   
/* 141 */   private String deleteGroupSql = "delete from groups where id = ?";
/*     */   
/* 143 */   private String deleteGroupAuthoritiesSql = "delete from group_authorities where group_id = ?";
/*     */   
/* 145 */   private String deleteGroupMembersSql = "delete from group_members where group_id = ?";
/*     */   
/* 147 */   private String renameGroupSql = "update groups set group_name = ? where group_name = ?";
/*     */   
/* 149 */   private String insertGroupMemberSql = "insert into group_members (group_id, username) values (?,?)";
/*     */   
/* 151 */   private String deleteGroupMemberSql = "delete from group_members where group_id = ? and username = ?";
/*     */   
/* 153 */   private String groupAuthoritiesSql = "select g.id, g.group_name, ga.authority from groups g, group_authorities ga where g.group_name = ? and g.id = ga.group_id ";
/*     */   
/* 155 */   private String deleteGroupAuthoritySql = "delete from group_authorities where group_id = ? and authority = ?";
/*     */   
/*     */   private AuthenticationManager authenticationManager;
/*     */   
/* 159 */   private UserCache userCache = (UserCache)new NullUserCache();
/*     */   
/* 161 */   private RowMapper<UserDetails> userDetailsMapper = this::mapToUser;
/*     */   
/* 163 */   private RowMapper<GrantedAuthority> grantedAuthorityMapper = this::mapToGrantedAuthority;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcUserDetailsManager(DataSource dataSource) {
/* 169 */     setDataSource(dataSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserDetailsMapper(RowMapper<UserDetails> mapper) {
/* 184 */     Assert.notNull(mapper, "userDetailsMapper cannot be null");
/* 185 */     this.userDetailsMapper = mapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGrantedAuthorityMapper(RowMapper<GrantedAuthority> mapper) {
/* 199 */     Assert.notNull(mapper, "grantedAuthorityMapper cannot be null");
/* 200 */     this.grantedAuthorityMapper = mapper;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initDao() throws ApplicationContextException {
/* 205 */     if (this.authenticationManager == null) {
/* 206 */       this.logger.info("No authentication manager set. Reauthentication of users when changing passwords will not be performed.");
/*     */     }
/*     */     
/* 209 */     super.initDao();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<UserDetails> loadUsersByUsername(String username) {
/* 218 */     return requireJdbcTemplate().query(getUsersByUsernameQuery(), this.userDetailsMapper, new Object[] { username });
/*     */   }
/*     */   
/*     */   private UserDetails mapToUser(ResultSet rs, int rowNum) throws SQLException {
/* 222 */     String userName = rs.getString(1);
/* 223 */     String password = rs.getString(2);
/* 224 */     boolean enabled = rs.getBoolean(3);
/* 225 */     boolean accLocked = false;
/* 226 */     boolean accExpired = false;
/* 227 */     boolean credsExpired = false;
/* 228 */     if (rs.getMetaData().getColumnCount() > 3) {
/*     */       
/* 230 */       accLocked = rs.getBoolean(4);
/* 231 */       accExpired = rs.getBoolean(5);
/* 232 */       credsExpired = rs.getBoolean(6);
/*     */     } 
/* 234 */     return (UserDetails)new User(userName, password, enabled, !accExpired, !credsExpired, !accLocked, AuthorityUtils.NO_AUTHORITIES);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void createUser(UserDetails user) {
/* 240 */     validateUserDetails(user);
/* 241 */     requireJdbcTemplate().update(this.createUserSql, ps -> {
/*     */           ps.setString(1, user.getUsername());
/*     */           
/*     */           ps.setString(2, user.getPassword());
/*     */           ps.setBoolean(3, user.isEnabled());
/*     */           int paramCount = ps.getParameterMetaData().getParameterCount();
/*     */           if (paramCount > 3) {
/*     */             ps.setBoolean(4, !user.isAccountNonLocked());
/*     */             ps.setBoolean(5, !user.isAccountNonExpired());
/*     */             ps.setBoolean(6, !user.isCredentialsNonExpired());
/*     */           } 
/*     */         });
/* 253 */     if (getEnableAuthorities()) {
/* 254 */       insertUserAuthorities(user);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateUser(UserDetails user) {
/* 260 */     validateUserDetails(user);
/* 261 */     requireJdbcTemplate().update(this.updateUserSql, ps -> {
/*     */           ps.setString(1, user.getPassword());
/*     */           
/*     */           ps.setBoolean(2, user.isEnabled());
/*     */           
/*     */           int paramCount = ps.getParameterMetaData().getParameterCount();
/*     */           if (paramCount == 3) {
/*     */             ps.setString(3, user.getUsername());
/*     */           } else {
/*     */             ps.setBoolean(3, !user.isAccountNonLocked());
/*     */             ps.setBoolean(4, !user.isAccountNonExpired());
/*     */             ps.setBoolean(5, !user.isCredentialsNonExpired());
/*     */             ps.setString(6, user.getUsername());
/*     */           } 
/*     */         });
/* 276 */     if (getEnableAuthorities()) {
/* 277 */       deleteUserAuthorities(user.getUsername());
/* 278 */       insertUserAuthorities(user);
/*     */     } 
/* 280 */     this.userCache.removeUserFromCache(user.getUsername());
/*     */   }
/*     */   
/*     */   private void insertUserAuthorities(UserDetails user) {
/* 284 */     for (GrantedAuthority auth : user.getAuthorities()) {
/* 285 */       requireJdbcTemplate().update(this.createAuthoritySql, new Object[] { user.getUsername(), auth.getAuthority() });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void deleteUser(String username) {
/* 291 */     if (getEnableAuthorities()) {
/* 292 */       deleteUserAuthorities(username);
/*     */     }
/* 294 */     requireJdbcTemplate().update(this.deleteUserSql, new Object[] { username });
/* 295 */     this.userCache.removeUserFromCache(username);
/*     */   }
/*     */   
/*     */   private void deleteUserAuthorities(String username) {
/* 299 */     requireJdbcTemplate().update(this.deleteUserAuthoritiesSql, new Object[] { username });
/*     */   }
/*     */ 
/*     */   
/*     */   public void changePassword(String oldPassword, String newPassword) throws AuthenticationException {
/* 304 */     Authentication currentUser = this.securityContextHolderStrategy.getContext().getAuthentication();
/* 305 */     if (currentUser == null)
/*     */     {
/* 307 */       throw new AccessDeniedException("Can't change password as no Authentication object found in context for current user.");
/*     */     }
/*     */     
/* 310 */     String username = currentUser.getName();
/*     */ 
/*     */     
/* 313 */     if (this.authenticationManager != null) {
/* 314 */       this.logger.debug(LogMessage.format("Reauthenticating user '%s' for password change request.", username));
/* 315 */       this.authenticationManager
/* 316 */         .authenticate((Authentication)UsernamePasswordAuthenticationToken.unauthenticated(username, oldPassword));
/*     */     } else {
/*     */       
/* 319 */       this.logger.debug("No authentication manager set. Password won't be re-checked.");
/*     */     } 
/* 321 */     this.logger.debug("Changing password for user '" + username + "'");
/* 322 */     requireJdbcTemplate().update(this.changePasswordSql, new Object[] { newPassword, username });
/* 323 */     Authentication authentication = createNewAuthentication(currentUser, newPassword);
/* 324 */     SecurityContext context = this.securityContextHolderStrategy.createEmptyContext();
/* 325 */     context.setAuthentication(authentication);
/* 326 */     this.securityContextHolderStrategy.setContext(context);
/* 327 */     this.userCache.removeUserFromCache(username);
/*     */   }
/*     */   
/*     */   protected Authentication createNewAuthentication(Authentication currentAuth, String newPassword) {
/* 331 */     UserDetails user = loadUserByUsername(currentAuth.getName());
/* 332 */     UsernamePasswordAuthenticationToken newAuthentication = UsernamePasswordAuthenticationToken.authenticated(user, null, user
/* 333 */         .getAuthorities());
/* 334 */     newAuthentication.setDetails(currentAuth.getDetails());
/* 335 */     return (Authentication)newAuthentication;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean userExists(String username) {
/* 340 */     List<String> users = requireJdbcTemplate().queryForList(this.userExistsSql, String.class, new Object[] { username });
/* 341 */     if (users.size() > 1) {
/* 342 */       throw new IncorrectResultSizeDataAccessException("More than one user found with name '" + username + "'", 1);
/*     */     }
/*     */     
/* 345 */     return (users.size() == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> findAllGroups() {
/* 350 */     return requireJdbcTemplate().queryForList(this.findAllGroupsSql, String.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> findUsersInGroup(String groupName) {
/* 355 */     Assert.hasText(groupName, "groupName should have text");
/* 356 */     return requireJdbcTemplate().queryForList(this.findUsersInGroupSql, String.class, new Object[] { groupName });
/*     */   }
/*     */ 
/*     */   
/*     */   public void createGroup(String groupName, List<GrantedAuthority> authorities) {
/* 361 */     Assert.hasText(groupName, "groupName should have text");
/* 362 */     Assert.notNull(authorities, "authorities cannot be null");
/* 363 */     this.logger.debug("Creating new group '" + groupName + "' with authorities " + 
/* 364 */         String.valueOf(AuthorityUtils.authorityListToSet(authorities)));
/* 365 */     requireJdbcTemplate().update(this.insertGroupSql, new Object[] { groupName });
/* 366 */     int groupId = findGroupId(groupName);
/* 367 */     for (GrantedAuthority a : authorities) {
/* 368 */       String authority = a.getAuthority();
/* 369 */       requireJdbcTemplate().update(this.insertGroupAuthoritySql, ps -> {
/*     */             ps.setInt(1, groupId);
/*     */             ps.setString(2, authority);
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void deleteGroup(String groupName) {
/* 378 */     this.logger.debug("Deleting group '" + groupName + "'");
/* 379 */     Assert.hasText(groupName, "groupName should have text");
/* 380 */     int id = findGroupId(groupName);
/* 381 */     PreparedStatementSetter groupIdPSS = ps -> ps.setInt(1, id);
/* 382 */     requireJdbcTemplate().update(this.deleteGroupMembersSql, groupIdPSS);
/* 383 */     requireJdbcTemplate().update(this.deleteGroupAuthoritiesSql, groupIdPSS);
/* 384 */     requireJdbcTemplate().update(this.deleteGroupSql, groupIdPSS);
/*     */   }
/*     */ 
/*     */   
/*     */   public void renameGroup(String oldName, String newName) {
/* 389 */     this.logger.debug("Changing group name from '" + oldName + "' to '" + newName + "'");
/* 390 */     Assert.hasText(oldName, "oldName should have text");
/* 391 */     Assert.hasText(newName, "newName should have text");
/* 392 */     requireJdbcTemplate().update(this.renameGroupSql, new Object[] { newName, oldName });
/*     */   }
/*     */ 
/*     */   
/*     */   public void addUserToGroup(String username, String groupName) {
/* 397 */     this.logger.debug("Adding user '" + username + "' to group '" + groupName + "'");
/* 398 */     Assert.hasText(username, "username should have text");
/* 399 */     Assert.hasText(groupName, "groupName should have text");
/* 400 */     int id = findGroupId(groupName);
/* 401 */     requireJdbcTemplate().update(this.insertGroupMemberSql, ps -> {
/*     */           ps.setInt(1, id);
/*     */           ps.setString(2, username);
/*     */         });
/* 405 */     this.userCache.removeUserFromCache(username);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeUserFromGroup(String username, String groupName) {
/* 410 */     this.logger.debug("Removing user '" + username + "' to group '" + groupName + "'");
/* 411 */     Assert.hasText(username, "username should have text");
/* 412 */     Assert.hasText(groupName, "groupName should have text");
/* 413 */     int id = findGroupId(groupName);
/* 414 */     requireJdbcTemplate().update(this.deleteGroupMemberSql, ps -> {
/*     */           ps.setInt(1, id);
/*     */           ps.setString(2, username);
/*     */         });
/* 418 */     this.userCache.removeUserFromCache(username);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<GrantedAuthority> findGroupAuthorities(String groupName) {
/* 423 */     this.logger.debug("Loading authorities for group '" + groupName + "'");
/* 424 */     Assert.hasText(groupName, "groupName should have text");
/* 425 */     return requireJdbcTemplate().query(this.groupAuthoritiesSql, this.grantedAuthorityMapper, new Object[] { groupName });
/*     */   }
/*     */   
/*     */   private GrantedAuthority mapToGrantedAuthority(ResultSet rs, int rowNum) throws SQLException {
/* 429 */     String roleName = getRolePrefix() + getRolePrefix();
/* 430 */     return (GrantedAuthority)new SimpleGrantedAuthority(roleName);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeGroupAuthority(String groupName, GrantedAuthority authority) {
/* 435 */     this.logger.debug("Removing authority '" + String.valueOf(authority) + "' from group '" + groupName + "'");
/* 436 */     Assert.hasText(groupName, "groupName should have text");
/* 437 */     Assert.notNull(authority, "authority cannot be null");
/* 438 */     int id = findGroupId(groupName);
/* 439 */     requireJdbcTemplate().update(this.deleteGroupAuthoritySql, ps -> {
/*     */           ps.setInt(1, id);
/*     */           ps.setString(2, authority.getAuthority());
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void addGroupAuthority(String groupName, GrantedAuthority authority) {
/* 447 */     this.logger.debug("Adding authority '" + String.valueOf(authority) + "' to group '" + groupName + "'");
/* 448 */     Assert.hasText(groupName, "groupName should have text");
/* 449 */     Assert.notNull(authority, "authority cannot be null");
/* 450 */     int id = findGroupId(groupName);
/* 451 */     requireJdbcTemplate().update(this.insertGroupAuthoritySql, ps -> {
/*     */           ps.setInt(1, id);
/*     */           ps.setString(2, authority.getAuthority());
/*     */         });
/*     */   }
/*     */   
/*     */   private int findGroupId(String group) {
/* 458 */     return ((Integer)requireJdbcTemplate().queryForObject(this.findGroupIdSql, Integer.class, new Object[] { group })).intValue();
/*     */   }
/*     */   
/*     */   private JdbcTemplate requireJdbcTemplate() {
/* 462 */     JdbcTemplate jdbc = getJdbcTemplate();
/* 463 */     Assert.notNull(jdbc, "JdbcTemplate cannot be null");
/* 464 */     return jdbc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 474 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 475 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */   
/*     */   public void setAuthenticationManager(AuthenticationManager authenticationManager) {
/* 479 */     this.authenticationManager = authenticationManager;
/*     */   }
/*     */   
/*     */   public void setCreateUserSql(String createUserSql) {
/* 483 */     Assert.hasText(createUserSql, "createUserSql should have text");
/* 484 */     this.createUserSql = createUserSql;
/*     */   }
/*     */   
/*     */   public void setDeleteUserSql(String deleteUserSql) {
/* 488 */     Assert.hasText(deleteUserSql, "deleteUserSql should have text");
/* 489 */     this.deleteUserSql = deleteUserSql;
/*     */   }
/*     */   
/*     */   public void setUpdateUserSql(String updateUserSql) {
/* 493 */     Assert.hasText(updateUserSql, "updateUserSql should have text");
/* 494 */     this.updateUserSql = updateUserSql;
/*     */   }
/*     */   
/*     */   public void setCreateAuthoritySql(String createAuthoritySql) {
/* 498 */     Assert.hasText(createAuthoritySql, "createAuthoritySql should have text");
/* 499 */     this.createAuthoritySql = createAuthoritySql;
/*     */   }
/*     */   
/*     */   public void setDeleteUserAuthoritiesSql(String deleteUserAuthoritiesSql) {
/* 503 */     Assert.hasText(deleteUserAuthoritiesSql, "deleteUserAuthoritiesSql should have text");
/* 504 */     this.deleteUserAuthoritiesSql = deleteUserAuthoritiesSql;
/*     */   }
/*     */   
/*     */   public void setUserExistsSql(String userExistsSql) {
/* 508 */     Assert.hasText(userExistsSql, "userExistsSql should have text");
/* 509 */     this.userExistsSql = userExistsSql;
/*     */   }
/*     */   
/*     */   public void setChangePasswordSql(String changePasswordSql) {
/* 513 */     Assert.hasText(changePasswordSql, "changePasswordSql should have text");
/* 514 */     this.changePasswordSql = changePasswordSql;
/*     */   }
/*     */   
/*     */   public void setFindAllGroupsSql(String findAllGroupsSql) {
/* 518 */     Assert.hasText(findAllGroupsSql, "findAllGroupsSql should have text");
/* 519 */     this.findAllGroupsSql = findAllGroupsSql;
/*     */   }
/*     */   
/*     */   public void setFindUsersInGroupSql(String findUsersInGroupSql) {
/* 523 */     Assert.hasText(findUsersInGroupSql, "findUsersInGroupSql should have text");
/* 524 */     this.findUsersInGroupSql = findUsersInGroupSql;
/*     */   }
/*     */   
/*     */   public void setInsertGroupSql(String insertGroupSql) {
/* 528 */     Assert.hasText(insertGroupSql, "insertGroupSql should have text");
/* 529 */     this.insertGroupSql = insertGroupSql;
/*     */   }
/*     */   
/*     */   public void setFindGroupIdSql(String findGroupIdSql) {
/* 533 */     Assert.hasText(findGroupIdSql, "findGroupIdSql should have text");
/* 534 */     this.findGroupIdSql = findGroupIdSql;
/*     */   }
/*     */   
/*     */   public void setInsertGroupAuthoritySql(String insertGroupAuthoritySql) {
/* 538 */     Assert.hasText(insertGroupAuthoritySql, "insertGroupAuthoritySql should have text");
/* 539 */     this.insertGroupAuthoritySql = insertGroupAuthoritySql;
/*     */   }
/*     */   
/*     */   public void setDeleteGroupSql(String deleteGroupSql) {
/* 543 */     Assert.hasText(deleteGroupSql, "deleteGroupSql should have text");
/* 544 */     this.deleteGroupSql = deleteGroupSql;
/*     */   }
/*     */   
/*     */   public void setDeleteGroupAuthoritiesSql(String deleteGroupAuthoritiesSql) {
/* 548 */     Assert.hasText(deleteGroupAuthoritiesSql, "deleteGroupAuthoritiesSql should have text");
/* 549 */     this.deleteGroupAuthoritiesSql = deleteGroupAuthoritiesSql;
/*     */   }
/*     */   
/*     */   public void setDeleteGroupMembersSql(String deleteGroupMembersSql) {
/* 553 */     Assert.hasText(deleteGroupMembersSql, "deleteGroupMembersSql should have text");
/* 554 */     this.deleteGroupMembersSql = deleteGroupMembersSql;
/*     */   }
/*     */   
/*     */   public void setRenameGroupSql(String renameGroupSql) {
/* 558 */     Assert.hasText(renameGroupSql, "renameGroupSql should have text");
/* 559 */     this.renameGroupSql = renameGroupSql;
/*     */   }
/*     */   
/*     */   public void setInsertGroupMemberSql(String insertGroupMemberSql) {
/* 563 */     Assert.hasText(insertGroupMemberSql, "insertGroupMemberSql should have text");
/* 564 */     this.insertGroupMemberSql = insertGroupMemberSql;
/*     */   }
/*     */   
/*     */   public void setDeleteGroupMemberSql(String deleteGroupMemberSql) {
/* 568 */     Assert.hasText(deleteGroupMemberSql, "deleteGroupMemberSql should have text");
/* 569 */     this.deleteGroupMemberSql = deleteGroupMemberSql;
/*     */   }
/*     */   
/*     */   public void setGroupAuthoritiesSql(String groupAuthoritiesSql) {
/* 573 */     Assert.hasText(groupAuthoritiesSql, "groupAuthoritiesSql should have text");
/* 574 */     this.groupAuthoritiesSql = groupAuthoritiesSql;
/*     */   }
/*     */   
/*     */   public void setDeleteGroupAuthoritySql(String deleteGroupAuthoritySql) {
/* 578 */     Assert.hasText(deleteGroupAuthoritySql, "deleteGroupAuthoritySql should have text");
/* 579 */     this.deleteGroupAuthoritySql = deleteGroupAuthoritySql;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserCache(UserCache userCache) {
/* 589 */     Assert.notNull(userCache, "userCache cannot be null");
/* 590 */     this.userCache = userCache;
/*     */   }
/*     */   
/*     */   private void validateUserDetails(UserDetails user) {
/* 594 */     Assert.hasText(user.getUsername(), "Username may not be empty or null");
/* 595 */     validateAuthorities(user.getAuthorities());
/*     */   }
/*     */   
/*     */   private void validateAuthorities(Collection<? extends GrantedAuthority> authorities) {
/* 599 */     Assert.notNull(authorities, "Authorities list must not be null");
/* 600 */     for (GrantedAuthority authority : authorities) {
/* 601 */       Assert.notNull(authority, "Authorities list contains a null entry");
/* 602 */       Assert.hasText(authority.getAuthority(), "getAuthority() method must return a non-empty string");
/*     */     } 
/*     */   }
/*     */   
/*     */   public JdbcUserDetailsManager() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\provisioning\JdbcUserDetailsManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */