package org.springframework.security.provisioning;

import org.springframework.security.core.userdetails.UserDetails;

interface MutableUserDetails extends UserDetails {
  void setPassword(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\provisioning\MutableUserDetails.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */