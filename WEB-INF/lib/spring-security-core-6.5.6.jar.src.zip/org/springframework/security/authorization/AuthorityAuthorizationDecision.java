/*    */ package org.springframework.security.authorization;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthorityAuthorizationDecision
/*    */   extends AuthorizationDecision
/*    */ {
/*    */   private static final long serialVersionUID = -8338309042331376592L;
/*    */   private final Collection<GrantedAuthority> authorities;
/*    */   
/*    */   public AuthorityAuthorizationDecision(boolean granted, Collection<GrantedAuthority> authorities) {
/* 38 */     super(granted);
/* 39 */     this.authorities = authorities;
/*    */   }
/*    */   
/*    */   public Collection<GrantedAuthority> getAuthorities() {
/* 43 */     return this.authorities;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 48 */     return getClass().getSimpleName() + " [granted=" + getClass().getSimpleName() + ", authorities=" + isGranted() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\AuthorityAuthorizationDecision.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */