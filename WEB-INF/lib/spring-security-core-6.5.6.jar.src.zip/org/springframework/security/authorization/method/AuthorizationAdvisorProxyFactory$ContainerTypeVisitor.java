/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.security.authorization.AuthorizationProxyFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ContainerTypeVisitor
/*     */   implements AuthorizationAdvisorProxyFactory.TargetVisitor
/*     */ {
/*     */   public Object visit(AuthorizationAdvisorProxyFactory proxyFactory, Object target) {
/* 404 */     if (target instanceof Iterator) { Iterator<?> iterator = (Iterator)target;
/* 405 */       return proxyIterator(proxyFactory, iterator); }
/*     */     
/* 407 */     if (target instanceof Queue) { Queue<?> queue = (Queue)target;
/* 408 */       return proxyQueue(proxyFactory, queue); }
/*     */     
/* 410 */     if (target instanceof List) { List<?> list = (List)target;
/* 411 */       return proxyList(proxyFactory, list); }
/*     */     
/* 413 */     if (target instanceof SortedSet) { SortedSet<?> set = (SortedSet)target;
/* 414 */       return proxySortedSet(proxyFactory, set); }
/*     */     
/* 416 */     if (target instanceof Set) { Set<?> set = (Set)target;
/* 417 */       return proxySet(proxyFactory, set); }
/*     */     
/* 419 */     if (target.getClass().isArray()) {
/* 420 */       return proxyArray(proxyFactory, (Object[])target);
/*     */     }
/* 422 */     if (target instanceof SortedMap) { SortedMap<?, ?> map = (SortedMap<?, ?>)target;
/* 423 */       return proxySortedMap(proxyFactory, map); }
/*     */     
/* 425 */     if (target instanceof Iterable) { Iterable<?> iterable = (Iterable)target;
/* 426 */       return proxyIterable(proxyFactory, iterable); }
/*     */     
/* 428 */     if (target instanceof Map) { Map<?, ?> map = (Map<?, ?>)target;
/* 429 */       return proxyMap(proxyFactory, map); }
/*     */     
/* 431 */     if (target instanceof Stream) { Stream<?> stream = (Stream)target;
/* 432 */       return proxyStream(proxyFactory, stream); }
/*     */     
/* 434 */     if (target instanceof Optional) { Optional<?> optional = (Optional)target;
/* 435 */       return proxyOptional(proxyFactory, optional); }
/*     */     
/* 437 */     if (target instanceof Supplier) { Supplier<?> supplier = (Supplier)target;
/* 438 */       return proxySupplier(proxyFactory, supplier); }
/*     */     
/* 440 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T proxyCast(AuthorizationProxyFactory proxyFactory, T target) {
/* 445 */     return (T)proxyFactory.proxy(target);
/*     */   }
/*     */   
/*     */   private <T> Iterable<T> proxyIterable(AuthorizationProxyFactory proxyFactory, Iterable<T> iterable) {
/* 449 */     return () -> proxyIterator(proxyFactory, iterable.iterator());
/*     */   }
/*     */   
/*     */   private <T> Iterator<T> proxyIterator(final AuthorizationProxyFactory proxyFactory, final Iterator<T> iterator) {
/* 453 */     return new Iterator<T>()
/*     */       {
/*     */         public boolean hasNext() {
/* 456 */           return iterator.hasNext();
/*     */         }
/*     */ 
/*     */         
/*     */         public T next() {
/* 461 */           return AuthorizationAdvisorProxyFactory.ContainerTypeVisitor.this.proxyCast(proxyFactory, iterator.next());
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   private <T> SortedSet<T> proxySortedSet(AuthorizationProxyFactory proxyFactory, SortedSet<T> set) {
/* 467 */     SortedSet<T> proxies = new TreeSet<>(set.comparator());
/* 468 */     for (T toProxy : set) {
/* 469 */       proxies.add(proxyCast(proxyFactory, toProxy));
/*     */     }
/*     */     try {
/* 472 */       set.clear();
/* 473 */       set.addAll(proxies);
/* 474 */       return proxies;
/*     */     }
/* 476 */     catch (UnsupportedOperationException ex) {
/* 477 */       return Collections.unmodifiableSortedSet(proxies);
/*     */     } 
/*     */   }
/*     */   
/*     */   private <T> Set<T> proxySet(AuthorizationProxyFactory proxyFactory, Set<T> set) {
/* 482 */     Set<T> proxies = new LinkedHashSet<>(set.size());
/* 483 */     for (T toProxy : set) {
/* 484 */       proxies.add(proxyCast(proxyFactory, toProxy));
/*     */     }
/*     */     try {
/* 487 */       set.clear();
/* 488 */       set.addAll(proxies);
/* 489 */       return proxies;
/*     */     }
/* 491 */     catch (UnsupportedOperationException ex) {
/* 492 */       return Collections.unmodifiableSet(proxies);
/*     */     } 
/*     */   }
/*     */   
/*     */   private <T> Queue<T> proxyQueue(AuthorizationProxyFactory proxyFactory, Queue<T> queue) {
/* 497 */     Queue<T> proxies = new LinkedList<>();
/* 498 */     for (T toProxy : queue) {
/* 499 */       proxies.add(proxyCast(proxyFactory, toProxy));
/*     */     }
/* 501 */     queue.clear();
/* 502 */     queue.addAll(proxies);
/* 503 */     return proxies;
/*     */   }
/*     */   
/*     */   private <T> List<T> proxyList(AuthorizationProxyFactory proxyFactory, List<T> list) {
/* 507 */     List<T> proxies = new ArrayList<>(list.size());
/* 508 */     for (T toProxy : list) {
/* 509 */       proxies.add(proxyCast(proxyFactory, toProxy));
/*     */     }
/*     */     try {
/* 512 */       list.clear();
/* 513 */       list.addAll(proxies);
/* 514 */       return proxies;
/*     */     }
/* 516 */     catch (UnsupportedOperationException ex) {
/* 517 */       return Collections.unmodifiableList(proxies);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Object[] proxyArray(AuthorizationProxyFactory proxyFactory, Object[] objects) {
/* 522 */     List<Object> retain = new ArrayList(objects.length);
/* 523 */     for (Object object : objects) {
/* 524 */       retain.add(proxyFactory.proxy(object));
/*     */     }
/* 526 */     Object[] proxies = (Object[])Array.newInstance(objects.getClass().getComponentType(), retain.size());
/* 527 */     for (int i = 0; i < retain.size(); i++) {
/* 528 */       proxies[i] = retain.get(i);
/*     */     }
/* 530 */     return proxies;
/*     */   }
/*     */   
/*     */   private <K, V> SortedMap<K, V> proxySortedMap(AuthorizationProxyFactory proxyFactory, SortedMap<K, V> entries) {
/* 534 */     SortedMap<K, V> proxies = new TreeMap<>(entries.comparator());
/* 535 */     for (Map.Entry<K, V> entry : entries.entrySet()) {
/* 536 */       proxies.put(entry.getKey(), proxyCast(proxyFactory, entry.getValue()));
/*     */     }
/*     */     try {
/* 539 */       entries.clear();
/* 540 */       entries.putAll(proxies);
/* 541 */       return entries;
/*     */     }
/* 543 */     catch (UnsupportedOperationException ex) {
/* 544 */       return Collections.unmodifiableSortedMap(proxies);
/*     */     } 
/*     */   }
/*     */   
/*     */   private <K, V> Map<K, V> proxyMap(AuthorizationProxyFactory proxyFactory, Map<K, V> entries) {
/* 549 */     Map<K, V> proxies = new LinkedHashMap<>(entries.size());
/* 550 */     for (Map.Entry<K, V> entry : entries.entrySet()) {
/* 551 */       proxies.put(entry.getKey(), proxyCast(proxyFactory, entry.getValue()));
/*     */     }
/*     */     try {
/* 554 */       entries.clear();
/* 555 */       entries.putAll(proxies);
/* 556 */       return entries;
/*     */     }
/* 558 */     catch (UnsupportedOperationException ex) {
/* 559 */       return Collections.unmodifiableMap(proxies);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Stream<?> proxyStream(AuthorizationProxyFactory proxyFactory, Stream<?> stream) {
/* 564 */     Objects.requireNonNull(proxyFactory); Objects.requireNonNull(stream); return stream.map(proxyFactory::proxy).onClose(stream::close);
/*     */   }
/*     */ 
/*     */   
/*     */   private Optional<?> proxyOptional(AuthorizationProxyFactory proxyFactory, Optional<?> optional) {
/* 569 */     Objects.requireNonNull(proxyFactory); return optional.map(proxyFactory::proxy);
/*     */   }
/*     */   
/*     */   private Supplier<?> proxySupplier(AuthorizationProxyFactory proxyFactory, Supplier<?> supplier) {
/* 573 */     return () -> proxyFactory.proxy(supplier.get());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\AuthorizationAdvisorProxyFactory$ContainerTypeVisitor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */