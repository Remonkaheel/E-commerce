/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.core.MethodClassKey;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractExpressionAttributeRegistry<T extends ExpressionAttribute>
/*     */ {
/*  40 */   private final Map<MethodClassKey, T> cachedAttributes = new ConcurrentHashMap<>();
/*     */   
/*  42 */   private MethodSecurityExpressionHandler expressionHandler = (MethodSecurityExpressionHandler)new DefaultMethodSecurityExpressionHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final T getAttribute(MethodInvocation mi) {
/*  50 */     Method method = mi.getMethod();
/*  51 */     Object target = mi.getThis();
/*  52 */     Class<?> targetClass = (target != null) ? target.getClass() : null;
/*  53 */     return getAttribute(method, targetClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final T getAttribute(Method method, Class<?> targetClass) {
/*  63 */     MethodClassKey cacheKey = new MethodClassKey(method, targetClass);
/*  64 */     return this.cachedAttributes.computeIfAbsent(cacheKey, k -> resolveAttribute(method, targetClass));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MethodSecurityExpressionHandler getExpressionHandler() {
/*  72 */     return this.expressionHandler;
/*     */   }
/*     */   
/*     */   void setExpressionHandler(MethodSecurityExpressionHandler expressionHandler) {
/*  76 */     Assert.notNull(expressionHandler, "expressionHandler cannot be null");
/*  77 */     this.expressionHandler = expressionHandler;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   void setTemplateDefaults(PrePostTemplateDefaults defaults) {
/*  82 */     AnnotationTemplateExpressionDefaults adapter = new AnnotationTemplateExpressionDefaults();
/*  83 */     adapter.setIgnoreUnknown(defaults.isIgnoreUnknown());
/*  84 */     setTemplateDefaults(adapter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Class<?> targetClass(Method method, Class<?> targetClass) {
/* 100 */     return (targetClass != null) ? targetClass : method.getDeclaringClass();
/*     */   }
/*     */   
/*     */   abstract void setTemplateDefaults(AnnotationTemplateExpressionDefaults paramAnnotationTemplateExpressionDefaults);
/*     */   
/*     */   @NonNull
/*     */   abstract T resolveAttribute(Method paramMethod, Class<?> paramClass);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\AbstractExpressionAttributeRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */