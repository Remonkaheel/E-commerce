/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ import java.util.Objects;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.EvaluationException;
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.security.authorization.AuthorizationResult;
/*    */ import org.springframework.security.authorization.ExpressionAuthorizationDecision;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ReactiveExpressionUtils
/*    */ {
/*    */   static Mono<AuthorizationResult> evaluate(Expression expr, EvaluationContext ctx) {
/* 36 */     return Mono.defer(() -> {
/*    */           Object value;
/*    */           
/*    */           try {
/*    */             value = expr.getValue(ctx);
/* 41 */           } catch (EvaluationException ex) {
/*    */             return Mono.error(());
/*    */           } 
/*    */           if (value instanceof Mono) {
/*    */             Mono<?> mono = (Mono)value;
/*    */             return mono.flatMap(());
/*    */           } 
/*    */           return adapt(expr, value);
/*    */         });
/*    */   }
/*    */   
/*    */   private static Mono<AuthorizationResult> adapt(Expression expr, Object value) {
/* 53 */     if (value instanceof Boolean) { Boolean granted = (Boolean)value;
/* 54 */       return Mono.just(new ExpressionAuthorizationDecision(granted.booleanValue(), expr)); }
/*    */     
/* 56 */     if (value instanceof AuthorizationResult) { AuthorizationResult decision = (AuthorizationResult)value;
/* 57 */       return Mono.just(decision); }
/*    */     
/* 59 */     return createInvalidReturnTypeMono(expr);
/*    */   }
/*    */   
/*    */   static Mono<Boolean> evaluateAsBoolean(Expression expr, EvaluationContext ctx) {
/* 63 */     return Mono.defer(() -> {
/*    */           Object value;
/*    */           
/*    */           try {
/*    */             value = expr.getValue(ctx);
/* 68 */           } catch (EvaluationException ex) {
/*    */             return Mono.error(());
/*    */           } 
/*    */           if (value instanceof Boolean) {
/*    */             return Mono.just(value);
/*    */           }
/*    */           if (value instanceof Mono) {
/*    */             Mono<?> monoValue = (Mono)value;
/*    */             Objects.requireNonNull(Boolean.class);
/*    */             Objects.requireNonNull(Boolean.class);
/*    */             return monoValue.filter(Boolean.class::isInstance).map(Boolean.class::cast).switchIfEmpty(createInvalidReturnTypeMono(expr));
/*    */           } 
/*    */           return createInvalidReturnTypeMono(expr);
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static <T> Mono<T> createInvalidReturnTypeMono(Expression expr) {
/* 89 */     return Mono.error(() -> new IllegalStateException("Expression: '" + expr.getExpressionString() + "' must return boolean, Mono<Boolean>, AuthorizationResult, or Mono<AuthorizationResult>"));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\ReactiveExpressionUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */