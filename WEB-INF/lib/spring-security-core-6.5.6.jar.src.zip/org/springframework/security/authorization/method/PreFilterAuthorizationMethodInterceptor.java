/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.function.Supplier;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.prepost.PreFilter;
/*     */ import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PreFilterAuthorizationMethodInterceptor
/*     */   implements AuthorizationAdvisor
/*     */ {
/*  47 */   private Supplier<SecurityContextHolderStrategy> securityContextHolderStrategy = SecurityContextHolder::getContextHolderStrategy;
/*     */   
/*  49 */   private PreFilterExpressionAttributeRegistry registry = new PreFilterExpressionAttributeRegistry();
/*     */   
/*  51 */   private int order = AuthorizationInterceptorsOrder.PRE_FILTER.getOrder();
/*     */ 
/*     */ 
/*     */   
/*     */   private final Pointcut pointcut;
/*     */ 
/*     */ 
/*     */   
/*     */   public PreFilterAuthorizationMethodInterceptor() {
/*  60 */     this.pointcut = AuthorizationMethodPointcuts.forAnnotations((Class<? extends Annotation>[])new Class[] { PreFilter.class });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpressionHandler(MethodSecurityExpressionHandler expressionHandler) {
/*  68 */     this.registry.setExpressionHandler(expressionHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setTemplateDefaults(PrePostTemplateDefaults defaults) {
/*  83 */     this.registry.setTemplateDefaults(defaults);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTemplateDefaults(AnnotationTemplateExpressionDefaults defaults) {
/*  95 */     this.registry.setTemplateDefaults(defaults);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 103 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 107 */     this.order = order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pointcut getPointcut() {
/* 115 */     return this.pointcut;
/*     */   }
/*     */ 
/*     */   
/*     */   public Advice getAdvice() {
/* 120 */     return (Advice)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPerInstance() {
/* 125 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy strategy) {
/* 135 */     this.securityContextHolderStrategy = (() -> strategy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(MethodInvocation mi) throws Throwable {
/* 145 */     PreFilterExpressionAttributeRegistry.PreFilterExpressionAttribute attribute = this.registry.getAttribute(mi);
/* 146 */     if (attribute == PreFilterExpressionAttributeRegistry.PreFilterExpressionAttribute.NULL_ATTRIBUTE) {
/* 147 */       return mi.proceed();
/*     */     }
/* 149 */     MethodSecurityExpressionHandler expressionHandler = this.registry.getExpressionHandler();
/* 150 */     EvaluationContext ctx = expressionHandler.createEvaluationContext(this::getAuthentication, mi);
/* 151 */     Object filterTarget = findFilterTarget(attribute.getFilterTarget(), ctx, mi);
/* 152 */     expressionHandler.filter(filterTarget, attribute.getExpression(), ctx);
/* 153 */     return mi.proceed();
/*     */   }
/*     */   
/*     */   private Object findFilterTarget(String filterTargetName, EvaluationContext ctx, MethodInvocation methodInvocation) {
/*     */     Object filterTarget;
/* 158 */     if (StringUtils.hasText(filterTargetName)) {
/* 159 */       filterTarget = ctx.lookupVariable(filterTargetName);
/* 160 */       Assert.notNull(filterTarget, () -> "Filter target was null, or no argument with name '" + filterTargetName + "' found in method.");
/*     */     }
/*     */     else {
/*     */       
/* 164 */       Object[] arguments = methodInvocation.getArguments();
/* 165 */       Assert.state((arguments.length == 1), "Unable to determine the method argument for filtering. Specify the filter target.");
/*     */       
/* 167 */       filterTarget = arguments[0];
/* 168 */       Assert.notNull(filterTarget, "Filter target was null. Make sure you passing the correct value in the method argument.");
/*     */     } 
/*     */     
/* 171 */     Assert.state(!filterTarget.getClass().isArray(), "Pre-filtering on array types is not supported. Using a Collection will solve this problem.");
/*     */     
/* 173 */     return filterTarget;
/*     */   }
/*     */   
/*     */   private Authentication getAuthentication() {
/* 177 */     Authentication authentication = ((SecurityContextHolderStrategy)this.securityContextHolderStrategy.get()).getContext().getAuthentication();
/* 178 */     if (authentication == null) {
/* 179 */       throw new AuthenticationCredentialsNotFoundException("An Authentication object was not found in the SecurityContext");
/*     */     }
/*     */     
/* 182 */     return authentication;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\PreFilterAuthorizationMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */