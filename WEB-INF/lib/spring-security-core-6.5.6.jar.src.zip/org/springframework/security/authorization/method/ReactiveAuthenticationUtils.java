/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ import org.springframework.security.authentication.AnonymousAuthenticationToken;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.authority.AuthorityUtils;
/*    */ import org.springframework.security.core.context.ReactiveSecurityContextHolder;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ReactiveAuthenticationUtils
/*    */ {
/* 35 */   private static final Authentication ANONYMOUS = (Authentication)new AnonymousAuthenticationToken("key", "anonymous", 
/* 36 */       AuthorityUtils.createAuthorityList(new String[] { "ROLE_ANONYMOUS" }));
/*    */   
/*    */   static Mono<Authentication> getAuthentication() {
/* 39 */     return ReactiveSecurityContextHolder.getContext()
/* 40 */       .map(SecurityContext::getAuthentication)
/* 41 */       .defaultIfEmpty(ANONYMOUS);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\ReactiveAuthenticationUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */