/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.AuthorizationResult;
/*     */ import org.springframework.security.authorization.ReactiveAuthorizationManager;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PreAuthorizeReactiveAuthorizationManager
/*     */   implements ReactiveAuthorizationManager<MethodInvocation>, MethodAuthorizationDeniedHandler
/*     */ {
/*  44 */   private final PreAuthorizeExpressionAttributeRegistry registry = new PreAuthorizeExpressionAttributeRegistry();
/*     */   
/*     */   public PreAuthorizeReactiveAuthorizationManager() {
/*  47 */     this((MethodSecurityExpressionHandler)new DefaultMethodSecurityExpressionHandler());
/*     */   }
/*     */   
/*     */   public PreAuthorizeReactiveAuthorizationManager(MethodSecurityExpressionHandler expressionHandler) {
/*  51 */     Assert.notNull(expressionHandler, "expressionHandler cannot be null");
/*  52 */     this.registry.setExpressionHandler(expressionHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setTemplateDefaults(PrePostTemplateDefaults defaults) {
/*  67 */     this.registry.setTemplateDefaults(defaults);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTemplateDefaults(AnnotationTemplateExpressionDefaults defaults) {
/*  79 */     this.registry.setTemplateDefaults(defaults);
/*     */   }
/*     */   
/*     */   public void setApplicationContext(ApplicationContext context) {
/*  83 */     this.registry.setApplicationContext(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<AuthorizationDecision> check(Mono<Authentication> authentication, MethodInvocation mi) {
/*  96 */     ExpressionAttribute attribute = this.registry.getAttribute(mi);
/*  97 */     if (attribute == ExpressionAttribute.NULL_ATTRIBUTE) {
/*  98 */       return Mono.empty();
/*     */     }
/*     */     
/* 101 */     return authentication
/* 102 */       .map(auth -> this.registry.getExpressionHandler().createEvaluationContext(auth, mi))
/* 103 */       .flatMap(ctx -> ReactiveExpressionUtils.evaluate(attribute.getExpression(), ctx))
/* 104 */       .cast(AuthorizationDecision.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object handleDeniedInvocation(MethodInvocation methodInvocation, AuthorizationResult authorizationResult) {
/* 110 */     ExpressionAttribute attribute = this.registry.getAttribute(methodInvocation);
/* 111 */     PreAuthorizeExpressionAttribute preAuthorizeAttribute = (PreAuthorizeExpressionAttribute)attribute;
/* 112 */     return preAuthorizeAttribute.getHandler().handleDeniedInvocation(methodInvocation, authorizationResult);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\PreAuthorizeReactiveAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */