/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum AuthorizationInterceptorsOrder
/*    */ {
/* 33 */   FIRST(-2147483648),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 38 */   PRE_FILTER,
/*    */   
/* 40 */   PRE_AUTHORIZE,
/*    */   
/* 42 */   SECURED,
/*    */   
/* 44 */   JSR250,
/*    */   
/* 46 */   SECURE_RESULT(450),
/*    */   
/* 48 */   POST_AUTHORIZE(500),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   POST_FILTER(600),
/*    */   
/* 55 */   LAST(2147483647);
/*    */   
/*    */   private static final int INTERVAL = 100;
/*    */   
/*    */   private final int order;
/*    */   
/*    */   AuthorizationInterceptorsOrder() {
/* 62 */     this.order = ordinal() * 100;
/*    */   }
/*    */   
/*    */   AuthorizationInterceptorsOrder(int order) {
/* 66 */     this.order = order;
/*    */   }
/*    */   
/*    */   public int getOrder() {
/* 70 */     return this.order;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\AuthorizationInterceptorsOrder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */