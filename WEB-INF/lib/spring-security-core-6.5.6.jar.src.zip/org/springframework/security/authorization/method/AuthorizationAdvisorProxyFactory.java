/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Optional;
/*     */ import java.util.Queue;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import java.util.function.Supplier;
/*     */ import java.util.stream.Stream;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.framework.AopInfrastructureBean;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.beans.factory.SmartInitializingSingleton;
/*     */ import org.springframework.core.annotation.AnnotationAwareOrderComparator;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.security.authorization.AuthorizationProxyFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthorizationAdvisorProxyFactory
/*     */   implements AuthorizationProxyFactory, Iterable<AuthorizationAdvisor>, AopInfrastructureBean, SmartInitializingSingleton
/*     */ {
/*  86 */   private static final boolean isReactivePresent = ClassUtils.isPresent("reactor.core.publisher.Mono", null);
/*     */   
/*  88 */   private static final TargetVisitor DEFAULT_VISITOR = isReactivePresent ? 
/*  89 */     TargetVisitor.of(new TargetVisitor[] { new ClassVisitor(), new ReactiveTypeVisitor(), new ContainerTypeVisitor()
/*  90 */       }) : TargetVisitor.of(new TargetVisitor[] { new ClassVisitor(), new ContainerTypeVisitor() });
/*     */   
/*  92 */   private static final TargetVisitor DEFAULT_VISITOR_SKIP_VALUE_TYPES = TargetVisitor.of(new TargetVisitor[] { new ClassVisitor(), new IgnoreValueTypeVisitor(), DEFAULT_VISITOR });
/*     */ 
/*     */   
/*  95 */   private final AuthorizationProxyMethodInterceptor authorizationProxy = new AuthorizationProxyMethodInterceptor();
/*     */   
/*     */   private List<AuthorizationAdvisor> advisors;
/*     */   
/*  99 */   private TargetVisitor visitor = DEFAULT_VISITOR;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationAdvisorProxyFactory(List<AuthorizationAdvisor> advisors) {
/* 107 */     this.advisors = new ArrayList<>(advisors);
/* 108 */     for (AuthorizationAdvisor advisor : this.advisors) {
/* 109 */       if (advisor instanceof AuthorizeReturnObjectMethodInterceptor) { AuthorizeReturnObjectMethodInterceptor interceptor = (AuthorizeReturnObjectMethodInterceptor)advisor;
/* 110 */         interceptor.setAuthorizationProxyFactory(this); }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationAdvisorProxyFactory withDefaults() {
/* 122 */     List<AuthorizationAdvisor> advisors = new ArrayList<>();
/* 123 */     advisors.add(AuthorizationManagerBeforeMethodInterceptor.preAuthorize());
/* 124 */     advisors.add(AuthorizationManagerAfterMethodInterceptor.postAuthorize());
/* 125 */     advisors.add(new PreFilterAuthorizationMethodInterceptor());
/* 126 */     advisors.add(new PostFilterAuthorizationMethodInterceptor());
/* 127 */     advisors.add(new AuthorizeReturnObjectMethodInterceptor());
/* 128 */     AuthorizationAdvisorProxyFactory proxyFactory = new AuthorizationAdvisorProxyFactory(advisors);
/* 129 */     AnnotationAwareOrderComparator.sort(proxyFactory.advisors);
/* 130 */     return proxyFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationAdvisorProxyFactory withReactiveDefaults() {
/* 140 */     List<AuthorizationAdvisor> advisors = new ArrayList<>();
/* 141 */     advisors.add(AuthorizationManagerBeforeReactiveMethodInterceptor.preAuthorize());
/* 142 */     advisors.add(AuthorizationManagerAfterReactiveMethodInterceptor.postAuthorize());
/* 143 */     advisors.add(new PreFilterAuthorizationReactiveMethodInterceptor());
/* 144 */     advisors.add(new PostFilterAuthorizationReactiveMethodInterceptor());
/* 145 */     advisors.add(new AuthorizeReturnObjectMethodInterceptor());
/* 146 */     AuthorizationAdvisorProxyFactory proxyFactory = new AuthorizationAdvisorProxyFactory(advisors);
/* 147 */     AnnotationAwareOrderComparator.sort(proxyFactory.advisors);
/* 148 */     return proxyFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterSingletonsInstantiated() {
/* 153 */     AnnotationAwareOrderComparator.sort(this.advisors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object proxy(Object target) {
/* 176 */     if (target == null) {
/* 177 */       return null;
/*     */     }
/* 179 */     if (target instanceof AuthorizationProxy) { AuthorizationProxy authorizationProxy = (AuthorizationProxy)target;
/* 180 */       return authorizationProxy; }
/*     */     
/* 182 */     Object proxied = this.visitor.visit(this, target);
/* 183 */     if (proxied != null) {
/* 184 */       return proxied;
/*     */     }
/* 186 */     ProxyFactory factory = new ProxyFactory(target);
/* 187 */     factory.addAdvisors(new Advisor[] { (Advisor)this.authorizationProxy });
/* 188 */     List<Advisor> advisors = new ArrayList(this.advisors);
/* 189 */     AnnotationAwareOrderComparator.sort(advisors);
/* 190 */     factory.addAdvisors(advisors);
/* 191 */     factory.addInterface(AuthorizationProxy.class);
/* 192 */     factory.setOpaque(true);
/* 193 */     factory.setProxyTargetClass(!Modifier.isFinal(target.getClass().getModifiers()));
/* 194 */     return factory.getProxy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setAdvisors(AuthorizationAdvisor... advisors) {
/* 207 */     this.advisors = new ArrayList<>(List.of(advisors));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setAdvisors(Collection<AuthorizationAdvisor> advisors) {
/* 220 */     this.advisors = new ArrayList<>(advisors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void addAdvisor(AuthorizationAdvisor advisor) {
/* 237 */     this.advisors.add(advisor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetVisitor(TargetVisitor visitor) {
/* 276 */     Assert.notNull(visitor, "delegate cannot be null");
/* 277 */     this.visitor = visitor;
/*     */   }
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public Iterator<AuthorizationAdvisor> iterator() {
/* 283 */     return this.advisors.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface TargetVisitor
/*     */   {
/*     */     Object visit(AuthorizationAdvisorProxyFactory param1AuthorizationAdvisorProxyFactory, Object param1Object);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static TargetVisitor defaults() {
/* 324 */       return AuthorizationAdvisorProxyFactory.DEFAULT_VISITOR;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static TargetVisitor defaultsSkipValueTypes() {
/* 333 */       return AuthorizationAdvisorProxyFactory.DEFAULT_VISITOR_SKIP_VALUE_TYPES;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     static TargetVisitor of(TargetVisitor... visitors) {
/* 348 */       return (proxyFactory, target) -> {
/*     */           for (TargetVisitor visitor : visitors) {
/*     */             Object result = visitor.visit(proxyFactory, target);
/*     */             if (result != null) {
/*     */               return result;
/*     */             }
/*     */           } 
/*     */           return null;
/*     */         };
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class IgnoreValueTypeVisitor
/*     */     implements TargetVisitor
/*     */   {
/*     */     public Object visit(AuthorizationAdvisorProxyFactory proxyFactory, Object object) {
/* 365 */       if (ClassUtils.isSimpleValueType(object.getClass())) {
/* 366 */         return object;
/*     */       }
/* 368 */       return null;
/*     */     } }
/*     */   
/*     */   private static final class ClassVisitor implements TargetVisitor {
/*     */     private final AuthorizationAdvisorProxyFactory.AuthorizationProxyMethodInterceptor authorizationProxy;
/*     */     
/*     */     private ClassVisitor() {
/* 375 */       this.authorizationProxy = new AuthorizationAdvisorProxyFactory.AuthorizationProxyMethodInterceptor();
/*     */     }
/*     */     
/*     */     public Object visit(AuthorizationAdvisorProxyFactory proxyFactory, Object object) {
/* 379 */       if (object instanceof Class) { Class<?> targetClass = (Class)object;
/* 380 */         if (AuthorizationProxy.class.isAssignableFrom(targetClass)) {
/* 381 */           return targetClass;
/*     */         }
/* 383 */         ProxyFactory factory = new ProxyFactory();
/* 384 */         factory.setTargetClass(targetClass);
/* 385 */         factory.setInterfaces(ClassUtils.getAllInterfacesForClass(targetClass));
/* 386 */         factory.setOpaque(true);
/* 387 */         factory.setProxyTargetClass(!Modifier.isFinal(targetClass.getModifiers()));
/* 388 */         factory.addAdvisor((Advisor)this.authorizationProxy);
/* 389 */         for (Advisor advisor : proxyFactory) {
/* 390 */           factory.addAdvisors(new Advisor[] { advisor });
/*     */         } 
/* 392 */         factory.addInterface(AuthorizationProxy.class);
/* 393 */         return factory.getProxyClass(getClass().getClassLoader()); }
/*     */       
/* 395 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class ContainerTypeVisitor
/*     */     implements TargetVisitor
/*     */   {
/*     */     public Object visit(AuthorizationAdvisorProxyFactory proxyFactory, Object target) {
/* 404 */       if (target instanceof Iterator) { Iterator<?> iterator = (Iterator)target;
/* 405 */         return proxyIterator(proxyFactory, iterator); }
/*     */       
/* 407 */       if (target instanceof Queue) { Queue<?> queue = (Queue)target;
/* 408 */         return proxyQueue(proxyFactory, queue); }
/*     */       
/* 410 */       if (target instanceof List) { List<?> list = (List)target;
/* 411 */         return proxyList(proxyFactory, list); }
/*     */       
/* 413 */       if (target instanceof SortedSet) { SortedSet<?> set = (SortedSet)target;
/* 414 */         return proxySortedSet(proxyFactory, set); }
/*     */       
/* 416 */       if (target instanceof Set) { Set<?> set = (Set)target;
/* 417 */         return proxySet(proxyFactory, set); }
/*     */       
/* 419 */       if (target.getClass().isArray()) {
/* 420 */         return proxyArray(proxyFactory, (Object[])target);
/*     */       }
/* 422 */       if (target instanceof SortedMap) { SortedMap<?, ?> map = (SortedMap<?, ?>)target;
/* 423 */         return proxySortedMap(proxyFactory, map); }
/*     */       
/* 425 */       if (target instanceof Iterable) { Iterable<?> iterable = (Iterable)target;
/* 426 */         return proxyIterable(proxyFactory, iterable); }
/*     */       
/* 428 */       if (target instanceof Map) { Map<?, ?> map = (Map<?, ?>)target;
/* 429 */         return proxyMap(proxyFactory, map); }
/*     */       
/* 431 */       if (target instanceof Stream) { Stream<?> stream = (Stream)target;
/* 432 */         return proxyStream(proxyFactory, stream); }
/*     */       
/* 434 */       if (target instanceof Optional) { Optional<?> optional = (Optional)target;
/* 435 */         return proxyOptional(proxyFactory, optional); }
/*     */       
/* 437 */       if (target instanceof Supplier) { Supplier<?> supplier = (Supplier)target;
/* 438 */         return proxySupplier(proxyFactory, supplier); }
/*     */       
/* 440 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     private <T> T proxyCast(AuthorizationProxyFactory proxyFactory, T target) {
/* 445 */       return (T)proxyFactory.proxy(target);
/*     */     }
/*     */     
/*     */     private <T> Iterable<T> proxyIterable(AuthorizationProxyFactory proxyFactory, Iterable<T> iterable) {
/* 449 */       return () -> proxyIterator(proxyFactory, iterable.iterator());
/*     */     }
/*     */     
/*     */     private <T> Iterator<T> proxyIterator(final AuthorizationProxyFactory proxyFactory, final Iterator<T> iterator) {
/* 453 */       return new Iterator<T>()
/*     */         {
/*     */           public boolean hasNext() {
/* 456 */             return iterator.hasNext();
/*     */           }
/*     */ 
/*     */           
/*     */           public T next() {
/* 461 */             return AuthorizationAdvisorProxyFactory.ContainerTypeVisitor.this.proxyCast(proxyFactory, iterator.next());
/*     */           }
/*     */         };
/*     */     }
/*     */     
/*     */     private <T> SortedSet<T> proxySortedSet(AuthorizationProxyFactory proxyFactory, SortedSet<T> set) {
/* 467 */       SortedSet<T> proxies = new TreeSet<>(set.comparator());
/* 468 */       for (T toProxy : set) {
/* 469 */         proxies.add(proxyCast(proxyFactory, toProxy));
/*     */       }
/*     */       try {
/* 472 */         set.clear();
/* 473 */         set.addAll(proxies);
/* 474 */         return proxies;
/*     */       }
/* 476 */       catch (UnsupportedOperationException ex) {
/* 477 */         return Collections.unmodifiableSortedSet(proxies);
/*     */       } 
/*     */     }
/*     */     
/*     */     private <T> Set<T> proxySet(AuthorizationProxyFactory proxyFactory, Set<T> set) {
/* 482 */       Set<T> proxies = new LinkedHashSet<>(set.size());
/* 483 */       for (T toProxy : set) {
/* 484 */         proxies.add(proxyCast(proxyFactory, toProxy));
/*     */       }
/*     */       try {
/* 487 */         set.clear();
/* 488 */         set.addAll(proxies);
/* 489 */         return proxies;
/*     */       }
/* 491 */       catch (UnsupportedOperationException ex) {
/* 492 */         return Collections.unmodifiableSet(proxies);
/*     */       } 
/*     */     }
/*     */     
/*     */     private <T> Queue<T> proxyQueue(AuthorizationProxyFactory proxyFactory, Queue<T> queue) {
/* 497 */       Queue<T> proxies = new LinkedList<>();
/* 498 */       for (T toProxy : queue) {
/* 499 */         proxies.add(proxyCast(proxyFactory, toProxy));
/*     */       }
/* 501 */       queue.clear();
/* 502 */       queue.addAll(proxies);
/* 503 */       return proxies;
/*     */     }
/*     */     
/*     */     private <T> List<T> proxyList(AuthorizationProxyFactory proxyFactory, List<T> list) {
/* 507 */       List<T> proxies = new ArrayList<>(list.size());
/* 508 */       for (T toProxy : list) {
/* 509 */         proxies.add(proxyCast(proxyFactory, toProxy));
/*     */       }
/*     */       try {
/* 512 */         list.clear();
/* 513 */         list.addAll(proxies);
/* 514 */         return proxies;
/*     */       }
/* 516 */       catch (UnsupportedOperationException ex) {
/* 517 */         return Collections.unmodifiableList(proxies);
/*     */       } 
/*     */     }
/*     */     
/*     */     private Object[] proxyArray(AuthorizationProxyFactory proxyFactory, Object[] objects) {
/* 522 */       List<Object> retain = new ArrayList(objects.length);
/* 523 */       for (Object object : objects) {
/* 524 */         retain.add(proxyFactory.proxy(object));
/*     */       }
/* 526 */       Object[] proxies = (Object[])Array.newInstance(objects.getClass().getComponentType(), retain.size());
/* 527 */       for (int i = 0; i < retain.size(); i++) {
/* 528 */         proxies[i] = retain.get(i);
/*     */       }
/* 530 */       return proxies;
/*     */     }
/*     */     
/*     */     private <K, V> SortedMap<K, V> proxySortedMap(AuthorizationProxyFactory proxyFactory, SortedMap<K, V> entries) {
/* 534 */       SortedMap<K, V> proxies = new TreeMap<>(entries.comparator());
/* 535 */       for (Map.Entry<K, V> entry : entries.entrySet()) {
/* 536 */         proxies.put(entry.getKey(), proxyCast(proxyFactory, entry.getValue()));
/*     */       }
/*     */       try {
/* 539 */         entries.clear();
/* 540 */         entries.putAll(proxies);
/* 541 */         return entries;
/*     */       }
/* 543 */       catch (UnsupportedOperationException ex) {
/* 544 */         return Collections.unmodifiableSortedMap(proxies);
/*     */       } 
/*     */     }
/*     */     
/*     */     private <K, V> Map<K, V> proxyMap(AuthorizationProxyFactory proxyFactory, Map<K, V> entries) {
/* 549 */       Map<K, V> proxies = new LinkedHashMap<>(entries.size());
/* 550 */       for (Map.Entry<K, V> entry : entries.entrySet()) {
/* 551 */         proxies.put(entry.getKey(), proxyCast(proxyFactory, entry.getValue()));
/*     */       }
/*     */       try {
/* 554 */         entries.clear();
/* 555 */         entries.putAll(proxies);
/* 556 */         return entries;
/*     */       }
/* 558 */       catch (UnsupportedOperationException ex) {
/* 559 */         return Collections.unmodifiableMap(proxies);
/*     */       } 
/*     */     }
/*     */     
/*     */     private Stream<?> proxyStream(AuthorizationProxyFactory proxyFactory, Stream<?> stream) {
/* 564 */       Objects.requireNonNull(proxyFactory); Objects.requireNonNull(stream); return stream.map(proxyFactory::proxy).onClose(stream::close);
/*     */     }
/*     */ 
/*     */     
/*     */     private Optional<?> proxyOptional(AuthorizationProxyFactory proxyFactory, Optional<?> optional) {
/* 569 */       Objects.requireNonNull(proxyFactory); return optional.map(proxyFactory::proxy);
/*     */     }
/*     */     
/*     */     private Supplier<?> proxySupplier(AuthorizationProxyFactory proxyFactory, Supplier<?> supplier) {
/* 573 */       return () -> proxyFactory.proxy(supplier.get());
/*     */     }
/*     */   }
/*     */   class null implements Iterator<T> { public boolean hasNext() {
/*     */       return iterator.hasNext();
/*     */     }
/*     */     public T next() {
/*     */       return AuthorizationAdvisorProxyFactory.ContainerTypeVisitor.this.proxyCast(proxyFactory, iterator.next());
/*     */     } }
/*     */   private static class ReactiveTypeVisitor implements TargetVisitor { public Object visit(AuthorizationAdvisorProxyFactory proxyFactory, Object target) {
/* 583 */       if (target instanceof Mono) { Mono<?> mono = (Mono)target;
/* 584 */         return proxyMono(proxyFactory, mono); }
/*     */       
/* 586 */       if (target instanceof Flux) { Flux<?> flux = (Flux)target;
/* 587 */         return proxyFlux(proxyFactory, flux); }
/*     */       
/* 589 */       return null;
/*     */     }
/*     */     
/*     */     private Mono<?> proxyMono(AuthorizationProxyFactory proxyFactory, Mono<?> mono) {
/* 593 */       Objects.requireNonNull(proxyFactory); return mono.map(proxyFactory::proxy);
/*     */     }
/*     */     
/*     */     private Flux<?> proxyFlux(AuthorizationProxyFactory proxyFactory, Flux<?> flux) {
/* 597 */       Objects.requireNonNull(proxyFactory); return flux.map(proxyFactory::proxy);
/*     */     } }
/*     */ 
/*     */   
/*     */   private static final class AuthorizationProxyMethodInterceptor
/*     */     implements AuthorizationAdvisor
/*     */   {
/* 604 */     private static final Method GET_TARGET_METHOD = ClassUtils.getMethod(AuthorizationProxy.class, "toAuthorizedTarget", new Class[0]);
/*     */ 
/*     */ 
/*     */     
/*     */     public Object invoke(MethodInvocation invocation) throws Throwable {
/* 609 */       if (invocation.getMethod().equals(GET_TARGET_METHOD)) {
/* 610 */         return invocation.getThis();
/*     */       }
/* 612 */       return invocation.proceed();
/*     */     }
/*     */ 
/*     */     
/*     */     public Pointcut getPointcut() {
/* 617 */       return Pointcut.TRUE;
/*     */     }
/*     */ 
/*     */     
/*     */     public Advice getAdvice() {
/* 622 */       return (Advice)this;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getOrder() {
/* 627 */       return 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\AuthorizationAdvisorProxyFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */