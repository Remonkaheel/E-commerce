/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.lang.NonNull;
/*    */ import org.springframework.security.access.prepost.PostFilter;
/*    */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*    */ import org.springframework.security.core.annotation.SecurityAnnotationScanner;
/*    */ import org.springframework.security.core.annotation.SecurityAnnotationScanners;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PostFilterExpressionAttributeRegistry
/*    */   extends AbstractExpressionAttributeRegistry<ExpressionAttribute>
/*    */ {
/* 37 */   private SecurityAnnotationScanner<PostFilter> scanner = SecurityAnnotationScanners.requireUnique(PostFilter.class);
/*    */ 
/*    */   
/*    */   @NonNull
/*    */   ExpressionAttribute resolveAttribute(Method method, Class<?> targetClass) {
/* 42 */     PostFilter postFilter = findPostFilterAnnotation(method, targetClass);
/* 43 */     if (postFilter == null) {
/* 44 */       return ExpressionAttribute.NULL_ATTRIBUTE;
/*    */     }
/*    */     
/* 47 */     Expression postFilterExpression = getExpressionHandler().getExpressionParser().parseExpression(postFilter.value());
/* 48 */     return new ExpressionAttribute(postFilterExpression);
/*    */   }
/*    */   
/*    */   void setTemplateDefaults(AnnotationTemplateExpressionDefaults defaults) {
/* 52 */     this.scanner = SecurityAnnotationScanners.requireUnique(PostFilter.class, defaults);
/*    */   }
/*    */   
/*    */   private PostFilter findPostFilterAnnotation(Method method, Class<?> targetClass) {
/* 56 */     Class<?> targetClassToUse = targetClass(method, targetClass);
/* 57 */     return (PostFilter)this.scanner.scan(method, targetClassToUse);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\PostFilterExpressionAttributeRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */