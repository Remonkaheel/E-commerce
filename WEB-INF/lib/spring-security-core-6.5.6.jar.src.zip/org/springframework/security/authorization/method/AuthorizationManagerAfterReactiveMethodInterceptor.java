/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.function.Function;
/*     */ import kotlinx.coroutines.reactive.ReactiveFlowKt;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ReactiveAdapter;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.security.access.prepost.PostAuthorize;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.AuthorizationDeniedException;
/*     */ import org.springframework.security.authorization.AuthorizationResult;
/*     */ import org.springframework.security.authorization.ReactiveAuthorizationManager;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.publisher.Signal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthorizationManagerAfterReactiveMethodInterceptor
/*     */   implements AuthorizationAdvisor
/*     */ {
/*     */   private static final String COROUTINES_FLOW_CLASS_NAME = "kotlinx.coroutines.flow.Flow";
/*     */   private static final int RETURN_TYPE_METHOD_PARAMETER_INDEX = -1;
/*     */   private final Pointcut pointcut;
/*     */   private final ReactiveAuthorizationManager<MethodInvocationResult> authorizationManager;
/*  62 */   private int order = AuthorizationInterceptorsOrder.LAST.getOrder();
/*     */   
/*  64 */   private final MethodAuthorizationDeniedHandler defaultHandler = new ThrowingMethodAuthorizationDeniedHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationManagerAfterReactiveMethodInterceptor postAuthorize() {
/*  71 */     return postAuthorize(new PostAuthorizeReactiveAuthorizationManager());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationManagerAfterReactiveMethodInterceptor postAuthorize(ReactiveAuthorizationManager<MethodInvocationResult> authorizationManager) {
/*  82 */     AuthorizationManagerAfterReactiveMethodInterceptor interceptor = new AuthorizationManagerAfterReactiveMethodInterceptor(AuthorizationMethodPointcuts.forAnnotations((Class<? extends Annotation>[])new Class[] { PostAuthorize.class }, ), authorizationManager);
/*  83 */     interceptor.setOrder(AuthorizationInterceptorsOrder.POST_AUTHORIZE.getOrder());
/*  84 */     return interceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationManagerAfterReactiveMethodInterceptor(Pointcut pointcut, ReactiveAuthorizationManager<MethodInvocationResult> authorizationManager) {
/*  94 */     Assert.notNull(pointcut, "pointcut cannot be null");
/*  95 */     Assert.notNull(authorizationManager, "authorizationManager cannot be null");
/*  96 */     this.pointcut = pointcut;
/*  97 */     this.authorizationManager = authorizationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(MethodInvocation mi) throws Throwable {
/* 109 */     Method method = mi.getMethod();
/* 110 */     Class<?> type = method.getReturnType();
/* 111 */     boolean isSuspendingFunction = KotlinDetector.isSuspendingFunction(method);
/*     */     
/* 113 */     boolean hasFlowReturnType = "kotlinx.coroutines.flow.Flow".equals((new MethodParameter(method, -1)).getParameterType().getName());
/* 114 */     boolean hasReactiveReturnType = (Publisher.class.isAssignableFrom(type) || isSuspendingFunction || hasFlowReturnType);
/*     */     
/* 116 */     Assert.state(hasReactiveReturnType, () -> "The returnType " + String.valueOf(type) + " on " + String.valueOf(method) + " must return an instance of org.reactivestreams.Publisher (for example, a Mono or Flux) or the function must be a Kotlin coroutine in order to support Reactor Context");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     Mono<Authentication> authentication = ReactiveAuthenticationUtils.getAuthentication();
/* 122 */     Function<Signal<?>, Mono<?>> postAuthorize = signal -> {
/*     */         if (signal.isOnComplete())
/*     */           return Mono.empty(); 
/*     */         if (!signal.hasError())
/*     */           return postAuthorize(authentication, mi, signal.get()); 
/*     */         Throwable patt5721$temp = signal.getThrowable();
/*     */         if (patt5721$temp instanceof AuthorizationDeniedException) {
/*     */           AuthorizationDeniedException denied = (AuthorizationDeniedException)patt5721$temp;
/*     */           return postProcess((AuthorizationResult)denied, mi);
/*     */         } 
/*     */         return Mono.error(signal.getThrowable());
/*     */       };
/* 134 */     ReactiveAdapter adapter = ReactiveAdapterRegistry.getSharedInstance().getAdapter(type);
/* 135 */     if (hasFlowReturnType) {
/* 136 */       if (isSuspendingFunction) {
/* 137 */         Publisher<?> publisher1 = ReactiveMethodInvocationUtils.<Publisher>proceed(mi);
/* 138 */         return Flux.from(publisher1).materialize().flatMap(postAuthorize);
/*     */       } 
/*     */       
/* 141 */       Assert.state((adapter != null), () -> "The returnType " + String.valueOf(type) + " on " + String.valueOf(method) + " must have a org.springframework.core.ReactiveAdapter registered");
/*     */ 
/*     */ 
/*     */       
/* 145 */       Flux<?> response = Flux.defer(() -> adapter.toPublisher(ReactiveMethodInvocationUtils.proceed(mi))).materialize().flatMap(postAuthorize);
/* 146 */       return KotlinDelegate.asFlow((Publisher<?>)response);
/*     */     } 
/*     */     
/* 149 */     Publisher<?> publisher = ReactiveMethodInvocationUtils.<Publisher>proceed(mi);
/* 150 */     if (isMultiValue(type, adapter)) {
/* 151 */       Flux<?> flux = Flux.from(publisher).materialize().flatMap(postAuthorize);
/* 152 */       return (adapter != null) ? adapter.fromPublisher((Publisher)flux) : flux;
/*     */     } 
/* 154 */     Mono<?> mono = Mono.from(publisher).materialize().flatMap(postAuthorize);
/* 155 */     return (adapter != null) ? adapter.fromPublisher((Publisher)mono) : mono;
/*     */   }
/*     */   
/*     */   private boolean isMultiValue(Class<?> returnType, ReactiveAdapter adapter) {
/* 159 */     if (Flux.class.isAssignableFrom(returnType)) {
/* 160 */       return true;
/*     */     }
/* 162 */     return (adapter != null && adapter.isMultiValue());
/*     */   }
/*     */   
/*     */   private Mono<Object> postAuthorize(Mono<Authentication> authentication, MethodInvocation mi, Object result) {
/* 166 */     MethodInvocationResult invocationResult = new MethodInvocationResult(mi, result);
/* 167 */     return this.authorizationManager.authorize(authentication, invocationResult)
/* 168 */       .switchIfEmpty(Mono.just(new AuthorizationDecision(false)))
/* 169 */       .flatMap(decision -> postProcess(decision, invocationResult));
/*     */   }
/*     */   
/*     */   private Mono<Object> postProcess(AuthorizationResult decision, MethodInvocationResult methodInvocationResult) {
/* 173 */     if (decision.isGranted()) {
/* 174 */       return Mono.just(methodInvocationResult.getResult());
/*     */     }
/* 176 */     return Mono.fromSupplier(() -> {
/*     */           ReactiveAuthorizationManager<MethodInvocationResult> patt7817$temp = this.authorizationManager; if (patt7817$temp instanceof MethodAuthorizationDeniedHandler) {
/*     */             MethodAuthorizationDeniedHandler handler = (MethodAuthorizationDeniedHandler)patt7817$temp; return handler.handleDeniedInvocationResult(methodInvocationResult, decision);
/*     */           } 
/*     */           return this.defaultHandler.handleDeniedInvocationResult(methodInvocationResult, decision);
/* 181 */         }).flatMap(processedResult -> Mono.class.isAssignableFrom(processedResult.getClass()) ? (Mono)processedResult : Mono.justOrEmpty(processedResult));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Mono<Object> postProcess(AuthorizationResult decision, MethodInvocation methodInvocation) {
/* 190 */     return Mono.fromSupplier(() -> {
/*     */           ReactiveAuthorizationManager<MethodInvocationResult> patt8423$temp = this.authorizationManager; if (patt8423$temp instanceof MethodAuthorizationDeniedHandler) {
/*     */             MethodAuthorizationDeniedHandler handler = (MethodAuthorizationDeniedHandler)patt8423$temp; return handler.handleDeniedInvocation(methodInvocation, decision);
/*     */           } 
/*     */           return this.defaultHandler.handleDeniedInvocation(methodInvocation, decision);
/* 195 */         }).flatMap(processedResult -> Mono.class.isAssignableFrom(processedResult.getClass()) ? (Mono)processedResult : Mono.justOrEmpty(processedResult));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pointcut getPointcut() {
/* 205 */     return this.pointcut;
/*     */   }
/*     */ 
/*     */   
/*     */   public Advice getAdvice() {
/* 210 */     return (Advice)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPerInstance() {
/* 215 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 220 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 224 */     this.order = order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class KotlinDelegate
/*     */   {
/*     */     private static Object asFlow(Publisher<?> publisher) {
/* 233 */       return ReactiveFlowKt.asFlow(publisher);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\AuthorizationManagerAfterReactiveMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */