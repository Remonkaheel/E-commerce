/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.security.access.expression.ExpressionUtils;
/*    */ import org.springframework.security.access.expression.SecurityExpressionHandler;
/*    */ import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
/*    */ import org.springframework.security.authorization.AuthorizationDecision;
/*    */ import org.springframework.security.authorization.AuthorizationManager;
/*    */ import org.springframework.security.authorization.ExpressionAuthorizationDecision;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MethodExpressionAuthorizationManager
/*    */   implements AuthorizationManager<MethodInvocation>
/*    */ {
/* 43 */   private SecurityExpressionHandler<MethodInvocation> expressionHandler = (SecurityExpressionHandler<MethodInvocation>)new DefaultMethodSecurityExpressionHandler();
/*    */ 
/*    */ 
/*    */   
/*    */   private Expression expression;
/*    */ 
/*    */ 
/*    */   
/*    */   public MethodExpressionAuthorizationManager(String expressionString) {
/* 52 */     Assert.hasText(expressionString, "expressionString cannot be empty");
/* 53 */     this.expression = this.expressionHandler.getExpressionParser().parseExpression(expressionString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setExpressionHandler(SecurityExpressionHandler<MethodInvocation> expressionHandler) {
/* 62 */     Assert.notNull(expressionHandler, "expressionHandler cannot be null");
/* 63 */     this.expressionHandler = expressionHandler;
/* 64 */     this
/* 65 */       .expression = expressionHandler.getExpressionParser().parseExpression(this.expression.getExpressionString());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AuthorizationDecision check(Supplier<Authentication> authentication, MethodInvocation context) {
/* 77 */     EvaluationContext ctx = this.expressionHandler.createEvaluationContext(authentication, context);
/* 78 */     boolean granted = ExpressionUtils.evaluateAsBoolean(this.expression, ctx);
/* 79 */     return (AuthorizationDecision)new ExpressionAuthorizationDecision(granted, this.expression);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 84 */     return "WebExpressionAuthorizationManager[expression='" + String.valueOf(this.expression) + "']";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\MethodExpressionAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */