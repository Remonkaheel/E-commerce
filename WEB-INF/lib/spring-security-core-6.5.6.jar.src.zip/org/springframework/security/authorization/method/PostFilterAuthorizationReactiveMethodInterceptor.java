/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.core.ReactiveAdapter;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.expression.method.MethodSecurityExpressionOperations;
/*     */ import org.springframework.security.access.prepost.PostFilter;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PostFilterAuthorizationReactiveMethodInterceptor
/*     */   implements AuthorizationAdvisor
/*     */ {
/*  49 */   private final PostFilterExpressionAttributeRegistry registry = new PostFilterExpressionAttributeRegistry();
/*     */   
/*  51 */   private final Pointcut pointcut = AuthorizationMethodPointcuts.forAnnotations((Class<? extends Annotation>[])new Class[] { PostFilter.class });
/*     */   
/*  53 */   private int order = AuthorizationInterceptorsOrder.POST_FILTER.getOrder();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PostFilterAuthorizationReactiveMethodInterceptor() {
/*  59 */     this((MethodSecurityExpressionHandler)new DefaultMethodSecurityExpressionHandler());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PostFilterAuthorizationReactiveMethodInterceptor(MethodSecurityExpressionHandler expressionHandler) {
/*  66 */     Assert.notNull(expressionHandler, "expressionHandler cannot be null");
/*  67 */     this.registry.setExpressionHandler(expressionHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setTemplateDefaults(PrePostTemplateDefaults defaults) {
/*  82 */     this.registry.setTemplateDefaults(defaults);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTemplateDefaults(AnnotationTemplateExpressionDefaults defaults) {
/*  94 */     this.registry.setTemplateDefaults(defaults);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(MethodInvocation mi) throws Throwable {
/* 105 */     ExpressionAttribute attribute = this.registry.getAttribute(mi);
/* 106 */     if (attribute == ExpressionAttribute.NULL_ATTRIBUTE) {
/* 107 */       return ReactiveMethodInvocationUtils.proceed(mi);
/*     */     }
/*     */     
/* 110 */     Mono<EvaluationContext> toInvoke = ReactiveAuthenticationUtils.getAuthentication().map(auth -> this.registry.getExpressionHandler().createEvaluationContext(auth, mi));
/* 111 */     Method method = mi.getMethod();
/* 112 */     Class<?> type = method.getReturnType();
/*     */     
/* 114 */     Assert.state(Publisher.class.isAssignableFrom(type), () -> String.format("The parameter type %s on %s must be an instance of org.reactivestreams.Publisher (for example, a Mono or Flux) in order to support Reactor Context", new Object[] { type, method }));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 119 */     ReactiveAdapter adapter = ReactiveAdapterRegistry.getSharedInstance().getAdapter(type);
/* 120 */     if (isMultiValue(type, adapter)) {
/* 121 */       Flux flux1 = Flux.defer(() -> (Publisher)ReactiveMethodInvocationUtils.<Publisher>proceed(mi));
/* 122 */       Flux<?> flux = toInvoke.flatMapMany(ctx -> filterMultiValue(publisher, ctx, attribute));
/* 123 */       return (adapter != null) ? adapter.fromPublisher((Publisher)flux) : flux;
/*     */     } 
/* 125 */     Mono mono1 = Mono.defer(() -> (Mono)ReactiveMethodInvocationUtils.<Mono>proceed(mi));
/* 126 */     Mono<?> mono = toInvoke.flatMap(ctx -> filterSingleValue(publisher, ctx, attribute));
/* 127 */     return (adapter != null) ? adapter.fromPublisher((Publisher)mono) : mono;
/*     */   }
/*     */   
/*     */   private boolean isMultiValue(Class<?> returnType, ReactiveAdapter adapter) {
/* 131 */     if (Flux.class.isAssignableFrom(returnType)) {
/* 132 */       return true;
/*     */     }
/* 134 */     return (adapter == null || adapter.isMultiValue());
/*     */   }
/*     */   
/*     */   private Mono<?> filterSingleValue(Publisher<?> publisher, EvaluationContext ctx, ExpressionAttribute attribute) {
/* 138 */     return Mono.from(publisher)
/* 139 */       .doOnNext(result -> setFilterObject(ctx, result))
/* 140 */       .flatMap(result -> postFilter(ctx, result, attribute));
/*     */   }
/*     */   
/*     */   private Flux<?> filterMultiValue(Publisher<?> publisher, EvaluationContext ctx, ExpressionAttribute attribute) {
/* 144 */     return Flux.from(publisher)
/* 145 */       .doOnNext(result -> setFilterObject(ctx, result))
/* 146 */       .flatMap(result -> postFilter(ctx, result, attribute));
/*     */   }
/*     */   
/*     */   private void setFilterObject(EvaluationContext ctx, Object result) {
/* 150 */     ((MethodSecurityExpressionOperations)ctx.getRootObject().getValue()).setFilterObject(result);
/*     */   }
/*     */   
/*     */   private Mono<?> postFilter(EvaluationContext ctx, Object result, ExpressionAttribute attribute) {
/* 154 */     return ReactiveExpressionUtils.evaluateAsBoolean(attribute.getExpression(), ctx)
/* 155 */       .flatMap(granted -> granted.booleanValue() ? Mono.just(result) : Mono.empty());
/*     */   }
/*     */ 
/*     */   
/*     */   public Pointcut getPointcut() {
/* 160 */     return this.pointcut;
/*     */   }
/*     */ 
/*     */   
/*     */   public Advice getAdvice() {
/* 165 */     return (Advice)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPerInstance() {
/* 170 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 175 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 179 */     this.order = order;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\PostFilterAuthorizationReactiveMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */