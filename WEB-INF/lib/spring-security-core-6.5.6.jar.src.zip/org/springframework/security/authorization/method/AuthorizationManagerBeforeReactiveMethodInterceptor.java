/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import kotlinx.coroutines.reactive.ReactiveFlowKt;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.core.KotlinDetector;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.ReactiveAdapter;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.security.access.prepost.PreAuthorize;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.AuthorizationDeniedException;
/*     */ import org.springframework.security.authorization.AuthorizationResult;
/*     */ import org.springframework.security.authorization.ReactiveAuthorizationManager;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthorizationManagerBeforeReactiveMethodInterceptor
/*     */   implements AuthorizationAdvisor
/*     */ {
/*     */   private static final String COROUTINES_FLOW_CLASS_NAME = "kotlinx.coroutines.flow.Flow";
/*     */   private static final int RETURN_TYPE_METHOD_PARAMETER_INDEX = -1;
/*     */   private final Pointcut pointcut;
/*     */   private final ReactiveAuthorizationManager<MethodInvocation> authorizationManager;
/*  61 */   private int order = AuthorizationInterceptorsOrder.FIRST.getOrder();
/*     */   
/*  63 */   private final MethodAuthorizationDeniedHandler defaultHandler = new ThrowingMethodAuthorizationDeniedHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationManagerBeforeReactiveMethodInterceptor preAuthorize() {
/*  70 */     return preAuthorize(new PreAuthorizeReactiveAuthorizationManager());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationManagerBeforeReactiveMethodInterceptor preAuthorize(ReactiveAuthorizationManager<MethodInvocation> authorizationManager) {
/*  81 */     AuthorizationManagerBeforeReactiveMethodInterceptor interceptor = new AuthorizationManagerBeforeReactiveMethodInterceptor(AuthorizationMethodPointcuts.forAnnotations((Class<? extends Annotation>[])new Class[] { PreAuthorize.class }, ), authorizationManager);
/*  82 */     interceptor.setOrder(AuthorizationInterceptorsOrder.PRE_AUTHORIZE.getOrder());
/*  83 */     return interceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationManagerBeforeReactiveMethodInterceptor(Pointcut pointcut, ReactiveAuthorizationManager<MethodInvocation> authorizationManager) {
/*  93 */     Assert.notNull(pointcut, "pointcut cannot be null");
/*  94 */     Assert.notNull(authorizationManager, "authorizationManager cannot be null");
/*  95 */     this.pointcut = pointcut;
/*  96 */     this.authorizationManager = authorizationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(MethodInvocation mi) throws Throwable {
/* 108 */     Method method = mi.getMethod();
/* 109 */     Class<?> type = method.getReturnType();
/* 110 */     boolean isSuspendingFunction = KotlinDetector.isSuspendingFunction(method);
/*     */     
/* 112 */     boolean hasFlowReturnType = "kotlinx.coroutines.flow.Flow".equals((new MethodParameter(method, -1)).getParameterType().getName());
/* 113 */     boolean hasReactiveReturnType = (Publisher.class.isAssignableFrom(type) || isSuspendingFunction || hasFlowReturnType);
/*     */     
/* 115 */     Assert.state(hasReactiveReturnType, () -> "The returnType " + String.valueOf(type) + " on " + String.valueOf(method) + " must return an instance of org.reactivestreams.Publisher (for example, a Mono or Flux) or the function must be a Kotlin coroutine in order to support Reactor Context");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     ReactiveAdapter adapter = ReactiveAdapterRegistry.getSharedInstance().getAdapter(type);
/* 121 */     if (hasFlowReturnType) {
/* 122 */       if (isSuspendingFunction) {
/* 123 */         return preAuthorized(mi, Flux.defer(() -> (Publisher)ReactiveMethodInvocationUtils.<Publisher>proceed(mi)));
/*     */       }
/*     */       
/* 126 */       Assert.state((adapter != null), () -> "The returnType " + String.valueOf(type) + " on " + String.valueOf(method) + " must have a org.springframework.core.ReactiveAdapter registered");
/*     */       
/* 128 */       Flux<Object> response = preAuthorized(mi, 
/* 129 */           Flux.defer(() -> adapter.toPublisher(ReactiveMethodInvocationUtils.proceed(mi))));
/* 130 */       return KotlinDelegate.asFlow((Publisher<?>)response);
/*     */     } 
/*     */     
/* 133 */     if (isMultiValue(type, adapter)) {
/* 134 */       Flux<?> flux = preAuthorized(mi, Flux.defer(() -> (Publisher)ReactiveMethodInvocationUtils.<Publisher>proceed(mi)));
/* 135 */       return (adapter != null) ? adapter.fromPublisher((Publisher)flux) : flux;
/*     */     } 
/* 137 */     Mono<?> result = preAuthorized(mi, Mono.defer(() -> (Mono)ReactiveMethodInvocationUtils.<Mono>proceed(mi)));
/* 138 */     return (adapter != null) ? adapter.fromPublisher((Publisher)result) : result;
/*     */   }
/*     */   
/*     */   private Flux<Object> preAuthorized(MethodInvocation mi, Flux<Object> mapping) {
/* 142 */     Mono<Authentication> authentication = ReactiveAuthenticationUtils.getAuthentication();
/* 143 */     return this.authorizationManager.authorize(authentication, mi)
/* 144 */       .switchIfEmpty(Mono.just(new AuthorizationDecision(false)))
/* 145 */       .flatMapMany(decision -> decision.isGranted() ? mapping.onErrorResume(AuthorizationDeniedException.class, ()) : postProcess(decision, mi));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Mono<Object> preAuthorized(MethodInvocation mi, Mono<Object> mapping) {
/* 155 */     Mono<Authentication> authentication = ReactiveAuthenticationUtils.getAuthentication();
/* 156 */     return this.authorizationManager.authorize(authentication, mi)
/* 157 */       .switchIfEmpty(Mono.just(new AuthorizationDecision(false)))
/* 158 */       .flatMap(decision -> decision.isGranted() ? mapping.onErrorResume(AuthorizationDeniedException.class, ()) : postProcess(decision, mi));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Mono<Object> postProcess(AuthorizationResult decision, MethodInvocation mi) {
/* 168 */     return Mono.fromSupplier(() -> {
/*     */           ReactiveAuthorizationManager<MethodInvocation> patt7477$temp = this.authorizationManager; if (patt7477$temp instanceof MethodAuthorizationDeniedHandler) {
/*     */             MethodAuthorizationDeniedHandler handler = (MethodAuthorizationDeniedHandler)patt7477$temp; return handler.handleDeniedInvocation(mi, decision);
/*     */           } 
/*     */           return this.defaultHandler.handleDeniedInvocation(mi, decision);
/* 173 */         }).flatMap(result -> Mono.class.isAssignableFrom(result.getClass()) ? (Mono)result : Mono.justOrEmpty(result));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMultiValue(Class<?> returnType, ReactiveAdapter adapter) {
/* 182 */     if (Flux.class.isAssignableFrom(returnType)) {
/* 183 */       return true;
/*     */     }
/* 185 */     return (adapter != null && adapter.isMultiValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public Pointcut getPointcut() {
/* 190 */     return this.pointcut;
/*     */   }
/*     */ 
/*     */   
/*     */   public Advice getAdvice() {
/* 195 */     return (Advice)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPerInstance() {
/* 200 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 205 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 209 */     this.order = order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class KotlinDelegate
/*     */   {
/*     */     private static Object asFlow(Publisher<?> publisher) {
/* 218 */       return ReactiveFlowKt.asFlow(publisher);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\AuthorizationManagerBeforeReactiveMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */