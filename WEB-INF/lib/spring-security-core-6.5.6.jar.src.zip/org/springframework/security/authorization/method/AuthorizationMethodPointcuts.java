/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.aop.support.ComposablePointcut;
/*    */ import org.springframework.aop.support.Pointcuts;
/*    */ import org.springframework.aop.support.annotation.AnnotationMatchingPointcut;
/*    */ import org.springframework.security.access.prepost.PostAuthorize;
/*    */ import org.springframework.security.access.prepost.PostFilter;
/*    */ import org.springframework.security.access.prepost.PreAuthorize;
/*    */ import org.springframework.security.access.prepost.PreFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class AuthorizationMethodPointcuts
/*    */ {
/*    */   static Pointcut forAllAnnotations() {
/* 37 */     return forAnnotations((Class<? extends Annotation>[])new Class[] { PreFilter.class, PreAuthorize.class, PostFilter.class, PostAuthorize.class });
/*    */   }
/*    */   
/*    */   @SafeVarargs
/*    */   static Pointcut forAnnotations(Class<? extends Annotation>... annotations) {
/* 42 */     ComposablePointcut pointcut = null;
/* 43 */     for (Class<? extends Annotation> annotation : annotations) {
/* 44 */       if (pointcut == null) {
/* 45 */         pointcut = new ComposablePointcut(classOrMethod(annotation));
/*    */       } else {
/*    */         
/* 48 */         pointcut.union(classOrMethod(annotation));
/*    */       } 
/*    */     } 
/* 51 */     return (Pointcut)pointcut;
/*    */   }
/*    */   
/*    */   private static Pointcut classOrMethod(Class<? extends Annotation> annotation) {
/* 55 */     return Pointcuts.union((Pointcut)new AnnotationMatchingPointcut(null, annotation, true), (Pointcut)new AnnotationMatchingPointcut(annotation, true));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\AuthorizationMethodPointcuts.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */