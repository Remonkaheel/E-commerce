/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.lang.NonNull;
/*    */ import org.springframework.security.access.prepost.PreFilter;
/*    */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*    */ import org.springframework.security.core.annotation.SecurityAnnotationScanner;
/*    */ import org.springframework.security.core.annotation.SecurityAnnotationScanners;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class PreFilterExpressionAttributeRegistry
/*    */   extends AbstractExpressionAttributeRegistry<PreFilterExpressionAttributeRegistry.PreFilterExpressionAttribute>
/*    */ {
/* 38 */   private SecurityAnnotationScanner<PreFilter> scanner = SecurityAnnotationScanners.requireUnique(PreFilter.class);
/*    */ 
/*    */   
/*    */   @NonNull
/*    */   PreFilterExpressionAttribute resolveAttribute(Method method, Class<?> targetClass) {
/* 43 */     PreFilter preFilter = findPreFilterAnnotation(method, targetClass);
/* 44 */     if (preFilter == null) {
/* 45 */       return PreFilterExpressionAttribute.NULL_ATTRIBUTE;
/*    */     }
/*    */     
/* 48 */     Expression preFilterExpression = getExpressionHandler().getExpressionParser().parseExpression(preFilter.value());
/* 49 */     return new PreFilterExpressionAttribute(preFilterExpression, preFilter.filterTarget());
/*    */   }
/*    */   
/*    */   void setTemplateDefaults(AnnotationTemplateExpressionDefaults defaults) {
/* 53 */     this.scanner = SecurityAnnotationScanners.requireUnique(PreFilter.class, defaults);
/*    */   }
/*    */   
/*    */   private PreFilter findPreFilterAnnotation(Method method, Class<?> targetClass) {
/* 57 */     Class<?> targetClassToUse = targetClass(method, targetClass);
/* 58 */     return (PreFilter)this.scanner.scan(method, targetClassToUse);
/*    */   }
/*    */   
/*    */   static final class PreFilterExpressionAttribute
/*    */     extends ExpressionAttribute {
/* 63 */     static final PreFilterExpressionAttribute NULL_ATTRIBUTE = new PreFilterExpressionAttribute(null, null);
/*    */     
/*    */     private final String filterTarget;
/*    */     
/*    */     private PreFilterExpressionAttribute(Expression expression, String filterTarget) {
/* 68 */       super(expression);
/* 69 */       this.filterTarget = filterTarget;
/*    */     }
/*    */     
/*    */     String getFilterTarget() {
/* 73 */       return this.filterTarget;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\PreFilterExpressionAttributeRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */