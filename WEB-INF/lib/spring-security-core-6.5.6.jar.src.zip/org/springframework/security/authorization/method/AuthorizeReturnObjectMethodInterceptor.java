/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.function.Predicate;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.support.Pointcuts;
/*     */ import org.springframework.aop.support.StaticMethodMatcherPointcut;
/*     */ import org.springframework.security.authorization.AuthorizationProxyFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthorizeReturnObjectMethodInterceptor
/*     */   implements AuthorizationAdvisor
/*     */ {
/*     */   private AuthorizationProxyFactory authorizationProxyFactory;
/*  44 */   private Pointcut pointcut = Pointcuts.intersection((Pointcut)new MethodReturnTypePointcut(
/*  45 */         Predicate.not(ClassUtils::isVoidType)), 
/*  46 */       AuthorizationMethodPointcuts.forAnnotations((Class<? extends Annotation>[])new Class[] { AuthorizeReturnObject.class }));
/*     */   
/*  48 */   private int order = AuthorizationInterceptorsOrder.SECURE_RESULT.getOrder();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizeReturnObjectMethodInterceptor() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizeReturnObjectMethodInterceptor(AuthorizationProxyFactory authorizationProxyFactory) {
/*  64 */     Assert.notNull(authorizationProxyFactory, "authorizationProxyFactory cannot be null");
/*  65 */     this.authorizationProxyFactory = authorizationProxyFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object invoke(MethodInvocation mi) throws Throwable {
/*  70 */     Object result = mi.proceed();
/*  71 */     if (result == null) {
/*  72 */       return null;
/*     */     }
/*  74 */     Assert.notNull(this.authorizationProxyFactory, "authorizationProxyFactory cannot be null");
/*  75 */     return this.authorizationProxyFactory.proxy(result);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthorizationProxyFactory(AuthorizationProxyFactory authorizationProxyFactory) {
/*  84 */     Assert.notNull(authorizationProxyFactory, "authorizationProxyFactory cannot be null");
/*  85 */     this.authorizationProxyFactory = authorizationProxyFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/*  90 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/*  94 */     this.order = order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pointcut getPointcut() {
/* 102 */     return this.pointcut;
/*     */   }
/*     */   
/*     */   public void setPointcut(Pointcut pointcut) {
/* 106 */     this.pointcut = pointcut;
/*     */   }
/*     */ 
/*     */   
/*     */   public Advice getAdvice() {
/* 111 */     return (Advice)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPerInstance() {
/* 116 */     return true;
/*     */   }
/*     */   
/*     */   static final class MethodReturnTypePointcut
/*     */     extends StaticMethodMatcherPointcut {
/*     */     private final Predicate<Class<?>> returnTypeMatches;
/*     */     
/*     */     MethodReturnTypePointcut(Predicate<Class<?>> returnTypeMatches) {
/* 124 */       this.returnTypeMatches = returnTypeMatches;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean matches(Method method, Class<?> targetClass) {
/* 129 */       return this.returnTypeMatches.test(method.getReturnType());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\AuthorizeReturnObjectMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */