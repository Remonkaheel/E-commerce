/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ import org.springframework.expression.Expression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ExpressionAttribute
/*    */ {
/* 32 */   static final ExpressionAttribute NULL_ATTRIBUTE = new ExpressionAttribute(null);
/*    */ 
/*    */ 
/*    */   
/*    */   private final Expression expression;
/*    */ 
/*    */ 
/*    */   
/*    */   ExpressionAttribute(Expression expression) {
/* 41 */     this.expression = expression;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Expression getExpression() {
/* 49 */     return this.expression;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 54 */     return getClass().getSimpleName() + " [Expression=" + getClass().getSimpleName() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\ExpressionAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */