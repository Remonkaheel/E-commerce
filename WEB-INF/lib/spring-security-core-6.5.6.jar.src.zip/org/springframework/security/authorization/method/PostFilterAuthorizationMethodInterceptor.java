/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.function.Supplier;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.prepost.PostFilter;
/*     */ import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PostFilterAuthorizationMethodInterceptor
/*     */   implements AuthorizationAdvisor
/*     */ {
/*  46 */   private Supplier<SecurityContextHolderStrategy> securityContextHolderStrategy = SecurityContextHolder::getContextHolderStrategy;
/*     */   
/*  48 */   private PostFilterExpressionAttributeRegistry registry = new PostFilterExpressionAttributeRegistry();
/*     */   
/*  50 */   private int order = AuthorizationInterceptorsOrder.POST_FILTER.getOrder();
/*     */ 
/*     */ 
/*     */   
/*     */   private final Pointcut pointcut;
/*     */ 
/*     */ 
/*     */   
/*     */   public PostFilterAuthorizationMethodInterceptor() {
/*  59 */     this.pointcut = AuthorizationMethodPointcuts.forAnnotations((Class<? extends Annotation>[])new Class[] { PostFilter.class });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpressionHandler(MethodSecurityExpressionHandler expressionHandler) {
/*  67 */     this.registry.setExpressionHandler(expressionHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setTemplateDefaults(PrePostTemplateDefaults defaults) {
/*  81 */     this.registry.setTemplateDefaults(defaults);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTemplateDefaults(AnnotationTemplateExpressionDefaults defaults) {
/*  93 */     this.registry.setTemplateDefaults(defaults);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 101 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 105 */     this.order = order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pointcut getPointcut() {
/* 113 */     return this.pointcut;
/*     */   }
/*     */ 
/*     */   
/*     */   public Advice getAdvice() {
/* 118 */     return (Advice)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPerInstance() {
/* 123 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy strategy) {
/* 133 */     this.securityContextHolderStrategy = (() -> strategy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(MethodInvocation mi) throws Throwable {
/* 144 */     Object returnedObject = mi.proceed();
/* 145 */     ExpressionAttribute attribute = this.registry.getAttribute(mi);
/* 146 */     if (attribute == ExpressionAttribute.NULL_ATTRIBUTE) {
/* 147 */       return returnedObject;
/*     */     }
/* 149 */     MethodSecurityExpressionHandler expressionHandler = this.registry.getExpressionHandler();
/* 150 */     EvaluationContext ctx = expressionHandler.createEvaluationContext(this::getAuthentication, mi);
/* 151 */     return expressionHandler.filter(returnedObject, attribute.getExpression(), ctx);
/*     */   }
/*     */   
/*     */   private Authentication getAuthentication() {
/* 155 */     Authentication authentication = ((SecurityContextHolderStrategy)this.securityContextHolderStrategy.get()).getContext().getAuthentication();
/* 156 */     if (authentication == null) {
/* 157 */       throw new AuthenticationCredentialsNotFoundException("An Authentication object was not found in the SecurityContext");
/*     */     }
/*     */     
/* 160 */     return authentication;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\PostFilterAuthorizationMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */