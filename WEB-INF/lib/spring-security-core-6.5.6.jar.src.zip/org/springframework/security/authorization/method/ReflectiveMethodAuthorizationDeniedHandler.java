/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.security.authorization.AuthorizationResult;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ReflectiveMethodAuthorizationDeniedHandler
/*    */   implements MethodAuthorizationDeniedHandler
/*    */ {
/* 27 */   private final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   private final Class<?> targetClass;
/*    */   
/*    */   private final Class<?> managerClass;
/*    */   
/*    */   ReflectiveMethodAuthorizationDeniedHandler(Class<?> targetClass, Class<?> managerClass) {
/* 34 */     this.logger.debug("Will attempt to instantiate handlerClass attributes using reflection since no application context was supplied to " + String.valueOf(managerClass));
/*    */ 
/*    */     
/* 37 */     this.targetClass = targetClass;
/* 38 */     this.managerClass = managerClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object handleDeniedInvocation(MethodInvocation methodInvocation, AuthorizationResult authorizationResult) {
/* 43 */     return constructMethodAuthorizationDeniedHandler().handleDeniedInvocation(methodInvocation, authorizationResult);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object handleDeniedInvocationResult(MethodInvocationResult methodInvocationResult, AuthorizationResult authorizationResult) {
/* 50 */     return constructMethodAuthorizationDeniedHandler().handleDeniedInvocationResult(methodInvocationResult, authorizationResult);
/*    */   }
/*    */ 
/*    */   
/*    */   private MethodAuthorizationDeniedHandler constructMethodAuthorizationDeniedHandler() {
/*    */     try {
/* 56 */       return this.targetClass.getConstructor(new Class[0]).newInstance(new Object[0]);
/*    */     }
/* 58 */     catch (Exception ex) {
/* 59 */       throw new IllegalArgumentException("Failed to construct instance of " + String.valueOf(this.targetClass) + ". Please either add a public default constructor to the class  or publish an instance of it as a Spring bean. If you publish it as a Spring bean,  either add `@EnableMethodSecurity` to your configuration or  provide the `ApplicationContext` directly to " + String.valueOf(this.managerClass), ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\ReflectiveMethodAuthorizationDeniedHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */