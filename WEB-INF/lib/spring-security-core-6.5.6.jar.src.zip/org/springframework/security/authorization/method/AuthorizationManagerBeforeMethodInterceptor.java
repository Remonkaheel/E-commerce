/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import jakarta.annotation.security.DenyAll;
/*     */ import jakarta.annotation.security.PermitAll;
/*     */ import jakarta.annotation.security.RolesAllowed;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.function.Supplier;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.access.annotation.Secured;
/*     */ import org.springframework.security.access.prepost.PreAuthorize;
/*     */ import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
/*     */ import org.springframework.security.authorization.AuthorizationDeniedException;
/*     */ import org.springframework.security.authorization.AuthorizationEventPublisher;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationResult;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthorizationManagerBeforeMethodInterceptor
/*     */   implements AuthorizationAdvisor
/*     */ {
/*  55 */   private Supplier<SecurityContextHolderStrategy> securityContextHolderStrategy = SecurityContextHolder::getContextHolderStrategy;
/*     */   
/*  57 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final Pointcut pointcut;
/*     */   
/*     */   private final AuthorizationManager<MethodInvocation> authorizationManager;
/*     */   
/*  63 */   private final MethodAuthorizationDeniedHandler defaultHandler = new ThrowingMethodAuthorizationDeniedHandler();
/*     */   
/*  65 */   private int order = AuthorizationInterceptorsOrder.FIRST.getOrder();
/*     */   
/*  67 */   private AuthorizationEventPublisher eventPublisher = new NoOpAuthorizationEventPublisher();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationManagerBeforeMethodInterceptor(Pointcut pointcut, AuthorizationManager<MethodInvocation> authorizationManager) {
/*  76 */     Assert.notNull(pointcut, "pointcut cannot be null");
/*  77 */     Assert.notNull(authorizationManager, "authorizationManager cannot be null");
/*  78 */     this.pointcut = pointcut;
/*  79 */     this.authorizationManager = authorizationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationManagerBeforeMethodInterceptor preAuthorize() {
/*  87 */     return preAuthorize(new PreAuthorizeAuthorizationManager());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationManagerBeforeMethodInterceptor preAuthorize(PreAuthorizeAuthorizationManager authorizationManager) {
/*  98 */     AuthorizationManagerBeforeMethodInterceptor interceptor = new AuthorizationManagerBeforeMethodInterceptor(AuthorizationMethodPointcuts.forAnnotations((Class<? extends Annotation>[])new Class[] { PreAuthorize.class }, ), authorizationManager);
/*  99 */     interceptor.setOrder(AuthorizationInterceptorsOrder.PRE_AUTHORIZE.getOrder());
/* 100 */     return interceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationManagerBeforeMethodInterceptor preAuthorize(AuthorizationManager<MethodInvocation> authorizationManager) {
/* 112 */     AuthorizationManagerBeforeMethodInterceptor interceptor = new AuthorizationManagerBeforeMethodInterceptor(AuthorizationMethodPointcuts.forAnnotations((Class<? extends Annotation>[])new Class[] { PreAuthorize.class }, ), authorizationManager);
/* 113 */     interceptor.setOrder(AuthorizationInterceptorsOrder.PRE_AUTHORIZE.getOrder());
/* 114 */     return interceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationManagerBeforeMethodInterceptor secured() {
/* 122 */     return secured(new SecuredAuthorizationManager());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationManagerBeforeMethodInterceptor secured(SecuredAuthorizationManager authorizationManager) {
/* 133 */     AuthorizationManagerBeforeMethodInterceptor interceptor = new AuthorizationManagerBeforeMethodInterceptor(AuthorizationMethodPointcuts.forAnnotations((Class<? extends Annotation>[])new Class[] { Secured.class }, ), authorizationManager);
/* 134 */     interceptor.setOrder(AuthorizationInterceptorsOrder.SECURED.getOrder());
/* 135 */     return interceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationManagerBeforeMethodInterceptor secured(AuthorizationManager<MethodInvocation> authorizationManager) {
/* 147 */     AuthorizationManagerBeforeMethodInterceptor interceptor = new AuthorizationManagerBeforeMethodInterceptor(AuthorizationMethodPointcuts.forAnnotations((Class<? extends Annotation>[])new Class[] { Secured.class }, ), authorizationManager);
/* 148 */     interceptor.setOrder(AuthorizationInterceptorsOrder.SECURED.getOrder());
/* 149 */     return interceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationManagerBeforeMethodInterceptor jsr250() {
/* 157 */     return jsr250(new Jsr250AuthorizationManager());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationManagerBeforeMethodInterceptor jsr250(Jsr250AuthorizationManager authorizationManager) {
/* 167 */     AuthorizationManagerBeforeMethodInterceptor interceptor = new AuthorizationManagerBeforeMethodInterceptor(AuthorizationMethodPointcuts.forAnnotations((Class<? extends Annotation>[])new Class[] { RolesAllowed.class, DenyAll.class, PermitAll.class }, ), authorizationManager);
/*     */     
/* 169 */     interceptor.setOrder(AuthorizationInterceptorsOrder.JSR250.getOrder());
/* 170 */     return interceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationManagerBeforeMethodInterceptor jsr250(AuthorizationManager<MethodInvocation> authorizationManager) {
/* 182 */     AuthorizationManagerBeforeMethodInterceptor interceptor = new AuthorizationManagerBeforeMethodInterceptor(AuthorizationMethodPointcuts.forAnnotations((Class<? extends Annotation>[])new Class[] { RolesAllowed.class, DenyAll.class, PermitAll.class }, ), authorizationManager);
/*     */     
/* 184 */     interceptor.setOrder(AuthorizationInterceptorsOrder.JSR250.getOrder());
/* 185 */     return interceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(MethodInvocation mi) throws Throwable {
/* 196 */     return attemptAuthorization(mi);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 201 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 205 */     this.order = order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthorizationEventPublisher(AuthorizationEventPublisher eventPublisher) {
/* 215 */     Assert.notNull(eventPublisher, "eventPublisher cannot be null");
/* 216 */     this.eventPublisher = eventPublisher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pointcut getPointcut() {
/* 224 */     return this.pointcut;
/*     */   }
/*     */ 
/*     */   
/*     */   public Advice getAdvice() {
/* 229 */     return (Advice)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPerInstance() {
/* 234 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 244 */     this.securityContextHolderStrategy = (() -> securityContextHolderStrategy);
/*     */   }
/*     */   private Object attemptAuthorization(MethodInvocation mi) throws Throwable {
/*     */     AuthorizationResult result;
/* 248 */     this.logger.debug(LogMessage.of(() -> "Authorizing method invocation " + String.valueOf(mi)));
/*     */     
/*     */     try {
/* 251 */       result = this.authorizationManager.authorize(this::getAuthentication, mi);
/*     */     }
/* 253 */     catch (AuthorizationDeniedException denied) {
/* 254 */       return handle(mi, denied);
/*     */     } 
/* 256 */     this.eventPublisher.publishAuthorizationEvent(this::getAuthentication, mi, result);
/* 257 */     if (result != null && !result.isGranted()) {
/* 258 */       this.logger.debug(LogMessage.of(() -> "Failed to authorize " + String.valueOf(mi) + " with authorization manager " + String.valueOf(this.authorizationManager) + " and result " + String.valueOf(result)));
/*     */       
/* 260 */       return handle(mi, result);
/*     */     } 
/* 262 */     this.logger.debug(LogMessage.of(() -> "Authorized method invocation " + String.valueOf(mi)));
/* 263 */     return proceed(mi);
/*     */   }
/*     */   
/*     */   private Object proceed(MethodInvocation mi) throws Throwable {
/*     */     try {
/* 268 */       return mi.proceed();
/*     */     }
/* 270 */     catch (AuthorizationDeniedException ex) {
/* 271 */       AuthorizationManager<MethodInvocation> authorizationManager = this.authorizationManager; if (authorizationManager instanceof MethodAuthorizationDeniedHandler) { MethodAuthorizationDeniedHandler handler = (MethodAuthorizationDeniedHandler)authorizationManager;
/* 272 */         return handler.handleDeniedInvocation(mi, (AuthorizationResult)ex); }
/*     */       
/* 274 */       return this.defaultHandler.handleDeniedInvocation(mi, (AuthorizationResult)ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Object handle(MethodInvocation mi, AuthorizationDeniedException denied) {
/* 279 */     AuthorizationManager<MethodInvocation> authorizationManager = this.authorizationManager; if (authorizationManager instanceof MethodAuthorizationDeniedHandler) { MethodAuthorizationDeniedHandler handler = (MethodAuthorizationDeniedHandler)authorizationManager;
/* 280 */       return handler.handleDeniedInvocation(mi, (AuthorizationResult)denied); }
/*     */     
/* 282 */     return this.defaultHandler.handleDeniedInvocation(mi, (AuthorizationResult)denied);
/*     */   }
/*     */   
/*     */   private Object handle(MethodInvocation mi, AuthorizationResult result) {
/* 286 */     AuthorizationManager<MethodInvocation> authorizationManager = this.authorizationManager; if (authorizationManager instanceof MethodAuthorizationDeniedHandler) { MethodAuthorizationDeniedHandler handler = (MethodAuthorizationDeniedHandler)authorizationManager;
/* 287 */       return handler.handleDeniedInvocation(mi, result); }
/*     */     
/* 289 */     return this.defaultHandler.handleDeniedInvocation(mi, result);
/*     */   }
/*     */   
/*     */   private Authentication getAuthentication() {
/* 293 */     Authentication authentication = ((SecurityContextHolderStrategy)this.securityContextHolderStrategy.get()).getContext().getAuthentication();
/* 294 */     if (authentication == null) {
/* 295 */       throw new AuthenticationCredentialsNotFoundException("An Authentication object was not found in the SecurityContext");
/*     */     }
/*     */     
/* 298 */     return authentication;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\AuthorizationManagerBeforeMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */