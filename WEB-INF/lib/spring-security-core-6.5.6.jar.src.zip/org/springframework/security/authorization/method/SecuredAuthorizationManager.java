/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.function.Supplier;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.core.MethodClassKey;
/*     */ import org.springframework.security.access.annotation.Secured;
/*     */ import org.springframework.security.authorization.AuthoritiesAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanner;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanners;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SecuredAuthorizationManager
/*     */   implements AuthorizationManager<MethodInvocation>
/*     */ {
/*  50 */   private AuthorizationManager<Collection<String>> authoritiesAuthorizationManager = (AuthorizationManager<Collection<String>>)new AuthoritiesAuthorizationManager();
/*     */   
/*  52 */   private final Map<MethodClassKey, Set<String>> cachedAuthorities = new ConcurrentHashMap<>();
/*     */   
/*  54 */   private final SecurityAnnotationScanner<Secured> scanner = SecurityAnnotationScanners.requireUnique(Secured.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthoritiesAuthorizationManager(AuthorizationManager<Collection<String>> authoritiesAuthorizationManager) {
/*  65 */     Assert.notNull(authoritiesAuthorizationManager, "authoritiesAuthorizationManager cannot be null");
/*  66 */     this.authoritiesAuthorizationManager = authoritiesAuthorizationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public AuthorizationDecision check(Supplier<Authentication> authentication, MethodInvocation mi) {
/*  81 */     Set<String> authorities = getAuthorities(mi);
/*  82 */     return authorities.isEmpty() ? null : this.authoritiesAuthorizationManager.check(authentication, authorities);
/*     */   }
/*     */   
/*     */   private Set<String> getAuthorities(MethodInvocation methodInvocation) {
/*  86 */     Method method = methodInvocation.getMethod();
/*  87 */     Object target = methodInvocation.getThis();
/*  88 */     Class<?> targetClass = (target != null) ? target.getClass() : null;
/*  89 */     MethodClassKey cacheKey = new MethodClassKey(method, targetClass);
/*  90 */     return this.cachedAuthorities.computeIfAbsent(cacheKey, k -> resolveAuthorities(method, targetClass));
/*     */   }
/*     */   
/*     */   private Set<String> resolveAuthorities(Method method, Class<?> targetClass) {
/*  94 */     Secured secured = findSecuredAnnotation(method, targetClass);
/*  95 */     return (secured != null) ? Set.<String>of(secured.value()) : Collections.<String>emptySet();
/*     */   }
/*     */   
/*     */   private Secured findSecuredAnnotation(Method method, Class<?> targetClass) {
/*  99 */     Class<?> targetClassToUse = (targetClass != null) ? targetClass : method.getDeclaringClass();
/* 100 */     return (Secured)this.scanner.scan(method, targetClassToUse);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\SecuredAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */