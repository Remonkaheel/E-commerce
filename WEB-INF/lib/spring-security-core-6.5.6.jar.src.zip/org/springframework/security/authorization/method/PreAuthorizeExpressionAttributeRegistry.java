/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.security.access.prepost.PreAuthorize;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanner;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanners;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PreAuthorizeExpressionAttributeRegistry
/*     */   extends AbstractExpressionAttributeRegistry<ExpressionAttribute>
/*     */ {
/*  41 */   private final MethodAuthorizationDeniedHandler defaultHandler = new ThrowingMethodAuthorizationDeniedHandler();
/*     */ 
/*     */   
/*  44 */   private final SecurityAnnotationScanner<HandleAuthorizationDenied> handleAuthorizationDeniedScanner = SecurityAnnotationScanners.requireUnique(HandleAuthorizationDenied.class);
/*     */ 
/*     */   
/*     */   private Function<Class<? extends MethodAuthorizationDeniedHandler>, MethodAuthorizationDeniedHandler> handlerResolver;
/*     */   
/*  49 */   private SecurityAnnotationScanner<PreAuthorize> preAuthorizeScanner = SecurityAnnotationScanners.requireUnique(PreAuthorize.class);
/*     */   
/*     */   PreAuthorizeExpressionAttributeRegistry() {
/*  52 */     this.handlerResolver = (clazz -> new ReflectiveMethodAuthorizationDeniedHandler(clazz, PreAuthorizeAuthorizationManager.class));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   ExpressionAttribute resolveAttribute(Method method, Class<?> targetClass) {
/*  59 */     PreAuthorize preAuthorize = findPreAuthorizeAnnotation(method, targetClass);
/*  60 */     if (preAuthorize == null) {
/*  61 */       return ExpressionAttribute.NULL_ATTRIBUTE;
/*     */     }
/*  63 */     Expression expression = getExpressionHandler().getExpressionParser().parseExpression(preAuthorize.value());
/*  64 */     MethodAuthorizationDeniedHandler handler = resolveHandler(method, targetClass);
/*  65 */     return new PreAuthorizeExpressionAttribute(expression, handler);
/*     */   }
/*     */   
/*     */   private MethodAuthorizationDeniedHandler resolveHandler(Method method, Class<?> targetClass) {
/*  69 */     Class<?> targetClassToUse = targetClass(method, targetClass);
/*  70 */     HandleAuthorizationDenied deniedHandler = (HandleAuthorizationDenied)this.handleAuthorizationDeniedScanner.scan(method, targetClassToUse);
/*  71 */     if (deniedHandler != null) {
/*  72 */       return this.handlerResolver.apply(deniedHandler.handlerClass());
/*     */     }
/*  74 */     return this.defaultHandler;
/*     */   }
/*     */   
/*     */   private PreAuthorize findPreAuthorizeAnnotation(Method method, Class<?> targetClass) {
/*  78 */     Class<?> targetClassToUse = targetClass(method, targetClass);
/*  79 */     return (PreAuthorize)this.preAuthorizeScanner.scan(method, targetClassToUse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setApplicationContext(ApplicationContext context) {
/*  88 */     Assert.notNull(context, "context cannot be null");
/*  89 */     this.handlerResolver = (clazz -> resolveHandler(context, clazz));
/*     */   }
/*     */   
/*     */   void setTemplateDefaults(AnnotationTemplateExpressionDefaults defaults) {
/*  93 */     this.preAuthorizeScanner = SecurityAnnotationScanners.requireUnique(PreAuthorize.class, defaults);
/*     */   }
/*     */ 
/*     */   
/*     */   private MethodAuthorizationDeniedHandler resolveHandler(ApplicationContext context, Class<? extends MethodAuthorizationDeniedHandler> handlerClass) {
/*  98 */     if (handlerClass == this.defaultHandler.getClass()) {
/*  99 */       return this.defaultHandler;
/*     */     }
/* 101 */     String[] beanNames = context.getBeanNamesForType(handlerClass);
/* 102 */     if (beanNames.length == 0) {
/* 103 */       throw new IllegalStateException("Could not find a bean of type " + handlerClass.getName());
/*     */     }
/* 105 */     if (beanNames.length > 1) {
/* 106 */       throw new IllegalStateException("Expected to find a single bean of type " + handlerClass.getName() + " but found " + 
/* 107 */           Arrays.toString(beanNames));
/*     */     }
/* 109 */     return (MethodAuthorizationDeniedHandler)context.getBean(beanNames[0], handlerClass);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\PreAuthorizeExpressionAttributeRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */