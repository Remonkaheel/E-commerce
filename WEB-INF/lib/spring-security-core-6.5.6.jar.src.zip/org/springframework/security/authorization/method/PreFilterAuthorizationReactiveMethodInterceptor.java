/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.reactivestreams.Publisher;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.ReactiveAdapter;
/*     */ import org.springframework.core.ReactiveAdapterRegistry;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.expression.method.MethodSecurityExpressionOperations;
/*     */ import org.springframework.security.access.prepost.PreFilter;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.security.core.parameters.DefaultSecurityParameterNameDiscoverer;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ import reactor.core.publisher.Flux;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PreFilterAuthorizationReactiveMethodInterceptor
/*     */   implements AuthorizationAdvisor
/*     */ {
/*  53 */   private final PreFilterExpressionAttributeRegistry registry = new PreFilterExpressionAttributeRegistry();
/*     */   
/*  55 */   private final Pointcut pointcut = AuthorizationMethodPointcuts.forAnnotations((Class<? extends Annotation>[])new Class[] { PreFilter.class });
/*     */   
/*  57 */   private ParameterNameDiscoverer parameterNameDiscoverer = (ParameterNameDiscoverer)new DefaultSecurityParameterNameDiscoverer();
/*     */   
/*  59 */   private int order = AuthorizationInterceptorsOrder.PRE_FILTER.getOrder();
/*     */   
/*     */   public PreFilterAuthorizationReactiveMethodInterceptor() {
/*  62 */     this((MethodSecurityExpressionHandler)new DefaultMethodSecurityExpressionHandler());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PreFilterAuthorizationReactiveMethodInterceptor(MethodSecurityExpressionHandler expressionHandler) {
/*  69 */     Assert.notNull(expressionHandler, "expressionHandler cannot be null");
/*  70 */     this.registry.setExpressionHandler(expressionHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setTemplateDefaults(PrePostTemplateDefaults defaults) {
/*  85 */     this.registry.setTemplateDefaults(defaults);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTemplateDefaults(AnnotationTemplateExpressionDefaults defaults) {
/*  97 */     this.registry.setTemplateDefaults(defaults);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParameterNameDiscoverer(ParameterNameDiscoverer parameterNameDiscoverer) {
/* 105 */     Assert.notNull(parameterNameDiscoverer, "parameterNameDiscoverer cannot be null");
/* 106 */     this.parameterNameDiscoverer = parameterNameDiscoverer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(MethodInvocation mi) throws Throwable {
/* 117 */     PreFilterExpressionAttributeRegistry.PreFilterExpressionAttribute attribute = this.registry.getAttribute(mi);
/* 118 */     if (attribute == PreFilterExpressionAttributeRegistry.PreFilterExpressionAttribute.NULL_ATTRIBUTE) {
/* 119 */       return ReactiveMethodInvocationUtils.proceed(mi);
/*     */     }
/* 121 */     FilterTarget filterTarget = findFilterTarget(attribute.getFilterTarget(), mi);
/*     */     
/* 123 */     Mono<EvaluationContext> toInvoke = ReactiveAuthenticationUtils.getAuthentication().map(auth -> this.registry.getExpressionHandler().createEvaluationContext(auth, mi));
/* 124 */     Method method = mi.getMethod();
/* 125 */     Class<?> type = filterTarget.value.getClass();
/*     */     
/* 127 */     Assert.state(Publisher.class.isAssignableFrom(type), () -> String.format("The parameter type %s on %s must be an instance of org.reactivestreams.Publisher (for example, a Mono or Flux) in order to support Reactor Context", new Object[] { type, method }));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     ReactiveAdapter adapter = ReactiveAdapterRegistry.getSharedInstance().getAdapter(type);
/* 133 */     if (isMultiValue(type, adapter)) {
/*     */       
/* 135 */       Flux<?> result = toInvoke.flatMapMany(ctx -> filterMultiValue(filterTarget.value, attribute.getExpression(), ctx));
/* 136 */       mi.getArguments()[filterTarget.index] = (adapter != null) ? adapter.fromPublisher((Publisher)result) : result;
/*     */     }
/*     */     else {
/*     */       
/* 140 */       Mono<?> result = toInvoke.flatMap(ctx -> filterSingleValue(filterTarget.value, attribute.getExpression(), ctx));
/* 141 */       mi.getArguments()[filterTarget.index] = (adapter != null) ? adapter.fromPublisher((Publisher)result) : result;
/*     */     } 
/* 143 */     return ReactiveMethodInvocationUtils.proceed(mi);
/*     */   }
/*     */   
/*     */   private FilterTarget findFilterTarget(String name, MethodInvocation mi) {
/* 147 */     Object value = null;
/* 148 */     int index = 0;
/* 149 */     if (StringUtils.hasText(name)) {
/* 150 */       Object target = mi.getThis();
/* 151 */       Class<?> targetClass = (target != null) ? AopUtils.getTargetClass(target) : null;
/* 152 */       Method specificMethod = AopUtils.getMostSpecificMethod(mi.getMethod(), targetClass);
/* 153 */       String[] parameterNames = this.parameterNameDiscoverer.getParameterNames(specificMethod);
/* 154 */       if (parameterNames != null && parameterNames.length > 0) {
/* 155 */         Object[] arguments = mi.getArguments();
/* 156 */         for (index = 0; index < parameterNames.length; index++) {
/* 157 */           if (name.equals(parameterNames[index])) {
/* 158 */             value = arguments[index];
/*     */             break;
/*     */           } 
/*     */         } 
/* 162 */         Assert.notNull(value, "Filter target was null, or no argument with name '" + name + "' found in method.");
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 167 */       Object[] arguments = mi.getArguments();
/* 168 */       Assert.state((arguments.length == 1), "Unable to determine the method argument for filtering. Specify the filter target.");
/*     */       
/* 170 */       value = arguments[0];
/* 171 */       Assert.notNull(value, "Filter target was null. Make sure you passing the correct value in the method argument.");
/*     */     } 
/*     */     
/* 174 */     Assert.state(value instanceof Publisher, "Filter target must be an instance of Publisher.");
/* 175 */     return new FilterTarget((Publisher)value, index);
/*     */   }
/*     */   
/*     */   private boolean isMultiValue(Class<?> returnType, ReactiveAdapter adapter) {
/* 179 */     if (Flux.class.isAssignableFrom(returnType)) {
/* 180 */       return true;
/*     */     }
/* 182 */     return (adapter == null || adapter.isMultiValue());
/*     */   }
/*     */ 
/*     */   
/*     */   private Mono<?> filterSingleValue(Publisher<?> filterTarget, Expression filterExpression, EvaluationContext ctx) {
/* 187 */     MethodSecurityExpressionOperations rootObject = (MethodSecurityExpressionOperations)ctx.getRootObject().getValue();
/* 188 */     return Mono.from(filterTarget).filterWhen(filterObject -> {
/*     */           rootObject.setFilterObject(filterObject);
/*     */           return (Publisher)ReactiveExpressionUtils.evaluateAsBoolean(filterExpression, ctx);
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private Flux<?> filterMultiValue(Publisher<?> filterTarget, Expression filterExpression, EvaluationContext ctx) {
/* 196 */     MethodSecurityExpressionOperations rootObject = (MethodSecurityExpressionOperations)ctx.getRootObject().getValue();
/* 197 */     return Flux.from(filterTarget).filterWhen(filterObject -> {
/*     */           rootObject.setFilterObject(filterObject);
/*     */           return (Publisher)ReactiveExpressionUtils.evaluateAsBoolean(filterExpression, ctx);
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public Pointcut getPointcut() {
/* 205 */     return this.pointcut;
/*     */   }
/*     */ 
/*     */   
/*     */   public Advice getAdvice() {
/* 210 */     return (Advice)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPerInstance() {
/* 215 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 220 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 224 */     this.order = order;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class FilterTarget
/*     */   {
/*     */     private final Publisher<?> value;
/*     */     private final int index;
/*     */     
/*     */     private FilterTarget(Publisher<?> value, int index) {
/* 234 */       this.value = value;
/* 235 */       this.index = index;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\PreFilterAuthorizationReactiveMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */