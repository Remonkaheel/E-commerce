/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import jakarta.annotation.security.DenyAll;
/*     */ import jakarta.annotation.security.PermitAll;
/*     */ import jakarta.annotation.security.RolesAllowed;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.security.authorization.AuthoritiesAuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationResult;
/*     */ import org.springframework.security.authorization.SingleResultAuthorizationManager;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanner;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanners;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Jsr250AuthorizationManager
/*     */   implements AuthorizationManager<MethodInvocation>
/*     */ {
/*  55 */   private final Jsr250AuthorizationManagerRegistry registry = new Jsr250AuthorizationManagerRegistry();
/*     */   
/*  57 */   private AuthorizationManager<Collection<String>> authoritiesAuthorizationManager = (AuthorizationManager<Collection<String>>)new AuthoritiesAuthorizationManager();
/*     */   
/*  59 */   private String rolePrefix = "ROLE_";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthoritiesAuthorizationManager(AuthorizationManager<Collection<String>> authoritiesAuthorizationManager) {
/*  70 */     Assert.notNull(authoritiesAuthorizationManager, "authoritiesAuthorizationManager cannot be null");
/*  71 */     this.authoritiesAuthorizationManager = authoritiesAuthorizationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRolePrefix(String rolePrefix) {
/*  79 */     Assert.notNull(rolePrefix, "rolePrefix cannot be null");
/*  80 */     this.rolePrefix = rolePrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public AuthorizationDecision check(Supplier<Authentication> authentication, MethodInvocation methodInvocation) {
/*  96 */     AuthorizationManager<MethodInvocation> delegate = this.registry.getManager(methodInvocation);
/*  97 */     return delegate.check(authentication, methodInvocation);
/*     */   }
/*     */   
/*     */   private final class Jsr250AuthorizationManagerRegistry
/*     */     extends AbstractAuthorizationManagerRegistry
/*     */   {
/* 103 */     private final SecurityAnnotationScanner<?> scanner = SecurityAnnotationScanners.requireUnique(List.of(DenyAll.class, PermitAll.class, RolesAllowed.class));
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     AuthorizationManager<MethodInvocation> resolveManager(Method method, Class<?> targetClass) {
/* 108 */       Annotation annotation = findJsr250Annotation(method, targetClass);
/* 109 */       if (annotation instanceof DenyAll) {
/* 110 */         return (AuthorizationManager<MethodInvocation>)SingleResultAuthorizationManager.denyAll();
/*     */       }
/* 112 */       if (annotation instanceof PermitAll) {
/* 113 */         return (AuthorizationManager<MethodInvocation>)SingleResultAuthorizationManager.permitAll();
/*     */       }
/* 115 */       if (annotation instanceof RolesAllowed) { RolesAllowed rolesAllowed = (RolesAllowed)annotation;
/* 116 */         return (a, o) -> Jsr250AuthorizationManager.this.authoritiesAuthorizationManager.authorize(a, getAllowedRolesWithPrefix(rolesAllowed)); }
/*     */ 
/*     */ 
/*     */       
/* 120 */       return NULL_MANAGER;
/*     */     }
/*     */     
/*     */     private Annotation findJsr250Annotation(Method method, Class<?> targetClass) {
/* 124 */       Class<?> targetClassToUse = (targetClass != null) ? targetClass : method.getDeclaringClass();
/* 125 */       return this.scanner.scan(method, targetClassToUse);
/*     */     }
/*     */     
/*     */     private Set<String> getAllowedRolesWithPrefix(RolesAllowed rolesAllowed) {
/* 129 */       Set<String> roles = new HashSet<>();
/* 130 */       for (int i = 0; i < (rolesAllowed.value()).length; i++) {
/* 131 */         roles.add(Jsr250AuthorizationManager.this.rolePrefix + Jsr250AuthorizationManager.this.rolePrefix);
/*     */       }
/* 133 */       return roles;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static interface AuthorizationManagerCheckAdapter<T>
/*     */     extends AuthorizationManager<T>
/*     */   {
/*     */     default AuthorizationDecision check(Supplier<Authentication> authentication, T object) {
/* 142 */       AuthorizationResult result = authorize(authentication, object);
/* 143 */       if (result == null) {
/* 144 */         return null;
/*     */       }
/* 146 */       if (result instanceof AuthorizationDecision) { AuthorizationDecision decision = (AuthorizationDecision)result;
/* 147 */         return decision; }
/*     */       
/* 149 */       throw new IllegalArgumentException("please call #authorize or ensure that the result is of type AuthorizationDecision");
/*     */     }
/*     */     
/*     */     AuthorizationResult authorize(Supplier<Authentication> param1Supplier, T param1T);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\Jsr250AuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */