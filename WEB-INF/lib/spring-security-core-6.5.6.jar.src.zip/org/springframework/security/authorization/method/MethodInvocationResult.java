/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodInvocationResult
/*    */ {
/*    */   private final MethodInvocation methodInvocation;
/*    */   private final Object result;
/*    */   
/*    */   public MethodInvocationResult(MethodInvocation methodInvocation, Object result) {
/* 42 */     Assert.notNull(methodInvocation, "methodInvocation cannot be null");
/* 43 */     this.methodInvocation = methodInvocation;
/* 44 */     this.result = result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MethodInvocation getMethodInvocation() {
/* 52 */     return this.methodInvocation;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getResult() {
/* 60 */     return this.result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\MethodInvocationResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */