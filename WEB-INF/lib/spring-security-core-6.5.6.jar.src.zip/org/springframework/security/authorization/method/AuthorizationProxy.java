package org.springframework.security.authorization.method;

import org.springframework.aop.RawTargetAccess;

public interface AuthorizationProxy extends RawTargetAccess {
  Object toAuthorizedTarget();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\AuthorizationProxy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */