/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PostAuthorizeExpressionAttribute
/*    */   extends ExpressionAttribute
/*    */ {
/*    */   private final MethodAuthorizationDeniedHandler handler;
/*    */   
/*    */   PostAuthorizeExpressionAttribute(Expression expression, MethodAuthorizationDeniedHandler handler) {
/* 33 */     super(expression);
/* 34 */     Assert.notNull(handler, "handler cannot be null");
/* 35 */     this.handler = handler;
/*    */   }
/*    */   
/*    */   MethodAuthorizationDeniedHandler getHandler() {
/* 39 */     return this.handler;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\PostAuthorizeExpressionAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */