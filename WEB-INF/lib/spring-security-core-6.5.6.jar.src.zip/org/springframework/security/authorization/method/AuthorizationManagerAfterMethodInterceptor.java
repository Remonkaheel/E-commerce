/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.function.Supplier;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.access.prepost.PostAuthorize;
/*     */ import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
/*     */ import org.springframework.security.authorization.AuthorizationDeniedException;
/*     */ import org.springframework.security.authorization.AuthorizationEventPublisher;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationResult;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthorizationManagerAfterMethodInterceptor
/*     */   implements AuthorizationAdvisor
/*     */ {
/*  51 */   private Supplier<SecurityContextHolderStrategy> securityContextHolderStrategy = SecurityContextHolder::getContextHolderStrategy;
/*     */   
/*  53 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final Pointcut pointcut;
/*     */   
/*     */   private final AuthorizationManager<MethodInvocationResult> authorizationManager;
/*     */   
/*  59 */   private final MethodAuthorizationDeniedHandler defaultHandler = new ThrowingMethodAuthorizationDeniedHandler();
/*     */   
/*     */   private int order;
/*     */   
/*  63 */   private AuthorizationEventPublisher eventPublisher = new NoOpAuthorizationEventPublisher();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationManagerAfterMethodInterceptor(Pointcut pointcut, AuthorizationManager<MethodInvocationResult> authorizationManager) {
/*  72 */     Assert.notNull(pointcut, "pointcut cannot be null");
/*  73 */     Assert.notNull(authorizationManager, "authorizationManager cannot be null");
/*  74 */     this.pointcut = pointcut;
/*  75 */     this.authorizationManager = authorizationManager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationManagerAfterMethodInterceptor postAuthorize() {
/*  83 */     return postAuthorize(new PostAuthorizeAuthorizationManager());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationManagerAfterMethodInterceptor postAuthorize(PostAuthorizeAuthorizationManager authorizationManager) {
/*  94 */     AuthorizationManagerAfterMethodInterceptor interceptor = new AuthorizationManagerAfterMethodInterceptor(AuthorizationMethodPointcuts.forAnnotations((Class<? extends Annotation>[])new Class[] { PostAuthorize.class }, ), authorizationManager);
/*  95 */     interceptor.setOrder(AuthorizationInterceptorsOrder.POST_AUTHORIZE.getOrder());
/*  96 */     return interceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static AuthorizationManagerAfterMethodInterceptor postAuthorize(AuthorizationManager<MethodInvocationResult> authorizationManager) {
/* 108 */     AuthorizationManagerAfterMethodInterceptor interceptor = new AuthorizationManagerAfterMethodInterceptor(AuthorizationMethodPointcuts.forAnnotations((Class<? extends Annotation>[])new Class[] { PostAuthorize.class }, ), authorizationManager);
/* 109 */     interceptor.setOrder(AuthorizationInterceptorsOrder.POST_AUTHORIZE.getOrder());
/* 110 */     return interceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(MethodInvocation mi) throws Throwable {
/*     */     Object result;
/*     */     try {
/* 123 */       result = mi.proceed();
/*     */     }
/* 125 */     catch (AuthorizationDeniedException ex) {
/* 126 */       AuthorizationManager<MethodInvocationResult> authorizationManager = this.authorizationManager; if (authorizationManager instanceof MethodAuthorizationDeniedHandler) { MethodAuthorizationDeniedHandler handler = (MethodAuthorizationDeniedHandler)authorizationManager;
/* 127 */         return handler.handleDeniedInvocation(mi, (AuthorizationResult)ex); }
/*     */       
/* 129 */       return this.defaultHandler.handleDeniedInvocation(mi, (AuthorizationResult)ex);
/*     */     } 
/* 131 */     return attemptAuthorization(mi, result);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getOrder() {
/* 136 */     return this.order;
/*     */   }
/*     */   
/*     */   public void setOrder(int order) {
/* 140 */     this.order = order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthorizationEventPublisher(AuthorizationEventPublisher eventPublisher) {
/* 150 */     Assert.notNull(eventPublisher, "eventPublisher cannot be null");
/* 151 */     this.eventPublisher = eventPublisher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pointcut getPointcut() {
/* 159 */     return this.pointcut;
/*     */   }
/*     */ 
/*     */   
/*     */   public Advice getAdvice() {
/* 164 */     return (Advice)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPerInstance() {
/* 169 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy strategy) {
/* 179 */     this.securityContextHolderStrategy = (() -> strategy);
/*     */   }
/*     */   
/*     */   private Object attemptAuthorization(MethodInvocation mi, Object result) {
/* 183 */     this.logger.debug(LogMessage.of(() -> "Authorizing method invocation " + String.valueOf(mi)));
/* 184 */     MethodInvocationResult object = new MethodInvocationResult(mi, result);
/* 185 */     AuthorizationResult authorizationResult = this.authorizationManager.authorize(this::getAuthentication, object);
/* 186 */     this.eventPublisher.publishAuthorizationEvent(this::getAuthentication, object, authorizationResult);
/* 187 */     if (authorizationResult != null && !authorizationResult.isGranted()) {
/* 188 */       this.logger.debug(LogMessage.of(() -> "Failed to authorize " + String.valueOf(mi) + " with authorization manager " + String.valueOf(this.authorizationManager) + " and authorizationResult " + String.valueOf(authorizationResult)));
/*     */       
/* 190 */       return handlePostInvocationDenied(object, authorizationResult);
/*     */     } 
/* 192 */     this.logger.debug(LogMessage.of(() -> "Authorized method invocation " + String.valueOf(mi)));
/* 193 */     return result;
/*     */   }
/*     */   
/*     */   private Object handlePostInvocationDenied(MethodInvocationResult mi, AuthorizationResult result) {
/* 197 */     AuthorizationManager<MethodInvocationResult> authorizationManager = this.authorizationManager; if (authorizationManager instanceof MethodAuthorizationDeniedHandler) { MethodAuthorizationDeniedHandler deniedHandler = (MethodAuthorizationDeniedHandler)authorizationManager;
/* 198 */       return deniedHandler.handleDeniedInvocationResult(mi, result); }
/*     */     
/* 200 */     return this.defaultHandler.handleDeniedInvocationResult(mi, result);
/*     */   }
/*     */   
/*     */   private Authentication getAuthentication() {
/* 204 */     Authentication authentication = ((SecurityContextHolderStrategy)this.securityContextHolderStrategy.get()).getContext().getAuthentication();
/* 205 */     if (authentication == null) {
/* 206 */       throw new AuthenticationCredentialsNotFoundException("An Authentication object was not found in the SecurityContext");
/*     */     }
/*     */     
/* 209 */     return authentication;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\AuthorizationManagerAfterMethodInterceptor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */