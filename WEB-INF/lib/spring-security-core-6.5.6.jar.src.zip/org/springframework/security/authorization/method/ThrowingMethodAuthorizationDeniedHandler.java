/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.security.authorization.AuthorizationDeniedException;
/*    */ import org.springframework.security.authorization.AuthorizationResult;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ThrowingMethodAuthorizationDeniedHandler
/*    */   implements MethodAuthorizationDeniedHandler
/*    */ {
/*    */   public Object handleDeniedInvocation(MethodInvocation methodInvocation, AuthorizationResult authorizationResult) {
/* 35 */     if (authorizationResult instanceof AuthorizationDeniedException) { AuthorizationDeniedException denied = (AuthorizationDeniedException)authorizationResult;
/* 36 */       throw denied; }
/*    */     
/* 38 */     throw new AuthorizationDeniedException("Access Denied", authorizationResult);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object handleDeniedInvocationResult(MethodInvocationResult methodInvocationResult, AuthorizationResult authorizationResult) {
/* 44 */     if (authorizationResult instanceof AuthorizationDeniedException) { AuthorizationDeniedException denied = (AuthorizationDeniedException)authorizationResult;
/* 45 */       throw denied; }
/*    */     
/* 47 */     throw new AuthorizationDeniedException("Access Denied", authorizationResult);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\ThrowingMethodAuthorizationDeniedHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */