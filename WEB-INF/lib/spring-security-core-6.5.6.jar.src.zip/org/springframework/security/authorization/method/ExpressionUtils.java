/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.EvaluationException;
/*    */ import org.springframework.expression.Expression;
/*    */ import org.springframework.security.authorization.AuthorizationDeniedException;
/*    */ import org.springframework.security.authorization.AuthorizationResult;
/*    */ import org.springframework.security.authorization.ExpressionAuthorizationDecision;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ExpressionUtils
/*    */ {
/*    */   static AuthorizationResult evaluate(Expression expr, EvaluationContext ctx) {
/*    */     try {
/* 33 */       Object result = expr.getValue(ctx);
/* 34 */       if (result instanceof AuthorizationResult) { AuthorizationResult decision = (AuthorizationResult)result;
/* 35 */         return decision; }
/*    */       
/* 37 */       if (result instanceof Boolean) { Boolean granted = (Boolean)result;
/* 38 */         return (AuthorizationResult)new ExpressionAuthorizationDecision(granted.booleanValue(), expr); }
/*    */       
/* 40 */       if (result == null) {
/* 41 */         return null;
/*    */       }
/* 43 */       throw new IllegalArgumentException("SpEL expression must return either a Boolean or an AuthorizationDecision");
/*    */     
/*    */     }
/* 46 */     catch (EvaluationException ex) {
/* 47 */       AuthorizationDeniedException denied = findAuthorizationException(ex);
/* 48 */       if (denied != null) {
/* 49 */         throw denied;
/*    */       }
/* 51 */       throw new IllegalArgumentException("Failed to evaluate expression '" + expr.getExpressionString() + "'", ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   static AuthorizationDeniedException findAuthorizationException(EvaluationException ex) {
/* 57 */     Throwable cause = ex.getCause();
/* 58 */     while (cause != null) {
/* 59 */       if (cause instanceof AuthorizationDeniedException) { AuthorizationDeniedException denied = (AuthorizationDeniedException)cause;
/* 60 */         return denied; }
/*    */       
/* 62 */       cause = cause.getCause();
/*    */     } 
/* 64 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\ExpressionUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */