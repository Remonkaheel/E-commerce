/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.function.Supplier;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.core.MethodClassKey;
/*    */ import org.springframework.lang.NonNull;
/*    */ import org.springframework.security.authorization.AuthorizationDecision;
/*    */ import org.springframework.security.authorization.AuthorizationManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractAuthorizationManagerRegistry
/*    */ {
/*    */   static final AuthorizationManager<MethodInvocation> NULL_MANAGER = (a, o) -> null;
/* 38 */   private final Map<MethodClassKey, AuthorizationManager<MethodInvocation>> cachedManagers = new ConcurrentHashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   final AuthorizationManager<MethodInvocation> getManager(MethodInvocation methodInvocation) {
/* 46 */     Method method = methodInvocation.getMethod();
/* 47 */     Object target = methodInvocation.getThis();
/* 48 */     Class<?> targetClass = (target != null) ? target.getClass() : null;
/* 49 */     MethodClassKey cacheKey = new MethodClassKey(method, targetClass);
/* 50 */     return this.cachedManagers.computeIfAbsent(cacheKey, k -> resolveManager(method, targetClass));
/*    */   }
/*    */   
/*    */   @NonNull
/*    */   abstract AuthorizationManager<MethodInvocation> resolveManager(Method paramMethod, Class<?> paramClass);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\AbstractAuthorizationManagerRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */