/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class PrePostTemplateDefaults
/*    */ {
/*    */   private boolean ignoreUnknown = true;
/*    */   
/*    */   public boolean isIgnoreUnknown() {
/* 43 */     return this.ignoreUnknown;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setIgnoreUnknown(boolean ignoreUnknown) {
/* 55 */     this.ignoreUnknown = ignoreUnknown;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\PrePostTemplateDefaults.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */