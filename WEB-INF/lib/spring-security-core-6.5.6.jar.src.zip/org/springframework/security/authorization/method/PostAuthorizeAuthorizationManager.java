/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationResult;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PostAuthorizeAuthorizationManager
/*     */   implements AuthorizationManager<MethodInvocationResult>, MethodAuthorizationDeniedHandler
/*     */ {
/*  44 */   private PostAuthorizeExpressionAttributeRegistry registry = new PostAuthorizeExpressionAttributeRegistry();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpressionHandler(MethodSecurityExpressionHandler expressionHandler) {
/*  51 */     this.registry.setExpressionHandler(expressionHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setTemplateDefaults(PrePostTemplateDefaults defaults) {
/*  66 */     this.registry.setTemplateDefaults(defaults);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTemplateDefaults(AnnotationTemplateExpressionDefaults defaults) {
/*  78 */     this.registry.setTemplateDefaults(defaults);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplicationContext(ApplicationContext context) {
/*  90 */     this.registry.setApplicationContext(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationDecision check(Supplier<Authentication> authentication, MethodInvocationResult mi) {
/* 104 */     ExpressionAttribute attribute = this.registry.getAttribute(mi.getMethodInvocation());
/* 105 */     if (attribute == ExpressionAttribute.NULL_ATTRIBUTE) {
/* 106 */       return null;
/*     */     }
/* 108 */     MethodSecurityExpressionHandler expressionHandler = this.registry.getExpressionHandler();
/* 109 */     EvaluationContext ctx = expressionHandler.createEvaluationContext(authentication, mi.getMethodInvocation());
/* 110 */     expressionHandler.setReturnObject(mi.getResult(), ctx);
/* 111 */     return (AuthorizationDecision)ExpressionUtils.evaluate(attribute.getExpression(), ctx);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object handleDeniedInvocation(MethodInvocation methodInvocation, AuthorizationResult authorizationResult) {
/* 116 */     ExpressionAttribute attribute = this.registry.getAttribute(methodInvocation);
/* 117 */     PostAuthorizeExpressionAttribute postAuthorizeAttribute = (PostAuthorizeExpressionAttribute)attribute;
/* 118 */     return postAuthorizeAttribute.getHandler().handleDeniedInvocation(methodInvocation, authorizationResult);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object handleDeniedInvocationResult(MethodInvocationResult methodInvocationResult, AuthorizationResult authorizationResult) {
/* 124 */     ExpressionAttribute attribute = this.registry.getAttribute(methodInvocationResult.getMethodInvocation());
/* 125 */     PostAuthorizeExpressionAttribute postAuthorizeAttribute = (PostAuthorizeExpressionAttribute)attribute;
/* 126 */     return postAuthorizeAttribute.getHandler()
/* 127 */       .handleDeniedInvocationResult(methodInvocationResult, authorizationResult);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\PostAuthorizeAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */