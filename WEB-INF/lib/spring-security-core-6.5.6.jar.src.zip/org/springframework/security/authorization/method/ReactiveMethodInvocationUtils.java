/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import reactor.core.Exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ReactiveMethodInvocationUtils
/*    */ {
/*    */   static <T> T proceed(MethodInvocation mi) {
/*    */     try {
/* 32 */       return (T)mi.proceed();
/*    */     }
/* 34 */     catch (Throwable ex) {
/* 35 */       throw Exceptions.propagate(ex);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\ReactiveMethodInvocationUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */