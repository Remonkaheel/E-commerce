/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.AuthorizationManager;
/*     */ import org.springframework.security.authorization.AuthorizationResult;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PreAuthorizeAuthorizationManager
/*     */   implements AuthorizationManager<MethodInvocation>, MethodAuthorizationDeniedHandler
/*     */ {
/*  44 */   private PreAuthorizeExpressionAttributeRegistry registry = new PreAuthorizeExpressionAttributeRegistry();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExpressionHandler(MethodSecurityExpressionHandler expressionHandler) {
/*  51 */     this.registry.setExpressionHandler(expressionHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setTemplateDefaults(PrePostTemplateDefaults defaults) {
/*  66 */     this.registry.setTemplateDefaults(defaults);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTemplateDefaults(AnnotationTemplateExpressionDefaults defaults) {
/*  78 */     this.registry.setTemplateDefaults(defaults);
/*     */   }
/*     */   
/*     */   public void setApplicationContext(ApplicationContext context) {
/*  82 */     this.registry.setApplicationContext(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationDecision check(Supplier<Authentication> authentication, MethodInvocation mi) {
/*  96 */     ExpressionAttribute attribute = this.registry.getAttribute(mi);
/*  97 */     if (attribute == ExpressionAttribute.NULL_ATTRIBUTE) {
/*  98 */       return null;
/*     */     }
/* 100 */     EvaluationContext ctx = this.registry.getExpressionHandler().createEvaluationContext(authentication, mi);
/* 101 */     return (AuthorizationDecision)ExpressionUtils.evaluate(attribute.getExpression(), ctx);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object handleDeniedInvocation(MethodInvocation methodInvocation, AuthorizationResult authorizationResult) {
/* 106 */     ExpressionAttribute attribute = this.registry.getAttribute(methodInvocation);
/* 107 */     PreAuthorizeExpressionAttribute preAuthorizeAttribute = (PreAuthorizeExpressionAttribute)attribute;
/* 108 */     return preAuthorizeAttribute.getHandler().handleDeniedInvocation(methodInvocation, authorizationResult);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\PreAuthorizeAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */