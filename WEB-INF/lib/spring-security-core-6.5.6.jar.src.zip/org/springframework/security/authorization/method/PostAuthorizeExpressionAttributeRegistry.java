/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.function.Function;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.security.access.prepost.PostAuthorize;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanner;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanners;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.util.annotation.NonNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PostAuthorizeExpressionAttributeRegistry
/*     */   extends AbstractExpressionAttributeRegistry<ExpressionAttribute>
/*     */ {
/*  42 */   private final MethodAuthorizationDeniedHandler defaultHandler = new ThrowingMethodAuthorizationDeniedHandler();
/*     */ 
/*     */   
/*  45 */   private final SecurityAnnotationScanner<HandleAuthorizationDenied> handleAuthorizationDeniedScanner = SecurityAnnotationScanners.requireUnique(HandleAuthorizationDenied.class);
/*     */ 
/*     */   
/*     */   private Function<Class<? extends MethodAuthorizationDeniedHandler>, MethodAuthorizationDeniedHandler> handlerResolver;
/*     */   
/*  50 */   private SecurityAnnotationScanner<PostAuthorize> postAuthorizeScanner = SecurityAnnotationScanners.requireUnique(PostAuthorize.class);
/*     */   
/*     */   PostAuthorizeExpressionAttributeRegistry() {
/*  53 */     this.handlerResolver = (clazz -> new ReflectiveMethodAuthorizationDeniedHandler(clazz, PostAuthorizeAuthorizationManager.class));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   ExpressionAttribute resolveAttribute(Method method, Class<?> targetClass) {
/*  60 */     PostAuthorize postAuthorize = findPostAuthorizeAnnotation(method, targetClass);
/*  61 */     if (postAuthorize == null) {
/*  62 */       return ExpressionAttribute.NULL_ATTRIBUTE;
/*     */     }
/*  64 */     Expression expression = getExpressionHandler().getExpressionParser().parseExpression(postAuthorize.value());
/*  65 */     MethodAuthorizationDeniedHandler deniedHandler = resolveHandler(method, targetClass);
/*  66 */     return new PostAuthorizeExpressionAttribute(expression, deniedHandler);
/*     */   }
/*     */   
/*     */   private MethodAuthorizationDeniedHandler resolveHandler(Method method, Class<?> targetClass) {
/*  70 */     Class<?> targetClassToUse = targetClass(method, targetClass);
/*  71 */     HandleAuthorizationDenied deniedHandler = (HandleAuthorizationDenied)this.handleAuthorizationDeniedScanner.scan(method, targetClassToUse);
/*  72 */     if (deniedHandler != null) {
/*  73 */       return this.handlerResolver.apply(deniedHandler.handlerClass());
/*     */     }
/*  75 */     return this.defaultHandler;
/*     */   }
/*     */   
/*     */   private PostAuthorize findPostAuthorizeAnnotation(Method method, Class<?> targetClass) {
/*  79 */     Class<?> targetClassToUse = targetClass(method, targetClass);
/*  80 */     return (PostAuthorize)this.postAuthorizeScanner.scan(method, targetClassToUse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setApplicationContext(ApplicationContext context) {
/*  89 */     Assert.notNull(context, "context cannot be null");
/*  90 */     this.handlerResolver = (clazz -> resolveHandler(context, clazz));
/*     */   }
/*     */   
/*     */   void setTemplateDefaults(AnnotationTemplateExpressionDefaults templateDefaults) {
/*  94 */     this.postAuthorizeScanner = SecurityAnnotationScanners.requireUnique(PostAuthorize.class, templateDefaults);
/*     */   }
/*     */ 
/*     */   
/*     */   private MethodAuthorizationDeniedHandler resolveHandler(ApplicationContext context, Class<? extends MethodAuthorizationDeniedHandler> handlerClass) {
/*  99 */     if (handlerClass == this.defaultHandler.getClass()) {
/* 100 */       return this.defaultHandler;
/*     */     }
/* 102 */     String[] beanNames = context.getBeanNamesForType(handlerClass);
/* 103 */     if (beanNames.length == 0) {
/* 104 */       throw new IllegalStateException("Could not find a bean of type " + handlerClass.getName());
/*     */     }
/* 106 */     if (beanNames.length > 1) {
/* 107 */       throw new IllegalStateException("Expected to find a single bean of type " + handlerClass.getName() + " but found " + 
/* 108 */           Arrays.toString(beanNames));
/*     */     }
/* 110 */     return (MethodAuthorizationDeniedHandler)context.getBean(beanNames[0], handlerClass);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\PostAuthorizeExpressionAttributeRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */