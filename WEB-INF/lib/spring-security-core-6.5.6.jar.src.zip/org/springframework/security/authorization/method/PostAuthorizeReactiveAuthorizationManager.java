/*     */ package org.springframework.security.authorization.method;
/*     */ 
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
/*     */ import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.AuthorizationResult;
/*     */ import org.springframework.security.authorization.ReactiveAuthorizationManager;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.annotation.AnnotationTemplateExpressionDefaults;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PostAuthorizeReactiveAuthorizationManager
/*     */   implements ReactiveAuthorizationManager<MethodInvocationResult>, MethodAuthorizationDeniedHandler
/*     */ {
/*  44 */   private final PostAuthorizeExpressionAttributeRegistry registry = new PostAuthorizeExpressionAttributeRegistry();
/*     */   
/*     */   public PostAuthorizeReactiveAuthorizationManager() {
/*  47 */     this((MethodSecurityExpressionHandler)new DefaultMethodSecurityExpressionHandler());
/*     */   }
/*     */   
/*     */   public PostAuthorizeReactiveAuthorizationManager(MethodSecurityExpressionHandler expressionHandler) {
/*  51 */     Assert.notNull(expressionHandler, "expressionHandler cannot be null");
/*  52 */     this.registry.setExpressionHandler(expressionHandler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setTemplateDefaults(PrePostTemplateDefaults defaults) {
/*  67 */     this.registry.setTemplateDefaults(defaults);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTemplateDefaults(AnnotationTemplateExpressionDefaults defaults) {
/*  79 */     this.registry.setTemplateDefaults(defaults);
/*     */   }
/*     */   
/*     */   public void setApplicationContext(ApplicationContext context) {
/*  83 */     this.registry.setApplicationContext(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<AuthorizationDecision> check(Mono<Authentication> authentication, MethodInvocationResult result) {
/*  97 */     MethodInvocation mi = result.getMethodInvocation();
/*  98 */     ExpressionAttribute attribute = this.registry.getAttribute(mi);
/*  99 */     if (attribute == ExpressionAttribute.NULL_ATTRIBUTE) {
/* 100 */       return Mono.empty();
/*     */     }
/*     */     
/* 103 */     MethodSecurityExpressionHandler expressionHandler = this.registry.getExpressionHandler();
/*     */     
/* 105 */     return authentication
/* 106 */       .map(auth -> expressionHandler.createEvaluationContext(auth, mi))
/* 107 */       .doOnNext(ctx -> expressionHandler.setReturnObject(result.getResult(), ctx))
/* 108 */       .flatMap(ctx -> ReactiveExpressionUtils.evaluate(attribute.getExpression(), ctx))
/* 109 */       .cast(AuthorizationDecision.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object handleDeniedInvocation(MethodInvocation methodInvocation, AuthorizationResult authorizationResult) {
/* 115 */     ExpressionAttribute attribute = this.registry.getAttribute(methodInvocation);
/* 116 */     PostAuthorizeExpressionAttribute postAuthorizeAttribute = (PostAuthorizeExpressionAttribute)attribute;
/* 117 */     return postAuthorizeAttribute.getHandler().handleDeniedInvocation(methodInvocation, authorizationResult);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object handleDeniedInvocationResult(MethodInvocationResult methodInvocationResult, AuthorizationResult authorizationResult) {
/* 123 */     ExpressionAttribute attribute = this.registry.getAttribute(methodInvocationResult.getMethodInvocation());
/* 124 */     PostAuthorizeExpressionAttribute postAuthorizeAttribute = (PostAuthorizeExpressionAttribute)attribute;
/* 125 */     return postAuthorizeAttribute.getHandler()
/* 126 */       .handleDeniedInvocationResult(methodInvocationResult, authorizationResult);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\PostAuthorizeReactiveAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */