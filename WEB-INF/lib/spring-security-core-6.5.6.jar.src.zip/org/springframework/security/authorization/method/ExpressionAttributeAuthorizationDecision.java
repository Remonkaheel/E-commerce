/*    */ package org.springframework.security.authorization.method;
/*    */ 
/*    */ import org.springframework.security.authorization.AuthorizationDecision;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public class ExpressionAttributeAuthorizationDecision
/*    */   extends AuthorizationDecision
/*    */ {
/*    */   private final ExpressionAttribute expressionAttribute;
/*    */   
/*    */   public ExpressionAttributeAuthorizationDecision(boolean granted, ExpressionAttribute expressionAttribute) {
/* 36 */     super(granted);
/* 37 */     this.expressionAttribute = expressionAttribute;
/*    */   }
/*    */   
/*    */   public ExpressionAttribute getExpressionAttribute() {
/* 41 */     return this.expressionAttribute;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 46 */     return getClass().getSimpleName() + " [granted=" + getClass().getSimpleName() + ", expressionAttribute=" + isGranted() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\method\ExpressionAttributeAuthorizationDecision.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */