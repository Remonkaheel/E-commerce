/*    */ package org.springframework.security.authorization;
/*    */ 
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ReactiveAuthorizationManager<T>
/*    */ {
/*    */   default Mono<Void> verify(Mono<Authentication> authentication, T object) {
/* 53 */     return check(authentication, object)
/* 54 */       .filter(AuthorizationDecision::isGranted)
/* 55 */       .switchIfEmpty(Mono.defer(() -> Mono.error((Throwable)new AccessDeniedException("Access Denied"))))
/* 56 */       .flatMap(decision -> Mono.empty());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default Mono<AuthorizationResult> authorize(Mono<Authentication> authentication, T object) {
/* 68 */     return check(authentication, object).cast(AuthorizationResult.class);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   Mono<AuthorizationDecision> check(Mono<Authentication> paramMono, T paramT);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\ReactiveAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */