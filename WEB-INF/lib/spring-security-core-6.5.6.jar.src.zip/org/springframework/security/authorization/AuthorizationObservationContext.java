/*     */ package org.springframework.security.authorization;
/*     */ 
/*     */ import io.micrometer.observation.Observation;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthorizationObservationContext<T>
/*     */   extends Observation.Context
/*     */ {
/*     */   private Authentication authentication;
/*     */   private final T object;
/*     */   private AuthorizationResult authorizationResult;
/*     */   
/*     */   public AuthorizationObservationContext(T object) {
/*  39 */     Assert.notNull(object, "object cannot be null");
/*  40 */     this.object = object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Authentication getAuthentication() {
/*  52 */     return this.authentication;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthentication(Authentication authentication) {
/*  60 */     this.authentication = authentication;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T getObject() {
/*  68 */     return this.object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public AuthorizationDecision getDecision() {
/*  78 */     if (this.authorizationResult == null) {
/*  79 */       return null;
/*     */     }
/*  81 */     AuthorizationResult authorizationResult = this.authorizationResult; if (authorizationResult instanceof AuthorizationDecision) { AuthorizationDecision decision = (AuthorizationDecision)authorizationResult;
/*  82 */       return decision; }
/*     */     
/*  84 */     throw new IllegalArgumentException("Please call getAuthorizationResult instead. If you must call getDecision, please ensure that the result you provide is of type AuthorizationDecision");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setDecision(AuthorizationDecision decision) {
/*  95 */     this.authorizationResult = decision;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationResult getAuthorizationResult() {
/* 104 */     return this.authorizationResult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthorizationResult(AuthorizationResult authorizationResult) {
/* 113 */     this.authorizationResult = authorizationResult;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\AuthorizationObservationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */