/*     */ package org.springframework.security.authorization;
/*     */ 
/*     */ import java.util.Set;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthorityAuthorizationManager<T>
/*     */   implements AuthorizationManager<T>
/*     */ {
/*     */   private static final String ROLE_PREFIX = "ROLE_";
/*  39 */   private final AuthoritiesAuthorizationManager delegate = new AuthoritiesAuthorizationManager();
/*     */   
/*     */   private final Set<String> authorities;
/*     */   
/*     */   private AuthorityAuthorizationManager(String... authorities) {
/*  44 */     this.authorities = Set.of(authorities);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRoleHierarchy(RoleHierarchy roleHierarchy) {
/*  54 */     this.delegate.setRoleHierarchy(roleHierarchy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> AuthorityAuthorizationManager<T> hasRole(String role) {
/*  66 */     Assert.notNull(role, "role cannot be null");
/*  67 */     Assert.isTrue(!role.startsWith("ROLE_"), () -> role + " should not start with ROLE_ since ROLE_ is automatically prepended when using hasRole. Consider using hasAuthority instead.");
/*     */     
/*  69 */     return hasAuthority("ROLE_" + role);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> AuthorityAuthorizationManager<T> hasAuthority(String authority) {
/*  80 */     Assert.notNull(authority, "authority cannot be null");
/*  81 */     return new AuthorityAuthorizationManager<>(new String[] { authority });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> AuthorityAuthorizationManager<T> hasAnyRole(String... roles) {
/*  93 */     return hasAnyRole("ROLE_", roles);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> AuthorityAuthorizationManager<T> hasAnyRole(String rolePrefix, String[] roles) {
/* 105 */     Assert.notNull(rolePrefix, "rolePrefix cannot be null");
/* 106 */     Assert.notEmpty((Object[])roles, "roles cannot be empty");
/* 107 */     Assert.noNullElements((Object[])roles, "roles cannot contain null values");
/* 108 */     return hasAnyAuthority(toNamedRolesArray(rolePrefix, roles));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> AuthorityAuthorizationManager<T> hasAnyAuthority(String... authorities) {
/* 119 */     Assert.notEmpty((Object[])authorities, "authorities cannot be empty");
/* 120 */     Assert.noNullElements((Object[])authorities, "authorities cannot contain null values");
/* 121 */     return new AuthorityAuthorizationManager<>(authorities);
/*     */   }
/*     */   
/*     */   private static String[] toNamedRolesArray(String rolePrefix, String[] roles) {
/* 125 */     String[] result = new String[roles.length];
/* 126 */     for (int i = 0; i < roles.length; i++) {
/* 127 */       String role = roles[i];
/* 128 */       Assert.isTrue((rolePrefix.isEmpty() || !role.startsWith(rolePrefix)), () -> role + " should not start with " + role + " since " + rolePrefix + " is automatically prepended when using hasAnyRole. Consider using hasAnyAuthority instead.");
/*     */ 
/*     */       
/* 131 */       result[i] = rolePrefix + rolePrefix;
/*     */     } 
/* 133 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public AuthorizationDecision check(Supplier<Authentication> authentication, T object) {
/* 147 */     return this.delegate.check(authentication, this.authorities);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 152 */     return "AuthorityAuthorizationManager[authorities=" + String.valueOf(this.authorities) + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\AuthorityAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */