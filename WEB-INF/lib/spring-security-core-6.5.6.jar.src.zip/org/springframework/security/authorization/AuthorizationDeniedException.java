/*    */ package org.springframework.security.authorization;
/*    */ 
/*    */ import org.springframework.security.access.AccessDeniedException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthorizationDeniedException
/*    */   extends AccessDeniedException
/*    */   implements AuthorizationResult
/*    */ {
/*    */   private static final long serialVersionUID = 3227305845919610459L;
/*    */   private final AuthorizationResult result;
/*    */   
/*    */   public AuthorizationDeniedException(String msg, AuthorizationResult authorizationResult) {
/* 38 */     super(msg);
/* 39 */     Assert.notNull(authorizationResult, "authorizationResult cannot be null");
/* 40 */     Assert.isTrue(!authorizationResult.isGranted(), "Granted authorization results are not supported");
/* 41 */     this.result = authorizationResult;
/*    */   }
/*    */   
/*    */   public AuthorizationDeniedException(String msg) {
/* 45 */     this(msg, new AuthorizationDecision(false));
/*    */   }
/*    */   
/*    */   public AuthorizationResult getAuthorizationResult() {
/* 49 */     return this.result;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isGranted() {
/* 54 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\AuthorizationDeniedException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */