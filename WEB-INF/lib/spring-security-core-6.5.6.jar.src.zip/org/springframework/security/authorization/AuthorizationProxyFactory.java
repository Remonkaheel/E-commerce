package org.springframework.security.authorization;

public interface AuthorizationProxyFactory {
  Object proxy(Object paramObject);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\AuthorizationProxyFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */