/*     */ package org.springframework.security.authorization;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*     */ import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthenticatedAuthorizationManager<T>
/*     */   implements AuthorizationManager<T>
/*     */ {
/*     */   private final AbstractAuthorizationStrategy authorizationStrategy;
/*     */   
/*     */   public AuthenticatedAuthorizationManager() {
/*  48 */     this(new AuthenticatedAuthorizationStrategy());
/*     */   }
/*     */   
/*     */   private AuthenticatedAuthorizationManager(AbstractAuthorizationStrategy authorizationStrategy) {
/*  52 */     this.authorizationStrategy = authorizationStrategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrustResolver(AuthenticationTrustResolver trustResolver) {
/*  62 */     this.authorizationStrategy.setTrustResolver(trustResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> AuthenticatedAuthorizationManager<T> authenticated() {
/*  71 */     return new AuthenticatedAuthorizationManager<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> AuthenticatedAuthorizationManager<T> fullyAuthenticated() {
/*  82 */     return new AuthenticatedAuthorizationManager<>(new FullyAuthenticatedAuthorizationStrategy());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> AuthenticatedAuthorizationManager<T> rememberMe() {
/*  93 */     return new AuthenticatedAuthorizationManager<>(new RememberMeAuthorizationStrategy());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> AuthenticatedAuthorizationManager<T> anonymous() {
/* 104 */     return new AuthenticatedAuthorizationManager<>(new AnonymousAuthorizationStrategy());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationDecision check(Supplier<Authentication> authentication, T object) {
/* 115 */     boolean granted = this.authorizationStrategy.isGranted(authentication.get());
/* 116 */     return new AuthorizationDecision(granted);
/*     */   }
/*     */   
/*     */   private static abstract class AbstractAuthorizationStrategy
/*     */   {
/* 121 */     AuthenticationTrustResolver trustResolver = (AuthenticationTrustResolver)new AuthenticationTrustResolverImpl();
/*     */     
/*     */     private void setTrustResolver(AuthenticationTrustResolver trustResolver) {
/* 124 */       Assert.notNull(trustResolver, "trustResolver cannot be null");
/* 125 */       this.trustResolver = trustResolver;
/*     */     }
/*     */ 
/*     */     
/*     */     abstract boolean isGranted(Authentication param1Authentication);
/*     */   }
/*     */   
/*     */   private static class AuthenticatedAuthorizationStrategy
/*     */     extends AbstractAuthorizationStrategy
/*     */   {
/*     */     boolean isGranted(Authentication authentication) {
/* 136 */       return this.trustResolver.isAuthenticated(authentication);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class FullyAuthenticatedAuthorizationStrategy
/*     */     extends AuthenticatedAuthorizationStrategy
/*     */   {
/*     */     boolean isGranted(Authentication authentication) {
/* 145 */       return this.trustResolver.isFullyAuthenticated(authentication);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class AnonymousAuthorizationStrategy
/*     */     extends AbstractAuthorizationStrategy
/*     */   {
/*     */     boolean isGranted(Authentication authentication) {
/* 154 */       return this.trustResolver.isAnonymous(authentication);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class RememberMeAuthorizationStrategy
/*     */     extends AbstractAuthorizationStrategy
/*     */   {
/*     */     boolean isGranted(Authentication authentication) {
/* 163 */       return this.trustResolver.isRememberMe(authentication);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\AuthenticatedAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */