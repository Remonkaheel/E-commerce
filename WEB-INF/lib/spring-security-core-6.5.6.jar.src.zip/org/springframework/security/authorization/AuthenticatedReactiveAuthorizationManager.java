/*    */ package org.springframework.security.authorization;
/*    */ 
/*    */ import org.springframework.security.authentication.AuthenticationTrustResolver;
/*    */ import org.springframework.security.authentication.AuthenticationTrustResolverImpl;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticatedReactiveAuthorizationManager<T>
/*    */   implements ReactiveAuthorizationManager<T>
/*    */ {
/* 36 */   private AuthenticationTrustResolver authTrustResolver = (AuthenticationTrustResolver)new AuthenticationTrustResolverImpl();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<AuthorizationDecision> check(Mono<Authentication> authentication, T object) {
/* 43 */     return authentication.filter(this::isNotAnonymous)
/* 44 */       .map(this::getAuthorizationDecision)
/* 45 */       .defaultIfEmpty(new AuthorizationDecision(false));
/*    */   }
/*    */   
/*    */   private AuthorizationDecision getAuthorizationDecision(Authentication authentication) {
/* 49 */     return new AuthorizationDecision(authentication.isAuthenticated());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean isNotAnonymous(Authentication authentication) {
/* 59 */     return !this.authTrustResolver.isAnonymous(authentication);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T> AuthenticatedReactiveAuthorizationManager<T> authenticated() {
/* 68 */     return new AuthenticatedReactiveAuthorizationManager<>();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\AuthenticatedReactiveAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */