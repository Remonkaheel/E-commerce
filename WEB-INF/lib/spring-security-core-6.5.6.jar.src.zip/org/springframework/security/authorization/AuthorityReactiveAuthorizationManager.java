/*     */ package org.springframework.security.authorization;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Mono;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthorityReactiveAuthorizationManager<T>
/*     */   implements ReactiveAuthorizationManager<T>
/*     */ {
/*     */   private final List<GrantedAuthority> authorities;
/*     */   
/*     */   AuthorityReactiveAuthorizationManager(String... authorities) {
/*  42 */     this.authorities = AuthorityUtils.createAuthorityList(authorities);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<AuthorizationDecision> check(Mono<Authentication> authentication, T object) {
/*  48 */     return authentication.filter(Authentication::isAuthenticated)
/*  49 */       .flatMapIterable(Authentication::getAuthorities)
/*  50 */       .map(GrantedAuthority::getAuthority)
/*  51 */       .any(grantedAuthority -> this.authorities.stream().anyMatch(()))
/*  52 */       .map(granted -> new AuthorityAuthorizationDecision(granted.booleanValue(), this.authorities))
/*  53 */       .defaultIfEmpty(new AuthorityAuthorizationDecision(false, this.authorities));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> AuthorityReactiveAuthorizationManager<T> hasAuthority(String authority) {
/*  65 */     Assert.notNull(authority, "authority cannot be null");
/*  66 */     return new AuthorityReactiveAuthorizationManager<>(new String[] { authority });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> AuthorityReactiveAuthorizationManager<T> hasAnyAuthority(String... authorities) {
/*  77 */     Assert.notNull(authorities, "authorities cannot be null");
/*  78 */     for (String authority : authorities) {
/*  79 */       Assert.notNull(authority, "authority cannot be null");
/*     */     }
/*  81 */     return new AuthorityReactiveAuthorizationManager<>(authorities);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> AuthorityReactiveAuthorizationManager<T> hasRole(String role) {
/*  92 */     Assert.notNull(role, "role cannot be null");
/*  93 */     return hasAuthority("ROLE_" + role);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> AuthorityReactiveAuthorizationManager<T> hasAnyRole(String... roles) {
/* 104 */     Assert.notNull(roles, "roles cannot be null");
/* 105 */     for (String role : roles) {
/* 106 */       Assert.notNull(role, "role cannot be null");
/*     */     }
/* 108 */     return hasAnyAuthority(toNamedRolesArray(roles));
/*     */   }
/*     */   
/*     */   private static String[] toNamedRolesArray(String... roles) {
/* 112 */     String[] result = new String[roles.length];
/* 113 */     for (int i = 0; i < roles.length; i++) {
/* 114 */       result[i] = "ROLE_" + roles[i];
/*     */     }
/* 116 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\AuthorityReactiveAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */