/*    */ package org.springframework.security.authorization;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationEventPublisher;
/*    */ import org.springframework.security.authorization.event.AuthorizationDeniedEvent;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpringAuthorizationEventPublisher
/*    */   implements AuthorizationEventPublisher
/*    */ {
/*    */   private final ApplicationEventPublisher eventPublisher;
/*    */   
/*    */   public SpringAuthorizationEventPublisher(ApplicationEventPublisher eventPublisher) {
/* 48 */     Assert.notNull(eventPublisher, "eventPublisher cannot be null");
/* 49 */     this.eventPublisher = eventPublisher;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> void publishAuthorizationEvent(Supplier<Authentication> authentication, T object, AuthorizationDecision decision) {
/* 58 */     publishAuthorizationEvent(authentication, object, decision);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public <T> void publishAuthorizationEvent(Supplier<Authentication> authentication, T object, AuthorizationResult result) {
/* 64 */     if (result == null || result.isGranted()) {
/*    */       return;
/*    */     }
/* 67 */     AuthorizationDeniedEvent<T> failure = new AuthorizationDeniedEvent(authentication, object, result);
/* 68 */     this.eventPublisher.publishEvent((ApplicationEvent)failure);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\SpringAuthorizationEventPublisher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */