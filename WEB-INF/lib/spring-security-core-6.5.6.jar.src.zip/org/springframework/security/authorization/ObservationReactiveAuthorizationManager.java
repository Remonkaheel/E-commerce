/*     */ package org.springframework.security.authorization;
/*     */ 
/*     */ import io.micrometer.observation.Observation;
/*     */ import io.micrometer.observation.ObservationConvention;
/*     */ import io.micrometer.observation.ObservationRegistry;
/*     */ import java.util.Objects;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.security.access.AccessDeniedException;
/*     */ import org.springframework.security.authorization.method.MethodAuthorizationDeniedHandler;
/*     */ import org.springframework.security.authorization.method.MethodInvocationResult;
/*     */ import org.springframework.security.authorization.method.ThrowingMethodAuthorizationDeniedHandler;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.util.context.ContextView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ObservationReactiveAuthorizationManager<T>
/*     */   implements ReactiveAuthorizationManager<T>, MethodAuthorizationDeniedHandler
/*     */ {
/*     */   private final ObservationRegistry registry;
/*     */   private final ReactiveAuthorizationManager<T> delegate;
/*  46 */   private ObservationConvention<AuthorizationObservationContext<?>> convention = new AuthorizationObservationConvention();
/*     */   
/*  48 */   private MethodAuthorizationDeniedHandler handler = (MethodAuthorizationDeniedHandler)new ThrowingMethodAuthorizationDeniedHandler();
/*     */ 
/*     */   
/*     */   public ObservationReactiveAuthorizationManager(ObservationRegistry registry, ReactiveAuthorizationManager<T> delegate) {
/*  52 */     this.registry = registry;
/*  53 */     this.delegate = delegate;
/*  54 */     if (delegate instanceof MethodAuthorizationDeniedHandler) { MethodAuthorizationDeniedHandler h = (MethodAuthorizationDeniedHandler)delegate;
/*  55 */       this.handler = h; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Mono<AuthorizationDecision> check(Mono<Authentication> authentication, T object) {
/*  65 */     AuthorizationObservationContext<T> context = new AuthorizationObservationContext<>(object);
/*  66 */     Mono<Authentication> wrapped = authentication.map(auth -> {
/*     */           context.setAuthentication(auth);
/*     */           return context.getAuthentication();
/*     */         });
/*  70 */     return Mono.deferContextual(contextView -> {
/*     */           Observation observation = Observation.createNotStarted(this.convention, (), this.registry).parentObservation((Observation)contextView.getOrDefault("micrometer.observation", null)).start();
/*     */           Objects.requireNonNull(observation);
/*     */           return this.delegate.check(wrapped, (T)object).doOnSuccess(()).doOnCancel(observation::stop).doOnError(());
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setObservationConvention(ObservationConvention<AuthorizationObservationContext<?>> convention) {
/*  94 */     Assert.notNull(convention, "The observation convention cannot be null");
/*  95 */     this.convention = convention;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object handleDeniedInvocation(MethodInvocation methodInvocation, AuthorizationResult authorizationResult) {
/* 100 */     return this.handler.handleDeniedInvocation(methodInvocation, authorizationResult);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object handleDeniedInvocationResult(MethodInvocationResult methodInvocationResult, AuthorizationResult authorizationResult) {
/* 106 */     return this.handler.handleDeniedInvocationResult(methodInvocationResult, authorizationResult);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\ObservationReactiveAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */