/*    */ package org.springframework.security.authorization;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface AuthorizationManager<T>
/*    */ {
/*    */   default void verify(Supplier<Authentication> authentication, T object) {
/* 42 */     AuthorizationDecision decision = check(authentication, object);
/* 43 */     if (decision != null && !decision.isGranted()) {
/* 44 */       throw new AuthorizationDeniedException("Access Denied", decision);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   @Deprecated
/*    */   AuthorizationDecision check(Supplier<Authentication> paramSupplier, T paramT);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   default AuthorizationResult authorize(Supplier<Authentication> authentication, T object) {
/* 69 */     return check(authentication, object);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\AuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */