package org.springframework.security.authorization;

import java.io.Serializable;

public interface AuthorizationResult extends Serializable {
  boolean isGranted();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\AuthorizationResult.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */