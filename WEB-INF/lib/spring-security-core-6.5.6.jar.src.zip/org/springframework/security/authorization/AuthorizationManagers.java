/*     */ package org.springframework.security.authorization;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.security.core.Authentication;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthorizationManagers
/*     */ {
/*     */   @SafeVarargs
/*     */   public static <T> AuthorizationManager<T> anyOf(AuthorizationManager<T>... managers) {
/*  44 */     return anyOf(new AuthorizationDecision(false), managers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public static <T> AuthorizationManager<T> anyOf(AuthorizationDecision allAbstainDefaultDecision, AuthorizationManager<T>... managers) {
/*  61 */     return (authentication, object) -> {
/*     */         List<AuthorizationResult> results = new ArrayList<>();
/*     */         for (AuthorizationManager<T> manager : managers) {
/*     */           AuthorizationResult result = manager.authorize(authentication, (T)object);
/*     */           if (result != null) {
/*     */             if (result.isGranted()) {
/*     */               return result;
/*     */             }
/*     */             results.add(result);
/*     */           } 
/*     */         } 
/*     */         return results.isEmpty() ? allAbstainDefaultDecision : new CompositeAuthorizationDecision(false, results);
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public static <T> AuthorizationManager<T> allOf(AuthorizationManager<T>... managers) {
/*  90 */     return allOf(new AuthorizationDecision(true), managers);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public static <T> AuthorizationManager<T> allOf(AuthorizationDecision allAbstainDefaultDecision, AuthorizationManager<T>... managers) {
/* 107 */     return (authentication, object) -> {
/*     */         List<AuthorizationResult> results = new ArrayList<>();
/*     */         for (AuthorizationManager<T> manager : managers) {
/*     */           AuthorizationResult result = manager.authorize(authentication, (T)object);
/*     */           if (result != null) {
/*     */             if (!result.isGranted()) {
/*     */               return result;
/*     */             }
/*     */             results.add(result);
/*     */           } 
/*     */         } 
/*     */         return results.isEmpty() ? allAbstainDefaultDecision : new CompositeAuthorizationDecision(true, results);
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> AuthorizationManager<T> not(AuthorizationManager<T> manager) {
/* 136 */     return (authentication, object) -> {
/*     */         AuthorizationResult result = manager.authorize(authentication, object);
/*     */         return (result == null) ? null : new NotAuthorizationDecision(result);
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class CompositeAuthorizationDecision
/*     */     extends AuthorizationDecision
/*     */   {
/*     */     private final List<AuthorizationResult> results;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private CompositeAuthorizationDecision(boolean granted, List<AuthorizationResult> results) {
/* 154 */       super(granted);
/* 155 */       this.results = results;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 160 */       return "CompositeAuthorizationDecision [results=" + String.valueOf(this.results) + "]";
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static final class NotAuthorizationDecision
/*     */     extends AuthorizationDecision
/*     */   {
/*     */     private final AuthorizationResult result;
/*     */     
/*     */     private NotAuthorizationDecision(AuthorizationResult result) {
/* 171 */       super(!result.isGranted());
/* 172 */       this.result = result;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 177 */       return "NotAuthorizationDecision [result=" + String.valueOf(this.result) + "]";
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static interface AuthorizationManagerCheckAdapter<T>
/*     */     extends AuthorizationManager<T>
/*     */   {
/*     */     default AuthorizationDecision check(Supplier<Authentication> authentication, T object) {
/* 186 */       AuthorizationResult result = authorize(authentication, object);
/* 187 */       if (result == null) {
/* 188 */         return null;
/*     */       }
/* 190 */       if (result instanceof AuthorizationDecision) { AuthorizationDecision decision = (AuthorizationDecision)result;
/* 191 */         return decision; }
/*     */       
/* 193 */       throw new IllegalArgumentException("please call #authorize or ensure that the result is of type AuthorizationDecision");
/*     */     }
/*     */     
/*     */     AuthorizationResult authorize(Supplier<Authentication> param1Supplier, T param1T);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\AuthorizationManagers.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */