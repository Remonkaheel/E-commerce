/*    */ package org.springframework.security.authorization.event;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.core.ResolvableTypeProvider;
/*    */ import org.springframework.security.authorization.AuthorizationDecision;
/*    */ import org.springframework.security.authorization.AuthorizationResult;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthorizationDeniedEvent<T>
/*    */   extends AuthorizationEvent
/*    */   implements ResolvableTypeProvider
/*    */ {
/*    */   @Deprecated
/*    */   public AuthorizationDeniedEvent(Supplier<Authentication> authentication, T object, AuthorizationDecision decision) {
/* 43 */     super(authentication, object, decision);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AuthorizationDeniedEvent(Supplier<Authentication> authentication, T object, AuthorizationResult result) {
/* 50 */     super(authentication, object, result);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public T getObject() {
/* 61 */     return (T)getSource();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ResolvableType getResolvableType() {
/* 71 */     return ResolvableType.forClassWithGenerics(getClass(), new ResolvableType[] { ResolvableType.forInstance(getObject()) });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\event\AuthorizationDeniedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */