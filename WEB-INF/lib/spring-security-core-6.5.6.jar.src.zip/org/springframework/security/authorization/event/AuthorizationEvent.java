/*     */ package org.springframework.security.authorization.event;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.security.authorization.AuthorizationDecision;
/*     */ import org.springframework.security.authorization.AuthorizationResult;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AuthorizationEvent
/*     */   extends ApplicationEvent
/*     */ {
/*     */   private static final long serialVersionUID = -9053927371500241295L;
/*     */   private final Supplier<Authentication> authentication;
/*     */   private final AuthorizationResult result;
/*     */   
/*     */   public AuthorizationEvent(Supplier<Authentication> authentication, Object object, AuthorizationDecision result) {
/*  52 */     super(object);
/*  53 */     Assert.notNull(authentication, "authentication supplier cannot be null");
/*  54 */     this.authentication = authentication;
/*  55 */     this.result = (AuthorizationResult)result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationEvent(Supplier<Authentication> authentication, Object object, AuthorizationResult result) {
/*  65 */     super(object);
/*  66 */     Assert.notNull(authentication, "authentication supplier cannot be null");
/*  67 */     this.authentication = authentication;
/*  68 */     this.result = result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Supplier<Authentication> getAuthentication() {
/*  76 */     return this.authentication;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getObject() {
/*  84 */     return getSource();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public AuthorizationDecision getAuthorizationDecision() {
/*  94 */     if (this.result == null) {
/*  95 */       return null;
/*     */     }
/*  97 */     AuthorizationResult authorizationResult = this.result; if (authorizationResult instanceof AuthorizationDecision) { AuthorizationDecision decision = (AuthorizationDecision)authorizationResult;
/*  98 */       return decision; }
/*     */     
/* 100 */     throw new IllegalArgumentException("Please either call getAuthorizationResult or ensure that the result is of type AuthorizationDecision");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizationResult getAuthorizationResult() {
/* 110 */     return this.result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\event\AuthorizationEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */