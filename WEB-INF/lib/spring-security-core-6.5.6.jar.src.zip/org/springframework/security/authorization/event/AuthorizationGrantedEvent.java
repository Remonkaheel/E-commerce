/*    */ package org.springframework.security.authorization.event;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.core.ResolvableType;
/*    */ import org.springframework.core.ResolvableTypeProvider;
/*    */ import org.springframework.security.authorization.AuthorizationDecision;
/*    */ import org.springframework.security.authorization.AuthorizationResult;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthorizationGrantedEvent<T>
/*    */   extends AuthorizationEvent
/*    */   implements ResolvableTypeProvider
/*    */ {
/*    */   private static final long serialVersionUID = -8690818228055810339L;
/*    */   
/*    */   @Deprecated
/*    */   public AuthorizationGrantedEvent(Supplier<Authentication> authentication, T object, AuthorizationDecision decision) {
/* 48 */     super(authentication, object, decision);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AuthorizationGrantedEvent(Supplier<Authentication> authentication, T object, AuthorizationResult result) {
/* 55 */     super(authentication, object, result);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public T getObject() {
/* 66 */     return (T)getSource();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ResolvableType getResolvableType() {
/* 76 */     return ResolvableType.forClassWithGenerics(getClass(), new ResolvableType[] { ResolvableType.forInstance(getObject()) });
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\event\AuthorizationGrantedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */