/*    */ package org.springframework.security.authorization;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @FunctionalInterface
/*    */ public interface AuthorizationEventPublisher
/*    */ {
/*    */   @Deprecated
/*    */   <T> void publishAuthorizationEvent(Supplier<Authentication> paramSupplier, T paramT, AuthorizationDecision paramAuthorizationDecision);
/*    */   
/*    */   default <T> void publishAuthorizationEvent(Supplier<Authentication> authentication, T object, AuthorizationResult result) {
/* 68 */     if (result == null) {
/* 69 */       publishAuthorizationEvent(authentication, object, (AuthorizationDecision)null);
/*    */       return;
/*    */     } 
/* 72 */     if (result instanceof AuthorizationDecision) { AuthorizationDecision decision = (AuthorizationDecision)result;
/* 73 */       publishAuthorizationEvent(authentication, object, decision);
/*    */       return; }
/*    */     
/* 76 */     throw new UnsupportedOperationException("result must be of type AuthorizationDecision");
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\AuthorizationEventPublisher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */