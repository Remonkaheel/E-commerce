/*    */ package org.springframework.security.authorization;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthorizationDecision
/*    */   implements AuthorizationResult
/*    */ {
/*    */   private static final long serialVersionUID = -3226018324649244416L;
/*    */   private final boolean granted;
/*    */   
/*    */   public AuthorizationDecision(boolean granted) {
/* 33 */     this.granted = granted;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isGranted() {
/* 38 */     return this.granted;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 43 */     return getClass().getSimpleName() + " [granted=" + getClass().getSimpleName() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\AuthorizationDecision.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */