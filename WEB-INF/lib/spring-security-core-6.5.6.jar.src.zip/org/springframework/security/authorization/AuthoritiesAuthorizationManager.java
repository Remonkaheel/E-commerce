/*    */ package org.springframework.security.authorization;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.security.access.hierarchicalroles.NullRoleHierarchy;
/*    */ import org.springframework.security.access.hierarchicalroles.RoleHierarchy;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.authority.AuthorityUtils;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AuthoritiesAuthorizationManager
/*    */   implements AuthorizationManager<Collection<String>>
/*    */ {
/* 38 */   private RoleHierarchy roleHierarchy = (RoleHierarchy)new NullRoleHierarchy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRoleHierarchy(RoleHierarchy roleHierarchy) {
/* 46 */     Assert.notNull(roleHierarchy, "roleHierarchy cannot be null");
/* 47 */     this.roleHierarchy = roleHierarchy;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AuthorityAuthorizationDecision check(Supplier<Authentication> authentication, Collection<String> authorities) {
/* 60 */     boolean granted = isGranted(authentication.get(), authorities);
/* 61 */     return new AuthorityAuthorizationDecision(granted, AuthorityUtils.createAuthorityList(authorities));
/*    */   }
/*    */   
/*    */   private boolean isGranted(Authentication authentication, Collection<String> authorities) {
/* 65 */     return (authentication != null && isAuthorized(authentication, authorities));
/*    */   }
/*    */   
/*    */   private boolean isAuthorized(Authentication authentication, Collection<String> authorities) {
/* 69 */     for (GrantedAuthority grantedAuthority : getGrantedAuthorities(authentication)) {
/* 70 */       if (authorities.contains(grantedAuthority.getAuthority())) {
/* 71 */         return true;
/*    */       }
/*    */     } 
/* 74 */     return false;
/*    */   }
/*    */   
/*    */   private Collection<? extends GrantedAuthority> getGrantedAuthorities(Authentication authentication) {
/* 78 */     return this.roleHierarchy.getReachableGrantedAuthorities(authentication.getAuthorities());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\AuthoritiesAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */