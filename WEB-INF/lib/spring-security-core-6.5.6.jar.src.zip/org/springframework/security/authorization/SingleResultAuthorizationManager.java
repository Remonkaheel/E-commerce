/*    */ package org.springframework.security.authorization;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SingleResultAuthorizationManager<C>
/*    */   implements AuthorizationManager<C>
/*    */ {
/* 33 */   private static final SingleResultAuthorizationManager<?> DENY_MANAGER = new SingleResultAuthorizationManager(new AuthorizationDecision(false));
/*    */ 
/*    */   
/* 36 */   private static final SingleResultAuthorizationManager<?> PERMIT_MANAGER = new SingleResultAuthorizationManager(new AuthorizationDecision(true));
/*    */   
/*    */   private final AuthorizationResult result;
/*    */ 
/*    */   
/*    */   public SingleResultAuthorizationManager(AuthorizationResult result) {
/* 42 */     Assert.notNull(result, "result cannot be null");
/* 43 */     this.result = result;
/*    */   }
/*    */ 
/*    */   
/*    */   public AuthorizationDecision check(Supplier<Authentication> authentication, C object) {
/* 48 */     if (!(this.result instanceof AuthorizationDecision)) {
/* 49 */       throw new IllegalArgumentException("result should be AuthorizationDecision");
/*    */     }
/* 51 */     return (AuthorizationDecision)this.result;
/*    */   }
/*    */ 
/*    */   
/*    */   public AuthorizationResult authorize(Supplier<Authentication> authentication, C object) {
/* 56 */     return this.result;
/*    */   }
/*    */ 
/*    */   
/*    */   public static <C> SingleResultAuthorizationManager<C> denyAll() {
/* 61 */     return (SingleResultAuthorizationManager)DENY_MANAGER;
/*    */   }
/*    */ 
/*    */   
/*    */   public static <C> SingleResultAuthorizationManager<C> permitAll() {
/* 66 */     return (SingleResultAuthorizationManager)PERMIT_MANAGER;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\SingleResultAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */