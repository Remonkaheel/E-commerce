/*     */ package org.springframework.security.authorization;
/*     */ 
/*     */ import io.micrometer.common.KeyValues;
/*     */ import io.micrometer.observation.Observation;
/*     */ import io.micrometer.observation.ObservationConvention;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthorizationObservationConvention
/*     */   implements ObservationConvention<AuthorizationObservationContext<?>>
/*     */ {
/*     */   static final String OBSERVATION_NAME = "spring.security.authorizations";
/*     */   
/*     */   public String getName() {
/*  40 */     return "spring.security.authorizations";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContextualName(AuthorizationObservationContext<?> context) {
/*  45 */     return "authorize " + getObjectType(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyValues getLowCardinalityKeyValues(AuthorizationObservationContext<?> context) {
/*  53 */     return KeyValues.of("spring.security.authentication.type", getAuthenticationType(context))
/*  54 */       .and("spring.security.object", getObjectType(context))
/*  55 */       .and("spring.security.authorization.decision", getAuthorizationDecision(context));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyValues getHighCardinalityKeyValues(AuthorizationObservationContext<?> context) {
/*  63 */     return KeyValues.of("spring.security.authentication.authorities", getAuthorities(context))
/*  64 */       .and("spring.security.authorization.decision.details", getDecisionDetails(context));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supportsContext(Observation.Context context) {
/*  69 */     return context instanceof AuthorizationObservationContext;
/*     */   }
/*     */   
/*     */   private String getAuthenticationType(AuthorizationObservationContext<?> context) {
/*  73 */     if (context.getAuthentication() == null) {
/*  74 */       return "n/a";
/*     */     }
/*  76 */     return context.getAuthentication().getClass().getSimpleName();
/*     */   }
/*     */   
/*     */   private String getObjectType(AuthorizationObservationContext<?> context) {
/*  80 */     if (context.getObject() == null) {
/*  81 */       return "unknown";
/*     */     }
/*  83 */     if (context.getObject() instanceof org.aopalliance.intercept.MethodInvocation) {
/*  84 */       return "method";
/*     */     }
/*  86 */     String className = context.getObject().getClass().getSimpleName();
/*  87 */     if (className.contains("Method")) {
/*  88 */       return "method";
/*     */     }
/*  90 */     if (className.contains("Request")) {
/*  91 */       return "request";
/*     */     }
/*  93 */     if (className.contains("Message")) {
/*  94 */       return "message";
/*     */     }
/*  96 */     if (className.contains("Exchange")) {
/*  97 */       return "exchange";
/*     */     }
/*  99 */     return className;
/*     */   }
/*     */   
/*     */   private String getAuthorizationDecision(AuthorizationObservationContext<?> context) {
/* 103 */     if (context.getAuthorizationResult() == null) {
/* 104 */       return "unknown";
/*     */     }
/* 106 */     return String.valueOf(context.getAuthorizationResult().isGranted());
/*     */   }
/*     */   
/*     */   private String getAuthorities(AuthorizationObservationContext<?> context) {
/* 110 */     if (context.getAuthentication() == null) {
/* 111 */       return "n/a";
/*     */     }
/* 113 */     return String.valueOf(context.getAuthentication().getAuthorities());
/*     */   }
/*     */   
/*     */   private String getDecisionDetails(AuthorizationObservationContext<?> context) {
/* 117 */     if (context.getAuthorizationResult() == null) {
/* 118 */       return "unknown";
/*     */     }
/* 120 */     AuthorizationResult decision = context.getAuthorizationResult();
/* 121 */     return String.valueOf(decision);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\AuthorizationObservationConvention.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */