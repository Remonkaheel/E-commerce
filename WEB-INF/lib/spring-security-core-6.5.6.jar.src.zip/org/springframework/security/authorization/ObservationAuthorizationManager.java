/*     */ package org.springframework.security.authorization;
/*     */ 
/*     */ import io.micrometer.observation.Observation;
/*     */ import io.micrometer.observation.ObservationConvention;
/*     */ import io.micrometer.observation.ObservationRegistry;
/*     */ import java.util.function.Supplier;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.security.authorization.method.MethodAuthorizationDeniedHandler;
/*     */ import org.springframework.security.authorization.method.MethodInvocationResult;
/*     */ import org.springframework.security.authorization.method.ThrowingMethodAuthorizationDeniedHandler;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ObservationAuthorizationManager<T>
/*     */   implements AuthorizationManager<T>, MessageSourceAware, MethodAuthorizationDeniedHandler
/*     */ {
/*     */   private final ObservationRegistry registry;
/*     */   private final AuthorizationManager<T> delegate;
/*  50 */   private ObservationConvention<AuthorizationObservationContext<?>> convention = new AuthorizationObservationConvention();
/*     */   
/*  52 */   private MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */   
/*  54 */   private MethodAuthorizationDeniedHandler handler = (MethodAuthorizationDeniedHandler)new ThrowingMethodAuthorizationDeniedHandler();
/*     */   
/*     */   public ObservationAuthorizationManager(ObservationRegistry registry, AuthorizationManager<T> delegate) {
/*  57 */     this.registry = registry;
/*  58 */     this.delegate = delegate;
/*  59 */     if (delegate instanceof MethodAuthorizationDeniedHandler) { MethodAuthorizationDeniedHandler h = (MethodAuthorizationDeniedHandler)delegate;
/*  60 */       this.handler = h; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public AuthorizationDecision check(Supplier<Authentication> authentication, T object) {
/*  70 */     AuthorizationObservationContext<T> context = new AuthorizationObservationContext<>(object);
/*  71 */     Supplier<Authentication> wrapped = () -> {
/*     */         context.setAuthentication(authentication.get());
/*     */         return context.getAuthentication();
/*     */       };
/*  75 */     Observation observation = Observation.createNotStarted(this.convention, () -> context, this.registry).start(); try {
/*  76 */       Observation.Scope scope = observation.openScope();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  85 */     catch (Throwable ex) {
/*  86 */       observation.error(ex);
/*  87 */       throw ex;
/*     */     } finally {
/*     */       
/*  90 */       observation.stop();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setObservationConvention(ObservationConvention<AuthorizationObservationContext<?>> convention) {
/* 101 */     Assert.notNull(convention, "The observation convention cannot be null");
/* 102 */     this.convention = convention;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 112 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object handleDeniedInvocation(MethodInvocation methodInvocation, AuthorizationResult authorizationResult) {
/* 117 */     return this.handler.handleDeniedInvocation(methodInvocation, authorizationResult);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object handleDeniedInvocationResult(MethodInvocationResult methodInvocationResult, AuthorizationResult authorizationResult) {
/* 123 */     return this.handler.handleDeniedInvocationResult(methodInvocationResult, authorizationResult);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\ObservationAuthorizationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */