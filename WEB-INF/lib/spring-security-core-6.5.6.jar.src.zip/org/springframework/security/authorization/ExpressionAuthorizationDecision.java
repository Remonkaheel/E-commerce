/*    */ package org.springframework.security.authorization;
/*    */ 
/*    */ import org.springframework.expression.Expression;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExpressionAuthorizationDecision
/*    */   extends AuthorizationDecision
/*    */ {
/*    */   private final Expression expression;
/*    */   
/*    */   public ExpressionAuthorizationDecision(boolean granted, Expression expressionAttribute) {
/* 33 */     super(granted);
/* 34 */     this.expression = expressionAttribute;
/*    */   }
/*    */   
/*    */   public Expression getExpression() {
/* 38 */     return this.expression;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 43 */     return getClass().getSimpleName() + " [granted=" + getClass().getSimpleName() + ", expressionAttribute=" + isGranted() + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authorization\ExpressionAuthorizationDecision.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */