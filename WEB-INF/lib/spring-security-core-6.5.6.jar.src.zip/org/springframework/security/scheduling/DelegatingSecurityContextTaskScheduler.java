/*     */ package org.springframework.security.scheduling;
/*     */ 
/*     */ import java.time.Clock;
/*     */ import java.time.Duration;
/*     */ import java.time.Instant;
/*     */ import java.util.Date;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import org.springframework.scheduling.TaskScheduler;
/*     */ import org.springframework.scheduling.Trigger;
/*     */ import org.springframework.security.concurrent.DelegatingSecurityContextRunnable;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingSecurityContextTaskScheduler
/*     */   implements TaskScheduler
/*     */ {
/*     */   private final TaskScheduler delegate;
/*     */   private final SecurityContext securityContext;
/*     */   
/*     */   public DelegatingSecurityContextTaskScheduler(TaskScheduler delegateTaskScheduler, SecurityContext securityContext) {
/*  58 */     Assert.notNull(delegateTaskScheduler, "delegateTaskScheduler cannot be null");
/*  59 */     this.delegate = delegateTaskScheduler;
/*  60 */     this.securityContext = securityContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DelegatingSecurityContextTaskScheduler(TaskScheduler delegate) {
/*  69 */     this(delegate, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> schedule(Runnable task, Trigger trigger) {
/*  74 */     return this.delegate.schedule(wrap(task), trigger);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> schedule(Runnable task, Date startTime) {
/*  79 */     return this.delegate.schedule(wrap(task), startTime);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> scheduleAtFixedRate(Runnable task, Date startTime, long period) {
/*  84 */     return this.delegate.scheduleAtFixedRate(wrap(task), startTime, period);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> scheduleAtFixedRate(Runnable task, long period) {
/*  89 */     return this.delegate.scheduleAtFixedRate(wrap(task), period);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> scheduleWithFixedDelay(Runnable task, Date startTime, long delay) {
/*  94 */     return this.delegate.scheduleWithFixedDelay(wrap(task), startTime, delay);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> scheduleWithFixedDelay(Runnable task, long delay) {
/*  99 */     return this.delegate.scheduleWithFixedDelay(wrap(task), delay);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> schedule(Runnable task, Instant startTime) {
/* 104 */     return this.delegate.schedule(wrap(task), startTime);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> scheduleAtFixedRate(Runnable task, Instant startTime, Duration period) {
/* 109 */     return this.delegate.scheduleAtFixedRate(wrap(task), startTime, period);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> scheduleAtFixedRate(Runnable task, Duration period) {
/* 114 */     return this.delegate.scheduleAtFixedRate(wrap(task), period);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> scheduleWithFixedDelay(Runnable task, Instant startTime, Duration delay) {
/* 119 */     return this.delegate.scheduleWithFixedDelay(wrap(task), startTime, delay);
/*     */   }
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> scheduleWithFixedDelay(Runnable task, Duration delay) {
/* 124 */     return this.delegate.scheduleWithFixedDelay(wrap(task), delay);
/*     */   }
/*     */ 
/*     */   
/*     */   public Clock getClock() {
/* 129 */     return this.delegate.getClock();
/*     */   }
/*     */   
/*     */   private Runnable wrap(Runnable delegate) {
/* 133 */     return DelegatingSecurityContextRunnable.create(delegate, this.securityContext);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\scheduling\DelegatingSecurityContextTaskScheduler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */