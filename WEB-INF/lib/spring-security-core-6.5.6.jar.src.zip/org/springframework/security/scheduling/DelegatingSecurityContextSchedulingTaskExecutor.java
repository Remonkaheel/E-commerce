/*    */ package org.springframework.security.scheduling;
/*    */ 
/*    */ import org.springframework.core.task.AsyncTaskExecutor;
/*    */ import org.springframework.scheduling.SchedulingTaskExecutor;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.security.task.DelegatingSecurityContextAsyncTaskExecutor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingSecurityContextSchedulingTaskExecutor
/*    */   extends DelegatingSecurityContextAsyncTaskExecutor
/*    */   implements SchedulingTaskExecutor
/*    */ {
/*    */   public DelegatingSecurityContextSchedulingTaskExecutor(SchedulingTaskExecutor delegateSchedulingTaskExecutor, SecurityContext securityContext) {
/* 50 */     super((AsyncTaskExecutor)delegateSchedulingTaskExecutor, securityContext);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DelegatingSecurityContextSchedulingTaskExecutor(SchedulingTaskExecutor delegateAsyncTaskExecutor) {
/* 60 */     this(delegateAsyncTaskExecutor, null);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean prefersShortLivedTasks() {
/* 65 */     return getDelegate().prefersShortLivedTasks();
/*    */   }
/*    */   
/*    */   private SchedulingTaskExecutor getDelegate() {
/* 69 */     return (SchedulingTaskExecutor)getDelegateExecutor();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\scheduling\DelegatingSecurityContextSchedulingTaskExecutor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */