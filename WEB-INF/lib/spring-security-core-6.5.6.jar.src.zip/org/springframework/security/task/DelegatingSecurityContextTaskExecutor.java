/*    */ package org.springframework.security.task;
/*    */ 
/*    */ import java.util.concurrent.Executor;
/*    */ import org.springframework.core.task.TaskExecutor;
/*    */ import org.springframework.security.concurrent.DelegatingSecurityContextExecutor;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingSecurityContextTaskExecutor
/*    */   extends DelegatingSecurityContextExecutor
/*    */   implements TaskExecutor
/*    */ {
/*    */   public DelegatingSecurityContextTaskExecutor(TaskExecutor delegateTaskExecutor, SecurityContext securityContext) {
/* 43 */     super((Executor)delegateTaskExecutor, securityContext);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DelegatingSecurityContextTaskExecutor(TaskExecutor delegate) {
/* 52 */     this(delegate, null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\task\DelegatingSecurityContextTaskExecutor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */