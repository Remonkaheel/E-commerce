/*    */ package org.springframework.security.task;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.Future;
/*    */ import org.springframework.core.task.AsyncTaskExecutor;
/*    */ import org.springframework.core.task.TaskExecutor;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingSecurityContextAsyncTaskExecutor
/*    */   extends DelegatingSecurityContextTaskExecutor
/*    */   implements AsyncTaskExecutor
/*    */ {
/*    */   public DelegatingSecurityContextAsyncTaskExecutor(AsyncTaskExecutor delegateAsyncTaskExecutor, SecurityContext securityContext) {
/* 49 */     super((TaskExecutor)delegateAsyncTaskExecutor, securityContext);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DelegatingSecurityContextAsyncTaskExecutor(AsyncTaskExecutor delegateAsyncTaskExecutor) {
/* 59 */     this(delegateAsyncTaskExecutor, (SecurityContext)null);
/*    */   }
/*    */ 
/*    */   
/*    */   public final void execute(Runnable task, long startTimeout) {
/* 64 */     getDelegate().execute(wrap(task), startTimeout);
/*    */   }
/*    */ 
/*    */   
/*    */   public final Future<?> submit(Runnable task) {
/* 69 */     return getDelegate().submit(wrap(task));
/*    */   }
/*    */ 
/*    */   
/*    */   public final <T> Future<T> submit(Callable<T> task) {
/* 74 */     return getDelegate().submit(wrap(task));
/*    */   }
/*    */   
/*    */   private AsyncTaskExecutor getDelegate() {
/* 78 */     return (AsyncTaskExecutor)getDelegateExecutor();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\task\DelegatingSecurityContextAsyncTaskExecutor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */