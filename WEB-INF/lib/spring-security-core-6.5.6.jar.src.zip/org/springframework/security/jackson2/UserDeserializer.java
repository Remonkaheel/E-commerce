/*    */ package org.springframework.security.jackson2;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JacksonException;
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.core.JsonProcessingException;
/*    */ import com.fasterxml.jackson.core.type.TypeReference;
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.JsonNode;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.fasterxml.jackson.databind.node.MissingNode;
/*    */ import java.io.IOException;
/*    */ import java.util.Set;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*    */ import org.springframework.security.core.userdetails.User;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class UserDeserializer
/*    */   extends JsonDeserializer<User>
/*    */ {
/* 45 */   private static final TypeReference<Set<SimpleGrantedAuthority>> SIMPLE_GRANTED_AUTHORITY_SET = new TypeReference<Set<SimpleGrantedAuthority>>()
/*    */     {
/*    */     
/*    */     };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public User deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException, JsonProcessingException {
/* 61 */     ObjectMapper mapper = (ObjectMapper)jp.getCodec();
/* 62 */     JsonNode jsonNode = (JsonNode)mapper.readTree(jp);
/* 63 */     Set<? extends GrantedAuthority> authorities = (Set<? extends GrantedAuthority>)mapper.convertValue(jsonNode.get("authorities"), SIMPLE_GRANTED_AUTHORITY_SET);
/*    */     
/* 65 */     JsonNode passwordNode = readJsonNode(jsonNode, "password");
/* 66 */     String username = readJsonNode(jsonNode, "username").asText();
/* 67 */     String password = passwordNode.asText("");
/* 68 */     boolean enabled = readJsonNode(jsonNode, "enabled").asBoolean();
/* 69 */     boolean accountNonExpired = readJsonNode(jsonNode, "accountNonExpired").asBoolean();
/* 70 */     boolean credentialsNonExpired = readJsonNode(jsonNode, "credentialsNonExpired").asBoolean();
/* 71 */     boolean accountNonLocked = readJsonNode(jsonNode, "accountNonLocked").asBoolean();
/* 72 */     User result = new User(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);
/*    */     
/* 74 */     if (passwordNode.asText(null) == null) {
/* 75 */       result.eraseCredentials();
/*    */     }
/* 77 */     return result;
/*    */   }
/*    */   
/*    */   private JsonNode readJsonNode(JsonNode jsonNode, String field) {
/* 81 */     return jsonNode.has(field) ? jsonNode.get(field) : (JsonNode)MissingNode.getInstance();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\jackson2\UserDeserializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */