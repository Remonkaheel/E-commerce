/*    */ package org.springframework.security.jackson2;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JacksonException;
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.core.ObjectCodec;
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.JsonNode;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import java.io.IOException;
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class UnmodifiableMapDeserializer
/*    */   extends JsonDeserializer<Map<?, ?>>
/*    */ {
/*    */   public Map<?, ?> deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
/* 41 */     ObjectMapper mapper = (ObjectMapper)jp.getCodec();
/* 42 */     JsonNode node = (JsonNode)mapper.readTree(jp);
/*    */     
/* 44 */     Map<String, Object> result = new LinkedHashMap<>();
/* 45 */     if (node != null && node.isObject()) {
/* 46 */       Objects.requireNonNull(node); Iterable<Map.Entry<String, JsonNode>> fields = node::fields;
/* 47 */       for (Map.Entry<String, JsonNode> field : fields) {
/* 48 */         result.put(field.getKey(), mapper.readValue(((JsonNode)field.getValue()).traverse((ObjectCodec)mapper), Object.class));
/*    */       }
/*    */     } 
/* 51 */     return Collections.unmodifiableMap(result);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\jackson2\UnmodifiableMapDeserializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */