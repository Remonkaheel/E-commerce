/*     */ package org.springframework.security.jackson2;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JacksonAnnotation;
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.databind.DatabindContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.Module;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.cfg.MapperConfig;
/*     */ import com.fasterxml.jackson.databind.jsontype.BasicPolymorphicTypeValidator;
/*     */ import com.fasterxml.jackson.databind.jsontype.NamedType;
/*     */ import com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SecurityJackson2Modules
/*     */ {
/*  74 */   private static final Log logger = LogFactory.getLog(SecurityJackson2Modules.class);
/*     */   
/*  76 */   private static final List<String> securityJackson2ModuleClasses = Arrays.asList(new String[] { "org.springframework.security.jackson2.CoreJackson2Module", "org.springframework.security.web.jackson2.WebJackson2Module", "org.springframework.security.web.server.jackson2.WebServerJackson2Module" });
/*     */ 
/*     */   
/*     */   private static final String webServletJackson2ModuleClass = "org.springframework.security.web.jackson2.WebServletJackson2Module";
/*     */ 
/*     */   
/*     */   private static final String oauth2ClientJackson2ModuleClass = "org.springframework.security.oauth2.client.jackson2.OAuth2ClientJackson2Module";
/*     */   
/*     */   private static final String javaTimeJackson2ModuleClass = "com.fasterxml.jackson.datatype.jsr310.JavaTimeModule";
/*     */   
/*     */   private static final String ldapJackson2ModuleClass = "org.springframework.security.ldap.jackson2.LdapJackson2Module";
/*     */   
/*     */   private static final String saml2Jackson2ModuleClass = "org.springframework.security.saml2.jackson2.Saml2Jackson2Module";
/*     */   
/*     */   private static final String casJackson2ModuleClass = "org.springframework.security.cas.jackson2.CasJackson2Module";
/*     */   
/*     */   private static final boolean webServletPresent;
/*     */   
/*     */   private static final boolean oauth2ClientPresent;
/*     */   
/*     */   private static final boolean javaTimeJacksonPresent;
/*     */   
/*     */   private static final boolean ldapJacksonPresent;
/*     */   
/*     */   private static final boolean saml2JacksonPresent;
/*     */   
/*     */   private static final boolean casJacksonPresent;
/*     */ 
/*     */   
/*     */   static {
/* 106 */     ClassLoader classLoader = SecurityJackson2Modules.class.getClassLoader();
/* 107 */     webServletPresent = ClassUtils.isPresent("jakarta.servlet.http.Cookie", classLoader);
/* 108 */     oauth2ClientPresent = ClassUtils.isPresent("org.springframework.security.oauth2.client.OAuth2AuthorizedClient", classLoader);
/*     */     
/* 110 */     javaTimeJacksonPresent = ClassUtils.isPresent("com.fasterxml.jackson.datatype.jsr310.JavaTimeModule", classLoader);
/* 111 */     ldapJacksonPresent = ClassUtils.isPresent("org.springframework.security.ldap.jackson2.LdapJackson2Module", classLoader);
/* 112 */     saml2JacksonPresent = ClassUtils.isPresent("org.springframework.security.saml2.jackson2.Saml2Jackson2Module", classLoader);
/* 113 */     casJacksonPresent = ClassUtils.isPresent("org.springframework.security.cas.jackson2.CasJackson2Module", classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void enableDefaultTyping(ObjectMapper mapper) {
/* 120 */     if (mapper != null) {
/* 121 */       TypeResolverBuilder<?> typeBuilder = mapper.getDeserializationConfig().getDefaultTyper(null);
/* 122 */       if (typeBuilder == null) {
/* 123 */         mapper.setDefaultTyping(createAllowlistedDefaultTyping());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static Module loadAndGetInstance(String className, ClassLoader loader) {
/*     */     try {
/* 131 */       Class<? extends Module> securityModule = ClassUtils.forName(className, loader);
/* 132 */       if (securityModule != null) {
/* 133 */         logger.debug(LogMessage.format("Loaded module %s, now registering", className));
/* 134 */         return securityModule.getConstructor(new Class[0]).newInstance(new Object[0]);
/*     */       }
/*     */     
/* 137 */     } catch (Exception ex) {
/* 138 */       logger.debug(LogMessage.format("Cannot load module %s", className), ex);
/*     */     } 
/* 140 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Module> getModules(ClassLoader loader) {
/* 148 */     List<Module> modules = new ArrayList<>();
/* 149 */     for (String className : securityJackson2ModuleClasses) {
/* 150 */       addToModulesList(loader, modules, className);
/*     */     }
/* 152 */     if (webServletPresent) {
/* 153 */       addToModulesList(loader, modules, "org.springframework.security.web.jackson2.WebServletJackson2Module");
/*     */     }
/* 155 */     if (oauth2ClientPresent) {
/* 156 */       addToModulesList(loader, modules, "org.springframework.security.oauth2.client.jackson2.OAuth2ClientJackson2Module");
/*     */     }
/* 158 */     if (javaTimeJacksonPresent) {
/* 159 */       addToModulesList(loader, modules, "com.fasterxml.jackson.datatype.jsr310.JavaTimeModule");
/*     */     }
/* 161 */     if (ldapJacksonPresent) {
/* 162 */       addToModulesList(loader, modules, "org.springframework.security.ldap.jackson2.LdapJackson2Module");
/*     */     }
/* 164 */     if (saml2JacksonPresent) {
/* 165 */       addToModulesList(loader, modules, "org.springframework.security.saml2.jackson2.Saml2Jackson2Module");
/*     */     }
/* 167 */     if (casJacksonPresent) {
/* 168 */       addToModulesList(loader, modules, "org.springframework.security.cas.jackson2.CasJackson2Module");
/*     */     }
/* 170 */     return modules;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void addToModulesList(ClassLoader loader, List<Module> modules, String className) {
/* 179 */     Module module = loadAndGetInstance(className, loader);
/* 180 */     if (module != null) {
/* 181 */       modules.add(module);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static TypeResolverBuilder<? extends TypeResolverBuilder> createAllowlistedDefaultTyping() {
/* 190 */     AllowlistTypeResolverBuilder allowlistTypeResolverBuilder = new AllowlistTypeResolverBuilder(ObjectMapper.DefaultTyping.NON_FINAL);
/*     */     
/* 192 */     TypeResolverBuilder<? extends TypeResolverBuilder> typeResolverBuilder = allowlistTypeResolverBuilder.init(JsonTypeInfo.Id.CLASS, null);
/* 193 */     typeResolverBuilder = typeResolverBuilder.inclusion(JsonTypeInfo.As.PROPERTY);
/* 194 */     return typeResolverBuilder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class AllowlistTypeResolverBuilder
/*     */     extends ObjectMapper.DefaultTypeResolverBuilder
/*     */   {
/*     */     AllowlistTypeResolverBuilder(ObjectMapper.DefaultTyping defaultTyping) {
/* 208 */       super(defaultTyping, 
/*     */           
/* 210 */           (PolymorphicTypeValidator)BasicPolymorphicTypeValidator.builder().allowIfSubType(Object.class).build());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected TypeIdResolver idResolver(MapperConfig<?> config, JavaType baseType, PolymorphicTypeValidator subtypeValidator, Collection<NamedType> subtypes, boolean forSer, boolean forDeser) {
/* 217 */       TypeIdResolver result = super.idResolver(config, baseType, subtypeValidator, subtypes, forSer, forDeser);
/* 218 */       return new SecurityJackson2Modules.AllowlistTypeIdResolver(result);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static class AllowlistTypeIdResolver
/*     */     implements TypeIdResolver
/*     */   {
/*     */     private static final Set<String> ALLOWLIST_CLASS_NAMES;
/*     */     
/*     */     private final TypeIdResolver delegate;
/*     */ 
/*     */     
/*     */     static {
/* 233 */       Set<String> names = new HashSet<>();
/* 234 */       names.add("java.util.ArrayList");
/* 235 */       names.add("java.util.Collections$EmptyList");
/* 236 */       names.add("java.util.Collections$EmptyMap");
/* 237 */       names.add("java.util.Collections$UnmodifiableRandomAccessList");
/* 238 */       names.add("java.util.Collections$SingletonList");
/* 239 */       names.add("java.util.Date");
/* 240 */       names.add("java.time.Instant");
/* 241 */       names.add("java.net.URL");
/* 242 */       names.add("java.util.TreeMap");
/* 243 */       names.add("java.util.HashMap");
/* 244 */       names.add("java.util.LinkedHashMap");
/* 245 */       names.add("org.springframework.security.core.context.SecurityContextImpl");
/* 246 */       names.add("java.util.Arrays$ArrayList");
/* 247 */       ALLOWLIST_CLASS_NAMES = Collections.unmodifiableSet(names);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     AllowlistTypeIdResolver(TypeIdResolver delegate) {
/* 253 */       this.delegate = delegate;
/*     */     }
/*     */ 
/*     */     
/*     */     public void init(JavaType baseType) {
/* 258 */       this.delegate.init(baseType);
/*     */     }
/*     */ 
/*     */     
/*     */     public String idFromValue(Object value) {
/* 263 */       return this.delegate.idFromValue(value);
/*     */     }
/*     */ 
/*     */     
/*     */     public String idFromValueAndType(Object value, Class<?> suggestedType) {
/* 268 */       return this.delegate.idFromValueAndType(value, suggestedType);
/*     */     }
/*     */ 
/*     */     
/*     */     public String idFromBaseType() {
/* 273 */       return this.delegate.idFromBaseType();
/*     */     }
/*     */ 
/*     */     
/*     */     public JavaType typeFromId(DatabindContext context, String id) throws IOException {
/* 278 */       DeserializationConfig config = (DeserializationConfig)context.getConfig();
/* 279 */       JavaType result = this.delegate.typeFromId(context, id);
/* 280 */       String className = result.getRawClass().getName();
/* 281 */       if (isInAllowlist(className)) {
/* 282 */         return result;
/*     */       }
/* 284 */       boolean isExplicitMixin = (config.findMixInClassFor(result.getRawClass()) != null);
/* 285 */       if (isExplicitMixin) {
/* 286 */         return result;
/*     */       }
/* 288 */       JacksonAnnotation jacksonAnnotation = (JacksonAnnotation)AnnotationUtils.findAnnotation(result.getRawClass(), JacksonAnnotation.class);
/*     */       
/* 290 */       if (jacksonAnnotation != null) {
/* 291 */         return result;
/*     */       }
/* 293 */       throw new IllegalArgumentException("The class with " + id + " and name of " + className + " is not in the allowlist. If you believe this class is safe to deserialize, please provide an explicit mapping using Jackson annotations or by providing a Mixin. If the serialization is only done by a trusted source, you can also enable default typing. See https://github.com/spring-projects/spring-security/issues/4370 for details");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean isInAllowlist(String id) {
/* 301 */       return ALLOWLIST_CLASS_NAMES.contains(id);
/*     */     }
/*     */ 
/*     */     
/*     */     public String getDescForKnownTypeIds() {
/* 306 */       return this.delegate.getDescForKnownTypeIds();
/*     */     }
/*     */ 
/*     */     
/*     */     public JsonTypeInfo.Id getMechanism() {
/* 311 */       return this.delegate.getMechanism();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\jackson2\SecurityJackson2Modules.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */