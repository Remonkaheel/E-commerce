package org.springframework.security.jackson2;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(use = JsonTypeInfo.Id.CLASS, include = JsonTypeInfo.As.PROPERTY)
@JsonIgnoreProperties(ignoreUnknown = true, value = {"cause", "stackTrace", "authenticationRequest"})
class BadCredentialsExceptionMixin {
  @JsonCreator
  BadCredentialsExceptionMixin(@JsonProperty("message") String message) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\jackson2\BadCredentialsExceptionMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */