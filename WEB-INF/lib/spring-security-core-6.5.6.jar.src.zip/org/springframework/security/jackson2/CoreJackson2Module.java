/*    */ package org.springframework.security.jackson2;
/*    */ 
/*    */ import com.fasterxml.jackson.core.Version;
/*    */ import com.fasterxml.jackson.databind.Module;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*    */ import java.util.Collections;
/*    */ import org.springframework.security.authentication.AnonymousAuthenticationToken;
/*    */ import org.springframework.security.authentication.BadCredentialsException;
/*    */ import org.springframework.security.authentication.RememberMeAuthenticationToken;
/*    */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*    */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*    */ import org.springframework.security.core.userdetails.User;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoreJackson2Module
/*    */   extends SimpleModule
/*    */ {
/*    */   public CoreJackson2Module() {
/* 54 */     super(CoreJackson2Module.class.getName(), new Version(1, 0, 0, null, null, null));
/*    */   }
/*    */ 
/*    */   
/*    */   public void setupModule(Module.SetupContext context) {
/* 59 */     SecurityJackson2Modules.enableDefaultTyping((ObjectMapper)context.getOwner());
/* 60 */     context.setMixInAnnotations(AnonymousAuthenticationToken.class, AnonymousAuthenticationTokenMixin.class);
/* 61 */     context.setMixInAnnotations(RememberMeAuthenticationToken.class, RememberMeAuthenticationTokenMixin.class);
/* 62 */     context.setMixInAnnotations(SimpleGrantedAuthority.class, SimpleGrantedAuthorityMixin.class);
/* 63 */     context.setMixInAnnotations(Collections.unmodifiableSet(Collections.emptySet()).getClass(), UnmodifiableSetMixin.class);
/*    */     
/* 65 */     context.setMixInAnnotations(Collections.unmodifiableList(Collections.emptyList()).getClass(), UnmodifiableListMixin.class);
/*    */     
/* 67 */     context.setMixInAnnotations(Collections.unmodifiableMap(Collections.emptyMap()).getClass(), UnmodifiableMapMixin.class);
/*    */     
/* 69 */     context.setMixInAnnotations(User.class, UserMixin.class);
/* 70 */     context.setMixInAnnotations(UsernamePasswordAuthenticationToken.class, UsernamePasswordAuthenticationTokenMixin.class);
/*    */     
/* 72 */     context.setMixInAnnotations(BadCredentialsException.class, BadCredentialsExceptionMixin.class);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\jackson2\CoreJackson2Module.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */