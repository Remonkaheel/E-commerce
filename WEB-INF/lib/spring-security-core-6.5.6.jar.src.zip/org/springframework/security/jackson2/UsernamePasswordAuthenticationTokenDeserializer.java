/*     */ package org.springframework.security.jackson2;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JacksonException;
/*     */ import com.fasterxml.jackson.core.JsonParseException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.core.type.TypeReference;
/*     */ import com.fasterxml.jackson.databind.DeserializationContext;
/*     */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import com.fasterxml.jackson.databind.node.MissingNode;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UsernamePasswordAuthenticationTokenDeserializer
/*     */   extends JsonDeserializer<UsernamePasswordAuthenticationToken>
/*     */ {
/*  53 */   private static final TypeReference<List<GrantedAuthority>> GRANTED_AUTHORITY_LIST = new TypeReference<List<GrantedAuthority>>() {
/*     */     
/*     */     };
/*  56 */   private static final TypeReference<Object> OBJECT = new TypeReference<Object>()
/*     */     {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UsernamePasswordAuthenticationToken deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException, JsonProcessingException {
/*  71 */     ObjectMapper mapper = (ObjectMapper)jp.getCodec();
/*  72 */     JsonNode jsonNode = (JsonNode)mapper.readTree(jp);
/*  73 */     Boolean authenticated = Boolean.valueOf(readJsonNode(jsonNode, "authenticated").asBoolean());
/*  74 */     JsonNode principalNode = readJsonNode(jsonNode, "principal");
/*  75 */     Object principal = getPrincipal(mapper, principalNode);
/*  76 */     JsonNode credentialsNode = readJsonNode(jsonNode, "credentials");
/*  77 */     Object credentials = getCredentials(credentialsNode);
/*  78 */     List<GrantedAuthority> authorities = (List<GrantedAuthority>)mapper.readValue(readJsonNode(jsonNode, "authorities").traverse((ObjectCodec)mapper), GRANTED_AUTHORITY_LIST);
/*     */ 
/*     */ 
/*     */     
/*  82 */     UsernamePasswordAuthenticationToken token = !authenticated.booleanValue() ? UsernamePasswordAuthenticationToken.unauthenticated(principal, credentials) : UsernamePasswordAuthenticationToken.authenticated(principal, credentials, authorities);
/*  83 */     JsonNode detailsNode = readJsonNode(jsonNode, "details");
/*  84 */     if (detailsNode.isNull() || detailsNode.isMissingNode()) {
/*  85 */       token.setDetails(null);
/*     */     } else {
/*     */       
/*  88 */       Object details = mapper.readValue(detailsNode.toString(), OBJECT);
/*  89 */       token.setDetails(details);
/*     */     } 
/*  91 */     return token;
/*     */   }
/*     */   
/*     */   private Object getCredentials(JsonNode credentialsNode) {
/*  95 */     if (credentialsNode.isNull() || credentialsNode.isMissingNode()) {
/*  96 */       return null;
/*     */     }
/*  98 */     return credentialsNode.asText();
/*     */   }
/*     */ 
/*     */   
/*     */   private Object getPrincipal(ObjectMapper mapper, JsonNode principalNode) throws IOException, JsonParseException, JsonMappingException {
/* 103 */     if (principalNode.isObject()) {
/* 104 */       return mapper.readValue(principalNode.traverse((ObjectCodec)mapper), Object.class);
/*     */     }
/* 106 */     return principalNode.asText();
/*     */   }
/*     */   
/*     */   private JsonNode readJsonNode(JsonNode jsonNode, String field) {
/* 110 */     return jsonNode.has(field) ? jsonNode.get(field) : (JsonNode)MissingNode.getInstance();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\jackson2\UsernamePasswordAuthenticationTokenDeserializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */