/*    */ package org.springframework.security.jackson2;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonParser;
/*    */ import com.fasterxml.jackson.core.ObjectCodec;
/*    */ import com.fasterxml.jackson.databind.DeserializationContext;
/*    */ import com.fasterxml.jackson.databind.JsonDeserializer;
/*    */ import com.fasterxml.jackson.databind.JsonNode;
/*    */ import com.fasterxml.jackson.databind.ObjectMapper;
/*    */ import com.fasterxml.jackson.databind.node.ArrayNode;
/*    */ import java.io.IOException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractUnmodifiableCollectionDeserializer<T>
/*    */   extends JsonDeserializer<T>
/*    */ {
/*    */   public T deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
/* 46 */     ObjectMapper mapper = (ObjectMapper)jp.getCodec();
/* 47 */     JsonNode node = (JsonNode)mapper.readTree(jp);
/* 48 */     Collection<Object> values = new ArrayList();
/* 49 */     if (node instanceof ArrayNode) { ArrayNode arrayNode = (ArrayNode)node;
/* 50 */       for (JsonNode elementNode : arrayNode) {
/* 51 */         values.add(mapper.readValue(elementNode.traverse((ObjectCodec)mapper), Object.class));
/*    */       } }
/*    */     
/* 54 */     else if (node != null)
/* 55 */     { values.add(mapper.readValue(node.traverse((ObjectCodec)mapper), Object.class)); }
/*    */     
/* 57 */     return createUnmodifiableCollection(values);
/*    */   }
/*    */   
/*    */   abstract T createUnmodifiableCollection(Collection<Object> paramCollection) throws IOException;
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\jackson2\AbstractUnmodifiableCollectionDeserializer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */