/*     */ package org.springframework.security.jackson2;
/*     */ 
/*     */ import com.fasterxml.jackson.annotation.JacksonAnnotation;
/*     */ import com.fasterxml.jackson.annotation.JsonTypeInfo;
/*     */ import com.fasterxml.jackson.databind.DatabindContext;
/*     */ import com.fasterxml.jackson.databind.DeserializationConfig;
/*     */ import com.fasterxml.jackson.databind.JavaType;
/*     */ import com.fasterxml.jackson.databind.jsontype.TypeIdResolver;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AllowlistTypeIdResolver
/*     */   implements TypeIdResolver
/*     */ {
/*     */   private static final Set<String> ALLOWLIST_CLASS_NAMES;
/*     */   private final TypeIdResolver delegate;
/*     */   
/*     */   static {
/* 233 */     Set<String> names = new HashSet<>();
/* 234 */     names.add("java.util.ArrayList");
/* 235 */     names.add("java.util.Collections$EmptyList");
/* 236 */     names.add("java.util.Collections$EmptyMap");
/* 237 */     names.add("java.util.Collections$UnmodifiableRandomAccessList");
/* 238 */     names.add("java.util.Collections$SingletonList");
/* 239 */     names.add("java.util.Date");
/* 240 */     names.add("java.time.Instant");
/* 241 */     names.add("java.net.URL");
/* 242 */     names.add("java.util.TreeMap");
/* 243 */     names.add("java.util.HashMap");
/* 244 */     names.add("java.util.LinkedHashMap");
/* 245 */     names.add("org.springframework.security.core.context.SecurityContextImpl");
/* 246 */     names.add("java.util.Arrays$ArrayList");
/* 247 */     ALLOWLIST_CLASS_NAMES = Collections.unmodifiableSet(names);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   AllowlistTypeIdResolver(TypeIdResolver delegate) {
/* 253 */     this.delegate = delegate;
/*     */   }
/*     */ 
/*     */   
/*     */   public void init(JavaType baseType) {
/* 258 */     this.delegate.init(baseType);
/*     */   }
/*     */ 
/*     */   
/*     */   public String idFromValue(Object value) {
/* 263 */     return this.delegate.idFromValue(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String idFromValueAndType(Object value, Class<?> suggestedType) {
/* 268 */     return this.delegate.idFromValueAndType(value, suggestedType);
/*     */   }
/*     */ 
/*     */   
/*     */   public String idFromBaseType() {
/* 273 */     return this.delegate.idFromBaseType();
/*     */   }
/*     */ 
/*     */   
/*     */   public JavaType typeFromId(DatabindContext context, String id) throws IOException {
/* 278 */     DeserializationConfig config = (DeserializationConfig)context.getConfig();
/* 279 */     JavaType result = this.delegate.typeFromId(context, id);
/* 280 */     String className = result.getRawClass().getName();
/* 281 */     if (isInAllowlist(className)) {
/* 282 */       return result;
/*     */     }
/* 284 */     boolean isExplicitMixin = (config.findMixInClassFor(result.getRawClass()) != null);
/* 285 */     if (isExplicitMixin) {
/* 286 */       return result;
/*     */     }
/* 288 */     JacksonAnnotation jacksonAnnotation = (JacksonAnnotation)AnnotationUtils.findAnnotation(result.getRawClass(), JacksonAnnotation.class);
/*     */     
/* 290 */     if (jacksonAnnotation != null) {
/* 291 */       return result;
/*     */     }
/* 293 */     throw new IllegalArgumentException("The class with " + id + " and name of " + className + " is not in the allowlist. If you believe this class is safe to deserialize, please provide an explicit mapping using Jackson annotations or by providing a Mixin. If the serialization is only done by a trusted source, you can also enable default typing. See https://github.com/spring-projects/spring-security/issues/4370 for details");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isInAllowlist(String id) {
/* 301 */     return ALLOWLIST_CLASS_NAMES.contains(id);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDescForKnownTypeIds() {
/* 306 */     return this.delegate.getDescForKnownTypeIds();
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonTypeInfo.Id getMechanism() {
/* 311 */     return this.delegate.getMechanism();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\jackson2\SecurityJackson2Modules$AllowlistTypeIdResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */