package org.springframework.security.jackson2;

import com.fasterxml.jackson.core.type.TypeReference;

class null extends TypeReference<Object> {}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\jackson2\UsernamePasswordAuthenticationTokenDeserializer$2.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */