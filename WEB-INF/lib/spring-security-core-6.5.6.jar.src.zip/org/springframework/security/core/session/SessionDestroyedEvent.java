/*    */ package org.springframework.security.core.session;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SessionDestroyedEvent
/*    */   extends AbstractSessionEvent
/*    */ {
/*    */   public SessionDestroyedEvent(Object source) {
/* 33 */     super(source);
/*    */   }
/*    */   
/*    */   public abstract List<SecurityContext> getSecurityContexts();
/*    */   
/*    */   public abstract String getId();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\session\SessionDestroyedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */