/*    */ package org.springframework.security.core.session;
/*    */ 
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AbstractSessionEvent
/*    */   extends ApplicationEvent
/*    */ {
/*    */   private static final long serialVersionUID = -6878881229287231479L;
/*    */   
/*    */   public AbstractSessionEvent(Object source) {
/* 35 */     super(source);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\session\AbstractSessionEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */