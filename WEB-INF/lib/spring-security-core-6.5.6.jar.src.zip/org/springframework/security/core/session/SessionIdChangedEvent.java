/*    */ package org.springframework.security.core.session;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SessionIdChangedEvent
/*    */   extends AbstractSessionEvent
/*    */ {
/*    */   public SessionIdChangedEvent(Object source) {
/* 28 */     super(source);
/*    */   }
/*    */   
/*    */   public abstract String getOldSessionId();
/*    */   
/*    */   public abstract String getNewSessionId();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\session\SessionIdChangedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */