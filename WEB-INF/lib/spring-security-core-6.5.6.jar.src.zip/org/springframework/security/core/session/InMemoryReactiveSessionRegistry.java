/*    */ package org.springframework.security.core.session;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import java.util.Objects;
/*    */ import java.util.Set;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import java.util.concurrent.CopyOnWriteArraySet;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InMemoryReactiveSessionRegistry
/*    */   implements ReactiveSessionRegistry
/*    */ {
/*    */   private final ConcurrentMap<Object, Set<String>> sessionIdsByPrincipal;
/*    */   private final Map<String, ReactiveSessionInformation> sessionById;
/*    */   
/*    */   public InMemoryReactiveSessionRegistry() {
/* 42 */     this.sessionIdsByPrincipal = new ConcurrentHashMap<>();
/* 43 */     this.sessionById = new ConcurrentHashMap<>();
/*    */   }
/*    */ 
/*    */   
/*    */   public InMemoryReactiveSessionRegistry(ConcurrentMap<Object, Set<String>> sessionIdsByPrincipal, Map<String, ReactiveSessionInformation> sessionById) {
/* 48 */     this.sessionIdsByPrincipal = sessionIdsByPrincipal;
/* 49 */     this.sessionById = sessionById;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Flux<ReactiveSessionInformation> getAllSessions(Object principal) {
/* 55 */     Objects.requireNonNull(this.sessionById); return Flux.fromIterable(this.sessionIdsByPrincipal.getOrDefault(principal, Collections.emptySet())).map(this.sessionById::get);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Void> saveSessionInformation(ReactiveSessionInformation information) {
/* 60 */     this.sessionById.put(information.getSessionId(), information);
/* 61 */     ((Set<String>)this.sessionIdsByPrincipal.computeIfAbsent(information.getPrincipal(), key -> new CopyOnWriteArraySet()))
/* 62 */       .add(information.getSessionId());
/* 63 */     return Mono.empty();
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<ReactiveSessionInformation> getSessionInformation(String sessionId) {
/* 68 */     return Mono.justOrEmpty(this.sessionById.get(sessionId));
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<ReactiveSessionInformation> removeSessionInformation(String sessionId) {
/* 73 */     return getSessionInformation(sessionId).doOnNext(sessionInformation -> {
/*    */           this.sessionById.remove(sessionId);
/*    */           Set<String> sessionsUsedByPrincipal = this.sessionIdsByPrincipal.get(sessionInformation.getPrincipal());
/*    */           if (sessionsUsedByPrincipal != null) {
/*    */             sessionsUsedByPrincipal.remove(sessionId);
/*    */             if (sessionsUsedByPrincipal.isEmpty()) {
/*    */               this.sessionIdsByPrincipal.remove(sessionInformation.getPrincipal());
/*    */             }
/*    */           } 
/*    */         });
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<ReactiveSessionInformation> updateLastAccessTime(String sessionId) {
/* 87 */     ReactiveSessionInformation session = this.sessionById.get(sessionId);
/* 88 */     if (session != null) {
/* 89 */       return session.refreshLastRequest().thenReturn(session);
/*    */     }
/* 91 */     return Mono.empty();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\session\InMemoryReactiveSessionRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */