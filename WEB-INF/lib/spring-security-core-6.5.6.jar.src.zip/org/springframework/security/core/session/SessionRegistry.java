package org.springframework.security.core.session;

import java.util.List;

public interface SessionRegistry {
  List<Object> getAllPrincipals();
  
  List<SessionInformation> getAllSessions(Object paramObject, boolean paramBoolean);
  
  SessionInformation getSessionInformation(String paramString);
  
  void refreshLastRequest(String paramString);
  
  void registerNewSession(String paramString, Object paramObject);
  
  void removeSessionInformation(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\session\SessionRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */