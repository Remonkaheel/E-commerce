/*    */ package org.springframework.security.core.session;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class SessionCreationEvent
/*    */   extends AbstractSessionEvent
/*    */ {
/*    */   public SessionCreationEvent(Object source) {
/* 29 */     super(source);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\session\SessionCreationEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */