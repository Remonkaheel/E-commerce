/*    */ package org.springframework.security.core.session;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.time.Instant;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReactiveSessionInformation
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 620L;
/*    */   private Instant lastAccessTime;
/*    */   private final Object principal;
/*    */   private final String sessionId;
/*    */   private boolean expired = false;
/*    */   
/*    */   public ReactiveSessionInformation(Object principal, String sessionId, Instant lastAccessTime) {
/* 42 */     Assert.notNull(principal, "principal cannot be null");
/* 43 */     Assert.hasText(sessionId, "sessionId cannot be null");
/* 44 */     Assert.notNull(lastAccessTime, "lastAccessTime cannot be null");
/* 45 */     this.principal = principal;
/* 46 */     this.sessionId = sessionId;
/* 47 */     this.lastAccessTime = lastAccessTime;
/*    */   }
/*    */   
/*    */   public ReactiveSessionInformation withSessionId(String sessionId) {
/* 51 */     return new ReactiveSessionInformation(this.principal, sessionId, this.lastAccessTime);
/*    */   }
/*    */   
/*    */   public Mono<Void> invalidate() {
/* 55 */     return Mono.fromRunnable(() -> this.expired = true);
/*    */   }
/*    */   
/*    */   public Mono<Void> refreshLastRequest() {
/* 59 */     this.lastAccessTime = Instant.now();
/* 60 */     return Mono.empty();
/*    */   }
/*    */   
/*    */   public Instant getLastAccessTime() {
/* 64 */     return this.lastAccessTime;
/*    */   }
/*    */   
/*    */   public Object getPrincipal() {
/* 68 */     return this.principal;
/*    */   }
/*    */   
/*    */   public String getSessionId() {
/* 72 */     return this.sessionId;
/*    */   }
/*    */   
/*    */   public boolean isExpired() {
/* 76 */     return this.expired;
/*    */   }
/*    */   
/*    */   public void setLastAccessTime(Instant lastAccessTime) {
/* 80 */     this.lastAccessTime = lastAccessTime;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\session\ReactiveSessionInformation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */