/*    */ package org.springframework.security.core.session;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.Date;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SessionInformation
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 620L;
/*    */   private Date lastRequest;
/*    */   private final Object principal;
/*    */   private final String sessionId;
/*    */   private boolean expired = false;
/*    */   
/*    */   public SessionInformation(Object principal, String sessionId, Date lastRequest) {
/* 53 */     Assert.notNull(principal, "Principal required");
/* 54 */     Assert.hasText(sessionId, "SessionId required");
/* 55 */     Assert.notNull(lastRequest, "LastRequest required");
/* 56 */     this.principal = principal;
/* 57 */     this.sessionId = sessionId;
/* 58 */     this.lastRequest = lastRequest;
/*    */   }
/*    */   
/*    */   public void expireNow() {
/* 62 */     this.expired = true;
/*    */   }
/*    */   
/*    */   public Date getLastRequest() {
/* 66 */     return this.lastRequest;
/*    */   }
/*    */   
/*    */   public Object getPrincipal() {
/* 70 */     return this.principal;
/*    */   }
/*    */   
/*    */   public String getSessionId() {
/* 74 */     return this.sessionId;
/*    */   }
/*    */   
/*    */   public boolean isExpired() {
/* 78 */     return this.expired;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void refreshLastRequest() {
/* 85 */     this.lastRequest = new Date();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\session\SessionInformation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */