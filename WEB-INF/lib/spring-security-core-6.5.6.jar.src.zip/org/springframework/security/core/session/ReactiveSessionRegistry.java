package org.springframework.security.core.session;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ReactiveSessionRegistry {
  Flux<ReactiveSessionInformation> getAllSessions(Object paramObject);
  
  Mono<Void> saveSessionInformation(ReactiveSessionInformation paramReactiveSessionInformation);
  
  Mono<ReactiveSessionInformation> getSessionInformation(String paramString);
  
  Mono<ReactiveSessionInformation> removeSessionInformation(String paramString);
  
  Mono<ReactiveSessionInformation> updateLastAccessTime(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\session\ReactiveSessionRegistry.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */