/*     */ package org.springframework.security.core.session;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ import java.util.concurrent.CopyOnWriteArraySet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SessionRegistryImpl
/*     */   implements SessionRegistry, ApplicationListener<AbstractSessionEvent>
/*     */ {
/*  52 */   protected final Log logger = LogFactory.getLog(SessionRegistryImpl.class);
/*     */ 
/*     */   
/*     */   private final ConcurrentMap<Object, Set<String>> principals;
/*     */   
/*     */   private final Map<String, SessionInformation> sessionIds;
/*     */ 
/*     */   
/*     */   public SessionRegistryImpl() {
/*  61 */     this.principals = new ConcurrentHashMap<>();
/*  62 */     this.sessionIds = new ConcurrentHashMap<>();
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionRegistryImpl(ConcurrentMap<Object, Set<String>> principals, Map<String, SessionInformation> sessionIds) {
/*  67 */     this.principals = principals;
/*  68 */     this.sessionIds = sessionIds;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Object> getAllPrincipals() {
/*  73 */     return new ArrayList(this.principals.keySet());
/*     */   }
/*     */ 
/*     */   
/*     */   public List<SessionInformation> getAllSessions(Object principal, boolean includeExpiredSessions) {
/*  78 */     Set<String> sessionsUsedByPrincipal = this.principals.get(principal);
/*  79 */     if (sessionsUsedByPrincipal == null) {
/*  80 */       return Collections.emptyList();
/*     */     }
/*  82 */     List<SessionInformation> list = new ArrayList<>(sessionsUsedByPrincipal.size());
/*  83 */     for (String sessionId : sessionsUsedByPrincipal) {
/*  84 */       SessionInformation sessionInformation = getSessionInformation(sessionId);
/*  85 */       if (sessionInformation == null) {
/*     */         continue;
/*     */       }
/*  88 */       if (includeExpiredSessions || !sessionInformation.isExpired()) {
/*  89 */         list.add(sessionInformation);
/*     */       }
/*     */     } 
/*  92 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   public SessionInformation getSessionInformation(String sessionId) {
/*  97 */     Assert.hasText(sessionId, "SessionId required as per interface contract");
/*  98 */     return this.sessionIds.get(sessionId);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(AbstractSessionEvent event) {
/* 103 */     if (event instanceof SessionDestroyedEvent) { SessionDestroyedEvent sessionDestroyedEvent = (SessionDestroyedEvent)event;
/* 104 */       String sessionId = sessionDestroyedEvent.getId();
/* 105 */       removeSessionInformation(sessionId); }
/*     */     
/* 107 */     else if (event instanceof SessionIdChangedEvent) { SessionIdChangedEvent sessionIdChangedEvent = (SessionIdChangedEvent)event;
/* 108 */       String oldSessionId = sessionIdChangedEvent.getOldSessionId();
/* 109 */       if (this.sessionIds.containsKey(oldSessionId)) {
/* 110 */         Object principal = ((SessionInformation)this.sessionIds.get(oldSessionId)).getPrincipal();
/* 111 */         removeSessionInformation(oldSessionId);
/* 112 */         registerNewSession(sessionIdChangedEvent.getNewSessionId(), principal);
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void refreshLastRequest(String sessionId) {
/* 119 */     Assert.hasText(sessionId, "SessionId required as per interface contract");
/* 120 */     SessionInformation info = getSessionInformation(sessionId);
/* 121 */     if (info != null) {
/* 122 */       info.refreshLastRequest();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerNewSession(String sessionId, Object principal) {
/* 128 */     Assert.hasText(sessionId, "SessionId required as per interface contract");
/* 129 */     Assert.notNull(principal, "Principal required as per interface contract");
/* 130 */     if (getSessionInformation(sessionId) != null) {
/* 131 */       removeSessionInformation(sessionId);
/*     */     }
/* 133 */     if (this.logger.isDebugEnabled()) {
/* 134 */       this.logger.debug(LogMessage.format("Registering session %s, for principal %s", sessionId, principal));
/*     */     }
/* 136 */     this.sessionIds.put(sessionId, new SessionInformation(principal, sessionId, new Date()));
/* 137 */     this.principals.compute(principal, (key, sessionsUsedByPrincipal) -> {
/*     */           if (sessionsUsedByPrincipal == null) {
/*     */             sessionsUsedByPrincipal = new CopyOnWriteArraySet();
/*     */           }
/*     */           sessionsUsedByPrincipal.add(sessionId);
/*     */           this.logger.trace(LogMessage.format("Sessions used by '%s' : %s", principal, sessionsUsedByPrincipal));
/*     */           return sessionsUsedByPrincipal;
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeSessionInformation(String sessionId) {
/* 149 */     Assert.hasText(sessionId, "SessionId required as per interface contract");
/* 150 */     SessionInformation info = getSessionInformation(sessionId);
/* 151 */     if (info == null) {
/*     */       return;
/*     */     }
/* 154 */     if (this.logger.isTraceEnabled()) {
/* 155 */       this.logger.debug("Removing session " + sessionId + " from set of registered sessions");
/*     */     }
/* 157 */     this.sessionIds.remove(sessionId);
/* 158 */     this.principals.computeIfPresent(info.getPrincipal(), (key, sessionsUsedByPrincipal) -> {
/*     */           this.logger.debug(LogMessage.format("Removing session %s from principal's set of registered sessions", sessionId));
/*     */           sessionsUsedByPrincipal.remove(sessionId);
/*     */           if (sessionsUsedByPrincipal.isEmpty()) {
/*     */             this.logger.debug(LogMessage.format("Removing principal %s from registry", info.getPrincipal()));
/*     */             sessionsUsedByPrincipal = null;
/*     */           } 
/*     */           this.logger.trace(LogMessage.format("Sessions used by '%s' : %s", info.getPrincipal(), sessionsUsedByPrincipal));
/*     */           return sessionsUsedByPrincipal;
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\session\SessionRegistryImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */