package org.springframework.security.core.userdetails;

public interface AuthenticationUserDetailsService<T extends org.springframework.security.core.Authentication> {
  UserDetails loadUserDetails(T paramT) throws UsernameNotFoundException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\cor\\userdetails\AuthenticationUserDetailsService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */