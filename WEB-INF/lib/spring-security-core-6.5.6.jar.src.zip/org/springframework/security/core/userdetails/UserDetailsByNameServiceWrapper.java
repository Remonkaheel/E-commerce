/*    */ package org.springframework.security.core.userdetails;
/*    */ 
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserDetailsByNameServiceWrapper<T extends Authentication>
/*    */   implements AuthenticationUserDetailsService<T>, InitializingBean
/*    */ {
/* 35 */   private UserDetailsService userDetailsService = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public UserDetailsByNameServiceWrapper() {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public UserDetailsByNameServiceWrapper(UserDetailsService userDetailsService) {
/* 52 */     Assert.notNull(userDetailsService, "userDetailsService cannot be null.");
/* 53 */     this.userDetailsService = userDetailsService;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() {
/* 63 */     Assert.notNull(this.userDetailsService, "UserDetailsService must be set");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public UserDetails loadUserDetails(T authentication) throws UsernameNotFoundException {
/* 71 */     return this.userDetailsService.loadUserByUsername(authentication.getName());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setUserDetailsService(UserDetailsService aUserDetailsService) {
/* 79 */     this.userDetailsService = aUserDetailsService;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\cor\\userdetails\UserDetailsByNameServiceWrapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */