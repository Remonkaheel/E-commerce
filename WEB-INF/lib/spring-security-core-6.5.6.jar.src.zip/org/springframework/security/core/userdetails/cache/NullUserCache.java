/*    */ package org.springframework.security.core.userdetails.cache;
/*    */ 
/*    */ import org.springframework.security.core.userdetails.UserCache;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullUserCache
/*    */   implements UserCache
/*    */ {
/*    */   public UserDetails getUserFromCache(String username) {
/* 31 */     return null;
/*    */   }
/*    */   
/*    */   public void putUserInCache(UserDetails user) {}
/*    */   
/*    */   public void removeUserFromCache(String username) {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\cor\\userdetails\cache\NullUserCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */