package org.springframework.security.core.userdetails;

public interface UserDetailsPasswordService {
  UserDetails updatePassword(UserDetails paramUserDetails, String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\cor\\userdetails\UserDetailsPasswordService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */