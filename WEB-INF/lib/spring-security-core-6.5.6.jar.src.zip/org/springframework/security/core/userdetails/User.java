/*     */ package org.springframework.security.core.userdetails;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import java.util.function.Function;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.security.core.CredentialsContainer;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*     */ import org.springframework.security.crypto.factory.PasswordEncoderFactories;
/*     */ import org.springframework.security.crypto.password.PasswordEncoder;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class User
/*     */   implements UserDetails, CredentialsContainer
/*     */ {
/*     */   private static final long serialVersionUID = 620L;
/*  67 */   private static final Log logger = LogFactory.getLog(User.class);
/*     */ 
/*     */   
/*     */   private String password;
/*     */ 
/*     */   
/*     */   private final String username;
/*     */   
/*     */   private final Set<GrantedAuthority> authorities;
/*     */   
/*     */   private final boolean accountNonExpired;
/*     */   
/*     */   private final boolean accountNonLocked;
/*     */   
/*     */   private final boolean credentialsNonExpired;
/*     */   
/*     */   private final boolean enabled;
/*     */ 
/*     */   
/*     */   public User(String username, String password, Collection<? extends GrantedAuthority> authorities) {
/*  87 */     this(username, password, true, true, true, true, authorities);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public User(String username, String password, boolean enabled, boolean accountNonExpired, boolean credentialsNonExpired, boolean accountNonLocked, Collection<? extends GrantedAuthority> authorities) {
/* 110 */     Assert.isTrue((username != null && !"".equals(username) && password != null), "Cannot pass null or empty values to constructor");
/*     */     
/* 112 */     this.username = username;
/* 113 */     this.password = password;
/* 114 */     this.enabled = enabled;
/* 115 */     this.accountNonExpired = accountNonExpired;
/* 116 */     this.credentialsNonExpired = credentialsNonExpired;
/* 117 */     this.accountNonLocked = accountNonLocked;
/* 118 */     this.authorities = Collections.unmodifiableSet(sortAuthorities(authorities));
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<GrantedAuthority> getAuthorities() {
/* 123 */     return this.authorities;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPassword() {
/* 128 */     return this.password;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUsername() {
/* 133 */     return this.username;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/* 138 */     return this.enabled;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAccountNonExpired() {
/* 143 */     return this.accountNonExpired;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAccountNonLocked() {
/* 148 */     return this.accountNonLocked;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCredentialsNonExpired() {
/* 153 */     return this.credentialsNonExpired;
/*     */   }
/*     */ 
/*     */   
/*     */   public void eraseCredentials() {
/* 158 */     this.password = null;
/*     */   }
/*     */   
/*     */   private static SortedSet<GrantedAuthority> sortAuthorities(Collection<? extends GrantedAuthority> authorities) {
/* 162 */     Assert.notNull(authorities, "Cannot pass a null GrantedAuthority collection");
/*     */ 
/*     */     
/* 165 */     SortedSet<GrantedAuthority> sortedAuthorities = new TreeSet<>(new AuthorityComparator());
/* 166 */     for (GrantedAuthority grantedAuthority : authorities) {
/* 167 */       Assert.notNull(grantedAuthority, "GrantedAuthority list cannot contain any null elements");
/* 168 */       sortedAuthorities.add(grantedAuthority);
/*     */     } 
/* 170 */     return sortedAuthorities;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 182 */     if (obj instanceof User) { User user = (User)obj;
/* 183 */       return this.username.equals(user.getUsername()); }
/*     */     
/* 185 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 193 */     return this.username.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 198 */     StringBuilder sb = new StringBuilder();
/* 199 */     sb.append(getClass().getName()).append(" [");
/* 200 */     sb.append("Username=").append(this.username).append(", ");
/* 201 */     sb.append("Password=[PROTECTED], ");
/* 202 */     sb.append("Enabled=").append(this.enabled).append(", ");
/* 203 */     sb.append("AccountNonExpired=").append(this.accountNonExpired).append(", ");
/* 204 */     sb.append("CredentialsNonExpired=").append(this.credentialsNonExpired).append(", ");
/* 205 */     sb.append("AccountNonLocked=").append(this.accountNonLocked).append(", ");
/* 206 */     sb.append("Granted Authorities=").append(this.authorities).append("]");
/* 207 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UserBuilder withUsername(String username) {
/* 216 */     return builder().username(username);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UserBuilder builder() {
/* 224 */     return new UserBuilder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static UserBuilder withDefaultPasswordEncoder() {
/* 284 */     logger.warn("User.withDefaultPasswordEncoder() is considered unsafe for production and is only intended for sample applications.");
/*     */     
/* 286 */     PasswordEncoder encoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
/* 287 */     Objects.requireNonNull(encoder); return builder().passwordEncoder(encoder::encode);
/*     */   }
/*     */ 
/*     */   
/*     */   public static UserBuilder withUserDetails(UserDetails userDetails) {
/* 292 */     return withUsername(userDetails.getUsername())
/* 293 */       .password(userDetails.getPassword())
/* 294 */       .accountExpired(!userDetails.isAccountNonExpired())
/* 295 */       .accountLocked(!userDetails.isAccountNonLocked())
/* 296 */       .authorities(userDetails.getAuthorities())
/* 297 */       .credentialsExpired(!userDetails.isCredentialsNonExpired())
/* 298 */       .disabled(!userDetails.isEnabled());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class AuthorityComparator
/*     */     implements Comparator<GrantedAuthority>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 620L;
/*     */ 
/*     */ 
/*     */     
/*     */     public int compare(GrantedAuthority g1, GrantedAuthority g2) {
/* 311 */       if (g2.getAuthority() == null) {
/* 312 */         return -1;
/*     */       }
/* 314 */       if (g1.getAuthority() == null) {
/* 315 */         return 1;
/*     */       }
/* 317 */       return g1.getAuthority().compareTo(g2.getAuthority());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class UserBuilder
/*     */   {
/*     */     private String username;
/*     */ 
/*     */     
/*     */     private String password;
/*     */ 
/*     */     
/* 332 */     private List<GrantedAuthority> authorities = new ArrayList<>();
/*     */     
/*     */     private boolean accountExpired;
/*     */     
/*     */     private boolean accountLocked;
/*     */     private boolean credentialsExpired;
/*     */     private boolean disabled;
/*     */     private Function<String, String> passwordEncoder;
/*     */     
/*     */     private UserBuilder() {
/* 342 */       this.passwordEncoder = (password -> password);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserBuilder username(String username) {
/* 357 */       Assert.notNull(username, "username cannot be null");
/* 358 */       this.username = username;
/* 359 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserBuilder password(String password) {
/* 369 */       Assert.notNull(password, "password cannot be null");
/* 370 */       this.password = password;
/* 371 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserBuilder passwordEncoder(Function<String, String> encoder) {
/* 382 */       Assert.notNull(encoder, "encoder cannot be null");
/* 383 */       this.passwordEncoder = encoder;
/* 384 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserBuilder roles(String... roles) {
/* 412 */       List<GrantedAuthority> authorities = new ArrayList<>(roles.length);
/* 413 */       for (String role : roles) {
/* 414 */         Assert.isTrue(!role.startsWith("ROLE_"), () -> role + " cannot start with ROLE_ (it is automatically added)");
/*     */         
/* 416 */         authorities.add(new SimpleGrantedAuthority("ROLE_" + role));
/*     */       } 
/* 418 */       return authorities(authorities);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserBuilder authorities(GrantedAuthority... authorities) {
/* 430 */       Assert.notNull(authorities, "authorities cannot be null");
/* 431 */       return authorities(Arrays.asList(authorities));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserBuilder authorities(Collection<? extends GrantedAuthority> authorities) {
/* 443 */       Assert.notNull(authorities, "authorities cannot be null");
/* 444 */       this.authorities = new ArrayList<>(authorities);
/* 445 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserBuilder authorities(String... authorities) {
/* 457 */       Assert.notNull(authorities, "authorities cannot be null");
/* 458 */       return authorities(AuthorityUtils.createAuthorityList(authorities));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserBuilder accountExpired(boolean accountExpired) {
/* 468 */       this.accountExpired = accountExpired;
/* 469 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserBuilder accountLocked(boolean accountLocked) {
/* 479 */       this.accountLocked = accountLocked;
/* 480 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserBuilder credentialsExpired(boolean credentialsExpired) {
/* 490 */       this.credentialsExpired = credentialsExpired;
/* 491 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserBuilder disabled(boolean disabled) {
/* 501 */       this.disabled = disabled;
/* 502 */       return this;
/*     */     }
/*     */     
/*     */     public UserDetails build() {
/* 506 */       String encodedPassword = this.passwordEncoder.apply(this.password);
/* 507 */       return new User(this.username, encodedPassword, !this.disabled, !this.accountExpired, !this.credentialsExpired, !this.accountLocked, this.authorities);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\cor\\userdetails\User.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */