/*     */ package org.springframework.security.core.userdetails.jdbc;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*     */ import org.springframework.security.core.userdetails.User;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdbcDaoImpl
/*     */   extends JdbcDaoSupport
/*     */   implements UserDetailsService, MessageSourceAware
/*     */ {
/*     */   public static final String DEFAULT_USER_SCHEMA_DDL_LOCATION = "org/springframework/security/core/userdetails/jdbc/users.ddl";
/*     */   public static final String DEF_USERS_BY_USERNAME_QUERY = "select username,password,enabled from users where username = ?";
/*     */   public static final String DEF_AUTHORITIES_BY_USERNAME_QUERY = "select username,authority from authorities where username = ?";
/*     */   public static final String DEF_GROUP_AUTHORITIES_BY_USERNAME_QUERY = "select g.id, g.group_name, ga.authority from groups g, group_members gm, group_authorities ga where gm.username = ? and g.id = ga.group_id and g.id = gm.group_id";
/* 133 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */   
/*     */   private String authoritiesByUsernameQuery;
/*     */   
/*     */   private String groupAuthoritiesByUsernameQuery;
/*     */   
/*     */   private String usersByUsernameQuery;
/*     */   
/* 141 */   private String rolePrefix = "";
/*     */   
/*     */   private boolean usernameBasedPrimaryKey = true;
/*     */   
/*     */   private boolean enableAuthorities = true;
/*     */   
/*     */   private boolean enableGroups;
/*     */   
/*     */   public JdbcDaoImpl() {
/* 150 */     this.usersByUsernameQuery = "select username,password,enabled from users where username = ?";
/* 151 */     this.authoritiesByUsernameQuery = "select username,authority from authorities where username = ?";
/* 152 */     this.groupAuthoritiesByUsernameQuery = "select g.id, g.group_name, ga.authority from groups g, group_members gm, group_authorities ga where gm.username = ? and g.id = ga.group_id and g.id = gm.group_id";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MessageSourceAccessor getMessages() {
/* 159 */     return this.messages;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addCustomAuthorities(String username, List<GrantedAuthority> authorities) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUsersByUsernameQuery() {
/* 173 */     return this.usersByUsernameQuery;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initDao() throws ApplicationContextException {
/* 178 */     Assert.isTrue((this.enableAuthorities || this.enableGroups), "Use of either authorities or groups must be enabled");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
/* 184 */     List<UserDetails> users = loadUsersByUsername(username);
/* 185 */     if (users.isEmpty()) {
/* 186 */       this.logger.debug("Query returned no results for user '" + username + "'");
/* 187 */       throw new UsernameNotFoundException(this.messages.getMessage("JdbcDaoImpl.notFound", new Object[] { username }, "Username {0} not found"));
/*     */     } 
/*     */     
/* 190 */     UserDetails user = users.get(0);
/* 191 */     Set<GrantedAuthority> dbAuthsSet = new HashSet<>();
/* 192 */     if (this.enableAuthorities) {
/* 193 */       dbAuthsSet.addAll(loadUserAuthorities(user.getUsername()));
/*     */     }
/* 195 */     if (this.enableGroups) {
/* 196 */       dbAuthsSet.addAll(loadGroupAuthorities(user.getUsername()));
/*     */     }
/* 198 */     List<GrantedAuthority> dbAuths = new ArrayList<>(dbAuthsSet);
/* 199 */     addCustomAuthorities(user.getUsername(), dbAuths);
/* 200 */     if (dbAuths.isEmpty()) {
/* 201 */       this.logger.debug("User '" + username + "' has no authorities and will be treated as 'not found'");
/* 202 */       throw new UsernameNotFoundException(this.messages.getMessage("JdbcDaoImpl.noAuthority", new Object[] { username }, "User {0} has no GrantedAuthority"));
/*     */     } 
/*     */     
/* 205 */     return createUserDetails(username, user, dbAuths);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<UserDetails> loadUsersByUsername(String username) {
/* 214 */     RowMapper<UserDetails> mapper = (rs, rowNum) -> {
/*     */         String username1 = rs.getString(1);
/*     */         
/*     */         String password = rs.getString(2);
/*     */         boolean enabled = rs.getBoolean(3);
/*     */         return (UserDetails)new User(username1, password, enabled, true, true, true, AuthorityUtils.NO_AUTHORITIES);
/*     */       };
/* 221 */     return getJdbcTemplate().query(this.usersByUsernameQuery, mapper, new Object[] { username });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<GrantedAuthority> loadUserAuthorities(String username) {
/* 229 */     return getJdbcTemplate().query(this.authoritiesByUsernameQuery, (rs, rowNum) -> { String roleName = this.rolePrefix + this.rolePrefix; return (GrantedAuthority)new SimpleGrantedAuthority(roleName); }new Object[] { username });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<GrantedAuthority> loadGroupAuthorities(String username) {
/* 241 */     return getJdbcTemplate().query(this.groupAuthoritiesByUsernameQuery, (rs, rowNum) -> { String roleName = getRolePrefix() + getRolePrefix(); return (GrantedAuthority)new SimpleGrantedAuthority(roleName); }new Object[] { username });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UserDetails createUserDetails(String username, UserDetails userFromUserQuery, List<GrantedAuthority> combinedAuthorities) {
/* 258 */     String returnUsername = userFromUserQuery.getUsername();
/* 259 */     if (!this.usernameBasedPrimaryKey) {
/* 260 */       returnUsername = username;
/*     */     }
/* 262 */     return (UserDetails)new User(returnUsername, userFromUserQuery.getPassword(), userFromUserQuery.isEnabled(), userFromUserQuery
/* 263 */         .isAccountNonExpired(), userFromUserQuery.isCredentialsNonExpired(), userFromUserQuery
/* 264 */         .isAccountNonLocked(), combinedAuthorities);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthoritiesByUsernameQuery(String queryString) {
/* 276 */     this.authoritiesByUsernameQuery = queryString;
/*     */   }
/*     */   
/*     */   protected String getAuthoritiesByUsernameQuery() {
/* 280 */     return this.authoritiesByUsernameQuery;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGroupAuthoritiesByUsernameQuery(String queryString) {
/* 292 */     this.groupAuthoritiesByUsernameQuery = queryString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRolePrefix(String rolePrefix) {
/* 304 */     this.rolePrefix = rolePrefix;
/*     */   }
/*     */   
/*     */   protected String getRolePrefix() {
/* 308 */     return this.rolePrefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsernameBasedPrimaryKey(boolean usernameBasedPrimaryKey) {
/* 324 */     this.usernameBasedPrimaryKey = usernameBasedPrimaryKey;
/*     */   }
/*     */   
/*     */   protected boolean isUsernameBasedPrimaryKey() {
/* 328 */     return this.usernameBasedPrimaryKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUsersByUsernameQuery(String usersByUsernameQueryString) {
/* 345 */     this.usersByUsernameQuery = usersByUsernameQueryString;
/*     */   }
/*     */   
/*     */   protected boolean getEnableAuthorities() {
/* 349 */     return this.enableAuthorities;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnableAuthorities(boolean enableAuthorities) {
/* 356 */     this.enableAuthorities = enableAuthorities;
/*     */   }
/*     */   
/*     */   protected boolean getEnableGroups() {
/* 360 */     return this.enableGroups;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnableGroups(boolean enableGroups) {
/* 368 */     this.enableGroups = enableGroups;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 373 */     Assert.notNull(messageSource, "messageSource cannot be null");
/* 374 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\cor\\userdetails\jdbc\JdbcDaoImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */