/*    */ package org.springframework.security.core.userdetails.memory;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Vector;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserAttribute
/*    */ {
/* 34 */   private List<GrantedAuthority> authorities = new Vector<>();
/*    */   
/*    */   private String password;
/*    */   
/*    */   private boolean enabled = true;
/*    */   
/*    */   public void addAuthority(GrantedAuthority newAuthority) {
/* 41 */     this.authorities.add(newAuthority);
/*    */   }
/*    */   
/*    */   public List<GrantedAuthority> getAuthorities() {
/* 45 */     return this.authorities;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAuthorities(List<GrantedAuthority> authorities) {
/* 54 */     this.authorities = authorities;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAuthoritiesAsString(List<String> authoritiesAsStrings) {
/* 64 */     setAuthorities(new ArrayList<>(authoritiesAsStrings.size()));
/* 65 */     for (String authority : authoritiesAsStrings) {
/* 66 */       addAuthority((GrantedAuthority)new SimpleGrantedAuthority(authority));
/*    */     }
/*    */   }
/*    */   
/*    */   public String getPassword() {
/* 71 */     return this.password;
/*    */   }
/*    */   
/*    */   public boolean isEnabled() {
/* 75 */     return this.enabled;
/*    */   }
/*    */   
/*    */   public boolean isValid() {
/* 79 */     return (this.password != null && this.authorities.size() > 0);
/*    */   }
/*    */   
/*    */   public void setEnabled(boolean enabled) {
/* 83 */     this.enabled = enabled;
/*    */   }
/*    */   
/*    */   public void setPassword(String password) {
/* 87 */     this.password = password;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\cor\\userdetails\memory\UserAttribute.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */