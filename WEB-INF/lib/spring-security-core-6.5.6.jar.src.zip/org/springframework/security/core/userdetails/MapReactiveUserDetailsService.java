/*    */ package org.springframework.security.core.userdetails;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.Collection;
/*    */ import java.util.Locale;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MapReactiveUserDetailsService
/*    */   implements ReactiveUserDetailsService, ReactiveUserDetailsPasswordService
/*    */ {
/*    */   private final Map<String, UserDetails> users;
/*    */   
/*    */   public MapReactiveUserDetailsService(Map<String, UserDetails> users) {
/* 44 */     this.users = users;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MapReactiveUserDetailsService(UserDetails... users) {
/* 52 */     this(Arrays.asList(users));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MapReactiveUserDetailsService(Collection<UserDetails> users) {
/* 60 */     Assert.notEmpty(users, "users cannot be null or empty");
/* 61 */     this.users = new ConcurrentHashMap<>();
/* 62 */     for (UserDetails user : users) {
/* 63 */       this.users.put(getKey(user.getUsername()), user);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<UserDetails> findByUsername(String username) {
/* 69 */     String key = getKey(username);
/* 70 */     UserDetails result = this.users.get(key);
/* 71 */     return (result != null) ? Mono.just(User.withUserDetails(result).build()) : Mono.empty();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<UserDetails> updatePassword(UserDetails user, String newPassword) {
/* 77 */     return Mono.just(user)
/* 78 */       .map(userDetails -> withNewPassword(userDetails, newPassword))
/* 79 */       .doOnNext(userDetails -> {
/*    */           String key = getKey(user.getUsername());
/*    */           this.users.put(key, userDetails);
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private UserDetails withNewPassword(UserDetails userDetails, String newPassword) {
/* 88 */     return User.withUserDetails(userDetails)
/* 89 */       .password(newPassword)
/* 90 */       .build();
/*    */   }
/*    */ 
/*    */   
/*    */   private String getKey(String username) {
/* 95 */     return username.toLowerCase(Locale.ROOT);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\cor\\userdetails\MapReactiveUserDetailsService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */