/*    */ package org.springframework.security.core.userdetails.memory;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserAttributeEditor
/*    */   extends PropertyEditorSupport
/*    */ {
/*    */   public void setAsText(String s) throws IllegalArgumentException {
/* 36 */     if (!StringUtils.hasText(s)) {
/* 37 */       setValue(null);
/*    */       return;
/*    */     } 
/* 40 */     String[] tokens = StringUtils.commaDelimitedListToStringArray(s);
/* 41 */     UserAttribute userAttrib = new UserAttribute();
/* 42 */     List<String> authoritiesAsStrings = new ArrayList<>();
/* 43 */     for (int i = 0; i < tokens.length; i++) {
/* 44 */       String currentToken = tokens[i].trim();
/* 45 */       if (i == 0) {
/* 46 */         userAttrib.setPassword(currentToken);
/*    */       
/*    */       }
/* 49 */       else if (currentToken.toLowerCase(Locale.ENGLISH).equals("enabled")) {
/* 50 */         userAttrib.setEnabled(true);
/*    */       }
/* 52 */       else if (currentToken.toLowerCase(Locale.ENGLISH).equals("disabled")) {
/* 53 */         userAttrib.setEnabled(false);
/*    */       } else {
/*    */         
/* 56 */         authoritiesAsStrings.add(currentToken);
/*    */       } 
/*    */     } 
/*    */     
/* 60 */     userAttrib.setAuthoritiesAsString(authoritiesAsStrings);
/* 61 */     setValue(userAttrib.isValid() ? userAttrib : null);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\cor\\userdetails\memory\UserAttributeEditor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */