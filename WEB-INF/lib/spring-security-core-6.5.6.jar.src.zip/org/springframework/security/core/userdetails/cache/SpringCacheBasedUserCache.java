/*    */ package org.springframework.security.core.userdetails.cache;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.cache.Cache;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.security.core.userdetails.UserCache;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringCacheBasedUserCache
/*    */   implements UserCache
/*    */ {
/* 36 */   private static final Log logger = LogFactory.getLog(SpringCacheBasedUserCache.class);
/*    */   
/*    */   private final Cache cache;
/*    */   
/*    */   public SpringCacheBasedUserCache(Cache cache) {
/* 41 */     Assert.notNull(cache, "cache mandatory");
/* 42 */     this.cache = cache;
/*    */   }
/*    */ 
/*    */   
/*    */   public UserDetails getUserFromCache(String username) {
/* 47 */     Cache.ValueWrapper element = (username != null) ? this.cache.get(username) : null;
/* 48 */     logger.debug(LogMessage.of(() -> "Cache hit: " + ((element != null) ? 1 : 0) + "; username: " + username));
/* 49 */     return (element != null) ? (UserDetails)element.get() : null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void putUserInCache(UserDetails user) {
/* 54 */     logger.debug(LogMessage.of(() -> "Cache put: " + user.getUsername()));
/* 55 */     this.cache.put(user.getUsername(), user);
/*    */   }
/*    */   
/*    */   public void removeUserFromCache(UserDetails user) {
/* 59 */     logger.debug(LogMessage.of(() -> "Cache remove: " + user.getUsername()));
/* 60 */     removeUserFromCache(user.getUsername());
/*    */   }
/*    */ 
/*    */   
/*    */   public void removeUserFromCache(String username) {
/* 65 */     this.cache.evict(username);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\cor\\userdetails\cache\SpringCacheBasedUserCache.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */