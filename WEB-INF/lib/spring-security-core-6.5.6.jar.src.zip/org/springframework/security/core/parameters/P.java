package org.springframework.security.core.parameters;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface P {
  String value();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\parameters\P.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */