/*     */ package org.springframework.security.core.parameters;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotationParameterNameDiscoverer
/*     */   implements ParameterNameDiscoverer
/*     */ {
/*     */   private static final ParameterNameFactory<Constructor<?>> CONSTRUCTOR_METHODPARAM_FACTORY;
/*     */   
/*     */   static {
/*  91 */     CONSTRUCTOR_METHODPARAM_FACTORY = (constructor -> constructor.getParameterAnnotations());
/*     */   }
/*     */   
/*  94 */   private static final ParameterNameFactory<Method> METHOD_METHODPARAM_FACTORY = Method::getParameterAnnotations;
/*     */   
/*     */   private final Set<String> annotationClassesToUse;
/*     */   
/*     */   public AnnotationParameterNameDiscoverer(String... annotationClassToUse) {
/*  99 */     this(new HashSet<>(Arrays.asList(annotationClassToUse)));
/*     */   }
/*     */   
/*     */   public AnnotationParameterNameDiscoverer(Set<String> annotationClassesToUse) {
/* 103 */     Assert.notEmpty(annotationClassesToUse, "annotationClassesToUse cannot be null or empty");
/* 104 */     this.annotationClassesToUse = annotationClassesToUse;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getParameterNames(Method method) {
/* 109 */     Method originalMethod = BridgeMethodResolver.findBridgedMethod(method);
/* 110 */     String[] paramNames = lookupParameterNames(METHOD_METHODPARAM_FACTORY, originalMethod);
/* 111 */     if (paramNames != null) {
/* 112 */       return paramNames;
/*     */     }
/* 114 */     Class<?> declaringClass = method.getDeclaringClass();
/* 115 */     Class<?>[] interfaces = declaringClass.getInterfaces();
/* 116 */     for (Class<?> intrfc : interfaces) {
/* 117 */       Method intrfcMethod = ReflectionUtils.findMethod(intrfc, method.getName(), method.getParameterTypes());
/* 118 */       if (intrfcMethod != null) {
/* 119 */         return lookupParameterNames(METHOD_METHODPARAM_FACTORY, intrfcMethod);
/*     */       }
/*     */     } 
/* 122 */     return paramNames;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getParameterNames(Constructor<?> constructor) {
/* 127 */     return lookupParameterNames(CONSTRUCTOR_METHODPARAM_FACTORY, constructor);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T extends java.lang.reflect.AccessibleObject> String[] lookupParameterNames(ParameterNameFactory<T> parameterNameFactory, T t) {
/* 139 */     Annotation[][] parameterAnnotations = parameterNameFactory.findParameterAnnotations(t);
/* 140 */     int parameterCount = parameterAnnotations.length;
/* 141 */     String[] paramNames = new String[parameterCount];
/* 142 */     boolean found = false;
/* 143 */     for (int i = 0; i < parameterCount; i++) {
/* 144 */       Annotation[] annotations = parameterAnnotations[i];
/* 145 */       String parameterName = findParameterName(annotations);
/* 146 */       if (parameterName != null) {
/* 147 */         found = true;
/* 148 */         paramNames[i] = parameterName;
/*     */       } 
/*     */     } 
/* 151 */     return found ? paramNames : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String findParameterName(Annotation[] parameterAnnotations) {
/* 162 */     for (Annotation paramAnnotation : parameterAnnotations) {
/* 163 */       if (this.annotationClassesToUse.contains(paramAnnotation.annotationType().getName())) {
/* 164 */         return (String)AnnotationUtils.getValue(paramAnnotation, "value");
/*     */       }
/*     */     } 
/* 167 */     return null;
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   private static interface ParameterNameFactory<T extends java.lang.reflect.AccessibleObject> {
/*     */     Annotation[][] findParameterAnnotations(T param1T);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\parameters\AnnotationParameterNameDiscoverer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */