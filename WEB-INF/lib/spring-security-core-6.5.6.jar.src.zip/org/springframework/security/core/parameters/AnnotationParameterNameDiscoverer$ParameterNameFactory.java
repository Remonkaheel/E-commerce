package org.springframework.security.core.parameters;

import java.lang.annotation.Annotation;

@FunctionalInterface
interface ParameterNameFactory<T extends java.lang.reflect.AccessibleObject> {
  Annotation[][] findParameterAnnotations(T paramT);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\parameters\AnnotationParameterNameDiscoverer$ParameterNameFactory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */