/*    */ package org.springframework.security.core.parameters;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.springframework.core.DefaultParameterNameDiscoverer;
/*    */ import org.springframework.core.ParameterNameDiscoverer;
/*    */ import org.springframework.core.PrioritizedParameterNameDiscoverer;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultSecurityParameterNameDiscoverer
/*    */   extends PrioritizedParameterNameDiscoverer
/*    */ {
/*    */   private static final String DATA_PARAM_CLASSNAME = "org.springframework.data.repository.query.Param";
/* 48 */   private static final boolean DATA_PARAM_PRESENT = ClassUtils.isPresent("org.springframework.data.repository.query.Param", DefaultSecurityParameterNameDiscoverer.class
/* 49 */       .getClassLoader());
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DefaultSecurityParameterNameDiscoverer() {
/* 56 */     this(Collections.emptyList());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DefaultSecurityParameterNameDiscoverer(List<? extends ParameterNameDiscoverer> parameterNameDiscovers) {
/* 67 */     Assert.notNull(parameterNameDiscovers, "parameterNameDiscovers cannot be null");
/* 68 */     for (ParameterNameDiscoverer discover : parameterNameDiscovers) {
/* 69 */       addDiscoverer(discover);
/*    */     }
/* 71 */     Set<String> annotationClassesToUse = new HashSet<>(2);
/* 72 */     annotationClassesToUse.add("org.springframework.security.access.method.P");
/* 73 */     annotationClassesToUse.add(P.class.getName());
/* 74 */     if (DATA_PARAM_PRESENT) {
/* 75 */       annotationClassesToUse.add("org.springframework.data.repository.query.Param");
/*    */     }
/* 77 */     addDiscoverer(new AnnotationParameterNameDiscoverer(annotationClassesToUse));
/* 78 */     addDiscoverer((ParameterNameDiscoverer)new DefaultParameterNameDiscoverer());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\parameters\DefaultSecurityParameterNameDiscoverer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */