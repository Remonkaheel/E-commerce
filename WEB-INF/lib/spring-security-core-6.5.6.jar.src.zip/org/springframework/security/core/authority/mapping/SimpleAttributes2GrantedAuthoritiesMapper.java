/*     */ package org.springframework.security.core.authority.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleAttributes2GrantedAuthoritiesMapper
/*     */   implements Attributes2GrantedAuthoritiesMapper, InitializingBean
/*     */ {
/*  44 */   private String attributePrefix = "ROLE_";
/*     */ 
/*     */   
/*     */   private boolean convertAttributeToUpperCase = false;
/*     */ 
/*     */   
/*     */   private boolean convertAttributeToLowerCase = false;
/*     */ 
/*     */   
/*     */   private boolean addPrefixIfAlreadyExisting = false;
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  57 */     Assert.isTrue((!isConvertAttributeToUpperCase() || !isConvertAttributeToLowerCase()), "Either convertAttributeToUpperCase or convertAttributeToLowerCase can be set to true, but not both");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<GrantedAuthority> getGrantedAuthorities(Collection<String> attributes) {
/*  67 */     List<GrantedAuthority> result = new ArrayList<>(attributes.size());
/*  68 */     for (String attribute : attributes) {
/*  69 */       result.add(getGrantedAuthority(attribute));
/*     */     }
/*  71 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private GrantedAuthority getGrantedAuthority(String attribute) {
/*  81 */     if (isConvertAttributeToLowerCase()) {
/*  82 */       attribute = attribute.toLowerCase(Locale.ROOT);
/*     */     }
/*  84 */     else if (isConvertAttributeToUpperCase()) {
/*  85 */       attribute = attribute.toUpperCase(Locale.ROOT);
/*     */     } 
/*  87 */     if (isAddPrefixIfAlreadyExisting() || !attribute.startsWith(getAttributePrefix())) {
/*  88 */       return (GrantedAuthority)new SimpleGrantedAuthority(getAttributePrefix() + getAttributePrefix());
/*     */     }
/*     */     
/*  91 */     return (GrantedAuthority)new SimpleGrantedAuthority(attribute);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isConvertAttributeToLowerCase() {
/*  96 */     return this.convertAttributeToLowerCase;
/*     */   }
/*     */   
/*     */   public void setConvertAttributeToLowerCase(boolean b) {
/* 100 */     this.convertAttributeToLowerCase = b;
/*     */   }
/*     */   
/*     */   private boolean isConvertAttributeToUpperCase() {
/* 104 */     return this.convertAttributeToUpperCase;
/*     */   }
/*     */   
/*     */   public void setConvertAttributeToUpperCase(boolean b) {
/* 108 */     this.convertAttributeToUpperCase = b;
/*     */   }
/*     */   
/*     */   private String getAttributePrefix() {
/* 112 */     return (this.attributePrefix != null) ? this.attributePrefix : "";
/*     */   }
/*     */   
/*     */   public void setAttributePrefix(String string) {
/* 116 */     this.attributePrefix = string;
/*     */   }
/*     */   
/*     */   private boolean isAddPrefixIfAlreadyExisting() {
/* 120 */     return this.addPrefixIfAlreadyExisting;
/*     */   }
/*     */   
/*     */   public void setAddPrefixIfAlreadyExisting(boolean b) {
/* 124 */     this.addPrefixIfAlreadyExisting = b;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\authority\mapping\SimpleAttributes2GrantedAuthoritiesMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */