/*     */ package org.springframework.security.core.authority.mapping;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapBasedAttributes2GrantedAuthoritiesMapper
/*     */   implements Attributes2GrantedAuthoritiesMapper, MappableAttributesRetriever, InitializingBean
/*     */ {
/*  45 */   private Map<String, Collection<GrantedAuthority>> attributes2grantedAuthoritiesMap = null;
/*     */   
/*  47 */   private String stringSeparator = ",";
/*     */   
/*  49 */   private Set<String> mappableAttributes = null;
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  53 */     Assert.notNull(this.attributes2grantedAuthoritiesMap, "attributes2grantedAuthoritiesMap must be set");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<GrantedAuthority> getGrantedAuthorities(Collection<String> attributes) {
/*  61 */     ArrayList<GrantedAuthority> result = new ArrayList<>();
/*  62 */     for (String attribute : attributes) {
/*  63 */       Collection<GrantedAuthority> granted = this.attributes2grantedAuthoritiesMap.get(attribute);
/*  64 */       if (granted != null) {
/*  65 */         result.addAll(granted);
/*     */       }
/*     */     } 
/*  68 */     result.trimToSize();
/*  69 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Collection<GrantedAuthority>> getAttributes2grantedAuthoritiesMap() {
/*  76 */     return this.attributes2grantedAuthoritiesMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttributes2grantedAuthoritiesMap(Map<?, ?> attributes2grantedAuthoritiesMap) {
/*  84 */     Assert.notEmpty(attributes2grantedAuthoritiesMap, "A non-empty attributes2grantedAuthoritiesMap must be supplied");
/*     */     
/*  86 */     this.attributes2grantedAuthoritiesMap = preProcessMap(attributes2grantedAuthoritiesMap);
/*  87 */     this.mappableAttributes = Collections.unmodifiableSet(this.attributes2grantedAuthoritiesMap.keySet());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Collection<GrantedAuthority>> preProcessMap(Map<?, ?> orgMap) {
/*  96 */     Map<String, Collection<GrantedAuthority>> result = new HashMap<>(orgMap.size());
/*  97 */     for (Map.Entry<?, ?> entry : orgMap.entrySet()) {
/*  98 */       Assert.isInstanceOf(String.class, entry.getKey(), "attributes2grantedAuthoritiesMap contains non-String objects as keys");
/*     */       
/* 100 */       result.put((String)entry.getKey(), getGrantedAuthorityCollection(entry.getValue()));
/*     */     } 
/* 102 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Collection<GrantedAuthority> getGrantedAuthorityCollection(Object value) {
/* 111 */     Collection<GrantedAuthority> result = new ArrayList<>();
/* 112 */     addGrantedAuthorityCollection(result, value);
/* 113 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addGrantedAuthorityCollection(Collection<GrantedAuthority> result, Object value) {
/* 122 */     if (value == null) {
/*     */       return;
/*     */     }
/* 125 */     if (value instanceof Collection) {
/* 126 */       addGrantedAuthorityCollection(result, (Collection)value);
/*     */     }
/* 128 */     else if (value instanceof Object[]) {
/* 129 */       addGrantedAuthorityCollection(result, (Object[])value);
/*     */     }
/* 131 */     else if (value instanceof String) {
/* 132 */       addGrantedAuthorityCollection(result, (String)value);
/*     */     }
/* 134 */     else if (value instanceof GrantedAuthority) {
/* 135 */       result.add((GrantedAuthority)value);
/*     */     } else {
/*     */       
/* 138 */       throw new IllegalArgumentException("Invalid object type: " + value.getClass().getName());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addGrantedAuthorityCollection(Collection<GrantedAuthority> result, Collection<?> value) {
/* 143 */     for (Object elt : value) {
/* 144 */       addGrantedAuthorityCollection(result, elt);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addGrantedAuthorityCollection(Collection<GrantedAuthority> result, Object[] value) {
/* 149 */     for (Object aValue : value) {
/* 150 */       addGrantedAuthorityCollection(result, aValue);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addGrantedAuthorityCollection(Collection<GrantedAuthority> result, String value) {
/* 155 */     StringTokenizer tokenizer = new StringTokenizer(value, this.stringSeparator, false);
/* 156 */     while (tokenizer.hasMoreTokens()) {
/* 157 */       String token = tokenizer.nextToken();
/* 158 */       if (StringUtils.hasText(token)) {
/* 159 */         result.add(new SimpleGrantedAuthority(token));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getMappableAttributes() {
/* 170 */     return this.mappableAttributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStringSeparator() {
/* 177 */     return this.stringSeparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStringSeparator(String stringSeparator) {
/* 184 */     this.stringSeparator = stringSeparator;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\authority\mapping\MapBasedAttributes2GrantedAuthoritiesMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */