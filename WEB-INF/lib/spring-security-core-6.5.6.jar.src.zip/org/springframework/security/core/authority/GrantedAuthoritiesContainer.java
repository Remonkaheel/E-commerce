package org.springframework.security.core.authority;

import java.io.Serializable;
import java.util.Collection;
import org.springframework.security.core.GrantedAuthority;

public interface GrantedAuthoritiesContainer extends Serializable {
  Collection<? extends GrantedAuthority> getGrantedAuthorities();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\authority\GrantedAuthoritiesContainer.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */