package org.springframework.security.core.authority.mapping;

import java.util.Set;

public interface MappableAttributesRetriever {
  Set<String> getMappableAttributes();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\authority\mapping\MappableAttributesRetriever.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */