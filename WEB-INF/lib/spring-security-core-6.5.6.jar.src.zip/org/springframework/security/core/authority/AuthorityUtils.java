/*    */ package org.springframework.security.core.authority;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AuthorityUtils
/*    */ {
/* 40 */   public static final List<GrantedAuthority> NO_AUTHORITIES = Collections.emptyList();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static List<GrantedAuthority> commaSeparatedStringToAuthorityList(String authorityString) {
/* 52 */     return createAuthorityList(StringUtils.tokenizeToStringArray(authorityString, ","));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Set<String> authorityListToSet(Collection<? extends GrantedAuthority> userAuthorities) {
/* 61 */     Assert.notNull(userAuthorities, "userAuthorities cannot be null");
/* 62 */     Set<String> set = new HashSet<>(userAuthorities.size());
/* 63 */     for (GrantedAuthority authority : userAuthorities) {
/* 64 */       set.add(authority.getAuthority());
/*    */     }
/* 66 */     return set;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static List<GrantedAuthority> createAuthorityList(String... authorities) {
/* 75 */     List<GrantedAuthority> grantedAuthorities = new ArrayList<>(authorities.length);
/* 76 */     for (String authority : authorities) {
/* 77 */       grantedAuthorities.add(new SimpleGrantedAuthority(authority));
/*    */     }
/* 79 */     return grantedAuthorities;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static List<GrantedAuthority> createAuthorityList(Collection<String> authorities) {
/* 89 */     List<GrantedAuthority> grantedAuthorities = new ArrayList<>(authorities.size());
/* 90 */     for (String authority : authorities) {
/* 91 */       grantedAuthorities.add(new SimpleGrantedAuthority(authority));
/*    */     }
/* 93 */     return grantedAuthorities;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\authority\AuthorityUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */