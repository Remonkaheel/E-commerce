/*     */ package org.springframework.security.core.authority.mapping;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.SimpleGrantedAuthority;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SimpleAuthorityMapper
/*     */   implements GrantedAuthoritiesMapper, InitializingBean
/*     */ {
/*     */   private GrantedAuthority defaultAuthority;
/*  41 */   private String prefix = "ROLE_";
/*     */   
/*     */   private boolean convertToUpperCase = false;
/*     */   
/*     */   private boolean convertToLowerCase = false;
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/*  49 */     Assert.isTrue((!this.convertToUpperCase || !this.convertToLowerCase), "Either convertToUpperCase or convertToLowerCase can be set to true, but not both");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<GrantedAuthority> mapAuthorities(Collection<? extends GrantedAuthority> authorities) {
/*  63 */     HashSet<GrantedAuthority> mapped = new HashSet<>(authorities.size());
/*  64 */     for (GrantedAuthority authority : authorities) {
/*  65 */       mapped.add(mapAuthority(authority.getAuthority()));
/*     */     }
/*  67 */     if (this.defaultAuthority != null) {
/*  68 */       mapped.add(this.defaultAuthority);
/*     */     }
/*  70 */     return mapped;
/*     */   }
/*     */   
/*     */   private GrantedAuthority mapAuthority(String name) {
/*  74 */     if (this.convertToUpperCase) {
/*  75 */       name = name.toUpperCase(Locale.ROOT);
/*     */     }
/*  77 */     else if (this.convertToLowerCase) {
/*  78 */       name = name.toLowerCase(Locale.ROOT);
/*     */     } 
/*  80 */     if (this.prefix.length() > 0 && !name.startsWith(this.prefix)) {
/*  81 */       name = this.prefix + this.prefix;
/*     */     }
/*  83 */     return (GrantedAuthority)new SimpleGrantedAuthority(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrefix(String prefix) {
/*  93 */     Assert.notNull(prefix, "prefix cannot be null");
/*  94 */     this.prefix = prefix;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConvertToUpperCase(boolean convertToUpperCase) {
/* 102 */     this.convertToUpperCase = convertToUpperCase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConvertToLowerCase(boolean convertToLowerCase) {
/* 110 */     this.convertToLowerCase = convertToLowerCase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultAuthority(String authority) {
/* 118 */     Assert.hasText(authority, "The authority name cannot be set to an empty value");
/* 119 */     this.defaultAuthority = (GrantedAuthority)new SimpleGrantedAuthority(authority);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\authority\mapping\SimpleAuthorityMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */