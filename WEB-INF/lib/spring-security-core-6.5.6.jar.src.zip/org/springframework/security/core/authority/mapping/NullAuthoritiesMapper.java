/*    */ package org.springframework.security.core.authority.mapping;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullAuthoritiesMapper
/*    */   implements GrantedAuthoritiesMapper
/*    */ {
/*    */   public Collection<? extends GrantedAuthority> mapAuthorities(Collection<? extends GrantedAuthority> authorities) {
/* 30 */     return authorities;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\authority\mapping\NullAuthoritiesMapper.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */