/*    */ package org.springframework.security.core.authority;
/*    */ 
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SimpleGrantedAuthority
/*    */   implements GrantedAuthority
/*    */ {
/*    */   private static final long serialVersionUID = 620L;
/*    */   private final String role;
/*    */   
/*    */   public SimpleGrantedAuthority(String role) {
/* 39 */     Assert.hasText(role, "A granted authority textual representation is required");
/* 40 */     this.role = role;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAuthority() {
/* 45 */     return this.role;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 50 */     if (this == obj) {
/* 51 */       return true;
/*    */     }
/* 53 */     if (obj instanceof SimpleGrantedAuthority) { SimpleGrantedAuthority sga = (SimpleGrantedAuthority)obj;
/* 54 */       return this.role.equals(sga.getAuthority()); }
/*    */     
/* 56 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 61 */     return this.role.hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 66 */     return this.role;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\authority\SimpleGrantedAuthority.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */