/*    */ package org.springframework.security.core.authority.mapping;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleMappableAttributesRetriever
/*    */   implements MappableAttributesRetriever
/*    */ {
/* 32 */   private Set<String> mappableAttributes = null;
/*    */ 
/*    */   
/*    */   public Set<String> getMappableAttributes() {
/* 36 */     return this.mappableAttributes;
/*    */   }
/*    */   
/*    */   public void setMappableAttributes(Set<String> aMappableRoles) {
/* 40 */     this.mappableAttributes = new HashSet<>();
/* 41 */     this.mappableAttributes.addAll(aMappableRoles);
/* 42 */     this.mappableAttributes = Collections.unmodifiableSet(this.mappableAttributes);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\authority\mapping\SimpleMappableAttributesRetriever.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */