package org.springframework.security.core;

interface Item {
  public static final int INT_ITEM = 3;
  
  public static final int LONG_ITEM = 4;
  
  public static final int BIGINTEGER_ITEM = 0;
  
  public static final int STRING_ITEM = 1;
  
  public static final int LIST_ITEM = 2;
  
  int compareTo(Item paramItem);
  
  int getType();
  
  boolean isNull();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\ComparableVersion$Item.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */