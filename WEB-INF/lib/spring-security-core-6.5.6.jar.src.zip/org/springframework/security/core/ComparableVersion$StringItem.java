/*     */ package org.springframework.security.core;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StringItem
/*     */   implements ComparableVersion.Item
/*     */ {
/* 301 */   private static final List<String> QUALIFIERS = Arrays.asList(new String[] { "alpha", "beta", "milestone", "rc", "snapshot", "", "sp" });
/*     */ 
/*     */   
/* 304 */   private static final Properties ALIASES = new Properties();
/*     */   static {
/* 306 */     ALIASES.put("ga", "");
/* 307 */     ALIASES.put("final", "");
/* 308 */     ALIASES.put("release", "");
/* 309 */     ALIASES.put("cr", "rc");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 317 */   private static final String RELEASE_VERSION_INDEX = String.valueOf(QUALIFIERS.indexOf(""));
/*     */   
/*     */   private final String value;
/*     */   
/*     */   StringItem(String value, boolean followedByDigit) {
/* 322 */     if (followedByDigit && value.length() == 1) {
/*     */       
/* 324 */       switch (value.charAt(0)) { case 'a': 
/*     */         case 'b': 
/*     */         case 'm': 
/*     */         default:
/* 328 */           break; }  value = value;
/*     */     } 
/*     */     
/* 331 */     this.value = ALIASES.getProperty(value, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getType() {
/* 336 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 341 */     return (comparableQualifier(this.value).compareTo(RELEASE_VERSION_INDEX) == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String comparableQualifier(String qualifier) {
/* 358 */     int i = QUALIFIERS.indexOf(qualifier);
/*     */     
/* 360 */     return (i == -1) ? ("" + QUALIFIERS.size() + "-" + QUALIFIERS.size()) : String.valueOf(i);
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(ComparableVersion.Item item) {
/* 365 */     if (item == null)
/*     */     {
/* 367 */       return comparableQualifier(this.value).compareTo(RELEASE_VERSION_INDEX);
/*     */     }
/* 369 */     switch (item.getType()) { case 0: case 3: case 4:
/*     */       
/*     */       case 1:
/*     */       
/*     */       case 2:
/* 374 */        }  throw new IllegalStateException("invalid item: " + String.valueOf(item.getClass()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 380 */     if (this == o) {
/* 381 */       return true;
/*     */     }
/* 383 */     if (o == null || getClass() != o.getClass()) {
/* 384 */       return false;
/*     */     }
/*     */     
/* 387 */     StringItem that = (StringItem)o;
/*     */     
/* 389 */     return this.value.equals(that.value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 395 */     return this.value.hashCode();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 399 */     return this.value;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\ComparableVersion$StringItem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */