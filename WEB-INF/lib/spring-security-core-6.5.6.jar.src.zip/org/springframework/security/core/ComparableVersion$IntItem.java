/*     */ package org.springframework.security.core;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IntItem
/*     */   implements ComparableVersion.Item
/*     */ {
/*     */   private final int value;
/* 107 */   public static final IntItem ZERO = new IntItem();
/*     */   
/*     */   private IntItem() {
/* 110 */     this.value = 0;
/*     */   }
/*     */   
/*     */   IntItem(String str) {
/* 114 */     this.value = Integer.parseInt(str);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getType() {
/* 119 */     return 3;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isNull() {
/* 124 */     return (this.value == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(ComparableVersion.Item item) {
/* 129 */     if (item == null) {
/* 130 */       return (this.value == 0) ? 0 : 1;
/*     */     }
/*     */     
/* 133 */     switch (item.getType()) { case 3: 
/*     */       case 0: case 4: 
/*     */       case 1:
/*     */       
/*     */       case 2:
/* 138 */        }  throw new IllegalStateException("invalid item: " + String.valueOf(item.getClass()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 144 */     if (this == o) {
/* 145 */       return true;
/*     */     }
/* 147 */     if (o == null || getClass() != o.getClass()) {
/* 148 */       return false;
/*     */     }
/*     */     
/* 151 */     IntItem intItem = (IntItem)o;
/*     */     
/* 153 */     return (this.value == intItem.value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 159 */     return this.value;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 164 */     return Integer.toString(this.value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\ComparableVersion$IntItem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */