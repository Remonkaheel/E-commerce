package org.springframework.security.core;

import java.io.Serializable;

public interface GrantedAuthority extends Serializable {
  String getAuthority();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\GrantedAuthority.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */