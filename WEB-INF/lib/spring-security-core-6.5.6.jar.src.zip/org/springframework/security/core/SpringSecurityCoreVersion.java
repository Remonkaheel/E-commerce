/*     */ package org.springframework.security.core;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.SpringVersion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SpringSecurityCoreVersion
/*     */ {
/*  36 */   private static final String DISABLE_CHECKS = SpringSecurityCoreVersion.class.getName().concat(".DISABLE_CHECKS");
/*     */   
/*  38 */   private static final Log logger = LogFactory.getLog(SpringSecurityCoreVersion.class);
/*     */ 
/*     */ 
/*     */   
/*     */   public static final long SERIAL_VERSION_UID = 620L;
/*     */ 
/*     */   
/*  45 */   static final String MIN_SPRING_VERSION = getSpringVersion();
/*     */   
/*     */   static {
/*  48 */     performVersionChecks();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void performVersionChecks() {
/*  55 */     performVersionChecks(MIN_SPRING_VERSION);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void performVersionChecks(String minSpringVersion) {
/*  63 */     if (minSpringVersion == null) {
/*     */       return;
/*     */     }
/*     */     
/*  67 */     String springVersion = SpringVersion.getVersion();
/*  68 */     String version = getVersion();
/*  69 */     if (disableChecks(springVersion, version)) {
/*     */       return;
/*     */     }
/*  72 */     logger.info("You are running with Spring Security Core " + version);
/*  73 */     if ((new ComparableVersion(springVersion)).compareTo(new ComparableVersion(minSpringVersion)) < 0) {
/*  74 */       logger.warn("**** You are advised to use Spring " + minSpringVersion + " or later with this version. You are running: " + springVersion);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getVersion() {
/*  80 */     Package pkg = SpringSecurityCoreVersion.class.getPackage();
/*  81 */     return (pkg != null) ? pkg.getImplementationVersion() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean disableChecks(String springVersion, String springSecurityVersion) {
/*  92 */     if (springVersion == null || springVersion.equals(springSecurityVersion)) {
/*  93 */       return true;
/*     */     }
/*  95 */     return Boolean.getBoolean(DISABLE_CHECKS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getSpringVersion() {
/* 103 */     Properties properties = new Properties();
/*     */     
/* 105 */     try { InputStream is = SpringSecurityCoreVersion.class.getClassLoader().getResourceAsStream("META-INF/spring-security.versions"); 
/* 106 */       try { properties.load(is);
/* 107 */         if (is != null) is.close();  } catch (Throwable throwable) { if (is != null)
/* 108 */           try { is.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }  } catch (IOException|NullPointerException ex)
/* 109 */     { return null; }
/*     */     
/* 111 */     return properties.getProperty("org.springframework:spring-core");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\SpringSecurityCoreVersion.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */