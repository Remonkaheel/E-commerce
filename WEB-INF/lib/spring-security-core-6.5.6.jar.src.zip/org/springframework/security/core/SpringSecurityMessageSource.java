/*    */ package org.springframework.security.core;
/*    */ 
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.context.support.MessageSourceAccessor;
/*    */ import org.springframework.context.support.ResourceBundleMessageSource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SpringSecurityMessageSource
/*    */   extends ResourceBundleMessageSource
/*    */ {
/*    */   public SpringSecurityMessageSource() {
/* 37 */     setBasename("org.springframework.security.messages");
/*    */   }
/*    */   
/*    */   public static MessageSourceAccessor getAccessor() {
/* 41 */     return new MessageSourceAccessor((MessageSource)new SpringSecurityMessageSource());
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\SpringSecurityMessageSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */