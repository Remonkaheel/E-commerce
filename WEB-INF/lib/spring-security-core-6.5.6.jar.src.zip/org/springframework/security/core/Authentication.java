package org.springframework.security.core;

import java.io.Serializable;
import java.security.Principal;
import java.util.Collection;

public interface Authentication extends Principal, Serializable {
  Collection<? extends GrantedAuthority> getAuthorities();
  
  Object getCredentials();
  
  Object getDetails();
  
  Object getPrincipal();
  
  boolean isAuthenticated();
  
  void setAuthenticated(boolean paramBoolean) throws IllegalArgumentException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\Authentication.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */