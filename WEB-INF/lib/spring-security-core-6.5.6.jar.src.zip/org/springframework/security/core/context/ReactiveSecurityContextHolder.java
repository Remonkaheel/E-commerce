/*    */ package org.springframework.security.core.context;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.context.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ReactiveSecurityContextHolder
/*    */ {
/* 34 */   private static final Class<?> SECURITY_CONTEXT_KEY = SecurityContext.class;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Mono<SecurityContext> getContext() {
/* 45 */     return Mono.deferContextual(Mono::just)
/* 46 */       .cast(Context.class)
/* 47 */       .filter(ReactiveSecurityContextHolder::hasSecurityContext)
/* 48 */       .flatMap(ReactiveSecurityContextHolder::getSecurityContext);
/*    */   }
/*    */ 
/*    */   
/*    */   private static boolean hasSecurityContext(Context context) {
/* 53 */     return context.hasKey(SECURITY_CONTEXT_KEY);
/*    */   }
/*    */   
/*    */   private static Mono<SecurityContext> getSecurityContext(Context context) {
/* 57 */     return (Mono<SecurityContext>)context.get(SECURITY_CONTEXT_KEY);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Function<Context, Context> clearContext() {
/* 66 */     return context -> context.delete(SECURITY_CONTEXT_KEY);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Context withSecurityContext(Mono<? extends SecurityContext> securityContext) {
/* 77 */     return Context.of(SECURITY_CONTEXT_KEY, securityContext);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Context withAuthentication(Authentication authentication) {
/* 86 */     return withSecurityContext(Mono.just(new SecurityContextImpl(authentication)));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\context\ReactiveSecurityContextHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */