/*    */ package org.springframework.security.core.context;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class GlobalSecurityContextHolderStrategy
/*    */   implements SecurityContextHolderStrategy
/*    */ {
/*    */   private static SecurityContext contextHolder;
/*    */   
/*    */   public void clearContext() {
/* 36 */     contextHolder = null;
/*    */   }
/*    */ 
/*    */   
/*    */   public SecurityContext getContext() {
/* 41 */     if (contextHolder == null) {
/* 42 */       contextHolder = new SecurityContextImpl();
/*    */     }
/* 44 */     return contextHolder;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setContext(SecurityContext context) {
/* 49 */     Assert.notNull(context, "Only non-null SecurityContext instances are permitted");
/* 50 */     contextHolder = context;
/*    */   }
/*    */ 
/*    */   
/*    */   public SecurityContext createEmptyContext() {
/* 55 */     return new SecurityContextImpl();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\context\GlobalSecurityContextHolderStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */