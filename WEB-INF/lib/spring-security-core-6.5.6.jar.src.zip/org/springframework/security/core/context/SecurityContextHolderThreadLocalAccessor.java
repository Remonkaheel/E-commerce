/*    */ package org.springframework.security.core.context;
/*    */ 
/*    */ import io.micrometer.context.ThreadLocalAccessor;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SecurityContextHolderThreadLocalAccessor
/*    */   implements ThreadLocalAccessor<SecurityContext>
/*    */ {
/*    */   public Object key() {
/* 41 */     return SecurityContext.class.getName();
/*    */   }
/*    */ 
/*    */   
/*    */   public SecurityContext getValue() {
/* 46 */     SecurityContext securityContext = SecurityContextHolder.getContext();
/* 47 */     SecurityContext emptyContext = SecurityContextHolder.createEmptyContext();
/*    */     
/* 49 */     return !securityContext.equals(emptyContext) ? securityContext : null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(SecurityContext securityContext) {
/* 54 */     Assert.notNull(securityContext, "securityContext cannot be null");
/* 55 */     SecurityContextHolder.setContext(securityContext);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue() {
/* 60 */     SecurityContextHolder.clearContext();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\context\SecurityContextHolderThreadLocalAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */