/*    */ package org.springframework.security.core.context;
/*    */ 
/*    */ import io.micrometer.context.ThreadLocalAccessor;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ReactiveSecurityContextHolderThreadLocalAccessor
/*    */   implements ThreadLocalAccessor<Mono<SecurityContext>>
/*    */ {
/* 42 */   private static final ThreadLocal<Mono<SecurityContext>> threadLocal = new ThreadLocal<>();
/*    */ 
/*    */   
/*    */   public Object key() {
/* 46 */     return SecurityContext.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<SecurityContext> getValue() {
/* 51 */     return threadLocal.get();
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue(Mono<SecurityContext> securityContext) {
/* 56 */     Assert.notNull(securityContext, "securityContext cannot be null");
/* 57 */     threadLocal.set(securityContext);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setValue() {
/* 62 */     threadLocal.remove();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\context\ReactiveSecurityContextHolderThreadLocalAccessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */