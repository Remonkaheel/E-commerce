/*    */ package org.springframework.security.core.context;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecurityContextChangedEvent
/*    */   extends ApplicationEvent
/*    */ {
/*    */   public static final Supplier<SecurityContext> NO_CONTEXT = () -> null;
/*    */   private final Supplier<SecurityContext> oldContext;
/*    */   private final Supplier<SecurityContext> newContext;
/*    */   
/*    */   public SecurityContextChangedEvent(Supplier<SecurityContext> oldContext, Supplier<SecurityContext> newContext) {
/* 46 */     super(SecurityContextHolder.class);
/* 47 */     this.oldContext = oldContext;
/* 48 */     this.newContext = newContext;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SecurityContextChangedEvent(SecurityContext oldContext, SecurityContext newContext) {
/* 57 */     this(() -> oldContext, (newContext != null) ? (() -> newContext) : NO_CONTEXT);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SecurityContext getOldContext() {
/* 66 */     return this.oldContext.get();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SecurityContext getNewContext() {
/* 75 */     return this.newContext.get();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isCleared() {
/* 89 */     return (this.newContext == NO_CONTEXT);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\context\SecurityContextChangedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */