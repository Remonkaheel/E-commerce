package org.springframework.security.core.context;

import java.io.Serializable;
import org.springframework.security.core.Authentication;

public interface SecurityContext extends Serializable {
  Authentication getAuthentication();
  
  void setAuthentication(Authentication paramAuthentication);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\context\SecurityContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */