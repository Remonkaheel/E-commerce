/*     */ package org.springframework.security.core.context;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecurityContextHolder
/*     */ {
/*     */   public static final String MODE_THREADLOCAL = "MODE_THREADLOCAL";
/*     */   public static final String MODE_INHERITABLETHREADLOCAL = "MODE_INHERITABLETHREADLOCAL";
/*     */   public static final String MODE_GLOBAL = "MODE_GLOBAL";
/*     */   private static final String MODE_PRE_INITIALIZED = "MODE_PRE_INITIALIZED";
/*     */   public static final String SYSTEM_PROPERTY = "spring.security.strategy";
/*  65 */   private static String strategyName = System.getProperty("spring.security.strategy");
/*     */   
/*     */   private static SecurityContextHolderStrategy strategy;
/*     */   
/*  69 */   private static int initializeCount = 0;
/*     */   
/*     */   static {
/*  72 */     initialize();
/*     */   }
/*     */   
/*     */   private static void initialize() {
/*  76 */     initializeStrategy();
/*  77 */     initializeCount++;
/*     */   }
/*     */   
/*     */   private static void initializeStrategy() {
/*  81 */     if ("MODE_PRE_INITIALIZED".equals(strategyName)) {
/*  82 */       Assert.state((strategy != null), "When using MODE_PRE_INITIALIZED, setContextHolderStrategy must be called with the fully constructed strategy");
/*     */       
/*     */       return;
/*     */     } 
/*  86 */     if (!StringUtils.hasText(strategyName))
/*     */     {
/*  88 */       strategyName = "MODE_THREADLOCAL";
/*     */     }
/*  90 */     if (strategyName.equals("MODE_THREADLOCAL")) {
/*  91 */       strategy = new ThreadLocalSecurityContextHolderStrategy();
/*     */       return;
/*     */     } 
/*  94 */     if (strategyName.equals("MODE_INHERITABLETHREADLOCAL")) {
/*  95 */       strategy = new InheritableThreadLocalSecurityContextHolderStrategy();
/*     */       return;
/*     */     } 
/*  98 */     if (strategyName.equals("MODE_GLOBAL")) {
/*  99 */       strategy = new GlobalSecurityContextHolderStrategy();
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/* 104 */       Class<?> clazz = Class.forName(strategyName);
/* 105 */       Constructor<?> customStrategy = clazz.getConstructor(new Class[0]);
/* 106 */       strategy = (SecurityContextHolderStrategy)customStrategy.newInstance(new Object[0]);
/*     */     }
/* 108 */     catch (Exception ex) {
/* 109 */       ReflectionUtils.handleReflectionException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clearContext() {
/* 117 */     strategy.clearContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SecurityContext getContext() {
/* 125 */     return strategy.getContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Supplier<SecurityContext> getDeferredContext() {
/* 135 */     return strategy.getDeferredContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getInitializeCount() {
/* 147 */     return initializeCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setContext(SecurityContext context) {
/* 155 */     strategy.setContext(context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setDeferredContext(Supplier<SecurityContext> deferredContext) {
/* 165 */     strategy.setDeferredContext(deferredContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setStrategyName(String strategyName) {
/* 176 */     SecurityContextHolder.strategyName = strategyName;
/* 177 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setContextHolderStrategy(SecurityContextHolderStrategy strategy) {
/* 209 */     Assert.notNull(strategy, "securityContextHolderStrategy cannot be null");
/* 210 */     strategyName = "MODE_PRE_INITIALIZED";
/* 211 */     SecurityContextHolder.strategy = strategy;
/* 212 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SecurityContextHolderStrategy getContextHolderStrategy() {
/* 220 */     return strategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SecurityContext createEmptyContext() {
/* 227 */     return strategy.createEmptyContext();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 232 */     return "SecurityContextHolder[strategy='" + strategy.getClass().getSimpleName() + "'; initializeCount=" + initializeCount + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\context\SecurityContextHolder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */