package org.springframework.security.core.context;

@FunctionalInterface
public interface SecurityContextChangedListener {
  void securityContextChanged(SecurityContextChangedEvent paramSecurityContextChangedEvent);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\context\SecurityContextChangedListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */