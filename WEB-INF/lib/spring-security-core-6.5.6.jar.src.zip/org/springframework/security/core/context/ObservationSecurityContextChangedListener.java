/*    */ package org.springframework.security.core.context;
/*    */ 
/*    */ import io.micrometer.observation.Observation;
/*    */ import io.micrometer.observation.ObservationRegistry;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ObservationSecurityContextChangedListener
/*    */   implements SecurityContextChangedListener
/*    */ {
/*    */   static final String SECURITY_CONTEXT_CREATED = "spring.security.context.created";
/*    */   static final String SECURITY_CONTEXT_CHANGED = "spring.security.context.changed";
/*    */   static final String SECURITY_CONTEXT_CLEARED = "spring.security.context.cleared";
/*    */   private final ObservationRegistry registry;
/*    */   
/*    */   public ObservationSecurityContextChangedListener(ObservationRegistry registry) {
/* 50 */     this.registry = registry;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void securityContextChanged(SecurityContextChangedEvent event) {
/* 58 */     Observation observation = this.registry.getCurrentObservation();
/* 59 */     if (observation == null) {
/*    */       return;
/*    */     }
/* 62 */     if (event.isCleared()) {
/* 63 */       observation.event(Observation.Event.of("spring.security.context.cleared"));
/*    */       return;
/*    */     } 
/* 66 */     Authentication oldAuthentication = getAuthentication(event.getOldContext());
/* 67 */     Authentication newAuthentication = getAuthentication(event.getNewContext());
/* 68 */     if (oldAuthentication == null && newAuthentication == null) {
/*    */       return;
/*    */     }
/* 71 */     if (oldAuthentication == null) {
/* 72 */       observation.event(Observation.Event.of("spring.security.context.created", "%s [%s]")
/* 73 */           .format(new Object[] { "spring.security.context.created", newAuthentication.getClass().getSimpleName() }));
/*    */       return;
/*    */     } 
/* 76 */     if (newAuthentication == null) {
/* 77 */       observation.event(Observation.Event.of("spring.security.context.cleared", "%s [%s]")
/* 78 */           .format(new Object[] { "spring.security.context.cleared", oldAuthentication.getClass().getSimpleName() }));
/*    */       return;
/*    */     } 
/* 81 */     if (oldAuthentication.equals(newAuthentication)) {
/*    */       return;
/*    */     }
/* 84 */     observation.event(Observation.Event.of("spring.security.context.changed", "%s [%s] -> [%s]")
/* 85 */         .format(new Object[] { "spring.security.context.changed", oldAuthentication.getClass().getSimpleName(), newAuthentication
/* 86 */             .getClass().getSimpleName() }));
/*    */   }
/*    */   
/*    */   private static Authentication getAuthentication(SecurityContext context) {
/* 90 */     if (context == null) {
/* 91 */       return null;
/*    */     }
/* 93 */     return context.getAuthentication();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\context\ObservationSecurityContextChangedListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */