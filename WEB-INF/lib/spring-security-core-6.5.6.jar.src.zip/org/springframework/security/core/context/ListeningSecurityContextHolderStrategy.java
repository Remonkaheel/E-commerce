/*     */ package org.springframework.security.core.context;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ListeningSecurityContextHolderStrategy
/*     */   implements SecurityContextHolderStrategy
/*     */ {
/*     */   private final Collection<SecurityContextChangedListener> listeners;
/*     */   private final SecurityContextHolderStrategy delegate;
/*     */   
/*     */   public ListeningSecurityContextHolderStrategy(Collection<SecurityContextChangedListener> listeners) {
/*  77 */     this(new ThreadLocalSecurityContextHolderStrategy(), listeners);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListeningSecurityContextHolderStrategy(SecurityContextChangedListener... listeners) {
/*  90 */     this(new ThreadLocalSecurityContextHolderStrategy(), listeners);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListeningSecurityContextHolderStrategy(SecurityContextHolderStrategy delegate, Collection<SecurityContextChangedListener> listeners) {
/* 102 */     Assert.notNull(delegate, "securityContextHolderStrategy cannot be null");
/* 103 */     Assert.notNull(listeners, "securityContextChangedListeners cannot be null");
/* 104 */     Assert.notEmpty(listeners, "securityContextChangedListeners cannot be empty");
/* 105 */     Assert.noNullElements(listeners, "securityContextChangedListeners cannot contain null elements");
/* 106 */     this.delegate = delegate;
/* 107 */     this.listeners = listeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListeningSecurityContextHolderStrategy(SecurityContextHolderStrategy delegate, SecurityContextChangedListener... listeners) {
/* 119 */     Assert.notNull(delegate, "securityContextHolderStrategy cannot be null");
/* 120 */     Assert.notNull(listeners, "securityContextChangedListeners cannot be null");
/* 121 */     Assert.notEmpty((Object[])listeners, "securityContextChangedListeners cannot be empty");
/* 122 */     Assert.noNullElements((Object[])listeners, "securityContextChangedListeners cannot contain null elements");
/* 123 */     this.delegate = delegate;
/* 124 */     this.listeners = Arrays.asList(listeners);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearContext() {
/* 132 */     Supplier<SecurityContext> deferred = this.delegate.getDeferredContext();
/* 133 */     this.delegate.clearContext();
/* 134 */     publish(new SecurityContextChangedEvent(deferred, SecurityContextChangedEvent.NO_CONTEXT));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SecurityContext getContext() {
/* 142 */     return this.delegate.getContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Supplier<SecurityContext> getDeferredContext() {
/* 150 */     return this.delegate.getDeferredContext();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContext(SecurityContext context) {
/* 158 */     setDeferredContext(() -> context);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDeferredContext(Supplier<SecurityContext> deferredContext) {
/* 166 */     this.delegate.setDeferredContext(new PublishOnceSupplier(getDeferredContext(), deferredContext));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SecurityContext createEmptyContext() {
/* 174 */     return this.delegate.createEmptyContext();
/*     */   }
/*     */   
/*     */   private void publish(SecurityContextChangedEvent event) {
/* 178 */     for (SecurityContextChangedListener listener : this.listeners)
/* 179 */       listener.securityContextChanged(event); 
/*     */   }
/*     */   
/*     */   class PublishOnceSupplier
/*     */     implements Supplier<SecurityContext>
/*     */   {
/* 185 */     private final AtomicBoolean isPublished = new AtomicBoolean(false);
/*     */     
/*     */     private final Supplier<SecurityContext> old;
/*     */     
/*     */     private final Supplier<SecurityContext> updated;
/*     */     
/*     */     PublishOnceSupplier(Supplier<SecurityContext> old, Supplier<SecurityContext> updated) {
/* 192 */       if (old instanceof PublishOnceSupplier) {
/* 193 */         this.old = ((PublishOnceSupplier)old).updated;
/*     */       } else {
/*     */         
/* 196 */         this.old = old;
/*     */       } 
/* 198 */       this.updated = updated;
/*     */     }
/*     */ 
/*     */     
/*     */     public SecurityContext get() {
/* 203 */       SecurityContext updated = this.updated.get();
/* 204 */       if (this.isPublished.compareAndSet(false, true)) {
/* 205 */         SecurityContext old = this.old.get();
/* 206 */         if (old != updated) {
/* 207 */           ListeningSecurityContextHolderStrategy.this.publish(new SecurityContextChangedEvent(old, updated));
/*     */         }
/*     */       } 
/* 210 */       return updated;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\context\ListeningSecurityContextHolderStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */