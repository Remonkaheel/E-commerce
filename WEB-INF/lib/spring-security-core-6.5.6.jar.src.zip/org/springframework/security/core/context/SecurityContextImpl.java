/*    */ package org.springframework.security.core.context;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecurityContextImpl
/*    */   implements SecurityContext
/*    */ {
/*    */   private static final long serialVersionUID = 620L;
/*    */   private Authentication authentication;
/*    */   
/*    */   public SecurityContextImpl() {}
/*    */   
/*    */   public SecurityContextImpl(Authentication authentication) {
/* 40 */     this.authentication = authentication;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 45 */     if (obj instanceof SecurityContextImpl) { SecurityContextImpl other = (SecurityContextImpl)obj;
/* 46 */       if (getAuthentication() == null && other.getAuthentication() == null) {
/* 47 */         return true;
/*    */       }
/* 49 */       if (getAuthentication() != null && other.getAuthentication() != null && 
/* 50 */         getAuthentication().equals(other.getAuthentication())) {
/* 51 */         return true;
/*    */       } }
/*    */     
/* 54 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public Authentication getAuthentication() {
/* 59 */     return this.authentication;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 64 */     return ObjectUtils.nullSafeHashCode(this.authentication);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setAuthentication(Authentication authentication) {
/* 69 */     this.authentication = authentication;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 74 */     StringBuilder sb = new StringBuilder();
/* 75 */     sb.append(getClass().getSimpleName()).append(" [");
/* 76 */     if (this.authentication == null) {
/* 77 */       sb.append("Null authentication");
/*    */     } else {
/*    */       
/* 80 */       sb.append("Authentication=").append(this.authentication);
/*    */     } 
/* 82 */     sb.append("]");
/* 83 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\context\SecurityContextImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */