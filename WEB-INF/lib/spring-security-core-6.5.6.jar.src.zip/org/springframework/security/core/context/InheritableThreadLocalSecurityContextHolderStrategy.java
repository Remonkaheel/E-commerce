/*    */ package org.springframework.security.core.context;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class InheritableThreadLocalSecurityContextHolderStrategy
/*    */   implements SecurityContextHolderStrategy
/*    */ {
/* 33 */   private static final ThreadLocal<Supplier<SecurityContext>> contextHolder = new InheritableThreadLocal<>();
/*    */ 
/*    */   
/*    */   public void clearContext() {
/* 37 */     contextHolder.remove();
/*    */   }
/*    */ 
/*    */   
/*    */   public SecurityContext getContext() {
/* 42 */     return getDeferredContext().get();
/*    */   }
/*    */ 
/*    */   
/*    */   public Supplier<SecurityContext> getDeferredContext() {
/* 47 */     Supplier<SecurityContext> result = contextHolder.get();
/* 48 */     if (result == null) {
/* 49 */       SecurityContext context = createEmptyContext();
/* 50 */       result = (() -> context);
/* 51 */       contextHolder.set(result);
/*    */     } 
/* 53 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setContext(SecurityContext context) {
/* 58 */     Assert.notNull(context, "Only non-null SecurityContext instances are permitted");
/* 59 */     contextHolder.set(() -> context);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setDeferredContext(Supplier<SecurityContext> deferredContext) {
/* 64 */     Assert.notNull(deferredContext, "Only non-null Supplier instances are permitted");
/* 65 */     Supplier<SecurityContext> notNullDeferredContext = () -> {
/*    */         SecurityContext result = deferredContext.get();
/*    */         Assert.notNull(result, "A Supplier<SecurityContext> returned null and is not allowed.");
/*    */         return result;
/*    */       };
/* 70 */     contextHolder.set(notNullDeferredContext);
/*    */   }
/*    */ 
/*    */   
/*    */   public SecurityContext createEmptyContext() {
/* 75 */     return new SecurityContextImpl();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\context\InheritableThreadLocalSecurityContextHolderStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */