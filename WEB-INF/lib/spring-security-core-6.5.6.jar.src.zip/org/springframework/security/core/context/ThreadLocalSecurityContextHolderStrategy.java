/*    */ package org.springframework.security.core.context;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ThreadLocalSecurityContextHolderStrategy
/*    */   implements SecurityContextHolderStrategy
/*    */ {
/* 34 */   private static final ThreadLocal<Supplier<SecurityContext>> contextHolder = new ThreadLocal<>();
/*    */ 
/*    */   
/*    */   public void clearContext() {
/* 38 */     contextHolder.remove();
/*    */   }
/*    */ 
/*    */   
/*    */   public SecurityContext getContext() {
/* 43 */     return getDeferredContext().get();
/*    */   }
/*    */ 
/*    */   
/*    */   public Supplier<SecurityContext> getDeferredContext() {
/* 48 */     Supplier<SecurityContext> result = contextHolder.get();
/* 49 */     if (result == null) {
/* 50 */       SecurityContext context = createEmptyContext();
/* 51 */       result = (() -> context);
/* 52 */       contextHolder.set(result);
/*    */     } 
/* 54 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setContext(SecurityContext context) {
/* 59 */     Assert.notNull(context, "Only non-null SecurityContext instances are permitted");
/* 60 */     contextHolder.set(() -> context);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setDeferredContext(Supplier<SecurityContext> deferredContext) {
/* 65 */     Assert.notNull(deferredContext, "Only non-null Supplier instances are permitted");
/* 66 */     Supplier<SecurityContext> notNullDeferredContext = () -> {
/*    */         SecurityContext result = deferredContext.get();
/*    */         Assert.notNull(result, "A Supplier<SecurityContext> returned null and is not allowed.");
/*    */         return result;
/*    */       };
/* 71 */     contextHolder.set(notNullDeferredContext);
/*    */   }
/*    */ 
/*    */   
/*    */   public SecurityContext createEmptyContext() {
/* 76 */     return new SecurityContextImpl();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\context\ThreadLocalSecurityContextHolderStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */