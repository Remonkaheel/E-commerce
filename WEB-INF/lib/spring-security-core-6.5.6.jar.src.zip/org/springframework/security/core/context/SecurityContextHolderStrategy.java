/*    */ package org.springframework.security.core.context;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SecurityContextHolderStrategy
/*    */ {
/*    */   void clearContext();
/*    */   
/*    */   SecurityContext getContext();
/*    */   
/*    */   default Supplier<SecurityContext> getDeferredContext() {
/* 51 */     return this::getContext;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void setContext(SecurityContext paramSecurityContext);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default void setDeferredContext(Supplier<SecurityContext> deferredContext) {
/* 69 */     setContext(deferredContext.get());
/*    */   }
/*    */   
/*    */   SecurityContext createEmptyContext();
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\context\SecurityContextHolderStrategy.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */