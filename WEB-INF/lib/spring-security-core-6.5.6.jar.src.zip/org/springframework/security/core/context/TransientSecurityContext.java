/*    */ package org.springframework.security.core.context;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.Transient;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Transient
/*    */ public class TransientSecurityContext
/*    */   extends SecurityContextImpl
/*    */ {
/*    */   private static final long serialVersionUID = -7925492364422193347L;
/*    */   
/*    */   public TransientSecurityContext() {}
/*    */   
/*    */   public TransientSecurityContext(Authentication authentication) {
/* 42 */     super(authentication);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\context\TransientSecurityContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */