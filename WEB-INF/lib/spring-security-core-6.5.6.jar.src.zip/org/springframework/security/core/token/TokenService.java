package org.springframework.security.core.token;

public interface TokenService {
  Token allocateToken(String paramString);
  
  Token verifyToken(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\token\TokenService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */