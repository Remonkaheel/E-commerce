/*    */ package org.springframework.security.core.token;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultToken
/*    */   implements Token
/*    */ {
/*    */   private final String key;
/*    */   private final long keyCreationTime;
/*    */   private final String extendedInformation;
/*    */   
/*    */   public DefaultToken(String key, long keyCreationTime, String extendedInformation) {
/* 38 */     Assert.hasText(key, "Key required");
/* 39 */     Assert.notNull(extendedInformation, "Extended information cannot be null");
/* 40 */     this.key = key;
/* 41 */     this.keyCreationTime = keyCreationTime;
/* 42 */     this.extendedInformation = extendedInformation;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getKey() {
/* 47 */     return this.key;
/*    */   }
/*    */ 
/*    */   
/*    */   public long getKeyCreationTime() {
/* 52 */     return this.keyCreationTime;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getExtendedInformation() {
/* 57 */     return this.extendedInformation;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 62 */     if (obj instanceof DefaultToken) { DefaultToken rhs = (DefaultToken)obj;
/* 63 */       return (this.key.equals(rhs.key) && this.keyCreationTime == rhs.keyCreationTime && this.extendedInformation
/* 64 */         .equals(rhs.extendedInformation)); }
/*    */     
/* 66 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 71 */     int code = 979;
/* 72 */     code *= this.key.hashCode();
/* 73 */     code *= Long.valueOf(this.keyCreationTime).hashCode();
/* 74 */     code *= this.extendedInformation.hashCode();
/* 75 */     return code;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 80 */     return "DefaultToken[key=" + this.key + "; creation=" + String.valueOf(new Date(this.keyCreationTime)) + "; extended=" + this.extendedInformation + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\token\DefaultToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */