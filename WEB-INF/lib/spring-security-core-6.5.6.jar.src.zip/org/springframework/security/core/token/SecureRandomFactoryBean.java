/*    */ package org.springframework.security.core.token;
/*    */ 
/*    */ import java.security.SecureRandom;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.FileCopyUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecureRandomFactoryBean
/*    */   implements FactoryBean<SecureRandom>
/*    */ {
/* 35 */   private String algorithm = "SHA1PRNG";
/*    */   
/*    */   private Resource seed;
/*    */ 
/*    */   
/*    */   public SecureRandom getObject() throws Exception {
/* 41 */     SecureRandom random = SecureRandom.getInstance(this.algorithm);
/*    */ 
/*    */     
/* 44 */     random.nextBytes(new byte[1]);
/* 45 */     if (this.seed != null) {
/*    */       
/* 47 */       byte[] seedBytes = FileCopyUtils.copyToByteArray(this.seed.getInputStream());
/* 48 */       random.setSeed(seedBytes);
/*    */     } 
/* 50 */     return random;
/*    */   }
/*    */ 
/*    */   
/*    */   public Class<SecureRandom> getObjectType() {
/* 55 */     return SecureRandom.class;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isSingleton() {
/* 60 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAlgorithm(String algorithm) {
/* 69 */     Assert.hasText(algorithm, "Algorithm required");
/* 70 */     this.algorithm = algorithm;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSeed(Resource seed) {
/* 83 */     this.seed = seed;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\token\SecureRandomFactoryBean.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */