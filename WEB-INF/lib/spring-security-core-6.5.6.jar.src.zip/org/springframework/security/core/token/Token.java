package org.springframework.security.core.token;

public interface Token {
  String getKey();
  
  long getKeyCreationTime();
  
  String getExtendedInformation();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\token\Token.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */