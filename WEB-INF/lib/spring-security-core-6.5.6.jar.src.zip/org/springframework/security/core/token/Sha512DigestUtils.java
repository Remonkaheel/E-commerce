/*    */ package org.springframework.security.core.token;
/*    */ 
/*    */ import java.security.MessageDigest;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import org.springframework.security.crypto.codec.Hex;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Sha512DigestUtils
/*    */ {
/*    */   private static MessageDigest getSha512Digest() {
/*    */     try {
/* 45 */       return MessageDigest.getInstance("SHA-512");
/*    */     }
/* 47 */     catch (NoSuchAlgorithmException ex) {
/* 48 */       throw new RuntimeException(ex.getMessage());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static byte[] sha(byte[] data) {
/* 58 */     return getSha512Digest().digest(data);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static byte[] sha(String data) {
/* 67 */     return sha(data.getBytes());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String shaHex(byte[] data) {
/* 76 */     return new String(Hex.encode(sha(data)));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String shaHex(String data) {
/* 85 */     return new String(Hex.encode(sha(data)));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\token\Sha512DigestUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */