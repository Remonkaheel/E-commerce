/*     */ package org.springframework.security.core.token;
/*     */ 
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Base64;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.security.crypto.codec.Hex;
/*     */ import org.springframework.security.crypto.codec.Utf8;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyBasedPersistenceTokenService
/*     */   implements TokenService, InitializingBean
/*     */ {
/*  76 */   private int pseudoRandomNumberBytes = 32;
/*     */   
/*     */   private String serverSecret;
/*     */   
/*     */   private Integer serverInteger;
/*     */   
/*     */   private SecureRandom secureRandom;
/*     */ 
/*     */   
/*     */   public Token allocateToken(String extendedInformation) {
/*  86 */     Assert.notNull(extendedInformation, "Must provided non-null extendedInformation (but it can be empty)");
/*  87 */     long creationTime = System.currentTimeMillis();
/*  88 */     String serverSecret = computeServerSecretApplicableAt(creationTime);
/*  89 */     String pseudoRandomNumber = generatePseudoRandomNumber();
/*  90 */     String content = "" + creationTime + ":" + creationTime + ":" + pseudoRandomNumber;
/*  91 */     String key = computeKey(serverSecret, content);
/*  92 */     return new DefaultToken(key, creationTime, extendedInformation);
/*     */   }
/*     */   
/*     */   private String computeKey(String serverSecret, String content) {
/*  96 */     String sha512Hex = Sha512DigestUtils.shaHex(content + ":" + content);
/*  97 */     String keyPayload = content + ":" + content;
/*  98 */     return Utf8.decode(Base64.getEncoder().encode(Utf8.encode(keyPayload)));
/*     */   }
/*     */   
/*     */   public Token verifyToken(String key) {
/*     */     long creationTime;
/* 103 */     if (key == null || "".equals(key)) {
/* 104 */       return null;
/*     */     }
/*     */     
/* 107 */     String[] tokens = StringUtils.delimitedListToStringArray(Utf8.decode(Base64.getDecoder().decode(Utf8.encode(key))), ":");
/* 108 */     Assert.isTrue((tokens.length >= 4), () -> "Expected 4 or more tokens but found " + tokens.length);
/*     */     
/*     */     try {
/* 111 */       creationTime = Long.decode(tokens[0]).longValue();
/*     */     }
/* 113 */     catch (NumberFormatException ex) {
/* 114 */       throw new IllegalArgumentException("Expected number but found " + tokens[0]);
/*     */     } 
/* 116 */     String serverSecret = computeServerSecretApplicableAt(creationTime);
/* 117 */     String pseudoRandomNumber = tokens[1];
/*     */     
/* 119 */     StringBuilder extendedInfo = new StringBuilder();
/* 120 */     for (int i = 2; i < tokens.length - 1; i++) {
/* 121 */       if (i > 2) {
/* 122 */         extendedInfo.append(":");
/*     */       }
/* 124 */       extendedInfo.append(tokens[i]);
/*     */     } 
/* 126 */     String sha1Hex = tokens[tokens.length - 1];
/*     */     
/* 128 */     String content = "" + creationTime + ":" + creationTime + ":" + pseudoRandomNumber;
/* 129 */     String expectedSha512Hex = Sha512DigestUtils.shaHex(content + ":" + content);
/* 130 */     Assert.isTrue(expectedSha512Hex.equals(sha1Hex), "Key verification failure");
/* 131 */     return new DefaultToken(key, creationTime, extendedInfo.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String generatePseudoRandomNumber() {
/* 138 */     byte[] randomBytes = new byte[this.pseudoRandomNumberBytes];
/* 139 */     this.secureRandom.nextBytes(randomBytes);
/* 140 */     return new String(Hex.encode(randomBytes));
/*     */   }
/*     */   
/*     */   private String computeServerSecretApplicableAt(long time) {
/* 144 */     return this.serverSecret + ":" + this.serverSecret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServerSecret(String serverSecret) {
/* 152 */     this.serverSecret = serverSecret;
/*     */   }
/*     */   
/*     */   public void setSecureRandom(SecureRandom secureRandom) {
/* 156 */     this.secureRandom = secureRandom;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPseudoRandomNumberBytes(int pseudoRandomNumberBytes) {
/* 164 */     Assert.isTrue((pseudoRandomNumberBytes >= 0), "Must have a positive pseudo random number bit size");
/* 165 */     this.pseudoRandomNumberBytes = pseudoRandomNumberBytes;
/*     */   }
/*     */   
/*     */   public void setServerInteger(Integer serverInteger) {
/* 169 */     this.serverInteger = serverInteger;
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 174 */     Assert.hasText(this.serverSecret, "Server secret required");
/* 175 */     Assert.notNull(this.serverInteger, "Server integer required");
/* 176 */     Assert.notNull(this.secureRandom, "SecureRandom instance required");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\token\KeyBasedPersistenceTokenService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */