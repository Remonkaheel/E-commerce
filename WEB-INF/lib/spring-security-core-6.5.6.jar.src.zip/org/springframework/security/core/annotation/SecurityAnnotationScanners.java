/*    */ package org.springframework.security.core.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SecurityAnnotationScanners
/*    */ {
/* 34 */   private static final Map<Class<? extends Annotation>, SecurityAnnotationScanner<? extends Annotation>> uniqueScanners = new ConcurrentHashMap<>();
/*    */   
/* 36 */   private static final Map<Class<? extends Annotation>, SecurityAnnotationScanner<? extends Annotation>> uniqueTemplateScanners = new ConcurrentHashMap<>();
/*    */   
/* 38 */   private static final Map<List<Class<? extends Annotation>>, SecurityAnnotationScanner<? extends Annotation>> uniqueTypesScanners = new ConcurrentHashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <A extends Annotation> SecurityAnnotationScanner<A> requireUnique(Class<A> type) {
/* 51 */     return (SecurityAnnotationScanner<A>)uniqueScanners.computeIfAbsent(type, t -> new UniqueSecurityAnnotationScanner<>(type));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <A extends Annotation> SecurityAnnotationScanner<A> requireUnique(Class<A> type, AnnotationTemplateExpressionDefaults templateDefaults) {
/* 71 */     if (templateDefaults == null) {
/* 72 */       return requireUnique(type);
/*    */     }
/* 74 */     return (SecurityAnnotationScanner<A>)uniqueTemplateScanners.computeIfAbsent(type, t -> new ExpressionTemplateSecurityAnnotationScanner<>(t, templateDefaults));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static SecurityAnnotationScanner<Annotation> requireUnique(List<Class<? extends Annotation>> types) {
/* 86 */     List<Class<Annotation>> casted = new ArrayList<>();
/* 87 */     types.forEach(type -> casted.add(type));
/* 88 */     return (SecurityAnnotationScanner<Annotation>)uniqueTypesScanners.computeIfAbsent(types, t -> new UniqueSecurityAnnotationScanner<>(casted));
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\annotation\SecurityAnnotationScanners.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */