package org.springframework.security.core.annotation;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import org.springframework.lang.Nullable;

public interface SecurityAnnotationScanner<A extends java.lang.annotation.Annotation> {
  @Nullable
  A scan(Method paramMethod, Class<?> paramClass);
  
  @Nullable
  A scan(Parameter paramParameter);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\annotation\SecurityAnnotationScanner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */