/*     */ package org.springframework.security.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Executable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.Parameter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.core.MethodClassKey;
/*     */ import org.springframework.core.ResolvableType;
/*     */ import org.springframework.core.annotation.AnnotationConfigurationException;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.annotation.MergedAnnotations;
/*     */ import org.springframework.core.annotation.RepeatableContainers;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class UniqueSecurityAnnotationScanner<A extends Annotation>
/*     */   extends AbstractSecurityAnnotationScanner<A>
/*     */ {
/*     */   private final List<Class<A>> types;
/*  97 */   private final Map<Parameter, MergedAnnotation<A>> uniqueParameterAnnotationCache = new ConcurrentHashMap<>();
/*     */   
/*  99 */   private final Map<MethodClassKey, MergedAnnotation<A>> uniqueMethodAnnotationCache = new ConcurrentHashMap<>();
/*     */   
/*     */   UniqueSecurityAnnotationScanner(Class<A> type) {
/* 102 */     Assert.notNull(type, "type cannot be null");
/* 103 */     this.types = List.of(type);
/*     */   }
/*     */   
/*     */   UniqueSecurityAnnotationScanner(List<Class<A>> types) {
/* 107 */     Assert.notNull(types, "types cannot be null");
/* 108 */     this.types = types;
/*     */   }
/*     */ 
/*     */   
/*     */   MergedAnnotation<A> merge(AnnotatedElement element, Class<?> targetClass) {
/* 113 */     if (element instanceof Parameter) { Parameter parameter = (Parameter)element;
/* 114 */       return this.uniqueParameterAnnotationCache.computeIfAbsent(parameter, p -> {
/*     */             List<MergedAnnotation<A>> annotations = findParameterAnnotations(p);
/*     */             return requireUnique(p, annotations);
/*     */           }); }
/*     */     
/* 119 */     if (element instanceof Method) { Method method = (Method)element;
/* 120 */       return this.uniqueMethodAnnotationCache.computeIfAbsent(new MethodClassKey(method, targetClass), k -> {
/*     */             List<MergedAnnotation<A>> annotations = findMethodAnnotations(method, targetClass);
/*     */             return requireUnique(method, annotations);
/*     */           }); }
/*     */     
/* 125 */     throw new AnnotationConfigurationException("Unsupported element of type " + String.valueOf(element.getClass()));
/*     */   }
/*     */   
/*     */   private MergedAnnotation<A> requireUnique(AnnotatedElement element, List<MergedAnnotation<A>> annotations) {
/* 129 */     switch (annotations.size()) { case 0:
/*     */       
/*     */       case 1:
/*     */        }
/* 133 */      List<Annotation> synthesized = new ArrayList<>();
/* 134 */     for (MergedAnnotation<A> annotation : annotations) {
/* 135 */       synthesized.add(annotation.synthesize());
/*     */     }
/* 137 */     throw new AnnotationConfigurationException("Please ensure there is one unique annotation of type %s attributed to %s. Found %d competing annotations: %s"
/*     */         
/* 139 */         .formatted(new Object[] { this.types, element, Integer.valueOf(annotations.size()), synthesized }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<MergedAnnotation<A>> findParameterAnnotations(Parameter current) {
/* 146 */     List<MergedAnnotation<A>> directAnnotations = findDirectAnnotations(current);
/* 147 */     if (!directAnnotations.isEmpty()) {
/* 148 */       return directAnnotations;
/*     */     }
/* 150 */     Executable executable = current.getDeclaringExecutable();
/* 151 */     if (executable instanceof Method) { Method method = (Method)executable;
/* 152 */       directAnnotations = findClosestParameterAnnotations(method, method.getDeclaringClass(), current, new HashSet<>());
/*     */       
/* 154 */       if (!directAnnotations.isEmpty()) {
/* 155 */         return directAnnotations;
/*     */       } }
/*     */     
/* 158 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   private List<MergedAnnotation<A>> findClosestParameterAnnotations(Method method, Class<?> clazz, Parameter current, Set<Class<?>> visited) {
/* 163 */     if (clazz == null || clazz == Object.class || !visited.add(clazz)) {
/* 164 */       return Collections.emptyList();
/*     */     }
/* 166 */     List<MergedAnnotation<A>> directAnnotations = findDirectParameterAnnotations(method, clazz, current);
/* 167 */     if (!directAnnotations.isEmpty()) {
/* 168 */       return directAnnotations;
/*     */     }
/*     */     
/* 171 */     List<MergedAnnotation<A>> annotations = new ArrayList<>(findClosestParameterAnnotations(method, clazz.getSuperclass(), current, visited));
/* 172 */     for (Class<?> ifc : clazz.getInterfaces()) {
/* 173 */       annotations.addAll(findClosestParameterAnnotations(method, ifc, current, visited));
/*     */     }
/* 175 */     return annotations;
/*     */   }
/*     */   
/*     */   private List<MergedAnnotation<A>> findDirectParameterAnnotations(Method method, Class<?> clazz, Parameter current) {
/*     */     try {
/* 180 */       Method methodToUse = clazz.getDeclaredMethod(method.getName(), method.getParameterTypes());
/* 181 */       for (Parameter parameter : methodToUse.getParameters()) {
/* 182 */         if (parameter.getName().equals(current.getName())) {
/* 183 */           List<MergedAnnotation<A>> directAnnotations = findDirectAnnotations(parameter);
/* 184 */           if (!directAnnotations.isEmpty()) {
/* 185 */             return directAnnotations;
/*     */           }
/*     */         }
/*     */       
/*     */       } 
/* 190 */     } catch (NoSuchMethodException noSuchMethodException) {}
/*     */ 
/*     */     
/* 193 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<MergedAnnotation<A>> findMethodAnnotations(Method method, Class<?> targetClass) {
/* 200 */     Method specificMethod = ClassUtils.getMostSpecificMethod(method, targetClass);
/* 201 */     List<MergedAnnotation<A>> annotations = findClosestMethodAnnotations(specificMethod, specificMethod
/* 202 */         .getDeclaringClass(), new HashSet<>());
/* 203 */     if (!annotations.isEmpty()) {
/* 204 */       return annotations;
/*     */     }
/*     */     
/* 207 */     if (specificMethod != method) {
/* 208 */       annotations = findClosestMethodAnnotations(method, method.getDeclaringClass(), new HashSet<>());
/* 209 */       if (!annotations.isEmpty()) {
/* 210 */         return annotations;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 215 */     annotations = findClosestClassAnnotations(specificMethod.getDeclaringClass(), new HashSet<>());
/* 216 */     if (!annotations.isEmpty()) {
/* 217 */       return annotations;
/*     */     }
/* 219 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */   
/*     */   private List<MergedAnnotation<A>> findClosestMethodAnnotations(Method method, Class<?> targetClass, Set<Class<?>> classesToSkip) {
/* 224 */     if (targetClass == null || classesToSkip.contains(targetClass) || targetClass == Object.class) {
/* 225 */       return Collections.emptyList();
/*     */     }
/* 227 */     classesToSkip.add(targetClass);
/* 228 */     Method methodToUse = findMethod(method, targetClass);
/* 229 */     if (methodToUse != null) {
/* 230 */       List<MergedAnnotation<A>> list = findDirectAnnotations(methodToUse);
/* 231 */       if (!list.isEmpty()) {
/* 232 */         return list;
/*     */       }
/*     */     } 
/*     */     
/* 236 */     List<MergedAnnotation<A>> annotations = new ArrayList<>(findClosestMethodAnnotations(method, targetClass.getSuperclass(), classesToSkip));
/* 237 */     for (Class<?> inter : targetClass.getInterfaces()) {
/* 238 */       annotations.addAll(findClosestMethodAnnotations(method, inter, classesToSkip));
/*     */     }
/* 240 */     return annotations;
/*     */   }
/*     */   
/*     */   private List<MergedAnnotation<A>> findClosestClassAnnotations(Class<?> targetClass, Set<Class<?>> classesToSkip) {
/* 244 */     if (targetClass == null || classesToSkip.contains(targetClass) || targetClass == Object.class) {
/* 245 */       return Collections.emptyList();
/*     */     }
/* 247 */     classesToSkip.add(targetClass);
/* 248 */     List<MergedAnnotation<A>> annotations = new ArrayList<>(findDirectAnnotations(targetClass));
/* 249 */     if (!annotations.isEmpty()) {
/* 250 */       return annotations;
/*     */     }
/* 252 */     annotations.addAll(findClosestClassAnnotations(targetClass.getSuperclass(), classesToSkip));
/* 253 */     for (Class<?> inter : targetClass.getInterfaces()) {
/* 254 */       annotations.addAll(findClosestClassAnnotations(inter, classesToSkip));
/*     */     }
/* 256 */     return annotations;
/*     */   }
/*     */   
/*     */   private List<MergedAnnotation<A>> findDirectAnnotations(AnnotatedElement element) {
/* 260 */     MergedAnnotations mergedAnnotations = MergedAnnotations.from(element, MergedAnnotations.SearchStrategy.DIRECT, 
/* 261 */         RepeatableContainers.none());
/* 262 */     return mergedAnnotations.stream()
/* 263 */       .filter(annotation -> this.types.contains(annotation.getType()))
/* 264 */       .map(annotation -> annotation)
/* 265 */       .toList();
/*     */   }
/*     */   
/*     */   private static Method findMethod(Method method, Class<?> targetClass) {
/* 269 */     for (Method candidate : targetClass.getDeclaredMethods()) {
/* 270 */       if (candidate.equals(method)) {
/* 271 */         return candidate;
/*     */       }
/* 273 */       if (isOverride(method, candidate)) {
/* 274 */         return candidate;
/*     */       }
/*     */     } 
/* 277 */     return null;
/*     */   }
/*     */   
/*     */   private static boolean isOverride(Method rootMethod, Method candidateMethod) {
/* 281 */     return (!Modifier.isPrivate(candidateMethod.getModifiers()) && candidateMethod
/* 282 */       .getName().equals(rootMethod.getName()) && 
/* 283 */       hasSameParameterTypes(rootMethod, candidateMethod));
/*     */   }
/*     */   
/*     */   private static boolean hasSameParameterTypes(Method rootMethod, Method candidateMethod) {
/* 287 */     if (candidateMethod.getParameterCount() != rootMethod.getParameterCount()) {
/* 288 */       return false;
/*     */     }
/* 290 */     Class<?>[] rootParameterTypes = rootMethod.getParameterTypes();
/* 291 */     Class<?>[] candidateParameterTypes = candidateMethod.getParameterTypes();
/* 292 */     if (Arrays.equals((Object[])candidateParameterTypes, (Object[])rootParameterTypes)) {
/* 293 */       return true;
/*     */     }
/* 295 */     return hasSameGenericTypeParameters(rootMethod, candidateMethod, rootParameterTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean hasSameGenericTypeParameters(Method rootMethod, Method candidateMethod, Class<?>[] rootParameterTypes) {
/* 301 */     Class<?> sourceDeclaringClass = rootMethod.getDeclaringClass();
/* 302 */     Class<?> candidateDeclaringClass = candidateMethod.getDeclaringClass();
/* 303 */     if (!candidateDeclaringClass.isAssignableFrom(sourceDeclaringClass)) {
/* 304 */       return false;
/*     */     }
/* 306 */     for (int i = 0; i < rootParameterTypes.length; i++) {
/*     */       
/* 308 */       Class<?> resolvedParameterType = ResolvableType.forMethodParameter(candidateMethod, i, sourceDeclaringClass).toClass();
/* 309 */       if (rootParameterTypes[i] != resolvedParameterType) {
/* 310 */         return false;
/*     */       }
/*     */     } 
/* 313 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\annotation\UniqueSecurityAnnotationScanner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */