/*     */ package org.springframework.security.core.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Parameter;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.annotation.MergedAnnotation;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.convert.support.DefaultConversionService;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PropertyPlaceholderHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ExpressionTemplateSecurityAnnotationScanner<A extends Annotation>
/*     */   extends AbstractSecurityAnnotationScanner<A>
/*     */ {
/*  71 */   private static final DefaultConversionService conversionService = new DefaultConversionService();
/*     */   
/*     */   static {
/*  74 */     conversionService.addConverter(new ClassToStringConverter());
/*     */   }
/*     */ 
/*     */   
/*     */   private final Class<A> type;
/*     */   
/*     */   private final UniqueSecurityAnnotationScanner<A> unique;
/*     */   private final AnnotationTemplateExpressionDefaults templateDefaults;
/*     */   
/*     */   ExpressionTemplateSecurityAnnotationScanner(Class<A> type, AnnotationTemplateExpressionDefaults templateDefaults) {
/*  84 */     Assert.notNull(type, "type cannot be null");
/*  85 */     Assert.notNull(templateDefaults, "templateDefaults cannot be null");
/*  86 */     this.type = type;
/*  87 */     this.unique = new UniqueSecurityAnnotationScanner<>(type);
/*  88 */     this.templateDefaults = templateDefaults;
/*     */   }
/*     */ 
/*     */   
/*     */   MergedAnnotation<A> merge(AnnotatedElement element, Class<?> targetClass) {
/*  93 */     if (element instanceof Parameter) { Parameter parameter = (Parameter)element;
/*  94 */       MergedAnnotation<A> annotation = this.unique.merge(parameter, targetClass);
/*  95 */       if (annotation == null) {
/*  96 */         return null;
/*     */       }
/*  98 */       return resolvePlaceholders(annotation); }
/*     */     
/* 100 */     if (element instanceof Method) { Method method = (Method)element;
/* 101 */       MergedAnnotation<A> annotation = this.unique.merge(method, targetClass);
/* 102 */       if (annotation == null) {
/* 103 */         return null;
/*     */       }
/* 105 */       return resolvePlaceholders(annotation); }
/*     */     
/* 107 */     throw new IllegalArgumentException("Unsupported element of type " + String.valueOf(element.getClass()));
/*     */   }
/*     */   
/*     */   private MergedAnnotation<A> resolvePlaceholders(MergedAnnotation<A> mergedAnnotation) {
/* 111 */     if (this.templateDefaults == null) {
/* 112 */       return mergedAnnotation;
/*     */     }
/* 114 */     if (mergedAnnotation.getMetaSource() == null) {
/* 115 */       return mergedAnnotation;
/*     */     }
/*     */     
/* 118 */     PropertyPlaceholderHelper helper = new PropertyPlaceholderHelper("{", "}", null, null, this.templateDefaults.isIgnoreUnknown());
/* 119 */     Map<String, Object> properties = new HashMap<>(mergedAnnotation.asMap(new MergedAnnotation.Adapt[0]));
/* 120 */     Map<String, String> metaAnnotationProperties = extractMetaAnnotationProperties(mergedAnnotation);
/* 121 */     for (Map.Entry<String, Object> annotationProperty : (Iterable<Map.Entry<String, Object>>)mergedAnnotation.asMap(new MergedAnnotation.Adapt[0]).entrySet()) {
/* 122 */       Object object = annotationProperty.getValue(); if (object instanceof String) { String expression = (String)object;
/*     */ 
/*     */         
/* 125 */         Objects.requireNonNull(metaAnnotationProperties); String value = helper.replacePlaceholders(expression, metaAnnotationProperties::get);
/* 126 */         properties.put(annotationProperty.getKey(), value); }
/*     */     
/* 128 */     }  AnnotatedElement annotatedElement = (AnnotatedElement)mergedAnnotation.getSource();
/* 129 */     return MergedAnnotation.of(annotatedElement, this.type, properties);
/*     */   }
/*     */   
/*     */   private Map<String, String> extractMetaAnnotationProperties(MergedAnnotation<A> mergedAnnotation) {
/* 133 */     Map<String, String> stringProperties = new HashMap<>();
/* 134 */     Map<String, Object> metaAnnotationProperties = new HashMap<>();
/* 135 */     MergedAnnotation<?> metaSource = mergedAnnotation.getMetaSource();
/* 136 */     while (metaSource != null) {
/* 137 */       metaAnnotationProperties.putAll(metaSource.asMap(new MergedAnnotation.Adapt[0]));
/* 138 */       metaSource = metaSource.getMetaSource();
/*     */     } 
/* 140 */     for (Map.Entry<String, Object> property : metaAnnotationProperties.entrySet()) {
/* 141 */       Object value = property.getValue();
/*     */       
/* 143 */       String valueString = (value instanceof String) ? (String)value : (String)conversionService.convert(value, String.class);
/* 144 */       stringProperties.put(property.getKey(), valueString);
/*     */     } 
/* 146 */     return stringProperties;
/*     */   }
/*     */   
/*     */   static class ClassToStringConverter
/*     */     implements GenericConverter
/*     */   {
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 153 */       return Collections.singleton(new GenericConverter.ConvertiblePair(Class.class, String.class));
/*     */     }
/*     */ 
/*     */     
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 158 */       return (source != null) ? source.toString() : null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\annotation\ExpressionTemplateSecurityAnnotationScanner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */