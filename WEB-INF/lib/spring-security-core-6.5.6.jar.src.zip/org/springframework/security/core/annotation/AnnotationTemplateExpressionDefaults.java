/*    */ package org.springframework.security.core.annotation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnotationTemplateExpressionDefaults
/*    */ {
/*    */   private boolean ignoreUnknown = true;
/*    */   
/*    */   public boolean isIgnoreUnknown() {
/* 38 */     return this.ignoreUnknown;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setIgnoreUnknown(boolean ignoreUnknown) {
/* 50 */     this.ignoreUnknown = ignoreUnknown;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\annotation\AnnotationTemplateExpressionDefaults.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */