/*    */ package org.springframework.security.core.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.AnnotatedElement;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Parameter;
/*    */ import org.springframework.core.annotation.MergedAnnotation;
/*    */ import org.springframework.lang.Nullable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractSecurityAnnotationScanner<A extends Annotation>
/*    */   implements SecurityAnnotationScanner<A>
/*    */ {
/*    */   @Nullable
/*    */   public A scan(Method method, Class<?> targetClass) {
/* 43 */     Assert.notNull(targetClass, "targetClass cannot be null");
/* 44 */     MergedAnnotation<A> annotation = merge(method, targetClass);
/* 45 */     if (annotation == null) {
/* 46 */       return null;
/*    */     }
/* 48 */     return (A)annotation.synthesize();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Nullable
/*    */   public A scan(Parameter parameter) {
/* 57 */     MergedAnnotation<A> annotation = merge(parameter, null);
/* 58 */     if (annotation == null) {
/* 59 */       return null;
/*    */     }
/* 61 */     return (A)annotation.synthesize();
/*    */   }
/*    */   
/*    */   abstract MergedAnnotation<A> merge(AnnotatedElement paramAnnotatedElement, Class<?> paramClass);
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\annotation\AbstractSecurityAnnotationScanner.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */