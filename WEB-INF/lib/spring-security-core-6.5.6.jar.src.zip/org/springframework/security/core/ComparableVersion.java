/*     */ package org.springframework.security.core;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Deque;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ComparableVersion
/*     */   implements Comparable<ComparableVersion>
/*     */ {
/*     */   private static final int MAX_INT_ITEM_LENGTH = 9;
/*     */   private static final int MAX_LONG_ITEM_LENGTH = 18;
/*     */   private String value;
/*     */   private String canonical;
/*     */   private ListItem items;
/*     */   
/*     */   private static class IntItem
/*     */     implements Item
/*     */   {
/*     */     private final int value;
/* 107 */     public static final IntItem ZERO = new IntItem();
/*     */     
/*     */     private IntItem() {
/* 110 */       this.value = 0;
/*     */     }
/*     */     
/*     */     IntItem(String str) {
/* 114 */       this.value = Integer.parseInt(str);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getType() {
/* 119 */       return 3;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isNull() {
/* 124 */       return (this.value == 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(ComparableVersion.Item item) {
/* 129 */       if (item == null) {
/* 130 */         return (this.value == 0) ? 0 : 1;
/*     */       }
/*     */       
/* 133 */       switch (item.getType()) { case 3: 
/*     */         case 0: case 4: 
/*     */         case 1:
/*     */         
/*     */         case 2:
/* 138 */          }  throw new IllegalStateException("invalid item: " + String.valueOf(item.getClass()));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 144 */       if (this == o) {
/* 145 */         return true;
/*     */       }
/* 147 */       if (o == null || getClass() != o.getClass()) {
/* 148 */         return false;
/*     */       }
/*     */       
/* 151 */       IntItem intItem = (IntItem)o;
/*     */       
/* 153 */       return (this.value == intItem.value);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 159 */       return this.value;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 164 */       return Integer.toString(this.value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class LongItem
/*     */     implements Item
/*     */   {
/*     */     private final long value;
/*     */ 
/*     */ 
/*     */     
/*     */     LongItem(String str) {
/* 178 */       this.value = Long.parseLong(str);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getType() {
/* 183 */       return 4;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isNull() {
/* 188 */       return (this.value == 0L);
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(ComparableVersion.Item item) {
/* 193 */       if (item == null) {
/* 194 */         return (this.value == 0L) ? 0 : 1;
/*     */       }
/*     */       
/* 197 */       switch (item.getType()) { case 3: 
/*     */         case 4: 
/*     */         case 0: 
/*     */         case 1:
/*     */         
/*     */         case 2:
/* 203 */          }  throw new IllegalStateException("invalid item: " + String.valueOf(item.getClass()));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 209 */       if (this == o) {
/* 210 */         return true;
/*     */       }
/* 212 */       if (o == null || getClass() != o.getClass()) {
/* 213 */         return false;
/*     */       }
/*     */       
/* 216 */       LongItem longItem = (LongItem)o;
/*     */       
/* 218 */       return (this.value == longItem.value);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 224 */       return (int)(this.value ^ this.value >>> 32L);
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 229 */       return Long.toString(this.value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class BigIntegerItem
/*     */     implements Item
/*     */   {
/*     */     private final BigInteger value;
/*     */ 
/*     */     
/*     */     BigIntegerItem(String str) {
/* 242 */       this.value = new BigInteger(str);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getType() {
/* 247 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isNull() {
/* 252 */       return BigInteger.ZERO.equals(this.value);
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(ComparableVersion.Item item) {
/* 257 */       if (item == null) {
/* 258 */         return BigInteger.ZERO.equals(this.value) ? 0 : 1;
/*     */       }
/*     */       
/* 261 */       switch (item.getType()) { case 3: case 4: 
/*     */         case 0: 
/*     */         case 1:
/*     */         
/*     */         case 2:
/* 266 */          }  throw new IllegalStateException("invalid item: " + String.valueOf(item.getClass()));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 272 */       if (this == o) {
/* 273 */         return true;
/*     */       }
/* 275 */       if (o == null || getClass() != o.getClass()) {
/* 276 */         return false;
/*     */       }
/*     */       
/* 279 */       BigIntegerItem that = (BigIntegerItem)o;
/*     */       
/* 281 */       return this.value.equals(that.value);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 287 */       return this.value.hashCode();
/*     */     }
/*     */     
/*     */     public String toString() {
/* 291 */       return this.value.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class StringItem
/*     */     implements Item
/*     */   {
/* 301 */     private static final List<String> QUALIFIERS = Arrays.asList(new String[] { "alpha", "beta", "milestone", "rc", "snapshot", "", "sp" });
/*     */ 
/*     */     
/* 304 */     private static final Properties ALIASES = new Properties();
/*     */     static {
/* 306 */       ALIASES.put("ga", "");
/* 307 */       ALIASES.put("final", "");
/* 308 */       ALIASES.put("release", "");
/* 309 */       ALIASES.put("cr", "rc");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 317 */     private static final String RELEASE_VERSION_INDEX = String.valueOf(QUALIFIERS.indexOf(""));
/*     */     
/*     */     private final String value;
/*     */     
/*     */     StringItem(String value, boolean followedByDigit) {
/* 322 */       if (followedByDigit && value.length() == 1) {
/*     */         
/* 324 */         switch (value.charAt(0)) { case 'a': 
/*     */           case 'b': 
/*     */           case 'm': 
/*     */           default:
/* 328 */             break; }  value = value;
/*     */       } 
/*     */       
/* 331 */       this.value = ALIASES.getProperty(value, value);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getType() {
/* 336 */       return 1;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isNull() {
/* 341 */       return (comparableQualifier(this.value).compareTo(RELEASE_VERSION_INDEX) == 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static String comparableQualifier(String qualifier) {
/* 358 */       int i = QUALIFIERS.indexOf(qualifier);
/*     */       
/* 360 */       return (i == -1) ? ("" + QUALIFIERS.size() + "-" + QUALIFIERS.size()) : String.valueOf(i);
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(ComparableVersion.Item item) {
/* 365 */       if (item == null)
/*     */       {
/* 367 */         return comparableQualifier(this.value).compareTo(RELEASE_VERSION_INDEX);
/*     */       }
/* 369 */       switch (item.getType()) { case 0: case 3: case 4:
/*     */         
/*     */         case 1:
/*     */         
/*     */         case 2:
/* 374 */          }  throw new IllegalStateException("invalid item: " + String.valueOf(item.getClass()));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 380 */       if (this == o) {
/* 381 */         return true;
/*     */       }
/* 383 */       if (o == null || getClass() != o.getClass()) {
/* 384 */         return false;
/*     */       }
/*     */       
/* 387 */       StringItem that = (StringItem)o;
/*     */       
/* 389 */       return this.value.equals(that.value);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 395 */       return this.value.hashCode();
/*     */     }
/*     */     
/*     */     public String toString() {
/* 399 */       return this.value;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ListItem
/*     */     extends ArrayList<Item>
/*     */     implements Item
/*     */   {
/*     */     public int getType() {
/* 413 */       return 2;
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isNull() {
/* 418 */       return isEmpty();
/*     */     }
/*     */     
/*     */     void normalize() {
/* 422 */       for (int i = size() - 1; i >= 0; i--) {
/* 423 */         ComparableVersion.Item lastItem = get(i);
/*     */         
/* 425 */         if (lastItem.isNull()) {
/*     */           
/* 427 */           remove(i);
/*     */         }
/* 429 */         else if (!(lastItem instanceof ListItem)) {
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */     public int compareTo(ComparableVersion.Item item) {
/*     */       Iterator<ComparableVersion.Item> left;
/*     */       Iterator<ComparableVersion.Item> right;
/* 437 */       if (item == null) {
/* 438 */         if (isEmpty()) {
/* 439 */           return 0;
/*     */         }
/* 441 */         ComparableVersion.Item first = get(0);
/* 442 */         return first.compareTo(null);
/*     */       } 
/* 444 */       switch (item.getType()) { case 0: case 3: case 4: 
/*     */         case 1:
/*     */         
/*     */         case 2:
/* 448 */           left = iterator();
/* 449 */           right = ((ListItem)item).iterator();
/* 450 */           while (left.hasNext() || right.hasNext()) {
/* 451 */             ComparableVersion.Item l = left.hasNext() ? left.next() : null;
/* 452 */             ComparableVersion.Item r = right.hasNext() ? right.next() : null;
/*     */ 
/*     */             
/* 455 */             int result = (l == null) ? ((r == null) ? 0 : (-1 * r.compareTo(l))) : l.compareTo(r);
/*     */             
/* 457 */             if (result != 0);
/*     */           }  }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 463 */       throw new IllegalStateException("invalid item: " + String.valueOf(item.getClass()));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 469 */       StringBuilder buffer = new StringBuilder();
/* 470 */       for (ComparableVersion.Item item : this) {
/* 471 */         if (buffer.length() > 0) {
/* 472 */           buffer.append((item instanceof ListItem) ? 45 : 46);
/*     */         }
/* 474 */         buffer.append(item);
/*     */       } 
/* 476 */       return buffer.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public ComparableVersion(String version) {
/* 482 */     parseVersion(version);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void parseVersion(String version) {
/* 487 */     this.value = version;
/*     */     
/* 489 */     this.items = new ListItem();
/*     */     
/* 491 */     version = version.toLowerCase(Locale.ENGLISH);
/*     */     
/* 493 */     ListItem list = this.items;
/*     */     
/* 495 */     Deque<Item> stack = new ArrayDeque<>();
/* 496 */     stack.push(list);
/*     */     
/* 498 */     boolean isDigit = false;
/*     */     
/* 500 */     int startIndex = 0;
/*     */     
/* 502 */     for (int i = 0; i < version.length(); i++) {
/* 503 */       char c = version.charAt(i);
/*     */       
/* 505 */       if (c == '.') {
/* 506 */         if (i == startIndex) {
/* 507 */           list.add(IntItem.ZERO);
/*     */         } else {
/*     */           
/* 510 */           list.add(parseItem(isDigit, version.substring(startIndex, i)));
/*     */         } 
/* 512 */         startIndex = i + 1;
/*     */       }
/* 514 */       else if (c == '-') {
/* 515 */         if (i == startIndex) {
/* 516 */           list.add(IntItem.ZERO);
/*     */         } else {
/*     */           
/* 519 */           list.add(parseItem(isDigit, version.substring(startIndex, i)));
/*     */         } 
/* 521 */         startIndex = i + 1;
/*     */         
/* 523 */         list.add(list = new ListItem());
/* 524 */         stack.push(list);
/*     */       }
/* 526 */       else if (Character.isDigit(c)) {
/* 527 */         if (!isDigit && i > startIndex) {
/* 528 */           list.add(new StringItem(version.substring(startIndex, i), true));
/* 529 */           startIndex = i;
/*     */           
/* 531 */           list.add(list = new ListItem());
/* 532 */           stack.push(list);
/*     */         } 
/*     */         
/* 535 */         isDigit = true;
/*     */       } else {
/*     */         
/* 538 */         if (isDigit && i > startIndex) {
/* 539 */           list.add(parseItem(true, version.substring(startIndex, i)));
/* 540 */           startIndex = i;
/*     */           
/* 542 */           list.add(list = new ListItem());
/* 543 */           stack.push(list);
/*     */         } 
/*     */         
/* 546 */         isDigit = false;
/*     */       } 
/*     */     } 
/*     */     
/* 550 */     if (version.length() > startIndex) {
/* 551 */       list.add(parseItem(isDigit, version.substring(startIndex)));
/*     */     }
/*     */     
/* 554 */     while (!stack.isEmpty()) {
/* 555 */       list = (ListItem)stack.pop();
/* 556 */       list.normalize();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static Item parseItem(boolean isDigit, String buf) {
/* 561 */     if (isDigit) {
/* 562 */       buf = stripLeadingZeroes(buf);
/* 563 */       if (buf.length() <= 9)
/*     */       {
/* 565 */         return new IntItem(buf);
/*     */       }
/* 567 */       if (buf.length() <= 18)
/*     */       {
/* 569 */         return new LongItem(buf);
/*     */       }
/* 571 */       return new BigIntegerItem(buf);
/*     */     } 
/* 573 */     return new StringItem(buf, false);
/*     */   }
/*     */   
/*     */   private static String stripLeadingZeroes(String buf) {
/* 577 */     if (buf == null || buf.isEmpty()) {
/* 578 */       return "0";
/*     */     }
/* 580 */     for (int i = 0; i < buf.length(); i++) {
/* 581 */       char c = buf.charAt(i);
/* 582 */       if (c != '0') {
/* 583 */         return buf.substring(i);
/*     */       }
/*     */     } 
/* 586 */     return buf;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(ComparableVersion o) {
/* 591 */     return this.items.compareTo(o.items);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 596 */     return this.value;
/*     */   }
/*     */   
/*     */   public String getCanonical() {
/* 600 */     if (this.canonical == null) {
/* 601 */       this.canonical = this.items.toString();
/*     */     }
/* 603 */     return this.canonical;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 608 */     return (o instanceof ComparableVersion && this.items.equals(((ComparableVersion)o).items));
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 613 */     return this.items.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String... args) {
/* 633 */     System.out.println("Display parameters as parsed by Maven (in canonical form) and comparison result:");
/* 634 */     if (args.length == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 638 */     ComparableVersion prev = null;
/* 639 */     int i = 1;
/* 640 */     for (String version : args) {
/* 641 */       ComparableVersion c = new ComparableVersion(version);
/*     */       
/* 643 */       if (prev != null) {
/* 644 */         int compare = prev.compareTo(c);
/* 645 */         System.out.println("   " + prev.toString() + " " + ((compare == 0) ? "==" : ((compare < 0) ? "<" : ">")) + " " + version);
/*     */       } 
/*     */ 
/*     */       
/* 649 */       System.out.println(String.valueOf(i++) + ". " + String.valueOf(i++) + " == " + version);
/*     */       
/* 651 */       prev = c;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static interface Item {
/*     */     public static final int INT_ITEM = 3;
/*     */     public static final int LONG_ITEM = 4;
/*     */     public static final int BIGINTEGER_ITEM = 0;
/*     */     public static final int STRING_ITEM = 1;
/*     */     public static final int LIST_ITEM = 2;
/*     */     
/*     */     int compareTo(Item param1Item);
/*     */     
/*     */     int getType();
/*     */     
/*     */     boolean isNull();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\ComparableVersion.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */