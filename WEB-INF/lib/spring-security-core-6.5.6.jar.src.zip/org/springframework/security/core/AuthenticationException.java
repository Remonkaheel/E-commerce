/*    */ package org.springframework.security.core;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AuthenticationException
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 2018827803361503060L;
/*    */   private Authentication authenticationRequest;
/*    */   
/*    */   public AuthenticationException(String msg, Throwable cause) {
/* 43 */     super(msg, cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AuthenticationException(String msg) {
/* 52 */     super(msg);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Authentication getAuthenticationRequest() {
/* 65 */     return this.authenticationRequest;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAuthenticationRequest(Authentication authenticationRequest) {
/* 78 */     Assert.notNull(authenticationRequest, "authenticationRequest cannot be null");
/* 79 */     this.authenticationRequest = authenticationRequest;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\core\AuthenticationException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */