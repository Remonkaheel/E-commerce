/*    */ package org.springframework.security.concurrent;
/*    */ 
/*    */ import java.util.concurrent.Executor;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingSecurityContextExecutor
/*    */   extends AbstractDelegatingSecurityContextSupport
/*    */   implements Executor
/*    */ {
/*    */   private final Executor delegate;
/*    */   
/*    */   public DelegatingSecurityContextExecutor(Executor delegateExecutor, SecurityContext securityContext) {
/* 46 */     super(securityContext);
/* 47 */     Assert.notNull(delegateExecutor, "delegateExecutor cannot be null");
/* 48 */     this.delegate = delegateExecutor;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DelegatingSecurityContextExecutor(Executor delegate) {
/* 58 */     this(delegate, null);
/*    */   }
/*    */ 
/*    */   
/*    */   public final void execute(Runnable task) {
/* 63 */     this.delegate.execute(wrap(task));
/*    */   }
/*    */   
/*    */   protected final Executor getDelegateExecutor() {
/* 67 */     return this.delegate;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 77 */     super.setSecurityContextHolderStrategy(securityContextHolderStrategy);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\concurrent\DelegatingSecurityContextExecutor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */