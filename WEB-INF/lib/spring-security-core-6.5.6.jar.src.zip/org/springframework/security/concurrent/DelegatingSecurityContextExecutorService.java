/*     */ package org.springframework.security.concurrent;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DelegatingSecurityContextExecutorService
/*     */   extends DelegatingSecurityContextExecutor
/*     */   implements ExecutorService
/*     */ {
/*     */   public DelegatingSecurityContextExecutorService(ExecutorService delegateExecutorService, SecurityContext securityContext) {
/*  54 */     super(delegateExecutorService, securityContext);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DelegatingSecurityContextExecutorService(ExecutorService delegate) {
/*  63 */     this(delegate, (SecurityContext)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void shutdown() {
/*  68 */     getDelegate().shutdown();
/*     */   }
/*     */ 
/*     */   
/*     */   public final List<Runnable> shutdownNow() {
/*  73 */     return getDelegate().shutdownNow();
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isShutdown() {
/*  78 */     return getDelegate().isShutdown();
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean isTerminated() {
/*  83 */     return getDelegate().isTerminated();
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean awaitTermination(long timeout, TimeUnit unit) throws InterruptedException {
/*  88 */     return getDelegate().awaitTermination(timeout, unit);
/*     */   }
/*     */ 
/*     */   
/*     */   public final <T> Future<T> submit(Callable<T> task) {
/*  93 */     return getDelegate().submit(wrap(task));
/*     */   }
/*     */ 
/*     */   
/*     */   public final <T> Future<T> submit(Runnable task, T result) {
/*  98 */     return getDelegate().submit(wrap(task), result);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Future<?> submit(Runnable task) {
/* 103 */     return getDelegate().submit(wrap(task));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final List invokeAll(Collection<Callable<?>> tasks) throws InterruptedException {
/* 109 */     tasks = createTasks(tasks);
/* 110 */     return getDelegate().invokeAll(tasks);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final List invokeAll(Collection<Callable<?>> tasks, long timeout, TimeUnit unit) throws InterruptedException {
/* 116 */     tasks = createTasks(tasks);
/* 117 */     return getDelegate().invokeAll(tasks, timeout, unit);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object invokeAny(Collection<Callable<?>> tasks) throws InterruptedException, ExecutionException {
/* 123 */     tasks = createTasks(tasks);
/* 124 */     return getDelegate().invokeAny(tasks);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object invokeAny(Collection<Callable<?>> tasks, long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
/* 131 */     tasks = createTasks(tasks);
/* 132 */     return getDelegate().invokeAny(tasks, timeout, unit);
/*     */   }
/*     */   
/*     */   private <T> Collection<Callable<T>> createTasks(Collection<Callable<T>> tasks) {
/* 136 */     if (tasks == null) {
/* 137 */       return null;
/*     */     }
/* 139 */     List<Callable<T>> results = new ArrayList<>(tasks.size());
/* 140 */     for (Callable<T> task : tasks) {
/* 141 */       results.add(wrap(task));
/*     */     }
/* 143 */     return results;
/*     */   }
/*     */   
/*     */   private ExecutorService getDelegate() {
/* 147 */     return (ExecutorService)getDelegateExecutor();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\concurrent\DelegatingSecurityContextExecutorService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */