/*    */ package org.springframework.security.concurrent;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ import org.springframework.security.core.context.SecurityContextHolder;
/*    */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class AbstractDelegatingSecurityContextSupport
/*    */ {
/* 37 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final SecurityContext securityContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   AbstractDelegatingSecurityContextSupport(SecurityContext securityContext) {
/* 50 */     this.securityContext = securityContext;
/*    */   }
/*    */   
/*    */   void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 54 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 55 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*    */   }
/*    */   
/*    */   protected final Runnable wrap(Runnable delegate) {
/* 59 */     return DelegatingSecurityContextRunnable.create(delegate, this.securityContext, this.securityContextHolderStrategy);
/*    */   }
/*    */ 
/*    */   
/*    */   protected final <T> Callable<T> wrap(Callable<T> delegate) {
/* 64 */     return DelegatingSecurityContextCallable.create(delegate, this.securityContext, this.securityContextHolderStrategy);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\concurrent\AbstractDelegatingSecurityContextSupport.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */