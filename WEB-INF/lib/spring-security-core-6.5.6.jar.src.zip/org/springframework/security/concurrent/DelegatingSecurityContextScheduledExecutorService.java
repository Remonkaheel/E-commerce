/*    */ package org.springframework.security.concurrent;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.ScheduledExecutorService;
/*    */ import java.util.concurrent.ScheduledFuture;
/*    */ import java.util.concurrent.TimeUnit;
/*    */ import org.springframework.security.core.context.SecurityContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DelegatingSecurityContextScheduledExecutorService
/*    */   extends DelegatingSecurityContextExecutorService
/*    */   implements ScheduledExecutorService
/*    */ {
/*    */   public DelegatingSecurityContextScheduledExecutorService(ScheduledExecutorService delegateScheduledExecutorService, SecurityContext securityContext) {
/* 49 */     super(delegateScheduledExecutorService, securityContext);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DelegatingSecurityContextScheduledExecutorService(ScheduledExecutorService delegate) {
/* 59 */     this(delegate, (SecurityContext)null);
/*    */   }
/*    */ 
/*    */   
/*    */   public ScheduledFuture<?> schedule(Runnable command, long delay, TimeUnit unit) {
/* 64 */     return getDelegate().schedule(wrap(command), delay, unit);
/*    */   }
/*    */ 
/*    */   
/*    */   public <V> ScheduledFuture<V> schedule(Callable<V> callable, long delay, TimeUnit unit) {
/* 69 */     return getDelegate().schedule(wrap(callable), delay, unit);
/*    */   }
/*    */ 
/*    */   
/*    */   public ScheduledFuture<?> scheduleAtFixedRate(Runnable command, long initialDelay, long period, TimeUnit unit) {
/* 74 */     return getDelegate().scheduleAtFixedRate(wrap(command), initialDelay, period, unit);
/*    */   }
/*    */ 
/*    */   
/*    */   public ScheduledFuture<?> scheduleWithFixedDelay(Runnable command, long initialDelay, long delay, TimeUnit unit) {
/* 79 */     return getDelegate().scheduleWithFixedDelay(wrap(command), initialDelay, delay, unit);
/*    */   }
/*    */   
/*    */   private ScheduledExecutorService getDelegate() {
/* 83 */     return (ScheduledExecutorService)getDelegateExecutor();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\concurrent\DelegatingSecurityContextScheduledExecutorService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */