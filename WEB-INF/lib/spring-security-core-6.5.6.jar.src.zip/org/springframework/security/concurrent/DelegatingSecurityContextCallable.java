/*     */ package org.springframework.security.concurrent;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DelegatingSecurityContextCallable<V>
/*     */   implements Callable<V>
/*     */ {
/*     */   private final Callable<V> delegate;
/*     */   private final boolean explicitSecurityContextProvided;
/*     */   private SecurityContext delegateSecurityContext;
/*  52 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SecurityContext originalSecurityContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DelegatingSecurityContextCallable(Callable<V> delegate, SecurityContext securityContext) {
/*  69 */     this(delegate, securityContext, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DelegatingSecurityContextCallable(Callable<V> delegate) {
/*  79 */     this(delegate, SecurityContextHolder.getContext(), false);
/*     */   }
/*     */ 
/*     */   
/*     */   private DelegatingSecurityContextCallable(Callable<V> delegate, SecurityContext securityContext, boolean explicitSecurityContextProvided) {
/*  84 */     Assert.notNull(delegate, "delegate cannot be null");
/*  85 */     Assert.notNull(securityContext, "securityContext cannot be null");
/*  86 */     this.delegate = delegate;
/*  87 */     this.delegateSecurityContext = securityContext;
/*  88 */     this.explicitSecurityContextProvided = explicitSecurityContextProvided;
/*     */   }
/*     */ 
/*     */   
/*     */   public V call() throws Exception {
/*  93 */     this.originalSecurityContext = this.securityContextHolderStrategy.getContext();
/*     */     try {
/*  95 */       this.securityContextHolderStrategy.setContext(this.delegateSecurityContext);
/*  96 */       return this.delegate.call();
/*     */     } finally {
/*     */       
/*  99 */       SecurityContext emptyContext = this.securityContextHolderStrategy.createEmptyContext();
/* 100 */       if (emptyContext.equals(this.originalSecurityContext)) {
/* 101 */         this.securityContextHolderStrategy.clearContext();
/*     */       } else {
/*     */         
/* 104 */         this.securityContextHolderStrategy.setContext(this.originalSecurityContext);
/*     */       } 
/* 106 */       this.originalSecurityContext = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 117 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 118 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/* 119 */     if (!this.explicitSecurityContextProvided) {
/* 120 */       this.delegateSecurityContext = securityContextHolderStrategy.getContext();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 126 */     return this.delegate.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <V> Callable<V> create(Callable<V> delegate, SecurityContext securityContext) {
/* 141 */     return (securityContext != null) ? new DelegatingSecurityContextCallable<>(delegate, securityContext) : 
/* 142 */       new DelegatingSecurityContextCallable<>(delegate);
/*     */   }
/*     */ 
/*     */   
/*     */   static <V> Callable<V> create(Callable<V> delegate, SecurityContext securityContext, SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 147 */     Assert.notNull(delegate, "delegate cannot be null");
/* 148 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/*     */ 
/*     */     
/* 151 */     DelegatingSecurityContextCallable<V> callable = (securityContext != null) ? new DelegatingSecurityContextCallable<>(delegate, securityContext) : new DelegatingSecurityContextCallable<>(delegate);
/* 152 */     callable.setSecurityContextHolderStrategy(securityContextHolderStrategy);
/* 153 */     return callable;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\concurrent\DelegatingSecurityContextCallable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */