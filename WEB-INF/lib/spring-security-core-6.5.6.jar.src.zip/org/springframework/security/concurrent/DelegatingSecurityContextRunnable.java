/*     */ package org.springframework.security.concurrent;
/*     */ 
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DelegatingSecurityContextRunnable
/*     */   implements Runnable
/*     */ {
/*     */   private final Runnable delegate;
/*     */   private final boolean explicitSecurityContextProvided;
/*  45 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SecurityContext delegateSecurityContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SecurityContext originalSecurityContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DelegatingSecurityContextRunnable(Runnable delegate, SecurityContext securityContext) {
/*  67 */     this(delegate, securityContext, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DelegatingSecurityContextRunnable(Runnable delegate) {
/*  77 */     this(delegate, SecurityContextHolder.getContext(), false);
/*     */   }
/*     */ 
/*     */   
/*     */   private DelegatingSecurityContextRunnable(Runnable delegate, SecurityContext securityContext, boolean explicitSecurityContextProvided) {
/*  82 */     Assert.notNull(delegate, "delegate cannot be null");
/*  83 */     Assert.notNull(securityContext, "securityContext cannot be null");
/*  84 */     this.delegate = delegate;
/*  85 */     this.delegateSecurityContext = securityContext;
/*  86 */     this.explicitSecurityContextProvided = explicitSecurityContextProvided;
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/*  91 */     this.originalSecurityContext = this.securityContextHolderStrategy.getContext();
/*     */     try {
/*  93 */       this.securityContextHolderStrategy.setContext(this.delegateSecurityContext);
/*  94 */       this.delegate.run();
/*     */     } finally {
/*     */       
/*  97 */       SecurityContext emptyContext = this.securityContextHolderStrategy.createEmptyContext();
/*  98 */       if (emptyContext.equals(this.originalSecurityContext)) {
/*  99 */         this.securityContextHolderStrategy.clearContext();
/*     */       } else {
/*     */         
/* 102 */         this.securityContextHolderStrategy.setContext(this.originalSecurityContext);
/*     */       } 
/* 104 */       this.originalSecurityContext = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 115 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 116 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/* 117 */     if (!this.explicitSecurityContextProvided) {
/* 118 */       this.delegateSecurityContext = this.securityContextHolderStrategy.getContext();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 124 */     return this.delegate.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Runnable create(Runnable delegate, SecurityContext securityContext) {
/* 138 */     Assert.notNull(delegate, "delegate cannot be  null");
/* 139 */     return (securityContext != null) ? new DelegatingSecurityContextRunnable(delegate, securityContext) : 
/* 140 */       new DelegatingSecurityContextRunnable(delegate);
/*     */   }
/*     */ 
/*     */   
/*     */   static Runnable create(Runnable delegate, SecurityContext securityContext, SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 145 */     Assert.notNull(delegate, "delegate cannot be  null");
/* 146 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/*     */ 
/*     */     
/* 149 */     DelegatingSecurityContextRunnable runnable = (securityContext != null) ? new DelegatingSecurityContextRunnable(delegate, securityContext) : new DelegatingSecurityContextRunnable(delegate);
/* 150 */     runnable.setSecurityContextHolderStrategy(securityContextHolderStrategy);
/* 151 */     return runnable;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\concurrent\DelegatingSecurityContextRunnable.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */