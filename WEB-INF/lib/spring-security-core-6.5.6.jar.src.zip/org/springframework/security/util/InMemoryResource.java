/*    */ package org.springframework.security.util;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.util.Arrays;
/*    */ import org.springframework.core.io.AbstractResource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InMemoryResource
/*    */   extends AbstractResource
/*    */ {
/*    */   private final byte[] source;
/*    */   private final String description;
/*    */   
/*    */   public InMemoryResource(String source) {
/* 42 */     this(source.getBytes());
/*    */   }
/*    */   
/*    */   public InMemoryResource(byte[] source) {
/* 46 */     this(source, null);
/*    */   }
/*    */   
/*    */   public InMemoryResource(byte[] source, String description) {
/* 50 */     Assert.notNull(source, "source cannot be null");
/* 51 */     this.source = source;
/* 52 */     this.description = description;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 57 */     return this.description;
/*    */   }
/*    */ 
/*    */   
/*    */   public InputStream getInputStream() {
/* 62 */     return new ByteArrayInputStream(this.source);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object res) {
/* 67 */     if (!(res instanceof InMemoryResource)) {
/* 68 */       return false;
/*    */     }
/* 70 */     return Arrays.equals(this.source, ((InMemoryResource)res).source);
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 75 */     return 1;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\securit\\util\InMemoryResource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */