/*    */ package org.springframework.security.util;
/*    */ 
/*    */ import java.lang.reflect.AccessibleObject;
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleMethodInvocation
/*    */   implements MethodInvocation
/*    */ {
/*    */   private Method method;
/*    */   private Object[] arguments;
/*    */   private Object targetObject;
/*    */   
/*    */   public SimpleMethodInvocation(Object targetObject, Method method, Object... arguments) {
/* 38 */     this.targetObject = targetObject;
/* 39 */     this.method = method;
/* 40 */     this.arguments = (arguments != null) ? arguments : new Object[0];
/*    */   }
/*    */ 
/*    */   
/*    */   public SimpleMethodInvocation() {}
/*    */ 
/*    */   
/*    */   public Object[] getArguments() {
/* 48 */     return this.arguments;
/*    */   }
/*    */ 
/*    */   
/*    */   public Method getMethod() {
/* 53 */     return this.method;
/*    */   }
/*    */ 
/*    */   
/*    */   public AccessibleObject getStaticPart() {
/* 58 */     throw new UnsupportedOperationException("mock method not implemented");
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getThis() {
/* 63 */     return this.targetObject;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object proceed() {
/* 68 */     throw new UnsupportedOperationException("mock method not implemented");
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 73 */     return "method invocation [" + String.valueOf(this.method) + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\securit\\util\SimpleMethodInvocation.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */