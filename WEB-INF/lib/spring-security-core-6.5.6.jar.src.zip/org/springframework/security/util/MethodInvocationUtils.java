/*     */ package org.springframework.security.util;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.aop.framework.Advised;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MethodInvocationUtils
/*     */ {
/*     */   public static MethodInvocation create(Object object, String methodName, Object... args) {
/*  52 */     Assert.notNull(object, "Object required");
/*  53 */     Class<?>[] classArgs = null;
/*  54 */     if (args != null) {
/*  55 */       classArgs = new Class[args.length];
/*  56 */       for (int i = 0; i < args.length; i++) {
/*  57 */         classArgs[i] = args[i].getClass();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  62 */     Class<?> target = AopUtils.getTargetClass(object);
/*  63 */     if (object instanceof Advised) { Advised a = (Advised)object;
/*  64 */       if (!a.isProxyTargetClass()) {
/*  65 */         Class<?>[] possibleInterfaces = a.getProxiedInterfaces();
/*  66 */         for (Class<?> possibleInterface : possibleInterfaces) {
/*     */           try {
/*  68 */             possibleInterface.getMethod(methodName, classArgs);
/*     */             
/*  70 */             target = possibleInterface;
/*     */             
/*     */             break;
/*  73 */           } catch (Exception exception) {}
/*     */         } 
/*     */       }  }
/*     */ 
/*     */ 
/*     */     
/*  79 */     return createFromClass(object, target, methodName, classArgs, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodInvocation createFromClass(Class<?> clazz, String methodName) {
/*  97 */     MethodInvocation invocation = createFromClass(null, clazz, methodName, null, null);
/*  98 */     if (invocation == null) {
/*  99 */       for (Method method : clazz.getDeclaredMethods()) {
/* 100 */         if (method.getName().equals(methodName)) {
/* 101 */           Assert.isTrue((invocation == null), () -> "The class " + String.valueOf(clazz) + " has more than one method named '" + methodName + "'");
/*     */           
/* 103 */           invocation = new SimpleMethodInvocation(null, method, new Object[0]);
/*     */         } 
/*     */       } 
/*     */     }
/* 107 */     return invocation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MethodInvocation createFromClass(Object targetObject, Class<?> clazz, String methodName, Class<?>[] classArgs, Object[] args) {
/* 125 */     Assert.notNull(clazz, "Class required");
/* 126 */     Assert.hasText(methodName, "MethodName required");
/*     */     try {
/* 128 */       Method method = clazz.getMethod(methodName, classArgs);
/* 129 */       return new SimpleMethodInvocation(targetObject, method, args);
/*     */     }
/* 131 */     catch (NoSuchMethodException ex) {
/* 132 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\securit\\util\MethodInvocationUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */