/*     */ package org.springframework.security.util;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FieldUtils
/*     */ {
/*     */   public static Field getField(Class<?> clazz, String fieldName) throws IllegalStateException {
/*  43 */     Assert.notNull(clazz, "Class required");
/*  44 */     Assert.hasText(fieldName, "Field name required");
/*     */     try {
/*  46 */       return clazz.getDeclaredField(fieldName);
/*     */     }
/*  48 */     catch (NoSuchFieldException ex) {
/*     */       
/*  50 */       if (clazz.getSuperclass() != null) {
/*  51 */         return getField(clazz.getSuperclass(), fieldName);
/*     */       }
/*  53 */       throw new IllegalStateException("Could not locate field '" + fieldName + "' on class " + String.valueOf(clazz));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object getFieldValue(Object bean, String fieldName) throws IllegalAccessException {
/*  64 */     Assert.notNull(bean, "Bean cannot be null");
/*  65 */     Assert.hasText(fieldName, "Field name required");
/*  66 */     String[] nestedFields = StringUtils.tokenizeToStringArray(fieldName, ".");
/*  67 */     Class<?> componentClass = bean.getClass();
/*  68 */     Object value = bean;
/*  69 */     for (String nestedField : nestedFields) {
/*  70 */       Field field = getField(componentClass, nestedField);
/*  71 */       field.setAccessible(true);
/*  72 */       value = field.get(value);
/*  73 */       if (value != null) {
/*  74 */         componentClass = value.getClass();
/*     */       }
/*     */     } 
/*  77 */     return value;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Object getProtectedFieldValue(String protectedField, Object object) {
/*  82 */     Field field = getField(object.getClass(), protectedField);
/*     */     try {
/*  84 */       field.setAccessible(true);
/*  85 */       return field.get(object);
/*     */     }
/*  87 */     catch (Exception ex) {
/*  88 */       ReflectionUtils.handleReflectionException(ex);
/*  89 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setProtectedFieldValue(String protectedField, Object object, Object newValue) {
/*  94 */     Field field = getField(object.getClass(), protectedField);
/*     */     try {
/*  96 */       field.setAccessible(true);
/*  97 */       field.set(object, newValue);
/*     */     }
/*  99 */     catch (Exception ex) {
/* 100 */       ReflectionUtils.handleReflectionException(ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\securit\\util\FieldUtils.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */