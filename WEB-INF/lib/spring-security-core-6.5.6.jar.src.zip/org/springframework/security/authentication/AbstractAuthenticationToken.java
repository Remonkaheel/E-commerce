/*     */ package org.springframework.security.authentication;
/*     */ 
/*     */ import java.security.Principal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import org.springframework.security.core.AuthenticatedPrincipal;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.CredentialsContainer;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.authority.AuthorityUtils;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAuthenticationToken
/*     */   implements Authentication, CredentialsContainer
/*     */ {
/*     */   private final Collection<GrantedAuthority> authorities;
/*     */   private Object details;
/*     */   private boolean authenticated = false;
/*     */   
/*     */   public AbstractAuthenticationToken(Collection<? extends GrantedAuthority> authorities) {
/*  54 */     if (authorities == null) {
/*  55 */       this.authorities = AuthorityUtils.NO_AUTHORITIES;
/*     */       return;
/*     */     } 
/*  58 */     for (GrantedAuthority a : authorities) {
/*  59 */       Assert.notNull(a, "Authorities collection cannot contain any null elements");
/*     */     }
/*  61 */     this.authorities = Collections.unmodifiableList(new ArrayList<>(authorities));
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<GrantedAuthority> getAuthorities() {
/*  66 */     return this.authorities;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  71 */     Object object = getPrincipal(); if (object instanceof UserDetails) { UserDetails userDetails = (UserDetails)object;
/*  72 */       return userDetails.getUsername(); }
/*     */     
/*  74 */     object = getPrincipal(); if (object instanceof AuthenticatedPrincipal) { AuthenticatedPrincipal authenticatedPrincipal = (AuthenticatedPrincipal)object;
/*  75 */       return authenticatedPrincipal.getName(); }
/*     */     
/*  77 */     object = getPrincipal(); if (object instanceof Principal) { Principal principal = (Principal)object;
/*  78 */       return principal.getName(); }
/*     */     
/*  80 */     return (getPrincipal() == null) ? "" : getPrincipal().toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAuthenticated() {
/*  85 */     return this.authenticated;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticated(boolean authenticated) {
/*  90 */     this.authenticated = authenticated;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getDetails() {
/*  95 */     return this.details;
/*     */   }
/*     */   
/*     */   public void setDetails(Object details) {
/*  99 */     this.details = details;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void eraseCredentials() {
/* 109 */     eraseSecret(getCredentials());
/* 110 */     eraseSecret(getPrincipal());
/* 111 */     eraseSecret(this.details);
/*     */   }
/*     */   
/*     */   private void eraseSecret(Object secret) {
/* 115 */     if (secret instanceof CredentialsContainer) { CredentialsContainer container = (CredentialsContainer)secret;
/* 116 */       container.eraseCredentials(); }
/*     */   
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj) {
/*     */     AbstractAuthenticationToken test;
/* 122 */     if (obj instanceof AbstractAuthenticationToken) { test = (AbstractAuthenticationToken)obj; }
/* 123 */     else { return false; }
/*     */     
/* 125 */     if (!this.authorities.equals(test.authorities)) {
/* 126 */       return false;
/*     */     }
/* 128 */     if (this.details == null && test.getDetails() != null) {
/* 129 */       return false;
/*     */     }
/* 131 */     if (this.details != null && test.getDetails() == null) {
/* 132 */       return false;
/*     */     }
/* 134 */     if (this.details != null && !this.details.equals(test.getDetails())) {
/* 135 */       return false;
/*     */     }
/* 137 */     if (getCredentials() == null && test.getCredentials() != null) {
/* 138 */       return false;
/*     */     }
/* 140 */     if (getCredentials() != null && !getCredentials().equals(test.getCredentials())) {
/* 141 */       return false;
/*     */     }
/* 143 */     if (getPrincipal() == null && test.getPrincipal() != null) {
/* 144 */       return false;
/*     */     }
/* 146 */     if (getPrincipal() != null && !getPrincipal().equals(test.getPrincipal())) {
/* 147 */       return false;
/*     */     }
/* 149 */     return (isAuthenticated() == test.isAuthenticated());
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 154 */     int code = 31;
/* 155 */     for (GrantedAuthority authority : this.authorities) {
/* 156 */       code ^= authority.hashCode();
/*     */     }
/* 158 */     if (getPrincipal() != null) {
/* 159 */       code ^= getPrincipal().hashCode();
/*     */     }
/* 161 */     if (getCredentials() != null) {
/* 162 */       code ^= getCredentials().hashCode();
/*     */     }
/* 164 */     if (getDetails() != null) {
/* 165 */       code ^= getDetails().hashCode();
/*     */     }
/* 167 */     if (isAuthenticated()) {
/* 168 */       code ^= 0xFFFFFFDB;
/*     */     }
/* 170 */     return code;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 175 */     StringBuilder sb = new StringBuilder();
/* 176 */     sb.append(getClass().getSimpleName()).append(" [");
/* 177 */     sb.append("Principal=").append(getPrincipal()).append(", ");
/* 178 */     sb.append("Credentials=[PROTECTED], ");
/* 179 */     sb.append("Authenticated=").append(isAuthenticated()).append(", ");
/* 180 */     sb.append("Details=").append(getDetails()).append(", ");
/* 181 */     sb.append("Granted Authorities=").append(this.authorities);
/* 182 */     sb.append("]");
/* 183 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\AbstractAuthenticationToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */