package org.springframework.security.authentication.password;

import org.springframework.lang.NonNull;

public interface CompromisedPasswordChecker {
  @NonNull
  CompromisedPasswordDecision check(String paramString);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\password\CompromisedPasswordChecker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */