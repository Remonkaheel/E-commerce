/*    */ package org.springframework.security.authentication.password;
/*    */ 
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompromisedPasswordException
/*    */   extends AuthenticationException
/*    */ {
/*    */   private static final long serialVersionUID = -885858958297842864L;
/*    */   
/*    */   public CompromisedPasswordException(String message) {
/* 35 */     super(message);
/*    */   }
/*    */   
/*    */   public CompromisedPasswordException(String message, Throwable cause) {
/* 39 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\password\CompromisedPasswordException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */