/*    */ package org.springframework.security.authentication.password;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompromisedPasswordDecision
/*    */ {
/*    */   private final boolean compromised;
/*    */   
/*    */   public CompromisedPasswordDecision(boolean compromised) {
/* 24 */     this.compromised = compromised;
/*    */   }
/*    */   
/*    */   public boolean isCompromised() {
/* 28 */     return this.compromised;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\password\CompromisedPasswordDecision.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */