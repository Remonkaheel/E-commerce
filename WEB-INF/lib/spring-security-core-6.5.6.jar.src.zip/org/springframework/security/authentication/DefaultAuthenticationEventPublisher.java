/*     */ package org.springframework.security.authentication;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.security.authentication.event.AbstractAuthenticationEvent;
/*     */ import org.springframework.security.authentication.event.AbstractAuthenticationFailureEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureCredentialsExpiredEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureDisabledEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureExpiredEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureLockedEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureProviderNotFoundEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureProxyUntrustedEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureServiceExceptionEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultAuthenticationEventPublisher
/*     */   implements AuthenticationEventPublisher, ApplicationEventPublisherAware
/*     */ {
/*  68 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private ApplicationEventPublisher applicationEventPublisher;
/*     */   
/*  72 */   private final HashMap<String, Constructor<? extends AbstractAuthenticationEvent>> exceptionMappings = new HashMap<>();
/*     */   
/*     */   private Constructor<? extends AbstractAuthenticationFailureEvent> defaultAuthenticationFailureEventConstructor;
/*     */   
/*     */   public DefaultAuthenticationEventPublisher() {
/*  77 */     this(null);
/*     */   }
/*     */   
/*     */   public DefaultAuthenticationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
/*  81 */     this.applicationEventPublisher = applicationEventPublisher;
/*  82 */     addMapping(BadCredentialsException.class.getName(), (Class)AuthenticationFailureBadCredentialsEvent.class);
/*  83 */     addMapping(UsernameNotFoundException.class.getName(), (Class)AuthenticationFailureBadCredentialsEvent.class);
/*  84 */     addMapping(AccountExpiredException.class.getName(), (Class)AuthenticationFailureExpiredEvent.class);
/*  85 */     addMapping(ProviderNotFoundException.class.getName(), (Class)AuthenticationFailureProviderNotFoundEvent.class);
/*  86 */     addMapping(DisabledException.class.getName(), (Class)AuthenticationFailureDisabledEvent.class);
/*  87 */     addMapping(LockedException.class.getName(), (Class)AuthenticationFailureLockedEvent.class);
/*  88 */     addMapping(AuthenticationServiceException.class.getName(), (Class)AuthenticationFailureServiceExceptionEvent.class);
/*  89 */     addMapping(CredentialsExpiredException.class.getName(), (Class)AuthenticationFailureCredentialsExpiredEvent.class);
/*  90 */     addMapping("org.springframework.security.authentication.cas.ProxyUntrustedException", (Class)AuthenticationFailureProxyUntrustedEvent.class);
/*     */     
/*  92 */     addMapping("org.springframework.security.oauth2.server.resource.InvalidBearerTokenException", (Class)AuthenticationFailureBadCredentialsEvent.class);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void publishAuthenticationSuccess(Authentication authentication) {
/*  98 */     if (this.applicationEventPublisher != null) {
/*  99 */       this.applicationEventPublisher.publishEvent((ApplicationEvent)new AuthenticationSuccessEvent(authentication));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void publishAuthenticationFailure(AuthenticationException exception, Authentication authentication) {
/* 105 */     Constructor<? extends AbstractAuthenticationEvent> constructor = getEventConstructor(exception);
/* 106 */     AbstractAuthenticationEvent event = null;
/* 107 */     if (constructor != null) {
/*     */       try {
/* 109 */         event = constructor.newInstance(new Object[] { authentication, exception });
/*     */       }
/* 111 */       catch (IllegalAccessException|java.lang.reflect.InvocationTargetException|InstantiationException illegalAccessException) {}
/*     */     }
/*     */     
/* 114 */     if (event != null) {
/* 115 */       if (this.applicationEventPublisher != null) {
/* 116 */         this.applicationEventPublisher.publishEvent((ApplicationEvent)event);
/*     */       
/*     */       }
/*     */     }
/* 120 */     else if (this.logger.isDebugEnabled()) {
/* 121 */       this.logger.debug("No event was found for the exception " + exception.getClass().getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Constructor<? extends AbstractAuthenticationEvent> getEventConstructor(AuthenticationException exception) {
/* 128 */     Constructor<? extends AbstractAuthenticationEvent> eventConstructor = this.exceptionMappings.get(exception.getClass().getName());
/* 129 */     return (eventConstructor != null) ? eventConstructor : (Constructor)this.defaultAuthenticationFailureEventConstructor;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
/* 134 */     this.applicationEventPublisher = applicationEventPublisher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setAdditionalExceptionMappings(Properties additionalExceptionMappings) {
/* 148 */     Assert.notNull(additionalExceptionMappings, "The exceptionMappings object must not be null");
/* 149 */     for (Object exceptionClass : additionalExceptionMappings.keySet()) {
/* 150 */       String eventClass = (String)additionalExceptionMappings.get(exceptionClass);
/*     */       try {
/* 152 */         Class<?> clazz = getClass().getClassLoader().loadClass(eventClass);
/* 153 */         Assert.isAssignable(AbstractAuthenticationFailureEvent.class, clazz);
/* 154 */         addMapping((String)exceptionClass, (Class)clazz);
/*     */       }
/* 156 */       catch (ClassNotFoundException ex) {
/* 157 */         throw new RuntimeException("Failed to load authentication event class " + eventClass);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAdditionalExceptionMappings(Map<Class<? extends AuthenticationException>, Class<? extends AbstractAuthenticationFailureEvent>> mappings) {
/* 170 */     Assert.notEmpty(mappings, "The mappings Map must not be empty nor null");
/* 171 */     for (Map.Entry<Class<? extends AuthenticationException>, Class<? extends AbstractAuthenticationFailureEvent>> entry : mappings
/* 172 */       .entrySet()) {
/* 173 */       Class<?> exceptionClass = entry.getKey();
/* 174 */       Class<?> eventClass = entry.getValue();
/* 175 */       Assert.notNull(exceptionClass, "exceptionClass cannot be null");
/* 176 */       Assert.notNull(eventClass, "eventClass cannot be null");
/* 177 */       addMapping(exceptionClass.getName(), (Class)eventClass);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultAuthenticationFailureEvent(Class<? extends AbstractAuthenticationFailureEvent> defaultAuthenticationFailureEventClass) {
/* 189 */     Assert.notNull(defaultAuthenticationFailureEventClass, "defaultAuthenticationFailureEventClass must not be null");
/*     */     
/*     */     try {
/* 192 */       this
/* 193 */         .defaultAuthenticationFailureEventConstructor = defaultAuthenticationFailureEventClass.getConstructor(new Class[] { Authentication.class, AuthenticationException.class });
/*     */     }
/* 195 */     catch (NoSuchMethodException ex) {
/* 196 */       throw new RuntimeException("Default Authentication Failure event class " + defaultAuthenticationFailureEventClass
/* 197 */           .getName() + " has no suitable constructor");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void addMapping(String exceptionClass, Class<? extends AbstractAuthenticationFailureEvent> eventClass) {
/*     */     try {
/* 204 */       Constructor<? extends AbstractAuthenticationEvent> constructor = (Constructor)eventClass.getConstructor(new Class[] { Authentication.class, AuthenticationException.class });
/* 205 */       this.exceptionMappings.put(exceptionClass, constructor);
/*     */     }
/* 207 */     catch (NoSuchMethodException ex) {
/* 208 */       throw new RuntimeException("Authentication event class " + eventClass
/* 209 */           .getName() + " has no suitable constructor");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\DefaultAuthenticationEventPublisher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */