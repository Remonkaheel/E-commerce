/*     */ package org.springframework.security.authentication;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.CredentialsContainer;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProviderManager
/*     */   implements AuthenticationManager, MessageSourceAware, InitializingBean
/*     */ {
/*  92 */   private static final Log logger = LogFactory.getLog(ProviderManager.class);
/*     */   
/*  94 */   private AuthenticationEventPublisher eventPublisher = new NullEventPublisher();
/*     */   
/*  96 */   private List<AuthenticationProvider> providers = Collections.emptyList();
/*     */   
/*  98 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */ 
/*     */   
/*     */   private AuthenticationManager parent;
/*     */ 
/*     */   
/*     */   private boolean eraseCredentialsAfterAuthentication = true;
/*     */ 
/*     */ 
/*     */   
/*     */   public ProviderManager(AuthenticationProvider... providers) {
/* 109 */     this(Arrays.asList(providers), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProviderManager(List<AuthenticationProvider> providers) {
/* 117 */     this(providers, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProviderManager(List<AuthenticationProvider> providers, AuthenticationManager parent) {
/* 126 */     Assert.notNull(providers, "providers list cannot be null");
/* 127 */     this.providers = providers;
/* 128 */     this.parent = parent;
/* 129 */     checkState();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() {
/* 134 */     checkState();
/*     */   }
/*     */   
/*     */   private void checkState() {
/* 138 */     Assert.isTrue((this.parent != null || !this.providers.isEmpty()), "A parent AuthenticationManager or a list of AuthenticationProviders is required");
/*     */     
/* 140 */     Assert.isTrue(!CollectionUtils.contains(this.providers.iterator(), null), "providers list cannot contain null values");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 166 */     Class<? extends Authentication> toTest = (Class)authentication.getClass();
/* 167 */     AuthenticationException lastException = null;
/* 168 */     AuthenticationException parentException = null;
/* 169 */     Authentication result = null;
/* 170 */     Authentication parentResult = null;
/* 171 */     int currentPosition = 0;
/* 172 */     int size = this.providers.size();
/* 173 */     for (AuthenticationProvider provider : getProviders()) {
/* 174 */       if (!provider.supports(toTest)) {
/*     */         continue;
/*     */       }
/* 177 */       if (logger.isTraceEnabled()) {
/* 178 */         logger.trace(LogMessage.format("Authenticating request with %s (%d/%d)", provider
/* 179 */               .getClass().getSimpleName(), Integer.valueOf(++currentPosition), Integer.valueOf(size)));
/*     */       }
/*     */       try {
/* 182 */         result = provider.authenticate(authentication);
/* 183 */         if (result != null) {
/* 184 */           copyDetails(authentication, result);
/*     */           
/*     */           break;
/*     */         } 
/* 188 */       } catch (AccountStatusException ex) {
/* 189 */         prepareException(ex, authentication);
/* 190 */         logger.debug(LogMessage.format("Authentication failed for user '%s' since their account status is %s", authentication
/* 191 */               .getName(), ex.getMessage()), (Throwable)ex);
/*     */ 
/*     */         
/* 194 */         throw ex;
/*     */       }
/* 196 */       catch (InternalAuthenticationServiceException ex) {
/* 197 */         prepareException(ex, authentication);
/* 198 */         logger.debug(LogMessage.format("Authentication service failed internally for user '%s'", authentication
/* 199 */               .getName()), (Throwable)ex);
/*     */ 
/*     */         
/* 202 */         throw ex;
/*     */       }
/* 204 */       catch (AuthenticationException ex) {
/* 205 */         ex.setAuthenticationRequest(authentication);
/* 206 */         logger.debug(LogMessage.format("Authentication failed with provider %s since %s", provider
/* 207 */               .getClass().getSimpleName(), ex.getMessage()));
/* 208 */         lastException = ex;
/*     */       } 
/*     */     } 
/* 211 */     if (result == null && this.parent != null) {
/*     */       
/*     */       try {
/* 214 */         parentResult = this.parent.authenticate(authentication);
/* 215 */         result = parentResult;
/*     */       }
/* 217 */       catch (ProviderNotFoundException providerNotFoundException) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 223 */       catch (AuthenticationException ex) {
/* 224 */         parentException = ex;
/* 225 */         lastException = ex;
/*     */       } 
/*     */     }
/* 228 */     if (result != null) {
/* 229 */       if (this.eraseCredentialsAfterAuthentication && result instanceof CredentialsContainer)
/*     */       {
/*     */         
/* 232 */         ((CredentialsContainer)result).eraseCredentials();
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 238 */       if (parentResult == null) {
/* 239 */         this.eventPublisher.publishAuthenticationSuccess(result);
/*     */       }
/*     */       
/* 242 */       return result;
/*     */     } 
/*     */ 
/*     */     
/* 246 */     if (lastException == null) {
/* 247 */       lastException = new ProviderNotFoundException(this.messages.getMessage("ProviderManager.providerNotFound", new Object[] { toTest
/* 248 */               .getName() }, "No AuthenticationProvider found for {0}"));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 254 */     if (parentException == null) {
/* 255 */       prepareException(lastException, authentication);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 260 */     if (this.parent != null) {
/* 261 */       logger.debug("Denying authentication since all attempted providers failed");
/*     */     }
/*     */     
/* 264 */     throw lastException;
/*     */   }
/*     */ 
/*     */   
/*     */   private void prepareException(AuthenticationException ex, Authentication auth) {
/* 269 */     ex.setAuthenticationRequest(auth);
/* 270 */     this.eventPublisher.publishAuthenticationFailure(ex, auth);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void copyDetails(Authentication source, Authentication dest) {
/* 280 */     if (dest instanceof AbstractAuthenticationToken) { AbstractAuthenticationToken token = (AbstractAuthenticationToken)dest; if (dest.getDetails() == null)
/* 281 */         token.setDetails(source.getDetails());  }
/*     */   
/*     */   }
/*     */   
/*     */   public List<AuthenticationProvider> getProviders() {
/* 286 */     return this.providers;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 291 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */   
/*     */   public void setAuthenticationEventPublisher(AuthenticationEventPublisher eventPublisher) {
/* 295 */     Assert.notNull(eventPublisher, "AuthenticationEventPublisher cannot be null");
/* 296 */     this.eventPublisher = eventPublisher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEraseCredentialsAfterAuthentication(boolean eraseSecretData) {
/* 308 */     this.eraseCredentialsAfterAuthentication = eraseSecretData;
/*     */   }
/*     */   
/*     */   public boolean isEraseCredentialsAfterAuthentication() {
/* 312 */     return this.eraseCredentialsAfterAuthentication;
/*     */   }
/*     */   
/*     */   private static final class NullEventPublisher implements AuthenticationEventPublisher {
/*     */     public void publishAuthenticationFailure(AuthenticationException exception, Authentication authentication) {}
/*     */     
/*     */     public void publishAuthenticationSuccess(Authentication authentication) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ProviderManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */