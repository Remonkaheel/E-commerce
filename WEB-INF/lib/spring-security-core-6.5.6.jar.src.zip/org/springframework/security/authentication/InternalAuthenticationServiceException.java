/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InternalAuthenticationServiceException
/*    */   extends AuthenticationServiceException
/*    */ {
/*    */   private static final long serialVersionUID = -6029644854192497840L;
/*    */   
/*    */   public InternalAuthenticationServiceException(String message, Throwable cause) {
/* 46 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public InternalAuthenticationServiceException(String message) {
/* 50 */     super(message);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\InternalAuthenticationServiceException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */