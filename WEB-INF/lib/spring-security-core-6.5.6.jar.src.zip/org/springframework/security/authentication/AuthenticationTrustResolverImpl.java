/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationTrustResolverImpl
/*    */   implements AuthenticationTrustResolver
/*    */ {
/* 34 */   private Class<? extends Authentication> anonymousClass = (Class)AnonymousAuthenticationToken.class;
/*    */   
/* 36 */   private Class<? extends Authentication> rememberMeClass = (Class)RememberMeAuthenticationToken.class;
/*    */   
/*    */   Class<? extends Authentication> getAnonymousClass() {
/* 39 */     return this.anonymousClass;
/*    */   }
/*    */   
/*    */   Class<? extends Authentication> getRememberMeClass() {
/* 43 */     return this.rememberMeClass;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isAnonymous(Authentication authentication) {
/* 48 */     if (this.anonymousClass == null || authentication == null) {
/* 49 */       return false;
/*    */     }
/* 51 */     return this.anonymousClass.isAssignableFrom(authentication.getClass());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isRememberMe(Authentication authentication) {
/* 56 */     if (this.rememberMeClass == null || authentication == null) {
/* 57 */       return false;
/*    */     }
/* 59 */     return this.rememberMeClass.isAssignableFrom(authentication.getClass());
/*    */   }
/*    */   
/*    */   public void setAnonymousClass(Class<? extends Authentication> anonymousClass) {
/* 63 */     this.anonymousClass = anonymousClass;
/*    */   }
/*    */   
/*    */   public void setRememberMeClass(Class<? extends Authentication> rememberMeClass) {
/* 67 */     this.rememberMeClass = rememberMeClass;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\AuthenticationTrustResolverImpl.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */