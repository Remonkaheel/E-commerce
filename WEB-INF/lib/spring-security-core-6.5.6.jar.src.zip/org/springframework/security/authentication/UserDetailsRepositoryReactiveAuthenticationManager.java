/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UserDetailsRepositoryReactiveAuthenticationManager
/*    */   extends AbstractUserDetailsReactiveAuthenticationManager
/*    */ {
/*    */   private ReactiveUserDetailsService userDetailsService;
/*    */   
/*    */   public UserDetailsRepositoryReactiveAuthenticationManager(ReactiveUserDetailsService userDetailsService) {
/* 39 */     Assert.notNull(userDetailsService, "userDetailsService cannot be null");
/* 40 */     this.userDetailsService = userDetailsService;
/*    */   }
/*    */ 
/*    */   
/*    */   protected Mono<UserDetails> retrieveUser(String username) {
/* 45 */     return this.userDetailsService.findByUsername(username);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\UserDetailsRepositoryReactiveAuthenticationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */