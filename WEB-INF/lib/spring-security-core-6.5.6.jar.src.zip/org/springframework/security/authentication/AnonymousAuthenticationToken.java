/*     */ package org.springframework.security.authentication;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnonymousAuthenticationToken
/*     */   extends AbstractAuthenticationToken
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final Object principal;
/*     */   private final int keyHash;
/*     */   
/*     */   public AnonymousAuthenticationToken(String key, Object principal, Collection<? extends GrantedAuthority> authorities) {
/*  47 */     this(extractKeyHash(key), principal, authorities);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AnonymousAuthenticationToken(Integer keyHash, Object principal, Collection<? extends GrantedAuthority> authorities) {
/*  59 */     super(authorities);
/*  60 */     Assert.isTrue((principal != null && !"".equals(principal)), "principal cannot be null or empty");
/*  61 */     Assert.notEmpty(authorities, "authorities cannot be null or empty");
/*  62 */     this.keyHash = keyHash.intValue();
/*  63 */     this.principal = principal;
/*  64 */     setAuthenticated(true);
/*     */   }
/*     */   
/*     */   private static Integer extractKeyHash(String key) {
/*  68 */     Assert.hasLength(key, "key cannot be empty or null");
/*  69 */     return Integer.valueOf(key.hashCode());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  74 */     if (!super.equals(obj)) {
/*  75 */       return false;
/*     */     }
/*  77 */     if (obj instanceof AnonymousAuthenticationToken) { AnonymousAuthenticationToken test = (AnonymousAuthenticationToken)obj;
/*  78 */       return (getKeyHash() == test.getKeyHash()); }
/*     */     
/*  80 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  85 */     int result = super.hashCode();
/*  86 */     result = 31 * result + this.keyHash;
/*  87 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getCredentials() {
/*  96 */     return "";
/*     */   }
/*     */   
/*     */   public int getKeyHash() {
/* 100 */     return this.keyHash;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getPrincipal() {
/* 105 */     return this.principal;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\AnonymousAuthenticationToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */