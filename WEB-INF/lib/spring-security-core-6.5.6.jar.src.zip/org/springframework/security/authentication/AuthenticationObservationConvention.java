/*     */ package org.springframework.security.authentication;
/*     */ 
/*     */ import io.micrometer.common.KeyValues;
/*     */ import io.micrometer.observation.Observation;
/*     */ import io.micrometer.observation.ObservationConvention;
/*     */ import java.util.Locale;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ import org.springframework.lang.NonNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthenticationObservationConvention
/*     */   implements ObservationConvention<AuthenticationObservationContext>
/*     */ {
/*     */   static final String OBSERVATION_NAME = "spring.security.authentications";
/*     */   
/*     */   public String getName() {
/*  45 */     return "spring.security.authentications";
/*     */   }
/*     */ 
/*     */   
/*     */   public String getContextualName(AuthenticationObservationContext context) {
/*  50 */     if (context.getAuthenticationRequest() != null) {
/*  51 */       String authenticationType = context.getAuthenticationRequest().getClass().getSimpleName();
/*  52 */       if (authenticationType.endsWith("Token")) {
/*  53 */         authenticationType = authenticationType.substring(0, authenticationType.lastIndexOf("Token"));
/*     */       }
/*  55 */       if (authenticationType.endsWith("Authentication")) {
/*  56 */         authenticationType = authenticationType.substring(0, authenticationType.lastIndexOf("Authentication"));
/*     */       }
/*  58 */       return "authenticate " + authenticationType.toLowerCase(Locale.ENGLISH);
/*     */     } 
/*  60 */     return "authenticate";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public KeyValues getLowCardinalityKeyValues(@NonNull AuthenticationObservationContext context) {
/*  69 */     return KeyValues.of("authentication.request.type", getAuthenticationType(context))
/*  70 */       .and("authentication.method", getAuthenticationMethod(context))
/*  71 */       .and("authentication.result.type", getAuthenticationResult(context))
/*  72 */       .and("authentication.failure.type", getAuthenticationFailureType(context));
/*     */   }
/*     */   
/*     */   private String getAuthenticationType(AuthenticationObservationContext context) {
/*  76 */     if (context.getAuthenticationRequest() == null) {
/*  77 */       return "unknown";
/*     */     }
/*  79 */     return context.getAuthenticationRequest().getClass().getSimpleName();
/*     */   }
/*     */   
/*     */   private String getAuthenticationMethod(AuthenticationObservationContext context) {
/*  83 */     if (context.getAuthenticationManagerClass() == null) {
/*  84 */       return "unknown";
/*     */     }
/*  86 */     return context.getAuthenticationManagerClass().getSimpleName();
/*     */   }
/*     */   
/*     */   private String getAuthenticationResult(AuthenticationObservationContext context) {
/*  90 */     if (context.getAuthenticationResult() == null) {
/*  91 */       return "n/a";
/*     */     }
/*  93 */     return context.getAuthenticationResult().getClass().getSimpleName();
/*     */   }
/*     */   
/*     */   private String getAuthenticationFailureType(AuthenticationObservationContext context) {
/*  97 */     if (context.getError() == null) {
/*  98 */       return "n/a";
/*     */     }
/* 100 */     return context.getError().getClass().getSimpleName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsContext(@NotNull Observation.Context context) {
/* 108 */     return context instanceof AuthenticationObservationContext;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\AuthenticationObservationConvention.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */