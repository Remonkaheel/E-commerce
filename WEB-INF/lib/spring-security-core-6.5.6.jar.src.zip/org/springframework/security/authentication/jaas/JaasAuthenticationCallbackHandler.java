package org.springframework.security.authentication.jaas;

import java.io.IOException;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.UnsupportedCallbackException;
import org.springframework.security.core.Authentication;

public interface JaasAuthenticationCallbackHandler {
  void handle(Callback paramCallback, Authentication paramAuthentication) throws IOException, UnsupportedCallbackException;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\jaas\JaasAuthenticationCallbackHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */