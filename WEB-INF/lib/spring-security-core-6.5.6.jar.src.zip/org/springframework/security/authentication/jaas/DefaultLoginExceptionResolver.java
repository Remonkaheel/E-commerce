/*    */ package org.springframework.security.authentication.jaas;
/*    */ 
/*    */ import javax.security.auth.login.LoginException;
/*    */ import org.springframework.security.authentication.AuthenticationServiceException;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultLoginExceptionResolver
/*    */   implements LoginExceptionResolver
/*    */ {
/*    */   public AuthenticationException resolveException(LoginException ex) {
/* 34 */     return (AuthenticationException)new AuthenticationServiceException(ex.getMessage(), ex);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\jaas\DefaultLoginExceptionResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */