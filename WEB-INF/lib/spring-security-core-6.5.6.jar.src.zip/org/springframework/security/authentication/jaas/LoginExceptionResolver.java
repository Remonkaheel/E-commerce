package org.springframework.security.authentication.jaas;

import javax.security.auth.login.LoginException;
import org.springframework.security.core.AuthenticationException;

public interface LoginExceptionResolver {
  AuthenticationException resolveException(LoginException paramLoginException);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\jaas\LoginExceptionResolver.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */