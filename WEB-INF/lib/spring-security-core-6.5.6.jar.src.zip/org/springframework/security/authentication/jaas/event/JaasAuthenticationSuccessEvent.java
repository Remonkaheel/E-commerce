/*    */ package org.springframework.security.authentication.jaas.event;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JaasAuthenticationSuccessEvent
/*    */   extends JaasAuthenticationEvent
/*    */ {
/*    */   private static final long serialVersionUID = 2236826715750256181L;
/*    */   
/*    */   public JaasAuthenticationSuccessEvent(Authentication auth) {
/* 37 */     super(auth);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\jaas\event\JaasAuthenticationSuccessEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */