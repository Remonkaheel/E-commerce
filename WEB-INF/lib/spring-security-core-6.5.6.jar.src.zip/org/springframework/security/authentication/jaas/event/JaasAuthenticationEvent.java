/*    */ package org.springframework.security.authentication.jaas.event;
/*    */ 
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class JaasAuthenticationEvent
/*    */   extends ApplicationEvent
/*    */ {
/*    */   public JaasAuthenticationEvent(Authentication auth) {
/* 36 */     super(auth);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Authentication getAuthentication() {
/* 44 */     return (Authentication)this.source;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\jaas\event\JaasAuthenticationEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */