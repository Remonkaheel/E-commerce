/*    */ package org.springframework.security.authentication.jaas;
/*    */ 
/*    */ import javax.security.auth.callback.Callback;
/*    */ import javax.security.auth.callback.PasswordCallback;
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JaasPasswordCallbackHandler
/*    */   implements JaasAuthenticationCallbackHandler
/*    */ {
/*    */   public void handle(Callback callback, Authentication auth) {
/* 49 */     if (callback instanceof PasswordCallback)
/* 50 */       ((PasswordCallback)callback).setPassword(auth.getCredentials().toString().toCharArray()); 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\jaas\JaasPasswordCallbackHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */