/*    */ package org.springframework.security.authentication.jaas;
/*    */ 
/*    */ import javax.security.auth.callback.Callback;
/*    */ import javax.security.auth.callback.NameCallback;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JaasNameCallbackHandler
/*    */   implements JaasAuthenticationCallbackHandler
/*    */ {
/*    */   public void handle(Callback callback, Authentication authentication) {
/* 48 */     if (callback instanceof NameCallback) {
/* 49 */       ((NameCallback)callback).setName(getUserName(authentication));
/*    */     }
/*    */   }
/*    */   
/*    */   private String getUserName(Authentication authentication) {
/* 54 */     Object principal = authentication.getPrincipal();
/* 55 */     if (principal instanceof UserDetails) {
/* 56 */       return ((UserDetails)principal).getUsername();
/*    */     }
/* 58 */     return principal.toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\jaas\JaasNameCallbackHandler.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */