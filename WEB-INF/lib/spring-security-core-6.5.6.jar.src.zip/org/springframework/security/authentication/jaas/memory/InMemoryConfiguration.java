/*    */ package org.springframework.security.authentication.jaas.memory;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.Map;
/*    */ import javax.security.auth.login.AppConfigurationEntry;
/*    */ import javax.security.auth.login.Configuration;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InMemoryConfiguration
/*    */   extends Configuration
/*    */ {
/*    */   private final AppConfigurationEntry[] defaultConfiguration;
/*    */   private final Map<String, AppConfigurationEntry[]> mappedConfigurations;
/*    */   
/*    */   public InMemoryConfiguration(AppConfigurationEntry[] defaultConfiguration) {
/* 51 */     this((Map)Collections.emptyMap(), defaultConfiguration);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InMemoryConfiguration(Map<String, AppConfigurationEntry[]> mappedConfigurations) {
/* 61 */     this(mappedConfigurations, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public InMemoryConfiguration(Map<String, AppConfigurationEntry[]> mappedConfigurations, AppConfigurationEntry[] defaultConfiguration) {
/* 75 */     Assert.notNull(mappedConfigurations, "mappedConfigurations cannot be null.");
/* 76 */     this.mappedConfigurations = mappedConfigurations;
/* 77 */     this.defaultConfiguration = defaultConfiguration;
/*    */   }
/*    */ 
/*    */   
/*    */   public AppConfigurationEntry[] getAppConfigurationEntry(String name) {
/* 82 */     AppConfigurationEntry[] mappedResult = this.mappedConfigurations.get(name);
/* 83 */     return (mappedResult != null) ? mappedResult : this.defaultConfiguration;
/*    */   }
/*    */   
/*    */   public void refresh() {}
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\jaas\memory\InMemoryConfiguration.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */