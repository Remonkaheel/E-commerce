/*    */ package org.springframework.security.authentication.jaas.event;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JaasAuthenticationFailedEvent
/*    */   extends JaasAuthenticationEvent
/*    */ {
/*    */   private static final long serialVersionUID = -240510538971925002L;
/*    */   private final Exception exception;
/*    */   
/*    */   public JaasAuthenticationFailedEvent(Authentication auth, Exception exception) {
/* 37 */     super(auth);
/* 38 */     this.exception = exception;
/*    */   }
/*    */   
/*    */   public Exception getException() {
/* 42 */     return this.exception;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\jaas\event\JaasAuthenticationFailedEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */