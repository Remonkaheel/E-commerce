/*     */ package org.springframework.security.authentication.jaas;
/*     */ 
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.login.Configuration;
/*     */ import javax.security.auth.login.LoginContext;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultJaasAuthenticationProvider
/*     */   extends AbstractJaasAuthenticationProvider
/*     */ {
/*     */   private Configuration configuration;
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/*  94 */     super.afterPropertiesSet();
/*  95 */     Assert.notNull(this.configuration, "configuration cannot be null.");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LoginContext createLoginContext(CallbackHandler handler) throws LoginException {
/* 104 */     return new LoginContext(getLoginContextName(), null, handler, getConfiguration());
/*     */   }
/*     */   
/*     */   protected Configuration getConfiguration() {
/* 108 */     return this.configuration;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConfiguration(Configuration configuration) {
/* 117 */     this.configuration = configuration;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\jaas\DefaultJaasAuthenticationProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */