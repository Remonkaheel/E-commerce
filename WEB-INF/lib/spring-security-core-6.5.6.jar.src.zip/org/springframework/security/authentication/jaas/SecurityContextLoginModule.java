/*     */ package org.springframework.security.authentication.jaas;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import javax.security.auth.spi.LoginModule;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.context.SecurityContextHolder;
/*     */ import org.springframework.security.core.context.SecurityContextHolderStrategy;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecurityContextLoginModule
/*     */   implements LoginModule
/*     */ {
/*  58 */   private static final Log log = LogFactory.getLog(SecurityContextLoginModule.class);
/*     */ 
/*     */   
/*  61 */   private SecurityContextHolderStrategy securityContextHolderStrategy = SecurityContextHolder.getContextHolderStrategy();
/*     */ 
/*     */ 
/*     */   
/*     */   private Authentication authen;
/*     */ 
/*     */ 
/*     */   
/*     */   private Subject subject;
/*     */ 
/*     */   
/*     */   private boolean ignoreMissingAuthentication = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean abort() {
/*  77 */     if (this.authen == null) {
/*  78 */       return false;
/*     */     }
/*  80 */     this.authen = null;
/*  81 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean commit() {
/*  92 */     if (this.authen == null) {
/*  93 */       return false;
/*     */     }
/*  95 */     this.subject.getPrincipals().add(this.authen);
/*  96 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSecurityContextHolderStrategy(SecurityContextHolderStrategy securityContextHolderStrategy) {
/* 106 */     Assert.notNull(securityContextHolderStrategy, "securityContextHolderStrategy cannot be null");
/* 107 */     this.securityContextHolderStrategy = securityContextHolderStrategy;
/*     */   }
/*     */   
/*     */   Authentication getAuthentication() {
/* 111 */     return this.authen;
/*     */   }
/*     */   
/*     */   Subject getSubject() {
/* 115 */     return this.subject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(Subject subject, CallbackHandler callbackHandler, Map sharedState, Map options) {
/* 131 */     this.subject = subject;
/* 132 */     if (options != null) {
/* 133 */       this.ignoreMissingAuthentication = "true".equals(options.get("ignoreMissingAuthentication"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean login() throws LoginException {
/* 146 */     this.authen = this.securityContextHolderStrategy.getContext().getAuthentication();
/* 147 */     if (this.authen != null) {
/* 148 */       return true;
/*     */     }
/* 150 */     String msg = "Login cannot complete, authentication not found in security context";
/* 151 */     if (!this.ignoreMissingAuthentication) {
/* 152 */       throw new LoginException(msg);
/*     */     }
/* 154 */     log.warn(msg);
/* 155 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean logout() {
/* 165 */     if (this.authen == null) {
/* 166 */       return false;
/*     */     }
/* 168 */     this.subject.getPrincipals().remove(this.authen);
/* 169 */     this.authen = null;
/* 170 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\jaas\SecurityContextLoginModule.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */