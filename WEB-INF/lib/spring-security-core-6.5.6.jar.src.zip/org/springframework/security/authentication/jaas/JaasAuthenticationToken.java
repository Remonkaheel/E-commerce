/*    */ package org.springframework.security.authentication.jaas;
/*    */ 
/*    */ import java.util.List;
/*    */ import javax.security.auth.login.LoginContext;
/*    */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JaasAuthenticationToken
/*    */   extends UsernamePasswordAuthenticationToken
/*    */ {
/*    */   private static final long serialVersionUID = 620L;
/*    */   private final transient LoginContext loginContext;
/*    */   
/*    */   public JaasAuthenticationToken(Object principal, Object credentials, LoginContext loginContext) {
/* 40 */     super(principal, credentials);
/* 41 */     this.loginContext = loginContext;
/*    */   }
/*    */ 
/*    */   
/*    */   public JaasAuthenticationToken(Object principal, Object credentials, List<GrantedAuthority> authorities, LoginContext loginContext) {
/* 46 */     super(principal, credentials, authorities);
/* 47 */     this.loginContext = loginContext;
/*    */   }
/*    */   
/*    */   public LoginContext getLoginContext() {
/* 51 */     return this.loginContext;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\jaas\JaasAuthenticationToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */