/*    */ package org.springframework.security.authentication.jaas;
/*    */ 
/*    */ import java.security.Principal;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JaasGrantedAuthority
/*    */   implements GrantedAuthority
/*    */ {
/*    */   private static final long serialVersionUID = 620L;
/*    */   private final String role;
/*    */   private final Principal principal;
/*    */   
/*    */   public JaasGrantedAuthority(String role, Principal principal) {
/* 41 */     Assert.notNull(role, "role cannot be null");
/* 42 */     Assert.notNull(principal, "principal cannot be null");
/* 43 */     this.role = role;
/* 44 */     this.principal = principal;
/*    */   }
/*    */   
/*    */   public Principal getPrincipal() {
/* 48 */     return this.principal;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAuthority() {
/* 53 */     return this.role;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 58 */     if (this == obj) {
/* 59 */       return true;
/*    */     }
/* 61 */     if (obj instanceof JaasGrantedAuthority) { JaasGrantedAuthority jga = (JaasGrantedAuthority)obj;
/* 62 */       return (this.role.equals(jga.getAuthority()) && this.principal.equals(jga.getPrincipal())); }
/*    */     
/* 64 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 69 */     int result = this.principal.hashCode();
/* 70 */     result = 31 * result + this.role.hashCode();
/* 71 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 76 */     return "Jaas Authority [" + this.role + "," + String.valueOf(this.principal) + "]";
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\jaas\JaasGrantedAuthority.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */