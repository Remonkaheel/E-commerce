/*     */ package org.springframework.security.authentication.jaas;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.security.Security;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.login.Configuration;
/*     */ import javax.security.auth.login.LoginContext;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.authentication.jaas.event.JaasAuthenticationFailedEvent;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JaasAuthenticationProvider
/*     */   extends AbstractJaasAuthenticationProvider
/*     */ {
/* 144 */   protected static final Log log = LogFactory.getLog(JaasAuthenticationProvider.class);
/*     */ 
/*     */   
/*     */   private Resource loginConfig;
/*     */ 
/*     */   
/*     */   private boolean refreshConfigurationOnStartup = true;
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 154 */     Assert.hasLength(getLoginContextName(), () -> "loginContextName must be set on " + String.valueOf(getClass()));
/* 155 */     Assert.notNull(this.loginConfig, () -> "loginConfig must be set on " + String.valueOf(getClass()));
/* 156 */     configureJaas(this.loginConfig);
/* 157 */     Assert.notNull(Configuration.getConfiguration(), "As per https://java.sun.com/j2se/1.5.0/docs/api/javax/security/auth/login/Configuration.html \"If a Configuration object was set via the Configuration.setConfiguration method, then that object is returned. Otherwise, a default Configuration object is returned\". Your JRE returned null to Configuration.getConfiguration().");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LoginContext createLoginContext(CallbackHandler handler) throws LoginException {
/* 166 */     return new LoginContext(getLoginContextName(), handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void configureJaas(Resource loginConfig) throws IOException {
/* 175 */     configureJaasUsingLoop();
/* 176 */     if (this.refreshConfigurationOnStartup)
/*     */     {
/* 178 */       Configuration.getConfiguration().refresh();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void configureJaasUsingLoop() throws IOException {
/* 189 */     String loginConfigUrl = convertLoginConfigToUrl();
/* 190 */     boolean alreadySet = false;
/* 191 */     int n = 1;
/* 192 */     String prefix = "login.config.url.";
/*     */     String existing;
/* 194 */     while ((existing = Security.getProperty("login.config.url." + n)) != null) {
/* 195 */       alreadySet = existing.equals(loginConfigUrl);
/* 196 */       if (alreadySet) {
/*     */         break;
/*     */       }
/* 199 */       n++;
/*     */     } 
/* 201 */     if (!alreadySet) {
/* 202 */       String key = "login.config.url." + n;
/* 203 */       log.debug(LogMessage.format("Setting security property [%s] to: %s", key, loginConfigUrl));
/* 204 */       Security.setProperty(key, loginConfigUrl);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String convertLoginConfigToUrl() throws IOException {
/*     */     try {
/* 211 */       String loginConfigPath = this.loginConfig.getFile().getAbsolutePath().replace(File.separatorChar, '/');
/* 212 */       if (!loginConfigPath.startsWith("/")) {
/* 213 */         loginConfigPath = "/" + loginConfigPath;
/*     */       }
/* 215 */       return (new URL("file", "", loginConfigPath)).toString();
/*     */     }
/* 217 */     catch (IOException ex) {
/*     */       
/* 219 */       return this.loginConfig.getURL().toString();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void publishFailureEvent(UsernamePasswordAuthenticationToken token, AuthenticationException ase) {
/* 232 */     getApplicationEventPublisher().publishEvent((ApplicationEvent)new JaasAuthenticationFailedEvent((Authentication)token, (Exception)ase));
/*     */   }
/*     */   
/*     */   public Resource getLoginConfig() {
/* 236 */     return this.loginConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoginConfig(Resource loginConfig) {
/* 248 */     this.loginConfig = loginConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRefreshConfigurationOnStartup(boolean refresh) {
/* 259 */     this.refreshConfigurationOnStartup = refresh;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\jaas\JaasAuthenticationProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */