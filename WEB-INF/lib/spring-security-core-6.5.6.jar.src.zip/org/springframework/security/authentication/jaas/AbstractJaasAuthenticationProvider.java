/*     */ package org.springframework.security.authentication.jaas;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.Principal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.security.auth.callback.Callback;
/*     */ import javax.security.auth.callback.CallbackHandler;
/*     */ import javax.security.auth.callback.UnsupportedCallbackException;
/*     */ import javax.security.auth.login.LoginContext;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationEventPublisher;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.authentication.jaas.event.JaasAuthenticationFailedEvent;
/*     */ import org.springframework.security.authentication.jaas.event.JaasAuthenticationSuccessEvent;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.security.core.context.SecurityContext;
/*     */ import org.springframework.security.core.session.SessionDestroyedEvent;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJaasAuthenticationProvider
/*     */   implements AuthenticationProvider, ApplicationEventPublisherAware, InitializingBean, ApplicationListener<SessionDestroyedEvent>
/*     */ {
/*     */   private ApplicationEventPublisher applicationEventPublisher;
/*     */   private AuthorityGranter[] authorityGranters;
/*     */   private JaasAuthenticationCallbackHandler[] callbackHandlers;
/* 128 */   protected final Log log = LogFactory.getLog(getClass());
/*     */   
/* 130 */   private LoginExceptionResolver loginExceptionResolver = new DefaultLoginExceptionResolver();
/*     */   
/* 132 */   private String loginContextName = "SPRINGSECURITY";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 142 */     Assert.hasLength(this.loginContextName, "loginContextName cannot be null or empty");
/* 143 */     Assert.notEmpty((Object[])this.authorityGranters, "authorityGranters cannot be null or empty");
/* 144 */     if (ObjectUtils.isEmpty((Object[])this.callbackHandlers)) {
/* 145 */       setCallbackHandlers(new JaasAuthenticationCallbackHandler[] { new JaasNameCallbackHandler(), new JaasPasswordCallbackHandler() });
/*     */     }
/*     */     
/* 148 */     Assert.notNull(this.loginExceptionResolver, "loginExceptionResolver cannot be null");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Authentication authenticate(Authentication auth) throws AuthenticationException {
/*     */     UsernamePasswordAuthenticationToken request;
/* 163 */     if (auth instanceof UsernamePasswordAuthenticationToken) { request = (UsernamePasswordAuthenticationToken)auth; }
/* 164 */     else { return null; }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 169 */       LoginContext loginContext = createLoginContext(new InternalCallbackHandler(auth));
/*     */ 
/*     */       
/* 172 */       loginContext.login();
/*     */       
/* 174 */       Set<Principal> principals = loginContext.getSubject().getPrincipals();
/*     */ 
/*     */       
/* 177 */       Set<GrantedAuthority> authorities = getAuthorities(principals);
/*     */ 
/*     */       
/* 180 */       JaasAuthenticationToken result = new JaasAuthenticationToken(request.getPrincipal(), request.getCredentials(), new ArrayList<>(authorities), loginContext);
/*     */       
/* 182 */       publishSuccessEvent(result);
/*     */       
/* 184 */       return (Authentication)result;
/*     */     
/*     */     }
/* 187 */     catch (LoginException ex) {
/* 188 */       AuthenticationException resolvedException = this.loginExceptionResolver.resolveException(ex);
/* 189 */       publishFailureEvent(request, resolvedException);
/* 190 */       throw resolvedException;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private Set<GrantedAuthority> getAuthorities(Set<Principal> principals) {
/* 196 */     Set<GrantedAuthority> authorities = new HashSet<>();
/* 197 */     for (Principal principal : principals) {
/* 198 */       for (AuthorityGranter granter : this.authorityGranters) {
/* 199 */         Set<String> roles = granter.grant(principal);
/*     */ 
/*     */         
/* 202 */         if (!CollectionUtils.isEmpty(roles)) {
/* 203 */           for (String role : roles) {
/* 204 */             authorities.add(new JaasGrantedAuthority(role, principal));
/*     */           }
/*     */         }
/*     */       } 
/*     */     } 
/* 209 */     return authorities;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleLogout(SessionDestroyedEvent event) {
/* 228 */     List<SecurityContext> contexts = event.getSecurityContexts();
/* 229 */     if (contexts.isEmpty()) {
/* 230 */       this.log.debug("The destroyed session has no SecurityContexts");
/*     */       return;
/*     */     } 
/* 233 */     for (SecurityContext context : contexts) {
/* 234 */       Authentication auth = context.getAuthentication();
/* 235 */       if (auth instanceof JaasAuthenticationToken) { JaasAuthenticationToken token = (JaasAuthenticationToken)auth;
/*     */         try {
/* 237 */           LoginContext loginContext = token.getLoginContext();
/* 238 */           logout(token, loginContext);
/*     */         }
/* 240 */         catch (LoginException ex) {
/* 241 */           this.log.warn("Error error logging out of LoginContext", ex);
/*     */         }  }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   private void logout(JaasAuthenticationToken token, LoginContext loginContext) throws LoginException {
/* 248 */     if (loginContext != null) {
/* 249 */       this.log
/* 250 */         .debug(LogMessage.of(() -> "Logging principal: [" + String.valueOf(token.getPrincipal()) + "] out of LoginContext"));
/* 251 */       loginContext.logout();
/*     */       return;
/*     */     } 
/* 254 */     this.log.debug(LogMessage.of(() -> "Cannot logout principal: [" + String.valueOf(token.getPrincipal()) + "] from LoginContext. The LoginContext is unavailable"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onApplicationEvent(SessionDestroyedEvent event) {
/* 260 */     handleLogout(event);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void publishFailureEvent(UsernamePasswordAuthenticationToken token, AuthenticationException ase) {
/* 270 */     if (this.applicationEventPublisher != null) {
/* 271 */       this.applicationEventPublisher.publishEvent((ApplicationEvent)new JaasAuthenticationFailedEvent((Authentication)token, (Exception)ase));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void publishSuccessEvent(UsernamePasswordAuthenticationToken token) {
/* 281 */     if (this.applicationEventPublisher != null) {
/* 282 */       this.applicationEventPublisher.publishEvent((ApplicationEvent)new JaasAuthenticationSuccessEvent((Authentication)token));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AuthorityGranter[] getAuthorityGranters() {
/* 295 */     return this.authorityGranters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAuthorityGranters(AuthorityGranter[] authorityGranters) {
/* 306 */     this.authorityGranters = authorityGranters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JaasAuthenticationCallbackHandler[] getCallbackHandlers() {
/* 317 */     return this.callbackHandlers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCallbackHandlers(JaasAuthenticationCallbackHandler[] callbackHandlers) {
/* 326 */     this.callbackHandlers = callbackHandlers;
/*     */   }
/*     */   
/*     */   String getLoginContextName() {
/* 330 */     return this.loginContextName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoginContextName(String loginContextName) {
/* 339 */     this.loginContextName = loginContextName;
/*     */   }
/*     */   
/*     */   LoginExceptionResolver getLoginExceptionResolver() {
/* 343 */     return this.loginExceptionResolver;
/*     */   }
/*     */   
/*     */   public void setLoginExceptionResolver(LoginExceptionResolver loginExceptionResolver) {
/* 347 */     this.loginExceptionResolver = loginExceptionResolver;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supports(Class<?> aClass) {
/* 352 */     return UsernamePasswordAuthenticationToken.class.isAssignableFrom(aClass);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
/* 357 */     this.applicationEventPublisher = applicationEventPublisher;
/*     */   }
/*     */   
/*     */   protected ApplicationEventPublisher getApplicationEventPublisher() {
/* 361 */     return this.applicationEventPublisher;
/*     */   }
/*     */   
/*     */   protected abstract LoginContext createLoginContext(CallbackHandler paramCallbackHandler) throws LoginException;
/*     */   
/*     */   private class InternalCallbackHandler
/*     */     implements CallbackHandler
/*     */   {
/*     */     private final Authentication authentication;
/*     */     
/*     */     InternalCallbackHandler(Authentication authentication) {
/* 372 */       this.authentication = authentication;
/*     */     }
/*     */ 
/*     */     
/*     */     public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
/* 377 */       for (JaasAuthenticationCallbackHandler handler : AbstractJaasAuthenticationProvider.this.callbackHandlers) {
/* 378 */         for (Callback callback : callbacks)
/* 379 */           handler.handle(callback, this.authentication); 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\jaas\AbstractJaasAuthenticationProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */