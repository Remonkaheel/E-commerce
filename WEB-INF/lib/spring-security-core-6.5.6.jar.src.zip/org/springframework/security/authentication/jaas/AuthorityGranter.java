package org.springframework.security.authentication.jaas;

import java.security.Principal;
import java.util.Set;

public interface AuthorityGranter {
  Set<String> grant(Principal paramPrincipal);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\jaas\AuthorityGranter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */