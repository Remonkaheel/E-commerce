package org.springframework.security.authentication;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

public interface AuthenticationProvider {
  Authentication authenticate(Authentication paramAuthentication) throws AuthenticationException;
  
  boolean supports(Class<?> paramClass);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\AuthenticationProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */