/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.context.MessageSourceAware;
/*    */ import org.springframework.context.support.MessageSourceAccessor;
/*    */ import org.springframework.security.core.SpringSecurityMessageSource;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ import org.springframework.security.core.userdetails.UserDetailsChecker;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccountStatusUserDetailsChecker
/*    */   implements UserDetailsChecker, MessageSourceAware
/*    */ {
/* 35 */   private final Log logger = LogFactory.getLog(getClass());
/*    */   
/* 37 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*    */ 
/*    */   
/*    */   public void check(UserDetails user) {
/* 41 */     if (!user.isAccountNonLocked()) {
/* 42 */       this.logger.debug("Failed to authenticate since user account is locked");
/* 43 */       throw new LockedException(this.messages
/* 44 */           .getMessage("AccountStatusUserDetailsChecker.locked", "User account is locked"));
/*    */     } 
/* 46 */     if (!user.isEnabled()) {
/* 47 */       this.logger.debug("Failed to authenticate since user account is disabled");
/* 48 */       throw new DisabledException(this.messages
/* 49 */           .getMessage("AccountStatusUserDetailsChecker.disabled", "User is disabled"));
/*    */     } 
/* 51 */     if (!user.isAccountNonExpired()) {
/* 52 */       this.logger.debug("Failed to authenticate since user account is expired");
/* 53 */       throw new AccountExpiredException(this.messages
/* 54 */           .getMessage("AccountStatusUserDetailsChecker.expired", "User account has expired"));
/*    */     } 
/* 56 */     if (!user.isCredentialsNonExpired()) {
/* 57 */       this.logger.debug("Failed to authenticate since user account credentials have expired");
/* 58 */       throw new CredentialsExpiredException(this.messages
/* 59 */           .getMessage("AccountStatusUserDetailsChecker.credentialsExpired", "User credentials have expired"));
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setMessageSource(MessageSource messageSource) {
/* 68 */     Assert.notNull(messageSource, "messageSource cannot be null");
/* 69 */     this.messages = new MessageSourceAccessor(messageSource);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\AccountStatusUserDetailsChecker.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */