/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.context.MessageSourceAware;
/*    */ import org.springframework.context.support.MessageSourceAccessor;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.core.SpringSecurityMessageSource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnonymousAuthenticationProvider
/*    */   implements AuthenticationProvider, MessageSourceAware
/*    */ {
/* 38 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*    */   
/*    */   private String key;
/*    */   
/*    */   public AnonymousAuthenticationProvider(String key) {
/* 43 */     Assert.hasLength(key, "A Key is required");
/* 44 */     this.key = key;
/*    */   }
/*    */ 
/*    */   
/*    */   public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 49 */     if (!supports(authentication.getClass())) {
/* 50 */       return null;
/*    */     }
/* 52 */     if (this.key.hashCode() != ((AnonymousAuthenticationToken)authentication).getKeyHash()) {
/* 53 */       throw new BadCredentialsException(this.messages.getMessage("AnonymousAuthenticationProvider.incorrectKey", "The presented AnonymousAuthenticationToken does not contain the expected key"));
/*    */     }
/*    */     
/* 56 */     return authentication;
/*    */   }
/*    */   
/*    */   public String getKey() {
/* 60 */     return this.key;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setMessageSource(MessageSource messageSource) {
/* 65 */     Assert.notNull(messageSource, "messageSource cannot be null");
/* 66 */     this.messages = new MessageSourceAccessor(messageSource);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(Class<?> authentication) {
/* 71 */     return AnonymousAuthenticationToken.class.isAssignableFrom(authentication);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\AnonymousAuthenticationProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */