/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.core.scheduler.Scheduler;
/*    */ import reactor.core.scheduler.Schedulers;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReactiveAuthenticationManagerAdapter
/*    */   implements ReactiveAuthenticationManager
/*    */ {
/*    */   private final AuthenticationManager authenticationManager;
/* 41 */   private Scheduler scheduler = Schedulers.boundedElastic();
/*    */   
/*    */   public ReactiveAuthenticationManagerAdapter(AuthenticationManager authenticationManager) {
/* 44 */     Assert.notNull(authenticationManager, "authenticationManager cannot be null");
/* 45 */     this.authenticationManager = authenticationManager;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Mono<Authentication> authenticate(Authentication token) {
/* 51 */     return Mono.just(token)
/* 52 */       .publishOn(this.scheduler)
/* 53 */       .flatMap(this::doAuthenticate)
/* 54 */       .filter(Authentication::isAuthenticated);
/*    */   }
/*    */ 
/*    */   
/*    */   private Mono<Authentication> doAuthenticate(Authentication authentication) {
/*    */     try {
/* 60 */       return Mono.just(this.authenticationManager.authenticate(authentication));
/*    */     }
/* 62 */     catch (Throwable ex) {
/* 63 */       return Mono.error(ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setScheduler(Scheduler scheduler) {
/* 73 */     Assert.notNull(scheduler, "scheduler cannot be null");
/* 74 */     this.scheduler = scheduler;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ReactiveAuthenticationManagerAdapter.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */