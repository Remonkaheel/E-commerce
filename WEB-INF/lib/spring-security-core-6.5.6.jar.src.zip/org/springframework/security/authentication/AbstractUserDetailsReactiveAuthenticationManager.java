/*     */ package org.springframework.security.authentication;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.security.authentication.password.CompromisedPasswordDecision;
/*     */ import org.springframework.security.authentication.password.CompromisedPasswordException;
/*     */ import org.springframework.security.authentication.password.ReactiveCompromisedPasswordChecker;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.security.core.userdetails.ReactiveUserDetailsPasswordService;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UserDetailsChecker;
/*     */ import org.springframework.security.crypto.factory.PasswordEncoderFactories;
/*     */ import org.springframework.security.crypto.password.PasswordEncoder;
/*     */ import org.springframework.util.Assert;
/*     */ import reactor.core.publisher.Mono;
/*     */ import reactor.core.scheduler.Scheduler;
/*     */ import reactor.core.scheduler.Schedulers;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractUserDetailsReactiveAuthenticationManager
/*     */   implements ReactiveAuthenticationManager, MessageSourceAware
/*     */ {
/*  57 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  59 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */   
/*  61 */   private PasswordEncoder passwordEncoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
/*     */   
/*     */   private ReactiveUserDetailsPasswordService userDetailsPasswordService;
/*     */   
/*  65 */   private Scheduler scheduler = Schedulers.boundedElastic();
/*     */   
/*  67 */   private UserDetailsChecker preAuthenticationChecks = this::defaultPreAuthenticationChecks;
/*     */   
/*  69 */   private UserDetailsChecker postAuthenticationChecks = this::defaultPostAuthenticationChecks;
/*     */   
/*     */   private ReactiveCompromisedPasswordChecker compromisedPasswordChecker;
/*     */   
/*     */   private void defaultPreAuthenticationChecks(UserDetails user) {
/*  74 */     if (!user.isAccountNonLocked()) {
/*  75 */       this.logger.debug("User account is locked");
/*  76 */       throw new LockedException(this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.locked", "User account is locked"));
/*     */     } 
/*     */     
/*  79 */     if (!user.isEnabled()) {
/*  80 */       this.logger.debug("User account is disabled");
/*  81 */       throw new DisabledException(this.messages
/*  82 */           .getMessage("AbstractUserDetailsAuthenticationProvider.disabled", "User is disabled"));
/*     */     } 
/*  84 */     if (!user.isAccountNonExpired()) {
/*  85 */       this.logger.debug("User account is expired");
/*  86 */       throw new AccountExpiredException(this.messages
/*  87 */           .getMessage("AbstractUserDetailsAuthenticationProvider.expired", "User account has expired"));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void defaultPostAuthenticationChecks(UserDetails user) {
/*  92 */     if (!user.isCredentialsNonExpired()) {
/*  93 */       this.logger.debug("User account credentials have expired");
/*  94 */       throw new CredentialsExpiredException(this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.credentialsExpired", "User credentials have expired"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Mono<Authentication> authenticate(Authentication authentication) {
/* 101 */     String username = authentication.getName();
/* 102 */     String presentedPassword = (String)authentication.getCredentials();
/*     */ 
/*     */     
/* 105 */     Objects.requireNonNull(this.preAuthenticationChecks);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     Objects.requireNonNull(this.postAuthenticationChecks); return retrieveUser(username).doOnNext(this.preAuthenticationChecks::check).publishOn(this.scheduler).filter(userDetails -> this.passwordEncoder.matches(presentedPassword, userDetails.getPassword())).switchIfEmpty(Mono.defer(() -> Mono.error((Throwable)new BadCredentialsException("Invalid Credentials")))).flatMap(userDetails -> checkCompromisedPassword(presentedPassword).thenReturn(userDetails)).flatMap(userDetails -> upgradeEncodingIfNecessary(userDetails, presentedPassword)).doOnNext(this.postAuthenticationChecks::check)
/* 112 */       .map(this::createUsernamePasswordAuthenticationToken);
/*     */   }
/*     */ 
/*     */   
/*     */   private Mono<Void> checkCompromisedPassword(String password) {
/* 117 */     if (this.compromisedPasswordChecker == null) {
/* 118 */       return Mono.empty();
/*     */     }
/* 120 */     return this.compromisedPasswordChecker.check(password)
/* 121 */       .filter(CompromisedPasswordDecision::isCompromised)
/* 122 */       .flatMap(compromised -> Mono.error((Throwable)new CompromisedPasswordException("The provided password is compromised, please change your password")));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Mono<UserDetails> upgradeEncodingIfNecessary(UserDetails userDetails, String presentedPassword) {
/* 128 */     boolean upgradeEncoding = (this.userDetailsPasswordService != null && this.passwordEncoder.upgradeEncoding(userDetails.getPassword()));
/* 129 */     if (upgradeEncoding) {
/* 130 */       String newPassword = this.passwordEncoder.encode(presentedPassword);
/* 131 */       return this.userDetailsPasswordService.updatePassword(userDetails, newPassword);
/*     */     } 
/* 133 */     return Mono.just(userDetails);
/*     */   }
/*     */   
/*     */   private UsernamePasswordAuthenticationToken createUsernamePasswordAuthenticationToken(UserDetails userDetails) {
/* 137 */     return UsernamePasswordAuthenticationToken.authenticated(userDetails, userDetails.getPassword(), userDetails
/* 138 */         .getAuthorities());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPasswordEncoder(PasswordEncoder passwordEncoder) {
/* 147 */     Assert.notNull(passwordEncoder, "passwordEncoder cannot be null");
/* 148 */     this.passwordEncoder = passwordEncoder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScheduler(Scheduler scheduler) {
/* 164 */     Assert.notNull(scheduler, "scheduler cannot be null");
/* 165 */     this.scheduler = scheduler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUserDetailsPasswordService(ReactiveUserDetailsPasswordService userDetailsPasswordService) {
/* 173 */     this.userDetailsPasswordService = userDetailsPasswordService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPostAuthenticationChecks(UserDetailsChecker postAuthenticationChecks) {
/* 183 */     Assert.notNull(this.postAuthenticationChecks, "postAuthenticationChecks cannot be null");
/* 184 */     this.postAuthenticationChecks = postAuthenticationChecks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 192 */     Assert.notNull(messageSource, "messageSource cannot be null");
/* 193 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCompromisedPasswordChecker(ReactiveCompromisedPasswordChecker compromisedPasswordChecker) {
/* 203 */     this.compromisedPasswordChecker = compromisedPasswordChecker;
/*     */   }
/*     */   
/*     */   protected abstract Mono<UserDetails> retrieveUser(String paramString);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\AbstractUserDetailsReactiveAuthenticationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */