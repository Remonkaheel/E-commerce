/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.Objects;
/*    */ import java.util.function.Function;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Flux;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DelegatingReactiveAuthenticationManager
/*    */   implements ReactiveAuthenticationManager
/*    */ {
/*    */   private final List<ReactiveAuthenticationManager> delegates;
/*    */   private boolean continueOnError = false;
/* 47 */   private final Log logger = LogFactory.getLog(getClass());
/*    */   
/*    */   public DelegatingReactiveAuthenticationManager(ReactiveAuthenticationManager... entryPoints) {
/* 50 */     this(Arrays.asList(entryPoints));
/*    */   }
/*    */   
/*    */   public DelegatingReactiveAuthenticationManager(List<ReactiveAuthenticationManager> entryPoints) {
/* 54 */     Assert.notEmpty(entryPoints, "entryPoints cannot be null");
/* 55 */     this.delegates = entryPoints;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Authentication> authenticate(Authentication authentication) {
/* 60 */     Flux<ReactiveAuthenticationManager> result = Flux.fromIterable(this.delegates);
/* 61 */     Function<ReactiveAuthenticationManager, Mono<Authentication>> logging = m -> {
/*    */         Objects.requireNonNull(this.logger);
/*    */         return m.authenticate(authentication).doOnError(AuthenticationException.class, ()).doOnError(this.logger::debug);
/*    */       };
/* 65 */     return (this.continueOnError ? result.concatMapDelayError(logging) : result.concatMap(logging)).next();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setContinueOnError(boolean continueOnError) {
/* 74 */     this.continueOnError = continueOnError;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\DelegatingReactiveAuthenticationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */