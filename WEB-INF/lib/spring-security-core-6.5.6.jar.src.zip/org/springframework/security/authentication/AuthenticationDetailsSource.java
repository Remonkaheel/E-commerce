package org.springframework.security.authentication;

public interface AuthenticationDetailsSource<C, T> {
  T buildDetails(C paramC);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\AuthenticationDetailsSource.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */