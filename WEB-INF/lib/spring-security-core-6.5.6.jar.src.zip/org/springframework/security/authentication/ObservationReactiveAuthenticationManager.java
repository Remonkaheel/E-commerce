/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import io.micrometer.observation.Observation;
/*    */ import io.micrometer.observation.ObservationConvention;
/*    */ import io.micrometer.observation.ObservationRegistry;
/*    */ import java.util.Objects;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ import reactor.util.context.ContextView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObservationReactiveAuthenticationManager
/*    */   implements ReactiveAuthenticationManager
/*    */ {
/*    */   private final ObservationRegistry registry;
/*    */   private final ReactiveAuthenticationManager delegate;
/* 41 */   private ObservationConvention<AuthenticationObservationContext> convention = new AuthenticationObservationConvention();
/*    */ 
/*    */   
/*    */   public ObservationReactiveAuthenticationManager(ObservationRegistry registry, ReactiveAuthenticationManager delegate) {
/* 45 */     this.registry = registry;
/* 46 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<Authentication> authenticate(Authentication authentication) throws AuthenticationException {
/* 51 */     AuthenticationObservationContext context = new AuthenticationObservationContext();
/* 52 */     context.setAuthenticationRequest(authentication);
/* 53 */     context.setAuthenticationManagerClass(this.delegate.getClass());
/* 54 */     return Mono.deferContextual(contextView -> {
/*    */           Observation observation = Observation.createNotStarted(this.convention, (), this.registry).parentObservation((Observation)contextView.getOrDefault("micrometer.observation", null)).start();
/*    */           Objects.requireNonNull(observation);
/*    */           return this.delegate.authenticate(authentication).doOnSuccess(()).doOnCancel(observation::stop).doOnError(());
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setObservationConvention(ObservationConvention<AuthenticationObservationContext> convention) {
/* 75 */     Assert.notNull(convention, "The observation convention cannot be null");
/* 76 */     this.convention = convention;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ObservationReactiveAuthenticationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */