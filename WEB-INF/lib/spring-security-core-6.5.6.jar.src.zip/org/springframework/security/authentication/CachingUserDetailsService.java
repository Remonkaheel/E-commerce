/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import org.springframework.security.core.userdetails.UserCache;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ import org.springframework.security.core.userdetails.UserDetailsService;
/*    */ import org.springframework.security.core.userdetails.cache.NullUserCache;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CachingUserDetailsService
/*    */   implements UserDetailsService
/*    */ {
/* 58 */   private UserCache userCache = (UserCache)new NullUserCache();
/*    */   
/*    */   private final UserDetailsService delegate;
/*    */   
/*    */   public CachingUserDetailsService(UserDetailsService delegate) {
/* 63 */     this.delegate = delegate;
/*    */   }
/*    */   
/*    */   public UserCache getUserCache() {
/* 67 */     return this.userCache;
/*    */   }
/*    */   
/*    */   public void setUserCache(UserCache userCache) {
/* 71 */     this.userCache = userCache;
/*    */   }
/*    */ 
/*    */   
/*    */   public UserDetails loadUserByUsername(String username) {
/* 76 */     UserDetails user = this.userCache.getUserFromCache(username);
/* 77 */     if (user == null) {
/* 78 */       user = this.delegate.loadUserByUsername(username);
/*    */     }
/* 80 */     Assert.notNull(user, () -> "UserDetailsService " + String.valueOf(this.delegate) + " returned null for username " + username + ". This is an interface contract violation");
/*    */     
/* 82 */     this.userCache.putUserInCache(user);
/* 83 */     return user;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\CachingUserDetailsService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */