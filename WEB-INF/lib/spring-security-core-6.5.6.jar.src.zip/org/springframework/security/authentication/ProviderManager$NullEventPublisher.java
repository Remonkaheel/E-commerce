package org.springframework.security.authentication;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

final class NullEventPublisher implements AuthenticationEventPublisher {
  public void publishAuthenticationFailure(AuthenticationException exception, Authentication authentication) {}
  
  public void publishAuthenticationSuccess(Authentication authentication) {}
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ProviderManager$NullEventPublisher.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */