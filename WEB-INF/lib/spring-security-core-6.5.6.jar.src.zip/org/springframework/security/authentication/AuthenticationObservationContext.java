/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import io.micrometer.observation.Observation;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationObservationContext
/*    */   extends Observation.Context
/*    */ {
/*    */   private Authentication authenticationRequest;
/*    */   private Class<?> authenticationManager;
/*    */   private Authentication authenticationResult;
/*    */   
/*    */   public Authentication getAuthenticationRequest() {
/* 43 */     return this.authenticationRequest;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAuthenticationRequest(Authentication authenticationRequest) {
/* 51 */     Assert.notNull(authenticationRequest, "authenticationRequest cannot be null");
/* 52 */     this.authenticationRequest = authenticationRequest;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Authentication getAuthenticationResult() {
/* 64 */     return this.authenticationResult;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAuthenticationResult(Authentication authenticationResult) {
/* 72 */     this.authenticationResult = authenticationResult;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getAuthenticationManagerClass() {
/* 80 */     return this.authenticationManager;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAuthenticationManagerClass(Class<?> authenticationManagerClass) {
/* 88 */     Assert.notNull(authenticationManagerClass, "authenticationManagerClass class cannot be null");
/* 89 */     this.authenticationManager = authenticationManagerClass;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\AuthenticationObservationContext.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */