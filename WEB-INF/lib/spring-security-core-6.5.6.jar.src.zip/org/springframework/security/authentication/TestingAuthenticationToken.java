/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.List;
/*    */ import org.springframework.security.core.GrantedAuthority;
/*    */ import org.springframework.security.core.authority.AuthorityUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TestingAuthenticationToken
/*    */   extends AbstractAuthenticationToken
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final Object credentials;
/*    */   private final Object principal;
/*    */   
/*    */   public TestingAuthenticationToken(Object principal, Object credentials) {
/* 42 */     super(null);
/* 43 */     this.principal = principal;
/* 44 */     this.credentials = credentials;
/*    */   }
/*    */   
/*    */   public TestingAuthenticationToken(Object principal, Object credentials, String... authorities) {
/* 48 */     this(principal, credentials, AuthorityUtils.createAuthorityList(authorities));
/*    */   }
/*    */ 
/*    */   
/*    */   public TestingAuthenticationToken(Object principal, Object credentials, List<? extends GrantedAuthority> authorities) {
/* 53 */     this(principal, credentials, authorities);
/*    */   }
/*    */ 
/*    */   
/*    */   public TestingAuthenticationToken(Object principal, Object credentials, Collection<? extends GrantedAuthority> authorities) {
/* 58 */     super(authorities);
/* 59 */     this.principal = principal;
/* 60 */     this.credentials = credentials;
/* 61 */     setAuthenticated(true);
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getCredentials() {
/* 66 */     return this.credentials;
/*    */   }
/*    */ 
/*    */   
/*    */   public Object getPrincipal() {
/* 71 */     return this.principal;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\TestingAuthenticationToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */