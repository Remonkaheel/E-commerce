/*    */ package org.springframework.security.authentication.ott.reactive;
/*    */ 
/*    */ import java.time.Clock;
/*    */ import java.util.Objects;
/*    */ import org.springframework.security.authentication.ott.GenerateOneTimeTokenRequest;
/*    */ import org.springframework.security.authentication.ott.InMemoryOneTimeTokenService;
/*    */ import org.springframework.security.authentication.ott.OneTimeToken;
/*    */ import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationToken;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class InMemoryReactiveOneTimeTokenService
/*    */   implements ReactiveOneTimeTokenService
/*    */ {
/* 38 */   private final InMemoryOneTimeTokenService oneTimeTokenService = new InMemoryOneTimeTokenService();
/*    */ 
/*    */   
/*    */   public Mono<OneTimeToken> generate(GenerateOneTimeTokenRequest request) {
/* 42 */     Objects.requireNonNull(this.oneTimeTokenService); return Mono.just(request).map(this.oneTimeTokenService::generate);
/*    */   }
/*    */ 
/*    */   
/*    */   public Mono<OneTimeToken> consume(OneTimeTokenAuthenticationToken authenticationToken) {
/* 47 */     Objects.requireNonNull(this.oneTimeTokenService); return Mono.just(authenticationToken).mapNotNull(this.oneTimeTokenService::consume);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setClock(Clock clock) {
/* 56 */     Assert.notNull(clock, "clock cannot be null");
/* 57 */     this.oneTimeTokenService.setClock(clock);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ott\reactive\InMemoryReactiveOneTimeTokenService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */