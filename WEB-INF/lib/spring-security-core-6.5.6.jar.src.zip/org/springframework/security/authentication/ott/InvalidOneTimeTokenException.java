/*    */ package org.springframework.security.authentication.ott;
/*    */ 
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidOneTimeTokenException
/*    */   extends AuthenticationException
/*    */ {
/*    */   private static final long serialVersionUID = -3651018515682919943L;
/*    */   
/*    */   public InvalidOneTimeTokenException(String msg) {
/* 35 */     super(msg);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ott\InvalidOneTimeTokenException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */