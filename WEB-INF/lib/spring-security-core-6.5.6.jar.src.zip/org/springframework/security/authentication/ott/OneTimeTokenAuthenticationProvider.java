/*    */ package org.springframework.security.authentication.ott;
/*    */ 
/*    */ import org.springframework.security.authentication.AuthenticationProvider;
/*    */ import org.springframework.security.authentication.BadCredentialsException;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ import org.springframework.security.core.userdetails.UserDetailsService;
/*    */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class OneTimeTokenAuthenticationProvider
/*    */   implements AuthenticationProvider
/*    */ {
/*    */   private final OneTimeTokenService oneTimeTokenService;
/*    */   private final UserDetailsService userDetailsService;
/*    */   
/*    */   public OneTimeTokenAuthenticationProvider(OneTimeTokenService oneTimeTokenService, UserDetailsService userDetailsService) {
/* 44 */     Assert.notNull(oneTimeTokenService, "oneTimeTokenService cannot be null");
/* 45 */     Assert.notNull(userDetailsService, "userDetailsService cannot be null");
/* 46 */     this.userDetailsService = userDetailsService;
/* 47 */     this.oneTimeTokenService = oneTimeTokenService;
/*    */   }
/*    */ 
/*    */   
/*    */   public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 52 */     OneTimeTokenAuthenticationToken otpAuthenticationToken = (OneTimeTokenAuthenticationToken)authentication;
/* 53 */     OneTimeToken consumed = this.oneTimeTokenService.consume(otpAuthenticationToken);
/* 54 */     if (consumed == null) {
/* 55 */       throw new InvalidOneTimeTokenException("Invalid token");
/*    */     }
/*    */     try {
/* 58 */       UserDetails user = this.userDetailsService.loadUserByUsername(consumed.getUsername());
/* 59 */       OneTimeTokenAuthenticationToken authenticated = OneTimeTokenAuthenticationToken.authenticated(user, user
/* 60 */           .getAuthorities());
/* 61 */       authenticated.setDetails(otpAuthenticationToken.getDetails());
/* 62 */       return (Authentication)authenticated;
/*    */     }
/* 64 */     catch (UsernameNotFoundException ex) {
/* 65 */       throw new BadCredentialsException("Failed to authenticate the one-time token");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(Class<?> authentication) {
/* 71 */     return OneTimeTokenAuthenticationToken.class.isAssignableFrom(authentication);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ott\OneTimeTokenAuthenticationProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */