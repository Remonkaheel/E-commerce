/*    */ package org.springframework.security.authentication.ott.reactive;
/*    */ 
/*    */ import java.util.function.Function;
/*    */ import org.springframework.security.authentication.ReactiveAuthenticationManager;
/*    */ import org.springframework.security.authentication.ott.InvalidOneTimeTokenException;
/*    */ import org.springframework.security.authentication.ott.OneTimeToken;
/*    */ import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationToken;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
/*    */ import org.springframework.security.core.userdetails.UserDetails;
/*    */ import org.springframework.util.Assert;
/*    */ import reactor.core.publisher.Mono;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class OneTimeTokenReactiveAuthenticationManager
/*    */   implements ReactiveAuthenticationManager
/*    */ {
/*    */   private final ReactiveOneTimeTokenService oneTimeTokenService;
/*    */   private final ReactiveUserDetailsService userDetailsService;
/*    */   
/*    */   public OneTimeTokenReactiveAuthenticationManager(ReactiveOneTimeTokenService oneTimeTokenService, ReactiveUserDetailsService userDetailsService) {
/* 45 */     Assert.notNull(oneTimeTokenService, "oneTimeTokenService cannot be null");
/* 46 */     Assert.notNull(userDetailsService, "userDetailsService cannot be null");
/* 47 */     this.oneTimeTokenService = oneTimeTokenService;
/* 48 */     this.userDetailsService = userDetailsService;
/*    */   }
/*    */   
/*    */   public Mono<Authentication> authenticate(Authentication authentication) {
/*    */     OneTimeTokenAuthenticationToken otpAuthenticationToken;
/* 53 */     if (authentication instanceof OneTimeTokenAuthenticationToken) { otpAuthenticationToken = (OneTimeTokenAuthenticationToken)authentication; }
/* 54 */     else { return Mono.empty(); }
/*    */     
/* 56 */     return this.oneTimeTokenService.consume(otpAuthenticationToken)
/* 57 */       .switchIfEmpty(Mono.defer(() -> Mono.error((Throwable)new InvalidOneTimeTokenException("Invalid token"))))
/* 58 */       .flatMap(consumed -> this.userDetailsService.findByUsername(consumed.getUsername()))
/* 59 */       .map(onSuccess(otpAuthenticationToken));
/*    */   }
/*    */   
/*    */   private Function<UserDetails, OneTimeTokenAuthenticationToken> onSuccess(OneTimeTokenAuthenticationToken token) {
/* 63 */     return user -> {
/*    */         OneTimeTokenAuthenticationToken authenticated = OneTimeTokenAuthenticationToken.authenticated(user, user.getAuthorities());
/*    */         authenticated.setDetails(token.getDetails());
/*    */         return authenticated;
/*    */       };
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ott\reactive\OneTimeTokenReactiveAuthenticationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */