package org.springframework.security.authentication.ott.reactive;

import org.springframework.security.authentication.ott.GenerateOneTimeTokenRequest;
import org.springframework.security.authentication.ott.OneTimeToken;
import org.springframework.security.authentication.ott.OneTimeTokenAuthenticationToken;
import reactor.core.publisher.Mono;

public interface ReactiveOneTimeTokenService {
  Mono<OneTimeToken> generate(GenerateOneTimeTokenRequest paramGenerateOneTimeTokenRequest);
  
  Mono<OneTimeToken> consume(OneTimeTokenAuthenticationToken paramOneTimeTokenAuthenticationToken);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ott\reactive\ReactiveOneTimeTokenService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */