package org.springframework.security.authentication.ott;

import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;

public interface OneTimeTokenService {
  @NonNull
  OneTimeToken generate(GenerateOneTimeTokenRequest paramGenerateOneTimeTokenRequest);
  
  @Nullable
  OneTimeToken consume(OneTimeTokenAuthenticationToken paramOneTimeTokenAuthenticationToken);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ott\OneTimeTokenService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */