/*    */ package org.springframework.security.authentication.ott;
/*    */ 
/*    */ import java.time.Clock;
/*    */ import java.time.Instant;
/*    */ import java.util.Map;
/*    */ import java.util.UUID;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import org.springframework.lang.NonNull;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class InMemoryOneTimeTokenService
/*    */   implements OneTimeTokenService
/*    */ {
/* 39 */   private final Map<String, OneTimeToken> oneTimeTokenByToken = new ConcurrentHashMap<>();
/*    */   
/* 41 */   private Clock clock = Clock.systemUTC();
/*    */ 
/*    */   
/*    */   @NonNull
/*    */   public OneTimeToken generate(GenerateOneTimeTokenRequest request) {
/* 46 */     String token = UUID.randomUUID().toString();
/* 47 */     Instant expiresAt = this.clock.instant().plus(request.getExpiresIn());
/* 48 */     OneTimeToken ott = new DefaultOneTimeToken(token, request.getUsername(), expiresAt);
/* 49 */     this.oneTimeTokenByToken.put(token, ott);
/* 50 */     cleanExpiredTokensIfNeeded();
/* 51 */     return ott;
/*    */   }
/*    */ 
/*    */   
/*    */   public OneTimeToken consume(OneTimeTokenAuthenticationToken authenticationToken) {
/* 56 */     OneTimeToken ott = this.oneTimeTokenByToken.remove(authenticationToken.getTokenValue());
/* 57 */     if (ott == null || isExpired(ott)) {
/* 58 */       return null;
/*    */     }
/* 60 */     return ott;
/*    */   }
/*    */   
/*    */   private void cleanExpiredTokensIfNeeded() {
/* 64 */     if (this.oneTimeTokenByToken.size() < 100) {
/*    */       return;
/*    */     }
/* 67 */     for (Map.Entry<String, OneTimeToken> entry : this.oneTimeTokenByToken.entrySet()) {
/* 68 */       if (isExpired(entry.getValue())) {
/* 69 */         this.oneTimeTokenByToken.remove(entry.getKey());
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   private boolean isExpired(OneTimeToken ott) {
/* 75 */     return this.clock.instant().isAfter(ott.getExpiresAt());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setClock(Clock clock) {
/* 84 */     Assert.notNull(clock, "clock cannot be null");
/* 85 */     this.clock = clock;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ott\InMemoryOneTimeTokenService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */