/*     */ package org.springframework.security.authentication.ott;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import org.springframework.security.authentication.AbstractAuthenticationToken;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OneTimeTokenAuthenticationToken
/*     */   extends AbstractAuthenticationToken
/*     */ {
/*     */   private static final long serialVersionUID = -8691636031126328365L;
/*     */   private final Object principal;
/*     */   private String tokenValue;
/*     */   
/*     */   public OneTimeTokenAuthenticationToken(Object principal, String tokenValue) {
/*  42 */     super(Collections.emptyList());
/*  43 */     this.tokenValue = tokenValue;
/*  44 */     this.principal = principal;
/*     */   }
/*     */   
/*     */   public OneTimeTokenAuthenticationToken(String tokenValue) {
/*  48 */     this((Object)null, tokenValue);
/*     */   }
/*     */   
/*     */   public OneTimeTokenAuthenticationToken(Object principal, Collection<? extends GrantedAuthority> authorities) {
/*  52 */     super(authorities);
/*  53 */     this.principal = principal;
/*  54 */     setAuthenticated(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static OneTimeTokenAuthenticationToken unauthenticated(String tokenValue) {
/*  63 */     return new OneTimeTokenAuthenticationToken(null, tokenValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static OneTimeTokenAuthenticationToken unauthenticated(Object principal, String tokenValue) {
/*  73 */     return new OneTimeTokenAuthenticationToken(principal, tokenValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static OneTimeTokenAuthenticationToken authenticated(Object principal, Collection<? extends GrantedAuthority> authorities) {
/*  84 */     return new OneTimeTokenAuthenticationToken(principal, authorities);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTokenValue() {
/*  92 */     return this.tokenValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getCredentials() {
/*  97 */     return this.tokenValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getPrincipal() {
/* 102 */     return this.principal;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ott\OneTimeTokenAuthenticationToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */