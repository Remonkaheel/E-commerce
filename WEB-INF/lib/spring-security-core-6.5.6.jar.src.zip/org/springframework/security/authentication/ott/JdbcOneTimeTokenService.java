/*     */ package org.springframework.security.authentication.ott;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.time.Clock;
/*     */ import java.time.Instant;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import java.util.function.Function;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jdbc.core.ArgumentPreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.JdbcOperations;
/*     */ import org.springframework.jdbc.core.PreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.SqlParameterValue;
/*     */ import org.springframework.scheduling.Trigger;
/*     */ import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
/*     */ import org.springframework.scheduling.support.CronTrigger;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JdbcOneTimeTokenService
/*     */   implements OneTimeTokenService, DisposableBean, InitializingBean
/*     */ {
/*  61 */   private final Log logger = LogFactory.getLog(getClass());
/*     */   
/*     */   private final JdbcOperations jdbcOperations;
/*     */   
/*  65 */   private Function<OneTimeToken, List<SqlParameterValue>> oneTimeTokenParametersMapper = new OneTimeTokenParametersMapper();
/*     */   
/*  67 */   private RowMapper<OneTimeToken> oneTimeTokenRowMapper = new OneTimeTokenRowMapper();
/*     */   
/*  69 */   private Clock clock = Clock.systemUTC();
/*     */ 
/*     */ 
/*     */   
/*     */   private ThreadPoolTaskScheduler taskScheduler;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DEFAULT_CLEANUP_CRON = "@hourly";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String TABLE_NAME = "one_time_tokens";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String COLUMN_NAMES = "token_value, username, expires_at";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String SAVE_ONE_TIME_TOKEN_SQL = "INSERT INTO one_time_tokens (token_value, username, expires_at) VALUES (?, ?, ?)";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String FILTER = "token_value = ?";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DELETE_ONE_TIME_TOKEN_SQL = "DELETE FROM one_time_tokens WHERE token_value = ?";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String SELECT_ONE_TIME_TOKEN_SQL = "SELECT token_value, username, expires_at FROM one_time_tokens WHERE token_value = ?";
/*     */ 
/*     */   
/*     */   private static final String DELETE_ONE_TIME_TOKENS_BY_EXPIRY_TIME_QUERY = "DELETE FROM one_time_tokens WHERE expires_at < ?";
/*     */ 
/*     */ 
/*     */   
/*     */   public JdbcOneTimeTokenService(JdbcOperations jdbcOperations) {
/* 109 */     Assert.notNull(jdbcOperations, "jdbcOperations cannot be null");
/* 110 */     this.jdbcOperations = jdbcOperations;
/* 111 */     this.taskScheduler = createTaskScheduler("@hourly");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCleanupCron(String cleanupCron) {
/* 127 */     this.taskScheduler = createTaskScheduler(cleanupCron);
/*     */   }
/*     */ 
/*     */   
/*     */   public OneTimeToken generate(GenerateOneTimeTokenRequest request) {
/* 132 */     Assert.notNull(request, "generateOneTimeTokenRequest cannot be null");
/* 133 */     String token = UUID.randomUUID().toString();
/* 134 */     Instant expiresAt = this.clock.instant().plus(request.getExpiresIn());
/* 135 */     OneTimeToken oneTimeToken = new DefaultOneTimeToken(token, request.getUsername(), expiresAt);
/* 136 */     insertOneTimeToken(oneTimeToken);
/* 137 */     return oneTimeToken;
/*     */   }
/*     */   
/*     */   private void insertOneTimeToken(OneTimeToken oneTimeToken) {
/* 141 */     List<SqlParameterValue> parameters = this.oneTimeTokenParametersMapper.apply(oneTimeToken);
/* 142 */     ArgumentPreparedStatementSetter argumentPreparedStatementSetter = new ArgumentPreparedStatementSetter(parameters.toArray());
/* 143 */     this.jdbcOperations.update("INSERT INTO one_time_tokens (token_value, username, expires_at) VALUES (?, ?, ?)", (PreparedStatementSetter)argumentPreparedStatementSetter);
/*     */   }
/*     */ 
/*     */   
/*     */   public OneTimeToken consume(OneTimeTokenAuthenticationToken authenticationToken) {
/* 148 */     Assert.notNull(authenticationToken, "authenticationToken cannot be null");
/*     */     
/* 150 */     List<OneTimeToken> tokens = selectOneTimeToken(authenticationToken);
/* 151 */     if (CollectionUtils.isEmpty(tokens)) {
/* 152 */       return null;
/*     */     }
/* 154 */     OneTimeToken token = tokens.get(0);
/* 155 */     deleteOneTimeToken(token);
/* 156 */     if (isExpired(token)) {
/* 157 */       return null;
/*     */     }
/* 159 */     return token;
/*     */   }
/*     */   
/*     */   private boolean isExpired(OneTimeToken ott) {
/* 163 */     return this.clock.instant().isAfter(ott.getExpiresAt());
/*     */   }
/*     */ 
/*     */   
/*     */   private List<OneTimeToken> selectOneTimeToken(OneTimeTokenAuthenticationToken authenticationToken) {
/* 168 */     List<SqlParameterValue> parameters = List.of(new SqlParameterValue(12, authenticationToken.getTokenValue()));
/* 169 */     ArgumentPreparedStatementSetter argumentPreparedStatementSetter = new ArgumentPreparedStatementSetter(parameters.toArray());
/* 170 */     return this.jdbcOperations.query("SELECT token_value, username, expires_at FROM one_time_tokens WHERE token_value = ?", (PreparedStatementSetter)argumentPreparedStatementSetter, this.oneTimeTokenRowMapper);
/*     */   }
/*     */ 
/*     */   
/*     */   private void deleteOneTimeToken(OneTimeToken oneTimeToken) {
/* 175 */     List<SqlParameterValue> parameters = List.of(new SqlParameterValue(12, oneTimeToken.getTokenValue()));
/* 176 */     ArgumentPreparedStatementSetter argumentPreparedStatementSetter = new ArgumentPreparedStatementSetter(parameters.toArray());
/* 177 */     this.jdbcOperations.update("DELETE FROM one_time_tokens WHERE token_value = ?", (PreparedStatementSetter)argumentPreparedStatementSetter);
/*     */   }
/*     */   
/*     */   private ThreadPoolTaskScheduler createTaskScheduler(String cleanupCron) {
/* 181 */     if (cleanupCron == null) {
/* 182 */       return null;
/*     */     }
/* 184 */     ThreadPoolTaskScheduler taskScheduler = new ThreadPoolTaskScheduler();
/* 185 */     taskScheduler.setThreadNamePrefix("spring-one-time-tokens-");
/* 186 */     taskScheduler.initialize();
/* 187 */     taskScheduler.schedule(this::cleanupExpiredTokens, (Trigger)new CronTrigger(cleanupCron));
/* 188 */     return taskScheduler;
/*     */   }
/*     */ 
/*     */   
/*     */   public void cleanupExpiredTokens() {
/* 193 */     List<SqlParameterValue> parameters = List.of(new SqlParameterValue(93, Timestamp.from(Instant.now())));
/* 194 */     ArgumentPreparedStatementSetter argumentPreparedStatementSetter = new ArgumentPreparedStatementSetter(parameters.toArray());
/* 195 */     int deletedCount = this.jdbcOperations.update("DELETE FROM one_time_tokens WHERE expires_at < ?", (PreparedStatementSetter)argumentPreparedStatementSetter);
/* 196 */     if (this.logger.isDebugEnabled()) {
/* 197 */       this.logger.debug("Cleaned up " + deletedCount + " expired tokens");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterPropertiesSet() throws Exception {
/* 203 */     this.taskScheduler.afterPropertiesSet();
/*     */   }
/*     */ 
/*     */   
/*     */   public void destroy() throws Exception {
/* 208 */     if (this.taskScheduler != null) {
/* 209 */       this.taskScheduler.shutdown();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setClock(Clock clock) {
/* 219 */     Assert.notNull(clock, "clock cannot be null");
/* 220 */     this.clock = clock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class OneTimeTokenParametersMapper
/*     */     implements Function<OneTimeToken, List<SqlParameterValue>>
/*     */   {
/*     */     public List<SqlParameterValue> apply(OneTimeToken oneTimeToken) {
/* 234 */       List<SqlParameterValue> parameters = new ArrayList<>();
/* 235 */       parameters.add(new SqlParameterValue(12, oneTimeToken.getTokenValue()));
/* 236 */       parameters.add(new SqlParameterValue(12, oneTimeToken.getUsername()));
/* 237 */       parameters.add(new SqlParameterValue(93, Timestamp.from(oneTimeToken.getExpiresAt())));
/* 238 */       return parameters;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class OneTimeTokenRowMapper
/*     */     implements RowMapper<OneTimeToken>
/*     */   {
/*     */     public OneTimeToken mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 254 */       String tokenValue = rs.getString("token_value");
/* 255 */       String userName = rs.getString("username");
/* 256 */       Instant expiresAt = rs.getTimestamp("expires_at").toInstant();
/* 257 */       return new DefaultOneTimeToken(tokenValue, userName, expiresAt);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ott\JdbcOneTimeTokenService.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */