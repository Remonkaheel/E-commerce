/*    */ package org.springframework.security.authentication.ott;
/*    */ 
/*    */ import java.time.Duration;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GenerateOneTimeTokenRequest
/*    */ {
/* 31 */   private static final Duration DEFAULT_EXPIRES_IN = Duration.ofMinutes(5L);
/*    */   
/*    */   private final String username;
/*    */   
/*    */   private final Duration expiresIn;
/*    */   
/*    */   public GenerateOneTimeTokenRequest(String username) {
/* 38 */     this(username, DEFAULT_EXPIRES_IN);
/*    */   }
/*    */   
/*    */   public GenerateOneTimeTokenRequest(String username, Duration expiresIn) {
/* 42 */     Assert.hasText(username, "username cannot be empty");
/* 43 */     Assert.notNull(expiresIn, "expiresIn cannot be null");
/* 44 */     this.username = username;
/* 45 */     this.expiresIn = expiresIn;
/*    */   }
/*    */   
/*    */   public String getUsername() {
/* 49 */     return this.username;
/*    */   }
/*    */   
/*    */   public Duration getExpiresIn() {
/* 53 */     return this.expiresIn;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ott\GenerateOneTimeTokenRequest.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */