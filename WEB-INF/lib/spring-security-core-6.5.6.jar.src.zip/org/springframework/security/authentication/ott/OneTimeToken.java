package org.springframework.security.authentication.ott;

import java.io.Serializable;
import java.time.Instant;

public interface OneTimeToken extends Serializable {
  String getTokenValue();
  
  String getUsername();
  
  Instant getExpiresAt();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ott\OneTimeToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */