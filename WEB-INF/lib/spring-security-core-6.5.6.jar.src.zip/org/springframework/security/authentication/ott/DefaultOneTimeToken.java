/*    */ package org.springframework.security.authentication.ott;
/*    */ 
/*    */ import java.time.Instant;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultOneTimeToken
/*    */   implements OneTimeToken
/*    */ {
/*    */   private static final long serialVersionUID = -1545822943352278549L;
/*    */   private final String token;
/*    */   private final String username;
/*    */   private final Instant expireAt;
/*    */   
/*    */   public DefaultOneTimeToken(String token, String username, Instant expireAt) {
/* 42 */     Assert.hasText(token, "token cannot be empty");
/* 43 */     Assert.hasText(username, "username cannot be empty");
/* 44 */     Assert.notNull(expireAt, "expireAt cannot be null");
/* 45 */     this.token = token;
/* 46 */     this.username = username;
/* 47 */     this.expireAt = expireAt;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getTokenValue() {
/* 52 */     return this.token;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getUsername() {
/* 57 */     return this.username;
/*    */   }
/*    */   
/*    */   public Instant getExpiresAt() {
/* 61 */     return this.expireAt;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ott\DefaultOneTimeToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */