/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AccountStatusException
/*    */   extends AuthenticationException
/*    */ {
/*    */   public AccountStatusException(String msg) {
/* 30 */     super(msg);
/*    */   }
/*    */   
/*    */   public AccountStatusException(String msg, Throwable cause) {
/* 34 */     super(msg, cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\AccountStatusException.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */