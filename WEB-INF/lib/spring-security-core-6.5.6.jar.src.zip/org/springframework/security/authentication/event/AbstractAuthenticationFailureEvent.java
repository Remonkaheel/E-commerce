/*    */ package org.springframework.security.authentication.event;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractAuthenticationFailureEvent
/*    */   extends AbstractAuthenticationEvent
/*    */ {
/*    */   private final AuthenticationException exception;
/*    */   
/*    */   public AbstractAuthenticationFailureEvent(Authentication authentication, AuthenticationException exception) {
/* 33 */     super(authentication);
/* 34 */     Assert.notNull(exception, "AuthenticationException is required");
/* 35 */     this.exception = exception;
/*    */   }
/*    */   
/*    */   public AuthenticationException getException() {
/* 39 */     return this.exception;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\event\AbstractAuthenticationFailureEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */