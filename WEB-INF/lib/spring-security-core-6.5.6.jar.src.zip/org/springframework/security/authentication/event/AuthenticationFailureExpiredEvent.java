/*    */ package org.springframework.security.authentication.event;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationFailureExpiredEvent
/*    */   extends AbstractAuthenticationFailureEvent
/*    */ {
/*    */   private static final long serialVersionUID = -8437264795214121718L;
/*    */   
/*    */   public AuthenticationFailureExpiredEvent(Authentication authentication, AuthenticationException exception) {
/* 36 */     super(authentication, exception);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\event\AuthenticationFailureExpiredEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */