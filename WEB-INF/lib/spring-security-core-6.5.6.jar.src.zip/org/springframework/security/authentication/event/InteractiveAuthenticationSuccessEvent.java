/*    */ package org.springframework.security.authentication.event;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InteractiveAuthenticationSuccessEvent
/*    */   extends AbstractAuthenticationEvent
/*    */ {
/*    */   private static final long serialVersionUID = -1990271553478571709L;
/*    */   private final Class<?> generatedBy;
/*    */   
/*    */   public InteractiveAuthenticationSuccessEvent(Authentication authentication, Class<?> generatedBy) {
/* 45 */     super(authentication);
/* 46 */     Assert.notNull(generatedBy, "generatedBy cannot be null");
/* 47 */     this.generatedBy = generatedBy;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<?> getGeneratedBy() {
/* 56 */     return this.generatedBy;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\event\InteractiveAuthenticationSuccessEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */