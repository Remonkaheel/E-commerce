/*    */ package org.springframework.security.authentication.event;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogoutSuccessEvent
/*    */   extends AbstractAuthenticationEvent
/*    */ {
/*    */   private static final long serialVersionUID = 5112491795571632311L;
/*    */   
/*    */   public LogoutSuccessEvent(Authentication authentication) {
/* 35 */     super(authentication);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\event\LogoutSuccessEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */