/*    */ package org.springframework.security.authentication.event;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.core.log.LogMessage;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggerListener
/*    */   implements ApplicationListener<AbstractAuthenticationEvent>
/*    */ {
/* 35 */   private static final Log logger = LogFactory.getLog(LoggerListener.class);
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean logInteractiveAuthenticationSuccessEvents = true;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void onApplicationEvent(AbstractAuthenticationEvent event) {
/* 45 */     if (!this.logInteractiveAuthenticationSuccessEvents && event instanceof InteractiveAuthenticationSuccessEvent) {
/*    */       return;
/*    */     }
/* 48 */     logger.warn(LogMessage.of(() -> getLogMessage(event)));
/*    */   }
/*    */   
/*    */   private String getLogMessage(AbstractAuthenticationEvent event) {
/* 52 */     StringBuilder builder = new StringBuilder();
/* 53 */     builder.append("Authentication event ");
/* 54 */     builder.append(ClassUtils.getShortName(event.getClass()));
/* 55 */     builder.append(": ");
/* 56 */     builder.append(event.getAuthentication().getName());
/* 57 */     builder.append("; details: ");
/* 58 */     builder.append(event.getAuthentication().getDetails());
/* 59 */     if (event instanceof AbstractAuthenticationFailureEvent) {
/* 60 */       builder.append("; exception: ");
/* 61 */       builder.append(((AbstractAuthenticationFailureEvent)event).getException().getMessage());
/*    */     } 
/* 63 */     return builder.toString();
/*    */   }
/*    */   
/*    */   public boolean isLogInteractiveAuthenticationSuccessEvents() {
/* 67 */     return this.logInteractiveAuthenticationSuccessEvents;
/*    */   }
/*    */   
/*    */   public void setLogInteractiveAuthenticationSuccessEvents(boolean logInteractiveAuthenticationSuccessEvents) {
/* 71 */     this.logInteractiveAuthenticationSuccessEvents = logInteractiveAuthenticationSuccessEvents;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\event\LoggerListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */