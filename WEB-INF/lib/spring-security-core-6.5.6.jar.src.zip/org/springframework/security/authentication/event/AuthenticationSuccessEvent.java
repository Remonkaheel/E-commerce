/*    */ package org.springframework.security.authentication.event;
/*    */ 
/*    */ import org.springframework.security.core.Authentication;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationSuccessEvent
/*    */   extends AbstractAuthenticationEvent
/*    */ {
/*    */   private static final long serialVersionUID = 2537206344128673963L;
/*    */   
/*    */   public AuthenticationSuccessEvent(Authentication authentication) {
/* 34 */     super(authentication);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\event\AuthenticationSuccessEvent.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */