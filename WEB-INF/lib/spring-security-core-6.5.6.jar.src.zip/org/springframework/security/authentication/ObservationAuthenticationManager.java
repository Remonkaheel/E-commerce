/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import io.micrometer.observation.Observation;
/*    */ import io.micrometer.observation.ObservationConvention;
/*    */ import io.micrometer.observation.ObservationRegistry;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ObservationAuthenticationManager
/*    */   implements AuthenticationManager
/*    */ {
/*    */   private final ObservationRegistry registry;
/*    */   private final AuthenticationManager delegate;
/* 39 */   private ObservationConvention<AuthenticationObservationContext> convention = new AuthenticationObservationConvention();
/*    */   
/*    */   public ObservationAuthenticationManager(ObservationRegistry registry, AuthenticationManager delegate) {
/* 42 */     Assert.notNull(registry, "observationRegistry cannot be null");
/* 43 */     Assert.notNull(delegate, "authenticationManager cannot be null");
/* 44 */     this.registry = registry;
/* 45 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   
/*    */   public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 50 */     AuthenticationObservationContext context = new AuthenticationObservationContext();
/* 51 */     context.setAuthenticationRequest(authentication);
/* 52 */     context.setAuthenticationManagerClass(this.delegate.getClass());
/* 53 */     return (Authentication)Observation.createNotStarted(this.convention, () -> context, this.registry).observe(() -> {
/*    */           Authentication result = this.delegate.authenticate(authentication);
/*    */           context.setAuthenticationResult(result);
/*    */           return result;
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setObservationConvention(ObservationConvention<AuthenticationObservationContext> convention) {
/* 67 */     Assert.notNull(convention, "The observation convention cannot be null");
/* 68 */     this.convention = convention;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\ObservationAuthenticationManager.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */