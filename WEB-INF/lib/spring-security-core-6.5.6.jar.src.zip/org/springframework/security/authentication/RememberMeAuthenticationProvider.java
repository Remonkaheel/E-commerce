/*    */ package org.springframework.security.authentication;
/*    */ 
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.context.MessageSourceAware;
/*    */ import org.springframework.context.support.MessageSourceAccessor;
/*    */ import org.springframework.security.core.Authentication;
/*    */ import org.springframework.security.core.AuthenticationException;
/*    */ import org.springframework.security.core.SpringSecurityMessageSource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RememberMeAuthenticationProvider
/*    */   implements AuthenticationProvider, InitializingBean, MessageSourceAware
/*    */ {
/* 37 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*    */   
/*    */   private String key;
/*    */   
/*    */   public RememberMeAuthenticationProvider(String key) {
/* 42 */     Assert.hasLength(key, "key must have a length");
/* 43 */     this.key = key;
/*    */   }
/*    */ 
/*    */   
/*    */   public void afterPropertiesSet() {
/* 48 */     Assert.notNull(this.messages, "A message source must be set");
/*    */   }
/*    */ 
/*    */   
/*    */   public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 53 */     if (!supports(authentication.getClass())) {
/* 54 */       return null;
/*    */     }
/* 56 */     if (this.key.hashCode() != ((RememberMeAuthenticationToken)authentication).getKeyHash()) {
/* 57 */       throw new BadCredentialsException(this.messages.getMessage("RememberMeAuthenticationProvider.incorrectKey", "The presented RememberMeAuthenticationToken does not contain the expected key"));
/*    */     }
/*    */     
/* 60 */     return authentication;
/*    */   }
/*    */   
/*    */   public String getKey() {
/* 64 */     return this.key;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setMessageSource(MessageSource messageSource) {
/* 69 */     this.messages = new MessageSourceAccessor(messageSource);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean supports(Class<?> authentication) {
/* 74 */     return RememberMeAuthenticationToken.class.isAssignableFrom(authentication);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\RememberMeAuthenticationProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */