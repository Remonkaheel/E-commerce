/*     */ package org.springframework.security.authentication;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RememberMeAuthenticationToken
/*     */   extends AbstractAuthenticationToken
/*     */ {
/*     */   private static final long serialVersionUID = 620L;
/*     */   private final Object principal;
/*     */   private final int keyHash;
/*     */   
/*     */   public RememberMeAuthenticationToken(String key, Object principal, Collection<? extends GrantedAuthority> authorities) {
/*  50 */     super(authorities);
/*  51 */     if (key == null || "".equals(key) || principal == null || "".equals(principal)) {
/*  52 */       throw new IllegalArgumentException("Cannot pass null or empty values to constructor");
/*     */     }
/*  54 */     this.keyHash = key.hashCode();
/*  55 */     this.principal = principal;
/*  56 */     setAuthenticated(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RememberMeAuthenticationToken(Integer keyHash, Object principal, Collection<? extends GrantedAuthority> authorities) {
/*  68 */     super(authorities);
/*  69 */     this.keyHash = keyHash.intValue();
/*  70 */     this.principal = principal;
/*  71 */     setAuthenticated(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getCredentials() {
/*  80 */     return "";
/*     */   }
/*     */   
/*     */   public int getKeyHash() {
/*  84 */     return this.keyHash;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getPrincipal() {
/*  89 */     return this.principal;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/*  94 */     if (!super.equals(obj)) {
/*  95 */       return false;
/*     */     }
/*  97 */     if (obj instanceof RememberMeAuthenticationToken) { RememberMeAuthenticationToken other = (RememberMeAuthenticationToken)obj;
/*  98 */       return (getKeyHash() == other.getKeyHash()); }
/*     */     
/* 100 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 105 */     int result = super.hashCode();
/* 106 */     result = 31 * result + this.keyHash;
/* 107 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\RememberMeAuthenticationToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */