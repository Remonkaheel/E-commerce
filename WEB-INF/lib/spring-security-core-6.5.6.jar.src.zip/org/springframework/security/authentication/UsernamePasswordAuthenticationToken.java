/*     */ package org.springframework.security.authentication;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.springframework.security.core.GrantedAuthority;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UsernamePasswordAuthenticationToken
/*     */   extends AbstractAuthenticationToken
/*     */ {
/*     */   private static final long serialVersionUID = 620L;
/*     */   private final Object principal;
/*     */   private Object credentials;
/*     */   
/*     */   public UsernamePasswordAuthenticationToken(Object principal, Object credentials) {
/*  52 */     super(null);
/*  53 */     this.principal = principal;
/*  54 */     this.credentials = credentials;
/*  55 */     setAuthenticated(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UsernamePasswordAuthenticationToken(Object principal, Object credentials, Collection<? extends GrantedAuthority> authorities) {
/*  69 */     super(authorities);
/*  70 */     this.principal = principal;
/*  71 */     this.credentials = credentials;
/*  72 */     super.setAuthenticated(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UsernamePasswordAuthenticationToken unauthenticated(Object principal, Object credentials) {
/*  85 */     return new UsernamePasswordAuthenticationToken(principal, credentials);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static UsernamePasswordAuthenticationToken authenticated(Object principal, Object credentials, Collection<? extends GrantedAuthority> authorities) {
/*  99 */     return new UsernamePasswordAuthenticationToken(principal, credentials, authorities);
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getCredentials() {
/* 104 */     return this.credentials;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getPrincipal() {
/* 109 */     return this.principal;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthenticated(boolean isAuthenticated) throws IllegalArgumentException {
/* 114 */     Assert.isTrue(!isAuthenticated, "Cannot set this token to trusted - use constructor which takes a GrantedAuthority list instead");
/*     */     
/* 116 */     super.setAuthenticated(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void eraseCredentials() {
/* 121 */     super.eraseCredentials();
/* 122 */     this.credentials = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\UsernamePasswordAuthenticationToken.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */