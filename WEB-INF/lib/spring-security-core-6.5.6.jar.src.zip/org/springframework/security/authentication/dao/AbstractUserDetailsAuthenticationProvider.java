/*     */ package org.springframework.security.authentication.dao;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.core.log.LogMessage;
/*     */ import org.springframework.security.authentication.AccountExpiredException;
/*     */ import org.springframework.security.authentication.AuthenticationProvider;
/*     */ import org.springframework.security.authentication.BadCredentialsException;
/*     */ import org.springframework.security.authentication.CredentialsExpiredException;
/*     */ import org.springframework.security.authentication.DisabledException;
/*     */ import org.springframework.security.authentication.LockedException;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.SpringSecurityMessageSource;
/*     */ import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
/*     */ import org.springframework.security.core.authority.mapping.NullAuthoritiesMapper;
/*     */ import org.springframework.security.core.userdetails.UserCache;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UserDetailsChecker;
/*     */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*     */ import org.springframework.security.core.userdetails.cache.NullUserCache;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractUserDetailsAuthenticationProvider
/*     */   implements AuthenticationProvider, InitializingBean, MessageSourceAware
/*     */ {
/*  81 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   
/*  83 */   protected MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
/*     */   
/*  85 */   private UserCache userCache = (UserCache)new NullUserCache();
/*     */   
/*     */   private boolean forcePrincipalAsString = false;
/*     */   
/*     */   protected boolean hideUserNotFoundExceptions = true;
/*     */   
/*  91 */   private UserDetailsChecker preAuthenticationChecks = new DefaultPreAuthenticationChecks();
/*     */   
/*  93 */   private UserDetailsChecker postAuthenticationChecks = new DefaultPostAuthenticationChecks();
/*     */   
/*  95 */   private GrantedAuthoritiesMapper authoritiesMapper = (GrantedAuthoritiesMapper)new NullAuthoritiesMapper();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void afterPropertiesSet() throws Exception {
/* 118 */     Assert.notNull(this.userCache, "A user cache must be set");
/* 119 */     Assert.notNull(this.messages, "A message source must be set");
/* 120 */     Assert.notNull(this.preAuthenticationChecks, "A pre authentication checks must be set");
/* 121 */     Assert.notNull(this.postAuthenticationChecks, "A post authentication checks must be set");
/* 122 */     doAfterPropertiesSet();
/*     */   }
/*     */ 
/*     */   
/*     */   public Authentication authenticate(Authentication authentication) throws AuthenticationException {
/* 127 */     Assert.isInstanceOf(UsernamePasswordAuthenticationToken.class, authentication, () -> this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.onlySupports", "Only UsernamePasswordAuthenticationToken is supported"));
/*     */ 
/*     */     
/* 130 */     String username = determineUsername(authentication);
/* 131 */     boolean cacheWasUsed = true;
/* 132 */     UserDetails user = this.userCache.getUserFromCache(username);
/* 133 */     if (user == null) {
/* 134 */       cacheWasUsed = false;
/*     */       try {
/* 136 */         user = retrieveUser(username, (UsernamePasswordAuthenticationToken)authentication);
/*     */       }
/* 138 */       catch (UsernameNotFoundException ex) {
/* 139 */         this.logger.debug(LogMessage.format("Failed to find user '%s'", username));
/* 140 */         if (!this.hideUserNotFoundExceptions) {
/* 141 */           throw ex;
/*     */         }
/* 143 */         throw new BadCredentialsException(this.messages
/* 144 */             .getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
/*     */       } 
/* 146 */       Assert.notNull(user, "retrieveUser returned null - a violation of the interface contract");
/*     */     } 
/*     */     try {
/* 149 */       this.preAuthenticationChecks.check(user);
/* 150 */       additionalAuthenticationChecks(user, (UsernamePasswordAuthenticationToken)authentication);
/*     */     }
/* 152 */     catch (AuthenticationException ex) {
/* 153 */       if (!cacheWasUsed) {
/* 154 */         throw ex;
/*     */       }
/*     */ 
/*     */       
/* 158 */       cacheWasUsed = false;
/* 159 */       user = retrieveUser(username, (UsernamePasswordAuthenticationToken)authentication);
/* 160 */       this.preAuthenticationChecks.check(user);
/* 161 */       additionalAuthenticationChecks(user, (UsernamePasswordAuthenticationToken)authentication);
/*     */     } 
/* 163 */     this.postAuthenticationChecks.check(user);
/* 164 */     if (!cacheWasUsed) {
/* 165 */       this.userCache.putUserInCache(user);
/*     */     }
/* 167 */     Object principalToReturn = user;
/* 168 */     if (this.forcePrincipalAsString) {
/* 169 */       principalToReturn = user.getUsername();
/*     */     }
/* 171 */     return createSuccessAuthentication(principalToReturn, authentication, user);
/*     */   }
/*     */   
/*     */   private String determineUsername(Authentication authentication) {
/* 175 */     return (authentication.getPrincipal() == null) ? "NONE_PROVIDED" : authentication.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Authentication createSuccessAuthentication(Object principal, Authentication authentication, UserDetails user) {
/* 199 */     UsernamePasswordAuthenticationToken result = UsernamePasswordAuthenticationToken.authenticated(principal, authentication
/* 200 */         .getCredentials(), this.authoritiesMapper.mapAuthorities(user.getAuthorities()));
/* 201 */     result.setDetails(authentication.getDetails());
/* 202 */     this.logger.debug("Authenticated user");
/* 203 */     return (Authentication)result;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doAfterPropertiesSet() throws Exception {}
/*     */   
/*     */   public UserCache getUserCache() {
/* 210 */     return this.userCache;
/*     */   }
/*     */   
/*     */   public boolean isForcePrincipalAsString() {
/* 214 */     return this.forcePrincipalAsString;
/*     */   }
/*     */   
/*     */   public boolean isHideUserNotFoundExceptions() {
/* 218 */     return this.hideUserNotFoundExceptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setForcePrincipalAsString(boolean forcePrincipalAsString) {
/* 263 */     this.forcePrincipalAsString = forcePrincipalAsString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHideUserNotFoundExceptions(boolean hideUserNotFoundExceptions) {
/* 278 */     this.hideUserNotFoundExceptions = hideUserNotFoundExceptions;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMessageSource(MessageSource messageSource) {
/* 283 */     this.messages = new MessageSourceAccessor(messageSource);
/*     */   }
/*     */   
/*     */   public void setUserCache(UserCache userCache) {
/* 287 */     this.userCache = userCache;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean supports(Class<?> authentication) {
/* 292 */     return UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
/*     */   }
/*     */   
/*     */   protected UserDetailsChecker getPreAuthenticationChecks() {
/* 296 */     return this.preAuthenticationChecks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPreAuthenticationChecks(UserDetailsChecker preAuthenticationChecks) {
/* 305 */     this.preAuthenticationChecks = preAuthenticationChecks;
/*     */   }
/*     */   
/*     */   protected UserDetailsChecker getPostAuthenticationChecks() {
/* 309 */     return this.postAuthenticationChecks;
/*     */   }
/*     */   
/*     */   public void setPostAuthenticationChecks(UserDetailsChecker postAuthenticationChecks) {
/* 313 */     this.postAuthenticationChecks = postAuthenticationChecks;
/*     */   }
/*     */   protected abstract void additionalAuthenticationChecks(UserDetails paramUserDetails, UsernamePasswordAuthenticationToken paramUsernamePasswordAuthenticationToken) throws AuthenticationException;
/*     */   public void setAuthoritiesMapper(GrantedAuthoritiesMapper authoritiesMapper) {
/* 317 */     this.authoritiesMapper = authoritiesMapper;
/*     */   }
/*     */   
/*     */   protected abstract UserDetails retrieveUser(String paramString, UsernamePasswordAuthenticationToken paramUsernamePasswordAuthenticationToken) throws AuthenticationException;
/*     */   
/*     */   private class DefaultPreAuthenticationChecks implements UserDetailsChecker {
/*     */     public void check(UserDetails user) {
/* 324 */       if (!user.isAccountNonLocked()) {
/* 325 */         AbstractUserDetailsAuthenticationProvider.this.logger
/* 326 */           .debug("Failed to authenticate since user account is locked");
/* 327 */         throw new LockedException(AbstractUserDetailsAuthenticationProvider.this.messages
/* 328 */             .getMessage("AbstractUserDetailsAuthenticationProvider.locked", "User account is locked"));
/*     */       } 
/* 330 */       if (!user.isEnabled()) {
/* 331 */         AbstractUserDetailsAuthenticationProvider.this.logger
/* 332 */           .debug("Failed to authenticate since user account is disabled");
/* 333 */         throw new DisabledException(AbstractUserDetailsAuthenticationProvider.this.messages
/* 334 */             .getMessage("AbstractUserDetailsAuthenticationProvider.disabled", "User is disabled"));
/*     */       } 
/* 336 */       if (!user.isAccountNonExpired()) {
/* 337 */         AbstractUserDetailsAuthenticationProvider.this.logger
/* 338 */           .debug("Failed to authenticate since user account has expired");
/* 339 */         throw new AccountExpiredException(AbstractUserDetailsAuthenticationProvider.this.messages
/* 340 */             .getMessage("AbstractUserDetailsAuthenticationProvider.expired", "User account has expired"));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class DefaultPostAuthenticationChecks
/*     */     implements UserDetailsChecker
/*     */   {
/*     */     public void check(UserDetails user) {
/* 350 */       if (!user.isCredentialsNonExpired()) {
/* 351 */         AbstractUserDetailsAuthenticationProvider.this.logger
/* 352 */           .debug("Failed to authenticate since user account credentials have expired");
/* 353 */         throw new CredentialsExpiredException(AbstractUserDetailsAuthenticationProvider.this.messages
/* 354 */             .getMessage("AbstractUserDetailsAuthenticationProvider.credentialsExpired", "User credentials have expired"));
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\dao\AbstractUserDetailsAuthenticationProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */