/*     */ package org.springframework.security.authentication.dao;
/*     */ 
/*     */ import java.util.function.Supplier;
/*     */ import org.springframework.security.authentication.BadCredentialsException;
/*     */ import org.springframework.security.authentication.InternalAuthenticationServiceException;
/*     */ import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.authentication.password.CompromisedPasswordChecker;
/*     */ import org.springframework.security.authentication.password.CompromisedPasswordException;
/*     */ import org.springframework.security.core.Authentication;
/*     */ import org.springframework.security.core.AuthenticationException;
/*     */ import org.springframework.security.core.userdetails.UserDetails;
/*     */ import org.springframework.security.core.userdetails.UserDetailsPasswordService;
/*     */ import org.springframework.security.core.userdetails.UserDetailsService;
/*     */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*     */ import org.springframework.security.crypto.factory.PasswordEncoderFactories;
/*     */ import org.springframework.security.crypto.password.PasswordEncoder;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.function.SingletonSupplier;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DaoAuthenticationProvider
/*     */   extends AbstractUserDetailsAuthenticationProvider
/*     */ {
/*     */   private static final String USER_NOT_FOUND_PASSWORD = "userNotFoundPassword";
/*  55 */   private Supplier<PasswordEncoder> passwordEncoder = (Supplier<PasswordEncoder>)SingletonSupplier.of(PasswordEncoderFactories::createDelegatingPasswordEncoder);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private volatile String userNotFoundEncodedPassword;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private UserDetailsService userDetailsService;
/*     */ 
/*     */ 
/*     */   
/*     */   private UserDetailsPasswordService userDetailsPasswordService;
/*     */ 
/*     */ 
/*     */   
/*     */   private CompromisedPasswordChecker compromisedPasswordChecker;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DaoAuthenticationProvider(UserDetailsService userDetailsService) {
/*  79 */     setUserDetailsService(userDetailsService);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public DaoAuthenticationProvider(PasswordEncoder passwordEncoder) {
/*  91 */     setPasswordEncoder(passwordEncoder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void additionalAuthenticationChecks(UserDetails userDetails, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
/*  98 */     if (authentication.getCredentials() == null) {
/*  99 */       this.logger.debug("Failed to authenticate since no credentials provided");
/* 100 */       throw new BadCredentialsException(this.messages
/* 101 */           .getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
/*     */     } 
/* 103 */     String presentedPassword = authentication.getCredentials().toString();
/* 104 */     if (!((PasswordEncoder)this.passwordEncoder.get()).matches(presentedPassword, userDetails.getPassword())) {
/* 105 */       this.logger.debug("Failed to authenticate since password does not match stored value");
/* 106 */       throw new BadCredentialsException(this.messages
/* 107 */           .getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doAfterPropertiesSet() {
/* 113 */     Assert.notNull(this.userDetailsService, "A UserDetailsService must be set");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final UserDetails retrieveUser(String username, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
/* 119 */     prepareTimingAttackProtection();
/*     */     try {
/* 121 */       UserDetails loadedUser = getUserDetailsService().loadUserByUsername(username);
/* 122 */       if (loadedUser == null) {
/* 123 */         throw new InternalAuthenticationServiceException("UserDetailsService returned null, which is an interface contract violation");
/*     */       }
/*     */       
/* 126 */       return loadedUser;
/*     */     }
/* 128 */     catch (UsernameNotFoundException ex) {
/* 129 */       mitigateAgainstTimingAttack(authentication);
/* 130 */       throw ex;
/*     */     }
/* 132 */     catch (InternalAuthenticationServiceException ex) {
/* 133 */       throw ex;
/*     */     }
/* 135 */     catch (Exception ex) {
/* 136 */       throw new InternalAuthenticationServiceException(ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Authentication createSuccessAuthentication(Object principal, Authentication authentication, UserDetails user) {
/* 143 */     String presentedPassword = authentication.getCredentials().toString();
/*     */     
/* 145 */     boolean isPasswordCompromised = (this.compromisedPasswordChecker != null && this.compromisedPasswordChecker.check(presentedPassword).isCompromised());
/* 146 */     if (isPasswordCompromised) {
/* 147 */       throw new CompromisedPasswordException("The provided password is compromised, please change your password");
/*     */     }
/*     */     
/* 150 */     boolean upgradeEncoding = (this.userDetailsPasswordService != null && ((PasswordEncoder)this.passwordEncoder.get()).upgradeEncoding(user.getPassword()));
/* 151 */     if (upgradeEncoding) {
/* 152 */       String newPassword = ((PasswordEncoder)this.passwordEncoder.get()).encode(presentedPassword);
/* 153 */       user = this.userDetailsPasswordService.updatePassword(user, newPassword);
/*     */     } 
/* 155 */     return super.createSuccessAuthentication(principal, authentication, user);
/*     */   }
/*     */   
/*     */   private void prepareTimingAttackProtection() {
/* 159 */     if (this.userNotFoundEncodedPassword == null) {
/* 160 */       this.userNotFoundEncodedPassword = ((PasswordEncoder)this.passwordEncoder.get()).encode("userNotFoundPassword");
/*     */     }
/*     */   }
/*     */   
/*     */   private void mitigateAgainstTimingAttack(UsernamePasswordAuthenticationToken authentication) {
/* 165 */     if (authentication.getCredentials() != null) {
/* 166 */       String presentedPassword = authentication.getCredentials().toString();
/* 167 */       ((PasswordEncoder)this.passwordEncoder.get()).matches(presentedPassword, this.userNotFoundEncodedPassword);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPasswordEncoder(PasswordEncoder passwordEncoder) {
/* 179 */     Assert.notNull(passwordEncoder, "passwordEncoder cannot be null");
/* 180 */     this.passwordEncoder = (() -> passwordEncoder);
/* 181 */     this.userNotFoundEncodedPassword = null;
/*     */   }
/*     */   
/*     */   protected PasswordEncoder getPasswordEncoder() {
/* 185 */     return this.passwordEncoder.get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setUserDetailsService(UserDetailsService userDetailsService) {
/* 194 */     this.userDetailsService = userDetailsService;
/*     */   }
/*     */   
/*     */   protected UserDetailsService getUserDetailsService() {
/* 198 */     return this.userDetailsService;
/*     */   }
/*     */   
/*     */   public void setUserDetailsPasswordService(UserDetailsPasswordService userDetailsPasswordService) {
/* 202 */     this.userDetailsPasswordService = userDetailsPasswordService;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCompromisedPasswordChecker(CompromisedPasswordChecker compromisedPasswordChecker) {
/* 212 */     this.compromisedPasswordChecker = compromisedPasswordChecker;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public DaoAuthenticationProvider() {}
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\authentication\dao\DaoAuthenticationProvider.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */