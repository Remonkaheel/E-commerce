/*     */ package org.springframework.security.converter;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import java.util.Base64;
/*     */ import java.util.List;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.lang.NonNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class X509CertificateDecoder
/*     */   implements Converter<List<String>, RSAPublicKey>
/*     */ {
/*     */   private final CertificateFactory certificateFactory;
/*     */   
/*     */   X509CertificateDecoder(CertificateFactory certificateFactory) {
/* 193 */     this.certificateFactory = certificateFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public RSAPublicKey convert(List<String> lines) {
/* 199 */     StringBuilder base64Encoded = new StringBuilder();
/* 200 */     for (String line : lines) {
/* 201 */       if (isNotX509CertificateWrapper(line)) {
/* 202 */         base64Encoded.append(line);
/*     */       }
/*     */     } 
/* 205 */     byte[] x509 = Base64.getDecoder().decode(base64Encoded.toString()); try {
/* 206 */       InputStream x509CertStream = new ByteArrayInputStream(x509);
/*     */       
/* 208 */       try { X509Certificate certificate = (X509Certificate)this.certificateFactory.generateCertificate(x509CertStream);
/* 209 */         RSAPublicKey rSAPublicKey = (RSAPublicKey)certificate.getPublicKey();
/* 210 */         x509CertStream.close(); return rSAPublicKey; } catch (Throwable throwable) { try { x509CertStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 211 */     } catch (CertificateException|java.io.IOException ex) {
/* 212 */       throw new IllegalArgumentException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isNotX509CertificateWrapper(String line) {
/* 217 */     return (!"-----BEGIN CERTIFICATE-----".equals(line) && !"-----END CERTIFICATE-----".equals(line));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\converter\RsaKeyConverters$X509CertificateDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */