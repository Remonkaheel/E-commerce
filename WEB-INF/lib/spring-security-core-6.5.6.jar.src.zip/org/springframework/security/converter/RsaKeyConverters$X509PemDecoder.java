/*     */ package org.springframework.security.converter;
/*     */ 
/*     */ import java.security.KeyFactory;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import java.security.spec.X509EncodedKeySpec;
/*     */ import java.util.Base64;
/*     */ import java.util.List;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.lang.NonNull;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class X509PemDecoder
/*     */   implements Converter<List<String>, RSAPublicKey>
/*     */ {
/*     */   private final KeyFactory keyFactory;
/*     */   
/*     */   X509PemDecoder(KeyFactory keyFactory) {
/* 161 */     this.keyFactory = keyFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   @NonNull
/*     */   public RSAPublicKey convert(List<String> lines) {
/* 167 */     StringBuilder base64Encoded = new StringBuilder();
/* 168 */     for (String line : lines) {
/* 169 */       if (isNotX509PemWrapper(line)) {
/* 170 */         base64Encoded.append(line);
/*     */       }
/*     */     } 
/* 173 */     byte[] x509 = Base64.getDecoder().decode(base64Encoded.toString());
/*     */     try {
/* 175 */       return (RSAPublicKey)this.keyFactory.generatePublic(new X509EncodedKeySpec(x509));
/*     */     }
/* 177 */     catch (Exception ex) {
/* 178 */       throw new IllegalArgumentException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isNotX509PemWrapper(String line) {
/* 183 */     return (!"-----BEGIN PUBLIC KEY-----".equals(line) && !"-----END PUBLIC KEY-----".equals(line));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\converter\RsaKeyConverters$X509PemDecoder.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */