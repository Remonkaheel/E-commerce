/*     */ package org.springframework.security.converter;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.security.interfaces.RSAPrivateKey;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import java.security.spec.PKCS8EncodedKeySpec;
/*     */ import java.security.spec.X509EncodedKeySpec;
/*     */ import java.util.Base64;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collector;
/*     */ import java.util.stream.Collectors;
/*     */ import org.springframework.core.convert.converter.Converter;
/*     */ import org.springframework.lang.NonNull;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RsaKeyConverters
/*     */ {
/*     */   private static final String DASHES = "-----";
/*     */   private static final String PKCS8_PEM_HEADER = "-----BEGIN PRIVATE KEY-----";
/*     */   private static final String PKCS8_PEM_FOOTER = "-----END PRIVATE KEY-----";
/*     */   private static final String X509_PEM_HEADER = "-----BEGIN PUBLIC KEY-----";
/*     */   private static final String X509_PEM_FOOTER = "-----END PUBLIC KEY-----";
/*     */   private static final String X509_CERT_HEADER = "-----BEGIN CERTIFICATE-----";
/*     */   private static final String X509_CERT_FOOTER = "-----END CERTIFICATE-----";
/*     */   
/*     */   public static Converter<InputStream, RSAPrivateKey> pkcs8() {
/*  82 */     KeyFactory keyFactory = rsaFactory();
/*  83 */     return source -> {
/*     */         List<String> lines = readAllLines(source);
/*  85 */         Assert.isTrue((!lines.isEmpty() && ((String)lines.get(0)).startsWith("-----BEGIN PRIVATE KEY-----")), "Key is not in PEM-encoded PKCS#8 format, please check that the header begins with -----BEGIN PRIVATE KEY-----");
/*     */         
/*     */         StringBuilder base64Encoded = new StringBuilder();
/*     */         
/*     */         for (String line : lines) {
/*     */           if (isNotPkcs8Wrapper(line)) {
/*     */             base64Encoded.append(line);
/*     */           }
/*     */         } 
/*     */         
/*     */         byte[] pkcs8 = Base64.getDecoder().decode(base64Encoded.toString());
/*     */         try {
/*     */           return (RSAPrivateKey)keyFactory.generatePrivate(new PKCS8EncodedKeySpec(pkcs8));
/*  98 */         } catch (Exception ex) {
/*     */           throw new IllegalArgumentException(ex);
/*     */         } 
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Converter<InputStream, RSAPublicKey> x509() {
/* 114 */     X509PemDecoder pemDecoder = new X509PemDecoder(rsaFactory());
/* 115 */     X509CertificateDecoder certDecoder = new X509CertificateDecoder(x509CertificateFactory());
/* 116 */     return source -> {
/*     */         List<String> lines = readAllLines(source);
/*     */         Assert.notEmpty(lines, "Input stream is empty");
/*     */         String encodingHint = lines.get(0);
/*     */         Converter<List<String>, RSAPublicKey> decoder = encodingHint.startsWith("-----BEGIN PUBLIC KEY-----") ? pemDecoder : (encodingHint.startsWith("-----BEGIN CERTIFICATE-----") ? certDecoder : null);
/*     */         Assert.notNull(decoder, "Key is not in PEM-encoded X.509 format or a valid X.509 certificate, please check that the header begins with -----BEGIN PUBLIC KEY----- or -----BEGIN CERTIFICATE-----");
/*     */         return (RSAPublicKey)decoder.convert(lines);
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static CertificateFactory x509CertificateFactory() {
/*     */     try {
/* 131 */       return CertificateFactory.getInstance("X.509");
/*     */     }
/* 133 */     catch (CertificateException ex) {
/* 134 */       throw new IllegalArgumentException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static List<String> readAllLines(InputStream source) {
/* 139 */     BufferedReader reader = new BufferedReader(new InputStreamReader(source));
/* 140 */     return reader.lines().collect((Collector)Collectors.toList());
/*     */   }
/*     */   
/*     */   private static KeyFactory rsaFactory() {
/*     */     try {
/* 145 */       return KeyFactory.getInstance("RSA");
/*     */     }
/* 147 */     catch (NoSuchAlgorithmException ex) {
/* 148 */       throw new IllegalStateException(ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static boolean isNotPkcs8Wrapper(String line) {
/* 153 */     return (!"-----BEGIN PRIVATE KEY-----".equals(line) && !"-----END PRIVATE KEY-----".equals(line));
/*     */   }
/*     */   
/*     */   private static class X509PemDecoder
/*     */     implements Converter<List<String>, RSAPublicKey> {
/*     */     private final KeyFactory keyFactory;
/*     */     
/*     */     X509PemDecoder(KeyFactory keyFactory) {
/* 161 */       this.keyFactory = keyFactory;
/*     */     }
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public RSAPublicKey convert(List<String> lines) {
/* 167 */       StringBuilder base64Encoded = new StringBuilder();
/* 168 */       for (String line : lines) {
/* 169 */         if (isNotX509PemWrapper(line)) {
/* 170 */           base64Encoded.append(line);
/*     */         }
/*     */       } 
/* 173 */       byte[] x509 = Base64.getDecoder().decode(base64Encoded.toString());
/*     */       try {
/* 175 */         return (RSAPublicKey)this.keyFactory.generatePublic(new X509EncodedKeySpec(x509));
/*     */       }
/* 177 */       catch (Exception ex) {
/* 178 */         throw new IllegalArgumentException(ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     private boolean isNotX509PemWrapper(String line) {
/* 183 */       return (!"-----BEGIN PUBLIC KEY-----".equals(line) && !"-----END PUBLIC KEY-----".equals(line));
/*     */     }
/*     */   }
/*     */   
/*     */   private static class X509CertificateDecoder
/*     */     implements Converter<List<String>, RSAPublicKey>
/*     */   {
/*     */     private final CertificateFactory certificateFactory;
/*     */     
/*     */     X509CertificateDecoder(CertificateFactory certificateFactory) {
/* 193 */       this.certificateFactory = certificateFactory;
/*     */     }
/*     */ 
/*     */     
/*     */     @NonNull
/*     */     public RSAPublicKey convert(List<String> lines) {
/* 199 */       StringBuilder base64Encoded = new StringBuilder();
/* 200 */       for (String line : lines) {
/* 201 */         if (isNotX509CertificateWrapper(line)) {
/* 202 */           base64Encoded.append(line);
/*     */         }
/*     */       } 
/* 205 */       byte[] x509 = Base64.getDecoder().decode(base64Encoded.toString()); try {
/* 206 */         InputStream x509CertStream = new ByteArrayInputStream(x509);
/*     */         
/* 208 */         try { X509Certificate certificate = (X509Certificate)this.certificateFactory.generateCertificate(x509CertStream);
/* 209 */           RSAPublicKey rSAPublicKey = (RSAPublicKey)certificate.getPublicKey();
/* 210 */           x509CertStream.close(); return rSAPublicKey; } catch (Throwable throwable) { try { x509CertStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 211 */       } catch (CertificateException|java.io.IOException ex) {
/* 212 */         throw new IllegalArgumentException(ex);
/*     */       } 
/*     */     }
/*     */     
/*     */     private boolean isNotX509CertificateWrapper(String line) {
/* 217 */       return (!"-----BEGIN CERTIFICATE-----".equals(line) && !"-----END CERTIFICATE-----".equals(line));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\converter\RsaKeyConverters.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */