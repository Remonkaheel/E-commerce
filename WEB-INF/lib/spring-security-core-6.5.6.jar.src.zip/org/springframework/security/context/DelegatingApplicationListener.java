/*    */ package org.springframework.security.context;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.concurrent.CopyOnWriteArrayList;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.context.event.SmartApplicationListener;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DelegatingApplicationListener
/*    */   implements ApplicationListener<ApplicationEvent>
/*    */ {
/* 36 */   private List<SmartApplicationListener> listeners = new CopyOnWriteArrayList<>();
/*    */ 
/*    */   
/*    */   public void onApplicationEvent(ApplicationEvent event) {
/* 40 */     if (event == null) {
/*    */       return;
/*    */     }
/* 43 */     for (SmartApplicationListener listener : this.listeners) {
/* 44 */       Object source = event.getSource();
/* 45 */       if (source != null && listener.supportsEventType(event.getClass()) && listener
/* 46 */         .supportsSourceType(source.getClass())) {
/* 47 */         listener.onApplicationEvent(event);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addListener(SmartApplicationListener smartApplicationListener) {
/* 58 */     Assert.notNull(smartApplicationListener, "smartApplicationListener cannot be null");
/* 59 */     this.listeners.add(smartApplicationListener);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\context\DelegatingApplicationListener.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */