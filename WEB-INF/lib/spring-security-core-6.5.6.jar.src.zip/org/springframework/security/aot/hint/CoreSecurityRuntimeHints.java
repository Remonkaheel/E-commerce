/*     */ package org.springframework.security.aot.hint;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.stream.Stream;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.RuntimeHintsRegistrar;
/*     */ import org.springframework.aot.hint.TypeHint;
/*     */ import org.springframework.aot.hint.TypeReference;
/*     */ import org.springframework.security.access.expression.SecurityExpressionOperations;
/*     */ import org.springframework.security.access.expression.SecurityExpressionRoot;
/*     */ import org.springframework.security.authentication.AbstractAuthenticationToken;
/*     */ import org.springframework.security.authentication.AccountExpiredException;
/*     */ import org.springframework.security.authentication.AuthenticationServiceException;
/*     */ import org.springframework.security.authentication.BadCredentialsException;
/*     */ import org.springframework.security.authentication.CredentialsExpiredException;
/*     */ import org.springframework.security.authentication.DisabledException;
/*     */ import org.springframework.security.authentication.LockedException;
/*     */ import org.springframework.security.authentication.ProviderNotFoundException;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureCredentialsExpiredEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureDisabledEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureExpiredEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureLockedEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureProviderNotFoundEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureProxyUntrustedEvent;
/*     */ import org.springframework.security.authentication.event.AuthenticationFailureServiceExceptionEvent;
/*     */ import org.springframework.security.core.context.SecurityContextImpl;
/*     */ import org.springframework.security.core.userdetails.UsernameNotFoundException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CoreSecurityRuntimeHints
/*     */   implements RuntimeHintsRegistrar
/*     */ {
/*     */   public void registerHints(RuntimeHints hints, ClassLoader classLoader) {
/*  58 */     registerExceptionEventsHints(hints);
/*  59 */     registerExpressionEvaluationHints(hints);
/*  60 */     registerMethodSecurityHints(hints);
/*  61 */     hints.resources().registerResourceBundle("org.springframework.security.messages");
/*  62 */     registerDefaultJdbcSchemaFileHint(hints);
/*  63 */     registerSecurityContextHints(hints);
/*     */   }
/*     */   
/*     */   private void registerMethodSecurityHints(RuntimeHints hints) {
/*  67 */     hints.reflection()
/*  68 */       .registerType(
/*     */         
/*  70 */         TypeReference.of("org.springframework.security.access.expression.method.MethodSecurityExpressionRoot"), builder -> builder.withMembers(new MemberCategory[] { MemberCategory.INVOKE_PUBLIC_METHODS }));
/*     */     
/*  72 */     hints.reflection()
/*  73 */       .registerType(AbstractAuthenticationToken.class, builder -> builder.withMembers(new MemberCategory[] { MemberCategory.INVOKE_PUBLIC_METHODS }));
/*     */   }
/*     */ 
/*     */   
/*     */   private void registerExpressionEvaluationHints(RuntimeHints hints) {
/*  78 */     hints.reflection()
/*  79 */       .registerTypes(
/*  80 */         List.of(TypeReference.of(SecurityExpressionOperations.class), 
/*  81 */           TypeReference.of(SecurityExpressionRoot.class)), builder -> builder.withMembers(new MemberCategory[] { MemberCategory.DECLARED_FIELDS, MemberCategory.INVOKE_DECLARED_METHODS }));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerExceptionEventsHints(RuntimeHints hints) {
/*  87 */     hints.reflection()
/*  88 */       .registerTypes(getDefaultAuthenticationExceptionEventPublisherTypes(), builder -> builder.withMembers(new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS }));
/*     */   }
/*     */ 
/*     */   
/*     */   private List<TypeReference> getDefaultAuthenticationExceptionEventPublisherTypes() {
/*  93 */     return 
/*  94 */       Stream.<Class<?>[]>of((Class<?>[][])new Class[] {
/*     */ 
/*     */           
/*     */           AuthenticationFailureBadCredentialsEvent.class, AuthenticationFailureCredentialsExpiredEvent.class, AuthenticationFailureDisabledEvent.class, AuthenticationFailureExpiredEvent.class, AuthenticationFailureLockedEvent.class, AuthenticationFailureProviderNotFoundEvent.class, AuthenticationFailureProxyUntrustedEvent.class, AuthenticationFailureServiceExceptionEvent.class, AuthenticationServiceException.class, AccountExpiredException.class,
/*     */ 
/*     */           
/*     */           BadCredentialsException.class, CredentialsExpiredException.class, DisabledException.class, LockedException.class, UsernameNotFoundException.class, ProviderNotFoundException.class
/* 101 */         }).map(TypeReference::of)
/* 102 */       .toList();
/*     */   }
/*     */   
/*     */   private void registerDefaultJdbcSchemaFileHint(RuntimeHints hints) {
/* 106 */     hints.resources().registerPattern("org/springframework/security/core/userdetails/jdbc/users.ddl");
/*     */   }
/*     */   
/*     */   private void registerSecurityContextHints(RuntimeHints hints) {
/* 110 */     hints.reflection()
/* 111 */       .registerType(SecurityContextImpl.class, builder -> builder.withMembers(new MemberCategory[] { MemberCategory.INVOKE_PUBLIC_METHODS }));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\aot\hint\CoreSecurityRuntimeHints.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */