/*     */ package org.springframework.security.aot.hint;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.aop.SpringProxy;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.security.authorization.AuthorizationProxyFactory;
/*     */ import org.springframework.security.authorization.method.AuthorizeReturnObject;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanner;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanners;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AuthorizeReturnObjectHintsRegistrar
/*     */   implements SecurityHintsRegistrar
/*     */ {
/*     */   private final AuthorizationProxyFactory proxyFactory;
/*  72 */   private final SecurityAnnotationScanner<AuthorizeReturnObject> scanner = SecurityAnnotationScanners.requireUnique(AuthorizeReturnObject.class);
/*     */   
/*  74 */   private final Set<Class<?>> visitedClasses = new HashSet<>();
/*     */   
/*     */   private final List<Class<?>> classesToProxy;
/*     */   
/*     */   public AuthorizeReturnObjectHintsRegistrar(AuthorizationProxyFactory proxyFactory, Class<?>... classes) {
/*  79 */     Assert.notNull(proxyFactory, "proxyFactory cannot be null");
/*  80 */     Assert.noNullElements((Object[])classes, "classes cannot contain null elements");
/*  81 */     this.proxyFactory = proxyFactory;
/*  82 */     this.classesToProxy = new ArrayList<>(List.of(classes));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AuthorizeReturnObjectHintsRegistrar(AuthorizationProxyFactory proxyFactory, List<Class<?>> classes) {
/*  92 */     this.proxyFactory = proxyFactory;
/*  93 */     this.classesToProxy = new ArrayList<>(classes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerHints(RuntimeHints hints, ConfigurableListableBeanFactory beanFactory) {
/* 101 */     List<Class<?>> toProxy = new ArrayList<>();
/* 102 */     for (Class<?> clazz : this.classesToProxy) {
/* 103 */       toProxy.add(clazz);
/* 104 */       traverseType(toProxy, clazz);
/*     */     } 
/* 106 */     for (Class<?> clazz : toProxy) {
/* 107 */       registerProxy(hints, clazz);
/*     */     }
/*     */   }
/*     */   
/*     */   private void registerProxy(RuntimeHints hints, Class<?> clazz) {
/* 112 */     Class<?> proxied = (Class)this.proxyFactory.proxy(clazz);
/* 113 */     if (proxied == null) {
/*     */       return;
/*     */     }
/* 116 */     if (Proxy.isProxyClass(proxied)) {
/* 117 */       hints.proxies().registerJdkProxy(proxied.getInterfaces());
/*     */       return;
/*     */     } 
/* 120 */     if (SpringProxy.class.isAssignableFrom(proxied)) {
/* 121 */       hints.reflection()
/* 122 */         .registerType(clazz, new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS, MemberCategory.INVOKE_DECLARED_METHODS
/*     */           
/* 124 */           }).registerType(proxied, new MemberCategory[] { MemberCategory.INVOKE_DECLARED_CONSTRUCTORS, MemberCategory.INVOKE_DECLARED_METHODS, MemberCategory.DECLARED_FIELDS });
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void traverseType(List<Class<?>> toProxy, Class<?> clazz) {
/* 130 */     if (clazz == Object.class || this.visitedClasses.contains(clazz)) {
/*     */       return;
/*     */     }
/* 133 */     this.visitedClasses.add(clazz);
/* 134 */     for (Method m : clazz.getDeclaredMethods()) {
/* 135 */       AuthorizeReturnObject object = (AuthorizeReturnObject)this.scanner.scan(m, clazz);
/* 136 */       if (object != null) {
/*     */ 
/*     */         
/* 139 */         Class<?> returnType = m.getReturnType();
/* 140 */         toProxy.add(returnType);
/* 141 */         traverseType(toProxy, returnType);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\aot\hint\AuthorizeReturnObjectHintsRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */