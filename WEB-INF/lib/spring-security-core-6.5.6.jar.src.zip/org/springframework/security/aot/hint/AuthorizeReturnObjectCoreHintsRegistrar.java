/*    */ package org.springframework.security.aot.hint;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.security.authorization.AuthorizationProxyFactory;
/*    */ import org.springframework.security.authorization.method.AuthorizeReturnObject;
/*    */ import org.springframework.security.core.annotation.SecurityAnnotationScanner;
/*    */ import org.springframework.security.core.annotation.SecurityAnnotationScanners;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AuthorizeReturnObjectCoreHintsRegistrar
/*    */   implements SecurityHintsRegistrar
/*    */ {
/*    */   private final AuthorizationProxyFactory proxyFactory;
/* 64 */   private final SecurityAnnotationScanner<AuthorizeReturnObject> scanner = SecurityAnnotationScanners.requireUnique(AuthorizeReturnObject.class);
/*    */   
/* 66 */   private final Set<Class<?>> visitedClasses = new HashSet<>();
/*    */   
/*    */   public AuthorizeReturnObjectCoreHintsRegistrar(AuthorizationProxyFactory proxyFactory) {
/* 69 */     Assert.notNull(proxyFactory, "proxyFactory cannot be null");
/* 70 */     this.proxyFactory = proxyFactory;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void registerHints(RuntimeHints hints, ConfigurableListableBeanFactory beanFactory) {
/* 78 */     List<Class<?>> toProxy = new ArrayList<>();
/* 79 */     for (String name : beanFactory.getBeanDefinitionNames()) {
/* 80 */       Class<?> clazz = beanFactory.getType(name, false);
/* 81 */       if (clazz != null)
/*    */       {
/*    */         
/* 84 */         for (Method method : clazz.getDeclaredMethods()) {
/* 85 */           AuthorizeReturnObject annotation = (AuthorizeReturnObject)this.scanner.scan(method, clazz);
/* 86 */           if (annotation != null)
/*    */           {
/*    */             
/* 89 */             toProxy.add(method.getReturnType()); } 
/*    */         }  } 
/*    */     } 
/* 92 */     (new AuthorizeReturnObjectHintsRegistrar(this.proxyFactory, toProxy)).registerHints(hints, beanFactory);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\aot\hint\AuthorizeReturnObjectCoreHintsRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */