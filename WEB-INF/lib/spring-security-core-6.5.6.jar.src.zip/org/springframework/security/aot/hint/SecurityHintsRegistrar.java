package org.springframework.security.aot.hint;

import org.springframework.aot.hint.RuntimeHints;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;

public interface SecurityHintsRegistrar {
  void registerHints(RuntimeHints paramRuntimeHints, ConfigurableListableBeanFactory paramConfigurableListableBeanFactory);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\aot\hint\SecurityHintsRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */