/*    */ package org.springframework.security.aot.hint;
/*    */ 
/*    */ import org.springframework.aot.generate.GenerationContext;
/*    */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotContribution;
/*    */ import org.springframework.beans.factory.aot.BeanFactoryInitializationAotProcessor;
/*    */ import org.springframework.beans.factory.aot.BeanFactoryInitializationCode;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SecurityHintsAotProcessor
/*    */   implements BeanFactoryInitializationAotProcessor
/*    */ {
/*    */   public BeanFactoryInitializationAotContribution processAheadOfTime(ConfigurableListableBeanFactory beanFactory) {
/* 29 */     return new AuthorizationProxyFactoryAotContribution(beanFactory);
/*    */   }
/*    */   
/*    */   private static final class AuthorizationProxyFactoryAotContribution
/*    */     implements BeanFactoryInitializationAotContribution
/*    */   {
/*    */     private final ConfigurableListableBeanFactory beanFactory;
/*    */     
/*    */     private AuthorizationProxyFactoryAotContribution(ConfigurableListableBeanFactory beanFactory) {
/* 38 */       this.beanFactory = beanFactory;
/*    */     }
/*    */ 
/*    */     
/*    */     public void applyTo(GenerationContext context, BeanFactoryInitializationCode code) {
/* 43 */       this.beanFactory.getBeanProvider(SecurityHintsRegistrar.class)
/* 44 */         .forEach(provider -> provider.registerHints(context.getRuntimeHints(), this.beanFactory));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\aot\hint\SecurityHintsAotProcessor.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */