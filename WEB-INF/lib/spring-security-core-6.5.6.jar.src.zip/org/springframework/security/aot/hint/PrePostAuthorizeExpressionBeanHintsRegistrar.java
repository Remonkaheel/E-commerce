/*     */ package org.springframework.security.aot.hint;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.aot.hint.MemberCategory;
/*     */ import org.springframework.aot.hint.RuntimeHints;
/*     */ import org.springframework.aot.hint.TypeReference;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.expression.spel.SpelNode;
/*     */ import org.springframework.expression.spel.ast.BeanReference;
/*     */ import org.springframework.expression.spel.standard.SpelExpression;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.security.access.prepost.PostAuthorize;
/*     */ import org.springframework.security.access.prepost.PreAuthorize;
/*     */ import org.springframework.security.authorization.method.AuthorizeReturnObject;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanner;
/*     */ import org.springframework.security.core.annotation.SecurityAnnotationScanners;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PrePostAuthorizeExpressionBeanHintsRegistrar
/*     */   implements SecurityHintsRegistrar
/*     */ {
/*  71 */   private final SecurityAnnotationScanner<PreAuthorize> preAuthorizeScanner = SecurityAnnotationScanners.requireUnique(PreAuthorize.class);
/*     */ 
/*     */   
/*  74 */   private final SecurityAnnotationScanner<PostAuthorize> postAuthorizeScanner = SecurityAnnotationScanners.requireUnique(PostAuthorize.class);
/*     */ 
/*     */   
/*  77 */   private final SecurityAnnotationScanner<AuthorizeReturnObject> authorizeReturnObjectScanner = SecurityAnnotationScanners.requireUnique(AuthorizeReturnObject.class);
/*     */   
/*  79 */   private final SpelExpressionParser expressionParser = new SpelExpressionParser();
/*     */   
/*  81 */   private final Set<Class<?>> visitedClasses = new HashSet<>();
/*     */   
/*     */   private final List<Class<?>> toVisit;
/*     */   
/*     */   public PrePostAuthorizeExpressionBeanHintsRegistrar(Class<?>... toVisit) {
/*  86 */     this(Arrays.asList(toVisit));
/*     */   }
/*     */   
/*     */   public PrePostAuthorizeExpressionBeanHintsRegistrar(List<Class<?>> toVisit) {
/*  90 */     Assert.notEmpty(toVisit, "toVisit cannot be empty");
/*  91 */     Assert.noNullElements(toVisit, "toVisit cannot contain null elements");
/*  92 */     this.toVisit = toVisit;
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerHints(RuntimeHints hints, ConfigurableListableBeanFactory beanFactory) {
/*  97 */     Set<String> expressions = new HashSet<>();
/*  98 */     for (Class<?> bean : this.toVisit) {
/*  99 */       expressions.addAll(extractSecurityExpressions(bean));
/*     */     }
/* 101 */     Set<String> beanNamesToRegister = new HashSet<>();
/* 102 */     for (String expression : expressions) {
/* 103 */       beanNamesToRegister.addAll(extractBeanNames(expression));
/*     */     }
/* 105 */     for (String toRegister : beanNamesToRegister) {
/* 106 */       Class<?> type = beanFactory.getType(toRegister, false);
/* 107 */       if (type == null) {
/*     */         continue;
/*     */       }
/* 110 */       hints.reflection().registerType(TypeReference.of(type), new MemberCategory[] { MemberCategory.INVOKE_DECLARED_METHODS });
/*     */     } 
/*     */   }
/*     */   
/*     */   private Set<String> extractSecurityExpressions(Class<?> clazz) {
/* 115 */     if (this.visitedClasses.contains(clazz)) {
/* 116 */       return Collections.emptySet();
/*     */     }
/* 118 */     this.visitedClasses.add(clazz);
/* 119 */     Set<String> expressions = new HashSet<>();
/* 120 */     for (Method method : clazz.getDeclaredMethods()) {
/* 121 */       PreAuthorize preAuthorize = (PreAuthorize)this.preAuthorizeScanner.scan(method, clazz);
/* 122 */       PostAuthorize postAuthorize = (PostAuthorize)this.postAuthorizeScanner.scan(method, clazz);
/* 123 */       if (preAuthorize != null) {
/* 124 */         expressions.add(preAuthorize.value());
/*     */       }
/* 126 */       if (postAuthorize != null) {
/* 127 */         expressions.add(postAuthorize.value());
/*     */       }
/* 129 */       AuthorizeReturnObject authorizeReturnObject = (AuthorizeReturnObject)this.authorizeReturnObjectScanner.scan(method, clazz);
/* 130 */       if (authorizeReturnObject != null) {
/* 131 */         expressions.addAll(extractSecurityExpressions(method.getReturnType()));
/*     */       }
/*     */     } 
/* 134 */     return expressions;
/*     */   }
/*     */   
/*     */   private Set<String> extractBeanNames(String rawExpression) {
/* 138 */     SpelExpression expression = this.expressionParser.parseRaw(rawExpression);
/* 139 */     SpelNode node = expression.getAST();
/* 140 */     Set<String> beanNames = new HashSet<>();
/* 141 */     resolveBeanNames(beanNames, node);
/* 142 */     return beanNames;
/*     */   }
/*     */   
/*     */   private void resolveBeanNames(Set<String> beanNames, SpelNode node) {
/* 146 */     if (node instanceof BeanReference) { BeanReference br = (BeanReference)node;
/* 147 */       beanNames.add(br.getName()); }
/*     */     
/* 149 */     int childCount = node.getChildCount();
/* 150 */     if (childCount == 0) {
/*     */       return;
/*     */     }
/* 153 */     for (int i = 0; i < childCount; i++)
/* 154 */       resolveBeanNames(beanNames, node.getChild(i)); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\aot\hint\PrePostAuthorizeExpressionBeanHintsRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */