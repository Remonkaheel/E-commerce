/*    */ package org.springframework.security.aot.hint;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ import org.springframework.aot.hint.RuntimeHints;
/*    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*    */ import org.springframework.beans.factory.support.RegisteredBean;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PrePostAuthorizeHintsRegistrar
/*    */   implements SecurityHintsRegistrar
/*    */ {
/*    */   public void registerHints(RuntimeHints hints, ConfigurableListableBeanFactory beanFactory) {
/* 45 */     List<Class<?>> beans = (List<Class<?>>)Arrays.<String>stream(beanFactory.getBeanDefinitionNames()).map(beanName -> RegisteredBean.of(beanFactory, beanName).getBeanClass()).collect(Collectors.toList());
/* 46 */     (new PrePostAuthorizeExpressionBeanHintsRegistrar(beans)).registerHints(hints, beanFactory);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\spring-security-core-6.5.6.jar!\org\springframework\security\aot\hint\PrePostAuthorizeHintsRegistrar.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */