/*     */ package org.unbescape.javascript;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum JavaScriptEscapeLevel
/*     */ {
/*  90 */   LEVEL_1_BASIC_ESCAPE_SET(1),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   LEVEL_2_ALL_NON_ASCII_PLUS_BASIC_ESCAPE_SET(2),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   LEVEL_3_ALL_NON_ALPHANUMERIC(3),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   LEVEL_4_ALL_CHARACTERS(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int escapeLevel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JavaScriptEscapeLevel forLevel(int level) {
/* 123 */     switch (level) { case 1:
/* 124 */         return LEVEL_1_BASIC_ESCAPE_SET;
/* 125 */       case 2: return LEVEL_2_ALL_NON_ASCII_PLUS_BASIC_ESCAPE_SET;
/* 126 */       case 3: return LEVEL_3_ALL_NON_ALPHANUMERIC;
/* 127 */       case 4: return LEVEL_4_ALL_CHARACTERS; }
/*     */     
/* 129 */     throw new IllegalArgumentException("No escape level enum constant defined for level: " + level);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   JavaScriptEscapeLevel(int escapeLevel) {
/* 135 */     this.escapeLevel = escapeLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEscapeLevel() {
/* 144 */     return this.escapeLevel;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\li\\unbescape-1.1.6.RELEASE.jar!\or\\unbescape\javascript\JavaScriptEscapeLevel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */