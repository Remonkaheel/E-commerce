/*    */ package org.unbescape.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum JsonEscapeType
/*    */ {
/* 51 */   SINGLE_ESCAPE_CHARS_DEFAULT_TO_UHEXA(true),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 56 */   UHEXA(false);
/*    */   
/*    */   private final boolean useSECs;
/*    */ 
/*    */   
/*    */   JsonEscapeType(boolean useSECs) {
/* 62 */     this.useSECs = useSECs;
/*    */   }
/*    */   
/*    */   boolean getUseSECs() {
/* 66 */     return this.useSECs;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\li\\unbescape-1.1.6.RELEASE.jar!\or\\unbescape\json\JsonEscapeType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */