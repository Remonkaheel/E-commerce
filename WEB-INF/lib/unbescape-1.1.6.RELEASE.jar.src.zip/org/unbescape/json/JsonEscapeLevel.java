/*     */ package org.unbescape.json;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum JsonEscapeLevel
/*     */ {
/*  85 */   LEVEL_1_BASIC_ESCAPE_SET(1),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   LEVEL_2_ALL_NON_ASCII_PLUS_BASIC_ESCAPE_SET(2),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   LEVEL_3_ALL_NON_ALPHANUMERIC(3),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   LEVEL_4_ALL_CHARACTERS(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int escapeLevel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonEscapeLevel forLevel(int level) {
/* 118 */     switch (level) { case 1:
/* 119 */         return LEVEL_1_BASIC_ESCAPE_SET;
/* 120 */       case 2: return LEVEL_2_ALL_NON_ASCII_PLUS_BASIC_ESCAPE_SET;
/* 121 */       case 3: return LEVEL_3_ALL_NON_ALPHANUMERIC;
/* 122 */       case 4: return LEVEL_4_ALL_CHARACTERS; }
/*     */     
/* 124 */     throw new IllegalArgumentException("No escape level enum constant defined for level: " + level);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   JsonEscapeLevel(int escapeLevel) {
/* 130 */     this.escapeLevel = escapeLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEscapeLevel() {
/* 139 */     return this.escapeLevel;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\li\\unbescape-1.1.6.RELEASE.jar!\or\\unbescape\json\JsonEscapeLevel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */