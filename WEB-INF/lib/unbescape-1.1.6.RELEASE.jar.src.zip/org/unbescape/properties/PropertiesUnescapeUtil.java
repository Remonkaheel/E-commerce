/*     */ package org.unbescape.properties;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PropertiesUnescapeUtil
/*     */ {
/*     */   private static final char ESCAPE_PREFIX = '\\';
/*     */   private static final char ESCAPE_UHEXA_PREFIX2 = 'u';
/*  93 */   private static char[] HEXA_CHARS_UPPER = "0123456789ABCDEF".toCharArray();
/*  94 */   private static char[] HEXA_CHARS_LOWER = "0123456789abcdef".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int parseIntFromReference(String text, int start, int end, int radix) {
/* 115 */     int result = 0;
/* 116 */     for (int i = start; i < end; i++) {
/* 117 */       char c = text.charAt(i);
/* 118 */       int n = -1;
/* 119 */       for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/* 120 */         if (c == HEXA_CHARS_UPPER[j] || c == HEXA_CHARS_LOWER[j]) {
/* 121 */           n = j;
/*     */           break;
/*     */         } 
/*     */       } 
/* 125 */       result = radix * result + n;
/*     */     } 
/* 127 */     return result;
/*     */   }
/*     */   
/*     */   static int parseIntFromReference(char[] text, int start, int end, int radix) {
/* 131 */     int result = 0;
/* 132 */     for (int i = start; i < end; i++) {
/* 133 */       char c = text[i];
/* 134 */       int n = -1;
/* 135 */       for (int j = 0; j < HEXA_CHARS_UPPER.length; j++) {
/* 136 */         if (c == HEXA_CHARS_UPPER[j] || c == HEXA_CHARS_LOWER[j]) {
/* 137 */           n = j;
/*     */           break;
/*     */         } 
/*     */       } 
/* 141 */       result = radix * result + n;
/*     */     } 
/* 143 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String unescape(String text) {
/* 155 */     if (text == null) {
/* 156 */       return null;
/*     */     }
/*     */     
/* 159 */     StringBuilder strBuilder = null;
/*     */     
/* 161 */     int offset = 0;
/* 162 */     int max = text.length();
/*     */     
/* 164 */     int readOffset = 0;
/* 165 */     int referenceOffset = 0;
/*     */     
/* 167 */     int i = 0; while (true) { if (i < max)
/*     */       
/* 169 */       { char c = text.charAt(i);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 175 */         if (c != '\\' || i + 1 >= max) {
/*     */           continue;
/*     */         }
/*     */         
/* 179 */         int codepoint = -1;
/*     */         
/* 181 */         if (c == '\\')
/*     */         
/* 183 */         { char c1 = text.charAt(i + 1);
/*     */           
/* 185 */           switch (c1) { case 't':
/* 186 */               codepoint = 9; referenceOffset = i + 1; break;
/* 187 */             case 'n': codepoint = 10; referenceOffset = i + 1; break;
/* 188 */             case 'f': codepoint = 12; referenceOffset = i + 1; break;
/* 189 */             case 'r': codepoint = 13; referenceOffset = i + 1; break;
/* 190 */             case '\\': codepoint = 92; referenceOffset = i + 1;
/*     */               break; }
/*     */           
/* 193 */           if (codepoint == -1)
/*     */           
/* 195 */           { if (c1 == 'u')
/*     */             
/*     */             { 
/* 198 */               int f = i + 2;
/* 199 */               while (f < i + 6 && f < max) {
/* 200 */                 char cf = text.charAt(f);
/* 201 */                 if ((cf < '0' || cf > '9') && (cf < 'A' || cf > 'F') && (cf < 'a' || cf > 'f')) {
/*     */                   break;
/*     */                 }
/* 204 */                 f++;
/*     */               } 
/*     */               
/* 207 */               if (f - i + 2 < 4)
/*     */               
/*     */               { 
/* 210 */                 i++; }
/*     */               
/*     */               else
/*     */               
/* 214 */               { codepoint = parseIntFromReference(text, i + 2, f, 16);
/*     */ 
/*     */                 
/* 217 */                 referenceOffset = f - 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 243 */                 if (strBuilder == null)
/* 244 */                   strBuilder = new StringBuilder(max + 5);  }  } else { codepoint = c1; referenceOffset = i + 1; if (strBuilder == null) strBuilder = new StringBuilder(max + 5);  }  continue; }  }  } else { break; }  if (strBuilder == null) strBuilder = new StringBuilder(max + 5);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       i++; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 278 */     if (strBuilder == null) {
/* 279 */       return text;
/*     */     }
/*     */     
/* 282 */     if (max - readOffset > 0) {
/* 283 */       strBuilder.append(text, readOffset, max);
/*     */     }
/*     */     
/* 286 */     return strBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void unescape(Reader reader, Writer writer) throws IOException {
/* 303 */     if (reader == null) {
/*     */       return;
/*     */     }
/*     */     
/* 307 */     char[] escapes = new char[4];
/*     */ 
/*     */     
/* 310 */     int c2 = reader.read();
/*     */     
/* 312 */     while (c2 >= 0) {
/*     */       
/* 314 */       int c1 = c2;
/* 315 */       c2 = reader.read();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 321 */       if (c1 != 92 || c2 < 0) {
/* 322 */         writer.write(c1);
/*     */         
/*     */         continue;
/*     */       } 
/* 326 */       int codepoint = -1;
/*     */       
/* 328 */       if (c1 == 92) {
/*     */         
/* 330 */         switch (c2) { case 116:
/* 331 */             codepoint = 9; c1 = c2; c2 = reader.read(); break;
/* 332 */           case 110: codepoint = 10; c1 = c2; c2 = reader.read(); break;
/* 333 */           case 102: codepoint = 12; c1 = c2; c2 = reader.read(); break;
/* 334 */           case 114: codepoint = 13; c1 = c2; c2 = reader.read(); break;
/* 335 */           case 92: codepoint = 92; c1 = c2; c2 = reader.read();
/*     */             break; }
/*     */         
/* 338 */         if (codepoint == -1)
/*     */         {
/* 340 */           if (c2 == 117) {
/*     */ 
/*     */             
/* 343 */             int escapei = 0;
/* 344 */             int ce = reader.read();
/* 345 */             while (ce >= 0 && escapei < 4 && ((
/* 346 */               ce >= 48 && ce <= 57) || (ce >= 65 && ce <= 70) || (ce >= 97 && ce <= 102))) {
/*     */ 
/*     */               
/* 349 */               escapes[escapei] = (char)ce;
/* 350 */               ce = reader.read();
/* 351 */               escapei++;
/*     */             } 
/*     */             
/* 354 */             if (escapei < 4) {
/*     */ 
/*     */               
/* 357 */               writer.write(c1);
/* 358 */               writer.write(c2);
/* 359 */               for (int i = 0; i < escapei; i++) {
/* 360 */                 c1 = c2;
/* 361 */                 c2 = escapes[i];
/* 362 */                 writer.write(c2);
/*     */               } 
/* 364 */               c1 = c2;
/* 365 */               c2 = ce;
/*     */               
/*     */               continue;
/*     */             } 
/* 369 */             c1 = escapes[3];
/* 370 */             c2 = ce;
/*     */             
/* 372 */             codepoint = parseIntFromReference(escapes, 0, 4, 16);
/*     */ 
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */ 
/*     */             
/* 381 */             codepoint = c2;
/*     */             
/* 383 */             c1 = c2;
/* 384 */             c2 = reader.read();
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 400 */       if (codepoint > 65535) {
/* 401 */         writer.write(Character.toChars(codepoint)); continue;
/*     */       } 
/* 403 */       writer.write((char)codepoint);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void unescape(char[] text, int offset, int len, Writer writer) throws IOException {
/* 421 */     if (text == null) {
/*     */       return;
/*     */     }
/*     */     
/* 425 */     int max = offset + len;
/*     */     
/* 427 */     int readOffset = offset;
/* 428 */     int referenceOffset = offset;
/*     */     
/* 430 */     int i = offset; while (true) { if (i < max)
/*     */       
/* 432 */       { char c = text[i];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 438 */         if (c != '\\' || i + 1 >= max) {
/*     */           continue;
/*     */         }
/*     */         
/* 442 */         int codepoint = -1;
/*     */         
/* 444 */         if (c == '\\')
/*     */         
/* 446 */         { char c1 = text[i + 1];
/*     */           
/* 448 */           switch (c1) { case 't':
/* 449 */               codepoint = 9; referenceOffset = i + 1; break;
/* 450 */             case 'n': codepoint = 10; referenceOffset = i + 1; break;
/* 451 */             case 'f': codepoint = 12; referenceOffset = i + 1; break;
/* 452 */             case 'r': codepoint = 13; referenceOffset = i + 1; break;
/* 453 */             case '\\': codepoint = 92; referenceOffset = i + 1;
/*     */               break; }
/*     */           
/* 456 */           if (codepoint == -1)
/*     */           
/* 458 */           { if (c1 == 'u')
/*     */             
/*     */             { 
/* 461 */               int f = i + 2;
/* 462 */               while (f < i + 6 && f < max) {
/* 463 */                 char cf = text[f];
/* 464 */                 if ((cf < '0' || cf > '9') && (cf < 'A' || cf > 'F') && (cf < 'a' || cf > 'f')) {
/*     */                   break;
/*     */                 }
/* 467 */                 f++;
/*     */               } 
/*     */               
/* 470 */               if (f - i + 2 < 4)
/*     */               
/*     */               { 
/* 473 */                 i++; }
/*     */               
/*     */               else
/*     */               
/* 477 */               { codepoint = parseIntFromReference(text, i + 2, f, 16);
/*     */ 
/*     */                 
/* 480 */                 referenceOffset = f - 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 505 */                 if (i - readOffset > 0)
/* 506 */                   writer.write(text, readOffset, i - readOffset);  }  } else { codepoint = c1; referenceOffset = i + 1; if (i - readOffset > 0) writer.write(text, readOffset, i - readOffset);  }  continue; }  }  } else { break; }  if (i - readOffset > 0) writer.write(text, readOffset, i - readOffset);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       i++; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 535 */     if (max - readOffset > 0)
/* 536 */       writer.write(text, readOffset, max - readOffset); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\li\\unbescape-1.1.6.RELEASE.jar!\or\\unbescape\properties\PropertiesUnescapeUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */