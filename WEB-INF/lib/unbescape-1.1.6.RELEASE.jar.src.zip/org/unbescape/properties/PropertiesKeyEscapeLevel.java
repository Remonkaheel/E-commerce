/*     */ package org.unbescape.properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum PropertiesKeyEscapeLevel
/*     */ {
/*  75 */   LEVEL_1_BASIC_ESCAPE_SET(1),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   LEVEL_2_ALL_NON_ASCII_PLUS_BASIC_ESCAPE_SET(2),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   LEVEL_3_ALL_NON_ALPHANUMERIC(3),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   LEVEL_4_ALL_CHARACTERS(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int escapeLevel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertiesKeyEscapeLevel forLevel(int level) {
/* 108 */     switch (level) { case 1:
/* 109 */         return LEVEL_1_BASIC_ESCAPE_SET;
/* 110 */       case 2: return LEVEL_2_ALL_NON_ASCII_PLUS_BASIC_ESCAPE_SET;
/* 111 */       case 3: return LEVEL_3_ALL_NON_ALPHANUMERIC;
/* 112 */       case 4: return LEVEL_4_ALL_CHARACTERS; }
/*     */     
/* 114 */     throw new IllegalArgumentException("No escape level enum constant defined for level: " + level);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   PropertiesKeyEscapeLevel(int escapeLevel) {
/* 120 */     this.escapeLevel = escapeLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEscapeLevel() {
/* 129 */     return this.escapeLevel;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\li\\unbescape-1.1.6.RELEASE.jar!\or\\unbescape\properties\PropertiesKeyEscapeLevel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */