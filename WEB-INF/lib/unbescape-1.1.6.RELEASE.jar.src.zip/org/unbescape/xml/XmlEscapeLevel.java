/*     */ package org.unbescape.xml;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum XmlEscapeLevel
/*     */ {
/*  73 */   LEVEL_1_ONLY_MARKUP_SIGNIFICANT(1),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   LEVEL_2_ALL_NON_ASCII_PLUS_MARKUP_SIGNIFICANT(2),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   LEVEL_3_ALL_NON_ALPHANUMERIC(3),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   LEVEL_4_ALL_CHARACTERS(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int escapeLevel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static XmlEscapeLevel forLevel(int level) {
/* 106 */     switch (level) { case 1:
/* 107 */         return LEVEL_1_ONLY_MARKUP_SIGNIFICANT;
/* 108 */       case 2: return LEVEL_2_ALL_NON_ASCII_PLUS_MARKUP_SIGNIFICANT;
/* 109 */       case 3: return LEVEL_3_ALL_NON_ALPHANUMERIC;
/* 110 */       case 4: return LEVEL_4_ALL_CHARACTERS; }
/*     */     
/* 112 */     throw new IllegalArgumentException("No escape level enum constant defined for level: " + level);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   XmlEscapeLevel(int escapeLevel) {
/* 118 */     this.escapeLevel = escapeLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEscapeLevel() {
/* 127 */     return this.escapeLevel;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\li\\unbescape-1.1.6.RELEASE.jar!\or\\unbescape\xml\XmlEscapeLevel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */