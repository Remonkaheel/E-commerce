/*    */ package org.unbescape.xml;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum XmlEscapeType
/*    */ {
/* 57 */   CHARACTER_ENTITY_REFERENCES_DEFAULT_TO_DECIMAL(true, false),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   CHARACTER_ENTITY_REFERENCES_DEFAULT_TO_HEXA(true, true),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 67 */   DECIMAL_REFERENCES(false, false),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 72 */   HEXADECIMAL_REFERENCES(false, true);
/*    */   
/*    */   private final boolean useCERs;
/*    */   
/*    */   private final boolean useHexa;
/*    */   
/*    */   XmlEscapeType(boolean useCERs, boolean useHexa) {
/* 79 */     this.useCERs = useCERs;
/* 80 */     this.useHexa = useHexa;
/*    */   }
/*    */   
/*    */   boolean getUseCERs() {
/* 84 */     return this.useCERs;
/*    */   }
/*    */   
/*    */   boolean getUseHexa() {
/* 88 */     return this.useHexa;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\li\\unbescape-1.1.6.RELEASE.jar!\or\\unbescape\xml\XmlEscapeType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */