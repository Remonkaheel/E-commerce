package org.unbescape.xml;

interface XmlCodepointValidator {
  boolean isValid(int paramInt);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\li\\unbescape-1.1.6.RELEASE.jar!\or\\unbescape\xml\XmlCodepointValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */