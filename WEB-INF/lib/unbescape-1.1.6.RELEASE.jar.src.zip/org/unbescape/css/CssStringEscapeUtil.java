/*     */ package org.unbescape.css;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class CssStringEscapeUtil
/*     */ {
/*     */   private static final char ESCAPE_PREFIX = '\\';
/*  80 */   private static char[] HEXA_CHARS_UPPER = "0123456789ABCDEF".toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   private static int BACKSLASH_CHARS_LEN = 127;
/*  87 */   private static char BACKSLASH_CHARS_NO_ESCAPE = Character.MIN_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   private static char[] BACKSLASH_CHARS = new char[BACKSLASH_CHARS_LEN]; static {
/* 106 */     Arrays.fill(BACKSLASH_CHARS, BACKSLASH_CHARS_NO_ESCAPE);
/* 107 */     BACKSLASH_CHARS[32] = ' ';
/* 108 */     BACKSLASH_CHARS[33] = '!';
/* 109 */     BACKSLASH_CHARS[34] = '"';
/* 110 */     BACKSLASH_CHARS[35] = '#';
/* 111 */     BACKSLASH_CHARS[36] = '$';
/* 112 */     BACKSLASH_CHARS[37] = '%';
/* 113 */     BACKSLASH_CHARS[38] = '&';
/* 114 */     BACKSLASH_CHARS[39] = '\'';
/* 115 */     BACKSLASH_CHARS[40] = '(';
/* 116 */     BACKSLASH_CHARS[41] = ')';
/* 117 */     BACKSLASH_CHARS[42] = '*';
/* 118 */     BACKSLASH_CHARS[43] = '+';
/* 119 */     BACKSLASH_CHARS[44] = ',';
/* 120 */     BACKSLASH_CHARS[45] = '-';
/* 121 */     BACKSLASH_CHARS[46] = '.';
/* 122 */     BACKSLASH_CHARS[47] = '/';
/*     */ 
/*     */     
/* 125 */     BACKSLASH_CHARS[59] = ';';
/* 126 */     BACKSLASH_CHARS[60] = '<';
/* 127 */     BACKSLASH_CHARS[61] = '=';
/* 128 */     BACKSLASH_CHARS[62] = '>';
/* 129 */     BACKSLASH_CHARS[63] = '?';
/* 130 */     BACKSLASH_CHARS[64] = '@';
/* 131 */     BACKSLASH_CHARS[91] = '[';
/* 132 */     BACKSLASH_CHARS[92] = '\\';
/* 133 */     BACKSLASH_CHARS[93] = ']';
/* 134 */     BACKSLASH_CHARS[94] = '^';
/* 135 */     BACKSLASH_CHARS[95] = '_';
/* 136 */     BACKSLASH_CHARS[96] = '`';
/* 137 */     BACKSLASH_CHARS[123] = '{';
/* 138 */     BACKSLASH_CHARS[124] = '|';
/* 139 */     BACKSLASH_CHARS[125] = '}';
/* 140 */     BACKSLASH_CHARS[126] = '~';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final char ESCAPE_LEVELS_LEN = '¡';
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   private static final byte[] ESCAPE_LEVELS = new byte[161];
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 159 */     Arrays.fill(ESCAPE_LEVELS, (byte)3);
/*     */ 
/*     */     
/*     */     char c;
/*     */     
/* 164 */     for (c = ''; c < '¡'; c = (char)(c + 1)) {
/* 165 */       ESCAPE_LEVELS[c] = 2;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 171 */     for (c = 'A'; c <= 'Z'; c = (char)(c + 1)) {
/* 172 */       ESCAPE_LEVELS[c] = 4;
/*     */     }
/* 174 */     for (c = 'a'; c <= 'z'; c = (char)(c + 1)) {
/* 175 */       ESCAPE_LEVELS[c] = 4;
/*     */     }
/* 177 */     for (c = '0'; c <= '9'; c = (char)(c + 1)) {
/* 178 */       ESCAPE_LEVELS[c] = 4;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 184 */     ESCAPE_LEVELS[34] = 1;
/* 185 */     ESCAPE_LEVELS[39] = 1;
/* 186 */     ESCAPE_LEVELS[92] = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     ESCAPE_LEVELS[47] = 1;
/* 192 */     ESCAPE_LEVELS[38] = 1;
/* 193 */     ESCAPE_LEVELS[59] = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     for (c = Character.MIN_VALUE; c <= '\037'; c = (char)(c + 1)) {
/* 200 */       ESCAPE_LEVELS[c] = 1;
/*     */     }
/* 202 */     for (c = ''; c <= ''; c = (char)(c + 1)) {
/* 203 */       ESCAPE_LEVELS[c] = 1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static char[] toCompactHexa(int codepoint, char next, int level) {
/* 221 */     boolean needTrailingSpace = ((level < 4 && ((next >= '0' && next <= '9') || (next >= 'A' && next <= 'F') || (next >= 'a' && next <= 'f'))) || (level < 3 && next == ' '));
/*     */ 
/*     */ 
/*     */     
/* 225 */     if (codepoint == 0) {
/* 226 */       (new char[2])[0] = '0'; (new char[2])[1] = ' '; (new char[1])[0] = '0'; return needTrailingSpace ? new char[2] : new char[1];
/*     */     } 
/* 228 */     int div = 20;
/* 229 */     char[] result = null;
/* 230 */     while (result == null && div >= 0) {
/* 231 */       if ((codepoint >>> div) % 16 > 0) {
/* 232 */         result = new char[div / 4 + (needTrailingSpace ? 2 : 1)];
/*     */       }
/* 234 */       div -= 4;
/*     */     } 
/* 236 */     div = 0;
/* 237 */     for (int i = needTrailingSpace ? (result.length - 2) : (result.length - 1); i >= 0; i--) {
/* 238 */       result[i] = HEXA_CHARS_UPPER[(codepoint >>> div) % 16];
/* 239 */       div += 4;
/*     */     } 
/* 241 */     if (needTrailingSpace) {
/* 242 */       result[result.length - 1] = ' ';
/*     */     }
/*     */     
/* 245 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static char[] toSixDigitHexa(int codepoint, char next, int level) {
/* 253 */     boolean needTrailingSpace = (level < 3 && next == ' ');
/*     */     
/* 255 */     char[] result = new char[6 + (needTrailingSpace ? 1 : 0)];
/* 256 */     if (needTrailingSpace) {
/* 257 */       result[6] = ' ';
/*     */     }
/* 259 */     result[5] = HEXA_CHARS_UPPER[codepoint % 16];
/* 260 */     result[4] = HEXA_CHARS_UPPER[(codepoint >>> 4) % 16];
/* 261 */     result[3] = HEXA_CHARS_UPPER[(codepoint >>> 8) % 16];
/* 262 */     result[2] = HEXA_CHARS_UPPER[(codepoint >>> 12) % 16];
/* 263 */     result[1] = HEXA_CHARS_UPPER[(codepoint >>> 16) % 16];
/* 264 */     result[0] = HEXA_CHARS_UPPER[(codepoint >>> 20) % 16];
/* 265 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String escape(String text, CssStringEscapeType escapeType, CssStringEscapeLevel escapeLevel) {
/* 275 */     if (text == null) {
/* 276 */       return null;
/*     */     }
/*     */     
/* 279 */     int level = escapeLevel.getEscapeLevel();
/* 280 */     boolean useBackslashEscapes = escapeType.getUseBackslashEscapes();
/* 281 */     boolean useCompactHexa = escapeType.getUseCompactHexa();
/*     */     
/* 283 */     StringBuilder strBuilder = null;
/*     */     
/* 285 */     int offset = 0;
/* 286 */     int max = text.length();
/*     */     
/* 288 */     int readOffset = 0;
/*     */     
/* 290 */     for (int i = 0; i < max; i++) {
/*     */       
/* 292 */       int codepoint = Character.codePointAt(text, i);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 299 */       if (codepoint <= 159 && level < ESCAPE_LEVELS[codepoint]) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 307 */       if (codepoint > 159 && level < ESCAPE_LEVELS[160]) {
/*     */         
/* 309 */         if (Character.charCount(codepoint) > 1)
/*     */         {
/* 311 */           i++;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 325 */       if (strBuilder == null) {
/* 326 */         strBuilder = new StringBuilder(max + 20);
/*     */       }
/*     */       
/* 329 */       if (i - readOffset > 0) {
/* 330 */         strBuilder.append(text, readOffset, i);
/*     */       }
/*     */       
/* 333 */       if (Character.charCount(codepoint) > 1)
/*     */       {
/* 335 */         i++;
/*     */       }
/*     */       
/* 338 */       readOffset = i + 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 349 */       if (useBackslashEscapes && codepoint < BACKSLASH_CHARS_LEN) {
/*     */ 
/*     */         
/* 352 */         char sec = BACKSLASH_CHARS[codepoint];
/*     */         
/* 354 */         if (sec != BACKSLASH_CHARS_NO_ESCAPE) {
/*     */           
/* 356 */           strBuilder.append('\\');
/* 357 */           strBuilder.append(sec);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 368 */       char next = (i + 1 < max) ? text.charAt(i + 1) : Character.MIN_VALUE;
/*     */       
/* 370 */       if (useCompactHexa) {
/* 371 */         strBuilder.append('\\');
/* 372 */         strBuilder.append(toCompactHexa(codepoint, next, level));
/*     */       }
/*     */       else {
/*     */         
/* 376 */         strBuilder.append('\\');
/* 377 */         strBuilder.append(toSixDigitHexa(codepoint, next, level));
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       continue;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 389 */     if (strBuilder == null) {
/* 390 */       return text;
/*     */     }
/*     */     
/* 393 */     if (max - readOffset > 0) {
/* 394 */       strBuilder.append(text, readOffset, max);
/*     */     }
/*     */     
/* 397 */     return strBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void escape(Reader reader, Writer writer, CssStringEscapeType escapeType, CssStringEscapeLevel escapeLevel) throws IOException {
/* 414 */     if (reader == null) {
/*     */       return;
/*     */     }
/*     */     
/* 418 */     int level = escapeLevel.getEscapeLevel();
/* 419 */     boolean useBackslashEscapes = escapeType.getUseBackslashEscapes();
/* 420 */     boolean useCompactHexa = escapeType.getUseCompactHexa();
/*     */ 
/*     */ 
/*     */     
/* 424 */     int c2 = reader.read();
/*     */     
/* 426 */     while (c2 >= 0) {
/*     */       
/* 428 */       int c1 = c2;
/* 429 */       c2 = reader.read();
/*     */       
/* 431 */       int codepoint = codePointAt((char)c1, (char)c2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 438 */       if (codepoint <= 159 && level < ESCAPE_LEVELS[codepoint]) {
/* 439 */         writer.write(c1);
/*     */ 
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */       
/* 447 */       if (codepoint > 159 && level < ESCAPE_LEVELS[160]) {
/*     */         
/* 449 */         writer.write(c1);
/*     */         
/* 451 */         if (Character.charCount(codepoint) > 1) {
/*     */ 
/*     */           
/* 454 */           writer.write(c2);
/*     */           
/* 456 */           c1 = c2;
/* 457 */           c2 = reader.read();
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 471 */       if (Character.charCount(codepoint) > 1) {
/*     */         
/* 473 */         c1 = c2;
/* 474 */         c2 = reader.read();
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 486 */       if (useBackslashEscapes && codepoint < BACKSLASH_CHARS_LEN) {
/*     */ 
/*     */         
/* 489 */         char sec = BACKSLASH_CHARS[codepoint];
/*     */         
/* 491 */         if (sec != BACKSLASH_CHARS_NO_ESCAPE) {
/*     */           
/* 493 */           writer.write(92);
/* 494 */           writer.write(sec);
/*     */ 
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 504 */       char next = (c2 >= 0) ? (char)c2 : Character.MIN_VALUE;
/*     */       
/* 506 */       if (useCompactHexa) {
/* 507 */         writer.write(92);
/* 508 */         writer.write(toCompactHexa(codepoint, next, level));
/*     */         
/*     */         continue;
/*     */       } 
/* 512 */       writer.write(92);
/* 513 */       writer.write(toSixDigitHexa(codepoint, next, level));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void escape(char[] text, int offset, int len, Writer writer, CssStringEscapeType escapeType, CssStringEscapeLevel escapeLevel) throws IOException {
/* 530 */     if (text == null || text.length == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 534 */     int level = escapeLevel.getEscapeLevel();
/* 535 */     boolean useBackslashEscapes = escapeType.getUseBackslashEscapes();
/* 536 */     boolean useCompactHexa = escapeType.getUseCompactHexa();
/*     */     
/* 538 */     int max = offset + len;
/*     */     
/* 540 */     int readOffset = offset;
/*     */     
/* 542 */     for (int i = offset; i < max; i++) {
/*     */       
/* 544 */       int codepoint = Character.codePointAt(text, i);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 551 */       if (codepoint <= 159 && level < ESCAPE_LEVELS[codepoint]) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 559 */       if (codepoint > 159 && level < ESCAPE_LEVELS[160]) {
/*     */         
/* 561 */         if (Character.charCount(codepoint) > 1)
/*     */         {
/* 563 */           i++;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 576 */       if (i - readOffset > 0) {
/* 577 */         writer.write(text, readOffset, i - readOffset);
/*     */       }
/*     */       
/* 580 */       if (Character.charCount(codepoint) > 1)
/*     */       {
/* 582 */         i++;
/*     */       }
/*     */       
/* 585 */       readOffset = i + 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 596 */       if (useBackslashEscapes && codepoint < BACKSLASH_CHARS_LEN) {
/*     */ 
/*     */         
/* 599 */         char escape = BACKSLASH_CHARS[codepoint];
/*     */         
/* 601 */         if (escape != BACKSLASH_CHARS_NO_ESCAPE) {
/*     */           
/* 603 */           writer.write(92);
/* 604 */           writer.write(escape);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 615 */       char next = (i + 1 < max) ? text[i + 1] : Character.MIN_VALUE;
/*     */       
/* 617 */       if (useCompactHexa) {
/* 618 */         writer.write(92);
/* 619 */         writer.write(toCompactHexa(codepoint, next, level));
/*     */       }
/*     */       else {
/*     */         
/* 623 */         writer.write(92);
/* 624 */         writer.write(toSixDigitHexa(codepoint, next, level));
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       continue;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 635 */     if (max - readOffset > 0) {
/* 636 */       writer.write(text, readOffset, max - readOffset);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int codePointAt(char c1, char c2) {
/* 645 */     if (Character.isHighSurrogate(c1) && 
/* 646 */       c2 >= '\000' && 
/* 647 */       Character.isLowSurrogate(c2)) {
/* 648 */       return Character.toCodePoint(c1, c2);
/*     */     }
/*     */ 
/*     */     
/* 652 */     return c1;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\li\\unbescape-1.1.6.RELEASE.jar!\or\\unbescape\css\CssStringEscapeUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */