/*     */ package org.unbescape.css;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum CssIdentifierEscapeLevel
/*     */ {
/* 102 */   LEVEL_1_BASIC_ESCAPE_SET(1),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   LEVEL_2_ALL_NON_ASCII_PLUS_BASIC_ESCAPE_SET(2),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   LEVEL_3_ALL_NON_ALPHANUMERIC(3),
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   LEVEL_4_ALL_CHARACTERS(4);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int escapeLevel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CssIdentifierEscapeLevel forLevel(int level) {
/* 135 */     switch (level) { case 1:
/* 136 */         return LEVEL_1_BASIC_ESCAPE_SET;
/* 137 */       case 2: return LEVEL_2_ALL_NON_ASCII_PLUS_BASIC_ESCAPE_SET;
/* 138 */       case 3: return LEVEL_3_ALL_NON_ALPHANUMERIC;
/* 139 */       case 4: return LEVEL_4_ALL_CHARACTERS; }
/*     */     
/* 141 */     throw new IllegalArgumentException("No escape level enum constant defined for level: " + level);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   CssIdentifierEscapeLevel(int escapeLevel) {
/* 147 */     this.escapeLevel = escapeLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEscapeLevel() {
/* 156 */     return this.escapeLevel;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\li\\unbescape-1.1.6.RELEASE.jar!\or\\unbescape\css\CssIdentifierEscapeLevel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */