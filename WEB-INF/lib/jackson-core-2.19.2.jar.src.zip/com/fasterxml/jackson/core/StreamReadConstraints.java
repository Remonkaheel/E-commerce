/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import com.fasterxml.jackson.core.exc.StreamConstraintsException;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamReadConstraints
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final int DEFAULT_MAX_DEPTH = 1000;
/*     */   public static final long DEFAULT_MAX_DOC_LEN = -1L;
/*     */   public static final long DEFAULT_MAX_TOKEN_COUNT = -1L;
/*     */   public static final int DEFAULT_MAX_NUM_LEN = 1000;
/*     */   public static final int DEFAULT_MAX_STRING_LEN = 20000000;
/*     */   public static final int DEFAULT_MAX_NAME_LEN = 50000;
/*     */   private static final int MAX_BIGINT_SCALE_MAGNITUDE = 100000;
/*     */   protected final int _maxNestingDepth;
/*     */   protected final long _maxDocLen;
/*     */   protected final long _maxTokenCount;
/*     */   protected final int _maxNumLen;
/*     */   protected final int _maxStringLen;
/*     */   protected final int _maxNameLen;
/*  92 */   private static StreamReadConstraints DEFAULT = new StreamReadConstraints(1000, -1L, 1000, 20000000, 50000);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void overrideDefaultStreamReadConstraints(StreamReadConstraints streamReadConstraints) {
/* 115 */     if (streamReadConstraints == null) {
/* 116 */       DEFAULT = new StreamReadConstraints(1000, -1L, 1000, 20000000);
/*     */     } else {
/*     */       
/* 119 */       DEFAULT = streamReadConstraints;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private long maxDocLen;
/*     */     
/*     */     private long maxTokenCount;
/*     */     
/*     */     private int maxNestingDepth;
/*     */     
/*     */     private int maxNumLen;
/*     */     
/*     */     private int maxStringLen;
/*     */     
/*     */     private int maxNameLen;
/*     */ 
/*     */     
/*     */     public Builder maxNestingDepth(int maxNestingDepth) {
/* 141 */       if (maxNestingDepth < 0) {
/* 142 */         throw new IllegalArgumentException("Cannot set maxNestingDepth to a negative value");
/*     */       }
/* 144 */       this.maxNestingDepth = maxNestingDepth;
/* 145 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder maxDocumentLength(long maxDocLen) {
/* 167 */       if (maxDocLen <= 0L) {
/* 168 */         maxDocLen = -1L;
/*     */       }
/* 170 */       this.maxDocLen = maxDocLen;
/* 171 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder maxTokenCount(long maxTokenCount) {
/* 192 */       if (maxTokenCount <= 0L) {
/* 193 */         maxTokenCount = -1L;
/*     */       }
/* 195 */       this.maxTokenCount = maxTokenCount;
/* 196 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder maxNumberLength(int maxNumLen) {
/* 209 */       if (maxNumLen < 0) {
/* 210 */         throw new IllegalArgumentException("Cannot set maxNumberLength to a negative value");
/*     */       }
/* 212 */       this.maxNumLen = maxNumLen;
/* 213 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder maxStringLength(int maxStringLen) {
/* 234 */       if (maxStringLen < 0) {
/* 235 */         throw new IllegalArgumentException("Cannot set maxStringLen to a negative value");
/*     */       }
/* 237 */       this.maxStringLen = maxStringLen;
/* 238 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder maxNameLength(int maxNameLen) {
/* 255 */       if (maxNameLen < 0) {
/* 256 */         throw new IllegalArgumentException("Cannot set maxNameLen to a negative value");
/*     */       }
/* 258 */       this.maxNameLen = maxNameLen;
/* 259 */       return this;
/*     */     }
/*     */     
/*     */     Builder() {
/* 263 */       this(1000, -1L, -1L, 1000, 20000000, 50000);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     Builder(int maxNestingDepth, long maxDocLen, long maxTokenCount, int maxNumLen, int maxStringLen, int maxNameLen) {
/* 269 */       this.maxNestingDepth = maxNestingDepth;
/* 270 */       this.maxDocLen = maxDocLen;
/* 271 */       this.maxTokenCount = maxTokenCount;
/* 272 */       this.maxNumLen = maxNumLen;
/* 273 */       this.maxStringLen = maxStringLen;
/* 274 */       this.maxNameLen = maxNameLen;
/*     */     }
/*     */     
/*     */     Builder(StreamReadConstraints src) {
/* 278 */       this.maxNestingDepth = src._maxNestingDepth;
/* 279 */       this.maxDocLen = src._maxDocLen;
/* 280 */       this.maxTokenCount = src._maxTokenCount;
/* 281 */       this.maxNumLen = src._maxNumLen;
/* 282 */       this.maxStringLen = src._maxStringLen;
/* 283 */       this.maxNameLen = src._maxNameLen;
/*     */     }
/*     */     
/*     */     public StreamReadConstraints build() {
/* 287 */       return new StreamReadConstraints(this.maxNestingDepth, this.maxDocLen, this.maxNumLen, this.maxStringLen, this.maxNameLen, this.maxTokenCount);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected StreamReadConstraints(int maxNestingDepth, long maxDocLen, int maxNumLen, int maxStringLen) {
/* 301 */     this(maxNestingDepth, maxDocLen, maxNumLen, maxStringLen, 50000, -1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected StreamReadConstraints(int maxNestingDepth, long maxDocLen, int maxNumLen, int maxStringLen, int maxNameLen) {
/* 317 */     this(maxNestingDepth, maxDocLen, maxNumLen, maxStringLen, maxNameLen, -1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StreamReadConstraints(int maxNestingDepth, long maxDocLen, int maxNumLen, int maxStringLen, int maxNameLen, long maxTokenCount) {
/* 332 */     this._maxNestingDepth = maxNestingDepth;
/* 333 */     this._maxDocLen = maxDocLen;
/* 334 */     this._maxNumLen = maxNumLen;
/* 335 */     this._maxStringLen = maxStringLen;
/* 336 */     this._maxNameLen = maxNameLen;
/* 337 */     this._maxTokenCount = maxTokenCount;
/*     */   }
/*     */   
/*     */   public static Builder builder() {
/* 341 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StreamReadConstraints defaults() {
/* 349 */     return DEFAULT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder rebuild() {
/* 357 */     return new Builder(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxNestingDepth() {
/* 373 */     return this._maxNestingDepth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMaxDocumentLength() {
/* 383 */     return this._maxDocLen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasMaxDocumentLength() {
/* 396 */     return (this._maxDocLen > 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getMaxTokenCount() {
/* 407 */     return this._maxTokenCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasMaxTokenCount() {
/* 421 */     return (this._maxTokenCount > 0L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxNumberLength() {
/* 431 */     return this._maxNumLen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxStringLength() {
/* 441 */     return this._maxStringLen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxNameLength() {
/* 451 */     return this._maxNameLen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateNestingDepth(int depth) throws StreamConstraintsException {
/* 473 */     if (depth > this._maxNestingDepth) {
/* 474 */       throw _constructException("Document nesting depth (%d) exceeds the maximum allowed (%d, from %s)", new Object[] {
/*     */             
/* 476 */             Integer.valueOf(depth), Integer.valueOf(this._maxNestingDepth), 
/* 477 */             _constrainRef("getMaxNestingDepth")
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateDocumentLength(long len) throws StreamConstraintsException {
/* 496 */     if (len > this._maxDocLen && this._maxDocLen > 0L)
/*     */     {
/*     */       
/* 499 */       throw _constructException("Document length (%d) exceeds the maximum allowed (%d, from %s)", new Object[] {
/*     */             
/* 501 */             Long.valueOf(len), Long.valueOf(this._maxDocLen), 
/* 502 */             _constrainRef("getMaxDocumentLength")
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateTokenCount(long count) throws StreamConstraintsException {
/* 523 */     if (count > this._maxTokenCount) {
/* 524 */       throw _constructException("Token count (%d) exceeds the maximum allowed (%d, from %s)", new Object[] {
/*     */             
/* 526 */             Long.valueOf(count), Long.valueOf(this._maxTokenCount), 
/* 527 */             _constrainRef("getMaxTokenCount")
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateFPLength(int length) throws StreamConstraintsException {
/* 550 */     if (length > this._maxNumLen) {
/* 551 */       throw _constructException("Number value length (%d) exceeds the maximum allowed (%d, from %s)", new Object[] {
/*     */             
/* 553 */             Integer.valueOf(length), Integer.valueOf(this._maxNumLen), 
/* 554 */             _constrainRef("getMaxNumberLength")
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateIntegerLength(int length) throws StreamConstraintsException {
/* 571 */     if (length > this._maxNumLen) {
/* 572 */       throw _constructException("Number value length (%d) exceeds the maximum allowed (%d, from %s)", new Object[] {
/*     */             
/* 574 */             Integer.valueOf(length), Integer.valueOf(this._maxNumLen), 
/* 575 */             _constrainRef("getMaxNumberLength")
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateStringLength(int length) throws StreamConstraintsException {
/* 592 */     if (length > this._maxStringLen) {
/* 593 */       throw _constructException("String value length (%d) exceeds the maximum allowed (%d, from %s)", new Object[] {
/*     */             
/* 595 */             Integer.valueOf(length), Integer.valueOf(this._maxStringLen), 
/* 596 */             _constrainRef("getMaxStringLength")
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateNameLength(int length) throws StreamConstraintsException {
/* 613 */     if (length > this._maxNameLen) {
/* 614 */       throw _constructException("Name length (%d) exceeds the maximum allowed (%d, from %s)", new Object[] {
/*     */             
/* 616 */             Integer.valueOf(length), Integer.valueOf(this._maxNameLen), 
/* 617 */             _constrainRef("getMaxNameLength")
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateBigIntegerScale(int scale) throws StreamConstraintsException {
/* 640 */     int absScale = Math.abs(scale);
/* 641 */     int limit = 100000;
/*     */     
/* 643 */     if (absScale > 100000) {
/* 644 */       throw _constructException("BigDecimal scale (%d) magnitude exceeds the maximum allowed (%d)", new Object[] {
/*     */             
/* 646 */             Integer.valueOf(scale), Integer.valueOf(100000)
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StreamConstraintsException _constructException(String msgTemplate, Object... args) throws StreamConstraintsException {
/* 658 */     throw new StreamConstraintsException(String.format(msgTemplate, args));
/*     */   }
/*     */ 
/*     */   
/*     */   protected String _constrainRef(String method) {
/* 663 */     return "`StreamReadConstraints." + method + "()`";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\StreamReadConstraints.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */