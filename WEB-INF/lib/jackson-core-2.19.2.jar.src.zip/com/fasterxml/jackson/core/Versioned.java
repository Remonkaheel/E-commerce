package com.fasterxml.jackson.core;

public interface Versioned {
  Version version();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\Versioned.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */