/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import com.fasterxml.jackson.core.exc.StreamReadException;
/*     */ import com.fasterxml.jackson.core.util.RequestPayload;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonParseException
/*     */   extends StreamReadException
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   
/*     */   public JsonParseException(String msg) {
/*  23 */     this((JsonParser)null, msg, (JsonLocation)null, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParseException(JsonParser p, String msg) {
/*  37 */     this(p, msg, _currentLocation(p), (Throwable)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParseException(JsonParser p, String msg, Throwable rootCause) {
/*  42 */     this(p, msg, _currentLocation(p), rootCause);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParseException(JsonParser p, String msg, JsonLocation loc) {
/*  47 */     this(p, msg, loc, (Throwable)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParseException(JsonParser p, String msg, JsonLocation loc, Throwable rootCause) {
/*  53 */     super(p, msg, loc, rootCause);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public JsonParseException(String msg, JsonLocation loc) {
/*  58 */     this((JsonParser)null, msg, loc, (Throwable)null);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public JsonParseException(String msg, JsonLocation loc, Throwable rootCause) {
/*  63 */     this((JsonParser)null, msg, loc, rootCause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParseException withParser(JsonParser p) {
/*  80 */     this._processor = p;
/*  81 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParseException withRequestPayload(RequestPayload payload) {
/*  98 */     this._requestPayload = payload;
/*  99 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParser getProcessor() {
/* 105 */     return super.getProcessor();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestPayload getRequestPayload() {
/* 111 */     return super.getRequestPayload();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRequestPayloadAsString() {
/* 117 */     return super.getRequestPayloadAsString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 123 */     return super.getMessage();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\JsonParseException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */