/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.InputDecorator;
/*     */ import com.fasterxml.jackson.core.io.OutputDecorator;
/*     */ import com.fasterxml.jackson.core.json.JsonReadFeature;
/*     */ import com.fasterxml.jackson.core.json.JsonWriteFeature;
/*     */ import com.fasterxml.jackson.core.util.BufferRecycler;
/*     */ import com.fasterxml.jackson.core.util.JsonGeneratorDecorator;
/*     */ import com.fasterxml.jackson.core.util.JsonRecyclerPools;
/*     */ import com.fasterxml.jackson.core.util.RecyclerPool;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TSFBuilder<F extends JsonFactory, B extends TSFBuilder<F, B>>
/*     */ {
/*  34 */   protected static final int DEFAULT_FACTORY_FEATURE_FLAGS = JsonFactory.Feature.collectDefaults();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   protected static final int DEFAULT_PARSER_FEATURE_FLAGS = JsonParser.Feature.collectDefaults();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   protected static final int DEFAULT_GENERATOR_FEATURE_FLAGS = JsonGenerator.Feature.collectDefaults();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _factoryFeatures;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _streamReadFeatures;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _streamWriteFeatures;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected RecyclerPool<BufferRecycler> _recyclerPool;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InputDecorator _inputDecorator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OutputDecorator _outputDecorator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StreamReadConstraints _streamReadConstraints;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StreamWriteConstraints _streamWriteConstraints;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ErrorReportConfiguration _errorReportConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<JsonGeneratorDecorator> _generatorDecorators;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TSFBuilder() {
/* 126 */     this(DEFAULT_FACTORY_FEATURE_FLAGS, DEFAULT_PARSER_FEATURE_FLAGS, DEFAULT_GENERATOR_FEATURE_FLAGS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TSFBuilder(JsonFactory base) {
/* 133 */     this(base._factoryFeatures, base._parserFeatures, base._generatorFeatures);
/*     */     
/* 135 */     this._inputDecorator = base._inputDecorator;
/* 136 */     this._outputDecorator = base._outputDecorator;
/* 137 */     this._streamReadConstraints = base._streamReadConstraints;
/* 138 */     this._streamWriteConstraints = base._streamWriteConstraints;
/* 139 */     this._errorReportConfiguration = base._errorReportConfiguration;
/* 140 */     this._generatorDecorators = _copy(base._generatorDecorators);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected TSFBuilder(int factoryFeatures, int parserFeatures, int generatorFeatures) {
/* 146 */     this._recyclerPool = JsonRecyclerPools.defaultPool();
/*     */     
/* 148 */     this._factoryFeatures = factoryFeatures;
/* 149 */     this._streamReadFeatures = parserFeatures;
/* 150 */     this._streamWriteFeatures = generatorFeatures;
/*     */     
/* 152 */     this._inputDecorator = null;
/* 153 */     this._outputDecorator = null;
/* 154 */     this._streamReadConstraints = StreamReadConstraints.defaults();
/* 155 */     this._streamWriteConstraints = StreamWriteConstraints.defaults();
/* 156 */     this._errorReportConfiguration = ErrorReportConfiguration.defaults();
/* 157 */     this._generatorDecorators = null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static <T> List<T> _copy(List<T> src) {
/* 162 */     if (src == null) {
/* 163 */       return src;
/*     */     }
/* 165 */     return new ArrayList<>(src);
/*     */   }
/*     */ 
/*     */   
/*     */   public int factoryFeaturesMask() {
/* 170 */     return this._factoryFeatures; }
/* 171 */   public int streamReadFeatures() { return this._streamReadFeatures; } public int streamWriteFeatures() {
/* 172 */     return this._streamWriteFeatures;
/*     */   }
/*     */   public RecyclerPool<BufferRecycler> recyclerPool() {
/* 175 */     return this._recyclerPool;
/*     */   }
/*     */   
/* 178 */   public InputDecorator inputDecorator() { return this._inputDecorator; } public OutputDecorator outputDecorator() {
/* 179 */     return this._outputDecorator;
/*     */   }
/*     */ 
/*     */   
/*     */   public B enable(JsonFactory.Feature f) {
/* 184 */     this._factoryFeatures |= f.getMask();
/* 185 */     return _this();
/*     */   }
/*     */   
/*     */   public B disable(JsonFactory.Feature f) {
/* 189 */     this._factoryFeatures &= f.getMask() ^ 0xFFFFFFFF;
/* 190 */     return _this();
/*     */   }
/*     */   
/*     */   public B configure(JsonFactory.Feature f, boolean state) {
/* 194 */     return state ? enable(f) : disable(f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public B enable(StreamReadFeature f) {
/* 200 */     this._streamReadFeatures |= f.mappedFeature().getMask();
/* 201 */     return _this();
/*     */   }
/*     */   
/*     */   public B enable(StreamReadFeature first, StreamReadFeature... other) {
/* 205 */     this._streamReadFeatures |= first.mappedFeature().getMask();
/* 206 */     for (StreamReadFeature f : other) {
/* 207 */       this._streamReadFeatures |= f.mappedFeature().getMask();
/*     */     }
/* 209 */     return _this();
/*     */   }
/*     */   
/*     */   public B disable(StreamReadFeature f) {
/* 213 */     this._streamReadFeatures &= f.mappedFeature().getMask() ^ 0xFFFFFFFF;
/* 214 */     return _this();
/*     */   }
/*     */   
/*     */   public B disable(StreamReadFeature first, StreamReadFeature... other) {
/* 218 */     this._streamReadFeatures &= first.mappedFeature().getMask() ^ 0xFFFFFFFF;
/* 219 */     for (StreamReadFeature f : other) {
/* 220 */       this._streamReadFeatures &= f.mappedFeature().getMask() ^ 0xFFFFFFFF;
/*     */     }
/* 222 */     return _this();
/*     */   }
/*     */   
/*     */   public B configure(StreamReadFeature f, boolean state) {
/* 226 */     return state ? enable(f) : disable(f);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public B enable(StreamWriteFeature f) {
/* 232 */     this._streamWriteFeatures |= f.mappedFeature().getMask();
/* 233 */     return _this();
/*     */   }
/*     */   
/*     */   public B enable(StreamWriteFeature first, StreamWriteFeature... other) {
/* 237 */     this._streamWriteFeatures |= first.mappedFeature().getMask();
/* 238 */     for (StreamWriteFeature f : other) {
/* 239 */       this._streamWriteFeatures |= f.mappedFeature().getMask();
/*     */     }
/* 241 */     return _this();
/*     */   }
/*     */   
/*     */   public B disable(StreamWriteFeature f) {
/* 245 */     this._streamWriteFeatures &= f.mappedFeature().getMask() ^ 0xFFFFFFFF;
/* 246 */     return _this();
/*     */   }
/*     */   
/*     */   public B disable(StreamWriteFeature first, StreamWriteFeature... other) {
/* 250 */     this._streamWriteFeatures &= first.mappedFeature().getMask() ^ 0xFFFFFFFF;
/* 251 */     for (StreamWriteFeature f : other) {
/* 252 */       this._streamWriteFeatures &= f.mappedFeature().getMask() ^ 0xFFFFFFFF;
/*     */     }
/* 254 */     return _this();
/*     */   }
/*     */   
/*     */   public B configure(StreamWriteFeature f, boolean state) {
/* 258 */     return state ? enable(f) : disable(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B enable(JsonReadFeature f) {
/* 271 */     return _failNonJSON(f);
/*     */   }
/*     */   
/*     */   public B enable(JsonReadFeature first, JsonReadFeature... other) {
/* 275 */     return _failNonJSON(first);
/*     */   }
/*     */   
/*     */   public B disable(JsonReadFeature f) {
/* 279 */     return _failNonJSON(f);
/*     */   }
/*     */   
/*     */   public B disable(JsonReadFeature first, JsonReadFeature... other) {
/* 283 */     return _failNonJSON(first);
/*     */   }
/*     */   
/*     */   public B configure(JsonReadFeature f, boolean state) {
/* 287 */     return _failNonJSON(f);
/*     */   }
/*     */   
/*     */   private B _failNonJSON(Object feature) {
/* 291 */     throw new IllegalArgumentException("Feature " + feature.getClass().getName() + "#" + feature
/* 292 */         .toString() + " not supported for non-JSON backend");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public B enable(JsonWriteFeature f) {
/* 298 */     return _failNonJSON(f);
/*     */   }
/*     */   
/*     */   public B enable(JsonWriteFeature first, JsonWriteFeature... other) {
/* 302 */     return _failNonJSON(first);
/*     */   }
/*     */   
/*     */   public B disable(JsonWriteFeature f) {
/* 306 */     return _failNonJSON(f);
/*     */   }
/*     */   
/*     */   public B disable(JsonWriteFeature first, JsonWriteFeature... other) {
/* 310 */     return _failNonJSON(first);
/*     */   }
/*     */   
/*     */   public B configure(JsonWriteFeature f, boolean state) {
/* 314 */     return _failNonJSON(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B recyclerPool(RecyclerPool<BufferRecycler> p) {
/* 327 */     this._recyclerPool = Objects.<RecyclerPool<BufferRecycler>>requireNonNull(p);
/* 328 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public B inputDecorator(InputDecorator dec) {
/* 334 */     this._inputDecorator = dec;
/* 335 */     return _this();
/*     */   }
/*     */   
/*     */   public B outputDecorator(OutputDecorator dec) {
/* 339 */     this._outputDecorator = dec;
/* 340 */     return _this();
/*     */   }
/*     */   
/*     */   public B addDecorator(JsonGeneratorDecorator decorator) {
/* 344 */     if (this._generatorDecorators == null) {
/* 345 */       this._generatorDecorators = new ArrayList<>();
/*     */     }
/* 347 */     this._generatorDecorators.add(decorator);
/* 348 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B streamReadConstraints(StreamReadConstraints streamReadConstraints) {
/* 361 */     this._streamReadConstraints = Objects.<StreamReadConstraints>requireNonNull(streamReadConstraints);
/* 362 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B streamWriteConstraints(StreamWriteConstraints streamWriteConstraints) {
/* 373 */     this._streamWriteConstraints = Objects.<StreamWriteConstraints>requireNonNull(streamWriteConstraints);
/* 374 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public B errorReportConfiguration(ErrorReportConfiguration errorReportConfiguration) {
/* 385 */     this._errorReportConfiguration = Objects.<ErrorReportConfiguration>requireNonNull(errorReportConfiguration);
/* 386 */     return _this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract F build();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final B _this() {
/* 401 */     return (B)this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _legacyEnable(JsonParser.Feature f) {
/* 406 */     if (f != null) {
/* 407 */       this._streamReadFeatures |= f.getMask();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void _legacyDisable(JsonParser.Feature f) {
/* 412 */     if (f != null) {
/* 413 */       this._streamReadFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*     */     }
/*     */   }
/*     */   
/*     */   protected void _legacyEnable(JsonGenerator.Feature f) {
/* 418 */     if (f != null)
/* 419 */       this._streamWriteFeatures |= f.getMask(); 
/*     */   }
/*     */   
/*     */   protected void _legacyDisable(JsonGenerator.Feature f) {
/* 423 */     if (f != null)
/* 424 */       this._streamWriteFeatures &= f.getMask() ^ 0xFFFFFFFF; 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\TSFBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */