/*      */ package com.fasterxml.jackson.core;
/*      */ 
/*      */ import com.fasterxml.jackson.core.format.InputAccessor;
/*      */ import com.fasterxml.jackson.core.format.MatchStrength;
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.io.ContentReference;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.io.InputDecorator;
/*      */ import com.fasterxml.jackson.core.io.OutputDecorator;
/*      */ import com.fasterxml.jackson.core.io.SerializedString;
/*      */ import com.fasterxml.jackson.core.io.UTF8Writer;
/*      */ import com.fasterxml.jackson.core.json.ByteSourceJsonBootstrapper;
/*      */ import com.fasterxml.jackson.core.json.PackageVersion;
/*      */ import com.fasterxml.jackson.core.json.ReaderBasedJsonParser;
/*      */ import com.fasterxml.jackson.core.json.UTF8DataInputJsonParser;
/*      */ import com.fasterxml.jackson.core.json.UTF8JsonGenerator;
/*      */ import com.fasterxml.jackson.core.json.WriterBasedJsonGenerator;
/*      */ import com.fasterxml.jackson.core.json.async.NonBlockingByteBufferJsonParser;
/*      */ import com.fasterxml.jackson.core.json.async.NonBlockingJsonParser;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.BufferRecycler;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeature;
/*      */ import com.fasterxml.jackson.core.util.JsonGeneratorDecorator;
/*      */ import com.fasterxml.jackson.core.util.JsonRecyclerPools;
/*      */ import com.fasterxml.jackson.core.util.RecyclerPool;
/*      */ import java.io.CharArrayReader;
/*      */ import java.io.DataInput;
/*      */ import java.io.DataOutput;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.io.StringReader;
/*      */ import java.io.Writer;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Objects;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JsonFactory
/*      */   extends TokenStreamFactory
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 2L;
/*      */   public static final String FORMAT_NAME_JSON = "JSON";
/*      */   
/*      */   public enum Feature
/*      */     implements JacksonFeature
/*      */   {
/*   83 */     INTERN_FIELD_NAMES(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   93 */     CANONICALIZE_FIELD_NAMES(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  109 */     FAIL_ON_SYMBOL_HASH_OVERFLOW(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  132 */     USE_THREAD_LOCAL_FOR_BUFFER_RECYCLING(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  144 */     CHARSET_DETECTION(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean _defaultState;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static int collectDefaults() {
/*  160 */       int flags = 0;
/*  161 */       for (Feature f : values()) {
/*  162 */         if (f.enabledByDefault()) flags |= f.getMask(); 
/*      */       } 
/*  164 */       return flags;
/*      */     }
/*      */     Feature(boolean defaultState) {
/*  167 */       this._defaultState = defaultState;
/*      */     }
/*      */     public boolean enabledByDefault() {
/*  170 */       return this._defaultState;
/*      */     } public boolean enabledIn(int flags) {
/*  172 */       return ((flags & getMask()) != 0);
/*      */     } public int getMask() {
/*  174 */       return 1 << ordinal();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  192 */   protected static final int DEFAULT_FACTORY_FEATURE_FLAGS = Feature.collectDefaults();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  198 */   protected static final int DEFAULT_PARSER_FEATURE_FLAGS = JsonParser.Feature.collectDefaults();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  204 */   protected static final int DEFAULT_GENERATOR_FEATURE_FLAGS = JsonGenerator.Feature.collectDefaults();
/*      */   
/*  206 */   public static final SerializableString DEFAULT_ROOT_VALUE_SEPARATOR = (SerializableString)new SerializedString(" ");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char DEFAULT_QUOTE_CHAR = '"';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected transient CharsToNameCanonicalizer _rootCharSymbols;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  235 */   protected final transient ByteQuadsCanonicalizer _byteSymbolCanonicalizer = ByteQuadsCanonicalizer.createRoot();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  246 */   protected int _factoryFeatures = DEFAULT_FACTORY_FEATURE_FLAGS;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  251 */   protected int _parserFeatures = DEFAULT_PARSER_FEATURE_FLAGS;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  256 */   protected int _generatorFeatures = DEFAULT_GENERATOR_FEATURE_FLAGS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RecyclerPool<BufferRecycler> _recyclerPool;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ObjectCodec _objectCodec;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected CharacterEscapes _characterEscapes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected StreamReadConstraints _streamReadConstraints;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ErrorReportConfiguration _errorReportConfiguration;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected StreamWriteConstraints _streamWriteConstraints;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InputDecorator _inputDecorator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OutputDecorator _outputDecorator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final List<JsonGeneratorDecorator> _generatorDecorators;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  338 */   protected SerializableString _rootValueSeparator = DEFAULT_ROOT_VALUE_SEPARATOR;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _maximumNonEscapedChar;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final char _quoteChar;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory() {
/*  373 */     this((ObjectCodec)null);
/*      */   }
/*      */   public JsonFactory(ObjectCodec oc) {
/*  376 */     this._recyclerPool = JsonRecyclerPools.defaultPool();
/*  377 */     this._objectCodec = oc;
/*  378 */     this._quoteChar = '"';
/*  379 */     this._streamReadConstraints = StreamReadConstraints.defaults();
/*  380 */     this._streamWriteConstraints = StreamWriteConstraints.defaults();
/*  381 */     this._errorReportConfiguration = ErrorReportConfiguration.defaults();
/*  382 */     this._generatorDecorators = null;
/*      */     
/*  384 */     this._rootCharSymbols = CharsToNameCanonicalizer.createRoot(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonFactory(JsonFactory src, ObjectCodec codec) {
/*  397 */     this._recyclerPool = src._recyclerPool;
/*  398 */     this._objectCodec = codec;
/*      */ 
/*      */     
/*  401 */     this._factoryFeatures = src._factoryFeatures;
/*  402 */     this._parserFeatures = src._parserFeatures;
/*  403 */     this._generatorFeatures = src._generatorFeatures;
/*  404 */     this._inputDecorator = src._inputDecorator;
/*  405 */     this._outputDecorator = src._outputDecorator;
/*  406 */     this._generatorDecorators = _copy(src._generatorDecorators);
/*  407 */     this._streamReadConstraints = Objects.<StreamReadConstraints>requireNonNull(src._streamReadConstraints);
/*  408 */     this._streamWriteConstraints = Objects.<StreamWriteConstraints>requireNonNull(src._streamWriteConstraints);
/*  409 */     this._errorReportConfiguration = Objects.<ErrorReportConfiguration>requireNonNull(src._errorReportConfiguration);
/*      */ 
/*      */     
/*  412 */     this._characterEscapes = src._characterEscapes;
/*  413 */     this._rootValueSeparator = src._rootValueSeparator;
/*  414 */     this._maximumNonEscapedChar = src._maximumNonEscapedChar;
/*  415 */     this._quoteChar = src._quoteChar;
/*      */     
/*  417 */     this._rootCharSymbols = CharsToNameCanonicalizer.createRoot(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory(JsonFactoryBuilder b) {
/*  428 */     this._recyclerPool = b._recyclerPool;
/*  429 */     this._objectCodec = null;
/*      */ 
/*      */     
/*  432 */     this._factoryFeatures = b._factoryFeatures;
/*  433 */     this._parserFeatures = b._streamReadFeatures;
/*  434 */     this._generatorFeatures = b._streamWriteFeatures;
/*  435 */     this._inputDecorator = b._inputDecorator;
/*  436 */     this._outputDecorator = b._outputDecorator;
/*  437 */     this._generatorDecorators = _copy(b._generatorDecorators);
/*  438 */     this._streamReadConstraints = Objects.<StreamReadConstraints>requireNonNull(b._streamReadConstraints);
/*  439 */     this._streamWriteConstraints = Objects.<StreamWriteConstraints>requireNonNull(b._streamWriteConstraints);
/*  440 */     this._errorReportConfiguration = Objects.<ErrorReportConfiguration>requireNonNull(b._errorReportConfiguration);
/*      */ 
/*      */     
/*  443 */     this._characterEscapes = b._characterEscapes;
/*  444 */     this._rootValueSeparator = b._rootValueSeparator;
/*  445 */     this._maximumNonEscapedChar = b._maximumNonEscapedChar;
/*  446 */     this._quoteChar = b._quoteChar;
/*      */     
/*  448 */     this._rootCharSymbols = CharsToNameCanonicalizer.createRoot(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonFactory(TSFBuilder<?, ?> b, boolean bogus) {
/*  460 */     this._recyclerPool = b._recyclerPool;
/*  461 */     this._objectCodec = null;
/*      */     
/*  463 */     this._factoryFeatures = b._factoryFeatures;
/*  464 */     this._parserFeatures = b._streamReadFeatures;
/*  465 */     this._generatorFeatures = b._streamWriteFeatures;
/*  466 */     this._inputDecorator = b._inputDecorator;
/*  467 */     this._outputDecorator = b._outputDecorator;
/*  468 */     this._generatorDecorators = _copy(b._generatorDecorators);
/*  469 */     this._streamReadConstraints = Objects.<StreamReadConstraints>requireNonNull(b._streamReadConstraints);
/*  470 */     this._streamWriteConstraints = Objects.<StreamWriteConstraints>requireNonNull(b._streamWriteConstraints);
/*  471 */     this._errorReportConfiguration = Objects.<ErrorReportConfiguration>requireNonNull(b._errorReportConfiguration);
/*      */ 
/*      */     
/*  474 */     this._characterEscapes = null;
/*  475 */     this._rootValueSeparator = null;
/*  476 */     this._maximumNonEscapedChar = 0;
/*  477 */     this._quoteChar = '"';
/*      */     
/*  479 */     this._rootCharSymbols = CharsToNameCanonicalizer.createRoot(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TSFBuilder<?, ?> rebuild() {
/*  492 */     _requireJSONFactory("Factory implementation for format (%s) MUST override `rebuild()` method");
/*  493 */     return new JsonFactoryBuilder(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TSFBuilder<?, ?> builder() {
/*  508 */     return new JsonFactoryBuilder();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory copy() {
/*  529 */     _checkInvalidCopy(JsonFactory.class);
/*      */     
/*  531 */     return new JsonFactory(this, null);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _checkInvalidCopy(Class<?> exp) {
/*  536 */     if (getClass() != exp) {
/*  537 */       throw new IllegalStateException("Failed copy(): " + getClass().getName() + " (version: " + 
/*  538 */           version() + ") does not override copy(); it has to");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected static <T> List<T> _copy(List<T> src) {
/*  544 */     if (src == null) {
/*  545 */       return src;
/*      */     }
/*  547 */     return new ArrayList<>(src);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object readResolve() {
/*  566 */     return new JsonFactory(this, this._objectCodec);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean requiresPropertyOrdering() {
/*  594 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canHandleBinaryNatively() {
/*  612 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canUseCharArrays() {
/*  629 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canParseAsync() {
/*  646 */     return _isJSONFactory();
/*      */   }
/*      */ 
/*      */   
/*      */   public Class<? extends FormatFeature> getFormatReadFeatureType() {
/*  651 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Class<? extends FormatFeature> getFormatWriteFeatureType() {
/*  656 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canUseSchema(FormatSchema schema) {
/*  680 */     if (schema == null) {
/*  681 */       return false;
/*      */     }
/*  683 */     String ourFormat = getFormatName();
/*  684 */     return (ourFormat != null && ourFormat.equals(schema.getSchemaType()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getFormatName() {
/*  703 */     if (getClass() == JsonFactory.class) {
/*  704 */       return "JSON";
/*      */     }
/*  706 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public MatchStrength hasFormat(InputAccessor acc) throws IOException {
/*  712 */     if (getClass() == JsonFactory.class) {
/*  713 */       return hasJSONFormat(acc);
/*      */     }
/*  715 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean requiresCustomCodec() {
/*  732 */     return false;
/*      */   }
/*      */   
/*      */   protected MatchStrength hasJSONFormat(InputAccessor acc) throws IOException {
/*  736 */     return ByteSourceJsonBootstrapper.hasJSONFormat(acc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Version version() {
/*  747 */     return PackageVersion.VERSION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final JsonFactory configure(Feature f, boolean state) {
/*  769 */     return state ? enable(f) : disable(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonFactory enable(Feature f) {
/*  784 */     this._factoryFeatures |= f.getMask();
/*  785 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonFactory disable(Feature f) {
/*  800 */     this._factoryFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*  801 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(Feature f) {
/*  813 */     return ((this._factoryFeatures & f.getMask()) != 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getFactoryFeatures() {
/*  818 */     return this._factoryFeatures;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getParserFeatures() {
/*  823 */     return this._parserFeatures;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getGeneratorFeatures() {
/*  828 */     return this._generatorFeatures;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFormatParserFeatures() {
/*  834 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFormatGeneratorFeatures() {
/*  840 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StreamReadConstraints streamReadConstraints() {
/*  851 */     return this._streamReadConstraints;
/*      */   }
/*      */ 
/*      */   
/*      */   public StreamWriteConstraints streamWriteConstraints() {
/*  856 */     return this._streamWriteConstraints;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory setStreamReadConstraints(StreamReadConstraints src) {
/*  875 */     int maxNameLen = this._streamReadConstraints.getMaxNameLength();
/*  876 */     this._streamReadConstraints = Objects.<StreamReadConstraints>requireNonNull(src);
/*      */ 
/*      */     
/*  879 */     if (this._streamReadConstraints.getMaxNameLength() != maxNameLen) {
/*  880 */       this._rootCharSymbols = CharsToNameCanonicalizer.createRoot(this);
/*      */     }
/*  882 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory setErrorReportConfiguration(ErrorReportConfiguration src) {
/*  901 */     this._errorReportConfiguration = Objects.<ErrorReportConfiguration>requireNonNull(src, "Cannot pass null ErrorReportConfiguration");
/*  902 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory setStreamWriteConstraints(StreamWriteConstraints swc) {
/*  921 */     this._streamWriteConstraints = Objects.<StreamWriteConstraints>requireNonNull(swc);
/*  922 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonFactory configure(JsonParser.Feature f, boolean state) {
/*  941 */     return state ? enable(f) : disable(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory enable(JsonParser.Feature f) {
/*  953 */     this._parserFeatures |= f.getMask();
/*  954 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory disable(JsonParser.Feature f) {
/*  966 */     this._parserFeatures &= f.getMask() ^ 0xFFFFFFFF;
/*  967 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(JsonParser.Feature f) {
/*  979 */     return ((this._parserFeatures & f.getMask()) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(StreamReadFeature f) {
/*  993 */     return ((this._parserFeatures & f.mappedFeature().getMask()) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputDecorator getInputDecorator() {
/* 1003 */     return this._inputDecorator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonFactory setInputDecorator(InputDecorator d) {
/* 1017 */     this._inputDecorator = d;
/* 1018 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonFactory configure(JsonGenerator.Feature f, boolean state) {
/* 1037 */     return state ? enable(f) : disable(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory enable(JsonGenerator.Feature f) {
/* 1049 */     this._generatorFeatures |= f.getMask();
/* 1050 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory disable(JsonGenerator.Feature f) {
/* 1062 */     this._generatorFeatures &= f.getMask() ^ 0xFFFFFFFF;
/* 1063 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(JsonGenerator.Feature f) {
/* 1075 */     return ((this._generatorFeatures & f.getMask()) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEnabled(StreamWriteFeature f) {
/* 1089 */     return ((this._generatorFeatures & f.mappedFeature().getMask()) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CharacterEscapes getCharacterEscapes() {
/* 1098 */     return this._characterEscapes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory setCharacterEscapes(CharacterEscapes esc) {
/* 1109 */     this._characterEscapes = esc;
/* 1110 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputDecorator getOutputDecorator() {
/* 1121 */     return this._outputDecorator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonFactory setOutputDecorator(OutputDecorator d) {
/* 1135 */     this._outputDecorator = d;
/* 1136 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory setRootValueSeparator(String sep) {
/* 1149 */     this._rootValueSeparator = (sep == null) ? null : (SerializableString)new SerializedString(sep);
/* 1150 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRootValueSeparator() {
/* 1157 */     return (this._rootValueSeparator == null) ? null : this._rootValueSeparator.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory setRecyclerPool(RecyclerPool<BufferRecycler> p) {
/* 1167 */     this._recyclerPool = Objects.<RecyclerPool<BufferRecycler>>requireNonNull(p);
/* 1168 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonFactory setCodec(ObjectCodec oc) {
/* 1183 */     this._objectCodec = oc;
/* 1184 */     return this;
/*      */   }
/*      */   public ObjectCodec getCodec() {
/* 1187 */     return this._objectCodec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(File f) throws IOException, JsonParseException {
/* 1218 */     IOContext ctxt = _createContext(_createContentReference(f), true);
/* 1219 */     InputStream in = _fileInputStream(f);
/* 1220 */     return _createParser(_decorate(in, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(URL url) throws IOException, JsonParseException {
/* 1244 */     IOContext ctxt = _createContext(_createContentReference(url), true);
/* 1245 */     InputStream in = _optimizedStreamFromURL(url);
/* 1246 */     return _createParser(_decorate(in, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(InputStream in) throws IOException, JsonParseException {
/* 1272 */     IOContext ctxt = _createContext(_createContentReference(in), false);
/* 1273 */     return _createParser(_decorate(in, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(Reader r) throws IOException, JsonParseException {
/* 1293 */     IOContext ctxt = _createContext(_createContentReference(r), false);
/* 1294 */     return _createParser(_decorate(r, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(byte[] data) throws IOException, JsonParseException {
/* 1305 */     IOContext ctxt = _createContext(_createContentReference(data), true);
/* 1306 */     if (this._inputDecorator != null) {
/* 1307 */       InputStream in = this._inputDecorator.decorate(ctxt, data, 0, data.length);
/* 1308 */       if (in != null) {
/* 1309 */         return _createParser(in, ctxt);
/*      */       }
/*      */     } 
/* 1312 */     return _createParser(data, 0, data.length, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(byte[] data, int offset, int len) throws IOException, JsonParseException {
/* 1327 */     _checkRangeBoundsForByteArray(data, offset, len);
/* 1328 */     IOContext ctxt = _createContext(_createContentReference(data, offset, len), true);
/*      */     
/* 1330 */     if (this._inputDecorator != null) {
/* 1331 */       InputStream in = this._inputDecorator.decorate(ctxt, data, offset, len);
/* 1332 */       if (in != null) {
/* 1333 */         return _createParser(in, ctxt);
/*      */       }
/*      */     } 
/* 1336 */     return _createParser(data, offset, len, ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(String content) throws IOException, JsonParseException {
/* 1347 */     int strLen = content.length();
/*      */     
/* 1349 */     if (this._inputDecorator != null || strLen > 32768 || !canUseCharArrays())
/*      */     {
/*      */       
/* 1352 */       return createParser(new StringReader(content));
/*      */     }
/* 1354 */     IOContext ctxt = _createContext(_createContentReference(content), true);
/* 1355 */     char[] buf = ctxt.allocTokenBuffer(strLen);
/* 1356 */     content.getChars(0, strLen, buf, 0);
/* 1357 */     return _createParser(buf, 0, strLen, ctxt, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(char[] content) throws IOException {
/* 1368 */     return createParser(content, 0, content.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(char[] content, int offset, int len) throws IOException {
/* 1378 */     _checkRangeBoundsForCharArray(content, offset, len);
/* 1379 */     if (this._inputDecorator != null) {
/* 1380 */       return createParser(new CharArrayReader(content, offset, len));
/*      */     }
/* 1382 */     return _createParser(content, offset, len, 
/* 1383 */         _createContext(_createContentReference(content, offset, len), true), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createParser(DataInput in) throws IOException {
/* 1399 */     IOContext ctxt = _createContext(_createContentReference(in), false);
/* 1400 */     return _createParser(_decorate(in, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createNonBlockingByteArrayParser() throws IOException {
/* 1430 */     _requireJSONFactory("Non-blocking source not (yet?) supported for this format (%s)");
/* 1431 */     IOContext ctxt = _createNonBlockingContext((Object)null);
/* 1432 */     ByteQuadsCanonicalizer can = this._byteSymbolCanonicalizer.makeChildOrPlaceholder(this._factoryFeatures);
/* 1433 */     return (JsonParser)new NonBlockingJsonParser(ctxt, this._parserFeatures, can);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser createNonBlockingByteBufferParser() throws IOException {
/* 1457 */     _requireJSONFactory("Non-blocking source not (yet?) supported for this format (%s)");
/* 1458 */     IOContext ctxt = _createNonBlockingContext((Object)null);
/* 1459 */     ByteQuadsCanonicalizer can = this._byteSymbolCanonicalizer.makeChildOrPlaceholder(this._factoryFeatures);
/* 1460 */     return (JsonParser)new NonBlockingByteBufferJsonParser(ctxt, this._parserFeatures, can);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(OutputStream out, JsonEncoding enc) throws IOException {
/* 1496 */     IOContext ctxt = _createContext(_createContentReference(out), false);
/* 1497 */     ctxt.setEncoding(enc);
/* 1498 */     if (enc == JsonEncoding.UTF8) {
/* 1499 */       return _createUTF8Generator(_decorate(out, ctxt), ctxt);
/*      */     }
/* 1501 */     Writer w = _createWriter(out, enc, ctxt);
/* 1502 */     return _createGenerator(_decorate(w, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(OutputStream out) throws IOException {
/* 1515 */     return createGenerator(out, JsonEncoding.UTF8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(Writer w) throws IOException {
/* 1535 */     IOContext ctxt = _createContext(_createContentReference(w), false);
/* 1536 */     return _createGenerator(_decorate(w, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(File f, JsonEncoding enc) throws IOException {
/* 1558 */     OutputStream out = _fileOutputStream(f);
/*      */     
/* 1560 */     IOContext ctxt = _createContext(_createContentReference(out), true);
/* 1561 */     ctxt.setEncoding(enc);
/* 1562 */     if (enc == JsonEncoding.UTF8) {
/* 1563 */       return _createUTF8Generator(_decorate(out, ctxt), ctxt);
/*      */     }
/* 1565 */     Writer w = _createWriter(out, enc, ctxt);
/* 1566 */     return _createGenerator(_decorate(w, ctxt), ctxt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(DataOutput out, JsonEncoding enc) throws IOException {
/* 1577 */     return createGenerator(_createDataOutputWrapper(out), enc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator createGenerator(DataOutput out) throws IOException {
/* 1590 */     return createGenerator(_createDataOutputWrapper(out), JsonEncoding.UTF8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(File f) throws IOException, JsonParseException {
/* 1625 */     return createParser(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(URL url) throws IOException, JsonParseException {
/* 1653 */     return createParser(url);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(InputStream in) throws IOException, JsonParseException {
/* 1684 */     return createParser(in);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(Reader r) throws IOException, JsonParseException {
/* 1708 */     return createParser(r);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(byte[] data) throws IOException, JsonParseException {
/* 1725 */     return createParser(data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(byte[] data, int offset, int len) throws IOException, JsonParseException {
/* 1745 */     return createParser(data, offset, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser createJsonParser(String content) throws IOException, JsonParseException {
/* 1763 */     return createParser(content);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonGenerator createJsonGenerator(OutputStream out, JsonEncoding enc) throws IOException {
/* 1800 */     return createGenerator(out, enc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonGenerator createJsonGenerator(Writer out) throws IOException {
/* 1824 */     return createGenerator(out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonGenerator createJsonGenerator(OutputStream out) throws IOException {
/* 1843 */     return createGenerator(out, JsonEncoding.UTF8);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _createParser(InputStream in, IOContext ctxt) throws IOException {
/*      */     try {
/* 1874 */       return (new ByteSourceJsonBootstrapper(ctxt, in)).constructParser(this._parserFeatures, this._objectCodec, this._byteSymbolCanonicalizer, this._rootCharSymbols, this._factoryFeatures);
/*      */     }
/* 1876 */     catch (IOException|RuntimeException e) {
/*      */       
/* 1878 */       if (ctxt.isResourceManaged()) {
/*      */         try {
/* 1880 */           in.close();
/* 1881 */         } catch (Exception e2) {
/* 1882 */           e.addSuppressed(e2);
/*      */         } 
/*      */       }
/* 1885 */       ctxt.close();
/* 1886 */       throw e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _createParser(Reader r, IOContext ctxt) throws IOException {
/* 1910 */     return (JsonParser)new ReaderBasedJsonParser(ctxt, this._parserFeatures, r, this._objectCodec, this._rootCharSymbols
/* 1911 */         .makeChild());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _createParser(char[] data, int offset, int len, IOContext ctxt, boolean recyclable) throws IOException {
/* 1932 */     return (JsonParser)new ReaderBasedJsonParser(ctxt, this._parserFeatures, null, this._objectCodec, this._rootCharSymbols
/* 1933 */         .makeChild(), data, offset, offset + len, recyclable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _createParser(byte[] data, int offset, int len, IOContext ctxt) throws IOException {
/* 1959 */     return (new ByteSourceJsonBootstrapper(ctxt, data, offset, len)).constructParser(this._parserFeatures, this._objectCodec, this._byteSymbolCanonicalizer, this._rootCharSymbols, this._factoryFeatures);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonParser _createParser(DataInput input, IOContext ctxt) throws IOException {
/* 1979 */     _requireJSONFactory("InputData source not (yet?) supported for this format (%s)");
/*      */ 
/*      */     
/* 1982 */     int firstByte = ByteSourceJsonBootstrapper.skipUTF8BOM(input);
/* 1983 */     ByteQuadsCanonicalizer can = this._byteSymbolCanonicalizer.makeChildOrPlaceholder(this._factoryFeatures);
/* 1984 */     return (JsonParser)new UTF8DataInputJsonParser(ctxt, this._parserFeatures, input, this._objectCodec, can, firstByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonGenerator _createGenerator(Writer out, IOContext ctxt) throws IOException {
/* 2014 */     WriterBasedJsonGenerator gen = new WriterBasedJsonGenerator(ctxt, this._generatorFeatures, this._objectCodec, out, this._quoteChar);
/*      */     
/* 2016 */     if (this._maximumNonEscapedChar > 0) {
/* 2017 */       gen.setHighestNonEscapedChar(this._maximumNonEscapedChar);
/*      */     }
/* 2019 */     if (this._characterEscapes != null) {
/* 2020 */       gen.setCharacterEscapes(this._characterEscapes);
/*      */     }
/* 2022 */     SerializableString rootSep = this._rootValueSeparator;
/* 2023 */     if (rootSep != DEFAULT_ROOT_VALUE_SEPARATOR) {
/* 2024 */       gen.setRootValueSeparator(rootSep);
/*      */     }
/* 2026 */     return _decorate((JsonGenerator)gen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonGenerator _createUTF8Generator(OutputStream out, IOContext ctxt) throws IOException {
/* 2047 */     UTF8JsonGenerator gen = new UTF8JsonGenerator(ctxt, this._generatorFeatures, this._objectCodec, out, this._quoteChar);
/*      */     
/* 2049 */     if (this._maximumNonEscapedChar > 0) {
/* 2050 */       gen.setHighestNonEscapedChar(this._maximumNonEscapedChar);
/*      */     }
/* 2052 */     if (this._characterEscapes != null) {
/* 2053 */       gen.setCharacterEscapes(this._characterEscapes);
/*      */     }
/* 2055 */     SerializableString rootSep = this._rootValueSeparator;
/* 2056 */     if (rootSep != DEFAULT_ROOT_VALUE_SEPARATOR) {
/* 2057 */       gen.setRootValueSeparator(rootSep);
/*      */     }
/* 2059 */     return _decorate((JsonGenerator)gen);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Writer _createWriter(OutputStream out, JsonEncoding enc, IOContext ctxt) throws IOException {
/* 2065 */     if (enc == JsonEncoding.UTF8) {
/* 2066 */       return (Writer)new UTF8Writer(ctxt, out);
/*      */     }
/*      */     
/* 2069 */     return new OutputStreamWriter(out, enc.getJavaName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final InputStream _decorate(InputStream in, IOContext ctxt) throws IOException {
/* 2079 */     if (this._inputDecorator != null) {
/* 2080 */       InputStream in2 = this._inputDecorator.decorate(ctxt, in);
/* 2081 */       if (in2 != null) {
/* 2082 */         return in2;
/*      */       }
/*      */     } 
/* 2085 */     return in;
/*      */   }
/*      */   
/*      */   protected final Reader _decorate(Reader in, IOContext ctxt) throws IOException {
/* 2089 */     if (this._inputDecorator != null) {
/* 2090 */       Reader in2 = this._inputDecorator.decorate(ctxt, in);
/* 2091 */       if (in2 != null) {
/* 2092 */         return in2;
/*      */       }
/*      */     } 
/* 2095 */     return in;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final DataInput _decorate(DataInput in, IOContext ctxt) throws IOException {
/* 2100 */     if (this._inputDecorator != null) {
/* 2101 */       DataInput in2 = this._inputDecorator.decorate(ctxt, in);
/* 2102 */       if (in2 != null) {
/* 2103 */         return in2;
/*      */       }
/*      */     } 
/* 2106 */     return in;
/*      */   }
/*      */   
/*      */   protected final OutputStream _decorate(OutputStream out, IOContext ctxt) throws IOException {
/* 2110 */     if (this._outputDecorator != null) {
/* 2111 */       OutputStream out2 = this._outputDecorator.decorate(ctxt, out);
/* 2112 */       if (out2 != null) {
/* 2113 */         return out2;
/*      */       }
/*      */     } 
/* 2116 */     return out;
/*      */   }
/*      */   
/*      */   protected final Writer _decorate(Writer out, IOContext ctxt) throws IOException {
/* 2120 */     if (this._outputDecorator != null) {
/* 2121 */       Writer out2 = this._outputDecorator.decorate(ctxt, out);
/* 2122 */       if (out2 != null) {
/* 2123 */         return out2;
/*      */       }
/*      */     } 
/* 2126 */     return out;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonGenerator _decorate(JsonGenerator g) {
/* 2140 */     if (this._generatorDecorators != null) {
/* 2141 */       for (JsonGeneratorDecorator decorator : this._generatorDecorators) {
/* 2142 */         g = decorator.decorate(this, g);
/*      */       }
/*      */     }
/* 2145 */     return g;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BufferRecycler _getBufferRecycler() {
/* 2164 */     return (BufferRecycler)_getRecyclerPool().acquireAndLinkPooled();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RecyclerPool<BufferRecycler> _getRecyclerPool() {
/* 2179 */     if (!Feature.USE_THREAD_LOCAL_FOR_BUFFER_RECYCLING.enabledIn(this._factoryFeatures)) {
/* 2180 */       return JsonRecyclerPools.nonRecyclingPool();
/*      */     }
/* 2182 */     return this._recyclerPool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IOContext _createContext(ContentReference contentRef, boolean resourceManaged) {
/* 2195 */     BufferRecycler br = null;
/* 2196 */     boolean recyclerExternal = false;
/*      */     
/* 2198 */     if (contentRef == null) {
/* 2199 */       contentRef = ContentReference.unknown();
/*      */     } else {
/* 2201 */       Object content = contentRef.getRawContent();
/*      */ 
/*      */       
/* 2204 */       if (content instanceof BufferRecycler.Gettable) {
/* 2205 */         br = ((BufferRecycler.Gettable)content).bufferRecycler();
/* 2206 */         recyclerExternal = (br != null);
/*      */       } 
/*      */     } 
/* 2209 */     if (br == null) {
/* 2210 */       br = _getBufferRecycler();
/*      */     }
/* 2212 */     IOContext ctxt = new IOContext(this._streamReadConstraints, this._streamWriteConstraints, this._errorReportConfiguration, br, contentRef, resourceManaged);
/*      */     
/* 2214 */     if (recyclerExternal) {
/* 2215 */       ctxt.markBufferRecyclerReleased();
/*      */     }
/* 2217 */     return ctxt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected IOContext _createContext(Object rawContentRef, boolean resourceManaged) {
/* 2232 */     return new IOContext(this._streamReadConstraints, this._streamWriteConstraints, this._errorReportConfiguration, 
/* 2233 */         _getBufferRecycler(), 
/* 2234 */         _createContentReference(rawContentRef), resourceManaged);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IOContext _createNonBlockingContext(Object srcRef) {
/* 2251 */     return new IOContext(this._streamReadConstraints, this._streamWriteConstraints, this._errorReportConfiguration, 
/* 2252 */         _getBufferRecycler(), 
/* 2253 */         _createContentReference(srcRef), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ContentReference _createContentReference(Object contentAccessor) {
/* 2272 */     return ContentReference.construct(!canHandleBinaryNatively(), contentAccessor, this._errorReportConfiguration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ContentReference _createContentReference(Object contentAccessor, int offset, int length) {
/* 2295 */     return ContentReference.construct(!canHandleBinaryNatively(), contentAccessor, offset, length, this._errorReportConfiguration);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _requireJSONFactory(String msg) {
/* 2320 */     if (!_isJSONFactory()) {
/* 2321 */       throw new UnsupportedOperationException(String.format(msg, new Object[] { getFormatName() }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean _isJSONFactory() {
/* 2328 */     return (getFormatName() == "JSON");
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\JsonFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */