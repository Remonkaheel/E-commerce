/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.NumberInput;
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonPointer
/*     */   implements Serializable
/*     */ {
/*     */   public static final char ESC = '~';
/*     */   public static final String ESC_SLASH = "~1";
/*     */   public static final String ESC_TILDE = "~0";
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final char SEPARATOR = '/';
/*  79 */   protected static final JsonPointer EMPTY = new JsonPointer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonPointer _nextSegment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected volatile JsonPointer _head;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _asString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _asStringOffset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _matchingPropertyName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _matchingElementIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _hashCode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonPointer() {
/* 142 */     this._nextSegment = null;
/*     */     
/* 144 */     this._matchingPropertyName = null;
/* 145 */     this._matchingElementIndex = -1;
/* 146 */     this._asString = "";
/* 147 */     this._asStringOffset = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonPointer(String fullString, int fullStringOffset, String segment, JsonPointer next) {
/* 154 */     this._asString = fullString;
/* 155 */     this._asStringOffset = fullStringOffset;
/* 156 */     this._nextSegment = next;
/*     */     
/* 158 */     this._matchingPropertyName = segment;
/*     */     
/* 160 */     this._matchingElementIndex = _parseIndex(segment);
/*     */   }
/*     */ 
/*     */   
/*     */   protected JsonPointer(String fullString, int fullStringOffset, String segment, int matchIndex, JsonPointer next) {
/* 165 */     this._asString = fullString;
/* 166 */     this._asStringOffset = fullStringOffset;
/* 167 */     this._nextSegment = next;
/* 168 */     this._matchingPropertyName = segment;
/* 169 */     this._matchingElementIndex = matchIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonPointer(JsonPointer src, JsonPointer next) {
/* 182 */     this._asString = src._asString;
/* 183 */     this._asStringOffset = src._asStringOffset;
/* 184 */     this._nextSegment = next;
/* 185 */     this._matchingPropertyName = src._matchingPropertyName;
/* 186 */     this._matchingElementIndex = src._matchingElementIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonPointer(JsonPointer src, String newFullString, int newFullStringOffset) {
/* 200 */     this._asString = newFullString;
/* 201 */     this._asStringOffset = newFullStringOffset;
/* 202 */     this._nextSegment = null;
/* 203 */     this._matchingPropertyName = src._matchingPropertyName;
/* 204 */     this._matchingElementIndex = src._matchingElementIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonPointer compile(String expr) throws IllegalArgumentException {
/* 229 */     if (expr == null || expr.length() == 0) {
/* 230 */       return EMPTY;
/*     */     }
/*     */     
/* 233 */     if (expr.charAt(0) != '/') {
/* 234 */       throw new IllegalArgumentException("Invalid input: JSON Pointer expression must start with '/': \"" + expr + "\"");
/*     */     }
/* 236 */     return _parseTail(expr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonPointer valueOf(String expr) {
/* 247 */     return compile(expr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonPointer empty() {
/* 260 */     return EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonPointer forPath(JsonStreamContext context, boolean includeRoot) {
/* 279 */     if (context == null) {
/* 280 */       return EMPTY;
/*     */     }
/*     */ 
/*     */     
/* 284 */     if (!context.hasPathSegment())
/*     */     {
/* 286 */       if (!includeRoot || !context.inRoot() || !context.hasCurrentIndex()) {
/* 287 */         context = context.getParent();
/*     */       }
/*     */     }
/*     */     
/* 291 */     PointerSegment next = null;
/* 292 */     int approxLength = 0;
/*     */     
/* 294 */     for (; context != null; context = context.getParent()) {
/* 295 */       if (context.inObject()) {
/* 296 */         String propName = context.getCurrentName();
/* 297 */         if (propName == null) {
/* 298 */           propName = "";
/*     */         }
/* 300 */         approxLength += 2 + propName.length();
/* 301 */         next = new PointerSegment(next, propName, -1);
/* 302 */       } else if (context.inArray() || includeRoot) {
/* 303 */         int ix = context.getCurrentIndex();
/* 304 */         approxLength += 6;
/* 305 */         next = new PointerSegment(next, null, ix);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 311 */     if (next == null) {
/* 312 */       return EMPTY;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 317 */     StringBuilder pathBuilder = new StringBuilder(approxLength);
/* 318 */     PointerSegment last = null;
/*     */     
/* 320 */     for (; next != null; next = next.next) {
/*     */       
/* 322 */       last = next;
/* 323 */       next.pathOffset = pathBuilder.length();
/* 324 */       pathBuilder.append('/');
/* 325 */       if (next.property != null) {
/* 326 */         _appendEscaped(pathBuilder, next.property);
/*     */       } else {
/* 328 */         pathBuilder.append(next.index);
/*     */       } 
/*     */     } 
/* 331 */     String fullPath = pathBuilder.toString();
/*     */ 
/*     */ 
/*     */     
/* 335 */     PointerSegment currSegment = last;
/* 336 */     JsonPointer currPtr = EMPTY;
/*     */     
/* 338 */     for (; currSegment != null; currSegment = currSegment.prev) {
/* 339 */       if (currSegment.property != null) {
/* 340 */         currPtr = new JsonPointer(fullPath, currSegment.pathOffset, currSegment.property, currPtr);
/*     */       } else {
/*     */         
/* 343 */         int index = currSegment.index;
/*     */         
/* 345 */         currPtr = new JsonPointer(fullPath, currSegment.pathOffset, String.valueOf(index), index, currPtr);
/*     */       } 
/*     */     } 
/*     */     
/* 349 */     return currPtr;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void _appendEscaped(StringBuilder sb, String segment) {
/* 354 */     for (int i = 0, end = segment.length(); i < end; i++) {
/* 355 */       char c = segment.charAt(i);
/* 356 */       if (c == '/') {
/* 357 */         sb.append("~1");
/*     */       
/*     */       }
/* 360 */       else if (c == '~') {
/* 361 */         sb.append("~0");
/*     */       } else {
/*     */         
/* 364 */         sb.append(c);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int length() {
/* 386 */     return this._asString.length() - this._asStringOffset;
/*     */   }
/*     */   
/* 389 */   public boolean matches() { return (this._nextSegment == null); }
/* 390 */   public String getMatchingProperty() { return this._matchingPropertyName; } public int getMatchingIndex() {
/* 391 */     return this._matchingElementIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mayMatchProperty() {
/* 397 */     return (this._matchingPropertyName != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean mayMatchElement() {
/* 403 */     return (this._matchingElementIndex >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer last() {
/* 412 */     JsonPointer current = this;
/* 413 */     if (current == EMPTY) {
/* 414 */       return null;
/*     */     }
/*     */     JsonPointer next;
/* 417 */     while ((next = current._nextSegment) != EMPTY) {
/* 418 */       current = next;
/*     */     }
/* 420 */     return current;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer append(JsonPointer tail) {
/* 440 */     if (this == EMPTY) {
/* 441 */       return tail;
/*     */     }
/* 443 */     if (tail == EMPTY) {
/* 444 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 449 */     String currentJsonPointer = toString();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 458 */     return compile(currentJsonPointer + tail.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer appendProperty(String property) {
/* 487 */     if (property == null) {
/* 488 */       return this;
/*     */     }
/*     */ 
/*     */     
/* 492 */     StringBuilder sb = toStringBuilder(property.length() + 2).append('/');
/* 493 */     _appendEscaped(sb, property);
/* 494 */     return compile(sb.toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer appendIndex(int index) {
/* 512 */     if (index < 0) {
/* 513 */       throw new IllegalArgumentException("Negative index cannot be appended");
/*     */     }
/*     */ 
/*     */     
/* 517 */     return compile(toStringBuilder(8).append('/').append(index).toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matchesProperty(String name) {
/* 531 */     return (this._nextSegment != null && this._matchingPropertyName.equals(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer matchProperty(String name) {
/* 546 */     if (this._nextSegment != null && this._matchingPropertyName.equals(name)) {
/* 547 */       return this._nextSegment;
/*     */     }
/* 549 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matchesElement(int index) {
/* 563 */     return (index == this._matchingElementIndex && index >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer matchElement(int index) {
/* 580 */     if (index != this._matchingElementIndex || index < 0) {
/* 581 */       return null;
/*     */     }
/* 583 */     return this._nextSegment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer tail() {
/* 600 */     return this._nextSegment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer head() {
/* 620 */     JsonPointer h = this._head;
/* 621 */     if (h == null) {
/* 622 */       if (this != EMPTY) {
/* 623 */         h = _constructHead();
/*     */       }
/* 625 */       this._head = h;
/*     */     } 
/* 627 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 638 */     if (this._asStringOffset <= 0) {
/* 639 */       return this._asString;
/*     */     }
/* 641 */     return this._asString.substring(this._asStringOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StringBuilder toStringBuilder(int slack) {
/* 658 */     if (this._asStringOffset <= 0) {
/* 659 */       return new StringBuilder(this._asString);
/*     */     }
/* 661 */     int len = this._asString.length();
/* 662 */     StringBuilder sb = new StringBuilder(len - this._asStringOffset + slack);
/* 663 */     sb.append(this._asString, this._asStringOffset, len);
/* 664 */     return sb;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 669 */     int h = this._hashCode;
/* 670 */     if (h == 0) {
/*     */ 
/*     */ 
/*     */       
/* 674 */       h = toString().hashCode();
/* 675 */       if (h == 0) {
/* 676 */         h = -1;
/*     */       }
/* 678 */       this._hashCode = h;
/*     */     } 
/* 680 */     return h;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 685 */     if (o == this) return true; 
/* 686 */     if (o == null) return false; 
/* 687 */     if (!(o instanceof JsonPointer)) return false; 
/* 688 */     JsonPointer other = (JsonPointer)o;
/*     */ 
/*     */ 
/*     */     
/* 692 */     return _compare(this._asString, this._asStringOffset, other._asString, other._asStringOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean _compare(String str1, int offset1, String str2, int offset2) {
/* 698 */     int end1 = str1.length();
/*     */ 
/*     */     
/* 701 */     if (end1 - offset1 != str2.length() - offset2) {
/* 702 */       return false;
/*     */     }
/*     */     
/* 705 */     while (offset1 < end1) {
/* 706 */       if (str1.charAt(offset1++) != str2.charAt(offset2++)) {
/* 707 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 711 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int _parseIndex(String str) {
/* 721 */     int len = str.length();
/*     */ 
/*     */     
/* 724 */     if (len == 0 || len > 10) {
/* 725 */       return -1;
/*     */     }
/*     */     
/* 728 */     char c = str.charAt(0);
/* 729 */     if (c <= '0') {
/* 730 */       return (len == 1 && c == '0') ? 0 : -1;
/*     */     }
/* 732 */     if (c > '9') {
/* 733 */       return -1;
/*     */     }
/* 735 */     for (int i = 1; i < len; i++) {
/* 736 */       c = str.charAt(i);
/* 737 */       if (c > '9' || c < '0') {
/* 738 */         return -1;
/*     */       }
/*     */     } 
/* 741 */     if (len == 10) {
/* 742 */       long l = Long.parseLong(str);
/* 743 */       if (l > 2147483647L) {
/* 744 */         return -1;
/*     */       }
/* 746 */       return (int)l;
/*     */     } 
/* 748 */     return NumberInput.parseInt(str);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static JsonPointer _parseTail(String fullPath) {
/* 753 */     PointerParent parent = null;
/*     */ 
/*     */     
/* 756 */     int i = 1;
/* 757 */     int end = fullPath.length();
/* 758 */     int startOffset = 0;
/*     */     
/* 760 */     while (i < end) {
/* 761 */       char c = fullPath.charAt(i);
/* 762 */       if (c == '/') {
/*     */         
/* 764 */         parent = new PointerParent(parent, startOffset, fullPath.substring(startOffset + 1, i));
/* 765 */         startOffset = i;
/* 766 */         i++;
/*     */         continue;
/*     */       } 
/* 769 */       i++;
/*     */       
/* 771 */       if (c == '~' && i < end) {
/*     */ 
/*     */         
/* 774 */         StringBuilder sb = new StringBuilder(32);
/* 775 */         i = _extractEscapedSegment(fullPath, startOffset + 1, i, sb);
/* 776 */         String segment = sb.toString();
/* 777 */         if (i < 0) {
/* 778 */           return _buildPath(fullPath, startOffset, segment, parent);
/*     */         }
/* 780 */         parent = new PointerParent(parent, startOffset, segment);
/* 781 */         startOffset = i;
/* 782 */         i++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 788 */     return _buildPath(fullPath, startOffset, fullPath.substring(startOffset + 1), parent);
/*     */   }
/*     */ 
/*     */   
/*     */   private static JsonPointer _buildPath(String fullPath, int fullPathOffset, String segment, PointerParent parent) {
/* 793 */     JsonPointer curr = new JsonPointer(fullPath, fullPathOffset, segment, EMPTY);
/* 794 */     for (; parent != null; parent = parent.parent) {
/* 795 */       curr = new JsonPointer(fullPath, parent.fullPathOffset, parent.segment, curr);
/*     */     }
/* 797 */     return curr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int _extractEscapedSegment(String input, int firstCharOffset, int i, StringBuilder sb) {
/* 818 */     int end = input.length();
/* 819 */     int toCopy = i - 1 - firstCharOffset;
/* 820 */     if (toCopy > 0) {
/* 821 */       sb.append(input, firstCharOffset, i - 1);
/*     */     }
/* 823 */     i += _appendEscape(sb, input.charAt(i));
/* 824 */     while (i < end) {
/* 825 */       char c = input.charAt(i);
/* 826 */       if (c == '/') {
/* 827 */         return i;
/*     */       }
/* 829 */       i++;
/* 830 */       if (c == '~' && i < end) {
/* 831 */         i += _appendEscape(sb, input.charAt(i));
/*     */         continue;
/*     */       } 
/* 834 */       sb.append(c);
/*     */     } 
/*     */     
/* 837 */     return -1;
/*     */   }
/*     */   
/*     */   private static int _appendEscape(StringBuilder sb, char c) {
/* 841 */     if (c == '0') {
/* 842 */       sb.append('~');
/* 843 */       return 1;
/*     */     } 
/* 845 */     if (c == '1') {
/* 846 */       sb.append('/');
/* 847 */       return 1;
/*     */     } 
/*     */     
/* 850 */     sb.append('~');
/* 851 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonPointer _constructHead() {
/* 857 */     JsonPointer last = last();
/* 858 */     if (last == this) {
/* 859 */       return EMPTY;
/*     */     }
/*     */ 
/*     */     
/* 863 */     ArrayList<JsonPointer> pointers = new ArrayList<>();
/*     */     
/* 865 */     JsonPointer current = this;
/* 866 */     String origFullString = toString();
/*     */     
/* 868 */     String fullString = origFullString.substring(0, origFullString.length() - last.length());
/*     */ 
/*     */     
/* 871 */     int offsetDiff = -this._asStringOffset;
/*     */     
/* 873 */     while (current != last) {
/*     */       
/* 875 */       JsonPointer nextSegment = new JsonPointer(current, fullString, current._asStringOffset + offsetDiff);
/*     */       
/* 877 */       pointers.add(nextSegment);
/* 878 */       current = current._nextSegment;
/*     */     } 
/*     */ 
/*     */     
/* 882 */     JsonPointer head = EMPTY;
/* 883 */     for (int i = pointers.size() - 1; i >= 0; i--) {
/* 884 */       head = new JsonPointer(pointers.get(i), head);
/*     */     }
/*     */     
/* 887 */     return head;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PointerParent
/*     */   {
/*     */     public final PointerParent parent;
/*     */ 
/*     */     
/*     */     public final int fullPathOffset;
/*     */ 
/*     */     
/*     */     public final String segment;
/*     */ 
/*     */ 
/*     */     
/*     */     PointerParent(PointerParent pp, int fpo, String sgm) {
/* 906 */       this.parent = pp;
/* 907 */       this.fullPathOffset = fpo;
/* 908 */       this.segment = sgm;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class PointerSegment
/*     */   {
/*     */     public final PointerSegment next;
/*     */     
/*     */     public final String property;
/*     */     
/*     */     public final int index;
/*     */     
/*     */     public int pathOffset;
/*     */     
/*     */     public PointerSegment prev;
/*     */ 
/*     */     
/*     */     public PointerSegment(PointerSegment next, String pn, int ix) {
/* 928 */       this.next = next;
/* 929 */       this.property = pn;
/* 930 */       this.index = ix;
/*     */       
/* 932 */       if (next != null) {
/* 933 */         next.prev = this;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object writeReplace() {
/* 947 */     return new Serialization(toString());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class Serialization
/*     */     implements Externalizable
/*     */   {
/*     */     private String _fullPath;
/*     */ 
/*     */ 
/*     */     
/*     */     public Serialization() {}
/*     */ 
/*     */ 
/*     */     
/*     */     Serialization(String fullPath) {
/* 965 */       this._fullPath = fullPath;
/*     */     }
/*     */ 
/*     */     
/*     */     public void writeExternal(ObjectOutput out) throws IOException {
/* 970 */       out.writeUTF(this._fullPath);
/*     */     }
/*     */ 
/*     */     
/*     */     public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/* 975 */       this._fullPath = in.readUTF();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Object readResolve() throws ObjectStreamException {
/* 981 */       return JsonPointer.compile(this._fullPath);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\JsonPointer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */