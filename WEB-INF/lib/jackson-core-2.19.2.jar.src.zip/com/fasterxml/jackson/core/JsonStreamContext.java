/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.CharTypes;
/*     */ import com.fasterxml.jackson.core.io.ContentReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JsonStreamContext
/*     */ {
/*     */   public static final int TYPE_ROOT = 0;
/*     */   public static final int TYPE_ARRAY = 1;
/*     */   public static final int TYPE_OBJECT = 2;
/*     */   protected int _type;
/*     */   protected int _index;
/*     */   protected int _nestingDepth;
/*     */   
/*     */   protected JsonStreamContext() {}
/*     */   
/*     */   protected JsonStreamContext(JsonStreamContext base) {
/*  82 */     this._type = base._type;
/*  83 */     this._index = base._index;
/*     */   }
/*     */ 
/*     */   
/*     */   protected JsonStreamContext(int type, int index) {
/*  88 */     this._type = type;
/*  89 */     this._index = index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonStreamContext getParent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean inArray() {
/* 112 */     return (this._type == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean inRoot() {
/* 121 */     return (this._type == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean inObject() {
/* 129 */     return (this._type == 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getNestingDepth() {
/* 140 */     return this._nestingDepth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final String getTypeDesc() {
/* 150 */     switch (this._type) { case 0:
/* 151 */         return "ROOT";
/* 152 */       case 1: return "ARRAY";
/* 153 */       case 2: return "OBJECT"; }
/*     */     
/* 155 */     return "?";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String typeDesc() {
/* 168 */     switch (this._type) { case 0:
/* 169 */         return "root";
/* 170 */       case 1: return "Array";
/* 171 */       case 2: return "Object"; }
/*     */     
/* 173 */     return "?";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getEntryCount() {
/* 179 */     return this._index + 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getCurrentIndex() {
/* 184 */     return (this._index < 0) ? 0 : this._index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasCurrentIndex() {
/* 195 */     return (this._index >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasPathSegment() {
/* 217 */     if (this._type == 2)
/* 218 */       return hasCurrentName(); 
/* 219 */     if (this._type == 1) {
/* 220 */       return hasCurrentIndex();
/*     */     }
/* 222 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getCurrentName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasCurrentName() {
/* 240 */     return (getCurrentName() != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getCurrentValue() {
/* 257 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurrentValue(Object v) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer pathAsPointer() {
/* 281 */     return JsonPointer.forPath(this, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointer pathAsPointer(boolean includeRoot) {
/* 296 */     return JsonPointer.forPath(this, includeRoot);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonLocation startLocation(ContentReference srcRef) {
/* 314 */     return JsonLocation.NA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonLocation getStartLocation(Object srcRef) {
/* 326 */     return JsonLocation.NA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 340 */     StringBuilder sb = new StringBuilder(64);
/* 341 */     switch (this._type)
/*     */     { case 0:
/* 343 */         sb.append("/");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 364 */         return sb.toString();case 1: sb.append('['); sb.append(getCurrentIndex()); sb.append(']'); return sb.toString(); }  sb.append('{'); String currentName = getCurrentName(); if (currentName != null) { sb.append('"'); CharTypes.appendQuoted(sb, currentName); sb.append('"'); } else { sb.append('?'); }  sb.append('}'); return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\JsonStreamContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */