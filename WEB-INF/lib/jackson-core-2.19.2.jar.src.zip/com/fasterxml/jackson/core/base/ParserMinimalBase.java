/*     */ package com.fasterxml.jackson.core.base;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParseException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.StreamReadConstraints;
/*     */ import com.fasterxml.jackson.core.exc.InputCoercionException;
/*     */ import com.fasterxml.jackson.core.exc.StreamConstraintsException;
/*     */ import com.fasterxml.jackson.core.io.JsonEOFException;
/*     */ import com.fasterxml.jackson.core.io.NumberInput;
/*     */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*     */ import com.fasterxml.jackson.core.util.VersionUtil;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ParserMinimalBase
/*     */   extends JsonParser
/*     */ {
/*     */   protected static final int INT_TAB = 9;
/*     */   protected static final int INT_LF = 10;
/*     */   protected static final int INT_CR = 13;
/*     */   protected static final int INT_SPACE = 32;
/*     */   protected static final int INT_RS = 30;
/*     */   protected static final int INT_LBRACKET = 91;
/*     */   protected static final int INT_RBRACKET = 93;
/*     */   protected static final int INT_LCURLY = 123;
/*     */   protected static final int INT_RCURLY = 125;
/*     */   protected static final int INT_QUOTE = 34;
/*     */   protected static final int INT_APOS = 39;
/*     */   protected static final int INT_BACKSLASH = 92;
/*     */   protected static final int INT_SLASH = 47;
/*     */   protected static final int INT_ASTERISK = 42;
/*     */   protected static final int INT_COLON = 58;
/*     */   protected static final int INT_COMMA = 44;
/*     */   protected static final int INT_HASH = 35;
/*     */   protected static final int INT_0 = 48;
/*     */   protected static final int INT_9 = 57;
/*     */   protected static final int INT_MINUS = 45;
/*     */   protected static final int INT_PLUS = 43;
/*     */   protected static final int INT_PERIOD = 46;
/*     */   protected static final int INT_e = 101;
/*     */   protected static final int INT_E = 69;
/*     */   protected static final char CHAR_NULL = '\000';
/*  65 */   protected static final byte[] NO_BYTES = new byte[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   protected static final int[] NO_INTS = new int[0];
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int NR_UNKNOWN = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int NR_INT = 1;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int NR_LONG = 2;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int NR_BIGINT = 4;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int NR_DOUBLE = 8;
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int NR_BIGDECIMAL = 16;
/*     */ 
/*     */   
/*     */   protected static final int NR_FLOAT = 32;
/*     */ 
/*     */   
/* 100 */   protected static final BigInteger BI_MIN_INT = BigInteger.valueOf(-2147483648L);
/* 101 */   protected static final BigInteger BI_MAX_INT = BigInteger.valueOf(2147483647L);
/*     */   
/* 103 */   protected static final BigInteger BI_MIN_LONG = BigInteger.valueOf(Long.MIN_VALUE);
/* 104 */   protected static final BigInteger BI_MAX_LONG = BigInteger.valueOf(Long.MAX_VALUE);
/*     */   
/* 106 */   protected static final BigDecimal BD_MIN_LONG = new BigDecimal(BI_MIN_LONG);
/* 107 */   protected static final BigDecimal BD_MAX_LONG = new BigDecimal(BI_MAX_LONG);
/*     */   
/* 109 */   protected static final BigDecimal BD_MIN_INT = new BigDecimal(BI_MIN_INT);
/* 110 */   protected static final BigDecimal BD_MAX_INT = new BigDecimal(BI_MAX_INT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final long MIN_INT_L = -2147483648L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final long MAX_INT_L = 2147483647L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final double MIN_LONG_D = -9.223372036854776E18D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final double MAX_LONG_D = 9.223372036854776E18D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final double MIN_INT_D = -2.147483648E9D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final double MAX_INT_D = 2.147483647E9D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected static final int MAX_ERROR_TOKEN_LENGTH = 256;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final StreamReadConstraints _streamReadConstraints;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonToken _currToken;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long _tokenCount;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _trackMaxTokenCount;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonToken _lastClearedToken;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected ParserMinimalBase() {
/* 192 */     this._streamReadConstraints = StreamReadConstraints.defaults();
/* 193 */     this._trackMaxTokenCount = this._streamReadConstraints.hasMaxTokenCount();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected ParserMinimalBase(int features) {
/* 198 */     this(features, (StreamReadConstraints)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected ParserMinimalBase(StreamReadConstraints src) {
/* 204 */     this._streamReadConstraints = (src == null) ? StreamReadConstraints.defaults() : src;
/* 205 */     this._trackMaxTokenCount = this._streamReadConstraints.hasMaxTokenCount();
/*     */   }
/*     */ 
/*     */   
/*     */   protected ParserMinimalBase(int features, StreamReadConstraints src) {
/* 210 */     super(features);
/* 211 */     this._streamReadConstraints = (src == null) ? StreamReadConstraints.defaults() : src;
/* 212 */     this._trackMaxTokenCount = this._streamReadConstraints.hasMaxTokenCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StreamReadConstraints streamReadConstraints() {
/* 233 */     return this._streamReadConstraints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonToken nextToken() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonToken currentToken() {
/* 244 */     return this._currToken;
/*     */   } public int currentTokenId() {
/* 246 */     JsonToken t = this._currToken;
/* 247 */     return (t == null) ? 0 : t.id();
/*     */   }
/*     */   public JsonToken getCurrentToken() {
/* 250 */     return this._currToken;
/*     */   }
/*     */   @Deprecated
/*     */   public int getCurrentTokenId() {
/* 254 */     JsonToken t = this._currToken;
/* 255 */     return (t == null) ? 0 : t.id();
/*     */   }
/*     */   public boolean hasCurrentToken() {
/* 258 */     return (this._currToken != null);
/*     */   } public boolean hasTokenId(int id) {
/* 260 */     JsonToken t = this._currToken;
/* 261 */     if (t == null) {
/* 262 */       return (0 == id);
/*     */     }
/* 264 */     return (t.id() == id);
/*     */   }
/*     */   
/*     */   public boolean hasToken(JsonToken t) {
/* 268 */     return (this._currToken == t);
/*     */   }
/*     */   
/* 271 */   public boolean isExpectedStartArrayToken() { return (this._currToken == JsonToken.START_ARRAY); }
/* 272 */   public boolean isExpectedStartObjectToken() { return (this._currToken == JsonToken.START_OBJECT); } public boolean isExpectedNumberIntToken() {
/* 273 */     return (this._currToken == JsonToken.VALUE_NUMBER_INT);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonToken nextValue() throws IOException {
/* 279 */     JsonToken t = nextToken();
/* 280 */     if (t == JsonToken.FIELD_NAME) {
/* 281 */       t = nextToken();
/*     */     }
/* 283 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParser skipChildren() throws IOException {
/* 289 */     if (this._currToken != JsonToken.START_OBJECT && this._currToken != JsonToken.START_ARRAY)
/*     */     {
/* 291 */       return this;
/*     */     }
/* 293 */     int open = 1;
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 298 */       JsonToken t = nextToken();
/* 299 */       if (t == null) {
/* 300 */         _handleEOF();
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 305 */         return this;
/*     */       } 
/* 307 */       if (t.isStructStart()) {
/* 308 */         open++; continue;
/* 309 */       }  if (t.isStructEnd()) {
/* 310 */         if (--open == 0)
/* 311 */           return this; 
/*     */         continue;
/*     */       } 
/* 314 */       if (t == JsonToken.NOT_AVAILABLE)
/*     */       {
/*     */         
/* 317 */         _reportError("Not enough content available for `skipChildren()`: non-blocking parser? (%s)", 
/* 318 */             getClass().getName());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void _handleEOF() throws JsonParseException;
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public abstract String getCurrentName() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void close() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isClosed();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonStreamContext getParsingContext();
/*     */ 
/*     */ 
/*     */   
/*     */   public long currentTokenCount() {
/* 347 */     return this._tokenCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearCurrentToken() {
/* 357 */     if (this._currToken != null) {
/* 358 */       this._lastClearedToken = this._currToken;
/* 359 */       this._currToken = null;
/*     */     } 
/*     */   }
/*     */   public JsonToken getLastClearedToken() {
/* 363 */     return this._lastClearedToken;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void overrideCurrentName(String paramString);
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getText() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract char[] getTextCharacters() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean hasTextCharacters();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getTextLength() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getTextOffset() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract byte[] getBinaryValue(Base64Variant paramBase64Variant) throws IOException;
/*     */ 
/*     */   
/*     */   public boolean getValueAsBoolean(boolean defaultValue) throws IOException {
/* 396 */     JsonToken t = this._currToken;
/* 397 */     if (t != null) {
/* 398 */       String str; Object value; switch (t.id()) {
/*     */         case 6:
/* 400 */           str = getText().trim();
/* 401 */           if ("true".equals(str)) {
/* 402 */             return true;
/*     */           }
/* 404 */           if ("false".equals(str)) {
/* 405 */             return false;
/*     */           }
/* 407 */           if (_hasTextualNull(str)) {
/* 408 */             return false;
/*     */           }
/*     */           break;
/*     */         case 7:
/* 412 */           return (getIntValue() != 0);
/*     */         case 9:
/* 414 */           return true;
/*     */         case 10:
/*     */         case 11:
/* 417 */           return false;
/*     */         case 12:
/* 419 */           value = getEmbeddedObject();
/* 420 */           if (value instanceof Boolean) {
/* 421 */             return ((Boolean)value).booleanValue();
/*     */           }
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 427 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValueAsInt() throws IOException {
/* 433 */     JsonToken t = this._currToken;
/* 434 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/* 435 */       return getIntValue();
/*     */     }
/* 437 */     return getValueAsInt(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValueAsInt(int defaultValue) throws IOException {
/* 443 */     JsonToken t = this._currToken;
/* 444 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/* 445 */       return getIntValue();
/*     */     }
/* 447 */     if (t != null) {
/* 448 */       String str; Object value; switch (t.id()) {
/*     */         case 6:
/* 450 */           str = getText();
/* 451 */           if (_hasTextualNull(str)) {
/* 452 */             return 0;
/*     */           }
/* 454 */           return NumberInput.parseAsInt(str, defaultValue);
/*     */         case 9:
/* 456 */           return 1;
/*     */         case 10:
/* 458 */           return 0;
/*     */         case 11:
/* 460 */           return 0;
/*     */         case 12:
/* 462 */           value = getEmbeddedObject();
/* 463 */           if (value instanceof Number)
/* 464 */             return ((Number)value).intValue(); 
/*     */           break;
/*     */       } 
/*     */     } 
/* 468 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getValueAsLong() throws IOException {
/* 474 */     JsonToken t = this._currToken;
/* 475 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/* 476 */       return getLongValue();
/*     */     }
/* 478 */     return getValueAsLong(0L);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getValueAsLong(long defaultValue) throws IOException {
/* 484 */     JsonToken t = this._currToken;
/* 485 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/* 486 */       return getLongValue();
/*     */     }
/* 488 */     if (t != null) {
/* 489 */       String str; Object value; switch (t.id()) {
/*     */         case 6:
/* 491 */           str = getText();
/* 492 */           if (_hasTextualNull(str)) {
/* 493 */             return 0L;
/*     */           }
/* 495 */           return NumberInput.parseAsLong(str, defaultValue);
/*     */         case 9:
/* 497 */           return 1L;
/*     */         case 10:
/*     */         case 11:
/* 500 */           return 0L;
/*     */         case 12:
/* 502 */           value = getEmbeddedObject();
/* 503 */           if (value instanceof Number)
/* 504 */             return ((Number)value).longValue(); 
/*     */           break;
/*     */       } 
/*     */     } 
/* 508 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValueAsDouble(double defaultValue) throws IOException {
/* 514 */     JsonToken t = this._currToken;
/* 515 */     if (t != null) {
/* 516 */       String str; Object value; switch (t.id()) {
/*     */         case 6:
/* 518 */           str = getText();
/* 519 */           if (_hasTextualNull(str)) {
/* 520 */             return 0.0D;
/*     */           }
/* 522 */           this._streamReadConstraints.validateFPLength(str.length());
/* 523 */           return NumberInput.parseAsDouble(str, defaultValue);
/*     */         case 7:
/*     */         case 8:
/* 526 */           return getDoubleValue();
/*     */         case 9:
/* 528 */           return 1.0D;
/*     */         case 10:
/*     */         case 11:
/* 531 */           return 0.0D;
/*     */         case 12:
/* 533 */           value = getEmbeddedObject();
/* 534 */           if (value instanceof Number)
/* 535 */             return ((Number)value).doubleValue(); 
/*     */           break;
/*     */       } 
/*     */     } 
/* 539 */     return defaultValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValueAsString() throws IOException {
/* 545 */     return getValueAsString((String)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getValueAsString(String defaultValue) throws IOException {
/* 550 */     if (this._currToken == JsonToken.VALUE_STRING) {
/* 551 */       return getText();
/*     */     }
/* 553 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 554 */       return currentName();
/*     */     }
/* 556 */     if (this._currToken == null || this._currToken == JsonToken.VALUE_NULL || !this._currToken.isScalarValue()) {
/* 557 */       return defaultValue;
/*     */     }
/* 559 */     return getText();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _decodeBase64(String str, ByteArrayBuilder builder, Base64Variant b64variant) throws IOException {
/*     */     try {
/* 582 */       b64variant.decode(str, builder);
/* 583 */     } catch (IllegalArgumentException e) {
/* 584 */       _reportError(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _hasTextualNull(String value) {
/* 608 */     return "null".equals(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _reportInputCoercion(String msg, JsonToken inputType, Class<?> targetType) throws InputCoercionException {
/* 619 */     throw new InputCoercionException(this, msg, inputType, targetType);
/*     */   }
/*     */   
/*     */   protected void _reportInvalidEOF() throws JsonParseException {
/* 623 */     _reportInvalidEOF(" in " + this._currToken, this._currToken);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _reportInvalidEOFInValue(JsonToken type) throws JsonParseException {
/*     */     String msg;
/* 629 */     if (type == JsonToken.VALUE_STRING) {
/* 630 */       msg = " in a String value";
/* 631 */     } else if (type == JsonToken.VALUE_NUMBER_INT || type == JsonToken.VALUE_NUMBER_FLOAT) {
/*     */       
/* 633 */       msg = " in a Number value";
/*     */     } else {
/* 635 */       msg = " in a value";
/*     */     } 
/* 637 */     _reportInvalidEOF(msg, type);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _reportInvalidEOF(String msg, JsonToken currToken) throws JsonParseException {
/* 642 */     throw new JsonEOFException(this, currToken, "Unexpected end-of-input" + msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportInvalidNumber(String msg) throws JsonParseException {
/* 656 */     throw _constructReadException("Invalid numeric value: " + msg);
/*     */   }
/*     */   
/*     */   protected void _reportMissingRootWS(int ch) throws JsonParseException {
/* 660 */     _reportUnexpectedChar(ch, "Expected space separating root-level values");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportOverflowInt() throws IOException {
/* 671 */     reportOverflowInt(getText());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reportOverflowInt(String numDesc) throws IOException {
/* 676 */     reportOverflowInt(numDesc, currentToken());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reportOverflowInt(String numDesc, JsonToken inputType) throws IOException {
/* 681 */     _reportInputCoercion(String.format("Numeric value (%s) out of range of int (%d - %s)", new Object[] {
/* 682 */             _longIntegerDesc(numDesc), Integer.valueOf(-2147483648), Integer.valueOf(2147483647)
/*     */           }), inputType, int.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reportOverflowLong() throws IOException {
/* 694 */     reportOverflowLong(getText());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reportOverflowLong(String numDesc) throws IOException {
/* 699 */     reportOverflowLong(numDesc, currentToken());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reportOverflowLong(String numDesc, JsonToken inputType) throws IOException {
/* 704 */     _reportInputCoercion(String.format("Numeric value (%s) out of range of long (%d - %s)", new Object[] {
/* 705 */             _longIntegerDesc(numDesc), Long.valueOf(Long.MIN_VALUE), Long.valueOf(Long.MAX_VALUE)
/*     */           }), inputType, long.class);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String _longIntegerDesc(String rawNum) {
/* 711 */     int rawLen = rawNum.length();
/* 712 */     if (rawLen < 1000) {
/* 713 */       return rawNum;
/*     */     }
/* 715 */     if (rawNum.startsWith("-")) {
/* 716 */       rawLen--;
/*     */     }
/* 718 */     return String.format("[Integer with %d digits]", new Object[] { Integer.valueOf(rawLen) });
/*     */   }
/*     */ 
/*     */   
/*     */   protected String _longNumberDesc(String rawNum) {
/* 723 */     int rawLen = rawNum.length();
/* 724 */     if (rawLen < 1000) {
/* 725 */       return rawNum;
/*     */     }
/* 727 */     if (rawNum.startsWith("-")) {
/* 728 */       rawLen--;
/*     */     }
/* 730 */     return String.format("[number with %d characters]", new Object[] { Integer.valueOf(rawLen) });
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _reportUnexpectedChar(int ch, String comment) throws JsonParseException {
/* 735 */     if (ch < 0) {
/* 736 */       _reportInvalidEOF();
/*     */     }
/* 738 */     String msg = String.format("Unexpected character (%s)", new Object[] { _getCharDesc(ch) });
/* 739 */     if (comment != null) {
/* 740 */       msg = msg + ": " + comment;
/*     */     }
/* 742 */     throw _constructReadException(msg, _currentLocationMinusOne());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> T _reportUnexpectedNumberChar(int ch, String comment) throws JsonParseException {
/* 758 */     String msg = String.format("Unexpected character (%s) in numeric value", new Object[] { _getCharDesc(ch) });
/* 759 */     if (comment != null) {
/* 760 */       msg = msg + ": " + comment;
/*     */     }
/* 762 */     throw _constructReadException(msg, _currentLocationMinusOne());
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected void reportUnexpectedNumberChar(int ch, String comment) throws JsonParseException {
/* 767 */     _reportUnexpectedNumberChar(ch, comment);
/*     */   }
/*     */   
/*     */   protected void _throwInvalidSpace(int i) throws JsonParseException {
/* 771 */     char c = (char)i;
/* 772 */     String msg = "Illegal character (" + _getCharDesc(c) + "): only regular white space (\\r, \\n, \\t) is allowed between tokens";
/*     */     
/* 774 */     if (i == 30) {
/* 775 */       msg = msg + " (consider enabling `JsonReadFeature.ALLOW_RS_CONTROL_CHAR` to allow use of Record Separators (\\u001E))";
/*     */     }
/* 777 */     throw _constructReadException(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonParseException _constructError(String msg, Throwable t) {
/* 787 */     return _constructReadException(msg, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonLocation _currentLocationMinusOne() {
/* 804 */     return currentLocation();
/*     */   }
/*     */ 
/*     */   
/*     */   protected static final String _getCharDesc(int ch) {
/* 809 */     char c = (char)ch;
/* 810 */     if (Character.isISOControl(c)) {
/* 811 */       return "(CTRL-CHAR, code " + ch + ")";
/*     */     }
/* 813 */     if (ch > 255) {
/* 814 */       return "'" + c + "' (code " + ch + " / 0x" + Integer.toHexString(ch) + ")";
/*     */     }
/* 816 */     return "'" + c + "' (code " + ch + ")";
/*     */   }
/*     */   
/*     */   protected final void _reportError(String msg) throws JsonParseException {
/* 820 */     throw _constructReadException(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void _reportError(String msg, Object arg) throws JsonParseException {
/* 825 */     throw _constructReadException(msg, arg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final void _reportError(String msg, Object arg1, Object arg2) throws JsonParseException {
/* 830 */     throw _constructReadException(msg, arg1, arg2);
/*     */   }
/*     */   
/*     */   protected final void _throwInternal() {
/* 834 */     VersionUtil.throwInternal();
/*     */   }
/*     */ 
/*     */   
/*     */   protected final <T> T _throwInternalReturnAny() {
/* 839 */     return (T)VersionUtil.throwInternalReturnAny();
/*     */   }
/*     */   
/*     */   protected final void _wrapError(String msg, Throwable t) throws JsonParseException {
/* 843 */     throw _constructReadException(msg, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonToken _updateToken(JsonToken token) throws StreamConstraintsException {
/* 854 */     this._currToken = token;
/* 855 */     if (this._trackMaxTokenCount) {
/* 856 */       this._streamReadConstraints.validateTokenCount(++this._tokenCount);
/*     */     }
/* 858 */     return token;
/*     */   }
/*     */ 
/*     */   
/*     */   protected final JsonToken _nullSafeUpdateToken(JsonToken token) throws StreamConstraintsException {
/* 863 */     this._currToken = token;
/* 864 */     if (this._trackMaxTokenCount && token != null) {
/* 865 */       this._streamReadConstraints.validateTokenCount(++this._tokenCount);
/*     */     }
/* 867 */     return token;
/*     */   }
/*     */   
/*     */   protected final JsonToken _updateTokenToNull() {
/* 871 */     return this._currToken = null;
/*     */   }
/*     */   
/*     */   protected final JsonToken _updateTokenToNA() {
/* 875 */     return this._currToken = JsonToken.NOT_AVAILABLE;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected static byte[] _asciiBytes(String str) {
/* 880 */     byte[] b = new byte[str.length()];
/* 881 */     for (int i = 0, len = str.length(); i < len; i++) {
/* 882 */       b[i] = (byte)str.charAt(i);
/*     */     }
/* 884 */     return b;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   protected static String _ascii(byte[] b) {
/* 889 */     return new String(b, StandardCharsets.US_ASCII);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\base\ParserMinimalBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */