/*      */ package com.fasterxml.jackson.core.base;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonProcessingException;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.StreamReadCapability;
/*      */ import com.fasterxml.jackson.core.StreamReadFeature;
/*      */ import com.fasterxml.jackson.core.Version;
/*      */ import com.fasterxml.jackson.core.exc.StreamConstraintsException;
/*      */ import com.fasterxml.jackson.core.io.ContentReference;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.io.NumberInput;
/*      */ import com.fasterxml.jackson.core.json.DupDetector;
/*      */ import com.fasterxml.jackson.core.json.JsonReadContext;
/*      */ import com.fasterxml.jackson.core.json.PackageVersion;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import com.fasterxml.jackson.core.util.TextBuffer;
/*      */ import java.io.IOException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ public abstract class ParserBase extends ParserMinimalBase {
/*   29 */   protected static final JacksonFeatureSet<StreamReadCapability> JSON_READ_CAPABILITIES = DEFAULT_READ_CAPABILITIES;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final IOContext _ioContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _closed;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _inputPtr;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _inputEnd;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long _currInputProcessed;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   88 */   protected int _currInputRow = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _currInputRowStart;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long _tokenInputTotal;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  117 */   protected int _tokenInputRow = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _tokenInputCol;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonReadContext _parsingContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _nextToken;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final TextBuffer _textBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char[] _nameCopyBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _nameCopied;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ByteArrayBuilder _byteArrayBuilder;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] _binaryValue;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  192 */   protected int _numTypesValid = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _numberInt;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long _numberLong;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected float _numberFloat;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected double _numberDouble;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BigInteger _numberBigInt;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BigDecimal _numberBigDecimal;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _numberString;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _numberIsNaN;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _numberNegative;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _intLength;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _fractLength;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _expLength;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ParserBase(IOContext ctxt, int features) {
/*  268 */     super(features, ctxt.streamReadConstraints());
/*  269 */     this._ioContext = ctxt;
/*  270 */     this._textBuffer = ctxt.constructReadConstrainedTextBuffer();
/*      */     
/*  272 */     DupDetector dups = JsonParser.Feature.STRICT_DUPLICATE_DETECTION.enabledIn(features) ? DupDetector.rootDetector(this) : null;
/*  273 */     this._parsingContext = JsonReadContext.createRootContext(dups);
/*      */   }
/*      */   
/*      */   public Version version() {
/*  277 */     return PackageVersion.VERSION;
/*      */   }
/*      */   
/*      */   public Object currentValue() {
/*  281 */     return this._parsingContext.getCurrentValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public void assignCurrentValue(Object v) {
/*  286 */     this._parsingContext.setCurrentValue(v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser enable(JsonParser.Feature f) {
/*  297 */     this._features |= f.getMask();
/*  298 */     if (f == JsonParser.Feature.STRICT_DUPLICATE_DETECTION && 
/*  299 */       this._parsingContext.getDupDetector() == null) {
/*  300 */       this._parsingContext = this._parsingContext.withDupDetector(DupDetector.rootDetector(this));
/*      */     }
/*      */     
/*  303 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonParser disable(JsonParser.Feature f) {
/*  308 */     this._features &= f.getMask() ^ 0xFFFFFFFF;
/*  309 */     if (f == JsonParser.Feature.STRICT_DUPLICATE_DETECTION) {
/*  310 */       this._parsingContext = this._parsingContext.withDupDetector(null);
/*      */     }
/*  312 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonParser setFeatureMask(int newMask) {
/*  318 */     int changes = this._features ^ newMask;
/*  319 */     if (changes != 0) {
/*  320 */       this._features = newMask;
/*  321 */       _checkStdFeatureChanges(newMask, changes);
/*      */     } 
/*  323 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public JsonParser overrideStdFeatures(int values, int mask) {
/*  328 */     int oldState = this._features;
/*  329 */     int newState = oldState & (mask ^ 0xFFFFFFFF) | values & mask;
/*  330 */     int changed = oldState ^ newState;
/*  331 */     if (changed != 0) {
/*  332 */       this._features = newState;
/*  333 */       _checkStdFeatureChanges(newState, changed);
/*      */     } 
/*  335 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _checkStdFeatureChanges(int newFeatureFlags, int changedFeatures) {
/*  349 */     int f = JsonParser.Feature.STRICT_DUPLICATE_DETECTION.getMask();
/*      */     
/*  351 */     if ((changedFeatures & f) != 0 && (
/*  352 */       newFeatureFlags & f) != 0) {
/*  353 */       if (this._parsingContext.getDupDetector() == null) {
/*  354 */         this._parsingContext = this._parsingContext.withDupDetector(DupDetector.rootDetector(this));
/*      */       } else {
/*  356 */         this._parsingContext = this._parsingContext.withDupDetector(null);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String getCurrentName() throws IOException {
/*  376 */     if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/*  377 */       JsonReadContext parent = this._parsingContext.getParent();
/*  378 */       if (parent != null) {
/*  379 */         return parent.getCurrentName();
/*      */       }
/*      */     } 
/*  382 */     return this._parsingContext.getCurrentName();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void overrideCurrentName(String name) {
/*  388 */     JsonReadContext ctxt = this._parsingContext;
/*  389 */     if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/*  390 */       ctxt = ctxt.getParent();
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/*  395 */       ctxt.setCurrentName(name);
/*  396 */     } catch (IOException e) {
/*  397 */       throw new IllegalStateException(e);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void close() throws IOException {
/*  402 */     if (!this._closed) {
/*      */       
/*  404 */       this._inputPtr = Math.max(this._inputPtr, this._inputEnd);
/*  405 */       this._closed = true;
/*      */       try {
/*  407 */         _closeInput();
/*      */       }
/*      */       finally {
/*      */         
/*  411 */         _releaseBuffers();
/*  412 */         this._ioContext.close();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*  417 */   public boolean isClosed() { return this._closed; } public JsonReadContext getParsingContext() {
/*  418 */     return this._parsingContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonLocation getTokenLocation() {
/*  428 */     return new JsonLocation(_contentReference(), -1L, 
/*  429 */         getTokenCharacterOffset(), 
/*  430 */         getTokenLineNr(), 
/*  431 */         getTokenColumnNr());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonLocation getCurrentLocation() {
/*  441 */     int col = this._inputPtr - this._currInputRowStart + 1;
/*  442 */     return new JsonLocation(_contentReference(), -1L, this._currInputProcessed + this._inputPtr, this._currInputRow, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasTextCharacters() {
/*  455 */     if (this._currToken == JsonToken.VALUE_STRING) return true; 
/*  456 */     if (this._currToken == JsonToken.FIELD_NAME) return this._nameCopied; 
/*  457 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBinaryValue(Base64Variant variant) throws IOException {
/*  464 */     if (this._binaryValue == null) {
/*  465 */       if (this._currToken != JsonToken.VALUE_STRING) {
/*  466 */         _reportError("Current token (" + this._currToken + ") not VALUE_STRING, can not access as binary");
/*      */       }
/*  468 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  469 */       _decodeBase64(getText(), builder, variant);
/*  470 */       this._binaryValue = builder.toByteArray();
/*      */     } 
/*  472 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getTokenCharacterOffset() {
/*  481 */     return this._tokenInputTotal; } public int getTokenLineNr() {
/*  482 */     return this._tokenInputRow;
/*      */   }
/*      */   public int getTokenColumnNr() {
/*  485 */     int col = this._tokenInputCol;
/*  486 */     return (col < 0) ? col : (col + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() throws IOException {
/*  513 */     this._textBuffer.releaseBuffers();
/*  514 */     char[] buf = this._nameCopyBuffer;
/*  515 */     if (buf != null) {
/*  516 */       this._nameCopyBuffer = null;
/*  517 */       this._ioContext.releaseNameCopyBuffer(buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _handleEOF() throws JsonParseException {
/*  528 */     if (!this._parsingContext.inRoot()) {
/*  529 */       String marker = this._parsingContext.inArray() ? "Array" : "Object";
/*  530 */       _reportInvalidEOF(String.format(": expected close marker for %s (start marker at %s)", new Object[] { marker, this._parsingContext
/*      */ 
/*      */               
/*  533 */               .startLocation(_contentReference()) }), (JsonToken)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _eofAsNextChar() throws JsonParseException {
/*  547 */     _handleEOF();
/*  548 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteArrayBuilder _getByteArrayBuilder() {
/*  559 */     if (this._byteArrayBuilder == null) {
/*  560 */       this._byteArrayBuilder = new ByteArrayBuilder();
/*      */     } else {
/*  562 */       this._byteArrayBuilder.reset();
/*      */     } 
/*  564 */     return this._byteArrayBuilder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken reset(boolean negative, int intLen, int fractLen, int expLen) throws IOException {
/*  578 */     if (fractLen < 1 && expLen < 1) {
/*  579 */       return resetInt(negative, intLen);
/*      */     }
/*  581 */     return resetFloat(negative, intLen, fractLen, expLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken resetInt(boolean negative, int intLen) throws IOException {
/*  588 */     this._streamReadConstraints.validateIntegerLength(intLen);
/*  589 */     this._numberNegative = negative;
/*  590 */     this._numberIsNaN = false;
/*  591 */     this._intLength = intLen;
/*  592 */     this._fractLength = 0;
/*  593 */     this._expLength = 0;
/*  594 */     this._numTypesValid = 0;
/*  595 */     this._numberString = null;
/*  596 */     return JsonToken.VALUE_NUMBER_INT;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken resetFloat(boolean negative, int intLen, int fractLen, int expLen) throws IOException {
/*  603 */     this._streamReadConstraints.validateFPLength(intLen + fractLen + expLen);
/*  604 */     this._numberNegative = negative;
/*  605 */     this._numberIsNaN = false;
/*  606 */     this._intLength = intLen;
/*  607 */     this._fractLength = fractLen;
/*  608 */     this._expLength = expLen;
/*  609 */     this._numTypesValid = 0;
/*  610 */     this._numberString = null;
/*  611 */     return JsonToken.VALUE_NUMBER_FLOAT;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken resetAsNaN(String valueStr, double value) throws IOException {
/*  617 */     this._textBuffer.resetWithString(valueStr);
/*  618 */     this._numberDouble = value;
/*  619 */     this._numTypesValid = 8;
/*  620 */     this._numberIsNaN = true;
/*  621 */     this._numberString = null;
/*  622 */     return JsonToken.VALUE_NUMBER_FLOAT;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNaN() throws IOException {
/*  628 */     return (this._currToken == JsonToken.VALUE_NUMBER_FLOAT && this._numberIsNaN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Number getNumberValue() throws IOException {
/*  641 */     if (this._numTypesValid == 0) {
/*  642 */       _parseNumericValue(0);
/*      */     }
/*      */     
/*  645 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  646 */       if ((this._numTypesValid & 0x1) != 0) {
/*  647 */         return Integer.valueOf(this._numberInt);
/*      */       }
/*  649 */       if ((this._numTypesValid & 0x2) != 0) {
/*  650 */         return Long.valueOf(this._numberLong);
/*      */       }
/*  652 */       if ((this._numTypesValid & 0x4) != 0) {
/*  653 */         return _getBigInteger();
/*      */       }
/*  655 */       _throwInternal();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  660 */     if ((this._numTypesValid & 0x10) != 0) {
/*  661 */       return _getBigDecimal();
/*      */     }
/*  663 */     if ((this._numTypesValid & 0x20) != 0) {
/*  664 */       return Float.valueOf(_getNumberFloat());
/*      */     }
/*  666 */     if ((this._numTypesValid & 0x8) == 0) {
/*  667 */       _throwInternal();
/*      */     }
/*  669 */     return Double.valueOf(_getNumberDouble());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Number getNumberValueExact() throws IOException {
/*  676 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  677 */       if (this._numTypesValid == 0) {
/*  678 */         _parseNumericValue(0);
/*      */       }
/*  680 */       if ((this._numTypesValid & 0x1) != 0) {
/*  681 */         return Integer.valueOf(this._numberInt);
/*      */       }
/*  683 */       if ((this._numTypesValid & 0x2) != 0) {
/*  684 */         return Long.valueOf(this._numberLong);
/*      */       }
/*  686 */       if ((this._numTypesValid & 0x4) != 0) {
/*  687 */         return _getBigInteger();
/*      */       }
/*  689 */       _throwInternal();
/*      */     } 
/*      */     
/*  692 */     if (this._numTypesValid == 0) {
/*  693 */       _parseNumericValue(16);
/*      */     }
/*  695 */     if ((this._numTypesValid & 0x10) != 0) {
/*  696 */       return _getBigDecimal();
/*      */     }
/*  698 */     if ((this._numTypesValid & 0x20) != 0) {
/*  699 */       return Float.valueOf(_getNumberFloat());
/*      */     }
/*  701 */     if ((this._numTypesValid & 0x8) == 0) {
/*  702 */       _throwInternal();
/*      */     }
/*  704 */     return Double.valueOf(_getNumberDouble());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getNumberValueDeferred() throws IOException {
/*  710 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  711 */       if (this._numTypesValid == 0) {
/*  712 */         _parseNumericValue(0);
/*      */       }
/*  714 */       if ((this._numTypesValid & 0x1) != 0) {
/*  715 */         return Integer.valueOf(this._numberInt);
/*      */       }
/*  717 */       if ((this._numTypesValid & 0x2) != 0) {
/*  718 */         return Long.valueOf(this._numberLong);
/*      */       }
/*  720 */       if ((this._numTypesValid & 0x4) != 0) {
/*      */         
/*  722 */         if (this._numberBigInt != null)
/*  723 */           return this._numberBigInt; 
/*  724 */         if (this._numberString != null) {
/*  725 */           return this._numberString;
/*      */         }
/*  727 */         return _getBigInteger();
/*      */       } 
/*  729 */       _throwInternal();
/*      */     } 
/*  731 */     if (this._currToken == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */ 
/*      */       
/*  734 */       if ((this._numTypesValid & 0x10) != 0) {
/*  735 */         return _getBigDecimal();
/*      */       }
/*  737 */       if ((this._numTypesValid & 0x8) != 0) {
/*  738 */         return Double.valueOf(_getNumberDouble());
/*      */       }
/*  740 */       if ((this._numTypesValid & 0x20) != 0) {
/*  741 */         return Float.valueOf(_getNumberFloat());
/*      */       }
/*      */ 
/*      */       
/*  745 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*      */     
/*  748 */     return getNumberValue();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser.NumberType getNumberType() throws IOException {
/*  754 */     if (this._numTypesValid == 0) {
/*  755 */       _parseNumericValue(0);
/*      */     }
/*  757 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  758 */       if ((this._numTypesValid & 0x1) != 0) {
/*  759 */         return JsonParser.NumberType.INT;
/*      */       }
/*  761 */       if ((this._numTypesValid & 0x2) != 0) {
/*  762 */         return JsonParser.NumberType.LONG;
/*      */       }
/*  764 */       return JsonParser.NumberType.BIG_INTEGER;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  773 */     if ((this._numTypesValid & 0x10) != 0) {
/*  774 */       return JsonParser.NumberType.BIG_DECIMAL;
/*      */     }
/*  776 */     if ((this._numTypesValid & 0x20) != 0) {
/*  777 */       return JsonParser.NumberType.FLOAT;
/*      */     }
/*  779 */     return JsonParser.NumberType.DOUBLE;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getIntValue() throws IOException {
/*  785 */     if ((this._numTypesValid & 0x1) == 0) {
/*  786 */       if (this._numTypesValid == 0) {
/*  787 */         return _parseIntValue();
/*      */       }
/*  789 */       if ((this._numTypesValid & 0x1) == 0) {
/*  790 */         convertNumberToInt();
/*      */       }
/*      */     } 
/*  793 */     return this._numberInt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLongValue() throws IOException {
/*  799 */     if ((this._numTypesValid & 0x2) == 0) {
/*  800 */       if (this._numTypesValid == 0) {
/*  801 */         _parseNumericValue(2);
/*      */       }
/*  803 */       if ((this._numTypesValid & 0x2) == 0) {
/*  804 */         convertNumberToLong();
/*      */       }
/*      */     } 
/*  807 */     return this._numberLong;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BigInteger getBigIntegerValue() throws IOException {
/*  813 */     if ((this._numTypesValid & 0x4) == 0) {
/*  814 */       if (this._numTypesValid == 0) {
/*  815 */         _parseNumericValue(4);
/*      */       }
/*  817 */       if ((this._numTypesValid & 0x4) == 0) {
/*  818 */         convertNumberToBigInteger();
/*  819 */         return this._numberBigInt;
/*      */       } 
/*      */     } 
/*  822 */     return _getBigInteger();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloatValue() throws IOException {
/*  836 */     if ((this._numTypesValid & 0x20) == 0) {
/*  837 */       if (this._numTypesValid == 0) {
/*  838 */         _parseNumericValue(32);
/*      */       }
/*  840 */       if ((this._numTypesValid & 0x20) == 0) {
/*  841 */         convertNumberToFloat();
/*  842 */         return this._numberFloat;
/*      */       } 
/*      */     } 
/*  845 */     return _getNumberFloat();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDoubleValue() throws IOException {
/*  851 */     if ((this._numTypesValid & 0x8) == 0) {
/*  852 */       if (this._numTypesValid == 0) {
/*  853 */         _parseNumericValue(8);
/*      */       }
/*      */       
/*  856 */       if ((this._numTypesValid & 0x8) == 0) {
/*  857 */         convertNumberToDouble();
/*  858 */         return this._numberDouble;
/*      */       } 
/*      */     } 
/*  861 */     return _getNumberDouble();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getDecimalValue() throws IOException {
/*  867 */     if ((this._numTypesValid & 0x10) == 0) {
/*  868 */       if (this._numTypesValid == 0) {
/*  869 */         _parseNumericValue(16);
/*      */       }
/*  871 */       if ((this._numTypesValid & 0x10) == 0) {
/*  872 */         convertNumberToBigDecimal();
/*  873 */         return this._numberBigDecimal;
/*      */       } 
/*      */     } 
/*  876 */     return _getBigDecimal();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _parseNumericValue(int expType) throws IOException {
/*  902 */     if (this._closed) {
/*  903 */       _reportError("Internal error: _parseNumericValue called when parser instance closed");
/*      */     }
/*      */ 
/*      */     
/*  907 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT) {
/*  908 */       int len = this._intLength;
/*      */       
/*  910 */       if (len <= 9) {
/*  911 */         this._numberInt = this._textBuffer.contentsAsInt(this._numberNegative);
/*  912 */         this._numTypesValid = 1;
/*      */         return;
/*      */       } 
/*  915 */       if (len <= 18) {
/*  916 */         long l = this._textBuffer.contentsAsLong(this._numberNegative);
/*      */         
/*  918 */         if (len == 10) {
/*  919 */           if (this._numberNegative) {
/*  920 */             if (l >= -2147483648L) {
/*  921 */               this._numberInt = (int)l;
/*  922 */               this._numTypesValid = 1;
/*      */               
/*      */               return;
/*      */             } 
/*  926 */           } else if (l <= 2147483647L) {
/*  927 */             this._numberInt = (int)l;
/*  928 */             this._numTypesValid = 1;
/*      */             
/*      */             return;
/*      */           } 
/*      */         }
/*  933 */         this._numberLong = l;
/*  934 */         this._numTypesValid = 2;
/*      */         
/*      */         return;
/*      */       } 
/*  938 */       if (len == 19) {
/*  939 */         char[] buf = this._textBuffer.getTextBuffer();
/*  940 */         int offset = this._textBuffer.getTextOffset();
/*  941 */         if (this._numberNegative) {
/*  942 */           offset++;
/*      */         }
/*  944 */         if (NumberInput.inLongRange(buf, offset, len, this._numberNegative)) {
/*  945 */           this._numberLong = NumberInput.parseLong19(buf, offset, this._numberNegative);
/*  946 */           this._numTypesValid = 2;
/*      */           return;
/*      */         } 
/*      */       } 
/*  950 */       _parseSlowInt(expType);
/*      */       return;
/*      */     } 
/*  953 */     if (this._currToken == JsonToken.VALUE_NUMBER_FLOAT) {
/*  954 */       _parseSlowFloat(expType);
/*      */       return;
/*      */     } 
/*  957 */     _reportError("Current token (%s) not numeric, can not use numeric value accessors", this._currToken);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _parseIntValue() throws IOException {
/*  966 */     if (this._closed) {
/*  967 */       _reportError("Internal error: _parseNumericValue called when parser instance closed");
/*      */     }
/*      */     
/*  970 */     if (this._currToken == JsonToken.VALUE_NUMBER_INT && 
/*  971 */       this._intLength <= 9) {
/*  972 */       int i = this._textBuffer.contentsAsInt(this._numberNegative);
/*  973 */       this._numberInt = i;
/*  974 */       this._numTypesValid = 1;
/*  975 */       return i;
/*      */     } 
/*      */ 
/*      */     
/*  979 */     _parseNumericValue(1);
/*  980 */     if ((this._numTypesValid & 0x1) == 0) {
/*  981 */       convertNumberToInt();
/*      */     }
/*  983 */     return this._numberInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _parseSlowFloat(int expType) throws IOException {
/*  995 */     if (expType == 16) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1000 */       this._numberBigDecimal = this._textBuffer.contentsAsDecimal(isEnabled(StreamReadFeature.USE_FAST_BIG_NUMBER_PARSER));
/* 1001 */       this._numTypesValid = 16;
/* 1002 */     } else if (expType == 8) {
/* 1003 */       this._numberDouble = this._textBuffer.contentsAsDouble(isEnabled(StreamReadFeature.USE_FAST_DOUBLE_PARSER));
/* 1004 */       this._numTypesValid = 8;
/* 1005 */     } else if (expType == 32) {
/* 1006 */       this._numberFloat = this._textBuffer.contentsAsFloat(isEnabled(StreamReadFeature.USE_FAST_DOUBLE_PARSER));
/* 1007 */       this._numTypesValid = 32;
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1012 */       this._numberDouble = 0.0D;
/* 1013 */       this._numberString = this._textBuffer.contentsAsString();
/* 1014 */       this._numTypesValid = 8;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void _parseSlowInt(int expType) throws IOException {
/* 1020 */     String numStr = this._textBuffer.contentsAsString();
/*      */     
/* 1022 */     if (expType == 1 || expType == 2) {
/* 1023 */       _reportTooLongIntegral(expType, numStr);
/*      */     }
/* 1025 */     if (expType == 8 || expType == 32) {
/* 1026 */       this._numberString = numStr;
/* 1027 */       this._numTypesValid = 8;
/*      */     } else {
/*      */       
/* 1030 */       this._numberBigInt = null;
/* 1031 */       this._numberString = numStr;
/* 1032 */       this._numTypesValid = 4;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportTooLongIntegral(int expType, String rawNum) throws IOException {
/* 1039 */     if (expType == 1) {
/* 1040 */       reportOverflowInt(rawNum);
/*      */     } else {
/* 1042 */       reportOverflowLong(rawNum);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void convertNumberToInt() throws IOException {
/* 1055 */     if ((this._numTypesValid & 0x2) != 0) {
/*      */       
/* 1057 */       int result = (int)this._numberLong;
/* 1058 */       if (result != this._numberLong) {
/* 1059 */         reportOverflowInt(getText(), currentToken());
/*      */       }
/* 1061 */       this._numberInt = result;
/* 1062 */     } else if ((this._numTypesValid & 0x4) != 0) {
/* 1063 */       BigInteger bigInteger = _getBigInteger();
/* 1064 */       if (BI_MIN_INT.compareTo(bigInteger) > 0 || BI_MAX_INT
/* 1065 */         .compareTo(bigInteger) < 0) {
/* 1066 */         reportOverflowInt();
/*      */       }
/* 1068 */       this._numberInt = bigInteger.intValue();
/* 1069 */     } else if ((this._numTypesValid & 0x8) != 0) {
/*      */       
/* 1071 */       double d = _getNumberDouble();
/* 1072 */       if (d < -2.147483648E9D || d > 2.147483647E9D) {
/* 1073 */         reportOverflowInt();
/*      */       }
/* 1075 */       this._numberInt = (int)d;
/* 1076 */     } else if ((this._numTypesValid & 0x10) != 0) {
/* 1077 */       BigDecimal bigDecimal = _getBigDecimal();
/* 1078 */       if (BD_MIN_INT.compareTo(bigDecimal) > 0 || BD_MAX_INT
/* 1079 */         .compareTo(bigDecimal) < 0) {
/* 1080 */         reportOverflowInt();
/*      */       }
/* 1082 */       this._numberInt = bigDecimal.intValue();
/*      */     } else {
/* 1084 */       _throwInternal();
/*      */     } 
/* 1086 */     this._numTypesValid |= 0x1;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void convertNumberToLong() throws IOException {
/* 1091 */     if ((this._numTypesValid & 0x1) != 0) {
/* 1092 */       this._numberLong = this._numberInt;
/* 1093 */     } else if ((this._numTypesValid & 0x4) != 0) {
/* 1094 */       BigInteger bigInteger = _getBigInteger();
/* 1095 */       if (BI_MIN_LONG.compareTo(bigInteger) > 0 || BI_MAX_LONG
/* 1096 */         .compareTo(bigInteger) < 0) {
/* 1097 */         reportOverflowLong();
/*      */       }
/* 1099 */       this._numberLong = bigInteger.longValue();
/* 1100 */     } else if ((this._numTypesValid & 0x8) != 0) {
/*      */       
/* 1102 */       double d = _getNumberDouble();
/* 1103 */       if (d < -9.223372036854776E18D || d > 9.223372036854776E18D) {
/* 1104 */         reportOverflowLong();
/*      */       }
/* 1106 */       this._numberLong = (long)d;
/* 1107 */     } else if ((this._numTypesValid & 0x10) != 0) {
/* 1108 */       BigDecimal bigDecimal = _getBigDecimal();
/* 1109 */       if (BD_MIN_LONG.compareTo(bigDecimal) > 0 || BD_MAX_LONG
/* 1110 */         .compareTo(bigDecimal) < 0) {
/* 1111 */         reportOverflowLong();
/*      */       }
/* 1113 */       this._numberLong = bigDecimal.longValue();
/*      */     } else {
/* 1115 */       _throwInternal();
/*      */     } 
/* 1117 */     this._numTypesValid |= 0x2;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void convertNumberToBigInteger() throws IOException {
/* 1122 */     if ((this._numTypesValid & 0x10) != 0) {
/*      */       
/* 1124 */       this._numberBigInt = _convertBigDecimalToBigInteger(_getBigDecimal());
/* 1125 */     } else if ((this._numTypesValid & 0x2) != 0) {
/* 1126 */       this._numberBigInt = BigInteger.valueOf(this._numberLong);
/* 1127 */     } else if ((this._numTypesValid & 0x1) != 0) {
/* 1128 */       this._numberBigInt = BigInteger.valueOf(this._numberInt);
/* 1129 */     } else if ((this._numTypesValid & 0x8) != 0) {
/* 1130 */       if (this._numberString != null) {
/* 1131 */         this._numberBigInt = _convertBigDecimalToBigInteger(_getBigDecimal());
/*      */       } else {
/* 1133 */         this._numberBigInt = _convertBigDecimalToBigInteger(BigDecimal.valueOf(_getNumberDouble()));
/*      */       } 
/*      */     } else {
/* 1136 */       _throwInternal();
/*      */     } 
/* 1138 */     this._numTypesValid |= 0x4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void convertNumberToDouble() throws IOException {
/* 1149 */     if ((this._numTypesValid & 0x10) != 0) {
/* 1150 */       if (this._numberString != null) {
/* 1151 */         this._numberDouble = _getNumberDouble();
/*      */       } else {
/* 1153 */         this._numberDouble = _getBigDecimal().doubleValue();
/*      */       } 
/* 1155 */     } else if ((this._numTypesValid & 0x4) != 0) {
/* 1156 */       if (this._numberString != null) {
/* 1157 */         this._numberDouble = _getNumberDouble();
/*      */       } else {
/* 1159 */         this._numberDouble = _getBigInteger().doubleValue();
/*      */       } 
/* 1161 */     } else if ((this._numTypesValid & 0x2) != 0) {
/* 1162 */       this._numberDouble = this._numberLong;
/* 1163 */     } else if ((this._numTypesValid & 0x1) != 0) {
/* 1164 */       this._numberDouble = this._numberInt;
/* 1165 */     } else if ((this._numTypesValid & 0x20) != 0) {
/* 1166 */       if (this._numberString != null) {
/* 1167 */         this._numberDouble = _getNumberDouble();
/*      */       } else {
/* 1169 */         this._numberDouble = _getNumberFloat();
/*      */       } 
/*      */     } else {
/* 1172 */       _throwInternal();
/*      */     } 
/* 1174 */     this._numTypesValid |= 0x8;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void convertNumberToFloat() throws IOException {
/* 1185 */     if ((this._numTypesValid & 0x10) != 0) {
/* 1186 */       if (this._numberString != null) {
/* 1187 */         this._numberFloat = _getNumberFloat();
/*      */       } else {
/* 1189 */         this._numberFloat = _getBigDecimal().floatValue();
/*      */       } 
/* 1191 */     } else if ((this._numTypesValid & 0x4) != 0) {
/* 1192 */       if (this._numberString != null) {
/* 1193 */         this._numberFloat = _getNumberFloat();
/*      */       } else {
/* 1195 */         this._numberFloat = _getBigInteger().floatValue();
/*      */       } 
/* 1197 */     } else if ((this._numTypesValid & 0x2) != 0) {
/* 1198 */       this._numberFloat = (float)this._numberLong;
/* 1199 */     } else if ((this._numTypesValid & 0x1) != 0) {
/* 1200 */       this._numberFloat = this._numberInt;
/* 1201 */     } else if ((this._numTypesValid & 0x8) != 0) {
/* 1202 */       if (this._numberString != null) {
/* 1203 */         this._numberFloat = _getNumberFloat();
/*      */       } else {
/* 1205 */         this._numberFloat = (float)_getNumberDouble();
/*      */       } 
/*      */     } else {
/* 1208 */       _throwInternal();
/*      */     } 
/* 1210 */     this._numTypesValid |= 0x20;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void convertNumberToBigDecimal() throws IOException {
/* 1221 */     if ((this._numTypesValid & 0x8) != 0) {
/*      */ 
/*      */       
/* 1224 */       String numStr = (this._numberString == null) ? getText() : this._numberString;
/* 1225 */       this._numberBigDecimal = NumberInput.parseBigDecimal(numStr, 
/*      */           
/* 1227 */           isEnabled(StreamReadFeature.USE_FAST_BIG_NUMBER_PARSER));
/* 1228 */     } else if ((this._numTypesValid & 0x4) != 0) {
/* 1229 */       this._numberBigDecimal = new BigDecimal(_getBigInteger());
/* 1230 */     } else if ((this._numTypesValid & 0x2) != 0) {
/* 1231 */       this._numberBigDecimal = BigDecimal.valueOf(this._numberLong);
/* 1232 */     } else if ((this._numTypesValid & 0x1) != 0) {
/* 1233 */       this._numberBigDecimal = BigDecimal.valueOf(this._numberInt);
/*      */     } else {
/* 1235 */       _throwInternal();
/*      */     } 
/* 1237 */     this._numTypesValid |= 0x10;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BigInteger _convertBigDecimalToBigInteger(BigDecimal bigDec) throws IOException {
/* 1244 */     this._streamReadConstraints.validateBigIntegerScale(bigDec.scale());
/* 1245 */     return bigDec.toBigInteger();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BigInteger _getBigInteger() throws JsonParseException {
/* 1259 */     if (this._numberBigInt != null) {
/* 1260 */       return this._numberBigInt;
/*      */     }
/* 1262 */     if (this._numberString == null) {
/* 1263 */       throw new IllegalStateException("cannot get BigInteger from current parser state");
/*      */     }
/*      */     
/*      */     try {
/* 1267 */       this._numberBigInt = NumberInput.parseBigInteger(this._numberString, 
/*      */           
/* 1269 */           isEnabled(StreamReadFeature.USE_FAST_BIG_NUMBER_PARSER));
/* 1270 */     } catch (NumberFormatException nex) {
/* 1271 */       _wrapError("Malformed numeric value (" + _longNumberDesc(this._numberString) + ")", nex);
/*      */     } 
/* 1273 */     this._numberString = null;
/* 1274 */     return this._numberBigInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BigDecimal _getBigDecimal() throws JsonParseException {
/* 1288 */     if (this._numberBigDecimal != null) {
/* 1289 */       return this._numberBigDecimal;
/*      */     }
/* 1291 */     if (this._numberString == null) {
/* 1292 */       throw new IllegalStateException("cannot get BigDecimal from current parser state");
/*      */     }
/*      */     
/*      */     try {
/* 1296 */       this._numberBigDecimal = NumberInput.parseBigDecimal(this._numberString, 
/*      */           
/* 1298 */           isEnabled(StreamReadFeature.USE_FAST_BIG_NUMBER_PARSER));
/* 1299 */     } catch (NumberFormatException nex) {
/* 1300 */       _wrapError("Malformed numeric value (" + _longNumberDesc(this._numberString) + ")", nex);
/*      */     } 
/* 1302 */     this._numberString = null;
/* 1303 */     return this._numberBigDecimal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected double _getNumberDouble() throws JsonParseException {
/* 1317 */     if (this._numberString != null) {
/*      */       try {
/* 1319 */         this._numberDouble = NumberInput.parseDouble(this._numberString, 
/* 1320 */             isEnabled(StreamReadFeature.USE_FAST_DOUBLE_PARSER));
/* 1321 */       } catch (NumberFormatException nex) {
/* 1322 */         _wrapError("Malformed numeric value (" + _longNumberDesc(this._numberString) + ")", nex);
/*      */       } 
/* 1324 */       this._numberString = null;
/*      */     } 
/* 1326 */     return this._numberDouble;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected float _getNumberFloat() throws JsonParseException {
/* 1340 */     if (this._numberString != null) {
/*      */       try {
/* 1342 */         this._numberFloat = NumberInput.parseFloat(this._numberString, 
/* 1343 */             isEnabled(StreamReadFeature.USE_FAST_DOUBLE_PARSER));
/* 1344 */       } catch (NumberFormatException nex) {
/* 1345 */         _wrapError("Malformed numeric value (" + _longNumberDesc(this._numberString) + ")", nex);
/*      */       } 
/* 1347 */       this._numberString = null;
/*      */     } 
/* 1349 */     return this._numberFloat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void createChildArrayContext(int lineNr, int colNr) throws IOException {
/* 1360 */     this._parsingContext = this._parsingContext.createChildArrayContext(lineNr, colNr);
/* 1361 */     this._streamReadConstraints.validateNestingDepth(this._parsingContext.getNestingDepth());
/*      */   }
/*      */ 
/*      */   
/*      */   protected void createChildObjectContext(int lineNr, int colNr) throws IOException {
/* 1366 */     this._parsingContext = this._parsingContext.createChildObjectContext(lineNr, colNr);
/* 1367 */     this._streamReadConstraints.validateNestingDepth(this._parsingContext.getNestingDepth());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _handleUnrecognizedCharacterEscape(char ch) throws JsonProcessingException {
/* 1379 */     if (isEnabled(JsonParser.Feature.ALLOW_BACKSLASH_ESCAPING_ANY_CHARACTER)) {
/* 1380 */       return ch;
/*      */     }
/*      */     
/* 1383 */     if (ch == '\'' && isEnabled(JsonParser.Feature.ALLOW_SINGLE_QUOTES)) {
/* 1384 */       return ch;
/*      */     }
/* 1386 */     throw _constructReadException("Unrecognized character escape " + _getCharDesc(ch), 
/* 1387 */         _currentLocationMinusOne());
/*      */   }
/*      */   
/*      */   protected void _reportMismatchedEndMarker(int actCh, char expCh) throws JsonParseException {
/* 1391 */     JsonReadContext ctxt = getParsingContext();
/*      */ 
/*      */     
/* 1394 */     if (ctxt.inRoot()) {
/* 1395 */       _reportExtraEndMarker(actCh);
/*      */       return;
/*      */     } 
/* 1398 */     String msg = String.format("Unexpected close marker '%s': expected '%c' (for %s starting at %s)", new Object[] {
/*      */           
/* 1400 */           Character.valueOf((char)actCh), Character.valueOf(expCh), ctxt.typeDesc(), ctxt
/* 1401 */           .startLocation(_contentReference()) });
/* 1402 */     throw _constructReadException(msg, _currentLocationMinusOne());
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _reportExtraEndMarker(int actCh) throws JsonParseException {
/* 1407 */     String scopeDesc = (actCh == 125) ? "Object" : "Array";
/* 1408 */     String msg = String.format("Unexpected close marker '%s': no open %s to close", new Object[] {
/* 1409 */           Character.valueOf((char)actCh), scopeDesc });
/* 1410 */     throw _constructReadException(msg, _currentLocationMinusOne());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _throwUnquotedSpace(int i, String ctxtDesc) throws JsonParseException {
/* 1427 */     if (!isEnabled(JsonParser.Feature.ALLOW_UNQUOTED_CONTROL_CHARS) || i > 32) {
/* 1428 */       char c = (char)i;
/* 1429 */       String msg = "Illegal unquoted character (" + _getCharDesc(c) + "): has to be escaped using backslash to be included in " + ctxtDesc;
/* 1430 */       throw _constructReadException(msg, _currentLocationMinusOne());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _validJsonTokenList() throws IOException {
/* 1444 */     return _validJsonValueList();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _validJsonValueList() throws IOException {
/* 1458 */     if (isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/* 1459 */       return "(JSON String, Number (or 'NaN'/'+INF'/'-INF'), Array, Object or token 'null', 'true' or 'false')";
/*      */     }
/* 1461 */     return "(JSON String, Number, Array, Object or token 'null', 'true' or 'false')";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/* 1480 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _decodeBase64Escape(Base64Variant b64variant, int ch, int index) throws IOException {
/* 1486 */     if (ch != 92) {
/* 1487 */       throw reportInvalidBase64Char(b64variant, ch, index);
/*      */     }
/* 1489 */     int unescaped = _decodeEscaped();
/*      */     
/* 1491 */     if (unescaped <= 32 && 
/* 1492 */       index == 0) {
/* 1493 */       return -1;
/*      */     }
/*      */ 
/*      */     
/* 1497 */     int bits = b64variant.decodeBase64Char(unescaped);
/* 1498 */     if (bits < 0 && 
/* 1499 */       bits != -2) {
/* 1500 */       throw reportInvalidBase64Char(b64variant, unescaped, index);
/*      */     }
/*      */     
/* 1503 */     return bits;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final int _decodeBase64Escape(Base64Variant b64variant, char ch, int index) throws IOException {
/* 1508 */     if (ch != '\\') {
/* 1509 */       throw reportInvalidBase64Char(b64variant, ch, index);
/*      */     }
/* 1511 */     char unescaped = _decodeEscaped();
/*      */     
/* 1513 */     if (unescaped <= ' ' && 
/* 1514 */       index == 0) {
/* 1515 */       return -1;
/*      */     }
/*      */ 
/*      */     
/* 1519 */     int bits = b64variant.decodeBase64Char(unescaped);
/* 1520 */     if (bits < 0)
/*      */     {
/* 1522 */       if (bits != -2 || index < 2) {
/* 1523 */         throw reportInvalidBase64Char(b64variant, unescaped, index);
/*      */       }
/*      */     }
/* 1526 */     return bits;
/*      */   }
/*      */   
/*      */   protected IllegalArgumentException reportInvalidBase64Char(Base64Variant b64variant, int ch, int bindex) throws IllegalArgumentException {
/* 1530 */     return reportInvalidBase64Char(b64variant, ch, bindex, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected IllegalArgumentException reportInvalidBase64Char(Base64Variant b64variant, int ch, int bindex, String msg) throws IllegalArgumentException {
/*      */     String base;
/* 1539 */     if (ch <= 32) {
/* 1540 */       base = String.format("Illegal white space character (code 0x%s) as character #%d of 4-char base64 unit: can only used between units", new Object[] {
/* 1541 */             Integer.toHexString(ch), Integer.valueOf(bindex + 1) });
/* 1542 */     } else if (b64variant.usesPaddingChar(ch)) {
/* 1543 */       base = "Unexpected padding character ('" + b64variant.getPaddingChar() + "') as character #" + (bindex + 1) + " of 4-char base64 unit: padding only legal as 3rd or 4th character";
/* 1544 */     } else if (!Character.isDefined(ch) || Character.isISOControl(ch)) {
/*      */       
/* 1546 */       base = "Illegal character (code 0x" + Integer.toHexString(ch) + ") in base64 content";
/*      */     } else {
/* 1548 */       base = "Illegal character '" + (char)ch + "' (code 0x" + Integer.toHexString(ch) + ") in base64 content";
/*      */     } 
/* 1550 */     if (msg != null) {
/* 1551 */       base = base + ": " + msg;
/*      */     }
/* 1553 */     return new IllegalArgumentException(base);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _handleBase64MissingPadding(Base64Variant b64variant) throws IOException {
/* 1559 */     _reportError(b64variant.missingPaddingMessage());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected Object _getSourceReference() {
/* 1575 */     if (JsonParser.Feature.INCLUDE_SOURCE_IN_LOCATION.enabledIn(this._features)) {
/* 1576 */       return this._ioContext.contentReference().getRawContent();
/*      */     }
/* 1578 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ContentReference _contentReference() {
/* 1590 */     if (JsonParser.Feature.INCLUDE_SOURCE_IN_LOCATION.enabledIn(this._features)) {
/* 1591 */       return this._ioContext.contentReference();
/*      */     }
/* 1593 */     return _contentReferenceRedacted();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ContentReference _contentReferenceRedacted() {
/* 1609 */     return ContentReference.redacted();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static int[] growArrayBy(int[] arr, int more) throws IllegalArgumentException {
/* 1618 */     if (arr == null) {
/* 1619 */       return new int[more];
/*      */     }
/* 1621 */     int len = arr.length + more;
/* 1622 */     if (len < 0) {
/* 1623 */       throw new IllegalArgumentException("Unable to grow array to longer than `Integer.MAX_VALUE`");
/*      */     }
/* 1625 */     return Arrays.copyOf(arr, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int[] _growNameDecodeBuffer(int[] arr, int more) throws StreamConstraintsException {
/* 1634 */     this._streamReadConstraints.validateNameLength(arr.length << 2);
/* 1635 */     return growArrayBy(arr, more);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void loadMoreGuaranteed() throws IOException {
/* 1647 */     if (!loadMore()) _reportInvalidEOF(); 
/*      */   }
/*      */   @Deprecated
/*      */   protected boolean loadMore() throws IOException {
/* 1651 */     return false;
/*      */   }
/*      */   
/*      */   protected void _finishString() throws IOException {}
/*      */   
/*      */   protected abstract void _closeInput() throws IOException;
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\base\ParserBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */