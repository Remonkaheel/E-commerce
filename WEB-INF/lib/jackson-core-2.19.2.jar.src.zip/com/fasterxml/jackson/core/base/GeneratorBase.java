/*     */ package com.fasterxml.jackson.core.base;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.core.PrettyPrinter;
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import com.fasterxml.jackson.core.TreeNode;
/*     */ import com.fasterxml.jackson.core.Version;
/*     */ import com.fasterxml.jackson.core.io.IOContext;
/*     */ import com.fasterxml.jackson.core.json.DupDetector;
/*     */ import com.fasterxml.jackson.core.json.JsonWriteContext;
/*     */ import com.fasterxml.jackson.core.json.PackageVersion;
/*     */ import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.math.BigDecimal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GeneratorBase
/*     */   extends JsonGenerator
/*     */ {
/*     */   public static final int SURR1_FIRST = 55296;
/*     */   public static final int SURR1_LAST = 56319;
/*     */   public static final int SURR2_FIRST = 56320;
/*     */   public static final int SURR2_LAST = 57343;
/*  34 */   protected static final int DERIVED_FEATURES_MASK = JsonGenerator.Feature.WRITE_NUMBERS_AS_STRINGS
/*  35 */     .getMask() | JsonGenerator.Feature.ESCAPE_NON_ASCII
/*  36 */     .getMask() | JsonGenerator.Feature.STRICT_DUPLICATE_DETECTION
/*  37 */     .getMask();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String WRITE_BINARY = "write a binary value";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String WRITE_BOOLEAN = "write a boolean value";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String WRITE_NULL = "write a null";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String WRITE_NUMBER = "write a number";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String WRITE_RAW = "write a raw (unencoded) value";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String WRITE_STRING = "write a string";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int MAX_BIG_DECIMAL_SCALE = 9999;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectCodec _objectCodec;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _features;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final IOContext _ioContext;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _cfgNumbersAsStrings;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonWriteContext _writeContext;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _closed;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected GeneratorBase(int features, ObjectCodec codec) {
/* 111 */     this(features, codec, (IOContext)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected GeneratorBase(int features, ObjectCodec codec, IOContext ioContext) {
/* 118 */     this._features = features;
/* 119 */     this._objectCodec = codec;
/* 120 */     this._ioContext = ioContext;
/*     */     
/* 122 */     DupDetector dups = JsonGenerator.Feature.STRICT_DUPLICATE_DETECTION.enabledIn(features) ? DupDetector.rootDetector(this) : null;
/* 123 */     this._writeContext = JsonWriteContext.createRootContext(dups);
/* 124 */     this._cfgNumbersAsStrings = JsonGenerator.Feature.WRITE_NUMBERS_AS_STRINGS.enabledIn(features);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected GeneratorBase(int features, ObjectCodec codec, JsonWriteContext ctxt) {
/* 130 */     this(features, codec, (IOContext)null, ctxt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected GeneratorBase(int features, ObjectCodec codec, IOContext ioContext, JsonWriteContext jsonWriteContext) {
/* 137 */     this._features = features;
/* 138 */     this._objectCodec = codec;
/* 139 */     this._ioContext = ioContext;
/* 140 */     this._writeContext = jsonWriteContext;
/* 141 */     this._cfgNumbersAsStrings = JsonGenerator.Feature.WRITE_NUMBERS_AS_STRINGS.enabledIn(features);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Version version() {
/* 152 */     return PackageVersion.VERSION;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object currentValue() {
/* 157 */     return this._writeContext.getCurrentValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void assignCurrentValue(Object v) {
/* 163 */     if (this._writeContext != null) {
/* 164 */       this._writeContext.setCurrentValue(v);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEnabled(JsonGenerator.Feature f) {
/* 175 */     return ((this._features & f.getMask()) != 0); } public int getFeatureMask() {
/* 176 */     return this._features;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonGenerator enable(JsonGenerator.Feature f) {
/* 183 */     int mask = f.getMask();
/* 184 */     this._features |= mask;
/* 185 */     if ((mask & DERIVED_FEATURES_MASK) != 0)
/*     */     {
/* 187 */       if (f == JsonGenerator.Feature.WRITE_NUMBERS_AS_STRINGS) {
/* 188 */         this._cfgNumbersAsStrings = true;
/* 189 */       } else if (f == JsonGenerator.Feature.ESCAPE_NON_ASCII) {
/* 190 */         setHighestNonEscapedChar(127);
/* 191 */       } else if (f == JsonGenerator.Feature.STRICT_DUPLICATE_DETECTION && 
/* 192 */         this._writeContext.getDupDetector() == null) {
/* 193 */         this._writeContext = this._writeContext.withDupDetector(DupDetector.rootDetector(this));
/*     */       } 
/*     */     }
/*     */     
/* 197 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonGenerator disable(JsonGenerator.Feature f) {
/* 203 */     int mask = f.getMask();
/* 204 */     this._features &= mask ^ 0xFFFFFFFF;
/* 205 */     if ((mask & DERIVED_FEATURES_MASK) != 0) {
/* 206 */       if (f == JsonGenerator.Feature.WRITE_NUMBERS_AS_STRINGS) {
/* 207 */         this._cfgNumbersAsStrings = false;
/* 208 */       } else if (f == JsonGenerator.Feature.ESCAPE_NON_ASCII) {
/* 209 */         setHighestNonEscapedChar(0);
/* 210 */       } else if (f == JsonGenerator.Feature.STRICT_DUPLICATE_DETECTION) {
/* 211 */         this._writeContext = this._writeContext.withDupDetector(null);
/*     */       } 
/*     */     }
/* 214 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonGenerator setFeatureMask(int newMask) {
/* 220 */     int changed = newMask ^ this._features;
/* 221 */     this._features = newMask;
/* 222 */     if (changed != 0) {
/* 223 */       _checkStdFeatureChanges(newMask, changed);
/*     */     }
/* 225 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonGenerator overrideStdFeatures(int values, int mask) {
/* 230 */     int oldState = this._features;
/* 231 */     int newState = oldState & (mask ^ 0xFFFFFFFF) | values & mask;
/* 232 */     int changed = oldState ^ newState;
/* 233 */     if (changed != 0) {
/* 234 */       this._features = newState;
/* 235 */       _checkStdFeatureChanges(newState, changed);
/*     */     } 
/* 237 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _checkStdFeatureChanges(int newFeatureFlags, int changedFeatures) {
/* 252 */     if ((changedFeatures & DERIVED_FEATURES_MASK) == 0) {
/*     */       return;
/*     */     }
/* 255 */     this._cfgNumbersAsStrings = JsonGenerator.Feature.WRITE_NUMBERS_AS_STRINGS.enabledIn(newFeatureFlags);
/* 256 */     if (JsonGenerator.Feature.ESCAPE_NON_ASCII.enabledIn(changedFeatures)) {
/* 257 */       if (JsonGenerator.Feature.ESCAPE_NON_ASCII.enabledIn(newFeatureFlags)) {
/* 258 */         setHighestNonEscapedChar(127);
/*     */       } else {
/* 260 */         setHighestNonEscapedChar(0);
/*     */       } 
/*     */     }
/* 263 */     if (JsonGenerator.Feature.STRICT_DUPLICATE_DETECTION.enabledIn(changedFeatures)) {
/* 264 */       if (JsonGenerator.Feature.STRICT_DUPLICATE_DETECTION.enabledIn(newFeatureFlags)) {
/* 265 */         if (this._writeContext.getDupDetector() == null) {
/* 266 */           this._writeContext = this._writeContext.withDupDetector(DupDetector.rootDetector(this));
/*     */         }
/*     */       } else {
/* 269 */         this._writeContext = this._writeContext.withDupDetector(null);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonGenerator useDefaultPrettyPrinter() {
/* 276 */     if (getPrettyPrinter() != null) {
/* 277 */       return this;
/*     */     }
/* 279 */     return setPrettyPrinter(_constructDefaultPrettyPrinter());
/*     */   }
/*     */   
/*     */   public JsonGenerator setCodec(ObjectCodec oc) {
/* 283 */     this._objectCodec = oc;
/* 284 */     return this;
/*     */   }
/*     */   public ObjectCodec getCodec() {
/* 287 */     return this._objectCodec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonStreamContext getOutputContext() {
/* 301 */     return (JsonStreamContext)this._writeContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IOContext ioContext() {
/* 311 */     return this._ioContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeStartObject(Object forValue) throws IOException {
/* 328 */     writeStartObject();
/* 329 */     if (forValue != null) {
/* 330 */       assignCurrentValue(forValue);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeFieldName(SerializableString name) throws IOException {
/* 341 */     writeFieldName(name.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeString(SerializableString text) throws IOException {
/* 356 */     writeString(text.getValue());
/*     */   }
/*     */   
/*     */   public void writeRawValue(String text) throws IOException {
/* 360 */     _verifyValueWrite("write raw value");
/* 361 */     writeRaw(text);
/*     */   }
/*     */   
/*     */   public void writeRawValue(String text, int offset, int len) throws IOException {
/* 365 */     _verifyValueWrite("write raw value");
/* 366 */     writeRaw(text, offset, len);
/*     */   }
/*     */   
/*     */   public void writeRawValue(char[] text, int offset, int len) throws IOException {
/* 370 */     _verifyValueWrite("write raw value");
/* 371 */     writeRaw(text, offset, len);
/*     */   }
/*     */   
/*     */   public void writeRawValue(SerializableString text) throws IOException {
/* 375 */     _verifyValueWrite("write raw value");
/* 376 */     writeRaw(text);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int writeBinary(Base64Variant b64variant, InputStream data, int dataLength) throws IOException {
/* 382 */     _reportUnsupportedOperation();
/* 383 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeObject(Object value) throws IOException {
/* 412 */     if (value == null) {
/*     */       
/* 414 */       writeNull();
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 421 */       if (this._objectCodec != null) {
/* 422 */         this._objectCodec.writeValue(this, value);
/*     */         return;
/*     */       } 
/* 425 */       _writeSimpleObject(value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTree(TreeNode rootNode) throws IOException {
/* 432 */     if (rootNode == null) {
/* 433 */       writeNull();
/*     */     } else {
/* 435 */       if (this._objectCodec == null) {
/* 436 */         throw new IllegalStateException("No ObjectCodec defined");
/*     */       }
/* 438 */       this._objectCodec.writeValue(this, rootNode);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void flush() throws IOException;
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 450 */     if (!this._closed) {
/* 451 */       if (this._ioContext != null) {
/* 452 */         this._ioContext.close();
/*     */       }
/* 454 */       this._closed = true;
/*     */     } 
/*     */   } public boolean isClosed() {
/* 457 */     return this._closed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void _releaseBuffers();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void _verifyValueWrite(String paramString) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PrettyPrinter _constructDefaultPrettyPrinter() {
/* 493 */     return (PrettyPrinter)new DefaultPrettyPrinter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String _asString(BigDecimal value) throws IOException {
/* 509 */     if (JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN.enabledIn(this._features)) {
/*     */       
/* 511 */       int scale = value.scale();
/* 512 */       if (scale < -9999 || scale > 9999)
/* 513 */         _reportError(String.format("Attempt to write plain `java.math.BigDecimal` (see JsonGenerator.Feature.WRITE_BIGDECIMAL_AS_PLAIN) with illegal scale (%d): needs to be between [-%d, %d]", new Object[] {
/*     */                 
/* 515 */                 Integer.valueOf(scale), Integer.valueOf(9999), Integer.valueOf(9999)
/*     */               })); 
/* 517 */       return value.toPlainString();
/*     */     } 
/* 519 */     return value.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _decodeSurrogate(int surr1, int surr2) throws IOException {
/* 532 */     if (surr2 < 56320 || surr2 > 57343) {
/* 533 */       String msg = String.format("Incomplete surrogate pair: first char 0x%04X, second 0x%04X", new Object[] {
/* 534 */             Integer.valueOf(surr1), Integer.valueOf(surr2) });
/* 535 */       _reportError(msg);
/*     */     } 
/* 537 */     return (surr1 << 10) + surr2 + -56613888;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _checkRangeBoundsForByteArray(byte[] data, int offset, int len) throws IOException {
/* 550 */     if (data == null) {
/* 551 */       _reportError("Invalid `byte[]` argument: `null`");
/*     */     }
/* 553 */     int dataLen = data.length;
/* 554 */     int end = offset + len;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 564 */     int anyNegs = offset | len | end | dataLen - end;
/* 565 */     if (anyNegs < 0) {
/* 566 */       _reportError(String.format("Invalid 'offset' (%d) and/or 'len' (%d) arguments for `byte[]` of length %d", new Object[] {
/*     */               
/* 568 */               Integer.valueOf(offset), Integer.valueOf(len), Integer.valueOf(dataLen)
/*     */             }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _checkRangeBoundsForCharArray(char[] data, int offset, int len) throws IOException {
/* 576 */     if (data == null) {
/* 577 */       _reportError("Invalid `char[]` argument: `null`");
/*     */     }
/* 579 */     int dataLen = data.length;
/* 580 */     int end = offset + len;
/*     */     
/* 582 */     int anyNegs = offset | len | end | dataLen - end;
/* 583 */     if (anyNegs < 0) {
/* 584 */       _reportError(String.format("Invalid 'offset' (%d) and/or 'len' (%d) arguments for `char[]` of length %d", new Object[] {
/*     */               
/* 586 */               Integer.valueOf(offset), Integer.valueOf(len), Integer.valueOf(dataLen)
/*     */             }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _checkRangeBoundsForString(String data, int offset, int len) throws IOException {
/* 594 */     if (data == null) {
/* 595 */       _reportError("Invalid `String` argument: `null`");
/*     */     }
/* 597 */     int dataLen = data.length();
/* 598 */     int end = offset + len;
/*     */     
/* 600 */     int anyNegs = offset | len | end | dataLen - end;
/* 601 */     if (anyNegs < 0)
/* 602 */       _reportError(String.format("Invalid 'offset' (%d) and/or 'len' (%d) arguments for `String` of length %d", new Object[] {
/*     */               
/* 604 */               Integer.valueOf(offset), Integer.valueOf(len), Integer.valueOf(dataLen)
/*     */             })); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\base\GeneratorBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */