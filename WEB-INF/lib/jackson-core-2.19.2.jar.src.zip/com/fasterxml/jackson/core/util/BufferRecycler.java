/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BufferRecycler
/*     */   implements RecyclerPool.WithPool<BufferRecycler>
/*     */ {
/*     */   public static final int BYTE_READ_IO_BUFFER = 0;
/*     */   public static final int BYTE_WRITE_ENCODING_BUFFER = 1;
/*     */   public static final int BYTE_WRITE_CONCAT_BUFFER = 2;
/*     */   public static final int BYTE_BASE64_CODEC_BUFFER = 3;
/*     */   public static final int CHAR_TOKEN_BUFFER = 0;
/*     */   public static final int CHAR_CONCAT_BUFFER = 1;
/*     */   public static final int CHAR_TEXT_BUFFER = 2;
/*     */   public static final int CHAR_NAME_COPY_BUFFER = 3;
/*  95 */   private static final int[] BYTE_BUFFER_LENGTHS = new int[] { 8000, 8000, 2000, 2000 };
/*  96 */   private static final int[] CHAR_BUFFER_LENGTHS = new int[] { 4000, 4000, 200, 200 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AtomicReferenceArray<byte[]> _byteBuffers;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final AtomicReferenceArray<char[]> _charBuffers;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RecyclerPool<BufferRecycler> _pool;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferRecycler() {
/* 117 */     this(4, 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BufferRecycler(int bbCount, int cbCount) {
/* 130 */     this._byteBuffers = (AtomicReferenceArray)new AtomicReferenceArray<>(bbCount);
/* 131 */     this._charBuffers = (AtomicReferenceArray)new AtomicReferenceArray<>(cbCount);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLinkedWithPool() {
/* 141 */     return (this._pool != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] allocByteBuffer(int ix) {
/* 156 */     return allocByteBuffer(ix, 0);
/*     */   }
/*     */   
/*     */   public byte[] allocByteBuffer(int ix, int minSize) {
/* 160 */     int DEF_SIZE = byteBufferLength(ix);
/* 161 */     if (minSize < DEF_SIZE) {
/* 162 */       minSize = DEF_SIZE;
/*     */     }
/* 164 */     byte[] buffer = this._byteBuffers.getAndSet(ix, null);
/* 165 */     if (buffer == null || buffer.length < minSize) {
/* 166 */       buffer = balloc(minSize);
/*     */     }
/* 168 */     return buffer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void releaseByteBuffer(int ix, byte[] buffer) {
/* 173 */     byte[] oldBuffer = this._byteBuffers.get(ix);
/* 174 */     if (oldBuffer == null || buffer.length > oldBuffer.length)
/*     */     {
/* 176 */       this._byteBuffers.set(ix, buffer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final char[] allocCharBuffer(int ix) {
/* 187 */     return allocCharBuffer(ix, 0);
/*     */   }
/*     */   
/*     */   public char[] allocCharBuffer(int ix, int minSize) {
/* 191 */     int DEF_SIZE = charBufferLength(ix);
/* 192 */     if (minSize < DEF_SIZE) {
/* 193 */       minSize = DEF_SIZE;
/*     */     }
/* 195 */     char[] buffer = this._charBuffers.getAndSet(ix, null);
/* 196 */     if (buffer == null || buffer.length < minSize) {
/* 197 */       buffer = calloc(minSize);
/*     */     }
/* 199 */     return buffer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void releaseCharBuffer(int ix, char[] buffer) {
/* 204 */     char[] oldBuffer = this._charBuffers.get(ix);
/* 205 */     if (oldBuffer == null || buffer.length > oldBuffer.length)
/*     */     {
/* 207 */       this._charBuffers.set(ix, buffer);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int byteBufferLength(int ix) {
/* 218 */     return BYTE_BUFFER_LENGTHS[ix];
/*     */   }
/*     */   
/*     */   protected int charBufferLength(int ix) {
/* 222 */     return CHAR_BUFFER_LENGTHS[ix];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] balloc(int size) {
/* 231 */     return new byte[size]; } protected char[] calloc(int size) {
/* 232 */     return new char[size];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferRecycler withPool(RecyclerPool<BufferRecycler> pool) {
/* 248 */     if (this._pool != null) {
/* 249 */       throw new IllegalStateException("BufferRecycler already linked to pool: " + pool);
/*     */     }
/*     */ 
/*     */     
/* 253 */     this._pool = Objects.<RecyclerPool<BufferRecycler>>requireNonNull(pool);
/* 254 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void releaseToPool() {
/* 265 */     if (this._pool != null) {
/* 266 */       RecyclerPool<BufferRecycler> tmpPool = this._pool;
/*     */ 
/*     */       
/* 269 */       this._pool = null;
/* 270 */       tmpPool.releasePooled(this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static interface Gettable {
/*     */     BufferRecycler bufferRecycler();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\cor\\util\BufferRecycler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */