/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Version;
/*     */ import com.fasterxml.jackson.core.Versioned;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Properties;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VersionUtil
/*     */ {
/*  28 */   private static final Pattern V_SEP = Pattern.compile("[-_./;:]");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Version version() {
/*  39 */     return Version.unknownVersion();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Version versionFor(Class<?> cls) {
/*  62 */     Version v = null;
/*     */     try {
/*  64 */       String versionInfoClassName = cls.getPackage().getName() + ".PackageVersion";
/*  65 */       Class<?> vClass = Class.forName(versionInfoClassName, true, cls.getClassLoader());
/*     */       
/*     */       try {
/*  68 */         v = ((Versioned)vClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0])).version();
/*  69 */       } catch (Exception e) {
/*  70 */         throw new IllegalArgumentException("Failed to get Versioned out of " + vClass);
/*     */       } 
/*  72 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/*  76 */     return (v == null) ? Version.unknownVersion() : v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static Version packageVersionFor(Class<?> cls) {
/*  91 */     return versionFor(cls);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static Version mavenVersionFor(ClassLoader cl, String groupId, String artifactId) {
/* 112 */     InputStream pomProperties = cl.getResourceAsStream("META-INF/maven/" + groupId
/* 113 */         .replaceAll("\\.", "/") + "/" + artifactId + "/pom.properties");
/* 114 */     if (pomProperties != null) {
/*     */       try {
/* 116 */         Properties props = new Properties();
/* 117 */         props.load(pomProperties);
/* 118 */         String versionStr = props.getProperty("version");
/* 119 */         String pomPropertiesArtifactId = props.getProperty("artifactId");
/* 120 */         String pomPropertiesGroupId = props.getProperty("groupId");
/* 121 */         return parseVersion(versionStr, pomPropertiesGroupId, pomPropertiesArtifactId);
/* 122 */       } catch (IOException iOException) {
/*     */       
/*     */       } finally {
/* 125 */         _close(pomProperties);
/*     */       } 
/*     */     }
/* 128 */     return Version.unknownVersion();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Version parseVersion(String s, String groupId, String artifactId) {
/* 143 */     if (s != null && (s = s.trim()).length() > 0) {
/* 144 */       String[] parts = V_SEP.split(s);
/* 145 */       return new Version(parseVersionPart(parts[0]), (parts.length > 1) ? 
/* 146 */           parseVersionPart(parts[1]) : 0, (parts.length > 2) ? 
/* 147 */           parseVersionPart(parts[2]) : 0, (parts.length > 3) ? parts[3] : null, groupId, artifactId);
/*     */     } 
/*     */ 
/*     */     
/* 151 */     return Version.unknownVersion();
/*     */   }
/*     */   
/*     */   protected static int parseVersionPart(String s) {
/* 155 */     int number = 0;
/* 156 */     for (int i = 0, len = s.length(); i < len; i++) {
/* 157 */       char c = s.charAt(i);
/* 158 */       if (c > '9' || c < '0')
/* 159 */         break;  number = number * 10 + c - 48;
/*     */     } 
/* 161 */     return number;
/*     */   }
/*     */   
/*     */   private static final void _close(Closeable c) {
/*     */     try {
/* 166 */       c.close();
/* 167 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void throwInternal() {
/* 177 */     throw new RuntimeException("Internal error: this code path should never get executed");
/*     */   }
/*     */   
/*     */   public static final <T> T throwInternalReturnAny() {
/* 181 */     throw new RuntimeException("Internal error: this code path should never get executed");
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\cor\\util\VersionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */