/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.JsonStringEncoder;
/*     */ import java.lang.ref.SoftReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class BufferRecyclers
/*     */ {
/*     */   public static final String SYSTEM_PROPERTY_TRACK_REUSABLE_BUFFERS = "com.fasterxml.jackson.core.util.BufferRecyclers.trackReusableBuffers";
/*     */   private static final ThreadLocalBufferManager _bufferRecyclerTracker;
/*     */   
/*     */   static {
/*  41 */     boolean trackReusableBuffers = false;
/*     */     try {
/*  43 */       trackReusableBuffers = "true".equals(System.getProperty("com.fasterxml.jackson.core.util.BufferRecyclers.trackReusableBuffers"));
/*  44 */     } catch (SecurityException securityException) {}
/*     */     
/*  46 */     _bufferRecyclerTracker = trackReusableBuffers ? ThreadLocalBufferManager.instance() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   protected static final ThreadLocal<SoftReference<BufferRecycler>> _recyclerRef = new ThreadLocal<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static BufferRecycler getBufferRecycler() {
/*  74 */     SoftReference<BufferRecycler> ref = _recyclerRef.get();
/*  75 */     BufferRecycler br = (ref == null) ? null : ref.get();
/*     */     
/*  77 */     if (br == null) {
/*  78 */       br = new BufferRecycler();
/*  79 */       if (_bufferRecyclerTracker != null) {
/*  80 */         ref = _bufferRecyclerTracker.wrapAndTrack(br);
/*     */       } else {
/*  82 */         ref = new SoftReference<>(br);
/*     */       } 
/*  84 */       _recyclerRef.set(ref);
/*     */     } 
/*  86 */     return br;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int releaseBuffers() {
/* 103 */     if (_bufferRecyclerTracker != null) {
/* 104 */       return _bufferRecyclerTracker.releaseBuffers();
/*     */     }
/* 106 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static JsonStringEncoder getJsonStringEncoder() {
/* 127 */     return JsonStringEncoder.getInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static byte[] encodeAsUTF8(String text) {
/* 143 */     return JsonStringEncoder.getInstance().encodeAsUTF8(text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static char[] quoteAsJsonText(String rawText) {
/* 160 */     return JsonStringEncoder.getInstance().quoteAsString(rawText);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static void quoteAsJsonText(CharSequence input, StringBuilder output) {
/* 176 */     JsonStringEncoder.getInstance().quoteAsString(input, output);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static byte[] quoteAsJsonUTF8(String rawText) {
/* 193 */     return JsonStringEncoder.getInstance().quoteAsUTF8(rawText);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\cor\\util\BufferRecyclers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */