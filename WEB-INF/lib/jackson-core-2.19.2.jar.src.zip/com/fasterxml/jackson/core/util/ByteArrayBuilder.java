/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ import java.io.OutputStream;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ByteArrayBuilder
/*     */   extends OutputStream
/*     */   implements BufferRecycler.Gettable
/*     */ {
/*  33 */   public static final byte[] NO_BYTES = new byte[0];
/*     */ 
/*     */   
/*     */   private static final int INITIAL_BLOCK_SIZE = 500;
/*     */ 
/*     */   
/*     */   private static final int MAX_BLOCK_SIZE = 131072;
/*     */ 
/*     */   
/*     */   static final int DEFAULT_BLOCK_ARRAY_SIZE = 40;
/*     */   
/*     */   private final BufferRecycler _bufferRecycler;
/*     */   
/*  46 */   private final LinkedList<byte[]> _pastBlocks = (LinkedList)new LinkedList<>();
/*     */   
/*     */   private int _pastLen;
/*     */   private byte[] _currBlock;
/*     */   private int _currBlockPtr;
/*     */   
/*     */   public ByteArrayBuilder() {
/*  53 */     this((BufferRecycler)null); }
/*  54 */   public ByteArrayBuilder(BufferRecycler br) { this(br, 500); } public ByteArrayBuilder(int firstBlockSize) {
/*  55 */     this(null, firstBlockSize);
/*     */   }
/*     */   public ByteArrayBuilder(BufferRecycler br, int firstBlockSize) {
/*  58 */     this._bufferRecycler = br;
/*     */ 
/*     */     
/*  61 */     if (firstBlockSize > 131072) {
/*  62 */       firstBlockSize = 131072;
/*     */     }
/*  64 */     this._currBlock = (br == null) ? new byte[firstBlockSize] : br.allocByteBuffer(2);
/*     */   }
/*     */   
/*     */   private ByteArrayBuilder(BufferRecycler br, byte[] initialBlock, int initialLen) {
/*  68 */     this._bufferRecycler = br;
/*  69 */     this._currBlock = initialBlock;
/*  70 */     this._currBlockPtr = initialLen;
/*     */   }
/*     */   
/*     */   public static ByteArrayBuilder fromInitial(byte[] initialBlock, int length) {
/*  74 */     return new ByteArrayBuilder(null, initialBlock, length);
/*     */   }
/*     */   
/*     */   public void reset() {
/*  78 */     this._pastLen = 0;
/*  79 */     this._currBlockPtr = 0;
/*     */     
/*  81 */     if (!this._pastBlocks.isEmpty()) {
/*  82 */       this._pastBlocks.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  92 */     return this._pastLen + this._currBlockPtr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/* 101 */     reset();
/* 102 */     if (this._bufferRecycler != null && this._currBlock != null) {
/* 103 */       this._bufferRecycler.releaseByteBuffer(2, this._currBlock);
/* 104 */       this._currBlock = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void append(int i) {
/* 109 */     if (this._currBlockPtr >= this._currBlock.length) {
/* 110 */       _allocMore();
/*     */     }
/* 112 */     this._currBlock[this._currBlockPtr++] = (byte)i;
/*     */   }
/*     */   
/*     */   public void appendTwoBytes(int b16) {
/* 116 */     if (this._currBlockPtr + 1 < this._currBlock.length) {
/* 117 */       this._currBlock[this._currBlockPtr++] = (byte)(b16 >> 8);
/* 118 */       this._currBlock[this._currBlockPtr++] = (byte)b16;
/*     */     } else {
/* 120 */       append(b16 >> 8);
/* 121 */       append(b16);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void appendThreeBytes(int b24) {
/* 126 */     if (this._currBlockPtr + 2 < this._currBlock.length) {
/* 127 */       this._currBlock[this._currBlockPtr++] = (byte)(b24 >> 16);
/* 128 */       this._currBlock[this._currBlockPtr++] = (byte)(b24 >> 8);
/* 129 */       this._currBlock[this._currBlockPtr++] = (byte)b24;
/*     */     } else {
/* 131 */       append(b24 >> 16);
/* 132 */       append(b24 >> 8);
/* 133 */       append(b24);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void appendFourBytes(int b32) {
/* 139 */     if (this._currBlockPtr + 3 < this._currBlock.length) {
/* 140 */       this._currBlock[this._currBlockPtr++] = (byte)(b32 >> 24);
/* 141 */       this._currBlock[this._currBlockPtr++] = (byte)(b32 >> 16);
/* 142 */       this._currBlock[this._currBlockPtr++] = (byte)(b32 >> 8);
/* 143 */       this._currBlock[this._currBlockPtr++] = (byte)b32;
/*     */     } else {
/* 145 */       append(b32 >> 24);
/* 146 */       append(b32 >> 16);
/* 147 */       append(b32 >> 8);
/* 148 */       append(b32);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toByteArray() {
/* 160 */     int totalLen = this._pastLen + this._currBlockPtr;
/*     */     
/* 162 */     if (totalLen == 0) {
/* 163 */       return NO_BYTES;
/*     */     }
/* 165 */     byte[] result = new byte[totalLen];
/* 166 */     int offset = 0;
/*     */     
/* 168 */     for (byte[] block : this._pastBlocks) {
/* 169 */       int len = block.length;
/* 170 */       System.arraycopy(block, 0, result, offset, len);
/* 171 */       offset += len;
/*     */     } 
/* 173 */     System.arraycopy(this._currBlock, 0, result, offset, this._currBlockPtr);
/* 174 */     offset += this._currBlockPtr;
/* 175 */     if (offset != totalLen) {
/* 176 */       throw new RuntimeException("Internal error: total len assumed to be " + totalLen + ", copied " + offset + " bytes");
/*     */     }
/*     */     
/* 179 */     if (!this._pastBlocks.isEmpty()) {
/* 180 */       reset();
/*     */     }
/* 182 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getClearAndRelease() {
/* 202 */     byte[] result = toByteArray();
/* 203 */     release();
/* 204 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferRecycler bufferRecycler() {
/* 215 */     return this._bufferRecycler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] resetAndGetFirstSegment() {
/* 231 */     reset();
/* 232 */     return this._currBlock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] finishCurrentSegment() {
/* 243 */     _allocMore();
/* 244 */     return this._currBlock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] completeAndCoalesce(int lastBlockLength) {
/* 257 */     this._currBlockPtr = lastBlockLength;
/* 258 */     return toByteArray();
/*     */   }
/*     */   
/* 261 */   public byte[] getCurrentSegment() { return this._currBlock; }
/* 262 */   public void setCurrentSegmentLength(int len) { this._currBlockPtr = len; } public int getCurrentSegmentLength() {
/* 263 */     return this._currBlockPtr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] b) {
/* 273 */     write(b, 0, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] b, int off, int len) {
/*     */     while (true) {
/* 280 */       int max = this._currBlock.length - this._currBlockPtr;
/* 281 */       int toCopy = Math.min(max, len);
/* 282 */       if (toCopy > 0) {
/* 283 */         System.arraycopy(b, off, this._currBlock, this._currBlockPtr, toCopy);
/* 284 */         off += toCopy;
/* 285 */         this._currBlockPtr += toCopy;
/* 286 */         len -= toCopy;
/*     */       } 
/* 288 */       if (len <= 0)
/* 289 */         break;  _allocMore();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(int b) {
/* 295 */     append(b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _allocMore() {
/* 314 */     int newPastLen = this._pastLen + this._currBlock.length;
/*     */ 
/*     */ 
/*     */     
/* 318 */     if (newPastLen < 0) {
/* 319 */       throw new IllegalStateException("Maximum Java array size (2GB) exceeded by `ByteArrayBuilder`");
/*     */     }
/*     */     
/* 322 */     this._pastLen = newPastLen;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 330 */     int newSize = Math.max(this._pastLen >> 1, 1000);
/*     */     
/* 332 */     if (newSize > 131072) {
/* 333 */       newSize = 131072;
/*     */     }
/* 335 */     this._pastBlocks.add(this._currBlock);
/* 336 */     this._currBlock = new byte[newSize];
/* 337 */     this._currBlockPtr = 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\cor\\util\ByteArrayBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */