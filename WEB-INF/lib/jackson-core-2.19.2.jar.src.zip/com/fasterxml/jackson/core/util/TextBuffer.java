/*      */ package com.fasterxml.jackson.core.util;
/*      */ 
/*      */ import com.fasterxml.jackson.core.io.NumberInput;
/*      */ import java.io.IOException;
/*      */ import java.io.Writer;
/*      */ import java.math.BigDecimal;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TextBuffer
/*      */ {
/*   30 */   static final char[] NO_CHARS = new char[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int MIN_SEGMENT_LEN = 500;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int MAX_SEGMENT_LEN = 65536;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final BufferRecycler _allocator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char[] _inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _inputStart;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _inputLen;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList<char[]> _segments;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _hasSegments;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _segmentSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char[] _currentSegment;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _currentSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String _resultString;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char[] _resultArray;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TextBuffer(BufferRecycler allocator) {
/*  125 */     this._allocator = allocator;
/*      */   }
/*      */ 
/*      */   
/*      */   protected TextBuffer(BufferRecycler allocator, char[] initialSegment) {
/*  130 */     this(allocator);
/*  131 */     this._currentSegment = initialSegment;
/*  132 */     this._currentSize = initialSegment.length;
/*  133 */     this._inputStart = -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TextBuffer fromInitial(char[] initialSegment) {
/*  148 */     return new TextBuffer(null, initialSegment);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void releaseBuffers() {
/*  166 */     this._inputStart = -1;
/*  167 */     this._currentSize = 0;
/*  168 */     this._inputLen = 0;
/*      */     
/*  170 */     this._inputBuffer = null;
/*      */ 
/*      */     
/*  173 */     this._resultArray = null;
/*      */     
/*  175 */     if (this._hasSegments) {
/*  176 */       clearSegments();
/*      */     }
/*      */ 
/*      */     
/*  180 */     if (this._allocator != null && 
/*  181 */       this._currentSegment != null) {
/*      */       
/*  183 */       char[] buf = this._currentSegment;
/*  184 */       this._currentSegment = null;
/*  185 */       this._allocator.releaseCharBuffer(2, buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetWithEmpty() {
/*  196 */     this._inputStart = -1;
/*  197 */     this._currentSize = 0;
/*  198 */     this._inputLen = 0;
/*      */     
/*  200 */     this._inputBuffer = null;
/*  201 */     this._resultString = null;
/*  202 */     this._resultArray = null;
/*      */ 
/*      */     
/*  205 */     if (this._hasSegments) {
/*  206 */       clearSegments();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetWith(char ch) {
/*  220 */     this._inputStart = -1;
/*  221 */     this._inputLen = 0;
/*      */     
/*  223 */     this._resultString = null;
/*  224 */     this._resultArray = null;
/*      */     
/*  226 */     if (this._hasSegments) {
/*  227 */       clearSegments();
/*  228 */     } else if (this._currentSegment == null) {
/*  229 */       this._currentSegment = buf(1);
/*      */     } 
/*  231 */     this._currentSegment[0] = ch;
/*  232 */     this._currentSize = this._segmentSize = 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetWithShared(char[] buf, int offset, int len) {
/*  248 */     this._resultString = null;
/*  249 */     this._resultArray = null;
/*      */ 
/*      */     
/*  252 */     this._inputBuffer = buf;
/*  253 */     this._inputStart = offset;
/*  254 */     this._inputLen = len;
/*      */ 
/*      */     
/*  257 */     if (this._hasSegments) {
/*  258 */       clearSegments();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetWithCopy(char[] buf, int offset, int len) throws IOException {
/*  270 */     this._inputBuffer = null;
/*  271 */     this._inputStart = -1;
/*  272 */     this._inputLen = 0;
/*      */     
/*  274 */     this._resultString = null;
/*  275 */     this._resultArray = null;
/*      */ 
/*      */     
/*  278 */     if (this._hasSegments) {
/*  279 */       clearSegments();
/*  280 */     } else if (this._currentSegment == null) {
/*  281 */       this._currentSegment = buf(len);
/*      */     } 
/*  283 */     this._currentSize = this._segmentSize = 0;
/*  284 */     append(buf, offset, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetWithCopy(String text, int start, int len) throws IOException {
/*  296 */     this._inputBuffer = null;
/*  297 */     this._inputStart = -1;
/*  298 */     this._inputLen = 0;
/*      */     
/*  300 */     this._resultString = null;
/*  301 */     this._resultArray = null;
/*      */     
/*  303 */     if (this._hasSegments) {
/*  304 */       clearSegments();
/*  305 */     } else if (this._currentSegment == null) {
/*  306 */       this._currentSegment = buf(len);
/*      */     } 
/*  308 */     this._currentSize = this._segmentSize = 0;
/*  309 */     append(text, start, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetWithString(String value) throws IOException {
/*  318 */     this._inputBuffer = null;
/*  319 */     this._inputStart = -1;
/*  320 */     this._inputLen = 0;
/*      */     
/*  322 */     validateStringLength(value.length());
/*  323 */     this._resultString = value;
/*  324 */     this._resultArray = null;
/*      */     
/*  326 */     if (this._hasSegments) {
/*  327 */       clearSegments();
/*      */     }
/*  329 */     this._currentSize = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getBufferWithoutReset() {
/*  341 */     return this._currentSegment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char[] buf(int needed) {
/*  348 */     if (this._allocator != null) {
/*  349 */       return this._allocator.allocCharBuffer(2, needed);
/*      */     }
/*  351 */     return new char[Math.max(needed, 500)];
/*      */   }
/*      */ 
/*      */   
/*      */   private void clearSegments() {
/*  356 */     this._hasSegments = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  363 */     this._segments.clear();
/*  364 */     this._currentSize = this._segmentSize = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BufferRecycler bufferRecycler() {
/*  377 */     return this._allocator;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int size() {
/*  384 */     if (this._inputStart >= 0) {
/*  385 */       return this._inputLen;
/*      */     }
/*  387 */     if (this._resultArray != null) {
/*  388 */       return this._resultArray.length;
/*      */     }
/*  390 */     if (this._resultString != null) {
/*  391 */       return this._resultString.length();
/*      */     }
/*      */     
/*  394 */     return this._segmentSize + this._currentSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextOffset() {
/*  402 */     return (this._inputStart >= 0) ? this._inputStart : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasTextAsCharacters() {
/*  415 */     if (this._inputStart >= 0 || this._resultArray != null) return true;
/*      */     
/*  417 */     if (this._resultString != null) return false; 
/*  418 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getTextBuffer() throws IOException {
/*  432 */     if (this._inputStart >= 0) return this._inputBuffer; 
/*  433 */     if (this._resultArray != null) return this._resultArray; 
/*  434 */     if (this._resultString != null) {
/*  435 */       return this._resultArray = this._resultString.toCharArray();
/*      */     }
/*      */     
/*  438 */     if (!this._hasSegments) {
/*  439 */       return (this._currentSegment == null) ? NO_CHARS : this._currentSegment;
/*      */     }
/*      */     
/*  442 */     return contentsAsArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String contentsAsString() throws IOException {
/*  461 */     if (this._resultString == null)
/*      */     {
/*  463 */       if (this._resultArray != null) {
/*      */         
/*  465 */         this._resultString = new String(this._resultArray);
/*      */       
/*      */       }
/*  468 */       else if (this._inputStart >= 0) {
/*  469 */         if (this._inputLen < 1) {
/*  470 */           return this._resultString = "";
/*      */         }
/*  472 */         validateStringLength(this._inputLen);
/*  473 */         this._resultString = new String(this._inputBuffer, this._inputStart, this._inputLen);
/*      */       } else {
/*      */         
/*  476 */         int segLen = this._segmentSize;
/*  477 */         int currLen = this._currentSize;
/*      */         
/*  479 */         if (segLen == 0) {
/*  480 */           if (currLen == 0) {
/*  481 */             this._resultString = "";
/*      */           } else {
/*  483 */             validateStringLength(currLen);
/*  484 */             this._resultString = new String(this._currentSegment, 0, currLen);
/*      */           } 
/*      */         } else {
/*  487 */           int builderLen = segLen + currLen;
/*  488 */           if (builderLen < 0) {
/*  489 */             _reportBufferOverflow(segLen, currLen);
/*      */           }
/*  491 */           validateStringLength(builderLen);
/*  492 */           StringBuilder sb = new StringBuilder(builderLen);
/*      */ 
/*      */           
/*  495 */           if (this._segments != null) {
/*  496 */             for (int i = 0, len = this._segments.size(); i < len; i++) {
/*  497 */               char[] curr = this._segments.get(i);
/*  498 */               sb.append(curr, 0, curr.length);
/*      */             } 
/*      */           }
/*      */           
/*  502 */           sb.append(this._currentSegment, 0, this._currentSize);
/*  503 */           this._resultString = sb.toString();
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  509 */     return this._resultString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] contentsAsArray() throws IOException {
/*  517 */     char[] result = this._resultArray;
/*  518 */     if (result == null) {
/*  519 */       this._resultArray = result = resultArray();
/*      */     }
/*  521 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double contentsAsDouble(boolean useFastParser) throws NumberFormatException {
/*  548 */     if (this._resultString != null) {
/*  549 */       return NumberInput.parseDouble(this._resultString, useFastParser);
/*      */     }
/*  551 */     if (this._inputStart >= 0) {
/*  552 */       return NumberInput.parseDouble(this._inputBuffer, this._inputStart, this._inputLen, useFastParser);
/*      */     }
/*  554 */     if (!this._hasSegments) {
/*  555 */       return NumberInput.parseDouble(this._currentSegment, 0, this._currentSize, useFastParser);
/*      */     }
/*  557 */     if (this._resultArray != null) {
/*  558 */       return NumberInput.parseDouble(this._resultArray, useFastParser);
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/*  563 */       return NumberInput.parseDouble(contentsAsString(), useFastParser);
/*  564 */     } catch (IOException e) {
/*      */       
/*  566 */       throw new NumberFormatException(e.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public double contentsAsDouble() throws NumberFormatException {
/*  582 */     return contentsAsDouble(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public float contentsAsFloat() throws NumberFormatException {
/*  596 */     return contentsAsFloat(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float contentsAsFloat(boolean useFastParser) throws NumberFormatException {
/*  623 */     if (this._resultString != null) {
/*  624 */       return NumberInput.parseFloat(this._resultString, useFastParser);
/*      */     }
/*  626 */     if (this._inputStart >= 0) {
/*  627 */       return NumberInput.parseFloat(this._inputBuffer, this._inputStart, this._inputLen, useFastParser);
/*      */     }
/*  629 */     if (!this._hasSegments) {
/*  630 */       return NumberInput.parseFloat(this._currentSegment, 0, this._currentSize, useFastParser);
/*      */     }
/*  632 */     if (this._resultArray != null) {
/*  633 */       return NumberInput.parseFloat(this._resultArray, useFastParser);
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/*  638 */       return NumberInput.parseFloat(contentsAsString(), useFastParser);
/*  639 */     } catch (IOException e) {
/*      */       
/*  641 */       throw new NumberFormatException(e.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public BigDecimal contentsAsDecimal() throws NumberFormatException {
/*  650 */     return contentsAsDecimal(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal contentsAsDecimal(boolean useFastParser) throws NumberFormatException {
/*  662 */     if (this._resultString != null) {
/*  663 */       return NumberInput.parseBigDecimal(this._resultString, useFastParser);
/*      */     }
/*  665 */     if (this._inputStart >= 0) {
/*  666 */       return NumberInput.parseBigDecimal(this._inputBuffer, this._inputStart, this._inputLen, useFastParser);
/*      */     }
/*  668 */     if (!this._hasSegments) {
/*  669 */       return NumberInput.parseBigDecimal(this._currentSegment, 0, this._currentSize, useFastParser);
/*      */     }
/*  671 */     if (this._resultArray != null) {
/*  672 */       return NumberInput.parseBigDecimal(this._resultArray, useFastParser);
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/*  677 */       return NumberInput.parseBigDecimal(contentsAsArray(), useFastParser);
/*  678 */     } catch (IOException e) {
/*      */       
/*  680 */       throw new NumberFormatException(e.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int contentsAsInt(boolean neg) {
/*  700 */     if (this._inputStart >= 0 && this._inputBuffer != null) {
/*  701 */       if (neg) {
/*  702 */         return -NumberInput.parseInt(this._inputBuffer, this._inputStart + 1, this._inputLen - 1);
/*      */       }
/*  704 */       return NumberInput.parseInt(this._inputBuffer, this._inputStart, this._inputLen);
/*      */     } 
/*  706 */     if (neg) {
/*  707 */       return -NumberInput.parseInt(this._currentSegment, 1, this._currentSize - 1);
/*      */     }
/*  709 */     return NumberInput.parseInt(this._currentSegment, 0, this._currentSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long contentsAsLong(boolean neg) {
/*  728 */     if (this._inputStart >= 0 && this._inputBuffer != null) {
/*  729 */       if (neg) {
/*  730 */         return -NumberInput.parseLong(this._inputBuffer, this._inputStart + 1, this._inputLen - 1);
/*      */       }
/*  732 */       return NumberInput.parseLong(this._inputBuffer, this._inputStart, this._inputLen);
/*      */     } 
/*  734 */     if (neg) {
/*  735 */       return -NumberInput.parseLong(this._currentSegment, 1, this._currentSize - 1);
/*      */     }
/*  737 */     return NumberInput.parseLong(this._currentSegment, 0, this._currentSize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int contentsToWriter(Writer w) throws IOException {
/*  753 */     if (this._resultArray != null) {
/*  754 */       w.write(this._resultArray);
/*  755 */       return this._resultArray.length;
/*      */     } 
/*  757 */     if (this._resultString != null) {
/*  758 */       w.write(this._resultString);
/*  759 */       return this._resultString.length();
/*      */     } 
/*      */     
/*  762 */     if (this._inputStart >= 0) {
/*  763 */       int i = this._inputLen;
/*  764 */       if (i > 0) {
/*  765 */         w.write(this._inputBuffer, this._inputStart, i);
/*      */       }
/*  767 */       return i;
/*      */     } 
/*      */     
/*  770 */     int total = 0;
/*  771 */     if (this._segments != null) {
/*  772 */       for (int i = 0, end = this._segments.size(); i < end; i++) {
/*  773 */         char[] curr = this._segments.get(i);
/*  774 */         int currLen = curr.length;
/*  775 */         total += currLen;
/*  776 */         w.write(curr, 0, currLen);
/*      */       } 
/*      */     }
/*  779 */     int len = this._currentSize;
/*  780 */     if (len > 0) {
/*  781 */       total += len;
/*  782 */       w.write(this._currentSegment, 0, len);
/*      */     } 
/*  784 */     return total;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ensureNotShared() {
/*  798 */     if (this._inputStart >= 0) {
/*  799 */       unshare(16);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void append(char c) throws IOException {
/*  809 */     if (this._inputStart >= 0) {
/*  810 */       unshare(16);
/*      */     }
/*  812 */     this._resultString = null;
/*  813 */     this._resultArray = null;
/*      */ 
/*      */     
/*  816 */     char[] curr = this._currentSegment;
/*  817 */     if (this._currentSize >= curr.length) {
/*  818 */       validateAppend(1);
/*  819 */       expand();
/*  820 */       curr = this._currentSegment;
/*      */     } 
/*  822 */     curr[this._currentSize++] = c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void append(char[] c, int start, int len) throws IOException {
/*  834 */     if (this._inputStart >= 0) {
/*  835 */       unshare(len);
/*      */     }
/*  837 */     this._resultString = null;
/*  838 */     this._resultArray = null;
/*      */ 
/*      */     
/*  841 */     char[] curr = this._currentSegment;
/*  842 */     int max = curr.length - this._currentSize;
/*      */     
/*  844 */     if (max >= len) {
/*  845 */       System.arraycopy(c, start, curr, this._currentSize, len);
/*  846 */       this._currentSize += len;
/*      */       
/*      */       return;
/*      */     } 
/*  850 */     validateAppend(len);
/*      */ 
/*      */     
/*  853 */     if (max > 0) {
/*  854 */       System.arraycopy(c, start, curr, this._currentSize, max);
/*  855 */       start += max;
/*  856 */       len -= max;
/*      */     } 
/*      */ 
/*      */     
/*      */     do {
/*  861 */       expand();
/*  862 */       int amount = Math.min(this._currentSegment.length, len);
/*  863 */       System.arraycopy(c, start, this._currentSegment, 0, amount);
/*  864 */       this._currentSize += amount;
/*  865 */       start += amount;
/*  866 */       len -= amount;
/*  867 */     } while (len > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void append(String str, int offset, int len) throws IOException {
/*  879 */     if (this._inputStart >= 0) {
/*  880 */       unshare(len);
/*      */     }
/*  882 */     this._resultString = null;
/*  883 */     this._resultArray = null;
/*      */ 
/*      */     
/*  886 */     char[] curr = this._currentSegment;
/*  887 */     int max = curr.length - this._currentSize;
/*  888 */     if (max >= len) {
/*  889 */       str.getChars(offset, offset + len, curr, this._currentSize);
/*  890 */       this._currentSize += len;
/*      */       
/*      */       return;
/*      */     } 
/*  894 */     validateAppend(len);
/*      */ 
/*      */     
/*  897 */     if (max > 0) {
/*  898 */       str.getChars(offset, offset + max, curr, this._currentSize);
/*  899 */       len -= max;
/*  900 */       offset += max;
/*      */     } 
/*      */ 
/*      */     
/*      */     do {
/*  905 */       expand();
/*  906 */       int amount = Math.min(this._currentSegment.length, len);
/*  907 */       str.getChars(offset, offset + amount, this._currentSegment, 0);
/*  908 */       this._currentSize += amount;
/*  909 */       offset += amount;
/*  910 */       len -= amount;
/*  911 */     } while (len > 0);
/*      */   }
/*      */   
/*      */   private void validateAppend(int toAppend) throws IOException {
/*  915 */     int newTotalLength = this._segmentSize + this._currentSize + toAppend;
/*      */     
/*  917 */     if (newTotalLength < 0) {
/*  918 */       newTotalLength = Integer.MAX_VALUE;
/*      */     }
/*  920 */     validateStringLength(newTotalLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getCurrentSegment() {
/*  935 */     if (this._inputStart >= 0) {
/*  936 */       unshare(1);
/*      */     } else {
/*  938 */       char[] curr = this._currentSegment;
/*  939 */       if (curr == null) {
/*  940 */         this._currentSegment = buf(0);
/*  941 */       } else if (this._currentSize >= curr.length) {
/*      */         
/*  943 */         expand();
/*      */       } 
/*      */     } 
/*  946 */     return this._currentSegment;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] emptyAndGetCurrentSegment() {
/*  952 */     this._inputStart = -1;
/*  953 */     this._currentSize = 0;
/*  954 */     this._inputLen = 0;
/*      */     
/*  956 */     this._inputBuffer = null;
/*  957 */     this._resultString = null;
/*  958 */     this._resultArray = null;
/*      */ 
/*      */     
/*  961 */     if (this._hasSegments) {
/*  962 */       clearSegments();
/*      */     }
/*  964 */     char[] curr = this._currentSegment;
/*  965 */     if (curr == null) {
/*  966 */       this._currentSegment = curr = buf(0);
/*      */     }
/*  968 */     return curr;
/*      */   }
/*      */   
/*  971 */   public int getCurrentSegmentSize() { return this._currentSize; } public void setCurrentLength(int len) {
/*  972 */     this._currentSize = len;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String setCurrentAndReturn(int len) throws IOException {
/*  988 */     this._currentSize = len;
/*      */     
/*  990 */     if (this._segmentSize > 0) {
/*  991 */       return contentsAsString();
/*      */     }
/*      */     
/*  994 */     int currLen = this._currentSize;
/*  995 */     validateStringLength(currLen);
/*  996 */     String str = (currLen == 0) ? "" : new String(this._currentSegment, 0, currLen);
/*  997 */     this._resultString = str;
/*  998 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] finishCurrentSegment() throws IOException {
/* 1006 */     if (this._segments == null) {
/* 1007 */       this._segments = (ArrayList)new ArrayList<>();
/*      */     }
/* 1009 */     this._hasSegments = true;
/* 1010 */     this._segments.add(this._currentSegment);
/* 1011 */     int oldLen = this._currentSegment.length;
/* 1012 */     this._segmentSize += oldLen;
/* 1013 */     if (this._segmentSize < 0) {
/* 1014 */       _reportBufferOverflow(this._segmentSize - oldLen, oldLen);
/*      */     }
/* 1016 */     this._currentSize = 0;
/* 1017 */     validateStringLength(this._segmentSize);
/*      */ 
/*      */     
/* 1020 */     int newLen = oldLen + (oldLen >> 1);
/* 1021 */     if (newLen < 500) {
/* 1022 */       newLen = 500;
/* 1023 */     } else if (newLen > 65536) {
/* 1024 */       newLen = 65536;
/*      */     } 
/* 1026 */     char[] curr = carr(newLen);
/* 1027 */     this._currentSegment = curr;
/* 1028 */     return curr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String finishAndReturn(int lastSegmentEnd, boolean trimTrailingSpaces) throws IOException {
/* 1043 */     if (trimTrailingSpaces) {
/*      */       
/* 1045 */       int ptr = lastSegmentEnd - 1;
/* 1046 */       if (ptr < 0 || this._currentSegment[ptr] <= ' ') {
/* 1047 */         return _doTrim(ptr);
/*      */       }
/*      */     } 
/* 1050 */     this._currentSize = lastSegmentEnd;
/* 1051 */     return contentsAsString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private String _doTrim(int ptr) throws IOException {
/*      */     while (true) {
/* 1058 */       char[] curr = this._currentSegment;
/* 1059 */       while (--ptr >= 0) {
/* 1060 */         if (curr[ptr] > ' ') {
/* 1061 */           this._currentSize = ptr + 1;
/* 1062 */           return contentsAsString();
/*      */         } 
/*      */       } 
/*      */       
/* 1066 */       if (this._segments == null || this._segments.isEmpty()) {
/*      */         break;
/*      */       }
/* 1069 */       this._currentSegment = this._segments.remove(this._segments.size() - 1);
/* 1070 */       ptr = this._currentSegment.length;
/*      */     } 
/*      */     
/* 1073 */     this._currentSize = 0;
/* 1074 */     this._hasSegments = false;
/* 1075 */     return contentsAsString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] expandCurrentSegment() {
/* 1088 */     char[] curr = this._currentSegment;
/*      */     
/* 1090 */     int len = curr.length;
/* 1091 */     int newLen = len + (len >> 1);
/*      */     
/* 1093 */     if (newLen > 65536) {
/* 1094 */       newLen = len + (len >> 2);
/*      */     }
/* 1096 */     return this._currentSegment = Arrays.copyOf(curr, newLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] expandCurrentSegment(int minSize) {
/* 1111 */     char[] curr = this._currentSegment;
/* 1112 */     if (curr.length >= minSize) return curr; 
/* 1113 */     this._currentSegment = curr = Arrays.copyOf(curr, minSize);
/* 1114 */     return curr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*      */     try {
/* 1130 */       return contentsAsString();
/* 1131 */     } catch (IOException e) {
/* 1132 */       return "TextBuffer: Exception when reading contents";
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void unshare(int needExtra) {
/* 1148 */     int sharedLen = this._inputLen;
/* 1149 */     this._inputLen = 0;
/* 1150 */     char[] inputBuf = this._inputBuffer;
/* 1151 */     this._inputBuffer = null;
/* 1152 */     int start = this._inputStart;
/* 1153 */     this._inputStart = -1;
/*      */ 
/*      */     
/* 1156 */     int needed = sharedLen + needExtra;
/* 1157 */     if (this._currentSegment == null || needed > this._currentSegment.length) {
/* 1158 */       this._currentSegment = buf(needed);
/*      */     }
/* 1160 */     if (sharedLen > 0) {
/* 1161 */       System.arraycopy(inputBuf, start, this._currentSegment, 0, sharedLen);
/*      */     }
/* 1163 */     this._segmentSize = 0;
/* 1164 */     this._currentSize = sharedLen;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void expand() {
/* 1171 */     if (this._segments == null) {
/* 1172 */       this._segments = (ArrayList)new ArrayList<>();
/*      */     }
/* 1174 */     char[] curr = this._currentSegment;
/* 1175 */     this._hasSegments = true;
/* 1176 */     this._segments.add(curr);
/* 1177 */     this._segmentSize += curr.length;
/* 1178 */     if (this._segmentSize < 0) {
/* 1179 */       _reportBufferOverflow(this._segmentSize - curr.length, curr.length);
/*      */     }
/* 1181 */     this._currentSize = 0;
/* 1182 */     int oldLen = curr.length;
/*      */ 
/*      */     
/* 1185 */     int newLen = oldLen + (oldLen >> 1);
/* 1186 */     if (newLen < 500) {
/* 1187 */       newLen = 500;
/* 1188 */     } else if (newLen > 65536) {
/* 1189 */       newLen = 65536;
/*      */     } 
/* 1191 */     this._currentSegment = carr(newLen);
/*      */   }
/*      */ 
/*      */   
/*      */   private char[] resultArray() throws IOException {
/* 1196 */     if (this._resultString != null) {
/* 1197 */       return this._resultString.toCharArray();
/*      */     }
/*      */     
/* 1200 */     if (this._inputStart >= 0) {
/* 1201 */       int len = this._inputLen;
/* 1202 */       if (len < 1) {
/* 1203 */         return NO_CHARS;
/*      */       }
/* 1205 */       validateStringLength(len);
/* 1206 */       int start = this._inputStart;
/* 1207 */       if (start == 0) {
/* 1208 */         return Arrays.copyOf(this._inputBuffer, len);
/*      */       }
/* 1210 */       return Arrays.copyOfRange(this._inputBuffer, start, start + len);
/*      */     } 
/*      */     
/* 1213 */     int size = size();
/* 1214 */     if (size < 1) {
/* 1215 */       if (size < 0) {
/* 1216 */         _reportBufferOverflow(this._segmentSize, this._currentSize);
/*      */       }
/* 1218 */       return NO_CHARS;
/*      */     } 
/* 1220 */     validateStringLength(size);
/* 1221 */     int offset = 0;
/* 1222 */     char[] result = carr(size);
/* 1223 */     if (this._segments != null) {
/* 1224 */       for (int i = 0, len = this._segments.size(); i < len; i++) {
/* 1225 */         char[] curr = this._segments.get(i);
/* 1226 */         int currLen = curr.length;
/* 1227 */         System.arraycopy(curr, 0, result, offset, currLen);
/* 1228 */         offset += currLen;
/*      */       } 
/*      */     }
/* 1231 */     System.arraycopy(this._currentSegment, 0, result, offset, this._currentSize);
/* 1232 */     return result;
/*      */   }
/*      */   private char[] carr(int len) {
/* 1235 */     return new char[len];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportBufferOverflow(int prev, int curr) {
/* 1244 */     long newSize = prev + curr;
/* 1245 */     throw new IllegalStateException("TextBuffer overrun: size reached (" + newSize + ") exceeds maximum of " + 2147483647);
/*      */   }
/*      */   
/*      */   protected void validateStringLength(int length) throws IOException {}
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\cor\\util\TextBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */