package com.fasterxml.jackson.core.util;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;

public interface JsonGeneratorDecorator {
  JsonGenerator decorate(JsonFactory paramJsonFactory, JsonGenerator paramJsonGenerator);
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\cor\\util\JsonGeneratorDecorator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */