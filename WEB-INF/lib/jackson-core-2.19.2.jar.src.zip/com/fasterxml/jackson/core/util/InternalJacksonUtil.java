/*    */ package com.fasterxml.jackson.core.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class InternalJacksonUtil
/*    */ {
/*    */   public static int addOverflowSafe(int base, int length) {
/* 19 */     int result = base + length;
/* 20 */     if (result < 0) {
/* 21 */       return Integer.MAX_VALUE;
/*    */     }
/* 23 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\cor\\util\InternalJacksonUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */