/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.PrettyPrinter;
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import com.fasterxml.jackson.core.io.SerializedString;
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultPrettyPrinter
/*     */   implements PrettyPrinter, Instantiatable<DefaultPrettyPrinter>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   @Deprecated
/*  39 */   public static final SerializedString DEFAULT_ROOT_VALUE_SEPARATOR = new SerializedString(" ");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   protected Indenter _arrayIndenter = FixedSpaceIndenter.instance;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   protected Indenter _objectIndenter = DefaultIndenter.SYSTEM_LINEFEED_INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SerializableString _rootSeparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected boolean _spacesInObjectEntries = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected transient int _nesting;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Separators _separators;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String _objectFieldValueSeparatorWithSpaces;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String _objectEntrySeparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String _objectEmptySeparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String _arrayValueSeparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String _arrayEmptySeparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultPrettyPrinter() {
/* 141 */     this(DEFAULT_SEPARATORS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public DefaultPrettyPrinter(String rootSeparator) {
/* 156 */     this((rootSeparator == null) ? null : (SerializableString)new SerializedString(rootSeparator));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public DefaultPrettyPrinter(SerializableString rootSeparator) {
/* 168 */     this(DEFAULT_SEPARATORS.withRootSeparator(rootSeparator.getValue()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public DefaultPrettyPrinter(DefaultPrettyPrinter base, SerializableString rootSeparator) {
/* 178 */     this._arrayIndenter = base._arrayIndenter;
/* 179 */     this._objectIndenter = base._objectIndenter;
/* 180 */     this._spacesInObjectEntries = base._spacesInObjectEntries;
/* 181 */     this._nesting = base._nesting;
/*     */     
/* 183 */     this._separators = base._separators;
/* 184 */     this._objectFieldValueSeparatorWithSpaces = base._objectFieldValueSeparatorWithSpaces;
/* 185 */     this._objectEntrySeparator = base._objectEntrySeparator;
/* 186 */     this._objectEmptySeparator = base._objectEmptySeparator;
/* 187 */     this._arrayValueSeparator = base._arrayValueSeparator;
/* 188 */     this._arrayEmptySeparator = base._arrayEmptySeparator;
/*     */     
/* 190 */     this._rootSeparator = rootSeparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultPrettyPrinter(Separators separators) {
/* 198 */     this._separators = separators;
/*     */     
/* 200 */     this._rootSeparator = (separators.getRootSeparator() == null) ? null : (SerializableString)new SerializedString(separators.getRootSeparator());
/* 201 */     this._objectFieldValueSeparatorWithSpaces = separators.getObjectFieldValueSpacing().apply(separators
/* 202 */         .getObjectFieldValueSeparator());
/* 203 */     this._objectEntrySeparator = separators.getObjectEntrySpacing().apply(separators.getObjectEntrySeparator());
/* 204 */     this._objectEmptySeparator = separators.getObjectEmptySeparator();
/* 205 */     this._arrayValueSeparator = separators.getArrayValueSpacing().apply(separators.getArrayValueSeparator());
/* 206 */     this._arrayEmptySeparator = separators.getArrayEmptySeparator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultPrettyPrinter(DefaultPrettyPrinter base) {
/* 215 */     this._rootSeparator = base._rootSeparator;
/*     */     
/* 217 */     this._arrayIndenter = base._arrayIndenter;
/* 218 */     this._objectIndenter = base._objectIndenter;
/* 219 */     this._spacesInObjectEntries = base._spacesInObjectEntries;
/* 220 */     this._nesting = base._nesting;
/*     */     
/* 222 */     this._separators = base._separators;
/* 223 */     this._objectFieldValueSeparatorWithSpaces = base._objectFieldValueSeparatorWithSpaces;
/* 224 */     this._objectEntrySeparator = base._objectEntrySeparator;
/* 225 */     this._objectEmptySeparator = base._objectEmptySeparator;
/* 226 */     this._arrayValueSeparator = base._arrayValueSeparator;
/* 227 */     this._arrayEmptySeparator = base._arrayEmptySeparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public DefaultPrettyPrinter withRootSeparator(SerializableString rootSeparator) {
/* 236 */     if (this._rootSeparator == rootSeparator || (rootSeparator != null && rootSeparator
/* 237 */       .equals(this._rootSeparator))) {
/* 238 */       return this;
/*     */     }
/* 240 */     Separators separators = this._separators.withRootSeparator((rootSeparator == null) ? null : rootSeparator.getValue());
/* 241 */     return (new DefaultPrettyPrinter(this))
/* 242 */       .withSeparators(separators);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public DefaultPrettyPrinter withRootSeparator(String rootSeparator) {
/* 255 */     return withRootSeparator((rootSeparator == null) ? null : (SerializableString)new SerializedString(rootSeparator));
/*     */   }
/*     */   
/*     */   public void indentArraysWith(Indenter i) {
/* 259 */     this._arrayIndenter = (i == null) ? NopIndenter.instance : i;
/*     */   }
/*     */   
/*     */   public void indentObjectsWith(Indenter i) {
/* 263 */     this._objectIndenter = (i == null) ? NopIndenter.instance : i;
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultPrettyPrinter withArrayIndenter(Indenter i) {
/* 268 */     if (i == null) {
/* 269 */       i = NopIndenter.instance;
/*     */     }
/* 271 */     if (this._arrayIndenter == i) {
/* 272 */       return this;
/*     */     }
/* 274 */     DefaultPrettyPrinter pp = new DefaultPrettyPrinter(this);
/* 275 */     pp._arrayIndenter = i;
/* 276 */     return pp;
/*     */   }
/*     */ 
/*     */   
/*     */   public DefaultPrettyPrinter withObjectIndenter(Indenter i) {
/* 281 */     if (i == null) {
/* 282 */       i = NopIndenter.instance;
/*     */     }
/* 284 */     if (this._objectIndenter == i) {
/* 285 */       return this;
/*     */     }
/* 287 */     DefaultPrettyPrinter pp = new DefaultPrettyPrinter(this);
/* 288 */     pp._objectIndenter = i;
/* 289 */     return pp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public DefaultPrettyPrinter withSpacesInObjectEntries() {
/* 305 */     return _withSpaces(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public DefaultPrettyPrinter withoutSpacesInObjectEntries() {
/* 321 */     return _withSpaces(false);
/*     */   }
/*     */ 
/*     */   
/*     */   protected DefaultPrettyPrinter _withSpaces(boolean state) {
/* 326 */     if (this._spacesInObjectEntries == state) {
/* 327 */       return this;
/*     */     }
/*     */     
/* 330 */     Separators copy = this._separators.withObjectFieldValueSpacing(state ? Separators.Spacing.BOTH : Separators.Spacing.NONE);
/* 331 */     DefaultPrettyPrinter pp = withSeparators(copy);
/* 332 */     pp._spacesInObjectEntries = state;
/* 333 */     return pp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultPrettyPrinter withSeparators(Separators separators) {
/* 346 */     DefaultPrettyPrinter result = new DefaultPrettyPrinter(this);
/* 347 */     result._separators = separators;
/*     */     
/* 349 */     result._rootSeparator = (separators.getRootSeparator() == null) ? null : (SerializableString)new SerializedString(separators.getRootSeparator());
/* 350 */     result._objectFieldValueSeparatorWithSpaces = separators.getObjectFieldValueSpacing().apply(separators
/* 351 */         .getObjectFieldValueSeparator());
/* 352 */     result._objectEntrySeparator = separators.getObjectEntrySpacing().apply(separators.getObjectEntrySeparator());
/* 353 */     result._objectEmptySeparator = separators.getObjectEmptySeparator();
/* 354 */     result._arrayValueSeparator = separators.getArrayValueSpacing().apply(separators.getArrayValueSeparator());
/* 355 */     result._arrayEmptySeparator = separators.getArrayEmptySeparator();
/*     */     
/* 357 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultPrettyPrinter createInstance() {
/* 368 */     if (getClass() != DefaultPrettyPrinter.class) {
/* 369 */       throw new IllegalStateException("Failed `createInstance()`: " + getClass().getName() + " does not override method; it has to");
/*     */     }
/*     */     
/* 372 */     return new DefaultPrettyPrinter(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeRootValueSeparator(JsonGenerator g) throws IOException {
/* 384 */     if (this._rootSeparator != null) {
/* 385 */       g.writeRaw(this._rootSeparator);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeStartObject(JsonGenerator g) throws IOException {
/* 392 */     g.writeRaw('{');
/* 393 */     if (!this._objectIndenter.isInline()) {
/* 394 */       this._nesting++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void beforeObjectEntries(JsonGenerator g) throws IOException {
/* 401 */     this._objectIndenter.writeIndentation(g, this._nesting);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeObjectFieldValueSeparator(JsonGenerator g) throws IOException {
/* 416 */     g.writeRaw(this._objectFieldValueSeparatorWithSpaces);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeObjectEntrySeparator(JsonGenerator g) throws IOException {
/* 431 */     g.writeRaw(this._objectEntrySeparator);
/* 432 */     this._objectIndenter.writeIndentation(g, this._nesting);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeEndObject(JsonGenerator g, int nrOfEntries) throws IOException {
/* 438 */     if (!this._objectIndenter.isInline()) {
/* 439 */       this._nesting--;
/*     */     }
/* 441 */     if (nrOfEntries > 0) {
/* 442 */       this._objectIndenter.writeIndentation(g, this._nesting);
/*     */     } else {
/* 444 */       g.writeRaw(this._objectEmptySeparator);
/*     */     } 
/* 446 */     g.writeRaw('}');
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeStartArray(JsonGenerator g) throws IOException {
/* 452 */     if (!this._arrayIndenter.isInline()) {
/* 453 */       this._nesting++;
/*     */     }
/* 455 */     g.writeRaw('[');
/*     */   }
/*     */ 
/*     */   
/*     */   public void beforeArrayValues(JsonGenerator g) throws IOException {
/* 460 */     this._arrayIndenter.writeIndentation(g, this._nesting);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeArrayValueSeparator(JsonGenerator g) throws IOException {
/* 475 */     g.writeRaw(this._arrayValueSeparator);
/* 476 */     this._arrayIndenter.writeIndentation(g, this._nesting);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeEndArray(JsonGenerator g, int nrOfValues) throws IOException {
/* 482 */     if (!this._arrayIndenter.isInline()) {
/* 483 */       this._nesting--;
/*     */     }
/* 485 */     if (nrOfValues > 0) {
/* 486 */       this._arrayIndenter.writeIndentation(g, this._nesting);
/*     */     } else {
/* 488 */       g.writeRaw(this._arrayEmptySeparator);
/*     */     } 
/* 490 */     g.writeRaw(']');
/*     */   }
/*     */ 
/*     */   
/*     */   public static interface Indenter
/*     */   {
/*     */     void writeIndentation(JsonGenerator param1JsonGenerator, int param1Int) throws IOException;
/*     */ 
/*     */     
/*     */     boolean isInline();
/*     */   }
/*     */   
/*     */   public static class NopIndenter
/*     */     implements Indenter, Serializable
/*     */   {
/* 505 */     public static final NopIndenter instance = new NopIndenter();
/*     */ 
/*     */     
/*     */     public void writeIndentation(JsonGenerator g, int level) throws IOException {}
/*     */     
/*     */     public boolean isInline() {
/* 511 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FixedSpaceIndenter
/*     */     extends NopIndenter
/*     */   {
/* 521 */     public static final FixedSpaceIndenter instance = new FixedSpaceIndenter();
/*     */ 
/*     */ 
/*     */     
/*     */     public void writeIndentation(JsonGenerator g, int level) throws IOException {
/* 526 */       g.writeRaw(' ');
/*     */     }
/*     */     
/*     */     public boolean isInline() {
/* 530 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\cor\\util\DefaultPrettyPrinter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */