/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JsonRecyclerPools
/*     */ {
/*     */   public static RecyclerPool<BufferRecycler> defaultPool() {
/*  31 */     return threadLocalPool();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RecyclerPool<BufferRecycler> threadLocalPool() {
/*  41 */     return ThreadLocalPool.GLOBAL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RecyclerPool<BufferRecycler> nonRecyclingPool() {
/*  51 */     return NonRecyclingPool.GLOBAL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RecyclerPool<BufferRecycler> sharedConcurrentDequePool() {
/*  60 */     return ConcurrentDequePool.GLOBAL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RecyclerPool<BufferRecycler> newConcurrentDequePool() {
/*  69 */     return ConcurrentDequePool.construct();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static RecyclerPool<BufferRecycler> sharedLockFreePool() {
/*  82 */     return LockFreePool.GLOBAL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static RecyclerPool<BufferRecycler> newLockFreePool() {
/*  95 */     return LockFreePool.construct();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RecyclerPool<BufferRecycler> sharedBoundedPool() {
/* 104 */     return BoundedPool.GLOBAL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RecyclerPool<BufferRecycler> newBoundedPool(int size) {
/* 115 */     return BoundedPool.construct(size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ThreadLocalPool
/*     */     extends RecyclerPool.ThreadLocalPoolBase<BufferRecycler>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     protected static final ThreadLocalPool GLOBAL = new ThreadLocalPool();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BufferRecycler acquirePooled() {
/* 142 */       return BufferRecyclers.getBufferRecycler();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object readResolve() {
/* 147 */       return GLOBAL;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class NonRecyclingPool
/*     */     extends RecyclerPool.NonRecyclingPoolBase<BufferRecycler>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/* 159 */     protected static final NonRecyclingPool GLOBAL = new NonRecyclingPool();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BufferRecycler acquirePooled() {
/* 165 */       return new BufferRecycler();
/*     */     }
/*     */ 
/*     */     
/*     */     protected Object readResolve() {
/* 170 */       return GLOBAL;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ConcurrentDequePool
/*     */     extends RecyclerPool.ConcurrentDequePoolBase<BufferRecycler>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/* 183 */     protected static final ConcurrentDequePool GLOBAL = new ConcurrentDequePool(-1);
/*     */ 
/*     */ 
/*     */     
/*     */     protected ConcurrentDequePool(int serialization) {
/* 188 */       super(serialization);
/*     */     }
/*     */     
/*     */     public static ConcurrentDequePool construct() {
/* 192 */       return new ConcurrentDequePool(1);
/*     */     }
/*     */ 
/*     */     
/*     */     public BufferRecycler createPooled() {
/* 197 */       return new BufferRecycler();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Object readResolve() {
/* 204 */       return _resolveToShared(GLOBAL).orElseGet(() -> construct());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static class LockFreePool
/*     */     extends RecyclerPool.LockFreePoolBase<BufferRecycler>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 229 */     protected static final LockFreePool GLOBAL = new LockFreePool(-1);
/*     */ 
/*     */ 
/*     */     
/*     */     protected LockFreePool(int serialization) {
/* 234 */       super(serialization);
/*     */     }
/*     */     
/*     */     public static LockFreePool construct() {
/* 238 */       return new LockFreePool(1);
/*     */     }
/*     */ 
/*     */     
/*     */     public BufferRecycler createPooled() {
/* 243 */       return new BufferRecycler();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Object readResolve() {
/* 250 */       return _resolveToShared(GLOBAL).orElseGet(() -> construct());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class BoundedPool
/*     */     extends RecyclerPool.BoundedPoolBase<BufferRecycler>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/* 265 */     protected static final BoundedPool GLOBAL = new BoundedPool(-1);
/*     */ 
/*     */ 
/*     */     
/*     */     protected BoundedPool(int capacityAsId) {
/* 270 */       super(capacityAsId);
/*     */     }
/*     */     
/*     */     public static BoundedPool construct(int capacity) {
/* 274 */       if (capacity <= 0) {
/* 275 */         throw new IllegalArgumentException("capacity must be > 0, was: " + capacity);
/*     */       }
/* 277 */       return new BoundedPool(capacity);
/*     */     }
/*     */ 
/*     */     
/*     */     public BufferRecycler createPooled() {
/* 282 */       return new BufferRecycler();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Object readResolve() {
/* 289 */       return _resolveToShared(GLOBAL).orElseGet(() -> construct(this._serialization));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\cor\\util\JsonRecyclerPools.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */