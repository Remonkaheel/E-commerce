/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Separators
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final String DEFAULT_ROOT_VALUE_SEPARATOR = " ";
/*     */   public static final String DEFAULT_OBJECT_EMPTY_SEPARATOR = " ";
/*     */   public static final String DEFAULT_ARRAY_EMPTY_SEPARATOR = " ";
/*     */   private final char objectFieldValueSeparator;
/*     */   private final Spacing objectFieldValueSpacing;
/*     */   private final char objectEntrySeparator;
/*     */   private final Spacing objectEntrySpacing;
/*     */   private final String objectEmptySeparator;
/*     */   private final char arrayValueSeparator;
/*     */   private final Spacing arrayValueSpacing;
/*     */   private final String arrayEmptySeparator;
/*     */   private final String rootSeparator;
/*     */   
/*     */   public enum Spacing
/*     */   {
/*  49 */     NONE("", ""),
/*  50 */     BEFORE(" ", ""),
/*  51 */     AFTER("", " "),
/*  52 */     BOTH(" ", " ");
/*     */     
/*     */     private final String spacesBefore;
/*     */     private final String spacesAfter;
/*     */     
/*     */     Spacing(String spacesBefore, String spacesAfter) {
/*  58 */       this.spacesBefore = spacesBefore;
/*  59 */       this.spacesAfter = spacesAfter;
/*     */     }
/*     */     
/*     */     public String spacesBefore() {
/*  63 */       return this.spacesBefore;
/*     */     }
/*     */     
/*     */     public String spacesAfter() {
/*  67 */       return this.spacesAfter;
/*     */     }
/*     */     
/*     */     public String apply(char separator) {
/*  71 */       return this.spacesBefore + separator + this.spacesAfter;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Separators createDefaultInstance() {
/*  86 */     return new Separators();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Separators() {
/*  94 */     this(':', ',', ',');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Separators(char objectFieldValueSeparator, char objectEntrySeparator, char arrayValueSeparator) {
/* 106 */     this(" ", objectFieldValueSeparator, Spacing.BOTH, objectEntrySeparator, Spacing.NONE, " ", arrayValueSeparator, Spacing.NONE, " ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Separators(String rootSeparator, char objectFieldValueSeparator, Spacing objectFieldValueSpacing, char objectEntrySeparator, Spacing objectEntrySpacing, char arrayValueSeparator, Spacing arrayValueSpacing) {
/* 129 */     this(rootSeparator, objectFieldValueSeparator, objectFieldValueSpacing, objectEntrySeparator, objectEntrySpacing, " ", arrayValueSeparator, arrayValueSpacing, " ");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Separators(String rootSeparator, char objectFieldValueSeparator, Spacing objectFieldValueSpacing, char objectEntrySeparator, Spacing objectEntrySpacing, String objectEmptySeparator, char arrayValueSeparator, Spacing arrayValueSpacing, String arrayEmptySeparator) {
/* 151 */     this.rootSeparator = rootSeparator;
/* 152 */     this.objectFieldValueSeparator = objectFieldValueSeparator;
/* 153 */     this.objectFieldValueSpacing = objectFieldValueSpacing;
/* 154 */     this.objectEntrySeparator = objectEntrySeparator;
/* 155 */     this.objectEntrySpacing = objectEntrySpacing;
/* 156 */     this.objectEmptySeparator = objectEmptySeparator;
/* 157 */     this.arrayValueSeparator = arrayValueSeparator;
/* 158 */     this.arrayValueSpacing = arrayValueSpacing;
/* 159 */     this.arrayEmptySeparator = arrayEmptySeparator;
/*     */   }
/*     */   
/*     */   public Separators withRootSeparator(String sep) {
/* 163 */     return Objects.equals(this.rootSeparator, sep) ? this : new Separators(sep, this.objectFieldValueSeparator, this.objectFieldValueSpacing, this.objectEntrySeparator, this.objectEntrySpacing, this.objectEmptySeparator, this.arrayValueSeparator, this.arrayValueSpacing, this.arrayEmptySeparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Separators withObjectFieldValueSeparator(char sep) {
/* 170 */     return (this.objectFieldValueSeparator == sep) ? this : new Separators(this.rootSeparator, sep, this.objectFieldValueSpacing, this.objectEntrySeparator, this.objectEntrySpacing, this.objectEmptySeparator, this.arrayValueSeparator, this.arrayValueSpacing, this.arrayEmptySeparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Separators withObjectFieldValueSpacing(Spacing spacing) {
/* 182 */     return (this.objectFieldValueSpacing == spacing) ? this : new Separators(this.rootSeparator, this.objectFieldValueSeparator, spacing, this.objectEntrySeparator, this.objectEntrySpacing, this.objectEmptySeparator, this.arrayValueSeparator, this.arrayValueSpacing, this.arrayEmptySeparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Separators withObjectEntrySeparator(char sep) {
/* 189 */     return (this.objectEntrySeparator == sep) ? this : new Separators(this.rootSeparator, this.objectFieldValueSeparator, this.objectFieldValueSpacing, sep, this.objectEntrySpacing, this.objectEmptySeparator, this.arrayValueSeparator, this.arrayValueSpacing, this.arrayEmptySeparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Separators withObjectEntrySpacing(Spacing spacing) {
/* 201 */     return (this.objectEntrySpacing == spacing) ? this : new Separators(this.rootSeparator, this.objectFieldValueSeparator, this.objectFieldValueSpacing, this.objectEntrySeparator, spacing, this.objectEmptySeparator, this.arrayValueSeparator, this.arrayValueSpacing, this.arrayEmptySeparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Separators withObjectEmptySeparator(String sep) {
/* 213 */     return Objects.equals(this.objectEmptySeparator, sep) ? this : new Separators(this.rootSeparator, this.objectFieldValueSeparator, this.objectFieldValueSpacing, this.objectEntrySeparator, this.objectEntrySpacing, sep, this.arrayValueSeparator, this.arrayValueSpacing, this.arrayEmptySeparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Separators withArrayValueSeparator(char sep) {
/* 220 */     return (this.arrayValueSeparator == sep) ? this : new Separators(this.rootSeparator, this.objectFieldValueSeparator, this.objectFieldValueSpacing, this.objectEntrySeparator, this.objectEntrySpacing, this.objectEmptySeparator, sep, this.arrayValueSpacing, this.arrayEmptySeparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Separators withArrayValueSpacing(Spacing spacing) {
/* 232 */     return (this.arrayValueSpacing == spacing) ? this : new Separators(this.rootSeparator, this.objectFieldValueSeparator, this.objectFieldValueSpacing, this.objectEntrySeparator, this.objectEntrySpacing, this.objectEmptySeparator, this.arrayValueSeparator, spacing, this.arrayEmptySeparator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Separators withArrayEmptySeparator(String sep) {
/* 244 */     return Objects.equals(this.arrayEmptySeparator, sep) ? this : new Separators(this.rootSeparator, this.objectFieldValueSeparator, this.objectFieldValueSpacing, this.objectEntrySeparator, this.objectEntrySpacing, this.objectEmptySeparator, this.arrayValueSeparator, this.arrayValueSpacing, sep);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRootSeparator() {
/* 256 */     return this.rootSeparator;
/*     */   }
/*     */   
/*     */   public char getObjectFieldValueSeparator() {
/* 260 */     return this.objectFieldValueSeparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Spacing getObjectFieldValueSpacing() {
/* 269 */     return this.objectFieldValueSpacing;
/*     */   }
/*     */   
/*     */   public char getObjectEntrySeparator() {
/* 273 */     return this.objectEntrySeparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Spacing getObjectEntrySpacing() {
/* 282 */     return this.objectEntrySpacing;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getObjectEmptySeparator() {
/* 291 */     return this.objectEmptySeparator;
/*     */   }
/*     */   
/*     */   public char getArrayValueSeparator() {
/* 295 */     return this.arrayValueSeparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Spacing getArrayValueSpacing() {
/* 304 */     return this.arrayValueSpacing;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getArrayEmptySeparator() {
/* 313 */     return this.arrayEmptySeparator;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\cor\\util\Separators.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */