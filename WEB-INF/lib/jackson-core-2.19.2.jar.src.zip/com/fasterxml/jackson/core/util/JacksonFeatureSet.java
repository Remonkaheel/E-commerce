/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JacksonFeatureSet<F extends JacksonFeature>
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   protected int _enabled;
/*     */   
/*     */   protected JacksonFeatureSet(int bitmask) {
/*  26 */     this._enabled = bitmask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <F extends JacksonFeature> JacksonFeatureSet<F> fromDefaults(F[] allFeatures) {
/*  42 */     if (allFeatures.length > 31) {
/*  43 */       String desc = allFeatures[0].getClass().getName();
/*  44 */       throw new IllegalArgumentException(String.format("Can not use type `%s` with JacksonFeatureSet: too many entries (%d > 31)", new Object[] { desc, 
/*     */               
/*  46 */               Integer.valueOf(allFeatures.length) }));
/*     */     } 
/*     */     
/*  49 */     int flags = 0;
/*  50 */     for (F f : allFeatures) {
/*  51 */       if (f.enabledByDefault()) {
/*  52 */         flags |= f.getMask();
/*     */       }
/*     */     } 
/*  55 */     return new JacksonFeatureSet<>(flags);
/*     */   }
/*     */   
/*     */   public static <F extends JacksonFeature> JacksonFeatureSet<F> fromBitmask(int bitmask) {
/*  59 */     return new JacksonFeatureSet<>(bitmask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JacksonFeatureSet<F> with(F feature) {
/*  72 */     int newMask = this._enabled | feature.getMask();
/*  73 */     return (newMask == this._enabled) ? this : new JacksonFeatureSet(newMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JacksonFeatureSet<F> without(F feature) {
/*  86 */     int newMask = this._enabled & (feature.getMask() ^ 0xFFFFFFFF);
/*  87 */     return (newMask == this._enabled) ? this : new JacksonFeatureSet(newMask);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled(F feature) {
/*  98 */     return ((feature.getMask() & this._enabled) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int asBitmask() {
/* 107 */     return this._enabled;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\cor\\util\JacksonFeatureSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */