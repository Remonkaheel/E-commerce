/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Deque;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.ArrayBlockingQueue;
/*     */ import java.util.concurrent.ConcurrentLinkedDeque;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface RecyclerPool<P extends RecyclerPool.WithPool<P>>
/*     */   extends Serializable
/*     */ {
/*     */   default P acquireAndLinkPooled() {
/*  80 */     return acquirePooled().withPool(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   P acquirePooled();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void releasePooled(P paramP);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default boolean clear() {
/* 111 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default int pooledCount() {
/* 130 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static interface WithPool<P extends WithPool<P>>
/*     */   {
/*     */     P withPool(RecyclerPool<P> param1RecyclerPool);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void releaseToPool();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class ThreadLocalPoolBase<P extends WithPool<P>>
/*     */     implements RecyclerPool<P>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public P acquireAndLinkPooled() {
/* 161 */       return acquirePooled();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract P acquirePooled();
/*     */ 
/*     */ 
/*     */     
/*     */     public void releasePooled(P pooled) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public int pooledCount() {
/* 175 */       return -1;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean clear() {
/* 181 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class NonRecyclingPoolBase<P extends WithPool<P>>
/*     */     implements RecyclerPool<P>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public P acquireAndLinkPooled() {
/* 198 */       return acquirePooled();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract P acquirePooled();
/*     */ 
/*     */ 
/*     */     
/*     */     public void releasePooled(P pooled) {}
/*     */ 
/*     */     
/*     */     public int pooledCount() {
/* 211 */       return 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean clear() {
/* 222 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class StatefulImplBase<P extends WithPool<P>>
/*     */     implements RecyclerPool<P>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     public static final int SERIALIZATION_SHARED = -1;
/*     */ 
/*     */ 
/*     */     
/*     */     public static final int SERIALIZATION_NON_SHARED = 1;
/*     */ 
/*     */     
/*     */     protected final int _serialization;
/*     */ 
/*     */ 
/*     */     
/*     */     protected StatefulImplBase(int serialization) {
/* 248 */       this._serialization = serialization;
/*     */     }
/*     */     
/*     */     protected Optional<StatefulImplBase<P>> _resolveToShared(StatefulImplBase<P> shared) {
/* 252 */       if (this._serialization == -1) {
/* 253 */         return Optional.of(shared);
/*     */       }
/* 255 */       return Optional.empty();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract P createPooled();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class ConcurrentDequePoolBase<P extends WithPool<P>>
/*     */     extends StatefulImplBase<P>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     
/*     */     protected final transient Deque<P> pool;
/*     */ 
/*     */     
/*     */     protected ConcurrentDequePoolBase(int serialization) {
/* 275 */       super(serialization);
/* 276 */       this.pool = new ConcurrentLinkedDeque<>();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public P acquirePooled() {
/* 283 */       RecyclerPool.WithPool withPool = (RecyclerPool.WithPool)this.pool.pollFirst();
/* 284 */       if (withPool == null) {
/* 285 */         withPool = (RecyclerPool.WithPool)createPooled();
/*     */       }
/* 287 */       return (P)withPool;
/*     */     }
/*     */ 
/*     */     
/*     */     public void releasePooled(P pooled) {
/* 292 */       this.pool.offerLast(pooled);
/*     */     }
/*     */ 
/*     */     
/*     */     public int pooledCount() {
/* 297 */       return this.pool.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean clear() {
/* 302 */       this.pool.clear();
/* 303 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static abstract class LockFreePoolBase<P extends WithPool<P>>
/*     */     extends StatefulImplBase<P>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final transient AtomicReference<Node<P>> head;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected LockFreePoolBase(int serialization) {
/* 334 */       super(serialization);
/* 335 */       this.head = new AtomicReference<>();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public P acquirePooled() {
/* 346 */       for (int i = 0; i < 3; i++) {
/* 347 */         Node<P> currentHead = this.head.get();
/* 348 */         if (currentHead == null) {
/* 349 */           return createPooled();
/*     */         }
/* 351 */         if (this.head.compareAndSet(currentHead, currentHead.next)) {
/* 352 */           currentHead.next = null;
/* 353 */           return currentHead.value;
/*     */         } 
/*     */       } 
/* 356 */       return createPooled();
/*     */     }
/*     */ 
/*     */     
/*     */     public void releasePooled(P pooled) {
/* 361 */       Node<P> newHead = new Node<>(pooled);
/* 362 */       for (int i = 0; i < 3; i++) {
/* 363 */         newHead.next = this.head.get();
/* 364 */         if (this.head.compareAndSet(newHead.next, newHead)) {
/*     */           return;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int pooledCount() {
/* 372 */       int count = 0;
/* 373 */       for (Node<P> curr = this.head.get(); curr != null; curr = curr.next) {
/* 374 */         count++;
/*     */       }
/* 376 */       return count;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean clear() {
/* 382 */       this.head.set(null);
/* 383 */       return true;
/*     */     }
/*     */     
/*     */     protected static class Node<P> {
/*     */       final P value;
/*     */       Node<P> next;
/*     */       
/*     */       Node(P value) {
/* 391 */         this.value = value;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static abstract class BoundedPoolBase<P extends WithPool<P>>
/*     */     extends StatefulImplBase<P>
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */ 
/*     */     
/*     */     public static final int DEFAULT_CAPACITY = 100;
/*     */ 
/*     */ 
/*     */     
/*     */     private final transient ArrayBlockingQueue<P> pool;
/*     */ 
/*     */ 
/*     */     
/*     */     private final transient int capacity;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected BoundedPoolBase(int capacityAsId) {
/* 421 */       super(capacityAsId);
/* 422 */       this.capacity = (capacityAsId <= 0) ? 100 : capacityAsId;
/* 423 */       this.pool = new ArrayBlockingQueue<>(this.capacity);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public P acquirePooled() {
/* 430 */       RecyclerPool.WithPool withPool = (RecyclerPool.WithPool)this.pool.poll();
/* 431 */       if (withPool == null) {
/* 432 */         withPool = (RecyclerPool.WithPool)createPooled();
/*     */       }
/* 434 */       return (P)withPool;
/*     */     }
/*     */ 
/*     */     
/*     */     public void releasePooled(P pooled) {
/* 439 */       this.pool.offer(pooled);
/*     */     }
/*     */ 
/*     */     
/*     */     public int pooledCount() {
/* 444 */       return this.pool.size();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean clear() {
/* 449 */       this.pool.clear();
/* 450 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public int capacity() {
/* 456 */       return this.capacity;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\cor\\util\RecyclerPool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */