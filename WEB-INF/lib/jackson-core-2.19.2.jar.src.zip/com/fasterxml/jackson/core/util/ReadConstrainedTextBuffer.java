/*    */ package com.fasterxml.jackson.core.util;
/*    */ 
/*    */ import com.fasterxml.jackson.core.StreamReadConstraints;
/*    */ import com.fasterxml.jackson.core.exc.StreamConstraintsException;
/*    */ 
/*    */ public final class ReadConstrainedTextBuffer
/*    */   extends TextBuffer {
/*    */   private final StreamReadConstraints _streamReadConstraints;
/*    */   
/*    */   public ReadConstrainedTextBuffer(StreamReadConstraints streamReadConstraints, BufferRecycler bufferRecycler) {
/* 11 */     super(bufferRecycler);
/* 12 */     this._streamReadConstraints = streamReadConstraints;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void validateStringLength(int length) throws StreamConstraintsException {
/* 27 */     this._streamReadConstraints.validateStringLength(length);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\cor\\util\ReadConstrainedTextBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */