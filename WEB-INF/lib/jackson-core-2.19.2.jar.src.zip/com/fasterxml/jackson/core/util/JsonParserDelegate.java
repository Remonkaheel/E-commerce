/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.core.FormatSchema;
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.core.StreamReadConstraints;
/*     */ import com.fasterxml.jackson.core.Version;
/*     */ import com.fasterxml.jackson.core.async.NonBlockingInputFeeder;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ public class JsonParserDelegate
/*     */   extends JsonParser
/*     */ {
/*     */   protected JsonParser delegate;
/*     */   
/*     */   public JsonParserDelegate(JsonParser d) {
/*  27 */     this.delegate = d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCodec(ObjectCodec c) {
/*  36 */     this.delegate.setCodec(c); } public ObjectCodec getCodec() {
/*  37 */     return this.delegate.getCodec();
/*     */   }
/*     */   
/*     */   public JsonParser enable(JsonParser.Feature f) {
/*  41 */     this.delegate.enable(f);
/*  42 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParser disable(JsonParser.Feature f) {
/*  47 */     this.delegate.disable(f);
/*  48 */     return this;
/*     */   }
/*     */   
/*  51 */   public boolean isEnabled(JsonParser.Feature f) { return this.delegate.isEnabled(f); } public int getFeatureMask() {
/*  52 */     return this.delegate.getFeatureMask();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public JsonParser setFeatureMask(int mask) {
/*  57 */     this.delegate.setFeatureMask(mask);
/*  58 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParser overrideStdFeatures(int values, int mask) {
/*  63 */     this.delegate.overrideStdFeatures(values, mask);
/*  64 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonParser overrideFormatFeatures(int values, int mask) {
/*  69 */     this.delegate.overrideFormatFeatures(values, mask);
/*  70 */     return this;
/*     */   }
/*     */   
/*  73 */   public FormatSchema getSchema() { return this.delegate.getSchema(); }
/*  74 */   public void setSchema(FormatSchema schema) { this.delegate.setSchema(schema); }
/*  75 */   public boolean canUseSchema(FormatSchema schema) { return this.delegate.canUseSchema(schema); }
/*  76 */   public Version version() { return this.delegate.version(); } public Object getInputSource() {
/*  77 */     return this.delegate.getInputSource();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StreamReadConstraints streamReadConstraints() {
/*  87 */     return this.delegate.streamReadConstraints();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canParseAsync() {
/*  98 */     return this.delegate.canParseAsync();
/*     */   }
/*     */ 
/*     */   
/*     */   public NonBlockingInputFeeder getNonBlockingInputFeeder() {
/* 103 */     return this.delegate.getNonBlockingInputFeeder();
/*     */   }
/*     */ 
/*     */   
/*     */   public JacksonFeatureSet<StreamReadCapability> getReadCapabilities() {
/* 108 */     return this.delegate.getReadCapabilities();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean requiresCustomCodec() {
/* 113 */     return this.delegate.requiresCustomCodec();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 122 */     this.delegate.close(); } public boolean isClosed() {
/* 123 */     return this.delegate.isClosed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearCurrentToken() {
/* 131 */     this.delegate.clearCurrentToken();
/* 132 */   } public JsonToken getLastClearedToken() { return this.delegate.getLastClearedToken(); } public void overrideCurrentName(String name) {
/* 133 */     this.delegate.overrideCurrentName(name);
/*     */   }
/*     */   public void assignCurrentValue(Object v) {
/* 136 */     this.delegate.assignCurrentValue(v);
/*     */   }
/*     */   @Deprecated
/*     */   public void setCurrentValue(Object v) {
/* 140 */     this.delegate.setCurrentValue(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonStreamContext getParsingContext() {
/* 148 */     return this.delegate.getParsingContext();
/*     */   }
/* 150 */   public JsonToken currentToken() { return this.delegate.currentToken(); }
/* 151 */   public int currentTokenId() { return this.delegate.currentTokenId(); }
/* 152 */   public String currentName() throws IOException { return this.delegate.currentName(); } public Object currentValue() {
/* 153 */     return this.delegate.currentValue();
/*     */   }
/* 155 */   public JsonLocation currentLocation() { return this.delegate.currentLocation(); } public JsonLocation currentTokenLocation() {
/* 156 */     return this.delegate.currentTokenLocation();
/*     */   }
/*     */   public long currentTokenCount() {
/* 159 */     return this.delegate.currentTokenCount();
/*     */   }
/*     */   @Deprecated
/*     */   public JsonToken getCurrentToken() {
/* 163 */     return this.delegate.getCurrentToken();
/*     */   }
/*     */   @Deprecated
/*     */   public int getCurrentTokenId() {
/* 167 */     return this.delegate.getCurrentTokenId();
/*     */   }
/*     */   @Deprecated
/*     */   public String getCurrentName() throws IOException {
/* 171 */     return this.delegate.getCurrentName();
/*     */   }
/*     */   @Deprecated
/*     */   public Object getCurrentValue() {
/* 175 */     return this.delegate.getCurrentValue();
/*     */   }
/*     */   @Deprecated
/*     */   public JsonLocation getCurrentLocation() {
/* 179 */     return this.delegate.getCurrentLocation();
/*     */   }
/*     */   @Deprecated
/*     */   public JsonLocation getTokenLocation() {
/* 183 */     return this.delegate.getTokenLocation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasCurrentToken() {
/* 191 */     return this.delegate.hasCurrentToken();
/* 192 */   } public boolean hasTokenId(int id) { return this.delegate.hasTokenId(id); } public boolean hasToken(JsonToken t) {
/* 193 */     return this.delegate.hasToken(t);
/*     */   }
/* 195 */   public boolean isExpectedStartArrayToken() { return this.delegate.isExpectedStartArrayToken(); }
/* 196 */   public boolean isExpectedStartObjectToken() { return this.delegate.isExpectedStartObjectToken(); } public boolean isExpectedNumberIntToken() {
/* 197 */     return this.delegate.isExpectedNumberIntToken();
/*     */   } public boolean isNaN() throws IOException {
/* 199 */     return this.delegate.isNaN();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() throws IOException {
/* 207 */     return this.delegate.getText();
/* 208 */   } public boolean hasTextCharacters() { return this.delegate.hasTextCharacters(); }
/* 209 */   public char[] getTextCharacters() throws IOException { return this.delegate.getTextCharacters(); }
/* 210 */   public int getTextLength() throws IOException { return this.delegate.getTextLength(); }
/* 211 */   public int getTextOffset() throws IOException { return this.delegate.getTextOffset(); } public int getText(Writer writer) throws IOException, UnsupportedOperationException {
/* 212 */     return this.delegate.getText(writer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BigInteger getBigIntegerValue() throws IOException {
/* 221 */     return this.delegate.getBigIntegerValue();
/*     */   }
/*     */   public boolean getBooleanValue() throws IOException {
/* 224 */     return this.delegate.getBooleanValue();
/*     */   }
/*     */   public byte getByteValue() throws IOException {
/* 227 */     return this.delegate.getByteValue();
/*     */   }
/*     */   public short getShortValue() throws IOException {
/* 230 */     return this.delegate.getShortValue();
/*     */   }
/*     */   public BigDecimal getDecimalValue() throws IOException {
/* 233 */     return this.delegate.getDecimalValue();
/*     */   }
/*     */   public double getDoubleValue() throws IOException {
/* 236 */     return this.delegate.getDoubleValue();
/*     */   }
/*     */   public float getFloatValue() throws IOException {
/* 239 */     return this.delegate.getFloatValue();
/*     */   }
/*     */   public int getIntValue() throws IOException {
/* 242 */     return this.delegate.getIntValue();
/*     */   }
/*     */   public long getLongValue() throws IOException {
/* 245 */     return this.delegate.getLongValue();
/*     */   }
/*     */   public JsonParser.NumberType getNumberType() throws IOException {
/* 248 */     return this.delegate.getNumberType();
/*     */   }
/*     */   public JsonParser.NumberTypeFP getNumberTypeFP() throws IOException {
/* 251 */     return this.delegate.getNumberTypeFP();
/*     */   }
/*     */   public Number getNumberValue() throws IOException {
/* 254 */     return this.delegate.getNumberValue();
/*     */   }
/*     */   public Number getNumberValueExact() throws IOException {
/* 257 */     return this.delegate.getNumberValueExact();
/*     */   }
/*     */   public Object getNumberValueDeferred() throws IOException {
/* 260 */     return this.delegate.getNumberValueDeferred();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValueAsInt() throws IOException {
/* 268 */     return this.delegate.getValueAsInt();
/* 269 */   } public int getValueAsInt(int defaultValue) throws IOException { return this.delegate.getValueAsInt(defaultValue); }
/* 270 */   public long getValueAsLong() throws IOException { return this.delegate.getValueAsLong(); }
/* 271 */   public long getValueAsLong(long defaultValue) throws IOException { return this.delegate.getValueAsLong(defaultValue); }
/* 272 */   public double getValueAsDouble() throws IOException { return this.delegate.getValueAsDouble(); }
/* 273 */   public double getValueAsDouble(double defaultValue) throws IOException { return this.delegate.getValueAsDouble(defaultValue); }
/* 274 */   public boolean getValueAsBoolean() throws IOException { return this.delegate.getValueAsBoolean(); }
/* 275 */   public boolean getValueAsBoolean(boolean defaultValue) throws IOException { return this.delegate.getValueAsBoolean(defaultValue); }
/* 276 */   public String getValueAsString() throws IOException { return this.delegate.getValueAsString(); } public String getValueAsString(String defaultValue) throws IOException {
/* 277 */     return this.delegate.getValueAsString(defaultValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getEmbeddedObject() throws IOException {
/* 285 */     return this.delegate.getEmbeddedObject();
/* 286 */   } public byte[] getBinaryValue(Base64Variant b64variant) throws IOException { return this.delegate.getBinaryValue(b64variant); } public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/* 287 */     return this.delegate.readBinaryValue(b64variant, out);
/*     */   } public JsonToken nextToken() throws IOException {
/* 289 */     return this.delegate.nextToken();
/*     */   } public JsonToken nextValue() throws IOException {
/* 291 */     return this.delegate.nextValue();
/*     */   } public void finishToken() throws IOException {
/* 293 */     this.delegate.finishToken();
/*     */   }
/*     */   
/*     */   public JsonParser skipChildren() throws IOException {
/* 297 */     this.delegate.skipChildren();
/*     */     
/* 299 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canReadObjectId() {
/* 308 */     return this.delegate.canReadObjectId();
/* 309 */   } public boolean canReadTypeId() { return this.delegate.canReadTypeId(); }
/* 310 */   public Object getObjectId() throws IOException { return this.delegate.getObjectId(); } public Object getTypeId() throws IOException {
/* 311 */     return this.delegate.getTypeId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParser delegate() {
/* 326 */     return this.delegate;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\cor\\util\JsonParserDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */