/*     */ package com.fasterxml.jackson.core.util;
/*     */ 
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ThreadLocalBufferManager
/*     */ {
/*  26 */   private final ReentrantLock RELEASE_LOCK = new ReentrantLock();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   private final Map<SoftReference<BufferRecycler>, Boolean> _trackedRecyclers = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   private final ReferenceQueue<BufferRecycler> _refQueue = new ReferenceQueue<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ThreadLocalBufferManager instance() {
/*  57 */     return ThreadLocalBufferManagerHolder.manager;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int releaseBuffers() {
/*  67 */     int count = 0;
/*  68 */     this.RELEASE_LOCK.lock();
/*     */     
/*     */     try {
/*  71 */       removeSoftRefsClearedByGc();
/*  72 */       for (SoftReference<BufferRecycler> ref : this._trackedRecyclers.keySet()) {
/*  73 */         ref.clear();
/*  74 */         count++;
/*     */       } 
/*  76 */       this._trackedRecyclers.clear();
/*     */     } finally {
/*  78 */       this.RELEASE_LOCK.unlock();
/*     */     } 
/*  80 */     return count;
/*     */   }
/*     */ 
/*     */   
/*     */   public SoftReference<BufferRecycler> wrapAndTrack(BufferRecycler br) {
/*  85 */     SoftReference<BufferRecycler> newRef = new SoftReference<>(br, this._refQueue);
/*     */     
/*  87 */     this._trackedRecyclers.put(newRef, Boolean.valueOf(true));
/*     */     
/*  89 */     removeSoftRefsClearedByGc();
/*  90 */     return newRef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeSoftRefsClearedByGc() {
/*     */     SoftReference<?> clearedSoftRef;
/* 105 */     while ((clearedSoftRef = (SoftReference)this._refQueue.poll()) != null)
/*     */     {
/* 107 */       this._trackedRecyclers.remove(clearedSoftRef);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ThreadLocalBufferManagerHolder
/*     */   {
/* 116 */     static final ThreadLocalBufferManager manager = new ThreadLocalBufferManager();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\cor\\util\ThreadLocalBufferManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */