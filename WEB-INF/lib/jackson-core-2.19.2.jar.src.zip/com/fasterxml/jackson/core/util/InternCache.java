/*    */ package com.fasterxml.jackson.core.util;
/*    */ 
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.locks.ReentrantLock;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class InternCache
/*    */   extends ConcurrentHashMap<String, String>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final int DEFAULT_MAX_ENTRIES = 280;
/* 28 */   public static final InternCache instance = new InternCache();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   private final ReentrantLock lock = new ReentrantLock();
/*    */   public InternCache() {
/* 37 */     this(280, 0.8F, 4);
/*    */   }
/*    */   public InternCache(int maxSize, float loadFactor, int concurrency) {
/* 40 */     super(maxSize, loadFactor, concurrency);
/*    */   }
/*    */   
/*    */   public String intern(String input) {
/* 44 */     String result = get(input);
/* 45 */     if (result != null) return result;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 52 */     if (size() >= 280)
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 59 */       if (this.lock.tryLock()) {
/*    */         try {
/* 61 */           if (size() >= 280) {
/* 62 */             clear();
/*    */           }
/*    */         } finally {
/* 65 */           this.lock.unlock();
/*    */         } 
/*    */       }
/*    */     }
/* 69 */     result = input.intern();
/* 70 */     put(result, result);
/* 71 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\cor\\util\InternCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */