/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ErrorReportConfiguration
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final int DEFAULT_MAX_ERROR_TOKEN_LENGTH = 256;
/*     */   public static final int DEFAULT_MAX_RAW_CONTENT_LENGTH = 500;
/*     */   protected final int _maxErrorTokenLength;
/*     */   protected final int _maxRawContentLength;
/*  47 */   private static ErrorReportConfiguration DEFAULT = new ErrorReportConfiguration(256, 500);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void overrideDefaultErrorReportConfiguration(ErrorReportConfiguration errorReportConfiguration) {
/*  67 */     if (errorReportConfiguration == null) {
/*  68 */       DEFAULT = new ErrorReportConfiguration(256, 500);
/*     */     } else {
/*  70 */       DEFAULT = errorReportConfiguration;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private int maxErrorTokenLength;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int maxRawContentLength;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder maxErrorTokenLength(int maxErrorTokenLength) {
/*  92 */       ErrorReportConfiguration.validateMaxErrorTokenLength(maxErrorTokenLength);
/*  93 */       this.maxErrorTokenLength = maxErrorTokenLength;
/*  94 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder maxRawContentLength(int maxRawContentLength) {
/* 105 */       ErrorReportConfiguration.validateMaxRawContentLength(maxRawContentLength);
/* 106 */       this.maxRawContentLength = maxRawContentLength;
/* 107 */       return this;
/*     */     }
/*     */     
/*     */     Builder() {
/* 111 */       this(256, 500);
/*     */     }
/*     */     
/*     */     Builder(int maxErrorTokenLength, int maxRawContentLength) {
/* 115 */       this.maxErrorTokenLength = maxErrorTokenLength;
/* 116 */       this.maxRawContentLength = maxRawContentLength;
/*     */     }
/*     */     
/*     */     Builder(ErrorReportConfiguration src) {
/* 120 */       this.maxErrorTokenLength = src._maxErrorTokenLength;
/* 121 */       this.maxRawContentLength = src._maxRawContentLength;
/*     */     }
/*     */     
/*     */     public ErrorReportConfiguration build() {
/* 125 */       return new ErrorReportConfiguration(this.maxErrorTokenLength, this.maxRawContentLength);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ErrorReportConfiguration(int maxErrorTokenLength, int maxRawContentLength) {
/* 136 */     this._maxErrorTokenLength = maxErrorTokenLength;
/* 137 */     this._maxRawContentLength = maxRawContentLength;
/*     */   }
/*     */   
/*     */   public static Builder builder() {
/* 141 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ErrorReportConfiguration defaults() {
/* 149 */     return DEFAULT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder rebuild() {
/* 156 */     return new Builder(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxErrorTokenLength() {
/* 172 */     return this._maxErrorTokenLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxRawContentLength() {
/* 182 */     return this._maxRawContentLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void validateMaxErrorTokenLength(int maxErrorTokenLength) throws IllegalArgumentException {
/* 198 */     if (maxErrorTokenLength < 0) {
/* 199 */       throw new IllegalArgumentException(
/* 200 */           String.format("Value of maxErrorTokenLength (%d) cannot be negative", new Object[] { Integer.valueOf(maxErrorTokenLength) }));
/*     */     }
/*     */   }
/*     */   
/*     */   static void validateMaxRawContentLength(int maxRawContentLength) {
/* 205 */     if (maxRawContentLength < 0)
/* 206 */       throw new IllegalArgumentException(
/* 207 */           String.format("Value of maxRawContentLength (%d) cannot be negative", new Object[] { Integer.valueOf(maxRawContentLength) })); 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\ErrorReportConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */