/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum JsonToken
/*     */ {
/*  31 */   NOT_AVAILABLE(null, -1),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  37 */   START_OBJECT("{", 1),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   END_OBJECT("}", 2),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   START_ARRAY("[", 3),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   END_ARRAY("]", 4),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   FIELD_NAME(null, 5),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   VALUE_EMBEDDED_OBJECT(null, 12),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   VALUE_STRING(null, 6),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   VALUE_NUMBER_INT(null, 7),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   VALUE_NUMBER_FLOAT(null, 8),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   VALUE_TRUE("true", 9),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   VALUE_FALSE("false", 10),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   VALUE_NULL("null", 11);
/*     */ 
/*     */   
/*     */   final String _serialized;
/*     */ 
/*     */   
/*     */   final char[] _serializedChars;
/*     */ 
/*     */   
/*     */   final byte[] _serializedBytes;
/*     */ 
/*     */   
/*     */   final int _id;
/*     */   
/*     */   final boolean _isStructStart;
/*     */   
/*     */   final boolean _isStructEnd;
/*     */   
/*     */   final boolean _isNumber;
/*     */   
/*     */   final boolean _isBoolean;
/*     */   
/*     */   final boolean _isScalar;
/*     */ 
/*     */   
/*     */   JsonToken(String token, int id) {
/* 145 */     if (token == null) {
/* 146 */       this._serialized = null;
/* 147 */       this._serializedChars = null;
/* 148 */       this._serializedBytes = null;
/*     */     } else {
/* 150 */       this._serialized = token;
/* 151 */       this._serializedChars = token.toCharArray();
/*     */       
/* 153 */       int len = this._serializedChars.length;
/* 154 */       this._serializedBytes = new byte[len];
/* 155 */       for (int i = 0; i < len; i++) {
/* 156 */         this._serializedBytes[i] = (byte)this._serializedChars[i];
/*     */       }
/*     */     } 
/* 159 */     this._id = id;
/*     */     
/* 161 */     this._isBoolean = (id == 10 || id == 9);
/* 162 */     this._isNumber = (id == 7 || id == 8);
/*     */     
/* 164 */     this._isStructStart = (id == 1 || id == 3);
/* 165 */     this._isStructEnd = (id == 2 || id == 4);
/*     */     
/* 167 */     this._isScalar = (!this._isStructStart && !this._isStructEnd && id != 5 && id != -1);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int id() {
/* 172 */     return this._id;
/*     */   }
/* 174 */   public final String asString() { return this._serialized; }
/* 175 */   public final char[] asCharArray() { return this._serializedChars; } public final byte[] asByteArray() {
/* 176 */     return this._serializedBytes;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isNumeric() {
/* 182 */     return this._isNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isStructStart() {
/* 195 */     return this._isStructStart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isStructEnd() {
/* 208 */     return this._isStructEnd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isScalarValue() {
/* 219 */     return this._isScalar;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isBoolean() {
/* 225 */     return this._isBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String valueDescFor(JsonToken t) {
/* 238 */     if (t == null) {
/* 239 */       return "<end of input>";
/*     */     }
/* 241 */     switch (t) {
/*     */       case START_OBJECT:
/*     */       case END_OBJECT:
/*     */       case FIELD_NAME:
/* 245 */         return "Object value";
/*     */       
/*     */       case START_ARRAY:
/*     */       case END_ARRAY:
/* 249 */         return "Array value";
/*     */       
/*     */       case VALUE_FALSE:
/*     */       case VALUE_TRUE:
/* 253 */         return "Boolean value";
/*     */       
/*     */       case VALUE_EMBEDDED_OBJECT:
/* 256 */         return "Embedded Object value";
/*     */       
/*     */       case VALUE_NUMBER_FLOAT:
/* 259 */         return "Floating-point value";
/*     */       case VALUE_NUMBER_INT:
/* 261 */         return "Integer value";
/*     */       case VALUE_STRING:
/* 263 */         return "String value";
/*     */       
/*     */       case VALUE_NULL:
/* 266 */         return "Null value";
/*     */     } 
/*     */ 
/*     */     
/* 270 */     return "[Unavailable value]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\JsonToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */