/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import com.fasterxml.jackson.core.exc.StreamConstraintsException;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamWriteConstraints
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   public static final int DEFAULT_MAX_DEPTH = 1000;
/*     */   protected final int _maxNestingDepth;
/*  33 */   private static StreamWriteConstraints DEFAULT = new StreamWriteConstraints(1000);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void overrideDefaultStreamWriteConstraints(StreamWriteConstraints streamWriteConstraints) {
/*  52 */     if (streamWriteConstraints == null) {
/*  53 */       DEFAULT = new StreamWriteConstraints(1000);
/*     */     } else {
/*  55 */       DEFAULT = streamWriteConstraints;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Builder
/*     */   {
/*     */     private int maxNestingDepth;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Builder maxNestingDepth(int maxNestingDepth) {
/*  72 */       if (maxNestingDepth < 0) {
/*  73 */         throw new IllegalArgumentException("Cannot set maxNestingDepth to a negative value");
/*     */       }
/*  75 */       this.maxNestingDepth = maxNestingDepth;
/*  76 */       return this;
/*     */     }
/*     */     
/*     */     Builder() {
/*  80 */       this(1000);
/*     */     }
/*     */     
/*     */     Builder(int maxNestingDepth) {
/*  84 */       this.maxNestingDepth = maxNestingDepth;
/*     */     }
/*     */     
/*     */     Builder(StreamWriteConstraints src) {
/*  88 */       this.maxNestingDepth = src._maxNestingDepth;
/*     */     }
/*     */     
/*     */     public StreamWriteConstraints build() {
/*  92 */       return new StreamWriteConstraints(this.maxNestingDepth);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StreamWriteConstraints(int maxNestingDepth) {
/* 103 */     this._maxNestingDepth = maxNestingDepth;
/*     */   }
/*     */   
/*     */   public static Builder builder() {
/* 107 */     return new Builder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StreamWriteConstraints defaults() {
/* 115 */     return DEFAULT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Builder rebuild() {
/* 123 */     return new Builder(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxNestingDepth() {
/* 139 */     return this._maxNestingDepth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void validateNestingDepth(int depth) throws StreamConstraintsException {
/* 161 */     if (depth > this._maxNestingDepth) {
/* 162 */       throw _constructException("Document nesting depth (%d) exceeds the maximum allowed (%d, from %s)", new Object[] {
/*     */             
/* 164 */             Integer.valueOf(depth), Integer.valueOf(this._maxNestingDepth), 
/* 165 */             _constrainRef("getMaxNestingDepth")
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StreamConstraintsException _constructException(String msgTemplate, Object... args) throws StreamConstraintsException {
/* 177 */     throw new StreamConstraintsException(String.format(msgTemplate, args));
/*     */   }
/*     */ 
/*     */   
/*     */   protected String _constrainRef(String method) {
/* 182 */     return "`StreamWriteConstraints." + method + "()`";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\StreamWriteConstraints.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */