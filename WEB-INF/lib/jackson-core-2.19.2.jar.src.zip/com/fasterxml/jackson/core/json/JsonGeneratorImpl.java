/*     */ package com.fasterxml.jackson.core.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import com.fasterxml.jackson.core.StreamWriteCapability;
/*     */ import com.fasterxml.jackson.core.StreamWriteConstraints;
/*     */ import com.fasterxml.jackson.core.Version;
/*     */ import com.fasterxml.jackson.core.base.GeneratorBase;
/*     */ import com.fasterxml.jackson.core.io.CharTypes;
/*     */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*     */ import com.fasterxml.jackson.core.io.IOContext;
/*     */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*     */ import com.fasterxml.jackson.core.util.VersionUtil;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JsonGeneratorImpl
/*     */   extends GeneratorBase
/*     */ {
/*  31 */   protected static final int[] sOutputEscapes = CharTypes.get7BitOutputEscapes();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   protected static final JacksonFeatureSet<StreamWriteCapability> JSON_WRITE_CAPABILITIES = DEFAULT_TEXTUAL_WRITE_CAPABILITIES;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final StreamWriteConstraints _streamWriteConstraints;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   protected int[] _outputEscapes = sOutputEscapes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _maximumNonEscapedChar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CharacterEscapes _characterEscapes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   protected SerializableString _rootValueSeparator = JsonFactory.DEFAULT_ROOT_VALUE_SEPARATOR;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _cfgUnqNames;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _cfgWriteHexUppercase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonGeneratorImpl(IOContext ctxt, int features, ObjectCodec codec) {
/* 124 */     super(features, codec, ctxt);
/* 125 */     this._streamWriteConstraints = ctxt.streamWriteConstraints();
/* 126 */     if (JsonGenerator.Feature.ESCAPE_NON_ASCII.enabledIn(features))
/*     */     {
/* 128 */       this._maximumNonEscapedChar = 127;
/*     */     }
/* 130 */     this._cfgWriteHexUppercase = JsonGenerator.Feature.WRITE_HEX_UPPER_CASE.enabledIn(features);
/* 131 */     this._cfgUnqNames = !JsonGenerator.Feature.QUOTE_FIELD_NAMES.enabledIn(features);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Version version() {
/* 142 */     return VersionUtil.versionFor(getClass());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StreamWriteConstraints streamWriteConstraints() {
/* 153 */     return this._streamWriteConstraints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonGenerator enable(JsonGenerator.Feature f) {
/* 165 */     super.enable(f);
/* 166 */     if (f == JsonGenerator.Feature.QUOTE_FIELD_NAMES) {
/* 167 */       this._cfgUnqNames = false;
/* 168 */     } else if (f == JsonGenerator.Feature.WRITE_HEX_UPPER_CASE) {
/* 169 */       this._cfgWriteHexUppercase = true;
/*     */     } 
/* 171 */     return (JsonGenerator)this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonGenerator disable(JsonGenerator.Feature f) {
/* 177 */     super.disable(f);
/* 178 */     if (f == JsonGenerator.Feature.QUOTE_FIELD_NAMES) {
/* 179 */       this._cfgUnqNames = true;
/* 180 */     } else if (f == JsonGenerator.Feature.WRITE_HEX_UPPER_CASE) {
/* 181 */       this._cfgWriteHexUppercase = false;
/*     */     } 
/* 183 */     return (JsonGenerator)this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _checkStdFeatureChanges(int newFeatureFlags, int changedFeatures) {
/* 189 */     super._checkStdFeatureChanges(newFeatureFlags, changedFeatures);
/* 190 */     this._cfgUnqNames = !JsonGenerator.Feature.QUOTE_FIELD_NAMES.enabledIn(newFeatureFlags);
/* 191 */     this._cfgWriteHexUppercase = JsonGenerator.Feature.WRITE_HEX_UPPER_CASE.enabledIn(newFeatureFlags);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonGenerator setHighestNonEscapedChar(int charCode) {
/* 196 */     this._maximumNonEscapedChar = (charCode < 0) ? 0 : charCode;
/* 197 */     return (JsonGenerator)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHighestEscapedChar() {
/* 202 */     return this._maximumNonEscapedChar;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonGenerator setCharacterEscapes(CharacterEscapes esc) {
/* 208 */     this._characterEscapes = esc;
/* 209 */     if (esc == null) {
/* 210 */       this._outputEscapes = sOutputEscapes;
/*     */     } else {
/* 212 */       this._outputEscapes = esc.getEscapeCodesForAscii();
/*     */     } 
/* 214 */     return (JsonGenerator)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharacterEscapes getCharacterEscapes() {
/* 223 */     return this._characterEscapes;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonGenerator setRootValueSeparator(SerializableString sep) {
/* 228 */     this._rootValueSeparator = sep;
/* 229 */     return (JsonGenerator)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public JacksonFeatureSet<StreamWriteCapability> getWriteCapabilities() {
/* 234 */     return JSON_WRITE_CAPABILITIES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _verifyPrettyValueWrite(String typeMsg, int status) throws IOException {
/* 246 */     switch (status) {
/*     */       case 1:
/* 248 */         this._cfgPrettyPrinter.writeArrayValueSeparator((JsonGenerator)this);
/*     */         return;
/*     */       case 2:
/* 251 */         this._cfgPrettyPrinter.writeObjectFieldValueSeparator((JsonGenerator)this);
/*     */         return;
/*     */       case 3:
/* 254 */         this._cfgPrettyPrinter.writeRootValueSeparator((JsonGenerator)this);
/*     */         return;
/*     */       
/*     */       case 0:
/* 258 */         if (this._writeContext.inArray()) {
/* 259 */           this._cfgPrettyPrinter.beforeArrayValues((JsonGenerator)this);
/* 260 */         } else if (this._writeContext.inObject()) {
/* 261 */           this._cfgPrettyPrinter.beforeObjectEntries((JsonGenerator)this);
/*     */         } 
/*     */         return;
/*     */       case 5:
/* 265 */         _reportCantWriteValueExpectName(typeMsg);
/*     */         return;
/*     */     } 
/* 268 */     _throwInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _reportCantWriteValueExpectName(String typeMsg) throws IOException {
/* 275 */     _reportError(String.format("Can not %s, expecting field name (context: %s)", new Object[] { typeMsg, this._writeContext
/* 276 */             .typeDesc() }));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\json\JsonGeneratorImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */