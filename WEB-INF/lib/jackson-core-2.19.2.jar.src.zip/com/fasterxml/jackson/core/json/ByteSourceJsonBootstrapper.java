/*     */ package com.fasterxml.jackson.core.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonEncoding;
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.core.format.InputAccessor;
/*     */ import com.fasterxml.jackson.core.format.MatchStrength;
/*     */ import com.fasterxml.jackson.core.io.IOContext;
/*     */ import com.fasterxml.jackson.core.io.MergedStream;
/*     */ import com.fasterxml.jackson.core.io.UTF32Reader;
/*     */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*     */ import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;
/*     */ import com.fasterxml.jackson.core.util.VersionUtil;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.CharConversionException;
/*     */ import java.io.DataInput;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ByteSourceJsonBootstrapper
/*     */ {
/*     */   public static final byte UTF8_BOM_1 = -17;
/*     */   public static final byte UTF8_BOM_2 = -69;
/*     */   public static final byte UTF8_BOM_3 = -65;
/*     */   private static final int STRING_READER_BYTE_ARRAY_LENGTH_LIMIT = 8192;
/*     */   private final IOContext _context;
/*     */   private final InputStream _in;
/*     */   private final byte[] _inputBuffer;
/*     */   private int _inputPtr;
/*     */   private int _inputEnd;
/*     */   private final boolean _bufferRecyclable;
/*     */   private boolean _bigEndian = true;
/*     */   private int _bytesPerChar;
/*     */   
/*     */   public ByteSourceJsonBootstrapper(IOContext ctxt, InputStream in) {
/*  92 */     this._context = ctxt;
/*  93 */     this._in = in;
/*  94 */     this._inputBuffer = ctxt.allocReadIOBuffer();
/*  95 */     this._inputEnd = this._inputPtr = 0;
/*     */     
/*  97 */     this._bufferRecyclable = true;
/*     */   }
/*     */   
/*     */   public ByteSourceJsonBootstrapper(IOContext ctxt, byte[] inputBuffer, int inputStart, int inputLen) {
/* 101 */     this._context = ctxt;
/* 102 */     this._in = null;
/* 103 */     this._inputBuffer = inputBuffer;
/* 104 */     this._inputPtr = inputStart;
/* 105 */     this._inputEnd = inputStart + inputLen;
/*     */ 
/*     */     
/* 108 */     this._bufferRecyclable = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonEncoding detectEncoding() throws IOException {
/*     */     JsonEncoding enc;
/* 128 */     boolean foundEncoding = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     if (ensureLoaded(4)) {
/* 138 */       int quad = this._inputBuffer[this._inputPtr] << 24 | (this._inputBuffer[this._inputPtr + 1] & 0xFF) << 16 | (this._inputBuffer[this._inputPtr + 2] & 0xFF) << 8 | this._inputBuffer[this._inputPtr + 3] & 0xFF;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 143 */       if (handleBOM(quad)) {
/* 144 */         foundEncoding = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 152 */       else if (checkUTF32(quad)) {
/* 153 */         foundEncoding = true;
/* 154 */       } else if (checkUTF16(quad >>> 16)) {
/* 155 */         foundEncoding = true;
/*     */       }
/*     */     
/* 158 */     } else if (ensureLoaded(2)) {
/* 159 */       int i16 = (this._inputBuffer[this._inputPtr] & 0xFF) << 8 | this._inputBuffer[this._inputPtr + 1] & 0xFF;
/*     */       
/* 161 */       if (checkUTF16(i16)) {
/* 162 */         foundEncoding = true;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     if (!foundEncoding)
/* 170 */     { enc = JsonEncoding.UTF8; }
/*     */     else
/* 172 */     { switch (this._bytesPerChar) { case 1:
/* 173 */           enc = JsonEncoding.UTF8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 183 */           this._context.setEncoding(enc);
/* 184 */           return enc;case 2: enc = this._bigEndian ? JsonEncoding.UTF16_BE : JsonEncoding.UTF16_LE; this._context.setEncoding(enc); return enc;case 4: enc = this._bigEndian ? JsonEncoding.UTF32_BE : JsonEncoding.UTF32_LE; this._context.setEncoding(enc); return enc; }  return (JsonEncoding)VersionUtil.throwInternalReturnAny(); }  this._context.setEncoding(enc); return enc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int skipUTF8BOM(DataInput input) throws IOException {
/* 201 */     int b = input.readUnsignedByte();
/* 202 */     if (b != 239) {
/* 203 */       return b;
/*     */     }
/*     */ 
/*     */     
/* 207 */     b = input.readUnsignedByte();
/* 208 */     if (b != 187) {
/* 209 */       throw new IOException("Unexpected byte 0x" + Integer.toHexString(b) + " following 0xEF; should get 0xBB as part of UTF-8 BOM");
/*     */     }
/*     */     
/* 212 */     b = input.readUnsignedByte();
/* 213 */     if (b != 191) {
/* 214 */       throw new IOException("Unexpected byte 0x" + Integer.toHexString(b) + " following 0xEF 0xBB; should get 0xBF as part of UTF-8 BOM");
/*     */     }
/*     */     
/* 217 */     return input.readUnsignedByte();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reader constructReader() throws IOException {
/*     */     InputStream in;
/*     */     MergedStream mergedStream;
/* 229 */     JsonEncoding enc = this._context.getEncoding();
/* 230 */     switch (enc.bits()) {
/*     */ 
/*     */       
/*     */       case 8:
/*     */       case 16:
/* 235 */         in = this._in;
/*     */         
/* 237 */         if (in == null) {
/* 238 */           int length = this._inputEnd - this._inputPtr;
/* 239 */           if (length <= 8192)
/*     */           {
/*     */             
/* 242 */             return new StringReader(new String(this._inputBuffer, this._inputPtr, length, enc.getJavaName()));
/*     */           }
/* 244 */           in = new ByteArrayInputStream(this._inputBuffer, this._inputPtr, this._inputEnd);
/*     */ 
/*     */         
/*     */         }
/* 248 */         else if (this._inputPtr < this._inputEnd) {
/* 249 */           mergedStream = new MergedStream(this._context, in, this._inputBuffer, this._inputPtr, this._inputEnd);
/*     */         } 
/*     */         
/* 252 */         return new InputStreamReader((InputStream)mergedStream, enc.getJavaName());
/*     */       
/*     */       case 32:
/* 255 */         return (Reader)new UTF32Reader(this._context, this._in, this._inputBuffer, this._inputPtr, this._inputEnd, this._context
/* 256 */             .getEncoding().isBigEndian());
/*     */     } 
/* 258 */     return (Reader)VersionUtil.throwInternalReturnAny();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParser constructParser(int parserFeatures, ObjectCodec codec, ByteQuadsCanonicalizer rootByteSymbols, CharsToNameCanonicalizer rootCharSymbols, int factoryFeatures) throws IOException {
/* 265 */     int prevInputPtr = this._inputPtr;
/* 266 */     JsonEncoding enc = JsonFactory.Feature.CHARSET_DETECTION.enabledIn(factoryFeatures) ? detectEncoding() : JsonEncoding.UTF8;
/* 267 */     int bytesProcessed = this._inputPtr - prevInputPtr;
/*     */     
/* 269 */     if (enc == JsonEncoding.UTF8)
/*     */     {
/*     */       
/* 272 */       if (JsonFactory.Feature.CANONICALIZE_FIELD_NAMES.enabledIn(factoryFeatures)) {
/* 273 */         ByteQuadsCanonicalizer can = rootByteSymbols.makeChild(factoryFeatures);
/* 274 */         return (JsonParser)new UTF8StreamJsonParser(this._context, parserFeatures, this._in, codec, can, this._inputBuffer, this._inputPtr, this._inputEnd, bytesProcessed, this._bufferRecyclable);
/*     */       } 
/*     */     }
/*     */     
/* 278 */     return (JsonParser)new ReaderBasedJsonParser(this._context, parserFeatures, constructReader(), codec, rootCharSymbols
/* 279 */         .makeChild());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MatchStrength hasJSONFormat(InputAccessor acc) throws IOException {
/* 305 */     if (!acc.hasMoreBytes()) {
/* 306 */       return MatchStrength.INCONCLUSIVE;
/*     */     }
/* 308 */     byte b = acc.nextByte();
/*     */     
/* 310 */     if (b == -17) {
/* 311 */       if (!acc.hasMoreBytes()) {
/* 312 */         return MatchStrength.INCONCLUSIVE;
/*     */       }
/* 314 */       if (acc.nextByte() != -69) {
/* 315 */         return MatchStrength.NO_MATCH;
/*     */       }
/* 317 */       if (!acc.hasMoreBytes()) {
/* 318 */         return MatchStrength.INCONCLUSIVE;
/*     */       }
/* 320 */       if (acc.nextByte() != -65) {
/* 321 */         return MatchStrength.NO_MATCH;
/*     */       }
/* 323 */       if (!acc.hasMoreBytes()) {
/* 324 */         return MatchStrength.INCONCLUSIVE;
/*     */       }
/* 326 */       b = acc.nextByte();
/*     */     } 
/*     */     
/* 329 */     int ch = skipSpace(acc, b);
/* 330 */     if (ch < 0) {
/* 331 */       return MatchStrength.INCONCLUSIVE;
/*     */     }
/*     */     
/* 334 */     if (ch == 123) {
/*     */       
/* 336 */       ch = skipSpace(acc);
/* 337 */       if (ch < 0) {
/* 338 */         return MatchStrength.INCONCLUSIVE;
/*     */       }
/* 340 */       if (ch == 34 || ch == 125) {
/* 341 */         return MatchStrength.SOLID_MATCH;
/*     */       }
/*     */       
/* 344 */       return MatchStrength.NO_MATCH;
/*     */     } 
/*     */ 
/*     */     
/* 348 */     if (ch == 91) {
/* 349 */       ch = skipSpace(acc);
/* 350 */       if (ch < 0) {
/* 351 */         return MatchStrength.INCONCLUSIVE;
/*     */       }
/*     */       
/* 354 */       if (ch == 93 || ch == 91) {
/* 355 */         return MatchStrength.SOLID_MATCH;
/*     */       }
/* 357 */       return MatchStrength.SOLID_MATCH;
/*     */     } 
/*     */     
/* 360 */     MatchStrength strength = MatchStrength.WEAK_MATCH;
/*     */ 
/*     */     
/* 363 */     if (ch == 34) {
/* 364 */       return strength;
/*     */     }
/* 366 */     if (ch <= 57 && ch >= 48) {
/* 367 */       return strength;
/*     */     }
/* 369 */     if (ch == 45) {
/* 370 */       ch = skipSpace(acc);
/* 371 */       if (ch < 0) {
/* 372 */         return MatchStrength.INCONCLUSIVE;
/*     */       }
/* 374 */       return (ch <= 57 && ch >= 48) ? strength : MatchStrength.NO_MATCH;
/*     */     } 
/*     */     
/* 377 */     if (ch == 110) {
/* 378 */       return tryMatch(acc, "ull", strength);
/*     */     }
/* 380 */     if (ch == 116) {
/* 381 */       return tryMatch(acc, "rue", strength);
/*     */     }
/* 383 */     if (ch == 102) {
/* 384 */       return tryMatch(acc, "alse", strength);
/*     */     }
/* 386 */     return MatchStrength.NO_MATCH;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static MatchStrength tryMatch(InputAccessor acc, String matchStr, MatchStrength fullMatchStrength) throws IOException {
/* 392 */     for (int i = 0, len = matchStr.length(); i < len; i++) {
/* 393 */       if (!acc.hasMoreBytes()) {
/* 394 */         return MatchStrength.INCONCLUSIVE;
/*     */       }
/* 396 */       if (acc.nextByte() != matchStr.charAt(i)) {
/* 397 */         return MatchStrength.NO_MATCH;
/*     */       }
/*     */     } 
/* 400 */     return fullMatchStrength;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int skipSpace(InputAccessor acc) throws IOException {
/* 405 */     if (!acc.hasMoreBytes()) {
/* 406 */       return -1;
/*     */     }
/* 408 */     return skipSpace(acc, acc.nextByte());
/*     */   }
/*     */ 
/*     */   
/*     */   private static int skipSpace(InputAccessor acc, byte b) throws IOException {
/*     */     while (true) {
/* 414 */       int ch = b & 0xFF;
/* 415 */       if (ch != 32 && ch != 13 && ch != 10 && ch != 9) {
/* 416 */         return ch;
/*     */       }
/* 418 */       if (!acc.hasMoreBytes()) {
/* 419 */         return -1;
/*     */       }
/* 421 */       b = acc.nextByte();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean handleBOM(int quad) throws IOException {
/* 440 */     switch (quad) {
/*     */       case 65279:
/* 442 */         this._bigEndian = true;
/* 443 */         this._inputPtr += 4;
/* 444 */         this._bytesPerChar = 4;
/* 445 */         return true;
/*     */       case -131072:
/* 447 */         this._inputPtr += 4;
/* 448 */         this._bytesPerChar = 4;
/* 449 */         this._bigEndian = false;
/* 450 */         return true;
/*     */       case 65534:
/* 452 */         reportWeirdUCS4("2143");
/*     */         break;
/*     */       case -16842752:
/* 455 */         reportWeirdUCS4("3412");
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 460 */     int msw = quad >>> 16;
/* 461 */     if (msw == 65279) {
/* 462 */       this._inputPtr += 2;
/* 463 */       this._bytesPerChar = 2;
/* 464 */       this._bigEndian = true;
/* 465 */       return true;
/*     */     } 
/* 467 */     if (msw == 65534) {
/* 468 */       this._inputPtr += 2;
/* 469 */       this._bytesPerChar = 2;
/* 470 */       this._bigEndian = false;
/* 471 */       return true;
/*     */     } 
/*     */     
/* 474 */     if (quad >>> 8 == 15711167) {
/* 475 */       this._inputPtr += 3;
/* 476 */       this._bytesPerChar = 1;
/* 477 */       this._bigEndian = true;
/* 478 */       return true;
/*     */     } 
/* 480 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkUTF32(int quad) throws IOException {
/* 488 */     if (quad >> 8 == 0) {
/* 489 */       this._bigEndian = true;
/* 490 */     } else if ((quad & 0xFFFFFF) == 0) {
/* 491 */       this._bigEndian = false;
/* 492 */     } else if ((quad & 0xFF00FFFF) == 0) {
/* 493 */       reportWeirdUCS4("3412");
/* 494 */     } else if ((quad & 0xFFFF00FF) == 0) {
/* 495 */       reportWeirdUCS4("2143");
/*     */     } else {
/*     */       
/* 498 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 502 */     this._bytesPerChar = 4;
/* 503 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkUTF16(int i16) {
/* 508 */     if ((i16 & 0xFF00) == 0) {
/* 509 */       this._bigEndian = true;
/* 510 */     } else if ((i16 & 0xFF) == 0) {
/* 511 */       this._bigEndian = false;
/*     */     } else {
/* 513 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 517 */     this._bytesPerChar = 2;
/* 518 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void reportWeirdUCS4(String type) throws IOException {
/* 528 */     throw new CharConversionException("Unsupported UCS-4 endianness (" + type + ") detected");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean ensureLoaded(int minimum) throws IOException {
/* 540 */     int gotten = this._inputEnd - this._inputPtr;
/* 541 */     while (gotten < minimum) {
/*     */       int count;
/*     */       
/* 544 */       if (this._in == null) {
/* 545 */         count = -1;
/*     */       } else {
/* 547 */         count = this._in.read(this._inputBuffer, this._inputEnd, this._inputBuffer.length - this._inputEnd);
/*     */       } 
/* 549 */       if (count < 1) {
/* 550 */         return false;
/*     */       }
/* 552 */       this._inputEnd += count;
/* 553 */       gotten += count;
/*     */     } 
/* 555 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\json\ByteSourceJsonBootstrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */