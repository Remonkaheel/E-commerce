/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.exc.StreamConstraintsException;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.InternalJacksonUtil;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Writer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class UTF8StreamJsonParser
/*      */   extends JsonParserBase
/*      */ {
/*      */   protected static final byte BYTE_LF = 10;
/*      */   protected final ByteQuadsCanonicalizer _symbols;
/*   43 */   protected int[] _quadBuffer = new int[16];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _tokenIncomplete;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _quad1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _nameStartOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _nameStartRow;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _nameStartCol;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InputStream _inputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] _inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _bufferRecyclable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public UTF8StreamJsonParser(IOContext ctxt, int features, InputStream in, ObjectCodec codec, ByteQuadsCanonicalizer sym, byte[] inputBuffer, int start, int end, boolean bufferRecyclable) {
/*  137 */     this(ctxt, features, in, codec, sym, inputBuffer, start, end, 0, bufferRecyclable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UTF8StreamJsonParser(IOContext ctxt, int features, InputStream in, ObjectCodec codec, ByteQuadsCanonicalizer sym, byte[] inputBuffer, int start, int end, int bytesPreProcessed, boolean bufferRecyclable) {
/*  163 */     super(ctxt, features, codec);
/*  164 */     this._inputStream = in;
/*  165 */     this._symbols = sym;
/*  166 */     this._inputBuffer = inputBuffer;
/*  167 */     this._inputPtr = start;
/*  168 */     this._inputEnd = end;
/*  169 */     this._currInputRowStart = start - bytesPreProcessed;
/*      */     
/*  171 */     this._currInputProcessed = (-start + bytesPreProcessed);
/*  172 */     this._bufferRecyclable = bufferRecyclable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int releaseBuffered(OutputStream out) throws IOException {
/*  184 */     int count = this._inputEnd - this._inputPtr;
/*  185 */     if (count < 1) {
/*  186 */       return 0;
/*      */     }
/*      */     
/*  189 */     int origPtr = this._inputPtr;
/*  190 */     this._inputPtr += count;
/*  191 */     out.write(this._inputBuffer, origPtr, count);
/*  192 */     return count;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getInputSource() {
/*  197 */     return this._inputStream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean _loadMore() throws IOException {
/*  208 */     if (this._inputStream != null) {
/*  209 */       int space = this._inputBuffer.length;
/*  210 */       if (space == 0) {
/*  211 */         return false;
/*      */       }
/*      */       
/*  214 */       int bufSize = this._inputEnd;
/*  215 */       this._currInputProcessed += bufSize;
/*  216 */       this._currInputRowStart -= bufSize;
/*      */       
/*  218 */       this._streamReadConstraints.validateDocumentLength(this._currInputProcessed);
/*      */       
/*  220 */       int count = this._inputStream.read(this._inputBuffer, 0, space);
/*  221 */       if (count > 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  226 */         this._nameStartOffset -= bufSize;
/*      */         
/*  228 */         this._inputPtr = 0;
/*  229 */         this._inputEnd = count;
/*      */         
/*  231 */         return true;
/*      */       } 
/*  233 */       this._inputPtr = this._inputEnd = 0;
/*      */       
/*  235 */       _closeInput();
/*      */       
/*  237 */       if (count == 0) {
/*  238 */         throw new IOException("InputStream.read() returned 0 characters when trying to read " + this._inputBuffer.length + " bytes");
/*      */       }
/*      */     } 
/*  241 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _closeInput() throws IOException {
/*  249 */     if (this._inputStream != null) {
/*  250 */       if (this._ioContext.isResourceManaged() || isEnabled(JsonParser.Feature.AUTO_CLOSE_SOURCE)) {
/*  251 */         this._inputStream.close();
/*      */       }
/*  253 */       this._inputStream = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() throws IOException {
/*  266 */     super._releaseBuffers();
/*      */     
/*  268 */     this._symbols.release();
/*  269 */     if (this._bufferRecyclable) {
/*  270 */       byte[] buf = this._inputBuffer;
/*  271 */       if (buf != null)
/*      */       {
/*      */         
/*  274 */         if (buf != NO_BYTES) {
/*  275 */           this._inputBuffer = NO_BYTES;
/*  276 */           this._ioContext.releaseReadIOBuffer(buf);
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getText() throws IOException {
/*  291 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  292 */       if (this._tokenIncomplete) {
/*  293 */         this._tokenIncomplete = false;
/*  294 */         return _finishAndReturnString();
/*      */       } 
/*  296 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  298 */     return _getText2(this._currToken);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getText(Writer writer) throws IOException {
/*  304 */     JsonToken t = this._currToken;
/*  305 */     if (t == JsonToken.VALUE_STRING) {
/*  306 */       if (this._tokenIncomplete) {
/*  307 */         this._tokenIncomplete = false;
/*  308 */         _finishString();
/*      */       } 
/*  310 */       return this._textBuffer.contentsToWriter(writer);
/*      */     } 
/*  312 */     if (t == JsonToken.FIELD_NAME) {
/*  313 */       String n = this._parsingContext.getCurrentName();
/*  314 */       writer.write(n);
/*  315 */       return n.length();
/*      */     } 
/*  317 */     if (t != null) {
/*  318 */       if (t.isNumeric()) {
/*  319 */         return this._textBuffer.contentsToWriter(writer);
/*      */       }
/*  321 */       char[] ch = t.asCharArray();
/*  322 */       writer.write(ch);
/*  323 */       return ch.length;
/*      */     } 
/*  325 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString() throws IOException {
/*  334 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  335 */       if (this._tokenIncomplete) {
/*  336 */         this._tokenIncomplete = false;
/*  337 */         return _finishAndReturnString();
/*      */       } 
/*  339 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  341 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  342 */       return currentName();
/*      */     }
/*  344 */     return super.getValueAsString(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString(String defValue) throws IOException {
/*  351 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  352 */       if (this._tokenIncomplete) {
/*  353 */         this._tokenIncomplete = false;
/*  354 */         return _finishAndReturnString();
/*      */       } 
/*  356 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  358 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  359 */       return currentName();
/*      */     }
/*  361 */     return super.getValueAsString(defValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt() throws IOException {
/*  368 */     JsonToken t = this._currToken;
/*  369 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */       
/*  371 */       if ((this._numTypesValid & 0x1) == 0) {
/*  372 */         if (this._numTypesValid == 0) {
/*  373 */           return _parseIntValue();
/*      */         }
/*  375 */         if ((this._numTypesValid & 0x1) == 0) {
/*  376 */           convertNumberToInt();
/*      */         }
/*      */       } 
/*  379 */       return this._numberInt;
/*      */     } 
/*  381 */     return super.getValueAsInt(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt(int defValue) throws IOException {
/*  388 */     JsonToken t = this._currToken;
/*  389 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */       
/*  391 */       if ((this._numTypesValid & 0x1) == 0) {
/*  392 */         if (this._numTypesValid == 0) {
/*  393 */           return _parseIntValue();
/*      */         }
/*  395 */         if ((this._numTypesValid & 0x1) == 0) {
/*  396 */           convertNumberToInt();
/*      */         }
/*      */       } 
/*  399 */       return this._numberInt;
/*      */     } 
/*  401 */     return super.getValueAsInt(defValue);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String _getText2(JsonToken t) throws IOException {
/*  406 */     if (t == null) {
/*  407 */       return null;
/*      */     }
/*  409 */     switch (t.id()) {
/*      */       case 5:
/*  411 */         return this._parsingContext.getCurrentName();
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  417 */         return this._textBuffer.contentsAsString();
/*      */     } 
/*  419 */     return t.asString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getTextCharacters() throws IOException {
/*  426 */     if (this._currToken != null) {
/*  427 */       switch (this._currToken.id()) {
/*      */         
/*      */         case 5:
/*  430 */           if (!this._nameCopied) {
/*  431 */             String name = this._parsingContext.getCurrentName();
/*  432 */             int nameLen = name.length();
/*  433 */             if (this._nameCopyBuffer == null) {
/*  434 */               this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/*  435 */             } else if (this._nameCopyBuffer.length < nameLen) {
/*  436 */               this._nameCopyBuffer = new char[nameLen];
/*      */             } 
/*  438 */             name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/*  439 */             this._nameCopied = true;
/*      */           } 
/*  441 */           return this._nameCopyBuffer;
/*      */         
/*      */         case 6:
/*  444 */           if (this._tokenIncomplete) {
/*  445 */             this._tokenIncomplete = false;
/*  446 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  451 */           return this._textBuffer.getTextBuffer();
/*      */       } 
/*      */       
/*  454 */       return this._currToken.asCharArray();
/*      */     } 
/*      */     
/*  457 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextLength() throws IOException {
/*  463 */     if (this._currToken != null) {
/*  464 */       switch (this._currToken.id()) {
/*      */         
/*      */         case 5:
/*  467 */           return this._parsingContext.getCurrentName().length();
/*      */         case 6:
/*  469 */           if (this._tokenIncomplete) {
/*  470 */             this._tokenIncomplete = false;
/*  471 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  476 */           return this._textBuffer.size();
/*      */       } 
/*      */       
/*  479 */       return (this._currToken.asCharArray()).length;
/*      */     } 
/*      */     
/*  482 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextOffset() throws IOException {
/*  489 */     if (this._currToken != null) {
/*  490 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  492 */           return 0;
/*      */         case 6:
/*  494 */           if (this._tokenIncomplete) {
/*  495 */             this._tokenIncomplete = false;
/*  496 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  501 */           return this._textBuffer.getTextOffset();
/*      */       } 
/*      */     
/*      */     }
/*  505 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBinaryValue(Base64Variant b64variant) throws IOException {
/*  511 */     if (this._currToken != JsonToken.VALUE_STRING && (this._currToken != JsonToken.VALUE_EMBEDDED_OBJECT || this._binaryValue == null))
/*      */     {
/*  513 */       _reportError("Current token (" + this._currToken + ") not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary");
/*      */     }
/*      */     
/*  516 */     if (this._tokenIncomplete) {
/*      */       try {
/*  518 */         this._binaryValue = _decodeBase64(b64variant);
/*  519 */       } catch (IllegalArgumentException iae) {
/*  520 */         throw _constructError("Failed to decode VALUE_STRING as base64 (" + b64variant + "): " + iae.getMessage());
/*      */       } 
/*      */       
/*  523 */       this._tokenIncomplete = false;
/*      */     }
/*  525 */     else if (this._binaryValue == null) {
/*      */       
/*  527 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  528 */       _decodeBase64(getText(), builder, b64variant);
/*  529 */       this._binaryValue = builder.toByteArray();
/*      */     } 
/*      */     
/*  532 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/*  539 */     if (!this._tokenIncomplete || this._currToken != JsonToken.VALUE_STRING) {
/*  540 */       byte[] b = getBinaryValue(b64variant);
/*  541 */       out.write(b);
/*  542 */       return b.length;
/*      */     } 
/*      */     
/*  545 */     byte[] buf = this._ioContext.allocBase64Buffer();
/*      */     try {
/*  547 */       return _readBinary(b64variant, out, buf);
/*      */     } finally {
/*  549 */       this._ioContext.releaseBase64Buffer(buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _readBinary(Base64Variant b64variant, OutputStream out, byte[] buffer) throws IOException {
/*  556 */     int outputPtr = 0;
/*  557 */     int outputEnd = buffer.length - 3;
/*  558 */     int outputCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  564 */       if (this._inputPtr >= this._inputEnd) {
/*  565 */         _loadMoreGuaranteed();
/*      */       }
/*  567 */       int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  568 */       if (ch > 32) {
/*  569 */         int bits = b64variant.decodeBase64Char(ch);
/*  570 */         if (bits < 0) {
/*  571 */           if (ch == 34) {
/*      */             break;
/*      */           }
/*  574 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/*  575 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  581 */         if (outputPtr > outputEnd) {
/*  582 */           outputCount += outputPtr;
/*  583 */           out.write(buffer, 0, outputPtr);
/*  584 */           outputPtr = 0;
/*      */         } 
/*      */         
/*  587 */         int decodedData = bits;
/*      */ 
/*      */ 
/*      */         
/*  591 */         if (this._inputPtr >= this._inputEnd) {
/*  592 */           _loadMoreGuaranteed();
/*      */         }
/*  594 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  595 */         bits = b64variant.decodeBase64Char(ch);
/*  596 */         if (bits < 0) {
/*  597 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/*  599 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/*  602 */         if (this._inputPtr >= this._inputEnd) {
/*  603 */           _loadMoreGuaranteed();
/*      */         }
/*  605 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  606 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/*  609 */         if (bits < 0) {
/*  610 */           if (bits != -2) {
/*      */             
/*  612 */             if (ch == 34) {
/*  613 */               decodedData >>= 4;
/*  614 */               buffer[outputPtr++] = (byte)decodedData;
/*  615 */               if (b64variant.requiresPaddingOnRead()) {
/*  616 */                 this._inputPtr--;
/*  617 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/*      */               break;
/*      */             } 
/*  621 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/*  623 */           if (bits == -2) {
/*      */             
/*  625 */             if (this._inputPtr >= this._inputEnd) {
/*  626 */               _loadMoreGuaranteed();
/*      */             }
/*  628 */             ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  629 */             if (!b64variant.usesPaddingChar(ch) && 
/*  630 */               _decodeBase64Escape(b64variant, ch, 3) != -2) {
/*  631 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/*  635 */             decodedData >>= 4;
/*  636 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  641 */         decodedData = decodedData << 6 | bits;
/*      */         
/*  643 */         if (this._inputPtr >= this._inputEnd) {
/*  644 */           _loadMoreGuaranteed();
/*      */         }
/*  646 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*  647 */         bits = b64variant.decodeBase64Char(ch);
/*  648 */         if (bits < 0) {
/*  649 */           if (bits != -2) {
/*      */             
/*  651 */             if (ch == 34) {
/*  652 */               decodedData >>= 2;
/*  653 */               buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  654 */               buffer[outputPtr++] = (byte)decodedData;
/*  655 */               if (b64variant.requiresPaddingOnRead()) {
/*  656 */                 this._inputPtr--;
/*  657 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/*      */               break;
/*      */             } 
/*  661 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/*  663 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  670 */             decodedData >>= 2;
/*  671 */             buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  672 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  677 */         decodedData = decodedData << 6 | bits;
/*  678 */         buffer[outputPtr++] = (byte)(decodedData >> 16);
/*  679 */         buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  680 */         buffer[outputPtr++] = (byte)decodedData;
/*      */       } 
/*  682 */     }  this._tokenIncomplete = false;
/*  683 */     if (outputPtr > 0) {
/*  684 */       outputCount += outputPtr;
/*  685 */       out.write(buffer, 0, outputPtr);
/*      */     } 
/*  687 */     return outputCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken nextToken() throws IOException {
/*  707 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  708 */       return _nextAfterName();
/*      */     }
/*      */ 
/*      */     
/*  712 */     this._numTypesValid = 0;
/*  713 */     if (this._tokenIncomplete) {
/*  714 */       _skipString();
/*      */     }
/*  716 */     int i = _skipWSOrEnd();
/*  717 */     if (i < 0) {
/*      */       
/*  719 */       close();
/*  720 */       return _updateTokenToNull();
/*      */     } 
/*      */     
/*  723 */     this._binaryValue = null;
/*      */ 
/*      */     
/*  726 */     if (i == 93) {
/*  727 */       _closeArrayScope();
/*  728 */       return _updateToken(JsonToken.END_ARRAY);
/*      */     } 
/*  730 */     if (i == 125) {
/*  731 */       _closeObjectScope();
/*  732 */       return _updateToken(JsonToken.END_OBJECT);
/*      */     } 
/*      */ 
/*      */     
/*  736 */     if (this._parsingContext.expectComma()) {
/*  737 */       if (i != 44) {
/*  738 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  740 */       i = _skipWS();
/*      */       
/*  742 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  743 */         i == 93 || i == 125)) {
/*  744 */         return _closeScope(i);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  751 */     if (!this._parsingContext.inObject()) {
/*  752 */       _updateLocation();
/*  753 */       return _nextTokenNotInObject(i);
/*      */     } 
/*      */     
/*  756 */     _updateNameLocation();
/*  757 */     String n = _parseName(i);
/*  758 */     this._parsingContext.setCurrentName(n);
/*  759 */     _updateToken(JsonToken.FIELD_NAME);
/*      */     
/*  761 */     i = _skipColon();
/*  762 */     _updateLocation();
/*      */ 
/*      */     
/*  765 */     if (i == 34) {
/*  766 */       this._tokenIncomplete = true;
/*  767 */       this._nextToken = JsonToken.VALUE_STRING;
/*  768 */       return this._currToken;
/*      */     } 
/*      */ 
/*      */     
/*  772 */     switch (i)
/*      */     { case 45:
/*  774 */         t = _parseSignedNumber(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  820 */         this._nextToken = t;
/*  821 */         return this._currToken;case 43: if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) { t = _parseSignedNumber(false); } else { t = _handleUnexpectedValue(i); }  this._nextToken = t; return this._currToken;case 46: t = _parseFloatThatStartsWithPeriod(false, false); this._nextToken = t; return this._currToken;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parseUnsignedNumber(i); this._nextToken = t; return this._currToken;case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return this._currToken;case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return this._currToken;case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return this._currToken;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return this._currToken;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return this._currToken; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return this._currToken;
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextTokenNotInObject(int i) throws IOException {
/*  826 */     if (i == 34) {
/*  827 */       this._tokenIncomplete = true;
/*  828 */       return _updateToken(JsonToken.VALUE_STRING);
/*      */     } 
/*  830 */     switch (i) {
/*      */       case 91:
/*  832 */         createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  833 */         return _updateToken(JsonToken.START_ARRAY);
/*      */       case 123:
/*  835 */         createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*  836 */         return _updateToken(JsonToken.START_OBJECT);
/*      */       case 116:
/*  838 */         _matchTrue();
/*  839 */         return _updateToken(JsonToken.VALUE_TRUE);
/*      */       case 102:
/*  841 */         _matchFalse();
/*  842 */         return _updateToken(JsonToken.VALUE_FALSE);
/*      */       case 110:
/*  844 */         _matchNull();
/*  845 */         return _updateToken(JsonToken.VALUE_NULL);
/*      */       case 45:
/*  847 */         return _updateToken(_parseSignedNumber(true));
/*      */       case 43:
/*  849 */         if (!isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/*  850 */           return _updateToken(_handleUnexpectedValue(i));
/*      */         }
/*  852 */         return _updateToken(_parseSignedNumber(false));
/*      */       case 46:
/*  854 */         return _updateToken(_parseFloatThatStartsWithPeriod(false, false));
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  865 */         return _updateToken(_parseUnsignedNumber(i));
/*      */     } 
/*  867 */     return _updateToken(_handleUnexpectedValue(i));
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextAfterName() throws IOException {
/*  872 */     this._nameCopied = false;
/*  873 */     JsonToken t = this._nextToken;
/*  874 */     this._nextToken = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  879 */     if (t == JsonToken.START_ARRAY) {
/*  880 */       createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  881 */     } else if (t == JsonToken.START_OBJECT) {
/*  882 */       createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */     } 
/*  884 */     return _updateToken(t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void finishToken() throws IOException {
/*  889 */     if (this._tokenIncomplete) {
/*  890 */       this._tokenIncomplete = false;
/*  891 */       _finishString();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean nextFieldName(SerializableString str) throws IOException {
/*  905 */     this._numTypesValid = 0;
/*  906 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  907 */       _nextAfterName();
/*  908 */       return false;
/*      */     } 
/*  910 */     if (this._tokenIncomplete) {
/*  911 */       _skipString();
/*      */     }
/*  913 */     int i = _skipWSOrEnd();
/*  914 */     if (i < 0) {
/*  915 */       close();
/*  916 */       _updateTokenToNull();
/*  917 */       return false;
/*      */     } 
/*  919 */     this._binaryValue = null;
/*      */ 
/*      */     
/*  922 */     if (i == 93) {
/*  923 */       _closeArrayScope();
/*  924 */       _updateToken(JsonToken.END_ARRAY);
/*  925 */       return false;
/*      */     } 
/*  927 */     if (i == 125) {
/*  928 */       _closeObjectScope();
/*  929 */       _updateToken(JsonToken.END_OBJECT);
/*  930 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  934 */     if (this._parsingContext.expectComma()) {
/*  935 */       if (i != 44) {
/*  936 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  938 */       i = _skipWS();
/*      */ 
/*      */       
/*  941 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  942 */         i == 93 || i == 125)) {
/*  943 */         _closeScope(i);
/*  944 */         return false;
/*      */       } 
/*      */     } 
/*      */     
/*  948 */     if (!this._parsingContext.inObject()) {
/*  949 */       _updateLocation();
/*  950 */       _nextTokenNotInObject(i);
/*  951 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  955 */     _updateNameLocation();
/*  956 */     if (i == 34) {
/*      */       
/*  958 */       byte[] nameBytes = str.asQuotedUTF8();
/*  959 */       int len = nameBytes.length;
/*      */ 
/*      */       
/*  962 */       if (this._inputPtr + len + 4 < this._inputEnd) {
/*      */         
/*  964 */         int end = this._inputPtr + len;
/*  965 */         if (this._inputBuffer[end] == 34) {
/*  966 */           int offset = 0;
/*  967 */           int ptr = this._inputPtr;
/*      */           while (true) {
/*  969 */             if (ptr == end) {
/*  970 */               this._parsingContext.setCurrentName(str.getValue());
/*  971 */               i = _skipColonFast(ptr + 1);
/*  972 */               _isNextTokenNameYes(i);
/*  973 */               return true;
/*      */             } 
/*  975 */             if (nameBytes[offset] != this._inputBuffer[ptr]) {
/*      */               break;
/*      */             }
/*  978 */             offset++;
/*  979 */             ptr++;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  984 */     return _isNextTokenNameMaybe(i, str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextFieldName() throws IOException {
/*  991 */     this._numTypesValid = 0;
/*  992 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  993 */       _nextAfterName();
/*  994 */       return null;
/*      */     } 
/*  996 */     if (this._tokenIncomplete) {
/*  997 */       _skipString();
/*      */     }
/*  999 */     int i = _skipWSOrEnd();
/* 1000 */     if (i < 0) {
/* 1001 */       close();
/* 1002 */       _updateTokenToNull();
/* 1003 */       return null;
/*      */     } 
/* 1005 */     this._binaryValue = null;
/*      */     
/* 1007 */     if (i == 93) {
/* 1008 */       _closeArrayScope();
/* 1009 */       _updateToken(JsonToken.END_ARRAY);
/* 1010 */       return null;
/*      */     } 
/* 1012 */     if (i == 125) {
/* 1013 */       _closeObjectScope();
/* 1014 */       _updateToken(JsonToken.END_OBJECT);
/* 1015 */       return null;
/*      */     } 
/*      */ 
/*      */     
/* 1019 */     if (this._parsingContext.expectComma()) {
/* 1020 */       if (i != 44) {
/* 1021 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/* 1023 */       i = _skipWS();
/*      */       
/* 1025 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/* 1026 */         i == 93 || i == 125)) {
/* 1027 */         _closeScope(i);
/* 1028 */         return null;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1033 */     if (!this._parsingContext.inObject()) {
/* 1034 */       _updateLocation();
/* 1035 */       _nextTokenNotInObject(i);
/* 1036 */       return null;
/*      */     } 
/*      */     
/* 1039 */     _updateNameLocation();
/* 1040 */     String nameStr = _parseName(i);
/* 1041 */     this._parsingContext.setCurrentName(nameStr);
/* 1042 */     _updateToken(JsonToken.FIELD_NAME);
/*      */     
/* 1044 */     i = _skipColon();
/* 1045 */     _updateLocation();
/* 1046 */     if (i == 34) {
/* 1047 */       this._tokenIncomplete = true;
/* 1048 */       this._nextToken = JsonToken.VALUE_STRING;
/* 1049 */       return nameStr;
/*      */     } 
/*      */     
/* 1052 */     switch (i)
/*      */     { case 45:
/* 1054 */         t = _parseSignedNumber(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1100 */         this._nextToken = t;
/* 1101 */         return nameStr;case 43: if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) { t = _parseSignedNumber(false); } else { t = _handleUnexpectedValue(i); }  this._nextToken = t; return nameStr;case 46: t = _parseFloatThatStartsWithPeriod(false, false); this._nextToken = t; return nameStr;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parseUnsignedNumber(i); this._nextToken = t; return nameStr;case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return nameStr;case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return nameStr;case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return nameStr;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return nameStr;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return nameStr; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return nameStr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipColonFast(int ptr) throws IOException {
/* 1107 */     int i = this._inputBuffer[ptr++];
/* 1108 */     if (i == 58) {
/* 1109 */       i = this._inputBuffer[ptr++];
/* 1110 */       if (i > 32) {
/* 1111 */         if (i != 47 && i != 35) {
/* 1112 */           this._inputPtr = ptr;
/* 1113 */           return i;
/*      */         } 
/* 1115 */       } else if (i == 32 || i == 9) {
/* 1116 */         i = this._inputBuffer[ptr++];
/* 1117 */         if (i > 32 && 
/* 1118 */           i != 47 && i != 35) {
/* 1119 */           this._inputPtr = ptr;
/* 1120 */           return i;
/*      */         } 
/*      */       } 
/*      */       
/* 1124 */       this._inputPtr = ptr - 1;
/* 1125 */       return _skipColon2(true);
/*      */     } 
/* 1127 */     if (i == 32 || i == 9) {
/* 1128 */       i = this._inputBuffer[ptr++];
/*      */     }
/* 1130 */     if (i == 58) {
/* 1131 */       i = this._inputBuffer[ptr++];
/* 1132 */       if (i > 32) {
/* 1133 */         if (i != 47 && i != 35) {
/* 1134 */           this._inputPtr = ptr;
/* 1135 */           return i;
/*      */         } 
/* 1137 */       } else if (i == 32 || i == 9) {
/* 1138 */         i = this._inputBuffer[ptr++];
/* 1139 */         if (i > 32 && 
/* 1140 */           i != 47 && i != 35) {
/* 1141 */           this._inputPtr = ptr;
/* 1142 */           return i;
/*      */         } 
/*      */       } 
/*      */       
/* 1146 */       this._inputPtr = ptr - 1;
/* 1147 */       return _skipColon2(true);
/*      */     } 
/* 1149 */     this._inputPtr = ptr - 1;
/* 1150 */     return _skipColon2(false);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _isNextTokenNameYes(int i) throws IOException {
/* 1155 */     _updateToken(JsonToken.FIELD_NAME);
/* 1156 */     _updateLocation();
/*      */     
/* 1158 */     switch (i) {
/*      */       case 34:
/* 1160 */         this._tokenIncomplete = true;
/* 1161 */         this._nextToken = JsonToken.VALUE_STRING;
/*      */         return;
/*      */       case 91:
/* 1164 */         this._nextToken = JsonToken.START_ARRAY;
/*      */         return;
/*      */       case 123:
/* 1167 */         this._nextToken = JsonToken.START_OBJECT;
/*      */         return;
/*      */       case 116:
/* 1170 */         _matchTrue();
/* 1171 */         this._nextToken = JsonToken.VALUE_TRUE;
/*      */         return;
/*      */       case 102:
/* 1174 */         _matchFalse();
/* 1175 */         this._nextToken = JsonToken.VALUE_FALSE;
/*      */         return;
/*      */       case 110:
/* 1178 */         _matchNull();
/* 1179 */         this._nextToken = JsonToken.VALUE_NULL;
/*      */         return;
/*      */       case 45:
/* 1182 */         this._nextToken = _parseSignedNumber(true);
/*      */         return;
/*      */       case 43:
/* 1185 */         if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/* 1186 */           this._nextToken = _parseSignedNumber(false);
/*      */         } else {
/* 1188 */           this._nextToken = _handleUnexpectedValue(i);
/*      */         } 
/*      */         return;
/*      */       case 46:
/* 1192 */         this._nextToken = _parseFloatThatStartsWithPeriod(false, false);
/*      */         return;
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/* 1204 */         this._nextToken = _parseUnsignedNumber(i);
/*      */         return;
/*      */     } 
/* 1207 */     this._nextToken = _handleUnexpectedValue(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean _isNextTokenNameMaybe(int i, SerializableString str) throws IOException {
/* 1214 */     String n = _parseName(i);
/* 1215 */     this._parsingContext.setCurrentName(n);
/* 1216 */     boolean match = n.equals(str.getValue());
/* 1217 */     _updateToken(JsonToken.FIELD_NAME);
/* 1218 */     i = _skipColon();
/* 1219 */     _updateLocation();
/*      */ 
/*      */     
/* 1222 */     if (i == 34) {
/* 1223 */       this._tokenIncomplete = true;
/* 1224 */       this._nextToken = JsonToken.VALUE_STRING;
/* 1225 */       return match;
/*      */     } 
/*      */ 
/*      */     
/* 1229 */     switch (i)
/*      */     { case 91:
/* 1231 */         t = JsonToken.START_ARRAY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1276 */         this._nextToken = t;
/* 1277 */         return match;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return match;case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return match;case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return match;case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return match;case 45: t = _parseSignedNumber(true); this._nextToken = t; return match;case 43: if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) { t = _parseSignedNumber(false); } else { t = _handleUnexpectedValue(i); }  this._nextToken = t; return match;case 46: t = _parseFloatThatStartsWithPeriod(false, false); this._nextToken = t; return match;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parseUnsignedNumber(i); this._nextToken = t; return match; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return match;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextTextValue() throws IOException {
/* 1284 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1285 */       this._nameCopied = false;
/* 1286 */       JsonToken t = this._nextToken;
/* 1287 */       this._nextToken = null;
/* 1288 */       _updateToken(t);
/* 1289 */       if (t == JsonToken.VALUE_STRING) {
/* 1290 */         if (this._tokenIncomplete) {
/* 1291 */           this._tokenIncomplete = false;
/* 1292 */           return _finishAndReturnString();
/*      */         } 
/* 1294 */         return this._textBuffer.contentsAsString();
/*      */       } 
/* 1296 */       if (t == JsonToken.START_ARRAY) {
/* 1297 */         createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1298 */       } else if (t == JsonToken.START_OBJECT) {
/* 1299 */         createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1301 */       return null;
/*      */     } 
/*      */     
/* 1304 */     return (nextToken() == JsonToken.VALUE_STRING) ? getText() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int nextIntValue(int defaultValue) throws IOException {
/* 1311 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1312 */       this._nameCopied = false;
/* 1313 */       JsonToken t = this._nextToken;
/* 1314 */       this._nextToken = null;
/* 1315 */       _updateToken(t);
/* 1316 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1317 */         return getIntValue();
/*      */       }
/* 1319 */       if (t == JsonToken.START_ARRAY) {
/* 1320 */         createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1321 */       } else if (t == JsonToken.START_OBJECT) {
/* 1322 */         createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1324 */       return defaultValue;
/*      */     } 
/*      */     
/* 1327 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getIntValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long nextLongValue(long defaultValue) throws IOException {
/* 1334 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1335 */       this._nameCopied = false;
/* 1336 */       JsonToken t = this._nextToken;
/* 1337 */       this._nextToken = null;
/* 1338 */       _updateToken(t);
/* 1339 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1340 */         return getLongValue();
/*      */       }
/* 1342 */       if (t == JsonToken.START_ARRAY) {
/* 1343 */         createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1344 */       } else if (t == JsonToken.START_OBJECT) {
/* 1345 */         createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1347 */       return defaultValue;
/*      */     } 
/*      */     
/* 1350 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getLongValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Boolean nextBooleanValue() throws IOException {
/* 1357 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1358 */       this._nameCopied = false;
/* 1359 */       JsonToken jsonToken = this._nextToken;
/* 1360 */       this._nextToken = null;
/* 1361 */       _updateToken(jsonToken);
/* 1362 */       if (jsonToken == JsonToken.VALUE_TRUE) {
/* 1363 */         return Boolean.TRUE;
/*      */       }
/* 1365 */       if (jsonToken == JsonToken.VALUE_FALSE) {
/* 1366 */         return Boolean.FALSE;
/*      */       }
/* 1368 */       if (jsonToken == JsonToken.START_ARRAY) {
/* 1369 */         createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1370 */       } else if (jsonToken == JsonToken.START_OBJECT) {
/* 1371 */         createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1373 */       return null;
/*      */     } 
/*      */     
/* 1376 */     JsonToken t = nextToken();
/* 1377 */     if (t == JsonToken.VALUE_TRUE) {
/* 1378 */       return Boolean.TRUE;
/*      */     }
/* 1380 */     if (t == JsonToken.VALUE_FALSE) {
/* 1381 */       return Boolean.FALSE;
/*      */     }
/* 1383 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod() throws IOException {
/* 1394 */     return _parseFloatThatStartsWithPeriod(false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod(boolean neg, boolean hasSign) throws IOException {
/* 1402 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1403 */       return _handleUnexpectedValue(46);
/*      */     }
/* 1405 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1406 */     int outPtr = 0;
/*      */     
/* 1408 */     if (neg) {
/* 1409 */       outBuf[outPtr++] = '-';
/*      */     }
/* 1411 */     return _parseFloat(outBuf, outPtr, 46, neg, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _parseUnsignedNumber(int c) throws IOException {
/* 1439 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */     
/* 1441 */     if (c == 48) {
/* 1442 */       c = _verifyNoLeadingZeroes();
/*      */     }
/*      */     
/* 1445 */     outBuf[0] = (char)c;
/* 1446 */     int intLen = 1;
/* 1447 */     int outPtr = 1;
/*      */ 
/*      */     
/* 1450 */     int end = Math.min(this._inputEnd, this._inputPtr + outBuf.length - 1);
/*      */     
/*      */     while (true) {
/* 1453 */       if (this._inputPtr >= end) {
/* 1454 */         return _parseNumber2(outBuf, outPtr, false, intLen);
/*      */       }
/* 1456 */       c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1457 */       if (c < 48 || c > 57) {
/*      */         break;
/*      */       }
/* 1460 */       intLen++;
/* 1461 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 1463 */     if (c == 46 || (c | 0x20) == 101) {
/* 1464 */       return _parseFloat(outBuf, outPtr, c, false, intLen);
/*      */     }
/* 1466 */     this._inputPtr--;
/* 1467 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1469 */     if (this._parsingContext.inRoot()) {
/* 1470 */       _verifyRootSpace(c);
/*      */     }
/*      */     
/* 1473 */     return resetInt(false, intLen);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _parseSignedNumber(boolean negative) throws IOException {
/* 1478 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1479 */     int outPtr = 0;
/*      */     
/* 1481 */     if (negative)
/*      */     {
/* 1483 */       outBuf[outPtr++] = '-';
/*      */     }
/*      */     
/* 1486 */     if (this._inputPtr >= this._inputEnd) {
/* 1487 */       _loadMoreGuaranteed();
/*      */     }
/* 1489 */     int c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */     
/* 1491 */     if (c <= 48) {
/*      */       
/* 1493 */       if (c != 48) {
/* 1494 */         if (c == 46) {
/* 1495 */           return _parseFloatThatStartsWithPeriod(negative, true);
/*      */         }
/* 1497 */         return _handleInvalidNumberStart(c, negative, true);
/*      */       } 
/* 1499 */       c = _verifyNoLeadingZeroes();
/* 1500 */     } else if (c > 57) {
/* 1501 */       return _handleInvalidNumberStart(c, negative, true);
/*      */     } 
/*      */ 
/*      */     
/* 1505 */     outBuf[outPtr++] = (char)c;
/* 1506 */     int intLen = 1;
/*      */ 
/*      */ 
/*      */     
/* 1510 */     int end = Math.min(this._inputEnd, this._inputPtr + outBuf.length - outPtr);
/*      */     
/*      */     while (true) {
/* 1513 */       if (this._inputPtr >= end)
/*      */       {
/* 1515 */         return _parseNumber2(outBuf, outPtr, negative, intLen);
/*      */       }
/* 1517 */       c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1518 */       if (c < 48 || c > 57) {
/*      */         break;
/*      */       }
/* 1521 */       intLen++;
/* 1522 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 1524 */     if (c == 46 || (c | 0x20) == 101) {
/* 1525 */       return _parseFloat(outBuf, outPtr, c, negative, intLen);
/*      */     }
/*      */     
/* 1528 */     this._inputPtr--;
/* 1529 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1531 */     if (this._parsingContext.inRoot()) {
/* 1532 */       _verifyRootSpace(c);
/*      */     }
/*      */ 
/*      */     
/* 1536 */     return resetInt(negative, intLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseNumber2(char[] outBuf, int outPtr, boolean negative, int intPartLength) throws IOException {
/*      */     while (true) {
/* 1546 */       if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1547 */         this._textBuffer.setCurrentLength(outPtr);
/* 1548 */         return resetInt(negative, intPartLength);
/*      */       } 
/* 1550 */       int c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1551 */       if (c > 57 || c < 48) {
/* 1552 */         if (c == 46 || (c | 0x20) == 101) {
/* 1553 */           return _parseFloat(outBuf, outPtr, c, negative, intPartLength);
/*      */         }
/*      */         break;
/*      */       } 
/* 1557 */       if (outPtr >= outBuf.length) {
/* 1558 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1559 */         outPtr = 0;
/*      */       } 
/* 1561 */       outBuf[outPtr++] = (char)c;
/* 1562 */       intPartLength++;
/*      */     } 
/* 1564 */     this._inputPtr--;
/* 1565 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1567 */     if (this._parsingContext.inRoot()) {
/* 1568 */       _verifyRootSpace(this._inputBuffer[this._inputPtr] & 0xFF);
/*      */     }
/*      */ 
/*      */     
/* 1572 */     return resetInt(negative, intPartLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _verifyNoLeadingZeroes() throws IOException {
/* 1581 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1582 */       return 48;
/*      */     }
/* 1584 */     int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/*      */     
/* 1586 */     if (ch < 48 || ch > 57) {
/* 1587 */       return 48;
/*      */     }
/*      */     
/* 1590 */     if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1591 */       reportInvalidNumber("Leading zeroes not allowed");
/*      */     }
/*      */     
/* 1594 */     this._inputPtr++;
/* 1595 */     if (ch == 48) {
/* 1596 */       while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 1597 */         ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 1598 */         if (ch < 48 || ch > 57) {
/* 1599 */           return 48;
/*      */         }
/* 1601 */         this._inputPtr++;
/* 1602 */         if (ch != 48) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/* 1607 */     return ch;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseFloat(char[] outBuf, int outPtr, int c, boolean negative, int integerPartLength) throws IOException {
/* 1613 */     int fractLen = 0;
/* 1614 */     boolean eof = false;
/*      */ 
/*      */     
/* 1617 */     if (c == 46) {
/* 1618 */       if (outPtr >= outBuf.length) {
/* 1619 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1620 */         outPtr = 0;
/*      */       } 
/* 1622 */       outBuf[outPtr++] = (char)c;
/*      */ 
/*      */       
/*      */       while (true) {
/* 1626 */         if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1627 */           eof = true;
/*      */           break;
/*      */         } 
/* 1630 */         c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1631 */         if (c < 48 || c > 57) {
/*      */           break;
/*      */         }
/* 1634 */         fractLen++;
/* 1635 */         if (outPtr >= outBuf.length) {
/* 1636 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1637 */           outPtr = 0;
/*      */         } 
/* 1639 */         outBuf[outPtr++] = (char)c;
/*      */       } 
/*      */       
/* 1642 */       if (fractLen == 0 && 
/* 1643 */         !isEnabled(JsonReadFeature.ALLOW_TRAILING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1644 */         _reportUnexpectedNumberChar(c, "Decimal point not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1649 */     int expLen = 0;
/* 1650 */     if ((c | 0x20) == 101) {
/* 1651 */       if (outPtr >= outBuf.length) {
/* 1652 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1653 */         outPtr = 0;
/*      */       } 
/* 1655 */       outBuf[outPtr++] = (char)c;
/*      */       
/* 1657 */       if (this._inputPtr >= this._inputEnd) {
/* 1658 */         _loadMoreGuaranteed();
/*      */       }
/* 1660 */       c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */       
/* 1662 */       if (c == 45 || c == 43) {
/* 1663 */         if (outPtr >= outBuf.length) {
/* 1664 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1665 */           outPtr = 0;
/*      */         } 
/* 1667 */         outBuf[outPtr++] = (char)c;
/*      */         
/* 1669 */         if (this._inputPtr >= this._inputEnd) {
/* 1670 */           _loadMoreGuaranteed();
/*      */         }
/* 1672 */         c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */       } 
/*      */ 
/*      */       
/* 1676 */       while (c >= 48 && c <= 57) {
/* 1677 */         expLen++;
/* 1678 */         if (outPtr >= outBuf.length) {
/* 1679 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1680 */           outPtr = 0;
/*      */         } 
/* 1682 */         outBuf[outPtr++] = (char)c;
/* 1683 */         if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1684 */           eof = true;
/*      */           break;
/*      */         } 
/* 1687 */         c = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */       } 
/*      */       
/* 1690 */       if (expLen == 0) {
/* 1691 */         _reportUnexpectedNumberChar(c, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1696 */     if (!eof) {
/* 1697 */       this._inputPtr--;
/*      */       
/* 1699 */       if (this._parsingContext.inRoot()) {
/* 1700 */         _verifyRootSpace(c);
/*      */       }
/*      */     } 
/* 1703 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/*      */     
/* 1706 */     return resetFloat(negative, integerPartLength, fractLen, expLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _verifyRootSpace(int ch) throws IOException {
/* 1724 */     this._inputPtr++;
/*      */     
/* 1726 */     switch (ch) {
/*      */       case 9:
/*      */       case 32:
/*      */         return;
/*      */ 
/*      */ 
/*      */       
/*      */       case 13:
/* 1734 */         this._inputPtr--;
/*      */         return;
/*      */       case 10:
/* 1737 */         this._currInputRow++;
/* 1738 */         this._currInputRowStart = this._inputPtr;
/*      */         return;
/*      */     } 
/* 1741 */     _reportMissingRootWS(ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String _parseName(int i) throws IOException {
/* 1752 */     if (i != 34) {
/* 1753 */       return _handleOddName(i);
/*      */     }
/*      */     
/* 1756 */     if (this._inputPtr + 13 > this._inputEnd) {
/* 1757 */       return slowParseName();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1766 */     byte[] input = this._inputBuffer;
/* 1767 */     int[] codes = INPUT_CODES_LATIN1;
/*      */     
/* 1769 */     int q = input[this._inputPtr++] & 0xFF;
/*      */     
/* 1771 */     if (codes[q] == 0) {
/* 1772 */       i = input[this._inputPtr++] & 0xFF;
/* 1773 */       if (codes[i] == 0) {
/* 1774 */         q = q << 8 | i;
/* 1775 */         i = input[this._inputPtr++] & 0xFF;
/* 1776 */         if (codes[i] == 0) {
/* 1777 */           q = q << 8 | i;
/* 1778 */           i = input[this._inputPtr++] & 0xFF;
/* 1779 */           if (codes[i] == 0) {
/* 1780 */             q = q << 8 | i;
/* 1781 */             i = input[this._inputPtr++] & 0xFF;
/* 1782 */             if (codes[i] == 0) {
/* 1783 */               this._quad1 = q;
/* 1784 */               return parseMediumName(i);
/*      */             } 
/* 1786 */             if (i == 34) {
/* 1787 */               return findName(q, 4);
/*      */             }
/* 1789 */             return parseName(q, i, 4);
/*      */           } 
/* 1791 */           if (i == 34) {
/* 1792 */             return findName(q, 3);
/*      */           }
/* 1794 */           return parseName(q, i, 3);
/*      */         } 
/* 1796 */         if (i == 34) {
/* 1797 */           return findName(q, 2);
/*      */         }
/* 1799 */         return parseName(q, i, 2);
/*      */       } 
/* 1801 */       if (i == 34) {
/* 1802 */         return findName(q, 1);
/*      */       }
/* 1804 */       return parseName(q, i, 1);
/*      */     } 
/* 1806 */     if (q == 34) {
/* 1807 */       return "";
/*      */     }
/* 1809 */     return parseName(0, q, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String parseMediumName(int q2) throws IOException {
/* 1814 */     byte[] input = this._inputBuffer;
/* 1815 */     int[] codes = INPUT_CODES_LATIN1;
/*      */ 
/*      */     
/* 1818 */     int i = input[this._inputPtr++] & 0xFF;
/* 1819 */     if (codes[i] != 0) {
/* 1820 */       if (i == 34) {
/* 1821 */         return findName(this._quad1, q2, 1);
/*      */       }
/* 1823 */       return parseName(this._quad1, q2, i, 1);
/*      */     } 
/* 1825 */     q2 = q2 << 8 | i;
/* 1826 */     i = input[this._inputPtr++] & 0xFF;
/* 1827 */     if (codes[i] != 0) {
/* 1828 */       if (i == 34) {
/* 1829 */         return findName(this._quad1, q2, 2);
/*      */       }
/* 1831 */       return parseName(this._quad1, q2, i, 2);
/*      */     } 
/* 1833 */     q2 = q2 << 8 | i;
/* 1834 */     i = input[this._inputPtr++] & 0xFF;
/* 1835 */     if (codes[i] != 0) {
/* 1836 */       if (i == 34) {
/* 1837 */         return findName(this._quad1, q2, 3);
/*      */       }
/* 1839 */       return parseName(this._quad1, q2, i, 3);
/*      */     } 
/* 1841 */     q2 = q2 << 8 | i;
/* 1842 */     i = input[this._inputPtr++] & 0xFF;
/* 1843 */     if (codes[i] != 0) {
/* 1844 */       if (i == 34) {
/* 1845 */         return findName(this._quad1, q2, 4);
/*      */       }
/* 1847 */       return parseName(this._quad1, q2, i, 4);
/*      */     } 
/* 1849 */     return parseMediumName2(i, q2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String parseMediumName2(int q3, int q2) throws IOException {
/* 1855 */     byte[] input = this._inputBuffer;
/* 1856 */     int[] codes = INPUT_CODES_LATIN1;
/*      */ 
/*      */     
/* 1859 */     int i = input[this._inputPtr++] & 0xFF;
/* 1860 */     if (codes[i] != 0) {
/* 1861 */       if (i == 34) {
/* 1862 */         return findName(this._quad1, q2, q3, 1);
/*      */       }
/* 1864 */       return parseName(this._quad1, q2, q3, i, 1);
/*      */     } 
/* 1866 */     q3 = q3 << 8 | i;
/* 1867 */     i = input[this._inputPtr++] & 0xFF;
/* 1868 */     if (codes[i] != 0) {
/* 1869 */       if (i == 34) {
/* 1870 */         return findName(this._quad1, q2, q3, 2);
/*      */       }
/* 1872 */       return parseName(this._quad1, q2, q3, i, 2);
/*      */     } 
/* 1874 */     q3 = q3 << 8 | i;
/* 1875 */     i = input[this._inputPtr++] & 0xFF;
/* 1876 */     if (codes[i] != 0) {
/* 1877 */       if (i == 34) {
/* 1878 */         return findName(this._quad1, q2, q3, 3);
/*      */       }
/* 1880 */       return parseName(this._quad1, q2, q3, i, 3);
/*      */     } 
/* 1882 */     q3 = q3 << 8 | i;
/* 1883 */     i = input[this._inputPtr++] & 0xFF;
/* 1884 */     if (codes[i] != 0) {
/* 1885 */       if (i == 34) {
/* 1886 */         return findName(this._quad1, q2, q3, 4);
/*      */       }
/* 1888 */       return parseName(this._quad1, q2, q3, i, 4);
/*      */     } 
/* 1890 */     return parseLongName(i, q2, q3);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String parseLongName(int q, int q2, int q3) throws IOException {
/* 1895 */     this._quadBuffer[0] = this._quad1;
/* 1896 */     this._quadBuffer[1] = q2;
/* 1897 */     this._quadBuffer[2] = q3;
/*      */ 
/*      */     
/* 1900 */     byte[] input = this._inputBuffer;
/* 1901 */     int[] codes = INPUT_CODES_LATIN1;
/* 1902 */     int qlen = 3;
/*      */     
/* 1904 */     while (this._inputPtr + 4 <= this._inputEnd) {
/* 1905 */       int i = input[this._inputPtr++] & 0xFF;
/* 1906 */       if (codes[i] != 0) {
/* 1907 */         if (i == 34) {
/* 1908 */           return findName(this._quadBuffer, qlen, q, 1);
/*      */         }
/* 1910 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 1);
/*      */       } 
/*      */       
/* 1913 */       q = q << 8 | i;
/* 1914 */       i = input[this._inputPtr++] & 0xFF;
/* 1915 */       if (codes[i] != 0) {
/* 1916 */         if (i == 34) {
/* 1917 */           return findName(this._quadBuffer, qlen, q, 2);
/*      */         }
/* 1919 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 2);
/*      */       } 
/*      */       
/* 1922 */       q = q << 8 | i;
/* 1923 */       i = input[this._inputPtr++] & 0xFF;
/* 1924 */       if (codes[i] != 0) {
/* 1925 */         if (i == 34) {
/* 1926 */           return findName(this._quadBuffer, qlen, q, 3);
/*      */         }
/* 1928 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 3);
/*      */       } 
/*      */       
/* 1931 */       q = q << 8 | i;
/* 1932 */       i = input[this._inputPtr++] & 0xFF;
/* 1933 */       if (codes[i] != 0) {
/* 1934 */         if (i == 34) {
/* 1935 */           return findName(this._quadBuffer, qlen, q, 4);
/*      */         }
/* 1937 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 4);
/*      */       } 
/*      */ 
/*      */       
/* 1941 */       if (qlen >= this._quadBuffer.length) {
/* 1942 */         this._quadBuffer = _growNameDecodeBuffer(this._quadBuffer, qlen);
/*      */       }
/* 1944 */       this._quadBuffer[qlen++] = q;
/* 1945 */       q = i;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1952 */     return parseEscapedName(this._quadBuffer, qlen, 0, q, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String slowParseName() throws IOException {
/* 1960 */     if (this._inputPtr >= this._inputEnd && 
/* 1961 */       !_loadMore()) {
/* 1962 */       _reportInvalidEOF(": was expecting closing '\"' for name", JsonToken.FIELD_NAME);
/*      */     }
/*      */     
/* 1965 */     int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 1966 */     if (i == 34) {
/* 1967 */       return "";
/*      */     }
/* 1969 */     return parseEscapedName(this._quadBuffer, 0, 0, i, 0);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int ch, int lastQuadBytes) throws IOException {
/* 1973 */     return parseEscapedName(this._quadBuffer, 0, q1, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int ch, int lastQuadBytes) throws IOException {
/* 1977 */     this._quadBuffer[0] = q1;
/* 1978 */     return parseEscapedName(this._quadBuffer, 1, q2, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int q3, int ch, int lastQuadBytes) throws IOException {
/* 1982 */     this._quadBuffer[0] = q1;
/* 1983 */     this._quadBuffer[1] = q2;
/* 1984 */     return parseEscapedName(this._quadBuffer, 2, q3, ch, lastQuadBytes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String parseEscapedName(int[] quads, int qlen, int currQuad, int ch, int currQuadBytes) throws IOException {
/* 1997 */     int[] codes = INPUT_CODES_LATIN1;
/*      */     
/*      */     while (true) {
/* 2000 */       if (codes[ch] != 0) {
/* 2001 */         if (ch == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 2005 */         if (ch != 92) {
/*      */           
/* 2007 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 2010 */           ch = _decodeEscaped();
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2015 */         if (ch > 127) {
/*      */           
/* 2017 */           if (currQuadBytes >= 4) {
/* 2018 */             if (qlen >= quads.length) {
/* 2019 */               this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */             }
/* 2021 */             quads[qlen++] = currQuad;
/* 2022 */             currQuad = 0;
/* 2023 */             currQuadBytes = 0;
/*      */           } 
/* 2025 */           if (ch < 2048) {
/* 2026 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2027 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 2030 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 2031 */             currQuadBytes++;
/*      */             
/* 2033 */             if (currQuadBytes >= 4) {
/* 2034 */               if (qlen >= quads.length) {
/* 2035 */                 this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */               }
/* 2037 */               quads[qlen++] = currQuad;
/* 2038 */               currQuad = 0;
/* 2039 */               currQuadBytes = 0;
/*      */             } 
/* 2041 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2042 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 2045 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 2049 */       if (currQuadBytes < 4) {
/* 2050 */         currQuadBytes++;
/* 2051 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 2053 */         if (qlen >= quads.length) {
/* 2054 */           this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */         }
/* 2056 */         quads[qlen++] = currQuad;
/* 2057 */         currQuad = ch;
/* 2058 */         currQuadBytes = 1;
/*      */       } 
/* 2060 */       if (this._inputPtr >= this._inputEnd && 
/* 2061 */         !_loadMore()) {
/* 2062 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 2065 */       ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */     } 
/*      */     
/* 2068 */     if (currQuadBytes > 0) {
/* 2069 */       if (qlen >= quads.length) {
/* 2070 */         this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */       }
/* 2072 */       quads[qlen++] = _padLastQuad(currQuad, currQuadBytes);
/*      */     } 
/* 2074 */     String name = this._symbols.findName(quads, qlen);
/* 2075 */     if (name == null) {
/* 2076 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2078 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _handleOddName(int ch) throws IOException {
/* 2097 */     if (ch == 39 && (this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 2098 */       return _parseAposName();
/*      */     }
/*      */     
/* 2101 */     if ((this._features & FEAT_MASK_ALLOW_UNQUOTED_NAMES) == 0) {
/* 2102 */       char c = (char)_decodeCharForError(ch);
/* 2103 */       _reportUnexpectedChar(c, "was expecting double-quote to start field name");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2109 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */     
/* 2111 */     if (codes[ch] != 0) {
/* 2112 */       _reportUnexpectedChar(ch, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2118 */     int[] quads = this._quadBuffer;
/* 2119 */     int qlen = 0;
/* 2120 */     int currQuad = 0;
/* 2121 */     int currQuadBytes = 0;
/*      */ 
/*      */     
/*      */     while (true) {
/* 2125 */       if (currQuadBytes < 4) {
/* 2126 */         currQuadBytes++;
/* 2127 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 2129 */         if (qlen >= quads.length) {
/* 2130 */           this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */         }
/* 2132 */         quads[qlen++] = currQuad;
/* 2133 */         currQuad = ch;
/* 2134 */         currQuadBytes = 1;
/*      */       } 
/* 2136 */       if (this._inputPtr >= this._inputEnd && 
/* 2137 */         !_loadMore()) {
/* 2138 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 2141 */       ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2142 */       if (codes[ch] != 0) {
/*      */         break;
/*      */       }
/* 2145 */       this._inputPtr++;
/*      */     } 
/*      */     
/* 2148 */     if (currQuadBytes > 0) {
/* 2149 */       if (qlen >= quads.length) {
/* 2150 */         this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */       }
/* 2152 */       quads[qlen++] = currQuad;
/*      */     } 
/* 2154 */     String name = this._symbols.findName(quads, qlen);
/* 2155 */     if (name == null) {
/* 2156 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2158 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _parseAposName() throws IOException {
/* 2167 */     if (this._inputPtr >= this._inputEnd && 
/* 2168 */       !_loadMore()) {
/* 2169 */       _reportInvalidEOF(": was expecting closing ''' for field name", JsonToken.FIELD_NAME);
/*      */     }
/*      */     
/* 2172 */     int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 2173 */     if (ch == 39) {
/* 2174 */       return "";
/*      */     }
/* 2176 */     int[] quads = this._quadBuffer;
/* 2177 */     int qlen = 0;
/* 2178 */     int currQuad = 0;
/* 2179 */     int currQuadBytes = 0;
/*      */ 
/*      */ 
/*      */     
/* 2183 */     int[] codes = INPUT_CODES_LATIN1;
/*      */ 
/*      */     
/* 2186 */     while (ch != 39) {
/*      */ 
/*      */ 
/*      */       
/* 2190 */       if (codes[ch] != 0 && ch != 34) {
/* 2191 */         if (ch != 92) {
/*      */ 
/*      */           
/* 2194 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 2197 */           ch = _decodeEscaped();
/*      */         } 
/*      */         
/* 2200 */         if (ch > 127) {
/*      */           
/* 2202 */           if (currQuadBytes >= 4) {
/* 2203 */             if (qlen >= quads.length) {
/* 2204 */               this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */             }
/* 2206 */             quads[qlen++] = currQuad;
/* 2207 */             currQuad = 0;
/* 2208 */             currQuadBytes = 0;
/*      */           } 
/* 2210 */           if (ch < 2048) {
/* 2211 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2212 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 2215 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 2216 */             currQuadBytes++;
/*      */             
/* 2218 */             if (currQuadBytes >= 4) {
/* 2219 */               if (qlen >= quads.length) {
/* 2220 */                 this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */               }
/* 2222 */               quads[qlen++] = currQuad;
/* 2223 */               currQuad = 0;
/* 2224 */               currQuadBytes = 0;
/*      */             } 
/* 2226 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2227 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 2230 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 2234 */       if (currQuadBytes < 4) {
/* 2235 */         currQuadBytes++;
/* 2236 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 2238 */         if (qlen >= quads.length) {
/* 2239 */           this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */         }
/* 2241 */         quads[qlen++] = currQuad;
/* 2242 */         currQuad = ch;
/* 2243 */         currQuadBytes = 1;
/*      */       } 
/* 2245 */       if (this._inputPtr >= this._inputEnd && 
/* 2246 */         !_loadMore()) {
/* 2247 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 2250 */       ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */     } 
/*      */     
/* 2253 */     if (currQuadBytes > 0) {
/* 2254 */       if (qlen >= quads.length) {
/* 2255 */         this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */       }
/* 2257 */       quads[qlen++] = _padLastQuad(currQuad, currQuadBytes);
/*      */     } 
/* 2259 */     String name = this._symbols.findName(quads, qlen);
/* 2260 */     if (name == null) {
/* 2261 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2263 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int lastQuadBytes) throws JsonParseException, StreamConstraintsException {
/* 2275 */     q1 = _padLastQuad(q1, lastQuadBytes);
/*      */     
/* 2277 */     String name = this._symbols.findName(q1);
/* 2278 */     if (name != null) {
/* 2279 */       return name;
/*      */     }
/*      */     
/* 2282 */     this._quadBuffer[0] = q1;
/* 2283 */     return addName(this._quadBuffer, 1, lastQuadBytes);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int q2, int lastQuadBytes) throws JsonParseException, StreamConstraintsException {
/* 2289 */     q2 = _padLastQuad(q2, lastQuadBytes);
/*      */     
/* 2291 */     String name = this._symbols.findName(q1, q2);
/* 2292 */     if (name != null) {
/* 2293 */       return name;
/*      */     }
/*      */     
/* 2296 */     this._quadBuffer[0] = q1;
/* 2297 */     this._quadBuffer[1] = q2;
/* 2298 */     return addName(this._quadBuffer, 2, lastQuadBytes);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int q2, int q3, int lastQuadBytes) throws JsonParseException, StreamConstraintsException {
/* 2304 */     q3 = _padLastQuad(q3, lastQuadBytes);
/* 2305 */     String name = this._symbols.findName(q1, q2, q3);
/* 2306 */     if (name != null) {
/* 2307 */       return name;
/*      */     }
/* 2309 */     int[] quads = this._quadBuffer;
/* 2310 */     quads[0] = q1;
/* 2311 */     quads[1] = q2;
/* 2312 */     quads[2] = _padLastQuad(q3, lastQuadBytes);
/* 2313 */     return addName(quads, 3, lastQuadBytes);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final String findName(int[] quads, int qlen, int lastQuad, int lastQuadBytes) throws JsonParseException, StreamConstraintsException {
/* 2319 */     if (qlen >= quads.length) {
/* 2320 */       this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */     }
/* 2322 */     quads[qlen++] = _padLastQuad(lastQuad, lastQuadBytes);
/* 2323 */     String name = this._symbols.findName(quads, qlen);
/* 2324 */     if (name == null) {
/* 2325 */       return addName(quads, qlen, lastQuadBytes);
/*      */     }
/* 2327 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String addName(int[] quads, int qlen, int lastQuadBytes) throws JsonParseException, StreamConstraintsException {
/* 2343 */     int lastQuad, byteLen = (qlen << 2) - 4 + lastQuadBytes;
/* 2344 */     this._streamReadConstraints.validateNameLength(byteLen);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2353 */     if (lastQuadBytes < 4) {
/* 2354 */       lastQuad = quads[qlen - 1];
/*      */       
/* 2356 */       quads[qlen - 1] = lastQuad << 4 - lastQuadBytes << 3;
/*      */     } else {
/* 2358 */       lastQuad = 0;
/*      */     } 
/*      */ 
/*      */     
/* 2362 */     char[] cbuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2363 */     int cix = 0;
/*      */     
/* 2365 */     for (int ix = 0; ix < byteLen; ) {
/* 2366 */       int ch = quads[ix >> 2];
/* 2367 */       int byteIx = ix & 0x3;
/* 2368 */       ch = ch >> 3 - byteIx << 3 & 0xFF;
/* 2369 */       ix++;
/*      */       
/* 2371 */       if (ch > 127) {
/*      */         int needed;
/* 2373 */         if ((ch & 0xE0) == 192) {
/* 2374 */           ch &= 0x1F;
/* 2375 */           needed = 1;
/* 2376 */         } else if ((ch & 0xF0) == 224) {
/* 2377 */           ch &= 0xF;
/* 2378 */           needed = 2;
/* 2379 */         } else if ((ch & 0xF8) == 240) {
/* 2380 */           ch &= 0x7;
/* 2381 */           needed = 3;
/*      */         } else {
/* 2383 */           _reportInvalidInitial(ch);
/* 2384 */           needed = ch = 1;
/*      */         } 
/* 2386 */         if (ix + needed > byteLen) {
/* 2387 */           _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */         }
/*      */ 
/*      */         
/* 2391 */         int ch2 = quads[ix >> 2];
/* 2392 */         byteIx = ix & 0x3;
/* 2393 */         ch2 >>= 3 - byteIx << 3;
/* 2394 */         ix++;
/*      */         
/* 2396 */         if ((ch2 & 0xC0) != 128) {
/* 2397 */           _reportInvalidOther(ch2);
/*      */         }
/* 2399 */         ch = ch << 6 | ch2 & 0x3F;
/* 2400 */         if (needed > 1) {
/* 2401 */           ch2 = quads[ix >> 2];
/* 2402 */           byteIx = ix & 0x3;
/* 2403 */           ch2 >>= 3 - byteIx << 3;
/* 2404 */           ix++;
/*      */           
/* 2406 */           if ((ch2 & 0xC0) != 128) {
/* 2407 */             _reportInvalidOther(ch2);
/*      */           }
/* 2409 */           ch = ch << 6 | ch2 & 0x3F;
/* 2410 */           if (needed > 2) {
/* 2411 */             ch2 = quads[ix >> 2];
/* 2412 */             byteIx = ix & 0x3;
/* 2413 */             ch2 >>= 3 - byteIx << 3;
/* 2414 */             ix++;
/* 2415 */             if ((ch2 & 0xC0) != 128) {
/* 2416 */               _reportInvalidOther(ch2 & 0xFF);
/*      */             }
/* 2418 */             ch = ch << 6 | ch2 & 0x3F;
/*      */           } 
/*      */         } 
/* 2421 */         if (needed > 2) {
/* 2422 */           ch -= 65536;
/* 2423 */           if (cix >= cbuf.length) {
/* 2424 */             cbuf = this._textBuffer.expandCurrentSegment();
/*      */           }
/* 2426 */           cbuf[cix++] = (char)(55296 + (ch >> 10));
/* 2427 */           ch = 0xDC00 | ch & 0x3FF;
/*      */         } 
/*      */       } 
/* 2430 */       if (cix >= cbuf.length) {
/* 2431 */         cbuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 2433 */       cbuf[cix++] = (char)ch;
/*      */     } 
/*      */ 
/*      */     
/* 2437 */     String baseName = new String(cbuf, 0, cix);
/*      */     
/* 2439 */     if (lastQuadBytes < 4) {
/* 2440 */       quads[qlen - 1] = lastQuad;
/*      */     }
/* 2442 */     return this._symbols.addName(baseName, quads, qlen);
/*      */   }
/*      */ 
/*      */   
/*      */   private static final int _padLastQuad(int q, int bytes) {
/* 2447 */     return (bytes == 4) ? q : (q | -1 << bytes << 3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _loadMoreGuaranteed() throws IOException {
/* 2457 */     if (!_loadMore()) _reportInvalidEOF();
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _finishString() throws IOException {
/* 2464 */     int ptr = this._inputPtr;
/* 2465 */     if (ptr >= this._inputEnd) {
/* 2466 */       _loadMoreGuaranteed();
/* 2467 */       ptr = this._inputPtr;
/*      */     } 
/* 2469 */     int outPtr = 0;
/* 2470 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2471 */     int[] codes = INPUT_CODES_UTF8;
/*      */     
/* 2473 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2474 */     byte[] inputBuffer = this._inputBuffer;
/* 2475 */     while (ptr < max) {
/* 2476 */       int c = inputBuffer[ptr] & 0xFF;
/* 2477 */       if (codes[c] != 0) {
/* 2478 */         if (c == 34) {
/* 2479 */           this._inputPtr = ptr + 1;
/* 2480 */           this._textBuffer.setCurrentLength(outPtr);
/*      */           return;
/*      */         } 
/*      */         break;
/*      */       } 
/* 2485 */       ptr++;
/* 2486 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 2488 */     this._inputPtr = ptr;
/* 2489 */     _finishString2(outBuf, outPtr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _finishAndReturnString() throws IOException {
/* 2496 */     int ptr = this._inputPtr;
/* 2497 */     if (ptr >= this._inputEnd) {
/* 2498 */       _loadMoreGuaranteed();
/* 2499 */       ptr = this._inputPtr;
/*      */     } 
/* 2501 */     int outPtr = 0;
/* 2502 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2503 */     int[] codes = INPUT_CODES_UTF8;
/*      */     
/* 2505 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2506 */     byte[] inputBuffer = this._inputBuffer;
/* 2507 */     while (ptr < max) {
/* 2508 */       int c = inputBuffer[ptr] & 0xFF;
/* 2509 */       if (codes[c] != 0) {
/* 2510 */         if (c == 34) {
/* 2511 */           this._inputPtr = ptr + 1;
/* 2512 */           return this._textBuffer.setCurrentAndReturn(outPtr);
/*      */         } 
/*      */         break;
/*      */       } 
/* 2516 */       ptr++;
/* 2517 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 2519 */     this._inputPtr = ptr;
/* 2520 */     _finishString2(outBuf, outPtr);
/* 2521 */     return this._textBuffer.contentsAsString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _finishString2(char[] outBuf, int outPtr) throws IOException {
/* 2530 */     int[] codes = INPUT_CODES_UTF8;
/* 2531 */     byte[] inputBuffer = this._inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2538 */       int ptr = this._inputPtr;
/* 2539 */       if (ptr >= this._inputEnd) {
/* 2540 */         _loadMoreGuaranteed();
/* 2541 */         ptr = this._inputPtr;
/*      */       } 
/* 2543 */       if (outPtr >= outBuf.length) {
/* 2544 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2545 */         outPtr = 0;
/*      */       } 
/* 2547 */       int max = Math.min(this._inputEnd, 
/*      */           
/* 2549 */           InternalJacksonUtil.addOverflowSafe(ptr, outBuf.length - outPtr));
/* 2550 */       while (ptr < max) {
/* 2551 */         int c = inputBuffer[ptr++] & 0xFF;
/* 2552 */         if (codes[c] != 0) {
/* 2553 */           this._inputPtr = ptr;
/*      */         } else {
/*      */           
/* 2556 */           outBuf[outPtr++] = (char)c;
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/* 2561 */         if (c == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 2565 */         switch (codes[c]) {
/*      */           case 1:
/* 2567 */             c = _decodeEscaped();
/*      */             break;
/*      */           case 2:
/* 2570 */             c = _decodeUtf8_2(c);
/*      */             break;
/*      */           case 3:
/* 2573 */             if (this._inputEnd - this._inputPtr >= 2) {
/* 2574 */               c = _decodeUtf8_3fast(c); break;
/*      */             } 
/* 2576 */             c = _decodeUtf8_3(c);
/*      */             break;
/*      */           
/*      */           case 4:
/* 2580 */             c = _decodeUtf8_4(c);
/*      */             
/* 2582 */             outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2583 */             if (outPtr >= outBuf.length) {
/* 2584 */               outBuf = this._textBuffer.finishCurrentSegment();
/* 2585 */               outPtr = 0;
/*      */             } 
/* 2587 */             c = 0xDC00 | c & 0x3FF;
/*      */             break;
/*      */           
/*      */           default:
/* 2591 */             if (c < 32) {
/*      */               
/* 2593 */               _throwUnquotedSpace(c, "string value");
/*      */               break;
/*      */             } 
/* 2596 */             _reportInvalidChar(c);
/*      */             break;
/*      */         } 
/*      */         
/* 2600 */         if (outPtr >= outBuf.length) {
/* 2601 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 2602 */           outPtr = 0;
/*      */         } 
/*      */         
/* 2605 */         outBuf[outPtr++] = (char)c;
/*      */       }  this._inputPtr = ptr;
/* 2607 */     }  this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _skipString() throws IOException {
/* 2620 */     this._tokenIncomplete = false;
/*      */ 
/*      */     
/* 2623 */     int[] codes = INPUT_CODES_UTF8;
/* 2624 */     byte[] inputBuffer = this._inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2632 */       int ptr = this._inputPtr;
/* 2633 */       int max = this._inputEnd;
/* 2634 */       if (ptr >= max) {
/* 2635 */         _loadMoreGuaranteed();
/* 2636 */         ptr = this._inputPtr;
/* 2637 */         max = this._inputEnd;
/*      */       } 
/* 2639 */       while (ptr < max) {
/* 2640 */         int c = inputBuffer[ptr++] & 0xFF;
/* 2641 */         if (codes[c] != 0) {
/* 2642 */           this._inputPtr = ptr;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2649 */           if (c != 34) {
/*      */ 
/*      */ 
/*      */             
/* 2653 */             switch (codes[c]) {
/*      */               case 1:
/* 2655 */                 _decodeEscaped();
/*      */                 continue;
/*      */               case 2:
/* 2658 */                 _skipUtf8_2();
/*      */                 continue;
/*      */               case 3:
/* 2661 */                 _skipUtf8_3();
/*      */                 continue;
/*      */               case 4:
/* 2664 */                 _skipUtf8_4(c);
/*      */                 continue;
/*      */             } 
/* 2667 */             if (c < 32) {
/* 2668 */               _throwUnquotedSpace(c, "string value");
/*      */               continue;
/*      */             } 
/* 2671 */             _reportInvalidChar(c);
/*      */             continue;
/*      */           } 
/*      */           return;
/*      */         } 
/*      */       } 
/*      */       this._inputPtr = ptr;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleUnexpectedValue(int c) throws IOException {
/* 2691 */     switch (c) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 93:
/* 2700 */         if (!this._parsingContext.inArray()) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 44:
/* 2709 */         if (!this._parsingContext.inRoot() && (
/* 2710 */           this._features & FEAT_MASK_ALLOW_MISSING) != 0) {
/* 2711 */           this._inputPtr--;
/* 2712 */           return JsonToken.VALUE_NULL;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 125:
/* 2719 */         _reportUnexpectedChar(c, "expected a value");
/*      */       case 39:
/* 2721 */         if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 2722 */           return _handleApos();
/*      */         }
/*      */         break;
/*      */       case 78:
/* 2726 */         _matchToken("NaN", 1);
/* 2727 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2728 */           return resetAsNaN("NaN", Double.NaN);
/*      */         }
/* 2730 */         _reportError("Non-standard token 'NaN': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/*      */         break;
/*      */       case 73:
/* 2733 */         _matchToken("Infinity", 1);
/* 2734 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2735 */           return resetAsNaN("Infinity", Double.POSITIVE_INFINITY);
/*      */         }
/* 2737 */         _reportError("Non-standard token 'Infinity': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/*      */         break;
/*      */       case 43:
/* 2740 */         if (this._inputPtr >= this._inputEnd && 
/* 2741 */           !_loadMore()) {
/* 2742 */           _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_INT);
/*      */         }
/*      */         
/* 2745 */         return _handleInvalidNumberStart(this._inputBuffer[this._inputPtr++] & 0xFF, false, true);
/*      */     } 
/*      */     
/* 2748 */     if (Character.isJavaIdentifierStart(c)) {
/* 2749 */       _reportInvalidToken("" + (char)c, _validJsonTokenList());
/*      */     }
/*      */     
/* 2752 */     _reportUnexpectedChar(c, "expected a valid value " + _validJsonValueList());
/* 2753 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleApos() throws IOException {
/* 2758 */     int c = 0;
/*      */     
/* 2760 */     int outPtr = 0;
/* 2761 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */ 
/*      */     
/* 2764 */     int[] codes = INPUT_CODES_UTF8;
/* 2765 */     byte[] inputBuffer = this._inputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true)
/* 2772 */     { if (this._inputPtr >= this._inputEnd) {
/* 2773 */         _loadMoreGuaranteed();
/*      */       }
/* 2775 */       if (outPtr >= outBuf.length) {
/* 2776 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2777 */         outPtr = 0;
/*      */       } 
/* 2779 */       int max = this._inputEnd;
/*      */ 
/*      */       
/* 2782 */       int max2 = InternalJacksonUtil.addOverflowSafe(this._inputPtr, outBuf.length - outPtr);
/* 2783 */       if (max2 < max) {
/* 2784 */         max = max2;
/*      */       }
/*      */       
/* 2787 */       while (this._inputPtr < max)
/* 2788 */       { c = inputBuffer[this._inputPtr++] & 0xFF;
/* 2789 */         if (c != 39) {
/*      */ 
/*      */           
/* 2792 */           if (codes[c] != 0 && c != 34) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2802 */             switch (codes[c]) {
/*      */               case 1:
/* 2804 */                 c = _decodeEscaped();
/*      */                 break;
/*      */               case 2:
/* 2807 */                 c = _decodeUtf8_2(c);
/*      */                 break;
/*      */               case 3:
/* 2810 */                 if (this._inputEnd - this._inputPtr >= 2) {
/* 2811 */                   c = _decodeUtf8_3fast(c); break;
/*      */                 } 
/* 2813 */                 c = _decodeUtf8_3(c);
/*      */                 break;
/*      */               
/*      */               case 4:
/* 2817 */                 c = _decodeUtf8_4(c);
/*      */                 
/* 2819 */                 outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2820 */                 if (outPtr >= outBuf.length) {
/* 2821 */                   outBuf = this._textBuffer.finishCurrentSegment();
/* 2822 */                   outPtr = 0;
/*      */                 } 
/* 2824 */                 c = 0xDC00 | c & 0x3FF;
/*      */                 break;
/*      */               
/*      */               default:
/* 2828 */                 if (c < 32) {
/* 2829 */                   _throwUnquotedSpace(c, "string value");
/*      */                 }
/*      */                 
/* 2832 */                 _reportInvalidChar(c);
/*      */                 break;
/*      */             } 
/* 2835 */             if (outPtr >= outBuf.length) {
/* 2836 */               outBuf = this._textBuffer.finishCurrentSegment();
/* 2837 */               outPtr = 0;
/*      */             } 
/*      */             
/* 2840 */             outBuf[outPtr++] = (char)c; continue;
/*      */           }  outBuf[outPtr++] = (char)c; continue;
/* 2842 */         }  this._textBuffer.setCurrentLength(outPtr);
/*      */         
/* 2844 */         return JsonToken.VALUE_STRING; }  }  this._textBuffer.setCurrentLength(outPtr); return JsonToken.VALUE_STRING;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean neg) throws IOException {
/* 2857 */     return _handleInvalidNumberStart(ch, neg, false);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean neg, boolean hasSign) throws IOException {
/* 2862 */     while (ch == 73) {
/* 2863 */       String match; if (this._inputPtr >= this._inputEnd && 
/* 2864 */         !_loadMore()) {
/* 2865 */         _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_FLOAT);
/*      */       }
/*      */       
/* 2868 */       ch = this._inputBuffer[this._inputPtr++];
/*      */       
/* 2870 */       if (ch == 78) {
/* 2871 */         match = neg ? "-INF" : "+INF";
/* 2872 */       } else if (ch == 110) {
/* 2873 */         match = neg ? "-Infinity" : "+Infinity";
/*      */       } else {
/*      */         break;
/*      */       } 
/* 2877 */       _matchToken(match, 3);
/* 2878 */       if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2879 */         return resetAsNaN(match, neg ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */       }
/* 2881 */       _reportError("Non-standard token '%s': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow", match);
/*      */     } 
/*      */     
/* 2884 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature()) && hasSign && !neg) {
/* 2885 */       _reportUnexpectedNumberChar(43, "JSON spec does not allow numbers to have plus signs: enable `JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS` to allow");
/*      */     }
/* 2887 */     String message = neg ? "expected digit (0-9) to follow minus sign, for valid numeric value" : "expected digit (0-9) for valid numeric value";
/*      */ 
/*      */     
/* 2890 */     _reportUnexpectedNumberChar(ch, message);
/* 2891 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _matchTrue() throws IOException {
/* 2897 */     int ptr = this._inputPtr;
/* 2898 */     if (ptr + 3 < this._inputEnd) {
/* 2899 */       byte[] buf = this._inputBuffer;
/* 2900 */       if (buf[ptr++] == 114 && buf[ptr++] == 117 && buf[ptr++] == 101) {
/*      */ 
/*      */         
/* 2903 */         int ch = buf[ptr] & 0xFF;
/* 2904 */         if (ch < 48 || (ch | 0x20) == 125) {
/* 2905 */           this._inputPtr = ptr;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2910 */     _matchToken2("true", 1);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _matchFalse() throws IOException {
/* 2915 */     int ptr = this._inputPtr;
/* 2916 */     if (ptr + 4 < this._inputEnd) {
/* 2917 */       byte[] buf = this._inputBuffer;
/* 2918 */       if (buf[ptr++] == 97 && buf[ptr++] == 108 && buf[ptr++] == 115 && buf[ptr++] == 101) {
/*      */ 
/*      */ 
/*      */         
/* 2922 */         int ch = buf[ptr] & 0xFF;
/* 2923 */         if (ch < 48 || (ch | 0x20) == 125) {
/* 2924 */           this._inputPtr = ptr;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2929 */     _matchToken2("false", 1);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _matchNull() throws IOException {
/* 2934 */     int ptr = this._inputPtr;
/* 2935 */     if (ptr + 3 < this._inputEnd) {
/* 2936 */       byte[] buf = this._inputBuffer;
/* 2937 */       if (buf[ptr++] == 117 && buf[ptr++] == 108 && buf[ptr++] == 108) {
/*      */ 
/*      */         
/* 2940 */         int ch = buf[ptr] & 0xFF;
/* 2941 */         if (ch < 48 || (ch | 0x20) == 125) {
/* 2942 */           this._inputPtr = ptr;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2947 */     _matchToken2("null", 1);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _matchToken(String matchStr, int i) throws IOException {
/* 2952 */     int len = matchStr.length();
/* 2953 */     if (this._inputPtr + len >= this._inputEnd) {
/* 2954 */       _matchToken2(matchStr, i);
/*      */       return;
/*      */     } 
/*      */     do {
/* 2958 */       if (this._inputBuffer[this._inputPtr] != matchStr.charAt(i)) {
/* 2959 */         _reportInvalidToken(matchStr.substring(0, i));
/*      */       }
/* 2961 */       this._inputPtr++;
/* 2962 */     } while (++i < len);
/*      */     
/* 2964 */     int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2965 */     if (ch >= 48 && ch != 93 && ch != 125) {
/* 2966 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _matchToken2(String matchStr, int i) throws IOException {
/* 2972 */     int len = matchStr.length();
/*      */     do {
/* 2974 */       if ((this._inputPtr >= this._inputEnd && !_loadMore()) || this._inputBuffer[this._inputPtr] != matchStr
/* 2975 */         .charAt(i)) {
/* 2976 */         _reportInvalidToken(matchStr.substring(0, i));
/*      */       }
/* 2978 */       this._inputPtr++;
/* 2979 */     } while (++i < len);
/*      */ 
/*      */     
/* 2982 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */       return;
/*      */     }
/* 2985 */     int ch = this._inputBuffer[this._inputPtr] & 0xFF;
/* 2986 */     if (ch >= 48 && ch != 93 && ch != 125) {
/* 2987 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _checkMatchEnd(String matchStr, int i, int ch) throws IOException {
/* 2993 */     char c = (char)_decodeCharForError(ch);
/* 2994 */     if (Character.isJavaIdentifierPart(c)) {
/* 2995 */       _reportInvalidToken(matchStr.substring(0, i));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWS() throws IOException {
/* 3007 */     while (this._inputPtr < this._inputEnd) {
/* 3008 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3009 */       if (i > 32) {
/* 3010 */         if (i == 47 || i == 35) {
/* 3011 */           this._inputPtr--;
/* 3012 */           return _skipWS2();
/*      */         } 
/* 3014 */         return i;
/*      */       } 
/* 3016 */       if (i != 32) {
/* 3017 */         if (i == 10) {
/* 3018 */           this._currInputRow++;
/* 3019 */           this._currInputRowStart = this._inputPtr; continue;
/* 3020 */         }  if (i == 13) {
/* 3021 */           _skipCR(); continue;
/* 3022 */         }  if (i != 9) {
/* 3023 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 3027 */     return _skipWS2();
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipWS2() throws IOException {
/* 3032 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3033 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3034 */       if (i > 32) {
/* 3035 */         if (i == 47) {
/* 3036 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 3039 */         if (i == 35 && 
/* 3040 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 3044 */         return i;
/*      */       } 
/* 3046 */       if (i != 32) {
/* 3047 */         if (i == 10) {
/* 3048 */           this._currInputRow++;
/* 3049 */           this._currInputRowStart = this._inputPtr; continue;
/* 3050 */         }  if (i == 13) {
/* 3051 */           _skipCR(); continue;
/* 3052 */         }  if (i != 9) {
/* 3053 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 3057 */     throw _constructError("Unexpected end-of-input within/between " + this._parsingContext.typeDesc() + " entries");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWSOrEnd() throws IOException {
/* 3064 */     if (this._inputPtr >= this._inputEnd && 
/* 3065 */       !_loadMore()) {
/* 3066 */       return _eofAsNextChar();
/*      */     }
/*      */     
/* 3069 */     int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3070 */     if (i > 32) {
/* 3071 */       if (i == 47 || i == 35) {
/* 3072 */         this._inputPtr--;
/* 3073 */         return _skipWSOrEnd2();
/*      */       } 
/* 3075 */       return i;
/*      */     } 
/* 3077 */     if (i != 32) {
/* 3078 */       if (i == 10) {
/* 3079 */         this._currInputRow++;
/* 3080 */         this._currInputRowStart = this._inputPtr;
/* 3081 */       } else if (i == 13) {
/* 3082 */         _skipCR();
/* 3083 */       } else if (i != 9 && !_isAllowedCtrlCharRS(i)) {
/* 3084 */         _throwInvalidSpace(i);
/*      */       } 
/*      */     }
/*      */     
/* 3088 */     while (this._inputPtr < this._inputEnd) {
/* 3089 */       i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3090 */       if (i > 32) {
/* 3091 */         if (i == 47 || i == 35) {
/* 3092 */           this._inputPtr--;
/* 3093 */           return _skipWSOrEnd2();
/*      */         } 
/* 3095 */         return i;
/*      */       } 
/* 3097 */       if (i != 32) {
/* 3098 */         if (i == 10) {
/* 3099 */           this._currInputRow++;
/* 3100 */           this._currInputRowStart = this._inputPtr; continue;
/* 3101 */         }  if (i == 13) {
/* 3102 */           _skipCR(); continue;
/* 3103 */         }  if (i != 9 && !_isAllowedCtrlCharRS(i)) {
/* 3104 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 3108 */     return _skipWSOrEnd2();
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipWSOrEnd2() throws IOException {
/* 3113 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3114 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3115 */       if (i > 32) {
/* 3116 */         if (i == 47) {
/* 3117 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 3120 */         if (i == 35 && 
/* 3121 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 3125 */         return i;
/* 3126 */       }  if (i != 32) {
/* 3127 */         if (i == 10) {
/* 3128 */           this._currInputRow++;
/* 3129 */           this._currInputRowStart = this._inputPtr; continue;
/* 3130 */         }  if (i == 13) {
/* 3131 */           _skipCR(); continue;
/* 3132 */         }  if (i != 9) {
/* 3133 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 3138 */     return _eofAsNextChar();
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon() throws IOException {
/* 3143 */     if (this._inputPtr + 4 >= this._inputEnd) {
/* 3144 */       return _skipColon2(false);
/*      */     }
/*      */     
/* 3147 */     int i = this._inputBuffer[this._inputPtr];
/* 3148 */     if (i == 58) {
/* 3149 */       i = this._inputBuffer[++this._inputPtr];
/* 3150 */       if (i > 32) {
/* 3151 */         if (i == 47 || i == 35) {
/* 3152 */           return _skipColon2(true);
/*      */         }
/* 3154 */         this._inputPtr++;
/* 3155 */         return i;
/*      */       } 
/* 3157 */       if (i == 32 || i == 9) {
/* 3158 */         i = this._inputBuffer[++this._inputPtr];
/* 3159 */         if (i > 32) {
/* 3160 */           if (i == 47 || i == 35) {
/* 3161 */             return _skipColon2(true);
/*      */           }
/* 3163 */           this._inputPtr++;
/* 3164 */           return i;
/*      */         } 
/*      */       } 
/* 3167 */       return _skipColon2(true);
/*      */     } 
/* 3169 */     if (i == 32 || i == 9) {
/* 3170 */       i = this._inputBuffer[++this._inputPtr];
/*      */     }
/* 3172 */     if (i == 58) {
/* 3173 */       i = this._inputBuffer[++this._inputPtr];
/* 3174 */       if (i > 32) {
/* 3175 */         if (i == 47 || i == 35) {
/* 3176 */           return _skipColon2(true);
/*      */         }
/* 3178 */         this._inputPtr++;
/* 3179 */         return i;
/*      */       } 
/* 3181 */       if (i == 32 || i == 9) {
/* 3182 */         i = this._inputBuffer[++this._inputPtr];
/* 3183 */         if (i > 32) {
/* 3184 */           if (i == 47 || i == 35) {
/* 3185 */             return _skipColon2(true);
/*      */           }
/* 3187 */           this._inputPtr++;
/* 3188 */           return i;
/*      */         } 
/*      */       } 
/* 3191 */       return _skipColon2(true);
/*      */     } 
/* 3193 */     return _skipColon2(false);
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon2(boolean gotColon) throws IOException {
/* 3198 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3199 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */       
/* 3201 */       if (i > 32) {
/* 3202 */         if (i == 47) {
/* 3203 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 3206 */         if (i == 35 && 
/* 3207 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 3211 */         if (gotColon) {
/* 3212 */           return i;
/*      */         }
/* 3214 */         if (i != 58) {
/* 3215 */           _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */         }
/* 3217 */         gotColon = true; continue;
/* 3218 */       }  if (i != 32) {
/* 3219 */         if (i == 10) {
/* 3220 */           this._currInputRow++;
/* 3221 */           this._currInputRowStart = this._inputPtr; continue;
/* 3222 */         }  if (i == 13) {
/* 3223 */           _skipCR(); continue;
/* 3224 */         }  if (i != 9) {
/* 3225 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 3229 */     _reportInvalidEOF(" within/between " + this._parsingContext.typeDesc() + " entries", null);
/*      */     
/* 3231 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipComment() throws IOException {
/* 3236 */     if ((this._features & FEAT_MASK_ALLOW_JAVA_COMMENTS) == 0) {
/* 3237 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/*      */     
/* 3240 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 3241 */       _reportInvalidEOF(" in a comment", null);
/*      */     }
/* 3243 */     int c = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3244 */     if (c == 47) {
/* 3245 */       _skipLine();
/* 3246 */     } else if (c == 42) {
/* 3247 */       _skipCComment();
/*      */     } else {
/* 3249 */       _reportUnexpectedChar(c, "was expecting either '*' or '/' for a comment");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipCComment() throws IOException {
/* 3256 */     int[] codes = CharTypes.getInputCodeComment();
/*      */ 
/*      */ 
/*      */     
/* 3260 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3261 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3262 */       int code = codes[i];
/* 3263 */       if (code != 0) {
/* 3264 */         switch (code) {
/*      */           case 42:
/* 3266 */             if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */               break;
/*      */             }
/* 3269 */             if (this._inputBuffer[this._inputPtr] == 47) {
/* 3270 */               this._inputPtr++;
/*      */               return;
/*      */             } 
/*      */             continue;
/*      */           case 10:
/* 3275 */             this._currInputRow++;
/* 3276 */             this._currInputRowStart = this._inputPtr;
/*      */             continue;
/*      */           case 13:
/* 3279 */             _skipCR();
/*      */             continue;
/*      */           case 2:
/* 3282 */             _skipUtf8_2();
/*      */             continue;
/*      */           case 3:
/* 3285 */             _skipUtf8_3();
/*      */             continue;
/*      */           case 4:
/* 3288 */             _skipUtf8_4(i);
/*      */             continue;
/*      */         } 
/*      */         
/* 3292 */         _reportInvalidChar(i);
/*      */       } 
/*      */     } 
/*      */     
/* 3296 */     _reportInvalidEOF(" in a comment", null);
/*      */   }
/*      */ 
/*      */   
/*      */   private final boolean _skipYAMLComment() throws IOException {
/* 3301 */     if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) == 0) {
/* 3302 */       return false;
/*      */     }
/* 3304 */     _skipLine();
/* 3305 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipLine() throws IOException {
/* 3313 */     int[] codes = CharTypes.getInputCodeComment();
/* 3314 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3315 */       int i = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3316 */       int code = codes[i];
/* 3317 */       if (code != 0) {
/* 3318 */         switch (code) {
/*      */           case 10:
/* 3320 */             this._currInputRow++;
/* 3321 */             this._currInputRowStart = this._inputPtr;
/*      */             return;
/*      */           case 13:
/* 3324 */             _skipCR();
/*      */             return;
/*      */           case 42:
/*      */             continue;
/*      */           case 2:
/* 3329 */             _skipUtf8_2();
/*      */             continue;
/*      */           case 3:
/* 3332 */             _skipUtf8_3();
/*      */             continue;
/*      */           case 4:
/* 3335 */             _skipUtf8_4(i);
/*      */             continue;
/*      */         } 
/* 3338 */         if (code < 0)
/*      */         {
/* 3340 */           _reportInvalidChar(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/* 3350 */     if (this._inputPtr >= this._inputEnd && 
/* 3351 */       !_loadMore()) {
/* 3352 */       _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */     }
/*      */     
/* 3355 */     int c = this._inputBuffer[this._inputPtr++];
/*      */     
/* 3357 */     switch (c) {
/*      */       
/*      */       case 98:
/* 3360 */         return '\b';
/*      */       case 116:
/* 3362 */         return '\t';
/*      */       case 110:
/* 3364 */         return '\n';
/*      */       case 102:
/* 3366 */         return '\f';
/*      */       case 114:
/* 3368 */         return '\r';
/*      */ 
/*      */       
/*      */       case 34:
/*      */       case 47:
/*      */       case 92:
/* 3374 */         return (char)c;
/*      */       
/*      */       case 117:
/*      */         break;
/*      */       
/*      */       default:
/* 3380 */         return _handleUnrecognizedCharacterEscape((char)_decodeCharForError(c));
/*      */     } 
/*      */ 
/*      */     
/* 3384 */     int value = 0;
/* 3385 */     for (int i = 0; i < 4; i++) {
/* 3386 */       if (this._inputPtr >= this._inputEnd && 
/* 3387 */         !_loadMore()) {
/* 3388 */         _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */       }
/*      */       
/* 3391 */       int ch = this._inputBuffer[this._inputPtr++];
/* 3392 */       int digit = CharTypes.charToHex(ch);
/* 3393 */       if (digit < 0) {
/* 3394 */         _reportUnexpectedChar(ch & 0xFF, "expected a hex-digit for character escape sequence");
/*      */       }
/* 3396 */       value = value << 4 | digit;
/*      */     } 
/* 3398 */     return (char)value;
/*      */   }
/*      */ 
/*      */   
/*      */   protected int _decodeCharForError(int firstByte) throws IOException {
/* 3403 */     int c = firstByte & 0xFF;
/* 3404 */     if (c > 127) {
/*      */       int needed;
/*      */ 
/*      */       
/* 3408 */       if ((c & 0xE0) == 192) {
/* 3409 */         c &= 0x1F;
/* 3410 */         needed = 1;
/* 3411 */       } else if ((c & 0xF0) == 224) {
/* 3412 */         c &= 0xF;
/* 3413 */         needed = 2;
/* 3414 */       } else if ((c & 0xF8) == 240) {
/*      */         
/* 3416 */         c &= 0x7;
/* 3417 */         needed = 3;
/*      */       } else {
/* 3419 */         _reportInvalidInitial(c & 0xFF);
/* 3420 */         needed = 1;
/*      */       } 
/*      */       
/* 3423 */       int d = nextByte();
/* 3424 */       if ((d & 0xC0) != 128) {
/* 3425 */         _reportInvalidOther(d & 0xFF);
/*      */       }
/* 3427 */       c = c << 6 | d & 0x3F;
/*      */       
/* 3429 */       if (needed > 1) {
/* 3430 */         d = nextByte();
/* 3431 */         if ((d & 0xC0) != 128) {
/* 3432 */           _reportInvalidOther(d & 0xFF);
/*      */         }
/* 3434 */         c = c << 6 | d & 0x3F;
/* 3435 */         if (needed > 2) {
/* 3436 */           d = nextByte();
/* 3437 */           if ((d & 0xC0) != 128) {
/* 3438 */             _reportInvalidOther(d & 0xFF);
/*      */           }
/* 3440 */           c = c << 6 | d & 0x3F;
/*      */         } 
/*      */       } 
/*      */     } 
/* 3444 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_2(int c) throws IOException {
/* 3455 */     if (this._inputPtr >= this._inputEnd) {
/* 3456 */       _loadMoreGuaranteed();
/*      */     }
/* 3458 */     int d = this._inputBuffer[this._inputPtr++];
/* 3459 */     if ((d & 0xC0) != 128) {
/* 3460 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3462 */     return (c & 0x1F) << 6 | d & 0x3F;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_3(int c1) throws IOException {
/* 3467 */     if (this._inputPtr >= this._inputEnd) {
/* 3468 */       _loadMoreGuaranteed();
/*      */     }
/* 3470 */     c1 &= 0xF;
/* 3471 */     int d = this._inputBuffer[this._inputPtr++];
/* 3472 */     if ((d & 0xC0) != 128) {
/* 3473 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3475 */     int c = c1 << 6 | d & 0x3F;
/* 3476 */     if (this._inputPtr >= this._inputEnd) {
/* 3477 */       _loadMoreGuaranteed();
/*      */     }
/* 3479 */     d = this._inputBuffer[this._inputPtr++];
/* 3480 */     if ((d & 0xC0) != 128) {
/* 3481 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3483 */     c = c << 6 | d & 0x3F;
/* 3484 */     return c;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_3fast(int c1) throws IOException {
/* 3489 */     c1 &= 0xF;
/* 3490 */     int d = this._inputBuffer[this._inputPtr++];
/* 3491 */     if ((d & 0xC0) != 128) {
/* 3492 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3494 */     int c = c1 << 6 | d & 0x3F;
/* 3495 */     d = this._inputBuffer[this._inputPtr++];
/* 3496 */     if ((d & 0xC0) != 128) {
/* 3497 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3499 */     c = c << 6 | d & 0x3F;
/* 3500 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_4(int c) throws IOException {
/* 3507 */     if (this._inputPtr >= this._inputEnd) {
/* 3508 */       _loadMoreGuaranteed();
/*      */     }
/* 3510 */     int d = this._inputBuffer[this._inputPtr++];
/* 3511 */     if ((d & 0xC0) != 128) {
/* 3512 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3514 */     c = (c & 0x7) << 6 | d & 0x3F;
/*      */     
/* 3516 */     if (this._inputPtr >= this._inputEnd) {
/* 3517 */       _loadMoreGuaranteed();
/*      */     }
/* 3519 */     d = this._inputBuffer[this._inputPtr++];
/* 3520 */     if ((d & 0xC0) != 128) {
/* 3521 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3523 */     c = c << 6 | d & 0x3F;
/* 3524 */     if (this._inputPtr >= this._inputEnd) {
/* 3525 */       _loadMoreGuaranteed();
/*      */     }
/* 3527 */     d = this._inputBuffer[this._inputPtr++];
/* 3528 */     if ((d & 0xC0) != 128) {
/* 3529 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3535 */     return (c << 6 | d & 0x3F) - 65536;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_2() throws IOException {
/* 3540 */     if (this._inputPtr >= this._inputEnd) {
/* 3541 */       _loadMoreGuaranteed();
/*      */     }
/* 3543 */     int c = this._inputBuffer[this._inputPtr++];
/* 3544 */     if ((c & 0xC0) != 128) {
/* 3545 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_3() throws IOException {
/* 3554 */     if (this._inputPtr >= this._inputEnd) {
/* 3555 */       _loadMoreGuaranteed();
/*      */     }
/*      */     
/* 3558 */     int c = this._inputBuffer[this._inputPtr++];
/* 3559 */     if ((c & 0xC0) != 128) {
/* 3560 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */     }
/* 3562 */     if (this._inputPtr >= this._inputEnd) {
/* 3563 */       _loadMoreGuaranteed();
/*      */     }
/* 3565 */     c = this._inputBuffer[this._inputPtr++];
/* 3566 */     if ((c & 0xC0) != 128) {
/* 3567 */       _reportInvalidOther(c & 0xFF, this._inputPtr);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_4(int c) throws IOException {
/* 3573 */     if (this._inputPtr >= this._inputEnd) {
/* 3574 */       _loadMoreGuaranteed();
/*      */     }
/* 3576 */     int d = this._inputBuffer[this._inputPtr++];
/* 3577 */     if ((d & 0xC0) != 128) {
/* 3578 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3580 */     if (this._inputPtr >= this._inputEnd) {
/* 3581 */       _loadMoreGuaranteed();
/*      */     }
/* 3583 */     d = this._inputBuffer[this._inputPtr++];
/* 3584 */     if ((d & 0xC0) != 128) {
/* 3585 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 3587 */     if (this._inputPtr >= this._inputEnd) {
/* 3588 */       _loadMoreGuaranteed();
/*      */     }
/* 3590 */     d = this._inputBuffer[this._inputPtr++];
/* 3591 */     if ((d & 0xC0) != 128) {
/* 3592 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _skipCR() throws IOException {
/* 3606 */     if ((this._inputPtr < this._inputEnd || _loadMore()) && 
/* 3607 */       this._inputBuffer[this._inputPtr] == 10) {
/* 3608 */       this._inputPtr++;
/*      */     }
/*      */     
/* 3611 */     this._currInputRow++;
/* 3612 */     this._currInputRowStart = this._inputPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   private int nextByte() throws IOException {
/* 3617 */     if (this._inputPtr >= this._inputEnd) {
/* 3618 */       _loadMoreGuaranteed();
/*      */     }
/* 3620 */     return this._inputBuffer[this._inputPtr++] & 0xFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart, int ptr) throws IOException {
/* 3630 */     this._inputPtr = ptr;
/* 3631 */     _reportInvalidToken(matchedPart, _validJsonTokenList());
/*      */   }
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart) throws IOException {
/* 3635 */     _reportInvalidToken(matchedPart, _validJsonTokenList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart, String msg) throws IOException {
/* 3644 */     StringBuilder sb = new StringBuilder(matchedPart);
/* 3645 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3646 */       int i = this._inputBuffer[this._inputPtr++];
/* 3647 */       char c = (char)_decodeCharForError(i);
/* 3648 */       if (!Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3656 */       sb.append(c);
/* 3657 */       if (sb.length() >= this._ioContext.errorReportConfiguration().getMaxErrorTokenLength()) {
/* 3658 */         sb.append("...");
/*      */         break;
/*      */       } 
/*      */     } 
/* 3662 */     _reportError("Unrecognized token '%s': was expecting %s", sb, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidChar(int c) throws JsonParseException {
/* 3668 */     if (c < 32) {
/* 3669 */       _throwInvalidSpace(c);
/*      */     }
/* 3671 */     _reportInvalidInitial(c);
/*      */   }
/*      */   
/*      */   protected void _reportInvalidInitial(int mask) throws JsonParseException {
/* 3675 */     _reportError("Invalid UTF-8 start byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */   
/*      */   protected void _reportInvalidOther(int mask) throws JsonParseException {
/* 3679 */     _reportError("Invalid UTF-8 middle byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidOther(int mask, int ptr) throws JsonParseException {
/* 3685 */     this._inputPtr = ptr;
/* 3686 */     _reportInvalidOther(mask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final byte[] _decodeBase64(Base64Variant b64variant) throws IOException {
/* 3709 */     ByteArrayBuilder builder = _getByteArrayBuilder();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 3715 */       if (this._inputPtr >= this._inputEnd) {
/* 3716 */         _loadMoreGuaranteed();
/*      */       }
/* 3718 */       int ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3719 */       if (ch > 32) {
/* 3720 */         int bits = b64variant.decodeBase64Char(ch);
/* 3721 */         if (bits < 0) {
/* 3722 */           if (ch == 34) {
/* 3723 */             return builder.toByteArray();
/*      */           }
/* 3725 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/* 3726 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/* 3730 */         int decodedData = bits;
/*      */ 
/*      */ 
/*      */         
/* 3734 */         if (this._inputPtr >= this._inputEnd) {
/* 3735 */           _loadMoreGuaranteed();
/*      */         }
/* 3737 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3738 */         bits = b64variant.decodeBase64Char(ch);
/* 3739 */         if (bits < 0) {
/* 3740 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/* 3742 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/* 3745 */         if (this._inputPtr >= this._inputEnd) {
/* 3746 */           _loadMoreGuaranteed();
/*      */         }
/* 3748 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3749 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/* 3752 */         if (bits < 0) {
/* 3753 */           if (bits != -2) {
/*      */             
/* 3755 */             if (ch == 34) {
/* 3756 */               decodedData >>= 4;
/* 3757 */               builder.append(decodedData);
/* 3758 */               if (b64variant.requiresPaddingOnRead()) {
/* 3759 */                 this._inputPtr--;
/* 3760 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/* 3762 */               return builder.toByteArray();
/*      */             } 
/* 3764 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/* 3766 */           if (bits == -2) {
/*      */             
/* 3768 */             if (this._inputPtr >= this._inputEnd) {
/* 3769 */               _loadMoreGuaranteed();
/*      */             }
/* 3771 */             ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3772 */             if (!b64variant.usesPaddingChar(ch) && 
/* 3773 */               _decodeBase64Escape(b64variant, ch, 3) != -2) {
/* 3774 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/* 3778 */             decodedData >>= 4;
/* 3779 */             builder.append(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 3784 */         decodedData = decodedData << 6 | bits;
/*      */         
/* 3786 */         if (this._inputPtr >= this._inputEnd) {
/* 3787 */           _loadMoreGuaranteed();
/*      */         }
/* 3789 */         ch = this._inputBuffer[this._inputPtr++] & 0xFF;
/* 3790 */         bits = b64variant.decodeBase64Char(ch);
/* 3791 */         if (bits < 0) {
/* 3792 */           if (bits != -2) {
/*      */             
/* 3794 */             if (ch == 34) {
/* 3795 */               decodedData >>= 2;
/* 3796 */               builder.appendTwoBytes(decodedData);
/* 3797 */               if (b64variant.requiresPaddingOnRead()) {
/* 3798 */                 this._inputPtr--;
/* 3799 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/* 3801 */               return builder.toByteArray();
/*      */             } 
/* 3803 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/* 3805 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */             
/* 3809 */             decodedData >>= 2;
/* 3810 */             builder.appendTwoBytes(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 3815 */         decodedData = decodedData << 6 | bits;
/* 3816 */         builder.appendThreeBytes(decodedData);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation currentLocation() {
/* 3829 */     int col = this._inputPtr - this._currInputRowStart + 1;
/* 3830 */     return new JsonLocation(_contentReference(), this._currInputProcessed + this._inputPtr, -1L, this._currInputRow, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonLocation _currentLocationMinusOne() {
/* 3837 */     int prevInputPtr = this._inputPtr - 1;
/* 3838 */     int col = prevInputPtr - this._currInputRowStart + 1;
/* 3839 */     return new JsonLocation(_contentReference(), this._currInputProcessed + prevInputPtr, -1L, this._currInputRow, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation currentTokenLocation() {
/* 3847 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 3848 */       long total = this._currInputProcessed + (this._nameStartOffset - 1);
/* 3849 */       return new JsonLocation(_contentReference(), total, -1L, this._nameStartRow, this._nameStartCol);
/*      */     } 
/*      */     
/* 3852 */     return new JsonLocation(_contentReference(), this._tokenInputTotal - 1L, -1L, this._tokenInputRow, this._tokenInputCol);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _updateLocation() {
/* 3859 */     this._tokenInputRow = this._currInputRow;
/* 3860 */     int ptr = this._inputPtr;
/* 3861 */     this._tokenInputTotal = this._currInputProcessed + ptr;
/* 3862 */     this._tokenInputCol = ptr - this._currInputRowStart;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _updateNameLocation() {
/* 3868 */     this._nameStartRow = this._currInputRow;
/* 3869 */     int ptr = this._inputPtr;
/* 3870 */     this._nameStartOffset = ptr;
/* 3871 */     this._nameStartCol = ptr - this._currInputRowStart;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _closeScope(int i) throws IOException {
/* 3881 */     if (i == 125) {
/* 3882 */       _closeObjectScope();
/* 3883 */       return _updateToken(JsonToken.END_OBJECT);
/*      */     } 
/* 3885 */     _closeArrayScope();
/* 3886 */     return _updateToken(JsonToken.END_ARRAY);
/*      */   }
/*      */   
/*      */   private final void _closeArrayScope() throws IOException {
/* 3890 */     _updateLocation();
/* 3891 */     if (!this._parsingContext.inArray()) {
/* 3892 */       _reportMismatchedEndMarker(93, '}');
/*      */     }
/* 3894 */     this._parsingContext = this._parsingContext.clearAndGetParent();
/*      */   }
/*      */   
/*      */   private final void _closeObjectScope() throws IOException {
/* 3898 */     _updateLocation();
/* 3899 */     if (!this._parsingContext.inObject()) {
/* 3900 */       _reportMismatchedEndMarker(125, ']');
/*      */     }
/* 3902 */     this._parsingContext = this._parsingContext.clearAndGetParent();
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\json\UTF8StreamJsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */