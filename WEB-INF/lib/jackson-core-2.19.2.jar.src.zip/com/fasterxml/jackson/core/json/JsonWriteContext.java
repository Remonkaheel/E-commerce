/*     */ package com.fasterxml.jackson.core.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerationException;
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonWriteContext
/*     */   extends JsonStreamContext
/*     */ {
/*     */   public static final int STATUS_OK_AS_IS = 0;
/*     */   public static final int STATUS_OK_AFTER_COMMA = 1;
/*     */   public static final int STATUS_OK_AFTER_COLON = 2;
/*     */   public static final int STATUS_OK_AFTER_SPACE = 3;
/*     */   public static final int STATUS_EXPECT_VALUE = 4;
/*     */   public static final int STATUS_EXPECT_NAME = 5;
/*     */   protected final JsonWriteContext _parent;
/*     */   protected DupDetector _dups;
/*     */   protected JsonWriteContext _child;
/*     */   protected String _currentName;
/*     */   protected Object _currentValue;
/*     */   protected boolean _gotName;
/*     */   
/*     */   protected JsonWriteContext(int type, JsonWriteContext parent, DupDetector dups) {
/*  70 */     this._type = type;
/*  71 */     this._parent = parent;
/*  72 */     this._nestingDepth = (parent == null) ? 0 : (parent._nestingDepth + 1);
/*  73 */     this._dups = dups;
/*  74 */     this._index = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonWriteContext(int type, JsonWriteContext parent, DupDetector dups, Object currValue) {
/*  81 */     this._type = type;
/*  82 */     this._parent = parent;
/*  83 */     this._nestingDepth = (parent == null) ? 0 : (parent._nestingDepth + 1);
/*  84 */     this._dups = dups;
/*  85 */     this._index = -1;
/*  86 */     this._currentValue = currValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonWriteContext reset(int type) {
/* 103 */     this._type = type;
/* 104 */     this._index = -1;
/* 105 */     this._currentName = null;
/* 106 */     this._gotName = false;
/* 107 */     this._currentValue = null;
/* 108 */     if (this._dups != null) this._dups.reset(); 
/* 109 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonWriteContext reset(int type, Object currValue) {
/* 129 */     this._type = type;
/* 130 */     this._index = -1;
/* 131 */     this._currentName = null;
/* 132 */     this._gotName = false;
/* 133 */     this._currentValue = currValue;
/* 134 */     if (this._dups != null) this._dups.reset(); 
/* 135 */     return this;
/*     */   }
/*     */   
/*     */   public JsonWriteContext withDupDetector(DupDetector dups) {
/* 139 */     this._dups = dups;
/* 140 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getCurrentValue() {
/* 145 */     return this._currentValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrentValue(Object v) {
/* 150 */     this._currentValue = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static JsonWriteContext createRootContext() {
/* 165 */     return createRootContext((DupDetector)null);
/*     */   }
/*     */   public static JsonWriteContext createRootContext(DupDetector dd) {
/* 168 */     return new JsonWriteContext(0, null, dd);
/*     */   }
/*     */   
/*     */   public JsonWriteContext createChildArrayContext() {
/* 172 */     JsonWriteContext ctxt = this._child;
/* 173 */     if (ctxt == null) {
/* 174 */       this
/* 175 */         ._child = ctxt = new JsonWriteContext(1, this, (this._dups == null) ? null : this._dups.child());
/* 176 */       return ctxt;
/*     */     } 
/* 178 */     return ctxt.reset(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonWriteContext createChildArrayContext(Object currValue) {
/* 183 */     JsonWriteContext ctxt = this._child;
/* 184 */     if (ctxt == null) {
/* 185 */       this
/* 186 */         ._child = ctxt = new JsonWriteContext(1, this, (this._dups == null) ? null : this._dups.child(), currValue);
/* 187 */       return ctxt;
/*     */     } 
/* 189 */     return ctxt.reset(1, currValue);
/*     */   }
/*     */   
/*     */   public JsonWriteContext createChildObjectContext() {
/* 193 */     JsonWriteContext ctxt = this._child;
/* 194 */     if (ctxt == null) {
/* 195 */       this
/* 196 */         ._child = ctxt = new JsonWriteContext(2, this, (this._dups == null) ? null : this._dups.child());
/* 197 */       return ctxt;
/*     */     } 
/* 199 */     return ctxt.reset(2);
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonWriteContext createChildObjectContext(Object currValue) {
/* 204 */     JsonWriteContext ctxt = this._child;
/* 205 */     if (ctxt == null) {
/* 206 */       this
/* 207 */         ._child = ctxt = new JsonWriteContext(2, this, (this._dups == null) ? null : this._dups.child(), currValue);
/* 208 */       return ctxt;
/*     */     } 
/* 210 */     return ctxt.reset(2, currValue);
/*     */   }
/*     */   
/* 213 */   public final JsonWriteContext getParent() { return this._parent; } public final String getCurrentName() {
/* 214 */     return this._currentName;
/*     */   } public boolean hasCurrentName() {
/* 216 */     return (this._currentName != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonWriteContext clearAndGetParent() {
/* 231 */     this._currentValue = null;
/*     */     
/* 233 */     return this._parent;
/*     */   }
/*     */   
/*     */   public DupDetector getDupDetector() {
/* 237 */     return this._dups;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int writeFieldName(String name) throws JsonProcessingException {
/* 250 */     if (this._type != 2 || this._gotName) {
/* 251 */       return 4;
/*     */     }
/* 253 */     this._gotName = true;
/* 254 */     this._currentName = name;
/* 255 */     if (this._dups != null) _checkDup(this._dups, name); 
/* 256 */     return (this._index < 0) ? 0 : 1;
/*     */   }
/*     */   
/*     */   private final void _checkDup(DupDetector dd, String name) throws JsonProcessingException {
/* 260 */     if (dd.isDup(name)) {
/* 261 */       Object src = dd.getSource();
/* 262 */       throw new JsonGenerationException("Duplicate field '" + name + "'", (src instanceof JsonGenerator) ? (JsonGenerator)src : null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int writeValue() {
/* 269 */     if (this._type == 2) {
/* 270 */       if (!this._gotName) {
/* 271 */         return 5;
/*     */       }
/* 273 */       this._gotName = false;
/* 274 */       this._index++;
/* 275 */       return 2;
/*     */     } 
/*     */ 
/*     */     
/* 279 */     if (this._type == 1) {
/* 280 */       int ix = this._index;
/* 281 */       this._index++;
/* 282 */       return (ix < 0) ? 0 : 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 287 */     this._index++;
/* 288 */     return (this._index == 0) ? 0 : 3;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\json\JsonWriteContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */