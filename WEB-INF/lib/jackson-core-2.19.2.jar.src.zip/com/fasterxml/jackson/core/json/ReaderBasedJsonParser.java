/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import com.fasterxml.jackson.core.util.TextBuffer;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ReaderBasedJsonParser
/*      */   extends JsonParserBase
/*      */ {
/*      */   protected Reader _reader;
/*      */   protected char[] _inputBuffer;
/*      */   protected boolean _bufferRecyclable;
/*      */   protected ObjectCodec _objectCodec;
/*      */   protected final CharsToNameCanonicalizer _symbols;
/*      */   protected final int _hashSeed;
/*      */   protected boolean _tokenIncomplete;
/*      */   protected long _nameStartOffset;
/*      */   protected int _nameStartRow;
/*      */   protected int _nameStartCol;
/*      */   
/*      */   public ReaderBasedJsonParser(IOContext ctxt, int features, Reader r, ObjectCodec codec, CharsToNameCanonicalizer st, char[] inputBuffer, int start, int end, boolean bufferRecyclable) {
/*  123 */     super(ctxt, features, codec);
/*  124 */     this._reader = r;
/*  125 */     this._inputBuffer = inputBuffer;
/*  126 */     this._inputPtr = start;
/*  127 */     this._inputEnd = end;
/*  128 */     this._currInputRowStart = start;
/*      */     
/*  130 */     this._currInputProcessed = -start;
/*  131 */     this._symbols = st;
/*  132 */     this._hashSeed = st.hashSeed();
/*  133 */     this._bufferRecyclable = bufferRecyclable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ReaderBasedJsonParser(IOContext ctxt, int features, Reader r, ObjectCodec codec, CharsToNameCanonicalizer st) {
/*  149 */     super(ctxt, features, codec);
/*  150 */     this._reader = r;
/*  151 */     this._inputBuffer = ctxt.allocTokenBuffer();
/*  152 */     this._inputPtr = 0;
/*  153 */     this._inputEnd = 0;
/*  154 */     this._symbols = st;
/*  155 */     this._hashSeed = st.hashSeed();
/*  156 */     this._bufferRecyclable = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int releaseBuffered(Writer w) throws IOException {
/*  167 */     int count = this._inputEnd - this._inputPtr;
/*  168 */     if (count < 1) return 0;
/*      */     
/*  170 */     int origPtr = this._inputPtr;
/*  171 */     this._inputPtr += count;
/*  172 */     w.write(this._inputBuffer, origPtr, count);
/*  173 */     return count;
/*      */   }
/*      */   public Object getInputSource() {
/*  176 */     return this._reader;
/*      */   }
/*      */   @Deprecated
/*      */   protected char getNextChar(String eofMsg) throws IOException {
/*  180 */     return getNextChar(eofMsg, (JsonToken)null);
/*      */   }
/*      */   
/*      */   protected char getNextChar(String eofMsg, JsonToken forToken) throws IOException {
/*  184 */     if (this._inputPtr >= this._inputEnd && 
/*  185 */       !_loadMore()) {
/*  186 */       _reportInvalidEOF(eofMsg, forToken);
/*      */     }
/*      */     
/*  189 */     return this._inputBuffer[this._inputPtr++];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _closeInput() throws IOException {
/*  201 */     if (this._reader != null) {
/*  202 */       if (this._ioContext.isResourceManaged() || isEnabled(JsonParser.Feature.AUTO_CLOSE_SOURCE)) {
/*  203 */         this._reader.close();
/*      */       }
/*  205 */       this._reader = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() throws IOException {
/*  218 */     super._releaseBuffers();
/*      */     
/*  220 */     this._symbols.release();
/*      */     
/*  222 */     if (this._bufferRecyclable) {
/*  223 */       char[] buf = this._inputBuffer;
/*  224 */       if (buf != null) {
/*  225 */         this._inputBuffer = null;
/*  226 */         this._ioContext.releaseTokenBuffer(buf);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _loadMoreGuaranteed() throws IOException {
/*  238 */     if (!_loadMore()) _reportInvalidEOF();
/*      */   
/*      */   }
/*      */   
/*      */   protected boolean _loadMore() throws IOException {
/*  243 */     if (this._reader != null) {
/*  244 */       int bufSize = this._inputEnd;
/*  245 */       this._currInputProcessed += bufSize;
/*  246 */       this._currInputRowStart -= bufSize;
/*      */       
/*  248 */       this._streamReadConstraints.validateDocumentLength(this._currInputProcessed);
/*      */       
/*  250 */       int count = this._reader.read(this._inputBuffer, 0, this._inputBuffer.length);
/*  251 */       if (count > 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  256 */         this._nameStartOffset -= bufSize;
/*      */         
/*  258 */         this._inputPtr = 0;
/*  259 */         this._inputEnd = count;
/*      */         
/*  261 */         return true;
/*      */       } 
/*  263 */       this._inputPtr = this._inputEnd = 0;
/*      */       
/*  265 */       _closeInput();
/*      */       
/*  267 */       if (count == 0) {
/*  268 */         throw new IOException("Reader returned 0 characters when trying to read " + this._inputEnd);
/*      */       }
/*      */     } 
/*  271 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getText() throws IOException {
/*  292 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  293 */       if (this._tokenIncomplete) {
/*  294 */         this._tokenIncomplete = false;
/*  295 */         _finishString();
/*      */       } 
/*  297 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  299 */     return _getText2(this._currToken);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getText(Writer writer) throws IOException {
/*  305 */     JsonToken t = this._currToken;
/*  306 */     if (t == JsonToken.VALUE_STRING) {
/*  307 */       if (this._tokenIncomplete) {
/*  308 */         this._tokenIncomplete = false;
/*  309 */         _finishString();
/*      */       } 
/*  311 */       return this._textBuffer.contentsToWriter(writer);
/*      */     } 
/*  313 */     if (t == JsonToken.FIELD_NAME) {
/*  314 */       String n = this._parsingContext.getCurrentName();
/*  315 */       writer.write(n);
/*  316 */       return n.length();
/*      */     } 
/*  318 */     if (t != null) {
/*  319 */       if (t.isNumeric()) {
/*  320 */         return this._textBuffer.contentsToWriter(writer);
/*      */       }
/*  322 */       char[] ch = t.asCharArray();
/*  323 */       writer.write(ch);
/*  324 */       return ch.length;
/*      */     } 
/*  326 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getValueAsString() throws IOException {
/*  335 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  336 */       if (this._tokenIncomplete) {
/*  337 */         this._tokenIncomplete = false;
/*  338 */         _finishString();
/*      */       } 
/*  340 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  342 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  343 */       return currentName();
/*      */     }
/*  345 */     return super.getValueAsString(null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getValueAsString(String defValue) throws IOException {
/*  351 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  352 */       if (this._tokenIncomplete) {
/*  353 */         this._tokenIncomplete = false;
/*  354 */         _finishString();
/*      */       } 
/*  356 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  358 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  359 */       return currentName();
/*      */     }
/*  361 */     return super.getValueAsString(defValue);
/*      */   }
/*      */   
/*      */   protected final String _getText2(JsonToken t) throws IOException {
/*  365 */     if (t == null) {
/*  366 */       return null;
/*      */     }
/*  368 */     switch (t.id()) {
/*      */       case 5:
/*  370 */         return this._parsingContext.getCurrentName();
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  376 */         return this._textBuffer.contentsAsString();
/*      */     } 
/*  378 */     return t.asString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final char[] getTextCharacters() throws IOException {
/*  385 */     if (this._currToken != null) {
/*  386 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  388 */           if (!this._nameCopied) {
/*  389 */             String name = this._parsingContext.getCurrentName();
/*  390 */             int nameLen = name.length();
/*  391 */             if (this._nameCopyBuffer == null) {
/*  392 */               this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/*  393 */             } else if (this._nameCopyBuffer.length < nameLen) {
/*  394 */               this._nameCopyBuffer = new char[nameLen];
/*      */             } 
/*  396 */             name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/*  397 */             this._nameCopied = true;
/*      */           } 
/*  399 */           return this._nameCopyBuffer;
/*      */         case 6:
/*  401 */           if (this._tokenIncomplete) {
/*  402 */             this._tokenIncomplete = false;
/*  403 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  408 */           return this._textBuffer.getTextBuffer();
/*      */       } 
/*  410 */       return this._currToken.asCharArray();
/*      */     } 
/*      */     
/*  413 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getTextLength() throws IOException {
/*  419 */     if (this._currToken != null) {
/*  420 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  422 */           return this._parsingContext.getCurrentName().length();
/*      */         case 6:
/*  424 */           if (this._tokenIncomplete) {
/*  425 */             this._tokenIncomplete = false;
/*  426 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  431 */           return this._textBuffer.size();
/*      */       } 
/*  433 */       return (this._currToken.asCharArray()).length;
/*      */     } 
/*      */     
/*  436 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getTextOffset() throws IOException {
/*  443 */     if (this._currToken != null) {
/*  444 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  446 */           return 0;
/*      */         case 6:
/*  448 */           if (this._tokenIncomplete) {
/*  449 */             this._tokenIncomplete = false;
/*  450 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  455 */           return this._textBuffer.getTextOffset();
/*      */       } 
/*      */     
/*      */     }
/*  459 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBinaryValue(Base64Variant b64variant) throws IOException {
/*  465 */     if (this._currToken == JsonToken.VALUE_EMBEDDED_OBJECT && this._binaryValue != null) {
/*  466 */       return this._binaryValue;
/*      */     }
/*  468 */     if (this._currToken != JsonToken.VALUE_STRING) {
/*  469 */       _reportError("Current token (" + this._currToken + ") not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary");
/*      */     }
/*      */     
/*  472 */     if (this._tokenIncomplete) {
/*      */       try {
/*  474 */         this._binaryValue = _decodeBase64(b64variant);
/*  475 */       } catch (IllegalArgumentException iae) {
/*  476 */         throw _constructError("Failed to decode VALUE_STRING as base64 (" + b64variant + "): " + iae.getMessage());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  481 */       this._tokenIncomplete = false;
/*      */     }
/*  483 */     else if (this._binaryValue == null) {
/*      */       
/*  485 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  486 */       _decodeBase64(getText(), builder, b64variant);
/*  487 */       this._binaryValue = builder.toByteArray();
/*      */     } 
/*      */     
/*  490 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/*  497 */     if (!this._tokenIncomplete || this._currToken != JsonToken.VALUE_STRING) {
/*  498 */       byte[] b = getBinaryValue(b64variant);
/*  499 */       out.write(b);
/*  500 */       return b.length;
/*      */     } 
/*      */     
/*  503 */     byte[] buf = this._ioContext.allocBase64Buffer();
/*      */     try {
/*  505 */       return _readBinary(b64variant, out, buf);
/*      */     } finally {
/*  507 */       this._ioContext.releaseBase64Buffer(buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected int _readBinary(Base64Variant b64variant, OutputStream out, byte[] buffer) throws IOException {
/*  513 */     int outputPtr = 0;
/*  514 */     int outputEnd = buffer.length - 3;
/*  515 */     int outputCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  521 */       if (this._inputPtr >= this._inputEnd) {
/*  522 */         _loadMoreGuaranteed();
/*      */       }
/*  524 */       char ch = this._inputBuffer[this._inputPtr++];
/*  525 */       if (ch > ' ') {
/*  526 */         int bits = b64variant.decodeBase64Char(ch);
/*  527 */         if (bits < 0) {
/*  528 */           if (ch == '"') {
/*      */             break;
/*      */           }
/*  531 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/*  532 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  538 */         if (outputPtr > outputEnd) {
/*  539 */           outputCount += outputPtr;
/*  540 */           out.write(buffer, 0, outputPtr);
/*  541 */           outputPtr = 0;
/*      */         } 
/*      */         
/*  544 */         int decodedData = bits;
/*      */ 
/*      */ 
/*      */         
/*  548 */         if (this._inputPtr >= this._inputEnd) {
/*  549 */           _loadMoreGuaranteed();
/*      */         }
/*  551 */         ch = this._inputBuffer[this._inputPtr++];
/*  552 */         bits = b64variant.decodeBase64Char(ch);
/*  553 */         if (bits < 0) {
/*  554 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/*  556 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/*  559 */         if (this._inputPtr >= this._inputEnd) {
/*  560 */           _loadMoreGuaranteed();
/*      */         }
/*  562 */         ch = this._inputBuffer[this._inputPtr++];
/*  563 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/*  566 */         if (bits < 0) {
/*  567 */           if (bits != -2) {
/*      */             
/*  569 */             if (ch == '"') {
/*  570 */               decodedData >>= 4;
/*  571 */               buffer[outputPtr++] = (byte)decodedData;
/*  572 */               if (b64variant.requiresPaddingOnRead()) {
/*  573 */                 this._inputPtr--;
/*  574 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/*      */               break;
/*      */             } 
/*  578 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/*  580 */           if (bits == -2) {
/*      */             
/*  582 */             if (this._inputPtr >= this._inputEnd) {
/*  583 */               _loadMoreGuaranteed();
/*      */             }
/*  585 */             ch = this._inputBuffer[this._inputPtr++];
/*  586 */             if (!b64variant.usesPaddingChar(ch) && 
/*  587 */               _decodeBase64Escape(b64variant, ch, 3) != -2) {
/*  588 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/*  592 */             decodedData >>= 4;
/*  593 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  598 */         decodedData = decodedData << 6 | bits;
/*      */         
/*  600 */         if (this._inputPtr >= this._inputEnd) {
/*  601 */           _loadMoreGuaranteed();
/*      */         }
/*  603 */         ch = this._inputBuffer[this._inputPtr++];
/*  604 */         bits = b64variant.decodeBase64Char(ch);
/*  605 */         if (bits < 0) {
/*  606 */           if (bits != -2) {
/*      */             
/*  608 */             if (ch == '"') {
/*  609 */               decodedData >>= 2;
/*  610 */               buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  611 */               buffer[outputPtr++] = (byte)decodedData;
/*  612 */               if (b64variant.requiresPaddingOnRead()) {
/*  613 */                 this._inputPtr--;
/*  614 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/*      */               break;
/*      */             } 
/*  618 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/*  620 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  627 */             decodedData >>= 2;
/*  628 */             buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  629 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  634 */         decodedData = decodedData << 6 | bits;
/*  635 */         buffer[outputPtr++] = (byte)(decodedData >> 16);
/*  636 */         buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  637 */         buffer[outputPtr++] = (byte)decodedData;
/*      */       } 
/*  639 */     }  this._tokenIncomplete = false;
/*  640 */     if (outputPtr > 0) {
/*  641 */       outputCount += outputPtr;
/*  642 */       out.write(buffer, 0, outputPtr);
/*      */     } 
/*  644 */     return outputCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonToken nextToken() throws IOException {
/*      */     JsonToken t;
/*  664 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  665 */       return _nextAfterName();
/*      */     }
/*      */ 
/*      */     
/*  669 */     this._numTypesValid = 0;
/*  670 */     if (this._tokenIncomplete) {
/*  671 */       _skipString();
/*      */     }
/*  673 */     int i = _skipWSOrEnd();
/*  674 */     if (i < 0) {
/*      */ 
/*      */       
/*  677 */       close();
/*  678 */       return _updateTokenToNull();
/*      */     } 
/*      */     
/*  681 */     this._binaryValue = null;
/*      */ 
/*      */     
/*  684 */     if ((i | 0x20) == 125) {
/*  685 */       _closeScope(i);
/*  686 */       return this._currToken;
/*      */     } 
/*      */ 
/*      */     
/*  690 */     if (this._parsingContext.expectComma()) {
/*  691 */       i = _skipComma(i);
/*      */ 
/*      */       
/*  694 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  695 */         i | 0x20) == 125) {
/*  696 */         _closeScope(i);
/*  697 */         return this._currToken;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  705 */     boolean inObject = this._parsingContext.inObject();
/*  706 */     if (inObject) {
/*      */       
/*  708 */       _updateNameLocation();
/*  709 */       String name = (i == 34) ? _parseName() : _handleOddName(i);
/*  710 */       this._parsingContext.setCurrentName(name);
/*  711 */       _updateToken(JsonToken.FIELD_NAME);
/*  712 */       i = _skipColon();
/*      */     } 
/*  714 */     _updateLocation();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  720 */     switch (i) {
/*      */       case 34:
/*  722 */         this._tokenIncomplete = true;
/*  723 */         t = JsonToken.VALUE_STRING;
/*      */         break;
/*      */       case 91:
/*  726 */         if (!inObject) {
/*  727 */           createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*      */         }
/*  729 */         t = JsonToken.START_ARRAY;
/*      */         break;
/*      */       case 123:
/*  732 */         if (!inObject) {
/*  733 */           createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */         }
/*  735 */         t = JsonToken.START_OBJECT;
/*      */         break;
/*      */ 
/*      */       
/*      */       case 125:
/*  740 */         _reportUnexpectedChar(i, "expected a value");
/*      */       case 116:
/*  742 */         _matchTrue();
/*  743 */         t = JsonToken.VALUE_TRUE;
/*      */         break;
/*      */       case 102:
/*  746 */         _matchFalse();
/*  747 */         t = JsonToken.VALUE_FALSE;
/*      */         break;
/*      */       case 110:
/*  750 */         _matchNull();
/*  751 */         t = JsonToken.VALUE_NULL;
/*      */         break;
/*      */       
/*      */       case 45:
/*  755 */         t = _parseSignedNumber(true);
/*      */         break;
/*      */       case 43:
/*  758 */         if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/*  759 */           t = _parseSignedNumber(false); break;
/*      */         } 
/*  761 */         t = _handleOddValue(i);
/*      */         break;
/*      */       
/*      */       case 46:
/*  765 */         t = _parseFloatThatStartsWithPeriod(false);
/*      */         break;
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  777 */         t = _parseUnsignedNumber(i);
/*      */         break;
/*      */       default:
/*  780 */         t = _handleOddValue(i);
/*      */         break;
/*      */     } 
/*      */     
/*  784 */     if (inObject) {
/*  785 */       this._nextToken = t;
/*  786 */       return this._currToken;
/*      */     } 
/*  788 */     return _updateToken(t);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextAfterName() throws IOException {
/*  793 */     this._nameCopied = false;
/*  794 */     JsonToken t = this._nextToken;
/*  795 */     this._nextToken = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  800 */     if (t == JsonToken.START_ARRAY) {
/*  801 */       createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  802 */     } else if (t == JsonToken.START_OBJECT) {
/*  803 */       createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */     } 
/*  805 */     return _updateToken(t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void finishToken() throws IOException {
/*  810 */     if (this._tokenIncomplete) {
/*  811 */       this._tokenIncomplete = false;
/*  812 */       _finishString();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean nextFieldName(SerializableString sstr) throws IOException {
/*  828 */     this._numTypesValid = 0;
/*  829 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  830 */       _nextAfterName();
/*  831 */       return false;
/*      */     } 
/*  833 */     if (this._tokenIncomplete) {
/*  834 */       _skipString();
/*      */     }
/*  836 */     int i = _skipWSOrEnd();
/*  837 */     if (i < 0) {
/*  838 */       close();
/*  839 */       _updateTokenToNull();
/*  840 */       return false;
/*      */     } 
/*  842 */     this._binaryValue = null;
/*      */ 
/*      */     
/*  845 */     if ((i | 0x20) == 125) {
/*  846 */       _closeScope(i);
/*  847 */       return false;
/*      */     } 
/*      */     
/*  850 */     if (this._parsingContext.expectComma()) {
/*  851 */       i = _skipComma(i);
/*      */ 
/*      */       
/*  854 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  855 */         i | 0x20) == 125) {
/*  856 */         _closeScope(i);
/*  857 */         return false;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  862 */     if (!this._parsingContext.inObject()) {
/*  863 */       _updateLocation();
/*  864 */       _nextTokenNotInObject(i);
/*  865 */       return false;
/*      */     } 
/*      */     
/*  868 */     _updateNameLocation();
/*  869 */     if (i == 34) {
/*      */       
/*  871 */       char[] nameChars = sstr.asQuotedChars();
/*  872 */       int len = nameChars.length;
/*      */ 
/*      */       
/*  875 */       if (this._inputPtr + len + 4 < this._inputEnd) {
/*      */         
/*  877 */         int end = this._inputPtr + len;
/*  878 */         if (this._inputBuffer[end] == '"') {
/*  879 */           int offset = 0;
/*  880 */           int ptr = this._inputPtr;
/*      */           while (true) {
/*  882 */             if (ptr == end) {
/*  883 */               this._parsingContext.setCurrentName(sstr.getValue());
/*  884 */               _isNextTokenNameYes(_skipColonFast(ptr + 1));
/*  885 */               return true;
/*      */             } 
/*  887 */             if (nameChars[offset] != this._inputBuffer[ptr]) {
/*      */               break;
/*      */             }
/*  890 */             offset++;
/*  891 */             ptr++;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  896 */     return _isNextTokenNameMaybe(i, sstr.getValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextFieldName() throws IOException {
/*  904 */     this._numTypesValid = 0;
/*  905 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  906 */       _nextAfterName();
/*  907 */       return null;
/*      */     } 
/*  909 */     if (this._tokenIncomplete) {
/*  910 */       _skipString();
/*      */     }
/*  912 */     int i = _skipWSOrEnd();
/*  913 */     if (i < 0) {
/*  914 */       close();
/*  915 */       _updateTokenToNull();
/*  916 */       return null;
/*      */     } 
/*  918 */     this._binaryValue = null;
/*  919 */     if ((i | 0x20) == 125) {
/*  920 */       _closeScope(i);
/*  921 */       return null;
/*      */     } 
/*  923 */     if (this._parsingContext.expectComma()) {
/*  924 */       i = _skipComma(i);
/*  925 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  926 */         i | 0x20) == 125) {
/*  927 */         _closeScope(i);
/*  928 */         return null;
/*      */       } 
/*      */     } 
/*      */     
/*  932 */     if (!this._parsingContext.inObject()) {
/*  933 */       _updateLocation();
/*  934 */       _nextTokenNotInObject(i);
/*  935 */       return null;
/*      */     } 
/*      */     
/*  938 */     _updateNameLocation();
/*  939 */     String name = (i == 34) ? _parseName() : _handleOddName(i);
/*  940 */     this._parsingContext.setCurrentName(name);
/*  941 */     _updateToken(JsonToken.FIELD_NAME);
/*  942 */     i = _skipColon();
/*      */     
/*  944 */     _updateLocation();
/*  945 */     if (i == 34) {
/*  946 */       this._tokenIncomplete = true;
/*  947 */       this._nextToken = JsonToken.VALUE_STRING;
/*  948 */       return name;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  955 */     switch (i)
/*      */     { case 45:
/*  957 */         t = _parseSignedNumber(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1003 */         this._nextToken = t;
/* 1004 */         return name;case 43: if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) { t = _parseSignedNumber(false); } else { t = _handleOddValue(i); }  this._nextToken = t; return name;case 46: t = _parseFloatThatStartsWithPeriod(false); this._nextToken = t; return name;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parseUnsignedNumber(i); this._nextToken = t; return name;case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return name;case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return name;case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return name;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return name;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return name; }  JsonToken t = _handleOddValue(i); this._nextToken = t; return name;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _isNextTokenNameYes(int i) throws IOException {
/* 1009 */     _updateToken(JsonToken.FIELD_NAME);
/* 1010 */     _updateLocation();
/*      */     
/* 1012 */     switch (i) {
/*      */       case 34:
/* 1014 */         this._tokenIncomplete = true;
/* 1015 */         this._nextToken = JsonToken.VALUE_STRING;
/*      */         return;
/*      */       case 91:
/* 1018 */         this._nextToken = JsonToken.START_ARRAY;
/*      */         return;
/*      */       case 123:
/* 1021 */         this._nextToken = JsonToken.START_OBJECT;
/*      */         return;
/*      */       case 116:
/* 1024 */         _matchToken("true", 1);
/* 1025 */         this._nextToken = JsonToken.VALUE_TRUE;
/*      */         return;
/*      */       case 102:
/* 1028 */         _matchToken("false", 1);
/* 1029 */         this._nextToken = JsonToken.VALUE_FALSE;
/*      */         return;
/*      */       case 110:
/* 1032 */         _matchToken("null", 1);
/* 1033 */         this._nextToken = JsonToken.VALUE_NULL;
/*      */         return;
/*      */       case 45:
/* 1036 */         this._nextToken = _parseSignedNumber(true);
/*      */         return;
/*      */       case 43:
/* 1039 */         if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/* 1040 */           this._nextToken = _parseSignedNumber(false);
/*      */         } else {
/* 1042 */           this._nextToken = _handleOddValue(i);
/*      */         } 
/*      */         return;
/*      */       case 46:
/* 1046 */         this._nextToken = _parseFloatThatStartsWithPeriod(false);
/*      */         return;
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/* 1058 */         this._nextToken = _parseUnsignedNumber(i);
/*      */         return;
/*      */     } 
/* 1061 */     this._nextToken = _handleOddValue(i);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _isNextTokenNameMaybe(int i, String nameToMatch) throws IOException {
/* 1067 */     String name = (i == 34) ? _parseName() : _handleOddName(i);
/* 1068 */     this._parsingContext.setCurrentName(name);
/* 1069 */     _updateToken(JsonToken.FIELD_NAME);
/* 1070 */     i = _skipColon();
/* 1071 */     _updateLocation();
/* 1072 */     if (i == 34) {
/* 1073 */       this._tokenIncomplete = true;
/* 1074 */       this._nextToken = JsonToken.VALUE_STRING;
/* 1075 */       return nameToMatch.equals(name);
/*      */     } 
/*      */ 
/*      */     
/* 1079 */     switch (i)
/*      */     { case 45:
/* 1081 */         t = _parseSignedNumber(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1127 */         this._nextToken = t;
/* 1128 */         return nameToMatch.equals(name);case 43: if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) { t = _parseSignedNumber(false); } else { t = _handleOddValue(i); }  this._nextToken = t; return nameToMatch.equals(name);case 46: t = _parseFloatThatStartsWithPeriod(false); this._nextToken = t; return nameToMatch.equals(name);case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parseUnsignedNumber(i); this._nextToken = t; return nameToMatch.equals(name);case 102: _matchFalse(); t = JsonToken.VALUE_FALSE; this._nextToken = t; return nameToMatch.equals(name);case 110: _matchNull(); t = JsonToken.VALUE_NULL; this._nextToken = t; return nameToMatch.equals(name);case 116: _matchTrue(); t = JsonToken.VALUE_TRUE; this._nextToken = t; return nameToMatch.equals(name);case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return nameToMatch.equals(name);case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return nameToMatch.equals(name); }  JsonToken t = _handleOddValue(i); this._nextToken = t; return nameToMatch.equals(name);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextTokenNotInObject(int i) throws IOException {
/* 1133 */     if (i == 34) {
/* 1134 */       this._tokenIncomplete = true;
/* 1135 */       return _updateToken(JsonToken.VALUE_STRING);
/*      */     } 
/* 1137 */     switch (i) {
/*      */       case 91:
/* 1139 */         createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1140 */         return _updateToken(JsonToken.START_ARRAY);
/*      */       case 123:
/* 1142 */         createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/* 1143 */         return _updateToken(JsonToken.START_OBJECT);
/*      */       case 116:
/* 1145 */         _matchToken("true", 1);
/* 1146 */         return _updateToken(JsonToken.VALUE_TRUE);
/*      */       case 102:
/* 1148 */         _matchToken("false", 1);
/* 1149 */         return _updateToken(JsonToken.VALUE_FALSE);
/*      */       case 110:
/* 1151 */         _matchToken("null", 1);
/* 1152 */         return _updateToken(JsonToken.VALUE_NULL);
/*      */       case 45:
/* 1154 */         return _updateToken(_parseSignedNumber(true));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 46:
/* 1160 */         return _updateToken(_parseFloatThatStartsWithPeriod(false));
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/* 1171 */         return _updateToken(_parseUnsignedNumber(i));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 44:
/* 1183 */         if (!this._parsingContext.inRoot() && (
/* 1184 */           this._features & FEAT_MASK_ALLOW_MISSING) != 0) {
/* 1185 */           this._inputPtr--;
/* 1186 */           return _updateToken(JsonToken.VALUE_NULL);
/*      */         } 
/*      */         break;
/*      */     } 
/* 1190 */     return _updateToken(_handleOddValue(i));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final String nextTextValue() throws IOException {
/* 1196 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1197 */       this._nameCopied = false;
/* 1198 */       JsonToken t = this._nextToken;
/* 1199 */       this._nextToken = null;
/* 1200 */       _updateToken(t);
/* 1201 */       if (t == JsonToken.VALUE_STRING) {
/* 1202 */         if (this._tokenIncomplete) {
/* 1203 */           this._tokenIncomplete = false;
/* 1204 */           _finishString();
/*      */         } 
/* 1206 */         return this._textBuffer.contentsAsString();
/*      */       } 
/* 1208 */       if (t == JsonToken.START_ARRAY) {
/* 1209 */         createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1210 */       } else if (t == JsonToken.START_OBJECT) {
/* 1211 */         createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1213 */       return null;
/*      */     } 
/*      */     
/* 1216 */     return (nextToken() == JsonToken.VALUE_STRING) ? getText() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int nextIntValue(int defaultValue) throws IOException {
/* 1223 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1224 */       this._nameCopied = false;
/* 1225 */       JsonToken t = this._nextToken;
/* 1226 */       this._nextToken = null;
/* 1227 */       _updateToken(t);
/* 1228 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1229 */         return getIntValue();
/*      */       }
/* 1231 */       if (t == JsonToken.START_ARRAY) {
/* 1232 */         createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1233 */       } else if (t == JsonToken.START_OBJECT) {
/* 1234 */         createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1236 */       return defaultValue;
/*      */     } 
/*      */     
/* 1239 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getIntValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final long nextLongValue(long defaultValue) throws IOException {
/* 1246 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1247 */       this._nameCopied = false;
/* 1248 */       JsonToken t = this._nextToken;
/* 1249 */       this._nextToken = null;
/* 1250 */       _updateToken(t);
/* 1251 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/* 1252 */         return getLongValue();
/*      */       }
/* 1254 */       if (t == JsonToken.START_ARRAY) {
/* 1255 */         createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1256 */       } else if (t == JsonToken.START_OBJECT) {
/* 1257 */         createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1259 */       return defaultValue;
/*      */     } 
/*      */     
/* 1262 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getLongValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Boolean nextBooleanValue() throws IOException {
/* 1269 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1270 */       this._nameCopied = false;
/* 1271 */       JsonToken jsonToken = this._nextToken;
/* 1272 */       this._nextToken = null;
/* 1273 */       _updateToken(jsonToken);
/* 1274 */       if (jsonToken == JsonToken.VALUE_TRUE) {
/* 1275 */         return Boolean.TRUE;
/*      */       }
/* 1277 */       if (jsonToken == JsonToken.VALUE_FALSE) {
/* 1278 */         return Boolean.FALSE;
/*      */       }
/* 1280 */       if (jsonToken == JsonToken.START_ARRAY) {
/* 1281 */         createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/* 1282 */       } else if (jsonToken == JsonToken.START_OBJECT) {
/* 1283 */         createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/* 1285 */       return null;
/*      */     } 
/* 1287 */     JsonToken t = nextToken();
/* 1288 */     if (t != null) {
/* 1289 */       int id = t.id();
/* 1290 */       if (id == 9) return Boolean.TRUE; 
/* 1291 */       if (id == 10) return Boolean.FALSE; 
/*      */     } 
/* 1293 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod() throws IOException {
/* 1304 */     return _parseFloatThatStartsWithPeriod(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod(boolean neg) throws IOException {
/* 1311 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1312 */       return _handleOddValue(46);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1320 */     int startPtr = this._inputPtr - 1;
/* 1321 */     if (neg) {
/* 1322 */       startPtr--;
/*      */     }
/* 1324 */     return _parseFloat(46, startPtr, this._inputPtr, neg, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _parseUnsignedNumber(int ch) throws IOException {
/* 1357 */     int ptr = this._inputPtr;
/* 1358 */     int startPtr = ptr - 1;
/* 1359 */     int inputLen = this._inputEnd;
/*      */ 
/*      */     
/* 1362 */     if (ch == 48) {
/* 1363 */       return _parseNumber2(false, startPtr);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1372 */     int intLen = 1;
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 1377 */       if (ptr >= inputLen) {
/* 1378 */         this._inputPtr = startPtr;
/* 1379 */         return _parseNumber2(false, startPtr);
/*      */       } 
/* 1381 */       ch = this._inputBuffer[ptr++];
/* 1382 */       if (ch < 48 || ch > 57) {
/*      */         break;
/*      */       }
/* 1385 */       intLen++;
/*      */     } 
/* 1387 */     if (ch == 46 || (ch | 0x20) == 101) {
/* 1388 */       this._inputPtr = ptr;
/* 1389 */       return _parseFloat(ch, startPtr, ptr, false, intLen);
/*      */     } 
/*      */ 
/*      */     
/* 1393 */     this._inputPtr = --ptr;
/*      */     
/* 1395 */     if (this._parsingContext.inRoot()) {
/* 1396 */       _verifyRootSpace(ch);
/*      */     }
/* 1398 */     int len = ptr - startPtr;
/* 1399 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, len);
/* 1400 */     return resetInt(false, intLen);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseFloat(int ch, int startPtr, int ptr, boolean neg, int intLen) throws IOException {
/* 1406 */     int inputLen = this._inputEnd;
/* 1407 */     int fractLen = 0;
/*      */ 
/*      */     
/* 1410 */     if (ch == 46) {
/*      */       
/*      */       while (true) {
/* 1413 */         if (ptr >= inputLen) {
/* 1414 */           return _parseNumber2(neg, startPtr);
/*      */         }
/* 1416 */         ch = this._inputBuffer[ptr++];
/* 1417 */         if (ch < 48 || ch > 57) {
/*      */           break;
/*      */         }
/* 1420 */         fractLen++;
/*      */       } 
/*      */       
/* 1423 */       if (fractLen == 0 && 
/* 1424 */         !isEnabled(JsonReadFeature.ALLOW_TRAILING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1425 */         _reportUnexpectedNumberChar(ch, "Decimal point not followed by a digit");
/*      */       }
/*      */     } 
/*      */     
/* 1429 */     int expLen = 0;
/* 1430 */     if ((ch | 0x20) == 101) {
/* 1431 */       if (ptr >= inputLen) {
/* 1432 */         this._inputPtr = startPtr;
/* 1433 */         return _parseNumber2(neg, startPtr);
/*      */       } 
/*      */       
/* 1436 */       ch = this._inputBuffer[ptr++];
/* 1437 */       if (ch == 45 || ch == 43) {
/* 1438 */         if (ptr >= inputLen) {
/* 1439 */           this._inputPtr = startPtr;
/* 1440 */           return _parseNumber2(neg, startPtr);
/*      */         } 
/* 1442 */         ch = this._inputBuffer[ptr++];
/*      */       } 
/* 1444 */       while (ch <= 57 && ch >= 48) {
/* 1445 */         expLen++;
/* 1446 */         if (ptr >= inputLen) {
/* 1447 */           this._inputPtr = startPtr;
/* 1448 */           return _parseNumber2(neg, startPtr);
/*      */         } 
/* 1450 */         ch = this._inputBuffer[ptr++];
/*      */       } 
/*      */       
/* 1453 */       if (expLen == 0) {
/* 1454 */         _reportUnexpectedNumberChar(ch, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */     
/* 1458 */     this._inputPtr = --ptr;
/*      */     
/* 1460 */     if (this._parsingContext.inRoot()) {
/* 1461 */       _verifyRootSpace(ch);
/*      */     }
/* 1463 */     int len = ptr - startPtr;
/* 1464 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, len);
/*      */     
/* 1466 */     return resetFloat(neg, intLen, fractLen, expLen);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _parseSignedNumber(boolean negative) throws IOException {
/* 1471 */     int ptr = this._inputPtr;
/*      */ 
/*      */     
/* 1474 */     int startPtr = negative ? (ptr - 1) : ptr;
/* 1475 */     int inputEnd = this._inputEnd;
/*      */     
/* 1477 */     if (ptr >= inputEnd) {
/* 1478 */       return _parseNumber2(negative, startPtr);
/*      */     }
/* 1480 */     int ch = this._inputBuffer[ptr++];
/*      */     
/* 1482 */     if (ch > 57 || ch < 48) {
/* 1483 */       this._inputPtr = ptr;
/* 1484 */       if (ch == 46) {
/* 1485 */         return _parseFloatThatStartsWithPeriod(negative);
/*      */       }
/* 1487 */       return _handleInvalidNumberStart(ch, negative, true);
/*      */     } 
/*      */     
/* 1490 */     if (ch == 48) {
/* 1491 */       return _parseNumber2(negative, startPtr);
/*      */     }
/* 1493 */     int intLen = 1;
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 1498 */       if (ptr >= inputEnd) {
/* 1499 */         return _parseNumber2(negative, startPtr);
/*      */       }
/* 1501 */       ch = this._inputBuffer[ptr++];
/* 1502 */       if (ch < 48 || ch > 57) {
/*      */         break;
/*      */       }
/* 1505 */       intLen++;
/*      */     } 
/*      */     
/* 1508 */     if (ch == 46 || (ch | 0x20) == 101) {
/* 1509 */       this._inputPtr = ptr;
/* 1510 */       return _parseFloat(ch, startPtr, ptr, negative, intLen);
/*      */     } 
/*      */     
/* 1513 */     this._inputPtr = --ptr;
/* 1514 */     if (this._parsingContext.inRoot()) {
/* 1515 */       _verifyRootSpace(ch);
/*      */     }
/* 1517 */     int len = ptr - startPtr;
/* 1518 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, len);
/* 1519 */     return resetInt(negative, intLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseNumber2(boolean neg, int startPtr) throws IOException {
/* 1540 */     this._inputPtr = neg ? (startPtr + 1) : startPtr;
/* 1541 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1542 */     int outPtr = 0;
/*      */ 
/*      */     
/* 1545 */     if (neg) {
/* 1546 */       outBuf[outPtr++] = '-';
/*      */     }
/*      */ 
/*      */     
/* 1550 */     int intLen = 0;
/*      */     
/* 1552 */     char c = (this._inputPtr < this._inputEnd) ? this._inputBuffer[this._inputPtr++] : getNextChar("No digit following sign", JsonToken.VALUE_NUMBER_INT);
/* 1553 */     if (c == '0') {
/* 1554 */       c = _verifyNoLeadingZeroes();
/*      */     }
/* 1556 */     boolean eof = false;
/*      */ 
/*      */ 
/*      */     
/* 1560 */     while (c >= '0' && c <= '9') {
/* 1561 */       intLen++;
/* 1562 */       if (outPtr >= outBuf.length) {
/* 1563 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1564 */         outPtr = 0;
/*      */       } 
/* 1566 */       outBuf[outPtr++] = c;
/* 1567 */       if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */         
/* 1569 */         c = Character.MIN_VALUE;
/* 1570 */         eof = true;
/*      */         break;
/*      */       } 
/* 1573 */       c = this._inputBuffer[this._inputPtr++];
/*      */     } 
/*      */     
/* 1576 */     if (intLen == 0)
/*      */     {
/* 1578 */       if (c != '.' || !isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1579 */         return _handleInvalidNumberStart(c, neg);
/*      */       }
/*      */     }
/*      */     
/* 1583 */     int fractLen = -1;
/*      */     
/* 1585 */     if (c == '.') {
/* 1586 */       fractLen = 0;
/* 1587 */       if (outPtr >= outBuf.length) {
/* 1588 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1589 */         outPtr = 0;
/*      */       } 
/* 1591 */       outBuf[outPtr++] = c;
/*      */ 
/*      */       
/*      */       while (true) {
/* 1595 */         if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1596 */           eof = true;
/*      */           break;
/*      */         } 
/* 1599 */         c = this._inputBuffer[this._inputPtr++];
/* 1600 */         if (c < '0' || c > '9') {
/*      */           break;
/*      */         }
/* 1603 */         fractLen++;
/* 1604 */         if (outPtr >= outBuf.length) {
/* 1605 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1606 */           outPtr = 0;
/*      */         } 
/* 1608 */         outBuf[outPtr++] = c;
/*      */       } 
/*      */       
/* 1611 */       if (fractLen == 0 && 
/* 1612 */         !isEnabled(JsonReadFeature.ALLOW_TRAILING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1613 */         _reportUnexpectedNumberChar(c, "Decimal point not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1618 */     int expLen = -1;
/* 1619 */     if ((c | 0x20) == 101) {
/* 1620 */       expLen = 0;
/* 1621 */       if (outPtr >= outBuf.length) {
/* 1622 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1623 */         outPtr = 0;
/*      */       } 
/* 1625 */       outBuf[outPtr++] = c;
/*      */ 
/*      */       
/* 1628 */       c = (this._inputPtr < this._inputEnd) ? this._inputBuffer[this._inputPtr++] : getNextChar("expected a digit for number exponent", JsonToken.VALUE_NUMBER_FLOAT);
/*      */       
/* 1630 */       if (c == '-' || c == '+') {
/* 1631 */         if (outPtr >= outBuf.length) {
/* 1632 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1633 */           outPtr = 0;
/*      */         } 
/* 1635 */         outBuf[outPtr++] = c;
/*      */ 
/*      */         
/* 1638 */         c = (this._inputPtr < this._inputEnd) ? this._inputBuffer[this._inputPtr++] : getNextChar("expected a digit for number exponent", JsonToken.VALUE_NUMBER_FLOAT);
/*      */       } 
/*      */ 
/*      */       
/* 1642 */       while (c <= '9' && c >= '0') {
/* 1643 */         expLen++;
/* 1644 */         if (outPtr >= outBuf.length) {
/* 1645 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1646 */           outPtr = 0;
/*      */         } 
/* 1648 */         outBuf[outPtr++] = c;
/* 1649 */         if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1650 */           eof = true;
/*      */           break;
/*      */         } 
/* 1653 */         c = this._inputBuffer[this._inputPtr++];
/*      */       } 
/*      */       
/* 1656 */       if (expLen == 0) {
/* 1657 */         _reportUnexpectedNumberChar(c, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1662 */     if (!eof) {
/* 1663 */       this._inputPtr--;
/* 1664 */       if (this._parsingContext.inRoot()) {
/* 1665 */         _verifyRootSpace(c);
/*      */       }
/*      */     } 
/* 1668 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1673 */     if (fractLen < 0 && expLen < 0) {
/* 1674 */       return resetInt(neg, intLen);
/*      */     }
/* 1676 */     return resetFloat(neg, intLen, fractLen, expLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final char _verifyNoLeadingZeroes() throws IOException {
/* 1684 */     if (this._inputPtr < this._inputEnd) {
/* 1685 */       char ch = this._inputBuffer[this._inputPtr];
/*      */       
/* 1687 */       if (ch < '0' || ch > '9') {
/* 1688 */         return '0';
/*      */       }
/*      */     } 
/*      */     
/* 1692 */     return _verifyNLZ2();
/*      */   }
/*      */ 
/*      */   
/*      */   private char _verifyNLZ2() throws IOException {
/* 1697 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 1698 */       return '0';
/*      */     }
/* 1700 */     char ch = this._inputBuffer[this._inputPtr];
/* 1701 */     if (ch < '0' || ch > '9') {
/* 1702 */       return '0';
/*      */     }
/* 1704 */     if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1705 */       reportInvalidNumber("Leading zeroes not allowed");
/*      */     }
/*      */     
/* 1708 */     this._inputPtr++;
/* 1709 */     if (ch == '0') {
/* 1710 */       while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 1711 */         ch = this._inputBuffer[this._inputPtr];
/* 1712 */         if (ch < '0' || ch > '9') {
/* 1713 */           return '0';
/*      */         }
/* 1715 */         this._inputPtr++;
/* 1716 */         if (ch != '0') {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     }
/* 1721 */     return ch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean negative) throws IOException {
/* 1728 */     return _handleInvalidNumberStart(ch, negative, false);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean negative, boolean hasSign) throws IOException {
/* 1733 */     if (ch == 73) {
/* 1734 */       if (this._inputPtr >= this._inputEnd && 
/* 1735 */         !_loadMore()) {
/* 1736 */         _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_INT);
/*      */       }
/*      */       
/* 1739 */       ch = this._inputBuffer[this._inputPtr++];
/* 1740 */       if (ch == 78) {
/* 1741 */         String match = negative ? "-INF" : "+INF";
/* 1742 */         _matchToken(match, 3);
/* 1743 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 1744 */           return resetAsNaN(match, negative ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */         }
/* 1746 */         _reportError("Non-standard token '" + match + "': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/* 1747 */       } else if (ch == 110) {
/* 1748 */         String match = negative ? "-Infinity" : "+Infinity";
/* 1749 */         _matchToken(match, 3);
/* 1750 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 1751 */           return resetAsNaN(match, negative ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */         }
/* 1753 */         _reportError("Non-standard token '" + match + "': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/*      */       } 
/*      */     } 
/* 1756 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature()) && hasSign && !negative) {
/* 1757 */       _reportUnexpectedNumberChar(43, "JSON spec does not allow numbers to have plus signs: enable `JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS` to allow");
/*      */     }
/* 1759 */     String message = negative ? "expected digit (0-9) to follow minus sign, for valid numeric value" : "expected digit (0-9) for valid numeric value";
/*      */ 
/*      */     
/* 1762 */     _reportUnexpectedNumberChar(ch, message);
/* 1763 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _verifyRootSpace(int ch) throws IOException {
/* 1781 */     this._inputPtr++;
/* 1782 */     switch (ch) {
/*      */       case 9:
/*      */       case 32:
/*      */         return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 13:
/* 1793 */         this._inputPtr--;
/*      */         return;
/*      */       case 10:
/* 1796 */         this._currInputRow++;
/* 1797 */         this._currInputRowStart = this._inputPtr;
/*      */         return;
/*      */     } 
/* 1800 */     _reportMissingRootWS(ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String _parseName() throws IOException {
/* 1813 */     int ptr = this._inputPtr;
/* 1814 */     int hash = this._hashSeed;
/* 1815 */     int[] codes = INPUT_CODES_LATIN1;
/*      */     
/* 1817 */     while (ptr < this._inputEnd) {
/* 1818 */       int ch = this._inputBuffer[ptr];
/* 1819 */       if (ch < codes.length && codes[ch] != 0) {
/* 1820 */         if (ch == 34) {
/* 1821 */           int i = this._inputPtr;
/* 1822 */           this._inputPtr = ptr + 1;
/* 1823 */           return this._symbols.findSymbol(this._inputBuffer, i, ptr - i, hash);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1827 */       hash = hash * 33 + ch;
/* 1828 */       ptr++;
/*      */     } 
/* 1830 */     int start = this._inputPtr;
/* 1831 */     this._inputPtr = ptr;
/* 1832 */     return _parseName2(start, hash, 34);
/*      */   }
/*      */ 
/*      */   
/*      */   private String _parseName2(int startPtr, int hash, int endChar) throws IOException {
/* 1837 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, this._inputPtr - startPtr);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1842 */     char[] outBuf = this._textBuffer.getCurrentSegment();
/* 1843 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/*      */     
/*      */     while (true) {
/* 1846 */       if (this._inputPtr >= this._inputEnd && 
/* 1847 */         !_loadMore()) {
/* 1848 */         _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */       }
/*      */       
/* 1851 */       char c = this._inputBuffer[this._inputPtr++];
/* 1852 */       int i = c;
/* 1853 */       if (i <= 92) {
/* 1854 */         if (i == 92) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1859 */           c = _decodeEscaped();
/* 1860 */         } else if (i <= endChar) {
/* 1861 */           if (i == endChar) {
/*      */             break;
/*      */           }
/* 1864 */           if (i < 32) {
/* 1865 */             _throwUnquotedSpace(i, "name");
/*      */           }
/*      */         } 
/*      */       }
/* 1869 */       hash = hash * 33 + c;
/*      */       
/* 1871 */       outBuf[outPtr++] = c;
/*      */ 
/*      */       
/* 1874 */       if (outPtr >= outBuf.length) {
/* 1875 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1876 */         outPtr = 0;
/*      */       } 
/*      */     } 
/* 1879 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1881 */     TextBuffer tb = this._textBuffer;
/* 1882 */     char[] buf = tb.getTextBuffer();
/* 1883 */     int start = tb.getTextOffset();
/* 1884 */     return this._symbols.findSymbol(buf, start, tb.size(), hash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _handleOddName(int i) throws IOException {
/*      */     boolean firstOk;
/* 1904 */     if (i == 39 && (this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 1905 */       return _parseAposName();
/*      */     }
/*      */     
/* 1908 */     if ((this._features & FEAT_MASK_ALLOW_UNQUOTED_NAMES) == 0) {
/* 1909 */       _reportUnexpectedChar(i, "was expecting double-quote to start field name");
/*      */     }
/* 1911 */     int[] codes = CharTypes.getInputCodeLatin1JsNames();
/* 1912 */     int maxCode = codes.length;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1917 */     if (i < maxCode) {
/* 1918 */       firstOk = (codes[i] == 0);
/*      */     } else {
/* 1920 */       firstOk = Character.isJavaIdentifierPart((char)i);
/*      */     } 
/* 1922 */     if (!firstOk) {
/* 1923 */       _reportUnexpectedChar(i, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/* 1925 */     int ptr = this._inputPtr;
/* 1926 */     int hash = this._hashSeed;
/* 1927 */     int inputLen = this._inputEnd;
/*      */     
/* 1929 */     if (ptr < inputLen) {
/*      */       do {
/* 1931 */         int ch = this._inputBuffer[ptr];
/* 1932 */         if (ch < maxCode) {
/* 1933 */           if (codes[ch] != 0) {
/* 1934 */             int j = this._inputPtr - 1;
/* 1935 */             this._inputPtr = ptr;
/* 1936 */             return this._symbols.findSymbol(this._inputBuffer, j, ptr - j, hash);
/*      */           } 
/* 1938 */         } else if (!Character.isJavaIdentifierPart((char)ch)) {
/* 1939 */           int j = this._inputPtr - 1;
/* 1940 */           this._inputPtr = ptr;
/* 1941 */           return this._symbols.findSymbol(this._inputBuffer, j, ptr - j, hash);
/*      */         } 
/* 1943 */         hash = hash * 33 + ch;
/* 1944 */         ++ptr;
/* 1945 */       } while (ptr < inputLen);
/*      */     }
/* 1947 */     int start = this._inputPtr - 1;
/* 1948 */     this._inputPtr = ptr;
/* 1949 */     return _handleOddName2(start, hash, codes);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _parseAposName() throws IOException {
/* 1955 */     int ptr = this._inputPtr;
/* 1956 */     int hash = this._hashSeed;
/* 1957 */     int inputLen = this._inputEnd;
/*      */     
/* 1959 */     if (ptr < inputLen) {
/* 1960 */       int[] codes = INPUT_CODES_LATIN1;
/* 1961 */       int maxCode = codes.length;
/*      */       
/*      */       do {
/* 1964 */         int ch = this._inputBuffer[ptr];
/* 1965 */         if (ch == 39) {
/* 1966 */           int i = this._inputPtr;
/* 1967 */           this._inputPtr = ptr + 1;
/* 1968 */           return this._symbols.findSymbol(this._inputBuffer, i, ptr - i, hash);
/*      */         } 
/* 1970 */         if (ch < maxCode && codes[ch] != 0) {
/*      */           break;
/*      */         }
/* 1973 */         hash = hash * 33 + ch;
/* 1974 */         ++ptr;
/* 1975 */       } while (ptr < inputLen);
/*      */     } 
/*      */     
/* 1978 */     int start = this._inputPtr;
/* 1979 */     this._inputPtr = ptr;
/*      */     
/* 1981 */     return _parseName2(start, hash, 39);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleOddValue(int i) throws IOException {
/* 1998 */     switch (i) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 39:
/* 2005 */         if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 2006 */           return _handleApos();
/*      */         }
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 93:
/* 2014 */         if (!this._parsingContext.inArray()) {
/*      */           break;
/*      */         }
/*      */ 
/*      */       
/*      */       case 44:
/* 2020 */         if (!this._parsingContext.inRoot() && (
/* 2021 */           this._features & FEAT_MASK_ALLOW_MISSING) != 0) {
/* 2022 */           this._inputPtr--;
/* 2023 */           return JsonToken.VALUE_NULL;
/*      */         } 
/*      */         break;
/*      */       
/*      */       case 78:
/* 2028 */         _matchToken("NaN", 1);
/* 2029 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2030 */           return resetAsNaN("NaN", Double.NaN);
/*      */         }
/* 2032 */         _reportError("Non-standard token 'NaN': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/*      */         break;
/*      */       case 73:
/* 2035 */         _matchToken("Infinity", 1);
/* 2036 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2037 */           return resetAsNaN("Infinity", Double.POSITIVE_INFINITY);
/*      */         }
/* 2039 */         _reportError("Non-standard token 'Infinity': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/*      */         break;
/*      */       case 43:
/* 2042 */         if (this._inputPtr >= this._inputEnd && 
/* 2043 */           !_loadMore()) {
/* 2044 */           _reportInvalidEOFInValue(JsonToken.VALUE_NUMBER_INT);
/*      */         }
/*      */         
/* 2047 */         return _handleInvalidNumberStart(this._inputBuffer[this._inputPtr++], false, true);
/*      */     } 
/*      */     
/* 2050 */     if (Character.isJavaIdentifierStart(i)) {
/* 2051 */       _reportInvalidToken("" + (char)i, _validJsonTokenList());
/*      */     }
/*      */     
/* 2054 */     _reportUnexpectedChar(i, "expected a valid value " + _validJsonValueList());
/* 2055 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleApos() throws IOException {
/* 2060 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2061 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/*      */     
/*      */     while (true) {
/* 2064 */       if (this._inputPtr >= this._inputEnd && 
/* 2065 */         !_loadMore()) {
/* 2066 */         _reportInvalidEOF(": was expecting closing quote for a string value", JsonToken.VALUE_STRING);
/*      */       }
/*      */ 
/*      */       
/* 2070 */       char c = this._inputBuffer[this._inputPtr++];
/* 2071 */       int i = c;
/* 2072 */       if (i <= 92) {
/* 2073 */         if (i == 92) {
/*      */ 
/*      */ 
/*      */           
/* 2077 */           c = _decodeEscaped();
/* 2078 */         } else if (i <= 39) {
/* 2079 */           if (i == 39) {
/*      */             break;
/*      */           }
/* 2082 */           if (i < 32) {
/* 2083 */             _throwUnquotedSpace(i, "string value");
/*      */           }
/*      */         } 
/*      */       }
/*      */       
/* 2088 */       if (outPtr >= outBuf.length) {
/* 2089 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2090 */         outPtr = 0;
/*      */       } 
/*      */       
/* 2093 */       outBuf[outPtr++] = c;
/*      */     } 
/* 2095 */     this._textBuffer.setCurrentLength(outPtr);
/* 2096 */     return JsonToken.VALUE_STRING;
/*      */   }
/*      */ 
/*      */   
/*      */   private String _handleOddName2(int startPtr, int hash, int[] codes) throws IOException {
/* 2101 */     this._textBuffer.resetWithShared(this._inputBuffer, startPtr, this._inputPtr - startPtr);
/* 2102 */     char[] outBuf = this._textBuffer.getCurrentSegment();
/* 2103 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2104 */     int maxCode = codes.length;
/*      */ 
/*      */     
/* 2107 */     while (this._inputPtr < this._inputEnd || 
/* 2108 */       _loadMore()) {
/*      */ 
/*      */ 
/*      */       
/* 2112 */       char c = this._inputBuffer[this._inputPtr];
/* 2113 */       int i = c;
/* 2114 */       if ((i < maxCode) ? (
/* 2115 */         codes[i] != 0) : 
/*      */ 
/*      */         
/* 2118 */         !Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/* 2121 */       this._inputPtr++;
/* 2122 */       hash = hash * 33 + i;
/*      */       
/* 2124 */       outBuf[outPtr++] = c;
/*      */ 
/*      */       
/* 2127 */       if (outPtr >= outBuf.length) {
/* 2128 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2129 */         outPtr = 0;
/*      */       } 
/*      */     } 
/* 2132 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 2134 */     TextBuffer tb = this._textBuffer;
/* 2135 */     char[] buf = tb.getTextBuffer();
/* 2136 */     int start = tb.getTextOffset();
/* 2137 */     return this._symbols.findSymbol(buf, start, tb.size(), hash);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _finishString() throws IOException {
/* 2148 */     int ptr = this._inputPtr;
/* 2149 */     int inputLen = this._inputEnd;
/*      */     
/* 2151 */     if (ptr < inputLen) {
/* 2152 */       int[] codes = INPUT_CODES_LATIN1;
/* 2153 */       int maxCode = codes.length;
/*      */       
/*      */       do {
/* 2156 */         int ch = this._inputBuffer[ptr];
/* 2157 */         if (ch < maxCode && codes[ch] != 0) {
/* 2158 */           if (ch == 34) {
/* 2159 */             this._textBuffer.resetWithShared(this._inputBuffer, this._inputPtr, ptr - this._inputPtr);
/* 2160 */             this._inputPtr = ptr + 1;
/*      */             
/*      */             return;
/*      */           } 
/*      */           break;
/*      */         } 
/* 2166 */         ++ptr;
/* 2167 */       } while (ptr < inputLen);
/*      */     } 
/*      */ 
/*      */     
/* 2171 */     this._textBuffer.resetWithCopy(this._inputBuffer, this._inputPtr, ptr - this._inputPtr);
/* 2172 */     this._inputPtr = ptr;
/* 2173 */     _finishString2();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _finishString2() throws IOException {
/* 2178 */     char[] outBuf = this._textBuffer.getCurrentSegment();
/* 2179 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2180 */     int[] codes = INPUT_CODES_LATIN1;
/* 2181 */     int maxCode = codes.length;
/*      */     
/*      */     while (true) {
/* 2184 */       if (this._inputPtr >= this._inputEnd && 
/* 2185 */         !_loadMore()) {
/* 2186 */         _reportInvalidEOF(": was expecting closing quote for a string value", JsonToken.VALUE_STRING);
/*      */       }
/*      */ 
/*      */       
/* 2190 */       char c = this._inputBuffer[this._inputPtr++];
/* 2191 */       int i = c;
/* 2192 */       if (i < maxCode && codes[i] != 0) {
/* 2193 */         if (i == 34)
/*      */           break; 
/* 2195 */         if (i == 92) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2200 */           c = _decodeEscaped();
/* 2201 */         } else if (i < 32) {
/* 2202 */           _throwUnquotedSpace(i, "string value");
/*      */         } 
/*      */       } 
/*      */       
/* 2206 */       if (outPtr >= outBuf.length) {
/* 2207 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2208 */         outPtr = 0;
/*      */       } 
/*      */       
/* 2211 */       outBuf[outPtr++] = c;
/*      */     } 
/* 2213 */     this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _skipString() throws IOException {
/* 2226 */     this._tokenIncomplete = false;
/*      */     
/* 2228 */     int inPtr = this._inputPtr;
/* 2229 */     int inLen = this._inputEnd;
/* 2230 */     char[] inBuf = this._inputBuffer;
/*      */     
/*      */     while (true) {
/* 2233 */       if (inPtr >= inLen) {
/* 2234 */         this._inputPtr = inPtr;
/* 2235 */         if (!_loadMore()) {
/* 2236 */           _reportInvalidEOF(": was expecting closing quote for a string value", JsonToken.VALUE_STRING);
/*      */         }
/*      */         
/* 2239 */         inPtr = this._inputPtr;
/* 2240 */         inLen = this._inputEnd;
/*      */       } 
/* 2242 */       char c = inBuf[inPtr++];
/* 2243 */       int i = c;
/* 2244 */       if (i <= 92) {
/* 2245 */         if (i == 92) {
/*      */ 
/*      */           
/* 2248 */           this._inputPtr = inPtr;
/* 2249 */           _decodeEscaped();
/* 2250 */           inPtr = this._inputPtr;
/* 2251 */           inLen = this._inputEnd; continue;
/* 2252 */         }  if (i <= 34) {
/* 2253 */           if (i == 34) {
/* 2254 */             this._inputPtr = inPtr;
/*      */             break;
/*      */           } 
/* 2257 */           if (i < 32) {
/* 2258 */             this._inputPtr = inPtr;
/* 2259 */             _throwUnquotedSpace(i, "string value");
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _skipCR() throws IOException {
/* 2275 */     if ((this._inputPtr < this._inputEnd || _loadMore()) && 
/* 2276 */       this._inputBuffer[this._inputPtr] == '\n') {
/* 2277 */       this._inputPtr++;
/*      */     }
/*      */     
/* 2280 */     this._currInputRow++;
/* 2281 */     this._currInputRowStart = this._inputPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon() throws IOException {
/* 2286 */     if (this._inputPtr + 4 >= this._inputEnd) {
/* 2287 */       return _skipColon2(false);
/*      */     }
/* 2289 */     char c = this._inputBuffer[this._inputPtr];
/* 2290 */     if (c == ':') {
/* 2291 */       int i = this._inputBuffer[++this._inputPtr];
/* 2292 */       if (i > 32) {
/* 2293 */         if (i == 47 || i == 35) {
/* 2294 */           return _skipColon2(true);
/*      */         }
/* 2296 */         this._inputPtr++;
/* 2297 */         return i;
/*      */       } 
/* 2299 */       if (i == 32 || i == 9) {
/* 2300 */         i = this._inputBuffer[++this._inputPtr];
/* 2301 */         if (i > 32) {
/* 2302 */           if (i == 47 || i == 35) {
/* 2303 */             return _skipColon2(true);
/*      */           }
/* 2305 */           this._inputPtr++;
/* 2306 */           return i;
/*      */         } 
/*      */       } 
/* 2309 */       return _skipColon2(true);
/*      */     } 
/* 2311 */     if (c == ' ' || c == '\t') {
/* 2312 */       c = this._inputBuffer[++this._inputPtr];
/*      */     }
/* 2314 */     if (c == ':') {
/* 2315 */       int i = this._inputBuffer[++this._inputPtr];
/* 2316 */       if (i > 32) {
/* 2317 */         if (i == 47 || i == 35) {
/* 2318 */           return _skipColon2(true);
/*      */         }
/* 2320 */         this._inputPtr++;
/* 2321 */         return i;
/*      */       } 
/* 2323 */       if (i == 32 || i == 9) {
/* 2324 */         i = this._inputBuffer[++this._inputPtr];
/* 2325 */         if (i > 32) {
/* 2326 */           if (i == 47 || i == 35) {
/* 2327 */             return _skipColon2(true);
/*      */           }
/* 2329 */           this._inputPtr++;
/* 2330 */           return i;
/*      */         } 
/*      */       } 
/* 2333 */       return _skipColon2(true);
/*      */     } 
/* 2335 */     return _skipColon2(false);
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon2(boolean gotColon) throws IOException {
/* 2340 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 2341 */       int i = this._inputBuffer[this._inputPtr++];
/* 2342 */       if (i > 32) {
/* 2343 */         if (i == 47) {
/* 2344 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 2347 */         if (i == 35 && 
/* 2348 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 2352 */         if (gotColon) {
/* 2353 */           return i;
/*      */         }
/* 2355 */         if (i != 58) {
/* 2356 */           _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */         }
/* 2358 */         gotColon = true;
/*      */         continue;
/*      */       } 
/* 2361 */       if (i < 32) {
/* 2362 */         if (i == 10) {
/* 2363 */           this._currInputRow++;
/* 2364 */           this._currInputRowStart = this._inputPtr; continue;
/* 2365 */         }  if (i == 13) {
/* 2366 */           _skipCR(); continue;
/* 2367 */         }  if (i != 9) {
/* 2368 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2372 */     _reportInvalidEOF(" within/between " + this._parsingContext.typeDesc() + " entries", null);
/*      */     
/* 2374 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipColonFast(int ptr) throws IOException {
/* 2380 */     int i = this._inputBuffer[ptr++];
/* 2381 */     if (i == 58) {
/* 2382 */       i = this._inputBuffer[ptr++];
/* 2383 */       if (i > 32) {
/* 2384 */         if (i != 47 && i != 35) {
/* 2385 */           this._inputPtr = ptr;
/* 2386 */           return i;
/*      */         } 
/* 2388 */       } else if (i == 32 || i == 9) {
/* 2389 */         i = this._inputBuffer[ptr++];
/* 2390 */         if (i > 32 && 
/* 2391 */           i != 47 && i != 35) {
/* 2392 */           this._inputPtr = ptr;
/* 2393 */           return i;
/*      */         } 
/*      */       } 
/*      */       
/* 2397 */       this._inputPtr = ptr - 1;
/* 2398 */       return _skipColon2(true);
/*      */     } 
/* 2400 */     if (i == 32 || i == 9) {
/* 2401 */       i = this._inputBuffer[ptr++];
/*      */     }
/* 2403 */     boolean gotColon = (i == 58);
/* 2404 */     if (gotColon) {
/* 2405 */       i = this._inputBuffer[ptr++];
/* 2406 */       if (i > 32) {
/* 2407 */         if (i != 47 && i != 35) {
/* 2408 */           this._inputPtr = ptr;
/* 2409 */           return i;
/*      */         } 
/* 2411 */       } else if (i == 32 || i == 9) {
/* 2412 */         i = this._inputBuffer[ptr++];
/* 2413 */         if (i > 32 && 
/* 2414 */           i != 47 && i != 35) {
/* 2415 */           this._inputPtr = ptr;
/* 2416 */           return i;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 2421 */     this._inputPtr = ptr - 1;
/* 2422 */     return _skipColon2(gotColon);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipComma(int i) throws IOException {
/* 2428 */     if (i != 44) {
/* 2429 */       _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */     }
/* 2431 */     while (this._inputPtr < this._inputEnd) {
/* 2432 */       i = this._inputBuffer[this._inputPtr++];
/* 2433 */       if (i > 32) {
/* 2434 */         if (i == 47 || i == 35) {
/* 2435 */           this._inputPtr--;
/* 2436 */           return _skipAfterComma2();
/*      */         } 
/* 2438 */         return i;
/*      */       } 
/* 2440 */       if (i < 32) {
/* 2441 */         if (i == 10) {
/* 2442 */           this._currInputRow++;
/* 2443 */           this._currInputRowStart = this._inputPtr; continue;
/* 2444 */         }  if (i == 13) {
/* 2445 */           _skipCR(); continue;
/* 2446 */         }  if (i != 9) {
/* 2447 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2451 */     return _skipAfterComma2();
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipAfterComma2() throws IOException {
/* 2456 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 2457 */       int i = this._inputBuffer[this._inputPtr++];
/* 2458 */       if (i > 32) {
/* 2459 */         if (i == 47) {
/* 2460 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 2463 */         if (i == 35 && 
/* 2464 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 2468 */         return i;
/*      */       } 
/* 2470 */       if (i < 32) {
/* 2471 */         if (i == 10) {
/* 2472 */           this._currInputRow++;
/* 2473 */           this._currInputRowStart = this._inputPtr; continue;
/* 2474 */         }  if (i == 13) {
/* 2475 */           _skipCR(); continue;
/* 2476 */         }  if (i != 9) {
/* 2477 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2481 */     throw _constructError("Unexpected end-of-input within/between " + this._parsingContext.typeDesc() + " entries");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWSOrEnd() throws IOException {
/* 2488 */     if (this._inputPtr >= this._inputEnd && 
/* 2489 */       !_loadMore()) {
/* 2490 */       return _eofAsNextChar();
/*      */     }
/*      */     
/* 2493 */     int i = this._inputBuffer[this._inputPtr++];
/* 2494 */     if (i > 32) {
/* 2495 */       if (i == 47 || i == 35) {
/* 2496 */         this._inputPtr--;
/* 2497 */         return _skipWSOrEnd2();
/*      */       } 
/* 2499 */       return i;
/*      */     } 
/* 2501 */     if (i != 32) {
/* 2502 */       if (i == 10) {
/* 2503 */         this._currInputRow++;
/* 2504 */         this._currInputRowStart = this._inputPtr;
/* 2505 */       } else if (i == 13) {
/* 2506 */         _skipCR();
/* 2507 */       } else if (i != 9 && !_isAllowedCtrlCharRS(i)) {
/* 2508 */         _throwInvalidSpace(i);
/*      */       } 
/*      */     }
/*      */     
/* 2512 */     while (this._inputPtr < this._inputEnd) {
/* 2513 */       i = this._inputBuffer[this._inputPtr++];
/* 2514 */       if (i > 32) {
/* 2515 */         if (i == 47 || i == 35) {
/* 2516 */           this._inputPtr--;
/* 2517 */           return _skipWSOrEnd2();
/*      */         } 
/* 2519 */         return i;
/*      */       } 
/* 2521 */       if (i != 32) {
/* 2522 */         if (i == 10) {
/* 2523 */           this._currInputRow++;
/* 2524 */           this._currInputRowStart = this._inputPtr; continue;
/* 2525 */         }  if (i == 13) {
/* 2526 */           _skipCR(); continue;
/* 2527 */         }  if (i != 9 && !_isAllowedCtrlCharRS(i)) {
/* 2528 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/* 2532 */     return _skipWSOrEnd2();
/*      */   }
/*      */ 
/*      */   
/*      */   private int _skipWSOrEnd2() throws IOException {
/*      */     while (true) {
/* 2538 */       if (this._inputPtr >= this._inputEnd && 
/* 2539 */         !_loadMore()) {
/* 2540 */         return _eofAsNextChar();
/*      */       }
/*      */       
/* 2543 */       int i = this._inputBuffer[this._inputPtr++];
/* 2544 */       if (i > 32) {
/* 2545 */         if (i == 47) {
/* 2546 */           _skipComment();
/*      */           continue;
/*      */         } 
/* 2549 */         if (i == 35 && 
/* 2550 */           _skipYAMLComment()) {
/*      */           continue;
/*      */         }
/*      */         
/* 2554 */         return i;
/* 2555 */       }  if (i != 32) {
/* 2556 */         if (i == 10) {
/* 2557 */           this._currInputRow++;
/* 2558 */           this._currInputRowStart = this._inputPtr; continue;
/* 2559 */         }  if (i == 13) {
/* 2560 */           _skipCR(); continue;
/* 2561 */         }  if (i != 9) {
/* 2562 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void _skipComment() throws IOException {
/* 2570 */     if ((this._features & FEAT_MASK_ALLOW_JAVA_COMMENTS) == 0) {
/* 2571 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/*      */     
/* 2574 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/* 2575 */       _reportInvalidEOF(" in a comment", null);
/*      */     }
/* 2577 */     char c = this._inputBuffer[this._inputPtr++];
/* 2578 */     if (c == '/') {
/* 2579 */       _skipLine();
/* 2580 */     } else if (c == '*') {
/* 2581 */       _skipCComment();
/*      */     } else {
/* 2583 */       _reportUnexpectedChar(c, "was expecting either '*' or '/' for a comment");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _skipCComment() throws IOException {
/* 2590 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 2591 */       int i = this._inputBuffer[this._inputPtr++];
/* 2592 */       if (i <= 42) {
/* 2593 */         if (i == 42) {
/* 2594 */           if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */             break;
/*      */           }
/* 2597 */           if (this._inputBuffer[this._inputPtr] == '/') {
/* 2598 */             this._inputPtr++;
/*      */             return;
/*      */           } 
/*      */           continue;
/*      */         } 
/* 2603 */         if (i < 32) {
/* 2604 */           if (i == 10) {
/* 2605 */             this._currInputRow++;
/* 2606 */             this._currInputRowStart = this._inputPtr; continue;
/* 2607 */           }  if (i == 13) {
/* 2608 */             _skipCR(); continue;
/* 2609 */           }  if (i != 9) {
/* 2610 */             _throwInvalidSpace(i);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 2615 */     _reportInvalidEOF(" in a comment", null);
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean _skipYAMLComment() throws IOException {
/* 2620 */     if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) == 0) {
/* 2621 */       return false;
/*      */     }
/* 2623 */     _skipLine();
/* 2624 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _skipLine() throws IOException {
/* 2630 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 2631 */       int i = this._inputBuffer[this._inputPtr++];
/* 2632 */       if (i < 32) {
/* 2633 */         if (i == 10) {
/* 2634 */           this._currInputRow++;
/* 2635 */           this._currInputRowStart = this._inputPtr; break;
/*      */         } 
/* 2637 */         if (i == 13) {
/* 2638 */           _skipCR(); break;
/*      */         } 
/* 2640 */         if (i != 9) {
/* 2641 */           _throwInvalidSpace(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/* 2650 */     if (this._inputPtr >= this._inputEnd && 
/* 2651 */       !_loadMore()) {
/* 2652 */       _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */     }
/*      */     
/* 2655 */     char c = this._inputBuffer[this._inputPtr++];
/*      */     
/* 2657 */     switch (c) {
/*      */       
/*      */       case 'b':
/* 2660 */         return '\b';
/*      */       case 't':
/* 2662 */         return '\t';
/*      */       case 'n':
/* 2664 */         return '\n';
/*      */       case 'f':
/* 2666 */         return '\f';
/*      */       case 'r':
/* 2668 */         return '\r';
/*      */ 
/*      */       
/*      */       case '"':
/*      */       case '/':
/*      */       case '\\':
/* 2674 */         return c;
/*      */       
/*      */       case 'u':
/*      */         break;
/*      */       
/*      */       default:
/* 2680 */         return _handleUnrecognizedCharacterEscape(c);
/*      */     } 
/*      */ 
/*      */     
/* 2684 */     int value = 0;
/* 2685 */     for (int i = 0; i < 4; i++) {
/* 2686 */       if (this._inputPtr >= this._inputEnd && 
/* 2687 */         !_loadMore()) {
/* 2688 */         _reportInvalidEOF(" in character escape sequence", JsonToken.VALUE_STRING);
/*      */       }
/*      */       
/* 2691 */       int ch = this._inputBuffer[this._inputPtr++];
/* 2692 */       int digit = CharTypes.charToHex(ch);
/* 2693 */       if (digit < 0) {
/* 2694 */         _reportUnexpectedChar(ch, "expected a hex-digit for character escape sequence");
/*      */       }
/* 2696 */       value = value << 4 | digit;
/*      */     } 
/* 2698 */     return (char)value;
/*      */   }
/*      */   
/*      */   private final void _matchTrue() throws IOException {
/* 2702 */     int ptr = this._inputPtr;
/* 2703 */     if (ptr + 3 < this._inputEnd) {
/* 2704 */       char[] b = this._inputBuffer;
/* 2705 */       if (b[ptr] == 'r' && b[++ptr] == 'u' && b[++ptr] == 'e') {
/* 2706 */         char c = b[++ptr];
/* 2707 */         if (c < '0' || c == ']' || c == '}') {
/* 2708 */           this._inputPtr = ptr;
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2714 */     _matchToken("true", 1);
/*      */   }
/*      */   
/*      */   private final void _matchFalse() throws IOException {
/* 2718 */     int ptr = this._inputPtr;
/* 2719 */     if (ptr + 4 < this._inputEnd) {
/* 2720 */       char[] b = this._inputBuffer;
/* 2721 */       if (b[ptr] == 'a' && b[++ptr] == 'l' && b[++ptr] == 's' && b[++ptr] == 'e') {
/* 2722 */         char c = b[++ptr];
/* 2723 */         if (c < '0' || c == ']' || c == '}') {
/* 2724 */           this._inputPtr = ptr;
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2730 */     _matchToken("false", 1);
/*      */   }
/*      */   
/*      */   private final void _matchNull() throws IOException {
/* 2734 */     int ptr = this._inputPtr;
/* 2735 */     if (ptr + 3 < this._inputEnd) {
/* 2736 */       char[] b = this._inputBuffer;
/* 2737 */       if (b[ptr] == 'u' && b[++ptr] == 'l' && b[++ptr] == 'l') {
/* 2738 */         char c = b[++ptr];
/* 2739 */         if (c < '0' || c == ']' || c == '}') {
/* 2740 */           this._inputPtr = ptr;
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2746 */     _matchToken("null", 1);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _matchToken(String matchStr, int i) throws IOException {
/* 2752 */     int len = matchStr.length();
/* 2753 */     if (this._inputPtr + len >= this._inputEnd) {
/* 2754 */       _matchToken2(matchStr, i);
/*      */       
/*      */       return;
/*      */     } 
/*      */     while (true) {
/* 2759 */       if (this._inputBuffer[this._inputPtr] != matchStr.charAt(i)) {
/* 2760 */         _reportInvalidToken(matchStr.substring(0, i));
/*      */       }
/* 2762 */       this._inputPtr++;
/* 2763 */       if (++i >= len) {
/* 2764 */         int ch = this._inputBuffer[this._inputPtr];
/* 2765 */         if (ch >= 48 && ch != 93 && ch != 125)
/* 2766 */           _checkMatchEnd(matchStr, i, ch); 
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   private final void _matchToken2(String matchStr, int i) throws IOException {
/* 2772 */     int len = matchStr.length();
/*      */     do {
/* 2774 */       if ((this._inputPtr >= this._inputEnd && !_loadMore()) || this._inputBuffer[this._inputPtr] != matchStr
/* 2775 */         .charAt(i)) {
/* 2776 */         _reportInvalidToken(matchStr.substring(0, i));
/*      */       }
/* 2778 */       this._inputPtr++;
/* 2779 */     } while (++i < len);
/*      */ 
/*      */     
/* 2782 */     if (this._inputPtr >= this._inputEnd && !_loadMore()) {
/*      */       return;
/*      */     }
/* 2785 */     int ch = this._inputBuffer[this._inputPtr];
/* 2786 */     if (ch >= 48 && ch != 93 && ch != 125) {
/* 2787 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _checkMatchEnd(String matchStr, int i, int c) throws IOException {
/* 2793 */     char ch = (char)c;
/* 2794 */     if (Character.isJavaIdentifierPart(ch)) {
/* 2795 */       _reportInvalidToken(matchStr.substring(0, i));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] _decodeBase64(Base64Variant b64variant) throws IOException {
/* 2819 */     ByteArrayBuilder builder = _getByteArrayBuilder();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2826 */       if (this._inputPtr >= this._inputEnd) {
/* 2827 */         _loadMoreGuaranteed();
/*      */       }
/* 2829 */       char ch = this._inputBuffer[this._inputPtr++];
/* 2830 */       if (ch > ' ') {
/* 2831 */         int bits = b64variant.decodeBase64Char(ch);
/* 2832 */         if (bits < 0) {
/* 2833 */           if (ch == '"') {
/* 2834 */             return builder.toByteArray();
/*      */           }
/* 2836 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/* 2837 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/* 2841 */         int decodedData = bits;
/*      */ 
/*      */ 
/*      */         
/* 2845 */         if (this._inputPtr >= this._inputEnd) {
/* 2846 */           _loadMoreGuaranteed();
/*      */         }
/* 2848 */         ch = this._inputBuffer[this._inputPtr++];
/* 2849 */         bits = b64variant.decodeBase64Char(ch);
/* 2850 */         if (bits < 0) {
/* 2851 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/* 2853 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/* 2856 */         if (this._inputPtr >= this._inputEnd) {
/* 2857 */           _loadMoreGuaranteed();
/*      */         }
/* 2859 */         ch = this._inputBuffer[this._inputPtr++];
/* 2860 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/* 2863 */         if (bits < 0) {
/* 2864 */           if (bits != -2) {
/*      */             
/* 2866 */             if (ch == '"') {
/* 2867 */               decodedData >>= 4;
/* 2868 */               builder.append(decodedData);
/* 2869 */               if (b64variant.requiresPaddingOnRead()) {
/* 2870 */                 this._inputPtr--;
/* 2871 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/* 2873 */               return builder.toByteArray();
/*      */             } 
/* 2875 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/* 2877 */           if (bits == -2) {
/*      */             
/* 2879 */             if (this._inputPtr >= this._inputEnd) {
/* 2880 */               _loadMoreGuaranteed();
/*      */             }
/* 2882 */             ch = this._inputBuffer[this._inputPtr++];
/* 2883 */             if (!b64variant.usesPaddingChar(ch) && 
/* 2884 */               _decodeBase64Escape(b64variant, ch, 3) != -2) {
/* 2885 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/* 2889 */             decodedData >>= 4;
/* 2890 */             builder.append(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*      */         
/* 2896 */         decodedData = decodedData << 6 | bits;
/*      */         
/* 2898 */         if (this._inputPtr >= this._inputEnd) {
/* 2899 */           _loadMoreGuaranteed();
/*      */         }
/* 2901 */         ch = this._inputBuffer[this._inputPtr++];
/* 2902 */         bits = b64variant.decodeBase64Char(ch);
/* 2903 */         if (bits < 0) {
/* 2904 */           if (bits != -2) {
/*      */             
/* 2906 */             if (ch == '"') {
/* 2907 */               decodedData >>= 2;
/* 2908 */               builder.appendTwoBytes(decodedData);
/* 2909 */               if (b64variant.requiresPaddingOnRead()) {
/* 2910 */                 this._inputPtr--;
/* 2911 */                 _handleBase64MissingPadding(b64variant);
/*      */               } 
/* 2913 */               return builder.toByteArray();
/*      */             } 
/* 2915 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/* 2917 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2923 */             decodedData >>= 2;
/* 2924 */             builder.appendTwoBytes(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*      */         
/* 2930 */         decodedData = decodedData << 6 | bits;
/* 2931 */         builder.appendThreeBytes(decodedData);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation currentLocation() {
/* 2943 */     int col = this._inputPtr - this._currInputRowStart + 1;
/* 2944 */     return new JsonLocation(_contentReference(), -1L, this._currInputProcessed + this._inputPtr, this._currInputRow, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonLocation _currentLocationMinusOne() {
/* 2951 */     int prevInputPtr = this._inputPtr - 1;
/* 2952 */     int col = prevInputPtr - this._currInputRowStart + 1;
/* 2953 */     return new JsonLocation(_contentReference(), -1L, this._currInputProcessed + prevInputPtr, this._currInputRow, col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation currentTokenLocation() {
/* 2961 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 2962 */       long total = this._currInputProcessed + this._nameStartOffset - 1L;
/* 2963 */       return new JsonLocation(_contentReference(), -1L, total, this._nameStartRow, this._nameStartCol);
/*      */     } 
/*      */     
/* 2966 */     return new JsonLocation(_contentReference(), -1L, this._tokenInputTotal - 1L, this._tokenInputRow, this._tokenInputCol);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _updateLocation() {
/* 2973 */     int ptr = this._inputPtr;
/* 2974 */     this._tokenInputTotal = this._currInputProcessed + ptr;
/* 2975 */     this._tokenInputRow = this._currInputRow;
/* 2976 */     this._tokenInputCol = ptr - this._currInputRowStart;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _updateNameLocation() {
/* 2982 */     int ptr = this._inputPtr;
/* 2983 */     this._nameStartOffset = ptr;
/* 2984 */     this._nameStartRow = this._currInputRow;
/* 2985 */     this._nameStartCol = ptr - this._currInputRowStart;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart) throws IOException {
/* 2995 */     _reportInvalidToken(matchedPart, _validJsonTokenList());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(String matchedPart, String msg) throws IOException {
/* 3004 */     StringBuilder sb = new StringBuilder(matchedPart);
/* 3005 */     while (this._inputPtr < this._inputEnd || _loadMore()) {
/* 3006 */       char c = this._inputBuffer[this._inputPtr];
/* 3007 */       if (!Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/* 3010 */       this._inputPtr++;
/* 3011 */       sb.append(c);
/* 3012 */       if (sb.length() >= this._ioContext.errorReportConfiguration().getMaxErrorTokenLength()) {
/* 3013 */         sb.append("...");
/*      */         break;
/*      */       } 
/*      */     } 
/* 3017 */     _reportError("Unrecognized token '%s': was expecting %s", sb, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _closeScope(int i) throws IOException {
/* 3028 */     if (i == 93) {
/* 3029 */       _updateLocation();
/* 3030 */       if (!this._parsingContext.inArray()) {
/* 3031 */         _reportMismatchedEndMarker(i, '}');
/*      */       }
/* 3033 */       this._parsingContext = this._parsingContext.clearAndGetParent();
/* 3034 */       _updateToken(JsonToken.END_ARRAY);
/*      */     } 
/* 3036 */     if (i == 125) {
/* 3037 */       _updateLocation();
/* 3038 */       if (!this._parsingContext.inObject()) {
/* 3039 */         _reportMismatchedEndMarker(i, ']');
/*      */       }
/* 3041 */       this._parsingContext = this._parsingContext.clearAndGetParent();
/* 3042 */       _updateToken(JsonToken.END_OBJECT);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\json\ReaderBasedJsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */