/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.exc.StreamConstraintsException;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*      */ import java.io.DataInput;
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Writer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class UTF8DataInputJsonParser
/*      */   extends JsonParserBase
/*      */ {
/*      */   protected final ByteQuadsCanonicalizer _symbols;
/*   60 */   protected int[] _quadBuffer = new int[16];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _tokenIncomplete;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _quad1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DataInput _inputData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   86 */   protected int _nextByte = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UTF8DataInputJsonParser(IOContext ctxt, int features, DataInput inputData, ObjectCodec codec, ByteQuadsCanonicalizer sym, int firstByte) {
/*   98 */     super(ctxt, features, codec);
/*   99 */     this._symbols = sym;
/*  100 */     this._inputData = inputData;
/*  101 */     this._nextByte = firstByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int releaseBuffered(OutputStream out) throws IOException {
/*  112 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getInputSource() {
/*  117 */     return this._inputData;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _closeInput() throws IOException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() throws IOException {
/*  138 */     super._releaseBuffers();
/*      */     
/*  140 */     this._symbols.release();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getText() throws IOException {
/*  152 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  153 */       if (this._tokenIncomplete) {
/*  154 */         this._tokenIncomplete = false;
/*  155 */         return _finishAndReturnString();
/*      */       } 
/*  157 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  159 */     return _getText2(this._currToken);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getText(Writer writer) throws IOException {
/*  165 */     JsonToken t = this._currToken;
/*  166 */     if (t == JsonToken.VALUE_STRING) {
/*  167 */       if (this._tokenIncomplete) {
/*  168 */         this._tokenIncomplete = false;
/*  169 */         _finishString();
/*      */       } 
/*  171 */       return this._textBuffer.contentsToWriter(writer);
/*      */     } 
/*  173 */     if (t == JsonToken.FIELD_NAME) {
/*  174 */       String n = this._parsingContext.getCurrentName();
/*  175 */       writer.write(n);
/*  176 */       return n.length();
/*      */     } 
/*  178 */     if (t != null) {
/*  179 */       if (t.isNumeric()) {
/*  180 */         return this._textBuffer.contentsToWriter(writer);
/*      */       }
/*  182 */       char[] ch = t.asCharArray();
/*  183 */       writer.write(ch);
/*  184 */       return ch.length;
/*      */     } 
/*  186 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString() throws IOException {
/*  193 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  194 */       if (this._tokenIncomplete) {
/*  195 */         this._tokenIncomplete = false;
/*  196 */         return _finishAndReturnString();
/*      */       } 
/*  198 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  200 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  201 */       return currentName();
/*      */     }
/*  203 */     return super.getValueAsString(null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getValueAsString(String defValue) throws IOException {
/*  209 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  210 */       if (this._tokenIncomplete) {
/*  211 */         this._tokenIncomplete = false;
/*  212 */         return _finishAndReturnString();
/*      */       } 
/*  214 */       return this._textBuffer.contentsAsString();
/*      */     } 
/*  216 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  217 */       return currentName();
/*      */     }
/*  219 */     return super.getValueAsString(defValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt() throws IOException {
/*  225 */     JsonToken t = this._currToken;
/*  226 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */       
/*  228 */       if ((this._numTypesValid & 0x1) == 0) {
/*  229 */         if (this._numTypesValid == 0) {
/*  230 */           return _parseIntValue();
/*      */         }
/*  232 */         if ((this._numTypesValid & 0x1) == 0) {
/*  233 */           convertNumberToInt();
/*      */         }
/*      */       } 
/*  236 */       return this._numberInt;
/*      */     } 
/*  238 */     return super.getValueAsInt(0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt(int defValue) throws IOException {
/*  244 */     JsonToken t = this._currToken;
/*  245 */     if (t == JsonToken.VALUE_NUMBER_INT || t == JsonToken.VALUE_NUMBER_FLOAT) {
/*      */       
/*  247 */       if ((this._numTypesValid & 0x1) == 0) {
/*  248 */         if (this._numTypesValid == 0) {
/*  249 */           return _parseIntValue();
/*      */         }
/*  251 */         if ((this._numTypesValid & 0x1) == 0) {
/*  252 */           convertNumberToInt();
/*      */         }
/*      */       } 
/*  255 */       return this._numberInt;
/*      */     } 
/*  257 */     return super.getValueAsInt(defValue);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final String _getText2(JsonToken t) throws IOException {
/*  262 */     if (t == null) {
/*  263 */       return null;
/*      */     }
/*  265 */     switch (t.id()) {
/*      */       case 5:
/*  267 */         return this._parsingContext.getCurrentName();
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  273 */         return this._textBuffer.contentsAsString();
/*      */     } 
/*  275 */     return t.asString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getTextCharacters() throws IOException {
/*  282 */     if (this._currToken != null) {
/*  283 */       switch (this._currToken.id()) {
/*      */         
/*      */         case 5:
/*  286 */           if (!this._nameCopied) {
/*  287 */             String name = this._parsingContext.getCurrentName();
/*  288 */             int nameLen = name.length();
/*  289 */             if (this._nameCopyBuffer == null) {
/*  290 */               this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/*  291 */             } else if (this._nameCopyBuffer.length < nameLen) {
/*  292 */               this._nameCopyBuffer = new char[nameLen];
/*      */             } 
/*  294 */             name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/*  295 */             this._nameCopied = true;
/*      */           } 
/*  297 */           return this._nameCopyBuffer;
/*      */         
/*      */         case 6:
/*  300 */           if (this._tokenIncomplete) {
/*  301 */             this._tokenIncomplete = false;
/*  302 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  307 */           return this._textBuffer.getTextBuffer();
/*      */       } 
/*      */       
/*  310 */       return this._currToken.asCharArray();
/*      */     } 
/*      */     
/*  313 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextLength() throws IOException {
/*  319 */     if (this._currToken == JsonToken.VALUE_STRING) {
/*  320 */       if (this._tokenIncomplete) {
/*  321 */         this._tokenIncomplete = false;
/*  322 */         _finishString();
/*      */       } 
/*  324 */       return this._textBuffer.size();
/*      */     } 
/*  326 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  327 */       return this._parsingContext.getCurrentName().length();
/*      */     }
/*  329 */     if (this._currToken != null) {
/*  330 */       if (this._currToken.isNumeric()) {
/*  331 */         return this._textBuffer.size();
/*      */       }
/*  333 */       return (this._currToken.asCharArray()).length;
/*      */     } 
/*  335 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTextOffset() throws IOException {
/*  342 */     if (this._currToken != null) {
/*  343 */       switch (this._currToken.id()) {
/*      */         case 5:
/*  345 */           return 0;
/*      */         case 6:
/*  347 */           if (this._tokenIncomplete) {
/*  348 */             this._tokenIncomplete = false;
/*  349 */             _finishString();
/*      */           } 
/*      */         
/*      */         case 7:
/*      */         case 8:
/*  354 */           return this._textBuffer.getTextOffset();
/*      */       } 
/*      */     
/*      */     }
/*  358 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBinaryValue(Base64Variant b64variant) throws IOException {
/*  364 */     if (this._currToken != JsonToken.VALUE_STRING && (this._currToken != JsonToken.VALUE_EMBEDDED_OBJECT || this._binaryValue == null))
/*      */     {
/*  366 */       _reportError("Current token (" + this._currToken + ") not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  371 */     if (this._tokenIncomplete) {
/*      */       try {
/*  373 */         this._binaryValue = _decodeBase64(b64variant);
/*  374 */       } catch (IllegalArgumentException iae) {
/*  375 */         throw _constructError("Failed to decode VALUE_STRING as base64 (" + b64variant + "): " + iae.getMessage());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  380 */       this._tokenIncomplete = false;
/*      */     }
/*  382 */     else if (this._binaryValue == null) {
/*      */       
/*  384 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/*  385 */       _decodeBase64(getText(), builder, b64variant);
/*  386 */       this._binaryValue = builder.toByteArray();
/*      */     } 
/*      */     
/*  389 */     return this._binaryValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/*  396 */     if (!this._tokenIncomplete || this._currToken != JsonToken.VALUE_STRING) {
/*  397 */       byte[] b = getBinaryValue(b64variant);
/*  398 */       out.write(b);
/*  399 */       return b.length;
/*      */     } 
/*      */     
/*  402 */     byte[] buf = this._ioContext.allocBase64Buffer();
/*      */     try {
/*  404 */       return _readBinary(b64variant, out, buf);
/*      */     } finally {
/*  406 */       this._ioContext.releaseBase64Buffer(buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _readBinary(Base64Variant b64variant, OutputStream out, byte[] buffer) throws IOException {
/*  413 */     int outputPtr = 0;
/*  414 */     int outputEnd = buffer.length - 3;
/*  415 */     int outputCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  421 */       int ch = this._inputData.readUnsignedByte();
/*  422 */       if (ch > 32) {
/*  423 */         int bits = b64variant.decodeBase64Char(ch);
/*  424 */         if (bits < 0) {
/*  425 */           if (ch == 34) {
/*      */             break;
/*      */           }
/*  428 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/*  429 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  435 */         if (outputPtr > outputEnd) {
/*  436 */           outputCount += outputPtr;
/*  437 */           out.write(buffer, 0, outputPtr);
/*  438 */           outputPtr = 0;
/*      */         } 
/*      */         
/*  441 */         int decodedData = bits;
/*      */ 
/*      */         
/*  444 */         ch = this._inputData.readUnsignedByte();
/*  445 */         bits = b64variant.decodeBase64Char(ch);
/*  446 */         if (bits < 0) {
/*  447 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/*  449 */         decodedData = decodedData << 6 | bits;
/*      */ 
/*      */         
/*  452 */         ch = this._inputData.readUnsignedByte();
/*  453 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/*  456 */         if (bits < 0) {
/*  457 */           if (bits != -2) {
/*      */             
/*  459 */             if (ch == 34) {
/*  460 */               decodedData >>= 4;
/*  461 */               buffer[outputPtr++] = (byte)decodedData;
/*  462 */               if (b64variant.requiresPaddingOnRead()) {
/*  463 */                 _handleBase64MissingPadding(b64variant);
/*      */               }
/*      */               break;
/*      */             } 
/*  467 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/*  469 */           if (bits == -2) {
/*      */             
/*  471 */             ch = this._inputData.readUnsignedByte();
/*  472 */             if (!b64variant.usesPaddingChar(ch) && (
/*  473 */               ch != 92 || 
/*  474 */               _decodeBase64Escape(b64variant, ch, 3) != -2)) {
/*  475 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/*  479 */             decodedData >>= 4;
/*  480 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  485 */         decodedData = decodedData << 6 | bits;
/*      */         
/*  487 */         ch = this._inputData.readUnsignedByte();
/*  488 */         bits = b64variant.decodeBase64Char(ch);
/*  489 */         if (bits < 0) {
/*  490 */           if (bits != -2) {
/*      */             
/*  492 */             if (ch == 34) {
/*  493 */               decodedData >>= 2;
/*  494 */               buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  495 */               buffer[outputPtr++] = (byte)decodedData;
/*  496 */               if (b64variant.requiresPaddingOnRead()) {
/*  497 */                 _handleBase64MissingPadding(b64variant);
/*      */               }
/*      */               break;
/*      */             } 
/*  501 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/*  503 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  510 */             decodedData >>= 2;
/*  511 */             buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  512 */             buffer[outputPtr++] = (byte)decodedData;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*  517 */         decodedData = decodedData << 6 | bits;
/*  518 */         buffer[outputPtr++] = (byte)(decodedData >> 16);
/*  519 */         buffer[outputPtr++] = (byte)(decodedData >> 8);
/*  520 */         buffer[outputPtr++] = (byte)decodedData;
/*      */       } 
/*  522 */     }  this._tokenIncomplete = false;
/*  523 */     if (outputPtr > 0) {
/*  524 */       outputCount += outputPtr;
/*  525 */       out.write(buffer, 0, outputPtr);
/*      */     } 
/*  527 */     return outputCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken nextToken() throws IOException {
/*  543 */     if (this._closed) {
/*  544 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  550 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  551 */       return _nextAfterName();
/*      */     }
/*      */ 
/*      */     
/*  555 */     this._numTypesValid = 0;
/*  556 */     if (this._tokenIncomplete) {
/*  557 */       _skipString();
/*      */     }
/*  559 */     int i = _skipWSOrEnd();
/*  560 */     if (i < 0) {
/*      */       
/*  562 */       close();
/*  563 */       return _updateTokenToNull();
/*      */     } 
/*      */     
/*  566 */     this._binaryValue = null;
/*  567 */     this._tokenInputRow = this._currInputRow;
/*      */ 
/*      */     
/*  570 */     if ((i | 0x20) == 125) {
/*  571 */       _closeScope(i);
/*  572 */       return this._currToken;
/*      */     } 
/*      */ 
/*      */     
/*  576 */     if (this._parsingContext.expectComma()) {
/*  577 */       if (i != 44) {
/*  578 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  580 */       i = _skipWS();
/*      */ 
/*      */       
/*  583 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  584 */         i | 0x20) == 125) {
/*  585 */         _closeScope(i);
/*  586 */         return this._currToken;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  595 */     if (!this._parsingContext.inObject()) {
/*  596 */       return _nextTokenNotInObject(i);
/*      */     }
/*      */     
/*  599 */     String n = _parseName(i);
/*  600 */     this._parsingContext.setCurrentName(n);
/*  601 */     _updateToken(JsonToken.FIELD_NAME);
/*      */     
/*  603 */     i = _skipColon();
/*      */ 
/*      */     
/*  606 */     if (i == 34) {
/*  607 */       this._tokenIncomplete = true;
/*  608 */       this._nextToken = JsonToken.VALUE_STRING;
/*  609 */       return this._currToken;
/*      */     } 
/*      */ 
/*      */     
/*  613 */     switch (i)
/*      */     { case 45:
/*  615 */         t = _parseNegNumber();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  661 */         this._nextToken = t;
/*  662 */         return this._currToken;case 43: if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) { t = _parsePosNumber(); } else { t = _handleUnexpectedValue(i); }  this._nextToken = t; return this._currToken;case 46: t = _parseFloatThatStartsWithPeriod(false, false); this._nextToken = t; return this._currToken;case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parseUnsignedNumber(i); this._nextToken = t; return this._currToken;case 102: _matchToken("false", 1); t = JsonToken.VALUE_FALSE; this._nextToken = t; return this._currToken;case 110: _matchToken("null", 1); t = JsonToken.VALUE_NULL; this._nextToken = t; return this._currToken;case 116: _matchToken("true", 1); t = JsonToken.VALUE_TRUE; this._nextToken = t; return this._currToken;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return this._currToken;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return this._currToken; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return this._currToken;
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextTokenNotInObject(int i) throws IOException {
/*  667 */     if (i == 34) {
/*  668 */       this._tokenIncomplete = true;
/*  669 */       return _updateToken(JsonToken.VALUE_STRING);
/*      */     } 
/*  671 */     switch (i) {
/*      */       case 91:
/*  673 */         createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  674 */         return _updateToken(JsonToken.START_ARRAY);
/*      */       case 123:
/*  676 */         createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*  677 */         return _updateToken(JsonToken.START_OBJECT);
/*      */       case 116:
/*  679 */         _matchToken("true", 1);
/*  680 */         return _updateToken(JsonToken.VALUE_TRUE);
/*      */       case 102:
/*  682 */         _matchToken("false", 1);
/*  683 */         return _updateToken(JsonToken.VALUE_FALSE);
/*      */       case 110:
/*  685 */         _matchToken("null", 1);
/*  686 */         return _updateToken(JsonToken.VALUE_NULL);
/*      */       case 45:
/*  688 */         return _updateToken(_parseNegNumber());
/*      */       case 43:
/*  690 */         if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/*  691 */           return _updateToken(_parsePosNumber());
/*      */         }
/*  693 */         return _updateToken(_handleUnexpectedValue(i));
/*      */       case 46:
/*  695 */         return _updateToken(_parseFloatThatStartsWithPeriod(false, false));
/*      */       case 48:
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  706 */         return _updateToken(_parseUnsignedNumber(i));
/*      */     } 
/*  708 */     return _updateToken(_handleUnexpectedValue(i));
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _nextAfterName() throws IOException {
/*  713 */     this._nameCopied = false;
/*  714 */     JsonToken t = this._nextToken;
/*  715 */     this._nextToken = null;
/*      */ 
/*      */     
/*  718 */     if (t == JsonToken.START_ARRAY) {
/*  719 */       createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  720 */     } else if (t == JsonToken.START_OBJECT) {
/*  721 */       createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */     } 
/*  723 */     return _updateToken(t);
/*      */   }
/*      */ 
/*      */   
/*      */   public void finishToken() throws IOException {
/*  728 */     if (this._tokenIncomplete) {
/*  729 */       this._tokenIncomplete = false;
/*  730 */       _finishString();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextFieldName() throws IOException {
/*  748 */     this._numTypesValid = 0;
/*  749 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  750 */       _nextAfterName();
/*  751 */       return null;
/*      */     } 
/*  753 */     if (this._tokenIncomplete) {
/*  754 */       _skipString();
/*      */     }
/*  756 */     int i = _skipWS();
/*  757 */     this._binaryValue = null;
/*  758 */     this._tokenInputRow = this._currInputRow;
/*      */     
/*  760 */     if ((i | 0x20) == 125) {
/*  761 */       _closeScope(i);
/*  762 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  766 */     if (this._parsingContext.expectComma()) {
/*  767 */       if (i != 44) {
/*  768 */         _reportUnexpectedChar(i, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */       }
/*  770 */       i = _skipWS();
/*      */ 
/*      */       
/*  773 */       if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0 && (
/*  774 */         i | 0x20) == 125) {
/*  775 */         _closeScope(i);
/*  776 */         return null;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  781 */     if (!this._parsingContext.inObject()) {
/*  782 */       _nextTokenNotInObject(i);
/*  783 */       return null;
/*      */     } 
/*      */     
/*  786 */     String nameStr = _parseName(i);
/*  787 */     this._parsingContext.setCurrentName(nameStr);
/*  788 */     _updateToken(JsonToken.FIELD_NAME);
/*      */     
/*  790 */     i = _skipColon();
/*  791 */     if (i == 34) {
/*  792 */       this._tokenIncomplete = true;
/*  793 */       this._nextToken = JsonToken.VALUE_STRING;
/*  794 */       return nameStr;
/*      */     } 
/*      */     
/*  797 */     switch (i)
/*      */     { case 45:
/*  799 */         t = _parseNegNumber();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  844 */         this._nextToken = t;
/*  845 */         return nameStr;case 43: if (isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) { t = _parsePosNumber(); } else { t = _handleUnexpectedValue(i); }  this._nextToken = t; return nameStr;case 46: t = _parseFloatThatStartsWithPeriod(false, false);case 48: case 49: case 50: case 51: case 52: case 53: case 54: case 55: case 56: case 57: t = _parseUnsignedNumber(i); this._nextToken = t; return nameStr;case 102: _matchToken("false", 1); t = JsonToken.VALUE_FALSE; this._nextToken = t; return nameStr;case 110: _matchToken("null", 1); t = JsonToken.VALUE_NULL; this._nextToken = t; return nameStr;case 116: _matchToken("true", 1); t = JsonToken.VALUE_TRUE; this._nextToken = t; return nameStr;case 91: t = JsonToken.START_ARRAY; this._nextToken = t; return nameStr;case 123: t = JsonToken.START_OBJECT; this._nextToken = t; return nameStr; }  JsonToken t = _handleUnexpectedValue(i); this._nextToken = t; return nameStr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextTextValue() throws IOException {
/*  852 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  853 */       this._nameCopied = false;
/*  854 */       JsonToken t = this._nextToken;
/*  855 */       this._nextToken = null;
/*  856 */       _updateToken(t);
/*  857 */       if (t == JsonToken.VALUE_STRING) {
/*  858 */         if (this._tokenIncomplete) {
/*  859 */           this._tokenIncomplete = false;
/*  860 */           return _finishAndReturnString();
/*      */         } 
/*  862 */         return this._textBuffer.contentsAsString();
/*      */       } 
/*  864 */       if (t == JsonToken.START_ARRAY) {
/*  865 */         createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  866 */       } else if (t == JsonToken.START_OBJECT) {
/*  867 */         createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/*  869 */       return null;
/*      */     } 
/*  871 */     return (nextToken() == JsonToken.VALUE_STRING) ? getText() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int nextIntValue(int defaultValue) throws IOException {
/*  878 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  879 */       this._nameCopied = false;
/*  880 */       JsonToken t = this._nextToken;
/*  881 */       this._nextToken = null;
/*  882 */       _updateToken(t);
/*  883 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/*  884 */         return getIntValue();
/*      */       }
/*  886 */       if (t == JsonToken.START_ARRAY) {
/*  887 */         createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  888 */       } else if (t == JsonToken.START_OBJECT) {
/*  889 */         createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/*  891 */       return defaultValue;
/*      */     } 
/*  893 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getIntValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long nextLongValue(long defaultValue) throws IOException {
/*  900 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  901 */       this._nameCopied = false;
/*  902 */       JsonToken t = this._nextToken;
/*  903 */       this._nextToken = null;
/*  904 */       _updateToken(t);
/*  905 */       if (t == JsonToken.VALUE_NUMBER_INT) {
/*  906 */         return getLongValue();
/*      */       }
/*  908 */       if (t == JsonToken.START_ARRAY) {
/*  909 */         createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  910 */       } else if (t == JsonToken.START_OBJECT) {
/*  911 */         createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/*  913 */       return defaultValue;
/*      */     } 
/*  915 */     return (nextToken() == JsonToken.VALUE_NUMBER_INT) ? getLongValue() : defaultValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Boolean nextBooleanValue() throws IOException {
/*  922 */     if (this._currToken == JsonToken.FIELD_NAME) {
/*  923 */       this._nameCopied = false;
/*  924 */       JsonToken jsonToken = this._nextToken;
/*  925 */       this._nextToken = null;
/*  926 */       _updateToken(jsonToken);
/*  927 */       if (jsonToken == JsonToken.VALUE_TRUE) {
/*  928 */         return Boolean.TRUE;
/*      */       }
/*  930 */       if (jsonToken == JsonToken.VALUE_FALSE) {
/*  931 */         return Boolean.FALSE;
/*      */       }
/*  933 */       if (jsonToken == JsonToken.START_ARRAY) {
/*  934 */         createChildArrayContext(this._tokenInputRow, this._tokenInputCol);
/*  935 */       } else if (jsonToken == JsonToken.START_OBJECT) {
/*  936 */         createChildObjectContext(this._tokenInputRow, this._tokenInputCol);
/*      */       } 
/*  938 */       return null;
/*      */     } 
/*      */     
/*  941 */     JsonToken t = nextToken();
/*  942 */     if (t == JsonToken.VALUE_TRUE) {
/*  943 */       return Boolean.TRUE;
/*      */     }
/*  945 */     if (t == JsonToken.VALUE_FALSE) {
/*  946 */       return Boolean.FALSE;
/*      */     }
/*  948 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod() throws IOException {
/*  959 */     return _parseFloatThatStartsWithPeriod(false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _parseFloatThatStartsWithPeriod(boolean neg, boolean hasSign) throws IOException {
/*  967 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/*  968 */       return _handleUnexpectedValue(46);
/*      */     }
/*  970 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*  971 */     int outPtr = 0;
/*      */     
/*  973 */     if (neg) {
/*  974 */       outBuf[outPtr++] = '-';
/*      */     }
/*  976 */     return _parseFloat(outBuf, outPtr, 46, neg, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _parseUnsignedNumber(int c) throws IOException {
/*      */     int outPtr;
/* 1004 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1009 */     if (c == 48) {
/* 1010 */       c = _handleLeadingZeroes();
/* 1011 */       if (c <= 57 && c >= 48)
/* 1012 */       { outPtr = 0; }
/* 1013 */       else { if (c == 120 || c == 88) {
/* 1014 */           return _handleInvalidNumberStart(c, false);
/*      */         }
/* 1016 */         outBuf[0] = '0';
/* 1017 */         outPtr = 1; }
/*      */     
/*      */     } else {
/* 1020 */       outBuf[0] = (char)c;
/* 1021 */       c = this._inputData.readUnsignedByte();
/* 1022 */       outPtr = 1;
/*      */     } 
/* 1024 */     int intLen = outPtr;
/*      */ 
/*      */     
/* 1027 */     while (c <= 57 && c >= 48) {
/* 1028 */       intLen++;
/* 1029 */       if (outPtr >= outBuf.length) {
/* 1030 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1031 */         outPtr = 0;
/*      */       } 
/* 1033 */       outBuf[outPtr++] = (char)c;
/* 1034 */       c = this._inputData.readUnsignedByte();
/*      */     } 
/* 1036 */     if (c == 46 || (c | 0x20) == 101) {
/* 1037 */       return _parseFloat(outBuf, outPtr, c, false, intLen);
/*      */     }
/* 1039 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1041 */     this._nextByte = c;
/* 1042 */     if (this._parsingContext.inRoot()) {
/* 1043 */       _verifyRootSpace();
/*      */     }
/*      */     
/* 1046 */     return resetInt(false, intLen);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final JsonToken _parsePosNumber() throws IOException {
/* 1051 */     return _parseSignedNumber(false);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final JsonToken _parseNegNumber() throws IOException {
/* 1056 */     return _parseSignedNumber(true);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _parseSignedNumber(boolean negative) throws IOException {
/* 1061 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1062 */     int outPtr = 0;
/*      */     
/* 1064 */     if (negative)
/*      */     {
/* 1066 */       outBuf[outPtr++] = '-';
/*      */     }
/* 1068 */     int c = this._inputData.readUnsignedByte();
/* 1069 */     outBuf[outPtr++] = (char)c;
/*      */     
/* 1071 */     if (c <= 48) {
/*      */       
/* 1073 */       if (c == 48)
/* 1074 */       { c = _handleLeadingZeroes(); }
/* 1075 */       else { if (c == 46) {
/* 1076 */           return _parseFloatThatStartsWithPeriod(negative, true);
/*      */         }
/* 1078 */         return _handleInvalidNumberStart(c, negative, true); }
/*      */     
/*      */     } else {
/* 1081 */       if (c > 57) {
/* 1082 */         return _handleInvalidNumberStart(c, negative, true);
/*      */       }
/* 1084 */       c = this._inputData.readUnsignedByte();
/*      */     } 
/*      */     
/* 1087 */     int intLen = 1;
/*      */ 
/*      */     
/* 1090 */     while (c <= 57 && c >= 48) {
/* 1091 */       intLen++;
/* 1092 */       if (outPtr >= outBuf.length) {
/* 1093 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1094 */         outPtr = 0;
/*      */       } 
/* 1096 */       outBuf[outPtr++] = (char)c;
/* 1097 */       c = this._inputData.readUnsignedByte();
/*      */     } 
/* 1099 */     if (c == 46 || (c | 0x20) == 101) {
/* 1100 */       return _parseFloat(outBuf, outPtr, c, negative, intLen);
/*      */     }
/* 1102 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1104 */     this._nextByte = c;
/* 1105 */     if (this._parsingContext.inRoot()) {
/* 1106 */       _verifyRootSpace();
/*      */     }
/*      */     
/* 1109 */     return resetInt(negative, intLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _handleLeadingZeroes() throws IOException {
/* 1124 */     int ch = this._inputData.readUnsignedByte();
/*      */     
/* 1126 */     if (ch < 48 || ch > 57) {
/* 1127 */       return ch;
/*      */     }
/*      */     
/* 1130 */     if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1131 */       reportInvalidNumber("Leading zeroes not allowed");
/*      */     }
/*      */     
/* 1134 */     while (ch == 48) {
/* 1135 */       ch = this._inputData.readUnsignedByte();
/*      */     }
/* 1137 */     return ch;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseFloat(char[] outBuf, int outPtr, int c, boolean negative, int integerPartLength) throws IOException {
/* 1143 */     int fractLen = 0;
/*      */ 
/*      */     
/* 1146 */     if (c == 46) {
/*      */       
/* 1148 */       if (outPtr >= outBuf.length) {
/* 1149 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1150 */         outPtr = 0;
/*      */       } 
/* 1152 */       outBuf[outPtr++] = (char)c;
/*      */ 
/*      */       
/*      */       while (true) {
/* 1156 */         c = this._inputData.readUnsignedByte();
/* 1157 */         if (c < 48 || c > 57) {
/*      */           break;
/*      */         }
/* 1160 */         fractLen++;
/* 1161 */         if (outPtr >= outBuf.length) {
/* 1162 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1163 */           outPtr = 0;
/*      */         } 
/* 1165 */         outBuf[outPtr++] = (char)c;
/*      */       } 
/*      */       
/* 1168 */       if (fractLen == 0 && 
/* 1169 */         !isEnabled(JsonReadFeature.ALLOW_TRAILING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1170 */         _reportUnexpectedNumberChar(c, "Decimal point not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1175 */     int expLen = 0;
/* 1176 */     if ((c | 0x20) == 101) {
/* 1177 */       if (outPtr >= outBuf.length) {
/* 1178 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 1179 */         outPtr = 0;
/*      */       } 
/* 1181 */       outBuf[outPtr++] = (char)c;
/* 1182 */       c = this._inputData.readUnsignedByte();
/*      */       
/* 1184 */       if (c == 45 || c == 43) {
/* 1185 */         if (outPtr >= outBuf.length) {
/* 1186 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1187 */           outPtr = 0;
/*      */         } 
/* 1189 */         outBuf[outPtr++] = (char)c;
/* 1190 */         c = this._inputData.readUnsignedByte();
/*      */       } 
/* 1192 */       while (c <= 57 && c >= 48) {
/* 1193 */         expLen++;
/* 1194 */         if (outPtr >= outBuf.length) {
/* 1195 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1196 */           outPtr = 0;
/*      */         } 
/* 1198 */         outBuf[outPtr++] = (char)c;
/* 1199 */         c = this._inputData.readUnsignedByte();
/*      */       } 
/*      */       
/* 1202 */       if (expLen == 0) {
/* 1203 */         _reportUnexpectedNumberChar(c, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1209 */     this._nextByte = c;
/* 1210 */     if (this._parsingContext.inRoot()) {
/* 1211 */       _verifyRootSpace();
/*      */     }
/* 1213 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/*      */     
/* 1216 */     return resetFloat(negative, integerPartLength, fractLen, expLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _verifyRootSpace() throws IOException {
/* 1229 */     int ch = this._nextByte;
/* 1230 */     if (ch <= 32) {
/* 1231 */       this._nextByte = -1;
/* 1232 */       if (ch == 13 || ch == 10) {
/* 1233 */         this._currInputRow++;
/*      */       }
/*      */       return;
/*      */     } 
/* 1237 */     _reportMissingRootWS(ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String _parseName(int i) throws IOException {
/* 1248 */     if (i != 34) {
/* 1249 */       return _handleOddName(i);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1257 */     int[] codes = INPUT_CODES_LATIN1;
/*      */     
/* 1259 */     int q = this._inputData.readUnsignedByte();
/*      */     
/* 1261 */     if (codes[q] == 0) {
/* 1262 */       i = this._inputData.readUnsignedByte();
/* 1263 */       if (codes[i] == 0) {
/* 1264 */         q = q << 8 | i;
/* 1265 */         i = this._inputData.readUnsignedByte();
/* 1266 */         if (codes[i] == 0) {
/* 1267 */           q = q << 8 | i;
/* 1268 */           i = this._inputData.readUnsignedByte();
/* 1269 */           if (codes[i] == 0) {
/* 1270 */             q = q << 8 | i;
/* 1271 */             i = this._inputData.readUnsignedByte();
/* 1272 */             if (codes[i] == 0) {
/* 1273 */               this._quad1 = q;
/* 1274 */               return _parseMediumName(i);
/*      */             } 
/* 1276 */             if (i == 34) {
/* 1277 */               return findName(q, 4);
/*      */             }
/* 1279 */             return parseName(q, i, 4);
/*      */           } 
/* 1281 */           if (i == 34) {
/* 1282 */             return findName(q, 3);
/*      */           }
/* 1284 */           return parseName(q, i, 3);
/*      */         } 
/* 1286 */         if (i == 34) {
/* 1287 */           return findName(q, 2);
/*      */         }
/* 1289 */         return parseName(q, i, 2);
/*      */       } 
/* 1291 */       if (i == 34) {
/* 1292 */         return findName(q, 1);
/*      */       }
/* 1294 */       return parseName(q, i, 1);
/*      */     } 
/* 1296 */     if (q == 34) {
/* 1297 */       return "";
/*      */     }
/* 1299 */     return parseName(0, q, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseMediumName(int q2) throws IOException {
/* 1304 */     int[] codes = INPUT_CODES_LATIN1;
/*      */ 
/*      */     
/* 1307 */     int i = this._inputData.readUnsignedByte();
/* 1308 */     if (codes[i] != 0) {
/* 1309 */       if (i == 34) {
/* 1310 */         return findName(this._quad1, q2, 1);
/*      */       }
/* 1312 */       return parseName(this._quad1, q2, i, 1);
/*      */     } 
/* 1314 */     q2 = q2 << 8 | i;
/* 1315 */     i = this._inputData.readUnsignedByte();
/* 1316 */     if (codes[i] != 0) {
/* 1317 */       if (i == 34) {
/* 1318 */         return findName(this._quad1, q2, 2);
/*      */       }
/* 1320 */       return parseName(this._quad1, q2, i, 2);
/*      */     } 
/* 1322 */     q2 = q2 << 8 | i;
/* 1323 */     i = this._inputData.readUnsignedByte();
/* 1324 */     if (codes[i] != 0) {
/* 1325 */       if (i == 34) {
/* 1326 */         return findName(this._quad1, q2, 3);
/*      */       }
/* 1328 */       return parseName(this._quad1, q2, i, 3);
/*      */     } 
/* 1330 */     q2 = q2 << 8 | i;
/* 1331 */     i = this._inputData.readUnsignedByte();
/* 1332 */     if (codes[i] != 0) {
/* 1333 */       if (i == 34) {
/* 1334 */         return findName(this._quad1, q2, 4);
/*      */       }
/* 1336 */       return parseName(this._quad1, q2, i, 4);
/*      */     } 
/* 1338 */     return _parseMediumName2(i, q2);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseMediumName2(int q3, int q2) throws IOException {
/* 1343 */     int[] codes = INPUT_CODES_LATIN1;
/*      */ 
/*      */     
/* 1346 */     int i = this._inputData.readUnsignedByte();
/* 1347 */     if (codes[i] != 0) {
/* 1348 */       if (i == 34) {
/* 1349 */         return findName(this._quad1, q2, q3, 1);
/*      */       }
/* 1351 */       return parseName(this._quad1, q2, q3, i, 1);
/*      */     } 
/* 1353 */     q3 = q3 << 8 | i;
/* 1354 */     i = this._inputData.readUnsignedByte();
/* 1355 */     if (codes[i] != 0) {
/* 1356 */       if (i == 34) {
/* 1357 */         return findName(this._quad1, q2, q3, 2);
/*      */       }
/* 1359 */       return parseName(this._quad1, q2, q3, i, 2);
/*      */     } 
/* 1361 */     q3 = q3 << 8 | i;
/* 1362 */     i = this._inputData.readUnsignedByte();
/* 1363 */     if (codes[i] != 0) {
/* 1364 */       if (i == 34) {
/* 1365 */         return findName(this._quad1, q2, q3, 3);
/*      */       }
/* 1367 */       return parseName(this._quad1, q2, q3, i, 3);
/*      */     } 
/* 1369 */     q3 = q3 << 8 | i;
/* 1370 */     i = this._inputData.readUnsignedByte();
/* 1371 */     if (codes[i] != 0) {
/* 1372 */       if (i == 34) {
/* 1373 */         return findName(this._quad1, q2, q3, 4);
/*      */       }
/* 1375 */       return parseName(this._quad1, q2, q3, i, 4);
/*      */     } 
/* 1377 */     return _parseLongName(i, q2, q3);
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseLongName(int q, int q2, int q3) throws IOException {
/* 1382 */     this._quadBuffer[0] = this._quad1;
/* 1383 */     this._quadBuffer[1] = q2;
/* 1384 */     this._quadBuffer[2] = q3;
/*      */ 
/*      */     
/* 1387 */     int[] codes = INPUT_CODES_LATIN1;
/* 1388 */     int qlen = 3;
/*      */     
/*      */     while (true) {
/* 1391 */       int i = this._inputData.readUnsignedByte();
/* 1392 */       if (codes[i] != 0) {
/* 1393 */         if (i == 34) {
/* 1394 */           return findName(this._quadBuffer, qlen, q, 1);
/*      */         }
/* 1396 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 1);
/*      */       } 
/*      */       
/* 1399 */       q = q << 8 | i;
/* 1400 */       i = this._inputData.readUnsignedByte();
/* 1401 */       if (codes[i] != 0) {
/* 1402 */         if (i == 34) {
/* 1403 */           return findName(this._quadBuffer, qlen, q, 2);
/*      */         }
/* 1405 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 2);
/*      */       } 
/*      */       
/* 1408 */       q = q << 8 | i;
/* 1409 */       i = this._inputData.readUnsignedByte();
/* 1410 */       if (codes[i] != 0) {
/* 1411 */         if (i == 34) {
/* 1412 */           return findName(this._quadBuffer, qlen, q, 3);
/*      */         }
/* 1414 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 3);
/*      */       } 
/*      */       
/* 1417 */       q = q << 8 | i;
/* 1418 */       i = this._inputData.readUnsignedByte();
/* 1419 */       if (codes[i] != 0) {
/* 1420 */         if (i == 34) {
/* 1421 */           return findName(this._quadBuffer, qlen, q, 4);
/*      */         }
/* 1423 */         return parseEscapedName(this._quadBuffer, qlen, q, i, 4);
/*      */       } 
/*      */ 
/*      */       
/* 1427 */       if (qlen >= this._quadBuffer.length) {
/* 1428 */         this._quadBuffer = growArrayBy(this._quadBuffer, qlen);
/*      */       }
/* 1430 */       this._quadBuffer[qlen++] = q;
/* 1431 */       q = i;
/*      */     } 
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int ch, int lastQuadBytes) throws IOException {
/* 1436 */     return parseEscapedName(this._quadBuffer, 0, q1, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int ch, int lastQuadBytes) throws IOException {
/* 1440 */     this._quadBuffer[0] = q1;
/* 1441 */     return parseEscapedName(this._quadBuffer, 1, q2, ch, lastQuadBytes);
/*      */   }
/*      */   
/*      */   private final String parseName(int q1, int q2, int q3, int ch, int lastQuadBytes) throws IOException {
/* 1445 */     this._quadBuffer[0] = q1;
/* 1446 */     this._quadBuffer[1] = q2;
/* 1447 */     return parseEscapedName(this._quadBuffer, 2, q3, ch, lastQuadBytes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String parseEscapedName(int[] quads, int qlen, int currQuad, int ch, int currQuadBytes) throws IOException {
/* 1463 */     int[] codes = INPUT_CODES_LATIN1;
/*      */     
/*      */     while (true) {
/* 1466 */       if (codes[ch] != 0) {
/* 1467 */         if (ch == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 1471 */         if (ch != 92) {
/*      */           
/* 1473 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 1476 */           ch = _decodeEscaped();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1483 */         if (ch > 127) {
/*      */           
/* 1485 */           if (currQuadBytes >= 4) {
/* 1486 */             if (qlen >= quads.length) {
/* 1487 */               this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */             }
/* 1489 */             quads[qlen++] = currQuad;
/* 1490 */             currQuad = 0;
/* 1491 */             currQuadBytes = 0;
/*      */           } 
/* 1493 */           if (ch < 2048) {
/* 1494 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 1495 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 1498 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 1499 */             currQuadBytes++;
/*      */             
/* 1501 */             if (currQuadBytes >= 4) {
/* 1502 */               if (qlen >= quads.length) {
/* 1503 */                 this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */               }
/* 1505 */               quads[qlen++] = currQuad;
/* 1506 */               currQuad = 0;
/* 1507 */               currQuadBytes = 0;
/*      */             } 
/* 1509 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 1510 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 1513 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 1517 */       if (currQuadBytes < 4) {
/* 1518 */         currQuadBytes++;
/* 1519 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 1521 */         if (qlen >= quads.length) {
/* 1522 */           this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */         }
/* 1524 */         quads[qlen++] = currQuad;
/* 1525 */         currQuad = ch;
/* 1526 */         currQuadBytes = 1;
/*      */       } 
/* 1528 */       ch = this._inputData.readUnsignedByte();
/*      */     } 
/*      */     
/* 1531 */     if (currQuadBytes > 0) {
/* 1532 */       if (qlen >= quads.length) {
/* 1533 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 1535 */       quads[qlen++] = pad(currQuad, currQuadBytes);
/*      */     } 
/* 1537 */     String name = this._symbols.findName(quads, qlen);
/* 1538 */     if (name == null) {
/* 1539 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 1541 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _handleOddName(int ch) throws IOException {
/* 1559 */     if (ch == 39 && (this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 1560 */       return _parseAposName();
/*      */     }
/* 1562 */     if ((this._features & FEAT_MASK_ALLOW_UNQUOTED_NAMES) == 0) {
/* 1563 */       char c = (char)_decodeCharForError(ch);
/* 1564 */       _reportUnexpectedChar(c, "was expecting double-quote to start field name");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1570 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */     
/* 1572 */     if (codes[ch] != 0) {
/* 1573 */       _reportUnexpectedChar(ch, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1580 */     int[] quads = this._quadBuffer;
/* 1581 */     int qlen = 0;
/* 1582 */     int currQuad = 0;
/* 1583 */     int currQuadBytes = 0;
/*      */ 
/*      */     
/*      */     do {
/* 1587 */       if (currQuadBytes < 4) {
/* 1588 */         currQuadBytes++;
/* 1589 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 1591 */         if (qlen >= quads.length) {
/* 1592 */           this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */         }
/* 1594 */         quads[qlen++] = currQuad;
/* 1595 */         currQuad = ch;
/* 1596 */         currQuadBytes = 1;
/*      */       } 
/* 1598 */       ch = this._inputData.readUnsignedByte();
/* 1599 */     } while (codes[ch] == 0);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1604 */     this._nextByte = ch;
/* 1605 */     if (currQuadBytes > 0) {
/* 1606 */       if (qlen >= quads.length) {
/* 1607 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 1609 */       quads[qlen++] = currQuad;
/*      */     } 
/* 1611 */     String name = this._symbols.findName(quads, qlen);
/* 1612 */     if (name == null) {
/* 1613 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 1615 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String _parseAposName() throws IOException {
/* 1626 */     int ch = this._inputData.readUnsignedByte();
/* 1627 */     if (ch == 39) {
/* 1628 */       return "";
/*      */     }
/* 1630 */     int[] quads = this._quadBuffer;
/* 1631 */     int qlen = 0;
/* 1632 */     int currQuad = 0;
/* 1633 */     int currQuadBytes = 0;
/*      */ 
/*      */ 
/*      */     
/* 1637 */     int[] codes = INPUT_CODES_LATIN1;
/*      */ 
/*      */     
/* 1640 */     while (ch != 39) {
/*      */ 
/*      */ 
/*      */       
/* 1644 */       if (ch != 34 && codes[ch] != 0) {
/* 1645 */         if (ch != 92) {
/*      */ 
/*      */           
/* 1648 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 1651 */           ch = _decodeEscaped();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1657 */         if (ch > 127) {
/*      */           
/* 1659 */           if (currQuadBytes >= 4) {
/* 1660 */             if (qlen >= quads.length) {
/* 1661 */               this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */             }
/* 1663 */             quads[qlen++] = currQuad;
/* 1664 */             currQuad = 0;
/* 1665 */             currQuadBytes = 0;
/*      */           } 
/* 1667 */           if (ch < 2048) {
/* 1668 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 1669 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 1672 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 1673 */             currQuadBytes++;
/*      */             
/* 1675 */             if (currQuadBytes >= 4) {
/* 1676 */               if (qlen >= quads.length) {
/* 1677 */                 this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */               }
/* 1679 */               quads[qlen++] = currQuad;
/* 1680 */               currQuad = 0;
/* 1681 */               currQuadBytes = 0;
/*      */             } 
/* 1683 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 1684 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 1687 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 1691 */       if (currQuadBytes < 4) {
/* 1692 */         currQuadBytes++;
/* 1693 */         currQuad = currQuad << 8 | ch;
/*      */       } else {
/* 1695 */         if (qlen >= quads.length) {
/* 1696 */           this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */         }
/* 1698 */         quads[qlen++] = currQuad;
/* 1699 */         currQuad = ch;
/* 1700 */         currQuadBytes = 1;
/*      */       } 
/* 1702 */       ch = this._inputData.readUnsignedByte();
/*      */     } 
/*      */     
/* 1705 */     if (currQuadBytes > 0) {
/* 1706 */       if (qlen >= quads.length) {
/* 1707 */         this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */       }
/* 1709 */       quads[qlen++] = pad(currQuad, currQuadBytes);
/*      */     } 
/* 1711 */     String name = this._symbols.findName(quads, qlen);
/* 1712 */     if (name == null) {
/* 1713 */       name = addName(quads, qlen, currQuadBytes);
/*      */     }
/* 1715 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int lastQuadBytes) throws JsonParseException, StreamConstraintsException {
/* 1727 */     q1 = pad(q1, lastQuadBytes);
/*      */     
/* 1729 */     String name = this._symbols.findName(q1);
/* 1730 */     if (name != null) {
/* 1731 */       return name;
/*      */     }
/*      */     
/* 1734 */     this._quadBuffer[0] = q1;
/* 1735 */     return addName(this._quadBuffer, 1, lastQuadBytes);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int q2, int lastQuadBytes) throws JsonParseException, StreamConstraintsException {
/* 1741 */     q2 = pad(q2, lastQuadBytes);
/*      */     
/* 1743 */     String name = this._symbols.findName(q1, q2);
/* 1744 */     if (name != null) {
/* 1745 */       return name;
/*      */     }
/*      */     
/* 1748 */     this._quadBuffer[0] = q1;
/* 1749 */     this._quadBuffer[1] = q2;
/* 1750 */     return addName(this._quadBuffer, 2, lastQuadBytes);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final String findName(int q1, int q2, int q3, int lastQuadBytes) throws JsonParseException, StreamConstraintsException {
/* 1756 */     q3 = pad(q3, lastQuadBytes);
/* 1757 */     String name = this._symbols.findName(q1, q2, q3);
/* 1758 */     if (name != null) {
/* 1759 */       return name;
/*      */     }
/* 1761 */     int[] quads = this._quadBuffer;
/* 1762 */     quads[0] = q1;
/* 1763 */     quads[1] = q2;
/* 1764 */     quads[2] = pad(q3, lastQuadBytes);
/* 1765 */     return addName(quads, 3, lastQuadBytes);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final String findName(int[] quads, int qlen, int lastQuad, int lastQuadBytes) throws JsonParseException, StreamConstraintsException {
/* 1771 */     if (qlen >= quads.length) {
/* 1772 */       this._quadBuffer = quads = growArrayBy(quads, quads.length);
/*      */     }
/* 1774 */     quads[qlen++] = pad(lastQuad, lastQuadBytes);
/* 1775 */     String name = this._symbols.findName(quads, qlen);
/* 1776 */     if (name == null) {
/* 1777 */       return addName(quads, qlen, lastQuadBytes);
/*      */     }
/* 1779 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String addName(int[] quads, int qlen, int lastQuadBytes) throws JsonParseException, StreamConstraintsException {
/* 1796 */     int lastQuad, byteLen = (qlen << 2) - 4 + lastQuadBytes;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1805 */     if (lastQuadBytes < 4) {
/* 1806 */       lastQuad = quads[qlen - 1];
/*      */       
/* 1808 */       quads[qlen - 1] = lastQuad << 4 - lastQuadBytes << 3;
/*      */     } else {
/* 1810 */       lastQuad = 0;
/*      */     } 
/*      */ 
/*      */     
/* 1814 */     char[] cbuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1815 */     int cix = 0;
/*      */     
/* 1817 */     for (int ix = 0; ix < byteLen; ) {
/* 1818 */       int ch = quads[ix >> 2];
/* 1819 */       int byteIx = ix & 0x3;
/* 1820 */       ch = ch >> 3 - byteIx << 3 & 0xFF;
/* 1821 */       ix++;
/*      */       
/* 1823 */       if (ch > 127) {
/*      */         int needed;
/* 1825 */         if ((ch & 0xE0) == 192) {
/* 1826 */           ch &= 0x1F;
/* 1827 */           needed = 1;
/* 1828 */         } else if ((ch & 0xF0) == 224) {
/* 1829 */           ch &= 0xF;
/* 1830 */           needed = 2;
/* 1831 */         } else if ((ch & 0xF8) == 240) {
/* 1832 */           ch &= 0x7;
/* 1833 */           needed = 3;
/*      */         } else {
/* 1835 */           _reportInvalidInitial(ch);
/* 1836 */           needed = ch = 1;
/*      */         } 
/* 1838 */         if (ix + needed > byteLen) {
/* 1839 */           _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*      */         }
/*      */ 
/*      */         
/* 1843 */         int ch2 = quads[ix >> 2];
/* 1844 */         byteIx = ix & 0x3;
/* 1845 */         ch2 >>= 3 - byteIx << 3;
/* 1846 */         ix++;
/*      */         
/* 1848 */         if ((ch2 & 0xC0) != 128) {
/* 1849 */           _reportInvalidOther(ch2);
/*      */         }
/* 1851 */         ch = ch << 6 | ch2 & 0x3F;
/* 1852 */         if (needed > 1) {
/* 1853 */           ch2 = quads[ix >> 2];
/* 1854 */           byteIx = ix & 0x3;
/* 1855 */           ch2 >>= 3 - byteIx << 3;
/* 1856 */           ix++;
/*      */           
/* 1858 */           if ((ch2 & 0xC0) != 128) {
/* 1859 */             _reportInvalidOther(ch2);
/*      */           }
/* 1861 */           ch = ch << 6 | ch2 & 0x3F;
/* 1862 */           if (needed > 2) {
/* 1863 */             ch2 = quads[ix >> 2];
/* 1864 */             byteIx = ix & 0x3;
/* 1865 */             ch2 >>= 3 - byteIx << 3;
/* 1866 */             ix++;
/* 1867 */             if ((ch2 & 0xC0) != 128) {
/* 1868 */               _reportInvalidOther(ch2 & 0xFF);
/*      */             }
/* 1870 */             ch = ch << 6 | ch2 & 0x3F;
/*      */           } 
/*      */         } 
/* 1873 */         if (needed > 2) {
/* 1874 */           ch -= 65536;
/* 1875 */           if (cix >= cbuf.length) {
/* 1876 */             cbuf = this._textBuffer.expandCurrentSegment();
/*      */           }
/* 1878 */           cbuf[cix++] = (char)(55296 + (ch >> 10));
/* 1879 */           ch = 0xDC00 | ch & 0x3FF;
/*      */         } 
/*      */       } 
/* 1882 */       if (cix >= cbuf.length) {
/* 1883 */         cbuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1885 */       cbuf[cix++] = (char)ch;
/*      */     } 
/*      */ 
/*      */     
/* 1889 */     String baseName = new String(cbuf, 0, cix);
/*      */     
/* 1891 */     if (!this._symbols.isCanonicalizing()) {
/* 1892 */       return baseName;
/*      */     }
/*      */     
/* 1895 */     if (lastQuadBytes < 4) {
/* 1896 */       quads[qlen - 1] = lastQuad;
/*      */     }
/* 1898 */     return this._symbols.addName(baseName, quads, qlen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _finishString() throws IOException {
/* 1910 */     int outPtr = 0;
/* 1911 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1912 */     int[] codes = INPUT_CODES_UTF8;
/* 1913 */     int outEnd = outBuf.length;
/*      */     
/*      */     while (true) {
/* 1916 */       int c = this._inputData.readUnsignedByte();
/* 1917 */       if (codes[c] != 0) {
/* 1918 */         if (c == 34) {
/* 1919 */           this._textBuffer.setCurrentLength(outPtr);
/*      */           return;
/*      */         } 
/* 1922 */         _finishString2(outBuf, outPtr, c);
/*      */         return;
/*      */       } 
/* 1925 */       outBuf[outPtr++] = (char)c;
/* 1926 */       if (outPtr >= outEnd) {
/* 1927 */         _finishString2(outBuf, outPtr, this._inputData.readUnsignedByte());
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   } private String _finishAndReturnString() throws IOException {
/* 1932 */     int outPtr = 0;
/* 1933 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1934 */     int[] codes = INPUT_CODES_UTF8;
/* 1935 */     int outEnd = outBuf.length;
/*      */     
/*      */     while (true) {
/* 1938 */       int c = this._inputData.readUnsignedByte();
/* 1939 */       if (codes[c] != 0) {
/* 1940 */         if (c == 34) {
/* 1941 */           return this._textBuffer.setCurrentAndReturn(outPtr);
/*      */         }
/* 1943 */         _finishString2(outBuf, outPtr, c);
/* 1944 */         return this._textBuffer.contentsAsString();
/*      */       } 
/* 1946 */       outBuf[outPtr++] = (char)c;
/* 1947 */       if (outPtr >= outEnd) {
/* 1948 */         _finishString2(outBuf, outPtr, this._inputData.readUnsignedByte());
/* 1949 */         return this._textBuffer.contentsAsString();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _finishString2(char[] outBuf, int outPtr, int c) throws IOException {
/* 1956 */     int[] codes = INPUT_CODES_UTF8;
/* 1957 */     int outEnd = outBuf.length;
/*      */ 
/*      */     
/* 1960 */     for (;; c = this._inputData.readUnsignedByte()) {
/*      */       
/* 1962 */       while (codes[c] == 0) {
/* 1963 */         if (outPtr >= outEnd) {
/* 1964 */           outBuf = this._textBuffer.finishCurrentSegment();
/* 1965 */           outPtr = 0;
/* 1966 */           outEnd = outBuf.length;
/*      */         } 
/* 1968 */         outBuf[outPtr++] = (char)c;
/* 1969 */         c = this._inputData.readUnsignedByte();
/*      */       } 
/*      */       
/* 1972 */       if (c == 34) {
/*      */         break;
/*      */       }
/* 1975 */       switch (codes[c]) {
/*      */         case 1:
/* 1977 */           c = _decodeEscaped();
/*      */           break;
/*      */         case 2:
/* 1980 */           c = _decodeUtf8_2(c);
/*      */           break;
/*      */         case 3:
/* 1983 */           c = _decodeUtf8_3(c);
/*      */           break;
/*      */         case 4:
/* 1986 */           c = _decodeUtf8_4(c);
/*      */           
/* 1988 */           if (outPtr >= outBuf.length) {
/* 1989 */             outBuf = this._textBuffer.finishCurrentSegment();
/* 1990 */             outPtr = 0;
/* 1991 */             outEnd = outBuf.length;
/*      */           } 
/* 1993 */           outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 1994 */           c = 0xDC00 | c & 0x3FF;
/*      */           break;
/*      */         
/*      */         default:
/* 1998 */           if (c < 32) {
/* 1999 */             _throwUnquotedSpace(c, "string value");
/*      */             break;
/*      */           } 
/* 2002 */           _reportInvalidChar(c);
/*      */           break;
/*      */       } 
/*      */       
/* 2006 */       if (outPtr >= outBuf.length) {
/* 2007 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2008 */         outPtr = 0;
/* 2009 */         outEnd = outBuf.length;
/*      */       } 
/*      */       
/* 2012 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 2014 */     this._textBuffer.setCurrentLength(outPtr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _skipString() throws IOException {
/* 2027 */     this._tokenIncomplete = false;
/*      */ 
/*      */     
/* 2030 */     int[] codes = INPUT_CODES_UTF8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2038 */       int c = this._inputData.readUnsignedByte();
/* 2039 */       if (codes[c] != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2044 */         if (c == 34) {
/*      */           break;
/*      */         }
/*      */         
/* 2048 */         switch (codes[c]) {
/*      */           case 1:
/* 2050 */             _decodeEscaped();
/*      */             continue;
/*      */           case 2:
/* 2053 */             _skipUtf8_2();
/*      */             continue;
/*      */           case 3:
/* 2056 */             _skipUtf8_3();
/*      */             continue;
/*      */           case 4:
/* 2059 */             _skipUtf8_4();
/*      */             continue;
/*      */         } 
/* 2062 */         if (c < 32) {
/* 2063 */           _throwUnquotedSpace(c, "string value");
/*      */           continue;
/*      */         } 
/* 2066 */         _reportInvalidChar(c);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleUnexpectedValue(int c) throws IOException {
/* 2087 */     switch (c) {
/*      */       case 93:
/* 2089 */         if (!this._parsingContext.inArray()) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 44:
/* 2098 */         if (!this._parsingContext.inRoot() && (
/* 2099 */           this._features & FEAT_MASK_ALLOW_MISSING) != 0) {
/*      */           
/* 2101 */           this._nextByte = c;
/* 2102 */           return JsonToken.VALUE_NULL;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 125:
/* 2109 */         _reportUnexpectedChar(c, "expected a value");
/*      */       case 39:
/* 2111 */         if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 2112 */           return _handleApos();
/*      */         }
/*      */         break;
/*      */       case 78:
/* 2116 */         _matchToken("NaN", 1);
/* 2117 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2118 */           return resetAsNaN("NaN", Double.NaN);
/*      */         }
/* 2120 */         _reportError("Non-standard token 'NaN': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/*      */         break;
/*      */       case 73:
/* 2123 */         _matchToken("Infinity", 1);
/* 2124 */         if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2125 */           return resetAsNaN("Infinity", Double.POSITIVE_INFINITY);
/*      */         }
/* 2127 */         _reportError("Non-standard token 'Infinity': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/*      */         break;
/*      */       case 43:
/* 2130 */         return _handleInvalidNumberStart(this._inputData.readUnsignedByte(), false, true);
/*      */     } 
/*      */     
/* 2133 */     if (Character.isJavaIdentifierStart(c)) {
/* 2134 */       _reportInvalidToken(c, "" + (char)c, _validJsonTokenList());
/*      */     }
/*      */     
/* 2137 */     _reportUnexpectedChar(c, "expected a valid value " + _validJsonValueList());
/* 2138 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleApos() throws IOException {
/* 2143 */     int c = 0;
/*      */     
/* 2145 */     int outPtr = 0;
/* 2146 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */ 
/*      */     
/* 2149 */     int[] codes = INPUT_CODES_UTF8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     label36: while (true) {
/* 2156 */       int outEnd = outBuf.length;
/* 2157 */       if (outPtr >= outBuf.length) {
/* 2158 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2159 */         outPtr = 0;
/* 2160 */         outEnd = outBuf.length;
/*      */       } 
/*      */       while (true)
/* 2163 */       { c = this._inputData.readUnsignedByte();
/* 2164 */         if (c == 39) {
/*      */           break;
/*      */         }
/* 2167 */         if (codes[c] != 0 && c != 34)
/*      */         
/*      */         { 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2176 */           switch (codes[c]) {
/*      */             case 1:
/* 2178 */               c = _decodeEscaped();
/*      */               break;
/*      */             case 2:
/* 2181 */               c = _decodeUtf8_2(c);
/*      */               break;
/*      */             case 3:
/* 2184 */               c = _decodeUtf8_3(c);
/*      */               break;
/*      */             case 4:
/* 2187 */               c = _decodeUtf8_4(c);
/*      */               
/* 2189 */               outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2190 */               if (outPtr >= outBuf.length) {
/* 2191 */                 outBuf = this._textBuffer.finishCurrentSegment();
/* 2192 */                 outPtr = 0;
/*      */               } 
/* 2194 */               c = 0xDC00 | c & 0x3FF;
/*      */               break;
/*      */             
/*      */             default:
/* 2198 */               if (c < 32) {
/* 2199 */                 _throwUnquotedSpace(c, "string value");
/*      */               }
/*      */               
/* 2202 */               _reportInvalidChar(c);
/*      */               break;
/*      */           } 
/* 2205 */           if (outPtr >= outBuf.length) {
/* 2206 */             outBuf = this._textBuffer.finishCurrentSegment();
/* 2207 */             outPtr = 0;
/*      */           } 
/*      */           
/* 2210 */           outBuf[outPtr++] = (char)c; continue; }  outBuf[outPtr++] = (char)c; if (outPtr >= outEnd)
/*      */           continue label36;  }  break;
/* 2212 */     }  this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 2214 */     return JsonToken.VALUE_STRING;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean neg) throws IOException {
/* 2223 */     return _handleInvalidNumberStart(ch, neg, false);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _handleInvalidNumberStart(int ch, boolean neg, boolean hasSign) throws IOException {
/* 2228 */     while (ch == 73) {
/* 2229 */       String match; ch = this._inputData.readUnsignedByte();
/*      */       
/* 2231 */       if (ch == 78) {
/* 2232 */         match = neg ? "-INF" : "+INF";
/* 2233 */       } else if (ch == 110) {
/* 2234 */         match = neg ? "-Infinity" : "+Infinity";
/*      */       } else {
/*      */         break;
/*      */       } 
/* 2238 */       _matchToken(match, 3);
/* 2239 */       if ((this._features & FEAT_MASK_NON_NUM_NUMBERS) != 0) {
/* 2240 */         return resetAsNaN(match, neg ? Double.NEGATIVE_INFINITY : Double.POSITIVE_INFINITY);
/*      */       }
/* 2242 */       _reportError("Non-standard token '" + match + "': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow");
/*      */     } 
/* 2244 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature()) && hasSign && !neg) {
/* 2245 */       _reportUnexpectedNumberChar(43, "JSON spec does not allow numbers to have plus signs: enable `JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS` to allow");
/*      */     }
/* 2247 */     String message = neg ? "expected digit (0-9) to follow minus sign, for valid numeric value" : "expected digit (0-9) for valid numeric value";
/*      */ 
/*      */     
/* 2250 */     _reportUnexpectedNumberChar(ch, message);
/* 2251 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _matchToken(String matchStr, int i) throws IOException {
/* 2256 */     int len = matchStr.length();
/*      */     do {
/* 2258 */       int j = this._inputData.readUnsignedByte();
/* 2259 */       if (j == matchStr.charAt(i))
/* 2260 */         continue;  _reportInvalidToken(j, matchStr.substring(0, i));
/*      */     }
/* 2262 */     while (++i < len);
/*      */     
/* 2264 */     int ch = this._inputData.readUnsignedByte();
/* 2265 */     if (ch >= 48 && ch != 93 && ch != 125) {
/* 2266 */       _checkMatchEnd(matchStr, i, ch);
/*      */     }
/* 2268 */     this._nextByte = ch;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _checkMatchEnd(String matchStr, int i, int ch) throws IOException {
/* 2273 */     char c = (char)_decodeCharForError(ch);
/* 2274 */     if (Character.isJavaIdentifierPart(c)) {
/* 2275 */       _reportInvalidToken(c, matchStr.substring(0, i));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWS() throws IOException {
/* 2287 */     int i = this._nextByte;
/* 2288 */     if (i < 0) {
/* 2289 */       i = this._inputData.readUnsignedByte();
/*      */     } else {
/* 2291 */       this._nextByte = -1;
/*      */     } 
/*      */     while (true) {
/* 2294 */       if (i > 32) {
/* 2295 */         if (i == 47 || i == 35) {
/* 2296 */           return _skipWSComment(i);
/*      */         }
/* 2298 */         return i;
/*      */       } 
/*      */ 
/*      */       
/* 2302 */       if (i == 13 || i == 10) {
/* 2303 */         this._currInputRow++;
/*      */       }
/*      */       
/* 2306 */       i = this._inputData.readUnsignedByte();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWSOrEnd() throws IOException {
/* 2318 */     int i = this._nextByte;
/* 2319 */     if (i < 0) {
/*      */       try {
/* 2321 */         i = this._inputData.readUnsignedByte();
/* 2322 */       } catch (EOFException e) {
/* 2323 */         return _eofAsNextChar();
/*      */       } 
/*      */     } else {
/* 2326 */       this._nextByte = -1;
/*      */     } 
/*      */     while (true) {
/* 2329 */       if (i > 32) {
/* 2330 */         if (i == 47 || i == 35) {
/* 2331 */           return _skipWSComment(i);
/*      */         }
/* 2333 */         return i;
/*      */       } 
/*      */ 
/*      */       
/* 2337 */       if (i == 13 || i == 10) {
/* 2338 */         this._currInputRow++;
/*      */       }
/*      */       
/*      */       try {
/* 2342 */         i = this._inputData.readUnsignedByte();
/* 2343 */       } catch (EOFException e) {
/* 2344 */         return _eofAsNextChar();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipWSComment(int i) throws IOException {
/*      */     while (true) {
/* 2352 */       if (i > 32) {
/* 2353 */         if (i == 47) {
/* 2354 */           _skipComment();
/* 2355 */         } else if (i == 35) {
/* 2356 */           if (!_skipYAMLComment()) {
/* 2357 */             return i;
/*      */           }
/*      */         } else {
/* 2360 */           return i;
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 2365 */       else if (i == 13 || i == 10) {
/* 2366 */         this._currInputRow++;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2374 */       i = this._inputData.readUnsignedByte();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon() throws IOException {
/* 2380 */     int i = this._nextByte;
/* 2381 */     if (i < 0) {
/* 2382 */       i = this._inputData.readUnsignedByte();
/*      */     } else {
/* 2384 */       this._nextByte = -1;
/*      */     } 
/*      */     
/* 2387 */     if (i == 58) {
/* 2388 */       i = this._inputData.readUnsignedByte();
/* 2389 */       if (i > 32) {
/* 2390 */         if (i == 47 || i == 35) {
/* 2391 */           return _skipColon2(i, true);
/*      */         }
/* 2393 */         return i;
/*      */       } 
/* 2395 */       if (i == 32 || i == 9) {
/* 2396 */         i = this._inputData.readUnsignedByte();
/* 2397 */         if (i > 32) {
/* 2398 */           if (i == 47 || i == 35) {
/* 2399 */             return _skipColon2(i, true);
/*      */           }
/* 2401 */           return i;
/*      */         } 
/*      */       } 
/* 2404 */       return _skipColon2(i, true);
/*      */     } 
/* 2406 */     if (i == 32 || i == 9) {
/* 2407 */       i = this._inputData.readUnsignedByte();
/*      */     }
/* 2409 */     if (i == 58) {
/* 2410 */       i = this._inputData.readUnsignedByte();
/* 2411 */       if (i > 32) {
/* 2412 */         if (i == 47 || i == 35) {
/* 2413 */           return _skipColon2(i, true);
/*      */         }
/* 2415 */         return i;
/*      */       } 
/* 2417 */       if (i == 32 || i == 9) {
/* 2418 */         i = this._inputData.readUnsignedByte();
/* 2419 */         if (i > 32) {
/* 2420 */           if (i == 47 || i == 35) {
/* 2421 */             return _skipColon2(i, true);
/*      */           }
/* 2423 */           return i;
/*      */         } 
/*      */       } 
/* 2426 */       return _skipColon2(i, true);
/*      */     } 
/* 2428 */     return _skipColon2(i, false);
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _skipColon2(int i, boolean gotColon) throws IOException {
/* 2433 */     for (;; i = this._inputData.readUnsignedByte()) {
/* 2434 */       if (i > 32) {
/* 2435 */         if (i == 47) {
/* 2436 */           _skipComment();
/*      */         
/*      */         }
/* 2439 */         else if (i != 35 || 
/* 2440 */           !_skipYAMLComment()) {
/*      */ 
/*      */ 
/*      */           
/* 2444 */           if (gotColon) {
/* 2445 */             return i;
/*      */           }
/* 2447 */           if (i != 58) {
/* 2448 */             _reportUnexpectedChar(i, "was expecting a colon to separate field name and value");
/*      */           }
/* 2450 */           gotColon = true;
/*      */         }
/*      */       
/*      */       }
/* 2454 */       else if (i == 13 || i == 10) {
/* 2455 */         this._currInputRow++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipComment() throws IOException {
/* 2463 */     if ((this._features & FEAT_MASK_ALLOW_JAVA_COMMENTS) == 0) {
/* 2464 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/* 2466 */     int c = this._inputData.readUnsignedByte();
/* 2467 */     if (c == 47) {
/* 2468 */       _skipLine();
/* 2469 */     } else if (c == 42) {
/* 2470 */       _skipCComment();
/*      */     } else {
/* 2472 */       _reportUnexpectedChar(c, "was expecting either '*' or '/' for a comment");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipCComment() throws IOException {
/* 2479 */     int[] codes = CharTypes.getInputCodeComment();
/* 2480 */     int i = this._inputData.readUnsignedByte();
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2485 */       int code = codes[i];
/* 2486 */       if (code != 0)
/* 2487 */         switch (code) {
/*      */           case 42:
/* 2489 */             i = this._inputData.readUnsignedByte();
/* 2490 */             if (i == 47) {
/*      */               return;
/*      */             }
/*      */             continue;
/*      */           case 10:
/*      */           case 13:
/* 2496 */             this._currInputRow++;
/*      */             break;
/*      */           case 2:
/* 2499 */             _skipUtf8_2();
/*      */             break;
/*      */           case 3:
/* 2502 */             _skipUtf8_3();
/*      */             break;
/*      */           case 4:
/* 2505 */             _skipUtf8_4();
/*      */             break;
/*      */           
/*      */           default:
/* 2509 */             _reportInvalidChar(i);
/*      */             break;
/*      */         }  
/* 2512 */       i = this._inputData.readUnsignedByte();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final boolean _skipYAMLComment() throws IOException {
/* 2518 */     if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) == 0) {
/* 2519 */       return false;
/*      */     }
/* 2521 */     _skipLine();
/* 2522 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipLine() throws IOException {
/* 2532 */     int[] codes = CharTypes.getInputCodeComment();
/*      */     while (true) {
/* 2534 */       int i = this._inputData.readUnsignedByte();
/* 2535 */       int code = codes[i];
/* 2536 */       if (code != 0) {
/* 2537 */         switch (code) {
/*      */           case 10:
/*      */           case 13:
/* 2540 */             this._currInputRow++;
/*      */             return;
/*      */           case 42:
/*      */             continue;
/*      */           case 2:
/* 2545 */             _skipUtf8_2();
/*      */             continue;
/*      */           case 3:
/* 2548 */             _skipUtf8_3();
/*      */             continue;
/*      */           case 4:
/* 2551 */             _skipUtf8_4();
/*      */             continue;
/*      */         } 
/* 2554 */         if (code < 0)
/*      */         {
/* 2556 */           _reportInvalidChar(i);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/* 2566 */     int c = this._inputData.readUnsignedByte();
/*      */     
/* 2568 */     switch (c) {
/*      */       
/*      */       case 98:
/* 2571 */         return '\b';
/*      */       case 116:
/* 2573 */         return '\t';
/*      */       case 110:
/* 2575 */         return '\n';
/*      */       case 102:
/* 2577 */         return '\f';
/*      */       case 114:
/* 2579 */         return '\r';
/*      */ 
/*      */       
/*      */       case 34:
/*      */       case 47:
/*      */       case 92:
/* 2585 */         return (char)c;
/*      */       
/*      */       case 117:
/*      */         break;
/*      */       
/*      */       default:
/* 2591 */         return _handleUnrecognizedCharacterEscape((char)_decodeCharForError(c));
/*      */     } 
/*      */ 
/*      */     
/* 2595 */     int value = 0;
/* 2596 */     for (int i = 0; i < 4; i++) {
/* 2597 */       int ch = this._inputData.readUnsignedByte();
/* 2598 */       int digit = CharTypes.charToHex(ch);
/* 2599 */       if (digit < 0) {
/* 2600 */         _reportUnexpectedChar(ch, "expected a hex-digit for character escape sequence");
/*      */       }
/* 2602 */       value = value << 4 | digit;
/*      */     } 
/* 2604 */     return (char)value;
/*      */   }
/*      */ 
/*      */   
/*      */   protected int _decodeCharForError(int firstByte) throws IOException {
/* 2609 */     int c = firstByte & 0xFF;
/* 2610 */     if (c > 127) {
/*      */       int needed;
/*      */ 
/*      */       
/* 2614 */       if ((c & 0xE0) == 192) {
/* 2615 */         c &= 0x1F;
/* 2616 */         needed = 1;
/* 2617 */       } else if ((c & 0xF0) == 224) {
/* 2618 */         c &= 0xF;
/* 2619 */         needed = 2;
/* 2620 */       } else if ((c & 0xF8) == 240) {
/*      */         
/* 2622 */         c &= 0x7;
/* 2623 */         needed = 3;
/*      */       } else {
/* 2625 */         _reportInvalidInitial(c & 0xFF);
/* 2626 */         needed = 1;
/*      */       } 
/*      */       
/* 2629 */       int d = this._inputData.readUnsignedByte();
/* 2630 */       if ((d & 0xC0) != 128) {
/* 2631 */         _reportInvalidOther(d & 0xFF);
/*      */       }
/* 2633 */       c = c << 6 | d & 0x3F;
/*      */       
/* 2635 */       if (needed > 1) {
/* 2636 */         d = this._inputData.readUnsignedByte();
/* 2637 */         if ((d & 0xC0) != 128) {
/* 2638 */           _reportInvalidOther(d & 0xFF);
/*      */         }
/* 2640 */         c = c << 6 | d & 0x3F;
/* 2641 */         if (needed > 2) {
/* 2642 */           d = this._inputData.readUnsignedByte();
/* 2643 */           if ((d & 0xC0) != 128) {
/* 2644 */             _reportInvalidOther(d & 0xFF);
/*      */           }
/* 2646 */           c = c << 6 | d & 0x3F;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2650 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_2(int c) throws IOException {
/* 2661 */     int d = this._inputData.readUnsignedByte();
/* 2662 */     if ((d & 0xC0) != 128) {
/* 2663 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2665 */     return (c & 0x1F) << 6 | d & 0x3F;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_3(int c1) throws IOException {
/* 2670 */     c1 &= 0xF;
/* 2671 */     int d = this._inputData.readUnsignedByte();
/* 2672 */     if ((d & 0xC0) != 128) {
/* 2673 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2675 */     int c = c1 << 6 | d & 0x3F;
/* 2676 */     d = this._inputData.readUnsignedByte();
/* 2677 */     if ((d & 0xC0) != 128) {
/* 2678 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2680 */     c = c << 6 | d & 0x3F;
/* 2681 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUtf8_4(int c) throws IOException {
/* 2690 */     int d = this._inputData.readUnsignedByte();
/* 2691 */     if ((d & 0xC0) != 128) {
/* 2692 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2694 */     c = (c & 0x7) << 6 | d & 0x3F;
/* 2695 */     d = this._inputData.readUnsignedByte();
/* 2696 */     if ((d & 0xC0) != 128) {
/* 2697 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2699 */     c = c << 6 | d & 0x3F;
/* 2700 */     d = this._inputData.readUnsignedByte();
/* 2701 */     if ((d & 0xC0) != 128) {
/* 2702 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2708 */     return (c << 6 | d & 0x3F) - 65536;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_2() throws IOException {
/* 2713 */     int c = this._inputData.readUnsignedByte();
/* 2714 */     if ((c & 0xC0) != 128) {
/* 2715 */       _reportInvalidOther(c & 0xFF);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_3() throws IOException {
/* 2725 */     int c = this._inputData.readUnsignedByte();
/* 2726 */     if ((c & 0xC0) != 128) {
/* 2727 */       _reportInvalidOther(c & 0xFF);
/*      */     }
/* 2729 */     c = this._inputData.readUnsignedByte();
/* 2730 */     if ((c & 0xC0) != 128) {
/* 2731 */       _reportInvalidOther(c & 0xFF);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _skipUtf8_4() throws IOException {
/* 2737 */     int d = this._inputData.readUnsignedByte();
/* 2738 */     if ((d & 0xC0) != 128) {
/* 2739 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2741 */     d = this._inputData.readUnsignedByte();
/* 2742 */     if ((d & 0xC0) != 128) {
/* 2743 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/* 2745 */     d = this._inputData.readUnsignedByte();
/* 2746 */     if ((d & 0xC0) != 128) {
/* 2747 */       _reportInvalidOther(d & 0xFF);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(int ch, String matchedPart) throws IOException {
/* 2759 */     _reportInvalidToken(ch, matchedPart, _validJsonTokenList());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidToken(int ch, String matchedPart, String msg) throws IOException {
/* 2765 */     StringBuilder sb = new StringBuilder(matchedPart);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2772 */       char c = (char)_decodeCharForError(ch);
/* 2773 */       if (!Character.isJavaIdentifierPart(c)) {
/*      */         break;
/*      */       }
/* 2776 */       sb.append(c);
/* 2777 */       ch = this._inputData.readUnsignedByte();
/*      */     } 
/* 2779 */     _reportError("Unrecognized token '" + sb.toString() + "': was expecting " + msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidChar(int c) throws JsonParseException {
/* 2786 */     if (c < 32) {
/* 2787 */       _throwInvalidSpace(c);
/*      */     }
/* 2789 */     _reportInvalidInitial(c);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportInvalidInitial(int mask) throws JsonParseException {
/* 2795 */     _reportError("Invalid UTF-8 start byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _reportInvalidOther(int mask) throws JsonParseException {
/* 2801 */     _reportError("Invalid UTF-8 middle byte 0x" + Integer.toHexString(mask));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final byte[] _decodeBase64(Base64Variant b64variant) throws IOException {
/* 2824 */     ByteArrayBuilder builder = _getByteArrayBuilder();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2831 */       int ch = this._inputData.readUnsignedByte();
/* 2832 */       if (ch > 32) {
/* 2833 */         int bits = b64variant.decodeBase64Char(ch);
/* 2834 */         if (bits < 0) {
/* 2835 */           if (ch == 34) {
/* 2836 */             return builder.toByteArray();
/*      */           }
/* 2838 */           bits = _decodeBase64Escape(b64variant, ch, 0);
/* 2839 */           if (bits < 0) {
/*      */             continue;
/*      */           }
/*      */         } 
/* 2843 */         int decodedData = bits;
/*      */ 
/*      */         
/* 2846 */         ch = this._inputData.readUnsignedByte();
/* 2847 */         bits = b64variant.decodeBase64Char(ch);
/* 2848 */         if (bits < 0) {
/* 2849 */           bits = _decodeBase64Escape(b64variant, ch, 1);
/*      */         }
/* 2851 */         decodedData = decodedData << 6 | bits;
/*      */         
/* 2853 */         ch = this._inputData.readUnsignedByte();
/* 2854 */         bits = b64variant.decodeBase64Char(ch);
/*      */ 
/*      */         
/* 2857 */         if (bits < 0) {
/* 2858 */           if (bits != -2) {
/*      */             
/* 2860 */             if (ch == 34) {
/* 2861 */               decodedData >>= 4;
/* 2862 */               builder.append(decodedData);
/* 2863 */               if (b64variant.requiresPaddingOnRead()) {
/* 2864 */                 _handleBase64MissingPadding(b64variant);
/*      */               }
/* 2866 */               return builder.toByteArray();
/*      */             } 
/* 2868 */             bits = _decodeBase64Escape(b64variant, ch, 2);
/*      */           } 
/* 2870 */           if (bits == -2) {
/* 2871 */             ch = this._inputData.readUnsignedByte();
/* 2872 */             if (!b64variant.usesPaddingChar(ch) && (
/* 2873 */               ch != 92 || 
/* 2874 */               _decodeBase64Escape(b64variant, ch, 3) != -2)) {
/* 2875 */               throw reportInvalidBase64Char(b64variant, ch, 3, "expected padding character '" + b64variant.getPaddingChar() + "'");
/*      */             }
/*      */ 
/*      */             
/* 2879 */             decodedData >>= 4;
/* 2880 */             builder.append(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 2885 */         decodedData = decodedData << 6 | bits;
/*      */         
/* 2887 */         ch = this._inputData.readUnsignedByte();
/* 2888 */         bits = b64variant.decodeBase64Char(ch);
/* 2889 */         if (bits < 0) {
/* 2890 */           if (bits != -2) {
/*      */             
/* 2892 */             if (ch == 34) {
/* 2893 */               decodedData >>= 2;
/* 2894 */               builder.appendTwoBytes(decodedData);
/* 2895 */               if (b64variant.requiresPaddingOnRead()) {
/* 2896 */                 _handleBase64MissingPadding(b64variant);
/*      */               }
/* 2898 */               return builder.toByteArray();
/*      */             } 
/* 2900 */             bits = _decodeBase64Escape(b64variant, ch, 3);
/*      */           } 
/* 2902 */           if (bits == -2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2909 */             decodedData >>= 2;
/* 2910 */             builder.appendTwoBytes(decodedData);
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/* 2915 */         decodedData = decodedData << 6 | bits;
/* 2916 */         builder.appendThreeBytes(decodedData);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation currentLocation() {
/* 2929 */     int col = -1;
/* 2930 */     return new JsonLocation(_contentReference(), -1L, -1L, this._currInputRow, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonLocation _currentLocationMinusOne() {
/* 2937 */     return currentLocation();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonLocation currentTokenLocation() {
/* 2952 */     return new JsonLocation(_contentReference(), -1L, -1L, this._tokenInputRow, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _closeScope(int i) throws IOException {
/* 2963 */     if (i == 93) {
/* 2964 */       if (!this._parsingContext.inArray()) {
/* 2965 */         _reportMismatchedEndMarker(i, '}');
/*      */       }
/* 2967 */       this._parsingContext = this._parsingContext.clearAndGetParent();
/* 2968 */       _updateToken(JsonToken.END_ARRAY);
/*      */     } 
/* 2970 */     if (i == 125) {
/* 2971 */       if (!this._parsingContext.inObject()) {
/* 2972 */         _reportMismatchedEndMarker(i, ']');
/*      */       }
/* 2974 */       this._parsingContext = this._parsingContext.clearAndGetParent();
/* 2975 */       _updateToken(JsonToken.END_OBJECT);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int pad(int q, int bytes) {
/* 2983 */     return (bytes == 4) ? q : (q | -1 << bytes << 3);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\json\UTF8DataInputJsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */