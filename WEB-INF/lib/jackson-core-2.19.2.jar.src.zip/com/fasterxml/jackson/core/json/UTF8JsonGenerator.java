/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonGenerationException;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.io.NumberOutput;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ 
/*      */ public class UTF8JsonGenerator
/*      */   extends JsonGeneratorImpl {
/*      */   private static final byte BYTE_u = 117;
/*      */   private static final byte BYTE_0 = 48;
/*      */   private static final byte BYTE_LBRACKET = 91;
/*      */   private static final byte BYTE_RBRACKET = 93;
/*      */   private static final byte BYTE_LCURLY = 123;
/*      */   private static final byte BYTE_RCURLY = 125;
/*      */   private static final byte BYTE_BACKSLASH = 92;
/*      */   private static final byte BYTE_COMMA = 44;
/*      */   private static final byte BYTE_COLON = 58;
/*      */   private static final int MAX_BYTES_TO_BUFFER = 512;
/*   32 */   private static final byte[] HEX_BYTES_UPPER = CharTypes.copyHexBytes(true);
/*   33 */   private static final byte[] HEX_BYTES_LOWER = CharTypes.copyHexBytes(false);
/*      */   
/*   35 */   private static final byte[] NULL_BYTES = new byte[] { 110, 117, 108, 108 };
/*   36 */   private static final byte[] TRUE_BYTES = new byte[] { 116, 114, 117, 101 };
/*   37 */   private static final byte[] FALSE_BYTES = new byte[] { 102, 97, 108, 115, 101 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final OutputStream _outputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte _quoteChar;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] _outputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _outputTail;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _outputEnd;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _outputMaxContiguous;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char[] _charBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _charBufferLength;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] _entityBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _bufferRecyclable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UTF8JsonGenerator(IOContext ctxt, int features, ObjectCodec codec, OutputStream out, char quoteChar) {
/*  121 */     super(ctxt, features, codec);
/*  122 */     this._outputStream = out;
/*  123 */     this._quoteChar = (byte)quoteChar;
/*      */     
/*  125 */     boolean escapeSlash = isEnabled(JsonWriteFeature.ESCAPE_FORWARD_SLASHES.mappedFeature());
/*  126 */     if (quoteChar != '"' || escapeSlash) {
/*  127 */       this._outputEscapes = CharTypes.get7BitOutputEscapes(quoteChar, escapeSlash);
/*      */     }
/*  129 */     this._bufferRecyclable = true;
/*  130 */     this._outputBuffer = ctxt.allocWriteEncodingBuffer();
/*  131 */     this._outputEnd = this._outputBuffer.length;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  136 */     this._outputMaxContiguous = this._outputEnd >> 3;
/*  137 */     this._charBuffer = ctxt.allocConcatBuffer();
/*  138 */     this._charBufferLength = this._charBuffer.length;
/*      */ 
/*      */     
/*  141 */     if (isEnabled(JsonWriteFeature.ESCAPE_NON_ASCII.mappedFeature())) {
/*  142 */       setHighestNonEscapedChar(127);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UTF8JsonGenerator(IOContext ctxt, int features, ObjectCodec codec, OutputStream out, char quoteChar, byte[] outputBuffer, int outputOffset, boolean bufferRecyclable) {
/*  152 */     super(ctxt, features, codec);
/*  153 */     this._outputStream = out;
/*  154 */     this._quoteChar = (byte)quoteChar;
/*  155 */     boolean escapeSlash = isEnabled(JsonWriteFeature.ESCAPE_FORWARD_SLASHES.mappedFeature());
/*  156 */     if (quoteChar != '"' || escapeSlash) {
/*  157 */       this._outputEscapes = CharTypes.get7BitOutputEscapes(quoteChar, escapeSlash);
/*      */     }
/*      */     
/*  160 */     this._bufferRecyclable = bufferRecyclable;
/*  161 */     this._outputTail = outputOffset;
/*  162 */     this._outputBuffer = outputBuffer;
/*  163 */     this._outputEnd = this._outputBuffer.length;
/*      */     
/*  165 */     this._outputMaxContiguous = this._outputEnd >> 3;
/*  166 */     this._charBuffer = ctxt.allocConcatBuffer();
/*  167 */     this._charBufferLength = this._charBuffer.length;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public UTF8JsonGenerator(IOContext ctxt, int features, ObjectCodec codec, OutputStream out) {
/*  173 */     this(ctxt, features, codec, out, '"');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public UTF8JsonGenerator(IOContext ctxt, int features, ObjectCodec codec, OutputStream out, byte[] outputBuffer, int outputOffset, boolean bufferRecyclable) {
/*  181 */     this(ctxt, features, codec, out, '"', outputBuffer, outputOffset, bufferRecyclable);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getOutputTarget() {
/*  193 */     return this._outputStream;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getOutputBuffered() {
/*  199 */     return this._outputTail;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldName(String name) throws IOException {
/*  211 */     if (this._cfgPrettyPrinter != null) {
/*  212 */       _writePPFieldName(name);
/*      */       return;
/*      */     } 
/*  215 */     int status = this._writeContext.writeFieldName(name);
/*  216 */     if (status == 4) {
/*  217 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  219 */     if (status == 1) {
/*  220 */       if (this._outputTail >= this._outputEnd) {
/*  221 */         _flushBuffer();
/*      */       }
/*  223 */       this._outputBuffer[this._outputTail++] = 44;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  228 */     if (this._cfgUnqNames) {
/*  229 */       _writeStringSegments(name, false);
/*      */       return;
/*      */     } 
/*  232 */     int len = name.length();
/*      */     
/*  234 */     if (len > this._charBufferLength) {
/*  235 */       _writeStringSegments(name, true);
/*      */       return;
/*      */     } 
/*  238 */     if (this._outputTail >= this._outputEnd) {
/*  239 */       _flushBuffer();
/*      */     }
/*  241 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     
/*  243 */     if (len <= this._outputMaxContiguous) {
/*  244 */       if (this._outputTail + len > this._outputEnd) {
/*  245 */         _flushBuffer();
/*      */       }
/*  247 */       _writeStringSegment(name, 0, len);
/*      */     } else {
/*  249 */       _writeStringSegments(name, 0, len);
/*      */     } 
/*      */     
/*  252 */     if (this._outputTail >= this._outputEnd) {
/*  253 */       _flushBuffer();
/*      */     }
/*  255 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldName(SerializableString name) throws IOException {
/*  261 */     if (this._cfgPrettyPrinter != null) {
/*  262 */       _writePPFieldName(name);
/*      */       return;
/*      */     } 
/*  265 */     int status = this._writeContext.writeFieldName(name.getValue());
/*  266 */     if (status == 4) {
/*  267 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  269 */     if (status == 1) {
/*  270 */       if (this._outputTail >= this._outputEnd) {
/*  271 */         _flushBuffer();
/*      */       }
/*  273 */       this._outputBuffer[this._outputTail++] = 44;
/*      */     } 
/*  275 */     if (this._cfgUnqNames) {
/*  276 */       _writeUnq(name);
/*      */       return;
/*      */     } 
/*  279 */     if (this._outputTail >= this._outputEnd) {
/*  280 */       _flushBuffer();
/*      */     }
/*  282 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  283 */     int len = name.appendQuotedUTF8(this._outputBuffer, this._outputTail);
/*  284 */     if (len < 0) {
/*  285 */       _writeBytes(name.asQuotedUTF8());
/*      */     } else {
/*  287 */       this._outputTail += len;
/*      */     } 
/*  289 */     if (this._outputTail >= this._outputEnd) {
/*  290 */       _flushBuffer();
/*      */     }
/*  292 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */   
/*      */   private final void _writeUnq(SerializableString name) throws IOException {
/*  296 */     int len = name.appendQuotedUTF8(this._outputBuffer, this._outputTail);
/*  297 */     if (len < 0) {
/*  298 */       _writeBytes(name.asQuotedUTF8());
/*      */     } else {
/*  300 */       this._outputTail += len;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeStartArray() throws IOException {
/*  313 */     _verifyValueWrite("start an array");
/*  314 */     this._writeContext = this._writeContext.createChildArrayContext();
/*  315 */     streamWriteConstraints().validateNestingDepth(this._writeContext.getNestingDepth());
/*  316 */     if (this._cfgPrettyPrinter != null) {
/*  317 */       this._cfgPrettyPrinter.writeStartArray((JsonGenerator)this);
/*      */     } else {
/*  319 */       if (this._outputTail >= this._outputEnd) {
/*  320 */         _flushBuffer();
/*      */       }
/*  322 */       this._outputBuffer[this._outputTail++] = 91;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeStartArray(Object currentValue) throws IOException {
/*  329 */     _verifyValueWrite("start an array");
/*  330 */     this._writeContext = this._writeContext.createChildArrayContext(currentValue);
/*  331 */     streamWriteConstraints().validateNestingDepth(this._writeContext.getNestingDepth());
/*  332 */     if (this._cfgPrettyPrinter != null) {
/*  333 */       this._cfgPrettyPrinter.writeStartArray((JsonGenerator)this);
/*      */     } else {
/*  335 */       if (this._outputTail >= this._outputEnd) {
/*  336 */         _flushBuffer();
/*      */       }
/*  338 */       this._outputBuffer[this._outputTail++] = 91;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object currentValue, int size) throws IOException {
/*  345 */     _verifyValueWrite("start an array");
/*  346 */     this._writeContext = this._writeContext.createChildArrayContext(currentValue);
/*  347 */     streamWriteConstraints().validateNestingDepth(this._writeContext.getNestingDepth());
/*  348 */     if (this._cfgPrettyPrinter != null) {
/*  349 */       this._cfgPrettyPrinter.writeStartArray((JsonGenerator)this);
/*      */     } else {
/*  351 */       if (this._outputTail >= this._outputEnd) {
/*  352 */         _flushBuffer();
/*      */       }
/*  354 */       this._outputBuffer[this._outputTail++] = 91;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeEndArray() throws IOException {
/*  361 */     if (!this._writeContext.inArray()) {
/*  362 */       _reportError("Current context not Array but " + this._writeContext.typeDesc());
/*      */     }
/*  364 */     if (this._cfgPrettyPrinter != null) {
/*  365 */       this._cfgPrettyPrinter.writeEndArray((JsonGenerator)this, this._writeContext.getEntryCount());
/*      */     } else {
/*  367 */       if (this._outputTail >= this._outputEnd) {
/*  368 */         _flushBuffer();
/*      */       }
/*  370 */       this._outputBuffer[this._outputTail++] = 93;
/*      */     } 
/*  372 */     this._writeContext = this._writeContext.clearAndGetParent();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeStartObject() throws IOException {
/*  378 */     _verifyValueWrite("start an object");
/*  379 */     this._writeContext = this._writeContext.createChildObjectContext();
/*  380 */     streamWriteConstraints().validateNestingDepth(this._writeContext.getNestingDepth());
/*  381 */     if (this._cfgPrettyPrinter != null) {
/*  382 */       this._cfgPrettyPrinter.writeStartObject((JsonGenerator)this);
/*      */     } else {
/*  384 */       if (this._outputTail >= this._outputEnd) {
/*  385 */         _flushBuffer();
/*      */       }
/*  387 */       this._outputBuffer[this._outputTail++] = 123;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue) throws IOException {
/*  394 */     _verifyValueWrite("start an object");
/*  395 */     JsonWriteContext ctxt = this._writeContext.createChildObjectContext(forValue);
/*  396 */     streamWriteConstraints().validateNestingDepth(ctxt.getNestingDepth());
/*  397 */     this._writeContext = ctxt;
/*  398 */     if (this._cfgPrettyPrinter != null) {
/*  399 */       this._cfgPrettyPrinter.writeStartObject((JsonGenerator)this);
/*      */     } else {
/*  401 */       if (this._outputTail >= this._outputEnd) {
/*  402 */         _flushBuffer();
/*      */       }
/*  404 */       this._outputBuffer[this._outputTail++] = 123;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue, int size) throws IOException {
/*  410 */     writeStartObject(forValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeEndObject() throws IOException {
/*  416 */     if (!this._writeContext.inObject()) {
/*  417 */       _reportError("Current context not Object but " + this._writeContext.typeDesc());
/*      */     }
/*  419 */     if (this._cfgPrettyPrinter != null) {
/*  420 */       this._cfgPrettyPrinter.writeEndObject((JsonGenerator)this, this._writeContext.getEntryCount());
/*      */     } else {
/*  422 */       if (this._outputTail >= this._outputEnd) {
/*  423 */         _flushBuffer();
/*      */       }
/*  425 */       this._outputBuffer[this._outputTail++] = 125;
/*      */     } 
/*  427 */     this._writeContext = this._writeContext.clearAndGetParent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _writePPFieldName(String name) throws IOException {
/*  434 */     int status = this._writeContext.writeFieldName(name);
/*  435 */     if (status == 4) {
/*  436 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  438 */     if (status == 1) {
/*  439 */       this._cfgPrettyPrinter.writeObjectEntrySeparator((JsonGenerator)this);
/*      */     } else {
/*  441 */       this._cfgPrettyPrinter.beforeObjectEntries((JsonGenerator)this);
/*      */     } 
/*  443 */     if (this._cfgUnqNames) {
/*  444 */       _writeStringSegments(name, false);
/*      */       return;
/*      */     } 
/*  447 */     int len = name.length();
/*  448 */     if (len > this._charBufferLength) {
/*  449 */       _writeStringSegments(name, true);
/*      */       return;
/*      */     } 
/*  452 */     if (this._outputTail >= this._outputEnd) {
/*  453 */       _flushBuffer();
/*      */     }
/*  455 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  456 */     name.getChars(0, len, this._charBuffer, 0);
/*      */     
/*  458 */     if (len <= this._outputMaxContiguous) {
/*  459 */       if (this._outputTail + len > this._outputEnd) {
/*  460 */         _flushBuffer();
/*      */       }
/*  462 */       _writeStringSegment(this._charBuffer, 0, len);
/*      */     } else {
/*  464 */       _writeStringSegments(this._charBuffer, 0, len);
/*      */     } 
/*  466 */     if (this._outputTail >= this._outputEnd) {
/*  467 */       _flushBuffer();
/*      */     }
/*  469 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _writePPFieldName(SerializableString name) throws IOException {
/*  474 */     int status = this._writeContext.writeFieldName(name.getValue());
/*  475 */     if (status == 4) {
/*  476 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  478 */     if (status == 1) {
/*  479 */       this._cfgPrettyPrinter.writeObjectEntrySeparator((JsonGenerator)this);
/*      */     } else {
/*  481 */       this._cfgPrettyPrinter.beforeObjectEntries((JsonGenerator)this);
/*      */     } 
/*      */     
/*  484 */     boolean addQuotes = !this._cfgUnqNames;
/*  485 */     if (addQuotes) {
/*  486 */       if (this._outputTail >= this._outputEnd) {
/*  487 */         _flushBuffer();
/*      */       }
/*  489 */       this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     } 
/*  491 */     int len = name.appendQuotedUTF8(this._outputBuffer, this._outputTail);
/*  492 */     if (len < 0) {
/*  493 */       _writeBytes(name.asQuotedUTF8());
/*      */     } else {
/*  495 */       this._outputTail += len;
/*      */     } 
/*  497 */     if (addQuotes) {
/*  498 */       if (this._outputTail >= this._outputEnd) {
/*  499 */         _flushBuffer();
/*      */       }
/*  501 */       this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(String text) throws IOException {
/*  514 */     _verifyValueWrite("write a string");
/*  515 */     if (text == null) {
/*  516 */       _writeNull();
/*      */       
/*      */       return;
/*      */     } 
/*  520 */     int len = text.length();
/*  521 */     if (len > this._outputMaxContiguous) {
/*  522 */       _writeStringSegments(text, true);
/*      */       return;
/*      */     } 
/*  525 */     if (this._outputTail + len >= this._outputEnd) {
/*  526 */       _flushBuffer();
/*      */     }
/*  528 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  529 */     _writeStringSegment(text, 0, len);
/*  530 */     if (this._outputTail >= this._outputEnd) {
/*  531 */       _flushBuffer();
/*      */     }
/*  533 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeString(Reader reader, int len) throws IOException {
/*  538 */     _verifyValueWrite("write a string");
/*  539 */     if (reader == null) {
/*  540 */       _reportError("null reader");
/*      */       
/*      */       return;
/*      */     } 
/*  544 */     int toRead = (len >= 0) ? len : Integer.MAX_VALUE;
/*  545 */     char[] buf = this._charBuffer;
/*      */ 
/*      */     
/*  548 */     if (this._outputTail >= this._outputEnd) {
/*  549 */       _flushBuffer();
/*      */     }
/*  551 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */ 
/*      */     
/*  554 */     while (toRead > 0) {
/*  555 */       int toReadNow = Math.min(toRead, buf.length);
/*  556 */       int numRead = reader.read(buf, 0, toReadNow);
/*  557 */       if (numRead <= 0) {
/*      */         break;
/*      */       }
/*  560 */       if (this._outputTail + len >= this._outputEnd) {
/*  561 */         _flushBuffer();
/*      */       }
/*  563 */       _writeStringSegments(buf, 0, numRead);
/*      */       
/*  565 */       toRead -= numRead;
/*      */     } 
/*      */ 
/*      */     
/*  569 */     if (this._outputTail >= this._outputEnd) {
/*  570 */       _flushBuffer();
/*      */     }
/*  572 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     
/*  574 */     if (toRead > 0 && len >= 0) {
/*  575 */       _reportError("Didn't read enough from reader");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(char[] text, int offset, int len) throws IOException {
/*  582 */     _verifyValueWrite("write a string");
/*  583 */     if (this._outputTail >= this._outputEnd) {
/*  584 */       _flushBuffer();
/*      */     }
/*  586 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     
/*  588 */     if (len <= this._outputMaxContiguous) {
/*  589 */       if (this._outputTail + len > this._outputEnd) {
/*  590 */         _flushBuffer();
/*      */       }
/*  592 */       _writeStringSegment(text, offset, len);
/*      */     } else {
/*  594 */       _writeStringSegments(text, offset, len);
/*      */     } 
/*      */     
/*  597 */     if (this._outputTail >= this._outputEnd) {
/*  598 */       _flushBuffer();
/*      */     }
/*  600 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeString(SerializableString text) throws IOException {
/*  606 */     _verifyValueWrite("write a string");
/*  607 */     if (this._outputTail >= this._outputEnd) {
/*  608 */       _flushBuffer();
/*      */     }
/*  610 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  611 */     int len = text.appendQuotedUTF8(this._outputBuffer, this._outputTail);
/*  612 */     if (len < 0) {
/*  613 */       _writeBytes(text.asQuotedUTF8());
/*      */     } else {
/*  615 */       this._outputTail += len;
/*      */     } 
/*  617 */     if (this._outputTail >= this._outputEnd) {
/*  618 */       _flushBuffer();
/*      */     }
/*  620 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawUTF8String(byte[] text, int offset, int len) throws IOException {
/*  626 */     _checkRangeBoundsForByteArray(text, offset, len);
/*  627 */     _verifyValueWrite("write a string");
/*  628 */     if (this._outputTail >= this._outputEnd) {
/*  629 */       _flushBuffer();
/*      */     }
/*  631 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  632 */     _writeBytes(text, offset, len);
/*  633 */     if (this._outputTail >= this._outputEnd) {
/*  634 */       _flushBuffer();
/*      */     }
/*  636 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeUTF8String(byte[] text, int offset, int len) throws IOException {
/*  642 */     _checkRangeBoundsForByteArray(text, offset, len);
/*  643 */     _verifyValueWrite("write a string");
/*  644 */     if (this._outputTail >= this._outputEnd) {
/*  645 */       _flushBuffer();
/*      */     }
/*  647 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     
/*  649 */     if (len <= this._outputMaxContiguous) {
/*  650 */       _writeUTF8Segment(text, offset, len);
/*      */     } else {
/*  652 */       _writeUTF8Segments(text, offset, len);
/*      */     } 
/*  654 */     if (this._outputTail >= this._outputEnd) {
/*  655 */       _flushBuffer();
/*      */     }
/*  657 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(String text) throws IOException {
/*  668 */     int len = text.length();
/*  669 */     char[] buf = this._charBuffer;
/*  670 */     if (len <= buf.length) {
/*  671 */       text.getChars(0, len, buf, 0);
/*  672 */       writeRaw(buf, 0, len);
/*      */     } else {
/*  674 */       writeRaw(text, 0, len);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(String text, int offset, int len) throws IOException {
/*  681 */     _checkRangeBoundsForString(text, offset, len);
/*      */     
/*  683 */     char[] buf = this._charBuffer;
/*  684 */     int cbufLen = buf.length;
/*      */     
/*  686 */     if (len <= cbufLen) {
/*  687 */       text.getChars(offset, offset + len, buf, 0);
/*  688 */       writeRaw(buf, 0, len);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/*  695 */     int maxChunk = Math.min(cbufLen, (this._outputEnd >> 2) + (this._outputEnd >> 4));
/*      */     
/*  697 */     int maxBytes = maxChunk * 3;
/*      */     
/*  699 */     while (len > 0) {
/*  700 */       int len2 = Math.min(maxChunk, len);
/*  701 */       text.getChars(offset, offset + len2, buf, 0);
/*  702 */       if (this._outputTail + maxBytes > this._outputEnd) {
/*  703 */         _flushBuffer();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  711 */       if (len2 > 1) {
/*  712 */         char ch = buf[len2 - 1];
/*  713 */         if (ch >= '?' && ch <= '?') {
/*  714 */           len2--;
/*      */         }
/*      */       } 
/*  717 */       _writeRawSegment(buf, 0, len2);
/*  718 */       offset += len2;
/*  719 */       len -= len2;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(SerializableString text) throws IOException {
/*  726 */     int len = text.appendUnquotedUTF8(this._outputBuffer, this._outputTail);
/*  727 */     if (len < 0) {
/*  728 */       _writeBytes(text.asUnquotedUTF8());
/*      */     } else {
/*  730 */       this._outputTail += len;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawValue(SerializableString text) throws IOException {
/*  737 */     _verifyValueWrite("write a raw (unencoded) value");
/*  738 */     int len = text.appendUnquotedUTF8(this._outputBuffer, this._outputTail);
/*  739 */     if (len < 0) {
/*  740 */       _writeBytes(text.asUnquotedUTF8());
/*      */     } else {
/*  742 */       this._outputTail += len;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void writeRaw(char[] cbuf, int offset, int len) throws IOException {
/*  750 */     _checkRangeBoundsForCharArray(cbuf, offset, len);
/*      */ 
/*      */ 
/*      */     
/*  754 */     int len3 = len + len + len;
/*  755 */     if (this._outputTail + len3 > this._outputEnd) {
/*      */       
/*  757 */       if (this._outputEnd < len3) {
/*  758 */         _writeSegmentedRaw(cbuf, offset, len);
/*      */         
/*      */         return;
/*      */       } 
/*  762 */       _flushBuffer();
/*      */     } 
/*      */     
/*  765 */     len += offset;
/*      */ 
/*      */ 
/*      */     
/*  769 */     while (offset < len) {
/*      */       
/*      */       while (true) {
/*  772 */         int ch = cbuf[offset];
/*  773 */         if (ch > 127) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  781 */           ch = cbuf[offset++];
/*  782 */           if (ch < 2048) {
/*  783 */             this._outputBuffer[this._outputTail++] = (byte)(0xC0 | ch >> 6);
/*  784 */             this._outputBuffer[this._outputTail++] = (byte)(0x80 | ch & 0x3F); continue;
/*      */           } 
/*  786 */           offset = _outputRawMultiByteChar(ch, cbuf, offset, len);
/*      */           continue;
/*      */         } 
/*      */         this._outputBuffer[this._outputTail++] = (byte)ch;
/*      */         if (++offset >= len)
/*      */           break; 
/*      */       } 
/*      */     }  } public void writeRaw(char ch) throws IOException {
/*  794 */     if (this._outputTail + 3 >= this._outputEnd) {
/*  795 */       _flushBuffer();
/*      */     }
/*  797 */     byte[] bbuf = this._outputBuffer;
/*  798 */     if (ch <= '') {
/*  799 */       bbuf[this._outputTail++] = (byte)ch;
/*  800 */     } else if (ch < 'ࠀ') {
/*  801 */       bbuf[this._outputTail++] = (byte)(0xC0 | ch >> 6);
/*  802 */       bbuf[this._outputTail++] = (byte)(0x80 | ch & 0x3F);
/*      */     } else {
/*  804 */       _outputRawMultiByteChar(ch, (char[])null, 0, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeSegmentedRaw(char[] cbuf, int offset, int len) throws IOException {
/*  814 */     int end = this._outputEnd;
/*  815 */     byte[] bbuf = this._outputBuffer;
/*  816 */     int inputEnd = offset + len;
/*      */ 
/*      */     
/*  819 */     while (offset < inputEnd) {
/*      */       
/*      */       while (true) {
/*  822 */         int ch = cbuf[offset];
/*  823 */         if (ch > 127) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  835 */           if (this._outputTail + 3 >= this._outputEnd) {
/*  836 */             _flushBuffer();
/*      */           }
/*  838 */           ch = cbuf[offset++];
/*  839 */           if (ch < 2048) {
/*  840 */             bbuf[this._outputTail++] = (byte)(0xC0 | ch >> 6);
/*  841 */             bbuf[this._outputTail++] = (byte)(0x80 | ch & 0x3F); continue;
/*      */           } 
/*  843 */           offset = _outputRawMultiByteChar(ch, cbuf, offset, inputEnd);
/*      */           continue;
/*      */         } 
/*      */         if (this._outputTail >= end) {
/*      */           _flushBuffer();
/*      */         }
/*      */         bbuf[this._outputTail++] = (byte)ch;
/*      */         if (++offset >= inputEnd) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeRawSegment(char[] cbuf, int offset, int end) throws IOException {
/*  860 */     while (offset < end) {
/*      */       
/*      */       while (true) {
/*  863 */         int ch = cbuf[offset];
/*  864 */         if (ch > 127) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  872 */           ch = cbuf[offset++];
/*  873 */           if (ch < 2048) {
/*  874 */             this._outputBuffer[this._outputTail++] = (byte)(0xC0 | ch >> 6);
/*  875 */             this._outputBuffer[this._outputTail++] = (byte)(0x80 | ch & 0x3F); continue;
/*      */           } 
/*  877 */           offset = _outputRawMultiByteChar(ch, cbuf, offset, end);
/*      */           continue;
/*      */         } 
/*      */         this._outputBuffer[this._outputTail++] = (byte)ch;
/*      */         if (++offset >= end) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBinary(Base64Variant b64variant, byte[] data, int offset, int len) throws IOException, JsonGenerationException {
/*  893 */     _checkRangeBoundsForByteArray(data, offset, len);
/*      */     
/*  895 */     _verifyValueWrite("write a binary value");
/*      */     
/*  897 */     if (this._outputTail >= this._outputEnd) {
/*  898 */       _flushBuffer();
/*      */     }
/*  900 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  901 */     _writeBinary(b64variant, data, offset, offset + len);
/*      */     
/*  903 */     if (this._outputTail >= this._outputEnd) {
/*  904 */       _flushBuffer();
/*      */     }
/*  906 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int writeBinary(Base64Variant b64variant, InputStream data, int dataLength) throws IOException, JsonGenerationException {
/*      */     int bytes;
/*  914 */     _verifyValueWrite("write a binary value");
/*      */     
/*  916 */     if (this._outputTail >= this._outputEnd) {
/*  917 */       _flushBuffer();
/*      */     }
/*  919 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  920 */     byte[] encodingBuffer = this._ioContext.allocBase64Buffer();
/*      */     
/*      */     try {
/*  923 */       if (dataLength < 0) {
/*  924 */         bytes = _writeBinary(b64variant, data, encodingBuffer);
/*      */       } else {
/*  926 */         int missing = _writeBinary(b64variant, data, encodingBuffer, dataLength);
/*  927 */         if (missing > 0) {
/*  928 */           _reportError("Too few bytes available: missing " + missing + " bytes (out of " + dataLength + ")");
/*      */         }
/*  930 */         bytes = dataLength;
/*      */       } 
/*      */     } finally {
/*  933 */       this._ioContext.releaseBase64Buffer(encodingBuffer);
/*      */     } 
/*      */     
/*  936 */     if (this._outputTail >= this._outputEnd) {
/*  937 */       _flushBuffer();
/*      */     }
/*  939 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  940 */     return bytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(short s) throws IOException {
/*  952 */     _verifyValueWrite("write a number");
/*      */     
/*  954 */     if (this._outputTail + 6 >= this._outputEnd) {
/*  955 */       _flushBuffer();
/*      */     }
/*  957 */     if (this._cfgNumbersAsStrings) {
/*  958 */       _writeQuotedShort(s);
/*      */       return;
/*      */     } 
/*  961 */     this._outputTail = NumberOutput.outputInt(s, this._outputBuffer, this._outputTail);
/*      */   }
/*      */   
/*      */   private final void _writeQuotedShort(short s) throws IOException {
/*  965 */     if (this._outputTail + 8 >= this._outputEnd) {
/*  966 */       _flushBuffer();
/*      */     }
/*  968 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  969 */     this._outputTail = NumberOutput.outputInt(s, this._outputBuffer, this._outputTail);
/*  970 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(int i) throws IOException {
/*  976 */     _verifyValueWrite("write a number");
/*      */     
/*  978 */     if (this._outputTail + 11 >= this._outputEnd) {
/*  979 */       _flushBuffer();
/*      */     }
/*  981 */     if (this._cfgNumbersAsStrings) {
/*  982 */       _writeQuotedInt(i);
/*      */       return;
/*      */     } 
/*  985 */     this._outputTail = NumberOutput.outputInt(i, this._outputBuffer, this._outputTail);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _writeQuotedInt(int i) throws IOException {
/*  990 */     if (this._outputTail + 13 >= this._outputEnd) {
/*  991 */       _flushBuffer();
/*      */     }
/*  993 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  994 */     this._outputTail = NumberOutput.outputInt(i, this._outputBuffer, this._outputTail);
/*  995 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(long l) throws IOException {
/* 1001 */     _verifyValueWrite("write a number");
/* 1002 */     if (this._cfgNumbersAsStrings) {
/* 1003 */       _writeQuotedLong(l);
/*      */       return;
/*      */     } 
/* 1006 */     if (this._outputTail + 21 >= this._outputEnd)
/*      */     {
/* 1008 */       _flushBuffer();
/*      */     }
/* 1010 */     this._outputTail = NumberOutput.outputLong(l, this._outputBuffer, this._outputTail);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _writeQuotedLong(long l) throws IOException {
/* 1015 */     if (this._outputTail + 23 >= this._outputEnd) {
/* 1016 */       _flushBuffer();
/*      */     }
/* 1018 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/* 1019 */     this._outputTail = NumberOutput.outputLong(l, this._outputBuffer, this._outputTail);
/* 1020 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(BigInteger value) throws IOException {
/* 1026 */     _verifyValueWrite("write a number");
/* 1027 */     if (value == null) {
/* 1028 */       _writeNull();
/* 1029 */     } else if (this._cfgNumbersAsStrings) {
/* 1030 */       _writeQuotedRaw(value.toString());
/*      */     } else {
/* 1032 */       writeRaw(value.toString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(double d) throws IOException {
/* 1040 */     if (this._cfgNumbersAsStrings || (
/* 1041 */       NumberOutput.notFinite(d) && JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS
/* 1042 */       .enabledIn(this._features))) {
/* 1043 */       writeString(NumberOutput.toString(d, isEnabled(JsonGenerator.Feature.USE_FAST_DOUBLE_WRITER)));
/*      */       
/*      */       return;
/*      */     } 
/* 1047 */     _verifyValueWrite("write a number");
/* 1048 */     writeRaw(NumberOutput.toString(d, isEnabled(JsonGenerator.Feature.USE_FAST_DOUBLE_WRITER)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(float f) throws IOException {
/* 1055 */     if (this._cfgNumbersAsStrings || (
/* 1056 */       NumberOutput.notFinite(f) && JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS
/* 1057 */       .enabledIn(this._features))) {
/* 1058 */       writeString(NumberOutput.toString(f, isEnabled(JsonGenerator.Feature.USE_FAST_DOUBLE_WRITER)));
/*      */       
/*      */       return;
/*      */     } 
/* 1062 */     _verifyValueWrite("write a number");
/* 1063 */     writeRaw(NumberOutput.toString(f, isEnabled(JsonGenerator.Feature.USE_FAST_DOUBLE_WRITER)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(BigDecimal value) throws IOException {
/* 1070 */     _verifyValueWrite("write a number");
/* 1071 */     if (value == null) {
/* 1072 */       _writeNull();
/* 1073 */     } else if (this._cfgNumbersAsStrings) {
/* 1074 */       _writeQuotedRaw(_asString(value));
/*      */     } else {
/* 1076 */       writeRaw(_asString(value));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(String encodedValue) throws IOException {
/* 1083 */     _verifyValueWrite("write a number");
/* 1084 */     if (encodedValue == null) {
/* 1085 */       _writeNull();
/* 1086 */     } else if (this._cfgNumbersAsStrings) {
/* 1087 */       _writeQuotedRaw(encodedValue);
/*      */     } else {
/* 1089 */       writeRaw(encodedValue);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNumber(char[] encodedValueBuffer, int offset, int length) throws IOException {
/* 1095 */     _verifyValueWrite("write a number");
/* 1096 */     if (this._cfgNumbersAsStrings) {
/* 1097 */       _writeQuotedRaw(encodedValueBuffer, offset, length);
/*      */     } else {
/* 1099 */       writeRaw(encodedValueBuffer, offset, length);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _writeQuotedRaw(String value) throws IOException {
/* 1105 */     if (this._outputTail >= this._outputEnd) {
/* 1106 */       _flushBuffer();
/*      */     }
/* 1108 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/* 1109 */     writeRaw(value);
/* 1110 */     if (this._outputTail >= this._outputEnd) {
/* 1111 */       _flushBuffer();
/*      */     }
/* 1113 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */   
/*      */   private void _writeQuotedRaw(char[] text, int offset, int length) throws IOException {
/* 1118 */     if (this._outputTail >= this._outputEnd) {
/* 1119 */       _flushBuffer();
/*      */     }
/* 1121 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/* 1122 */     writeRaw(text, offset, length);
/* 1123 */     if (this._outputTail >= this._outputEnd) {
/* 1124 */       _flushBuffer();
/*      */     }
/* 1126 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBoolean(boolean state) throws IOException {
/* 1132 */     _verifyValueWrite("write a boolean value");
/* 1133 */     if (this._outputTail + 5 >= this._outputEnd) {
/* 1134 */       _flushBuffer();
/*      */     }
/* 1136 */     byte[] keyword = state ? TRUE_BYTES : FALSE_BYTES;
/* 1137 */     int len = keyword.length;
/* 1138 */     System.arraycopy(keyword, 0, this._outputBuffer, this._outputTail, len);
/* 1139 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNull() throws IOException {
/* 1145 */     _verifyValueWrite("write a null");
/* 1146 */     _writeNull();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _verifyValueWrite(String typeMsg) throws IOException {
/*      */     byte b;
/* 1158 */     int status = this._writeContext.writeValue();
/* 1159 */     if (this._cfgPrettyPrinter != null) {
/*      */       
/* 1161 */       _verifyPrettyValueWrite(typeMsg, status);
/*      */       
/*      */       return;
/*      */     } 
/* 1165 */     switch (status) {
/*      */       default:
/*      */         return;
/*      */       
/*      */       case 1:
/* 1170 */         b = 44;
/*      */         break;
/*      */       case 2:
/* 1173 */         b = 58;
/*      */         break;
/*      */       case 3:
/* 1176 */         if (this._rootValueSeparator != null) {
/* 1177 */           byte[] raw = this._rootValueSeparator.asUnquotedUTF8();
/* 1178 */           if (raw.length > 0) {
/* 1179 */             _writeBytes(raw);
/*      */           }
/*      */         } 
/*      */         return;
/*      */       case 5:
/* 1184 */         _reportCantWriteValueExpectName(typeMsg);
/*      */         return;
/*      */     } 
/* 1187 */     if (this._outputTail >= this._outputEnd) {
/* 1188 */       _flushBuffer();
/*      */     }
/* 1190 */     this._outputBuffer[this._outputTail++] = b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void flush() throws IOException {
/* 1202 */     _flushBuffer();
/* 1203 */     if (this._outputStream != null && 
/* 1204 */       isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM)) {
/* 1205 */       this._outputStream.flush();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws IOException {
/* 1213 */     super.close();
/*      */ 
/*      */ 
/*      */     
/* 1217 */     IOException flushFail = null;
/*      */     try {
/* 1219 */       if (this._outputBuffer != null && 
/* 1220 */         isEnabled(JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT)) {
/*      */         while (true) {
/* 1222 */           JsonStreamContext ctxt = getOutputContext();
/* 1223 */           if (ctxt.inArray()) {
/* 1224 */             writeEndArray(); continue;
/* 1225 */           }  if (ctxt.inObject()) {
/* 1226 */             writeEndObject();
/*      */             continue;
/*      */           } 
/*      */           break;
/*      */         } 
/*      */       }
/* 1232 */       _flushBuffer();
/* 1233 */     } catch (IOException e) {
/*      */ 
/*      */       
/* 1236 */       flushFail = e;
/*      */     } 
/*      */     
/* 1239 */     this._outputTail = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1247 */     if (this._outputStream != null) {
/*      */       try {
/* 1249 */         if (this._ioContext.isResourceManaged() || isEnabled(JsonGenerator.Feature.AUTO_CLOSE_TARGET)) {
/* 1250 */           this._outputStream.close();
/* 1251 */         } else if (isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM)) {
/*      */           
/* 1253 */           this._outputStream.flush();
/*      */         } 
/* 1255 */       } catch (IOException|RuntimeException e) {
/* 1256 */         if (flushFail != null) {
/* 1257 */           e.addSuppressed(flushFail);
/*      */         }
/* 1259 */         throw e;
/*      */       } 
/*      */     }
/*      */     
/* 1263 */     _releaseBuffers();
/*      */     
/* 1265 */     if (flushFail != null) {
/* 1266 */       throw flushFail;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() {
/* 1273 */     byte[] buf = this._outputBuffer;
/* 1274 */     if (buf != null && this._bufferRecyclable) {
/* 1275 */       this._outputBuffer = null;
/* 1276 */       this._ioContext.releaseWriteEncodingBuffer(buf);
/*      */     } 
/* 1278 */     char[] cbuf = this._charBuffer;
/* 1279 */     if (cbuf != null) {
/* 1280 */       this._charBuffer = null;
/* 1281 */       this._ioContext.releaseConcatBuffer(cbuf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeBytes(byte[] bytes) throws IOException {
/* 1293 */     int len = bytes.length;
/* 1294 */     if (this._outputTail + len > this._outputEnd) {
/* 1295 */       _flushBuffer();
/*      */       
/* 1297 */       if (len > 512) {
/* 1298 */         this._outputStream.write(bytes, 0, len);
/*      */         return;
/*      */       } 
/*      */     } 
/* 1302 */     System.arraycopy(bytes, 0, this._outputBuffer, this._outputTail, len);
/* 1303 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _writeBytes(byte[] bytes, int offset, int len) throws IOException {
/* 1308 */     if (this._outputTail + len > this._outputEnd) {
/* 1309 */       _flushBuffer();
/*      */       
/* 1311 */       if (len > 512) {
/* 1312 */         this._outputStream.write(bytes, offset, len);
/*      */         return;
/*      */       } 
/*      */     } 
/* 1316 */     System.arraycopy(bytes, offset, this._outputBuffer, this._outputTail, len);
/* 1317 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeStringSegments(String text, boolean addQuotes) throws IOException {
/* 1335 */     if (addQuotes) {
/* 1336 */       if (this._outputTail >= this._outputEnd) {
/* 1337 */         _flushBuffer();
/*      */       }
/* 1339 */       this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     } 
/*      */     
/* 1342 */     int left = text.length();
/* 1343 */     int offset = 0;
/*      */     
/* 1345 */     while (left > 0) {
/* 1346 */       int len = Math.min(this._outputMaxContiguous, left);
/* 1347 */       if (this._outputTail + len > this._outputEnd) {
/* 1348 */         _flushBuffer();
/*      */       }
/* 1350 */       _writeStringSegment(text, offset, len);
/* 1351 */       offset += len;
/* 1352 */       left -= len;
/*      */     } 
/*      */     
/* 1355 */     if (addQuotes) {
/* 1356 */       if (this._outputTail >= this._outputEnd) {
/* 1357 */         _flushBuffer();
/*      */       }
/* 1359 */       this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeStringSegments(char[] cbuf, int offset, int totalLen) throws IOException {
/*      */     do {
/* 1372 */       int len = Math.min(this._outputMaxContiguous, totalLen);
/* 1373 */       if (this._outputTail + len > this._outputEnd) {
/* 1374 */         _flushBuffer();
/*      */       }
/* 1376 */       _writeStringSegment(cbuf, offset, len);
/* 1377 */       offset += len;
/* 1378 */       totalLen -= len;
/* 1379 */     } while (totalLen > 0);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _writeStringSegments(String text, int offset, int totalLen) throws IOException {
/*      */     do {
/* 1385 */       int len = Math.min(this._outputMaxContiguous, totalLen);
/* 1386 */       if (this._outputTail + len > this._outputEnd) {
/* 1387 */         _flushBuffer();
/*      */       }
/* 1389 */       _writeStringSegment(text, offset, len);
/* 1390 */       offset += len;
/* 1391 */       totalLen -= len;
/* 1392 */     } while (totalLen > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeStringSegment(char[] cbuf, int offset, int len) throws IOException {
/* 1415 */     len += offset;
/*      */     
/* 1417 */     int outputPtr = this._outputTail;
/* 1418 */     byte[] outputBuffer = this._outputBuffer;
/* 1419 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1421 */     while (offset < len) {
/* 1422 */       int ch = cbuf[offset];
/*      */       
/* 1424 */       if (ch > 127 || escCodes[ch] != 0) {
/*      */         break;
/*      */       }
/* 1427 */       outputBuffer[outputPtr++] = (byte)ch;
/* 1428 */       offset++;
/*      */     } 
/* 1430 */     this._outputTail = outputPtr;
/* 1431 */     if (offset < len) {
/* 1432 */       if (this._characterEscapes != null) {
/* 1433 */         _writeCustomStringSegment2(cbuf, offset, len);
/* 1434 */       } else if (this._maximumNonEscapedChar == 0) {
/* 1435 */         _writeStringSegment2(cbuf, offset, len);
/*      */       } else {
/* 1437 */         _writeStringSegmentASCII2(cbuf, offset, len);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeStringSegment(String text, int offset, int len) throws IOException {
/* 1447 */     len += offset;
/*      */     
/* 1449 */     int outputPtr = this._outputTail;
/* 1450 */     byte[] outputBuffer = this._outputBuffer;
/* 1451 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1453 */     while (offset < len) {
/* 1454 */       int ch = text.charAt(offset);
/*      */       
/* 1456 */       if (ch > 127 || escCodes[ch] != 0) {
/*      */         break;
/*      */       }
/* 1459 */       outputBuffer[outputPtr++] = (byte)ch;
/* 1460 */       offset++;
/*      */     } 
/* 1462 */     this._outputTail = outputPtr;
/* 1463 */     if (offset < len) {
/* 1464 */       if (this._characterEscapes != null) {
/* 1465 */         _writeCustomStringSegment2(text, offset, len);
/* 1466 */       } else if (this._maximumNonEscapedChar == 0) {
/* 1467 */         _writeStringSegment2(text, offset, len);
/*      */       } else {
/* 1469 */         _writeStringSegmentASCII2(text, offset, len);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeStringSegment2(char[] cbuf, int offset, int end) throws IOException {
/* 1481 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1482 */       _flushBuffer();
/*      */     }
/*      */     
/* 1485 */     int outputPtr = this._outputTail;
/*      */     
/* 1487 */     byte[] outputBuffer = this._outputBuffer;
/* 1488 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1490 */     while (offset < end) {
/* 1491 */       int ch = cbuf[offset++];
/* 1492 */       if (ch <= 127) {
/* 1493 */         if (escCodes[ch] == 0) {
/* 1494 */           outputBuffer[outputPtr++] = (byte)ch;
/*      */           continue;
/*      */         } 
/* 1497 */         int escape = escCodes[ch];
/* 1498 */         if (escape > 0) {
/* 1499 */           outputBuffer[outputPtr++] = 92;
/* 1500 */           outputBuffer[outputPtr++] = (byte)escape;
/*      */           continue;
/*      */         } 
/* 1503 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         
/*      */         continue;
/*      */       } 
/* 1507 */       if (ch <= 2047) {
/* 1508 */         outputBuffer[outputPtr++] = (byte)(0xC0 | ch >> 6);
/* 1509 */         outputBuffer[outputPtr++] = (byte)(0x80 | ch & 0x3F);
/*      */         continue;
/*      */       } 
/* 1512 */       if (_isStartOfSurrogatePair(ch)) {
/* 1513 */         boolean combineSurrogates = JsonGenerator.Feature.COMBINE_UNICODE_SURROGATES_IN_UTF8.enabledIn(this._features);
/* 1514 */         if (combineSurrogates && offset < end) {
/* 1515 */           char highSurrogate = (char)ch;
/* 1516 */           char lowSurrogate = cbuf[offset++];
/* 1517 */           outputPtr = _outputSurrogatePair(highSurrogate, lowSurrogate, outputPtr);
/*      */           continue;
/*      */         } 
/*      */       } 
/* 1521 */       outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */     } 
/*      */     
/* 1524 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _writeStringSegment2(String text, int offset, int end) throws IOException {
/* 1529 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1530 */       _flushBuffer();
/*      */     }
/*      */     
/* 1533 */     int outputPtr = this._outputTail;
/*      */     
/* 1535 */     byte[] outputBuffer = this._outputBuffer;
/* 1536 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1538 */     while (offset < end) {
/* 1539 */       int ch = text.charAt(offset++);
/* 1540 */       if (ch <= 127) {
/* 1541 */         if (escCodes[ch] == 0) {
/* 1542 */           outputBuffer[outputPtr++] = (byte)ch;
/*      */           continue;
/*      */         } 
/* 1545 */         int escape = escCodes[ch];
/* 1546 */         if (escape > 0) {
/* 1547 */           outputBuffer[outputPtr++] = 92;
/* 1548 */           outputBuffer[outputPtr++] = (byte)escape;
/*      */           continue;
/*      */         } 
/* 1551 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         
/*      */         continue;
/*      */       } 
/* 1555 */       if (ch <= 2047) {
/* 1556 */         outputBuffer[outputPtr++] = (byte)(0xC0 | ch >> 6);
/* 1557 */         outputBuffer[outputPtr++] = (byte)(0x80 | ch & 0x3F);
/*      */         continue;
/*      */       } 
/* 1560 */       if (_isStartOfSurrogatePair(ch)) {
/* 1561 */         boolean combineSurrogates = JsonGenerator.Feature.COMBINE_UNICODE_SURROGATES_IN_UTF8.enabledIn(this._features);
/* 1562 */         if (combineSurrogates && offset < end) {
/* 1563 */           char highSurrogate = (char)ch;
/* 1564 */           char lowSurrogate = text.charAt(offset++);
/* 1565 */           outputPtr = _outputSurrogatePair(highSurrogate, lowSurrogate, outputPtr);
/*      */           continue;
/*      */         } 
/*      */       } 
/* 1569 */       outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */     } 
/*      */     
/* 1572 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeStringSegmentASCII2(char[] cbuf, int offset, int end) throws IOException {
/* 1589 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1590 */       _flushBuffer();
/*      */     }
/* 1592 */     int outputPtr = this._outputTail;
/*      */     
/* 1594 */     byte[] outputBuffer = this._outputBuffer;
/* 1595 */     int[] escCodes = this._outputEscapes;
/* 1596 */     int maxUnescaped = this._maximumNonEscapedChar;
/*      */     
/* 1598 */     while (offset < end) {
/* 1599 */       int ch = cbuf[offset++];
/* 1600 */       if (ch <= 127) {
/* 1601 */         if (escCodes[ch] == 0) {
/* 1602 */           outputBuffer[outputPtr++] = (byte)ch;
/*      */           continue;
/*      */         } 
/* 1605 */         int escape = escCodes[ch];
/* 1606 */         if (escape > 0) {
/* 1607 */           outputBuffer[outputPtr++] = 92;
/* 1608 */           outputBuffer[outputPtr++] = (byte)escape;
/*      */           continue;
/*      */         } 
/* 1611 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         
/*      */         continue;
/*      */       } 
/* 1615 */       if (ch > maxUnescaped) {
/* 1616 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         continue;
/*      */       } 
/* 1619 */       if (ch <= 2047) {
/* 1620 */         outputBuffer[outputPtr++] = (byte)(0xC0 | ch >> 6);
/* 1621 */         outputBuffer[outputPtr++] = (byte)(0x80 | ch & 0x3F); continue;
/*      */       } 
/* 1623 */       outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */     } 
/*      */     
/* 1626 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeStringSegmentASCII2(String text, int offset, int end) throws IOException {
/* 1632 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1633 */       _flushBuffer();
/*      */     }
/*      */     
/* 1636 */     int outputPtr = this._outputTail;
/*      */     
/* 1638 */     byte[] outputBuffer = this._outputBuffer;
/* 1639 */     int[] escCodes = this._outputEscapes;
/* 1640 */     int maxUnescaped = this._maximumNonEscapedChar;
/*      */     
/* 1642 */     while (offset < end) {
/* 1643 */       int ch = text.charAt(offset++);
/* 1644 */       if (ch <= 127) {
/* 1645 */         if (escCodes[ch] == 0) {
/* 1646 */           outputBuffer[outputPtr++] = (byte)ch;
/*      */           continue;
/*      */         } 
/* 1649 */         int escape = escCodes[ch];
/* 1650 */         if (escape > 0) {
/* 1651 */           outputBuffer[outputPtr++] = 92;
/* 1652 */           outputBuffer[outputPtr++] = (byte)escape;
/*      */           continue;
/*      */         } 
/* 1655 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         
/*      */         continue;
/*      */       } 
/* 1659 */       if (ch > maxUnescaped) {
/* 1660 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         continue;
/*      */       } 
/* 1663 */       if (ch <= 2047) {
/* 1664 */         outputBuffer[outputPtr++] = (byte)(0xC0 | ch >> 6);
/* 1665 */         outputBuffer[outputPtr++] = (byte)(0x80 | ch & 0x3F); continue;
/*      */       } 
/* 1667 */       outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */     } 
/*      */     
/* 1670 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeCustomStringSegment2(char[] cbuf, int offset, int end) throws IOException {
/* 1687 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1688 */       _flushBuffer();
/*      */     }
/* 1690 */     int outputPtr = this._outputTail;
/*      */     
/* 1692 */     byte[] outputBuffer = this._outputBuffer;
/* 1693 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1695 */     int maxUnescaped = (this._maximumNonEscapedChar <= 0) ? 65535 : this._maximumNonEscapedChar;
/* 1696 */     CharacterEscapes customEscapes = this._characterEscapes;
/*      */     
/* 1698 */     while (offset < end) {
/* 1699 */       int ch = cbuf[offset++];
/* 1700 */       if (ch <= 127) {
/* 1701 */         if (escCodes[ch] == 0) {
/* 1702 */           outputBuffer[outputPtr++] = (byte)ch;
/*      */           continue;
/*      */         } 
/* 1705 */         int escape = escCodes[ch];
/* 1706 */         if (escape > 0) {
/* 1707 */           outputBuffer[outputPtr++] = 92;
/* 1708 */           outputBuffer[outputPtr++] = (byte)escape; continue;
/* 1709 */         }  if (escape == -2) {
/* 1710 */           SerializableString serializableString = customEscapes.getEscapeSequence(ch);
/* 1711 */           if (serializableString == null) {
/* 1712 */             _reportError("Invalid custom escape definitions; custom escape not found for character code 0x" + 
/* 1713 */                 Integer.toHexString(ch) + ", although was supposed to have one");
/*      */           }
/* 1715 */           outputPtr = _writeCustomEscape(outputBuffer, outputPtr, serializableString, end - offset);
/*      */           continue;
/*      */         } 
/* 1718 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         
/*      */         continue;
/*      */       } 
/* 1722 */       if (ch > maxUnescaped) {
/* 1723 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         continue;
/*      */       } 
/* 1726 */       SerializableString esc = customEscapes.getEscapeSequence(ch);
/* 1727 */       if (esc != null) {
/* 1728 */         outputPtr = _writeCustomEscape(outputBuffer, outputPtr, esc, end - offset);
/*      */         continue;
/*      */       } 
/* 1731 */       if (ch <= 2047) {
/* 1732 */         outputBuffer[outputPtr++] = (byte)(0xC0 | ch >> 6);
/* 1733 */         outputBuffer[outputPtr++] = (byte)(0x80 | ch & 0x3F);
/*      */         continue;
/*      */       } 
/* 1736 */       if (_isStartOfSurrogatePair(ch)) {
/* 1737 */         boolean combineSurrogates = JsonGenerator.Feature.COMBINE_UNICODE_SURROGATES_IN_UTF8.enabledIn(this._features);
/* 1738 */         if (combineSurrogates && offset < end) {
/* 1739 */           char highSurrogate = (char)ch;
/* 1740 */           char lowSurrogate = cbuf[offset++];
/* 1741 */           outputPtr = _outputSurrogatePair(highSurrogate, lowSurrogate, outputPtr);
/*      */           continue;
/*      */         } 
/*      */       } 
/* 1745 */       outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */     } 
/*      */     
/* 1748 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeCustomStringSegment2(String text, int offset, int end) throws IOException {
/* 1754 */     if (this._outputTail + 6 * (end - offset) > this._outputEnd) {
/* 1755 */       _flushBuffer();
/*      */     }
/* 1757 */     int outputPtr = this._outputTail;
/*      */     
/* 1759 */     byte[] outputBuffer = this._outputBuffer;
/* 1760 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1762 */     int maxUnescaped = (this._maximumNonEscapedChar <= 0) ? 65535 : this._maximumNonEscapedChar;
/* 1763 */     CharacterEscapes customEscapes = this._characterEscapes;
/*      */     
/* 1765 */     while (offset < end) {
/* 1766 */       int ch = text.charAt(offset++);
/* 1767 */       if (ch <= 127) {
/* 1768 */         if (escCodes[ch] == 0) {
/* 1769 */           outputBuffer[outputPtr++] = (byte)ch;
/*      */           continue;
/*      */         } 
/* 1772 */         int escape = escCodes[ch];
/* 1773 */         if (escape > 0) {
/* 1774 */           outputBuffer[outputPtr++] = 92;
/* 1775 */           outputBuffer[outputPtr++] = (byte)escape; continue;
/* 1776 */         }  if (escape == -2) {
/* 1777 */           SerializableString serializableString = customEscapes.getEscapeSequence(ch);
/* 1778 */           if (serializableString == null) {
/* 1779 */             _reportError("Invalid custom escape definitions; custom escape not found for character code 0x" + 
/* 1780 */                 Integer.toHexString(ch) + ", although was supposed to have one");
/*      */           }
/* 1782 */           outputPtr = _writeCustomEscape(outputBuffer, outputPtr, serializableString, end - offset);
/*      */           continue;
/*      */         } 
/* 1785 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         
/*      */         continue;
/*      */       } 
/* 1789 */       if (ch > maxUnescaped) {
/* 1790 */         outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */         continue;
/*      */       } 
/* 1793 */       SerializableString esc = customEscapes.getEscapeSequence(ch);
/* 1794 */       if (esc != null) {
/* 1795 */         outputPtr = _writeCustomEscape(outputBuffer, outputPtr, esc, end - offset);
/*      */         continue;
/*      */       } 
/* 1798 */       if (ch <= 2047) {
/* 1799 */         outputBuffer[outputPtr++] = (byte)(0xC0 | ch >> 6);
/* 1800 */         outputBuffer[outputPtr++] = (byte)(0x80 | ch & 0x3F);
/*      */         continue;
/*      */       } 
/* 1803 */       if (_isStartOfSurrogatePair(ch)) {
/* 1804 */         boolean combineSurrogates = JsonGenerator.Feature.COMBINE_UNICODE_SURROGATES_IN_UTF8.enabledIn(this._features);
/* 1805 */         if (combineSurrogates && offset < end) {
/* 1806 */           char highSurrogate = (char)ch;
/* 1807 */           char lowSurrogate = text.charAt(offset++);
/* 1808 */           outputPtr = _outputSurrogatePair(highSurrogate, lowSurrogate, outputPtr);
/*      */           continue;
/*      */         } 
/*      */       } 
/* 1812 */       outputPtr = _outputMultiByteChar(ch, outputPtr);
/*      */     } 
/*      */     
/* 1815 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _writeCustomEscape(byte[] outputBuffer, int outputPtr, SerializableString esc, int remainingChars) throws IOException, JsonGenerationException {
/* 1821 */     byte[] raw = esc.asUnquotedUTF8();
/* 1822 */     int len = raw.length;
/* 1823 */     if (len > 6) {
/* 1824 */       return _handleLongCustomEscape(outputBuffer, outputPtr, this._outputEnd, raw, remainingChars);
/*      */     }
/*      */     
/* 1827 */     System.arraycopy(raw, 0, outputBuffer, outputPtr, len);
/* 1828 */     return outputPtr + len;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _handleLongCustomEscape(byte[] outputBuffer, int outputPtr, int outputEnd, byte[] raw, int remainingChars) throws IOException, JsonGenerationException {
/* 1835 */     int len = raw.length;
/* 1836 */     if (outputPtr + len > outputEnd) {
/* 1837 */       this._outputTail = outputPtr;
/* 1838 */       _flushBuffer();
/* 1839 */       outputPtr = this._outputTail;
/* 1840 */       if (len > outputBuffer.length) {
/* 1841 */         this._outputStream.write(raw, 0, len);
/* 1842 */         return outputPtr;
/*      */       } 
/*      */     } 
/* 1845 */     System.arraycopy(raw, 0, outputBuffer, outputPtr, len);
/* 1846 */     outputPtr += len;
/*      */     
/* 1848 */     if (outputPtr + 6 * remainingChars > outputEnd) {
/* 1849 */       this._outputTail = outputPtr;
/* 1850 */       _flushBuffer();
/* 1851 */       return this._outputTail;
/*      */     } 
/* 1853 */     return outputPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeUTF8Segments(byte[] utf8, int offset, int totalLen) throws IOException, JsonGenerationException {
/*      */     do {
/* 1871 */       int len = Math.min(this._outputMaxContiguous, totalLen);
/* 1872 */       _writeUTF8Segment(utf8, offset, len);
/* 1873 */       offset += len;
/* 1874 */       totalLen -= len;
/* 1875 */     } while (totalLen > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeUTF8Segment(byte[] utf8, int offset, int len) throws IOException, JsonGenerationException {
/* 1882 */     int[] escCodes = this._outputEscapes;
/*      */     
/* 1884 */     for (int ptr = offset, end = offset + len; ptr < end; ) {
/*      */       
/* 1886 */       int ch = utf8[ptr++];
/* 1887 */       if (ch >= 0 && escCodes[ch] != 0) {
/* 1888 */         _writeUTF8Segment2(utf8, offset, len);
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/* 1894 */     if (this._outputTail + len > this._outputEnd) {
/* 1895 */       _flushBuffer();
/*      */     }
/* 1897 */     System.arraycopy(utf8, offset, this._outputBuffer, this._outputTail, len);
/* 1898 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeUTF8Segment2(byte[] utf8, int offset, int len) throws IOException, JsonGenerationException {
/* 1904 */     int outputPtr = this._outputTail;
/*      */ 
/*      */     
/* 1907 */     if (outputPtr + len * 6 > this._outputEnd) {
/* 1908 */       _flushBuffer();
/* 1909 */       outputPtr = this._outputTail;
/*      */     } 
/*      */     
/* 1912 */     byte[] outputBuffer = this._outputBuffer;
/* 1913 */     int[] escCodes = this._outputEscapes;
/* 1914 */     len += offset;
/*      */     
/* 1916 */     while (offset < len) {
/* 1917 */       byte b = utf8[offset++];
/* 1918 */       int ch = b;
/* 1919 */       if (ch < 0 || escCodes[ch] == 0) {
/* 1920 */         outputBuffer[outputPtr++] = b;
/*      */         continue;
/*      */       } 
/* 1923 */       int escape = escCodes[ch];
/* 1924 */       if (escape > 0) {
/* 1925 */         outputBuffer[outputPtr++] = 92;
/* 1926 */         outputBuffer[outputPtr++] = (byte)escape;
/*      */         continue;
/*      */       } 
/* 1929 */       outputPtr = _writeGenericEscape(ch, outputPtr);
/*      */     } 
/*      */     
/* 1932 */     this._outputTail = outputPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _writeBinary(Base64Variant b64variant, byte[] input, int inputPtr, int inputEnd) throws IOException, JsonGenerationException {
/* 1946 */     int safeInputEnd = inputEnd - 3;
/*      */     
/* 1948 */     int safeOutputEnd = this._outputEnd - 6;
/* 1949 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */ 
/*      */     
/* 1952 */     while (inputPtr <= safeInputEnd) {
/* 1953 */       if (this._outputTail > safeOutputEnd) {
/* 1954 */         _flushBuffer();
/*      */       }
/*      */       
/* 1957 */       int b24 = input[inputPtr++] << 8;
/* 1958 */       b24 |= input[inputPtr++] & 0xFF;
/* 1959 */       b24 = b24 << 8 | input[inputPtr++] & 0xFF;
/* 1960 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 1961 */       if (--chunksBeforeLF <= 0) {
/*      */         
/* 1963 */         this._outputBuffer[this._outputTail++] = 92;
/* 1964 */         this._outputBuffer[this._outputTail++] = 110;
/* 1965 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1970 */     int inputLeft = inputEnd - inputPtr;
/* 1971 */     if (inputLeft > 0) {
/* 1972 */       if (this._outputTail > safeOutputEnd) {
/* 1973 */         _flushBuffer();
/*      */       }
/* 1975 */       int b24 = input[inputPtr++] << 16;
/* 1976 */       if (inputLeft == 2) {
/* 1977 */         b24 |= (input[inputPtr++] & 0xFF) << 8;
/*      */       }
/* 1979 */       this._outputTail = b64variant.encodeBase64Partial(b24, inputLeft, this._outputBuffer, this._outputTail);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _writeBinary(Base64Variant b64variant, InputStream data, byte[] readBuffer, int bytesLeft) throws IOException, JsonGenerationException {
/* 1988 */     int inputPtr = 0;
/* 1989 */     int inputEnd = 0;
/* 1990 */     int lastFullOffset = -3;
/*      */ 
/*      */     
/* 1993 */     int safeOutputEnd = this._outputEnd - 6;
/* 1994 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */     
/* 1996 */     while (bytesLeft > 2) {
/* 1997 */       if (inputPtr > lastFullOffset) {
/* 1998 */         inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, bytesLeft);
/* 1999 */         inputPtr = 0;
/* 2000 */         if (inputEnd < 3) {
/*      */           break;
/*      */         }
/* 2003 */         lastFullOffset = inputEnd - 3;
/*      */       } 
/* 2005 */       if (this._outputTail > safeOutputEnd) {
/* 2006 */         _flushBuffer();
/*      */       }
/* 2008 */       int b24 = readBuffer[inputPtr++] << 8;
/* 2009 */       b24 |= readBuffer[inputPtr++] & 0xFF;
/* 2010 */       b24 = b24 << 8 | readBuffer[inputPtr++] & 0xFF;
/* 2011 */       bytesLeft -= 3;
/* 2012 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 2013 */       if (--chunksBeforeLF <= 0) {
/* 2014 */         this._outputBuffer[this._outputTail++] = 92;
/* 2015 */         this._outputBuffer[this._outputTail++] = 110;
/* 2016 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2021 */     if (bytesLeft > 0) {
/* 2022 */       inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, bytesLeft);
/* 2023 */       inputPtr = 0;
/* 2024 */       if (inputEnd > 0) {
/* 2025 */         int amount; if (this._outputTail > safeOutputEnd) {
/* 2026 */           _flushBuffer();
/*      */         }
/* 2028 */         int b24 = readBuffer[inputPtr++] << 16;
/*      */         
/* 2030 */         if (inputPtr < inputEnd) {
/* 2031 */           b24 |= (readBuffer[inputPtr] & 0xFF) << 8;
/* 2032 */           amount = 2;
/*      */         } else {
/* 2034 */           amount = 1;
/*      */         } 
/* 2036 */         this._outputTail = b64variant.encodeBase64Partial(b24, amount, this._outputBuffer, this._outputTail);
/* 2037 */         bytesLeft -= amount;
/*      */       } 
/*      */     } 
/* 2040 */     return bytesLeft;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final int _writeBinary(Base64Variant b64variant, InputStream data, byte[] readBuffer) throws IOException, JsonGenerationException {
/* 2048 */     int inputPtr = 0;
/* 2049 */     int inputEnd = 0;
/* 2050 */     int lastFullOffset = -3;
/* 2051 */     int bytesDone = 0;
/*      */ 
/*      */     
/* 2054 */     int safeOutputEnd = this._outputEnd - 6;
/* 2055 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */ 
/*      */     
/*      */     while (true) {
/* 2059 */       if (inputPtr > lastFullOffset) {
/* 2060 */         inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, readBuffer.length);
/* 2061 */         inputPtr = 0;
/* 2062 */         if (inputEnd < 3) {
/*      */           break;
/*      */         }
/* 2065 */         lastFullOffset = inputEnd - 3;
/*      */       } 
/* 2067 */       if (this._outputTail > safeOutputEnd) {
/* 2068 */         _flushBuffer();
/*      */       }
/*      */       
/* 2071 */       int b24 = readBuffer[inputPtr++] << 8;
/* 2072 */       b24 |= readBuffer[inputPtr++] & 0xFF;
/* 2073 */       b24 = b24 << 8 | readBuffer[inputPtr++] & 0xFF;
/* 2074 */       bytesDone += 3;
/* 2075 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 2076 */       if (--chunksBeforeLF <= 0) {
/* 2077 */         this._outputBuffer[this._outputTail++] = 92;
/* 2078 */         this._outputBuffer[this._outputTail++] = 110;
/* 2079 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2084 */     if (inputPtr < inputEnd) {
/* 2085 */       if (this._outputTail > safeOutputEnd) {
/* 2086 */         _flushBuffer();
/*      */       }
/* 2088 */       int b24 = readBuffer[inputPtr++] << 16;
/* 2089 */       int amount = 1;
/* 2090 */       if (inputPtr < inputEnd) {
/* 2091 */         b24 |= (readBuffer[inputPtr] & 0xFF) << 8;
/* 2092 */         amount = 2;
/*      */       } 
/* 2094 */       bytesDone += amount;
/* 2095 */       this._outputTail = b64variant.encodeBase64Partial(b24, amount, this._outputBuffer, this._outputTail);
/*      */     } 
/* 2097 */     return bytesDone;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _readMore(InputStream in, byte[] readBuffer, int inputPtr, int inputEnd, int maxRead) throws IOException {
/* 2105 */     int i = 0;
/* 2106 */     while (inputPtr < inputEnd) {
/* 2107 */       readBuffer[i++] = readBuffer[inputPtr++];
/*      */     }
/* 2109 */     inputPtr = 0;
/* 2110 */     inputEnd = i;
/* 2111 */     maxRead = Math.min(maxRead, readBuffer.length);
/*      */     
/*      */     do {
/* 2114 */       int length = maxRead - inputEnd;
/* 2115 */       if (length == 0) {
/*      */         break;
/*      */       }
/* 2118 */       int count = in.read(readBuffer, inputEnd, length);
/* 2119 */       if (count < 0) {
/* 2120 */         return inputEnd;
/*      */       }
/* 2122 */       inputEnd += count;
/* 2123 */     } while (inputEnd < 3);
/* 2124 */     return inputEnd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _outputRawMultiByteChar(int ch, char[] cbuf, int inputOffset, int inputEnd) throws IOException {
/* 2142 */     if (ch >= 55296 && 
/* 2143 */       ch <= 57343) {
/*      */       
/* 2145 */       if (inputOffset >= inputEnd || cbuf == null) {
/* 2146 */         _reportError(String.format("Split surrogate on writeRaw() input (last character): first character 0x%4x", new Object[] {
/* 2147 */                 Integer.valueOf(ch) }));
/*      */       } else {
/* 2149 */         _outputSurrogates(ch, cbuf[inputOffset]);
/*      */       } 
/* 2151 */       return inputOffset + 1;
/*      */     } 
/*      */     
/* 2154 */     byte[] bbuf = this._outputBuffer;
/* 2155 */     bbuf[this._outputTail++] = (byte)(0xE0 | ch >> 12);
/* 2156 */     bbuf[this._outputTail++] = (byte)(0x80 | ch >> 6 & 0x3F);
/* 2157 */     bbuf[this._outputTail++] = (byte)(0x80 | ch & 0x3F);
/* 2158 */     return inputOffset;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _outputSurrogates(int surr1, int surr2) throws IOException {
/* 2163 */     int c = _decodeSurrogate(surr1, surr2);
/* 2164 */     if (this._outputTail + 4 > this._outputEnd) {
/* 2165 */       _flushBuffer();
/*      */     }
/* 2167 */     byte[] bbuf = this._outputBuffer;
/* 2168 */     bbuf[this._outputTail++] = (byte)(0xF0 | c >> 18);
/* 2169 */     bbuf[this._outputTail++] = (byte)(0x80 | c >> 12 & 0x3F);
/* 2170 */     bbuf[this._outputTail++] = (byte)(0x80 | c >> 6 & 0x3F);
/* 2171 */     bbuf[this._outputTail++] = (byte)(0x80 | c & 0x3F);
/*      */   }
/*      */ 
/*      */   
/*      */   private int _outputSurrogatePair(char highSurrogate, char lowSurrogate, int outputPtr) {
/* 2176 */     int unicode = 65536 + ((highSurrogate & 0x3FF) << 10) + (lowSurrogate & 0x3FF);
/*      */ 
/*      */     
/* 2179 */     this._outputBuffer[outputPtr++] = (byte)(240 + (unicode >> 18 & 0x7));
/* 2180 */     this._outputBuffer[outputPtr++] = (byte)(128 + (unicode >> 12 & 0x3F));
/* 2181 */     this._outputBuffer[outputPtr++] = (byte)(128 + (unicode >> 6 & 0x3F));
/* 2182 */     this._outputBuffer[outputPtr++] = (byte)(128 + (unicode & 0x3F));
/*      */     
/* 2184 */     return outputPtr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _outputMultiByteChar(int ch, int outputPtr) throws IOException {
/* 2198 */     byte[] HEX_CHARS = getHexBytes();
/* 2199 */     byte[] bbuf = this._outputBuffer;
/* 2200 */     if (ch >= 55296 && ch <= 57343) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2205 */       bbuf[outputPtr++] = 92;
/* 2206 */       bbuf[outputPtr++] = 117;
/*      */       
/* 2208 */       bbuf[outputPtr++] = HEX_CHARS[ch >> 12 & 0xF];
/* 2209 */       bbuf[outputPtr++] = HEX_CHARS[ch >> 8 & 0xF];
/* 2210 */       bbuf[outputPtr++] = HEX_CHARS[ch >> 4 & 0xF];
/* 2211 */       bbuf[outputPtr++] = HEX_CHARS[ch & 0xF];
/*      */     } else {
/*      */       
/* 2214 */       bbuf[outputPtr++] = (byte)(0xE0 | ch >> 12);
/* 2215 */       bbuf[outputPtr++] = (byte)(0x80 | ch >> 6 & 0x3F);
/* 2216 */       bbuf[outputPtr++] = (byte)(0x80 | ch & 0x3F);
/*      */     } 
/* 2218 */     return outputPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void _writeNull() throws IOException {
/* 2223 */     if (this._outputTail + 4 >= this._outputEnd) {
/* 2224 */       _flushBuffer();
/*      */     }
/* 2226 */     System.arraycopy(NULL_BYTES, 0, this._outputBuffer, this._outputTail, 4);
/* 2227 */     this._outputTail += 4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _writeGenericEscape(int charToEscape, int outputPtr) throws IOException {
/* 2237 */     byte[] bbuf = this._outputBuffer;
/* 2238 */     byte[] HEX_CHARS = getHexBytes();
/* 2239 */     bbuf[outputPtr++] = 92;
/* 2240 */     bbuf[outputPtr++] = 117;
/* 2241 */     if (charToEscape > 255) {
/* 2242 */       int hi = charToEscape >> 8 & 0xFF;
/* 2243 */       bbuf[outputPtr++] = HEX_CHARS[hi >> 4];
/* 2244 */       bbuf[outputPtr++] = HEX_CHARS[hi & 0xF];
/* 2245 */       charToEscape &= 0xFF;
/*      */     } else {
/* 2247 */       bbuf[outputPtr++] = 48;
/* 2248 */       bbuf[outputPtr++] = 48;
/*      */     } 
/*      */     
/* 2251 */     bbuf[outputPtr++] = HEX_CHARS[charToEscape >> 4];
/* 2252 */     bbuf[outputPtr++] = HEX_CHARS[charToEscape & 0xF];
/* 2253 */     return outputPtr;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void _flushBuffer() throws IOException {
/* 2258 */     int len = this._outputTail;
/* 2259 */     if (len > 0) {
/* 2260 */       this._outputTail = 0;
/* 2261 */       this._outputStream.write(this._outputBuffer, 0, len);
/*      */     } 
/*      */   }
/*      */   
/*      */   private byte[] getHexBytes() {
/* 2266 */     return this._cfgWriteHexUppercase ? HEX_BYTES_UPPER : HEX_BYTES_LOWER;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean _isStartOfSurrogatePair(int ch) {
/* 2272 */     return ((ch & 0xFC00) == 55296);
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\json\UTF8JsonGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */