/*     */ package com.fasterxml.jackson.core.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParseException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ import com.fasterxml.jackson.core.io.ContentReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonReadContext
/*     */   extends JsonStreamContext
/*     */ {
/*     */   protected final JsonReadContext _parent;
/*     */   protected DupDetector _dups;
/*     */   protected JsonReadContext _child;
/*     */   protected String _currentName;
/*     */   protected Object _currentValue;
/*     */   protected int _lineNr;
/*     */   protected int _columnNr;
/*     */   
/*     */   public JsonReadContext(JsonReadContext parent, int nestingDepth, DupDetector dups, int type, int lineNr, int colNr) {
/*  71 */     this._parent = parent;
/*  72 */     this._dups = dups;
/*  73 */     this._type = type;
/*  74 */     this._lineNr = lineNr;
/*  75 */     this._columnNr = colNr;
/*  76 */     this._index = -1;
/*  77 */     this._nestingDepth = nestingDepth;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonReadContext(JsonReadContext parent, DupDetector dups, int type, int lineNr, int colNr) {
/*  84 */     this._parent = parent;
/*  85 */     this._dups = dups;
/*  86 */     this._type = type;
/*  87 */     this._lineNr = lineNr;
/*  88 */     this._columnNr = colNr;
/*  89 */     this._index = -1;
/*  90 */     this._nestingDepth = (parent == null) ? 0 : (parent._nestingDepth + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset(int type, int lineNr, int colNr) {
/* 107 */     this._type = type;
/* 108 */     this._index = -1;
/* 109 */     this._lineNr = lineNr;
/* 110 */     this._columnNr = colNr;
/* 111 */     this._currentName = null;
/* 112 */     this._currentValue = null;
/* 113 */     if (this._dups != null) {
/* 114 */       this._dups.reset();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonReadContext withDupDetector(DupDetector dups) {
/* 125 */     this._dups = dups;
/* 126 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getCurrentValue() {
/* 131 */     return this._currentValue;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCurrentValue(Object v) {
/* 136 */     this._currentValue = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonReadContext createRootContext(int lineNr, int colNr, DupDetector dups) {
/* 146 */     return new JsonReadContext(null, 0, dups, 0, lineNr, colNr);
/*     */   }
/*     */   
/*     */   public static JsonReadContext createRootContext(DupDetector dups) {
/* 150 */     return new JsonReadContext(null, 0, dups, 0, 1, 0);
/*     */   }
/*     */   
/*     */   public JsonReadContext createChildArrayContext(int lineNr, int colNr) {
/* 154 */     JsonReadContext ctxt = this._child;
/* 155 */     if (ctxt == null) {
/* 156 */       this
/* 157 */         ._child = ctxt = new JsonReadContext(this, this._nestingDepth + 1, (this._dups == null) ? null : this._dups.child(), 1, lineNr, colNr);
/*     */     } else {
/* 159 */       ctxt.reset(1, lineNr, colNr);
/*     */     } 
/* 161 */     return ctxt;
/*     */   }
/*     */   
/*     */   public JsonReadContext createChildObjectContext(int lineNr, int colNr) {
/* 165 */     JsonReadContext ctxt = this._child;
/* 166 */     if (ctxt == null) {
/* 167 */       this
/* 168 */         ._child = ctxt = new JsonReadContext(this, this._nestingDepth + 1, (this._dups == null) ? null : this._dups.child(), 2, lineNr, colNr);
/* 169 */       return ctxt;
/*     */     } 
/* 171 */     ctxt.reset(2, lineNr, colNr);
/* 172 */     return ctxt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCurrentName() {
/* 181 */     return this._currentName;
/*     */   }
/*     */   public boolean hasCurrentName() {
/* 184 */     return (this._currentName != null);
/*     */   } public JsonReadContext getParent() {
/* 186 */     return this._parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public JsonLocation startLocation(ContentReference srcRef) {
/* 191 */     long totalChars = -1L;
/* 192 */     return new JsonLocation(srcRef, totalChars, this._lineNr, this._columnNr);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonLocation getStartLocation(Object rawSrc) {
/* 198 */     return startLocation(ContentReference.rawReference(rawSrc));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonReadContext clearAndGetParent() {
/* 220 */     this._currentValue = null;
/*     */     
/* 222 */     return this._parent;
/*     */   }
/*     */   
/*     */   public DupDetector getDupDetector() {
/* 226 */     return this._dups;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean expectComma() {
/* 240 */     int ix = ++this._index;
/* 241 */     return (this._type != 0 && ix > 0);
/*     */   }
/*     */   
/*     */   public void setCurrentName(String name) throws JsonProcessingException {
/* 245 */     this._currentName = name;
/* 246 */     if (this._dups != null) _checkDup(this._dups, name); 
/*     */   }
/*     */   
/*     */   private void _checkDup(DupDetector dd, String name) throws JsonProcessingException {
/* 250 */     if (dd.isDup(name)) {
/* 251 */       Object src = dd.getSource();
/* 252 */       throw new JsonParseException((src instanceof JsonParser) ? (JsonParser)src : null, "Duplicate field '" + name + "'");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\json\JsonReadContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */