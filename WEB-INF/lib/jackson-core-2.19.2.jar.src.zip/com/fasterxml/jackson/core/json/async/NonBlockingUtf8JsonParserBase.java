/*      */ package com.fasterxml.jackson.core.json.async;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.json.JsonReadFeature;
/*      */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*      */ import com.fasterxml.jackson.core.util.InternalJacksonUtil;
/*      */ import com.fasterxml.jackson.core.util.VersionUtil;
/*      */ import java.io.IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class NonBlockingUtf8JsonParserBase
/*      */   extends NonBlockingJsonParserBase
/*      */ {
/*   26 */   private static final int FEAT_MASK_TRAILING_COMMA = JsonParser.Feature.ALLOW_TRAILING_COMMA.getMask();
/*      */   
/*   28 */   private static final int FEAT_MASK_LEADING_ZEROS = JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS.getMask();
/*      */   
/*   30 */   private static final int FEAT_MASK_ALLOW_MISSING = JsonParser.Feature.ALLOW_MISSING_VALUES.getMask();
/*   31 */   private static final int FEAT_MASK_ALLOW_SINGLE_QUOTES = JsonParser.Feature.ALLOW_SINGLE_QUOTES.getMask();
/*   32 */   private static final int FEAT_MASK_ALLOW_UNQUOTED_NAMES = JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES.getMask();
/*   33 */   private static final int FEAT_MASK_ALLOW_JAVA_COMMENTS = JsonParser.Feature.ALLOW_COMMENTS.getMask();
/*   34 */   private static final int FEAT_MASK_ALLOW_YAML_COMMENTS = JsonParser.Feature.ALLOW_YAML_COMMENTS.getMask();
/*      */ 
/*      */   
/*   37 */   private static final int[] _icUTF8 = CharTypes.getInputCodeUtf8();
/*      */ 
/*      */ 
/*      */   
/*   41 */   protected static final int[] _icLatin1 = CharTypes.getInputCodeLatin1();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _origBufferLen;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected NonBlockingUtf8JsonParserBase(IOContext ctxt, int parserFeatures, ByteQuadsCanonicalizer sym) {
/*   66 */     super(ctxt, parserFeatures, sym);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean needMoreInput() {
/*   76 */     return (this._inputPtr >= this._inputEnd && !this._endOfInput);
/*      */   }
/*      */   
/*      */   public void endOfInput() {
/*   80 */     this._endOfInput = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _decodeEscaped() throws IOException {
/*  104 */     VersionUtil.throwInternal();
/*  105 */     return ' ';
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken nextToken() throws IOException {
/*  119 */     if (this._inputPtr >= this._inputEnd) {
/*  120 */       if (this._closed) {
/*  121 */         return null;
/*      */       }
/*      */       
/*  124 */       if (this._endOfInput) {
/*      */ 
/*      */         
/*  127 */         if (this._currToken == JsonToken.NOT_AVAILABLE) {
/*  128 */           return _finishTokenWithEOF();
/*      */         }
/*  130 */         return _eofAsNextToken();
/*      */       } 
/*  132 */       return JsonToken.NOT_AVAILABLE;
/*      */     } 
/*      */     
/*  135 */     if (this._currToken == JsonToken.NOT_AVAILABLE) {
/*  136 */       return _finishToken();
/*      */     }
/*      */ 
/*      */     
/*  140 */     this._numTypesValid = 0;
/*  141 */     this._tokenInputTotal = this._currInputProcessed + (this._inputPtr - this._currBufferStart);
/*      */ 
/*      */     
/*  144 */     this._binaryValue = null;
/*  145 */     int ch = getNextUnsignedByteFromBuffer();
/*      */     
/*  147 */     switch (this._majorState) {
/*      */       case 0:
/*  149 */         return _startDocument(ch);
/*      */       
/*      */       case 1:
/*  152 */         return _startValue(ch);
/*      */       
/*      */       case 2:
/*  155 */         return _startFieldName(ch);
/*      */       case 3:
/*  157 */         return _startFieldNameAfterComma(ch);
/*      */       
/*      */       case 4:
/*  160 */         return _startValueExpectColon(ch);
/*      */       
/*      */       case 5:
/*  163 */         return _startValue(ch);
/*      */       
/*      */       case 6:
/*  166 */         return _startValueExpectComma(ch);
/*      */     } 
/*      */ 
/*      */     
/*  170 */     VersionUtil.throwInternal();
/*  171 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract byte getNextSignedByteFromBuffer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract int getNextUnsignedByteFromBuffer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract byte getByteFromBuffer(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _finishToken() throws IOException {
/*      */     int c;
/*  205 */     switch (this._minorState) {
/*      */       case 1:
/*  207 */         return _finishBOM(this._pending32);
/*      */       case 4:
/*  209 */         return _startFieldName(getNextUnsignedByteFromBuffer());
/*      */       case 5:
/*  211 */         return _startFieldNameAfterComma(getNextUnsignedByteFromBuffer());
/*      */ 
/*      */       
/*      */       case 7:
/*  215 */         return _parseEscapedName(this._quadLength, this._pending32, this._pendingBytes);
/*      */       case 8:
/*  217 */         return _finishFieldWithEscape();
/*      */       case 9:
/*  219 */         return _finishAposName(this._quadLength, this._pending32, this._pendingBytes);
/*      */       case 10:
/*  221 */         return _finishUnquotedName(this._quadLength, this._pending32, this._pendingBytes);
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*  226 */         return _startValue(getNextUnsignedByteFromBuffer());
/*      */       case 15:
/*  228 */         return _startValueAfterComma(getNextUnsignedByteFromBuffer());
/*      */       case 13:
/*  230 */         return _startValueExpectComma(getNextUnsignedByteFromBuffer());
/*      */       case 14:
/*  232 */         return _startValueExpectColon(getNextUnsignedByteFromBuffer());
/*      */       
/*      */       case 16:
/*  235 */         return _finishKeywordToken("null", this._pending32, JsonToken.VALUE_NULL);
/*      */       case 17:
/*  237 */         return _finishKeywordToken("true", this._pending32, JsonToken.VALUE_TRUE);
/*      */       case 18:
/*  239 */         return _finishKeywordToken("false", this._pending32, JsonToken.VALUE_FALSE);
/*      */       case 19:
/*  241 */         return _finishNonStdToken(this._nonStdTokenType, this._pending32);
/*      */       
/*      */       case 22:
/*  244 */         return _finishNumberPlus(getNextUnsignedByteFromBuffer());
/*      */       case 23:
/*  246 */         return _finishNumberMinus(getNextUnsignedByteFromBuffer());
/*      */       case 24:
/*  248 */         return _finishNumberLeadingZeroes();
/*      */       case 25:
/*  250 */         return _finishNumberLeadingNegZeroes();
/*      */       case 26:
/*  252 */         return _finishNumberIntegralPart(this._textBuffer.getBufferWithoutReset(), this._textBuffer
/*  253 */             .getCurrentSegmentSize());
/*      */       case 30:
/*  255 */         return _finishFloatFraction();
/*      */       case 31:
/*  257 */         return _finishFloatExponent(true, getNextUnsignedByteFromBuffer());
/*      */       case 32:
/*  259 */         return _finishFloatExponent(false, getNextUnsignedByteFromBuffer());
/*      */       
/*      */       case 40:
/*  262 */         return _finishRegularString();
/*      */       case 42:
/*  264 */         this._textBuffer.append((char)_decodeUTF8_2(this._pending32, getNextSignedByteFromBuffer()));
/*  265 */         if (this._minorStateAfterSplit == 45) {
/*  266 */           return _finishAposString();
/*      */         }
/*  268 */         return _finishRegularString();
/*      */       case 43:
/*  270 */         if (!_decodeSplitUTF8_3(this._pending32, this._pendingBytes, getNextSignedByteFromBuffer())) {
/*  271 */           return JsonToken.NOT_AVAILABLE;
/*      */         }
/*  273 */         if (this._minorStateAfterSplit == 45) {
/*  274 */           return _finishAposString();
/*      */         }
/*  276 */         return _finishRegularString();
/*      */       case 44:
/*  278 */         if (!_decodeSplitUTF8_4(this._pending32, this._pendingBytes, getNextSignedByteFromBuffer())) {
/*  279 */           return JsonToken.NOT_AVAILABLE;
/*      */         }
/*  281 */         if (this._minorStateAfterSplit == 45) {
/*  282 */           return _finishAposString();
/*      */         }
/*  284 */         return _finishRegularString();
/*      */ 
/*      */       
/*      */       case 41:
/*  288 */         c = _decodeSplitEscaped(this._quoted32, this._quotedDigits);
/*  289 */         if (c < 0) {
/*  290 */           return JsonToken.NOT_AVAILABLE;
/*      */         }
/*  292 */         this._textBuffer.append((char)c);
/*      */         
/*  294 */         if (this._minorStateAfterSplit == 45) {
/*  295 */           return _finishAposString();
/*      */         }
/*  297 */         return _finishRegularString();
/*      */       
/*      */       case 45:
/*  300 */         return _finishAposString();
/*      */       
/*      */       case 50:
/*  303 */         return _finishErrorToken();
/*      */ 
/*      */ 
/*      */       
/*      */       case 51:
/*  308 */         return _startSlashComment(this._pending32);
/*      */       case 52:
/*  310 */         return _finishCComment(this._pending32, true);
/*      */       case 53:
/*  312 */         return _finishCComment(this._pending32, false);
/*      */       case 54:
/*  314 */         return _finishCppComment(this._pending32);
/*      */       case 55:
/*  316 */         return _finishHashComment(this._pending32);
/*      */     } 
/*  318 */     VersionUtil.throwInternal();
/*  319 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _finishTokenWithEOF() throws IOException {
/*      */     int len;
/*  335 */     JsonToken t = this._currToken;
/*  336 */     switch (this._minorState) {
/*      */       case 3:
/*  338 */         return _eofAsNextToken();
/*      */       case 12:
/*  340 */         return _eofAsNextToken();
/*      */ 
/*      */       
/*      */       case 16:
/*  344 */         return _finishKeywordTokenWithEOF("null", this._pending32, JsonToken.VALUE_NULL);
/*      */       case 17:
/*  346 */         return _finishKeywordTokenWithEOF("true", this._pending32, JsonToken.VALUE_TRUE);
/*      */       case 18:
/*  348 */         return _finishKeywordTokenWithEOF("false", this._pending32, JsonToken.VALUE_FALSE);
/*      */       case 19:
/*  350 */         return _finishNonStdTokenWithEOF(this._nonStdTokenType, this._pending32);
/*      */       case 50:
/*  352 */         return _finishErrorTokenWithEOF();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*      */       case 25:
/*  359 */         return _valueCompleteInt(0, "0");
/*      */ 
/*      */       
/*      */       case 26:
/*  363 */         len = this._textBuffer.getCurrentSegmentSize();
/*  364 */         if (this._numberNegative) {
/*  365 */           len--;
/*      */         }
/*  367 */         this._intLength = len;
/*      */         
/*  369 */         return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */       
/*      */       case 30:
/*  372 */         this._expLength = 0;
/*      */       
/*      */       case 32:
/*  375 */         return _valueComplete(JsonToken.VALUE_NUMBER_FLOAT);
/*      */       
/*      */       case 31:
/*  378 */         _reportInvalidEOF(": was expecting fraction after exponent marker", JsonToken.VALUE_NUMBER_FLOAT);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 52:
/*      */       case 53:
/*  386 */         _reportInvalidEOF(": was expecting closing '*/' for comment", JsonToken.NOT_AVAILABLE);
/*      */ 
/*      */       
/*      */       case 54:
/*      */       case 55:
/*  391 */         return _eofAsNextToken();
/*      */     } 
/*      */ 
/*      */     
/*  395 */     _reportInvalidEOF(": was expecting rest of token (internal state: " + this._minorState + ")", this._currToken);
/*  396 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startDocument(int ch) throws IOException {
/*  407 */     ch &= 0xFF;
/*      */ 
/*      */     
/*  410 */     if (ch == 239 && this._minorState != 1) {
/*  411 */       return _finishBOM(1);
/*      */     }
/*      */ 
/*      */     
/*  415 */     while (ch <= 32) {
/*  416 */       if (ch != 32) {
/*  417 */         if (ch == 10) {
/*  418 */           this._currInputRow++;
/*  419 */           this._currInputRowStart = this._inputPtr;
/*  420 */         } else if (ch == 13) {
/*  421 */           this._currInputRowAlt++;
/*  422 */           this._currInputRowStart = this._inputPtr;
/*  423 */         } else if (ch != 9) {
/*  424 */           _throwInvalidSpace(ch);
/*      */         } 
/*      */       }
/*  427 */       if (this._inputPtr >= this._inputEnd) {
/*  428 */         this._minorState = 3;
/*  429 */         if (this._closed) {
/*  430 */           return null;
/*      */         }
/*      */         
/*  433 */         if (this._endOfInput) {
/*  434 */           return _eofAsNextToken();
/*      */         }
/*  436 */         return JsonToken.NOT_AVAILABLE;
/*      */       } 
/*  438 */       ch = getNextUnsignedByteFromBuffer();
/*      */     } 
/*  440 */     return _startValue(ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _finishBOM(int bytesHandled) throws IOException {
/*  449 */     while (this._inputPtr < this._inputEnd) {
/*  450 */       int ch = getNextUnsignedByteFromBuffer();
/*  451 */       switch (bytesHandled) {
/*      */ 
/*      */         
/*      */         case 3:
/*  455 */           this._currInputProcessed -= 3L;
/*  456 */           return _startDocument(ch);
/*      */         case 2:
/*  458 */           if (ch != 191) {
/*  459 */             _reportError("Unexpected byte 0x%02x following 0xEF 0xBB; should get 0xBF as third byte of UTF-8 BOM", Integer.valueOf(ch));
/*      */           }
/*      */           break;
/*      */         case 1:
/*  463 */           if (ch != 187) {
/*  464 */             _reportError("Unexpected byte 0x%02x following 0xEF; should get 0xBB as second byte UTF-8 BOM", Integer.valueOf(ch));
/*      */           }
/*      */           break;
/*      */       } 
/*  468 */       bytesHandled++;
/*      */     } 
/*  470 */     this._pending32 = bytesHandled;
/*  471 */     this._minorState = 1;
/*  472 */     return _updateTokenToNA();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startFieldName(int ch) throws IOException {
/*  488 */     if (ch <= 32) {
/*  489 */       ch = _skipWS(ch);
/*  490 */       if (ch <= 0) {
/*  491 */         this._minorState = 4;
/*  492 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  495 */     _updateTokenLocation();
/*  496 */     if (ch != 34) {
/*  497 */       if (ch == 125) {
/*  498 */         return _closeObjectScope();
/*      */       }
/*  500 */       return _handleOddName(ch);
/*      */     } 
/*      */     
/*  503 */     if (this._inputPtr + 13 <= this._inputEnd) {
/*  504 */       String n = _fastParseName();
/*  505 */       if (n != null) {
/*  506 */         return _fieldComplete(n);
/*      */       }
/*      */     } 
/*  509 */     return _parseEscapedName(0, 0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startFieldNameAfterComma(int ch) throws IOException {
/*  515 */     if (ch <= 32) {
/*  516 */       ch = _skipWS(ch);
/*  517 */       if (ch <= 0) {
/*  518 */         this._minorState = 5;
/*  519 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  522 */     if (ch != 44) {
/*  523 */       if (ch == 125) {
/*  524 */         return _closeObjectScope();
/*      */       }
/*  526 */       if (ch == 35) {
/*  527 */         return _finishHashComment(5);
/*      */       }
/*  529 */       if (ch == 47) {
/*  530 */         return _startSlashComment(5);
/*      */       }
/*  532 */       _reportUnexpectedChar(ch, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */     } 
/*  534 */     int ptr = this._inputPtr;
/*  535 */     if (ptr >= this._inputEnd) {
/*  536 */       this._minorState = 4;
/*  537 */       return _updateTokenToNA();
/*      */     } 
/*  539 */     ch = getByteFromBuffer(ptr);
/*  540 */     this._inputPtr = ptr + 1;
/*  541 */     if (ch <= 32) {
/*  542 */       ch = _skipWS(ch);
/*  543 */       if (ch <= 0) {
/*  544 */         this._minorState = 4;
/*  545 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  548 */     _updateTokenLocation();
/*  549 */     if (ch != 34) {
/*  550 */       if (ch == 125 && (
/*  551 */         this._features & FEAT_MASK_TRAILING_COMMA) != 0) {
/*  552 */         return _closeObjectScope();
/*      */       }
/*      */       
/*  555 */       return _handleOddName(ch);
/*      */     } 
/*      */     
/*  558 */     if (this._inputPtr + 13 <= this._inputEnd) {
/*  559 */       String n = _fastParseName();
/*  560 */       if (n != null) {
/*  561 */         return _fieldComplete(n);
/*      */       }
/*      */     } 
/*  564 */     return _parseEscapedName(0, 0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startValue(int ch) throws IOException {
/*  581 */     if (ch <= 32) {
/*  582 */       ch = _skipWS(ch);
/*  583 */       if (ch <= 0) {
/*  584 */         this._minorState = 12;
/*  585 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  588 */     _updateTokenLocation();
/*      */     
/*  590 */     this._parsingContext.expectComma();
/*      */     
/*  592 */     if (ch == 34) {
/*  593 */       return _startString();
/*      */     }
/*  595 */     switch (ch) {
/*      */       case 35:
/*  597 */         return _finishHashComment(12);
/*      */       case 43:
/*  599 */         return _startPositiveNumber();
/*      */       case 45:
/*  601 */         return _startNegativeNumber();
/*      */       case 47:
/*  603 */         return _startSlashComment(12);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 46:
/*  610 */         if (isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/*  611 */           return _startFloatThatStartsWithPeriod();
/*      */         }
/*      */         break;
/*      */       
/*      */       case 48:
/*  616 */         return _startNumberLeadingZero();
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  626 */         return _startPositiveNumber(ch);
/*      */       case 102:
/*  628 */         return _startFalseToken();
/*      */       case 110:
/*  630 */         return _startNullToken();
/*      */       case 116:
/*  632 */         return _startTrueToken();
/*      */       case 91:
/*  634 */         return _startArrayScope();
/*      */       case 93:
/*  636 */         return _closeArrayScope();
/*      */       case 123:
/*  638 */         return _startObjectScope();
/*      */       case 125:
/*  640 */         return _closeObjectScope();
/*      */     } 
/*      */     
/*  643 */     return _startUnexpectedValue(false, ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startValueExpectComma(int ch) throws IOException {
/*  651 */     if (ch <= 32) {
/*  652 */       ch = _skipWS(ch);
/*  653 */       if (ch <= 0) {
/*  654 */         this._minorState = 13;
/*  655 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  658 */     if (ch != 44) {
/*  659 */       if (ch == 93) {
/*  660 */         return _closeArrayScope();
/*      */       }
/*  662 */       if (ch == 125) {
/*  663 */         return _closeObjectScope();
/*      */       }
/*  665 */       if (ch == 47) {
/*  666 */         return _startSlashComment(13);
/*      */       }
/*  668 */       if (ch == 35) {
/*  669 */         return _finishHashComment(13);
/*      */       }
/*  671 */       _reportUnexpectedChar(ch, "was expecting comma to separate " + this._parsingContext.typeDesc() + " entries");
/*      */     } 
/*      */ 
/*      */     
/*  675 */     this._parsingContext.expectComma();
/*      */     
/*  677 */     int ptr = this._inputPtr;
/*  678 */     if (ptr >= this._inputEnd) {
/*  679 */       this._minorState = 15;
/*  680 */       return _updateTokenToNA();
/*      */     } 
/*  682 */     ch = getByteFromBuffer(ptr);
/*  683 */     this._inputPtr = ptr + 1;
/*  684 */     if (ch <= 32) {
/*  685 */       ch = _skipWS(ch);
/*  686 */       if (ch <= 0) {
/*  687 */         this._minorState = 15;
/*  688 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  691 */     _updateTokenLocation();
/*  692 */     if (ch == 34) {
/*  693 */       return _startString();
/*      */     }
/*  695 */     switch (ch) {
/*      */       case 35:
/*  697 */         return _finishHashComment(15);
/*      */       case 43:
/*  699 */         return _startPositiveNumber();
/*      */       case 45:
/*  701 */         return _startNegativeNumber();
/*      */       case 47:
/*  703 */         return _startSlashComment(15);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 48:
/*  709 */         return _startNumberLeadingZero();
/*      */       case 49: case 50: case 51: case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  716 */         return _startPositiveNumber(ch);
/*      */       case 102:
/*  718 */         return _startFalseToken();
/*      */       case 110:
/*  720 */         return _startNullToken();
/*      */       case 116:
/*  722 */         return _startTrueToken();
/*      */       case 91:
/*  724 */         return _startArrayScope();
/*      */       
/*      */       case 93:
/*  727 */         if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0) {
/*  728 */           return _closeArrayScope();
/*      */         }
/*      */         break;
/*      */       case 123:
/*  732 */         return _startObjectScope();
/*      */       
/*      */       case 125:
/*  735 */         if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0) {
/*  736 */           return _closeObjectScope();
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  741 */     return _startUnexpectedValue(true, ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startValueExpectColon(int ch) throws IOException {
/*  750 */     if (ch <= 32) {
/*  751 */       ch = _skipWS(ch);
/*  752 */       if (ch <= 0) {
/*  753 */         this._minorState = 14;
/*  754 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  757 */     if (ch != 58) {
/*  758 */       if (ch == 47) {
/*  759 */         return _startSlashComment(14);
/*      */       }
/*  761 */       if (ch == 35) {
/*  762 */         return _finishHashComment(14);
/*      */       }
/*      */       
/*  765 */       _reportUnexpectedChar(ch, "was expecting a colon to separate field name and value");
/*      */     } 
/*  767 */     int ptr = this._inputPtr;
/*  768 */     if (ptr >= this._inputEnd) {
/*  769 */       this._minorState = 12;
/*  770 */       return _updateTokenToNA();
/*      */     } 
/*  772 */     ch = getByteFromBuffer(ptr);
/*  773 */     this._inputPtr = ptr + 1;
/*  774 */     if (ch <= 32) {
/*  775 */       ch = _skipWS(ch);
/*  776 */       if (ch <= 0) {
/*  777 */         this._minorState = 12;
/*  778 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  781 */     _updateTokenLocation();
/*  782 */     if (ch == 34) {
/*  783 */       return _startString();
/*      */     }
/*  785 */     switch (ch) {
/*      */       case 35:
/*  787 */         return _finishHashComment(12);
/*      */       case 43:
/*  789 */         return _startPositiveNumber();
/*      */       case 45:
/*  791 */         return _startNegativeNumber();
/*      */       case 47:
/*  793 */         return _startSlashComment(12);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 48:
/*  799 */         return _startNumberLeadingZero();
/*      */       case 49: case 50: case 51: case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  806 */         return _startPositiveNumber(ch);
/*      */       case 102:
/*  808 */         return _startFalseToken();
/*      */       case 110:
/*  810 */         return _startNullToken();
/*      */       case 116:
/*  812 */         return _startTrueToken();
/*      */       case 91:
/*  814 */         return _startArrayScope();
/*      */       case 123:
/*  816 */         return _startObjectScope();
/*      */     } 
/*      */     
/*  819 */     return _startUnexpectedValue(false, ch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startValueAfterComma(int ch) throws IOException {
/*  826 */     if (ch <= 32) {
/*  827 */       ch = _skipWS(ch);
/*  828 */       if (ch <= 0) {
/*  829 */         this._minorState = 15;
/*  830 */         return this._currToken;
/*      */       } 
/*      */     } 
/*  833 */     _updateTokenLocation();
/*  834 */     if (ch == 34) {
/*  835 */       return _startString();
/*      */     }
/*  837 */     switch (ch) {
/*      */       case 35:
/*  839 */         return _finishHashComment(15);
/*      */       case 43:
/*  841 */         return _startPositiveNumber();
/*      */       case 45:
/*  843 */         return _startNegativeNumber();
/*      */       case 47:
/*  845 */         return _startSlashComment(15);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 48:
/*  851 */         return _startNumberLeadingZero();
/*      */       case 49:
/*      */       case 50:
/*      */       case 51:
/*      */       case 52:
/*      */       case 53:
/*      */       case 54:
/*      */       case 55:
/*      */       case 56:
/*      */       case 57:
/*  861 */         return _startPositiveNumber(ch);
/*      */       case 102:
/*  863 */         return _startFalseToken();
/*      */       case 110:
/*  865 */         return _startNullToken();
/*      */       case 116:
/*  867 */         return _startTrueToken();
/*      */       case 91:
/*  869 */         return _startArrayScope();
/*      */       
/*      */       case 93:
/*  872 */         if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0) {
/*  873 */           return _closeArrayScope();
/*      */         }
/*      */         break;
/*      */       case 123:
/*  877 */         return _startObjectScope();
/*      */       
/*      */       case 125:
/*  880 */         if ((this._features & FEAT_MASK_TRAILING_COMMA) != 0) {
/*  881 */           return _closeObjectScope();
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  886 */     return _startUnexpectedValue(true, ch);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startUnexpectedValue(boolean leadingComma, int ch) throws IOException {
/*  891 */     switch (ch) {
/*      */       case 93:
/*  893 */         if (!this._parsingContext.inArray()) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 44:
/*  902 */         if (!this._parsingContext.inRoot() && (
/*  903 */           this._features & FEAT_MASK_ALLOW_MISSING) != 0) {
/*  904 */           this._inputPtr--;
/*  905 */           return _valueComplete(JsonToken.VALUE_NULL);
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 39:
/*  914 */         if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/*  915 */           return _startAposString();
/*      */         }
/*      */         break;
/*      */       case 43:
/*  919 */         return _finishNonStdToken(2, 1);
/*      */       case 78:
/*  921 */         return _finishNonStdToken(0, 1);
/*      */       case 73:
/*  923 */         return _finishNonStdToken(1, 1);
/*      */     } 
/*      */     
/*  926 */     _reportUnexpectedChar(ch, "expected a valid value " + _validJsonValueList());
/*  927 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _skipWS(int ch) throws IOException {
/*      */     while (true) {
/*  939 */       if (ch != 32) {
/*  940 */         if (ch == 10) {
/*  941 */           this._currInputRow++;
/*  942 */           this._currInputRowStart = this._inputPtr;
/*  943 */         } else if (ch == 13) {
/*  944 */           this._currInputRowAlt++;
/*  945 */           this._currInputRowStart = this._inputPtr;
/*  946 */         } else if (ch != 9 && !_isAllowedCtrlCharRS(ch)) {
/*  947 */           _throwInvalidSpace(ch);
/*      */         } 
/*      */       }
/*  950 */       if (this._inputPtr >= this._inputEnd) {
/*  951 */         _updateTokenToNA();
/*  952 */         return 0;
/*      */       } 
/*  954 */       ch = getNextUnsignedByteFromBuffer();
/*  955 */       if (ch > 32)
/*  956 */         return ch; 
/*      */     } 
/*      */   }
/*      */   
/*      */   private final JsonToken _startSlashComment(int fromMinorState) throws IOException {
/*  961 */     if ((this._features & FEAT_MASK_ALLOW_JAVA_COMMENTS) == 0) {
/*  962 */       _reportUnexpectedChar(47, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_COMMENTS' not enabled for parser)");
/*      */     }
/*      */ 
/*      */     
/*  966 */     if (this._inputPtr >= this._inputEnd) {
/*  967 */       this._pending32 = fromMinorState;
/*  968 */       this._minorState = 51;
/*  969 */       return _updateTokenToNA();
/*      */     } 
/*  971 */     int ch = getNextSignedByteFromBuffer();
/*  972 */     if (ch == 42) {
/*  973 */       return _finishCComment(fromMinorState, false);
/*      */     }
/*  975 */     if (ch == 47) {
/*  976 */       return _finishCppComment(fromMinorState);
/*      */     }
/*  978 */     _reportUnexpectedChar(ch & 0xFF, "was expecting either '*' or '/' for a comment");
/*  979 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _finishHashComment(int fromMinorState) throws IOException {
/*  985 */     if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) == 0) {
/*  986 */       _reportUnexpectedChar(35, "maybe a (non-standard) comment? (not recognized as one since Feature 'ALLOW_YAML_COMMENTS' not enabled for parser)");
/*      */     }
/*      */     while (true) {
/*  989 */       if (this._inputPtr >= this._inputEnd) {
/*  990 */         this._minorState = 55;
/*  991 */         this._pending32 = fromMinorState;
/*  992 */         return _updateTokenToNA();
/*      */       } 
/*  994 */       int ch = getNextUnsignedByteFromBuffer();
/*  995 */       if (ch < 32) {
/*  996 */         if (ch == 10) {
/*  997 */           this._currInputRow++;
/*  998 */           this._currInputRowStart = this._inputPtr; break;
/*      */         } 
/* 1000 */         if (ch == 13) {
/* 1001 */           this._currInputRowAlt++;
/* 1002 */           this._currInputRowStart = this._inputPtr; break;
/*      */         } 
/* 1004 */         if (ch != 9) {
/* 1005 */           _throwInvalidSpace(ch);
/*      */         }
/*      */       } 
/*      */     } 
/* 1009 */     return _startAfterComment(fromMinorState);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _finishCppComment(int fromMinorState) throws IOException {
/*      */     while (true) {
/* 1015 */       if (this._inputPtr >= this._inputEnd) {
/* 1016 */         this._minorState = 54;
/* 1017 */         this._pending32 = fromMinorState;
/* 1018 */         return _updateTokenToNA();
/*      */       } 
/* 1020 */       int ch = getNextUnsignedByteFromBuffer();
/* 1021 */       if (ch < 32) {
/* 1022 */         if (ch == 10) {
/* 1023 */           this._currInputRow++;
/* 1024 */           this._currInputRowStart = this._inputPtr; break;
/*      */         } 
/* 1026 */         if (ch == 13) {
/* 1027 */           this._currInputRowAlt++;
/* 1028 */           this._currInputRowStart = this._inputPtr; break;
/*      */         } 
/* 1030 */         if (ch != 9) {
/* 1031 */           _throwInvalidSpace(ch);
/*      */         }
/*      */       } 
/*      */     } 
/* 1035 */     return _startAfterComment(fromMinorState);
/*      */   }
/*      */ 
/*      */   
/*      */   private final JsonToken _finishCComment(int fromMinorState, boolean gotStar) throws IOException {
/*      */     while (true) {
/* 1041 */       if (this._inputPtr >= this._inputEnd) {
/* 1042 */         this._minorState = gotStar ? 52 : 53;
/* 1043 */         this._pending32 = fromMinorState;
/* 1044 */         return _updateTokenToNA();
/*      */       } 
/* 1046 */       int ch = getNextUnsignedByteFromBuffer();
/* 1047 */       if (ch < 32)
/* 1048 */       { if (ch == 10) {
/* 1049 */           this._currInputRow++;
/* 1050 */           this._currInputRowStart = this._inputPtr;
/* 1051 */         } else if (ch == 13) {
/* 1052 */           this._currInputRowAlt++;
/* 1053 */           this._currInputRowStart = this._inputPtr;
/* 1054 */         } else if (ch != 9) {
/* 1055 */           _throwInvalidSpace(ch);
/*      */         }  }
/* 1057 */       else { if (ch == 42) {
/* 1058 */           gotStar = true; continue;
/*      */         } 
/* 1060 */         if (ch == 47 && 
/* 1061 */           gotStar) {
/*      */           break;
/*      */         } }
/*      */       
/* 1065 */       gotStar = false;
/*      */     } 
/* 1067 */     return _startAfterComment(fromMinorState);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _startAfterComment(int fromMinorState) throws IOException {
/* 1073 */     if (this._inputPtr >= this._inputEnd) {
/* 1074 */       this._minorState = fromMinorState;
/* 1075 */       return _updateTokenToNA();
/*      */     } 
/* 1077 */     int ch = getNextUnsignedByteFromBuffer();
/* 1078 */     switch (fromMinorState) {
/*      */       case 4:
/* 1080 */         return _startFieldName(ch);
/*      */       case 5:
/* 1082 */         return _startFieldNameAfterComma(ch);
/*      */       case 12:
/* 1084 */         return _startValue(ch);
/*      */       case 13:
/* 1086 */         return _startValueExpectComma(ch);
/*      */       case 14:
/* 1088 */         return _startValueExpectColon(ch);
/*      */       case 15:
/* 1090 */         return _startValueAfterComma(ch);
/*      */     } 
/*      */     
/* 1093 */     VersionUtil.throwInternal();
/* 1094 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _startFalseToken() throws IOException {
/* 1105 */     int ptr = this._inputPtr;
/* 1106 */     if (ptr + 4 < this._inputEnd && 
/* 1107 */       getByteFromBuffer(ptr++) == 97 && 
/* 1108 */       getByteFromBuffer(ptr++) == 108 && 
/* 1109 */       getByteFromBuffer(ptr++) == 115 && 
/* 1110 */       getByteFromBuffer(ptr++) == 101) {
/* 1111 */       int ch = getByteFromBuffer(ptr) & 0xFF;
/* 1112 */       if (ch < 48 || (ch | 0x20) == 125) {
/* 1113 */         this._inputPtr = ptr;
/* 1114 */         return _valueComplete(JsonToken.VALUE_FALSE);
/*      */       } 
/*      */     } 
/*      */     
/* 1118 */     this._minorState = 18;
/* 1119 */     return _finishKeywordToken("false", 1, JsonToken.VALUE_FALSE);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startTrueToken() throws IOException {
/* 1124 */     int ptr = this._inputPtr;
/* 1125 */     if (ptr + 3 < this._inputEnd && 
/* 1126 */       getByteFromBuffer(ptr++) == 114 && 
/* 1127 */       getByteFromBuffer(ptr++) == 117 && 
/* 1128 */       getByteFromBuffer(ptr++) == 101) {
/* 1129 */       int ch = getByteFromBuffer(ptr) & 0xFF;
/* 1130 */       if (ch < 48 || (ch | 0x20) == 125) {
/* 1131 */         this._inputPtr = ptr;
/* 1132 */         return _valueComplete(JsonToken.VALUE_TRUE);
/*      */       } 
/*      */     } 
/*      */     
/* 1136 */     this._minorState = 17;
/* 1137 */     return _finishKeywordToken("true", 1, JsonToken.VALUE_TRUE);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startNullToken() throws IOException {
/* 1142 */     int ptr = this._inputPtr;
/* 1143 */     if (ptr + 3 < this._inputEnd && 
/* 1144 */       getByteFromBuffer(ptr++) == 117 && 
/* 1145 */       getByteFromBuffer(ptr++) == 108 && 
/* 1146 */       getByteFromBuffer(ptr++) == 108) {
/* 1147 */       int ch = getByteFromBuffer(ptr) & 0xFF;
/* 1148 */       if (ch < 48 || (ch | 0x20) == 125) {
/* 1149 */         this._inputPtr = ptr;
/* 1150 */         return _valueComplete(JsonToken.VALUE_NULL);
/*      */       } 
/*      */     } 
/*      */     
/* 1154 */     this._minorState = 16;
/* 1155 */     return _finishKeywordToken("null", 1, JsonToken.VALUE_NULL);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _finishKeywordToken(String expToken, int matched, JsonToken result) throws IOException {
/* 1161 */     int end = expToken.length();
/*      */     
/*      */     while (true) {
/* 1164 */       if (this._inputPtr >= this._inputEnd) {
/* 1165 */         this._pending32 = matched;
/* 1166 */         return _updateTokenToNA();
/*      */       } 
/* 1168 */       int ch = getByteFromBuffer(this._inputPtr);
/* 1169 */       if (matched == end) {
/* 1170 */         if (ch < 48 || (ch | 0x20) == 125) {
/* 1171 */           return _valueComplete(result);
/*      */         }
/*      */         break;
/*      */       } 
/* 1175 */       if (ch != expToken.charAt(matched)) {
/*      */         break;
/*      */       }
/* 1178 */       matched++;
/* 1179 */       this._inputPtr++;
/*      */     } 
/* 1181 */     this._minorState = 50;
/* 1182 */     this._textBuffer.resetWithCopy(expToken, 0, matched);
/* 1183 */     return _finishErrorToken();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _finishKeywordTokenWithEOF(String expToken, int matched, JsonToken result) throws IOException {
/* 1189 */     if (matched == expToken.length()) {
/* 1190 */       return _updateToken(result);
/*      */     }
/* 1192 */     this._textBuffer.resetWithCopy(expToken, 0, matched);
/* 1193 */     return _finishErrorTokenWithEOF();
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNonStdToken(int type, int matched) throws IOException {
/* 1198 */     String expToken = _nonStdToken(type);
/* 1199 */     int end = expToken.length();
/*      */     
/*      */     while (true) {
/* 1202 */       if (this._inputPtr >= this._inputEnd) {
/* 1203 */         this._nonStdTokenType = type;
/* 1204 */         this._pending32 = matched;
/* 1205 */         this._minorState = 19;
/* 1206 */         return _updateTokenToNA();
/*      */       } 
/* 1208 */       int ch = getByteFromBuffer(this._inputPtr);
/* 1209 */       if (matched == end) {
/* 1210 */         if (ch < 48 || (ch | 0x20) == 125) {
/* 1211 */           return _valueNonStdNumberComplete(type);
/*      */         }
/*      */         break;
/*      */       } 
/* 1215 */       if (ch != expToken.charAt(matched)) {
/*      */         break;
/*      */       }
/* 1218 */       matched++;
/* 1219 */       this._inputPtr++;
/*      */     } 
/* 1221 */     this._minorState = 50;
/* 1222 */     this._textBuffer.resetWithCopy(expToken, 0, matched);
/* 1223 */     return _finishErrorToken();
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNonStdTokenWithEOF(int type, int matched) throws IOException {
/* 1228 */     String expToken = _nonStdToken(type);
/* 1229 */     if (matched == expToken.length()) {
/* 1230 */       return _valueNonStdNumberComplete(type);
/*      */     }
/* 1232 */     this._textBuffer.resetWithCopy(expToken, 0, matched);
/* 1233 */     return _finishErrorTokenWithEOF();
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishErrorToken() throws IOException {
/* 1238 */     while (this._inputPtr < this._inputEnd) {
/* 1239 */       int i = getNextSignedByteFromBuffer();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1244 */       char ch = (char)i;
/* 1245 */       if (Character.isJavaIdentifierPart(ch)) {
/*      */ 
/*      */         
/* 1248 */         this._textBuffer.append(ch);
/* 1249 */         if (this._textBuffer.size() < this._ioContext.errorReportConfiguration().getMaxErrorTokenLength()) {
/*      */           continue;
/*      */         }
/*      */       } 
/* 1253 */       return _reportErrorToken(this._textBuffer.contentsAsString());
/*      */     } 
/* 1255 */     return _updateTokenToNA();
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishErrorTokenWithEOF() throws IOException {
/* 1260 */     return _reportErrorToken(this._textBuffer.contentsAsString());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _reportErrorToken(String actualToken) throws IOException {
/* 1266 */     _reportError("Unrecognized token '%s': was expecting %s", this._textBuffer.contentsAsString(), 
/* 1267 */         _validJsonTokenList());
/* 1268 */     return JsonToken.NOT_AVAILABLE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _startFloatThatStartsWithPeriod() throws IOException {
/* 1280 */     this._numberNegative = false;
/* 1281 */     this._intLength = 0;
/* 1282 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1283 */     return _startFloat(outBuf, 0, 46);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startPositiveNumber(int ch) throws IOException {
/* 1288 */     this._numberNegative = false;
/* 1289 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1290 */     outBuf[0] = (char)ch;
/*      */     
/* 1292 */     if (this._inputPtr >= this._inputEnd) {
/* 1293 */       this._minorState = 26;
/* 1294 */       this._textBuffer.setCurrentLength(1);
/* 1295 */       return _updateTokenToNA();
/*      */     } 
/*      */     
/* 1298 */     int outPtr = 1;
/*      */     
/* 1300 */     ch = getByteFromBuffer(this._inputPtr) & 0xFF;
/*      */     while (true) {
/* 1302 */       if (ch < 48) {
/* 1303 */         if (ch == 46) {
/* 1304 */           this._intLength = outPtr;
/* 1305 */           this._inputPtr++;
/* 1306 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1310 */       if (ch > 57) {
/* 1311 */         if ((ch | 0x20) == 101) {
/* 1312 */           this._intLength = outPtr;
/* 1313 */           this._inputPtr++;
/* 1314 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1318 */       if (outPtr >= outBuf.length)
/*      */       {
/*      */         
/* 1321 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1323 */       outBuf[outPtr++] = (char)ch;
/* 1324 */       if (++this._inputPtr >= this._inputEnd) {
/* 1325 */         this._minorState = 26;
/* 1326 */         this._textBuffer.setCurrentLength(outPtr);
/* 1327 */         return _updateTokenToNA();
/*      */       } 
/* 1329 */       ch = getByteFromBuffer(this._inputPtr) & 0xFF;
/*      */     } 
/* 1331 */     this._intLength = outPtr;
/* 1332 */     this._textBuffer.setCurrentLength(outPtr);
/* 1333 */     return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startNegativeNumber() throws IOException {
/* 1338 */     this._numberNegative = true;
/* 1339 */     if (this._inputPtr >= this._inputEnd) {
/* 1340 */       this._minorState = 23;
/* 1341 */       return _updateTokenToNA();
/*      */     } 
/* 1343 */     int ch = getNextUnsignedByteFromBuffer();
/* 1344 */     if (ch <= 48) {
/* 1345 */       if (ch == 48) {
/* 1346 */         return _finishNumberLeadingNegZeroes();
/*      */       }
/*      */       
/* 1349 */       _reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/* 1350 */     } else if (ch > 57) {
/* 1351 */       if (ch == 73) {
/* 1352 */         return _finishNonStdToken(3, 2);
/*      */       }
/* 1354 */       _reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow minus sign, for valid numeric value");
/*      */     } 
/* 1356 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1357 */     outBuf[0] = '-';
/* 1358 */     outBuf[1] = (char)ch;
/* 1359 */     if (this._inputPtr >= this._inputEnd) {
/* 1360 */       this._minorState = 26;
/* 1361 */       this._textBuffer.setCurrentLength(2);
/* 1362 */       this._intLength = 1;
/* 1363 */       return _updateTokenToNA();
/*      */     } 
/* 1365 */     ch = getByteFromBuffer(this._inputPtr);
/* 1366 */     int outPtr = 2;
/*      */     
/*      */     while (true) {
/* 1369 */       if (ch < 48) {
/* 1370 */         if (ch == 46) {
/* 1371 */           this._intLength = outPtr - 1;
/* 1372 */           this._inputPtr++;
/* 1373 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1377 */       if (ch > 57) {
/* 1378 */         if ((ch | 0x20) == 101) {
/* 1379 */           this._intLength = outPtr - 1;
/* 1380 */           this._inputPtr++;
/* 1381 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1385 */       if (outPtr >= outBuf.length)
/*      */       {
/* 1387 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1389 */       outBuf[outPtr++] = (char)ch;
/* 1390 */       if (++this._inputPtr >= this._inputEnd) {
/* 1391 */         this._minorState = 26;
/* 1392 */         this._textBuffer.setCurrentLength(outPtr);
/* 1393 */         return _updateTokenToNA();
/*      */       } 
/* 1395 */       ch = getByteFromBuffer(this._inputPtr) & 0xFF;
/*      */     } 
/* 1397 */     this._intLength = outPtr - 1;
/* 1398 */     this._textBuffer.setCurrentLength(outPtr);
/* 1399 */     return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startPositiveNumber() throws IOException {
/* 1404 */     this._numberNegative = false;
/* 1405 */     if (this._inputPtr >= this._inputEnd) {
/* 1406 */       this._minorState = 22;
/* 1407 */       return _updateTokenToNA();
/*      */     } 
/* 1409 */     int ch = getNextUnsignedByteFromBuffer();
/* 1410 */     if (ch <= 48) {
/* 1411 */       if (ch == 48) {
/* 1412 */         if (!isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/* 1413 */           _reportUnexpectedNumberChar(43, "JSON spec does not allow numbers to have plus signs: enable `JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS` to allow");
/*      */         }
/* 1415 */         return _finishNumberLeadingPosZeroes();
/*      */       } 
/*      */       
/* 1418 */       _reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow plus sign, for valid numeric value");
/* 1419 */     } else if (ch > 57) {
/* 1420 */       if (ch == 73) {
/* 1421 */         return _finishNonStdToken(2, 2);
/*      */       }
/* 1423 */       _reportUnexpectedNumberChar(ch, "expected digit (0-9) to follow plus sign, for valid numeric value");
/*      */     } 
/* 1425 */     if (!isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/* 1426 */       _reportUnexpectedNumberChar(43, "JSON spec does not allow numbers to have plus signs: enable `JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS` to allow");
/*      */     }
/* 1428 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1429 */     outBuf[0] = '+';
/* 1430 */     outBuf[1] = (char)ch;
/* 1431 */     if (this._inputPtr >= this._inputEnd) {
/* 1432 */       this._minorState = 26;
/* 1433 */       this._textBuffer.setCurrentLength(2);
/* 1434 */       this._intLength = 1;
/* 1435 */       return _updateTokenToNA();
/*      */     } 
/* 1437 */     ch = getByteFromBuffer(this._inputPtr);
/* 1438 */     int outPtr = 2;
/*      */     
/*      */     while (true) {
/* 1441 */       if (ch < 48) {
/* 1442 */         if (ch == 46) {
/* 1443 */           this._intLength = outPtr - 1;
/* 1444 */           this._inputPtr++;
/* 1445 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1449 */       if (ch > 57) {
/* 1450 */         if ((ch | 0x20) == 101) {
/* 1451 */           this._intLength = outPtr - 1;
/* 1452 */           this._inputPtr++;
/* 1453 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1457 */       if (outPtr >= outBuf.length)
/*      */       {
/* 1459 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1461 */       outBuf[outPtr++] = (char)ch;
/* 1462 */       if (++this._inputPtr >= this._inputEnd) {
/* 1463 */         this._minorState = 26;
/* 1464 */         this._textBuffer.setCurrentLength(outPtr);
/* 1465 */         return _updateTokenToNA();
/*      */       } 
/* 1467 */       ch = getByteFromBuffer(this._inputPtr) & 0xFF;
/*      */     } 
/* 1469 */     this._intLength = outPtr - 1;
/* 1470 */     this._textBuffer.setCurrentLength(outPtr);
/* 1471 */     return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startNumberLeadingZero() throws IOException {
/* 1476 */     int ptr = this._inputPtr;
/* 1477 */     if (ptr >= this._inputEnd) {
/* 1478 */       this._minorState = 24;
/* 1479 */       return _updateTokenToNA();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1486 */     int ch = getByteFromBuffer(ptr++) & 0xFF;
/*      */     
/* 1488 */     if (ch < 48) {
/* 1489 */       if (ch == 46) {
/* 1490 */         this._inputPtr = ptr;
/* 1491 */         this._intLength = 1;
/* 1492 */         char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1493 */         outBuf[0] = '0';
/* 1494 */         return _startFloat(outBuf, 1, ch);
/*      */       } 
/* 1496 */     } else if (ch > 57) {
/* 1497 */       if ((ch | 0x20) == 101) {
/* 1498 */         this._inputPtr = ptr;
/* 1499 */         this._intLength = 1;
/* 1500 */         char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1501 */         outBuf[0] = '0';
/* 1502 */         return _startFloat(outBuf, 1, ch);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1507 */       if ((ch | 0x20) != 125) {
/* 1508 */         _reportUnexpectedNumberChar(ch, "expected digit (0-9), decimal point (.) or exponent indicator (e/E) to follow '0'");
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/* 1513 */       return _finishNumberLeadingZeroes();
/*      */     } 
/*      */     
/* 1516 */     return _valueCompleteInt(0, "0");
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberMinus(int ch) throws IOException {
/* 1521 */     return _finishNumberPlusMinus(ch, true);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberPlus(int ch) throws IOException {
/* 1526 */     return _finishNumberPlusMinus(ch, false);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberPlusMinus(int ch, boolean negative) throws IOException {
/* 1531 */     if (ch <= 48) {
/* 1532 */       if (ch == 48) {
/* 1533 */         if (negative) {
/* 1534 */           return _finishNumberLeadingNegZeroes();
/*      */         }
/* 1536 */         if (!isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/* 1537 */           _reportUnexpectedNumberChar(43, "JSON spec does not allow numbers to have plus signs: enable `JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS` to allow");
/*      */         }
/* 1539 */         return _finishNumberLeadingPosZeroes();
/*      */       } 
/* 1541 */       if (ch == 46 && isEnabled(JsonReadFeature.ALLOW_LEADING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1542 */         if (negative) {
/* 1543 */           this._inputPtr--;
/* 1544 */           return _finishNumberLeadingNegZeroes();
/*      */         } 
/* 1546 */         if (!isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/* 1547 */           _reportUnexpectedNumberChar(43, "JSON spec does not allow numbers to have plus signs: enable `JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS` to allow");
/*      */         }
/* 1549 */         this._inputPtr--;
/* 1550 */         return _finishNumberLeadingPosZeroes();
/*      */       } 
/*      */       
/* 1553 */       String message = negative ? "expected digit (0-9) to follow minus sign, for valid numeric value" : "expected digit (0-9) for valid numeric value";
/*      */ 
/*      */       
/* 1556 */       _reportUnexpectedNumberChar(ch, message);
/* 1557 */     } else if (ch > 57) {
/* 1558 */       if (ch == 73) {
/* 1559 */         int token = negative ? 3 : 2;
/* 1560 */         return _finishNonStdToken(token, 2);
/*      */       } 
/* 1562 */       String message = negative ? "expected digit (0-9) to follow minus sign, for valid numeric value" : "expected digit (0-9) for valid numeric value";
/*      */ 
/*      */       
/* 1565 */       _reportUnexpectedNumberChar(ch, message);
/*      */     } 
/* 1567 */     if (!negative && !isEnabled(JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS.mappedFeature())) {
/* 1568 */       _reportUnexpectedNumberChar(43, "JSON spec does not allow numbers to have plus signs: enable `JsonReadFeature.ALLOW_LEADING_PLUS_SIGN_FOR_NUMBERS` to allow");
/*      */     }
/* 1570 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 1571 */     outBuf[0] = negative ? '-' : '+';
/* 1572 */     outBuf[1] = (char)ch;
/* 1573 */     this._intLength = 1;
/* 1574 */     return _finishNumberIntegralPart(outBuf, 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberLeadingZeroes() throws IOException {
/*      */     while (true) {
/* 1582 */       if (this._inputPtr >= this._inputEnd) {
/* 1583 */         this._minorState = 24;
/* 1584 */         return _updateTokenToNA();
/*      */       } 
/* 1586 */       int ch = getNextUnsignedByteFromBuffer();
/* 1587 */       if (ch < 48) {
/* 1588 */         if (ch == 46) {
/* 1589 */           char[] arrayOfChar = this._textBuffer.emptyAndGetCurrentSegment();
/* 1590 */           arrayOfChar[0] = '0';
/* 1591 */           this._intLength = 1;
/* 1592 */           return _startFloat(arrayOfChar, 1, ch);
/*      */         }  break;
/* 1594 */       }  if (ch > 57) {
/* 1595 */         if ((ch | 0x20) == 101) {
/* 1596 */           char[] arrayOfChar = this._textBuffer.emptyAndGetCurrentSegment();
/* 1597 */           arrayOfChar[0] = '0';
/* 1598 */           this._intLength = 1;
/* 1599 */           return _startFloat(arrayOfChar, 1, ch);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1604 */         if ((ch | 0x20) != 125) {
/* 1605 */           _reportUnexpectedNumberChar(ch, "expected digit (0-9), decimal point (.) or exponent indicator (e/E) to follow '0'");
/*      */         }
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 1611 */       if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1612 */         reportInvalidNumber("Leading zeroes not allowed");
/*      */       }
/* 1614 */       if (ch == 48) {
/*      */         continue;
/*      */       }
/* 1617 */       char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */       
/* 1619 */       outBuf[0] = (char)ch;
/* 1620 */       this._intLength = 1;
/* 1621 */       return _finishNumberIntegralPart(outBuf, 1);
/*      */     } 
/* 1623 */     this._inputPtr--;
/* 1624 */     return _valueCompleteInt(0, "0");
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberLeadingNegZeroes() throws IOException {
/* 1629 */     return _finishNumberLeadingPosNegZeroes(true);
/*      */   }
/*      */   
/*      */   protected JsonToken _finishNumberLeadingPosZeroes() throws IOException {
/* 1633 */     return _finishNumberLeadingPosNegZeroes(false);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberLeadingPosNegZeroes(boolean negative) throws IOException {
/*      */     while (true) {
/* 1640 */       if (this._inputPtr >= this._inputEnd) {
/* 1641 */         this._minorState = negative ? 25 : 24;
/* 1642 */         return _updateTokenToNA();
/*      */       } 
/* 1644 */       int ch = getNextUnsignedByteFromBuffer();
/* 1645 */       if (ch < 48) {
/* 1646 */         if (ch == 46) {
/* 1647 */           char[] arrayOfChar = this._textBuffer.emptyAndGetCurrentSegment();
/* 1648 */           arrayOfChar[0] = negative ? '-' : '+';
/* 1649 */           arrayOfChar[1] = '0';
/* 1650 */           this._intLength = 1;
/* 1651 */           return _startFloat(arrayOfChar, 2, ch);
/*      */         }  break;
/* 1653 */       }  if (ch > 57) {
/* 1654 */         if ((ch | 0x20) == 101) {
/* 1655 */           char[] arrayOfChar = this._textBuffer.emptyAndGetCurrentSegment();
/* 1656 */           arrayOfChar[0] = negative ? '-' : '+';
/* 1657 */           arrayOfChar[1] = '0';
/* 1658 */           this._intLength = 1;
/* 1659 */           return _startFloat(arrayOfChar, 2, ch);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1664 */         if ((ch | 0x20) != 125) {
/* 1665 */           _reportUnexpectedNumberChar(ch, "expected digit (0-9), decimal point (.) or exponent indicator (e/E) to follow '0'");
/*      */         }
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 1671 */       if ((this._features & FEAT_MASK_LEADING_ZEROS) == 0) {
/* 1672 */         reportInvalidNumber("Leading zeroes not allowed");
/*      */       }
/* 1674 */       if (ch == 48) {
/*      */         continue;
/*      */       }
/* 1677 */       char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/*      */       
/* 1679 */       outBuf[0] = negative ? '-' : '+';
/* 1680 */       outBuf[1] = (char)ch;
/* 1681 */       this._intLength = 1;
/* 1682 */       return _finishNumberIntegralPart(outBuf, 2);
/*      */     } 
/* 1684 */     this._inputPtr--;
/* 1685 */     return _valueCompleteInt(0, "0");
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishNumberIntegralPart(char[] outBuf, int outPtr) throws IOException {
/* 1690 */     int negMod = this._numberNegative ? -1 : 0;
/*      */     
/*      */     while (true) {
/* 1693 */       if (this._inputPtr >= this._inputEnd) {
/* 1694 */         this._minorState = 26;
/* 1695 */         this._textBuffer.setCurrentLength(outPtr);
/* 1696 */         return _updateTokenToNA();
/*      */       } 
/* 1698 */       int ch = getByteFromBuffer(this._inputPtr) & 0xFF;
/* 1699 */       if (ch < 48) {
/* 1700 */         if (ch == 46) {
/* 1701 */           this._intLength = outPtr + negMod;
/* 1702 */           this._inputPtr++;
/* 1703 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1707 */       if (ch > 57) {
/* 1708 */         if ((ch | 0x20) == 101) {
/* 1709 */           this._intLength = outPtr + negMod;
/* 1710 */           this._inputPtr++;
/* 1711 */           return _startFloat(outBuf, outPtr, ch);
/*      */         } 
/*      */         break;
/*      */       } 
/* 1715 */       this._inputPtr++;
/* 1716 */       if (outPtr >= outBuf.length)
/*      */       {
/*      */         
/* 1719 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1721 */       outBuf[outPtr++] = (char)ch;
/*      */     } 
/* 1723 */     this._intLength = outPtr + negMod;
/* 1724 */     this._textBuffer.setCurrentLength(outPtr);
/* 1725 */     return _valueComplete(JsonToken.VALUE_NUMBER_INT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _startFloat(char[] outBuf, int outPtr, int ch) throws IOException {
/* 1730 */     int fractLen = 0;
/* 1731 */     if (ch == 46) {
/* 1732 */       if (outPtr >= outBuf.length) {
/* 1733 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1735 */       outBuf[outPtr++] = '.';
/*      */       while (true) {
/* 1737 */         if (this._inputPtr >= this._inputEnd) {
/* 1738 */           this._textBuffer.setCurrentLength(outPtr);
/* 1739 */           this._minorState = 30;
/* 1740 */           this._fractLength = fractLen;
/* 1741 */           return _updateTokenToNA();
/*      */         } 
/* 1743 */         ch = getNextSignedByteFromBuffer();
/* 1744 */         if (ch < 48 || ch > 57) {
/* 1745 */           ch &= 0xFF;
/*      */           
/* 1747 */           if (fractLen == 0 && 
/* 1748 */             !isEnabled(JsonReadFeature.ALLOW_TRAILING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1749 */             _reportUnexpectedNumberChar(ch, "Decimal point not followed by a digit");
/*      */           }
/*      */           
/*      */           break;
/*      */         } 
/* 1754 */         if (outPtr >= outBuf.length) {
/* 1755 */           outBuf = this._textBuffer.expandCurrentSegment();
/*      */         }
/* 1757 */         outBuf[outPtr++] = (char)ch;
/* 1758 */         fractLen++;
/*      */       } 
/*      */     } 
/* 1761 */     this._fractLength = fractLen;
/* 1762 */     int expLen = 0;
/* 1763 */     if ((ch | 0x20) == 101) {
/* 1764 */       if (outPtr >= outBuf.length) {
/* 1765 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1767 */       outBuf[outPtr++] = (char)ch;
/* 1768 */       if (this._inputPtr >= this._inputEnd) {
/* 1769 */         this._textBuffer.setCurrentLength(outPtr);
/* 1770 */         this._minorState = 31;
/* 1771 */         this._expLength = 0;
/* 1772 */         return _updateTokenToNA();
/*      */       } 
/* 1774 */       ch = getNextSignedByteFromBuffer();
/* 1775 */       if (ch == 45 || ch == 43) {
/* 1776 */         if (outPtr >= outBuf.length) {
/* 1777 */           outBuf = this._textBuffer.expandCurrentSegment();
/*      */         }
/* 1779 */         outBuf[outPtr++] = (char)ch;
/* 1780 */         if (this._inputPtr >= this._inputEnd) {
/* 1781 */           this._textBuffer.setCurrentLength(outPtr);
/* 1782 */           this._minorState = 32;
/* 1783 */           this._expLength = 0;
/* 1784 */           return _updateTokenToNA();
/*      */         } 
/* 1786 */         ch = getNextSignedByteFromBuffer();
/*      */       } 
/* 1788 */       while (ch >= 48 && ch <= 57) {
/* 1789 */         expLen++;
/* 1790 */         if (outPtr >= outBuf.length) {
/* 1791 */           outBuf = this._textBuffer.expandCurrentSegment();
/*      */         }
/* 1793 */         outBuf[outPtr++] = (char)ch;
/* 1794 */         if (this._inputPtr >= this._inputEnd) {
/* 1795 */           this._textBuffer.setCurrentLength(outPtr);
/* 1796 */           this._minorState = 32;
/* 1797 */           this._expLength = expLen;
/* 1798 */           return _updateTokenToNA();
/*      */         } 
/* 1800 */         ch = getNextSignedByteFromBuffer();
/*      */       } 
/*      */       
/* 1803 */       ch &= 0xFF;
/* 1804 */       if (expLen == 0) {
/* 1805 */         _reportUnexpectedNumberChar(ch, "Exponent indicator not followed by a digit");
/*      */       }
/*      */     } 
/*      */     
/* 1809 */     this._inputPtr--;
/* 1810 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1812 */     this._expLength = expLen;
/* 1813 */     return _valueComplete(JsonToken.VALUE_NUMBER_FLOAT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishFloatFraction() throws IOException {
/* 1818 */     int fractLen = this._fractLength;
/* 1819 */     char[] outBuf = this._textBuffer.getBufferWithoutReset();
/* 1820 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/*      */ 
/*      */     
/* 1823 */     int ch = getNextSignedByteFromBuffer();
/* 1824 */     boolean loop = true;
/* 1825 */     while (loop) {
/* 1826 */       if (ch >= 48 && ch <= 57) {
/* 1827 */         fractLen++;
/* 1828 */         if (outPtr >= outBuf.length) {
/* 1829 */           outBuf = this._textBuffer.expandCurrentSegment();
/*      */         }
/* 1831 */         outBuf[outPtr++] = (char)ch;
/* 1832 */         if (this._inputPtr >= this._inputEnd) {
/* 1833 */           this._textBuffer.setCurrentLength(outPtr);
/* 1834 */           this._fractLength = fractLen;
/* 1835 */           return JsonToken.NOT_AVAILABLE;
/*      */         } 
/* 1837 */         ch = getNextSignedByteFromBuffer(); continue;
/* 1838 */       }  if ((ch | 0x22) == 102) {
/* 1839 */         _reportUnexpectedNumberChar(ch, "JSON does not support parsing numbers that have 'f' or 'd' suffixes"); continue;
/* 1840 */       }  if (ch == 46) {
/* 1841 */         _reportUnexpectedNumberChar(ch, "Cannot parse number with more than one decimal point"); continue;
/*      */       } 
/* 1843 */       loop = false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1849 */     if (fractLen == 0 && 
/* 1850 */       !isEnabled(JsonReadFeature.ALLOW_TRAILING_DECIMAL_POINT_FOR_NUMBERS.mappedFeature())) {
/* 1851 */       _reportUnexpectedNumberChar(ch, "Decimal point not followed by a digit");
/*      */     }
/*      */     
/* 1854 */     this._fractLength = fractLen;
/* 1855 */     this._textBuffer.setCurrentLength(outPtr);
/*      */ 
/*      */     
/* 1858 */     if ((ch | 0x20) == 101) {
/* 1859 */       this._textBuffer.append((char)ch);
/* 1860 */       this._expLength = 0;
/* 1861 */       if (this._inputPtr >= this._inputEnd) {
/* 1862 */         this._minorState = 31;
/* 1863 */         return JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1865 */       this._minorState = 32;
/* 1866 */       return _finishFloatExponent(true, getNextUnsignedByteFromBuffer());
/*      */     } 
/*      */ 
/*      */     
/* 1870 */     this._inputPtr--;
/* 1871 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1873 */     this._expLength = 0;
/* 1874 */     return _valueComplete(JsonToken.VALUE_NUMBER_FLOAT);
/*      */   }
/*      */ 
/*      */   
/*      */   protected JsonToken _finishFloatExponent(boolean checkSign, int ch) throws IOException {
/* 1879 */     if (checkSign) {
/* 1880 */       this._minorState = 32;
/* 1881 */       if (ch == 45 || ch == 43) {
/* 1882 */         this._textBuffer.append((char)ch);
/* 1883 */         if (this._inputPtr >= this._inputEnd) {
/* 1884 */           this._minorState = 32;
/* 1885 */           this._expLength = 0;
/* 1886 */           return JsonToken.NOT_AVAILABLE;
/*      */         } 
/* 1888 */         ch = getNextSignedByteFromBuffer();
/*      */       } 
/*      */     } 
/*      */     
/* 1892 */     char[] outBuf = this._textBuffer.getBufferWithoutReset();
/* 1893 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 1894 */     int expLen = this._expLength;
/*      */     
/* 1896 */     while (ch >= 48 && ch <= 57) {
/* 1897 */       expLen++;
/* 1898 */       if (outPtr >= outBuf.length) {
/* 1899 */         outBuf = this._textBuffer.expandCurrentSegment();
/*      */       }
/* 1901 */       outBuf[outPtr++] = (char)ch;
/* 1902 */       if (this._inputPtr >= this._inputEnd) {
/* 1903 */         this._textBuffer.setCurrentLength(outPtr);
/* 1904 */         this._expLength = expLen;
/* 1905 */         return JsonToken.NOT_AVAILABLE;
/*      */       } 
/* 1907 */       ch = getNextSignedByteFromBuffer();
/*      */     } 
/*      */     
/* 1910 */     ch &= 0xFF;
/* 1911 */     if (expLen == 0) {
/* 1912 */       _reportUnexpectedNumberChar(ch, "Exponent indicator not followed by a digit");
/*      */     }
/*      */     
/* 1915 */     this._inputPtr--;
/* 1916 */     this._textBuffer.setCurrentLength(outPtr);
/*      */     
/* 1918 */     this._expLength = expLen;
/* 1919 */     return _valueComplete(JsonToken.VALUE_NUMBER_FLOAT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String _fastParseName() throws IOException {
/* 1935 */     int[] codes = _icLatin1;
/* 1936 */     int ptr = this._inputPtr;
/*      */     
/* 1938 */     int q0 = getByteFromBuffer(ptr++) & 0xFF;
/* 1939 */     if (codes[q0] == 0) {
/* 1940 */       int i = getByteFromBuffer(ptr++) & 0xFF;
/* 1941 */       if (codes[i] == 0) {
/* 1942 */         int q = q0 << 8 | i;
/* 1943 */         i = getByteFromBuffer(ptr++) & 0xFF;
/* 1944 */         if (codes[i] == 0) {
/* 1945 */           q = q << 8 | i;
/* 1946 */           i = getByteFromBuffer(ptr++) & 0xFF;
/* 1947 */           if (codes[i] == 0) {
/* 1948 */             q = q << 8 | i;
/* 1949 */             i = getByteFromBuffer(ptr++) & 0xFF;
/* 1950 */             if (codes[i] == 0) {
/* 1951 */               this._quad1 = q;
/* 1952 */               return _parseMediumName(ptr, i);
/*      */             } 
/* 1954 */             if (i == 34) {
/* 1955 */               this._inputPtr = ptr;
/* 1956 */               return _findName(q, 4);
/*      */             } 
/* 1958 */             return null;
/*      */           } 
/* 1960 */           if (i == 34) {
/* 1961 */             this._inputPtr = ptr;
/* 1962 */             return _findName(q, 3);
/*      */           } 
/* 1964 */           return null;
/*      */         } 
/* 1966 */         if (i == 34) {
/* 1967 */           this._inputPtr = ptr;
/* 1968 */           return _findName(q, 2);
/*      */         } 
/* 1970 */         return null;
/*      */       } 
/* 1972 */       if (i == 34) {
/* 1973 */         this._inputPtr = ptr;
/* 1974 */         return _findName(q0, 1);
/*      */       } 
/* 1976 */       return null;
/*      */     } 
/* 1978 */     if (q0 == 34) {
/* 1979 */       this._inputPtr = ptr;
/* 1980 */       return "";
/*      */     } 
/* 1982 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseMediumName(int ptr, int q2) throws IOException {
/* 1987 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 1990 */     int i = getByteFromBuffer(ptr++) & 0xFF;
/* 1991 */     if (codes[i] == 0) {
/* 1992 */       q2 = q2 << 8 | i;
/* 1993 */       i = getByteFromBuffer(ptr++) & 0xFF;
/* 1994 */       if (codes[i] == 0) {
/* 1995 */         q2 = q2 << 8 | i;
/* 1996 */         i = getByteFromBuffer(ptr++) & 0xFF;
/* 1997 */         if (codes[i] == 0) {
/* 1998 */           q2 = q2 << 8 | i;
/* 1999 */           i = getByteFromBuffer(ptr++) & 0xFF;
/* 2000 */           if (codes[i] == 0) {
/* 2001 */             return _parseMediumName2(ptr, i, q2);
/*      */           }
/* 2003 */           if (i == 34) {
/* 2004 */             this._inputPtr = ptr;
/* 2005 */             return _findName(this._quad1, q2, 4);
/*      */           } 
/* 2007 */           return null;
/*      */         } 
/* 2009 */         if (i == 34) {
/* 2010 */           this._inputPtr = ptr;
/* 2011 */           return _findName(this._quad1, q2, 3);
/*      */         } 
/* 2013 */         return null;
/*      */       } 
/* 2015 */       if (i == 34) {
/* 2016 */         this._inputPtr = ptr;
/* 2017 */         return _findName(this._quad1, q2, 2);
/*      */       } 
/* 2019 */       return null;
/*      */     } 
/* 2021 */     if (i == 34) {
/* 2022 */       this._inputPtr = ptr;
/* 2023 */       return _findName(this._quad1, q2, 1);
/*      */     } 
/* 2025 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private final String _parseMediumName2(int ptr, int q3, int q2) throws IOException {
/* 2030 */     int[] codes = _icLatin1;
/*      */ 
/*      */     
/* 2033 */     int i = getByteFromBuffer(ptr++) & 0xFF;
/* 2034 */     if (codes[i] != 0) {
/* 2035 */       if (i == 34) {
/* 2036 */         this._inputPtr = ptr;
/* 2037 */         return _findName(this._quad1, q2, q3, 1);
/*      */       } 
/* 2039 */       return null;
/*      */     } 
/* 2041 */     q3 = q3 << 8 | i;
/* 2042 */     i = getByteFromBuffer(ptr++) & 0xFF;
/* 2043 */     if (codes[i] != 0) {
/* 2044 */       if (i == 34) {
/* 2045 */         this._inputPtr = ptr;
/* 2046 */         return _findName(this._quad1, q2, q3, 2);
/*      */       } 
/* 2048 */       return null;
/*      */     } 
/* 2050 */     q3 = q3 << 8 | i;
/* 2051 */     i = getByteFromBuffer(ptr++) & 0xFF;
/* 2052 */     if (codes[i] != 0) {
/* 2053 */       if (i == 34) {
/* 2054 */         this._inputPtr = ptr;
/* 2055 */         return _findName(this._quad1, q2, q3, 3);
/*      */       } 
/* 2057 */       return null;
/*      */     } 
/* 2059 */     q3 = q3 << 8 | i;
/* 2060 */     i = getByteFromBuffer(ptr++) & 0xFF;
/* 2061 */     if (i == 34) {
/* 2062 */       this._inputPtr = ptr;
/* 2063 */       return _findName(this._quad1, q2, q3, 4);
/*      */     } 
/*      */     
/* 2066 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _parseEscapedName(int qlen, int currQuad, int currQuadBytes) throws IOException {
/* 2082 */     int[] quads = this._quadBuffer;
/* 2083 */     int[] codes = _icLatin1;
/*      */     
/*      */     while (true) {
/* 2086 */       if (this._inputPtr >= this._inputEnd) {
/* 2087 */         this._quadLength = qlen;
/* 2088 */         this._pending32 = currQuad;
/* 2089 */         this._pendingBytes = currQuadBytes;
/* 2090 */         this._minorState = 7;
/* 2091 */         return _updateTokenToNA();
/*      */       } 
/* 2093 */       int ch = getNextUnsignedByteFromBuffer();
/* 2094 */       if (codes[ch] == 0) {
/* 2095 */         if (currQuadBytes < 4) {
/* 2096 */           currQuadBytes++;
/* 2097 */           currQuad = currQuad << 8 | ch;
/*      */           continue;
/*      */         } 
/* 2100 */         if (qlen >= quads.length) {
/* 2101 */           this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */         }
/* 2103 */         quads[qlen++] = currQuad;
/* 2104 */         currQuad = ch;
/* 2105 */         currQuadBytes = 1;
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/* 2110 */       if (ch == 34) {
/*      */         break;
/*      */       }
/*      */       
/* 2114 */       if (ch != 92) {
/*      */         
/* 2116 */         _throwUnquotedSpace(ch, "name");
/*      */       } else {
/*      */         
/* 2119 */         ch = _decodeCharEscape();
/* 2120 */         if (ch < 0) {
/* 2121 */           this._minorState = 8;
/* 2122 */           this._minorStateAfterSplit = 7;
/* 2123 */           this._quadLength = qlen;
/* 2124 */           this._pending32 = currQuad;
/* 2125 */           this._pendingBytes = currQuadBytes;
/* 2126 */           return _updateTokenToNA();
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2133 */       if (qlen >= quads.length) {
/* 2134 */         this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */       }
/* 2136 */       if (ch > 127) {
/*      */         
/* 2138 */         if (currQuadBytes >= 4) {
/* 2139 */           quads[qlen++] = currQuad;
/* 2140 */           currQuad = 0;
/* 2141 */           currQuadBytes = 0;
/*      */         } 
/* 2143 */         if (ch < 2048) {
/* 2144 */           currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2145 */           currQuadBytes++;
/*      */         } else {
/*      */           
/* 2148 */           currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 2149 */           currQuadBytes++;
/*      */           
/* 2151 */           if (currQuadBytes >= 4) {
/* 2152 */             quads[qlen++] = currQuad;
/* 2153 */             currQuad = 0;
/* 2154 */             currQuadBytes = 0;
/*      */           } 
/* 2156 */           currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2157 */           currQuadBytes++;
/*      */         } 
/*      */         
/* 2160 */         ch = 0x80 | ch & 0x3F;
/*      */       } 
/* 2162 */       if (currQuadBytes < 4) {
/* 2163 */         currQuadBytes++;
/* 2164 */         currQuad = currQuad << 8 | ch;
/*      */         continue;
/*      */       } 
/* 2167 */       quads[qlen++] = currQuad;
/* 2168 */       currQuad = ch;
/* 2169 */       currQuadBytes = 1;
/*      */     } 
/*      */     
/* 2172 */     if (currQuadBytes > 0) {
/* 2173 */       if (qlen >= quads.length) {
/* 2174 */         this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */       }
/* 2176 */       quads[qlen++] = _padLastQuad(currQuad, currQuadBytes);
/* 2177 */     } else if (qlen == 0) {
/* 2178 */       return _fieldComplete("");
/*      */     } 
/* 2180 */     String name = this._symbols.findName(quads, qlen);
/* 2181 */     if (name == null) {
/* 2182 */       name = _addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2184 */     return _fieldComplete(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JsonToken _handleOddName(int ch) throws IOException {
/* 2196 */     switch (ch) {
/*      */ 
/*      */       
/*      */       case 35:
/* 2200 */         if ((this._features & FEAT_MASK_ALLOW_YAML_COMMENTS) != 0) {
/* 2201 */           return _finishHashComment(4);
/*      */         }
/*      */         break;
/*      */       case 47:
/* 2205 */         return _startSlashComment(4);
/*      */       case 39:
/* 2207 */         if ((this._features & FEAT_MASK_ALLOW_SINGLE_QUOTES) != 0) {
/* 2208 */           return _finishAposName(0, 0, 0);
/*      */         }
/*      */         break;
/*      */       case 93:
/* 2212 */         return _closeArrayScope();
/*      */     } 
/*      */     
/* 2215 */     if ((this._features & FEAT_MASK_ALLOW_UNQUOTED_NAMES) == 0) {
/*      */ 
/*      */       
/* 2218 */       char c = (char)ch;
/* 2219 */       _reportUnexpectedChar(c, "was expecting double-quote to start field name");
/*      */     } 
/*      */ 
/*      */     
/* 2223 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */     
/* 2225 */     if (codes[ch] != 0) {
/* 2226 */       _reportUnexpectedChar(ch, "was expecting either valid name character (for unquoted name) or double-quote (for quoted) to start field name");
/*      */     }
/*      */     
/* 2229 */     return _finishUnquotedName(0, ch, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JsonToken _finishUnquotedName(int qlen, int currQuad, int currQuadBytes) throws IOException {
/* 2240 */     int[] quads = this._quadBuffer;
/* 2241 */     int[] codes = CharTypes.getInputCodeUtf8JsNames();
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2246 */       if (this._inputPtr >= this._inputEnd) {
/* 2247 */         this._quadLength = qlen;
/* 2248 */         this._pending32 = currQuad;
/* 2249 */         this._pendingBytes = currQuadBytes;
/* 2250 */         this._minorState = 10;
/* 2251 */         return _updateTokenToNA();
/*      */       } 
/* 2253 */       int ch = getByteFromBuffer(this._inputPtr) & 0xFF;
/* 2254 */       if (codes[ch] != 0) {
/*      */         break;
/*      */       }
/* 2257 */       this._inputPtr++;
/*      */       
/* 2259 */       if (currQuadBytes < 4) {
/* 2260 */         currQuadBytes++;
/* 2261 */         currQuad = currQuad << 8 | ch; continue;
/*      */       } 
/* 2263 */       if (qlen >= quads.length) {
/* 2264 */         this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */       }
/* 2266 */       quads[qlen++] = currQuad;
/* 2267 */       currQuad = ch;
/* 2268 */       currQuadBytes = 1;
/*      */     } 
/*      */ 
/*      */     
/* 2272 */     if (currQuadBytes > 0) {
/* 2273 */       if (qlen >= quads.length) {
/* 2274 */         this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */       }
/* 2276 */       quads[qlen++] = currQuad;
/*      */     } 
/* 2278 */     String name = this._symbols.findName(quads, qlen);
/* 2279 */     if (name == null) {
/* 2280 */       name = _addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2282 */     return _fieldComplete(name);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private JsonToken _finishAposName(int qlen, int currQuad, int currQuadBytes) throws IOException {
/* 2288 */     int[] quads = this._quadBuffer;
/* 2289 */     int[] codes = _icLatin1;
/*      */     
/*      */     while (true) {
/* 2292 */       if (this._inputPtr >= this._inputEnd) {
/* 2293 */         this._quadLength = qlen;
/* 2294 */         this._pending32 = currQuad;
/* 2295 */         this._pendingBytes = currQuadBytes;
/* 2296 */         this._minorState = 9;
/* 2297 */         return _updateTokenToNA();
/*      */       } 
/* 2299 */       int ch = getNextUnsignedByteFromBuffer();
/* 2300 */       if (ch == 39) {
/*      */         break;
/*      */       }
/*      */       
/* 2304 */       if (ch != 34 && codes[ch] != 0) {
/* 2305 */         if (ch != 92) {
/*      */           
/* 2307 */           _throwUnquotedSpace(ch, "name");
/*      */         } else {
/*      */           
/* 2310 */           ch = _decodeCharEscape();
/* 2311 */           if (ch < 0) {
/* 2312 */             this._minorState = 8;
/* 2313 */             this._minorStateAfterSplit = 9;
/* 2314 */             this._quadLength = qlen;
/* 2315 */             this._pending32 = currQuad;
/* 2316 */             this._pendingBytes = currQuadBytes;
/* 2317 */             return _updateTokenToNA();
/*      */           } 
/*      */         } 
/* 2320 */         if (ch > 127) {
/*      */           
/* 2322 */           if (currQuadBytes >= 4) {
/* 2323 */             if (qlen >= quads.length) {
/* 2324 */               this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */             }
/* 2326 */             quads[qlen++] = currQuad;
/* 2327 */             currQuad = 0;
/* 2328 */             currQuadBytes = 0;
/*      */           } 
/* 2330 */           if (ch < 2048) {
/* 2331 */             currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2332 */             currQuadBytes++;
/*      */           } else {
/*      */             
/* 2335 */             currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/* 2336 */             currQuadBytes++;
/*      */             
/* 2338 */             if (currQuadBytes >= 4) {
/* 2339 */               if (qlen >= quads.length) {
/* 2340 */                 this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */               }
/* 2342 */               quads[qlen++] = currQuad;
/* 2343 */               currQuad = 0;
/* 2344 */               currQuadBytes = 0;
/*      */             } 
/* 2346 */             currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2347 */             currQuadBytes++;
/*      */           } 
/*      */           
/* 2350 */           ch = 0x80 | ch & 0x3F;
/*      */         } 
/*      */       } 
/*      */       
/* 2354 */       if (currQuadBytes < 4) {
/* 2355 */         currQuadBytes++;
/* 2356 */         currQuad = currQuad << 8 | ch; continue;
/*      */       } 
/* 2358 */       if (qlen >= quads.length) {
/* 2359 */         this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */       }
/* 2361 */       quads[qlen++] = currQuad;
/* 2362 */       currQuad = ch;
/* 2363 */       currQuadBytes = 1;
/*      */     } 
/*      */ 
/*      */     
/* 2367 */     if (currQuadBytes > 0) {
/* 2368 */       if (qlen >= quads.length) {
/* 2369 */         this._quadBuffer = quads = _growNameDecodeBuffer(quads, quads.length);
/*      */       }
/* 2371 */       quads[qlen++] = _padLastQuad(currQuad, currQuadBytes);
/* 2372 */     } else if (qlen == 0) {
/* 2373 */       return _fieldComplete("");
/*      */     } 
/* 2375 */     String name = this._symbols.findName(quads, qlen);
/* 2376 */     if (name == null) {
/* 2377 */       name = _addName(quads, qlen, currQuadBytes);
/*      */     }
/* 2379 */     return _fieldComplete(name);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _finishFieldWithEscape() throws IOException {
/* 2385 */     int ch = _decodeSplitEscaped(this._quoted32, this._quotedDigits);
/* 2386 */     if (ch < 0) {
/* 2387 */       this._minorState = 8;
/* 2388 */       return JsonToken.NOT_AVAILABLE;
/*      */     } 
/* 2390 */     if (this._quadLength >= this._quadBuffer.length) {
/* 2391 */       this._quadBuffer = _growNameDecodeBuffer(this._quadBuffer, 32);
/*      */     }
/* 2393 */     int currQuad = this._pending32;
/* 2394 */     int currQuadBytes = this._pendingBytes;
/* 2395 */     if (ch > 127) {
/*      */       
/* 2397 */       if (currQuadBytes >= 4) {
/* 2398 */         this._quadBuffer[this._quadLength++] = currQuad;
/* 2399 */         currQuad = 0;
/* 2400 */         currQuadBytes = 0;
/*      */       } 
/* 2402 */       if (ch < 2048) {
/* 2403 */         currQuad = currQuad << 8 | 0xC0 | ch >> 6;
/* 2404 */         currQuadBytes++;
/*      */       } else {
/*      */         
/* 2407 */         currQuad = currQuad << 8 | 0xE0 | ch >> 12;
/*      */         
/* 2409 */         if (++currQuadBytes >= 4) {
/* 2410 */           this._quadBuffer[this._quadLength++] = currQuad;
/* 2411 */           currQuad = 0;
/* 2412 */           currQuadBytes = 0;
/*      */         } 
/* 2414 */         currQuad = currQuad << 8 | 0x80 | ch >> 6 & 0x3F;
/* 2415 */         currQuadBytes++;
/*      */       } 
/*      */       
/* 2418 */       ch = 0x80 | ch & 0x3F;
/*      */     } 
/* 2420 */     if (currQuadBytes < 4) {
/* 2421 */       currQuadBytes++;
/* 2422 */       currQuad = currQuad << 8 | ch;
/*      */     } else {
/* 2424 */       this._quadBuffer[this._quadLength++] = currQuad;
/* 2425 */       currQuad = ch;
/* 2426 */       currQuadBytes = 1;
/*      */     } 
/* 2428 */     if (this._minorStateAfterSplit == 9) {
/* 2429 */       return _finishAposName(this._quadLength, currQuad, currQuadBytes);
/*      */     }
/* 2431 */     return _parseEscapedName(this._quadLength, currQuad, currQuadBytes);
/*      */   }
/*      */ 
/*      */   
/*      */   private int _decodeSplitEscaped(int value, int bytesRead) throws IOException {
/* 2436 */     if (this._inputPtr >= this._inputEnd) {
/* 2437 */       this._quoted32 = value;
/* 2438 */       this._quotedDigits = bytesRead;
/* 2439 */       return -1;
/*      */     } 
/* 2441 */     int c = getNextSignedByteFromBuffer();
/* 2442 */     if (bytesRead == -1) {
/* 2443 */       char ch; switch (c) {
/*      */         
/*      */         case 98:
/* 2446 */           return 8;
/*      */         case 116:
/* 2448 */           return 9;
/*      */         case 110:
/* 2450 */           return 10;
/*      */         case 102:
/* 2452 */           return 12;
/*      */         case 114:
/* 2454 */           return 13;
/*      */ 
/*      */         
/*      */         case 34:
/*      */         case 47:
/*      */         case 92:
/* 2460 */           return c;
/*      */ 
/*      */ 
/*      */         
/*      */         case 117:
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 2469 */           ch = (char)c;
/* 2470 */           return _handleUnrecognizedCharacterEscape(ch);
/*      */       } 
/*      */       
/* 2473 */       if (this._inputPtr >= this._inputEnd) {
/* 2474 */         this._quotedDigits = 0;
/* 2475 */         this._quoted32 = 0;
/* 2476 */         return -1;
/*      */       } 
/* 2478 */       c = getNextSignedByteFromBuffer();
/* 2479 */       bytesRead = 0;
/*      */     } 
/* 2481 */     c &= 0xFF;
/*      */     while (true) {
/* 2483 */       int digit = CharTypes.charToHex(c);
/* 2484 */       if (digit < 0) {
/* 2485 */         _reportUnexpectedChar(c & 0xFF, "expected a hex-digit for character escape sequence");
/*      */       }
/* 2487 */       value = value << 4 | digit;
/* 2488 */       if (++bytesRead == 4) {
/* 2489 */         return value;
/*      */       }
/* 2491 */       if (this._inputPtr >= this._inputEnd) {
/* 2492 */         this._quotedDigits = bytesRead;
/* 2493 */         this._quoted32 = value;
/* 2494 */         return -1;
/*      */       } 
/* 2496 */       c = getNextUnsignedByteFromBuffer();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonToken _startString() throws IOException {
/* 2508 */     int ptr = this._inputPtr;
/* 2509 */     int outPtr = 0;
/* 2510 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2511 */     int[] codes = _icUTF8;
/*      */     
/* 2513 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2514 */     while (ptr < max) {
/* 2515 */       int c = getByteFromBuffer(ptr) & 0xFF;
/* 2516 */       if (codes[c] != 0) {
/* 2517 */         if (c == 34) {
/* 2518 */           this._inputPtr = ptr + 1;
/* 2519 */           this._textBuffer.setCurrentLength(outPtr);
/* 2520 */           return _valueComplete(JsonToken.VALUE_STRING);
/*      */         } 
/*      */         break;
/*      */       } 
/* 2524 */       ptr++;
/* 2525 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 2527 */     this._textBuffer.setCurrentLength(outPtr);
/* 2528 */     this._inputPtr = ptr;
/* 2529 */     return _finishRegularString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _finishRegularString() throws IOException {
/* 2537 */     int[] codes = _icUTF8;
/*      */     
/* 2539 */     char[] outBuf = this._textBuffer.getBufferWithoutReset();
/* 2540 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2541 */     int ptr = this._inputPtr;
/* 2542 */     int safeEnd = this._inputEnd - 5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2549 */       if (ptr >= this._inputEnd) {
/* 2550 */         this._inputPtr = ptr;
/* 2551 */         this._minorState = 40;
/* 2552 */         this._textBuffer.setCurrentLength(outPtr);
/* 2553 */         return _updateTokenToNA();
/*      */       } 
/* 2555 */       if (outPtr >= outBuf.length) {
/* 2556 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2557 */         outPtr = 0;
/*      */       } 
/* 2559 */       int max = Math.min(this._inputEnd, 
/*      */           
/* 2561 */           InternalJacksonUtil.addOverflowSafe(ptr, outBuf.length - outPtr));
/* 2562 */       while (ptr < max) {
/* 2563 */         int c = getByteFromBuffer(ptr++) & 0xFF;
/* 2564 */         if (codes[c] != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2571 */           if (c == 34) {
/* 2572 */             this._inputPtr = ptr;
/* 2573 */             this._textBuffer.setCurrentLength(outPtr);
/* 2574 */             return _valueComplete(JsonToken.VALUE_STRING);
/*      */           } 
/*      */           
/* 2577 */           if (ptr >= safeEnd) {
/* 2578 */             this._inputPtr = ptr;
/* 2579 */             this._textBuffer.setCurrentLength(outPtr);
/* 2580 */             if (!_decodeSplitMultiByte(c, codes[c], (ptr < this._inputEnd))) {
/* 2581 */               this._minorStateAfterSplit = 40;
/* 2582 */               return _updateTokenToNA();
/*      */             } 
/* 2584 */             outBuf = this._textBuffer.getBufferWithoutReset();
/* 2585 */             outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2586 */             ptr = this._inputPtr;
/*      */             
/*      */             continue;
/*      */           } 
/* 2590 */           switch (codes[c]) {
/*      */             case 1:
/* 2592 */               this._inputPtr = ptr;
/* 2593 */               c = _decodeFastCharEscape();
/* 2594 */               ptr = this._inputPtr;
/*      */               break;
/*      */             case 2:
/* 2597 */               c = _decodeUTF8_2(c, getByteFromBuffer(ptr++));
/*      */               break;
/*      */             case 3:
/* 2600 */               c = _decodeUTF8_3(c, getByteFromBuffer(ptr++), getByteFromBuffer(ptr++));
/*      */               break;
/*      */             case 4:
/* 2603 */               c = _decodeUTF8_4(c, getByteFromBuffer(ptr++), getByteFromBuffer(ptr++), 
/* 2604 */                   getByteFromBuffer(ptr++));
/*      */               
/* 2606 */               outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2607 */               if (outPtr >= outBuf.length) {
/* 2608 */                 outBuf = this._textBuffer.finishCurrentSegment();
/* 2609 */                 outPtr = 0;
/*      */               } 
/* 2611 */               c = 0xDC00 | c & 0x3FF;
/*      */               break;
/*      */             
/*      */             default:
/* 2615 */               if (c < 32) {
/*      */                 
/* 2617 */                 _throwUnquotedSpace(c, "string value");
/*      */                 break;
/*      */               } 
/* 2620 */               _reportInvalidChar(c);
/*      */               break;
/*      */           } 
/*      */           
/* 2624 */           if (outPtr >= outBuf.length) {
/* 2625 */             outBuf = this._textBuffer.finishCurrentSegment();
/* 2626 */             outPtr = 0;
/*      */           } 
/*      */           
/* 2629 */           outBuf[outPtr++] = (char)c;
/*      */           continue;
/*      */         } 
/*      */         outBuf[outPtr++] = (char)c;
/*      */       } 
/*      */     }  } protected JsonToken _startAposString() throws IOException {
/* 2635 */     int ptr = this._inputPtr;
/* 2636 */     int outPtr = 0;
/* 2637 */     char[] outBuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 2638 */     int[] codes = _icUTF8;
/*      */     
/* 2640 */     int max = Math.min(this._inputEnd, ptr + outBuf.length);
/* 2641 */     while (ptr < max) {
/* 2642 */       int c = getByteFromBuffer(ptr) & 0xFF;
/* 2643 */       if (c == 39) {
/* 2644 */         this._inputPtr = ptr + 1;
/* 2645 */         this._textBuffer.setCurrentLength(outPtr);
/* 2646 */         return _valueComplete(JsonToken.VALUE_STRING);
/*      */       } 
/*      */       
/* 2649 */       if (codes[c] != 0) {
/*      */         break;
/*      */       }
/* 2652 */       ptr++;
/* 2653 */       outBuf[outPtr++] = (char)c;
/*      */     } 
/* 2655 */     this._textBuffer.setCurrentLength(outPtr);
/* 2656 */     this._inputPtr = ptr;
/* 2657 */     return _finishAposString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final JsonToken _finishAposString() throws IOException {
/* 2663 */     int[] codes = _icUTF8;
/*      */     
/* 2665 */     char[] outBuf = this._textBuffer.getBufferWithoutReset();
/* 2666 */     int outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2667 */     int ptr = this._inputPtr;
/* 2668 */     int safeEnd = this._inputEnd - 5;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2674 */       if (ptr >= this._inputEnd) {
/* 2675 */         this._inputPtr = ptr;
/* 2676 */         this._minorState = 45;
/* 2677 */         this._textBuffer.setCurrentLength(outPtr);
/* 2678 */         return _updateTokenToNA();
/*      */       } 
/* 2680 */       if (outPtr >= outBuf.length) {
/* 2681 */         outBuf = this._textBuffer.finishCurrentSegment();
/* 2682 */         outPtr = 0;
/*      */       } 
/* 2684 */       int max = Math.min(this._inputEnd, 
/*      */           
/* 2686 */           InternalJacksonUtil.addOverflowSafe(ptr, outBuf.length - outPtr));
/* 2687 */       while (ptr < max) {
/* 2688 */         int c = getByteFromBuffer(ptr++) & 0xFF;
/* 2689 */         if (codes[c] != 0 && c != 34) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2702 */           if (ptr >= safeEnd) {
/* 2703 */             this._inputPtr = ptr;
/* 2704 */             this._textBuffer.setCurrentLength(outPtr);
/* 2705 */             if (!_decodeSplitMultiByte(c, codes[c], (ptr < this._inputEnd))) {
/* 2706 */               this._minorStateAfterSplit = 45;
/* 2707 */               return _updateTokenToNA();
/*      */             } 
/* 2709 */             outBuf = this._textBuffer.getBufferWithoutReset();
/* 2710 */             outPtr = this._textBuffer.getCurrentSegmentSize();
/* 2711 */             ptr = this._inputPtr;
/*      */             
/*      */             continue;
/*      */           } 
/* 2715 */           switch (codes[c]) {
/*      */             case 1:
/* 2717 */               this._inputPtr = ptr;
/* 2718 */               c = _decodeFastCharEscape();
/* 2719 */               ptr = this._inputPtr;
/*      */               break;
/*      */             case 2:
/* 2722 */               c = _decodeUTF8_2(c, getByteFromBuffer(ptr++));
/*      */               break;
/*      */             case 3:
/* 2725 */               c = _decodeUTF8_3(c, getByteFromBuffer(ptr++), getByteFromBuffer(ptr++));
/*      */               break;
/*      */             case 4:
/* 2728 */               c = _decodeUTF8_4(c, getByteFromBuffer(ptr++), getByteFromBuffer(ptr++), 
/* 2729 */                   getByteFromBuffer(ptr++));
/*      */               
/* 2731 */               outBuf[outPtr++] = (char)(0xD800 | c >> 10);
/* 2732 */               if (outPtr >= outBuf.length) {
/* 2733 */                 outBuf = this._textBuffer.finishCurrentSegment();
/* 2734 */                 outPtr = 0;
/*      */               } 
/* 2736 */               c = 0xDC00 | c & 0x3FF;
/*      */               break;
/*      */             
/*      */             default:
/* 2740 */               if (c < 32) {
/*      */                 
/* 2742 */                 _throwUnquotedSpace(c, "string value");
/*      */                 break;
/*      */               } 
/* 2745 */               _reportInvalidChar(c);
/*      */               break;
/*      */           } 
/*      */           
/* 2749 */           if (outPtr >= outBuf.length) {
/* 2750 */             outBuf = this._textBuffer.finishCurrentSegment();
/* 2751 */             outPtr = 0;
/*      */           } 
/*      */           
/* 2754 */           outBuf[outPtr++] = (char)c; continue;
/*      */         }  if (c == 39) {
/*      */           this._inputPtr = ptr; this._textBuffer.setCurrentLength(outPtr);
/*      */           return _valueComplete(JsonToken.VALUE_STRING);
/*      */         } 
/*      */         outBuf[outPtr++] = (char)c;
/*      */       } 
/* 2761 */     }  } private final boolean _decodeSplitMultiByte(int c, int type, boolean gotNext) throws IOException { switch (type) {
/*      */       case 1:
/* 2763 */         c = _decodeSplitEscaped(0, -1);
/* 2764 */         if (c < 0) {
/* 2765 */           this._minorState = 41;
/* 2766 */           return false;
/*      */         } 
/* 2768 */         this._textBuffer.append((char)c);
/* 2769 */         return true;
/*      */       case 2:
/* 2771 */         if (gotNext) {
/*      */           
/* 2773 */           c = _decodeUTF8_2(c, getNextSignedByteFromBuffer());
/* 2774 */           this._textBuffer.append((char)c);
/* 2775 */           return true;
/*      */         } 
/* 2777 */         this._minorState = 42;
/* 2778 */         this._pending32 = c;
/* 2779 */         return false;
/*      */       case 3:
/* 2781 */         c &= 0xF;
/* 2782 */         if (gotNext) {
/* 2783 */           return _decodeSplitUTF8_3(c, 1, getNextSignedByteFromBuffer());
/*      */         }
/* 2785 */         this._minorState = 43;
/* 2786 */         this._pending32 = c;
/* 2787 */         this._pendingBytes = 1;
/* 2788 */         return false;
/*      */       case 4:
/* 2790 */         c &= 0x7;
/* 2791 */         if (gotNext) {
/* 2792 */           return _decodeSplitUTF8_4(c, 1, getNextSignedByteFromBuffer());
/*      */         }
/* 2794 */         this._pending32 = c;
/* 2795 */         this._pendingBytes = 1;
/* 2796 */         this._minorState = 44;
/* 2797 */         return false;
/*      */     } 
/* 2799 */     if (c < 32) {
/*      */       
/* 2801 */       _throwUnquotedSpace(c, "string value");
/*      */     } else {
/*      */       
/* 2804 */       _reportInvalidChar(c);
/*      */     } 
/* 2806 */     this._textBuffer.append((char)c);
/* 2807 */     return true; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean _decodeSplitUTF8_3(int prev, int prevCount, int next) throws IOException {
/* 2814 */     if (prevCount == 1) {
/* 2815 */       if ((next & 0xC0) != 128) {
/* 2816 */         _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */       }
/* 2818 */       prev = prev << 6 | next & 0x3F;
/* 2819 */       if (this._inputPtr >= this._inputEnd) {
/* 2820 */         this._minorState = 43;
/* 2821 */         this._pending32 = prev;
/* 2822 */         this._pendingBytes = 2;
/* 2823 */         return false;
/*      */       } 
/* 2825 */       next = getNextSignedByteFromBuffer();
/*      */     } 
/* 2827 */     if ((next & 0xC0) != 128) {
/* 2828 */       _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */     }
/* 2830 */     this._textBuffer.append((char)(prev << 6 | next & 0x3F));
/* 2831 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean _decodeSplitUTF8_4(int prev, int prevCount, int next) throws IOException {
/* 2839 */     if (prevCount == 1) {
/* 2840 */       if ((next & 0xC0) != 128) {
/* 2841 */         _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */       }
/* 2843 */       prev = prev << 6 | next & 0x3F;
/* 2844 */       if (this._inputPtr >= this._inputEnd) {
/* 2845 */         this._minorState = 44;
/* 2846 */         this._pending32 = prev;
/* 2847 */         this._pendingBytes = 2;
/* 2848 */         return false;
/*      */       } 
/* 2850 */       prevCount = 2;
/* 2851 */       next = getNextSignedByteFromBuffer();
/*      */     } 
/* 2853 */     if (prevCount == 2) {
/* 2854 */       if ((next & 0xC0) != 128) {
/* 2855 */         _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */       }
/* 2857 */       prev = prev << 6 | next & 0x3F;
/* 2858 */       if (this._inputPtr >= this._inputEnd) {
/* 2859 */         this._minorState = 44;
/* 2860 */         this._pending32 = prev;
/* 2861 */         this._pendingBytes = 3;
/* 2862 */         return false;
/*      */       } 
/* 2864 */       next = getNextSignedByteFromBuffer();
/*      */     } 
/* 2866 */     if ((next & 0xC0) != 128) {
/* 2867 */       _reportInvalidOther(next & 0xFF, this._inputPtr);
/*      */     }
/* 2869 */     int c = (prev << 6 | next & 0x3F) - 65536;
/*      */     
/* 2871 */     this._textBuffer.append((char)(0xD800 | c >> 10));
/* 2872 */     c = 0xDC00 | c & 0x3FF;
/*      */     
/* 2874 */     this._textBuffer.append((char)c);
/* 2875 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeCharEscape() throws IOException {
/* 2886 */     int left = this._inputEnd - this._inputPtr;
/* 2887 */     if (left < 5) {
/* 2888 */       return _decodeSplitEscaped(0, -1);
/*      */     }
/* 2890 */     return _decodeFastCharEscape();
/*      */   }
/*      */   
/*      */   private final int _decodeFastCharEscape() throws IOException {
/*      */     char c1;
/* 2895 */     int c = getNextSignedByteFromBuffer();
/* 2896 */     switch (c) {
/*      */       
/*      */       case 98:
/* 2899 */         return 8;
/*      */       case 116:
/* 2901 */         return 9;
/*      */       case 110:
/* 2903 */         return 10;
/*      */       case 102:
/* 2905 */         return 12;
/*      */       case 114:
/* 2907 */         return 13;
/*      */ 
/*      */       
/*      */       case 34:
/*      */       case 47:
/*      */       case 92:
/* 2913 */         return (char)c;
/*      */ 
/*      */ 
/*      */       
/*      */       case 117:
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2922 */         c1 = (char)c;
/* 2923 */         return _handleUnrecognizedCharacterEscape(c1);
/*      */     } 
/*      */ 
/*      */     
/* 2927 */     int ch = getNextSignedByteFromBuffer();
/* 2928 */     int digit = CharTypes.charToHex(ch);
/* 2929 */     int result = digit;
/*      */     
/* 2931 */     if (digit >= 0) {
/* 2932 */       ch = getNextSignedByteFromBuffer();
/* 2933 */       digit = CharTypes.charToHex(ch);
/* 2934 */       if (digit >= 0) {
/* 2935 */         result = result << 4 | digit;
/* 2936 */         ch = getNextSignedByteFromBuffer();
/* 2937 */         digit = CharTypes.charToHex(ch);
/* 2938 */         if (digit >= 0) {
/* 2939 */           result = result << 4 | digit;
/* 2940 */           ch = getNextSignedByteFromBuffer();
/* 2941 */           digit = CharTypes.charToHex(ch);
/* 2942 */           if (digit >= 0) {
/* 2943 */             return result << 4 | digit;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 2948 */     _reportUnexpectedChar(ch & 0xFF, "expected a hex-digit for character escape sequence");
/* 2949 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUTF8_2(int c, int d) throws IOException {
/* 2960 */     if ((d & 0xC0) != 128) {
/* 2961 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2963 */     return (c & 0x1F) << 6 | d & 0x3F;
/*      */   }
/*      */ 
/*      */   
/*      */   private final int _decodeUTF8_3(int c, int d, int e) throws IOException {
/* 2968 */     c &= 0xF;
/* 2969 */     if ((d & 0xC0) != 128) {
/* 2970 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2972 */     c = c << 6 | d & 0x3F;
/* 2973 */     if ((e & 0xC0) != 128) {
/* 2974 */       _reportInvalidOther(e & 0xFF, this._inputPtr);
/*      */     }
/* 2976 */     return c << 6 | e & 0x3F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _decodeUTF8_4(int c, int d, int e, int f) throws IOException {
/* 2983 */     if ((d & 0xC0) != 128) {
/* 2984 */       _reportInvalidOther(d & 0xFF, this._inputPtr);
/*      */     }
/* 2986 */     c = (c & 0x7) << 6 | d & 0x3F;
/* 2987 */     if ((e & 0xC0) != 128) {
/* 2988 */       _reportInvalidOther(e & 0xFF, this._inputPtr);
/*      */     }
/* 2990 */     c = c << 6 | e & 0x3F;
/* 2991 */     if ((f & 0xC0) != 128) {
/* 2992 */       _reportInvalidOther(f & 0xFF, this._inputPtr);
/*      */     }
/* 2994 */     return (c << 6 | f & 0x3F) - 65536;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\json\async\NonBlockingUtf8JsonParserBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */