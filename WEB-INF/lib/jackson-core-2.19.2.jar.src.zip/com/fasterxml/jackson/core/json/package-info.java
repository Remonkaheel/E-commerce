package com.fasterxml.jackson.core.json;


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\json\package-info.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */