/*    */ package com.fasterxml.jackson.core.json.async;
/*    */ 
/*    */ import com.fasterxml.jackson.core.async.ByteBufferFeeder;
/*    */ import com.fasterxml.jackson.core.async.NonBlockingInputFeeder;
/*    */ import com.fasterxml.jackson.core.io.IOContext;
/*    */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.nio.ByteBuffer;
/*    */ import java.nio.channels.Channels;
/*    */ import java.nio.channels.WritableByteChannel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NonBlockingByteBufferJsonParser
/*    */   extends NonBlockingUtf8JsonParserBase
/*    */   implements ByteBufferFeeder
/*    */ {
/* 27 */   private ByteBuffer _inputBuffer = ByteBuffer.wrap(NO_BYTES);
/*    */ 
/*    */   
/*    */   public NonBlockingByteBufferJsonParser(IOContext ctxt, int parserFeatures, ByteQuadsCanonicalizer sym) {
/* 31 */     super(ctxt, parserFeatures, sym);
/*    */   }
/*    */ 
/*    */   
/*    */   public NonBlockingInputFeeder getNonBlockingInputFeeder() {
/* 36 */     return (NonBlockingInputFeeder)this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void feedInput(ByteBuffer byteBuffer) throws IOException {
/* 42 */     if (this._inputPtr < this._inputEnd) {
/* 43 */       _reportError("Still have %d undecoded bytes, should not call 'feedInput'", Integer.valueOf(this._inputEnd - this._inputPtr));
/*    */     }
/*    */     
/* 46 */     int start = byteBuffer.position();
/* 47 */     int end = byteBuffer.limit();
/*    */     
/* 49 */     if (end < start) {
/* 50 */       _reportError("Input end (%d) may not be before start (%d)", Integer.valueOf(end), Integer.valueOf(start));
/*    */     }
/*    */     
/* 53 */     if (this._endOfInput) {
/* 54 */       _reportError("Already closed, can not feed more input");
/*    */     }
/*    */     
/* 57 */     this._currInputProcessed += this._origBufferLen;
/*    */ 
/*    */     
/* 60 */     this._streamReadConstraints.validateDocumentLength(this._currInputProcessed);
/*    */ 
/*    */     
/* 63 */     this._currInputRowStart = start - this._inputEnd - this._currInputRowStart;
/*    */ 
/*    */     
/* 66 */     this._currBufferStart = start;
/* 67 */     this._inputBuffer = byteBuffer;
/* 68 */     this._inputPtr = start;
/* 69 */     this._inputEnd = end;
/* 70 */     this._origBufferLen = end - start;
/*    */   }
/*    */ 
/*    */   
/*    */   public int releaseBuffered(OutputStream out) throws IOException {
/* 75 */     int avail = this._inputEnd - this._inputPtr;
/* 76 */     if (avail > 0) {
/* 77 */       WritableByteChannel channel = Channels.newChannel(out);
/* 78 */       channel.write(this._inputBuffer);
/*    */     } 
/* 80 */     return avail;
/*    */   }
/*    */ 
/*    */   
/*    */   protected byte getNextSignedByteFromBuffer() {
/* 85 */     return this._inputBuffer.get(this._inputPtr++);
/*    */   }
/*    */ 
/*    */   
/*    */   protected int getNextUnsignedByteFromBuffer() {
/* 90 */     return this._inputBuffer.get(this._inputPtr++) & 0xFF;
/*    */   }
/*    */ 
/*    */   
/*    */   protected byte getByteFromBuffer(int ptr) {
/* 95 */     return this._inputBuffer.get(ptr);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\json\async\NonBlockingByteBufferJsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */