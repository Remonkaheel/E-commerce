/*     */ package com.fasterxml.jackson.core.json.async;
/*     */ 
/*     */ import com.fasterxml.jackson.core.Base64Variant;
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParseException;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.core.exc.StreamConstraintsException;
/*     */ import com.fasterxml.jackson.core.io.IOContext;
/*     */ import com.fasterxml.jackson.core.json.JsonParserBase;
/*     */ import com.fasterxml.jackson.core.json.JsonReadContext;
/*     */ import com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer;
/*     */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NonBlockingJsonParserBase
/*     */   extends JsonParserBase
/*     */ {
/*     */   protected static final int MAJOR_INITIAL = 0;
/*     */   protected static final int MAJOR_ROOT = 1;
/*     */   protected static final int MAJOR_OBJECT_FIELD_FIRST = 2;
/*     */   protected static final int MAJOR_OBJECT_FIELD_NEXT = 3;
/*     */   protected static final int MAJOR_OBJECT_VALUE = 4;
/*     */   protected static final int MAJOR_ARRAY_ELEMENT_FIRST = 5;
/*     */   protected static final int MAJOR_ARRAY_ELEMENT_NEXT = 6;
/*     */   protected static final int MAJOR_CLOSED = 7;
/*     */   protected static final int MINOR_ROOT_BOM = 1;
/*     */   protected static final int MINOR_ROOT_NEED_SEPARATOR = 2;
/*     */   protected static final int MINOR_ROOT_GOT_SEPARATOR = 3;
/*     */   protected static final int MINOR_FIELD_LEADING_WS = 4;
/*     */   protected static final int MINOR_FIELD_LEADING_COMMA = 5;
/*     */   protected static final int MINOR_FIELD_NAME = 7;
/*     */   protected static final int MINOR_FIELD_NAME_ESCAPE = 8;
/*     */   protected static final int MINOR_FIELD_APOS_NAME = 9;
/*     */   protected static final int MINOR_FIELD_UNQUOTED_NAME = 10;
/*     */   protected static final int MINOR_VALUE_LEADING_WS = 12;
/*     */   protected static final int MINOR_VALUE_EXPECTING_COMMA = 13;
/*     */   protected static final int MINOR_VALUE_EXPECTING_COLON = 14;
/*     */   protected static final int MINOR_VALUE_WS_AFTER_COMMA = 15;
/*     */   protected static final int MINOR_VALUE_TOKEN_NULL = 16;
/*     */   protected static final int MINOR_VALUE_TOKEN_TRUE = 17;
/*     */   protected static final int MINOR_VALUE_TOKEN_FALSE = 18;
/*     */   protected static final int MINOR_VALUE_TOKEN_NON_STD = 19;
/*     */   protected static final int MINOR_NUMBER_PLUS = 22;
/*     */   protected static final int MINOR_NUMBER_MINUS = 23;
/*     */   protected static final int MINOR_NUMBER_ZERO = 24;
/*     */   protected static final int MINOR_NUMBER_MINUSZERO = 25;
/*     */   protected static final int MINOR_NUMBER_INTEGER_DIGITS = 26;
/*     */   protected static final int MINOR_NUMBER_FRACTION_DIGITS = 30;
/*     */   protected static final int MINOR_NUMBER_EXPONENT_MARKER = 31;
/*     */   protected static final int MINOR_NUMBER_EXPONENT_DIGITS = 32;
/*     */   protected static final int MINOR_VALUE_STRING = 40;
/*     */   protected static final int MINOR_VALUE_STRING_ESCAPE = 41;
/*     */   protected static final int MINOR_VALUE_STRING_UTF8_2 = 42;
/*     */   protected static final int MINOR_VALUE_STRING_UTF8_3 = 43;
/*     */   protected static final int MINOR_VALUE_STRING_UTF8_4 = 44;
/*     */   protected static final int MINOR_VALUE_APOS_STRING = 45;
/*     */   protected static final int MINOR_VALUE_TOKEN_ERROR = 50;
/*     */   protected static final int MINOR_COMMENT_LEADING_SLASH = 51;
/*     */   protected static final int MINOR_COMMENT_CLOSING_ASTERISK = 52;
/*     */   protected static final int MINOR_COMMENT_C = 53;
/*     */   protected static final int MINOR_COMMENT_CPP = 54;
/*     */   protected static final int MINOR_COMMENT_YAML = 55;
/*     */   protected final ByteQuadsCanonicalizer _symbols;
/* 151 */   protected int[] _quadBuffer = new int[8];
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _quadLength;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _quad1;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _pending32;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _pendingBytes;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _quoted32;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _quotedDigits;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _majorState;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _majorStateAfterValue;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _minorState;
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _minorStateAfterSplit;
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _endOfInput = false;
/*     */ 
/*     */   
/*     */   protected static final int NON_STD_TOKEN_NAN = 0;
/*     */ 
/*     */   
/*     */   protected static final int NON_STD_TOKEN_INFINITY = 1;
/*     */ 
/*     */   
/*     */   protected static final int NON_STD_TOKEN_PLUS_INFINITY = 2;
/*     */ 
/*     */   
/*     */   protected static final int NON_STD_TOKEN_MINUS_INFINITY = 3;
/*     */ 
/*     */   
/* 210 */   protected static final String[] NON_STD_TOKENS = new String[] { "NaN", "Infinity", "+Infinity", "-Infinity" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   protected static final double[] NON_STD_TOKEN_VALUES = new double[] { Double.NaN, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int _nonStdTokenType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 237 */   protected int _currBufferStart = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 246 */   protected int _currInputRowAlt = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NonBlockingJsonParserBase(IOContext ctxt, int parserFeatures, ByteQuadsCanonicalizer sym) {
/* 257 */     super(ctxt, parserFeatures, null);
/* 258 */     this._symbols = sym;
/* 259 */     this._currToken = null;
/* 260 */     this._majorState = 0;
/* 261 */     this._majorStateAfterValue = 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCodec(ObjectCodec c) {
/* 266 */     throw new UnsupportedOperationException("Cannot use ObjectMapper with non-blocking parser");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canParseAsync() {
/* 276 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ByteQuadsCanonicalizer symbolTableForTests() {
/* 285 */     return this._symbols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int releaseBuffered(OutputStream paramOutputStream) throws IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _releaseBuffers() throws IOException {
/* 300 */     super._releaseBuffers();
/*     */     
/* 302 */     this._symbols.release();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getInputSource() {
/* 309 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _closeInput() throws IOException {
/* 317 */     this._currBufferStart = 0;
/* 318 */     this._inputEnd = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasTextCharacters() {
/* 330 */     if (this._currToken == JsonToken.VALUE_STRING)
/*     */     {
/* 332 */       return this._textBuffer.hasTextAsCharacters();
/*     */     }
/* 334 */     if (this._currToken == JsonToken.FIELD_NAME)
/*     */     {
/* 336 */       return this._nameCopied;
/*     */     }
/*     */     
/* 339 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonLocation currentLocation() {
/* 345 */     int col = this._inputPtr - this._currInputRowStart + 1;
/*     */     
/* 347 */     int row = Math.max(this._currInputRow, this._currInputRowAlt);
/* 348 */     return new JsonLocation(_contentReference(), this._currInputProcessed + (this._inputPtr - this._currBufferStart), -1L, row, col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonLocation _currentLocationMinusOne() {
/* 355 */     int prevInputPtr = this._inputPtr - 1;
/* 356 */     int row = Math.max(this._currInputRow, this._currInputRowAlt);
/* 357 */     int col = prevInputPtr - this._currInputRowStart + 1;
/* 358 */     return new JsonLocation(_contentReference(), this._currInputProcessed + (prevInputPtr - this._currBufferStart), -1L, row, col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonLocation currentTokenLocation() {
/* 366 */     return new JsonLocation(_contentReference(), this._tokenInputTotal, -1L, this._tokenInputRow, this._tokenInputCol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() throws IOException {
/* 388 */     if (this._currToken == JsonToken.VALUE_STRING) {
/* 389 */       return this._textBuffer.contentsAsString();
/*     */     }
/* 391 */     return _getText2(this._currToken);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final String _getText2(JsonToken t) throws IOException {
/* 396 */     if (t == null) {
/* 397 */       return null;
/*     */     }
/* 399 */     switch (t.id()) {
/*     */       case -1:
/* 401 */         return null;
/*     */       case 5:
/* 403 */         return this._parsingContext.getCurrentName();
/*     */       
/*     */       case 6:
/*     */       case 7:
/*     */       case 8:
/* 408 */         return this._textBuffer.contentsAsString();
/*     */     } 
/* 410 */     return t.asString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getText(Writer writer) throws IOException {
/* 417 */     JsonToken t = this._currToken;
/* 418 */     if (t == JsonToken.VALUE_STRING) {
/* 419 */       return this._textBuffer.contentsToWriter(writer);
/*     */     }
/* 421 */     if (t == JsonToken.FIELD_NAME) {
/* 422 */       String n = this._parsingContext.getCurrentName();
/* 423 */       writer.write(n);
/* 424 */       return n.length();
/*     */     } 
/* 426 */     if (t != null) {
/* 427 */       if (t.isNumeric()) {
/* 428 */         return this._textBuffer.contentsToWriter(writer);
/*     */       }
/* 430 */       if (t == JsonToken.NOT_AVAILABLE) {
/* 431 */         _reportError("Current token not available: can not call this method");
/*     */       }
/* 433 */       char[] ch = t.asCharArray();
/* 434 */       writer.write(ch);
/* 435 */       return ch.length;
/*     */     } 
/* 437 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValueAsString() throws IOException {
/* 446 */     if (this._currToken == JsonToken.VALUE_STRING) {
/* 447 */       return this._textBuffer.contentsAsString();
/*     */     }
/* 449 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 450 */       return currentName();
/*     */     }
/* 452 */     return super.getValueAsString(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValueAsString(String defValue) throws IOException {
/* 459 */     if (this._currToken == JsonToken.VALUE_STRING) {
/* 460 */       return this._textBuffer.contentsAsString();
/*     */     }
/* 462 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 463 */       return currentName();
/*     */     }
/* 465 */     return super.getValueAsString(defValue);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] getTextCharacters() throws IOException {
/* 471 */     if (this._currToken != null) {
/* 472 */       switch (this._currToken.id()) {
/*     */         
/*     */         case 5:
/* 475 */           if (!this._nameCopied) {
/* 476 */             String name = this._parsingContext.getCurrentName();
/* 477 */             int nameLen = name.length();
/* 478 */             if (this._nameCopyBuffer == null) {
/* 479 */               this._nameCopyBuffer = this._ioContext.allocNameCopyBuffer(nameLen);
/* 480 */             } else if (this._nameCopyBuffer.length < nameLen) {
/* 481 */               this._nameCopyBuffer = new char[nameLen];
/*     */             } 
/* 483 */             name.getChars(0, nameLen, this._nameCopyBuffer, 0);
/* 484 */             this._nameCopied = true;
/*     */           } 
/* 486 */           return this._nameCopyBuffer;
/*     */ 
/*     */         
/*     */         case 6:
/*     */         case 7:
/*     */         case 8:
/* 492 */           return this._textBuffer.getTextBuffer();
/*     */       } 
/*     */       
/* 495 */       return this._currToken.asCharArray();
/*     */     } 
/*     */     
/* 498 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTextLength() throws IOException {
/* 504 */     if (this._currToken != null) {
/* 505 */       switch (this._currToken.id()) {
/*     */         
/*     */         case 5:
/* 508 */           return this._parsingContext.getCurrentName().length();
/*     */         
/*     */         case 6:
/*     */         case 7:
/*     */         case 8:
/* 513 */           return this._textBuffer.size();
/*     */       } 
/*     */       
/* 516 */       return (this._currToken.asCharArray()).length;
/*     */     } 
/*     */     
/* 519 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTextOffset() throws IOException {
/* 526 */     if (this._currToken != null) {
/* 527 */       switch (this._currToken.id()) {
/*     */         case 5:
/* 529 */           return 0;
/*     */         
/*     */         case 6:
/*     */         case 7:
/*     */         case 8:
/* 534 */           return this._textBuffer.getTextOffset();
/*     */       } 
/*     */     
/*     */     }
/* 538 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBinaryValue(Base64Variant b64variant) throws IOException {
/* 550 */     if (this._currToken != JsonToken.VALUE_STRING) {
/* 551 */       _reportError("Current token (%s) not VALUE_STRING or VALUE_EMBEDDED_OBJECT, can not access as binary", this._currToken);
/*     */     }
/*     */     
/* 554 */     if (this._binaryValue == null) {
/*     */       
/* 556 */       ByteArrayBuilder builder = _getByteArrayBuilder();
/* 557 */       _decodeBase64(getText(), builder, b64variant);
/* 558 */       this._binaryValue = builder.toByteArray();
/*     */     } 
/* 560 */     return this._binaryValue;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/* 566 */     byte[] b = getBinaryValue(b64variant);
/* 567 */     out.write(b);
/* 568 */     return b.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getEmbeddedObject() throws IOException {
/* 574 */     if (this._currToken == JsonToken.VALUE_EMBEDDED_OBJECT) {
/* 575 */       return this._binaryValue;
/*     */     }
/* 577 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonToken _startArrayScope() throws IOException {
/* 588 */     createChildArrayContext(-1, -1);
/* 589 */     this._majorState = 5;
/* 590 */     this._majorStateAfterValue = 6;
/* 591 */     return _updateToken(JsonToken.START_ARRAY);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final JsonToken _startObjectScope() throws IOException {
/* 596 */     createChildObjectContext(-1, -1);
/* 597 */     this._majorState = 2;
/* 598 */     this._majorStateAfterValue = 3;
/* 599 */     return _updateToken(JsonToken.START_OBJECT);
/*     */   }
/*     */   
/*     */   protected final JsonToken _closeArrayScope() throws IOException {
/*     */     int st;
/* 604 */     if (!this._parsingContext.inArray()) {
/* 605 */       _reportMismatchedEndMarker(93, '}');
/*     */     }
/* 607 */     JsonReadContext ctxt = this._parsingContext.getParent();
/* 608 */     this._parsingContext = ctxt;
/*     */     
/* 610 */     if (ctxt.inObject()) {
/* 611 */       st = 3;
/* 612 */     } else if (ctxt.inArray()) {
/* 613 */       st = 6;
/*     */     } else {
/* 615 */       st = 1;
/*     */     } 
/* 617 */     this._majorState = st;
/* 618 */     this._majorStateAfterValue = st;
/* 619 */     return _updateToken(JsonToken.END_ARRAY);
/*     */   }
/*     */   
/*     */   protected final JsonToken _closeObjectScope() throws IOException {
/*     */     int st;
/* 624 */     if (!this._parsingContext.inObject()) {
/* 625 */       _reportMismatchedEndMarker(125, ']');
/*     */     }
/* 627 */     JsonReadContext ctxt = this._parsingContext.getParent();
/* 628 */     this._parsingContext = ctxt;
/*     */     
/* 630 */     if (ctxt.inObject()) {
/* 631 */       st = 3;
/* 632 */     } else if (ctxt.inArray()) {
/* 633 */       st = 6;
/*     */     } else {
/* 635 */       st = 1;
/*     */     } 
/* 637 */     this._majorState = st;
/* 638 */     this._majorStateAfterValue = st;
/* 639 */     return _updateToken(JsonToken.END_OBJECT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _findName(int q1, int lastQuadBytes) throws JsonParseException, StreamConstraintsException {
/* 651 */     q1 = _padLastQuad(q1, lastQuadBytes);
/*     */     
/* 653 */     String name = this._symbols.findName(q1);
/* 654 */     if (name != null) {
/* 655 */       return name;
/*     */     }
/*     */     
/* 658 */     this._quadBuffer[0] = q1;
/* 659 */     return _addName(this._quadBuffer, 1, lastQuadBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _findName(int q1, int q2, int lastQuadBytes) throws JsonParseException, StreamConstraintsException {
/* 665 */     q2 = _padLastQuad(q2, lastQuadBytes);
/*     */     
/* 667 */     String name = this._symbols.findName(q1, q2);
/* 668 */     if (name != null) {
/* 669 */       return name;
/*     */     }
/*     */     
/* 672 */     this._quadBuffer[0] = q1;
/* 673 */     this._quadBuffer[1] = q2;
/* 674 */     return _addName(this._quadBuffer, 2, lastQuadBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _findName(int q1, int q2, int q3, int lastQuadBytes) throws JsonParseException, StreamConstraintsException {
/* 680 */     q3 = _padLastQuad(q3, lastQuadBytes);
/* 681 */     String name = this._symbols.findName(q1, q2, q3);
/* 682 */     if (name != null) {
/* 683 */       return name;
/*     */     }
/* 685 */     int[] quads = this._quadBuffer;
/* 686 */     quads[0] = q1;
/* 687 */     quads[1] = q2;
/* 688 */     quads[2] = _padLastQuad(q3, lastQuadBytes);
/* 689 */     return _addName(quads, 3, lastQuadBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _addName(int[] quads, int qlen, int lastQuadBytes) throws JsonParseException, StreamConstraintsException {
/* 704 */     int lastQuad, byteLen = (qlen << 2) - 4 + lastQuadBytes;
/* 705 */     this._streamReadConstraints.validateNameLength(byteLen);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 714 */     if (lastQuadBytes < 4) {
/* 715 */       lastQuad = quads[qlen - 1];
/*     */       
/* 717 */       quads[qlen - 1] = lastQuad << 4 - lastQuadBytes << 3;
/*     */     } else {
/* 719 */       lastQuad = 0;
/*     */     } 
/*     */ 
/*     */     
/* 723 */     char[] cbuf = this._textBuffer.emptyAndGetCurrentSegment();
/* 724 */     int cix = 0;
/*     */     
/* 726 */     for (int ix = 0; ix < byteLen; ) {
/* 727 */       int ch = quads[ix >> 2];
/* 728 */       int byteIx = ix & 0x3;
/* 729 */       ch = ch >> 3 - byteIx << 3 & 0xFF;
/* 730 */       ix++;
/*     */       
/* 732 */       if (ch > 127) {
/*     */         int needed;
/* 734 */         if ((ch & 0xE0) == 192) {
/* 735 */           ch &= 0x1F;
/* 736 */           needed = 1;
/* 737 */         } else if ((ch & 0xF0) == 224) {
/* 738 */           ch &= 0xF;
/* 739 */           needed = 2;
/* 740 */         } else if ((ch & 0xF8) == 240) {
/* 741 */           ch &= 0x7;
/* 742 */           needed = 3;
/*     */         } else {
/* 744 */           _reportInvalidInitial(ch);
/* 745 */           needed = ch = 1;
/*     */         } 
/* 747 */         if (ix + needed > byteLen) {
/* 748 */           _reportInvalidEOF(" in field name", JsonToken.FIELD_NAME);
/*     */         }
/*     */ 
/*     */         
/* 752 */         int ch2 = quads[ix >> 2];
/* 753 */         byteIx = ix & 0x3;
/* 754 */         ch2 >>= 3 - byteIx << 3;
/* 755 */         ix++;
/*     */         
/* 757 */         if ((ch2 & 0xC0) != 128) {
/* 758 */           _reportInvalidOther(ch2);
/*     */         }
/* 760 */         ch = ch << 6 | ch2 & 0x3F;
/* 761 */         if (needed > 1) {
/* 762 */           ch2 = quads[ix >> 2];
/* 763 */           byteIx = ix & 0x3;
/* 764 */           ch2 >>= 3 - byteIx << 3;
/* 765 */           ix++;
/*     */           
/* 767 */           if ((ch2 & 0xC0) != 128) {
/* 768 */             _reportInvalidOther(ch2);
/*     */           }
/* 770 */           ch = ch << 6 | ch2 & 0x3F;
/* 771 */           if (needed > 2) {
/* 772 */             ch2 = quads[ix >> 2];
/* 773 */             byteIx = ix & 0x3;
/* 774 */             ch2 >>= 3 - byteIx << 3;
/* 775 */             ix++;
/* 776 */             if ((ch2 & 0xC0) != 128) {
/* 777 */               _reportInvalidOther(ch2 & 0xFF);
/*     */             }
/* 779 */             ch = ch << 6 | ch2 & 0x3F;
/*     */           } 
/*     */         } 
/* 782 */         if (needed > 2) {
/* 783 */           ch -= 65536;
/* 784 */           if (cix >= cbuf.length) {
/* 785 */             cbuf = this._textBuffer.expandCurrentSegment();
/*     */           }
/* 787 */           cbuf[cix++] = (char)(55296 + (ch >> 10));
/* 788 */           ch = 0xDC00 | ch & 0x3FF;
/*     */         } 
/*     */       } 
/* 791 */       if (cix >= cbuf.length) {
/* 792 */         cbuf = this._textBuffer.expandCurrentSegment();
/*     */       }
/* 794 */       cbuf[cix++] = (char)ch;
/*     */     } 
/*     */ 
/*     */     
/* 798 */     String baseName = new String(cbuf, 0, cix);
/*     */     
/* 800 */     if (!this._symbols.isCanonicalizing()) {
/* 801 */       return baseName;
/*     */     }
/*     */     
/* 804 */     if (lastQuadBytes < 4) {
/* 805 */       quads[qlen - 1] = lastQuad;
/*     */     }
/* 807 */     return this._symbols.addName(baseName, quads, qlen);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static final int _padLastQuad(int q, int bytes) {
/* 812 */     return (bytes == 4) ? q : (q | -1 << bytes << 3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonToken _eofAsNextToken() throws IOException {
/* 824 */     this._majorState = 7;
/* 825 */     if (!this._parsingContext.inRoot()) {
/* 826 */       _handleEOF();
/*     */     }
/* 828 */     close();
/* 829 */     return _updateTokenToNull();
/*     */   }
/*     */ 
/*     */   
/*     */   protected final JsonToken _fieldComplete(String name) throws IOException {
/* 834 */     this._majorState = 4;
/* 835 */     this._parsingContext.setCurrentName(name);
/* 836 */     return _updateToken(JsonToken.FIELD_NAME);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final JsonToken _valueComplete(JsonToken t) throws IOException {
/* 841 */     this._majorState = this._majorStateAfterValue;
/* 842 */     return _updateToken(t);
/*     */   }
/*     */ 
/*     */   
/*     */   protected final JsonToken _valueCompleteInt(int value, String asText) throws IOException {
/* 847 */     this._textBuffer.resetWithString(asText);
/* 848 */     this._intLength = asText.length();
/* 849 */     this._numTypesValid = 1;
/* 850 */     this._numberInt = value;
/* 851 */     this._majorState = this._majorStateAfterValue;
/* 852 */     return _updateToken(JsonToken.VALUE_NUMBER_INT);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final JsonToken _valueNonStdNumberComplete(int type) throws IOException {
/* 858 */     String tokenStr = NON_STD_TOKENS[type];
/* 859 */     this._textBuffer.resetWithString(tokenStr);
/* 860 */     if (!isEnabled(JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS)) {
/* 861 */       _reportError("Non-standard token '%s': enable `JsonReadFeature.ALLOW_NON_NUMERIC_NUMBERS` to allow", tokenStr);
/*     */     }
/*     */     
/* 864 */     this._intLength = 0;
/* 865 */     this._numTypesValid = 8;
/* 866 */     this._numberDouble = NON_STD_TOKEN_VALUES[type];
/* 867 */     this._majorState = this._majorStateAfterValue;
/* 868 */     return _updateToken(JsonToken.VALUE_NUMBER_FLOAT);
/*     */   }
/*     */   
/*     */   protected final String _nonStdToken(int type) {
/* 872 */     return NON_STD_TOKENS[type];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void _updateTokenLocation() {
/* 883 */     this._tokenInputRow = Math.max(this._currInputRow, this._currInputRowAlt);
/* 884 */     int ptr = this._inputPtr;
/* 885 */     this._tokenInputCol = ptr - this._currInputRowStart;
/* 886 */     this._tokenInputTotal = this._currInputProcessed + (ptr - this._currBufferStart);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void _reportInvalidChar(int c) throws JsonParseException {
/* 891 */     if (c < 32) {
/* 892 */       _throwInvalidSpace(c);
/*     */     }
/* 894 */     _reportInvalidInitial(c);
/*     */   }
/*     */   
/*     */   protected void _reportInvalidInitial(int mask) throws JsonParseException {
/* 898 */     _reportError("Invalid UTF-8 start byte 0x" + Integer.toHexString(mask));
/*     */   }
/*     */   
/*     */   protected void _reportInvalidOther(int mask, int ptr) throws JsonParseException {
/* 902 */     this._inputPtr = ptr;
/* 903 */     _reportInvalidOther(mask);
/*     */   }
/*     */   
/*     */   protected void _reportInvalidOther(int mask) throws JsonParseException {
/* 907 */     _reportError("Invalid UTF-8 middle byte 0x" + Integer.toHexString(mask));
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\json\async\NonBlockingJsonParserBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */