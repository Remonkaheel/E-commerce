/*     */ package com.fasterxml.jackson.core.json;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.ObjectCodec;
/*     */ import com.fasterxml.jackson.core.StreamReadCapability;
/*     */ import com.fasterxml.jackson.core.base.ParserBase;
/*     */ import com.fasterxml.jackson.core.io.CharTypes;
/*     */ import com.fasterxml.jackson.core.io.IOContext;
/*     */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JsonParserBase
/*     */   extends ParserBase
/*     */ {
/*  22 */   protected static final int FEAT_MASK_TRAILING_COMMA = JsonParser.Feature.ALLOW_TRAILING_COMMA.getMask();
/*     */   
/*  24 */   protected static final int FEAT_MASK_LEADING_ZEROS = JsonParser.Feature.ALLOW_NUMERIC_LEADING_ZEROS.getMask();
/*     */   
/*  26 */   protected static final int FEAT_MASK_NON_NUM_NUMBERS = JsonParser.Feature.ALLOW_NON_NUMERIC_NUMBERS.getMask();
/*     */   
/*  28 */   protected static final int FEAT_MASK_ALLOW_MISSING = JsonParser.Feature.ALLOW_MISSING_VALUES.getMask();
/*     */   
/*  30 */   protected static final int FEAT_MASK_ALLOW_CTRL_RS = JsonParser.Feature.ALLOW_RS_CONTROL_CHAR.getMask();
/*     */   
/*  32 */   protected static final int FEAT_MASK_ALLOW_SINGLE_QUOTES = JsonParser.Feature.ALLOW_SINGLE_QUOTES.getMask();
/*  33 */   protected static final int FEAT_MASK_ALLOW_UNQUOTED_NAMES = JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES.getMask();
/*  34 */   protected static final int FEAT_MASK_ALLOW_JAVA_COMMENTS = JsonParser.Feature.ALLOW_COMMENTS.getMask();
/*  35 */   protected static final int FEAT_MASK_ALLOW_YAML_COMMENTS = JsonParser.Feature.ALLOW_YAML_COMMENTS.getMask();
/*     */ 
/*     */ 
/*     */   
/*  39 */   protected static final int[] INPUT_CODES_LATIN1 = CharTypes.getInputCodeLatin1();
/*     */ 
/*     */   
/*  42 */   protected static final int[] INPUT_CODES_UTF8 = CharTypes.getInputCodeUtf8();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ObjectCodec _objectCodec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonParserBase(IOContext ioCtxt, int features, ObjectCodec codec) {
/*  64 */     super(ioCtxt, features);
/*  65 */     this._objectCodec = codec;
/*     */   }
/*     */ 
/*     */   
/*     */   public ObjectCodec getCodec() {
/*  70 */     return this._objectCodec;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCodec(ObjectCodec c) {
/*  75 */     this._objectCodec = c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final JacksonFeatureSet<StreamReadCapability> getReadCapabilities() {
/*  86 */     return JSON_READ_CAPABILITIES;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParser.NumberTypeFP getNumberTypeFP() throws IOException {
/* 105 */     return JsonParser.NumberTypeFP.UNKNOWN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonLocation currentLocation();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JsonLocation currentTokenLocation();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract JsonLocation _currentLocationMinusOne();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final JsonLocation getCurrentLocation() {
/* 128 */     return currentLocation();
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final JsonLocation getTokenLocation() {
/* 134 */     return currentTokenLocation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _isAllowedCtrlCharRS(int i) {
/* 145 */     return (i == 30 && (this._features & FEAT_MASK_ALLOW_CTRL_RS) != 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\json\JsonParserBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */