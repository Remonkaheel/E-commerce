/*      */ package com.fasterxml.jackson.core.json;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonGenerationException;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.ObjectCodec;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.io.CharTypes;
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.io.IOContext;
/*      */ import com.fasterxml.jackson.core.io.NumberOutput;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ 
/*      */ public class WriterBasedJsonGenerator extends JsonGeneratorImpl {
/*      */   protected static final int SHORT_WRITE = 32;
/*   22 */   protected static final char[] HEX_CHARS_UPPER = CharTypes.copyHexChars(true);
/*   23 */   protected static final char[] HEX_CHARS_LOWER = CharTypes.copyHexChars(false); protected final Writer _writer;
/*      */   
/*      */   private char[] getHexChars() {
/*   26 */     return this._cfgWriteHexUppercase ? HEX_CHARS_UPPER : HEX_CHARS_LOWER;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char _quoteChar;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char[] _outputBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _outputHead;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _outputTail;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _outputEnd;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char[] _entityBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SerializableString _currentEscape;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char[] _copyBuffer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public WriterBasedJsonGenerator(IOContext ctxt, int features, ObjectCodec codec, Writer w) {
/*  101 */     this(ctxt, features, codec, w, '"');
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WriterBasedJsonGenerator(IOContext ctxt, int features, ObjectCodec codec, Writer w, char quoteChar) {
/*  109 */     super(ctxt, features, codec);
/*  110 */     this._writer = w;
/*  111 */     this._outputBuffer = ctxt.allocConcatBuffer();
/*  112 */     this._outputEnd = this._outputBuffer.length;
/*  113 */     this._quoteChar = quoteChar;
/*  114 */     boolean escapeSlash = isEnabled(JsonWriteFeature.ESCAPE_FORWARD_SLASHES.mappedFeature());
/*  115 */     if (quoteChar != '"' || escapeSlash) {
/*  116 */       this._outputEscapes = CharTypes.get7BitOutputEscapes(quoteChar, escapeSlash);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getOutputTarget() {
/*  128 */     return this._writer;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getOutputBuffered() {
/*  134 */     int len = this._outputTail - this._outputHead;
/*  135 */     return Math.max(0, len);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean canWriteFormattedNumbers() {
/*  140 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldName(String name) throws IOException {
/*  151 */     int status = this._writeContext.writeFieldName(name);
/*  152 */     if (status == 4) {
/*  153 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  155 */     _writeFieldName(name, (status == 1));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldName(SerializableString name) throws IOException {
/*  162 */     int status = this._writeContext.writeFieldName(name.getValue());
/*  163 */     if (status == 4) {
/*  164 */       _reportError("Can not write a field name, expecting a value");
/*      */     }
/*  166 */     _writeFieldName(name, (status == 1));
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _writeFieldName(String name, boolean commaBefore) throws IOException {
/*  171 */     if (this._cfgPrettyPrinter != null) {
/*  172 */       _writePPFieldName(name, commaBefore);
/*      */       
/*      */       return;
/*      */     } 
/*  176 */     if (this._outputTail + 1 >= this._outputEnd) {
/*  177 */       _flushBuffer();
/*      */     }
/*  179 */     if (commaBefore) {
/*  180 */       this._outputBuffer[this._outputTail++] = ',';
/*      */     }
/*      */     
/*  183 */     if (this._cfgUnqNames) {
/*  184 */       _writeString(name);
/*      */       
/*      */       return;
/*      */     } 
/*  188 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     
/*  190 */     _writeString(name);
/*      */     
/*  192 */     if (this._outputTail >= this._outputEnd) {
/*  193 */       _flushBuffer();
/*      */     }
/*  195 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _writeFieldName(SerializableString name, boolean commaBefore) throws IOException {
/*  200 */     if (this._cfgPrettyPrinter != null) {
/*  201 */       _writePPFieldName(name, commaBefore);
/*      */       
/*      */       return;
/*      */     } 
/*  205 */     if (this._outputTail + 1 >= this._outputEnd) {
/*  206 */       _flushBuffer();
/*      */     }
/*  208 */     if (commaBefore) {
/*  209 */       this._outputBuffer[this._outputTail++] = ',';
/*      */     }
/*      */     
/*  212 */     if (this._cfgUnqNames) {
/*  213 */       char[] ch = name.asQuotedChars();
/*  214 */       writeRaw(ch, 0, ch.length);
/*      */       
/*      */       return;
/*      */     } 
/*  218 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */ 
/*      */     
/*  221 */     int len = name.appendQuoted(this._outputBuffer, this._outputTail);
/*  222 */     if (len < 0) {
/*  223 */       _writeFieldNameTail(name);
/*      */       return;
/*      */     } 
/*  226 */     this._outputTail += len;
/*  227 */     if (this._outputTail >= this._outputEnd) {
/*  228 */       _flushBuffer();
/*      */     }
/*  230 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _writeFieldNameTail(SerializableString name) throws IOException {
/*  235 */     char[] quoted = name.asQuotedChars();
/*  236 */     writeRaw(quoted, 0, quoted.length);
/*  237 */     if (this._outputTail >= this._outputEnd) {
/*  238 */       _flushBuffer();
/*      */     }
/*  240 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray() throws IOException {
/*  252 */     _verifyValueWrite("start an array");
/*  253 */     this._writeContext = this._writeContext.createChildArrayContext();
/*  254 */     streamWriteConstraints().validateNestingDepth(this._writeContext.getNestingDepth());
/*  255 */     if (this._cfgPrettyPrinter != null) {
/*  256 */       this._cfgPrettyPrinter.writeStartArray((JsonGenerator)this);
/*      */     } else {
/*  258 */       if (this._outputTail >= this._outputEnd) {
/*  259 */         _flushBuffer();
/*      */       }
/*  261 */       this._outputBuffer[this._outputTail++] = '[';
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object currentValue) throws IOException {
/*  268 */     _verifyValueWrite("start an array");
/*  269 */     this._writeContext = this._writeContext.createChildArrayContext(currentValue);
/*  270 */     streamWriteConstraints().validateNestingDepth(this._writeContext.getNestingDepth());
/*  271 */     if (this._cfgPrettyPrinter != null) {
/*  272 */       this._cfgPrettyPrinter.writeStartArray((JsonGenerator)this);
/*      */     } else {
/*  274 */       if (this._outputTail >= this._outputEnd) {
/*  275 */         _flushBuffer();
/*      */       }
/*  277 */       this._outputBuffer[this._outputTail++] = '[';
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object currentValue, int size) throws IOException {
/*  284 */     _verifyValueWrite("start an array");
/*  285 */     this._writeContext = this._writeContext.createChildArrayContext(currentValue);
/*  286 */     streamWriteConstraints().validateNestingDepth(this._writeContext.getNestingDepth());
/*  287 */     if (this._cfgPrettyPrinter != null) {
/*  288 */       this._cfgPrettyPrinter.writeStartArray((JsonGenerator)this);
/*      */     } else {
/*  290 */       if (this._outputTail >= this._outputEnd) {
/*  291 */         _flushBuffer();
/*      */       }
/*  293 */       this._outputBuffer[this._outputTail++] = '[';
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeEndArray() throws IOException {
/*  300 */     if (!this._writeContext.inArray()) {
/*  301 */       _reportError("Current context not Array but " + this._writeContext.typeDesc());
/*      */     }
/*  303 */     if (this._cfgPrettyPrinter != null) {
/*  304 */       this._cfgPrettyPrinter.writeEndArray((JsonGenerator)this, this._writeContext.getEntryCount());
/*      */     } else {
/*  306 */       if (this._outputTail >= this._outputEnd) {
/*  307 */         _flushBuffer();
/*      */       }
/*  309 */       this._outputBuffer[this._outputTail++] = ']';
/*      */     } 
/*  311 */     this._writeContext = this._writeContext.clearAndGetParent();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject() throws IOException {
/*  317 */     _verifyValueWrite("start an object");
/*  318 */     this._writeContext = this._writeContext.createChildObjectContext();
/*  319 */     streamWriteConstraints().validateNestingDepth(this._writeContext.getNestingDepth());
/*  320 */     if (this._cfgPrettyPrinter != null) {
/*  321 */       this._cfgPrettyPrinter.writeStartObject((JsonGenerator)this);
/*      */     } else {
/*  323 */       if (this._outputTail >= this._outputEnd) {
/*  324 */         _flushBuffer();
/*      */       }
/*  326 */       this._outputBuffer[this._outputTail++] = '{';
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue) throws IOException {
/*  333 */     _verifyValueWrite("start an object");
/*  334 */     JsonWriteContext ctxt = this._writeContext.createChildObjectContext(forValue);
/*  335 */     streamWriteConstraints().validateNestingDepth(this._writeContext.getNestingDepth());
/*  336 */     this._writeContext = ctxt;
/*  337 */     if (this._cfgPrettyPrinter != null) {
/*  338 */       this._cfgPrettyPrinter.writeStartObject((JsonGenerator)this);
/*      */     } else {
/*  340 */       if (this._outputTail >= this._outputEnd) {
/*  341 */         _flushBuffer();
/*      */       }
/*  343 */       this._outputBuffer[this._outputTail++] = '{';
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue, int size) throws IOException {
/*  349 */     writeStartObject(forValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeEndObject() throws IOException {
/*  355 */     if (!this._writeContext.inObject()) {
/*  356 */       _reportError("Current context not Object but " + this._writeContext.typeDesc());
/*      */     }
/*  358 */     if (this._cfgPrettyPrinter != null) {
/*  359 */       this._cfgPrettyPrinter.writeEndObject((JsonGenerator)this, this._writeContext.getEntryCount());
/*      */     } else {
/*  361 */       if (this._outputTail >= this._outputEnd) {
/*  362 */         _flushBuffer();
/*      */       }
/*  364 */       this._outputBuffer[this._outputTail++] = '}';
/*      */     } 
/*  366 */     this._writeContext = this._writeContext.clearAndGetParent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _writePPFieldName(String name, boolean commaBefore) throws IOException {
/*  373 */     if (commaBefore) {
/*  374 */       this._cfgPrettyPrinter.writeObjectEntrySeparator((JsonGenerator)this);
/*      */     } else {
/*  376 */       this._cfgPrettyPrinter.beforeObjectEntries((JsonGenerator)this);
/*      */     } 
/*      */     
/*  379 */     if (this._cfgUnqNames) {
/*  380 */       _writeString(name);
/*      */     } else {
/*  382 */       if (this._outputTail >= this._outputEnd) {
/*  383 */         _flushBuffer();
/*      */       }
/*  385 */       this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  386 */       _writeString(name);
/*  387 */       if (this._outputTail >= this._outputEnd) {
/*  388 */         _flushBuffer();
/*      */       }
/*  390 */       this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _writePPFieldName(SerializableString name, boolean commaBefore) throws IOException {
/*  396 */     if (commaBefore) {
/*  397 */       this._cfgPrettyPrinter.writeObjectEntrySeparator((JsonGenerator)this);
/*      */     } else {
/*  399 */       this._cfgPrettyPrinter.beforeObjectEntries((JsonGenerator)this);
/*      */     } 
/*  401 */     char[] quoted = name.asQuotedChars();
/*  402 */     if (this._cfgUnqNames) {
/*  403 */       writeRaw(quoted, 0, quoted.length);
/*      */     } else {
/*  405 */       if (this._outputTail >= this._outputEnd) {
/*  406 */         _flushBuffer();
/*      */       }
/*  408 */       this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  409 */       writeRaw(quoted, 0, quoted.length);
/*  410 */       if (this._outputTail >= this._outputEnd) {
/*  411 */         _flushBuffer();
/*      */       }
/*  413 */       this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(String text) throws IOException {
/*  426 */     _verifyValueWrite("write a string");
/*  427 */     if (text == null) {
/*  428 */       _writeNull();
/*      */       return;
/*      */     } 
/*  431 */     if (this._outputTail >= this._outputEnd) {
/*  432 */       _flushBuffer();
/*      */     }
/*  434 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  435 */     _writeString(text);
/*      */     
/*  437 */     if (this._outputTail >= this._outputEnd) {
/*  438 */       _flushBuffer();
/*      */     }
/*  440 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(Reader reader, int len) throws IOException {
/*  446 */     _verifyValueWrite("write a string");
/*  447 */     if (reader == null) {
/*  448 */       _reportError("null reader");
/*      */       return;
/*      */     } 
/*  451 */     int toRead = (len >= 0) ? len : Integer.MAX_VALUE;
/*      */     
/*  453 */     if (this._outputTail >= this._outputEnd) {
/*  454 */       _flushBuffer();
/*      */     }
/*  456 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     
/*  458 */     char[] buf = _allocateCopyBuffer();
/*  459 */     while (toRead > 0) {
/*  460 */       int toReadNow = Math.min(toRead, buf.length);
/*  461 */       int numRead = reader.read(buf, 0, toReadNow);
/*  462 */       if (numRead <= 0) {
/*      */         break;
/*      */       }
/*  465 */       _writeString(buf, 0, numRead);
/*  466 */       toRead -= numRead;
/*      */     } 
/*      */     
/*  469 */     if (this._outputTail >= this._outputEnd) {
/*  470 */       _flushBuffer();
/*      */     }
/*  472 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */     
/*  474 */     if (toRead > 0 && len >= 0) {
/*  475 */       _reportError("Didn't read enough from reader");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(char[] text, int offset, int len) throws IOException {
/*  482 */     _verifyValueWrite("write a string");
/*  483 */     if (this._outputTail >= this._outputEnd) {
/*  484 */       _flushBuffer();
/*      */     }
/*  486 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  487 */     _writeString(text, offset, len);
/*      */     
/*  489 */     if (this._outputTail >= this._outputEnd) {
/*  490 */       _flushBuffer();
/*      */     }
/*  492 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(SerializableString sstr) throws IOException {
/*  498 */     _verifyValueWrite("write a string");
/*  499 */     if (this._outputTail >= this._outputEnd) {
/*  500 */       _flushBuffer();
/*      */     }
/*  502 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  503 */     int len = sstr.appendQuoted(this._outputBuffer, this._outputTail);
/*  504 */     if (len < 0) {
/*  505 */       _writeString2(sstr);
/*      */       return;
/*      */     } 
/*  508 */     this._outputTail += len;
/*  509 */     if (this._outputTail >= this._outputEnd) {
/*  510 */       _flushBuffer();
/*      */     }
/*  512 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeString2(SerializableString sstr) throws IOException {
/*  518 */     char[] text = sstr.asQuotedChars();
/*  519 */     int len = text.length;
/*  520 */     if (len < 32) {
/*  521 */       int room = this._outputEnd - this._outputTail;
/*  522 */       if (len > room) {
/*  523 */         _flushBuffer();
/*      */       }
/*  525 */       System.arraycopy(text, 0, this._outputBuffer, this._outputTail, len);
/*  526 */       this._outputTail += len;
/*      */     } else {
/*  528 */       _flushBuffer();
/*  529 */       this._writer.write(text, 0, len);
/*      */     } 
/*  531 */     if (this._outputTail >= this._outputEnd) {
/*  532 */       _flushBuffer();
/*      */     }
/*  534 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawUTF8String(byte[] text, int offset, int length) throws IOException {
/*  540 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeUTF8String(byte[] text, int offset, int length) throws IOException {
/*  546 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(String text) throws IOException {
/*  559 */     int len = text.length();
/*  560 */     int room = this._outputEnd - this._outputTail;
/*      */     
/*  562 */     if (room == 0) {
/*  563 */       _flushBuffer();
/*  564 */       room = this._outputEnd - this._outputTail;
/*      */     } 
/*      */     
/*  567 */     if (room >= len) {
/*  568 */       text.getChars(0, len, this._outputBuffer, this._outputTail);
/*  569 */       this._outputTail += len;
/*      */     } else {
/*  571 */       writeRawLong(text);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(String text, int offset, int len) throws IOException {
/*  578 */     _checkRangeBoundsForString(text, offset, len);
/*      */ 
/*      */     
/*  581 */     int room = this._outputEnd - this._outputTail;
/*      */     
/*  583 */     if (room < len) {
/*  584 */       _flushBuffer();
/*  585 */       room = this._outputEnd - this._outputTail;
/*      */     } 
/*      */     
/*  588 */     if (room >= len) {
/*  589 */       text.getChars(offset, offset + len, this._outputBuffer, this._outputTail);
/*  590 */       this._outputTail += len;
/*      */     } else {
/*  592 */       writeRawLong(text.substring(offset, offset + len));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(SerializableString text) throws IOException {
/*  599 */     int len = text.appendUnquoted(this._outputBuffer, this._outputTail);
/*  600 */     if (len < 0) {
/*  601 */       writeRaw(text.getValue());
/*      */       return;
/*      */     } 
/*  604 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(char[] cbuf, int offset, int len) throws IOException {
/*  610 */     _checkRangeBoundsForCharArray(cbuf, offset, len);
/*      */ 
/*      */     
/*  613 */     if (len < 32) {
/*  614 */       int room = this._outputEnd - this._outputTail;
/*  615 */       if (len > room) {
/*  616 */         _flushBuffer();
/*      */       }
/*  618 */       System.arraycopy(cbuf, offset, this._outputBuffer, this._outputTail, len);
/*  619 */       this._outputTail += len;
/*      */       
/*      */       return;
/*      */     } 
/*  623 */     _flushBuffer();
/*  624 */     this._writer.write(cbuf, offset, len);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(char c) throws IOException {
/*  630 */     if (this._outputTail >= this._outputEnd) {
/*  631 */       _flushBuffer();
/*      */     }
/*  633 */     this._outputBuffer[this._outputTail++] = c;
/*      */   }
/*      */ 
/*      */   
/*      */   private void writeRawLong(String text) throws IOException {
/*  638 */     int room = this._outputEnd - this._outputTail;
/*      */     
/*  640 */     text.getChars(0, room, this._outputBuffer, this._outputTail);
/*  641 */     this._outputTail += room;
/*  642 */     _flushBuffer();
/*  643 */     int offset = room;
/*  644 */     int len = text.length() - room;
/*      */     
/*  646 */     while (len > this._outputEnd) {
/*  647 */       int amount = this._outputEnd;
/*  648 */       text.getChars(offset, offset + amount, this._outputBuffer, 0);
/*  649 */       this._outputHead = 0;
/*  650 */       this._outputTail = amount;
/*  651 */       _flushBuffer();
/*  652 */       offset += amount;
/*  653 */       len -= amount;
/*      */     } 
/*      */     
/*  656 */     text.getChars(offset, offset + len, this._outputBuffer, 0);
/*  657 */     this._outputHead = 0;
/*  658 */     this._outputTail = len;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBinary(Base64Variant b64variant, byte[] data, int offset, int len) throws IOException, JsonGenerationException {
/*  671 */     _checkRangeBoundsForByteArray(data, offset, len);
/*      */     
/*  673 */     _verifyValueWrite("write a binary value");
/*      */     
/*  675 */     if (this._outputTail >= this._outputEnd) {
/*  676 */       _flushBuffer();
/*      */     }
/*  678 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  679 */     _writeBinary(b64variant, data, offset, offset + len);
/*      */     
/*  681 */     if (this._outputTail >= this._outputEnd) {
/*  682 */       _flushBuffer();
/*      */     }
/*  684 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int writeBinary(Base64Variant b64variant, InputStream data, int dataLength) throws IOException, JsonGenerationException {
/*      */     int bytes;
/*  692 */     _verifyValueWrite("write a binary value");
/*      */     
/*  694 */     if (this._outputTail >= this._outputEnd) {
/*  695 */       _flushBuffer();
/*      */     }
/*  697 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  698 */     byte[] encodingBuffer = this._ioContext.allocBase64Buffer();
/*      */     
/*      */     try {
/*  701 */       if (dataLength < 0) {
/*  702 */         bytes = _writeBinary(b64variant, data, encodingBuffer);
/*      */       } else {
/*  704 */         int missing = _writeBinary(b64variant, data, encodingBuffer, dataLength);
/*  705 */         if (missing > 0) {
/*  706 */           _reportError("Too few bytes available: missing " + missing + " bytes (out of " + dataLength + ")");
/*      */         }
/*  708 */         bytes = dataLength;
/*      */       } 
/*      */     } finally {
/*  711 */       this._ioContext.releaseBase64Buffer(encodingBuffer);
/*      */     } 
/*      */     
/*  714 */     if (this._outputTail >= this._outputEnd) {
/*  715 */       _flushBuffer();
/*      */     }
/*  717 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  718 */     return bytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(short s) throws IOException {
/*  730 */     _verifyValueWrite("write a number");
/*  731 */     if (this._cfgNumbersAsStrings) {
/*  732 */       _writeQuotedShort(s);
/*      */       
/*      */       return;
/*      */     } 
/*  736 */     if (this._outputTail + 6 >= this._outputEnd) {
/*  737 */       _flushBuffer();
/*      */     }
/*  739 */     this._outputTail = NumberOutput.outputInt(s, this._outputBuffer, this._outputTail);
/*      */   }
/*      */   
/*      */   private void _writeQuotedShort(short s) throws IOException {
/*  743 */     if (this._outputTail + 8 >= this._outputEnd) {
/*  744 */       _flushBuffer();
/*      */     }
/*  746 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  747 */     this._outputTail = NumberOutput.outputInt(s, this._outputBuffer, this._outputTail);
/*  748 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(int i) throws IOException {
/*  754 */     _verifyValueWrite("write a number");
/*  755 */     if (this._cfgNumbersAsStrings) {
/*  756 */       _writeQuotedInt(i);
/*      */       
/*      */       return;
/*      */     } 
/*  760 */     if (this._outputTail + 11 >= this._outputEnd) {
/*  761 */       _flushBuffer();
/*      */     }
/*  763 */     this._outputTail = NumberOutput.outputInt(i, this._outputBuffer, this._outputTail);
/*      */   }
/*      */   
/*      */   private void _writeQuotedInt(int i) throws IOException {
/*  767 */     if (this._outputTail + 13 >= this._outputEnd) {
/*  768 */       _flushBuffer();
/*      */     }
/*  770 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  771 */     this._outputTail = NumberOutput.outputInt(i, this._outputBuffer, this._outputTail);
/*  772 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(long l) throws IOException {
/*  778 */     _verifyValueWrite("write a number");
/*  779 */     if (this._cfgNumbersAsStrings) {
/*  780 */       _writeQuotedLong(l);
/*      */       return;
/*      */     } 
/*  783 */     if (this._outputTail + 21 >= this._outputEnd)
/*      */     {
/*  785 */       _flushBuffer();
/*      */     }
/*  787 */     this._outputTail = NumberOutput.outputLong(l, this._outputBuffer, this._outputTail);
/*      */   }
/*      */   
/*      */   private void _writeQuotedLong(long l) throws IOException {
/*  791 */     if (this._outputTail + 23 >= this._outputEnd) {
/*  792 */       _flushBuffer();
/*      */     }
/*  794 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  795 */     this._outputTail = NumberOutput.outputLong(l, this._outputBuffer, this._outputTail);
/*  796 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(BigInteger value) throws IOException {
/*  804 */     _verifyValueWrite("write a number");
/*  805 */     if (value == null) {
/*  806 */       _writeNull();
/*  807 */     } else if (this._cfgNumbersAsStrings) {
/*  808 */       _writeQuotedRaw(value.toString());
/*      */     } else {
/*  810 */       writeRaw(value.toString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(double d) throws IOException {
/*  818 */     if (this._cfgNumbersAsStrings || (
/*  819 */       NumberOutput.notFinite(d) && isEnabled(JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS))) {
/*  820 */       writeString(NumberOutput.toString(d, isEnabled(JsonGenerator.Feature.USE_FAST_DOUBLE_WRITER)));
/*      */       
/*      */       return;
/*      */     } 
/*  824 */     _verifyValueWrite("write a number");
/*  825 */     writeRaw(NumberOutput.toString(d, isEnabled(JsonGenerator.Feature.USE_FAST_DOUBLE_WRITER)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(float f) throws IOException {
/*  832 */     if (this._cfgNumbersAsStrings || (
/*  833 */       NumberOutput.notFinite(f) && isEnabled(JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS))) {
/*  834 */       writeString(NumberOutput.toString(f, isEnabled(JsonGenerator.Feature.USE_FAST_DOUBLE_WRITER)));
/*      */       
/*      */       return;
/*      */     } 
/*  838 */     _verifyValueWrite("write a number");
/*  839 */     writeRaw(NumberOutput.toString(f, isEnabled(JsonGenerator.Feature.USE_FAST_DOUBLE_WRITER)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(BigDecimal value) throws IOException {
/*  846 */     _verifyValueWrite("write a number");
/*  847 */     if (value == null) {
/*  848 */       _writeNull();
/*  849 */     } else if (this._cfgNumbersAsStrings) {
/*  850 */       _writeQuotedRaw(_asString(value));
/*      */     } else {
/*  852 */       writeRaw(_asString(value));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(String encodedValue) throws IOException {
/*  859 */     _verifyValueWrite("write a number");
/*  860 */     if (encodedValue == null) {
/*  861 */       _writeNull();
/*  862 */     } else if (this._cfgNumbersAsStrings) {
/*  863 */       _writeQuotedRaw(encodedValue);
/*      */     } else {
/*  865 */       writeRaw(encodedValue);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNumber(char[] encodedValueBuffer, int offset, int length) throws IOException {
/*  871 */     _verifyValueWrite("write a number");
/*  872 */     if (this._cfgNumbersAsStrings) {
/*  873 */       _writeQuotedRaw(encodedValueBuffer, offset, length);
/*      */     } else {
/*  875 */       writeRaw(encodedValueBuffer, offset, length);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void _writeQuotedRaw(String value) throws IOException {
/*  881 */     if (this._outputTail >= this._outputEnd) {
/*  882 */       _flushBuffer();
/*      */     }
/*  884 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  885 */     writeRaw(value);
/*  886 */     if (this._outputTail >= this._outputEnd) {
/*  887 */       _flushBuffer();
/*      */     }
/*  889 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */   
/*      */   private void _writeQuotedRaw(char[] text, int offset, int length) throws IOException {
/*  894 */     if (this._outputTail >= this._outputEnd) {
/*  895 */       _flushBuffer();
/*      */     }
/*  897 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*  898 */     writeRaw(text, offset, length);
/*  899 */     if (this._outputTail >= this._outputEnd) {
/*  900 */       _flushBuffer();
/*      */     }
/*  902 */     this._outputBuffer[this._outputTail++] = this._quoteChar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBoolean(boolean state) throws IOException {
/*  908 */     _verifyValueWrite("write a boolean value");
/*  909 */     if (this._outputTail + 5 >= this._outputEnd) {
/*  910 */       _flushBuffer();
/*      */     }
/*  912 */     int ptr = this._outputTail;
/*  913 */     char[] buf = this._outputBuffer;
/*  914 */     if (state) {
/*  915 */       buf[ptr] = 't';
/*  916 */       buf[++ptr] = 'r';
/*  917 */       buf[++ptr] = 'u';
/*  918 */       buf[++ptr] = 'e';
/*      */     } else {
/*  920 */       buf[ptr] = 'f';
/*  921 */       buf[++ptr] = 'a';
/*  922 */       buf[++ptr] = 'l';
/*  923 */       buf[++ptr] = 's';
/*  924 */       buf[++ptr] = 'e';
/*      */     } 
/*  926 */     this._outputTail = ptr + 1;
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeNull() throws IOException {
/*  931 */     _verifyValueWrite("write a null");
/*  932 */     _writeNull();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _verifyValueWrite(String typeMsg) throws IOException {
/*      */     char c;
/*  944 */     int status = this._writeContext.writeValue();
/*  945 */     if (this._cfgPrettyPrinter != null) {
/*      */       
/*  947 */       _verifyPrettyValueWrite(typeMsg, status);
/*      */       
/*      */       return;
/*      */     } 
/*  951 */     switch (status) {
/*      */       default:
/*      */         return;
/*      */       
/*      */       case 1:
/*  956 */         c = ',';
/*      */         break;
/*      */       case 2:
/*  959 */         c = ':';
/*      */         break;
/*      */       case 3:
/*  962 */         if (this._rootValueSeparator != null) {
/*  963 */           writeRaw(this._rootValueSeparator.getValue());
/*      */         }
/*      */         return;
/*      */       case 5:
/*  967 */         _reportCantWriteValueExpectName(typeMsg);
/*      */         return;
/*      */     } 
/*  970 */     if (this._outputTail >= this._outputEnd) {
/*  971 */       _flushBuffer();
/*      */     }
/*  973 */     this._outputBuffer[this._outputTail++] = c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void flush() throws IOException {
/*  985 */     _flushBuffer();
/*  986 */     if (this._writer != null && 
/*  987 */       isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM)) {
/*  988 */       this._writer.flush();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws IOException {
/*  996 */     super.close();
/*      */ 
/*      */ 
/*      */     
/* 1000 */     IOException flushFail = null;
/*      */     try {
/* 1002 */       if (this._outputBuffer != null && 
/* 1003 */         isEnabled(JsonGenerator.Feature.AUTO_CLOSE_JSON_CONTENT)) {
/*      */         while (true) {
/* 1005 */           JsonStreamContext ctxt = getOutputContext();
/* 1006 */           if (ctxt.inArray()) {
/* 1007 */             writeEndArray(); continue;
/* 1008 */           }  if (ctxt.inObject()) {
/* 1009 */             writeEndObject();
/*      */             continue;
/*      */           } 
/*      */           break;
/*      */         } 
/*      */       }
/* 1015 */       _flushBuffer();
/* 1016 */     } catch (IOException e) {
/*      */ 
/*      */       
/* 1019 */       flushFail = e;
/*      */     } 
/* 1021 */     this._outputHead = 0;
/* 1022 */     this._outputTail = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1030 */     if (this._writer != null) {
/*      */       try {
/* 1032 */         if (this._ioContext.isResourceManaged() || isEnabled(JsonGenerator.Feature.AUTO_CLOSE_TARGET)) {
/* 1033 */           this._writer.close();
/* 1034 */         } else if (isEnabled(JsonGenerator.Feature.FLUSH_PASSED_TO_STREAM)) {
/*      */           
/* 1036 */           this._writer.flush();
/*      */         } 
/* 1038 */       } catch (IOException|RuntimeException e) {
/* 1039 */         if (flushFail != null) {
/* 1040 */           e.addSuppressed(flushFail);
/*      */         }
/* 1042 */         throw e;
/*      */       } 
/*      */     }
/*      */     
/* 1046 */     _releaseBuffers();
/*      */     
/* 1048 */     if (flushFail != null) {
/* 1049 */       throw flushFail;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _releaseBuffers() {
/* 1056 */     char[] buf = this._outputBuffer;
/* 1057 */     if (buf != null) {
/* 1058 */       this._outputBuffer = null;
/* 1059 */       this._ioContext.releaseConcatBuffer(buf);
/*      */     } 
/* 1061 */     buf = this._copyBuffer;
/* 1062 */     if (buf != null) {
/* 1063 */       this._copyBuffer = null;
/* 1064 */       this._ioContext.releaseNameCopyBuffer(buf);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeString(String text) throws IOException {
/* 1081 */     int len = text.length();
/* 1082 */     if (len > this._outputEnd) {
/* 1083 */       _writeLongString(text);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1089 */     if (this._outputTail + len > this._outputEnd) {
/* 1090 */       _flushBuffer();
/*      */     }
/* 1092 */     text.getChars(0, len, this._outputBuffer, this._outputTail);
/*      */     
/* 1094 */     if (this._characterEscapes != null) {
/* 1095 */       _writeStringCustom(len);
/* 1096 */     } else if (this._maximumNonEscapedChar != 0) {
/* 1097 */       _writeStringASCII(len, this._maximumNonEscapedChar);
/*      */     } else {
/* 1099 */       _writeString2(len);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeString2(int len) throws IOException {
/* 1106 */     int end = this._outputTail + len;
/* 1107 */     int[] escCodes = this._outputEscapes;
/* 1108 */     int escLen = escCodes.length;
/*      */ 
/*      */     
/* 1111 */     while (this._outputTail < end) {
/*      */       
/*      */       label17: while (true) {
/*      */         
/* 1115 */         char c = this._outputBuffer[this._outputTail];
/* 1116 */         if (c < escLen && escCodes[c] != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1128 */           int flushLen = this._outputTail - this._outputHead;
/* 1129 */           if (flushLen > 0) {
/* 1130 */             this._writer.write(this._outputBuffer, this._outputHead, flushLen);
/*      */             
/*      */             break label17;
/*      */           } 
/*      */           
/* 1135 */           char c1 = this._outputBuffer[this._outputTail++];
/* 1136 */           _prependOrWriteCharacterEscape(c1, escCodes[c1]);
/*      */           continue;
/*      */         } 
/*      */         if (++this._outputTail >= end) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void _writeLongString(String text) throws IOException {
/* 1147 */     _flushBuffer();
/*      */ 
/*      */     
/* 1150 */     int textLen = text.length();
/* 1151 */     int offset = 0;
/*      */     do {
/* 1153 */       int max = this._outputEnd;
/* 1154 */       int segmentLen = (offset + max > textLen) ? (textLen - offset) : max;
/*      */       
/* 1156 */       text.getChars(offset, offset + segmentLen, this._outputBuffer, 0);
/* 1157 */       if (this._characterEscapes != null) {
/* 1158 */         _writeSegmentCustom(segmentLen);
/* 1159 */       } else if (this._maximumNonEscapedChar != 0) {
/* 1160 */         _writeSegmentASCII(segmentLen, this._maximumNonEscapedChar);
/*      */       } else {
/* 1162 */         _writeSegment(segmentLen);
/*      */       } 
/* 1164 */       offset += segmentLen;
/* 1165 */     } while (offset < textLen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeSegment(int end) throws IOException {
/* 1179 */     int[] escCodes = this._outputEscapes;
/* 1180 */     int escLen = escCodes.length;
/*      */     
/* 1182 */     int ptr = 0;
/* 1183 */     int start = ptr;
/*      */ 
/*      */     
/* 1186 */     while (ptr < end) {
/*      */       char c;
/*      */       
/*      */       do {
/* 1190 */         c = this._outputBuffer[ptr];
/* 1191 */         if (c < escLen && escCodes[c] != 0) {
/*      */           break;
/*      */         }
/* 1194 */       } while (++ptr < end);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1203 */       int flushLen = ptr - start;
/* 1204 */       if (flushLen > 0) {
/* 1205 */         this._writer.write(this._outputBuffer, start, flushLen);
/* 1206 */         if (ptr >= end) {
/*      */           break;
/*      */         }
/*      */       } 
/* 1210 */       ptr++;
/*      */       
/* 1212 */       start = _prependOrWriteCharacterEscape(this._outputBuffer, ptr, end, c, escCodes[c]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeString(char[] text, int offset, int len) throws IOException {
/* 1222 */     if (this._characterEscapes != null) {
/* 1223 */       _writeStringCustom(text, offset, len);
/*      */       return;
/*      */     } 
/* 1226 */     if (this._maximumNonEscapedChar != 0) {
/* 1227 */       _writeStringASCII(text, offset, len, this._maximumNonEscapedChar);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/* 1234 */     len += offset;
/* 1235 */     int[] escCodes = this._outputEscapes;
/* 1236 */     int escLen = escCodes.length;
/* 1237 */     while (offset < len) {
/* 1238 */       int start = offset;
/*      */       
/*      */       do {
/* 1241 */         char c1 = text[offset];
/* 1242 */         if (c1 < escLen && escCodes[c1] != 0) {
/*      */           break;
/*      */         }
/* 1245 */       } while (++offset < len);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1251 */       int newAmount = offset - start;
/* 1252 */       if (newAmount < 32) {
/*      */         
/* 1254 */         if (this._outputTail + newAmount > this._outputEnd) {
/* 1255 */           _flushBuffer();
/*      */         }
/* 1257 */         if (newAmount > 0) {
/* 1258 */           System.arraycopy(text, start, this._outputBuffer, this._outputTail, newAmount);
/* 1259 */           this._outputTail += newAmount;
/*      */         } 
/*      */       } else {
/* 1262 */         _flushBuffer();
/* 1263 */         this._writer.write(text, start, newAmount);
/*      */       } 
/*      */       
/* 1266 */       if (offset >= len) {
/*      */         break;
/*      */       }
/*      */       
/* 1270 */       char c = text[offset++];
/* 1271 */       _appendCharacterEscape(c, escCodes[c]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeStringASCII(int len, int maxNonEscaped) throws IOException, JsonGenerationException {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield _outputTail : I
/*      */     //   4: iload_1
/*      */     //   5: iadd
/*      */     //   6: istore_3
/*      */     //   7: aload_0
/*      */     //   8: getfield _outputEscapes : [I
/*      */     //   11: astore #4
/*      */     //   13: aload #4
/*      */     //   15: arraylength
/*      */     //   16: iload_2
/*      */     //   17: iconst_1
/*      */     //   18: iadd
/*      */     //   19: invokestatic min : (II)I
/*      */     //   22: istore #5
/*      */     //   24: iconst_0
/*      */     //   25: istore #6
/*      */     //   27: aload_0
/*      */     //   28: getfield _outputTail : I
/*      */     //   31: iload_3
/*      */     //   32: if_icmpge -> 152
/*      */     //   35: aload_0
/*      */     //   36: getfield _outputBuffer : [C
/*      */     //   39: aload_0
/*      */     //   40: getfield _outputTail : I
/*      */     //   43: caload
/*      */     //   44: istore #7
/*      */     //   46: iload #7
/*      */     //   48: iload #5
/*      */     //   50: if_icmpge -> 68
/*      */     //   53: aload #4
/*      */     //   55: iload #7
/*      */     //   57: iaload
/*      */     //   58: istore #6
/*      */     //   60: iload #6
/*      */     //   62: ifeq -> 80
/*      */     //   65: goto -> 98
/*      */     //   68: iload #7
/*      */     //   70: iload_2
/*      */     //   71: if_icmple -> 80
/*      */     //   74: iconst_m1
/*      */     //   75: istore #6
/*      */     //   77: goto -> 98
/*      */     //   80: aload_0
/*      */     //   81: dup
/*      */     //   82: getfield _outputTail : I
/*      */     //   85: iconst_1
/*      */     //   86: iadd
/*      */     //   87: dup_x1
/*      */     //   88: putfield _outputTail : I
/*      */     //   91: iload_3
/*      */     //   92: if_icmplt -> 35
/*      */     //   95: goto -> 152
/*      */     //   98: aload_0
/*      */     //   99: getfield _outputTail : I
/*      */     //   102: aload_0
/*      */     //   103: getfield _outputHead : I
/*      */     //   106: isub
/*      */     //   107: istore #8
/*      */     //   109: iload #8
/*      */     //   111: ifle -> 131
/*      */     //   114: aload_0
/*      */     //   115: getfield _writer : Ljava/io/Writer;
/*      */     //   118: aload_0
/*      */     //   119: getfield _outputBuffer : [C
/*      */     //   122: aload_0
/*      */     //   123: getfield _outputHead : I
/*      */     //   126: iload #8
/*      */     //   128: invokevirtual write : ([CII)V
/*      */     //   131: aload_0
/*      */     //   132: dup
/*      */     //   133: getfield _outputTail : I
/*      */     //   136: iconst_1
/*      */     //   137: iadd
/*      */     //   138: putfield _outputTail : I
/*      */     //   141: aload_0
/*      */     //   142: iload #7
/*      */     //   144: iload #6
/*      */     //   146: invokespecial _prependOrWriteCharacterEscape : (CI)V
/*      */     //   149: goto -> 27
/*      */     //   152: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1289	-> 0
/*      */     //   #1290	-> 7
/*      */     //   #1291	-> 13
/*      */     //   #1292	-> 24
/*      */     //   #1295	-> 27
/*      */     //   #1300	-> 35
/*      */     //   #1301	-> 46
/*      */     //   #1302	-> 53
/*      */     //   #1303	-> 60
/*      */     //   #1304	-> 65
/*      */     //   #1306	-> 68
/*      */     //   #1307	-> 74
/*      */     //   #1308	-> 77
/*      */     //   #1310	-> 80
/*      */     //   #1311	-> 95
/*      */     //   #1314	-> 98
/*      */     //   #1315	-> 109
/*      */     //   #1316	-> 114
/*      */     //   #1318	-> 131
/*      */     //   #1319	-> 141
/*      */     //   #1320	-> 149
/*      */     //   #1321	-> 152
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   46	103	7	c	C
/*      */     //   109	40	8	flushLen	I
/*      */     //   0	153	0	this	Lcom/fasterxml/jackson/core/json/WriterBasedJsonGenerator;
/*      */     //   0	153	1	len	I
/*      */     //   0	153	2	maxNonEscaped	I
/*      */     //   7	146	3	end	I
/*      */     //   13	140	4	escCodes	[I
/*      */     //   24	129	5	escLimit	I
/*      */     //   27	126	6	escCode	I
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeSegmentASCII(int end, int maxNonEscaped) throws IOException, JsonGenerationException {
/* 1326 */     int[] escCodes = this._outputEscapes;
/* 1327 */     int escLimit = Math.min(escCodes.length, maxNonEscaped + 1);
/*      */     
/* 1329 */     int ptr = 0;
/* 1330 */     int escCode = 0;
/* 1331 */     int start = ptr;
/*      */ 
/*      */     
/* 1334 */     while (ptr < end) {
/*      */       char c;
/*      */       
/*      */       do {
/* 1338 */         c = this._outputBuffer[ptr];
/* 1339 */         if (c < escLimit) {
/* 1340 */           escCode = escCodes[c];
/* 1341 */           if (escCode != 0) {
/*      */             break;
/*      */           }
/* 1344 */         } else if (c > maxNonEscaped) {
/* 1345 */           escCode = -1;
/*      */           break;
/*      */         } 
/* 1348 */       } while (++ptr < end);
/*      */ 
/*      */ 
/*      */       
/* 1352 */       int flushLen = ptr - start;
/* 1353 */       if (flushLen > 0) {
/* 1354 */         this._writer.write(this._outputBuffer, start, flushLen);
/* 1355 */         if (ptr >= end) {
/*      */           break;
/*      */         }
/*      */       } 
/* 1359 */       ptr++;
/* 1360 */       start = _prependOrWriteCharacterEscape(this._outputBuffer, ptr, end, c, escCode);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeStringASCII(char[] text, int offset, int len, int maxNonEscaped) throws IOException, JsonGenerationException {
/* 1368 */     len += offset;
/* 1369 */     int[] escCodes = this._outputEscapes;
/* 1370 */     int escLimit = Math.min(escCodes.length, maxNonEscaped + 1);
/*      */     
/* 1372 */     int escCode = 0;
/*      */     
/* 1374 */     while (offset < len) {
/* 1375 */       char c; int start = offset;
/*      */ 
/*      */       
/*      */       do {
/* 1379 */         c = text[offset];
/* 1380 */         if (c < escLimit) {
/* 1381 */           escCode = escCodes[c];
/* 1382 */           if (escCode != 0) {
/*      */             break;
/*      */           }
/* 1385 */         } else if (c > maxNonEscaped) {
/* 1386 */           escCode = -1;
/*      */           break;
/*      */         } 
/* 1389 */       } while (++offset < len);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1395 */       int newAmount = offset - start;
/* 1396 */       if (newAmount < 32) {
/*      */         
/* 1398 */         if (this._outputTail + newAmount > this._outputEnd) {
/* 1399 */           _flushBuffer();
/*      */         }
/* 1401 */         if (newAmount > 0) {
/* 1402 */           System.arraycopy(text, start, this._outputBuffer, this._outputTail, newAmount);
/* 1403 */           this._outputTail += newAmount;
/*      */         } 
/*      */       } else {
/* 1406 */         _flushBuffer();
/* 1407 */         this._writer.write(text, start, newAmount);
/*      */       } 
/*      */       
/* 1410 */       if (offset >= len) {
/*      */         break;
/*      */       }
/*      */       
/* 1414 */       offset++;
/* 1415 */       _appendCharacterEscape(c, escCode);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeStringCustom(int len) throws IOException, JsonGenerationException {
/*      */     // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield _outputTail : I
/*      */     //   4: iload_1
/*      */     //   5: iadd
/*      */     //   6: istore_2
/*      */     //   7: aload_0
/*      */     //   8: getfield _outputEscapes : [I
/*      */     //   11: astore_3
/*      */     //   12: aload_0
/*      */     //   13: getfield _maximumNonEscapedChar : I
/*      */     //   16: iconst_1
/*      */     //   17: if_icmpge -> 25
/*      */     //   20: ldc 65535
/*      */     //   22: goto -> 29
/*      */     //   25: aload_0
/*      */     //   26: getfield _maximumNonEscapedChar : I
/*      */     //   29: istore #4
/*      */     //   31: aload_3
/*      */     //   32: arraylength
/*      */     //   33: iload #4
/*      */     //   35: iconst_1
/*      */     //   36: iadd
/*      */     //   37: invokestatic min : (II)I
/*      */     //   40: istore #5
/*      */     //   42: iconst_0
/*      */     //   43: istore #6
/*      */     //   45: aload_0
/*      */     //   46: getfield _characterEscapes : Lcom/fasterxml/jackson/core/io/CharacterEscapes;
/*      */     //   49: astore #7
/*      */     //   51: aload_0
/*      */     //   52: getfield _outputTail : I
/*      */     //   55: iload_2
/*      */     //   56: if_icmpge -> 198
/*      */     //   59: aload_0
/*      */     //   60: getfield _outputBuffer : [C
/*      */     //   63: aload_0
/*      */     //   64: getfield _outputTail : I
/*      */     //   67: caload
/*      */     //   68: istore #8
/*      */     //   70: iload #8
/*      */     //   72: iload #5
/*      */     //   74: if_icmpge -> 91
/*      */     //   77: aload_3
/*      */     //   78: iload #8
/*      */     //   80: iaload
/*      */     //   81: istore #6
/*      */     //   83: iload #6
/*      */     //   85: ifeq -> 126
/*      */     //   88: goto -> 144
/*      */     //   91: iload #8
/*      */     //   93: iload #4
/*      */     //   95: if_icmple -> 104
/*      */     //   98: iconst_m1
/*      */     //   99: istore #6
/*      */     //   101: goto -> 144
/*      */     //   104: aload_0
/*      */     //   105: aload #7
/*      */     //   107: iload #8
/*      */     //   109: invokevirtual getEscapeSequence : (I)Lcom/fasterxml/jackson/core/SerializableString;
/*      */     //   112: dup_x1
/*      */     //   113: putfield _currentEscape : Lcom/fasterxml/jackson/core/SerializableString;
/*      */     //   116: ifnull -> 126
/*      */     //   119: bipush #-2
/*      */     //   121: istore #6
/*      */     //   123: goto -> 144
/*      */     //   126: aload_0
/*      */     //   127: dup
/*      */     //   128: getfield _outputTail : I
/*      */     //   131: iconst_1
/*      */     //   132: iadd
/*      */     //   133: dup_x1
/*      */     //   134: putfield _outputTail : I
/*      */     //   137: iload_2
/*      */     //   138: if_icmplt -> 59
/*      */     //   141: goto -> 198
/*      */     //   144: aload_0
/*      */     //   145: getfield _outputTail : I
/*      */     //   148: aload_0
/*      */     //   149: getfield _outputHead : I
/*      */     //   152: isub
/*      */     //   153: istore #9
/*      */     //   155: iload #9
/*      */     //   157: ifle -> 177
/*      */     //   160: aload_0
/*      */     //   161: getfield _writer : Ljava/io/Writer;
/*      */     //   164: aload_0
/*      */     //   165: getfield _outputBuffer : [C
/*      */     //   168: aload_0
/*      */     //   169: getfield _outputHead : I
/*      */     //   172: iload #9
/*      */     //   174: invokevirtual write : ([CII)V
/*      */     //   177: aload_0
/*      */     //   178: dup
/*      */     //   179: getfield _outputTail : I
/*      */     //   182: iconst_1
/*      */     //   183: iadd
/*      */     //   184: putfield _outputTail : I
/*      */     //   187: aload_0
/*      */     //   188: iload #8
/*      */     //   190: iload #6
/*      */     //   192: invokespecial _prependOrWriteCharacterEscape : (CI)V
/*      */     //   195: goto -> 51
/*      */     //   198: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #1433	-> 0
/*      */     //   #1434	-> 7
/*      */     //   #1435	-> 12
/*      */     //   #1436	-> 31
/*      */     //   #1437	-> 42
/*      */     //   #1438	-> 45
/*      */     //   #1441	-> 51
/*      */     //   #1446	-> 59
/*      */     //   #1447	-> 70
/*      */     //   #1448	-> 77
/*      */     //   #1449	-> 83
/*      */     //   #1450	-> 88
/*      */     //   #1452	-> 91
/*      */     //   #1453	-> 98
/*      */     //   #1454	-> 101
/*      */     //   #1456	-> 104
/*      */     //   #1457	-> 119
/*      */     //   #1458	-> 123
/*      */     //   #1461	-> 126
/*      */     //   #1462	-> 141
/*      */     //   #1465	-> 144
/*      */     //   #1466	-> 155
/*      */     //   #1467	-> 160
/*      */     //   #1469	-> 177
/*      */     //   #1470	-> 187
/*      */     //   #1471	-> 195
/*      */     //   #1472	-> 198
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   70	125	8	c	C
/*      */     //   155	40	9	flushLen	I
/*      */     //   0	199	0	this	Lcom/fasterxml/jackson/core/json/WriterBasedJsonGenerator;
/*      */     //   0	199	1	len	I
/*      */     //   7	192	2	end	I
/*      */     //   12	187	3	escCodes	[I
/*      */     //   31	168	4	maxNonEscaped	I
/*      */     //   42	157	5	escLimit	I
/*      */     //   45	154	6	escCode	I
/*      */     //   51	148	7	customEscapes	Lcom/fasterxml/jackson/core/io/CharacterEscapes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeSegmentCustom(int end) throws IOException, JsonGenerationException {
/* 1477 */     int[] escCodes = this._outputEscapes;
/* 1478 */     int maxNonEscaped = (this._maximumNonEscapedChar < 1) ? 65535 : this._maximumNonEscapedChar;
/* 1479 */     int escLimit = Math.min(escCodes.length, maxNonEscaped + 1);
/* 1480 */     CharacterEscapes customEscapes = this._characterEscapes;
/*      */     
/* 1482 */     int ptr = 0;
/* 1483 */     int escCode = 0;
/* 1484 */     int start = ptr;
/*      */ 
/*      */     
/* 1487 */     while (ptr < end) {
/*      */       char c;
/*      */       
/*      */       do {
/* 1491 */         c = this._outputBuffer[ptr];
/* 1492 */         if (c < escLimit) {
/* 1493 */           escCode = escCodes[c];
/* 1494 */           if (escCode != 0)
/*      */             break; 
/*      */         } else {
/* 1497 */           if (c > maxNonEscaped) {
/* 1498 */             escCode = -1;
/*      */             break;
/*      */           } 
/* 1501 */           if ((this._currentEscape = customEscapes.getEscapeSequence(c)) != null) {
/* 1502 */             escCode = -2;
/*      */             break;
/*      */           } 
/*      */         } 
/* 1506 */       } while (++ptr < end);
/*      */ 
/*      */ 
/*      */       
/* 1510 */       int flushLen = ptr - start;
/* 1511 */       if (flushLen > 0) {
/* 1512 */         this._writer.write(this._outputBuffer, start, flushLen);
/* 1513 */         if (ptr >= end) {
/*      */           break;
/*      */         }
/*      */       } 
/* 1517 */       ptr++;
/* 1518 */       start = _prependOrWriteCharacterEscape(this._outputBuffer, ptr, end, c, escCode);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void _writeStringCustom(char[] text, int offset, int len) throws IOException, JsonGenerationException {
/* 1525 */     len += offset;
/* 1526 */     int[] escCodes = this._outputEscapes;
/* 1527 */     int maxNonEscaped = (this._maximumNonEscapedChar < 1) ? 65535 : this._maximumNonEscapedChar;
/* 1528 */     int escLimit = Math.min(escCodes.length, maxNonEscaped + 1);
/* 1529 */     CharacterEscapes customEscapes = this._characterEscapes;
/*      */     
/* 1531 */     int escCode = 0;
/*      */     
/* 1533 */     while (offset < len) {
/* 1534 */       char c; int start = offset;
/*      */ 
/*      */       
/*      */       do {
/* 1538 */         c = text[offset];
/* 1539 */         if (c < escLimit) {
/* 1540 */           escCode = escCodes[c];
/* 1541 */           if (escCode != 0)
/*      */             break; 
/*      */         } else {
/* 1544 */           if (c > maxNonEscaped) {
/* 1545 */             escCode = -1;
/*      */             break;
/*      */           } 
/* 1548 */           if ((this._currentEscape = customEscapes.getEscapeSequence(c)) != null) {
/* 1549 */             escCode = -2;
/*      */             break;
/*      */           } 
/*      */         } 
/* 1553 */       } while (++offset < len);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1559 */       int newAmount = offset - start;
/* 1560 */       if (newAmount < 32) {
/*      */         
/* 1562 */         if (this._outputTail + newAmount > this._outputEnd) {
/* 1563 */           _flushBuffer();
/*      */         }
/* 1565 */         if (newAmount > 0) {
/* 1566 */           System.arraycopy(text, start, this._outputBuffer, this._outputTail, newAmount);
/* 1567 */           this._outputTail += newAmount;
/*      */         } 
/*      */       } else {
/* 1570 */         _flushBuffer();
/* 1571 */         this._writer.write(text, start, newAmount);
/*      */       } 
/*      */       
/* 1574 */       if (offset >= len) {
/*      */         break;
/*      */       }
/*      */       
/* 1578 */       offset++;
/* 1579 */       _appendCharacterEscape(c, escCode);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _writeBinary(Base64Variant b64variant, byte[] input, int inputPtr, int inputEnd) throws IOException, JsonGenerationException {
/* 1593 */     int safeInputEnd = inputEnd - 3;
/*      */     
/* 1595 */     int safeOutputEnd = this._outputEnd - 6;
/* 1596 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */ 
/*      */     
/* 1599 */     while (inputPtr <= safeInputEnd) {
/* 1600 */       if (this._outputTail > safeOutputEnd) {
/* 1601 */         _flushBuffer();
/*      */       }
/*      */       
/* 1604 */       int b24 = input[inputPtr++] << 8;
/* 1605 */       b24 |= input[inputPtr++] & 0xFF;
/* 1606 */       b24 = b24 << 8 | input[inputPtr++] & 0xFF;
/* 1607 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 1608 */       if (--chunksBeforeLF <= 0) {
/*      */         
/* 1610 */         this._outputBuffer[this._outputTail++] = '\\';
/* 1611 */         this._outputBuffer[this._outputTail++] = 'n';
/* 1612 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1617 */     int inputLeft = inputEnd - inputPtr;
/* 1618 */     if (inputLeft > 0) {
/* 1619 */       if (this._outputTail > safeOutputEnd) {
/* 1620 */         _flushBuffer();
/*      */       }
/* 1622 */       int b24 = input[inputPtr++] << 16;
/* 1623 */       if (inputLeft == 2) {
/* 1624 */         b24 |= (input[inputPtr++] & 0xFF) << 8;
/*      */       }
/* 1626 */       this._outputTail = b64variant.encodeBase64Partial(b24, inputLeft, this._outputBuffer, this._outputTail);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _writeBinary(Base64Variant b64variant, InputStream data, byte[] readBuffer, int bytesLeft) throws IOException, JsonGenerationException {
/* 1635 */     int inputPtr = 0;
/* 1636 */     int inputEnd = 0;
/* 1637 */     int lastFullOffset = -3;
/*      */ 
/*      */     
/* 1640 */     int safeOutputEnd = this._outputEnd - 6;
/* 1641 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */     
/* 1643 */     while (bytesLeft > 2) {
/* 1644 */       if (inputPtr > lastFullOffset) {
/* 1645 */         inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, bytesLeft);
/* 1646 */         inputPtr = 0;
/* 1647 */         if (inputEnd < 3) {
/*      */           break;
/*      */         }
/* 1650 */         lastFullOffset = inputEnd - 3;
/*      */       } 
/* 1652 */       if (this._outputTail > safeOutputEnd) {
/* 1653 */         _flushBuffer();
/*      */       }
/* 1655 */       int b24 = readBuffer[inputPtr++] << 8;
/* 1656 */       b24 |= readBuffer[inputPtr++] & 0xFF;
/* 1657 */       b24 = b24 << 8 | readBuffer[inputPtr++] & 0xFF;
/* 1658 */       bytesLeft -= 3;
/* 1659 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 1660 */       if (--chunksBeforeLF <= 0) {
/* 1661 */         this._outputBuffer[this._outputTail++] = '\\';
/* 1662 */         this._outputBuffer[this._outputTail++] = 'n';
/* 1663 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1668 */     if (bytesLeft > 0) {
/* 1669 */       inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, bytesLeft);
/* 1670 */       inputPtr = 0;
/* 1671 */       if (inputEnd > 0) {
/* 1672 */         int amount; if (this._outputTail > safeOutputEnd) {
/* 1673 */           _flushBuffer();
/*      */         }
/* 1675 */         int b24 = readBuffer[inputPtr++] << 16;
/*      */         
/* 1677 */         if (inputPtr < inputEnd) {
/* 1678 */           b24 |= (readBuffer[inputPtr] & 0xFF) << 8;
/* 1679 */           amount = 2;
/*      */         } else {
/* 1681 */           amount = 1;
/*      */         } 
/* 1683 */         this._outputTail = b64variant.encodeBase64Partial(b24, amount, this._outputBuffer, this._outputTail);
/* 1684 */         bytesLeft -= amount;
/*      */       } 
/*      */     } 
/* 1687 */     return bytesLeft;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int _writeBinary(Base64Variant b64variant, InputStream data, byte[] readBuffer) throws IOException, JsonGenerationException {
/* 1695 */     int inputPtr = 0;
/* 1696 */     int inputEnd = 0;
/* 1697 */     int lastFullOffset = -3;
/* 1698 */     int bytesDone = 0;
/*      */ 
/*      */     
/* 1701 */     int safeOutputEnd = this._outputEnd - 6;
/* 1702 */     int chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */ 
/*      */     
/*      */     while (true) {
/* 1706 */       if (inputPtr > lastFullOffset) {
/* 1707 */         inputEnd = _readMore(data, readBuffer, inputPtr, inputEnd, readBuffer.length);
/* 1708 */         inputPtr = 0;
/* 1709 */         if (inputEnd < 3) {
/*      */           break;
/*      */         }
/* 1712 */         lastFullOffset = inputEnd - 3;
/*      */       } 
/* 1714 */       if (this._outputTail > safeOutputEnd) {
/* 1715 */         _flushBuffer();
/*      */       }
/*      */       
/* 1718 */       int b24 = readBuffer[inputPtr++] << 8;
/* 1719 */       b24 |= readBuffer[inputPtr++] & 0xFF;
/* 1720 */       b24 = b24 << 8 | readBuffer[inputPtr++] & 0xFF;
/* 1721 */       bytesDone += 3;
/* 1722 */       this._outputTail = b64variant.encodeBase64Chunk(b24, this._outputBuffer, this._outputTail);
/* 1723 */       if (--chunksBeforeLF <= 0) {
/* 1724 */         this._outputBuffer[this._outputTail++] = '\\';
/* 1725 */         this._outputBuffer[this._outputTail++] = 'n';
/* 1726 */         chunksBeforeLF = b64variant.getMaxLineLength() >> 2;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1731 */     if (inputPtr < inputEnd) {
/* 1732 */       if (this._outputTail > safeOutputEnd) {
/* 1733 */         _flushBuffer();
/*      */       }
/* 1735 */       int b24 = readBuffer[inputPtr++] << 16;
/* 1736 */       int amount = 1;
/* 1737 */       if (inputPtr < inputEnd) {
/* 1738 */         b24 |= (readBuffer[inputPtr] & 0xFF) << 8;
/* 1739 */         amount = 2;
/*      */       } 
/* 1741 */       bytesDone += amount;
/* 1742 */       this._outputTail = b64variant.encodeBase64Partial(b24, amount, this._outputBuffer, this._outputTail);
/*      */     } 
/* 1744 */     return bytesDone;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _readMore(InputStream in, byte[] readBuffer, int inputPtr, int inputEnd, int maxRead) throws IOException {
/* 1752 */     int i = 0;
/* 1753 */     while (inputPtr < inputEnd) {
/* 1754 */       readBuffer[i++] = readBuffer[inputPtr++];
/*      */     }
/* 1756 */     inputPtr = 0;
/* 1757 */     inputEnd = i;
/* 1758 */     maxRead = Math.min(maxRead, readBuffer.length);
/*      */     
/*      */     do {
/* 1761 */       int length = maxRead - inputEnd;
/* 1762 */       if (length == 0) {
/*      */         break;
/*      */       }
/* 1765 */       int count = in.read(readBuffer, inputEnd, length);
/* 1766 */       if (count < 0) {
/* 1767 */         return inputEnd;
/*      */       }
/* 1769 */       inputEnd += count;
/* 1770 */     } while (inputEnd < 3);
/* 1771 */     return inputEnd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void _writeNull() throws IOException {
/* 1782 */     if (this._outputTail + 4 >= this._outputEnd) {
/* 1783 */       _flushBuffer();
/*      */     }
/* 1785 */     int ptr = this._outputTail;
/* 1786 */     char[] buf = this._outputBuffer;
/* 1787 */     buf[ptr] = 'n';
/* 1788 */     buf[++ptr] = 'u';
/* 1789 */     buf[++ptr] = 'l';
/* 1790 */     buf[++ptr] = 'l';
/* 1791 */     this._outputTail = ptr + 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _prependOrWriteCharacterEscape(char ch, int escCode) throws IOException, JsonGenerationException {
/*      */     String escape;
/* 1808 */     if (escCode >= 0) {
/* 1809 */       if (this._outputTail >= 2) {
/* 1810 */         int ptr = this._outputTail - 2;
/* 1811 */         this._outputHead = ptr;
/* 1812 */         this._outputBuffer[ptr++] = '\\';
/* 1813 */         this._outputBuffer[ptr] = (char)escCode;
/*      */         
/*      */         return;
/*      */       } 
/* 1817 */       char[] buf = this._entityBuffer;
/* 1818 */       if (buf == null) {
/* 1819 */         buf = _allocateEntityBuffer();
/*      */       }
/* 1821 */       this._outputHead = this._outputTail;
/* 1822 */       buf[1] = (char)escCode;
/* 1823 */       this._writer.write(buf, 0, 2);
/*      */       return;
/*      */     } 
/* 1826 */     if (escCode != -2) {
/* 1827 */       char[] HEX_CHARS = getHexChars();
/* 1828 */       if (this._outputTail >= 6) {
/* 1829 */         char[] arrayOfChar = this._outputBuffer;
/* 1830 */         int ptr = this._outputTail - 6;
/* 1831 */         this._outputHead = ptr;
/* 1832 */         arrayOfChar[ptr] = '\\';
/* 1833 */         arrayOfChar[++ptr] = 'u';
/*      */         
/* 1835 */         if (ch > 'ÿ') {
/* 1836 */           int hi = ch >> 8 & 0xFF;
/* 1837 */           arrayOfChar[++ptr] = HEX_CHARS[hi >> 4];
/* 1838 */           arrayOfChar[++ptr] = HEX_CHARS[hi & 0xF];
/* 1839 */           ch = (char)(ch & 0xFF);
/*      */         } else {
/* 1841 */           arrayOfChar[++ptr] = '0';
/* 1842 */           arrayOfChar[++ptr] = '0';
/*      */         } 
/* 1844 */         arrayOfChar[++ptr] = HEX_CHARS[ch >> 4];
/* 1845 */         arrayOfChar[++ptr] = HEX_CHARS[ch & 0xF];
/*      */         
/*      */         return;
/*      */       } 
/* 1849 */       char[] buf = this._entityBuffer;
/* 1850 */       if (buf == null) {
/* 1851 */         buf = _allocateEntityBuffer();
/*      */       }
/* 1853 */       this._outputHead = this._outputTail;
/* 1854 */       if (ch > 'ÿ') {
/* 1855 */         int hi = ch >> 8 & 0xFF;
/* 1856 */         int lo = ch & 0xFF;
/* 1857 */         buf[10] = HEX_CHARS[hi >> 4];
/* 1858 */         buf[11] = HEX_CHARS[hi & 0xF];
/* 1859 */         buf[12] = HEX_CHARS[lo >> 4];
/* 1860 */         buf[13] = HEX_CHARS[lo & 0xF];
/* 1861 */         this._writer.write(buf, 8, 6);
/*      */       } else {
/* 1863 */         buf[6] = HEX_CHARS[ch >> 4];
/* 1864 */         buf[7] = HEX_CHARS[ch & 0xF];
/* 1865 */         this._writer.write(buf, 2, 6);
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1871 */     if (this._currentEscape == null) {
/* 1872 */       escape = this._characterEscapes.getEscapeSequence(ch).getValue();
/*      */     } else {
/* 1874 */       escape = this._currentEscape.getValue();
/* 1875 */       this._currentEscape = null;
/*      */     } 
/* 1877 */     int len = escape.length();
/* 1878 */     if (this._outputTail >= len) {
/* 1879 */       int ptr = this._outputTail - len;
/* 1880 */       this._outputHead = ptr;
/* 1881 */       escape.getChars(0, len, this._outputBuffer, ptr);
/*      */       
/*      */       return;
/*      */     } 
/* 1885 */     this._outputHead = this._outputTail;
/* 1886 */     this._writer.write(escape);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _prependOrWriteCharacterEscape(char[] buffer, int ptr, int end, char ch, int escCode) throws IOException, JsonGenerationException {
/*      */     String escape;
/* 1900 */     if (escCode >= 0) {
/* 1901 */       if (ptr > 1 && ptr < end) {
/* 1902 */         ptr -= 2;
/* 1903 */         buffer[ptr] = '\\';
/* 1904 */         buffer[ptr + 1] = (char)escCode;
/*      */       } else {
/* 1906 */         char[] ent = this._entityBuffer;
/* 1907 */         if (ent == null) {
/* 1908 */           ent = _allocateEntityBuffer();
/*      */         }
/* 1910 */         ent[1] = (char)escCode;
/* 1911 */         this._writer.write(ent, 0, 2);
/*      */       } 
/* 1913 */       return ptr;
/*      */     } 
/* 1915 */     if (escCode != -2) {
/* 1916 */       char[] HEX_CHARS = getHexChars();
/* 1917 */       if (ptr > 5 && ptr < end) {
/* 1918 */         ptr -= 6;
/* 1919 */         buffer[ptr++] = '\\';
/* 1920 */         buffer[ptr++] = 'u';
/*      */         
/* 1922 */         if (ch > 'ÿ') {
/* 1923 */           int hi = ch >> 8 & 0xFF;
/* 1924 */           buffer[ptr++] = HEX_CHARS[hi >> 4];
/* 1925 */           buffer[ptr++] = HEX_CHARS[hi & 0xF];
/* 1926 */           ch = (char)(ch & 0xFF);
/*      */         } else {
/* 1928 */           buffer[ptr++] = '0';
/* 1929 */           buffer[ptr++] = '0';
/*      */         } 
/* 1931 */         buffer[ptr++] = HEX_CHARS[ch >> 4];
/* 1932 */         buffer[ptr] = HEX_CHARS[ch & 0xF];
/* 1933 */         ptr -= 5;
/*      */       } else {
/*      */         
/* 1936 */         char[] ent = this._entityBuffer;
/* 1937 */         if (ent == null) {
/* 1938 */           ent = _allocateEntityBuffer();
/*      */         }
/* 1940 */         this._outputHead = this._outputTail;
/* 1941 */         if (ch > 'ÿ') {
/* 1942 */           int hi = ch >> 8 & 0xFF;
/* 1943 */           int lo = ch & 0xFF;
/* 1944 */           ent[10] = HEX_CHARS[hi >> 4];
/* 1945 */           ent[11] = HEX_CHARS[hi & 0xF];
/* 1946 */           ent[12] = HEX_CHARS[lo >> 4];
/* 1947 */           ent[13] = HEX_CHARS[lo & 0xF];
/* 1948 */           this._writer.write(ent, 8, 6);
/*      */         } else {
/* 1950 */           ent[6] = HEX_CHARS[ch >> 4];
/* 1951 */           ent[7] = HEX_CHARS[ch & 0xF];
/* 1952 */           this._writer.write(ent, 2, 6);
/*      */         } 
/*      */       } 
/* 1955 */       return ptr;
/*      */     } 
/*      */     
/* 1958 */     if (this._currentEscape == null) {
/* 1959 */       escape = this._characterEscapes.getEscapeSequence(ch).getValue();
/*      */     } else {
/* 1961 */       escape = this._currentEscape.getValue();
/* 1962 */       this._currentEscape = null;
/*      */     } 
/* 1964 */     int len = escape.length();
/* 1965 */     if (ptr >= len && ptr < end) {
/* 1966 */       ptr -= len;
/* 1967 */       escape.getChars(0, len, buffer, ptr);
/*      */     } else {
/* 1969 */       this._writer.write(escape);
/*      */     } 
/* 1971 */     return ptr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _appendCharacterEscape(char ch, int escCode) throws IOException, JsonGenerationException {
/*      */     String escape;
/* 1981 */     if (escCode >= 0) {
/* 1982 */       if (this._outputTail + 2 > this._outputEnd) {
/* 1983 */         _flushBuffer();
/*      */       }
/* 1985 */       this._outputBuffer[this._outputTail++] = '\\';
/* 1986 */       this._outputBuffer[this._outputTail++] = (char)escCode;
/*      */       return;
/*      */     } 
/* 1989 */     if (escCode != -2) {
/* 1990 */       if (this._outputTail + 5 >= this._outputEnd) {
/* 1991 */         _flushBuffer();
/*      */       }
/* 1993 */       int ptr = this._outputTail;
/* 1994 */       char[] buf = this._outputBuffer;
/* 1995 */       char[] HEX_CHARS = getHexChars();
/* 1996 */       buf[ptr++] = '\\';
/* 1997 */       buf[ptr++] = 'u';
/*      */       
/* 1999 */       if (ch > 'ÿ') {
/* 2000 */         int hi = ch >> 8 & 0xFF;
/* 2001 */         buf[ptr++] = HEX_CHARS[hi >> 4];
/* 2002 */         buf[ptr++] = HEX_CHARS[hi & 0xF];
/* 2003 */         ch = (char)(ch & 0xFF);
/*      */       } else {
/* 2005 */         buf[ptr++] = '0';
/* 2006 */         buf[ptr++] = '0';
/*      */       } 
/* 2008 */       buf[ptr++] = HEX_CHARS[ch >> 4];
/* 2009 */       buf[ptr++] = HEX_CHARS[ch & 0xF];
/* 2010 */       this._outputTail = ptr;
/*      */       
/*      */       return;
/*      */     } 
/* 2014 */     if (this._currentEscape == null) {
/* 2015 */       escape = this._characterEscapes.getEscapeSequence(ch).getValue();
/*      */     } else {
/* 2017 */       escape = this._currentEscape.getValue();
/* 2018 */       this._currentEscape = null;
/*      */     } 
/* 2020 */     int len = escape.length();
/* 2021 */     if (this._outputTail + len > this._outputEnd) {
/* 2022 */       _flushBuffer();
/* 2023 */       if (len > this._outputEnd) {
/* 2024 */         this._writer.write(escape);
/*      */         return;
/*      */       } 
/*      */     } 
/* 2028 */     escape.getChars(0, len, this._outputBuffer, this._outputTail);
/* 2029 */     this._outputTail += len;
/*      */   }
/*      */ 
/*      */   
/*      */   private char[] _allocateEntityBuffer() {
/* 2034 */     char[] buf = new char[14];
/*      */     
/* 2036 */     buf[0] = '\\';
/*      */     
/* 2038 */     buf[2] = '\\';
/* 2039 */     buf[3] = 'u';
/* 2040 */     buf[4] = '0';
/* 2041 */     buf[5] = '0';
/*      */     
/* 2043 */     buf[8] = '\\';
/* 2044 */     buf[9] = 'u';
/* 2045 */     this._entityBuffer = buf;
/* 2046 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char[] _allocateCopyBuffer() {
/* 2053 */     if (this._copyBuffer == null) {
/* 2054 */       this._copyBuffer = this._ioContext.allocNameCopyBuffer(2000);
/*      */     }
/* 2056 */     return this._copyBuffer;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _flushBuffer() throws IOException {
/* 2061 */     int len = this._outputTail - this._outputHead;
/* 2062 */     if (len > 0) {
/* 2063 */       int offset = this._outputHead;
/* 2064 */       this._outputTail = this._outputHead = 0;
/* 2065 */       this._writer.write(this._outputBuffer, offset, len);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\json\WriterBasedJsonGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */