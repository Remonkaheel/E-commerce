/*      */ package com.fasterxml.jackson.core.sym;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonFactory;
/*      */ import com.fasterxml.jackson.core.exc.StreamConstraintsException;
/*      */ import com.fasterxml.jackson.core.util.InternCache;
/*      */ import java.util.Arrays;
/*      */ import java.util.concurrent.atomic.AtomicReference;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ByteQuadsCanonicalizer
/*      */ {
/*      */   private static final int DEFAULT_T_SIZE = 64;
/*      */   private static final int MAX_T_SIZE = 65536;
/*      */   private static final int MIN_HASH_SIZE = 16;
/*      */   protected static final int MAX_ENTRIES_FOR_REUSE = 6000;
/*      */   protected final ByteQuadsCanonicalizer _parent;
/*      */   protected final AtomicReference<TableInfo> _tableInfo;
/*      */   protected final int _seed;
/*      */   protected final InternCache _interner;
/*      */   protected final boolean _failOnDoS;
/*      */   protected int[] _hashArea;
/*      */   protected int _hashSize;
/*      */   protected int _secondaryStart;
/*      */   protected int _tertiaryStart;
/*      */   protected int _tertiaryShift;
/*      */   protected int _count;
/*      */   protected String[] _names;
/*      */   protected int _spilloverEnd;
/*      */   protected int _longNameOffset;
/*      */   protected boolean _hashShared;
/*      */   private static final int MULT = 33;
/*      */   private static final int MULT2 = 65599;
/*      */   private static final int MULT3 = 31;
/*      */   
/*      */   private ByteQuadsCanonicalizer(int sz, int seed) {
/*  229 */     this._parent = null;
/*  230 */     this._count = 0;
/*      */ 
/*      */     
/*  233 */     this._hashShared = true;
/*  234 */     this._seed = seed;
/*  235 */     this._interner = null;
/*  236 */     this._failOnDoS = true;
/*      */     
/*  238 */     if (sz < 16) {
/*  239 */       sz = 16;
/*      */ 
/*      */     
/*      */     }
/*  243 */     else if ((sz & sz - 1) != 0) {
/*  244 */       int curr = 16;
/*  245 */       while (curr < sz) {
/*  246 */         curr += curr;
/*      */       }
/*  248 */       sz = curr;
/*      */     } 
/*      */     
/*  251 */     this._tableInfo = new AtomicReference<>(TableInfo.createInitial(sz));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ByteQuadsCanonicalizer(ByteQuadsCanonicalizer parent, int seed, TableInfo state, boolean intern, boolean failOnDoS) {
/*  261 */     this._parent = parent;
/*  262 */     this._seed = seed;
/*  263 */     this._interner = intern ? InternCache.instance : null;
/*  264 */     this._failOnDoS = failOnDoS;
/*  265 */     this._tableInfo = null;
/*      */ 
/*      */     
/*  268 */     this._count = state.count;
/*  269 */     this._hashSize = state.size;
/*  270 */     this._secondaryStart = this._hashSize << 2;
/*  271 */     this._tertiaryStart = this._secondaryStart + (this._secondaryStart >> 1);
/*  272 */     this._tertiaryShift = state.tertiaryShift;
/*      */     
/*  274 */     this._hashArea = state.mainHash;
/*  275 */     this._names = state.names;
/*      */     
/*  277 */     this._spilloverEnd = state.spilloverEnd;
/*  278 */     this._longNameOffset = state.longNameOffset;
/*      */ 
/*      */     
/*  281 */     this._hashShared = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ByteQuadsCanonicalizer(TableInfo state) {
/*  295 */     this._parent = null;
/*  296 */     this._seed = 0;
/*  297 */     this._interner = null;
/*  298 */     this._failOnDoS = true;
/*  299 */     this._tableInfo = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  305 */     this._count = -1;
/*      */     
/*  307 */     this._hashArea = state.mainHash;
/*  308 */     this._names = state.names;
/*      */     
/*  310 */     this._hashSize = state.size;
/*      */ 
/*      */ 
/*      */     
/*  314 */     int end = this._hashArea.length;
/*  315 */     this._secondaryStart = end;
/*  316 */     this._tertiaryStart = end;
/*  317 */     this._tertiaryShift = 1;
/*      */     
/*  319 */     this._spilloverEnd = end;
/*  320 */     this._longNameOffset = end;
/*      */ 
/*      */     
/*  323 */     this._hashShared = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static ByteQuadsCanonicalizer createRoot() {
/*  341 */     long now = System.currentTimeMillis();
/*      */     
/*  343 */     int seed = (int)now + (int)(now >>> 32L) | 0x1;
/*  344 */     return createRoot(seed);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected static ByteQuadsCanonicalizer createRoot(int seed) {
/*  350 */     return new ByteQuadsCanonicalizer(64, seed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteQuadsCanonicalizer makeChild(int flags) {
/*  362 */     return new ByteQuadsCanonicalizer(this, this._seed, this._tableInfo
/*  363 */         .get(), JsonFactory.Feature.INTERN_FIELD_NAMES
/*  364 */         .enabledIn(flags), JsonFactory.Feature.FAIL_ON_SYMBOL_HASH_OVERFLOW
/*  365 */         .enabledIn(flags));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ByteQuadsCanonicalizer makeChildOrPlaceholder(int flags) {
/*  381 */     if (JsonFactory.Feature.CANONICALIZE_FIELD_NAMES.enabledIn(flags))
/*      */     {
/*  383 */       return new ByteQuadsCanonicalizer(this, this._seed, this._tableInfo
/*  384 */           .get(), JsonFactory.Feature.INTERN_FIELD_NAMES
/*  385 */           .enabledIn(flags), JsonFactory.Feature.FAIL_ON_SYMBOL_HASH_OVERFLOW
/*  386 */           .enabledIn(flags));
/*      */     }
/*  388 */     return new ByteQuadsCanonicalizer(this._tableInfo.get());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void release() {
/*  401 */     if (this._parent != null && maybeDirty()) {
/*  402 */       this._parent.mergeChild(new TableInfo(this));
/*      */ 
/*      */       
/*  405 */       this._hashShared = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void mergeChild(TableInfo childState) {
/*  411 */     int childCount = childState.count;
/*  412 */     TableInfo currState = this._tableInfo.get();
/*      */ 
/*      */ 
/*      */     
/*  416 */     if (childCount == currState.count) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  424 */     if (childCount > 6000)
/*      */     {
/*  426 */       childState = TableInfo.createInitial(64);
/*      */     }
/*  428 */     this._tableInfo.compareAndSet(currState, childState);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int size() {
/*  442 */     if (this._tableInfo != null) {
/*  443 */       return ((TableInfo)this._tableInfo.get()).count;
/*      */     }
/*      */     
/*  446 */     return this._count;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int bucketCount() {
/*  452 */     return this._hashSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean maybeDirty() {
/*  461 */     return !this._hashShared;
/*      */   } public int hashSeed() {
/*  463 */     return this._seed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCanonicalizing() {
/*  473 */     return (this._parent != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int primaryCount() {
/*  485 */     int count = 0;
/*  486 */     for (int offset = 3, end = this._secondaryStart; offset < end; offset += 4) {
/*  487 */       if (this._hashArea[offset] != 0) {
/*  488 */         count++;
/*      */       }
/*      */     } 
/*  491 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int secondaryCount() {
/*  501 */     int count = 0;
/*  502 */     int offset = this._secondaryStart + 3;
/*  503 */     for (int end = this._tertiaryStart; offset < end; offset += 4) {
/*  504 */       if (this._hashArea[offset] != 0) {
/*  505 */         count++;
/*      */       }
/*      */     } 
/*  508 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int tertiaryCount() {
/*  518 */     int count = 0;
/*  519 */     int offset = this._tertiaryStart + 3;
/*  520 */     for (int end = offset + this._hashSize; offset < end; offset += 4) {
/*  521 */       if (this._hashArea[offset] != 0) {
/*  522 */         count++;
/*      */       }
/*      */     } 
/*  525 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int spilloverCount() {
/*  536 */     return this._spilloverEnd - _spilloverStart() >> 2;
/*      */   }
/*      */ 
/*      */   
/*      */   public int totalCount() {
/*  541 */     int count = 0;
/*  542 */     for (int offset = 3, end = this._hashSize << 3; offset < end; offset += 4) {
/*  543 */       if (this._hashArea[offset] != 0) {
/*  544 */         count++;
/*      */       }
/*      */     } 
/*  547 */     return count;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/*  552 */     int pri = primaryCount();
/*  553 */     int sec = secondaryCount();
/*  554 */     int tert = tertiaryCount();
/*  555 */     int spill = spilloverCount();
/*  556 */     int total = totalCount();
/*  557 */     return String.format("[%s: size=%d, hashSize=%d, %d/%d/%d/%d pri/sec/ter/spill (=%s), total:%d]", new Object[] {
/*  558 */           getClass().getName(), Integer.valueOf(this._count), Integer.valueOf(this._hashSize), 
/*  559 */           Integer.valueOf(pri), Integer.valueOf(sec), Integer.valueOf(tert), Integer.valueOf(spill), Integer.valueOf(pri + sec + tert + spill), Integer.valueOf(total)
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String findName(int q1) {
/*  570 */     int offset = _calcOffset(calcHash(q1));
/*      */     
/*  572 */     int[] hashArea = this._hashArea;
/*      */     
/*  574 */     int len = hashArea[offset + 3];
/*      */     
/*  576 */     if (len == 1) {
/*  577 */       if (hashArea[offset] == q1) {
/*  578 */         return this._names[offset >> 2];
/*      */       }
/*  580 */     } else if (len == 0) {
/*  581 */       return null;
/*      */     } 
/*      */     
/*  584 */     int offset2 = this._secondaryStart + (offset >> 3 << 2);
/*      */     
/*  586 */     len = hashArea[offset2 + 3];
/*      */     
/*  588 */     if (len == 1) {
/*  589 */       if (hashArea[offset2] == q1) {
/*  590 */         return this._names[offset2 >> 2];
/*      */       }
/*  592 */     } else if (len == 0) {
/*  593 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  597 */     return _findSecondary(offset, q1);
/*      */   }
/*      */ 
/*      */   
/*      */   public String findName(int q1, int q2) {
/*  602 */     int offset = _calcOffset(calcHash(q1, q2));
/*      */     
/*  604 */     int[] hashArea = this._hashArea;
/*      */     
/*  606 */     int len = hashArea[offset + 3];
/*      */     
/*  608 */     if (len == 2) {
/*  609 */       if (q1 == hashArea[offset] && q2 == hashArea[offset + 1]) {
/*  610 */         return this._names[offset >> 2];
/*      */       }
/*  612 */     } else if (len == 0) {
/*  613 */       return null;
/*      */     } 
/*      */     
/*  616 */     int offset2 = this._secondaryStart + (offset >> 3 << 2);
/*      */     
/*  618 */     len = hashArea[offset2 + 3];
/*      */     
/*  620 */     if (len == 2) {
/*  621 */       if (q1 == hashArea[offset2] && q2 == hashArea[offset2 + 1]) {
/*  622 */         return this._names[offset2 >> 2];
/*      */       }
/*  624 */     } else if (len == 0) {
/*  625 */       return null;
/*      */     } 
/*  627 */     return _findSecondary(offset, q1, q2);
/*      */   }
/*      */ 
/*      */   
/*      */   public String findName(int q1, int q2, int q3) {
/*  632 */     int offset = _calcOffset(calcHash(q1, q2, q3));
/*  633 */     int[] hashArea = this._hashArea;
/*  634 */     int len = hashArea[offset + 3];
/*      */     
/*  636 */     if (len == 3) {
/*  637 */       if (q1 == hashArea[offset] && hashArea[offset + 1] == q2 && hashArea[offset + 2] == q3) {
/*  638 */         return this._names[offset >> 2];
/*      */       }
/*  640 */     } else if (len == 0) {
/*  641 */       return null;
/*      */     } 
/*      */     
/*  644 */     int offset2 = this._secondaryStart + (offset >> 3 << 2);
/*      */     
/*  646 */     len = hashArea[offset2 + 3];
/*      */     
/*  648 */     if (len == 3) {
/*  649 */       if (q1 == hashArea[offset2] && hashArea[offset2 + 1] == q2 && hashArea[offset2 + 2] == q3) {
/*  650 */         return this._names[offset2 >> 2];
/*      */       }
/*  652 */     } else if (len == 0) {
/*  653 */       return null;
/*      */     } 
/*  655 */     return _findSecondary(offset, q1, q2, q3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String findName(int[] q, int qlen) {
/*  664 */     if (qlen < 4) {
/*  665 */       switch (qlen) {
/*      */         case 3:
/*  667 */           return findName(q[0], q[1], q[2]);
/*      */         case 2:
/*  669 */           return findName(q[0], q[1]);
/*      */         case 1:
/*  671 */           return findName(q[0]);
/*      */       } 
/*  673 */       return "";
/*      */     } 
/*      */     
/*  676 */     int hash = calcHash(q, qlen);
/*  677 */     int offset = _calcOffset(hash);
/*      */     
/*  679 */     int[] hashArea = this._hashArea;
/*      */     
/*  681 */     int len = hashArea[offset + 3];
/*      */     
/*  683 */     if (hash == hashArea[offset] && len == qlen)
/*      */     {
/*  685 */       if (_verifyLongName(q, qlen, hashArea[offset + 1])) {
/*  686 */         return this._names[offset >> 2];
/*      */       }
/*      */     }
/*  689 */     if (len == 0) {
/*  690 */       return null;
/*      */     }
/*      */     
/*  693 */     int offset2 = this._secondaryStart + (offset >> 3 << 2);
/*      */     
/*  695 */     int len2 = hashArea[offset2 + 3];
/*  696 */     if (hash == hashArea[offset2] && len2 == qlen && 
/*  697 */       _verifyLongName(q, qlen, hashArea[offset2 + 1])) {
/*  698 */       return this._names[offset2 >> 2];
/*      */     }
/*      */     
/*  701 */     return _findSecondary(offset, hash, q, qlen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _calcOffset(int hash) {
/*  709 */     int ix = hash & this._hashSize - 1;
/*      */     
/*  711 */     return ix << 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String _findSecondary(int origOffset, int q1) {
/*  726 */     int offset = this._tertiaryStart + (origOffset >> this._tertiaryShift + 2 << this._tertiaryShift);
/*  727 */     int[] hashArea = this._hashArea;
/*  728 */     int bucketSize = 1 << this._tertiaryShift;
/*  729 */     for (int end = offset + bucketSize; offset < end; offset += 4) {
/*  730 */       int len = hashArea[offset + 3];
/*  731 */       if (q1 == hashArea[offset] && 1 == len) {
/*  732 */         return this._names[offset >> 2];
/*      */       }
/*  734 */       if (len == 0) {
/*  735 */         return null;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  741 */     for (offset = _spilloverStart(); offset < this._spilloverEnd; offset += 4) {
/*  742 */       if (q1 == hashArea[offset] && 1 == hashArea[offset + 3]) {
/*  743 */         return this._names[offset >> 2];
/*      */       }
/*      */     } 
/*  746 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private String _findSecondary(int origOffset, int q1, int q2) {
/*  751 */     int offset = this._tertiaryStart + (origOffset >> this._tertiaryShift + 2 << this._tertiaryShift);
/*  752 */     int[] hashArea = this._hashArea;
/*      */     
/*  754 */     int bucketSize = 1 << this._tertiaryShift;
/*  755 */     for (int end = offset + bucketSize; offset < end; offset += 4) {
/*  756 */       int len = hashArea[offset + 3];
/*  757 */       if (q1 == hashArea[offset] && q2 == hashArea[offset + 1] && 2 == len) {
/*  758 */         return this._names[offset >> 2];
/*      */       }
/*  760 */       if (len == 0) {
/*  761 */         return null;
/*      */       }
/*      */     } 
/*  764 */     for (offset = _spilloverStart(); offset < this._spilloverEnd; offset += 4) {
/*  765 */       if (q1 == hashArea[offset] && q2 == hashArea[offset + 1] && 2 == hashArea[offset + 3]) {
/*  766 */         return this._names[offset >> 2];
/*      */       }
/*      */     } 
/*  769 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private String _findSecondary(int origOffset, int q1, int q2, int q3) {
/*  774 */     int offset = this._tertiaryStart + (origOffset >> this._tertiaryShift + 2 << this._tertiaryShift);
/*  775 */     int[] hashArea = this._hashArea;
/*      */     
/*  777 */     int bucketSize = 1 << this._tertiaryShift;
/*  778 */     for (int end = offset + bucketSize; offset < end; offset += 4) {
/*  779 */       int len = hashArea[offset + 3];
/*  780 */       if (q1 == hashArea[offset] && q2 == hashArea[offset + 1] && q3 == hashArea[offset + 2] && 3 == len) {
/*  781 */         return this._names[offset >> 2];
/*      */       }
/*  783 */       if (len == 0) {
/*  784 */         return null;
/*      */       }
/*      */     } 
/*  787 */     for (offset = _spilloverStart(); offset < this._spilloverEnd; offset += 4) {
/*  788 */       if (q1 == hashArea[offset] && q2 == hashArea[offset + 1] && q3 == hashArea[offset + 2] && 3 == hashArea[offset + 3])
/*      */       {
/*  790 */         return this._names[offset >> 2];
/*      */       }
/*      */     } 
/*  793 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private String _findSecondary(int origOffset, int hash, int[] q, int qlen) {
/*  798 */     int offset = this._tertiaryStart + (origOffset >> this._tertiaryShift + 2 << this._tertiaryShift);
/*  799 */     int[] hashArea = this._hashArea;
/*      */     
/*  801 */     int bucketSize = 1 << this._tertiaryShift;
/*  802 */     for (int end = offset + bucketSize; offset < end; offset += 4) {
/*  803 */       int len = hashArea[offset + 3];
/*  804 */       if (hash == hashArea[offset] && qlen == len && 
/*  805 */         _verifyLongName(q, qlen, hashArea[offset + 1])) {
/*  806 */         return this._names[offset >> 2];
/*      */       }
/*      */       
/*  809 */       if (len == 0) {
/*  810 */         return null;
/*      */       }
/*      */     } 
/*  813 */     for (offset = _spilloverStart(); offset < this._spilloverEnd; offset += 4) {
/*  814 */       if (hash == hashArea[offset] && qlen == hashArea[offset + 3] && 
/*  815 */         _verifyLongName(q, qlen, hashArea[offset + 1])) {
/*  816 */         return this._names[offset >> 2];
/*      */       }
/*      */     } 
/*      */     
/*  820 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean _verifyLongName(int[] q, int qlen, int spillOffset) {
/*  825 */     int[] hashArea = this._hashArea;
/*      */     
/*  827 */     int ix = 0;
/*      */     
/*  829 */     switch (qlen)
/*      */     { default:
/*  831 */         return _verifyLongName2(q, qlen, spillOffset);
/*      */       case 8:
/*  833 */         if (q[ix++] != hashArea[spillOffset++]) return false; 
/*      */       case 7:
/*  835 */         if (q[ix++] != hashArea[spillOffset++]) return false; 
/*      */       case 6:
/*  837 */         if (q[ix++] != hashArea[spillOffset++]) return false; 
/*      */       case 5:
/*  839 */         if (q[ix++] != hashArea[spillOffset++]) return false;  break;
/*      */       case 4:
/*  841 */         break; }  if (q[ix++] != hashArea[spillOffset++]) return false; 
/*  842 */     if (q[ix++] != hashArea[spillOffset++]) return false; 
/*  843 */     if (q[ix++] != hashArea[spillOffset++]) return false; 
/*  844 */     if (q[ix++] != hashArea[spillOffset++]) return false;
/*      */     
/*  846 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean _verifyLongName2(int[] q, int qlen, int spillOffset) {
/*  851 */     int ix = 0;
/*      */     while (true) {
/*  853 */       if (q[ix++] != this._hashArea[spillOffset++]) {
/*  854 */         return false;
/*      */       }
/*  856 */       if (ix >= qlen) {
/*  857 */         return true;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addName(String name, int q1) throws StreamConstraintsException {
/*  873 */     _verifySharing();
/*  874 */     if (this._interner != null) {
/*  875 */       name = this._interner.intern(name);
/*      */     }
/*  877 */     int offset = _findOffsetForAdd(calcHash(q1));
/*  878 */     this._hashArea[offset] = q1;
/*  879 */     this._hashArea[offset + 3] = 1;
/*  880 */     this._names[offset >> 2] = name;
/*  881 */     this._count++;
/*  882 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addName(String name, int q1, int q2) throws StreamConstraintsException {
/*  893 */     _verifySharing();
/*  894 */     if (this._interner != null) {
/*  895 */       name = this._interner.intern(name);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  902 */     int hash = calcHash(q1, q2);
/*  903 */     int offset = _findOffsetForAdd(hash);
/*  904 */     this._hashArea[offset] = q1;
/*  905 */     this._hashArea[offset + 1] = q2;
/*  906 */     this._hashArea[offset + 3] = 2;
/*  907 */     this._names[offset >> 2] = name;
/*  908 */     this._count++;
/*  909 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addName(String name, int q1, int q2, int q3) throws StreamConstraintsException {
/*  921 */     _verifySharing();
/*  922 */     if (this._interner != null) {
/*  923 */       name = this._interner.intern(name);
/*      */     }
/*  925 */     int offset = _findOffsetForAdd(calcHash(q1, q2, q3));
/*  926 */     this._hashArea[offset] = q1;
/*  927 */     this._hashArea[offset + 1] = q2;
/*  928 */     this._hashArea[offset + 2] = q3;
/*  929 */     this._hashArea[offset + 3] = 3;
/*  930 */     this._names[offset >> 2] = name;
/*  931 */     this._count++;
/*  932 */     return name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String addName(String name, int[] q, int qlen) throws StreamConstraintsException {
/*  944 */     _verifySharing();
/*  945 */     if (this._interner != null) {
/*  946 */       name = this._interner.intern(name);
/*      */     }
/*      */ 
/*      */     
/*  950 */     switch (qlen)
/*      */     
/*      */     { case 1:
/*  953 */         offset = _findOffsetForAdd(calcHash(q[0]));
/*  954 */         this._hashArea[offset] = q[0];
/*  955 */         this._hashArea[offset + 3] = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  985 */         this._names[offset >> 2] = name;
/*      */ 
/*      */         
/*  988 */         this._count++;
/*  989 */         return name;case 2: offset = _findOffsetForAdd(calcHash(q[0], q[1])); this._hashArea[offset] = q[0]; this._hashArea[offset + 1] = q[1]; this._hashArea[offset + 3] = 2; this._names[offset >> 2] = name; this._count++; return name;case 3: offset = _findOffsetForAdd(calcHash(q[0], q[1], q[2])); this._hashArea[offset] = q[0]; this._hashArea[offset + 1] = q[1]; this._hashArea[offset + 2] = q[2]; this._hashArea[offset + 3] = 3; this._names[offset >> 2] = name; this._count++; return name; }  int hash = calcHash(q, qlen); int offset = _findOffsetForAdd(hash); this._hashArea[offset] = hash; int longStart = _appendLongName(q, qlen); this._hashArea[offset + 1] = longStart; this._hashArea[offset + 3] = qlen; this._names[offset >> 2] = name; this._count++; return name;
/*      */   }
/*      */ 
/*      */   
/*      */   private void _verifySharing() {
/*  994 */     if (this._hashShared) {
/*      */ 
/*      */       
/*  997 */       if (this._parent == null) {
/*  998 */         if (this._count == 0) {
/*  999 */           throw new IllegalStateException("Internal error: Cannot add names to Root symbol table");
/*      */         }
/* 1001 */         throw new IllegalStateException("Internal error: Cannot add names to Placeholder symbol table");
/*      */       } 
/*      */       
/* 1004 */       this._hashArea = Arrays.copyOf(this._hashArea, this._hashArea.length);
/* 1005 */       this._names = Arrays.<String>copyOf(this._names, this._names.length);
/* 1006 */       this._hashShared = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _findOffsetForAdd(int hash) throws StreamConstraintsException {
/* 1020 */     int offset = _calcOffset(hash);
/* 1021 */     int[] hashArea = this._hashArea;
/* 1022 */     if (hashArea[offset + 3] == 0)
/*      */     {
/* 1024 */       return offset;
/*      */     }
/*      */ 
/*      */     
/* 1028 */     if (_checkNeedForRehash()) {
/* 1029 */       return _resizeAndFindOffsetForAdd(hash);
/*      */     }
/*      */ 
/*      */     
/* 1033 */     int offset2 = this._secondaryStart + (offset >> 3 << 2);
/* 1034 */     if (hashArea[offset2 + 3] == 0)
/*      */     {
/* 1036 */       return offset2;
/*      */     }
/*      */ 
/*      */     
/* 1040 */     offset2 = this._tertiaryStart + (offset >> this._tertiaryShift + 2 << this._tertiaryShift);
/* 1041 */     int bucketSize = 1 << this._tertiaryShift; int end;
/* 1042 */     for (end = offset2 + bucketSize; offset2 < end; offset2 += 4) {
/* 1043 */       if (hashArea[offset2 + 3] == 0)
/*      */       {
/* 1045 */         return offset2;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1050 */     offset = this._spilloverEnd;
/* 1051 */     this._spilloverEnd += 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1061 */     end = this._hashSize << 3;
/* 1062 */     if (this._spilloverEnd >= end) {
/* 1063 */       if (this._failOnDoS) {
/* 1064 */         _reportTooManyCollisions();
/*      */       }
/* 1066 */       return _resizeAndFindOffsetForAdd(hash);
/*      */     } 
/* 1068 */     return offset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _resizeAndFindOffsetForAdd(int hash) throws StreamConstraintsException {
/* 1075 */     rehash();
/*      */ 
/*      */     
/* 1078 */     int offset = _calcOffset(hash);
/* 1079 */     int[] hashArea = this._hashArea;
/* 1080 */     if (hashArea[offset + 3] == 0) {
/* 1081 */       return offset;
/*      */     }
/* 1083 */     int offset2 = this._secondaryStart + (offset >> 3 << 2);
/* 1084 */     if (hashArea[offset2 + 3] == 0) {
/* 1085 */       return offset2;
/*      */     }
/* 1087 */     offset2 = this._tertiaryStart + (offset >> this._tertiaryShift + 2 << this._tertiaryShift);
/* 1088 */     int bucketSize = 1 << this._tertiaryShift;
/* 1089 */     for (int end = offset2 + bucketSize; offset2 < end; offset2 += 4) {
/* 1090 */       if (hashArea[offset2 + 3] == 0) {
/* 1091 */         return offset2;
/*      */       }
/*      */     } 
/* 1094 */     offset = this._spilloverEnd;
/* 1095 */     this._spilloverEnd += 4;
/* 1096 */     return offset;
/*      */   }
/*      */ 
/*      */   
/*      */   static int multiplyByFourFifths(int number) {
/* 1101 */     return (int)(number * 3435973837L >>> 32L);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _checkNeedForRehash() {
/* 1107 */     if (this._count > this._hashSize >> 1) {
/* 1108 */       int spillCount = this._spilloverEnd - _spilloverStart() >> 2;
/* 1109 */       if (spillCount > 1 + this._count >> 7 || this._count > 
/* 1110 */         multiplyByFourFifths(this._hashSize)) {
/* 1111 */         return true;
/*      */       }
/*      */     } 
/* 1114 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private int _appendLongName(int[] quads, int qlen) {
/* 1119 */     int start = this._longNameOffset;
/* 1120 */     int newStart = start + qlen;
/* 1121 */     if (newStart < 0) {
/* 1122 */       throw new IllegalStateException(String.format("Internal error: long name offset overflow; start=%s, qlen=%s", new Object[] {
/* 1123 */               Integer.valueOf(start), Integer.valueOf(qlen)
/*      */             }));
/*      */     }
/*      */     
/* 1127 */     if (newStart > this._hashArea.length) {
/*      */       
/* 1129 */       int toAdd = newStart - this._hashArea.length;
/*      */       
/* 1131 */       int minAdd = Math.min(4096, this._hashSize);
/*      */       
/* 1133 */       int newSize = this._hashArea.length + Math.max(toAdd, minAdd);
/* 1134 */       this._hashArea = Arrays.copyOf(this._hashArea, newSize);
/*      */     } 
/* 1136 */     System.arraycopy(quads, 0, this._hashArea, start, qlen);
/* 1137 */     this._longNameOffset = newStart;
/* 1138 */     return start;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int calcHash(int q1) {
/* 1163 */     int hash = q1 ^ this._seed;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1169 */     hash += hash >>> 16;
/* 1170 */     hash ^= hash << 3;
/* 1171 */     hash += hash >>> 12;
/* 1172 */     return hash;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int calcHash(int q1, int q2) {
/* 1179 */     int hash = q1;
/*      */     
/* 1181 */     hash += hash >>> 15;
/* 1182 */     hash ^= hash >>> 9;
/* 1183 */     hash += q2 * 33;
/* 1184 */     hash ^= this._seed;
/* 1185 */     hash += hash >>> 16;
/* 1186 */     hash ^= hash >>> 4;
/* 1187 */     hash += hash << 3;
/*      */     
/* 1189 */     return hash;
/*      */   }
/*      */ 
/*      */   
/*      */   public int calcHash(int q1, int q2, int q3) {
/* 1194 */     int hash = q1 ^ this._seed;
/* 1195 */     hash += hash >>> 9;
/* 1196 */     hash *= 31;
/* 1197 */     hash += q2;
/* 1198 */     hash *= 33;
/* 1199 */     hash += hash >>> 15;
/* 1200 */     hash ^= q3;
/*      */     
/* 1202 */     hash += hash >>> 4;
/*      */     
/* 1204 */     hash += hash >>> 15;
/* 1205 */     hash ^= hash << 9;
/*      */     
/* 1207 */     return hash;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int calcHash(int[] q, int qlen) {
/* 1218 */     if (qlen < 4) {
/* 1219 */       throw new IllegalArgumentException("qlen is too short, needs to be at least 4");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1226 */     int hash = q[0] ^ this._seed;
/* 1227 */     hash += hash >>> 9;
/* 1228 */     hash += q[1];
/* 1229 */     hash += hash >>> 15;
/* 1230 */     hash *= 33;
/* 1231 */     hash ^= q[2];
/* 1232 */     hash += hash >>> 4;
/*      */     
/* 1234 */     for (int i = 3; i < qlen; i++) {
/* 1235 */       int next = q[i];
/* 1236 */       next ^= next >> 21;
/* 1237 */       hash += next;
/*      */     } 
/* 1239 */     hash *= 65599;
/*      */ 
/*      */     
/* 1242 */     hash += hash >>> 19;
/* 1243 */     hash ^= hash << 5;
/* 1244 */     return hash;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void rehash() throws StreamConstraintsException {
/* 1256 */     this._hashShared = false;
/*      */ 
/*      */ 
/*      */     
/* 1260 */     int[] oldHashArea = this._hashArea;
/* 1261 */     String[] oldNames = this._names;
/* 1262 */     int oldSize = this._hashSize;
/* 1263 */     int oldCount = this._count;
/* 1264 */     int newSize = oldSize + oldSize;
/* 1265 */     int oldEnd = this._spilloverEnd;
/*      */ 
/*      */ 
/*      */     
/* 1269 */     if (newSize > 65536) {
/* 1270 */       nukeSymbols(true);
/*      */       
/*      */       return;
/*      */     } 
/* 1274 */     this._hashArea = new int[oldHashArea.length + (oldSize << 3)];
/* 1275 */     this._hashSize = newSize;
/* 1276 */     this._secondaryStart = newSize << 2;
/* 1277 */     this._tertiaryStart = this._secondaryStart + (this._secondaryStart >> 1);
/* 1278 */     this._tertiaryShift = _calcTertiaryShift(newSize);
/*      */ 
/*      */     
/* 1281 */     this._names = new String[oldNames.length << 1];
/* 1282 */     nukeSymbols(false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1289 */     int copyCount = 0;
/* 1290 */     int[] q = new int[16];
/* 1291 */     for (int offset = 0, end = oldEnd; offset < end; offset += 4) {
/* 1292 */       int len = oldHashArea[offset + 3];
/* 1293 */       if (len != 0) {
/*      */         int qoff;
/*      */         
/* 1296 */         copyCount++;
/* 1297 */         String name = oldNames[offset >> 2];
/* 1298 */         switch (len) {
/*      */           case 1:
/* 1300 */             q[0] = oldHashArea[offset];
/* 1301 */             addName(name, q, 1);
/*      */             break;
/*      */           case 2:
/* 1304 */             q[0] = oldHashArea[offset];
/* 1305 */             q[1] = oldHashArea[offset + 1];
/* 1306 */             addName(name, q, 2);
/*      */             break;
/*      */           case 3:
/* 1309 */             q[0] = oldHashArea[offset];
/* 1310 */             q[1] = oldHashArea[offset + 1];
/* 1311 */             q[2] = oldHashArea[offset + 2];
/* 1312 */             addName(name, q, 3);
/*      */             break;
/*      */           default:
/* 1315 */             if (len > q.length) {
/* 1316 */               q = new int[len];
/*      */             }
/*      */             
/* 1319 */             qoff = oldHashArea[offset + 1];
/* 1320 */             System.arraycopy(oldHashArea, qoff, q, 0, len);
/* 1321 */             addName(name, q, len);
/*      */             break;
/*      */         } 
/*      */ 
/*      */       
/*      */       } 
/*      */     } 
/* 1328 */     if (copyCount != oldCount) {
/* 1329 */       throw new IllegalStateException("Internal error: Failed rehash(), old count=" + oldCount + ", copyCount=" + copyCount);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void nukeSymbols(boolean fill) {
/* 1338 */     this._count = 0;
/*      */     
/* 1340 */     this._spilloverEnd = _spilloverStart();
/*      */     
/* 1342 */     this._longNameOffset = this._hashSize << 3;
/* 1343 */     if (fill) {
/* 1344 */       Arrays.fill(this._hashArea, 0);
/* 1345 */       Arrays.fill((Object[])this._names, (Object)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int _spilloverStart() {
/* 1361 */     int offset = this._hashSize;
/* 1362 */     return (offset << 3) - offset;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportTooManyCollisions() throws StreamConstraintsException {
/* 1368 */     if (this._hashSize <= 1024) {
/*      */       return;
/*      */     }
/* 1371 */     throw new StreamConstraintsException("Spill-over slots in symbol table with " + this._count + " entries, hash area of " + this._hashSize + " slots is now full (all " + (this._hashSize >> 3) + " slots -- suspect a DoS attack based on hash collisions. You can disable the check via `JsonFactory.Feature.FAIL_ON_SYMBOL_HASH_OVERFLOW`");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int _calcTertiaryShift(int primarySlots) {
/* 1380 */     int tertSlots = primarySlots >> 2;
/*      */ 
/*      */     
/* 1383 */     if (tertSlots < 64) {
/* 1384 */       return 4;
/*      */     }
/* 1386 */     if (tertSlots <= 256) {
/* 1387 */       return 5;
/*      */     }
/* 1389 */     if (tertSlots <= 1024) {
/* 1390 */       return 6;
/*      */     }
/*      */     
/* 1393 */     return 7;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class TableInfo
/*      */   {
/*      */     public final int size;
/*      */ 
/*      */     
/*      */     public final int count;
/*      */ 
/*      */     
/*      */     public final int tertiaryShift;
/*      */ 
/*      */     
/*      */     public final int[] mainHash;
/*      */ 
/*      */     
/*      */     public final String[] names;
/*      */ 
/*      */     
/*      */     public final int spilloverEnd;
/*      */ 
/*      */     
/*      */     public final int longNameOffset;
/*      */ 
/*      */     
/*      */     public TableInfo(int size, int count, int tertiaryShift, int[] mainHash, String[] names, int spilloverEnd, int longNameOffset) {
/* 1422 */       this.size = size;
/* 1423 */       this.count = count;
/* 1424 */       this.tertiaryShift = tertiaryShift;
/* 1425 */       this.mainHash = mainHash;
/* 1426 */       this.names = names;
/* 1427 */       this.spilloverEnd = spilloverEnd;
/* 1428 */       this.longNameOffset = longNameOffset;
/*      */     }
/*      */ 
/*      */     
/*      */     public TableInfo(ByteQuadsCanonicalizer src) {
/* 1433 */       this.size = src._hashSize;
/* 1434 */       this.count = src._count;
/* 1435 */       this.tertiaryShift = src._tertiaryShift;
/* 1436 */       this.mainHash = src._hashArea;
/* 1437 */       this.names = src._names;
/* 1438 */       this.spilloverEnd = src._spilloverEnd;
/* 1439 */       this.longNameOffset = src._longNameOffset;
/*      */     }
/*      */     
/*      */     public static TableInfo createInitial(int sz) {
/* 1443 */       int hashAreaSize = sz << 3;
/* 1444 */       int tertShift = ByteQuadsCanonicalizer._calcTertiaryShift(sz);
/*      */       
/* 1446 */       return new TableInfo(sz, 0, tertShift, new int[hashAreaSize], new String[sz << 1], hashAreaSize - sz, hashAreaSize);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\sym\ByteQuadsCanonicalizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */