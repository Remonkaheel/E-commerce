/*     */ package com.fasterxml.jackson.core.sym;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonFactory;
/*     */ import com.fasterxml.jackson.core.StreamReadConstraints;
/*     */ import com.fasterxml.jackson.core.TokenStreamFactory;
/*     */ import com.fasterxml.jackson.core.exc.StreamConstraintsException;
/*     */ import com.fasterxml.jackson.core.util.InternCache;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.BitSet;
/*     */ import java.util.concurrent.atomic.AtomicReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CharsToNameCanonicalizer
/*     */ {
/*     */   public static final int HASH_MULT = 33;
/*     */   private static final int DEFAULT_T_SIZE = 64;
/*     */   private static final int MAX_T_SIZE = 65536;
/*     */   static final int MAX_ENTRIES_FOR_REUSE = 12000;
/*     */   static final int MAX_COLL_CHAIN_LENGTH = 150;
/*     */   protected final CharsToNameCanonicalizer _parent;
/*     */   protected final AtomicReference<TableInfo> _tableInfo;
/*     */   protected final StreamReadConstraints _streamReadConstraints;
/*     */   protected final int _seed;
/*     */   protected final int _factoryFeatures;
/*     */   protected boolean _canonicalize;
/*     */   protected String[] _symbols;
/*     */   protected Bucket[] _buckets;
/*     */   protected int _size;
/*     */   protected int _sizeThreshold;
/*     */   protected int _indexMask;
/*     */   protected int _longestCollisionList;
/*     */   protected boolean _hashShared;
/*     */   protected BitSet _overflows;
/*     */   
/*     */   private CharsToNameCanonicalizer(StreamReadConstraints src, int factoryFeatures, int seed) {
/* 249 */     this._parent = null;
/* 250 */     this._seed = seed;
/* 251 */     this._streamReadConstraints = src;
/*     */ 
/*     */     
/* 254 */     this._canonicalize = true;
/* 255 */     this._factoryFeatures = factoryFeatures;
/*     */     
/* 257 */     this._hashShared = false;
/* 258 */     this._longestCollisionList = 0;
/*     */     
/* 260 */     this._tableInfo = new AtomicReference<>(TableInfo.createInitial(64));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CharsToNameCanonicalizer(CharsToNameCanonicalizer parent, StreamReadConstraints src, int factoryFeatures, int seed, TableInfo parentState) {
/* 272 */     this._parent = parent;
/* 273 */     this._streamReadConstraints = src;
/* 274 */     this._seed = seed;
/* 275 */     this._tableInfo = null;
/* 276 */     this._factoryFeatures = factoryFeatures;
/* 277 */     this._canonicalize = JsonFactory.Feature.CANONICALIZE_FIELD_NAMES.enabledIn(factoryFeatures);
/*     */ 
/*     */     
/* 280 */     this._symbols = parentState.symbols;
/* 281 */     this._buckets = parentState.buckets;
/*     */     
/* 283 */     this._size = parentState.size;
/* 284 */     this._longestCollisionList = parentState.longestCollisionList;
/*     */ 
/*     */     
/* 287 */     int arrayLen = this._symbols.length;
/* 288 */     this._sizeThreshold = _thresholdSize(arrayLen);
/* 289 */     this._indexMask = arrayLen - 1;
/*     */ 
/*     */     
/* 292 */     this._hashShared = true;
/*     */   }
/*     */   private static int _thresholdSize(int hashAreaSize) {
/* 295 */     return hashAreaSize - (hashAreaSize >> 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static CharsToNameCanonicalizer createRoot() {
/* 310 */     return createRoot((TokenStreamFactory)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static CharsToNameCanonicalizer createRoot(int seed) {
/* 322 */     return createRoot(null, seed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CharsToNameCanonicalizer createRoot(TokenStreamFactory owner) {
/* 336 */     return createRoot(owner, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static CharsToNameCanonicalizer createRoot(TokenStreamFactory owner, int seed) {
/*     */     StreamReadConstraints src;
/*     */     int factoryFeatures;
/* 343 */     if (seed == 0)
/*     */     {
/* 345 */       seed = System.identityHashCode(owner);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 351 */     if (owner == null) {
/* 352 */       src = StreamReadConstraints.defaults();
/* 353 */       factoryFeatures = 0;
/*     */     } else {
/* 355 */       src = owner.streamReadConstraints();
/* 356 */       factoryFeatures = owner.getFactoryFeatures();
/*     */     } 
/* 358 */     return new CharsToNameCanonicalizer(src, factoryFeatures, seed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CharsToNameCanonicalizer makeChild() {
/* 375 */     return new CharsToNameCanonicalizer(this, this._streamReadConstraints, this._factoryFeatures, this._seed, this._tableInfo
/* 376 */         .get());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public CharsToNameCanonicalizer makeChild(int flags) {
/* 388 */     return makeChild();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/* 399 */     if (!maybeDirty()) {
/*     */       return;
/*     */     }
/* 402 */     if (this._parent != null && this._canonicalize) {
/* 403 */       this._parent.mergeChild(new TableInfo(this));
/*     */ 
/*     */       
/* 406 */       this._hashShared = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mergeChild(TableInfo childState) {
/* 419 */     int childCount = childState.size;
/* 420 */     TableInfo currState = this._tableInfo.get();
/*     */ 
/*     */ 
/*     */     
/* 424 */     if (childCount == currState.size) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 431 */     if (childCount > 12000)
/*     */     {
/* 433 */       childState = TableInfo.createInitial(64);
/*     */     }
/* 435 */     this._tableInfo.compareAndSet(currState, childState);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 448 */     if (this._tableInfo != null) {
/* 449 */       return ((TableInfo)this._tableInfo.get()).size;
/*     */     }
/*     */     
/* 452 */     return this._size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int bucketCount() {
/* 461 */     return this._symbols.length;
/* 462 */   } public boolean maybeDirty() { return !this._hashShared; } public int hashSeed() {
/* 463 */     return this._seed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int collisionCount() {
/* 475 */     int count = 0;
/*     */     
/* 477 */     for (Bucket bucket : this._buckets) {
/* 478 */       if (bucket != null) {
/* 479 */         count += bucket.length;
/*     */       }
/*     */     } 
/* 482 */     return count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int maxCollisionLength() {
/* 494 */     return this._longestCollisionList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findSymbol(char[] buffer, int start, int len, int h) throws IOException {
/* 504 */     if (len < 1) {
/* 505 */       return "";
/*     */     }
/* 507 */     if (!this._canonicalize) {
/* 508 */       this._streamReadConstraints.validateNameLength(len);
/* 509 */       return new String(buffer, start, len);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 517 */     int index = _hashToIndex(h);
/* 518 */     String sym = this._symbols[index];
/*     */ 
/*     */     
/* 521 */     if (sym != null) {
/*     */       
/* 523 */       if (sym.length() == len) {
/* 524 */         int i = 0;
/* 525 */         while (sym.charAt(i) == buffer[start + i]) {
/*     */           
/* 527 */           if (++i == len) {
/* 528 */             return sym;
/*     */           }
/*     */         } 
/*     */       } 
/* 532 */       Bucket b = this._buckets[index >> 1];
/* 533 */       if (b != null) {
/* 534 */         sym = b.has(buffer, start, len);
/* 535 */         if (sym != null) {
/* 536 */           return sym;
/*     */         }
/* 538 */         sym = _findSymbol2(buffer, start, len, b.next);
/* 539 */         if (sym != null) {
/* 540 */           return sym;
/*     */         }
/*     */       } 
/*     */     } 
/* 544 */     this._streamReadConstraints.validateNameLength(len);
/* 545 */     return _addSymbol(buffer, start, len, h, index);
/*     */   }
/*     */   
/*     */   private String _findSymbol2(char[] buffer, int start, int len, Bucket b) {
/* 549 */     while (b != null) {
/* 550 */       String sym = b.has(buffer, start, len);
/* 551 */       if (sym != null) {
/* 552 */         return sym;
/*     */       }
/* 554 */       b = b.next;
/*     */     } 
/* 556 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private String _addSymbol(char[] buffer, int start, int len, int h, int index) throws IOException {
/* 561 */     if (this._hashShared) {
/* 562 */       copyArrays();
/* 563 */       this._hashShared = false;
/* 564 */     } else if (this._size >= this._sizeThreshold) {
/* 565 */       rehash();
/*     */ 
/*     */       
/* 568 */       index = _hashToIndex(calcHash(buffer, start, len));
/*     */     } 
/*     */     
/* 571 */     String newSymbol = new String(buffer, start, len);
/* 572 */     if (JsonFactory.Feature.INTERN_FIELD_NAMES.enabledIn(this._factoryFeatures)) {
/* 573 */       newSymbol = InternCache.instance.intern(newSymbol);
/*     */     }
/* 575 */     this._size++;
/*     */     
/* 577 */     if (this._symbols[index] == null) {
/* 578 */       this._symbols[index] = newSymbol;
/*     */     } else {
/* 580 */       int bix = index >> 1;
/* 581 */       Bucket newB = new Bucket(newSymbol, this._buckets[bix]);
/* 582 */       int collLen = newB.length;
/* 583 */       if (collLen > 150) {
/*     */ 
/*     */         
/* 586 */         _handleSpillOverflow(bix, newB, index);
/*     */       } else {
/* 588 */         this._buckets[bix] = newB;
/* 589 */         this._longestCollisionList = Math.max(collLen, this._longestCollisionList);
/*     */       } 
/*     */     } 
/* 592 */     return newSymbol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _handleSpillOverflow(int bucketIndex, Bucket newBucket, int mainIndex) throws IOException {
/* 604 */     if (this._overflows == null) {
/* 605 */       this._overflows = new BitSet();
/* 606 */       this._overflows.set(bucketIndex);
/*     */     }
/* 608 */     else if (this._overflows.get(bucketIndex)) {
/*     */       
/* 610 */       if (JsonFactory.Feature.FAIL_ON_SYMBOL_HASH_OVERFLOW.enabledIn(this._factoryFeatures)) {
/* 611 */         _reportTooManyCollisions(150);
/*     */       }
/*     */ 
/*     */       
/* 615 */       this._canonicalize = false;
/*     */     } else {
/* 617 */       this._overflows.set(bucketIndex);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 622 */     this._symbols[mainIndex] = newBucket.symbol;
/* 623 */     this._buckets[bucketIndex] = null;
/*     */     
/* 625 */     this._size -= newBucket.length;
/*     */     
/* 627 */     this._longestCollisionList = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int _hashToIndex(int rawHash) {
/* 640 */     rawHash += rawHash >>> 15;
/* 641 */     rawHash ^= rawHash << 7;
/* 642 */     rawHash += rawHash >>> 3;
/* 643 */     return rawHash & this._indexMask;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int calcHash(char[] buffer, int start, int len) {
/* 659 */     int hash = this._seed;
/* 660 */     for (int i = start, end = start + len; i < end; i++) {
/* 661 */       hash = hash * 33 + buffer[i];
/*     */     }
/*     */     
/* 664 */     return (hash == 0) ? 1 : hash;
/*     */   }
/*     */ 
/*     */   
/*     */   public int calcHash(String key) {
/* 669 */     int len = key.length();
/*     */     
/* 671 */     int hash = this._seed;
/* 672 */     for (int i = 0; i < len; i++) {
/* 673 */       hash = hash * 33 + key.charAt(i);
/*     */     }
/*     */     
/* 676 */     return (hash == 0) ? 1 : hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void copyArrays() {
/* 690 */     String[] oldSyms = this._symbols;
/* 691 */     this._symbols = Arrays.<String>copyOf(oldSyms, oldSyms.length);
/* 692 */     Bucket[] oldBuckets = this._buckets;
/* 693 */     this._buckets = Arrays.<Bucket>copyOf(oldBuckets, oldBuckets.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void rehash() throws IOException {
/* 704 */     int size = this._symbols.length;
/* 705 */     int newSize = size + size;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 711 */     if (newSize > 65536) {
/*     */ 
/*     */       
/* 714 */       this._size = 0;
/* 715 */       this._canonicalize = false;
/*     */       
/* 717 */       this._symbols = new String[64];
/* 718 */       this._buckets = new Bucket[32];
/* 719 */       this._indexMask = 63;
/* 720 */       this._hashShared = false;
/*     */       
/*     */       return;
/*     */     } 
/* 724 */     String[] oldSyms = this._symbols;
/* 725 */     Bucket[] oldBuckets = this._buckets;
/* 726 */     this._symbols = new String[newSize];
/* 727 */     this._buckets = new Bucket[newSize >> 1];
/*     */     
/* 729 */     this._indexMask = newSize - 1;
/* 730 */     this._sizeThreshold = _thresholdSize(newSize);
/*     */     
/* 732 */     int count = 0;
/*     */ 
/*     */ 
/*     */     
/* 736 */     int maxColl = 0;
/* 737 */     for (int i = 0; i < size; i++) {
/* 738 */       String symbol = oldSyms[i];
/* 739 */       if (symbol != null) {
/* 740 */         count++;
/* 741 */         int index = _hashToIndex(calcHash(symbol));
/* 742 */         if (this._symbols[index] == null) {
/* 743 */           this._symbols[index] = symbol;
/*     */         } else {
/* 745 */           int bix = index >> 1;
/* 746 */           Bucket newB = new Bucket(symbol, this._buckets[bix]);
/* 747 */           this._buckets[bix] = newB;
/* 748 */           maxColl = Math.max(maxColl, newB.length);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 753 */     int bucketSize = size >> 1;
/* 754 */     for (int j = 0; j < bucketSize; j++) {
/* 755 */       Bucket b = oldBuckets[j];
/* 756 */       while (b != null) {
/* 757 */         count++;
/* 758 */         String symbol = b.symbol;
/* 759 */         int index = _hashToIndex(calcHash(symbol));
/* 760 */         if (this._symbols[index] == null) {
/* 761 */           this._symbols[index] = symbol;
/*     */         } else {
/* 763 */           int bix = index >> 1;
/* 764 */           Bucket newB = new Bucket(symbol, this._buckets[bix]);
/* 765 */           this._buckets[bix] = newB;
/* 766 */           maxColl = Math.max(maxColl, newB.length);
/*     */         } 
/* 768 */         b = b.next;
/*     */       } 
/*     */     } 
/* 771 */     this._longestCollisionList = maxColl;
/* 772 */     this._overflows = null;
/*     */     
/* 774 */     if (count != this._size) {
/* 775 */       throw new IllegalStateException(String.format("Internal error on SymbolTable.rehash(): had %d entries; now have %d", new Object[] {
/*     */               
/* 777 */               Integer.valueOf(this._size), Integer.valueOf(count)
/*     */             }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _reportTooManyCollisions(int maxLen) throws StreamConstraintsException {
/* 787 */     throw new StreamConstraintsException("Longest collision chain in symbol table (of size " + this._size + ") now exceeds maximum, " + maxLen + " -- suspect a DoS attack based on hash collisions");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void verifyInternalConsistency() {
/* 799 */     int count = 0;
/* 800 */     int size = this._symbols.length;
/*     */     
/* 802 */     for (int i = 0; i < size; i++) {
/* 803 */       String symbol = this._symbols[i];
/* 804 */       if (symbol != null) {
/* 805 */         count++;
/*     */       }
/*     */     } 
/*     */     
/* 809 */     int bucketSize = size >> 1;
/* 810 */     for (int j = 0; j < bucketSize; j++) {
/* 811 */       for (Bucket b = this._buckets[j]; b != null; b = b.next) {
/* 812 */         count++;
/*     */       }
/*     */     } 
/* 815 */     if (count != this._size) {
/* 816 */       throw new IllegalStateException(
/* 817 */           String.format("Internal error: expected internal size %d vs calculated count %d", new Object[] {
/* 818 */               Integer.valueOf(this._size), Integer.valueOf(count)
/*     */             }));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class Bucket
/*     */   {
/*     */     public final String symbol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final Bucket next;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int length;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Bucket(String s, Bucket n) {
/* 888 */       this.symbol = s;
/* 889 */       this.next = n;
/* 890 */       this.length = (n == null) ? 1 : (n.length + 1);
/*     */     }
/*     */     
/*     */     public String has(char[] buf, int start, int len) {
/* 894 */       if (this.symbol.length() != len) {
/* 895 */         return null;
/*     */       }
/* 897 */       int i = 0;
/*     */       while (true) {
/* 899 */         if (this.symbol.charAt(i) != buf[start + i]) {
/* 900 */           return null;
/*     */         }
/* 902 */         if (++i >= len) {
/* 903 */           return this.symbol;
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class TableInfo
/*     */   {
/*     */     final int size;
/*     */ 
/*     */     
/*     */     final int longestCollisionList;
/*     */     
/*     */     final String[] symbols;
/*     */     
/*     */     final CharsToNameCanonicalizer.Bucket[] buckets;
/*     */ 
/*     */     
/*     */     public TableInfo(int size, int longestCollisionList, String[] symbols, CharsToNameCanonicalizer.Bucket[] buckets) {
/* 924 */       this.size = size;
/* 925 */       this.longestCollisionList = longestCollisionList;
/* 926 */       this.symbols = symbols;
/* 927 */       this.buckets = buckets;
/*     */     }
/*     */ 
/*     */     
/*     */     public TableInfo(CharsToNameCanonicalizer src) {
/* 932 */       this.size = src._size;
/* 933 */       this.longestCollisionList = src._longestCollisionList;
/* 934 */       this.symbols = src._symbols;
/* 935 */       this.buckets = src._buckets;
/*     */     }
/*     */     
/*     */     public static TableInfo createInitial(int sz) {
/* 939 */       return new TableInfo(0, 0, new String[sz], new CharsToNameCanonicalizer.Bucket[sz >> 1]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\sym\CharsToNameCanonicalizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */