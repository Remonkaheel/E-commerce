/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonProcessingException
/*     */   extends JacksonException
/*     */ {
/*     */   private static final long serialVersionUID = 123L;
/*     */   protected JsonLocation _location;
/*     */   
/*     */   protected JsonProcessingException(String msg, JsonLocation loc, Throwable rootCause) {
/*  27 */     super(msg, rootCause);
/*  28 */     this._location = loc;
/*     */   }
/*     */   
/*     */   protected JsonProcessingException(String msg) {
/*  32 */     super(msg);
/*     */   }
/*     */   
/*     */   protected JsonProcessingException(String msg, JsonLocation loc) {
/*  36 */     this(msg, loc, null);
/*     */   }
/*     */   
/*     */   protected JsonProcessingException(String msg, Throwable rootCause) {
/*  40 */     this(msg, null, rootCause);
/*     */   }
/*     */   
/*     */   protected JsonProcessingException(Throwable rootCause) {
/*  44 */     this(null, null, rootCause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonLocation getLocation() {
/*  54 */     return this._location;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearLocation() {
/*  63 */     this._location = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOriginalMessage() {
/*  75 */     return super.getMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getProcessor() {
/*  92 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getMessageSuffix() {
/* 107 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 122 */     String msg = super.getMessage();
/* 123 */     if (msg == null) {
/* 124 */       msg = "N/A";
/*     */     }
/* 126 */     JsonLocation loc = getLocation();
/* 127 */     String suffix = getMessageSuffix();
/*     */     
/* 129 */     if (loc != null || suffix != null) {
/* 130 */       StringBuilder sb = new StringBuilder(100);
/* 131 */       sb.append(msg);
/* 132 */       if (suffix != null) {
/* 133 */         sb.append(suffix);
/*     */       }
/* 135 */       if (loc != null) {
/* 136 */         sb.append('\n');
/* 137 */         sb.append(" at ");
/* 138 */         sb.append(loc.toString());
/*     */       } 
/* 140 */       msg = sb.toString();
/*     */     } 
/* 142 */     return msg;
/*     */   }
/*     */   public String toString() {
/* 145 */     return getClass().getName() + ": " + getMessage();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\JsonProcessingException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */