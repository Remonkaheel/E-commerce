/*     */ package com.fasterxml.jackson.core.filter;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonGenerator;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.JsonStreamContext;
/*     */ import com.fasterxml.jackson.core.JsonToken;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenFilterContext
/*     */   extends JsonStreamContext
/*     */ {
/*     */   protected final TokenFilterContext _parent;
/*     */   protected TokenFilterContext _child;
/*     */   protected String _currentName;
/*     */   protected TokenFilter _filter;
/*     */   protected boolean _startHandled;
/*     */   protected boolean _needToHandleName;
/*     */   
/*     */   protected TokenFilterContext(int type, TokenFilterContext parent, TokenFilter filter, boolean startHandled) {
/*  72 */     this._type = type;
/*  73 */     this._parent = parent;
/*  74 */     this._nestingDepth = (parent == null) ? 0 : (parent._nestingDepth + 1);
/*  75 */     this._filter = filter;
/*  76 */     this._index = -1;
/*  77 */     this._startHandled = startHandled;
/*  78 */     this._needToHandleName = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected TokenFilterContext reset(int type, TokenFilter filter, boolean startWritten) {
/*  84 */     this._type = type;
/*  85 */     this._filter = filter;
/*  86 */     this._index = -1;
/*  87 */     this._currentName = null;
/*  88 */     this._startHandled = startWritten;
/*  89 */     this._needToHandleName = false;
/*  90 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static TokenFilterContext createRootContext(TokenFilter filter) {
/* 101 */     return new TokenFilterContext(0, null, filter, true);
/*     */   }
/*     */   
/*     */   public TokenFilterContext createChildArrayContext(TokenFilter filter, boolean writeStart) {
/* 105 */     TokenFilterContext ctxt = this._child;
/* 106 */     if (ctxt == null) {
/* 107 */       this._child = ctxt = new TokenFilterContext(1, this, filter, writeStart);
/* 108 */       return ctxt;
/*     */     } 
/* 110 */     return ctxt.reset(1, filter, writeStart);
/*     */   }
/*     */   
/*     */   public TokenFilterContext createChildObjectContext(TokenFilter filter, boolean writeStart) {
/* 114 */     TokenFilterContext ctxt = this._child;
/* 115 */     if (ctxt == null) {
/* 116 */       this._child = ctxt = new TokenFilterContext(2, this, filter, writeStart);
/* 117 */       return ctxt;
/*     */     } 
/* 119 */     return ctxt.reset(2, filter, writeStart);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenFilter setFieldName(String name) throws JsonProcessingException {
/* 129 */     this._currentName = name;
/* 130 */     this._needToHandleName = true;
/* 131 */     return this._filter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenFilter checkValue(TokenFilter filter) {
/* 144 */     if (this._type == 2) {
/* 145 */       return filter;
/*     */     }
/*     */     
/* 148 */     int ix = ++this._index;
/* 149 */     if (this._type == 1) {
/* 150 */       return filter.includeElement(ix);
/*     */     }
/* 152 */     return filter.includeRootValue(ix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ensureFieldNameWritten(JsonGenerator gen) throws IOException {
/* 166 */     if (this._needToHandleName) {
/* 167 */       this._needToHandleName = false;
/* 168 */       gen.writeFieldName(this._currentName);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writePath(JsonGenerator gen) throws IOException {
/* 183 */     if (this._filter == null || this._filter == TokenFilter.INCLUDE_ALL) {
/*     */       return;
/*     */     }
/* 186 */     if (this._parent != null) {
/* 187 */       this._parent._writePath(gen);
/*     */     }
/* 189 */     if (this._startHandled) {
/*     */       
/* 191 */       if (this._needToHandleName) {
/* 192 */         gen.writeFieldName(this._currentName);
/*     */       }
/*     */     } else {
/* 195 */       this._startHandled = true;
/* 196 */       if (this._type == 2) {
/* 197 */         gen.writeStartObject();
/* 198 */         gen.writeFieldName(this._currentName);
/* 199 */       } else if (this._type == 1) {
/* 200 */         gen.writeStartArray();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void _writePath(JsonGenerator gen) throws IOException {
/* 207 */     if (this._filter == null || this._filter == TokenFilter.INCLUDE_ALL) {
/*     */       return;
/*     */     }
/* 210 */     if (this._parent != null) {
/* 211 */       this._parent._writePath(gen);
/*     */     }
/* 213 */     if (this._startHandled) {
/*     */       
/* 215 */       if (this._needToHandleName) {
/* 216 */         this._needToHandleName = false;
/* 217 */         gen.writeFieldName(this._currentName);
/*     */       } 
/*     */     } else {
/* 220 */       this._startHandled = true;
/* 221 */       if (this._type == 2) {
/* 222 */         gen.writeStartObject();
/* 223 */         if (this._needToHandleName) {
/* 224 */           this._needToHandleName = false;
/* 225 */           gen.writeFieldName(this._currentName);
/*     */         } 
/* 227 */       } else if (this._type == 1) {
/* 228 */         gen.writeStartArray();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenFilterContext closeArray(JsonGenerator gen) throws IOException {
/* 235 */     if (this._startHandled) {
/* 236 */       gen.writeEndArray();
/*     */     }
/* 238 */     else if (this._filter != null && this._filter != TokenFilter.INCLUDE_ALL && 
/* 239 */       this._filter.includeEmptyArray(hasCurrentIndex())) {
/* 240 */       if (this._parent != null) {
/* 241 */         this._parent._writePath(gen);
/*     */       }
/* 243 */       gen.writeStartArray();
/* 244 */       gen.writeEndArray();
/*     */     } 
/*     */ 
/*     */     
/* 248 */     if (this._filter != null && this._filter != TokenFilter.INCLUDE_ALL) {
/* 249 */       this._filter.filterFinishArray();
/*     */     }
/* 251 */     return this._parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenFilterContext closeObject(JsonGenerator gen) throws IOException {
/* 256 */     if (this._startHandled) {
/* 257 */       gen.writeEndObject();
/*     */     }
/* 259 */     else if (this._filter != null && this._filter != TokenFilter.INCLUDE_ALL && 
/* 260 */       this._filter.includeEmptyObject(hasCurrentName())) {
/* 261 */       if (this._parent != null) {
/* 262 */         this._parent._writePath(gen);
/*     */       }
/* 264 */       gen.writeStartObject();
/* 265 */       gen.writeEndObject();
/*     */     } 
/*     */ 
/*     */     
/* 269 */     if (this._filter != null && this._filter != TokenFilter.INCLUDE_ALL) {
/* 270 */       this._filter.filterFinishObject();
/*     */     }
/* 272 */     return this._parent;
/*     */   }
/*     */   
/*     */   public void skipParentChecks() {
/* 276 */     this._filter = null;
/* 277 */     for (TokenFilterContext ctxt = this._parent; ctxt != null; ctxt = ctxt._parent) {
/* 278 */       ctxt._filter = null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getCurrentValue() {
/* 289 */     return null;
/*     */   }
/*     */   
/*     */   public void setCurrentValue(Object v) {}
/*     */   
/* 294 */   public final TokenFilterContext getParent() { return this._parent; } public final String getCurrentName() {
/* 295 */     return this._currentName;
/*     */   } public boolean hasCurrentName() {
/* 297 */     return (this._currentName != null);
/*     */   }
/* 299 */   public TokenFilter getFilter() { return this._filter; } public boolean isStartHandled() {
/* 300 */     return this._startHandled;
/*     */   }
/*     */   public JsonToken nextTokenToRead() {
/* 303 */     if (!this._startHandled) {
/* 304 */       this._startHandled = true;
/* 305 */       if (this._type == 2) {
/* 306 */         return JsonToken.START_OBJECT;
/*     */       }
/*     */       
/* 309 */       return JsonToken.START_ARRAY;
/*     */     } 
/*     */     
/* 312 */     if (this._needToHandleName && this._type == 2) {
/* 313 */       this._needToHandleName = false;
/* 314 */       return JsonToken.FIELD_NAME;
/*     */     } 
/* 316 */     return null;
/*     */   }
/*     */   
/*     */   public TokenFilterContext findChildOf(TokenFilterContext parent) {
/* 320 */     if (this._parent == parent) {
/* 321 */       return this;
/*     */     }
/* 323 */     TokenFilterContext curr = this._parent;
/* 324 */     while (curr != null) {
/* 325 */       TokenFilterContext p = curr._parent;
/* 326 */       if (p == parent) {
/* 327 */         return curr;
/*     */       }
/* 329 */       curr = p;
/*     */     } 
/*     */     
/* 332 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void appendDesc(StringBuilder sb) {
/* 338 */     if (this._parent != null) {
/* 339 */       this._parent.appendDesc(sb);
/*     */     }
/* 341 */     if (this._type == 2) {
/* 342 */       sb.append('{');
/* 343 */       if (this._currentName != null) {
/* 344 */         sb.append('"');
/*     */         
/* 346 */         sb.append(this._currentName);
/* 347 */         sb.append('"');
/*     */       } else {
/* 349 */         sb.append('?');
/*     */       } 
/* 351 */       sb.append('}');
/* 352 */     } else if (this._type == 1) {
/* 353 */       sb.append('[');
/* 354 */       sb.append(getCurrentIndex());
/* 355 */       sb.append(']');
/*     */     } else {
/*     */       
/* 358 */       sb.append("/");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 367 */     StringBuilder sb = new StringBuilder(64);
/* 368 */     appendDesc(sb);
/* 369 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\filter\TokenFilterContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */