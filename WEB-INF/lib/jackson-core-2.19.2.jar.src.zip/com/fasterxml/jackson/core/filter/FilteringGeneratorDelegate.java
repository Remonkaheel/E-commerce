/*      */ package com.fasterxml.jackson.core.filter;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.SerializableString;
/*      */ import com.fasterxml.jackson.core.util.JsonGeneratorDelegate;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FilteringGeneratorDelegate
/*      */   extends JsonGeneratorDelegate
/*      */ {
/*      */   protected TokenFilter rootFilter;
/*      */   protected boolean _allowMultipleMatches;
/*      */   protected TokenFilter.Inclusion _inclusion;
/*      */   protected TokenFilterContext _filterContext;
/*      */   protected TokenFilter _itemFilter;
/*      */   protected int _matchCount;
/*      */   
/*      */   @Deprecated
/*      */   public FilteringGeneratorDelegate(JsonGenerator d, TokenFilter f, boolean includePath, boolean allowMultipleMatches) {
/*   97 */     this(d, f, includePath ? TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH : TokenFilter.Inclusion.ONLY_INCLUDE_ALL, allowMultipleMatches);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FilteringGeneratorDelegate(JsonGenerator d, TokenFilter f, TokenFilter.Inclusion inclusion, boolean allowMultipleMatches) {
/*  112 */     super(d, false);
/*  113 */     this.rootFilter = f;
/*      */     
/*  115 */     this._itemFilter = f;
/*  116 */     this._filterContext = TokenFilterContext.createRootContext(f);
/*  117 */     this._inclusion = inclusion;
/*  118 */     this._allowMultipleMatches = allowMultipleMatches;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenFilter getFilter() {
/*  127 */     return this.rootFilter;
/*      */   }
/*      */   public JsonStreamContext getFilterContext() {
/*  130 */     return this._filterContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMatchCount() {
/*  140 */     return this._matchCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonStreamContext getOutputContext() {
/*  155 */     return this._filterContext;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray() throws IOException {
/*  168 */     if (this._itemFilter == null) {
/*  169 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*      */       return;
/*      */     } 
/*  172 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  173 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  174 */       this.delegate.writeStartArray();
/*      */       
/*      */       return;
/*      */     } 
/*  178 */     this._itemFilter = this._filterContext.checkValue(this._itemFilter);
/*  179 */     if (this._itemFilter == null) {
/*  180 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*      */       return;
/*      */     } 
/*  183 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  184 */       this._itemFilter = this._itemFilter.filterStartArray();
/*      */     }
/*  186 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  187 */       _checkParentPath();
/*  188 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  189 */       this.delegate.writeStartArray();
/*  190 */     } else if (this._itemFilter != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*  191 */       _checkParentPath(false);
/*  192 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  193 */       this.delegate.writeStartArray();
/*      */     } else {
/*  195 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray(int size) throws IOException {
/*  203 */     if (this._itemFilter == null) {
/*  204 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*      */       return;
/*      */     } 
/*  207 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  208 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  209 */       this.delegate.writeStartArray(size);
/*      */       return;
/*      */     } 
/*  212 */     this._itemFilter = this._filterContext.checkValue(this._itemFilter);
/*  213 */     if (this._itemFilter == null) {
/*  214 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*      */       return;
/*      */     } 
/*  217 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  218 */       this._itemFilter = this._itemFilter.filterStartArray();
/*      */     }
/*  220 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  221 */       _checkParentPath();
/*  222 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  223 */       this.delegate.writeStartArray(size);
/*  224 */     } else if (this._itemFilter != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*  225 */       _checkParentPath(false);
/*  226 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  227 */       this.delegate.writeStartArray(size);
/*      */     } else {
/*  229 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object forValue) throws IOException {
/*  236 */     if (this._itemFilter == null) {
/*  237 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*      */       return;
/*      */     } 
/*  240 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  241 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  242 */       this.delegate.writeStartArray(forValue);
/*      */       return;
/*      */     } 
/*  245 */     this._itemFilter = this._filterContext.checkValue(this._itemFilter);
/*  246 */     if (this._itemFilter == null) {
/*  247 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*      */       return;
/*      */     } 
/*  250 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  251 */       this._itemFilter = this._itemFilter.filterStartArray();
/*      */     }
/*  253 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  254 */       _checkParentPath();
/*  255 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  256 */       this.delegate.writeStartArray(forValue);
/*  257 */     } else if (this._itemFilter != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*  258 */       _checkParentPath(false);
/*  259 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  260 */       this.delegate.writeStartArray(forValue);
/*      */     } else {
/*  262 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object forValue, int size) throws IOException {
/*  269 */     if (this._itemFilter == null) {
/*  270 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*      */       return;
/*      */     } 
/*  273 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  274 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  275 */       this.delegate.writeStartArray(forValue, size);
/*      */       return;
/*      */     } 
/*  278 */     this._itemFilter = this._filterContext.checkValue(this._itemFilter);
/*  279 */     if (this._itemFilter == null) {
/*  280 */       this._filterContext = this._filterContext.createChildArrayContext(null, false);
/*      */       return;
/*      */     } 
/*  283 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  284 */       this._itemFilter = this._itemFilter.filterStartArray();
/*      */     }
/*  286 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  287 */       _checkParentPath();
/*  288 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  289 */       this.delegate.writeStartArray(forValue, size);
/*  290 */     } else if (this._itemFilter != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*  291 */       _checkParentPath(false);
/*  292 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, true);
/*  293 */       this.delegate.writeStartArray(forValue, size);
/*      */     } else {
/*  295 */       this._filterContext = this._filterContext.createChildArrayContext(this._itemFilter, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeEndArray() throws IOException {
/*  302 */     this._filterContext = this._filterContext.closeArray(this.delegate);
/*      */     
/*  304 */     if (this._filterContext != null) {
/*  305 */       this._itemFilter = this._filterContext.getFilter();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject() throws IOException {
/*  312 */     if (this._itemFilter == null) {
/*  313 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, false);
/*      */       return;
/*      */     } 
/*  316 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  317 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, true);
/*  318 */       this.delegate.writeStartObject();
/*      */       
/*      */       return;
/*      */     } 
/*  322 */     TokenFilter f = this._filterContext.checkValue(this._itemFilter);
/*  323 */     if (f == null) {
/*  324 */       this._filterContext = this._filterContext.createChildObjectContext(null, false);
/*      */       
/*      */       return;
/*      */     } 
/*  328 */     if (f != TokenFilter.INCLUDE_ALL) {
/*  329 */       f = f.filterStartObject();
/*      */     }
/*  331 */     if (f == TokenFilter.INCLUDE_ALL) {
/*  332 */       _checkParentPath();
/*  333 */       this._filterContext = this._filterContext.createChildObjectContext(f, true);
/*  334 */       this.delegate.writeStartObject();
/*  335 */     } else if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*  336 */       _checkParentPath(false);
/*  337 */       this._filterContext = this._filterContext.createChildObjectContext(f, true);
/*  338 */       this.delegate.writeStartObject();
/*      */     } else {
/*  340 */       this._filterContext = this._filterContext.createChildObjectContext(f, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue) throws IOException {
/*  347 */     if (this._itemFilter == null) {
/*  348 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, false);
/*      */       return;
/*      */     } 
/*  351 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  352 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, true);
/*  353 */       this.delegate.writeStartObject(forValue);
/*      */       
/*      */       return;
/*      */     } 
/*  357 */     TokenFilter f = this._filterContext.checkValue(this._itemFilter);
/*  358 */     if (f == null) {
/*  359 */       this._filterContext = this._filterContext.createChildObjectContext(null, false);
/*      */       
/*      */       return;
/*      */     } 
/*  363 */     if (f != TokenFilter.INCLUDE_ALL) {
/*  364 */       f = f.filterStartObject();
/*      */     }
/*  366 */     if (f == TokenFilter.INCLUDE_ALL) {
/*  367 */       _checkParentPath();
/*  368 */       this._filterContext = this._filterContext.createChildObjectContext(f, true);
/*  369 */       this.delegate.writeStartObject(forValue);
/*  370 */     } else if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*  371 */       _checkParentPath(false);
/*  372 */       this._filterContext = this._filterContext.createChildObjectContext(f, true);
/*  373 */       this.delegate.writeStartObject(forValue);
/*      */     } else {
/*  375 */       this._filterContext = this._filterContext.createChildObjectContext(f, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue, int size) throws IOException {
/*  382 */     if (this._itemFilter == null) {
/*  383 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, false);
/*      */       return;
/*      */     } 
/*  386 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/*  387 */       this._filterContext = this._filterContext.createChildObjectContext(this._itemFilter, true);
/*  388 */       this.delegate.writeStartObject(forValue, size);
/*      */       
/*      */       return;
/*      */     } 
/*  392 */     TokenFilter f = this._filterContext.checkValue(this._itemFilter);
/*  393 */     if (f == null) {
/*  394 */       this._filterContext = this._filterContext.createChildObjectContext(null, false);
/*      */       
/*      */       return;
/*      */     } 
/*  398 */     if (f != TokenFilter.INCLUDE_ALL) {
/*  399 */       f = f.filterStartObject();
/*      */     }
/*  401 */     if (f == TokenFilter.INCLUDE_ALL) {
/*  402 */       _checkParentPath();
/*  403 */       this._filterContext = this._filterContext.createChildObjectContext(f, true);
/*  404 */       this.delegate.writeStartObject(forValue, size);
/*      */     } else {
/*  406 */       this._filterContext = this._filterContext.createChildObjectContext(f, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeEndObject() throws IOException {
/*  413 */     this._filterContext = this._filterContext.closeObject(this.delegate);
/*  414 */     if (this._filterContext != null) {
/*  415 */       this._itemFilter = this._filterContext.getFilter();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldName(String name) throws IOException {
/*  422 */     TokenFilter state = this._filterContext.setFieldName(name);
/*  423 */     if (state == null) {
/*  424 */       this._itemFilter = null;
/*      */       return;
/*      */     } 
/*  427 */     if (state == TokenFilter.INCLUDE_ALL) {
/*  428 */       this._itemFilter = state;
/*  429 */       this.delegate.writeFieldName(name);
/*      */       return;
/*      */     } 
/*  432 */     state = state.includeProperty(name);
/*  433 */     this._itemFilter = state;
/*  434 */     if (state == TokenFilter.INCLUDE_ALL) {
/*  435 */       _checkPropertyParentPath();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldName(SerializableString name) throws IOException {
/*  442 */     TokenFilter state = this._filterContext.setFieldName(name.getValue());
/*  443 */     if (state == null) {
/*  444 */       this._itemFilter = null;
/*      */       return;
/*      */     } 
/*  447 */     if (state == TokenFilter.INCLUDE_ALL) {
/*  448 */       this._itemFilter = state;
/*  449 */       this.delegate.writeFieldName(name);
/*      */       return;
/*      */     } 
/*  452 */     state = state.includeProperty(name.getValue());
/*  453 */     this._itemFilter = state;
/*  454 */     if (state == TokenFilter.INCLUDE_ALL) {
/*  455 */       _checkPropertyParentPath();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldId(long id) throws IOException {
/*  462 */     writeFieldName(Long.toString(id));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(String value) throws IOException {
/*  474 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  477 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  478 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  479 */       if (state == null) {
/*      */         return;
/*      */       }
/*  482 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  483 */         !state.includeString(value)) {
/*      */         return;
/*      */       }
/*      */       
/*  487 */       _checkParentPath();
/*      */     } 
/*  489 */     this.delegate.writeString(value);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(char[] text, int offset, int len) throws IOException {
/*  495 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  498 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  499 */       String value = new String(text, offset, len);
/*  500 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  501 */       if (state == null) {
/*      */         return;
/*      */       }
/*  504 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  505 */         !state.includeString(value)) {
/*      */         return;
/*      */       }
/*      */       
/*  509 */       _checkParentPath();
/*      */     } 
/*  511 */     this.delegate.writeString(text, offset, len);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(SerializableString value) throws IOException {
/*  517 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  520 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  521 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  522 */       if (state == null) {
/*      */         return;
/*      */       }
/*  525 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  526 */         !state.includeString(value.getValue())) {
/*      */         return;
/*      */       }
/*      */       
/*  530 */       _checkParentPath();
/*      */     } 
/*  532 */     this.delegate.writeString(value);
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeString(Reader reader, int len) throws IOException {
/*  537 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  540 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  541 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  542 */       if (state == null) {
/*      */         return;
/*      */       }
/*  545 */       if (state != TokenFilter.INCLUDE_ALL)
/*      */       {
/*      */         
/*  548 */         if (!state.includeString(reader, len)) {
/*      */           return;
/*      */         }
/*      */       }
/*  552 */       _checkParentPath();
/*      */     } 
/*  554 */     this.delegate.writeString(reader, len);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawUTF8String(byte[] text, int offset, int length) throws IOException {
/*  560 */     if (_checkRawValueWrite()) {
/*  561 */       this.delegate.writeRawUTF8String(text, offset, length);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeUTF8String(byte[] text, int offset, int length) throws IOException {
/*  569 */     if (_checkRawValueWrite()) {
/*  570 */       this.delegate.writeUTF8String(text, offset, length);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(String text) throws IOException {
/*  583 */     if (_checkRawValueWrite()) {
/*  584 */       this.delegate.writeRaw(text);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(String text, int offset, int len) throws IOException {
/*  591 */     if (_checkRawValueWrite()) {
/*  592 */       this.delegate.writeRaw(text, offset, len);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(SerializableString text) throws IOException {
/*  599 */     if (_checkRawValueWrite()) {
/*  600 */       this.delegate.writeRaw(text);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(char[] text, int offset, int len) throws IOException {
/*  607 */     if (_checkRawValueWrite()) {
/*  608 */       this.delegate.writeRaw(text, offset, len);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(char c) throws IOException {
/*  615 */     if (_checkRawValueWrite()) {
/*  616 */       this.delegate.writeRaw(c);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawValue(String text) throws IOException {
/*  623 */     if (_checkRawValueWrite()) {
/*  624 */       this.delegate.writeRawValue(text);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawValue(String text, int offset, int len) throws IOException {
/*  631 */     if (_checkRawValueWrite()) {
/*  632 */       this.delegate.writeRawValue(text, offset, len);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawValue(char[] text, int offset, int len) throws IOException {
/*  639 */     if (_checkRawValueWrite()) {
/*  640 */       this.delegate.writeRawValue(text, offset, len);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBinary(Base64Variant b64variant, byte[] data, int offset, int len) throws IOException {
/*  647 */     if (_checkBinaryWrite()) {
/*  648 */       this.delegate.writeBinary(b64variant, data, offset, len);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int writeBinary(Base64Variant b64variant, InputStream data, int dataLength) throws IOException {
/*  655 */     if (_checkBinaryWrite()) {
/*  656 */       return this.delegate.writeBinary(b64variant, data, dataLength);
/*      */     }
/*  658 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(short v) throws IOException {
/*  670 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  673 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  674 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  675 */       if (state == null) {
/*      */         return;
/*      */       }
/*  678 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  679 */         !state.includeNumber(v)) {
/*      */         return;
/*      */       }
/*      */       
/*  683 */       _checkParentPath();
/*      */     } 
/*  685 */     this.delegate.writeNumber(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(int v) throws IOException {
/*  691 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  694 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  695 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  696 */       if (state == null) {
/*      */         return;
/*      */       }
/*  699 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  700 */         !state.includeNumber(v)) {
/*      */         return;
/*      */       }
/*      */       
/*  704 */       _checkParentPath();
/*      */     } 
/*  706 */     this.delegate.writeNumber(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(long v) throws IOException {
/*  712 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  715 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  716 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  717 */       if (state == null) {
/*      */         return;
/*      */       }
/*  720 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  721 */         !state.includeNumber(v)) {
/*      */         return;
/*      */       }
/*      */       
/*  725 */       _checkParentPath();
/*      */     } 
/*  727 */     this.delegate.writeNumber(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(BigInteger v) throws IOException {
/*  733 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  736 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  737 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  738 */       if (state == null) {
/*      */         return;
/*      */       }
/*  741 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  742 */         !state.includeNumber(v)) {
/*      */         return;
/*      */       }
/*      */       
/*  746 */       _checkParentPath();
/*      */     } 
/*  748 */     this.delegate.writeNumber(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(double v) throws IOException {
/*  754 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  757 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  758 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  759 */       if (state == null) {
/*      */         return;
/*      */       }
/*  762 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  763 */         !state.includeNumber(v)) {
/*      */         return;
/*      */       }
/*      */       
/*  767 */       _checkParentPath();
/*      */     } 
/*  769 */     this.delegate.writeNumber(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(float v) throws IOException {
/*  775 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  778 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  779 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  780 */       if (state == null) {
/*      */         return;
/*      */       }
/*  783 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  784 */         !state.includeNumber(v)) {
/*      */         return;
/*      */       }
/*      */       
/*  788 */       _checkParentPath();
/*      */     } 
/*  790 */     this.delegate.writeNumber(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(BigDecimal v) throws IOException {
/*  796 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  799 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  800 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  801 */       if (state == null) {
/*      */         return;
/*      */       }
/*  804 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  805 */         !state.includeNumber(v)) {
/*      */         return;
/*      */       }
/*      */       
/*  809 */       _checkParentPath();
/*      */     } 
/*  811 */     this.delegate.writeNumber(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(String encodedValue) throws IOException, UnsupportedOperationException {
/*  817 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  820 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  821 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  822 */       if (state == null) {
/*      */         return;
/*      */       }
/*  825 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  826 */         !state.includeRawValue()) {
/*      */         return;
/*      */       }
/*      */       
/*  830 */       _checkParentPath();
/*      */     } 
/*  832 */     this.delegate.writeNumber(encodedValue);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(char[] encodedValueBuffer, int offset, int length) throws IOException, UnsupportedOperationException {
/*  838 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  841 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  842 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  843 */       if (state == null) {
/*      */         return;
/*      */       }
/*  846 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  847 */         !state.includeRawValue()) {
/*      */         return;
/*      */       }
/*      */       
/*  851 */       _checkParentPath();
/*      */     } 
/*  853 */     this.delegate.writeNumber(encodedValueBuffer, offset, length);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBoolean(boolean v) throws IOException {
/*  859 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  862 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  863 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  864 */       if (state == null) {
/*      */         return;
/*      */       }
/*  867 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  868 */         !state.includeBoolean(v)) {
/*      */         return;
/*      */       }
/*      */       
/*  872 */       _checkParentPath();
/*      */     } 
/*  874 */     this.delegate.writeBoolean(v);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNull() throws IOException {
/*  880 */     if (this._itemFilter == null) {
/*      */       return;
/*      */     }
/*  883 */     if (this._itemFilter != TokenFilter.INCLUDE_ALL) {
/*  884 */       TokenFilter state = this._filterContext.checkValue(this._itemFilter);
/*  885 */       if (state == null) {
/*      */         return;
/*      */       }
/*  888 */       if (state != TokenFilter.INCLUDE_ALL && 
/*  889 */         !state.includeNull()) {
/*      */         return;
/*      */       }
/*      */       
/*  893 */       _checkParentPath();
/*      */     } 
/*  895 */     this.delegate.writeNull();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeOmittedField(String fieldName) throws IOException {
/*  907 */     if (this._itemFilter != null) {
/*  908 */       this.delegate.writeOmittedField(fieldName);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeObjectId(Object id) throws IOException {
/*  923 */     if (this._itemFilter != null) {
/*  924 */       this.delegate.writeObjectId(id);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeObjectRef(Object id) throws IOException {
/*  930 */     if (this._itemFilter != null) {
/*  931 */       this.delegate.writeObjectRef(id);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void writeTypeId(Object id) throws IOException {
/*  937 */     if (this._itemFilter != null) {
/*  938 */       this.delegate.writeTypeId(id);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _checkParentPath() throws IOException {
/* 1017 */     _checkParentPath(true);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _checkParentPath(boolean isMatch) throws IOException {
/* 1022 */     if (isMatch) {
/* 1023 */       this._matchCount++;
/*      */     }
/*      */     
/* 1026 */     if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/* 1027 */       this._filterContext.writePath(this.delegate);
/* 1028 */     } else if (this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*      */       
/* 1030 */       this._filterContext.ensureFieldNameWritten(this.delegate);
/*      */     } 
/*      */     
/* 1033 */     if (isMatch && !this._allowMultipleMatches)
/*      */     {
/* 1035 */       this._filterContext.skipParentChecks();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _checkPropertyParentPath() throws IOException {
/* 1048 */     this._matchCount++;
/* 1049 */     if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/* 1050 */       this._filterContext.writePath(this.delegate);
/* 1051 */     } else if (this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*      */       
/* 1053 */       this._filterContext.ensureFieldNameWritten(this.delegate);
/*      */     } 
/*      */ 
/*      */     
/* 1057 */     if (!this._allowMultipleMatches)
/*      */     {
/* 1059 */       this._filterContext.skipParentChecks();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean _checkBinaryWrite() throws IOException {
/* 1065 */     if (this._itemFilter == null) {
/* 1066 */       return false;
/*      */     }
/* 1068 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/* 1069 */       return true;
/*      */     }
/* 1071 */     if (this._itemFilter.includeBinary()) {
/* 1072 */       _checkParentPath();
/* 1073 */       return true;
/*      */     } 
/* 1075 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean _checkRawValueWrite() throws IOException {
/* 1080 */     if (this._itemFilter == null) {
/* 1081 */       return false;
/*      */     }
/* 1083 */     if (this._itemFilter == TokenFilter.INCLUDE_ALL) {
/* 1084 */       return true;
/*      */     }
/* 1086 */     if (this._itemFilter.includeRawValue()) {
/* 1087 */       _checkParentPath();
/* 1088 */       return true;
/*      */     } 
/* 1090 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\filter\FilteringGeneratorDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */