/*      */ package com.fasterxml.jackson.core.filter;
/*      */ 
/*      */ import com.fasterxml.jackson.core.Base64Variant;
/*      */ import com.fasterxml.jackson.core.JsonLocation;
/*      */ import com.fasterxml.jackson.core.JsonParser;
/*      */ import com.fasterxml.jackson.core.JsonStreamContext;
/*      */ import com.fasterxml.jackson.core.JsonToken;
/*      */ import com.fasterxml.jackson.core.util.JsonParserDelegate;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FilteringParserDelegate
/*      */   extends JsonParserDelegate
/*      */ {
/*      */   protected TokenFilter rootFilter;
/*      */   protected boolean _allowMultipleMatches;
/*      */   protected TokenFilter.Inclusion _inclusion;
/*      */   protected JsonToken _currToken;
/*      */   protected JsonToken _lastClearedToken;
/*      */   protected TokenFilterContext _headContext;
/*      */   protected TokenFilterContext _exposedContext;
/*      */   protected TokenFilter _itemFilter;
/*      */   protected int _matchCount;
/*      */   
/*      */   @Deprecated
/*      */   public FilteringParserDelegate(JsonParser p, TokenFilter f, boolean includePath, boolean allowMultipleMatches) {
/*  108 */     this(p, f, includePath ? TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH : TokenFilter.Inclusion.ONLY_INCLUDE_ALL, allowMultipleMatches);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FilteringParserDelegate(JsonParser p, TokenFilter f, TokenFilter.Inclusion inclusion, boolean allowMultipleMatches) {
/*  126 */     super(p);
/*      */     
/*  128 */     _checkAsyncParser(p);
/*      */     
/*  130 */     initializeFilters(f, inclusion, allowMultipleMatches);
/*      */   }
/*      */   
/*      */   private static void _checkAsyncParser(JsonParser p) throws IllegalArgumentException {
/*  134 */     if (p.canParseAsync()) {
/*  135 */       throw new IllegalArgumentException(
/*  136 */           String.format("%s is an asynchronous parser (canParseAsync() == true), which requires explicit permission to be used: to allow use, call constructor with `allowNonBlockingParser` passed as `true`", new Object[] {
/*      */ 
/*      */ 
/*      */               
/*  140 */               p.getClass().getSimpleName()
/*      */             }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FilteringParserDelegate(JsonParser p, TokenFilter f, TokenFilter.Inclusion inclusion, boolean allowMultipleMatches, boolean allowNonBlockingParser) {
/*  161 */     super(p);
/*      */     
/*  163 */     if (!allowNonBlockingParser) {
/*  164 */       _checkAsyncParser(p);
/*      */     }
/*      */     
/*  167 */     initializeFilters(f, inclusion, allowMultipleMatches);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeFilters(TokenFilter f, TokenFilter.Inclusion inclusion, boolean allowMultipleMatches) {
/*  178 */     this.rootFilter = f;
/*  179 */     this._itemFilter = f;
/*  180 */     this._headContext = TokenFilterContext.createRootContext(f);
/*  181 */     this._inclusion = inclusion;
/*  182 */     this._allowMultipleMatches = allowMultipleMatches;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TokenFilter getFilter() {
/*  191 */     return this.rootFilter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMatchCount() {
/*  200 */     return this._matchCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken currentToken() {
/*  209 */     return this._currToken;
/*      */   }
/*      */   @Deprecated
/*      */   public JsonToken getCurrentToken() {
/*  213 */     return this._currToken;
/*      */   }
/*      */   public final int currentTokenId() {
/*  216 */     JsonToken t = this._currToken;
/*  217 */     return (t == null) ? 0 : t.id();
/*      */   }
/*      */   @Deprecated
/*      */   public final int getCurrentTokenId() {
/*  221 */     return currentTokenId();
/*      */   }
/*      */   public boolean hasCurrentToken() {
/*  224 */     return (this._currToken != null);
/*      */   } public boolean hasTokenId(int id) {
/*  226 */     JsonToken t = this._currToken;
/*  227 */     if (t == null) {
/*  228 */       return (0 == id);
/*      */     }
/*  230 */     return (t.id() == id);
/*      */   }
/*      */   
/*      */   public final boolean hasToken(JsonToken t) {
/*  234 */     return (this._currToken == t);
/*      */   }
/*      */   
/*  237 */   public boolean isExpectedStartArrayToken() { return (this._currToken == JsonToken.START_ARRAY); } public boolean isExpectedStartObjectToken() {
/*  238 */     return (this._currToken == JsonToken.START_OBJECT);
/*      */   }
/*      */   
/*      */   public JsonLocation currentLocation() {
/*  242 */     return this.delegate.currentLocation();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public JsonLocation getCurrentLocation() {
/*  248 */     return this.delegate.getCurrentLocation();
/*      */   }
/*      */   
/*      */   public JsonLocation currentTokenLocation() {
/*  252 */     return this.delegate.currentTokenLocation();
/*      */   }
/*      */   @Deprecated
/*      */   public JsonLocation getTokenLocation() {
/*  256 */     return this.delegate.getTokenLocation();
/*      */   }
/*      */   
/*      */   public JsonStreamContext getParsingContext() {
/*  260 */     return _filterContext();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String getCurrentName() throws IOException {
/*  266 */     JsonStreamContext ctxt = _filterContext();
/*  267 */     if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/*  268 */       JsonStreamContext parent = ctxt.getParent();
/*  269 */       return (parent == null) ? null : parent.getCurrentName();
/*      */     } 
/*  271 */     return ctxt.getCurrentName();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String currentName() throws IOException {
/*  277 */     JsonStreamContext ctxt = _filterContext();
/*  278 */     if (this._currToken == JsonToken.START_OBJECT || this._currToken == JsonToken.START_ARRAY) {
/*  279 */       JsonStreamContext parent = ctxt.getParent();
/*  280 */       return (parent == null) ? null : parent.getCurrentName();
/*      */     } 
/*  282 */     return ctxt.getCurrentName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearCurrentToken() {
/*  293 */     if (this._currToken != null) {
/*  294 */       this._lastClearedToken = this._currToken;
/*  295 */       this._currToken = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public JsonToken getLastClearedToken() {
/*  300 */     return this._lastClearedToken;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void overrideCurrentName(String name) {
/*  307 */     throw new UnsupportedOperationException("Can not currently override name during filtering read");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken nextToken() throws IOException {
/*      */     boolean returnEnd;
/*      */     String name;
/*  327 */     if (!this._allowMultipleMatches && this._currToken != null && this._exposedContext == null)
/*      */     {
/*      */       
/*  330 */       if (this._currToken.isScalarValue() && !this._headContext.isStartHandled() && this._inclusion == TokenFilter.Inclusion.ONLY_INCLUDE_ALL && this._itemFilter == TokenFilter.INCLUDE_ALL)
/*      */       {
/*      */         
/*  333 */         return this._currToken = null;
/*      */       }
/*      */     }
/*      */     
/*  337 */     TokenFilterContext ctxt = this._exposedContext;
/*      */     
/*  339 */     if (ctxt != null) {
/*      */       while (true) {
/*  341 */         JsonToken jsonToken = ctxt.nextTokenToRead();
/*  342 */         if (jsonToken != null) {
/*  343 */           this._currToken = jsonToken;
/*  344 */           return jsonToken;
/*      */         } 
/*      */         
/*  347 */         if (ctxt == this._headContext) {
/*  348 */           this._exposedContext = null;
/*  349 */           if (ctxt.inArray()) {
/*  350 */             jsonToken = this.delegate.getCurrentToken();
/*  351 */             this._currToken = jsonToken;
/*  352 */             if (this._currToken == JsonToken.END_ARRAY) {
/*  353 */               this._headContext = this._headContext.getParent();
/*  354 */               this._itemFilter = this._headContext.getFilter();
/*      */             } 
/*  356 */             return jsonToken;
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  362 */           jsonToken = this.delegate.currentToken();
/*  363 */           if (jsonToken == JsonToken.END_OBJECT) {
/*  364 */             this._headContext = this._headContext.getParent();
/*  365 */             this._itemFilter = this._headContext.getFilter();
/*      */           } 
/*  367 */           if (jsonToken != JsonToken.FIELD_NAME) {
/*  368 */             this._currToken = jsonToken;
/*  369 */             return jsonToken;
/*      */           } 
/*      */           
/*      */           break;
/*      */         } 
/*  374 */         ctxt = this._headContext.findChildOf(ctxt);
/*  375 */         this._exposedContext = ctxt;
/*  376 */         if (ctxt == null) {
/*  377 */           throw _constructError("Unexpected problem: chain of filtered context broken");
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  383 */     JsonToken t = this.delegate.nextToken();
/*  384 */     if (t == null) {
/*      */       
/*  386 */       this._currToken = t;
/*  387 */       return t;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  393 */     switch (t.id())
/*      */     { case -1:
/*  395 */         throw _constructError("`JsonToken.NOT_AVAILABLE` received: ensure all input is fed to the Parser before use");
/*      */       case 3:
/*  397 */         f = this._itemFilter;
/*  398 */         if (f == TokenFilter.INCLUDE_ALL) {
/*  399 */           this._headContext = this._headContext.createChildArrayContext(f, true);
/*  400 */           return this._currToken = t;
/*      */         } 
/*  402 */         if (f == null) {
/*  403 */           this.delegate.skipChildren();
/*      */         }
/*      */         else {
/*      */           
/*  407 */           f = this._headContext.checkValue(f);
/*  408 */           if (f == null) {
/*  409 */             this.delegate.skipChildren();
/*      */           } else {
/*      */             
/*  412 */             if (f != TokenFilter.INCLUDE_ALL) {
/*  413 */               f = f.filterStartArray();
/*      */             }
/*  415 */             this._itemFilter = f;
/*  416 */             if (f == TokenFilter.INCLUDE_ALL) {
/*  417 */               this._headContext = this._headContext.createChildArrayContext(f, true);
/*  418 */               return this._currToken = t;
/*  419 */             }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*      */               
/*  421 */               this._headContext = this._headContext.createChildArrayContext(f, true);
/*  422 */               return this._currToken = t;
/*      */             } 
/*  424 */             this._headContext = this._headContext.createChildArrayContext(f, false);
/*      */ 
/*      */             
/*  427 */             if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/*  428 */               t = _nextTokenWithBuffering(this._headContext);
/*  429 */               if (t != null) {
/*  430 */                 this._currToken = t;
/*  431 */                 return t;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  557 */         return _nextToken2();case 1: f = this._itemFilter; if (f == TokenFilter.INCLUDE_ALL) { this._headContext = this._headContext.createChildObjectContext(f, true); return this._currToken = t; }  if (f == null) { this.delegate.skipChildren(); } else { f = this._headContext.checkValue(f); if (f == null) { this.delegate.skipChildren(); } else { if (f != TokenFilter.INCLUDE_ALL) f = f.filterStartObject();  this._itemFilter = f; if (f == TokenFilter.INCLUDE_ALL) { this._headContext = this._headContext.createChildObjectContext(f, true); return this._currToken = t; }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) { this._headContext = this._headContext.createChildObjectContext(f, true); return this._currToken = t; }  this._headContext = this._headContext.createChildObjectContext(f, false); if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) { t = _nextTokenWithBuffering(this._headContext); if (t != null) { this._currToken = t; return t; }  }  }  }  return _nextToken2();case 2: case 4: returnEnd = this._headContext.isStartHandled(); f = this._headContext.getFilter(); if (f != null && f != TokenFilter.INCLUDE_ALL) if (t.id() == 4) { f.filterFinishArray(); } else { f.filterFinishObject(); }   this._headContext = this._headContext.getParent(); this._itemFilter = this._headContext.getFilter(); if (returnEnd) return this._currToken = t;  return _nextToken2();case 5: name = this.delegate.currentName(); f = this._headContext.setFieldName(name); if (f == TokenFilter.INCLUDE_ALL) { this._itemFilter = f; return this._currToken = t; }  if (f == null) { this.delegate.nextToken(); this.delegate.skipChildren(); } else { f = f.includeProperty(name); if (f == null) { this.delegate.nextToken(); this.delegate.skipChildren(); } else { this._itemFilter = f; if (f == TokenFilter.INCLUDE_ALL) if (_verifyAllowedMatches()) { if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) return this._currToken = t;  } else { this.delegate.nextToken(); this.delegate.skipChildren(); }   if (this._inclusion != TokenFilter.Inclusion.ONLY_INCLUDE_ALL) { t = _nextTokenWithBuffering(this._headContext); if (t != null) { this._currToken = t; return t; }  }  }  }  return _nextToken2(); }  TokenFilter f = this._itemFilter; if (f == TokenFilter.INCLUDE_ALL) return this._currToken = t;  if (f != null) { f = this._headContext.checkValue(f); if ((f == TokenFilter.INCLUDE_ALL || (f != null && f.includeValue(this.delegate))) && _verifyAllowedMatches()) return this._currToken = t;  }  return _nextToken2();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _nextToken2() throws IOException {
/*      */     while (true) {
/*      */       boolean returnEnd;
/*      */       String name;
/*  568 */       JsonToken t = this.delegate.nextToken();
/*  569 */       if (t == null) {
/*  570 */         this._currToken = t;
/*  571 */         return t;
/*      */       } 
/*      */ 
/*      */       
/*  575 */       switch (t.id()) {
/*      */         case 3:
/*  577 */           f = this._itemFilter;
/*  578 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  579 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/*  580 */             return this._currToken = t;
/*      */           } 
/*  582 */           if (f == null) {
/*  583 */             this.delegate.skipChildren();
/*      */             
/*      */             continue;
/*      */           } 
/*  587 */           f = this._headContext.checkValue(f);
/*  588 */           if (f == null) {
/*  589 */             this.delegate.skipChildren();
/*      */             continue;
/*      */           } 
/*  592 */           if (f != TokenFilter.INCLUDE_ALL) {
/*  593 */             f = f.filterStartArray();
/*      */           }
/*  595 */           this._itemFilter = f;
/*  596 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  597 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/*  598 */             return this._currToken = t;
/*  599 */           }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*  600 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/*  601 */             return this._currToken = t;
/*      */           } 
/*  603 */           this._headContext = this._headContext.createChildArrayContext(f, false);
/*      */           
/*  605 */           if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/*  606 */             t = _nextTokenWithBuffering(this._headContext);
/*  607 */             if (t != null) {
/*  608 */               this._currToken = t;
/*  609 */               return t;
/*      */             } 
/*      */           } 
/*      */           continue;
/*      */         
/*      */         case 1:
/*  615 */           f = this._itemFilter;
/*  616 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  617 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/*  618 */             return this._currToken = t;
/*      */           } 
/*  620 */           if (f == null) {
/*  621 */             this.delegate.skipChildren();
/*      */             
/*      */             continue;
/*      */           } 
/*  625 */           f = this._headContext.checkValue(f);
/*  626 */           if (f == null) {
/*  627 */             this.delegate.skipChildren();
/*      */             continue;
/*      */           } 
/*  630 */           if (f != TokenFilter.INCLUDE_ALL) {
/*  631 */             f = f.filterStartObject();
/*      */           }
/*  633 */           this._itemFilter = f;
/*  634 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  635 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/*  636 */             return this._currToken = t;
/*  637 */           }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*  638 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/*  639 */             return this._currToken = t;
/*      */           } 
/*  641 */           this._headContext = this._headContext.createChildObjectContext(f, false);
/*  642 */           if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH) {
/*  643 */             t = _nextTokenWithBuffering(this._headContext);
/*  644 */             if (t != null) {
/*  645 */               this._currToken = t;
/*  646 */               return t;
/*      */             } 
/*      */           } 
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 4:
/*  653 */           returnEnd = this._headContext.isStartHandled();
/*  654 */           f = this._headContext.getFilter();
/*  655 */           if (f != null && f != TokenFilter.INCLUDE_ALL) {
/*  656 */             boolean includeEmpty = f.includeEmptyArray(this._headContext.hasCurrentIndex());
/*  657 */             f.filterFinishArray();
/*  658 */             if (includeEmpty) {
/*  659 */               return _nextBuffered(this._headContext);
/*      */             }
/*      */           } 
/*  662 */           this._headContext = this._headContext.getParent();
/*  663 */           this._itemFilter = this._headContext.getFilter();
/*  664 */           if (returnEnd) {
/*  665 */             return this._currToken = t;
/*      */           }
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 2:
/*  671 */           returnEnd = this._headContext.isStartHandled();
/*  672 */           f = this._headContext.getFilter();
/*  673 */           if (f != null && f != TokenFilter.INCLUDE_ALL) {
/*  674 */             boolean includeEmpty = f.includeEmptyArray(this._headContext.hasCurrentName());
/*  675 */             f.filterFinishObject();
/*  676 */             if (includeEmpty)
/*  677 */               return _nextBuffered(this._headContext); 
/*      */           } 
/*  679 */           this._headContext = this._headContext.getParent();
/*  680 */           this._itemFilter = this._headContext.getFilter();
/*  681 */           if (returnEnd) {
/*  682 */             return this._currToken = t;
/*      */           }
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 5:
/*  689 */           name = this.delegate.currentName();
/*  690 */           f = this._headContext.setFieldName(name);
/*  691 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  692 */             this._itemFilter = f;
/*  693 */             return this._currToken = t;
/*      */           } 
/*  695 */           if (f == null) {
/*  696 */             this.delegate.nextToken();
/*  697 */             this.delegate.skipChildren();
/*      */             continue;
/*      */           } 
/*  700 */           f = f.includeProperty(name);
/*  701 */           if (f == null) {
/*  702 */             this.delegate.nextToken();
/*  703 */             this.delegate.skipChildren();
/*      */             continue;
/*      */           } 
/*  706 */           this._itemFilter = f;
/*  707 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  708 */             if (_verifyAllowedMatches()) {
/*  709 */               if (this._inclusion == TokenFilter.Inclusion.INCLUDE_ALL_AND_PATH)
/*  710 */                 return this._currToken = t; 
/*      */               continue;
/*      */             } 
/*  713 */             this.delegate.nextToken();
/*  714 */             this.delegate.skipChildren();
/*      */             
/*      */             continue;
/*      */           } 
/*  718 */           if (this._inclusion != TokenFilter.Inclusion.ONLY_INCLUDE_ALL) {
/*  719 */             t = _nextTokenWithBuffering(this._headContext);
/*  720 */             if (t != null) {
/*  721 */               this._currToken = t;
/*  722 */               return t;
/*      */             } 
/*      */           } 
/*      */           continue;
/*      */       } 
/*      */ 
/*      */       
/*  729 */       TokenFilter f = this._itemFilter;
/*  730 */       if (f == TokenFilter.INCLUDE_ALL) {
/*  731 */         return this._currToken = t;
/*      */       }
/*  733 */       if (f != null) {
/*  734 */         f = this._headContext.checkValue(f);
/*  735 */         if ((f == TokenFilter.INCLUDE_ALL || (f != null && f
/*  736 */           .includeValue(this.delegate))) && 
/*  737 */           _verifyAllowedMatches()) {
/*  738 */           return this._currToken = t;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final JsonToken _nextTokenWithBuffering(TokenFilterContext buffRoot) throws IOException {
/*      */     while (true) {
/*      */       boolean gotEnd;
/*      */       String name;
/*      */       boolean returnEnd;
/*  754 */       JsonToken t = this.delegate.nextToken();
/*  755 */       if (t == null) {
/*  756 */         return t;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  764 */       switch (t.id()) {
/*      */         case 3:
/*  766 */           f = this._headContext.checkValue(this._itemFilter);
/*  767 */           if (f == null) {
/*  768 */             this.delegate.skipChildren();
/*      */             continue;
/*      */           } 
/*  771 */           if (f != TokenFilter.INCLUDE_ALL) {
/*  772 */             f = f.filterStartArray();
/*      */           }
/*  774 */           this._itemFilter = f;
/*  775 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  776 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/*  777 */             return _nextBuffered(buffRoot);
/*  778 */           }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*      */             
/*  780 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/*  781 */             return _nextBuffered(buffRoot);
/*      */           } 
/*  783 */           this._headContext = this._headContext.createChildArrayContext(f, false);
/*      */           continue;
/*      */         
/*      */         case 1:
/*  787 */           f = this._itemFilter;
/*  788 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  789 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/*  790 */             return t;
/*      */           } 
/*  792 */           if (f == null) {
/*  793 */             this.delegate.skipChildren();
/*      */             
/*      */             continue;
/*      */           } 
/*  797 */           f = this._headContext.checkValue(f);
/*  798 */           if (f == null) {
/*  799 */             this.delegate.skipChildren();
/*      */             continue;
/*      */           } 
/*  802 */           if (f != TokenFilter.INCLUDE_ALL) {
/*  803 */             f = f.filterStartObject();
/*      */           }
/*  805 */           this._itemFilter = f;
/*  806 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  807 */             this._headContext = this._headContext.createChildObjectContext(f, true);
/*  808 */             return _nextBuffered(buffRoot);
/*  809 */           }  if (f != null && this._inclusion == TokenFilter.Inclusion.INCLUDE_NON_NULL) {
/*      */             
/*  811 */             this._headContext = this._headContext.createChildArrayContext(f, true);
/*  812 */             return _nextBuffered(buffRoot);
/*      */           } 
/*  814 */           this._headContext = this._headContext.createChildObjectContext(f, false);
/*      */           continue;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 4:
/*  821 */           f = this._headContext.getFilter();
/*  822 */           if (f != null && f != TokenFilter.INCLUDE_ALL) {
/*  823 */             boolean includeEmpty = f.includeEmptyArray(this._headContext.hasCurrentIndex());
/*  824 */             f.filterFinishArray();
/*  825 */             if (includeEmpty) {
/*  826 */               return _nextBuffered(buffRoot);
/*      */             }
/*      */           } 
/*  829 */           gotEnd = (this._headContext == buffRoot);
/*  830 */           returnEnd = (gotEnd && this._headContext.isStartHandled());
/*      */           
/*  832 */           this._headContext = this._headContext.getParent();
/*  833 */           this._itemFilter = this._headContext.getFilter();
/*      */           
/*  835 */           if (returnEnd) {
/*  836 */             return t;
/*      */           }
/*  838 */           if (gotEnd) {
/*  839 */             return null;
/*      */           }
/*      */           continue;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2:
/*  847 */           f = this._headContext.getFilter();
/*  848 */           if (f != null && f != TokenFilter.INCLUDE_ALL) {
/*  849 */             boolean includeEmpty = f.includeEmptyObject(this._headContext.hasCurrentName());
/*  850 */             f.filterFinishObject();
/*  851 */             if (includeEmpty) {
/*  852 */               this._headContext._currentName = (this._headContext._parent == null) ? null : this._headContext._parent._currentName;
/*      */ 
/*      */               
/*  855 */               this._headContext._needToHandleName = false;
/*  856 */               return _nextBuffered(buffRoot);
/*      */             } 
/*      */           } 
/*  859 */           gotEnd = (this._headContext == buffRoot);
/*  860 */           returnEnd = (gotEnd && this._headContext.isStartHandled());
/*      */           
/*  862 */           this._headContext = this._headContext.getParent();
/*  863 */           this._itemFilter = this._headContext.getFilter();
/*      */           
/*  865 */           if (returnEnd) {
/*  866 */             return t;
/*      */           }
/*  868 */           if (gotEnd) {
/*  869 */             return null;
/*      */           }
/*      */           continue;
/*      */ 
/*      */ 
/*      */         
/*      */         case 5:
/*  876 */           name = this.delegate.currentName();
/*  877 */           f = this._headContext.setFieldName(name);
/*  878 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  879 */             this._itemFilter = f;
/*  880 */             return _nextBuffered(buffRoot);
/*      */           } 
/*  882 */           if (f == null) {
/*  883 */             this.delegate.nextToken();
/*  884 */             this.delegate.skipChildren();
/*      */             continue;
/*      */           } 
/*  887 */           f = f.includeProperty(name);
/*  888 */           if (f == null) {
/*  889 */             this.delegate.nextToken();
/*  890 */             this.delegate.skipChildren();
/*      */             continue;
/*      */           } 
/*  893 */           this._itemFilter = f;
/*  894 */           if (f == TokenFilter.INCLUDE_ALL) {
/*  895 */             if (_verifyAllowedMatches()) {
/*  896 */               return _nextBuffered(buffRoot);
/*      */             }
/*      */ 
/*      */             
/*  900 */             this._itemFilter = this._headContext.setFieldName(name);
/*      */           } 
/*      */           continue;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  907 */       TokenFilter f = this._itemFilter;
/*  908 */       if (f == TokenFilter.INCLUDE_ALL) {
/*  909 */         return _nextBuffered(buffRoot);
/*      */       }
/*  911 */       if (f != null) {
/*  912 */         f = this._headContext.checkValue(f);
/*  913 */         if ((f == TokenFilter.INCLUDE_ALL || (f != null && f
/*  914 */           .includeValue(this.delegate))) && 
/*  915 */           _verifyAllowedMatches()) {
/*  916 */           return _nextBuffered(buffRoot);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JsonToken _nextBuffered(TokenFilterContext buffRoot) throws IOException {
/*  928 */     this._exposedContext = buffRoot;
/*  929 */     TokenFilterContext ctxt = buffRoot;
/*  930 */     JsonToken t = ctxt.nextTokenToRead();
/*  931 */     if (t != null) {
/*  932 */       return t;
/*      */     }
/*      */     
/*      */     while (true) {
/*  936 */       if (ctxt == this._headContext) {
/*  937 */         throw _constructError("Internal error: failed to locate expected buffered tokens");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  944 */       ctxt = this._exposedContext.findChildOf(ctxt);
/*  945 */       this._exposedContext = ctxt;
/*  946 */       if (ctxt == null) {
/*  947 */         throw _constructError("Unexpected problem: chain of filtered context broken");
/*      */       }
/*  949 */       t = this._exposedContext.nextTokenToRead();
/*  950 */       if (t != null) {
/*  951 */         return t;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private final boolean _verifyAllowedMatches() throws IOException {
/*  957 */     if (this._matchCount == 0 || this._allowMultipleMatches) {
/*  958 */       this._matchCount++;
/*  959 */       return true;
/*      */     } 
/*  961 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonToken nextValue() throws IOException {
/*  967 */     JsonToken t = nextToken();
/*  968 */     if (t == JsonToken.FIELD_NAME) {
/*  969 */       t = nextToken();
/*      */     }
/*  971 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonParser skipChildren() throws IOException {
/*  982 */     if (this._currToken != JsonToken.START_OBJECT && this._currToken != JsonToken.START_ARRAY)
/*      */     {
/*  984 */       return (JsonParser)this;
/*      */     }
/*  986 */     int open = 1;
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  991 */       JsonToken t = nextToken();
/*  992 */       if (t == null) {
/*  993 */         return (JsonParser)this;
/*      */       }
/*  995 */       if (t.isStructStart()) {
/*  996 */         open++; continue;
/*  997 */       }  if (t.isStructEnd() && 
/*  998 */         --open == 0) {
/*  999 */         return (JsonParser)this;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getText() throws IOException {
/* 1015 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1016 */       return currentName();
/*      */     }
/* 1018 */     return this.delegate.getText();
/*      */   }
/*      */   
/*      */   public boolean hasTextCharacters() {
/* 1022 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1023 */       return false;
/*      */     }
/* 1025 */     return this.delegate.hasTextCharacters();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getTextCharacters() throws IOException {
/* 1031 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1032 */       return currentName().toCharArray();
/*      */     }
/* 1034 */     return this.delegate.getTextCharacters();
/*      */   }
/*      */   
/*      */   public int getTextLength() throws IOException {
/* 1038 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1039 */       return currentName().length();
/*      */     }
/* 1041 */     return this.delegate.getTextLength();
/*      */   }
/*      */   public int getTextOffset() throws IOException {
/* 1044 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1045 */       return 0;
/*      */     }
/* 1047 */     return this.delegate.getTextOffset();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigInteger getBigIntegerValue() throws IOException {
/* 1057 */     return this.delegate.getBigIntegerValue();
/*      */   }
/*      */   public boolean getBooleanValue() throws IOException {
/* 1060 */     return this.delegate.getBooleanValue();
/*      */   }
/*      */   public byte getByteValue() throws IOException {
/* 1063 */     return this.delegate.getByteValue();
/*      */   }
/*      */   public short getShortValue() throws IOException {
/* 1066 */     return this.delegate.getShortValue();
/*      */   }
/*      */   public BigDecimal getDecimalValue() throws IOException {
/* 1069 */     return this.delegate.getDecimalValue();
/*      */   }
/*      */   public double getDoubleValue() throws IOException {
/* 1072 */     return this.delegate.getDoubleValue();
/*      */   }
/*      */   public float getFloatValue() throws IOException {
/* 1075 */     return this.delegate.getFloatValue();
/*      */   }
/*      */   public int getIntValue() throws IOException {
/* 1078 */     return this.delegate.getIntValue();
/*      */   }
/*      */   public long getLongValue() throws IOException {
/* 1081 */     return this.delegate.getLongValue();
/*      */   }
/*      */   public JsonParser.NumberType getNumberType() throws IOException {
/* 1084 */     return this.delegate.getNumberType();
/*      */   }
/*      */   public Number getNumberValue() throws IOException {
/* 1087 */     return this.delegate.getNumberValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getValueAsInt() throws IOException {
/* 1095 */     return this.delegate.getValueAsInt();
/* 1096 */   } public int getValueAsInt(int defaultValue) throws IOException { return this.delegate.getValueAsInt(defaultValue); }
/* 1097 */   public long getValueAsLong() throws IOException { return this.delegate.getValueAsLong(); }
/* 1098 */   public long getValueAsLong(long defaultValue) throws IOException { return this.delegate.getValueAsLong(defaultValue); }
/* 1099 */   public double getValueAsDouble() throws IOException { return this.delegate.getValueAsDouble(); }
/* 1100 */   public double getValueAsDouble(double defaultValue) throws IOException { return this.delegate.getValueAsDouble(defaultValue); }
/* 1101 */   public boolean getValueAsBoolean() throws IOException { return this.delegate.getValueAsBoolean(); } public boolean getValueAsBoolean(boolean defaultValue) throws IOException {
/* 1102 */     return this.delegate.getValueAsBoolean(defaultValue);
/*      */   }
/*      */   public String getValueAsString() throws IOException {
/* 1105 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1106 */       return currentName();
/*      */     }
/* 1108 */     return this.delegate.getValueAsString();
/*      */   }
/*      */   public String getValueAsString(String defaultValue) throws IOException {
/* 1111 */     if (this._currToken == JsonToken.FIELD_NAME) {
/* 1112 */       return currentName();
/*      */     }
/* 1114 */     return this.delegate.getValueAsString(defaultValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getEmbeddedObject() throws IOException {
/* 1123 */     return this.delegate.getEmbeddedObject();
/* 1124 */   } public byte[] getBinaryValue(Base64Variant b64variant) throws IOException { return this.delegate.getBinaryValue(b64variant); } public int readBinaryValue(Base64Variant b64variant, OutputStream out) throws IOException {
/* 1125 */     return this.delegate.readBinaryValue(b64variant, out);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected JsonStreamContext _filterContext() {
/* 1134 */     if (this._exposedContext != null) {
/* 1135 */       return this._exposedContext;
/*      */     }
/* 1137 */     return this._headContext;
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\filter\FilteringParserDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */