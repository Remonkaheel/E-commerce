/*     */ package com.fasterxml.jackson.core.filter;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonPointer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonPointerBasedFilter
/*     */   extends TokenFilter
/*     */ {
/*     */   protected final JsonPointer _pathToMatch;
/*     */   protected final boolean _includeAllElements;
/*     */   
/*     */   public JsonPointerBasedFilter(String ptrExpr) {
/*  26 */     this(JsonPointer.compile(ptrExpr), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointerBasedFilter(JsonPointer pathToMatch) {
/*  33 */     this(pathToMatch, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPointerBasedFilter(JsonPointer pathToMatch, boolean includeAllElements) {
/*  44 */     this._pathToMatch = pathToMatch;
/*  45 */     this._includeAllElements = includeAllElements;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JsonPointerBasedFilter construct(JsonPointer pathToMatch, boolean includeAllElements) {
/*  62 */     return new JsonPointerBasedFilter(pathToMatch, includeAllElements);
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenFilter includeElement(int index) {
/*     */     JsonPointer next;
/*  68 */     if (this._includeAllElements && !this._pathToMatch.mayMatchElement()) {
/*  69 */       next = this._pathToMatch.tail();
/*     */     } else {
/*  71 */       next = this._pathToMatch.matchElement(index);
/*     */     } 
/*  73 */     if (next == null) {
/*  74 */       return null;
/*     */     }
/*  76 */     if (next.matches()) {
/*  77 */       return TokenFilter.INCLUDE_ALL;
/*     */     }
/*  79 */     return construct(next, this._includeAllElements);
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenFilter includeProperty(String name) {
/*  84 */     JsonPointer next = this._pathToMatch.matchProperty(name);
/*  85 */     if (next == null) {
/*  86 */       return null;
/*     */     }
/*  88 */     if (next.matches()) {
/*  89 */       return TokenFilter.INCLUDE_ALL;
/*     */     }
/*  91 */     return construct(next, this._includeAllElements);
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenFilter filterStartArray() {
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public TokenFilter filterStartObject() {
/* 101 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _includeScalar() {
/* 107 */     return this._pathToMatch.matches();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 112 */     return "[JsonPointerFilter at: " + this._pathToMatch + "]";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\filter\JsonPointerBasedFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */