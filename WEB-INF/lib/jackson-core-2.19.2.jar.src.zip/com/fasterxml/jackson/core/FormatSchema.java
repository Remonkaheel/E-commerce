package com.fasterxml.jackson.core;

public interface FormatSchema {
  String getSchemaType();
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\FormatSchema.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */