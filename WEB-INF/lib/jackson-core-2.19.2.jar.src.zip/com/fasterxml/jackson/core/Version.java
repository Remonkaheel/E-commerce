/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Version
/*     */   implements Comparable<Version>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  23 */   private static final Version UNKNOWN_VERSION = new Version(0, 0, 0, null, null, null);
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _majorVersion;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _minorVersion;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _patchLevel;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _groupId;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _artifactId;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _snapshotInfo;
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Version(int major, int minor, int patchLevel, String snapshotInfo) {
/*  53 */     this(major, minor, patchLevel, snapshotInfo, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Version(int major, int minor, int patchLevel, String snapshotInfo, String groupId, String artifactId) {
/*  59 */     this._majorVersion = major;
/*  60 */     this._minorVersion = minor;
/*  61 */     this._patchLevel = patchLevel;
/*  62 */     this._snapshotInfo = snapshotInfo;
/*  63 */     this._groupId = (groupId == null) ? "" : groupId;
/*  64 */     this._artifactId = (artifactId == null) ? "" : artifactId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Version unknownVersion() {
/*  74 */     return UNKNOWN_VERSION;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUnknownVersion() {
/*  82 */     return (this == UNKNOWN_VERSION);
/*     */   }
/*     */   public boolean isSnapshot() {
/*  85 */     return (this._snapshotInfo != null && !this._snapshotInfo.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean isUknownVersion() {
/*  95 */     return isUnknownVersion();
/*     */   }
/*  97 */   public int getMajorVersion() { return this._majorVersion; }
/*  98 */   public int getMinorVersion() { return this._minorVersion; } public int getPatchLevel() {
/*  99 */     return this._patchLevel;
/*     */   }
/* 101 */   public String getGroupId() { return this._groupId; } public String getArtifactId() {
/* 102 */     return this._artifactId;
/*     */   }
/*     */   public String toFullString() {
/* 105 */     return this._groupId + '/' + this._artifactId + '/' + toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 110 */     StringBuilder sb = new StringBuilder();
/* 111 */     sb.append(this._majorVersion).append('.');
/* 112 */     sb.append(this._minorVersion).append('.');
/* 113 */     sb.append(this._patchLevel);
/* 114 */     if (isSnapshot()) {
/* 115 */       sb.append('-').append(this._snapshotInfo);
/*     */     }
/* 117 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 122 */     return this._artifactId.hashCode() ^ this._groupId.hashCode() ^ 
/* 123 */       Objects.hashCode(this._snapshotInfo) + this._majorVersion - this._minorVersion + this._patchLevel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 130 */     if (o == this) return true; 
/* 131 */     if (o == null) return false; 
/* 132 */     if (o.getClass() != getClass()) return false; 
/* 133 */     Version other = (Version)o;
/* 134 */     return (other._majorVersion == this._majorVersion && other._minorVersion == this._minorVersion && other._patchLevel == this._patchLevel && 
/*     */ 
/*     */       
/* 137 */       Objects.equals(other._snapshotInfo, this._snapshotInfo) && other._artifactId
/* 138 */       .equals(this._artifactId) && other._groupId
/* 139 */       .equals(this._groupId));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(Version other) {
/* 146 */     if (other == this) return 0;
/*     */     
/* 148 */     int diff = this._groupId.compareTo(other._groupId);
/* 149 */     if (diff == 0) {
/* 150 */       diff = this._artifactId.compareTo(other._artifactId);
/* 151 */       if (diff == 0) {
/* 152 */         diff = this._majorVersion - other._majorVersion;
/* 153 */         if (diff == 0) {
/* 154 */           diff = this._minorVersion - other._minorVersion;
/* 155 */           if (diff == 0) {
/* 156 */             diff = this._patchLevel - other._patchLevel;
/* 157 */             if (diff == 0)
/*     */             {
/* 159 */               if (isSnapshot()) {
/* 160 */                 if (other.isSnapshot()) {
/* 161 */                   diff = this._snapshotInfo.compareTo(other._snapshotInfo);
/*     */                 } else {
/* 163 */                   diff = -1;
/*     */                 } 
/* 165 */               } else if (other.isSnapshot()) {
/* 166 */                 diff = 1;
/*     */               } else {
/* 168 */                 diff = 0;
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 175 */     return diff;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\Version.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */