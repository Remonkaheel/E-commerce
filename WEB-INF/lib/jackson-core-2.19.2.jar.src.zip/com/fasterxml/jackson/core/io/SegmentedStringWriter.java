/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import com.fasterxml.jackson.core.util.BufferRecycler;
/*     */ import com.fasterxml.jackson.core.util.TextBuffer;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SegmentedStringWriter
/*     */   extends Writer
/*     */   implements BufferRecycler.Gettable
/*     */ {
/*     */   private final TextBuffer _buffer;
/*     */   
/*     */   public SegmentedStringWriter(BufferRecycler br) {
/*  24 */     this._buffer = new TextBuffer(br);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferRecycler bufferRecycler() {
/*  35 */     return this._buffer.bufferRecycler();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Writer append(char c) throws IOException {
/*  46 */     write(c);
/*  47 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Writer append(CharSequence csq) throws IOException {
/*  52 */     String str = csq.toString();
/*  53 */     this._buffer.append(str, 0, str.length());
/*  54 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Writer append(CharSequence csq, int start, int end) throws IOException {
/*  59 */     String str = csq.subSequence(start, end).toString();
/*  60 */     this._buffer.append(str, 0, str.length());
/*  61 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */ 
/*     */   
/*     */   public void flush() {}
/*     */ 
/*     */   
/*     */   public void write(char[] cbuf) throws IOException {
/*  72 */     this._buffer.append(cbuf, 0, cbuf.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(char[] cbuf, int off, int len) throws IOException {
/*  78 */     this._buffer.append(cbuf, off, len);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(int c) throws IOException {
/*  83 */     this._buffer.append((char)c);
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(String str) throws IOException {
/*  88 */     this._buffer.append(str, 0, str.length());
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(String str, int off, int len) throws IOException {
/*  93 */     this._buffer.append(str, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAndClear() throws IOException {
/* 114 */     String result = this._buffer.contentsAsString();
/* 115 */     this._buffer.releaseBuffers();
/* 116 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\io\SegmentedStringWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */