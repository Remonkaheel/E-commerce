/*    */ package com.fasterxml.jackson.core.io;
/*    */ 
/*    */ import com.fasterxml.jackson.core.internal.shaded.fdp.v2_19_2.JavaBigIntegerParser;
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BigIntegerParser
/*    */ {
/*    */   public static BigInteger parseWithFastParser(String valueStr) {
/*    */     try {
/* 21 */       return JavaBigIntegerParser.parseBigInteger(valueStr);
/* 22 */     } catch (NumberFormatException nfe) {
/*    */       
/* 24 */       String reportNum = (valueStr.length() <= 1000) ? valueStr : (valueStr.substring(0, 1000) + " [truncated]");
/* 25 */       throw new NumberFormatException("Value \"" + reportNum + "\" can not be represented as `java.math.BigInteger`, reason: " + nfe
/* 26 */           .getMessage());
/*    */     } 
/*    */   }
/*    */   
/*    */   public static BigInteger parseWithFastParser(String valueStr, int radix) {
/*    */     try {
/* 32 */       return JavaBigIntegerParser.parseBigInteger(valueStr, radix);
/* 33 */     } catch (NumberFormatException nfe) {
/*    */       
/* 35 */       String reportNum = (valueStr.length() <= 1000) ? valueStr : (valueStr.substring(0, 1000) + " [truncated]");
/* 36 */       throw new NumberFormatException("Value \"" + reportNum + "\" can not be represented as `java.math.BigInteger` with radix " + radix + ", reason: " + nfe
/*    */           
/* 38 */           .getMessage());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\io\BigIntegerParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */