/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import com.fasterxml.jackson.core.ErrorReportConfiguration;
/*     */ import com.fasterxml.jackson.core.JsonEncoding;
/*     */ import com.fasterxml.jackson.core.StreamReadConstraints;
/*     */ import com.fasterxml.jackson.core.StreamWriteConstraints;
/*     */ import com.fasterxml.jackson.core.util.BufferRecycler;
/*     */ import com.fasterxml.jackson.core.util.ReadConstrainedTextBuffer;
/*     */ import com.fasterxml.jackson.core.util.TextBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IOContext
/*     */   implements AutoCloseable
/*     */ {
/*     */   protected final ContentReference _contentReference;
/*     */   @Deprecated
/*     */   protected final Object _sourceRef;
/*     */   protected JsonEncoding _encoding;
/*     */   protected final boolean _managedResource;
/*     */   protected final BufferRecycler _bufferRecycler;
/*     */   protected boolean _releaseRecycler = true;
/*     */   protected final StreamReadConstraints _streamReadConstraints;
/*     */   protected final StreamWriteConstraints _streamWriteConstraints;
/*     */   protected final ErrorReportConfiguration _errorReportConfiguration;
/*     */   protected byte[] _readIOBuffer;
/*     */   protected byte[] _writeEncodingBuffer;
/*     */   protected byte[] _base64Buffer;
/*     */   protected char[] _tokenCBuffer;
/*     */   protected char[] _concatCBuffer;
/*     */   protected char[] _nameCopyBuffer;
/*     */   private boolean _closed = false;
/*     */   
/*     */   public IOContext(StreamReadConstraints src, StreamWriteConstraints swc, ErrorReportConfiguration erc, BufferRecycler br, ContentReference contentRef, boolean managedResource) {
/* 155 */     this._streamReadConstraints = src;
/* 156 */     this._streamWriteConstraints = swc;
/* 157 */     this._errorReportConfiguration = erc;
/* 158 */     this._bufferRecycler = br;
/* 159 */     this._contentReference = contentRef;
/* 160 */     this._sourceRef = contentRef.getRawContent();
/* 161 */     this._managedResource = managedResource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IOContext(StreamReadConstraints src, BufferRecycler br, ContentReference contentRef, boolean managedResource) {
/* 180 */     this(src, StreamWriteConstraints.defaults(), ErrorReportConfiguration.defaults(), br, contentRef, managedResource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IOContext(BufferRecycler br, ContentReference contentRef, boolean managedResource) {
/* 198 */     this(StreamReadConstraints.defaults(), StreamWriteConstraints.defaults(), ErrorReportConfiguration.defaults(), br, contentRef, managedResource);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public IOContext(BufferRecycler br, Object rawContent, boolean managedResource) {
/* 204 */     this(br, ContentReference.rawReference(rawContent), managedResource);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IOContext markBufferRecyclerReleased() {
/* 217 */     this._releaseRecycler = false;
/* 218 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StreamReadConstraints streamReadConstraints() {
/* 232 */     return this._streamReadConstraints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StreamWriteConstraints streamWriteConstraints() {
/* 240 */     return this._streamWriteConstraints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ErrorReportConfiguration errorReportConfiguration() {
/* 250 */     return this._errorReportConfiguration;
/*     */   }
/*     */   
/*     */   public void setEncoding(JsonEncoding enc) {
/* 254 */     this._encoding = enc;
/*     */   }
/*     */   
/*     */   public IOContext withEncoding(JsonEncoding enc) {
/* 258 */     this._encoding = enc;
/* 259 */     return this;
/*     */   }
/*     */   
/* 262 */   public JsonEncoding getEncoding() { return this._encoding; } public boolean isResourceManaged() {
/* 263 */     return this._managedResource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentReference contentReference() {
/* 274 */     return this._contentReference;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Object getSourceReference() {
/* 282 */     return this._sourceRef;
/*     */   }
/*     */   
/*     */   public BufferRecycler bufferRecycler() {
/* 286 */     return this._bufferRecycler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextBuffer constructTextBuffer() {
/* 296 */     return new TextBuffer(this._bufferRecycler);
/*     */   }
/*     */   
/*     */   public TextBuffer constructReadConstrainedTextBuffer() {
/* 300 */     return (TextBuffer)new ReadConstrainedTextBuffer(this._streamReadConstraints, this._bufferRecycler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] allocReadIOBuffer() {
/* 312 */     _verifyAlloc(this._readIOBuffer);
/* 313 */     return this._readIOBuffer = this._bufferRecycler.allocByteBuffer(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] allocReadIOBuffer(int minSize) {
/* 327 */     _verifyAlloc(this._readIOBuffer);
/* 328 */     return this._readIOBuffer = this._bufferRecycler.allocByteBuffer(0, minSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] allocWriteEncodingBuffer() {
/* 340 */     _verifyAlloc(this._writeEncodingBuffer);
/* 341 */     return this._writeEncodingBuffer = this._bufferRecycler.allocByteBuffer(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] allocWriteEncodingBuffer(int minSize) {
/* 355 */     _verifyAlloc(this._writeEncodingBuffer);
/* 356 */     return this._writeEncodingBuffer = this._bufferRecycler.allocByteBuffer(1, minSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] allocBase64Buffer() {
/* 368 */     _verifyAlloc(this._base64Buffer);
/* 369 */     return this._base64Buffer = this._bufferRecycler.allocByteBuffer(3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] allocBase64Buffer(int minSize) {
/* 383 */     _verifyAlloc(this._base64Buffer);
/* 384 */     return this._base64Buffer = this._bufferRecycler.allocByteBuffer(3, minSize);
/*     */   }
/*     */   
/*     */   public char[] allocTokenBuffer() {
/* 388 */     _verifyAlloc(this._tokenCBuffer);
/* 389 */     return this._tokenCBuffer = this._bufferRecycler.allocCharBuffer(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public char[] allocTokenBuffer(int minSize) {
/* 394 */     _verifyAlloc(this._tokenCBuffer);
/* 395 */     return this._tokenCBuffer = this._bufferRecycler.allocCharBuffer(0, minSize);
/*     */   }
/*     */   
/*     */   public char[] allocConcatBuffer() {
/* 399 */     _verifyAlloc(this._concatCBuffer);
/* 400 */     return this._concatCBuffer = this._bufferRecycler.allocCharBuffer(1);
/*     */   }
/*     */   
/*     */   public char[] allocNameCopyBuffer(int minSize) {
/* 404 */     _verifyAlloc(this._nameCopyBuffer);
/* 405 */     return this._nameCopyBuffer = this._bufferRecycler.allocCharBuffer(3, minSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void releaseReadIOBuffer(byte[] buf) {
/* 415 */     if (buf != null) {
/*     */ 
/*     */       
/* 418 */       _verifyRelease(buf, this._readIOBuffer);
/* 419 */       this._readIOBuffer = null;
/* 420 */       this._bufferRecycler.releaseByteBuffer(0, buf);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void releaseWriteEncodingBuffer(byte[] buf) {
/* 425 */     if (buf != null) {
/*     */ 
/*     */       
/* 428 */       _verifyRelease(buf, this._writeEncodingBuffer);
/* 429 */       this._writeEncodingBuffer = null;
/* 430 */       this._bufferRecycler.releaseByteBuffer(1, buf);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void releaseBase64Buffer(byte[] buf) {
/* 435 */     if (buf != null) {
/* 436 */       _verifyRelease(buf, this._base64Buffer);
/* 437 */       this._base64Buffer = null;
/* 438 */       this._bufferRecycler.releaseByteBuffer(3, buf);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void releaseTokenBuffer(char[] buf) {
/* 443 */     if (buf != null) {
/* 444 */       _verifyRelease(buf, this._tokenCBuffer);
/* 445 */       this._tokenCBuffer = null;
/* 446 */       this._bufferRecycler.releaseCharBuffer(0, buf);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void releaseConcatBuffer(char[] buf) {
/* 451 */     if (buf != null) {
/*     */       
/* 453 */       _verifyRelease(buf, this._concatCBuffer);
/* 454 */       this._concatCBuffer = null;
/* 455 */       this._bufferRecycler.releaseCharBuffer(1, buf);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void releaseNameCopyBuffer(char[] buf) {
/* 460 */     if (buf != null) {
/*     */       
/* 462 */       _verifyRelease(buf, this._nameCopyBuffer);
/* 463 */       this._nameCopyBuffer = null;
/* 464 */       this._bufferRecycler.releaseCharBuffer(3, buf);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void _verifyAlloc(Object buffer) {
/* 475 */     if (buffer != null) throw new IllegalStateException("Trying to call same allocXxx() method second time");
/*     */   
/*     */   }
/*     */   
/*     */   protected final void _verifyRelease(byte[] toRelease, byte[] src) {
/* 480 */     if (toRelease != src && toRelease.length < src.length) throw wrongBuf();
/*     */   
/*     */   }
/*     */   
/*     */   protected final void _verifyRelease(char[] toRelease, char[] src) {
/* 485 */     if (toRelease != src && toRelease.length < src.length) throw wrongBuf();
/*     */   
/*     */   }
/*     */   
/*     */   private IllegalArgumentException wrongBuf() {
/* 490 */     return new IllegalArgumentException("Trying to release buffer smaller than original");
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 495 */     if (!this._closed) {
/* 496 */       this._closed = true;
/* 497 */       if (this._releaseRecycler) {
/* 498 */         this._releaseRecycler = false;
/* 499 */         this._bufferRecycler.releaseToPool();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\io\IOContext.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */