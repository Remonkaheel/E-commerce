/*     */ package com.fasterxml.jackson.core.io.schubfach;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DoubleToDecimal
/*     */ {
/*     */   static final int P = 53;
/*     */   private static final int W = 11;
/*     */   static final int Q_MIN = -1074;
/*     */   static final int Q_MAX = 971;
/*     */   static final int E_MIN = -323;
/*     */   static final int E_MAX = 309;
/*     */   static final long C_TINY = 3L;
/*     */   static final int K_MIN = -324;
/*     */   static final int K_MAX = 292;
/*     */   static final int H = 17;
/*     */   private static final long C_MIN = 4503599627370496L;
/*     */   private static final int BQ_MASK = 2047;
/*     */   private static final long T_MASK = 4503599627370495L;
/*     */   private static final long MASK_63 = 9223372036854775807L;
/*     */   private static final int MASK_28 = 268435455;
/*     */   private static final int NON_SPECIAL = 0;
/*     */   private static final int PLUS_ZERO = 1;
/*     */   private static final int MINUS_ZERO = 2;
/*     */   private static final int PLUS_INF = 3;
/*     */   private static final int MINUS_INF = 4;
/*     */   private static final int NAN = 5;
/* 115 */   public final int MAX_CHARS = 24;
/*     */ 
/*     */   
/* 118 */   private final byte[] bytes = new byte[24];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int index;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(double v) {
/* 240 */     return (new DoubleToDecimal()).toDecimalString(v);
/*     */   }
/*     */   
/*     */   private String toDecimalString(double v) {
/* 244 */     switch (toDecimal(v)) { case 0:
/* 245 */         return charsToString();
/* 246 */       case 1: return "0.0";
/* 247 */       case 2: return "-0.0";
/* 248 */       case 3: return "Infinity";
/* 249 */       case 4: return "-Infinity"; }
/* 250 */      return "NaN";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int toDecimal(double v) {
/* 272 */     long bits = Double.doubleToRawLongBits(v);
/* 273 */     long t = bits & 0xFFFFFFFFFFFFFL;
/* 274 */     int bq = (int)(bits >>> 52L) & 0x7FF;
/* 275 */     if (bq < 2047) {
/* 276 */       this.index = -1;
/* 277 */       if (bits < 0L) {
/* 278 */         append(45);
/*     */       }
/* 280 */       if (bq != 0) {
/*     */         
/* 282 */         int mq = 1075 - bq;
/* 283 */         long c = 0x10000000000000L | t;
/*     */         
/* 285 */         if ((((0 < mq) ? 1 : 0) & ((mq < 53) ? 1 : 0)) != 0) {
/* 286 */           long f = c >> mq;
/* 287 */           if (f << mq == c) {
/* 288 */             return toChars(f, 0);
/*     */           }
/*     */         } 
/* 291 */         return toDecimal(-mq, c, 0);
/*     */       } 
/* 293 */       if (t != 0L)
/*     */       {
/* 295 */         return (t < 3L) ? 
/* 296 */           toDecimal(-1074, 10L * t, -1) : 
/* 297 */           toDecimal(-1074, t, 0);
/*     */       }
/* 299 */       return (bits == 0L) ? 1 : 2;
/*     */     } 
/* 301 */     if (t != 0L) {
/* 302 */       return 5;
/*     */     }
/* 304 */     return (bits > 0L) ? 3 : 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int toDecimal(int q, long c, int dk) {
/*     */     long cbl;
/* 325 */     int k, out = (int)c & 0x1;
/* 326 */     long cb = c << 2L;
/* 327 */     long cbr = cb + 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 335 */     if ((((c != 4503599627370496L) ? 1 : 0) | ((q == -1074) ? 1 : 0)) != 0) {
/*     */       
/* 337 */       cbl = cb - 2L;
/* 338 */       k = MathUtils.flog10pow2(q);
/*     */     } else {
/*     */       
/* 341 */       cbl = cb - 1L;
/* 342 */       k = MathUtils.flog10threeQuartersPow2(q);
/*     */     } 
/* 344 */     int h = q + MathUtils.flog2pow10(-k) + 2;
/*     */ 
/*     */     
/* 347 */     long g1 = MathUtils.g1(k);
/* 348 */     long g0 = MathUtils.g0(k);
/*     */     
/* 350 */     long vb = rop(g1, g0, cb << h);
/* 351 */     long vbl = rop(g1, g0, cbl << h);
/* 352 */     long vbr = rop(g1, g0, cbr << h);
/*     */     
/* 354 */     long s = vb >> 2L;
/* 355 */     if (s >= 100L) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 367 */       long sp10 = 10L * MathUtils.multiplyHigh(s, 1844674407370955168L);
/* 368 */       long tp10 = sp10 + 10L;
/* 369 */       boolean upin = (vbl + out <= sp10 << 2L);
/* 370 */       boolean wpin = ((tp10 << 2L) + out <= vbr);
/* 371 */       if (upin != wpin) {
/* 372 */         return toChars(upin ? sp10 : tp10, k);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 382 */     long t = s + 1L;
/* 383 */     boolean uin = (vbl + out <= s << 2L);
/* 384 */     boolean win = ((t << 2L) + out <= vbr);
/* 385 */     if (uin != win)
/*     */     {
/* 387 */       return toChars(uin ? s : t, k + dk);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 393 */     long cmp = vb - (s + t << 1L);
/* 394 */     return toChars((cmp < 0L || (cmp == 0L && (s & 0x1L) == 0L)) ? s : t, k + dk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static long rop(long g1, long g0, long cp) {
/* 402 */     long x1 = MathUtils.multiplyHigh(g0, cp);
/* 403 */     long y0 = g1 * cp;
/* 404 */     long y1 = MathUtils.multiplyHigh(g1, cp);
/* 405 */     long z = (y0 >>> 1L) + x1;
/* 406 */     long vbp = y1 + (z >>> 63L);
/* 407 */     return vbp | (z & Long.MAX_VALUE) + Long.MAX_VALUE >>> 63L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int toChars(long f, int e) {
/* 420 */     int len = MathUtils.flog10pow2(64 - Long.numberOfLeadingZeros(f));
/* 421 */     if (f >= MathUtils.pow10(len)) {
/* 422 */       len++;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 431 */     f *= MathUtils.pow10(17 - len);
/* 432 */     e += len;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 448 */     long hm = MathUtils.multiplyHigh(f, 193428131138340668L) >>> 20L;
/* 449 */     int l = (int)(f - 100000000L * hm);
/* 450 */     int h = (int)(hm * 1441151881L >>> 57L);
/* 451 */     int m = (int)(hm - (100000000 * h));
/*     */     
/* 453 */     if (0 < e && e <= 7) {
/* 454 */       return toChars1(h, m, l, e);
/*     */     }
/* 456 */     if (-3 < e && e <= 0) {
/* 457 */       return toChars2(h, m, l, e);
/*     */     }
/* 459 */     return toChars3(h, m, l, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int toChars1(int h, int m, int l, int e) {
/* 468 */     appendDigit(h);
/* 469 */     int y = y(m);
/*     */     
/* 471 */     int i = 1;
/* 472 */     for (; i < e; i++) {
/* 473 */       int t = 10 * y;
/* 474 */       appendDigit(t >>> 28);
/* 475 */       y = t & 0xFFFFFFF;
/*     */     } 
/* 477 */     append(46);
/* 478 */     for (; i <= 8; i++) {
/* 479 */       int t = 10 * y;
/* 480 */       appendDigit(t >>> 28);
/* 481 */       y = t & 0xFFFFFFF;
/*     */     } 
/* 483 */     lowDigits(l);
/* 484 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private int toChars2(int h, int m, int l, int e) {
/* 489 */     appendDigit(0);
/* 490 */     append(46);
/* 491 */     for (; e < 0; e++) {
/* 492 */       appendDigit(0);
/*     */     }
/* 494 */     appendDigit(h);
/* 495 */     append8Digits(m);
/* 496 */     lowDigits(l);
/* 497 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private int toChars3(int h, int m, int l, int e) {
/* 502 */     appendDigit(h);
/* 503 */     append(46);
/* 504 */     append8Digits(m);
/* 505 */     lowDigits(l);
/* 506 */     exponent(e - 1);
/* 507 */     return 0;
/*     */   }
/*     */   
/*     */   private void lowDigits(int l) {
/* 511 */     if (l != 0) {
/* 512 */       append8Digits(l);
/*     */     }
/* 514 */     removeTrailingZeroes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void append8Digits(int m) {
/* 522 */     int y = y(m);
/* 523 */     for (int i = 0; i < 8; i++) {
/* 524 */       int t = 10 * y;
/* 525 */       appendDigit(t >>> 28);
/* 526 */       y = t & 0xFFFFFFF;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void removeTrailingZeroes() {
/* 531 */     while (this.bytes[this.index] == 48) {
/* 532 */       this.index--;
/*     */     }
/*     */     
/* 535 */     if (this.bytes[this.index] == 46) {
/* 536 */       this.index++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int y(int a) {
/* 549 */     return (int)(MathUtils.multiplyHigh((a + 1) << 28L, 193428131138340668L) >>> 20L) - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void exponent(int e) {
/* 555 */     append(69);
/* 556 */     if (e < 0) {
/* 557 */       append(45);
/* 558 */       e = -e;
/*     */     } 
/* 560 */     if (e < 10) {
/* 561 */       appendDigit(e);
/*     */       
/*     */       return;
/*     */     } 
/* 565 */     if (e >= 100) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 570 */       int i = e * 1311 >>> 17;
/* 571 */       appendDigit(i);
/* 572 */       e -= 100 * i;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 578 */     int d = e * 103 >>> 10;
/* 579 */     appendDigit(d);
/* 580 */     appendDigit(e - 10 * d);
/*     */   }
/*     */   
/*     */   private void append(int c) {
/* 584 */     this.bytes[++this.index] = (byte)c;
/*     */   }
/*     */   
/*     */   private void appendDigit(int d) {
/* 588 */     this.bytes[++this.index] = (byte)(48 + d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String charsToString() {
/* 594 */     return new String(this.bytes, 0, 0, this.index + 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\io\schubfach\DoubleToDecimal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */