/*     */ package com.fasterxml.jackson.core.io.schubfach;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FloatToDecimal
/*     */ {
/*     */   static final int P = 24;
/*     */   private static final int W = 8;
/*     */   static final int Q_MIN = -149;
/*     */   static final int Q_MAX = 104;
/*     */   static final int E_MIN = -44;
/*     */   static final int E_MAX = 39;
/*     */   static final int C_TINY = 8;
/*     */   static final int K_MIN = -45;
/*     */   static final int K_MAX = 31;
/*     */   static final int H = 9;
/*     */   private static final int C_MIN = 8388608;
/*     */   private static final int BQ_MASK = 255;
/*     */   private static final int T_MASK = 8388607;
/*     */   private static final long MASK_32 = 4294967295L;
/*     */   private static final int MASK_28 = 268435455;
/*     */   private static final int NON_SPECIAL = 0;
/*     */   private static final int PLUS_ZERO = 1;
/*     */   private static final int MINUS_ZERO = 2;
/*     */   private static final int PLUS_INF = 3;
/*     */   private static final int MINUS_INF = 4;
/*     */   private static final int NAN = 5;
/* 114 */   public final int MAX_CHARS = 15;
/*     */ 
/*     */   
/* 117 */   private final byte[] bytes = new byte[15];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int index;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(float v) {
/* 239 */     return (new FloatToDecimal()).toDecimalString(v);
/*     */   }
/*     */   
/*     */   private String toDecimalString(float v) {
/* 243 */     switch (toDecimal(v)) { case 0:
/* 244 */         return charsToString();
/* 245 */       case 1: return "0.0";
/* 246 */       case 2: return "-0.0";
/* 247 */       case 3: return "Infinity";
/* 248 */       case 4: return "-Infinity"; }
/* 249 */      return "NaN";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int toDecimal(float v) {
/* 271 */     int bits = Float.floatToRawIntBits(v);
/* 272 */     int t = bits & 0x7FFFFF;
/* 273 */     int bq = bits >>> 23 & 0xFF;
/* 274 */     if (bq < 255) {
/* 275 */       this.index = -1;
/* 276 */       if (bits < 0) {
/* 277 */         append(45);
/*     */       }
/* 279 */       if (bq != 0) {
/*     */         
/* 281 */         int mq = 150 - bq;
/* 282 */         int c = 0x800000 | t;
/*     */         
/* 284 */         if ((((0 < mq) ? 1 : 0) & ((mq < 24) ? 1 : 0)) != 0) {
/* 285 */           int f = c >> mq;
/* 286 */           if (f << mq == c) {
/* 287 */             return toChars(f, 0);
/*     */           }
/*     */         } 
/* 290 */         return toDecimal(-mq, c, 0);
/*     */       } 
/* 292 */       if (t != 0)
/*     */       {
/* 294 */         return (t < 8) ? 
/* 295 */           toDecimal(-149, 10 * t, -1) : 
/* 296 */           toDecimal(-149, t, 0);
/*     */       }
/* 298 */       return (bits == 0) ? 1 : 2;
/*     */     } 
/* 300 */     if (t != 0) {
/* 301 */       return 5;
/*     */     }
/* 303 */     return (bits > 0) ? 3 : 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int toDecimal(int q, int c, int dk) {
/*     */     long cbl;
/* 325 */     int k, out = c & 0x1;
/* 326 */     long cb = (c << 2);
/* 327 */     long cbr = cb + 2L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 335 */     if ((((c != 8388608) ? 1 : 0) | ((q == -149) ? 1 : 0)) != 0) {
/*     */       
/* 337 */       cbl = cb - 2L;
/* 338 */       k = MathUtils.flog10pow2(q);
/*     */     } else {
/*     */       
/* 341 */       cbl = cb - 1L;
/* 342 */       k = MathUtils.flog10threeQuartersPow2(q);
/*     */     } 
/* 344 */     int h = q + MathUtils.flog2pow10(-k) + 33;
/*     */ 
/*     */     
/* 347 */     long g = MathUtils.g1(k) + 1L;
/*     */     
/* 349 */     int vb = rop(g, cb << h);
/* 350 */     int vbl = rop(g, cbl << h);
/* 351 */     int vbr = rop(g, cbr << h);
/*     */     
/* 353 */     int s = vb >> 2;
/* 354 */     if (s >= 100) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 365 */       int sp10 = 10 * (int)(s * 1717986919L >>> 34L);
/* 366 */       int tp10 = sp10 + 10;
/* 367 */       boolean upin = (vbl + out <= sp10 << 2);
/* 368 */       boolean wpin = ((tp10 << 2) + out <= vbr);
/* 369 */       if (upin != wpin) {
/* 370 */         return toChars(upin ? sp10 : tp10, k);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 380 */     int t = s + 1;
/* 381 */     boolean uin = (vbl + out <= s << 2);
/* 382 */     boolean win = ((t << 2) + out <= vbr);
/* 383 */     if (uin != win)
/*     */     {
/* 385 */       return toChars(uin ? s : t, k + dk);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 391 */     int cmp = vb - (s + t << 1);
/* 392 */     return toChars((cmp < 0 || (cmp == 0 && (s & 0x1) == 0)) ? s : t, k + dk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int rop(long g, long cp) {
/* 400 */     long x1 = MathUtils.multiplyHigh(g, cp);
/* 401 */     long vbp = x1 >>> 31L;
/* 402 */     return (int)(vbp | (x1 & 0xFFFFFFFFL) + 4294967295L >>> 32L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int toChars(int f, int e) {
/* 415 */     int len = MathUtils.flog10pow2(32 - Integer.numberOfLeadingZeros(f));
/* 416 */     if (f >= MathUtils.pow10(len)) {
/* 417 */       len++;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 426 */     f = (int)(f * MathUtils.pow10(9 - len));
/* 427 */     e += len;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 439 */     int h = (int)(f * 1441151881L >>> 57L);
/* 440 */     int l = f - 100000000 * h;
/*     */     
/* 442 */     if (0 < e && e <= 7) {
/* 443 */       return toChars1(h, l, e);
/*     */     }
/* 445 */     if (-3 < e && e <= 0) {
/* 446 */       return toChars2(h, l, e);
/*     */     }
/* 448 */     return toChars3(h, l, e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int toChars1(int h, int l, int e) {
/* 457 */     appendDigit(h);
/* 458 */     int y = y(l);
/*     */     
/* 460 */     int i = 1;
/* 461 */     for (; i < e; i++) {
/* 462 */       int t = 10 * y;
/* 463 */       appendDigit(t >>> 28);
/* 464 */       y = t & 0xFFFFFFF;
/*     */     } 
/* 466 */     append(46);
/* 467 */     for (; i <= 8; i++) {
/* 468 */       int t = 10 * y;
/* 469 */       appendDigit(t >>> 28);
/* 470 */       y = t & 0xFFFFFFF;
/*     */     } 
/* 472 */     removeTrailingZeroes();
/* 473 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private int toChars2(int h, int l, int e) {
/* 478 */     appendDigit(0);
/* 479 */     append(46);
/* 480 */     for (; e < 0; e++) {
/* 481 */       appendDigit(0);
/*     */     }
/* 483 */     appendDigit(h);
/* 484 */     append8Digits(l);
/* 485 */     removeTrailingZeroes();
/* 486 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private int toChars3(int h, int l, int e) {
/* 491 */     appendDigit(h);
/* 492 */     append(46);
/* 493 */     append8Digits(l);
/* 494 */     removeTrailingZeroes();
/* 495 */     exponent(e - 1);
/* 496 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void append8Digits(int m) {
/* 504 */     int y = y(m);
/* 505 */     for (int i = 0; i < 8; i++) {
/* 506 */       int t = 10 * y;
/* 507 */       appendDigit(t >>> 28);
/* 508 */       y = t & 0xFFFFFFF;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void removeTrailingZeroes() {
/* 513 */     while (this.bytes[this.index] == 48) {
/* 514 */       this.index--;
/*     */     }
/*     */     
/* 517 */     if (this.bytes[this.index] == 46) {
/* 518 */       this.index++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int y(int a) {
/* 531 */     return (int)(MathUtils.multiplyHigh((a + 1) << 28L, 193428131138340668L) >>> 20L) - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void exponent(int e) {
/* 537 */     append(69);
/* 538 */     if (e < 0) {
/* 539 */       append(45);
/* 540 */       e = -e;
/*     */     } 
/* 542 */     if (e < 10) {
/* 543 */       appendDigit(e);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 550 */     int d = e * 103 >>> 10;
/* 551 */     appendDigit(d);
/* 552 */     appendDigit(e - 10 * d);
/*     */   }
/*     */   
/*     */   private void append(int c) {
/* 556 */     this.bytes[++this.index] = (byte)c;
/*     */   }
/*     */   
/*     */   private void appendDigit(int d) {
/* 560 */     this.bytes[++this.index] = (byte)(48 + d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String charsToString() {
/* 566 */     return new String(this.bytes, 0, 0, this.index + 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\io\schubfach\FloatToDecimal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */