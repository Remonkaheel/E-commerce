/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import com.fasterxml.jackson.core.internal.shaded.fdp.v2_19_2.JavaDoubleParser;
/*     */ import com.fasterxml.jackson.core.internal.shaded.fdp.v2_19_2.JavaFloatParser;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NumberInput
/*     */ {
/*     */   @Deprecated
/*     */   public static final String NASTY_SMALL_DOUBLE = "2.2250738585072012e-308";
/*     */   static final long L_BILLION = 1000000000L;
/*  32 */   static final String MIN_LONG_STR_NO_SIGN = String.valueOf(Long.MIN_VALUE).substring(1);
/*  33 */   static final String MAX_LONG_STR = String.valueOf(Long.MAX_VALUE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   private static final Pattern PATTERN_FLOAT = Pattern.compile("[+-]?[0-9]*[\\.]?[0-9]+([eE][+-]?[0-9]+)?");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private static final Pattern PATTERN_FLOAT_TRAILING_DOT = Pattern.compile("[+-]?[0-9]+[\\.]");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int parseInt(char[] ch, int off, int len) {
/*  70 */     if (len > 0 && ch[off] == '+') {
/*  71 */       off++;
/*  72 */       len--;
/*     */     } 
/*     */     
/*  75 */     int num = ch[off + len - 1] - 48;
/*     */     
/*  77 */     switch (len) {
/*     */       case 9:
/*  79 */         num += (ch[off++] - 48) * 100000000;
/*     */       case 8:
/*  81 */         num += (ch[off++] - 48) * 10000000;
/*     */       case 7:
/*  83 */         num += (ch[off++] - 48) * 1000000;
/*     */       case 6:
/*  85 */         num += (ch[off++] - 48) * 100000;
/*     */       case 5:
/*  87 */         num += (ch[off++] - 48) * 10000;
/*     */       case 4:
/*  89 */         num += (ch[off++] - 48) * 1000;
/*     */       case 3:
/*  91 */         num += (ch[off++] - 48) * 100;
/*     */       case 2:
/*  93 */         num += (ch[off] - 48) * 10; break;
/*     */     } 
/*  95 */     return num;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int parseInt(String s) {
/* 117 */     char c = s.charAt(0);
/* 118 */     int len = s.length();
/* 119 */     boolean neg = (c == '-');
/* 120 */     int offset = 1;
/*     */ 
/*     */     
/* 123 */     if (neg) {
/* 124 */       if (len == 1 || len > 10) {
/* 125 */         return Integer.parseInt(s);
/*     */       }
/* 127 */       c = s.charAt(offset++);
/*     */     }
/* 129 */     else if (len > 9) {
/* 130 */       return Integer.parseInt(s);
/*     */     } 
/*     */     
/* 133 */     if (c > '9' || c < '0') {
/* 134 */       return Integer.parseInt(s);
/*     */     }
/* 136 */     int num = c - 48;
/* 137 */     if (offset < len) {
/* 138 */       c = s.charAt(offset++);
/* 139 */       if (c > '9' || c < '0') {
/* 140 */         return Integer.parseInt(s);
/*     */       }
/* 142 */       num = num * 10 + c - 48;
/* 143 */       if (offset < len) {
/* 144 */         c = s.charAt(offset++);
/* 145 */         if (c > '9' || c < '0') {
/* 146 */           return Integer.parseInt(s);
/*     */         }
/* 148 */         num = num * 10 + c - 48;
/*     */         
/* 150 */         if (offset < len) {
/*     */           do {
/* 152 */             c = s.charAt(offset++);
/* 153 */             if (c > '9' || c < '0') {
/* 154 */               return Integer.parseInt(s);
/*     */             }
/* 156 */             num = num * 10 + c - 48;
/* 157 */           } while (offset < len);
/*     */         }
/*     */       } 
/*     */     } 
/* 161 */     return neg ? -num : num;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static long parseLong(char[] ch, int off, int len) {
/* 167 */     int len1 = len - 9;
/* 168 */     long val = parseInt(ch, off, len1) * 1000000000L;
/* 169 */     return val + parseInt(ch, off + len1, 9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long parseLong19(char[] ch, int off, boolean negative) {
/* 192 */     long num = 0L;
/* 193 */     for (int i = 0; i < 19; i++) {
/* 194 */       char c = ch[off + i];
/* 195 */       num = num * 10L + (c - 48);
/*     */     } 
/* 197 */     return negative ? -num : num;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static long parseLong(String s) {
/* 211 */     int length = s.length();
/* 212 */     if (length <= 9) {
/* 213 */       return parseInt(s);
/*     */     }
/*     */     
/* 216 */     return Long.parseLong(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean inLongRange(char[] ch, int off, int len, boolean negative) {
/* 237 */     String cmpStr = negative ? MIN_LONG_STR_NO_SIGN : MAX_LONG_STR;
/* 238 */     int cmpLen = cmpStr.length();
/* 239 */     if (len < cmpLen) return true; 
/* 240 */     if (len > cmpLen) return false;
/*     */     
/* 242 */     for (int i = 0; i < cmpLen; i++) {
/* 243 */       int diff = ch[off + i] - cmpStr.charAt(i);
/* 244 */       if (diff != 0) {
/* 245 */         return (diff < 0);
/*     */       }
/*     */     } 
/* 248 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean inLongRange(String s, boolean negative) {
/* 264 */     String cmp = negative ? MIN_LONG_STR_NO_SIGN : MAX_LONG_STR;
/* 265 */     int cmpLen = cmp.length();
/* 266 */     int alen = s.length();
/* 267 */     if (alen < cmpLen) return true; 
/* 268 */     if (alen > cmpLen) return false;
/*     */ 
/*     */     
/* 271 */     for (int i = 0; i < cmpLen; i++) {
/* 272 */       int diff = s.charAt(i) - cmp.charAt(i);
/* 273 */       if (diff != 0) {
/* 274 */         return (diff < 0);
/*     */       }
/*     */     } 
/* 277 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int parseAsInt(String s, int def) {
/* 282 */     if (s == null) {
/* 283 */       return def;
/*     */     }
/* 285 */     s = s.trim();
/* 286 */     int len = s.length();
/* 287 */     if (len == 0) {
/* 288 */       return def;
/*     */     }
/*     */     
/* 291 */     int i = 0;
/*     */     
/* 293 */     char sign = s.charAt(0);
/* 294 */     if (sign == '+') {
/* 295 */       s = s.substring(1);
/* 296 */       len = s.length();
/* 297 */     } else if (sign == '-') {
/* 298 */       i = 1;
/*     */     } 
/* 300 */     for (; i < len; i++) {
/* 301 */       char c = s.charAt(i);
/*     */       
/* 303 */       if (c > '9' || c < '0') {
/*     */         
/*     */         try {
/*     */           
/* 307 */           return (int)parseDouble(s, true);
/* 308 */         } catch (NumberFormatException e) {
/* 309 */           return def;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     try {
/* 314 */       return Integer.parseInt(s);
/* 315 */     } catch (NumberFormatException numberFormatException) {
/* 316 */       return def;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static long parseAsLong(String s, long def) {
/* 321 */     if (s == null) {
/* 322 */       return def;
/*     */     }
/* 324 */     s = s.trim();
/* 325 */     int len = s.length();
/* 326 */     if (len == 0) {
/* 327 */       return def;
/*     */     }
/*     */     
/* 330 */     int i = 0;
/*     */     
/* 332 */     char sign = s.charAt(0);
/* 333 */     if (sign == '+') {
/* 334 */       s = s.substring(1);
/* 335 */       len = s.length();
/* 336 */     } else if (sign == '-') {
/* 337 */       i = 1;
/*     */     } 
/* 339 */     for (; i < len; i++) {
/* 340 */       char c = s.charAt(i);
/*     */       
/* 342 */       if (c > '9' || c < '0') {
/*     */         
/*     */         try {
/*     */           
/* 346 */           return (long)parseDouble(s, true);
/* 347 */         } catch (NumberFormatException e) {
/* 348 */           return def;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     try {
/* 353 */       return Long.parseLong(s);
/* 354 */     } catch (NumberFormatException numberFormatException) {
/* 355 */       return def;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double parseAsDouble(String s, double def) {
/* 366 */     return parseAsDouble(s, def, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double parseAsDouble(String s, double def, boolean useFastParser) {
/* 378 */     if (s == null) return def; 
/* 379 */     s = s.trim();
/* 380 */     if (s.isEmpty()) {
/* 381 */       return def;
/*     */     }
/*     */     try {
/* 384 */       return parseDouble(s, useFastParser);
/* 385 */     } catch (NumberFormatException numberFormatException) {
/* 386 */       return def;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static double parseDouble(String s) throws NumberFormatException {
/* 399 */     return parseDouble(s, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double parseDouble(String s, boolean useFastParser) throws NumberFormatException {
/* 410 */     return useFastParser ? JavaDoubleParser.parseDouble(s) : Double.parseDouble(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double parseDouble(char[] array, boolean useFastParser) throws NumberFormatException {
/* 421 */     return parseDouble(array, 0, array.length, useFastParser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static double parseDouble(char[] array, int offset, int len, boolean useFastParser) throws NumberFormatException {
/* 435 */     return useFastParser ? JavaDoubleParser.parseDouble(array, offset, len) : 
/* 436 */       Double.parseDouble(new String(array, offset, len));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static float parseFloat(String s) throws NumberFormatException {
/* 450 */     return parseFloat(s, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float parseFloat(String s, boolean useFastParser) throws NumberFormatException {
/* 461 */     if (useFastParser) {
/* 462 */       return JavaFloatParser.parseFloat(s);
/*     */     }
/* 464 */     return Float.parseFloat(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float parseFloat(char[] array, boolean useFastParser) throws NumberFormatException {
/* 475 */     return parseFloat(array, 0, array.length, useFastParser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static float parseFloat(char[] array, int offset, int len, boolean useFastParser) throws NumberFormatException {
/* 489 */     return useFastParser ? JavaFloatParser.parseFloat(array, offset, len) : 
/* 490 */       Float.parseFloat(new String(array, offset, len));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static BigDecimal parseBigDecimal(String s) throws NumberFormatException {
/* 502 */     return parseBigDecimal(s, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal parseBigDecimal(String s, boolean useFastParser) throws NumberFormatException {
/* 513 */     if (useFastParser) {
/* 514 */       return BigDecimalParser.parseWithFastParser(s);
/*     */     }
/* 516 */     return BigDecimalParser.parse(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static BigDecimal parseBigDecimal(char[] ch, int off, int len) throws NumberFormatException {
/* 530 */     return BigDecimalParser.parse(ch, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal parseBigDecimal(char[] ch, int off, int len, boolean useFastParser) throws NumberFormatException {
/* 546 */     if (useFastParser) {
/* 547 */       return BigDecimalParser.parseWithFastParser(ch, off, len);
/*     */     }
/* 549 */     return BigDecimalParser.parse(ch, off, len);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static BigDecimal parseBigDecimal(char[] ch) throws NumberFormatException {
/* 561 */     return BigDecimalParser.parse(ch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal parseBigDecimal(char[] ch, boolean useFastParser) throws NumberFormatException {
/* 572 */     if (useFastParser) {
/* 573 */       return BigDecimalParser.parseWithFastParser(ch, 0, ch.length);
/*     */     }
/* 575 */     return BigDecimalParser.parse(ch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static BigInteger parseBigInteger(String s) throws NumberFormatException {
/* 588 */     return parseBigInteger(s, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigInteger parseBigInteger(String s, boolean useFastParser) throws NumberFormatException {
/* 599 */     if (useFastParser) {
/* 600 */       return BigIntegerParser.parseWithFastParser(s);
/*     */     }
/* 602 */     return new BigInteger(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigInteger parseBigIntegerWithRadix(String s, int radix, boolean useFastParser) throws NumberFormatException {
/* 615 */     if (useFastParser) {
/* 616 */       return BigIntegerParser.parseWithFastParser(s, radix);
/*     */     }
/* 618 */     return new BigInteger(s, radix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean looksLikeValidNumber(String s) {
/* 648 */     if (s == null || s.isEmpty()) {
/* 649 */       return false;
/*     */     }
/* 651 */     if (s.length() == 1) {
/* 652 */       char c = s.charAt(0);
/* 653 */       return (c <= '9' && c >= '0');
/*     */     } 
/* 655 */     return (PATTERN_FLOAT.matcher(s).matches() || PATTERN_FLOAT_TRAILING_DOT
/* 656 */       .matcher(s).matches());
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\io\NumberInput.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */