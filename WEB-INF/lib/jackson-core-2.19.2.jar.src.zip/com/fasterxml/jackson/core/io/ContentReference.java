/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import com.fasterxml.jackson.core.ErrorReportConfiguration;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ContentReference
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  34 */   protected static final ContentReference UNKNOWN_CONTENT = new ContentReference(false, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   protected static final ContentReference REDACTED_CONTENT = new ContentReference(false, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final int DEFAULT_MAX_CONTENT_SNIPPET = 500;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final transient Object _rawContent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _offset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _length;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean _isContentTextual;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _maxRawContentLength;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected ContentReference(boolean isContentTextual, Object rawContent) {
/* 106 */     this(isContentTextual, rawContent, -1, -1, ErrorReportConfiguration.defaults());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected ContentReference(boolean isContentTextual, Object rawContent, int offset, int length) {
/* 121 */     this(isContentTextual, rawContent, offset, length, ErrorReportConfiguration.defaults());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ContentReference(boolean isContentTextual, Object rawContent, ErrorReportConfiguration errorReportConfiguration) {
/* 128 */     this(isContentTextual, rawContent, -1, -1, errorReportConfiguration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ContentReference(boolean isContentTextual, Object rawContent, int offset, int length, ErrorReportConfiguration errorReportConfiguration) {
/* 135 */     this._isContentTextual = isContentTextual;
/* 136 */     this._rawContent = rawContent;
/* 137 */     this._offset = offset;
/* 138 */     this._length = length;
/* 139 */     this._maxRawContentLength = errorReportConfiguration.getMaxRawContentLength();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ContentReference unknown() {
/* 150 */     return UNKNOWN_CONTENT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ContentReference redacted() {
/* 164 */     return REDACTED_CONTENT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static ContentReference construct(boolean isContentTextual, Object rawContent) {
/* 173 */     return new ContentReference(isContentTextual, rawContent, ErrorReportConfiguration.defaults());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static ContentReference construct(boolean isContentTextual, Object rawContent, int offset, int length) {
/* 182 */     return new ContentReference(isContentTextual, rawContent, offset, length, ErrorReportConfiguration.defaults());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ContentReference construct(boolean isContentTextual, Object rawContent, int offset, int length, ErrorReportConfiguration errorReportConfiguration) {
/* 191 */     return new ContentReference(isContentTextual, rawContent, offset, length, errorReportConfiguration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ContentReference construct(boolean isContentTextual, Object rawContent, ErrorReportConfiguration errorReportConfiguration) {
/* 200 */     return new ContentReference(isContentTextual, rawContent, errorReportConfiguration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ContentReference rawReference(boolean isContentTextual, Object rawContent) {
/* 219 */     if (rawContent instanceof ContentReference) {
/* 220 */       return (ContentReference)rawContent;
/*     */     }
/* 222 */     return new ContentReference(isContentTextual, rawContent);
/*     */   }
/*     */   
/*     */   public static ContentReference rawReference(Object rawContent) {
/* 226 */     return rawReference(false, rawContent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object readResolve() {
/* 247 */     return UNKNOWN_CONTENT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasTextualContent() {
/* 257 */     return this._isContentTextual;
/*     */   }
/*     */   
/*     */   public Object getRawContent() {
/* 261 */     return this._rawContent;
/*     */   }
/*     */   
/* 264 */   public int contentOffset() { return this._offset; } public int contentLength() {
/* 265 */     return this._length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int maxRawContentLength() {
/* 276 */     return this._maxRawContentLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String buildSourceDescription() {
/* 292 */     return appendSourceDescription(new StringBuilder(200)).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder appendSourceDescription(StringBuilder sb) {
/* 305 */     Object srcRef = getRawContent();
/*     */     
/* 307 */     if (srcRef == null) {
/* 308 */       if (this == REDACTED_CONTENT) {
/* 309 */         sb.append("REDACTED (`StreamReadFeature.INCLUDE_SOURCE_IN_LOCATION` disabled)");
/*     */       } else {
/* 311 */         sb.append("UNKNOWN");
/*     */       } 
/* 313 */       return sb;
/*     */     } 
/*     */ 
/*     */     
/* 317 */     Class<?> srcType = (srcRef instanceof Class) ? (Class)srcRef : srcRef.getClass();
/* 318 */     String tn = srcType.getName();
/*     */     
/* 320 */     if (tn.startsWith("java.")) {
/* 321 */       tn = srcType.getSimpleName();
/* 322 */     } else if (srcRef instanceof byte[]) {
/* 323 */       tn = "byte[]";
/* 324 */     } else if (srcRef instanceof char[]) {
/* 325 */       tn = "char[]";
/*     */     } 
/* 327 */     sb.append('(').append(tn).append(')');
/*     */ 
/*     */ 
/*     */     
/* 331 */     if (hasTextualContent()) {
/* 332 */       String trimmed, unitStr = " chars";
/*     */ 
/*     */ 
/*     */       
/* 336 */       int maxLen = maxRawContentLength();
/* 337 */       int[] offsets = { contentOffset(), contentLength() };
/*     */       
/* 339 */       if (srcRef instanceof CharSequence) {
/* 340 */         trimmed = _truncate((CharSequence)srcRef, offsets, maxLen);
/* 341 */       } else if (srcRef instanceof char[]) {
/* 342 */         trimmed = _truncate((char[])srcRef, offsets, maxLen);
/* 343 */       } else if (srcRef instanceof byte[]) {
/* 344 */         trimmed = _truncate((byte[])srcRef, offsets, maxLen);
/* 345 */         unitStr = " bytes";
/*     */       } else {
/* 347 */         trimmed = null;
/*     */       } 
/* 349 */       if (trimmed != null) {
/* 350 */         _append(sb, trimmed);
/* 351 */         if (offsets[1] > maxLen) {
/* 352 */           sb.append("[truncated ").append(offsets[1] - maxLen).append(unitStr).append(']');
/*     */         }
/*     */       }
/*     */     
/*     */     }
/* 357 */     else if (srcRef instanceof byte[]) {
/* 358 */       int length = contentLength();
/*     */       
/* 360 */       if (length < 0) {
/* 361 */         length = ((byte[])srcRef).length;
/*     */       }
/* 363 */       sb.append('[')
/* 364 */         .append(length)
/* 365 */         .append(" bytes]");
/*     */     } 
/*     */     
/* 368 */     return sb;
/*     */   }
/*     */   
/*     */   protected String _truncate(CharSequence cs, int[] offsets, int maxSnippetLen) {
/* 372 */     _truncateOffsets(offsets, cs.length());
/* 373 */     int start = offsets[0];
/* 374 */     int length = Math.min(offsets[1], maxSnippetLen);
/* 375 */     return cs.subSequence(start, start + length).toString();
/*     */   }
/*     */   
/*     */   protected String _truncate(char[] cs, int[] offsets, int maxSnippetLen) {
/* 379 */     _truncateOffsets(offsets, cs.length);
/* 380 */     int start = offsets[0];
/* 381 */     int length = Math.min(offsets[1], maxSnippetLen);
/* 382 */     return new String(cs, start, length);
/*     */   }
/*     */   
/*     */   protected String _truncate(byte[] b, int[] offsets, int maxSnippetLen) {
/* 386 */     _truncateOffsets(offsets, b.length);
/* 387 */     int start = offsets[0];
/* 388 */     int length = Math.min(offsets[1], maxSnippetLen);
/* 389 */     return new String(b, start, length, StandardCharsets.UTF_8);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _truncateOffsets(int[] offsets, int actualLength) {
/* 395 */     int start = offsets[0];
/*     */     
/* 397 */     if (start < 0) {
/* 398 */       start = 0;
/* 399 */     } else if (start >= actualLength) {
/* 400 */       start = actualLength;
/*     */     } 
/* 402 */     offsets[0] = start;
/*     */ 
/*     */     
/* 405 */     int length = offsets[1];
/* 406 */     int maxLength = actualLength - start;
/* 407 */     if (length < 0 || length > maxLength) {
/* 408 */       offsets[1] = maxLength;
/*     */     }
/*     */   }
/*     */   
/*     */   protected int _append(StringBuilder sb, String content) {
/* 413 */     sb.append('"');
/*     */     
/* 415 */     for (int i = 0, end = content.length(); i < end; i++) {
/*     */ 
/*     */ 
/*     */       
/* 419 */       char ch = content.charAt(i);
/* 420 */       if (!Character.isISOControl(ch) || !_appendEscaped(sb, ch)) {
/* 421 */         sb.append(ch);
/*     */       }
/*     */     } 
/* 424 */     sb.append('"');
/* 425 */     return content.length();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean _appendEscaped(StringBuilder sb, int ctrlChar) {
/* 430 */     if (ctrlChar == 13 || ctrlChar == 10) {
/* 431 */       return false;
/*     */     }
/* 433 */     sb.append('\\');
/* 434 */     sb.append('u');
/* 435 */     sb.append(CharTypes.hexToChar(ctrlChar >> 12 & 0xF));
/* 436 */     sb.append(CharTypes.hexToChar(ctrlChar >> 8 & 0xF));
/* 437 */     sb.append(CharTypes.hexToChar(ctrlChar >> 4 & 0xF));
/* 438 */     sb.append(CharTypes.hexToChar(ctrlChar & 0xF));
/* 439 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 454 */     if (other == this) return true; 
/* 455 */     if (other == null) return false; 
/* 456 */     if (!(other instanceof ContentReference)) return false; 
/* 457 */     ContentReference otherSrc = (ContentReference)other;
/*     */ 
/*     */     
/* 460 */     if (this._offset != otherSrc._offset || this._length != otherSrc._length)
/*     */     {
/* 462 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 468 */     Object otherRaw = otherSrc._rawContent;
/*     */     
/* 470 */     if (this._rawContent == null)
/* 471 */       return (otherRaw == null); 
/* 472 */     if (otherRaw == null) {
/* 473 */       return false;
/*     */     }
/*     */     
/* 476 */     if (this._rawContent instanceof java.io.File || this._rawContent instanceof java.net.URL || this._rawContent instanceof java.net.URI)
/*     */     {
/*     */ 
/*     */       
/* 480 */       return this._rawContent.equals(otherRaw);
/*     */     }
/* 482 */     return (this._rawContent == otherSrc._rawContent);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 488 */     return Objects.hashCode(this._rawContent);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\io\ContentReference.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */