/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import com.fasterxml.jackson.core.internal.shaded.fdp.v2_19_2.JavaBigDecimalParser;
/*     */ import java.math.BigDecimal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BigDecimalParser
/*     */ {
/*     */   static final int MAX_CHARS_TO_REPORT = 1000;
/*     */   private static final int SIZE_FOR_SWITCH_TO_FASTDOUBLEPARSER = 500;
/*     */   
/*     */   public static BigDecimal parse(String valueStr) {
/*     */     try {
/*  45 */       if (valueStr.length() < 500) {
/*  46 */         return new BigDecimal(valueStr);
/*     */       }
/*  48 */       return JavaBigDecimalParser.parseBigDecimal(valueStr);
/*     */ 
/*     */     
/*     */     }
/*  52 */     catch (ArithmeticException|NumberFormatException e) {
/*  53 */       throw _parseFailure(e, valueStr);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal parse(char[] chars, int off, int len) {
/*     */     try {
/*  69 */       if (len < 500) {
/*  70 */         return new BigDecimal(chars, off, len);
/*     */       }
/*  72 */       return JavaBigDecimalParser.parseBigDecimal(chars, off, len);
/*     */ 
/*     */     
/*     */     }
/*  76 */     catch (ArithmeticException|NumberFormatException e) {
/*  77 */       throw _parseFailure(e, chars, off, len);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal parse(char[] chars) {
/*  93 */     return parse(chars, 0, chars.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal parseWithFastParser(String valueStr) {
/*     */     try {
/* 109 */       return JavaBigDecimalParser.parseBigDecimal(valueStr);
/* 110 */     } catch (ArithmeticException|NumberFormatException e) {
/* 111 */       throw _parseFailure(e, valueStr);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BigDecimal parseWithFastParser(char[] ch, int off, int len) {
/*     */     try {
/* 127 */       return JavaBigDecimalParser.parseBigDecimal(ch, off, len);
/* 128 */     } catch (ArithmeticException|NumberFormatException e) {
/* 129 */       throw _parseFailure(e, ch, off, len);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static NumberFormatException _parseFailure(Exception e, String fullValue) {
/* 134 */     String desc = e.getMessage();
/*     */     
/* 136 */     if (desc == null) {
/* 137 */       desc = "Not a valid number representation";
/*     */     }
/* 139 */     String valueToReport = _getValueDesc(fullValue);
/* 140 */     return new NumberFormatException(_generateExceptionMessage(valueToReport, desc));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static NumberFormatException _parseFailure(Exception e, char[] array, int offset, int len) {
/* 147 */     String desc = e.getMessage();
/*     */     
/* 149 */     if (desc == null) {
/* 150 */       desc = "Not a valid number representation";
/*     */     }
/* 152 */     String valueToReport = _getValueDesc(array, offset, len);
/* 153 */     return new NumberFormatException(_generateExceptionMessage(valueToReport, desc));
/*     */   }
/*     */   
/*     */   private static String _getValueDesc(String fullValue) {
/* 157 */     int len = fullValue.length();
/* 158 */     if (len <= 1000) {
/* 159 */       return String.format("\"%s\"", new Object[] { fullValue });
/*     */     }
/* 161 */     return String.format("\"%s\" (truncated to %d chars (from %d))", new Object[] { fullValue
/* 162 */           .substring(0, 1000), 
/* 163 */           Integer.valueOf(1000), Integer.valueOf(len) });
/*     */   }
/*     */   
/*     */   private static String _getValueDesc(char[] array, int offset, int len) {
/* 167 */     if (len <= 1000) {
/* 168 */       return String.format("\"%s\"", new Object[] { new String(array, offset, len) });
/*     */     }
/* 170 */     return String.format("\"%s\" (truncated to %d chars (from %d))", new Object[] { new String(array, offset, 1000), 
/*     */           
/* 172 */           Integer.valueOf(1000), Integer.valueOf(len) });
/*     */   }
/*     */   
/*     */   private static String _generateExceptionMessage(String valueToReport, String desc) {
/* 176 */     return String.format("Value %s can not be deserialized as `java.math.BigDecimal`, reason:  %s", new Object[] { valueToReport, desc });
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\io\BigDecimalParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */