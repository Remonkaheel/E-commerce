/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class UTF8Writer
/*     */   extends Writer
/*     */ {
/*     */   static final int SURR1_FIRST = 55296;
/*     */   static final int SURR1_LAST = 56319;
/*     */   static final int SURR2_FIRST = 56320;
/*     */   static final int SURR2_LAST = 57343;
/*     */   public static final int SURROGATE_BASE = -56613888;
/*     */   private final IOContext _context;
/*     */   private OutputStream _out;
/*     */   private byte[] _outBuffer;
/*     */   private final int _outBufferEnd;
/*     */   private int _outPtr;
/*     */   private int _surrogate;
/*     */   
/*     */   public UTF8Writer(IOContext ctxt, OutputStream out) {
/*  36 */     this._context = ctxt;
/*  37 */     this._out = out;
/*     */     
/*  39 */     this._outBuffer = ctxt.allocWriteEncodingBuffer();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  44 */     this._outBufferEnd = this._outBuffer.length - 4;
/*  45 */     this._outPtr = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Writer append(char c) throws IOException {
/*  52 */     write(c);
/*  53 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/*  60 */     if (this._out != null) {
/*  61 */       if (this._outPtr > 0) {
/*  62 */         this._out.write(this._outBuffer, 0, this._outPtr);
/*  63 */         this._outPtr = 0;
/*     */       } 
/*  65 */       OutputStream out = this._out;
/*  66 */       this._out = null;
/*     */       
/*  68 */       byte[] buf = this._outBuffer;
/*  69 */       if (buf != null) {
/*  70 */         this._outBuffer = null;
/*  71 */         this._context.releaseWriteEncodingBuffer(buf);
/*     */       } 
/*     */       
/*  74 */       out.close();
/*     */ 
/*     */ 
/*     */       
/*  78 */       int code = this._surrogate;
/*  79 */       this._surrogate = 0;
/*  80 */       if (code > 0) {
/*  81 */         illegalSurrogate(code);
/*     */       }
/*     */     } 
/*  84 */     this._context.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/*  91 */     if (this._out != null) {
/*  92 */       if (this._outPtr > 0) {
/*  93 */         this._out.write(this._outBuffer, 0, this._outPtr);
/*  94 */         this._outPtr = 0;
/*     */       } 
/*  96 */       this._out.flush();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(char[] cbuf) throws IOException {
/* 104 */     write(cbuf, 0, cbuf.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(char[] cbuf, int off, int len) throws IOException {
/* 111 */     if (len < 2) {
/* 112 */       if (len == 1) {
/* 113 */         write(cbuf[off]);
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 119 */     if (this._surrogate > 0) {
/* 120 */       char second = cbuf[off++];
/* 121 */       len--;
/* 122 */       write(convertSurrogate(second));
/*     */     } 
/*     */ 
/*     */     
/* 126 */     int outPtr = this._outPtr;
/* 127 */     byte[] outBuf = this._outBuffer;
/* 128 */     int outBufLast = this._outBufferEnd;
/*     */ 
/*     */     
/* 131 */     len += off;
/*     */ 
/*     */     
/* 134 */     label45: while (off < len) {
/*     */ 
/*     */ 
/*     */       
/* 138 */       if (outPtr >= outBufLast) {
/* 139 */         this._out.write(outBuf, 0, outPtr);
/* 140 */         outPtr = 0;
/*     */       } 
/*     */       
/* 143 */       int c = cbuf[off++];
/*     */       
/* 145 */       if (c < 128) {
/* 146 */         outBuf[outPtr++] = (byte)c;
/*     */         
/* 148 */         int maxInCount = len - off;
/* 149 */         int maxOutCount = outBufLast - outPtr;
/*     */         
/* 151 */         if (maxInCount > maxOutCount) {
/* 152 */           maxInCount = maxOutCount;
/*     */         }
/* 154 */         maxInCount += off;
/*     */ 
/*     */         
/* 157 */         while (off < maxInCount) {
/*     */ 
/*     */           
/* 160 */           c = cbuf[off++];
/* 161 */           if (c >= 128) {
/*     */             continue label45;
/*     */           }
/* 164 */           outBuf[outPtr++] = (byte)c;
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/* 169 */       if (c < 2048) {
/* 170 */         outBuf[outPtr++] = (byte)(0xC0 | c >> 6);
/* 171 */         outBuf[outPtr++] = (byte)(0x80 | c & 0x3F);
/*     */         continue;
/*     */       } 
/* 174 */       if (c < 55296 || c > 57343) {
/* 175 */         outBuf[outPtr++] = (byte)(0xE0 | c >> 12);
/* 176 */         outBuf[outPtr++] = (byte)(0x80 | c >> 6 & 0x3F);
/* 177 */         outBuf[outPtr++] = (byte)(0x80 | c & 0x3F);
/*     */         
/*     */         continue;
/*     */       } 
/* 181 */       if (c > 56319) {
/* 182 */         this._outPtr = outPtr;
/* 183 */         illegalSurrogate(c);
/*     */       } 
/* 185 */       this._surrogate = c;
/*     */       
/* 187 */       if (off >= len) {
/*     */         break;
/*     */       }
/* 190 */       c = convertSurrogate(cbuf[off++]);
/* 191 */       if (c > 1114111) {
/* 192 */         this._outPtr = outPtr;
/* 193 */         illegalSurrogate(c);
/*     */       } 
/* 195 */       outBuf[outPtr++] = (byte)(0xF0 | c >> 18);
/* 196 */       outBuf[outPtr++] = (byte)(0x80 | c >> 12 & 0x3F);
/* 197 */       outBuf[outPtr++] = (byte)(0x80 | c >> 6 & 0x3F);
/* 198 */       outBuf[outPtr++] = (byte)(0x80 | c & 0x3F);
/*     */     } 
/*     */     
/* 201 */     this._outPtr = outPtr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int c) throws IOException {
/* 208 */     if (this._surrogate > 0) {
/* 209 */       c = convertSurrogate(c);
/*     */     }
/* 211 */     else if (c >= 55296 && c <= 57343) {
/*     */       
/* 213 */       if (c > 56319) {
/* 214 */         illegalSurrogate(c);
/*     */       }
/*     */       
/* 217 */       this._surrogate = c;
/*     */       
/*     */       return;
/*     */     } 
/* 221 */     if (this._outPtr >= this._outBufferEnd) {
/* 222 */       this._out.write(this._outBuffer, 0, this._outPtr);
/* 223 */       this._outPtr = 0;
/*     */     } 
/*     */     
/* 226 */     if (c < 128) {
/* 227 */       this._outBuffer[this._outPtr++] = (byte)c;
/*     */     } else {
/* 229 */       int ptr = this._outPtr;
/* 230 */       if (c < 2048) {
/* 231 */         this._outBuffer[ptr++] = (byte)(0xC0 | c >> 6);
/* 232 */         this._outBuffer[ptr++] = (byte)(0x80 | c & 0x3F);
/* 233 */       } else if (c <= 65535) {
/* 234 */         this._outBuffer[ptr++] = (byte)(0xE0 | c >> 12);
/* 235 */         this._outBuffer[ptr++] = (byte)(0x80 | c >> 6 & 0x3F);
/* 236 */         this._outBuffer[ptr++] = (byte)(0x80 | c & 0x3F);
/*     */       } else {
/* 238 */         if (c > 1114111) {
/* 239 */           illegalSurrogate(c);
/*     */         }
/* 241 */         this._outBuffer[ptr++] = (byte)(0xF0 | c >> 18);
/* 242 */         this._outBuffer[ptr++] = (byte)(0x80 | c >> 12 & 0x3F);
/* 243 */         this._outBuffer[ptr++] = (byte)(0x80 | c >> 6 & 0x3F);
/* 244 */         this._outBuffer[ptr++] = (byte)(0x80 | c & 0x3F);
/*     */       } 
/* 246 */       this._outPtr = ptr;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(String str) throws IOException {
/* 253 */     write(str, 0, str.length());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(String str, int off, int len) throws IOException {
/* 259 */     if (len < 2) {
/* 260 */       if (len == 1) {
/* 261 */         write(str.charAt(off));
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 267 */     if (this._surrogate > 0) {
/* 268 */       char second = str.charAt(off++);
/* 269 */       len--;
/* 270 */       write(convertSurrogate(second));
/*     */     } 
/*     */ 
/*     */     
/* 274 */     int outPtr = this._outPtr;
/* 275 */     byte[] outBuf = this._outBuffer;
/* 276 */     int outBufLast = this._outBufferEnd;
/*     */ 
/*     */     
/* 279 */     len += off;
/*     */ 
/*     */     
/* 282 */     label45: while (off < len) {
/*     */ 
/*     */ 
/*     */       
/* 286 */       if (outPtr >= outBufLast) {
/* 287 */         this._out.write(outBuf, 0, outPtr);
/* 288 */         outPtr = 0;
/*     */       } 
/*     */       
/* 291 */       int c = str.charAt(off++);
/*     */       
/* 293 */       if (c < 128) {
/* 294 */         outBuf[outPtr++] = (byte)c;
/*     */         
/* 296 */         int maxInCount = len - off;
/* 297 */         int maxOutCount = outBufLast - outPtr;
/*     */         
/* 299 */         if (maxInCount > maxOutCount) {
/* 300 */           maxInCount = maxOutCount;
/*     */         }
/* 302 */         maxInCount += off;
/*     */ 
/*     */         
/* 305 */         while (off < maxInCount) {
/*     */ 
/*     */           
/* 308 */           c = str.charAt(off++);
/* 309 */           if (c >= 128) {
/*     */             continue label45;
/*     */           }
/* 312 */           outBuf[outPtr++] = (byte)c;
/*     */         } 
/*     */         
/*     */         continue;
/*     */       } 
/* 317 */       if (c < 2048) {
/* 318 */         outBuf[outPtr++] = (byte)(0xC0 | c >> 6);
/* 319 */         outBuf[outPtr++] = (byte)(0x80 | c & 0x3F);
/*     */         continue;
/*     */       } 
/* 322 */       if (c < 55296 || c > 57343) {
/* 323 */         outBuf[outPtr++] = (byte)(0xE0 | c >> 12);
/* 324 */         outBuf[outPtr++] = (byte)(0x80 | c >> 6 & 0x3F);
/* 325 */         outBuf[outPtr++] = (byte)(0x80 | c & 0x3F);
/*     */         
/*     */         continue;
/*     */       } 
/* 329 */       if (c > 56319) {
/* 330 */         this._outPtr = outPtr;
/* 331 */         illegalSurrogate(c);
/*     */       } 
/* 333 */       this._surrogate = c;
/*     */       
/* 335 */       if (off >= len) {
/*     */         break;
/*     */       }
/* 338 */       c = convertSurrogate(str.charAt(off++));
/* 339 */       if (c > 1114111) {
/* 340 */         this._outPtr = outPtr;
/* 341 */         illegalSurrogate(c);
/*     */       } 
/* 343 */       outBuf[outPtr++] = (byte)(0xF0 | c >> 18);
/* 344 */       outBuf[outPtr++] = (byte)(0x80 | c >> 12 & 0x3F);
/* 345 */       outBuf[outPtr++] = (byte)(0x80 | c >> 6 & 0x3F);
/* 346 */       outBuf[outPtr++] = (byte)(0x80 | c & 0x3F);
/*     */     } 
/*     */     
/* 349 */     this._outPtr = outPtr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int convertSurrogate(int secondPart) throws IOException {
/* 370 */     int firstPart = this._surrogate;
/* 371 */     this._surrogate = 0;
/*     */ 
/*     */     
/* 374 */     if (secondPart < 56320 || secondPart > 57343) {
/* 375 */       throw new IOException("Broken surrogate pair: first char 0x" + Integer.toHexString(firstPart) + ", second 0x" + Integer.toHexString(secondPart) + "; illegal combination");
/*     */     }
/* 377 */     return (firstPart << 10) + secondPart + -56613888;
/*     */   }
/*     */   
/*     */   protected static void illegalSurrogate(int code) throws IOException {
/* 381 */     throw new IOException(illegalSurrogateDesc(code));
/*     */   }
/*     */ 
/*     */   
/*     */   protected static String illegalSurrogateDesc(int code) {
/* 386 */     if (code > 1114111) {
/* 387 */       return "Illegal character point (0x" + Integer.toHexString(code) + ") to output; max is 0x10FFFF as per RFC 4627";
/*     */     }
/* 389 */     if (code >= 55296) {
/* 390 */       if (code <= 56319) {
/* 391 */         return "Unmatched first part of surrogate pair (0x" + Integer.toHexString(code) + ")";
/*     */       }
/* 393 */       return "Unmatched second part of surrogate pair (0x" + Integer.toHexString(code) + ")";
/*     */     } 
/*     */     
/* 396 */     return "Illegal character point (0x" + Integer.toHexString(code) + ") to output";
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\io\UTF8Writer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */