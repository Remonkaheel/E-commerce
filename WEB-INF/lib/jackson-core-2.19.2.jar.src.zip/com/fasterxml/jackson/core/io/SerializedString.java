/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import com.fasterxml.jackson.core.SerializableString;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SerializedString
/*     */   implements SerializableString, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  23 */   private static final JsonStringEncoder JSON_ENCODER = JsonStringEncoder.getInstance();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _value;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected volatile byte[] _quotedUTF8Ref;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected volatile byte[] _unquotedUTF8Ref;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected volatile char[] _quotedChars;
/*     */ 
/*     */ 
/*     */   
/*     */   protected transient String _jdkSerializeValue;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SerializedString(String v) {
/*  53 */     this._value = Objects.<String>requireNonNull(v, "Null String illegal for SerializedString");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException {
/*  71 */     this._jdkSerializeValue = in.readUTF();
/*     */   }
/*     */   
/*     */   private void writeObject(ObjectOutputStream out) throws IOException {
/*  75 */     out.writeUTF(this._value);
/*     */   }
/*     */   
/*     */   protected Object readResolve() {
/*  79 */     return new SerializedString(this._jdkSerializeValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getValue() {
/*  89 */     return this._value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int charLength() {
/*  95 */     return this._value.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final char[] asQuotedChars() {
/* 103 */     char[] result = this._quotedChars;
/* 104 */     if (result == null) {
/* 105 */       this._quotedChars = result = JSON_ENCODER.quoteAsString(this._value);
/*     */     }
/* 107 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] asQuotedUTF8() {
/* 117 */     byte[] result = this._quotedUTF8Ref;
/* 118 */     if (result == null) {
/* 119 */       this._quotedUTF8Ref = result = JSON_ENCODER.quoteAsUTF8(this._value);
/*     */     }
/* 121 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] asUnquotedUTF8() {
/* 130 */     byte[] result = this._unquotedUTF8Ref;
/* 131 */     if (result == null) {
/* 132 */       this._unquotedUTF8Ref = result = JSON_ENCODER.encodeAsUTF8(this._value);
/*     */     }
/* 134 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int appendQuoted(char[] buffer, int offset) {
/* 145 */     char[] result = this._quotedChars;
/* 146 */     if (result == null) {
/* 147 */       this._quotedChars = result = JSON_ENCODER.quoteAsString(this._value);
/*     */     }
/* 149 */     int length = result.length;
/* 150 */     if (offset + length > buffer.length) {
/* 151 */       return -1;
/*     */     }
/* 153 */     System.arraycopy(result, 0, buffer, offset, length);
/* 154 */     return length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int appendQuotedUTF8(byte[] buffer, int offset) {
/* 159 */     byte[] result = this._quotedUTF8Ref;
/* 160 */     if (result == null) {
/* 161 */       this._quotedUTF8Ref = result = JSON_ENCODER.quoteAsUTF8(this._value);
/*     */     }
/* 163 */     int length = result.length;
/* 164 */     if (offset + length > buffer.length) {
/* 165 */       return -1;
/*     */     }
/* 167 */     System.arraycopy(result, 0, buffer, offset, length);
/* 168 */     return length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int appendUnquoted(char[] buffer, int offset) {
/* 173 */     String str = this._value;
/* 174 */     int length = str.length();
/* 175 */     if (offset + length > buffer.length) {
/* 176 */       return -1;
/*     */     }
/* 178 */     str.getChars(0, length, buffer, offset);
/* 179 */     return length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int appendUnquotedUTF8(byte[] buffer, int offset) {
/* 184 */     byte[] result = this._unquotedUTF8Ref;
/* 185 */     if (result == null) {
/* 186 */       this._unquotedUTF8Ref = result = JSON_ENCODER.encodeAsUTF8(this._value);
/*     */     }
/* 188 */     int length = result.length;
/* 189 */     if (offset + length > buffer.length) {
/* 190 */       return -1;
/*     */     }
/* 192 */     System.arraycopy(result, 0, buffer, offset, length);
/* 193 */     return length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int writeQuotedUTF8(OutputStream out) throws IOException {
/* 198 */     byte[] result = this._quotedUTF8Ref;
/* 199 */     if (result == null) {
/* 200 */       this._quotedUTF8Ref = result = JSON_ENCODER.quoteAsUTF8(this._value);
/*     */     }
/* 202 */     int length = result.length;
/* 203 */     out.write(result, 0, length);
/* 204 */     return length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int writeUnquotedUTF8(OutputStream out) throws IOException {
/* 209 */     byte[] result = this._unquotedUTF8Ref;
/* 210 */     if (result == null) {
/* 211 */       this._unquotedUTF8Ref = result = JSON_ENCODER.encodeAsUTF8(this._value);
/*     */     }
/* 213 */     int length = result.length;
/* 214 */     out.write(result, 0, length);
/* 215 */     return length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int putQuotedUTF8(ByteBuffer buffer) {
/* 220 */     byte[] result = this._quotedUTF8Ref;
/* 221 */     if (result == null) {
/* 222 */       this._quotedUTF8Ref = result = JSON_ENCODER.quoteAsUTF8(this._value);
/*     */     }
/* 224 */     int length = result.length;
/* 225 */     if (length > buffer.remaining()) {
/* 226 */       return -1;
/*     */     }
/* 228 */     buffer.put(result, 0, length);
/* 229 */     return length;
/*     */   }
/*     */ 
/*     */   
/*     */   public int putUnquotedUTF8(ByteBuffer buffer) {
/* 234 */     byte[] result = this._unquotedUTF8Ref;
/* 235 */     if (result == null) {
/* 236 */       this._unquotedUTF8Ref = result = JSON_ENCODER.encodeAsUTF8(this._value);
/*     */     }
/* 238 */     int length = result.length;
/* 239 */     if (length > buffer.remaining()) {
/* 240 */       return -1;
/*     */     }
/* 242 */     buffer.put(result, 0, length);
/* 243 */     return length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 253 */     return this._value;
/*     */   }
/*     */   public final int hashCode() {
/* 256 */     return this._value.hashCode();
/*     */   }
/*     */   
/*     */   public final boolean equals(Object o) {
/* 260 */     if (o == this) return true; 
/* 261 */     if (o == null || o.getClass() != getClass()) return false; 
/* 262 */     SerializedString other = (SerializedString)o;
/* 263 */     return this._value.equals(other._value);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\io\SerializedString.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */