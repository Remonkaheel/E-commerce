/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import com.fasterxml.jackson.core.util.ByteArrayBuilder;
/*     */ import com.fasterxml.jackson.core.util.TextBuffer;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JsonStringEncoder
/*     */ {
/*  25 */   private static final char[] HC = CharTypes.copyHexChars(true);
/*     */   
/*  27 */   private static final byte[] HB = CharTypes.copyHexBytes(true);
/*     */ 
/*     */   
/*     */   private static final int SURR1_FIRST = 55296;
/*     */ 
/*     */   
/*     */   private static final int SURR1_LAST = 56319;
/*     */ 
/*     */   
/*     */   private static final int SURR2_FIRST = 56320;
/*     */ 
/*     */   
/*     */   private static final int SURR2_LAST = 57343;
/*     */ 
/*     */   
/*     */   static final int MIN_CHAR_BUFFER_SIZE = 16;
/*     */   
/*     */   static final int MAX_CHAR_BUFFER_SIZE = 32000;
/*     */   
/*     */   static final int MIN_BYTE_BUFFER_SIZE = 24;
/*     */   
/*     */   static final int MAX_BYTE_BUFFER_SIZE = 32000;
/*     */   
/*  50 */   private static final JsonStringEncoder instance = new JsonStringEncoder();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static JsonStringEncoder getInstance() {
/*  61 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] quoteAsString(String input) {
/*  80 */     int inputLen = input.length();
/*  81 */     char[] outputBuffer = new char[_initialCharBufSize(inputLen)];
/*  82 */     int[] escCodes = CharTypes.get7BitOutputEscapes();
/*  83 */     int escCodeCount = escCodes.length;
/*  84 */     int inPtr = 0;
/*  85 */     TextBuffer textBuffer = null;
/*  86 */     int outPtr = 0;
/*  87 */     char[] qbuf = null;
/*     */ 
/*     */     
/*  90 */     while (inPtr < inputLen) {
/*     */       
/*     */       while (true) {
/*  93 */         char d, c = input.charAt(inPtr);
/*  94 */         if (c < escCodeCount && escCodes[c] != 0)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 115 */           if (qbuf == null) {
/* 116 */             qbuf = _qbuf();
/*     */           }
/* 118 */           d = input.charAt(inPtr++);
/* 119 */           int escCode = escCodes[d];
/*     */ 
/*     */           
/* 122 */           int length = (escCode < 0) ? _appendNumeric(d, qbuf) : _appendNamed(escCode, qbuf);
/*     */           
/* 124 */           if (outPtr + length > outputBuffer.length) {
/* 125 */             int first = outputBuffer.length - outPtr;
/* 126 */             if (first > 0) {
/* 127 */               System.arraycopy(qbuf, 0, outputBuffer, outPtr, first);
/*     */             }
/* 129 */             if (textBuffer == null) {
/* 130 */               textBuffer = TextBuffer.fromInitial(outputBuffer);
/*     */             }
/*     */             try {
/* 133 */               outputBuffer = textBuffer.finishCurrentSegment();
/* 134 */             } catch (IOException e) {
/*     */               
/* 136 */               throw new IllegalStateException(e);
/*     */             } 
/* 138 */             int second = length - first;
/* 139 */             System.arraycopy(qbuf, first, outputBuffer, 0, second);
/* 140 */             outPtr = second; continue;
/*     */           } 
/* 142 */           System.arraycopy(qbuf, 0, outputBuffer, outPtr, length);
/* 143 */           outPtr += length; continue; }  if (outPtr >= outputBuffer.length) { if (textBuffer == null)
/*     */             textBuffer = TextBuffer.fromInitial(outputBuffer);  try { outputBuffer = textBuffer.finishCurrentSegment(); } catch (IOException e) { throw new IllegalStateException(e); }  outPtr = 0; }  outputBuffer[outPtr++] = d; if (++inPtr >= inputLen)
/*     */           break; 
/*     */       } 
/* 147 */     }  if (textBuffer == null) {
/* 148 */       return Arrays.copyOfRange(outputBuffer, 0, outPtr);
/*     */     }
/* 150 */     textBuffer.setCurrentLength(outPtr);
/*     */     try {
/* 152 */       return textBuffer.contentsAsArray();
/* 153 */     } catch (IOException e) {
/*     */       
/* 155 */       throw new IllegalStateException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] quoteAsString(CharSequence input) {
/* 171 */     if (input instanceof String) {
/* 172 */       return quoteAsString((String)input);
/*     */     }
/*     */     
/* 175 */     TextBuffer textBuffer = null;
/*     */     
/* 177 */     int inputLen = input.length();
/* 178 */     char[] outputBuffer = new char[_initialCharBufSize(inputLen)];
/* 179 */     int[] escCodes = CharTypes.get7BitOutputEscapes();
/* 180 */     int escCodeCount = escCodes.length;
/* 181 */     int inPtr = 0;
/* 182 */     int outPtr = 0;
/* 183 */     char[] qbuf = null;
/*     */ 
/*     */     
/* 186 */     while (inPtr < inputLen) {
/*     */       
/*     */       while (true) {
/* 189 */         char d, c = input.charAt(inPtr);
/* 190 */         if (c < escCodeCount && escCodes[c] != 0)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 211 */           if (qbuf == null) {
/* 212 */             qbuf = _qbuf();
/*     */           }
/* 214 */           d = input.charAt(inPtr++);
/* 215 */           int escCode = escCodes[d];
/*     */ 
/*     */           
/* 218 */           int length = (escCode < 0) ? _appendNumeric(d, qbuf) : _appendNamed(escCode, qbuf);
/*     */           
/* 220 */           if (outPtr + length > outputBuffer.length) {
/* 221 */             int first = outputBuffer.length - outPtr;
/* 222 */             if (first > 0) {
/* 223 */               System.arraycopy(qbuf, 0, outputBuffer, outPtr, first);
/*     */             }
/* 225 */             if (textBuffer == null) {
/* 226 */               textBuffer = TextBuffer.fromInitial(outputBuffer);
/*     */             }
/*     */             try {
/* 229 */               outputBuffer = textBuffer.finishCurrentSegment();
/* 230 */             } catch (IOException e) {
/*     */               
/* 232 */               throw new IllegalStateException(e);
/*     */             } 
/* 234 */             int second = length - first;
/* 235 */             System.arraycopy(qbuf, first, outputBuffer, 0, second);
/* 236 */             outPtr = second; continue;
/*     */           } 
/* 238 */           System.arraycopy(qbuf, 0, outputBuffer, outPtr, length);
/* 239 */           outPtr += length; continue; }  if (outPtr >= outputBuffer.length) { if (textBuffer == null)
/*     */             textBuffer = TextBuffer.fromInitial(outputBuffer);  try { outputBuffer = textBuffer.finishCurrentSegment(); } catch (IOException e) { throw new IllegalStateException(e); }  outPtr = 0; }  outputBuffer[outPtr++] = d; if (++inPtr >= inputLen)
/*     */           break; 
/*     */       } 
/* 243 */     }  if (textBuffer == null) {
/* 244 */       return Arrays.copyOfRange(outputBuffer, 0, outPtr);
/*     */     }
/* 246 */     textBuffer.setCurrentLength(outPtr);
/*     */     try {
/* 248 */       return textBuffer.contentsAsArray();
/* 249 */     } catch (IOException e) {
/*     */       
/* 251 */       throw new IllegalStateException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void quoteAsString(CharSequence input, StringBuilder output) {
/* 267 */     int[] escCodes = CharTypes.get7BitOutputEscapes();
/* 268 */     int escCodeCount = escCodes.length;
/* 269 */     int inPtr = 0;
/* 270 */     int inputLen = input.length();
/* 271 */     char[] qbuf = null;
/*     */ 
/*     */     
/* 274 */     while (inPtr < inputLen) {
/*     */       
/*     */       while (true) {
/* 277 */         char d, c = input.charAt(inPtr);
/* 278 */         if (c < escCodeCount && escCodes[c] != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 287 */           if (qbuf == null) {
/* 288 */             qbuf = _qbuf();
/*     */           }
/* 290 */           d = input.charAt(inPtr++);
/* 291 */           int escCode = escCodes[d];
/* 292 */           if (escCode < 0);
/*     */           
/* 294 */           int length = _appendNamed(escCode, qbuf);
/* 295 */           output.append(qbuf, 0, length);
/*     */           continue;
/*     */         } 
/*     */         output.append(d);
/*     */         if (++inPtr >= inputLen) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] quoteAsUTF8(String text) {
/* 311 */     int inputPtr = 0;
/* 312 */     int inputEnd = text.length();
/* 313 */     int outputPtr = 0;
/* 314 */     byte[] outputBuffer = new byte[_initialByteBufSize(inputEnd)];
/* 315 */     ByteArrayBuilder bb = null;
/*     */ 
/*     */     
/* 318 */     while (inputPtr < inputEnd)
/* 319 */     { int[] escCodes = CharTypes.get7BitOutputEscapes();
/*     */ 
/*     */       
/*     */       label55: while (true)
/* 323 */       { int ch = text.charAt(inputPtr);
/* 324 */         if (ch > 127 || escCodes[ch] != 0)
/*     */         
/*     */         { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 339 */           if (bb == null) {
/* 340 */             bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);
/*     */           }
/* 342 */           if (outputPtr >= outputBuffer.length) {
/* 343 */             outputBuffer = bb.finishCurrentSegment();
/* 344 */             outputPtr = 0;
/*     */           } 
/*     */           
/* 347 */           ch = text.charAt(inputPtr++);
/* 348 */           if (ch <= 127) {
/* 349 */             int escape = escCodes[ch];
/*     */             
/* 351 */             outputPtr = _appendByte(ch, escape, bb, outputPtr);
/* 352 */             outputBuffer = bb.getCurrentSegment();
/*     */             continue;
/*     */           } 
/* 355 */           if (ch <= 2047) {
/* 356 */             outputBuffer[outputPtr++] = (byte)(0xC0 | ch >> 6);
/* 357 */             ch = 0x80 | ch & 0x3F;
/*     */           
/*     */           }
/* 360 */           else if (ch < 55296 || ch > 57343) {
/* 361 */             outputBuffer[outputPtr++] = (byte)(0xE0 | ch >> 12);
/* 362 */             if (outputPtr >= outputBuffer.length) {
/* 363 */               outputBuffer = bb.finishCurrentSegment();
/* 364 */               outputPtr = 0;
/*     */             } 
/* 366 */             outputBuffer[outputPtr++] = (byte)(0x80 | ch >> 6 & 0x3F);
/* 367 */             ch = 0x80 | ch & 0x3F;
/*     */           } else {
/* 369 */             if (ch > 56319) {
/* 370 */               _illegal(ch);
/*     */             }
/*     */             
/* 373 */             if (inputPtr >= inputEnd) {
/* 374 */               _illegal(ch);
/*     */             }
/* 376 */             ch = _convert(ch, text.charAt(inputPtr++));
/* 377 */             if (ch > 1114111) {
/* 378 */               _illegal(ch);
/*     */             }
/* 380 */             outputBuffer[outputPtr++] = (byte)(0xF0 | ch >> 18);
/* 381 */             if (outputPtr >= outputBuffer.length) {
/* 382 */               outputBuffer = bb.finishCurrentSegment();
/* 383 */               outputPtr = 0;
/*     */             } 
/* 385 */             outputBuffer[outputPtr++] = (byte)(0x80 | ch >> 12 & 0x3F);
/* 386 */             if (outputPtr >= outputBuffer.length) {
/* 387 */               outputBuffer = bb.finishCurrentSegment();
/* 388 */               outputPtr = 0;
/*     */             } 
/* 390 */             outputBuffer[outputPtr++] = (byte)(0x80 | ch >> 6 & 0x3F);
/* 391 */             ch = 0x80 | ch & 0x3F;
/*     */           } 
/*     */           
/* 394 */           if (outputPtr >= outputBuffer.length) {
/* 395 */             outputBuffer = bb.finishCurrentSegment();
/* 396 */             outputPtr = 0; break label55;
/*     */           } 
/* 398 */           outputBuffer[outputPtr++] = (byte)ch; continue; }  if (outputPtr >= outputBuffer.length) { if (bb == null)
/*     */             bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);  outputBuffer = bb.finishCurrentSegment(); outputPtr = 0; }  outputBuffer[outputPtr++] = (byte)ch; if (++inputPtr >= inputEnd)
/* 400 */           break;  }  }  if (bb == null) {
/* 401 */       return Arrays.copyOfRange(outputBuffer, 0, outputPtr);
/*     */     }
/* 403 */     return bb.completeAndCoalesce(outputPtr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encodeAsUTF8(String text) {
/* 417 */     int inputPtr = 0;
/* 418 */     int inputEnd = text.length();
/* 419 */     int outputPtr = 0;
/* 420 */     byte[] outputBuffer = new byte[_initialByteBufSize(inputEnd)];
/* 421 */     int outputEnd = outputBuffer.length;
/* 422 */     ByteArrayBuilder bb = null;
/*     */ 
/*     */     
/* 425 */     label51: while (inputPtr < inputEnd) {
/* 426 */       int c = text.charAt(inputPtr++);
/*     */ 
/*     */       
/* 429 */       while (c <= 127) {
/* 430 */         if (outputPtr >= outputEnd) {
/* 431 */           if (bb == null) {
/* 432 */             bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);
/*     */           }
/* 434 */           outputBuffer = bb.finishCurrentSegment();
/* 435 */           outputEnd = outputBuffer.length;
/* 436 */           outputPtr = 0;
/*     */         } 
/* 438 */         outputBuffer[outputPtr++] = (byte)c;
/* 439 */         if (inputPtr >= inputEnd) {
/*     */           break label51;
/*     */         }
/* 442 */         c = text.charAt(inputPtr++);
/*     */       } 
/*     */ 
/*     */       
/* 446 */       if (bb == null) {
/* 447 */         bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);
/*     */       }
/* 449 */       if (outputPtr >= outputEnd) {
/* 450 */         outputBuffer = bb.finishCurrentSegment();
/* 451 */         outputEnd = outputBuffer.length;
/* 452 */         outputPtr = 0;
/*     */       } 
/* 454 */       if (c < 2048) {
/* 455 */         outputBuffer[outputPtr++] = (byte)(0xC0 | c >> 6);
/*     */       
/*     */       }
/* 458 */       else if (c < 55296 || c > 57343) {
/* 459 */         outputBuffer[outputPtr++] = (byte)(0xE0 | c >> 12);
/* 460 */         if (outputPtr >= outputEnd) {
/* 461 */           outputBuffer = bb.finishCurrentSegment();
/* 462 */           outputEnd = outputBuffer.length;
/* 463 */           outputPtr = 0;
/*     */         } 
/* 465 */         outputBuffer[outputPtr++] = (byte)(0x80 | c >> 6 & 0x3F);
/*     */       } else {
/* 467 */         if (c > 56319) {
/* 468 */           _illegal(c);
/*     */         }
/*     */         
/* 471 */         if (inputPtr >= inputEnd) {
/* 472 */           _illegal(c);
/*     */         }
/* 474 */         c = _convert(c, text.charAt(inputPtr++));
/* 475 */         if (c > 1114111) {
/* 476 */           _illegal(c);
/*     */         }
/* 478 */         outputBuffer[outputPtr++] = (byte)(0xF0 | c >> 18);
/* 479 */         if (outputPtr >= outputEnd) {
/* 480 */           outputBuffer = bb.finishCurrentSegment();
/* 481 */           outputEnd = outputBuffer.length;
/* 482 */           outputPtr = 0;
/*     */         } 
/* 484 */         outputBuffer[outputPtr++] = (byte)(0x80 | c >> 12 & 0x3F);
/* 485 */         if (outputPtr >= outputEnd) {
/* 486 */           outputBuffer = bb.finishCurrentSegment();
/* 487 */           outputEnd = outputBuffer.length;
/* 488 */           outputPtr = 0;
/*     */         } 
/* 490 */         outputBuffer[outputPtr++] = (byte)(0x80 | c >> 6 & 0x3F);
/*     */       } 
/*     */       
/* 493 */       if (outputPtr >= outputEnd) {
/* 494 */         outputBuffer = bb.finishCurrentSegment();
/* 495 */         outputEnd = outputBuffer.length;
/* 496 */         outputPtr = 0;
/*     */       } 
/* 498 */       outputBuffer[outputPtr++] = (byte)(0x80 | c & 0x3F);
/*     */     } 
/* 500 */     if (bb == null) {
/* 501 */       return Arrays.copyOfRange(outputBuffer, 0, outputPtr);
/*     */     }
/* 503 */     return bb.completeAndCoalesce(outputPtr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encodeAsUTF8(CharSequence text) {
/* 518 */     int inputPtr = 0;
/* 519 */     int inputEnd = text.length();
/* 520 */     int outputPtr = 0;
/* 521 */     byte[] outputBuffer = new byte[_initialByteBufSize(inputEnd)];
/* 522 */     int outputEnd = outputBuffer.length;
/* 523 */     ByteArrayBuilder bb = null;
/*     */ 
/*     */     
/* 526 */     label51: while (inputPtr < inputEnd) {
/* 527 */       int c = text.charAt(inputPtr++);
/*     */ 
/*     */       
/* 530 */       while (c <= 127) {
/* 531 */         if (outputPtr >= outputEnd) {
/* 532 */           if (bb == null) {
/* 533 */             bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);
/*     */           }
/* 535 */           outputBuffer = bb.finishCurrentSegment();
/* 536 */           outputEnd = outputBuffer.length;
/* 537 */           outputPtr = 0;
/*     */         } 
/* 539 */         outputBuffer[outputPtr++] = (byte)c;
/* 540 */         if (inputPtr >= inputEnd) {
/*     */           break label51;
/*     */         }
/* 543 */         c = text.charAt(inputPtr++);
/*     */       } 
/*     */ 
/*     */       
/* 547 */       if (bb == null) {
/* 548 */         bb = ByteArrayBuilder.fromInitial(outputBuffer, outputPtr);
/*     */       }
/* 550 */       if (outputPtr >= outputEnd) {
/* 551 */         outputBuffer = bb.finishCurrentSegment();
/* 552 */         outputEnd = outputBuffer.length;
/* 553 */         outputPtr = 0;
/*     */       } 
/* 555 */       if (c < 2048) {
/* 556 */         outputBuffer[outputPtr++] = (byte)(0xC0 | c >> 6);
/*     */       
/*     */       }
/* 559 */       else if (c < 55296 || c > 57343) {
/* 560 */         outputBuffer[outputPtr++] = (byte)(0xE0 | c >> 12);
/* 561 */         if (outputPtr >= outputEnd) {
/* 562 */           outputBuffer = bb.finishCurrentSegment();
/* 563 */           outputEnd = outputBuffer.length;
/* 564 */           outputPtr = 0;
/*     */         } 
/* 566 */         outputBuffer[outputPtr++] = (byte)(0x80 | c >> 6 & 0x3F);
/*     */       } else {
/* 568 */         if (c > 56319) {
/* 569 */           _illegal(c);
/*     */         }
/*     */         
/* 572 */         if (inputPtr >= inputEnd) {
/* 573 */           _illegal(c);
/*     */         }
/* 575 */         c = _convert(c, text.charAt(inputPtr++));
/* 576 */         if (c > 1114111) {
/* 577 */           _illegal(c);
/*     */         }
/* 579 */         outputBuffer[outputPtr++] = (byte)(0xF0 | c >> 18);
/* 580 */         if (outputPtr >= outputEnd) {
/* 581 */           outputBuffer = bb.finishCurrentSegment();
/* 582 */           outputEnd = outputBuffer.length;
/* 583 */           outputPtr = 0;
/*     */         } 
/* 585 */         outputBuffer[outputPtr++] = (byte)(0x80 | c >> 12 & 0x3F);
/* 586 */         if (outputPtr >= outputEnd) {
/* 587 */           outputBuffer = bb.finishCurrentSegment();
/* 588 */           outputEnd = outputBuffer.length;
/* 589 */           outputPtr = 0;
/*     */         } 
/* 591 */         outputBuffer[outputPtr++] = (byte)(0x80 | c >> 6 & 0x3F);
/*     */       } 
/*     */       
/* 594 */       if (outputPtr >= outputEnd) {
/* 595 */         outputBuffer = bb.finishCurrentSegment();
/* 596 */         outputEnd = outputBuffer.length;
/* 597 */         outputPtr = 0;
/*     */       } 
/* 599 */       outputBuffer[outputPtr++] = (byte)(0x80 | c & 0x3F);
/*     */     } 
/* 601 */     if (bb == null) {
/* 602 */       return Arrays.copyOfRange(outputBuffer, 0, outputPtr);
/*     */     }
/* 604 */     return bb.completeAndCoalesce(outputPtr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private char[] _qbuf() {
/* 614 */     char[] qbuf = new char[6];
/* 615 */     qbuf[0] = '\\';
/* 616 */     qbuf[2] = '0';
/* 617 */     qbuf[3] = '0';
/* 618 */     return qbuf;
/*     */   }
/*     */   
/*     */   private int _appendNumeric(int value, char[] qbuf) {
/* 622 */     qbuf[1] = 'u';
/*     */     
/* 624 */     qbuf[4] = HC[value >> 4];
/* 625 */     qbuf[5] = HC[value & 0xF];
/* 626 */     return 6;
/*     */   }
/*     */   
/*     */   private int _appendNamed(int esc, char[] qbuf) {
/* 630 */     qbuf[1] = (char)esc;
/* 631 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   private int _appendByte(int ch, int esc, ByteArrayBuilder bb, int ptr) {
/* 636 */     bb.setCurrentSegmentLength(ptr);
/* 637 */     bb.append(92);
/* 638 */     if (esc < 0) {
/* 639 */       bb.append(117);
/* 640 */       if (ch > 255) {
/* 641 */         int hi = ch >> 8;
/* 642 */         bb.append(HB[hi >> 4]);
/* 643 */         bb.append(HB[hi & 0xF]);
/* 644 */         ch &= 0xFF;
/*     */       } else {
/* 646 */         bb.append(48);
/* 647 */         bb.append(48);
/*     */       } 
/* 649 */       bb.append(HB[ch >> 4]);
/* 650 */       bb.append(HB[ch & 0xF]);
/*     */     } else {
/* 652 */       bb.append((byte)esc);
/*     */     } 
/* 654 */     return bb.getCurrentSegmentLength();
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _convert(int p1, int p2) {
/* 659 */     if (p2 < 56320 || p2 > 57343) {
/* 660 */       throw new IllegalArgumentException("Broken surrogate pair: first char 0x" + Integer.toHexString(p1) + ", second 0x" + Integer.toHexString(p2) + "; illegal combination");
/*     */     }
/* 662 */     return (p1 << 10) + p2 + -56613888;
/*     */   }
/*     */   
/*     */   private static void _illegal(int c) {
/* 666 */     throw new IllegalArgumentException(UTF8Writer.illegalSurrogateDesc(c));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int _initialCharBufSize(int strLen) {
/* 673 */     int estimated = Math.max(16, strLen + 
/* 674 */         Math.min(6 + (strLen >> 3), 1000));
/* 675 */     return Math.min(estimated, 32000);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int _initialByteBufSize(int strLen) {
/* 682 */     int doubled = Math.max(24, strLen + 6 + (strLen >> 1));
/*     */     
/* 684 */     return Math.min(doubled, 32000);
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\io\JsonStringEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */