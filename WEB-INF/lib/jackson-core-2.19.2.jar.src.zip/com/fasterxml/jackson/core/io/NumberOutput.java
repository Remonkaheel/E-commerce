/*     */ package com.fasterxml.jackson.core.io;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.schubfach.DoubleToDecimal;
/*     */ import com.fasterxml.jackson.core.io.schubfach.FloatToDecimal;
/*     */ 
/*     */ public final class NumberOutput
/*     */ {
/*   8 */   private static int MILLION = 1000000;
/*   9 */   private static int BILLION = 1000000000;
/*  10 */   private static long BILLION_L = 1000000000L;
/*     */   
/*  12 */   private static long MIN_INT_AS_LONG = -2147483648L;
/*  13 */   private static long MAX_INT_AS_LONG = 2147483647L;
/*     */   
/*  15 */   static final String SMALLEST_INT = String.valueOf(-2147483648);
/*  16 */   static final String SMALLEST_LONG = String.valueOf(Long.MIN_VALUE);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  24 */   private static final int[] TRIPLET_TO_CHARS = new int[1000];
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  29 */     int fullIx = 0;
/*  30 */     for (int i1 = 0; i1 < 10; i1++) {
/*  31 */       for (int i2 = 0; i2 < 10; i2++) {
/*  32 */         for (int i3 = 0; i3 < 10; i3++) {
/*  33 */           int enc = i1 + 48 << 16 | i2 + 48 << 8 | i3 + 48;
/*     */ 
/*     */           
/*  36 */           TRIPLET_TO_CHARS[fullIx++] = enc;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*  42 */   private static final String[] sSmallIntStrs = new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" };
/*     */ 
/*     */   
/*  45 */   private static final String[] sSmallIntStrs2 = new String[] { "-1", "-2", "-3", "-4", "-5", "-6", "-7", "-8", "-9", "-10" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int outputInt(int v, char[] b, int off) {
/*  70 */     if (v < 0) {
/*  71 */       if (v == Integer.MIN_VALUE)
/*     */       {
/*     */         
/*  74 */         return _outputSmallestI(b, off);
/*     */       }
/*  76 */       b[off++] = '-';
/*  77 */       v = -v;
/*     */     } 
/*     */     
/*  80 */     if (v < MILLION) {
/*  81 */       if (v < 1000) {
/*  82 */         if (v < 10) {
/*  83 */           b[off] = (char)(48 + v);
/*  84 */           return off + 1;
/*     */         } 
/*  86 */         return _leading3(v, b, off);
/*     */       } 
/*  88 */       int i = divBy1000(v);
/*  89 */       v -= i * 1000;
/*  90 */       off = _leading3(i, b, off);
/*  91 */       off = _full3(v, b, off);
/*  92 */       return off;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     if (v >= BILLION) {
/* 101 */       v -= BILLION;
/* 102 */       if (v >= BILLION) {
/* 103 */         v -= BILLION;
/* 104 */         b[off++] = '2';
/*     */       } else {
/* 106 */         b[off++] = '1';
/*     */       } 
/* 108 */       return _outputFullBillion(v, b, off);
/*     */     } 
/* 110 */     int newValue = divBy1000(v);
/* 111 */     int ones = v - newValue * 1000;
/* 112 */     v = newValue;
/* 113 */     newValue = divBy1000(newValue);
/* 114 */     int thousands = v - newValue * 1000;
/*     */     
/* 116 */     off = _leading3(newValue, b, off);
/* 117 */     off = _full3(thousands, b, off);
/* 118 */     return _full3(ones, b, off);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int outputInt(int v, byte[] b, int off) {
/* 123 */     if (v < 0) {
/* 124 */       if (v == Integer.MIN_VALUE) {
/* 125 */         return _outputSmallestI(b, off);
/*     */       }
/* 127 */       b[off++] = 45;
/* 128 */       v = -v;
/*     */     } 
/*     */     
/* 131 */     if (v < MILLION) {
/* 132 */       if (v < 1000) {
/* 133 */         if (v < 10) {
/* 134 */           b[off++] = (byte)(48 + v);
/*     */         } else {
/* 136 */           off = _leading3(v, b, off);
/*     */         } 
/*     */       } else {
/* 139 */         int i = divBy1000(v);
/* 140 */         v -= i * 1000;
/* 141 */         off = _leading3(i, b, off);
/* 142 */         off = _full3(v, b, off);
/*     */       } 
/* 144 */       return off;
/*     */     } 
/* 146 */     if (v >= BILLION) {
/* 147 */       v -= BILLION;
/* 148 */       if (v >= BILLION) {
/* 149 */         v -= BILLION;
/* 150 */         b[off++] = 50;
/*     */       } else {
/* 152 */         b[off++] = 49;
/*     */       } 
/* 154 */       return _outputFullBillion(v, b, off);
/*     */     } 
/* 156 */     int newValue = divBy1000(v);
/* 157 */     int ones = v - newValue * 1000;
/* 158 */     v = newValue;
/* 159 */     newValue = divBy1000(newValue);
/* 160 */     int thousands = v - newValue * 1000;
/* 161 */     off = _leading3(newValue, b, off);
/* 162 */     off = _full3(thousands, b, off);
/* 163 */     return _full3(ones, b, off);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int outputLong(long v, char[] b, int off) {
/* 182 */     if (v < 0L) {
/* 183 */       if (v > MIN_INT_AS_LONG) {
/* 184 */         return outputInt((int)v, b, off);
/*     */       }
/* 186 */       if (v == Long.MIN_VALUE) {
/* 187 */         return _outputSmallestL(b, off);
/*     */       }
/* 189 */       b[off++] = '-';
/* 190 */       v = -v;
/*     */     }
/* 192 */     else if (v <= MAX_INT_AS_LONG) {
/* 193 */       return outputInt((int)v, b, off);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 198 */     long upper = v / BILLION_L;
/* 199 */     v -= upper * BILLION_L;
/*     */ 
/*     */     
/* 202 */     if (upper < BILLION_L) {
/* 203 */       off = _outputUptoBillion((int)upper, b, off);
/*     */     } else {
/*     */       
/* 206 */       long hi = upper / BILLION_L;
/* 207 */       upper -= hi * BILLION_L;
/* 208 */       off = _leading3((int)hi, b, off);
/* 209 */       off = _outputFullBillion((int)upper, b, off);
/*     */     } 
/* 211 */     return _outputFullBillion((int)v, b, off);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int outputLong(long v, byte[] b, int off) {
/* 216 */     if (v < 0L) {
/* 217 */       if (v > MIN_INT_AS_LONG) {
/* 218 */         return outputInt((int)v, b, off);
/*     */       }
/* 220 */       if (v == Long.MIN_VALUE) {
/* 221 */         return _outputSmallestL(b, off);
/*     */       }
/* 223 */       b[off++] = 45;
/* 224 */       v = -v;
/*     */     }
/* 226 */     else if (v <= MAX_INT_AS_LONG) {
/* 227 */       return outputInt((int)v, b, off);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 232 */     long upper = v / BILLION_L;
/* 233 */     v -= upper * BILLION_L;
/*     */ 
/*     */     
/* 236 */     if (upper < BILLION_L) {
/* 237 */       off = _outputUptoBillion((int)upper, b, off);
/*     */     } else {
/*     */       
/* 240 */       long hi = upper / BILLION_L;
/* 241 */       upper -= hi * BILLION_L;
/* 242 */       off = _leading3((int)hi, b, off);
/* 243 */       off = _outputFullBillion((int)upper, b, off);
/*     */     } 
/* 245 */     return _outputFullBillion((int)v, b, off);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int divBy1000(int number) {
/* 255 */     return (int)(number * 274877907L >>> 38L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(int v) {
/* 270 */     if (v < sSmallIntStrs.length) {
/* 271 */       if (v >= 0) {
/* 272 */         return sSmallIntStrs[v];
/*     */       }
/* 274 */       int v2 = -v - 1;
/* 275 */       if (v2 < sSmallIntStrs2.length) {
/* 276 */         return sSmallIntStrs2[v2];
/*     */       }
/*     */     } 
/* 279 */     return Integer.toString(v);
/*     */   }
/*     */   
/*     */   public static String toString(long v) {
/* 283 */     if (v <= 2147483647L && v >= -2147483648L) {
/* 284 */       return toString((int)v);
/*     */     }
/* 286 */     return Long.toString(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(double v) {
/* 294 */     return toString(v, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(double v, boolean useFastWriter) {
/* 304 */     return useFastWriter ? DoubleToDecimal.toString(v) : Double.toString(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(float v) {
/* 313 */     return toString(v, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(float v, boolean useFastWriter) {
/* 323 */     return useFastWriter ? FloatToDecimal.toString(v) : Float.toString(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean notFinite(double value) {
/* 343 */     return !Double.isFinite(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean notFinite(float value) {
/* 357 */     return !Float.isFinite(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int _outputUptoBillion(int v, char[] b, int off) {
/* 368 */     if (v < MILLION) {
/* 369 */       if (v < 1000) {
/* 370 */         return _leading3(v, b, off);
/*     */       }
/* 372 */       int i = divBy1000(v);
/* 373 */       int j = v - i * 1000;
/* 374 */       return _outputUptoMillion(b, off, i, j);
/*     */     } 
/* 376 */     int thousands = divBy1000(v);
/* 377 */     int ones = v - thousands * 1000;
/* 378 */     int millions = divBy1000(thousands);
/* 379 */     thousands -= millions * 1000;
/*     */     
/* 381 */     off = _leading3(millions, b, off);
/*     */     
/* 383 */     int enc = TRIPLET_TO_CHARS[thousands];
/* 384 */     b[off++] = (char)(enc >> 16);
/* 385 */     b[off++] = (char)(enc >> 8 & 0x7F);
/* 386 */     b[off++] = (char)(enc & 0x7F);
/*     */     
/* 388 */     enc = TRIPLET_TO_CHARS[ones];
/* 389 */     b[off++] = (char)(enc >> 16);
/* 390 */     b[off++] = (char)(enc >> 8 & 0x7F);
/* 391 */     b[off++] = (char)(enc & 0x7F);
/*     */     
/* 393 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _outputFullBillion(int v, char[] b, int off) {
/* 398 */     int thousands = divBy1000(v);
/* 399 */     int ones = v - thousands * 1000;
/* 400 */     int millions = divBy1000(thousands);
/*     */     
/* 402 */     int enc = TRIPLET_TO_CHARS[millions];
/* 403 */     b[off++] = (char)(enc >> 16);
/* 404 */     b[off++] = (char)(enc >> 8 & 0x7F);
/* 405 */     b[off++] = (char)(enc & 0x7F);
/*     */     
/* 407 */     thousands -= millions * 1000;
/* 408 */     enc = TRIPLET_TO_CHARS[thousands];
/* 409 */     b[off++] = (char)(enc >> 16);
/* 410 */     b[off++] = (char)(enc >> 8 & 0x7F);
/* 411 */     b[off++] = (char)(enc & 0x7F);
/*     */     
/* 413 */     enc = TRIPLET_TO_CHARS[ones];
/* 414 */     b[off++] = (char)(enc >> 16);
/* 415 */     b[off++] = (char)(enc >> 8 & 0x7F);
/* 416 */     b[off++] = (char)(enc & 0x7F);
/*     */     
/* 418 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _outputUptoBillion(int v, byte[] b, int off) {
/* 423 */     if (v < MILLION) {
/* 424 */       if (v < 1000) {
/* 425 */         return _leading3(v, b, off);
/*     */       }
/* 427 */       int i = divBy1000(v);
/* 428 */       int j = v - i * 1000;
/* 429 */       return _outputUptoMillion(b, off, i, j);
/*     */     } 
/* 431 */     int thousands = divBy1000(v);
/* 432 */     int ones = v - thousands * 1000;
/* 433 */     int millions = divBy1000(thousands);
/* 434 */     thousands -= millions * 1000;
/*     */     
/* 436 */     off = _leading3(millions, b, off);
/*     */     
/* 438 */     int enc = TRIPLET_TO_CHARS[thousands];
/* 439 */     b[off++] = (byte)(enc >> 16);
/* 440 */     b[off++] = (byte)(enc >> 8);
/* 441 */     b[off++] = (byte)enc;
/*     */     
/* 443 */     enc = TRIPLET_TO_CHARS[ones];
/* 444 */     b[off++] = (byte)(enc >> 16);
/* 445 */     b[off++] = (byte)(enc >> 8);
/* 446 */     b[off++] = (byte)enc;
/*     */     
/* 448 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _outputFullBillion(int v, byte[] b, int off) {
/* 453 */     int thousands = divBy1000(v);
/* 454 */     int ones = v - thousands * 1000;
/* 455 */     int millions = divBy1000(thousands);
/* 456 */     thousands -= millions * 1000;
/*     */     
/* 458 */     int enc = TRIPLET_TO_CHARS[millions];
/* 459 */     b[off++] = (byte)(enc >> 16);
/* 460 */     b[off++] = (byte)(enc >> 8);
/* 461 */     b[off++] = (byte)enc;
/*     */     
/* 463 */     enc = TRIPLET_TO_CHARS[thousands];
/* 464 */     b[off++] = (byte)(enc >> 16);
/* 465 */     b[off++] = (byte)(enc >> 8);
/* 466 */     b[off++] = (byte)enc;
/*     */     
/* 468 */     enc = TRIPLET_TO_CHARS[ones];
/* 469 */     b[off++] = (byte)(enc >> 16);
/* 470 */     b[off++] = (byte)(enc >> 8);
/* 471 */     b[off++] = (byte)enc;
/*     */     
/* 473 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _outputUptoMillion(char[] b, int off, int thousands, int ones) {
/* 478 */     int enc = TRIPLET_TO_CHARS[thousands];
/* 479 */     if (thousands > 9) {
/* 480 */       if (thousands > 99) {
/* 481 */         b[off++] = (char)(enc >> 16);
/*     */       }
/* 483 */       b[off++] = (char)(enc >> 8 & 0x7F);
/*     */     } 
/* 485 */     b[off++] = (char)(enc & 0x7F);
/*     */     
/* 487 */     enc = TRIPLET_TO_CHARS[ones];
/* 488 */     b[off++] = (char)(enc >> 16);
/* 489 */     b[off++] = (char)(enc >> 8 & 0x7F);
/* 490 */     b[off++] = (char)(enc & 0x7F);
/* 491 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _outputUptoMillion(byte[] b, int off, int thousands, int ones) {
/* 496 */     int enc = TRIPLET_TO_CHARS[thousands];
/* 497 */     if (thousands > 9) {
/* 498 */       if (thousands > 99) {
/* 499 */         b[off++] = (byte)(enc >> 16);
/*     */       }
/* 501 */       b[off++] = (byte)(enc >> 8);
/*     */     } 
/* 503 */     b[off++] = (byte)enc;
/*     */     
/* 505 */     enc = TRIPLET_TO_CHARS[ones];
/* 506 */     b[off++] = (byte)(enc >> 16);
/* 507 */     b[off++] = (byte)(enc >> 8);
/* 508 */     b[off++] = (byte)enc;
/* 509 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _leading3(int t, char[] b, int off) {
/* 514 */     int enc = TRIPLET_TO_CHARS[t];
/* 515 */     if (t > 9) {
/* 516 */       if (t > 99) {
/* 517 */         b[off++] = (char)(enc >> 16);
/*     */       }
/* 519 */       b[off++] = (char)(enc >> 8 & 0x7F);
/*     */     } 
/* 521 */     b[off++] = (char)(enc & 0x7F);
/* 522 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _leading3(int t, byte[] b, int off) {
/* 527 */     int enc = TRIPLET_TO_CHARS[t];
/* 528 */     if (t > 9) {
/* 529 */       if (t > 99) {
/* 530 */         b[off++] = (byte)(enc >> 16);
/*     */       }
/* 532 */       b[off++] = (byte)(enc >> 8);
/*     */     } 
/* 534 */     b[off++] = (byte)enc;
/* 535 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _full3(int t, char[] b, int off) {
/* 540 */     int enc = TRIPLET_TO_CHARS[t];
/* 541 */     b[off++] = (char)(enc >> 16);
/* 542 */     b[off++] = (char)(enc >> 8 & 0x7F);
/* 543 */     b[off++] = (char)(enc & 0x7F);
/* 544 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _full3(int t, byte[] b, int off) {
/* 549 */     int enc = TRIPLET_TO_CHARS[t];
/* 550 */     b[off++] = (byte)(enc >> 16);
/* 551 */     b[off++] = (byte)(enc >> 8);
/* 552 */     b[off++] = (byte)enc;
/* 553 */     return off;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int _outputSmallestL(char[] b, int off) {
/* 560 */     int len = SMALLEST_LONG.length();
/* 561 */     SMALLEST_LONG.getChars(0, len, b, off);
/* 562 */     return off + len;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _outputSmallestL(byte[] b, int off) {
/* 567 */     int len = SMALLEST_LONG.length();
/* 568 */     for (int i = 0; i < len; i++) {
/* 569 */       b[off++] = (byte)SMALLEST_LONG.charAt(i);
/*     */     }
/* 571 */     return off;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _outputSmallestI(char[] b, int off) {
/* 576 */     int len = SMALLEST_INT.length();
/* 577 */     SMALLEST_INT.getChars(0, len, b, off);
/* 578 */     return off + len;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int _outputSmallestI(byte[] b, int off) {
/* 583 */     int len = SMALLEST_INT.length();
/* 584 */     for (int i = 0; i < len; i++) {
/* 585 */       b[off++] = (byte)SMALLEST_INT.charAt(i);
/*     */     }
/* 587 */     return off;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\io\NumberOutput.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */