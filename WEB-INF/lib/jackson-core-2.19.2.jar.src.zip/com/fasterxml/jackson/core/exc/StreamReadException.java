/*     */ package com.fasterxml.jackson.core.exc;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonLocation;
/*     */ import com.fasterxml.jackson.core.JsonParser;
/*     */ import com.fasterxml.jackson.core.JsonProcessingException;
/*     */ import com.fasterxml.jackson.core.util.RequestPayload;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class StreamReadException
/*     */   extends JsonProcessingException
/*     */ {
/*     */   static final long serialVersionUID = 2L;
/*     */   protected transient JsonParser _processor;
/*     */   protected RequestPayload _requestPayload;
/*     */   
/*     */   protected StreamReadException(String msg) {
/*  31 */     this(null, msg, null, null);
/*     */   }
/*     */   
/*     */   protected StreamReadException(JsonParser p, String msg) {
/*  35 */     this(p, msg, _currentLocation(p), null);
/*     */   }
/*     */   
/*     */   protected StreamReadException(JsonParser p, String msg, Throwable rootCause) {
/*  39 */     this(p, msg, _currentLocation(p), rootCause);
/*     */   }
/*     */   
/*     */   protected StreamReadException(JsonParser p, String msg, JsonLocation loc) {
/*  43 */     this(p, msg, loc, null);
/*     */   }
/*     */   
/*     */   protected StreamReadException(String msg, JsonLocation loc, Throwable rootCause) {
/*  47 */     this(null, msg, loc, rootCause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected StreamReadException(JsonParser p, String msg, JsonLocation loc, Throwable rootCause) {
/*  54 */     super(msg, loc, rootCause);
/*  55 */     this._processor = p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonParser getProcessor() {
/*  84 */     return this._processor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RequestPayload getRequestPayload() {
/*  94 */     return this._requestPayload;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRequestPayloadAsString() {
/* 104 */     return (this._requestPayload != null) ? this._requestPayload.toString() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 112 */     String msg = super.getMessage();
/* 113 */     if (this._requestPayload != null) {
/* 114 */       msg = msg + "\nRequest payload : " + this._requestPayload.toString();
/*     */     }
/* 116 */     return msg;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static JsonLocation _currentLocation(JsonParser p) {
/* 121 */     return (p == null) ? null : p.currentLocation();
/*     */   }
/*     */   
/*     */   public abstract StreamReadException withParser(JsonParser paramJsonParser);
/*     */   
/*     */   public abstract StreamReadException withRequestPayload(RequestPayload paramRequestPayload);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\exc\StreamReadException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */