/*    */ package com.fasterxml.jackson.core.exc;
/*    */ 
/*    */ import com.fasterxml.jackson.core.JsonLocation;
/*    */ import com.fasterxml.jackson.core.JsonProcessingException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StreamConstraintsException
/*    */   extends JsonProcessingException
/*    */ {
/*    */   private static final long serialVersionUID = 2L;
/*    */   
/*    */   public StreamConstraintsException(String msg) {
/* 19 */     super(msg);
/*    */   }
/*    */   
/*    */   public StreamConstraintsException(String msg, JsonLocation loc) {
/* 23 */     super(msg, loc);
/*    */   }
/*    */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\exc\StreamConstraintsException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */