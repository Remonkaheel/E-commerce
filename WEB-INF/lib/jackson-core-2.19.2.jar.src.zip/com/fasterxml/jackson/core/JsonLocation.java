/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import com.fasterxml.jackson.core.io.ContentReference;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonLocation
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2L;
/*     */   @Deprecated
/*     */   public static final int MAX_CONTENT_SNIPPET = 500;
/*  38 */   public static final JsonLocation NA = new JsonLocation(ContentReference.unknown(), -1L, -1L, -1, -1);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final long _totalBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final long _totalChars;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _lineNr;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int _columnNr;
/*     */ 
/*     */ 
/*     */   
/*     */   protected final ContentReference _contentReference;
/*     */ 
/*     */ 
/*     */   
/*     */   protected transient String _sourceDescription;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonLocation(ContentReference contentRef, long totalChars, int lineNr, int colNr) {
/*  72 */     this(contentRef, -1L, totalChars, lineNr, colNr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonLocation(ContentReference contentRef, long totalBytes, long totalChars, int lineNr, int columnNr) {
/*  79 */     if (contentRef == null) {
/*  80 */       contentRef = ContentReference.unknown();
/*     */     }
/*  82 */     this._contentReference = contentRef;
/*  83 */     this._totalBytes = totalBytes;
/*  84 */     this._totalChars = totalChars;
/*  85 */     this._lineNr = lineNr;
/*  86 */     this._columnNr = columnNr;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public JsonLocation(Object srcRef, long totalChars, int lineNr, int columnNr) {
/*  91 */     this(_wrap(srcRef), totalChars, lineNr, columnNr);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public JsonLocation(Object srcRef, long totalBytes, long totalChars, int lineNr, int columnNr) {
/*  97 */     this(_wrap(srcRef), totalBytes, totalChars, lineNr, columnNr);
/*     */   }
/*     */   
/*     */   protected static ContentReference _wrap(Object srcRef) {
/* 101 */     if (srcRef instanceof ContentReference) {
/* 102 */       return (ContentReference)srcRef;
/*     */     }
/* 104 */     return ContentReference.construct(false, srcRef, ErrorReportConfiguration.defaults());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ContentReference contentReference() {
/* 126 */     return this._contentReference;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Object getSourceRef() {
/* 143 */     return this._contentReference.getRawContent();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineNr() {
/* 152 */     return this._lineNr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnNr() {
/* 166 */     return this._columnNr;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getCharOffset() {
/* 172 */     return this._totalChars;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long getByteOffset() {
/* 178 */     return this._totalBytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String sourceDescription() {
/* 196 */     if (this._sourceDescription == null) {
/* 197 */       this._sourceDescription = this._contentReference.buildSourceDescription();
/*     */     }
/* 199 */     return this._sourceDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String offsetDescription() {
/* 212 */     return appendOffsetDescription(new StringBuilder(40)).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuilder appendOffsetDescription(StringBuilder sb) {
/* 222 */     if (this._contentReference.hasTextualContent()) {
/* 223 */       sb.append("line: ");
/*     */       
/* 225 */       if (this._lineNr >= 0) {
/* 226 */         sb.append(this._lineNr);
/*     */       } else {
/* 228 */         sb.append("UNKNOWN");
/*     */       } 
/* 230 */       sb.append(", column: ");
/* 231 */       if (this._columnNr >= 0) {
/* 232 */         sb.append(this._columnNr);
/*     */       } else {
/* 234 */         sb.append("UNKNOWN");
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 240 */     else if (this._lineNr > 0) {
/* 241 */       sb.append("line: ").append(this._lineNr);
/* 242 */       if (this._columnNr > 0) {
/* 243 */         sb.append(", column: ");
/* 244 */         sb.append(this._columnNr);
/*     */       } 
/*     */     } else {
/* 247 */       sb.append("byte offset: #");
/*     */ 
/*     */       
/* 250 */       if (this._totalBytes >= 0L) {
/* 251 */         sb.append(this._totalBytes);
/*     */       } else {
/* 253 */         sb.append("UNKNOWN");
/*     */       } 
/*     */     } 
/*     */     
/* 257 */     return sb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 269 */     int hash = (this._contentReference == null) ? 1 : 2;
/* 270 */     hash ^= this._lineNr;
/* 271 */     hash += this._columnNr;
/* 272 */     hash ^= (int)this._totalChars;
/* 273 */     hash += (int)this._totalBytes;
/* 274 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/* 280 */     if (other == this) return true; 
/* 281 */     if (other == null) return false; 
/* 282 */     if (!(other instanceof JsonLocation)) return false; 
/* 283 */     JsonLocation otherLoc = (JsonLocation)other;
/*     */     
/* 285 */     if (this._contentReference == null) {
/* 286 */       if (otherLoc._contentReference != null) return false; 
/* 287 */     } else if (!this._contentReference.equals(otherLoc._contentReference)) {
/* 288 */       return false;
/*     */     } 
/*     */     
/* 291 */     return (this._lineNr == otherLoc._lineNr && this._columnNr == otherLoc._columnNr && this._totalChars == otherLoc._totalChars && this._totalBytes == otherLoc._totalBytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 301 */     String srcDesc = sourceDescription();
/*     */ 
/*     */ 
/*     */     
/* 305 */     StringBuilder sb = (new StringBuilder(40 + srcDesc.length())).append("[Source: ").append(srcDesc).append("; ");
/* 306 */     return appendOffsetDescription(sb)
/* 307 */       .append(']')
/* 308 */       .toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\JsonLocation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */