/*      */ package com.fasterxml.jackson.core;
/*      */ 
/*      */ import com.fasterxml.jackson.core.exc.StreamWriteException;
/*      */ import com.fasterxml.jackson.core.io.CharacterEscapes;
/*      */ import com.fasterxml.jackson.core.type.WritableTypeId;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeature;
/*      */ import com.fasterxml.jackson.core.util.JacksonFeatureSet;
/*      */ import com.fasterxml.jackson.core.util.VersionUtil;
/*      */ import java.io.Closeable;
/*      */ import java.io.Flushable;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.util.Objects;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import java.util.concurrent.atomic.AtomicLong;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class JsonGenerator
/*      */   implements Closeable, Flushable, Versioned
/*      */ {
/*   44 */   protected static final JacksonFeatureSet<StreamWriteCapability> DEFAULT_WRITE_CAPABILITIES = JacksonFeatureSet.fromDefaults((JacksonFeature[])StreamWriteCapability.values());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   52 */   protected static final JacksonFeatureSet<StreamWriteCapability> DEFAULT_TEXTUAL_WRITE_CAPABILITIES = DEFAULT_WRITE_CAPABILITIES
/*   53 */     .with(StreamWriteCapability.CAN_WRITE_FORMATTED_NUMBERS);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   61 */   protected static final JacksonFeatureSet<StreamWriteCapability> DEFAULT_BINARY_WRITE_CAPABILITIES = DEFAULT_WRITE_CAPABILITIES
/*   62 */     .with(StreamWriteCapability.CAN_WRITE_BINARY_NATIVELY);
/*      */ 
/*      */ 
/*      */   
/*      */   protected PrettyPrinter _cfgPrettyPrinter;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract JsonGenerator setCodec(ObjectCodec paramObjectCodec);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract ObjectCodec getCodec();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Feature
/*      */   {
/*   83 */     AUTO_CLOSE_TARGET(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   95 */     AUTO_CLOSE_JSON_CONTENT(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  108 */     FLUSH_PASSED_TO_STREAM(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  123 */     QUOTE_FIELD_NAMES(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  140 */     QUOTE_NON_NUMERIC_NUMBERS(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  162 */     ESCAPE_NON_ASCII(false),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  187 */     WRITE_NUMBERS_AS_STRINGS(false),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  204 */     WRITE_BIGDECIMAL_AS_PLAIN(false),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  223 */     STRICT_DUPLICATE_DETECTION(false),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  245 */     IGNORE_UNKNOWN(false),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  255 */     USE_FAST_DOUBLE_WRITER(false),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  269 */     WRITE_HEX_UPPER_CASE(true),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  277 */     ESCAPE_FORWARD_SLASHES(false),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  284 */     COMBINE_UNICODE_SURROGATES_IN_UTF8(false);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean _defaultState;
/*      */ 
/*      */ 
/*      */     
/*      */     private final int _mask;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static int collectDefaults() {
/*  299 */       int flags = 0;
/*  300 */       for (Feature f : values()) {
/*  301 */         if (f.enabledByDefault()) {
/*  302 */           flags |= f.getMask();
/*      */         }
/*      */       } 
/*  305 */       return flags;
/*      */     }
/*      */     
/*      */     Feature(boolean defaultState) {
/*  309 */       this._defaultState = defaultState;
/*  310 */       this._mask = 1 << ordinal();
/*      */     }
/*      */     public boolean enabledByDefault() {
/*  313 */       return this._defaultState;
/*      */     }
/*      */     public boolean enabledIn(int flags) {
/*  316 */       return ((flags & this._mask) != 0);
/*      */     } public int getMask() {
/*  318 */       return this._mask;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StreamWriteConstraints streamWriteConstraints() {
/*  370 */     return StreamWriteConstraints.defaults();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract Version version();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract JsonStreamContext getOutputContext();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getOutputTarget() {
/*  414 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object currentValue() {
/*  433 */     JsonStreamContext ctxt = getOutputContext();
/*  434 */     return (ctxt == null) ? null : ctxt.getCurrentValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void assignCurrentValue(Object v) {
/*  448 */     JsonStreamContext ctxt = getOutputContext();
/*  449 */     if (ctxt != null) {
/*  450 */       ctxt.setCurrentValue(v);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Object getCurrentValue() {
/*  464 */     return currentValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setCurrentValue(Object v) {
/*  477 */     assignCurrentValue(v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract JsonGenerator enable(Feature paramFeature);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract JsonGenerator disable(Feature paramFeature);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final JsonGenerator configure(Feature f, boolean state) {
/*  516 */     if (state) { enable(f); } else { disable(f); }
/*  517 */      return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean isEnabled(Feature paramFeature);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled(StreamWriteFeature f) {
/*  541 */     return isEnabled(f.mappedFeature());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int getFeatureMask();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public abstract JsonGenerator setFeatureMask(int paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator overrideStdFeatures(int values, int mask) {
/*  587 */     int oldState = getFeatureMask();
/*  588 */     int newState = oldState & (mask ^ 0xFFFFFFFF) | values & mask;
/*  589 */     return setFeatureMask(newState);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFormatFeatures() {
/*  601 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator overrideFormatFeatures(int values, int mask) {
/*  623 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSchema(FormatSchema schema) {
/*  648 */     throw new UnsupportedOperationException(String.format("Generator of type %s does not support schema of type '%s'", new Object[] {
/*      */             
/*  650 */             getClass().getName(), schema.getSchemaType()
/*      */           }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FormatSchema getSchema() {
/*  659 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator setPrettyPrinter(PrettyPrinter pp) {
/*  681 */     this._cfgPrettyPrinter = pp;
/*  682 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PrettyPrinter getPrettyPrinter() {
/*  692 */     return this._cfgPrettyPrinter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract JsonGenerator useDefaultPrettyPrinter();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator setHighestNonEscapedChar(int charCode) {
/*  727 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHighestEscapedChar() {
/*  741 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CharacterEscapes getCharacterEscapes() {
/*  749 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator setCharacterEscapes(CharacterEscapes esc) {
/*  761 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JsonGenerator setRootValueSeparator(SerializableString sep) {
/*  775 */     throw new UnsupportedOperationException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getOutputBuffered() {
/*  803 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canUseSchema(FormatSchema schema) {
/*  820 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canWriteObjectId() {
/*  840 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canWriteTypeId() {
/*  860 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canWriteBinaryNatively() {
/*  877 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canOmitFields() {
/*  890 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canWriteFormattedNumbers() {
/*  909 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public JacksonFeatureSet<StreamWriteCapability> getWriteCapabilities() {
/*  920 */     return DEFAULT_WRITE_CAPABILITIES;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeStartArray() throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void writeStartArray(int size) throws IOException {
/*  966 */     writeStartArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object forValue) throws IOException {
/*  983 */     writeStartArray();
/*  984 */     setCurrentValue(forValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartArray(Object forValue, int size) throws IOException {
/* 1006 */     writeStartArray(size);
/* 1007 */     setCurrentValue(forValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeEndArray() throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeStartObject() throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue) throws IOException {
/* 1057 */     writeStartObject();
/* 1058 */     setCurrentValue(forValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStartObject(Object forValue, int size) throws IOException {
/* 1088 */     writeStartObject(forValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeEndObject() throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeFieldName(String paramString) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeFieldName(SerializableString paramSerializableString) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeFieldId(long id) throws IOException {
/* 1156 */     writeFieldName(Long.toString(id));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeArray(int[] array, int offset, int length) throws IOException {
/* 1181 */     if (array == null) {
/* 1182 */       throw new IllegalArgumentException("null array");
/*      */     }
/* 1184 */     _verifyOffsets(array.length, offset, length);
/* 1185 */     writeStartArray(array, length);
/* 1186 */     for (int i = offset, end = offset + length; i < end; i++) {
/* 1187 */       writeNumber(array[i]);
/*      */     }
/* 1189 */     writeEndArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeArray(long[] array, int offset, int length) throws IOException {
/* 1208 */     if (array == null) {
/* 1209 */       throw new IllegalArgumentException("null array");
/*      */     }
/* 1211 */     _verifyOffsets(array.length, offset, length);
/* 1212 */     writeStartArray(array, length);
/* 1213 */     for (int i = offset, end = offset + length; i < end; i++) {
/* 1214 */       writeNumber(array[i]);
/*      */     }
/* 1216 */     writeEndArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeArray(double[] array, int offset, int length) throws IOException {
/* 1235 */     if (array == null) {
/* 1236 */       throw new IllegalArgumentException("null array");
/*      */     }
/* 1238 */     _verifyOffsets(array.length, offset, length);
/* 1239 */     writeStartArray(array, length);
/* 1240 */     for (int i = offset, end = offset + length; i < end; i++) {
/* 1241 */       writeNumber(array[i]);
/*      */     }
/* 1243 */     writeEndArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeArray(String[] array, int offset, int length) throws IOException {
/* 1262 */     if (array == null) {
/* 1263 */       throw new IllegalArgumentException("null array");
/*      */     }
/* 1265 */     _verifyOffsets(array.length, offset, length);
/* 1266 */     writeStartArray(array, length);
/* 1267 */     for (int i = offset, end = offset + length; i < end; i++) {
/* 1268 */       writeString(array[i]);
/*      */     }
/* 1270 */     writeEndArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeString(String paramString) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeString(Reader reader, int len) throws IOException {
/* 1318 */     _reportUnsupportedOperation();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeString(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeString(SerializableString paramSerializableString) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeRawUTF8String(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeUTF8String(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeRaw(String paramString) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeRaw(String paramString, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeRaw(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeRaw(char paramChar) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRaw(SerializableString raw) throws IOException {
/* 1516 */     writeRaw(raw.getValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeRawValue(String paramString) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeRawValue(String paramString, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeRawValue(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeRawValue(SerializableString raw) throws IOException {
/* 1551 */     writeRawValue(raw.getValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeBinary(Base64Variant paramBase64Variant, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBinary(byte[] data, int offset, int len) throws IOException {
/* 1597 */     writeBinary(Base64Variants.getDefaultVariant(), data, offset, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBinary(byte[] data) throws IOException {
/* 1612 */     writeBinary(Base64Variants.getDefaultVariant(), data, 0, data.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int writeBinary(InputStream data, int dataLength) throws IOException {
/* 1635 */     return writeBinary(Base64Variants.getDefaultVariant(), data, dataLength);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int writeBinary(Base64Variant paramBase64Variant, InputStream paramInputStream, int paramInt) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(short v) throws IOException {
/* 1683 */     writeNumber(v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeNumber(int paramInt) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeNumber(long paramLong) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeNumber(BigInteger paramBigInteger) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeNumber(double paramDouble) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeNumber(float paramFloat) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeNumber(BigDecimal paramBigDecimal) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeNumber(String paramString) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumber(char[] encodedValueBuffer, int offset, int len) throws IOException {
/* 1810 */     writeNumber(new String(encodedValueBuffer, offset, len));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeBoolean(boolean paramBoolean) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeNull() throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeEmbeddedObject(Object object) throws IOException {
/* 1863 */     if (object == null) {
/* 1864 */       writeNull();
/*      */       return;
/*      */     } 
/* 1867 */     if (object instanceof byte[]) {
/* 1868 */       writeBinary((byte[])object);
/*      */       return;
/*      */     } 
/* 1871 */     throw new JsonGenerationException("No native support for writing embedded objects of type " + object
/* 1872 */         .getClass().getName(), this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeObjectId(Object id) throws IOException {
/* 1901 */     throw new JsonGenerationException("No native support for writing Object Ids", this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeObjectRef(Object referenced) throws IOException {
/* 1921 */     throw new JsonGenerationException("No native support for writing Object Ids", this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeTypeId(Object id) throws IOException {
/* 1943 */     throw new JsonGenerationException("No native support for writing Type Ids", this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WritableTypeId writeTypePrefix(WritableTypeId typeIdDef) throws IOException {
/* 1975 */     boolean wasStartObjectWritten = canWriteTypeId() ? _writeTypePrefixUsingNative(typeIdDef) : _writeTypePrefixUsingWrapper(typeIdDef);
/*      */ 
/*      */     
/* 1978 */     switch (typeIdDef.valueShape) {
/*      */       case PARENT_PROPERTY:
/* 1980 */         if (!wasStartObjectWritten) {
/* 1981 */           writeStartObject(typeIdDef.forValue);
/*      */         }
/*      */         break;
/*      */       case PAYLOAD_PROPERTY:
/* 1985 */         writeStartArray(typeIdDef.forValue);
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 1990 */     return typeIdDef;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _writeTypePrefixUsingNative(WritableTypeId typeIdDef) throws IOException {
/* 2001 */     typeIdDef.wrapperWritten = false;
/* 2002 */     writeTypeId(typeIdDef.id);
/* 2003 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _writeTypePrefixUsingWrapper(WritableTypeId typeIdDef) throws IOException {
/* 2015 */     String id = Objects.toString(typeIdDef.id, null);
/*      */ 
/*      */     
/* 2018 */     if (id == null) {
/* 2019 */       return false;
/*      */     }
/*      */     
/* 2022 */     WritableTypeId.Inclusion incl = typeIdDef.include;
/*      */ 
/*      */     
/* 2025 */     if (typeIdDef.valueShape != JsonToken.START_OBJECT && incl.requiresObjectContext()) {
/* 2026 */       typeIdDef.include = incl = WritableTypeId.Inclusion.WRAPPER_ARRAY;
/*      */     }
/*      */     
/* 2029 */     typeIdDef.wrapperWritten = true;
/*      */     
/* 2031 */     switch (incl) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case PARENT_PROPERTY:
/*      */       case PAYLOAD_PROPERTY:
/* 2059 */         return false;
/*      */       case METADATA_PROPERTY:
/*      */         writeStartObject(typeIdDef.forValue);
/*      */         writeStringField(typeIdDef.asProperty, id);
/*      */         return true;
/*      */       case WRAPPER_OBJECT:
/*      */         writeStartObject();
/*      */         writeFieldName(id);
/*      */     } 
/*      */     writeStartArray();
/*      */     writeString(id);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WritableTypeId writeTypeSuffix(WritableTypeId typeIdDef) throws IOException {
/* 2081 */     JsonToken valueShape = typeIdDef.valueShape;
/*      */     
/* 2083 */     if (valueShape == JsonToken.START_OBJECT) {
/* 2084 */       writeEndObject();
/* 2085 */     } else if (valueShape == JsonToken.START_ARRAY) {
/* 2086 */       writeEndArray();
/*      */     } 
/*      */     
/* 2089 */     if (typeIdDef.wrapperWritten) {
/* 2090 */       Object id; String idStr; switch (typeIdDef.include) {
/*      */         case WRAPPER_ARRAY:
/* 2092 */           writeEndArray();
/*      */ 
/*      */ 
/*      */         
/*      */         case PARENT_PROPERTY:
/* 2097 */           id = typeIdDef.id;
/* 2098 */           idStr = (id instanceof String) ? (String)id : String.valueOf(id);
/* 2099 */           writeStringField(typeIdDef.asProperty, idStr);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case PAYLOAD_PROPERTY:
/*      */         case METADATA_PROPERTY:
/* 2112 */           return typeIdDef;
/*      */       } 
/*      */       writeEndObject();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writePOJO(Object pojo) throws IOException {
/* 2140 */     writeObject(pojo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeObject(Object paramObject) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void writeTree(TreeNode paramTreeNode) throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBinaryField(String fieldName, byte[] data) throws IOException {
/* 2195 */     writeFieldName(fieldName);
/* 2196 */     writeBinary(data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeBooleanField(String fieldName, boolean value) throws IOException {
/* 2214 */     writeFieldName(fieldName);
/* 2215 */     writeBoolean(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNullField(String fieldName) throws IOException {
/* 2232 */     writeFieldName(fieldName);
/* 2233 */     writeNull();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeStringField(String fieldName, String value) throws IOException {
/* 2251 */     writeFieldName(fieldName);
/* 2252 */     writeString(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumberField(String fieldName, short value) throws IOException {
/* 2272 */     writeFieldName(fieldName);
/* 2273 */     writeNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumberField(String fieldName, int value) throws IOException {
/* 2291 */     writeFieldName(fieldName);
/* 2292 */     writeNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumberField(String fieldName, long value) throws IOException {
/* 2310 */     writeFieldName(fieldName);
/* 2311 */     writeNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumberField(String fieldName, BigInteger value) throws IOException {
/* 2331 */     writeFieldName(fieldName);
/* 2332 */     writeNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumberField(String fieldName, float value) throws IOException {
/* 2350 */     writeFieldName(fieldName);
/* 2351 */     writeNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumberField(String fieldName, double value) throws IOException {
/* 2369 */     writeFieldName(fieldName);
/* 2370 */     writeNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeNumberField(String fieldName, BigDecimal value) throws IOException {
/* 2389 */     writeFieldName(fieldName);
/* 2390 */     writeNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeArrayFieldStart(String fieldName) throws IOException {
/* 2412 */     writeFieldName(fieldName);
/* 2413 */     writeStartArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeObjectFieldStart(String fieldName) throws IOException {
/* 2435 */     writeFieldName(fieldName);
/* 2436 */     writeStartObject();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writePOJOField(String fieldName, Object pojo) throws IOException {
/* 2458 */     writeObjectField(fieldName, pojo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeObjectField(String fieldName, Object pojo) throws IOException {
/* 2472 */     writeFieldName(fieldName);
/* 2473 */     writeObject(pojo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeOmittedField(String fieldName) throws IOException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyCurrentEvent(JsonParser p) throws IOException {
/* 2517 */     JsonToken t = p.currentToken();
/* 2518 */     int token = (t == null) ? -1 : t.id();
/* 2519 */     switch (token) {
/*      */       case -1:
/* 2521 */         throw _constructWriteException("No current event to copy");
/*      */       case 1:
/* 2523 */         writeStartObject();
/*      */         return;
/*      */       case 2:
/* 2526 */         writeEndObject();
/*      */         return;
/*      */       case 3:
/* 2529 */         writeStartArray();
/*      */         return;
/*      */       case 4:
/* 2532 */         writeEndArray();
/*      */         return;
/*      */       case 5:
/* 2535 */         writeFieldName(p.currentName());
/*      */         return;
/*      */       case 6:
/* 2538 */         _copyCurrentStringValue(p);
/*      */         return;
/*      */       case 7:
/* 2541 */         _copyCurrentIntValue(p);
/*      */         return;
/*      */       
/*      */       case 8:
/* 2545 */         _copyCurrentFloatValue(p);
/*      */         return;
/*      */       case 9:
/* 2548 */         writeBoolean(true);
/*      */         return;
/*      */       case 10:
/* 2551 */         writeBoolean(false);
/*      */         return;
/*      */       case 11:
/* 2554 */         writeNull();
/*      */         return;
/*      */       case 12:
/* 2557 */         writeObject(p.getEmbeddedObject());
/*      */         return;
/*      */     } 
/* 2560 */     throw new IllegalStateException("Internal error: unknown current token, " + t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyCurrentEventExact(JsonParser p) throws IOException {
/* 2580 */     JsonToken t = p.currentToken();
/* 2581 */     int token = (t == null) ? -1 : t.id();
/* 2582 */     switch (token) {
/*      */       case -1:
/* 2584 */         throw _constructWriteException("No current event to copy");
/*      */       case 1:
/* 2586 */         writeStartObject();
/*      */         return;
/*      */       case 2:
/* 2589 */         writeEndObject();
/*      */         return;
/*      */       case 3:
/* 2592 */         writeStartArray();
/*      */         return;
/*      */       case 4:
/* 2595 */         writeEndArray();
/*      */         return;
/*      */       case 5:
/* 2598 */         writeFieldName(p.currentName());
/*      */         return;
/*      */       case 6:
/* 2601 */         _copyCurrentStringValue(p);
/*      */         return;
/*      */       case 7:
/* 2604 */         _copyCurrentIntValue(p);
/*      */         return;
/*      */       
/*      */       case 8:
/* 2608 */         _copyCurrentFloatValueExact(p);
/*      */         return;
/*      */       case 9:
/* 2611 */         writeBoolean(true);
/*      */         return;
/*      */       case 10:
/* 2614 */         writeBoolean(false);
/*      */         return;
/*      */       case 11:
/* 2617 */         writeNull();
/*      */         return;
/*      */       case 12:
/* 2620 */         writeObject(p.getEmbeddedObject());
/*      */         return;
/*      */     } 
/* 2623 */     throw new IllegalStateException("Internal error: unknown current token, " + t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copyCurrentStructure(JsonParser p) throws IOException {
/* 2669 */     JsonToken t = p.currentToken();
/*      */     
/* 2671 */     int id = (t == null) ? -1 : t.id();
/* 2672 */     if (id == 5) {
/* 2673 */       writeFieldName(p.currentName());
/* 2674 */       t = p.nextToken();
/* 2675 */       id = (t == null) ? -1 : t.id();
/*      */     } 
/*      */     
/* 2678 */     switch (id) {
/*      */       case 1:
/* 2680 */         writeStartObject();
/* 2681 */         _copyCurrentContents(p);
/*      */         return;
/*      */       case 3:
/* 2684 */         writeStartArray();
/* 2685 */         _copyCurrentContents(p);
/*      */         return;
/*      */     } 
/*      */     
/* 2689 */     copyCurrentEvent(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _copyCurrentContents(JsonParser p) throws IOException {
/* 2696 */     int depth = 1;
/*      */     
/*      */     JsonToken t;
/*      */     
/* 2700 */     while ((t = p.nextToken()) != null) {
/* 2701 */       switch (t.id()) {
/*      */         case 5:
/* 2703 */           writeFieldName(p.currentName());
/*      */           continue;
/*      */         
/*      */         case 3:
/* 2707 */           writeStartArray();
/* 2708 */           depth++;
/*      */           continue;
/*      */         
/*      */         case 1:
/* 2712 */           writeStartObject();
/* 2713 */           depth++;
/*      */           continue;
/*      */         
/*      */         case 4:
/* 2717 */           writeEndArray();
/* 2718 */           if (--depth == 0) {
/*      */             return;
/*      */           }
/*      */           continue;
/*      */         case 2:
/* 2723 */           writeEndObject();
/* 2724 */           if (--depth == 0) {
/*      */             return;
/*      */           }
/*      */           continue;
/*      */         
/*      */         case 6:
/* 2730 */           _copyCurrentStringValue(p);
/*      */           continue;
/*      */         case 7:
/* 2733 */           _copyCurrentIntValue(p);
/*      */           continue;
/*      */         case 8:
/* 2736 */           _copyCurrentFloatValue(p);
/*      */           continue;
/*      */         case 9:
/* 2739 */           writeBoolean(true);
/*      */           continue;
/*      */         case 10:
/* 2742 */           writeBoolean(false);
/*      */           continue;
/*      */         case 11:
/* 2745 */           writeNull();
/*      */           continue;
/*      */         case 12:
/* 2748 */           writeObject(p.getEmbeddedObject());
/*      */           continue;
/*      */       } 
/* 2751 */       throw new IllegalStateException("Internal error: unknown current token, " + t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _copyCurrentFloatValue(JsonParser p) throws IOException {
/* 2774 */     JsonParser.NumberType t = p.getNumberType();
/* 2775 */     if (t == JsonParser.NumberType.BIG_DECIMAL) {
/* 2776 */       writeNumber(p.getDecimalValue());
/* 2777 */     } else if (t == JsonParser.NumberType.FLOAT) {
/* 2778 */       writeNumber(p.getFloatValue());
/*      */     } else {
/* 2780 */       writeNumber(p.getDoubleValue());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _copyCurrentFloatValueExact(JsonParser p) throws IOException {
/* 2802 */     Number n = p.getNumberValueExact();
/* 2803 */     if (n instanceof BigDecimal) {
/* 2804 */       writeNumber((BigDecimal)n);
/* 2805 */     } else if (n instanceof Double) {
/* 2806 */       writeNumber(n.doubleValue());
/*      */     } else {
/* 2808 */       writeNumber(n.floatValue());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _copyCurrentIntValue(JsonParser p) throws IOException {
/* 2824 */     JsonParser.NumberType n = p.getNumberType();
/* 2825 */     if (n == JsonParser.NumberType.INT) {
/* 2826 */       writeNumber(p.getIntValue());
/* 2827 */     } else if (n == JsonParser.NumberType.LONG) {
/* 2828 */       writeNumber(p.getLongValue());
/*      */     } else {
/* 2830 */       writeNumber(p.getBigIntegerValue());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _copyCurrentStringValue(JsonParser p) throws IOException {
/* 2846 */     if (p.hasTextCharacters()) {
/* 2847 */       writeString(p.getTextCharacters(), p.getTextOffset(), p.getTextLength());
/*      */     } else {
/* 2849 */       writeString(p.getText());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void flush() throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean isClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void close() throws IOException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _reportError(String msg) throws JsonGenerationException {
/* 2919 */     throw (JsonGenerationException)_constructWriteException(msg);
/*      */   }
/*      */   protected final void _throwInternal() {
/* 2922 */     VersionUtil.throwInternal();
/*      */   }
/*      */   protected void _reportUnsupportedOperation() {
/* 2925 */     _reportUnsupportedOperation("Operation not supported by `JsonGenerator` of type " + getClass().getName());
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _reportUnsupportedOperation(String msg) {
/* 2930 */     throw new UnsupportedOperationException(msg);
/*      */   }
/*      */ 
/*      */   
/*      */   protected StreamWriteException _constructWriteException(String msg) {
/* 2935 */     return new JsonGenerationException(msg, this);
/*      */   }
/*      */ 
/*      */   
/*      */   protected StreamWriteException _constructWriteException(String msg, Object arg) {
/* 2940 */     return _constructWriteException(String.format(msg, new Object[] { arg }));
/*      */   }
/*      */ 
/*      */   
/*      */   protected StreamWriteException _constructWriteException(String msg, Object arg1, Object arg2) {
/* 2945 */     return _constructWriteException(String.format(msg, new Object[] { arg1, arg2 }));
/*      */   }
/*      */ 
/*      */   
/*      */   protected StreamWriteException _constructWriteException(String msg, Throwable t) {
/* 2950 */     return new JsonGenerationException(msg, t, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void _verifyOffsets(int arrayLength, int offset, int length) {
/* 2962 */     if (offset < 0 || offset + length > arrayLength) {
/* 2963 */       throw new IllegalArgumentException(String.format("invalid argument(s) (offset=%d, length=%d) for input array of %d element", new Object[] {
/*      */               
/* 2965 */               Integer.valueOf(offset), Integer.valueOf(length), Integer.valueOf(arrayLength)
/*      */             }));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _writeSimpleObject(Object value) throws IOException {
/* 2984 */     if (value == null) {
/* 2985 */       writeNull();
/*      */       return;
/*      */     } 
/* 2988 */     if (value instanceof String) {
/* 2989 */       writeString((String)value);
/*      */       return;
/*      */     } 
/* 2992 */     if (value instanceof Number) {
/* 2993 */       Number n = (Number)value;
/* 2994 */       if (n instanceof Integer) {
/* 2995 */         writeNumber(n.intValue()); return;
/*      */       } 
/* 2997 */       if (n instanceof Long) {
/* 2998 */         writeNumber(n.longValue()); return;
/*      */       } 
/* 3000 */       if (n instanceof Double) {
/* 3001 */         writeNumber(n.doubleValue()); return;
/*      */       } 
/* 3003 */       if (n instanceof Float) {
/* 3004 */         writeNumber(n.floatValue()); return;
/*      */       } 
/* 3006 */       if (n instanceof Short) {
/* 3007 */         writeNumber(n.shortValue()); return;
/*      */       } 
/* 3009 */       if (n instanceof Byte) {
/* 3010 */         writeNumber((short)n.byteValue()); return;
/*      */       } 
/* 3012 */       if (n instanceof BigInteger) {
/* 3013 */         writeNumber((BigInteger)n); return;
/*      */       } 
/* 3015 */       if (n instanceof BigDecimal) {
/* 3016 */         writeNumber((BigDecimal)n);
/*      */         
/*      */         return;
/*      */       } 
/* 3020 */       if (n instanceof AtomicInteger) {
/* 3021 */         writeNumber(((AtomicInteger)n).get()); return;
/*      */       } 
/* 3023 */       if (n instanceof AtomicLong) {
/* 3024 */         writeNumber(((AtomicLong)n).get()); return;
/*      */       } 
/*      */     } else {
/* 3027 */       if (value instanceof byte[]) {
/* 3028 */         writeBinary((byte[])value); return;
/*      */       } 
/* 3030 */       if (value instanceof Boolean) {
/* 3031 */         writeBoolean(((Boolean)value).booleanValue()); return;
/*      */       } 
/* 3033 */       if (value instanceof AtomicBoolean) {
/* 3034 */         writeBoolean(((AtomicBoolean)value).get()); return;
/*      */       } 
/*      */     } 
/* 3037 */     throw new IllegalStateException("No ObjectCodec defined for the generator, can only serialize simple wrapper types (type passed " + value
/* 3038 */         .getClass().getName() + ")");
/*      */   }
/*      */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\JsonGenerator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */