/*     */ package com.fasterxml.jackson.core;
/*     */ 
/*     */ import com.fasterxml.jackson.core.util.JacksonFeature;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum StreamReadCapability
/*     */   implements JacksonFeature
/*     */ {
/*  30 */   DUPLICATE_PROPERTIES(false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   SCALARS_AS_OBJECTS(false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   UNTYPED_SCALARS(false),
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   EXACT_FLOATS(false);
/*     */ 
/*     */   
/*     */   private final boolean _defaultState;
/*     */ 
/*     */   
/*     */   private final int _mask;
/*     */ 
/*     */ 
/*     */   
/*     */   StreamReadCapability(boolean defaultState) {
/*  98 */     this._defaultState = defaultState;
/*  99 */     this._mask = 1 << ordinal();
/*     */   }
/*     */   
/*     */   public boolean enabledByDefault() {
/* 103 */     return this._defaultState;
/*     */   } public boolean enabledIn(int flags) {
/* 105 */     return ((flags & this._mask) != 0);
/*     */   } public int getMask() {
/* 107 */     return this._mask;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\StreamReadCapability.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */