/*     */ package com.fasterxml.jackson.core.internal.shaded.fdp.v2_19_2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractJavaFloatingPointBitsFromCharArray
/*     */   extends AbstractFloatValueParser
/*     */ {
/*     */   private static final boolean CONDITIONAL_COMPILATION_PARSE_EIGHT_HEX_DIGITS = true;
/*     */   
/*     */   private static int skipWhitespace(char[] str, int index, int endIndex) {
/*  31 */     while (index < endIndex && str[index] <= ' ') {
/*  32 */       index++;
/*     */     }
/*  34 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract long nan();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract long negativeInfinity();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long parseDecFloatLiteral(char[] str, int index, int startIndex, int endIndex, boolean isNegative, boolean hasLeadingZero) {
/*     */     int i, digitCount, exponent;
/*     */     boolean isSignificandTruncated;
/*     */     int exponentOfTruncatedSignificand;
/*  76 */     long significand = 0L;
/*  77 */     int significandStartIndex = index;
/*  78 */     int virtualIndexOfPoint = -1;
/*  79 */     boolean illegal = false;
/*  80 */     char ch = Character.MIN_VALUE;
/*  81 */     int swarLimit = Math.min(endIndex - 4, 1073741824);
/*  82 */     for (; index < endIndex; index++) {
/*  83 */       ch = str[index];
/*  84 */       int digit = (char)(ch - 48);
/*  85 */       if (digit < 10) {
/*     */         
/*  87 */         significand = 10L * significand + digit;
/*  88 */       } else if (ch == '.') {
/*  89 */         i = illegal | ((virtualIndexOfPoint >= 0) ? 1 : 0);
/*  90 */         virtualIndexOfPoint = index;
/*  91 */         for (; index < swarLimit; index += 4) {
/*  92 */           int digits = FastDoubleSwar.tryToParseFourDigits(str, index + 1);
/*  93 */           if (digits < 0) {
/*     */             break;
/*     */           }
/*     */           
/*  97 */           significand = 10000L * significand + digits;
/*     */         } 
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 104 */     int significandEndIndex = index;
/*     */     
/* 106 */     if (virtualIndexOfPoint < 0) {
/* 107 */       digitCount = significandEndIndex - significandStartIndex;
/* 108 */       virtualIndexOfPoint = significandEndIndex;
/* 109 */       exponent = 0;
/*     */     } else {
/* 111 */       digitCount = significandEndIndex - significandStartIndex - 1;
/* 112 */       exponent = virtualIndexOfPoint - significandEndIndex + 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 117 */     int expNumber = 0;
/* 118 */     if ((ch | 0x20) == 101) {
/* 119 */       ch = charAt(str, ++index, endIndex);
/* 120 */       boolean isExponentNegative = (ch == '-');
/* 121 */       if (isExponentNegative || ch == '+') {
/* 122 */         ch = charAt(str, ++index, endIndex);
/*     */       }
/* 124 */       int digit = (char)(ch - 48);
/* 125 */       i |= (digit >= 10) ? 1 : 0;
/*     */       
/*     */       while (true) {
/* 128 */         if (expNumber < 1024) {
/* 129 */           expNumber = 10 * expNumber + digit;
/*     */         }
/* 131 */         ch = charAt(str, ++index, endIndex);
/* 132 */         digit = (char)(ch - 48);
/* 133 */         if (digit >= 10) {
/* 134 */           if (isExponentNegative) {
/* 135 */             expNumber = -expNumber;
/*     */           }
/* 137 */           exponent += expNumber;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 143 */     if ((ch | 0x22) == 102) {
/* 144 */       index++;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 149 */     index = skipWhitespace(str, index, endIndex);
/* 150 */     if (i != 0 || index < endIndex || (!hasLeadingZero && digitCount == 0))
/*     */     {
/* 152 */       throw new NumberFormatException("illegal syntax");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 158 */     int skipCountInTruncatedDigits = 0;
/*     */     
/* 160 */     if (digitCount > 19) {
/* 161 */       significand = 0L;
/* 162 */       for (index = significandStartIndex; index < significandEndIndex; index++) {
/* 163 */         ch = str[index];
/* 164 */         if (ch == '.') {
/* 165 */           skipCountInTruncatedDigits++;
/*     */         }
/* 167 */         else if (Long.compareUnsigned(significand, 1000000000000000000L) < 0) {
/* 168 */           significand = 10L * significand + ch - 48L;
/*     */         } else {
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 174 */       isSignificandTruncated = (index < significandEndIndex);
/* 175 */       exponentOfTruncatedSignificand = virtualIndexOfPoint - index + skipCountInTruncatedDigits + expNumber;
/*     */     } else {
/* 177 */       isSignificandTruncated = false;
/* 178 */       exponentOfTruncatedSignificand = 0;
/*     */     } 
/* 180 */     return valueOfFloatLiteral(str, startIndex, endIndex, isNegative, significand, exponent, isSignificandTruncated, exponentOfTruncatedSignificand);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long parseFloatingPointLiteral(char[] str, int offset, int length) {
/* 203 */     int endIndex = checkBounds(str.length, offset, length);
/*     */ 
/*     */ 
/*     */     
/* 207 */     int index = skipWhitespace(str, offset, endIndex);
/* 208 */     if (index == endIndex) {
/* 209 */       throw new NumberFormatException("illegal syntax");
/*     */     }
/* 211 */     char ch = str[index];
/*     */ 
/*     */ 
/*     */     
/* 215 */     boolean isNegative = (ch == '-');
/* 216 */     if (isNegative || ch == '+') {
/* 217 */       ch = charAt(str, ++index, endIndex);
/* 218 */       if (ch == '\000') {
/* 219 */         throw new NumberFormatException("illegal syntax");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 225 */     if (ch >= 'I') {
/* 226 */       return parseNaNOrInfinity(str, index, endIndex, isNegative);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 231 */     boolean hasLeadingZero = (ch == '0');
/* 232 */     if (hasLeadingZero) {
/* 233 */       ch = charAt(str, ++index, endIndex);
/* 234 */       if ((ch | 0x20) == 120) {
/* 235 */         return parseHexFloatLiteral(str, index + 1, offset, endIndex, isNegative);
/*     */       }
/*     */     } 
/*     */     
/* 239 */     return parseDecFloatLiteral(str, index, offset, endIndex, isNegative, hasLeadingZero);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long parseHexFloatLiteral(char[] str, int index, int startIndex, int endIndex, boolean isNegative) {
/*     */     int digitCount, i;
/*     */     boolean isSignificandTruncated;
/* 270 */     long significand = 0L;
/* 271 */     int exponent = 0;
/* 272 */     int significandStartIndex = index;
/* 273 */     int virtualIndexOfPoint = -1;
/*     */     
/* 275 */     boolean illegal = false;
/* 276 */     char ch = Character.MIN_VALUE;
/* 277 */     for (; index < endIndex; index++) {
/* 278 */       ch = str[index];
/*     */       
/* 280 */       int hexValue = lookupHex(ch);
/* 281 */       if (hexValue >= 0) {
/* 282 */         significand = significand << 4L | hexValue;
/* 283 */       } else if (hexValue == -4) {
/* 284 */         i = illegal | ((virtualIndexOfPoint >= 0) ? 1 : 0);
/* 285 */         virtualIndexOfPoint = index;
/*     */         
/* 287 */         while (index < endIndex - 8) {
/* 288 */           long parsed = tryToParseEightHexDigits(str, index + 1);
/* 289 */           if (parsed >= 0L) {
/*     */             
/* 291 */             significand = (significand << 32L) + parsed;
/*     */             
/*     */             index += 8;
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 301 */     int significandEndIndex = index;
/* 302 */     if (virtualIndexOfPoint < 0) {
/* 303 */       digitCount = significandEndIndex - significandStartIndex;
/* 304 */       virtualIndexOfPoint = significandEndIndex;
/*     */     } else {
/* 306 */       digitCount = significandEndIndex - significandStartIndex - 1;
/* 307 */       exponent = Math.min(virtualIndexOfPoint - index + 1, 1024) * 4;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 312 */     int expNumber = 0;
/* 313 */     boolean hasExponent = ((ch | 0x20) == 112);
/* 314 */     if (hasExponent) {
/* 315 */       ch = charAt(str, ++index, endIndex);
/* 316 */       boolean isExponentNegative = (ch == '-');
/* 317 */       if (isExponentNegative || ch == '+') {
/* 318 */         ch = charAt(str, ++index, endIndex);
/*     */       }
/* 320 */       int digit = (char)(ch - 48);
/* 321 */       i |= (digit >= 10) ? 1 : 0;
/*     */       
/*     */       while (true) {
/* 324 */         if (expNumber < 1024) {
/* 325 */           expNumber = 10 * expNumber + digit;
/*     */         }
/* 327 */         ch = charAt(str, ++index, endIndex);
/* 328 */         digit = (char)(ch - 48);
/* 329 */         if (digit >= 10) {
/* 330 */           if (isExponentNegative) {
/* 331 */             expNumber = -expNumber;
/*     */           }
/* 333 */           exponent += expNumber;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 339 */     if ((ch | 0x22) == 102) {
/* 340 */       index++;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 345 */     index = skipWhitespace(str, index, endIndex);
/* 346 */     if (i != 0 || index < endIndex || digitCount == 0 || !hasExponent)
/*     */     {
/*     */       
/* 349 */       throw new NumberFormatException("illegal syntax");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 355 */     int skipCountInTruncatedDigits = 0;
/* 356 */     if (digitCount > 16) {
/* 357 */       significand = 0L;
/* 358 */       for (index = significandStartIndex; index < significandEndIndex; index++) {
/* 359 */         ch = str[index];
/*     */         
/* 361 */         int hexValue = lookupHex(ch);
/* 362 */         if (hexValue >= 0) {
/* 363 */           if (Long.compareUnsigned(significand, 1000000000000000000L) < 0) {
/* 364 */             significand = significand << 4L | hexValue;
/*     */           } else {
/*     */             break;
/*     */           } 
/*     */         } else {
/* 369 */           skipCountInTruncatedDigits++;
/*     */         } 
/*     */       } 
/* 372 */       isSignificandTruncated = (index < significandEndIndex);
/*     */     } else {
/* 374 */       isSignificandTruncated = false;
/*     */     } 
/*     */     
/* 377 */     return valueOfHexLiteral(str, startIndex, endIndex, isNegative, significand, exponent, isSignificandTruncated, (virtualIndexOfPoint - index + skipCountInTruncatedDigits) * 4 + expNumber);
/*     */   }
/*     */ 
/*     */   
/*     */   private long parseNaNOrInfinity(char[] str, int index, int endIndex, boolean isNegative) {
/* 382 */     if (str[index] == 'N') {
/* 383 */       if (index + 2 < endIndex && str[index + 1] == 'a' && str[index + 2] == 'N')
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 388 */         index = skipWhitespace(str, index + 3, endIndex);
/* 389 */         if (index == endIndex) {
/* 390 */           return nan();
/*     */         }
/*     */       }
/*     */     
/* 394 */     } else if (index + 7 < endIndex && str[index] == 'I' && str[index + 1] == 'n' && str[index + 2] == 'f' && str[index + 3] == 'i' && str[index + 4] == 'n' && str[index + 5] == 'i' && str[index + 6] == 't' && str[index + 7] == 'y') {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 404 */       index = skipWhitespace(str, index + 8, endIndex);
/* 405 */       if (index == endIndex) {
/* 406 */         return isNegative ? negativeInfinity() : positiveInfinity();
/*     */       }
/*     */     } 
/*     */     
/* 410 */     throw new NumberFormatException("illegal syntax");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   abstract long positiveInfinity();
/*     */ 
/*     */ 
/*     */   
/*     */   private long tryToParseEightHexDigits(char[] str, int offset) {
/* 420 */     return FastDoubleSwar.tryToParseEightHexDigits(str, offset);
/*     */   }
/*     */   
/*     */   abstract long valueOfFloatLiteral(char[] paramArrayOfchar, int paramInt1, int paramInt2, boolean paramBoolean1, long paramLong, int paramInt3, boolean paramBoolean2, int paramInt4);
/*     */   
/*     */   abstract long valueOfHexLiteral(char[] paramArrayOfchar, int paramInt1, int paramInt2, boolean paramBoolean1, long paramLong, int paramInt3, boolean paramBoolean2, int paramInt4);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\internal\shaded\fdp\v2_19_2\AbstractJavaFloatingPointBitsFromCharArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */