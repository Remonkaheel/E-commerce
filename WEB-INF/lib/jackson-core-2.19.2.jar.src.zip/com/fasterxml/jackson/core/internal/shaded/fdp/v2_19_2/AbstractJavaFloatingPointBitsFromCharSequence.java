/*     */ package com.fasterxml.jackson.core.internal.shaded.fdp.v2_19_2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractJavaFloatingPointBitsFromCharSequence
/*     */   extends AbstractFloatValueParser
/*     */ {
/*     */   private static int skipWhitespace(CharSequence str, int index, int endIndex) {
/*  28 */     while (index < endIndex && str.charAt(index) <= ' ') {
/*  29 */       index++;
/*     */     }
/*  31 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract long nan();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract long negativeInfinity();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long parseDecFloatLiteral(CharSequence str, int index, int startIndex, int endIndex, boolean isNegative, boolean hasLeadingZero) {
/*     */     int i, digitCount, exponent;
/*     */     boolean isSignificandTruncated;
/*     */     int exponentOfTruncatedSignificand;
/*  73 */     long significand = 0L;
/*  74 */     int significandStartIndex = index;
/*  75 */     int virtualIndexOfPoint = -1;
/*  76 */     boolean illegal = false;
/*  77 */     char ch = Character.MIN_VALUE;
/*  78 */     for (; index < endIndex; index++) {
/*  79 */       ch = str.charAt(index);
/*  80 */       int digit = (char)(ch - 48);
/*  81 */       if (digit < 10) {
/*     */         
/*  83 */         significand = 10L * significand + digit;
/*  84 */       } else if (ch == '.') {
/*  85 */         i = illegal | ((virtualIndexOfPoint >= 0) ? 1 : 0);
/*  86 */         virtualIndexOfPoint = index;
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     int significandEndIndex = index;
/*     */     
/* 103 */     if (virtualIndexOfPoint < 0) {
/* 104 */       digitCount = significandEndIndex - significandStartIndex;
/* 105 */       virtualIndexOfPoint = significandEndIndex;
/* 106 */       exponent = 0;
/*     */     } else {
/* 108 */       digitCount = significandEndIndex - significandStartIndex - 1;
/* 109 */       exponent = virtualIndexOfPoint - significandEndIndex + 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 114 */     int expNumber = 0;
/* 115 */     if ((ch | 0x20) == 101) {
/* 116 */       ch = charAt(str, ++index, endIndex);
/* 117 */       boolean isExponentNegative = (ch == '-');
/* 118 */       if (isExponentNegative || ch == '+') {
/* 119 */         ch = charAt(str, ++index, endIndex);
/*     */       }
/* 121 */       int digit = (char)(ch - 48);
/* 122 */       i |= (digit >= 10) ? 1 : 0;
/*     */       
/*     */       while (true) {
/* 125 */         if (expNumber < 1024) {
/* 126 */           expNumber = 10 * expNumber + digit;
/*     */         }
/* 128 */         ch = charAt(str, ++index, endIndex);
/* 129 */         digit = (char)(ch - 48);
/* 130 */         if (digit >= 10) {
/* 131 */           if (isExponentNegative) {
/* 132 */             expNumber = -expNumber;
/*     */           }
/* 134 */           exponent += expNumber;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 140 */     if ((ch | 0x22) == 102) {
/* 141 */       index++;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 146 */     index = skipWhitespace(str, index, endIndex);
/* 147 */     if (i != 0 || index < endIndex || (!hasLeadingZero && digitCount == 0))
/*     */     {
/* 149 */       throw new NumberFormatException("illegal syntax");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 155 */     int skipCountInTruncatedDigits = 0;
/*     */     
/* 157 */     if (digitCount > 19) {
/* 158 */       significand = 0L;
/* 159 */       for (index = significandStartIndex; index < significandEndIndex; index++) {
/* 160 */         ch = str.charAt(index);
/* 161 */         if (ch == '.') {
/* 162 */           skipCountInTruncatedDigits++;
/*     */         }
/* 164 */         else if (Long.compareUnsigned(significand, 1000000000000000000L) < 0) {
/* 165 */           significand = 10L * significand + ch - 48L;
/*     */         } else {
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 171 */       isSignificandTruncated = (index < significandEndIndex);
/* 172 */       exponentOfTruncatedSignificand = virtualIndexOfPoint - index + skipCountInTruncatedDigits + expNumber;
/*     */     } else {
/* 174 */       isSignificandTruncated = false;
/* 175 */       exponentOfTruncatedSignificand = 0;
/*     */     } 
/* 177 */     return valueOfFloatLiteral(str, startIndex, endIndex, isNegative, significand, exponent, isSignificandTruncated, exponentOfTruncatedSignificand);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long parseFloatingPointLiteral(CharSequence str, int offset, int length) {
/* 200 */     int endIndex = checkBounds(str.length(), offset, length);
/*     */ 
/*     */ 
/*     */     
/* 204 */     int index = skipWhitespace(str, offset, endIndex);
/* 205 */     if (index == endIndex) {
/* 206 */       throw new NumberFormatException("illegal syntax");
/*     */     }
/* 208 */     char ch = str.charAt(index);
/*     */ 
/*     */ 
/*     */     
/* 212 */     boolean isNegative = (ch == '-');
/* 213 */     if (isNegative || ch == '+') {
/* 214 */       ch = charAt(str, ++index, endIndex);
/* 215 */       if (ch == '\000') {
/* 216 */         throw new NumberFormatException("illegal syntax");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 222 */     if (ch >= 'I') {
/* 223 */       return parseNaNOrInfinity(str, index, endIndex, isNegative);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 228 */     boolean hasLeadingZero = (ch == '0');
/* 229 */     if (hasLeadingZero) {
/* 230 */       ch = charAt(str, ++index, endIndex);
/* 231 */       if ((ch | 0x20) == 120) {
/* 232 */         return parseHexFloatLiteral(str, index + 1, offset, endIndex, isNegative);
/*     */       }
/*     */     } 
/*     */     
/* 236 */     return parseDecFloatLiteral(str, index, offset, endIndex, isNegative, hasLeadingZero);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long parseHexFloatLiteral(CharSequence str, int index, int startIndex, int endIndex, boolean isNegative) {
/*     */     int digitCount, i;
/*     */     boolean isSignificandTruncated;
/* 267 */     long significand = 0L;
/* 268 */     int exponent = 0;
/* 269 */     int significandStartIndex = index;
/* 270 */     int virtualIndexOfPoint = -1;
/*     */     
/* 272 */     boolean illegal = false;
/* 273 */     char ch = Character.MIN_VALUE;
/* 274 */     for (; index < endIndex; index++) {
/* 275 */       ch = str.charAt(index);
/*     */       
/* 277 */       int hexValue = lookupHex(ch);
/* 278 */       if (hexValue >= 0) {
/* 279 */         significand = significand << 4L | hexValue;
/* 280 */       } else if (hexValue == -4) {
/* 281 */         i = illegal | ((virtualIndexOfPoint >= 0) ? 1 : 0);
/* 282 */         virtualIndexOfPoint = index;
/* 283 */         while (index < endIndex - 8) {
/* 284 */           long parsed = FastDoubleSwar.tryToParseEightHexDigits(str, index + 1);
/* 285 */           if (parsed >= 0L) {
/*     */             
/* 287 */             significand = (significand << 32L) + parsed;
/*     */             
/*     */             index += 8;
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */     } 
/* 296 */     int significandEndIndex = index;
/* 297 */     if (virtualIndexOfPoint < 0) {
/* 298 */       digitCount = significandEndIndex - significandStartIndex;
/* 299 */       virtualIndexOfPoint = significandEndIndex;
/*     */     } else {
/* 301 */       digitCount = significandEndIndex - significandStartIndex - 1;
/* 302 */       exponent = Math.min(virtualIndexOfPoint - index + 1, 1024) * 4;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 307 */     int expNumber = 0;
/* 308 */     boolean hasExponent = ((ch | 0x20) == 112);
/* 309 */     if (hasExponent) {
/* 310 */       ch = charAt(str, ++index, endIndex);
/* 311 */       boolean isExponentNegative = (ch == '-');
/* 312 */       if (isExponentNegative || ch == '+') {
/* 313 */         ch = charAt(str, ++index, endIndex);
/*     */       }
/* 315 */       int digit = (char)(ch - 48);
/* 316 */       i |= (digit >= 10) ? 1 : 0;
/*     */       
/*     */       while (true) {
/* 319 */         if (expNumber < 1024) {
/* 320 */           expNumber = 10 * expNumber + digit;
/*     */         }
/* 322 */         ch = charAt(str, ++index, endIndex);
/* 323 */         digit = (char)(ch - 48);
/* 324 */         if (digit >= 10) {
/* 325 */           if (isExponentNegative) {
/* 326 */             expNumber = -expNumber;
/*     */           }
/* 328 */           exponent += expNumber;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 334 */     if ((ch | 0x22) == 102) {
/* 335 */       index++;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 340 */     index = skipWhitespace(str, index, endIndex);
/* 341 */     if (i != 0 || index < endIndex || digitCount == 0 || !hasExponent)
/*     */     {
/*     */       
/* 344 */       throw new NumberFormatException("illegal syntax");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 350 */     int skipCountInTruncatedDigits = 0;
/* 351 */     if (digitCount > 16) {
/* 352 */       significand = 0L;
/* 353 */       for (index = significandStartIndex; index < significandEndIndex; index++) {
/* 354 */         ch = str.charAt(index);
/*     */         
/* 356 */         int hexValue = lookupHex(ch);
/* 357 */         if (hexValue >= 0) {
/* 358 */           if (Long.compareUnsigned(significand, 1000000000000000000L) < 0) {
/* 359 */             significand = significand << 4L | hexValue;
/*     */           } else {
/*     */             break;
/*     */           } 
/*     */         } else {
/* 364 */           skipCountInTruncatedDigits++;
/*     */         } 
/*     */       } 
/* 367 */       isSignificandTruncated = (index < significandEndIndex);
/*     */     } else {
/* 369 */       isSignificandTruncated = false;
/*     */     } 
/*     */     
/* 372 */     return valueOfHexLiteral(str, startIndex, endIndex, isNegative, significand, exponent, isSignificandTruncated, (virtualIndexOfPoint - index + skipCountInTruncatedDigits) * 4 + expNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private long parseNaNOrInfinity(CharSequence str, int index, int endIndex, boolean isNegative) {
/* 378 */     if (str.charAt(index) == 'N') {
/* 379 */       if (index + 2 < endIndex && str
/*     */         
/* 381 */         .charAt(index + 1) == 'a' && str
/* 382 */         .charAt(index + 2) == 'N')
/*     */       {
/* 384 */         index = skipWhitespace(str, index + 3, endIndex);
/* 385 */         if (index == endIndex) {
/* 386 */           return nan();
/*     */         }
/*     */       }
/*     */     
/* 390 */     } else if (index + 7 < endIndex && str
/* 391 */       .charAt(index) == 'I' && str
/* 392 */       .charAt(index + 1) == 'n' && str
/* 393 */       .charAt(index + 2) == 'f' && str
/* 394 */       .charAt(index + 3) == 'i' && str
/* 395 */       .charAt(index + 4) == 'n' && str
/* 396 */       .charAt(index + 5) == 'i' && str
/* 397 */       .charAt(index + 6) == 't' && str
/* 398 */       .charAt(index + 7) == 'y') {
/*     */       
/* 400 */       index = skipWhitespace(str, index + 8, endIndex);
/* 401 */       if (index == endIndex) {
/* 402 */         return isNegative ? negativeInfinity() : positiveInfinity();
/*     */       }
/*     */     } 
/*     */     
/* 406 */     throw new NumberFormatException("illegal syntax");
/*     */   }
/*     */   
/*     */   abstract long positiveInfinity();
/*     */   
/*     */   abstract long valueOfFloatLiteral(CharSequence paramCharSequence, int paramInt1, int paramInt2, boolean paramBoolean1, long paramLong, int paramInt3, boolean paramBoolean2, int paramInt4);
/*     */   
/*     */   abstract long valueOfHexLiteral(CharSequence paramCharSequence, int paramInt1, int paramInt2, boolean paramBoolean1, long paramLong, int paramInt3, boolean paramBoolean2, int paramInt4);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\internal\shaded\fdp\v2_19_2\AbstractJavaFloatingPointBitsFromCharSequence.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */