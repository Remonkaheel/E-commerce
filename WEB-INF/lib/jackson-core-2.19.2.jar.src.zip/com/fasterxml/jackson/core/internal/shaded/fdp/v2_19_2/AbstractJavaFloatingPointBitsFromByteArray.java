/*     */ package com.fasterxml.jackson.core.internal.shaded.fdp.v2_19_2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractJavaFloatingPointBitsFromByteArray
/*     */   extends AbstractFloatValueParser
/*     */ {
/*     */   private static int skipWhitespace(byte[] str, int index, int endIndex) {
/*  28 */     while (index < endIndex && (str[index] & 0xFF) <= 32) {
/*  29 */       index++;
/*     */     }
/*  31 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract long nan();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract long negativeInfinity();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long parseDecFloatLiteral(byte[] str, int index, int startIndex, int endIndex, boolean isNegative, boolean hasLeadingZero) {
/*     */     int i, digitCount, exponent;
/*     */     boolean isSignificandTruncated;
/*     */     int exponentOfTruncatedSignificand;
/*  73 */     long significand = 0L;
/*  74 */     int significandStartIndex = index;
/*  75 */     int virtualIndexOfPoint = -1;
/*  76 */     boolean illegal = false;
/*  77 */     byte ch = 0;
/*  78 */     for (; index < endIndex; index++) {
/*  79 */       ch = str[index];
/*  80 */       char digit = (char)(ch - 48);
/*  81 */       if (digit < '\n') {
/*     */         
/*  83 */         significand = 10L * significand + digit;
/*  84 */       } else if (ch == 46) {
/*  85 */         i = illegal | ((virtualIndexOfPoint >= 0) ? 1 : 0);
/*  86 */         virtualIndexOfPoint = index;
/*  87 */         for (; index < endIndex - 4; index += 4) {
/*  88 */           int digits = FastDoubleSwar.tryToParseFourDigits(str, index + 1);
/*  89 */           if (digits < 0) {
/*     */             break;
/*     */           }
/*     */           
/*  93 */           significand = 10000L * significand + digits;
/*     */         } 
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 100 */     int significandEndIndex = index;
/*     */     
/* 102 */     if (virtualIndexOfPoint < 0) {
/* 103 */       digitCount = index - significandStartIndex;
/* 104 */       virtualIndexOfPoint = index;
/* 105 */       exponent = 0;
/*     */     } else {
/* 107 */       digitCount = index - significandStartIndex - 1;
/* 108 */       exponent = virtualIndexOfPoint - index + 1;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 113 */     int expNumber = 0;
/* 114 */     if ((ch | 0x20) == 101) {
/* 115 */       ch = charAt(str, ++index, endIndex);
/* 116 */       boolean isExponentNegative = (ch == 45);
/* 117 */       if (isExponentNegative || ch == 43) {
/* 118 */         ch = charAt(str, ++index, endIndex);
/*     */       }
/* 120 */       int digit = (char)(ch - 48);
/* 121 */       i |= (digit >= 10) ? 1 : 0;
/*     */       
/*     */       while (true) {
/* 124 */         if (expNumber < 1024) {
/* 125 */           expNumber = 10 * expNumber + digit;
/*     */         }
/* 127 */         ch = charAt(str, ++index, endIndex);
/* 128 */         digit = (char)(ch - 48);
/* 129 */         if (digit >= 10) {
/* 130 */           if (isExponentNegative) {
/* 131 */             expNumber = -expNumber;
/*     */           }
/* 133 */           exponent += expNumber;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 139 */     if ((ch | 0x22) == 102) {
/* 140 */       index++;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 145 */     index = skipWhitespace(str, index, endIndex);
/* 146 */     if (i != 0 || index < endIndex || (!hasLeadingZero && digitCount == 0))
/*     */     {
/* 148 */       throw new NumberFormatException("illegal syntax");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 154 */     int skipCountInTruncatedDigits = 0;
/*     */     
/* 156 */     if (digitCount > 19) {
/* 157 */       significand = 0L;
/* 158 */       for (index = significandStartIndex; index < significandEndIndex; index++) {
/* 159 */         ch = str[index];
/* 160 */         if (ch == 46) {
/* 161 */           skipCountInTruncatedDigits++;
/*     */         }
/* 163 */         else if (Long.compareUnsigned(significand, 1000000000000000000L) < 0) {
/* 164 */           significand = 10L * significand + ch - 48L;
/*     */         } else {
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 170 */       isSignificandTruncated = (index < significandEndIndex);
/* 171 */       exponentOfTruncatedSignificand = virtualIndexOfPoint - index + skipCountInTruncatedDigits + expNumber;
/*     */     } else {
/* 173 */       isSignificandTruncated = false;
/* 174 */       exponentOfTruncatedSignificand = 0;
/*     */     } 
/* 176 */     return valueOfFloatLiteral(str, startIndex, endIndex, isNegative, significand, exponent, isSignificandTruncated, exponentOfTruncatedSignificand);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long parseFloatingPointLiteral(byte[] str, int offset, int length) {
/* 200 */     int endIndex = checkBounds(str.length, offset, length);
/*     */ 
/*     */ 
/*     */     
/* 204 */     int index = skipWhitespace(str, offset, endIndex);
/* 205 */     if (index == endIndex) {
/* 206 */       throw new NumberFormatException("illegal syntax");
/*     */     }
/* 208 */     byte ch = str[index];
/*     */ 
/*     */ 
/*     */     
/* 212 */     boolean isNegative = (ch == 45);
/* 213 */     if (isNegative || ch == 43) {
/* 214 */       ch = charAt(str, ++index, endIndex);
/* 215 */       if (ch == 0) {
/* 216 */         throw new NumberFormatException("illegal syntax");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 222 */     if (ch >= 73) {
/* 223 */       return parseNaNOrInfinity(str, index, endIndex, isNegative);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 228 */     boolean hasLeadingZero = (ch == 48);
/* 229 */     if (hasLeadingZero) {
/* 230 */       ch = charAt(str, ++index, endIndex);
/* 231 */       if ((ch | 0x20) == 120) {
/* 232 */         return parseHexFloatingPointLiteral(str, index + 1, offset, endIndex, isNegative);
/*     */       }
/*     */     } 
/*     */     
/* 236 */     return parseDecFloatLiteral(str, index, offset, endIndex, isNegative, hasLeadingZero);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long parseHexFloatingPointLiteral(byte[] str, int index, int startIndex, int endIndex, boolean isNegative) {
/*     */     int digitCount, i;
/*     */     boolean isSignificandTruncated;
/* 267 */     long significand = 0L;
/* 268 */     int exponent = 0;
/* 269 */     int significandStartIndex = index;
/* 270 */     int virtualIndexOfPoint = -1;
/*     */     
/* 272 */     boolean illegal = false;
/* 273 */     byte ch = 0;
/* 274 */     for (; index < endIndex; index++) {
/* 275 */       ch = str[index];
/*     */       
/* 277 */       int hexValue = lookupHex(ch);
/* 278 */       if (hexValue >= 0) {
/* 279 */         significand = significand << 4L | hexValue;
/* 280 */       } else if (hexValue == -4) {
/* 281 */         i = illegal | ((virtualIndexOfPoint >= 0) ? 1 : 0);
/* 282 */         virtualIndexOfPoint = index;
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 298 */     int significandEndIndex = index;
/* 299 */     if (virtualIndexOfPoint < 0) {
/* 300 */       digitCount = significandEndIndex - significandStartIndex;
/* 301 */       virtualIndexOfPoint = significandEndIndex;
/*     */     } else {
/* 303 */       digitCount = significandEndIndex - significandStartIndex - 1;
/* 304 */       exponent = Math.min(virtualIndexOfPoint - index + 1, 1024) * 4;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 309 */     int expNumber = 0;
/* 310 */     boolean hasExponent = ((ch | 0x20) == 112);
/* 311 */     if (hasExponent) {
/* 312 */       ch = charAt(str, ++index, endIndex);
/* 313 */       boolean isExponentNegative = (ch == 45);
/* 314 */       if (isExponentNegative || ch == 43) {
/* 315 */         ch = charAt(str, ++index, endIndex);
/*     */       }
/* 317 */       int digit = (char)(ch - 48);
/* 318 */       i |= (digit >= 10) ? 1 : 0;
/*     */       
/*     */       while (true) {
/* 321 */         if (expNumber < 1024) {
/* 322 */           expNumber = 10 * expNumber + digit;
/*     */         }
/* 324 */         ch = charAt(str, ++index, endIndex);
/* 325 */         digit = (char)(ch - 48);
/* 326 */         if (digit >= 10) {
/* 327 */           if (isExponentNegative) {
/* 328 */             expNumber = -expNumber;
/*     */           }
/* 330 */           exponent += expNumber;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 336 */     if ((ch | 0x22) == 102) {
/* 337 */       index++;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 342 */     index = skipWhitespace(str, index, endIndex);
/* 343 */     if (i != 0 || index < endIndex || digitCount == 0 || !hasExponent)
/*     */     {
/*     */       
/* 346 */       throw new NumberFormatException("illegal syntax");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 352 */     int skipCountInTruncatedDigits = 0;
/* 353 */     if (digitCount > 16) {
/* 354 */       significand = 0L;
/* 355 */       for (index = significandStartIndex; index < significandEndIndex; index++) {
/* 356 */         ch = str[index];
/*     */         
/* 358 */         int hexValue = lookupHex(ch);
/* 359 */         if (hexValue >= 0) {
/* 360 */           if (Long.compareUnsigned(significand, 1000000000000000000L) < 0) {
/* 361 */             significand = significand << 4L | hexValue;
/*     */           } else {
/*     */             break;
/*     */           } 
/*     */         } else {
/* 366 */           skipCountInTruncatedDigits++;
/*     */         } 
/*     */       } 
/* 369 */       isSignificandTruncated = (index < significandEndIndex);
/*     */     } else {
/* 371 */       isSignificandTruncated = false;
/*     */     } 
/*     */     
/* 374 */     return valueOfHexLiteral(str, startIndex, endIndex, isNegative, significand, exponent, isSignificandTruncated, (virtualIndexOfPoint - index + skipCountInTruncatedDigits) * 4 + expNumber);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private long parseNaNOrInfinity(byte[] str, int index, int endIndex, boolean isNegative) {
/* 380 */     if (str[index] == 78) {
/* 381 */       if (index + 2 < endIndex && str[index + 1] == 97 && str[index + 2] == 78)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 386 */         index = skipWhitespace(str, index + 3, endIndex);
/* 387 */         if (index == endIndex) {
/* 388 */           return nan();
/*     */         }
/*     */       }
/*     */     
/* 392 */     } else if (index + 7 < endIndex && 
/* 393 */       FastDoubleSwar.readLongLE(str, index) == 8751735898823355977L) {
/*     */       
/* 395 */       index = skipWhitespace(str, index + 8, endIndex);
/* 396 */       if (index == endIndex) {
/* 397 */         return isNegative ? negativeInfinity() : positiveInfinity();
/*     */       }
/*     */     } 
/*     */     
/* 401 */     throw new NumberFormatException("illegal syntax");
/*     */   }
/*     */   
/*     */   abstract long positiveInfinity();
/*     */   
/*     */   abstract long valueOfFloatLiteral(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, boolean paramBoolean1, long paramLong, int paramInt3, boolean paramBoolean2, int paramInt4);
/*     */   
/*     */   abstract long valueOfHexLiteral(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, boolean paramBoolean1, long paramLong, int paramInt3, boolean paramBoolean2, int paramInt4);
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\internal\shaded\fdp\v2_19_2\AbstractJavaFloatingPointBitsFromByteArray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */