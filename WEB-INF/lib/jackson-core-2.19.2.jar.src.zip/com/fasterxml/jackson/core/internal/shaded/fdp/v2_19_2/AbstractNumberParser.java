/*     */ package com.fasterxml.jackson.core.internal.shaded.fdp.v2_19_2;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class AbstractNumberParser
/*     */ {
/*     */   public static final String ILLEGAL_OFFSET_OR_ILLEGAL_LENGTH = "offset < 0 or length > str.length";
/*     */   public static final String SYNTAX_ERROR = "illegal syntax";
/*     */   public static final String VALUE_EXCEEDS_LIMITS = "value exceeds limits";
/*     */   static final byte DECIMAL_POINT_CLASS = -4;
/*     */   static final byte OTHER_CLASS = -1;
/*  40 */   static final byte[] CHAR_TO_HEX_MAP = new byte[256];
/*     */   
/*     */   static {
/*  43 */     Arrays.fill(CHAR_TO_HEX_MAP, (byte)-1); char ch;
/*  44 */     for (ch = '0'; ch <= '9'; ch = (char)(ch + 1)) {
/*  45 */       CHAR_TO_HEX_MAP[ch] = (byte)(ch - 48);
/*     */     }
/*  47 */     for (ch = 'A'; ch <= 'F'; ch = (char)(ch + 1)) {
/*  48 */       CHAR_TO_HEX_MAP[ch] = (byte)(ch - 65 + 10);
/*     */     }
/*  50 */     for (ch = 'a'; ch <= 'f'; ch = (char)(ch + 1)) {
/*  51 */       CHAR_TO_HEX_MAP[ch] = (byte)(ch - 97 + 10);
/*     */     }
/*  53 */     CHAR_TO_HEX_MAP[46] = -4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static byte charAt(byte[] str, int i, int endIndex) {
/*  66 */     return (i < endIndex) ? str[i] : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static char charAt(char[] str, int i, int endIndex) {
/*  79 */     return (i < endIndex) ? str[i] : Character.MIN_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static char charAt(CharSequence str, int i, int endIndex) {
/*  92 */     return (i < endIndex) ? str.charAt(i) : Character.MIN_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int lookupHex(byte ch) {
/* 105 */     return CHAR_TO_HEX_MAP[ch & 0xFF];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int lookupHex(char ch) {
/* 124 */     return (ch < '') ? CHAR_TO_HEX_MAP[ch] : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int checkBounds(int size, int offset, int length, int maxInputLength) {
/* 138 */     if (length > maxInputLength) {
/* 139 */       throw new NumberFormatException("value exceeds limits");
/*     */     }
/* 141 */     return checkBounds(size, offset, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int checkBounds(int size, int offset, int length) {
/* 154 */     if ((offset | length | size - length - offset) < 0) {
/* 155 */       throw new IllegalArgumentException("offset < 0 or length > str.length");
/*     */     }
/* 157 */     return length + offset;
/*     */   }
/*     */ }


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\internal\shaded\fdp\v2_19_2\AbstractNumberParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */