package com.fasterxml.jackson.core.internal.shaded.fdp.v2_19_2;

abstract class AbstractFloatValueParser extends AbstractNumberParser {
  public static final int MAX_INPUT_LENGTH = 2147483643;
  
  static final long MINIMAL_NINETEEN_DIGIT_INTEGER = 1000000000000000000L;
  
  static final int MAX_EXPONENT_NUMBER = 1024;
}


/* Location:              C:\Users\oremo\Downloads\e-commerce.war!\WEB-INF\lib\jackson-core-2.19.2.jar!\com\fasterxml\jackson\core\internal\shaded\fdp\v2_19_2\AbstractFloatValueParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */